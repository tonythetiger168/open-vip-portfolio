// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sata_if.sv -- SATA interface (minimal companion VIP model)
`ifndef SATA_IF_SV
`define SATA_IF_SV
interface sata_if (input logic clk, input logic rst_n);
  logic [31:0] data;
  logic [7:0]  cmd;
  logic        valid;
  logic        ready;
  modport TB (input clk, rst_n, ready, output data, cmd, valid);
  modport DUT (input clk, rst_n, data, cmd, valid, output ready);
endinterface
`endif
