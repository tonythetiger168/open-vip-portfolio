// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sata_pkg.sv -- SATA companion VIP package (minimal functional model)
`ifndef SATA_PKG_SV
`define SATA_PKG_SV
package sata_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class sata_transaction extends uvm_sequence_item;
    `uvm_object_utils(sata_transaction)
    rand logic [31:0] data;
    rand logic [7:0]  cmd;
    rand int unsigned delay;
    constraint c_delay { delay inside {[0:20]}; }
    function new(string name="sata_transaction"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("SATA cmd=0x%02x data=0x%08x", cmd, data);
    endfunction
  endclass

  class sata_config extends uvm_object;
    `uvm_object_utils(sata_config)
    bit active = 1;
    function new(string name="sata_config"); super.new(name); endfunction
  endclass

  class sata_sequencer extends uvm_sequencer #(sata_transaction);
    `uvm_component_utils(sata_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  class sata_driver extends uvm_driver #(sata_transaction);
    `uvm_component_utils(sata_driver)
    virtual sata_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual sata_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "sata driver: vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      sata_transaction tx;
      vif.valid <= 0;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(tx);
        repeat (tx.delay) @(posedge vif.clk);
        vif.data  <= tx.data;
        vif.cmd   <= tx.cmd;
        vif.valid <= 1'b1;
        do @(posedge vif.clk); while (!vif.ready);
        vif.valid <= 1'b0;
        seq_item_port.item_done();
      end
    endtask
  endclass

  class sata_monitor extends uvm_monitor;
    `uvm_component_utils(sata_monitor)
    virtual sata_if vif;
    uvm_analysis_port #(sata_transaction) ap;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual sata_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "sata monitor: vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      sata_transaction tx;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n && vif.valid && vif.ready) begin
          tx = sata_transaction::type_id::create("mon_tx");
          tx.data = vif.data;
          tx.cmd  = vif.cmd;
          ap.write(tx);
        end
      end
    endtask
  endclass

  class sata_agent extends uvm_agent;
    `uvm_component_utils(sata_agent)
    sata_sequencer sqr;
    sata_driver    drv;
    sata_monitor   mon;
    uvm_analysis_port #(sata_transaction) ap;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = sata_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = sata_sequencer::type_id::create("sqr", this);
        drv = sata_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(ap);
    endfunction
  endclass

  class sata_random_sequence extends uvm_sequence #(sata_transaction);
    `uvm_object_utils(sata_random_sequence)
    rand int num_txns = 10;
    function new(string name="sata_random_sequence"); super.new(name); endfunction
    task body();
      sata_transaction tx;
      repeat (num_txns) begin
        tx = sata_transaction::type_id::create("tx");
        start_item(tx);
        void'(tx.randomize());
        finish_item(tx);
      end
    endtask
  endclass
endpackage
`endif
