// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_displayport2_tb.sv -- self-checking functional test for the
// DisplayPort 2 sink model (displayport2_sink_model in top/top_tb.sv,
// flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py DisplayPort2-VIP
//
// Model contract (from top/top_tb.sv), one event per clock:
//   * msa_valid counts a frame; with main_stream_active the MSA is checked:
//     hactive > htotal or vactive > vtotal is one timing error, hsync_end <
//     hsync_start or vsync_end < vsync_start another (each `uvm_error).
//   * sdp_valid counts an SDP; type 0x30 (PSR) is also counted as PSR.
//   * the sink becomes "trained" on K28.5 (0xBC) on all four lanes; after
//     that a K character during active video is counted (`uvm_warning).
//     lane_data carries one 8-bit symbol per lane (lane 0 in [7:0]).
module func_displayport2_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0, provoked = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [31:0] lane_data = '0;
  logic [3:0]  lane_k = '0;
  logic        lt_done = 1'b0, sdp_valid = 1'b0, msa_valid = 1'b0, active = 1'b0;
  logic [7:0]  sdp_type = '0;
  logic [23:0] htotal, vtotal, hactive, vactive, hs0, hs1, vs0, vs1;

  always #5 clk = ~clk;

  displayport2_sink_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_lane_data(lane_data), .vif_lane_k(lane_k),
    .vif_link_training_done(lt_done), .vif_sdp_type(sdp_type), .vif_sdp_valid(sdp_valid),
    .vif_msa_valid(msa_valid), .vif_htotal(htotal), .vif_vtotal(vtotal), .vif_hactive(hactive),
    .vif_vactive(vactive), .vif_hsync_start(hs0), .vif_hsync_end(hs1), .vif_vsync_start(vs0),
    .vif_vsync_end(vs1), .vif_main_stream_active(active)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // 1080p60 CTA timing
  task automatic timing_1080p();
    htotal = 2200; hactive = 1920; hs0 = 2008; hs1 = 2052;
    vtotal = 1125; vactive = 1080; vs0 = 1084; vs1 = 1089;
  endtask

  task automatic msa();
    @(negedge clk); msa_valid = 1;
    @(negedge clk); msa_valid = 0;
  endtask

  task automatic sdp(input [7:0] t);
    @(negedge clk); sdp_valid = 1; sdp_type = t;
    @(negedge clk); sdp_valid = 0;
  endtask

  int f0, e0;

  initial begin
    timing_1080p();
    repeat (2) @(negedge clk);
    rst_n = 1;
    @(negedge clk);

    // training pattern: K28.5 on all lanes
    lane_k = 4'hF; lane_data = {3{8'hBC}} << 8 | 32'h4A;   // lane 0 not K28.5
    repeat (4) @(negedge clk);
    chk(u_dut.trained === 1'b0, "K28.5 on only three lanes does not train");
    lane_k = 4'h7; lane_data = {4{8'hBC}};
    repeat (2) @(negedge clk);
    chk(u_dut.trained === 1'b0, "K flag missing on lane 3 does not train");
    lane_k = 4'hF;
    repeat (4) @(negedge clk);
    chk(u_dut.trained === 1'b1, "K28.5 on all four lanes completes training");
    lane_k = 4'h0; lane_data = 4'h0; lt_done = 1;

    // legal frames
    active = 1;
    f0 = u_dut.frame_cnt; e0 = u_dut.timing_err_cnt;
    repeat (3) msa();
    chk(u_dut.frame_cnt == f0 + 3 && u_dut.timing_err_cnt == e0, "three legal 1080p MSAs counted, no error");

    // 4K timing at the limit: active == total is legal
    htotal = 4400; hactive = 4400; vtotal = 2250; vactive = 2250;
    hs0 = 100; hs1 = 100; vs0 = 7; vs1 = 7;
    msa();
    chk(u_dut.timing_err_cnt == e0, "active == total and sync end == start are legal");

    // timing violations (each provokes one `uvm_error)
    timing_1080p(); hactive = 2201;
    msa(); provoked++;
    chk(u_dut.timing_err_cnt == e0 + 1, "hactive > htotal flagged");
    timing_1080p(); vactive = 1126;
    msa(); provoked++;
    chk(u_dut.timing_err_cnt == e0 + 2, "vactive > vtotal flagged");
    timing_1080p(); hs1 = 2000;
    msa(); provoked++;
    chk(u_dut.timing_err_cnt == e0 + 3, "hsync end before start flagged");
    timing_1080p(); vs1 = 1083;
    msa(); provoked++;
    chk(u_dut.timing_err_cnt == e0 + 4, "vsync end before start flagged");
    timing_1080p(); hactive = 3000; vs1 = 0;
    msa(); provoked += 2;
    chk(u_dut.timing_err_cnt == e0 + 6, "active and sync violations in one MSA are both flagged");

    // MSA while the main stream is off: counted, not checked
    active = 0; hactive = 3000;
    f0 = u_dut.frame_cnt;
    msa();
    chk(u_dut.frame_cnt == f0 + 1 && u_dut.timing_err_cnt == e0 + 6, "MSA without main stream counted, not checked");
    timing_1080p(); active = 1;

    // SDPs
    f0 = u_dut.sdp_cnt;
    sdp(8'h83); sdp(8'h84); sdp(8'h30); sdp(8'h07); sdp(8'h30);
    chk(u_dut.sdp_cnt == f0 + 5, "every SDP counted");
    chk(u_dut.psr_cnt == 2, "PSR SDPs (type 0x30) counted");

    // K character inside active video
    @(negedge clk); lane_k = 4'h2;
    @(negedge clk); lane_k = 4'h0;
    chk(u_dut.kchar_err_cnt == 1, "K character during active video after training is flagged");
    lt_done = 0;
    @(negedge clk); lane_k = 4'h1;
    @(negedge clk); lane_k = 4'h0;
    chk(u_dut.kchar_err_cnt == 1, "no K-character check before link training is done");

    // reset
    @(negedge clk); rst_n = 0;
    @(negedge clk);
    chk(u_dut.trained === 1'b0, "reset clears the training state");
    rst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d dut_errors=%0d", checks, xfails, provoked);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
