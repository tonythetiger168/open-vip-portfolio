// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// env_pkg.sv -- 5-Protocol Verification Environment

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sata_pkg::*;
  import nvme_pkg::*;
  import jtag_pkg::*;
  import bluetooth5_pkg::*;
  import displayport2_pkg::*;

  // Distinct analysis-imp types per protocol (multiple plain uvm_analysis_imp
  // overloads of write() in one class are ambiguous to some compilers)
  `uvm_analysis_imp_decl(_sata)
  `uvm_analysis_imp_decl(_nvme)
  `uvm_analysis_imp_decl(_jtag)
  `uvm_analysis_imp_decl(_bt5)
  `uvm_analysis_imp_decl(_dp2)

  class multi_protocol_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(multi_protocol_scoreboard)
    uvm_analysis_imp_sata #(sata_transaction, multi_protocol_scoreboard) sata_ap;
    uvm_analysis_imp_nvme #(nvme_transaction, multi_protocol_scoreboard) nvme_ap;
    uvm_analysis_imp_jtag #(jtag_transaction, multi_protocol_scoreboard) jtag_ap;
    uvm_analysis_imp_bt5  #(bluetooth5_transaction, multi_protocol_scoreboard) bt5_ap;
    uvm_analysis_imp_dp2  #(displayport2_transaction, multi_protocol_scoreboard) dp2_ap;
    int sata_count=0, nvme_count=0, jtag_count=0, bt5_count=0, dp2_count=0;
    int total_count=0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      sata_ap = new("sata_ap", this); nvme_ap = new("nvme_ap", this);
      jtag_ap = new("jtag_ap", this); bt5_ap  = new("bt5_ap", this);
      dp2_ap  = new("dp2_ap", this);
    endfunction
    function void write_sata(sata_transaction tx);       sata_count++; total_count++; endfunction
    function void write_nvme(nvme_transaction tx);       nvme_count++; total_count++; endfunction
    function void write_jtag(jtag_transaction tx);       jtag_count++; total_count++; endfunction
    function void write_bt5(bluetooth5_transaction tx);  bt5_count++;  total_count++; endfunction
    function void write_dp2(displayport2_transaction tx);dp2_count++; total_count++; endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("SCOREBOARD", "=== 5-PROTOCOL SCOREBOARD ===", UVM_LOW)
      `uvm_info("SCOREBOARD", $sformatf("SATA:%0d NVMe:%0d JTAG:%0d BT5:%0d DP2:%0d TOT:%0d",
        sata_count, nvme_count, jtag_count, bt5_count, dp2_count, total_count), UVM_LOW)
    endfunction
  endclass

  class multi_protocol_env extends uvm_env;
    `uvm_component_utils(multi_protocol_env)
    sata_agent sata_agt; nvme_agent nvme_agt; jtag_agent jtag_agt;
    bluetooth5_agent bt5_agt; displayport2_agent dp2_agt;
    displayport2_scoreboard dp2_sb;
    multi_protocol_scoreboard sb;
    vip_config env_cfg;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(vip_config)::get(this, "", "cfg", env_cfg))
        env_cfg = vip_config::type_id::create("env_cfg");
      sata_agt = sata_agent::type_id::create("sata_agt", this);
      nvme_agt = nvme_agent::type_id::create("nvme_agt", this);
      jtag_agt = jtag_agent::type_id::create("jtag_agt", this);
      bt5_agt  = bluetooth5_agent::type_id::create("bt5_agt", this);
      dp2_agt  = displayport2_agent::type_id::create("dp2_agt", this);
      dp2_sb = displayport2_scoreboard::type_id::create("dp2_sb", this);
      uvm_config_db#(sata_config)::set(this, "sata_agt", "cfg", sata_config::type_id::create("c"));
      uvm_config_db#(nvme_config)::set(this, "nvme_agt", "cfg", nvme_config::type_id::create("c"));
      uvm_config_db#(jtag_config)::set(this, "jtag_agt", "cfg", jtag_config::type_id::create("c"));
      uvm_config_db#(bluetooth5_config)::set(this, "bt5_agt", "cfg", bluetooth5_config::type_id::create("c"));
      uvm_config_db#(displayport2_config)::set(this, "dp2_agt", "cfg", displayport2_config::type_id::create("c"));
      if (env_cfg.enable_scoreboard) sb = multi_protocol_scoreboard::type_id::create("sb", this);
    endfunction
    function uvm_object create_cfg(uvm_object cfg_); return cfg_; endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (env_cfg.enable_scoreboard) begin
        sata_agt.ap.connect(sb.sata_ap); nvme_agt.ap.connect(sb.nvme_ap);
        jtag_agt.ap.connect(sb.jtag_ap); bt5_agt.ap.connect(sb.bt5_ap);
        dp2_agt.ap.connect(sb.dp2_ap);
        // end-to-end DP2 scoreboard: expected (driver) vs observed (monitor)
        dp2_agt.drv.drv_ap.connect(dp2_sb.exp_ap);
        dp2_agt.ap.connect(dp2_sb.obs_ap);
      end
    endfunction
  endclass
endpackage
