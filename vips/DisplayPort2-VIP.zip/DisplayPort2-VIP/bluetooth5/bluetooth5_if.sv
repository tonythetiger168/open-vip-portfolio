// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// bluetooth5_if.sv -- BLUETOOTH5 interface (minimal companion VIP model)
`ifndef BLUETOOTH5_IF_SV
`define BLUETOOTH5_IF_SV
interface bluetooth5_if (input logic clk, input logic rst_n);
  logic [31:0] data;
  logic [7:0]  cmd;
  logic        valid;
  logic        ready;
  modport TB (input clk, rst_n, ready, output data, cmd, valid);
  modport DUT (input clk, rst_n, data, cmd, valid, output ready);
endinterface
`endif
