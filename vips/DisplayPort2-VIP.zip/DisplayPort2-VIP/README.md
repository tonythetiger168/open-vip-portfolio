# DisplayPort2 - DisplayPort 2.x UVM VIP

Open-source UVM verification IP for **DisplayPort 2.x** (deepened), packaged
with minimal companion VIPs (SATA / NVMe / JTAG / Bluetooth5) sharing the
`multi_protocol_env`.

## Protocol overview

DisplayPort 2.x main link: 1/2/4 lanes at RBR/HBR/HBR2/HBR3/UHBR10/UHBR13.5/
UHBR20, 128b/132b (UHBR) or ANSI 8b/10b channel coding with K-characters,
link training (TPS1 clock recovery / TPS2 channel equalization), Main Stream
Attribute (MSA) timing packets, Secondary Data Packets (SDP: audio, PPS/DSC,
HDR, PSR), DSC/FEC for UHBR, and Panel Self Refresh (PSR) / panel replay.

## Architecture

| Path | Description |
|------|-------------|
| `displayport2/displayport2_if.sv` | Main-link interface (lanes, K-markers, training, MSA, SDP, PSR, MST) |
| `displayport2/displayport2_pkg.sv` | UVM package: config / transaction / sequencer / **driver (link training + MSA/SDP streaming)** / **monitor (waveform decode)** / checker / coverage / **scoreboard** / agent / sequences |
| `displayport2/sva/displayport2_compliance_checker.sv` | Tiered SVA checker: L1 / L2 / L3 / **L4** |
| `displayport2/vip/displayport2/*.sv` | Protocol / timing / error / data-integrity checker modules |
| `env/env_pkg.sv` | `multi_protocol_env` + `multi_protocol_scoreboard` + end-to-end `displayport2_scoreboard` |
| `tests/test_pkg.sv` | Per-protocol tests + DP2 directed tests + `full_regression_test` |
| `top/top_tb.sv` | TB top + **functional DP2 sink model** (MSA timing checks, frame/SDP/PSR accounting) + companion DUT responders |
| `sata/ nvme/ jtag/ bluetooth5/` | Minimal companion VIPs (transaction/driver/monitor/agent/sequence) |
| `regression/` | Makefile + coverage regression |

## Closed loop

The driver performs link training (K28.5 TPS1/TPS2), drives MSA timing and
SDP packets; the sink model checks MSA timing rules and accounts frames/SDPs;
the monitor reconstructs transactions from the waveform and the end-to-end
scoreboard compares expected (driver `drv_ap`) vs observed (monitor `ap`).

## Directed sequence library

| Sequence | Purpose |
|----------|---------|
| `displayport2_random_sequence` | randomized traffic |
| `displayport2_uhbr_sequence` | UHBR10/13.5/20 rates |
| `displayport2_dsc_sequence` | DSC + FEC enabled |
| `displayport2_8k_sequence` | 7680x4320 corner resolution |
| `displayport2_error_sequence` | K-marker corruption error injection |
| `displayport2_back_to_back_sequence` | minimum frame gap |
| `displayport2_reset_sequence` | single small frame after reset |
| `displayport2_psr_sequence` | PSR / panel-replay, stream inactive |
| `displayport2_stress_sequence` | 8K UHBR stress |
| `displayport2_regression_sequence` | weighted mix of all of the above |

Tests: `dp2_random_test`, `dp2_regression_test`, `dp2_error_test`,
`dp2_psr_test`, plus companion `<proto>_random/regression_test` and
`full_regression_test`.

## SVA compliance levels

- **L1 Basic Compliance (4)**: link rate / lane count / BPP / SDP type legal
- **L2 Full Protocol (6)**: training before stream, MSA with active stream, H/V active <= total, H/V sync valid
- **L3 Advanced Features (4)**: UHBR with FEC, DSC with BPP, PSR with stream, MST valid
- **L4 Protocol-Specific (4)**: UHBR requires FEC, PSR implies idle stream, non-PSR SDP only inside stream, training-done sticky across rate-stable cycles

## Functional coverage

- `dp2_rate_cg` - link rate x lane count, DSC x FEC, rate x stream-active crosses
- `dp2_res_cg` - resolution corners hactive x vactive cross
- `dp2_fsm_cg` - link FSM (idle/trained/streaming/PSR + transitions) x SDP type cross

## Quick start

```bash
cd regression
make all TESTNAME=dp2_regression_test        # compile + run (xrun default)
make regress                                 # full regression matrix
```

License: Apache-2.0
