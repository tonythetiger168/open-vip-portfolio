// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- 5-protocol top-level testbench (DisplayPort2-focused)
// Closed loop: DP2 VIP driver -> displayport2_if -> functional DP2 sink model
`ifndef TOP_TB_SV
`define TOP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module top_tb;
  logic clk = 0, rst_n;
  always #2ns clk = ~clk;
  initial begin rst_n = 0; #100ns; rst_n = 1; end

  displayport2_if dp2_if(clk, rst_n);
  sata_if         sata_if_i(clk, rst_n);
  nvme_if         nvme_if_i(clk, rst_n);
  jtag_if         jtag_if_i(clk, rst_n);
  bluetooth5_if   bt5_if_i(clk, rst_n);

  // functional DisplayPort 2.x sink model (closed loop)
  displayport2_sink_model dp2_sink(.vif(dp2_if));

  // SVA checkers (module form), bound to the DP2 interface
  displayport2_compliance_checker            u_dp2_sva_chk       (.vif(dp2_if));
  displayport2_data_integrity_checker        u_dp2_integrity_chk (.vif(dp2_if));
  displayport2_error_handling_checker        u_dp2_error_chk     (.vif(dp2_if));
  displayport2_protocol_compliance_checker   u_dp2_protocol_chk  (.vif(dp2_if));
  displayport2_timing_performance_checker    u_dp2_timing_chk    (.vif(dp2_if));

  // companion DUT responders (ready handshake)
  sata_dut       u_sata_dut(.vif(sata_if_i));
  nvme_dut       u_nvme_dut(.vif(nvme_if_i));
  jtag_dut       u_jtag_dut(.vif(jtag_if_i));
  bluetooth5_dut u_bt5_dut (.vif(bt5_if_i));

  initial begin
    uvm_config_db#(virtual displayport2_if)::set(null, "*", "vif", dp2_if);
    uvm_config_db#(virtual sata_if)::set(null, "*", "vif", sata_if_i);
    uvm_config_db#(virtual nvme_if)::set(null, "*", "vif", nvme_if_i);
    uvm_config_db#(virtual jtag_if)::set(null, "*", "vif", jtag_if_i);
    uvm_config_db#(virtual bluetooth5_if)::set(null, "*", "vif", bt5_if_i);
    run_test();
  end
endmodule

//--------------------------------------------------------------------------
// Functional DisplayPort 2.x sink model:
//  - observes link training (TPS1/TPS2 K-char phases)
//  - decodes MSA timing and checks timing-rule compliance
//  - counts video frames, SDP packets (incl. PSR 0x30) and K-char errors
//--------------------------------------------------------------------------
module displayport2_sink_model (displayport2_if vif);
  int unsigned frame_cnt = 0;
  int unsigned sdp_cnt = 0;
  int unsigned psr_cnt = 0;
  int unsigned kchar_err_cnt = 0;
  int unsigned timing_err_cnt = 0;
  bit trained = 0;

  always_ff @(posedge vif.clk or negedge vif.rst_n) begin : sink
    if (!vif.rst_n) begin : rst
      trained <= 0;
    end else begin : run
      // link training detection: K28.5 on all lanes during TPS1
      if (!trained && vif.lane_k == 4'hF && vif.lane_data == {4{8'hBC}})
        trained <= 1;
      // MSA timing-rule checks while the stream is active
      if (vif.main_stream_active && vif.msa_valid) begin
        if (vif.hactive > vif.htotal || vif.vactive > vif.vtotal) begin
          timing_err_cnt++;
          `uvm_error("DP2_SINK", "MSA timing violation: active > total")
        end
        if (vif.hsync_end < vif.hsync_start || vif.vsync_end < vif.vsync_start) begin
          timing_err_cnt++;
          `uvm_error("DP2_SINK", "MSA timing violation: sync end < start")
        end
      end
      // frame accounting on MSA rising edge
      if (vif.msa_valid) frame_cnt++;
      // SDP accounting
      if (vif.sdp_valid) begin
        sdp_cnt++;
        if (vif.sdp_type == 8'h30) psr_cnt++;
      end
      // K-char outside training / stream is a link error
      if (trained && vif.link_training_done && vif.main_stream_active &&
          vif.lane_k != 4'h0) begin
        kchar_err_cnt++;
        `uvm_warning("DP2_SINK", "K-character inside video data (error injection)")
      end
    end
  end

  final begin : rpt
    `uvm_info("DP2_SINK", $sformatf(
      "sink: frames=%0d sdp=%0d psr=%0d kchar_err=%0d timing_err=%0d",
      frame_cnt, sdp_cnt, psr_cnt, kchar_err_cnt, timing_err_cnt), UVM_LOW)
  end
endmodule

// companion DUT responders
module sata_dut (sata_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) vif.ready <= 1'b0;
    else            vif.ready <= #1ns vif.valid;
endmodule
module nvme_dut (nvme_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) vif.ready <= 1'b0;
    else            vif.ready <= #1ns vif.valid;
endmodule
module jtag_dut (jtag_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) vif.ready <= 1'b0;
    else            vif.ready <= #1ns vif.valid;
endmodule
module bluetooth5_dut (bluetooth5_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) vif.ready <= 1'b0;
    else            vif.ready <= #1ns vif.valid;
endmodule
`endif
