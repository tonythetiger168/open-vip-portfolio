// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// test_pkg.sv -- 5-protocol test package (DisplayPort2-focused)
`ifndef TEST_PKG_SV
`define TEST_PKG_SV
package test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sata_pkg::*;
  import nvme_pkg::*;
  import jtag_pkg::*;
  import bluetooth5_pkg::*;
  import displayport2_pkg::*;
  import env_pkg::*;

  class base_test extends uvm_test;
    `uvm_component_utils(base_test)
    multi_protocol_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = multi_protocol_env::type_id::create("env", this);
    endfunction
  endclass

  // ---- SATA ----
  class sata_random_test extends base_test;
    `uvm_component_utils(sata_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      sata_random_sequence seq = sata_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.sata_agt.sqr);
      #1000;
      phase.drop_objection(this);
    endtask
  endclass
  class sata_regression_test extends sata_random_test;
    `uvm_component_utils(sata_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  // ---- NVMe ----
  class nvme_random_test extends base_test;
    `uvm_component_utils(nvme_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      nvme_random_sequence seq = nvme_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.nvme_agt.sqr);
      #1000;
      phase.drop_objection(this);
    endtask
  endclass
  class nvme_regression_test extends nvme_random_test;
    `uvm_component_utils(nvme_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  // ---- JTAG ----
  class jtag_random_test extends base_test;
    `uvm_component_utils(jtag_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      jtag_random_sequence seq = jtag_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.jtag_agt.sqr);
      #1000;
      phase.drop_objection(this);
    endtask
  endclass
  class jtag_regression_test extends jtag_random_test;
    `uvm_component_utils(jtag_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  // ---- Bluetooth5 ----
  class bt5_random_test extends base_test;
    `uvm_component_utils(bt5_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      bluetooth5_random_sequence seq = bluetooth5_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.bt5_agt.sqr);
      #1000;
      phase.drop_objection(this);
    endtask
  endclass
  class bt5_regression_test extends bt5_random_test;
    `uvm_component_utils(bt5_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  // ---- DisplayPort2 ----
  class dp2_random_test extends base_test;
    `uvm_component_utils(dp2_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      displayport2_random_sequence seq = displayport2_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.num_txns = 10;
      seq.start(env.dp2_agt.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  class dp2_regression_test extends base_test;
    `uvm_component_utils(dp2_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      displayport2_regression_sequence seq = displayport2_regression_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.dp2_agt.sqr);
      #5000;
      phase.drop_objection(this);
    endtask
  endclass

  class dp2_error_test extends base_test;
    `uvm_component_utils(dp2_error_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      displayport2_error_sequence seq = displayport2_error_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.num_txns = 8;
      seq.start(env.dp2_agt.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  class dp2_psr_test extends base_test;
    `uvm_component_utils(dp2_psr_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      displayport2_psr_sequence seq = displayport2_psr_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.num_txns = 8;
      seq.start(env.dp2_agt.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  // ---- all protocols concurrently ----
  class full_regression_test extends base_test;
    `uvm_component_utils(full_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      sata_random_sequence       sata_seq = sata_random_sequence::type_id::create("sata_seq");
      nvme_random_sequence       nvme_seq = nvme_random_sequence::type_id::create("nvme_seq");
      jtag_random_sequence       jtag_seq = jtag_random_sequence::type_id::create("jtag_seq");
      bluetooth5_random_sequence bt5_seq  = bluetooth5_random_sequence::type_id::create("bt5_seq");
      displayport2_regression_sequence dp2_seq = displayport2_regression_sequence::type_id::create("dp2_seq");
      phase.raise_objection(this);
      fork
        sata_seq.start(env.sata_agt.sqr);
        nvme_seq.start(env.nvme_agt.sqr);
        jtag_seq.start(env.jtag_agt.sqr);
        bt5_seq.start(env.bt5_agt.sqr);
        dp2_seq.start(env.dp2_agt.sqr);
      join
      #5000;
      phase.drop_objection(this);
    endtask
  endclass
endpackage
`endif
