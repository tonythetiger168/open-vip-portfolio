// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// jtag_if.sv -- JTAG interface (minimal companion VIP model)
`ifndef JTAG_IF_SV
`define JTAG_IF_SV
interface jtag_if (input logic clk, input logic rst_n);
  logic [31:0] data;
  logic [7:0]  cmd;
  logic        valid;
  logic        ready;
  modport TB (input clk, rst_n, ready, output data, cmd, valid);
  modport DUT (input clk, rst_n, data, cmd, valid, output ready);
endinterface
`endif
