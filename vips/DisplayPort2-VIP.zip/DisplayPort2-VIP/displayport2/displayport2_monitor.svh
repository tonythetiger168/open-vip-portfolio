// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// displayport2_monitor.svh -- DisplayPort 2.x monitor (deepened)
// Decodes link-training/stream state from the interface waveform, extracts
// MSA timing and SDP packet type, and publishes one transaction per item.
`ifndef DISPLAYPORT2_MONITOR_SVH
`define DISPLAYPORT2_MONITOR_SVH

class displayport2_monitor extends uvm_monitor;
  `uvm_component_utils(displayport2_monitor)
  virtual displayport2_if vif;
  uvm_analysis_port #(displayport2_transaction) ap;
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual displayport2_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "displayport2 monitor: vif not found");
  endfunction

  task run_phase(uvm_phase phase);
    displayport2_transaction tx;
    bit prev_msa = 0, prev_sdp = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin prev_msa = 0; prev_sdp = 0; continue; end
      // main-stream item: publish once per MSA packet (rising edge)
      if (vif.msa_valid && !prev_msa) begin
        tx = capture();
        tx.main_stream_active = vif.main_stream_active;
        `uvm_info("DP2_MON", "observed main-stream item", UVM_HIGH)
        txn_count++;
        ap.write(tx);
      end
      // PSR / SDP-only item: publish once per SDP pulse outside the stream
      else if (vif.sdp_valid && !prev_sdp && !vif.main_stream_active) begin
        tx = capture();
        tx.main_stream_active = 1'b0;
        `uvm_info("DP2_MON", "observed SDP/PSR item", UVM_HIGH)
        txn_count++;
        ap.write(tx);
      end
      prev_msa = vif.msa_valid;
      prev_sdp = vif.sdp_valid;
    end
  endtask

  function displayport2_transaction capture();
    displayport2_transaction t;
    t = displayport2_transaction::type_id::create("mon_tx");
    t.link_rate          = displayport2_transaction::link_rate_e'(vif.link_rate);
    t.lane_count         = displayport2_transaction::lane_count_e'(vif.lane_count);
    t.bpp                = vif.bpp;
    t.dsc_enable         = vif.dsc_enable;
    t.fec_enable         = vif.fec_en;
    t.psr_enable         = vif.psr_enable;
    t.panel_replay_mode  = vif.panel_replay_mode;
    t.htotal             = vif.htotal;
    t.hactive            = vif.hactive;
    t.vtotal             = vif.vtotal;
    t.vactive            = vif.vactive;
    t.hsync_start        = vif.hsync_start;
    t.hsync_end          = vif.hsync_end;
    t.vsync_start        = vif.vsync_start;
    t.vsync_end          = vif.vsync_end;
    t.link_training_done = vif.link_training_done;
    // decode SDP: 0x30 is the fixed PSR SDP, small values map to the enum
    t.sdp_type           = (vif.sdp_type <= 8'h05) ?
                           displayport2_transaction::sdp_type_e'(vif.sdp_type[2:0]) :
                           displayport2_transaction::SDP_NONE;
    return t;
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("DP2_MON", $sformatf("monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
