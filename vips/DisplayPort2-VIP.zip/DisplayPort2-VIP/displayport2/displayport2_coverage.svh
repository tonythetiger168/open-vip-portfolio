// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// displayport2_coverage.svh

class displayport2_coverage extends coverage_collector_base;
  `uvm_component_utils(displayport2_coverage)
  uvm_analysis_imp #(displayport2_transaction, displayport2_coverage) analysis_export;

  // Coverpoint sample variables (declared before the covergroups that
  // reference them, per IEEE 1800 declaration-before-use rules)
  displayport2_transaction tx;
  int sample_count = 0;

  covergroup dp2_rate_cg;
    option.per_instance = 1;
    rate_cp: coverpoint tx.link_rate {
      bins rbr = {displayport2_transaction::RATE_RBR};
      bins hbr = {displayport2_transaction::RATE_HBR};
      bins hbr2 = {displayport2_transaction::RATE_HBR2};
      bins hbr3 = {displayport2_transaction::RATE_HBR3};
      bins uhbr10 = {displayport2_transaction::RATE_UHBR10};
      bins uhbr135 = {displayport2_transaction::RATE_UHBR135};
      bins uhbr20 = {displayport2_transaction::RATE_UHBR20};
    }
    lanes_cp: coverpoint tx.lane_count {
      bins x1 = {displayport2_transaction::LANES_1};
      bins x2 = {displayport2_transaction::LANES_2};
      bins x4 = {displayport2_transaction::LANES_4};
    }
    dsc_cp: coverpoint tx.dsc_enable { bins off = {0}; bins on = {4'hF}; }
    fec_cp: coverpoint tx.fec_enable { bins off = {0}; bins on = {4'hF}; }
    bpp_cp: coverpoint tx.bpp { bins b18 = {0}; bins b24 = {1}; bins b30 = {2}; bins b36 = {3}; bins b48 = {4}; }
    msa_cp: coverpoint tx.main_stream_active;
    psr_cp: coverpoint tx.psr_enable { bins off = {0}; bins on = {4'hF}; }
    error_cp: coverpoint tx.with_error;
    cross_rate_lanes: cross rate_cp, lanes_cp;
    cross_dsc_fec: cross dsc_cp, fec_cp;
    cross_rate_msa: cross rate_cp, msa_cp;
  endgroup

  covergroup dp2_res_cg;
    option.per_instance = 1;
    hactive_cp: coverpoint tx.hactive {
      bins sd = {[640:720]}; bins hd = {[1280:1920]}; bins fhd = {[1920:2048]};
      bins qhd = {[2560:3440]}; bins uhd4k = {[3840:4096]}; bins uhd8k = {[7680:7680]};
    }
    vactive_cp: coverpoint tx.vactive {
      bins sd = {[480:576]}; bins hd = {[720:1080]}; bins uhd = {[2160:2160]}; bins uhd8k = {[4320:4320]};
    }
    cross_h_v: cross hactive_cp, vactive_cp;
  endgroup

  // link FSM: idle -> trained -> streaming / PSR, crossed with SDP type
  covergroup dp2_fsm_cg;
    option.per_instance = 1;
    state_cp: coverpoint {tx.link_training_done, tx.main_stream_active, (tx.psr_enable != 4'h0)} {
      bins idle      = {3'b000}; bins trained   = {3'b100};
      bins streaming = {3'b110}; bins psr       = {3'b101};
      bins train_to_stream = (3'b100 => 3'b110);
      bins stream_to_psr   = (3'b110 => 3'b101);
    }
    sdp_cp: coverpoint tx.sdp_type {
      bins none = {displayport2_transaction::SDP_NONE}; bins audio = {displayport2_transaction::SDP_AUDIO};
      bins pps = {displayport2_transaction::SDP_PPS}; bins vsc = {displayport2_transaction::SDP_VSC};
      bins cea = {displayport2_transaction::SDP_CEA}; bins hdr = {displayport2_transaction::SDP_HDR};
    }
    cross_state_sdp: cross state_cp, sdp_cp;
  endgroup


  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    dp2_rate_cg = new();
    dp2_res_cg = new();
    dp2_fsm_cg = new();
  endfunction
  function void write(displayport2_transaction tx_); tx = tx_; sample_coverage(tx); endfunction
  virtual function void sample_coverage(uvm_sequence_item tx_);
    displayport2_transaction dtx;
    if (!$cast(dtx, tx_)) return;
    tx = dtx;
    dp2_rate_cg.sample();
    dp2_res_cg.sample();
    dp2_fsm_cg.sample();
    sample_count++;
  endfunction
  function void report_phase(uvm_phase phase);
    `uvm_info("DP2_COV", $sformatf("Sampled %0d transactions", sample_count), UVM_LOW)
    `uvm_info("DP2_COV", $sformatf("Rate coverage = %0.2f%%", dp2_rate_cg.get_coverage()), UVM_LOW)
    `uvm_info("DP2_COV", $sformatf("Resolution coverage = %0.2f%%", dp2_res_cg.get_coverage()), UVM_LOW)
    `uvm_info("DP2_COV", $sformatf("Link FSM coverage = %0.2f%%", dp2_fsm_cg.get_coverage()), UVM_LOW)
  endfunction
endclass
