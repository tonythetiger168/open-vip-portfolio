// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// displayport2_if.sv
// DisplayPort 2.0 Interface (4 lanes, UHBR20)

interface displayport2_if (input logic clk, input logic rst_n);
  // Main Link (4 lanes)
  logic [3:0] lane_data;
  logic [3:0] lane_k;
  logic       link_training_done;
  logic [2:0] link_rate;      // 0=RBR,1=HBR,2=HBR2,3=HBR3,4=UHBR10,5=UHBR13.5,6=UHBR20
  logic [1:0] lane_count;     // 0=1,1=2,2=4 lanes
  logic [3:0] scrambler_en;
  logic [3:0] fec_en;
  logic [7:0] sdp_type;
  logic       sdp_valid;
  logic       msa_valid;
  logic [23:0] htotal, vtotal;
  logic [23:0] hactive, vactive;
  logic [23:0] hsync_start, hsync_end;
  logic [23:0] vsync_start, vsync_end;
  logic       main_stream_active;
  logic       mst;            // multi-stream transport active
  logic [3:0] dsc_enable;
  logic [2:0] bpp;            // bits per pixel
  logic [7:0] panel_replay_mode;
  logic [3:0] psr_enable;

  modport DUT (
    input  clk, rst_n, lane_data, lane_k, link_training_done, link_rate, lane_count,
    input  scrambler_en, fec_en, sdp_type, sdp_valid, msa_valid,
    input  htotal, vtotal, hactive, vactive, hsync_start, hsync_end,
    input  vsync_start, vsync_end, main_stream_active, dsc_enable, bpp,
    input  panel_replay_mode, psr_enable, mst
  );

  modport TB (
    input  clk, rst_n,
    output lane_data, lane_k, link_training_done, link_rate, lane_count,
    output scrambler_en, fec_en, sdp_type, sdp_valid, msa_valid,
    output htotal, vtotal, hactive, vactive, hsync_start, hsync_end,
    output vsync_start, vsync_end, main_stream_active, dsc_enable, bpp,
    output panel_replay_mode, psr_enable, mst
  );

  clocking mon_cb @(posedge clk);
    input lane_data, lane_k, link_training_done, link_rate, lane_count;
    input scrambler_en, fec_en, sdp_type, sdp_valid, msa_valid;
    input htotal, vtotal, hactive, vactive, hsync_start, hsync_end;
    input vsync_start, vsync_end, main_stream_active, dsc_enable, bpp;
    input panel_replay_mode, psr_enable, mst;
  endclocking

  clocking drv_cb @(posedge clk);
    output lane_data, lane_k, link_training_done, link_rate, lane_count;
    output scrambler_en, fec_en, sdp_type, sdp_valid, msa_valid;
    output htotal, vtotal, hactive, vactive, hsync_start, hsync_end;
    output vsync_start, vsync_end, main_stream_active, dsc_enable, bpp;
    output panel_replay_mode, psr_enable, mst;
  endclocking
endinterface
