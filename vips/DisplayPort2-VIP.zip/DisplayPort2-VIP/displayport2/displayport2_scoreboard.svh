// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// displayport2_scoreboard.svh -- end-to-end scoreboard
// Compares expected (driver-issued) vs observed (monitor-decoded) DP2 items.
`ifndef DISPLAYPORT2_SCOREBOARD_SVH
`define DISPLAYPORT2_SCOREBOARD_SVH

`uvm_analysis_imp_decl(_dp2_exp)
`uvm_analysis_imp_decl(_dp2_obs)

class displayport2_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(displayport2_scoreboard)
  uvm_analysis_imp_dp2_exp #(displayport2_transaction, displayport2_scoreboard) exp_ap;
  uvm_analysis_imp_dp2_obs #(displayport2_transaction, displayport2_scoreboard) obs_ap;

  displayport2_transaction exp_q[$], obs_q[$];
  int unsigned n_matches = 0, n_mismatches = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    exp_ap = new("exp_ap", this);
    obs_ap = new("obs_ap", this);
  endfunction

  virtual function void write_dp2_exp(displayport2_transaction tx);
    exp_q.push_back(tx); check();
  endfunction

  virtual function void write_dp2_obs(displayport2_transaction tx);
    obs_q.push_back(tx); check();
  endfunction

  function void check();
    while (exp_q.size() && obs_q.size()) begin
      displayport2_transaction e = exp_q.pop_front();
      displayport2_transaction o = obs_q.pop_front();
      if (e.compare(o))
        n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("DP2_SB", $sformatf("mismatch exp{%s} obs{%s}",
                   e.convert2string(), o.convert2string()))
      end
    end
  endfunction

  virtual function void report_phase(uvm_phase phase);
    `uvm_info("DP2_SB", $sformatf("scoreboard: n_matches=%0d n_mismatches=%0d",
              n_matches, n_mismatches), UVM_LOW)
    if (n_mismatches) `uvm_error("DP2_SB", "end-to-end n_mismatches detected")
  endfunction
endclass
`endif
