// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// displayport2_transaction.svh

class displayport2_transaction extends uvm_sequence_item;
  `uvm_object_utils(displayport2_transaction)

  typedef enum bit [2:0] {
    RATE_RBR     = 3'd0,  // 1.62 Gbps
    RATE_HBR     = 3'd1,  // 2.7 Gbps
    RATE_HBR2    = 3'd2,  // 5.4 Gbps
    RATE_HBR3    = 3'd3,  // 8.1 Gbps
    RATE_UHBR10  = 3'd4,  // 10 Gbps
    RATE_UHBR135 = 3'd5,  // 13.5 Gbps
    RATE_UHBR20  = 3'd6   // 20 Gbps
  } link_rate_e;

  typedef enum bit [1:0] {
    LANES_1 = 2'd0,
    LANES_2 = 2'd1,
    LANES_4 = 2'd2
  } lane_count_e;

  typedef enum bit [2:0] {
    SDP_NONE     = 3'd0,
    SDP_AUDIO    = 3'd1,
    SDP_PPS      = 3'd2,  // DSC Parameter Set
    SDP_VSC      = 3'd3,  // Vendor Specific
    SDP_CEA      = 3'd4,
    SDP_HDR      = 3'd5   // HDR metadata
  } sdp_type_e;

  rand link_rate_e   link_rate;
  rand lane_count_e  lane_count;
  rand sdp_type_e    sdp_type;
  rand bit [23:0]    htotal, vtotal;
  rand bit [23:0]    hactive, vactive;
  rand bit [23:0]    hsync_start, hsync_end;
  rand bit [23:0]    vsync_start, vsync_end;
  rand bit           main_stream_active;
  rand bit           link_training_done;
  rand bit [3:0]     dsc_enable;
  rand bit [2:0]     bpp;
  rand bit [3:0]     fec_enable;
  rand bit [3:0]     scrambler_en;
  rand bit           with_error;
  rand bit [7:0]     panel_replay_mode;
  rand bit [3:0]     psr_enable;
  rand bit [15:0]    frame_count;

  constraint c_rate { link_rate inside {RATE_RBR, RATE_HBR, RATE_HBR2, RATE_HBR3, RATE_UHBR10, RATE_UHBR135, RATE_UHBR20}; }
  constraint c_lanes { lane_count inside {LANES_1, LANES_2, LANES_4}; }
  constraint c_timing {
    htotal >= hactive + 80;
    vtotal >= vactive + 10;
    hsync_start >= hactive;
    hsync_end > hsync_start;
    vsync_start >= vactive;
    vsync_end > vsync_start;
    hactive inside {[640:7680]};
    vactive inside {[480:4320]};
  }
  constraint c_bpp { bpp inside {0,1,2,3,4}; } // 6,8,10,12,16bpc -> 18,24,30,36,48bpp
  constraint c_dsc { dsc_enable dist {4'h0:=60, 4'hF:=40}; }
  constraint c_fec { fec_enable dist {4'h0:=30, 4'hF:=70}; }
  constraint c_error { with_error dist {0:=95, 1:=5}; }
  constraint c_psr { psr_enable dist {4'h0:=80, 4'hF:=20}; }

  function new(string name = "displayport2_transaction");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("DP2.0: rate=%s lanes=%0d res=%0dx%0d dsc=%b fec=%b bpp=%0d msa=%b err=%b",
      link_rate.name(), (lane_count+1)*2/(lane_count+1), hactive, vactive, dsc_enable, fec_enable, bpp, main_stream_active, with_error);
  endfunction

  // field-level compare for the end-to-end scoreboard
  virtual function bit compare(displayport2_transaction o);
    return (link_rate==o.link_rate) && (lane_count==o.lane_count) && (bpp==o.bpp) &&
           (dsc_enable==o.dsc_enable) && (fec_enable==o.fec_enable) &&
           (psr_enable==o.psr_enable) && (panel_replay_mode==o.panel_replay_mode) &&
           (htotal==o.htotal) && (hactive==o.hactive) &&
           (vtotal==o.vtotal) && (vactive==o.vactive) &&
           (sdp_type==o.sdp_type) &&
           (main_stream_active==o.main_stream_active) &&
           (link_training_done==o.link_training_done);
  endfunction
endclass
