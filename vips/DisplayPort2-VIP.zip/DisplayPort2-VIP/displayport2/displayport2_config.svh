// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// displayport2_config.svh

class displayport2_config extends uvm_object;
  `uvm_object_utils(displayport2_config)
  bit enable_checker  = 1;
  bit enable_coverage = 1;
  bit dsc_enabled = 1;
  bit fec_enabled = 1;
  bit panel_replay = 1;
  bit psr_enabled = 0;
  int max_link_rate = 6; // UHBR20
  int max_lanes = 4;
  int max_bpp = 4; // 30bpp
  function new(string name = "displayport2_config");
    super.new(name);
  endfunction
endclass
