// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// displayport2 Protocol Compliance Checker
// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
`ifndef DISPLAYPORT2_PROTOCOL_CHECKER_SV
`define DISPLAYPORT2_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module displayport2_protocol_compliance_checker (displayport2_if vif);
  property p_dp_link_rate; @(posedge vif.clk) disable iff (!vif.rst_n) vif.link_rate inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110}; endproperty
  assert_p_dp_link_rate: assert property(p_dp_link_rate) else `uvm_warning("DISPLAYPORT2", "Link rate valid failed");
  cover_p_dp_link_rate: cover property(p_dp_link_rate);
  property p_dp_lane_count; @(posedge vif.clk) disable iff (!vif.rst_n) vif.lane_count inside {2'b00,2'b01,2'b10}; endproperty
  assert_p_dp_lane_count: assert property(p_dp_lane_count) else `uvm_warning("DISPLAYPORT2", "Lane count 1/2/4 failed");
  cover_p_dp_lane_count: cover property(p_dp_lane_count);
  property p_dp_bpp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bpp inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_dp_bpp: assert property(p_dp_bpp) else `uvm_warning("DISPLAYPORT2", "BPP valid failed");
  cover_p_dp_bpp: cover property(p_dp_bpp);
  property p_dp_sdp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sdp_valid == 1 |-> vif.sdp_type <= 8'hFF; endproperty
  assert_p_dp_sdp: assert property(p_dp_sdp) else `uvm_warning("DISPLAYPORT2", "SDP type valid failed");
  cover_p_dp_sdp: cover property(p_dp_sdp);
endmodule
`endif
