// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// displayport2 Data Integrity Checker
// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
`ifndef DISPLAYPORT2_CHK_SV
`define DISPLAYPORT2_CHK_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module displayport2_data_integrity_checker (displayport2_if vif);
  property p_dp_training; @(posedge vif.clk) disable iff (!vif.rst_n) vif.main_stream_active == 1 |-> vif.link_training_done == 1; endproperty
  assert_p_dp_training: assert property(p_dp_training) else `uvm_warning("DISPLAYPORT2", "Training before stream failed");
  cover_p_dp_training: cover property(p_dp_training);
  property p_dp_msa; @(posedge vif.clk) disable iff (!vif.rst_n) vif.msa_valid == 1 |-> vif.main_stream_active == 1; endproperty
  assert_p_dp_msa: assert property(p_dp_msa) else `uvm_warning("DISPLAYPORT2", "MSA with active stream failed");
  cover_p_dp_msa: cover property(p_dp_msa);
  property p_dp_hactive; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hactive <= vif.htotal; endproperty
  assert_p_dp_hactive: assert property(p_dp_hactive) else `uvm_warning("DISPLAYPORT2", "HActive <= HTotal failed");
  cover_p_dp_hactive: cover property(p_dp_hactive);
endmodule
`endif
