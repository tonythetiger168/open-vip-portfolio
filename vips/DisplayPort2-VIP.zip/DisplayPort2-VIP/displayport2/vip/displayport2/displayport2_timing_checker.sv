// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// displayport2 Timing Performance Checker
// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
`ifndef DISPLAYPORT2_TIMING_CHECKER_SV
`define DISPLAYPORT2_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module displayport2_timing_performance_checker (displayport2_if vif);
  property p_dp_vactive; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vactive <= vif.vtotal; endproperty
  assert_p_dp_vactive: assert property(p_dp_vactive) else `uvm_warning("DISPLAYPORT2", "VActive <= VTotal failed");
  cover_p_dp_vactive: cover property(p_dp_vactive);
  property p_dp_hsync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hsync_start < vif.hsync_end && vif.hsync_end <= vif.htotal; endproperty
  assert_p_dp_hsync: assert property(p_dp_hsync) else `uvm_warning("DISPLAYPORT2", "HSync valid failed");
  cover_p_dp_hsync: cover property(p_dp_hsync);
  property p_dp_vsync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vsync_start < vif.vsync_end && vif.vsync_end <= vif.vtotal; endproperty
  assert_p_dp_vsync: assert property(p_dp_vsync) else `uvm_warning("DISPLAYPORT2", "VSync valid failed");
  cover_p_dp_vsync: cover property(p_dp_vsync);
endmodule
`endif
