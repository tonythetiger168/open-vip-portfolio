// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// displayport2 Error Handling Checker
// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
`ifndef DISPLAYPORT2_ERROR_CHECKER_SV
`define DISPLAYPORT2_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module displayport2_error_handling_checker (displayport2_if vif);
  property p_dp_fec; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fec_en != 0 |-> vif.link_rate >= 3'b100; endproperty
  assert_p_dp_fec: assert property(p_dp_fec) else `uvm_warning("DISPLAYPORT2", "FEC with UHBR failed");
  cover_p_dp_fec: cover property(p_dp_fec);
  property p_dp_dsc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.dsc_enable != 0 |-> vif.bpp > 0; endproperty
  assert_p_dp_dsc: assert property(p_dp_dsc) else `uvm_warning("DISPLAYPORT2", "DSC with valid BPP failed");
  cover_p_dp_dsc: cover property(p_dp_dsc);
  property p_dp_psr; @(posedge vif.clk) disable iff (!vif.rst_n) vif.psr_enable != 0 |-> vif.main_stream_active == 1; endproperty
  assert_p_dp_psr: assert property(p_dp_psr) else `uvm_warning("DISPLAYPORT2", "PSR with active stream failed");
  cover_p_dp_psr: cover property(p_dp_psr);
endmodule
`endif
