// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// displayport2_sequences.svh

class displayport2_base_sequence extends uvm_sequence #(displayport2_transaction);
  `uvm_object_utils(displayport2_base_sequence)
  function new(string name = "displayport2_base_sequence");
    super.new(name);
  endfunction
endclass

class displayport2_random_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "displayport2_random_sequence");
    super.new(name);
  endfunction
  task body();
    displayport2_transaction tx;
    repeat (num_txns) begin
      tx = displayport2_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "DP2.0 tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class displayport2_uhbr_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_uhbr_sequence)
  rand int num_txns = 30;
  function new(string name = "displayport2_uhbr_sequence");
    super.new(name);
  endfunction
  task body();
    displayport2_transaction tx;
    repeat (num_txns) begin
      tx = displayport2_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        link_rate inside {displayport2_transaction::RATE_UHBR10,
                          displayport2_transaction::RATE_UHBR135,
                          displayport2_transaction::RATE_UHBR20};
        lane_count == displayport2_transaction::LANES_4;
      }) `uvm_error("RANDFAIL", "DP2.0 UHBR randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class displayport2_dsc_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_dsc_sequence)
  rand int num_txns = 30;
  function new(string name = "displayport2_dsc_sequence");
    super.new(name);
  endfunction
  task body();
    displayport2_transaction tx;
    repeat (num_txns) begin
      tx = displayport2_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        dsc_enable == 4'hF;
        fec_enable == 4'hF;
        bpp inside {[2:4]};
      }) `uvm_error("RANDFAIL", "DP2.0 DSC randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class displayport2_8k_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_8k_sequence)
  rand int num_txns = 20;
  function new(string name = "displayport2_8k_sequence");
    super.new(name);
  endfunction
  task body();
    displayport2_transaction tx;
    repeat (num_txns) begin
      tx = displayport2_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        hactive == 7680;
        vactive == 4320;
        link_rate == displayport2_transaction::RATE_UHBR20;
        lane_count == displayport2_transaction::LANES_4;
        dsc_enable == 4'hF;
      }) `uvm_error("RANDFAIL", "DP2.0 8K randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Error injection: corrupted K-markers / FEC violations
class displayport2_error_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_error_sequence)
  rand int num_txns = 10;
  function new(string name = "displayport2_error_sequence"); super.new(name); endfunction
  task body();
    displayport2_transaction tx;
    repeat (num_txns) begin
      tx = displayport2_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { with_error == 1; })
        `uvm_error("RANDFAIL", "DP2.0 error randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Back-to-back: minimum gap between frames
class displayport2_back_to_back_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_back_to_back_sequence)
  rand int num_txns = 20;
  function new(string name = "displayport2_back_to_back_sequence"); super.new(name); endfunction
  task body();
    displayport2_transaction tx;
    repeat (num_txns) begin
      tx = displayport2_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_count inside {[0:7]}; with_error == 0;
                                 psr_enable == 4'h0; panel_replay_mode == 8'h00; })
        `uvm_error("RANDFAIL", "DP2.0 b2b randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Reset: single small frame issued right after reset release
class displayport2_reset_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_reset_sequence)
  function new(string name = "displayport2_reset_sequence"); super.new(name); endfunction
  task body();
    displayport2_transaction tx = displayport2_transaction::type_id::create("tx");
    start_item(tx);
    if (!tx.randomize() with { hactive == 640; vactive == 480; frame_count == 0;
                               with_error == 0; psr_enable == 4'h0; panel_replay_mode == 8'h00; })
      `uvm_error("RANDFAIL", "DP2.0 reset randomization failed")
    finish_item(tx);
  endtask
endclass

// Corner case: PSR / panel replay with the stream inactive
class displayport2_psr_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_psr_sequence)
  rand int num_txns = 10;
  function new(string name = "displayport2_psr_sequence"); super.new(name); endfunction
  task body();
    displayport2_transaction tx;
    repeat (num_txns) begin
      tx = displayport2_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { (psr_enable == 4'hF) || (panel_replay_mode != 8'h00);
                                 with_error == 0; })
        `uvm_error("RANDFAIL", "DP2.0 psr randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Stress: 8K UHBR long frames
class displayport2_stress_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_stress_sequence)
  rand int num_txns = 50;
  function new(string name = "displayport2_stress_sequence"); super.new(name); endfunction
  task body();
    displayport2_transaction tx;
    repeat (num_txns) begin
      tx = displayport2_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { hactive inside {[3840:7680]}; vactive inside {[2160:4320]};
                                 link_rate inside {displayport2_transaction::RATE_UHBR10,
                                                   displayport2_transaction::RATE_UHBR135,
                                                   displayport2_transaction::RATE_UHBR20};
                                 lane_count == displayport2_transaction::LANES_4;
                                 with_error == 0; })
        `uvm_error("RANDFAIL", "DP2.0 stress randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Regression: weighted mix of every directed sequence
class displayport2_regression_sequence extends displayport2_base_sequence;
  `uvm_object_utils(displayport2_regression_sequence)
  function new(string name = "displayport2_regression_sequence"); super.new(name); endfunction
  task body();
    displayport2_random_sequence       rnd = displayport2_random_sequence::type_id::create("rnd");
    displayport2_uhbr_sequence         uhb = displayport2_uhbr_sequence::type_id::create("uhb");
    displayport2_dsc_sequence          dsc = displayport2_dsc_sequence::type_id::create("dsc");
    displayport2_8k_sequence           e8k = displayport2_8k_sequence::type_id::create("e8k");
    displayport2_back_to_back_sequence b2b = displayport2_back_to_back_sequence::type_id::create("b2b");
    displayport2_psr_sequence          psr = displayport2_psr_sequence::type_id::create("psr");
    displayport2_stress_sequence       str = displayport2_stress_sequence::type_id::create("str");
    displayport2_reset_sequence        rst = displayport2_reset_sequence::type_id::create("rst");
    displayport2_error_sequence        err = displayport2_error_sequence::type_id::create("err");
    rnd.num_txns=10; uhb.num_txns=5; dsc.num_txns=5; e8k.num_txns=3;
    b2b.num_txns=10; psr.num_txns=5; str.num_txns=5; err.num_txns=5;
    rst.start(m_sequencer); rnd.start(m_sequencer); b2b.start(m_sequencer);
    uhb.start(m_sequencer); dsc.start(m_sequencer); psr.start(m_sequencer);
    e8k.start(m_sequencer); str.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
