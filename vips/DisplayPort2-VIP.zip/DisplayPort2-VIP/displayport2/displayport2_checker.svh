// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// displayport2_checker.svh

class displayport2_checker extends protocol_checker_base;
  `uvm_component_utils(displayport2_checker)
  uvm_analysis_imp #(displayport2_transaction, displayport2_checker) analysis_export;
  int tx_count = 0;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
  endfunction
  function void write(displayport2_transaction tx);
    tx_count++;
    check_link_rate(tx);
    check_lane_count(tx);
    check_timing(tx);
    check_dsc_fec(tx);
    check_bpp(tx);
    check_psr(tx);
  endfunction
  function void check_link_rate(displayport2_transaction tx);
    if (tx.link_rate > displayport2_transaction::RATE_UHBR20)
      check_protocol_error($sformatf("Invalid link rate %s", tx.link_rate.name()));
  endfunction
  function void check_lane_count(displayport2_transaction tx);
    if (tx.lane_count > displayport2_transaction::LANES_4)
      check_protocol_error($sformatf("Invalid lane count %s", tx.lane_count.name()));
  endfunction
  function void check_timing(displayport2_transaction tx);
    if (tx.htotal < tx.hactive + 1)
      check_protocol_error("htotal < hactive");
    if (tx.vtotal < tx.vactive + 1)
      check_protocol_error("vtotal < vactive");
    if (tx.hsync_start < tx.hactive)
      check_protocol_warning("hsync_start before hactive");
    if (tx.vsync_start < tx.vactive)
      check_protocol_warning("vsync_start before vactive");
  endfunction
  function void check_dsc_fec(displayport2_transaction tx);
    if (tx.dsc_enable != 0 && tx.dsc_enable != 4'hF)
      check_protocol_warning("Partial DSC enable");
    if (tx.fec_enable != 0 && tx.fec_enable != 4'hF)
      check_protocol_warning("Partial FEC enable");
  endfunction
  function void check_bpp(displayport2_transaction tx);
    if (tx.bpp > 4)
      check_protocol_error($sformatf("Invalid BPP %0d", tx.bpp));
  endfunction
  function void check_psr(displayport2_transaction tx);
    if (tx.psr_enable != 0 && tx.psr_enable != 4'hF)
      check_protocol_warning("Partial PSR enable");
  endfunction
  task run_phase(uvm_phase phase); endtask
  function void report_phase(uvm_phase phase);
    `uvm_info("DP2_CHK", $sformatf("Checked %0d transactions, %0d errors, %0d warnings",
      tx_count, error_count, warning_count), UVM_LOW)
  endfunction
endclass
