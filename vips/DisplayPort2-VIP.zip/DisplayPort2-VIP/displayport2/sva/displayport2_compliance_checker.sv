// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// displayport2_compliance_checker.sv -- DisplayPort 2.x tiered compliance SVA checker
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=Protocol-Specific
`ifndef DISPLAYPORT2_COMPLIANCE_CHECKER_SV
`define DISPLAYPORT2_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module displayport2_compliance_checker (displayport2_if vif);
  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_dp_link_rate; @(posedge vif.clk) disable iff (!vif.rst_n) vif.link_rate inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110}; endproperty
  assert_p_dp_link_rate: assert property(p_dp_link_rate) l1_pass[0]++; else begin `uvm_warning("DISPLAYPORT2_L1", "Link rate failed"); l1_fail[0]++; end
  cover_p_dp_link_rate: cover property(p_dp_link_rate);
  property p_dp_lane_count; @(posedge vif.clk) disable iff (!vif.rst_n) vif.lane_count inside {2'b00,2'b01,2'b10}; endproperty
  assert_p_dp_lane_count: assert property(p_dp_lane_count) l1_pass[1]++; else begin `uvm_warning("DISPLAYPORT2_L1", "Lane count failed"); l1_fail[1]++; end
  cover_p_dp_lane_count: cover property(p_dp_lane_count);
  property p_dp_bpp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bpp inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_dp_bpp: assert property(p_dp_bpp) l1_pass[2]++; else begin `uvm_warning("DISPLAYPORT2_L1", "BPP valid failed"); l1_fail[2]++; end
  cover_p_dp_bpp: cover property(p_dp_bpp);
  property p_dp_sdp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sdp_valid == 1 |-> vif.sdp_type <= 8'hFF; endproperty
  assert_p_dp_sdp: assert property(p_dp_sdp) l1_pass[3]++; else begin `uvm_warning("DISPLAYPORT2_L1", "SDP type failed"); l1_fail[3]++; end
  cover_p_dp_sdp: cover property(p_dp_sdp);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_dp_training; @(posedge vif.clk) disable iff (!vif.rst_n) vif.main_stream_active == 1 |-> vif.link_training_done == 1; endproperty
  assert_p_dp_training: assert property(p_dp_training) l2_pass[0]++; else begin `uvm_warning("DISPLAYPORT2_L2", "Training before stream failed"); l2_fail[0]++; end
  cover_p_dp_training: cover property(p_dp_training);
  property p_dp_msa; @(posedge vif.clk) disable iff (!vif.rst_n) vif.msa_valid == 1 |-> vif.main_stream_active == 1; endproperty
  assert_p_dp_msa: assert property(p_dp_msa) l2_pass[1]++; else begin `uvm_warning("DISPLAYPORT2_L2", "MSA with active failed"); l2_fail[1]++; end
  cover_p_dp_msa: cover property(p_dp_msa);
  property p_dp_hactive; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hactive <= vif.htotal; endproperty
  assert_p_dp_hactive: assert property(p_dp_hactive) l2_pass[2]++; else begin `uvm_warning("DISPLAYPORT2_L2", "HActive <= HTotal failed"); l2_fail[2]++; end
  cover_p_dp_hactive: cover property(p_dp_hactive);
  property p_dp_vactive; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vactive <= vif.vtotal; endproperty
  assert_p_dp_vactive: assert property(p_dp_vactive) l2_pass[3]++; else begin `uvm_warning("DISPLAYPORT2_L2", "VActive <= VTotal failed"); l2_fail[3]++; end
  cover_p_dp_vactive: cover property(p_dp_vactive);
  property p_dp_hsync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hsync_start < vif.hsync_end && vif.hsync_end <= vif.htotal; endproperty
  assert_p_dp_hsync: assert property(p_dp_hsync) l2_pass[4]++; else begin `uvm_warning("DISPLAYPORT2_L2", "HSync valid failed"); l2_fail[4]++; end
  cover_p_dp_hsync: cover property(p_dp_hsync);
  property p_dp_vsync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vsync_start < vif.vsync_end && vif.vsync_end <= vif.vtotal; endproperty
  assert_p_dp_vsync: assert property(p_dp_vsync) l2_pass[5]++; else begin `uvm_warning("DISPLAYPORT2_L2", "VSync valid failed"); l2_fail[5]++; end
  cover_p_dp_vsync: cover property(p_dp_vsync);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_dp_fec; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fec_en != 0 |-> vif.link_rate >= 3'b100; endproperty
  assert_p_dp_fec: assert property(p_dp_fec) l3_pass[0]++; else begin `uvm_warning("DISPLAYPORT2_L3", "FEC with UHBR failed"); l3_fail[0]++; end
  cover_p_dp_fec: cover property(p_dp_fec);
  property p_dp_dsc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.dsc_enable != 0 |-> vif.bpp > 0; endproperty
  assert_p_dp_dsc: assert property(p_dp_dsc) l3_pass[1]++; else begin `uvm_warning("DISPLAYPORT2_L3", "DSC with BPP failed"); l3_fail[1]++; end
  cover_p_dp_dsc: cover property(p_dp_dsc);
  property p_dp_psr; @(posedge vif.clk) disable iff (!vif.rst_n) vif.psr_enable != 0 |-> vif.main_stream_active == 1; endproperty
  assert_p_dp_psr: assert property(p_dp_psr) l3_pass[2]++; else begin `uvm_warning("DISPLAYPORT2_L3", "PSR with stream failed"); l3_fail[2]++; end
  cover_p_dp_psr: cover property(p_dp_psr);
  property p_dp_mst; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mst == 1 |-> vif.lane_count >= 2'b01; endproperty
  assert_p_dp_mst: assert property(p_dp_mst) l3_pass[3]++; else begin `uvm_warning("DISPLAYPORT2_L3", "MST valid failed"); l3_fail[3]++; end
  cover_p_dp_mst: cover property(p_dp_mst);

  // ---------------- L4: DisplayPort 2.x protocol-specific rules (4) ----------------
  property p_dp_l4_uhbr_fec; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.link_rate >= 3'd4) |-> (vif.fec_en != 4'h0); endproperty
  assert_p_dp_l4_uhbr_fec: assert property(p_dp_l4_uhbr_fec) l4_pass[0]++; else begin `uvm_warning("DISPLAYPORT2_L4", "UHBR without FEC failed"); l4_fail[0]++; end
  cover_p_dp_l4_uhbr_fec: cover property(p_dp_l4_uhbr_fec);
  property p_dp_l4_psr_idle; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.psr_enable != 4'h0) |-> !vif.main_stream_active; endproperty
  assert_p_dp_l4_psr_idle: assert property(p_dp_l4_psr_idle) l4_pass[1]++; else begin `uvm_warning("DISPLAYPORT2_L4", "PSR with active stream failed"); l4_fail[1]++; end
  cover_p_dp_l4_psr_idle: cover property(p_dp_l4_psr_idle);
  property p_dp_l4_sdp_stream; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.sdp_valid && vif.sdp_type != 8'h30) |-> vif.main_stream_active; endproperty
  assert_p_dp_l4_sdp_stream: assert property(p_dp_l4_sdp_stream) l4_pass[2]++; else begin `uvm_warning("DISPLAYPORT2_L4", "Non-PSR SDP outside stream failed"); l4_fail[2]++; end
  cover_p_dp_l4_sdp_stream: cover property(p_dp_l4_sdp_stream);
  property p_dp_l4_train_sticky; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.link_training_done && $stable(vif.link_rate)) |=> vif.link_training_done; endproperty
  assert_p_dp_l4_train_sticky: assert property(p_dp_l4_train_sticky) l4_pass[3]++; else begin `uvm_warning("DISPLAYPORT2_L4", "Training done dropped failed"); l4_fail[3]++; end
  cover_p_dp_l4_train_sticky: cover property(p_dp_l4_train_sticky);

  final begin : sva_report
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("DISPLAYPORT2_RPT", $sformatf("=== DisplayPort2 Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("DISPLAYPORT2_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("DISPLAYPORT2_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("DISPLAYPORT2_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("DISPLAYPORT2_RPT", $sformatf("  L4 Protocol Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("DISPLAYPORT2_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
