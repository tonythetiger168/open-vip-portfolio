// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// displayport2_driver.svh -- DisplayPort 2.x driver (deepened)
// Performs link training (TPS1 clock recovery / TPS2 channel EQ with K-chars),
// then streams MSA-timed video symbols with SDP packets / PSR behavior.
`ifndef DISPLAYPORT2_DRIVER_SVH
`define DISPLAYPORT2_DRIVER_SVH

class displayport2_driver extends uvm_driver #(displayport2_transaction);
  `uvm_component_utils(displayport2_driver)
  displayport2_config cfg;
  virtual displayport2_if vif;
  uvm_analysis_port #(displayport2_transaction) drv_ap;  // expected items

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual displayport2_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "displayport2 driver: vif not found");
    if(!uvm_config_db#(displayport2_config)::get(this, "", "cfg", cfg))
      `uvm_warning("CONFIG", "displayport2 driver: cfg not found, using defaults");
  endfunction

  task run_phase(uvm_phase phase);
    displayport2_transaction tx;
    init_signals();
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(tx);
      drive_item(tx);
      drv_ap.write(tx);
      seq_item_port.item_done();
    end
  endtask

  task init_signals();
    vif.link_rate <= 0; vif.lane_count <= 0; vif.bpp <= 0;
    vif.dsc_enable <= 0; vif.fec_en <= 0; vif.psr_enable <= 0;
    vif.panel_replay_mode <= 0; vif.mst <= 0;
    vif.htotal <= 0; vif.hactive <= 0; vif.vtotal <= 0; vif.vactive <= 0;
    vif.hsync_start <= 0; vif.hsync_end <= 0;
    vif.vsync_start <= 0; vif.vsync_end <= 0;
    vif.link_training_done <= 0; vif.main_stream_active <= 0;
    vif.sdp_type <= 0; vif.sdp_valid <= 0; vif.msa_valid <= 0;
    vif.lane_data <= 0; vif.lane_k <= 0; vif.scrambler_en <= 0;
  endtask

  task drive_item(displayport2_transaction tx);
    apply_config(tx);
    do_link_training();
    if (tx.psr_enable == 4'hF || tx.panel_replay_mode != 8'h00) begin
      tx.sdp_type = displayport2_transaction::SDP_NONE;   // PSR uses fixed 0x30 SDP
      drive_psr_frame(tx);
    end else begin
      drive_main_stream(tx);
    end
    `uvm_info("DP2_DRV", {"drove: ", tx.convert2string()}, UVM_HIGH)
  endtask

  task apply_config(displayport2_transaction tx);
    vif.link_rate          <= tx.link_rate;
    vif.lane_count         <= tx.lane_count;
    vif.bpp                <= tx.bpp;
    vif.dsc_enable         <= tx.dsc_enable;
    vif.fec_en             <= tx.fec_enable;
    vif.psr_enable         <= tx.psr_enable;
    vif.panel_replay_mode  <= tx.panel_replay_mode;
    vif.mst                <= 1'b0;                 // SST mode
    vif.htotal             <= tx.htotal;
    vif.hactive            <= tx.hactive;
    vif.vtotal             <= tx.vtotal;
    vif.vactive            <= tx.vactive;
    vif.hsync_start        <= tx.hsync_start;
    vif.hsync_end          <= tx.hsync_end;
    vif.vsync_start        <= tx.vsync_start;
    vif.vsync_end          <= tx.vsync_end;
    vif.scrambler_en       <= tx.scrambler_en;
  endtask

  // Link training: TPS1 (clock recovery, K28.5) -> TPS2 (channel EQ) -> done
  task do_link_training();
    if (vif.link_training_done === 1'b1) return;   // already trained
    // TPS1: K28.5 (BC) on all lanes, clock-recovery phase
    vif.lane_data <= {4{8'hBC}};
    vif.lane_k    <= 4'hF;
    repeat (8) @(posedge vif.clk);
    // TPS2: K28.5 + TPS2 character (4A) alternating, channel-equalization phase
    vif.lane_data <= {2{8'hBC, 8'h4A}};
    vif.lane_k    <= 4'h5;
    repeat (8) @(posedge vif.clk);
    vif.lane_k             <= 4'h0;
    vif.link_training_done <= 1'b1;
    @(posedge vif.clk);
  endtask

  // Main stream: MSA timing packet, SDP (audio/infoframe/PPS), video symbols
  task drive_main_stream(displayport2_transaction tx);
    vif.main_stream_active <= 1'b1;
    vif.msa_valid          <= 1'b1;   // MSA timing packet on the bus
    @(posedge vif.clk);
    // SDP transport
    vif.sdp_type  <= {5'b0, tx.sdp_type};
    vif.sdp_valid <= 1'b1;
    @(posedge vif.clk);
    vif.sdp_valid <= 1'b0;
    // video symbol stuffing; error injection corrupts a K-marker
    vif.lane_data <= {4{8'h5A}};
    vif.lane_k    <= tx.with_error ? 4'h1 : 4'h0;
    if (tx.with_error) begin
      vif.lane_data <= {4{8'hBC}};   // illegal K-char inside video data
      @(posedge vif.clk);
      vif.lane_data <= {4{8'h5A}};
      vif.lane_k    <= 4'h0;
    end
    repeat (tx.frame_count % 64) @(posedge vif.clk);
    vif.msa_valid          <= 1'b0;
    vif.main_stream_active <= 1'b0;
    @(posedge vif.clk);
  endtask

  // PSR / panel-replay: stream stays inactive, only PSR SDP (0x30) is sent
  task drive_psr_frame(displayport2_transaction tx);
    vif.main_stream_active <= 1'b0;
    vif.sdp_type           <= 8'h30;   // PSR SDP
    vif.sdp_valid          <= 1'b1;
    repeat (2) @(posedge vif.clk);
    vif.sdp_valid          <= 1'b0;
    vif.lane_data          <= 32'h0;
    vif.lane_k             <= 4'h0;
    repeat (4) @(posedge vif.clk);
  endtask
endclass
`endif
