// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// HSI Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 17
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
`ifndef HSI_COMPLIANCE_CHECKER_SV
`define HSI_COMPLIANCE_CHECKER_SV



import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// hsi_compliance_checker_sva -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module hsi_compliance_checker_sva (mipi_vip_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; l4_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_hsi_channel; @(posedge vif.clk) disable iff (!vif.rst_n) vif.channel <= 4'd15; endproperty
  assert_p_hsi_channel: assert property(p_hsi_channel) l1_pass[0]++; else begin `uvm_warning("HSI_L1", "Channel 0-15 failed"); l1_fail[0]++; end
  cover_p_hsi_channel: cover property(p_hsi_channel);
  property p_hsi_frame; @(posedge vif.clk) disable iff (!vif.rst_n) vif.frame |-> vif.channel <= 4'd15; endproperty
  assert_p_hsi_frame: assert property(p_hsi_frame) l1_pass[1]++; else begin `uvm_warning("HSI_L1", "Frame valid failed"); l1_fail[1]++; end
  cover_p_hsi_frame: cover property(p_hsi_frame);
  property p_hsi_break; @(posedge vif.clk) disable iff (!vif.rst_n) vif.break_sig |-> vif.channel == 4'd0; endproperty
  assert_p_hsi_break: assert property(p_hsi_break) l1_pass[2]++; else begin `uvm_warning("HSI_L1", "Break valid failed"); l1_fail[2]++; end
  cover_p_hsi_break: cover property(p_hsi_break);
  property p_hsi_flow; @(posedge vif.clk) disable iff (!vif.rst_n) vif.flow <= 2'd3; endproperty
  assert_p_hsi_flow: assert property(p_hsi_flow) l1_pass[3]++; else begin `uvm_warning("HSI_L1", "Flow 0-3 failed"); l1_fail[3]++; end
  cover_p_hsi_flow: cover property(p_hsi_flow);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_hsi_wake; @(posedge vif.clk) disable iff (!vif.rst_n) vif.wake |-> ##[1:10] vif.ready; endproperty
  assert_p_hsi_wake: assert property(p_hsi_wake) l2_pass[0]++; else begin `uvm_warning("HSI_L2", "Wake valid failed"); l2_fail[0]++; end
  cover_p_hsi_wake: cover property(p_hsi_wake);
  property p_hsi_ready; @(posedge vif.clk) disable iff (!vif.rst_n) vif.wake |-> ##[1:10] vif.ready; endproperty
  assert_p_hsi_ready: assert property(p_hsi_ready) l2_pass[1]++; else begin `uvm_warning("HSI_L2", "Ready after wake failed"); l2_fail[1]++; end
  cover_p_hsi_ready: cover property(p_hsi_ready);
  property p_hsi_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_hsi_no_x: assert property(p_hsi_no_x) l2_pass[2]++; else begin `uvm_warning("HSI_L2", "No X when valid failed"); l2_fail[2]++; end
  cover_p_hsi_no_x: cover property(p_hsi_no_x);
  property p_hsi_err; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err |-> vif.valid; endproperty
  assert_p_hsi_err: assert property(p_hsi_err) l2_pass[3]++; else begin `uvm_warning("HSI_L2", "Error valid failed"); l2_fail[3]++; end
  cover_p_hsi_err: cover property(p_hsi_err);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: BREAK condition aborts any frame in progress
  property p_hsi_l3_break_idle; @(posedge vif.clk) disable iff (!vif.rst_n) vif.break_sig |-> !vif.hsi_valid; endproperty
  assert_p_hsi_l3_break_idle: assert property(p_hsi_l3_break_idle) l3_pass[0]++; else begin `uvm_warning("HSI_L3", "Frame active during BREAK failed"); l3_fail[0]++; end
  cover_p_hsi_l3_break_idle: cover property(p_hsi_l3_break_idle);
  // L3-2: stalled transfer must hold valid until accepted
  property p_hsi_l3_valid_hold; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && !vif.ready) |=> vif.valid; endproperty
  assert_p_hsi_l3_valid_hold: assert property(p_hsi_l3_valid_hold) l3_pass[1]++; else begin `uvm_warning("HSI_L3", "Valid dropped before ready failed"); l3_fail[1]++; end
  cover_p_hsi_l3_valid_hold: cover property(p_hsi_l3_valid_hold);
  // L3-3: logical channel may only change at a frame boundary
  property p_hsi_l3_ch_boundary; @(posedge vif.clk) disable iff (!vif.rst_n) $changed(vif.channel) |-> (vif.sop || !vif.valid); endproperty
  assert_p_hsi_l3_ch_boundary: assert property(p_hsi_l3_ch_boundary) l3_pass[2]++; else begin `uvm_warning("HSI_L3", "Channel changed mid-frame failed"); l3_fail[2]++; end
  cover_p_hsi_l3_ch_boundary: cover property(p_hsi_l3_ch_boundary);
  // L3-4: idle flow-control encoding implies no data transfer
  property p_hsi_l3_idle_flow; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.flow == 2'b00) |-> !vif.valid; endproperty
  assert_p_hsi_l3_idle_flow: assert property(p_hsi_l3_idle_flow) l3_pass[3]++; else begin `uvm_warning("HSI_L3", "Transfer with idle flow encoding failed"); l3_fail[3]++; end
  cover_p_hsi_l3_idle_flow: cover property(p_hsi_l3_idle_flow);

  // ---------------- L4: HSI protocol-specific rules (5) ----------------
  // L4-1: a frame may only start after the receiver has been woken
  property p_hsi_l4_wake_first; @(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.hsi_valid) |-> (vif.hsi_wake || $past(vif.hsi_wake,1) || $past(vif.hsi_wake,2)); endproperty
  assert_p_hsi_l4_wake_first: assert property(p_hsi_l4_wake_first) l4_pass[0]++; else begin `uvm_warning("HSI_L4", "Frame started without preceding wake"); l4_fail[0]++; end
  cover_p_hsi_l4_wake_first: cover property(p_hsi_l4_wake_first);
  // L4-2: HSI data bus is known whenever a frame is in progress
  property p_hsi_l4_data_known; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.hsi_valid |-> !$isunknown(vif.hsi_data); endproperty
  assert_p_hsi_l4_data_known: assert property(p_hsi_l4_data_known) l4_pass[1]++; else begin `uvm_warning("HSI_L4", "HSI data unknown during frame"); l4_fail[1]++; end
  cover_p_hsi_l4_data_known: cover property(p_hsi_l4_data_known);
  // L4-3: logical channel is stable within a frame (after SOP)
  property p_hsi_l4_ch_stable; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.hsi_valid && vif.valid && !vif.sop) |-> $stable(vif.hsi_channel); endproperty
  assert_p_hsi_l4_ch_stable: assert property(p_hsi_l4_ch_stable) l4_pass[2]++; else begin `uvm_warning("HSI_L4", "HSI channel changed mid-frame"); l4_fail[2]++; end
  cover_p_hsi_l4_ch_stable: cover property(p_hsi_l4_ch_stable);
  // L4-4: flow-control encoding is non-idle while a frame is in progress
  property p_hsi_l4_flow_active; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.hsi_valid && vif.valid) |-> (vif.flow != 2'b00); endproperty
  assert_p_hsi_l4_flow_active: assert property(p_hsi_l4_flow_active) l4_pass[3]++; else begin `uvm_warning("HSI_L4", "Flow encoding idle during frame"); l4_fail[3]++; end
  cover_p_hsi_l4_flow_active: cover property(p_hsi_l4_flow_active);
  // L4-5: every SOP is eventually matched by an EOP
  property p_hsi_l4_sop_eop; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.sop |-> s_eventually vif.eop; endproperty
  assert_p_hsi_l4_sop_eop: assert property(p_hsi_l4_sop_eop) l4_pass[4]++; else begin `uvm_warning("HSI_L4", "SOP without eventual EOP"); l4_fail[4]++; end
  cover_p_hsi_l4_sop_eop: cover property(p_hsi_l4_sop_eop);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("HSI_RPT", $sformatf("=== HSI Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("HSI_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("HSI_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("HSI_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("HSI_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("HSI_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule

// ============================================================================
// hsi_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the hsi_compliance_checker_sva module above)
// ============================================================================
class hsi_compliance_checker extends uvm_component;
  `uvm_component_utils(hsi_compliance_checker)
  function new(string name = "hsi_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

`endif
