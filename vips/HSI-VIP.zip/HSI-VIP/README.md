# HSI — MIPI High-Speed Synchronous Serial Interface UVM VIP

Open-source UVM verification IP for **MIPI HSI** (wake/handshake link
management, 16 logical channels, flow control), built on the shared
`mipi_*` infrastructure that also carries CSI-2/DSI/D-PHY/C-PHY/M-PHY/
UniPro/DigRF/CSE sideband layers.

## Contents

| Path | Description |
|------|-------------|
| `rtl/mipi_vip_if.sv` | Protocol interface (generic packet layer + all MIPI PHY/link sidebands, HSI aliases, clocking blocks, assertions, coverage) |
| `vip/base/mipi_vip_pkg.sv` | Enums, `mipi_txn` (real CRC-32/ECC), sequencer/driver/monitor/agent, coverage model, end-to-end scoreboard, sequence library |
| `vip/hsi/hsi_protocol_checker.sv` | HSI SVA: wake timeout, channel range, ready handshake |
| `vip/<proto>/...` | Companion protocol checkers (csi2/dsi/dphy/cphy/mphy/unipro/digrf/cse) |
| `rtl/sva/hsi_compliance_checker.sv` | Tiered SVA compliance checker (L1=4, L2=4, L3=0, L4=5) |
| `env/mipi_env.sv` | Environment: agent + scoreboard + coverage + checkers |
| `tests/mipi_tests.sv` | base + per-protocol tests |
| `tb/top_tb.sv` | Testbench top + functional DUT (HSI receiver model) |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Architecture

```
sequence -> mipi_sequencer -> mipi_driver --drv_ap--> mipi_sb (expected)
                                     |
        wake/channel/flow sideband   |  packet beats (sop..eop, valid/ready)
                                     v
                                mipi_vip_if <--> mipi_dut (HSI receiver:
                                     |           ready backpressure,
                                     v           CRC check, err flag)
                               mipi_monitor --ap--> mipi_sb (observed)
                                     +-> mipi_cov (3 covergroups)
                                     +-> hsi_protocol_checker + SVA L1-L4
```

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `mipi_base_sequence` | constrained-random packets |
| `mipi_hsi_sequence` | directed HSI frames, HS mode, VC/channel sweep |
| `mipi_back_to_back_sequence` | zero-delay back-to-back stress |
| `mipi_max_payload_sequence` | corner: 4090–4095 byte payloads |
| `mipi_error_inject_sequence` | corrupted CRC (must be detected) |
| `mipi_reset_sequence` | frame right after reset release |
| `mipi_stress_sequence` | weighted-size stress burst |
| `mipi_regression_sequence` | mix of all of the above |

## SVA compliance checker

- **L1 (4)**: channel 0–15 during frame, break only on channel 0, flow
  encoding legal, wake only when idle
- **L2 (4)**: no-X on valid/data, ready response, wake→valid ordering, frame
  bounded
- **L4 (5)**: wake-before-frame, data known during frame, channel stable
  mid-frame, flow non-idle during frame, SOP→EOP pairing

## Functional coverage

- `cg_mipi`: protocol / packet-type / VC / lane / mode + pkt×VC, prot×lane cross
- `cg_wc`: word-count corners × packet-type cross
- `cg_lane_fsm`: lane-state bins + HS entry/exit/ULPS transition sequences
- interface `cg_mipi_if`: pkt×VC cross + per-layer activity
- checker `cg_hsi`: channel / wake / valid + wake×valid cross

## Quick start

```bash
cd scripts
make all                        # TEST=mipi_csi2_test (default)
make run TEST=mipi_hsi_test
./coverage_regression.sh        # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.4.0)

- **Driver**: real HSI link behavior — receiver wake pulse, logical channel
  select, flow encoding, packet streaming with valid/ready flow control,
  CRC/ECC sideband, corrupt-CRC error injection
- **Monitor**: SOP→EOP packet reassembly, word-count trim, **CRC-32
  re-computation** and error classification, analysis-port publish
- **End-to-end scoreboard**: expected-vs-observed pairing with payload
  compare; injected CRC errors must be *detected* to match
  (`n_matches`/`n_mismatches`, `UVM_ERROR` on mismatch)
- **Functional DUT**: HSI receiver model (wake/ready handshake, randomized
  backpressure, frame capture, CRC check, `err` flag) closing the loop
- **Coverage**: 3 covergroups (protocol config, word-count data patterns,
  lane-FSM transitions) with crosses + analysis-driven sampling
- **SVA L4**: five HSI-specific rules on top of the tiered L1/L2 set
