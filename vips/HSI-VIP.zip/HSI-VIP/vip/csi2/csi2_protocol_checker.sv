// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// csi2_protocol_checker.sv -- CSI-2 protocol checker (MIPI VIP infrastructure)
`ifndef CSI2_PROTOCOL_CHECKER_SV
`define CSI2_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// csi2_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module csi2_protocol_checker_sva (mipi_vip_if vif);

  int err_cnt = 0;


property p_csi2_vc;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.valid |-> vif.vc inside {[3'd0:3'd3]};
endproperty
assert_csi2_vc: assert property (p_csi2_vc)
  else begin
    `uvm_error("CSI2_CHK", "CSI-2 VC out of range")
    err_cnt++;
  end

property p_csi2_wc;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop) |-> vif.word_count > 16'd0;
endproperty
assert_csi2_wc: assert property (p_csi2_wc)
  else begin
    `uvm_error("CSI2_CHK", "CSI-2 zero word count")
    err_cnt++;
  end

property p_csi2_pkt;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.valid |-> vif.pkt_type != 6'h3F;
endproperty
assert_csi2_pkt: assert property (p_csi2_pkt)
  else begin
    `uvm_error("CSI2_CHK", "CSI-2 reserved packet type")
    err_cnt++;
  end

  final begin
    `uvm_info("CSI2_RPT", $sformatf("CSI-2 Chk | errors:%0d", err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// csi2_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the csi2_protocol_checker_sva module above)
// ============================================================================

class csi2_protocol_checker extends uvm_component;
  `uvm_component_utils(csi2_protocol_checker)
  function new(string name = "csi2_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
