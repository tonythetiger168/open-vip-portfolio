// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dphy_protocol_checker.sv -- D-PHY protocol checker (MIPI VIP infrastructure)
`ifndef DPHY_PROTOCOL_CHECKER_SV
`define DPHY_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// dphy_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module dphy_protocol_checker_sva (mipi_vip_if vif);

  int err_cnt = 0;


property p_dphy_hs;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.dphy_hs_rqst |-> ##[1:100] vif.dphy_hs_rdy;
endproperty
assert_dphy_hs: assert property (p_dphy_hs)
  else begin
    `uvm_error("DPHY_CHK", "D-PHY HS handshake timeout")
    err_cnt++;
  end

property p_dphy_lp;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.dphy_lp_dir |-> !vif.dphy_hs_rqst;
endproperty
assert_dphy_lp: assert property (p_dphy_lp)
  else begin
    `uvm_error("DPHY_CHK", "D-PHY LP/HS contention")
    err_cnt++;
  end

property p_dphy_clk;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.dphy_hs_rqst |-> vif.dphy_clk_p != vif.dphy_clk_n;
endproperty
assert_dphy_clk: assert property (p_dphy_clk)
  else begin
    `uvm_error("DPHY_CHK", "D-PHY DDR clock not differential")
    err_cnt++;
  end

  final begin
    `uvm_info("DPHY_RPT", $sformatf("D-PHY Chk | errors:%0d", err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// dphy_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the dphy_protocol_checker_sva module above)
// ============================================================================

class dphy_protocol_checker extends uvm_component;
  `uvm_component_utils(dphy_protocol_checker)
  function new(string name = "dphy_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
