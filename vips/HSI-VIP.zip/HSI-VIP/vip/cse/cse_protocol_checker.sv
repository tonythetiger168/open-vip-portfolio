// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cse_protocol_checker.sv -- CSE protocol checker (MIPI VIP infrastructure)
`ifndef CSE_PROTOCOL_CHECKER_SV
`define CSE_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// cse_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module cse_protocol_checker_sva (mipi_vip_if vif);

  int err_cnt = 0;


property p_cse_cmd;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.cse_valid |-> vif.cse_cmd inside {[4'd0:4'd15]};
endproperty
assert_cse_cmd: assert property (p_cse_cmd)
  else begin
    `uvm_error("CSE_CHK", "CSE command out of range")
    err_cnt++;
  end

property p_cse_rdy;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.cse_valid |-> ##[1:32] vif.cse_ready;
endproperty
assert_cse_rdy: assert property (p_cse_rdy)
  else begin
    `uvm_error("CSE_CHK", "CSE ready timeout")
    err_cnt++;
  end

property p_cse_irq;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.cse_irq |-> !$isunknown(vif.cse_cmd);
endproperty
assert_cse_irq: assert property (p_cse_irq)
  else begin
    `uvm_error("CSE_CHK", "CSE IRQ with unknown command")
    err_cnt++;
  end

  final begin
    `uvm_info("CSE_RPT", $sformatf("CSE Chk | errors:%0d", err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// cse_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the cse_protocol_checker_sva module above)
// ============================================================================

class cse_protocol_checker extends uvm_component;
  `uvm_component_utils(cse_protocol_checker)
  function new(string name = "cse_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
