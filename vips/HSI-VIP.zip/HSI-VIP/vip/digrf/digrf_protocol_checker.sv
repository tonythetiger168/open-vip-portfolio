// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// digrf_protocol_checker.sv -- DigRFv4 protocol checker (MIPI VIP infrastructure)
`ifndef DIGRF_PROTOCOL_CHECKER_SV
`define DIGRF_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// digrf_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module digrf_protocol_checker_sva (mipi_vip_if vif);

  int err_cnt = 0;


property p_digrf_sync;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.digrf_frame_sync |-> vif.digrf_valid;
endproperty
assert_digrf_sync: assert property (p_digrf_sync)
  else begin
    `uvm_error("DIGRF_CHK", "DigRF frame sync without valid")
    err_cnt++;
  end

property p_digrf_ant;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.digrf_valid |-> vif.digrf_antenna <= 4'd15;
endproperty
assert_digrf_ant: assert property (p_digrf_ant)
  else begin
    `uvm_error("DIGRF_CHK", "DigRF antenna id out of range")
    err_cnt++;
  end

property p_digrf_iq;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.digrf_valid |-> !$isunknown({vif.digrf_i, vif.digrf_q});
endproperty
assert_digrf_iq: assert property (p_digrf_iq)
  else begin
    `uvm_error("DIGRF_CHK", "DigRF I/Q unknown")
    err_cnt++;
  end

  final begin
    `uvm_info("DIGRF_RPT", $sformatf("DigRFv4 Chk | errors:%0d", err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// digrf_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the digrf_protocol_checker_sva module above)
// ============================================================================

class digrf_protocol_checker extends uvm_component;
  `uvm_component_utils(digrf_protocol_checker)
  function new(string name = "digrf_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
