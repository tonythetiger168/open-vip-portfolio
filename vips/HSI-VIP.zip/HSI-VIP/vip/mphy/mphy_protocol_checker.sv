// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// mphy_protocol_checker.sv -- M-PHY protocol checker (MIPI VIP infrastructure)
`ifndef MPHY_PROTOCOL_CHECKER_SV
`define MPHY_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// mphy_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module mphy_protocol_checker_sva (mipi_vip_if vif);

  int err_cnt = 0;


property p_mphy_gear;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.mphy_hs_mode |-> vif.mphy_gear inside {[4'd1:4'd5]};
endproperty
assert_mphy_gear: assert property (p_mphy_gear)
  else begin
    `uvm_error("MPHY_CHK", "M-PHY gear out of range")
    err_cnt++;
  end

property p_mphy_series;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.mphy_hs_mode |-> (vif.mphy_series_a ^ vif.mphy_series_b);
endproperty
assert_mphy_series: assert property (p_mphy_series)
  else begin
    `uvm_error("MPHY_CHK", "M-PHY series A/B conflict")
    err_cnt++;
  end

property p_mphy_rdy;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.valid |-> ##[1:64] vif.mphy_ready;
endproperty
assert_mphy_rdy: assert property (p_mphy_rdy)
  else begin
    `uvm_error("MPHY_CHK", "M-PHY ready timeout")
    err_cnt++;
  end

  final begin
    `uvm_info("MPHY_RPT", $sformatf("M-PHY Chk | errors:%0d", err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// mphy_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the mphy_protocol_checker_sva module above)
// ============================================================================

class mphy_protocol_checker extends uvm_component;
  `uvm_component_utils(mphy_protocol_checker)
  function new(string name = "mphy_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
