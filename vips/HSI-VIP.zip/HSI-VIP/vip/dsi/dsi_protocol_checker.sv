// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dsi_protocol_checker.sv -- DSI protocol checker (MIPI VIP infrastructure)
`ifndef DSI_PROTOCOL_CHECKER_SV
`define DSI_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// dsi_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module dsi_protocol_checker_sva (mipi_vip_if vif);

  int err_cnt = 0;


property p_dsi_vc;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.valid |-> vif.vc inside {[3'd0:3'd3]};
endproperty
assert_dsi_vc: assert property (p_dsi_vc)
  else begin
    `uvm_error("DSI_CHK", "DSI VC out of range")
    err_cnt++;
  end

property p_dsi_rgb;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop && vif.pkt_type == 6'h2E) |-> vif.word_count > 16'd2;
endproperty
assert_dsi_rgb: assert property (p_dsi_rgb)
  else begin
    `uvm_error("DSI_CHK", "DSI RGB888 short packet")
    err_cnt++;
  end

property p_dsi_ecc;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.valid |-> !$isunknown(vif.ecc);
endproperty
assert_dsi_ecc: assert property (p_dsi_ecc)
  else begin
    `uvm_error("DSI_CHK", "DSI ECC unknown")
    err_cnt++;
  end

  final begin
    `uvm_info("DSI_RPT", $sformatf("DSI Chk | errors:%0d", err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// dsi_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the dsi_protocol_checker_sva module above)
// ============================================================================

class dsi_protocol_checker extends uvm_component;
  `uvm_component_utils(dsi_protocol_checker)
  function new(string name = "dsi_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
