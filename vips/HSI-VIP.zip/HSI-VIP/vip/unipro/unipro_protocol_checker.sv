// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// unipro_protocol_checker.sv -- UniPro protocol checker (MIPI VIP infrastructure)
`ifndef UNIPRO_PROTOCOL_CHECKER_SV
`define UNIPRO_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// unipro_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module unipro_protocol_checker_sva (mipi_vip_if vif);

  int err_cnt = 0;


property p_unipro_tc;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.unipro_valid |-> vif.unipro_tc inside {[3'd0:3'd3]};
endproperty
assert_unipro_tc: assert property (p_unipro_tc)
  else begin
    `uvm_error("UNIPRO_CHK", "UniPro traffic class out of range")
    err_cnt++;
  end

property p_unipro_cport;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.unipro_valid |-> vif.unipro_cport <= 4'd15;
endproperty
assert_unipro_cport: assert property (p_unipro_cport)
  else begin
    `uvm_error("UNIPRO_CHK", "UniPro CPort out of range")
    err_cnt++;
  end

property p_unipro_rdy;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.unipro_valid |-> ##[1:32] vif.unipro_ready;
endproperty
assert_unipro_rdy: assert property (p_unipro_rdy)
  else begin
    `uvm_error("UNIPRO_CHK", "UniPro ready timeout")
    err_cnt++;
  end

  final begin
    `uvm_info("UNIPRO_RPT", $sformatf("UniPro Chk | errors:%0d", err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// unipro_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the unipro_protocol_checker_sva module above)
// ============================================================================

class unipro_protocol_checker extends uvm_component;
  `uvm_component_utils(unipro_protocol_checker)
  function new(string name = "unipro_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
