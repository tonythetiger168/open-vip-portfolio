// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hsi_protocol_checker.sv -- HSI protocol checker
// SVA for HSI wake/handshake, logical channels and flow control.

`ifndef HSI_PROTOCOL_CHECKER_SV
`define HSI_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// hsi_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module hsi_protocol_checker_sva (mipi_vip_if vif);

  int wake_err = 0;
  int ch_err = 0;
  int ready_err = 0;

property p_hsi_wake;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.hsi_wake) |-> ##[1:10] vif.hsi_valid;
endproperty
assert_hsi_wake: assert property (p_hsi_wake)
  else begin
    `uvm_error("HSI_CHK", "HSI wake timeout")
    wake_err++;
  end

property p_hsi_ch;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.hsi_valid) |-> vif.hsi_channel inside {[4'd0:4'd15]};
endproperty
assert_hsi_ch: assert property (p_hsi_ch)
  else begin
    `uvm_error("HSI_CHK", "HSI channel invalid")
    ch_err++;
  end

property p_hsi_ready;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.hsi_valid) |-> ##[1:16] vif.hsi_ready;
endproperty
assert_hsi_ready: assert property (p_hsi_ready)
  else begin
    `uvm_error("HSI_CHK", "HSI ready timeout")
    ready_err++;
  end

  final begin
    `uvm_info("HSI_RPT", $sformatf("HSI Chk | Wake:%0d Ch:%0d Rdy:%0d",
              wake_err, ch_err, ready_err), UVM_LOW)
  end
endmodule

// ============================================================================
// hsi_protocol_checker -- UVM shell; concurrent SVA moved to the
// hsi_protocol_checker_sva module above (the channel covergroup, which is
// legal class content, stays here)
// ============================================================================
class hsi_protocol_checker extends uvm_component;
  `uvm_component_utils(hsi_protocol_checker)

  virtual mipi_vip_if vif;

  function new(string name = "hsi_chk", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual mipi_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "HSI chk: no vif")
  endfunction

  covergroup cg_hsi @(posedge vif.clk);
    option.per_instance = 1;
    cp_ch: coverpoint vif.hsi_channel {
      bins ch0    = {0};
      bins ch1    = {1};
      bins ch2    = {2};
      bins ch3    = {3};
      bins ch4_15 = {[4:15]};
    }
    cp_wake:  coverpoint vif.hsi_wake  { bins off = {0}; bins on = {1}; }
    cp_valid: coverpoint vif.hsi_valid { bins off = {0}; bins on = {1}; }
    cross_wake_valid: cross cp_wake, cp_valid;
  endgroup

  // The class-scope covergroup instance is constructed implicitly with the
  // class (explicit new() of the implicit handle is rejected by some tools).
endclass
`endif
