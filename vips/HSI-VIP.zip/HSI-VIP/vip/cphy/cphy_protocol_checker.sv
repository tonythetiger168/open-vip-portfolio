// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cphy_protocol_checker.sv -- C-PHY protocol checker (MIPI VIP infrastructure)
`ifndef CPHY_PROTOCOL_CHECKER_SV
`define CPHY_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// cphy_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module cphy_protocol_checker_sva (mipi_vip_if vif);

  int err_cnt = 0;


property p_cphy_sym;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.cphy_symbol_valid |-> vif.cphy_symbol != 0;
endproperty
assert_cphy_sym: assert property (p_cphy_sym)
  else begin
    `uvm_error("CPHY_CHK", "C-PHY zero symbol")
    err_cnt++;
  end

property p_cphy_lane;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.cphy_symbol_valid |-> !$isunknown(vif.cphy_symbol);
endproperty
assert_cphy_lane: assert property (p_cphy_lane)
  else begin
    `uvm_error("CPHY_CHK", "C-PHY symbol unknown")
    err_cnt++;
  end

property p_cphy_diff;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.cphy_symbol_valid |-> vif.cphy_tx_p != vif.cphy_tx_n;
endproperty
assert_cphy_diff: assert property (p_cphy_diff)
  else begin
    `uvm_error("CPHY_CHK", "C-PHY wires not differential")
    err_cnt++;
  end

  final begin
    `uvm_info("CPHY_RPT", $sformatf("C-PHY Chk | errors:%0d", err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// cphy_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the cphy_protocol_checker_sva module above)
// ============================================================================

class cphy_protocol_checker extends uvm_component;
  `uvm_component_utils(cphy_protocol_checker)
  function new(string name = "cphy_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
