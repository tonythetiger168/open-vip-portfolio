// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// m_phy_compliance_checker.sv -- M-PHY tiered compliance SVA checker (module)
// L1 = basic compliance, L2 = full protocol, L3 = advanced, L4 = protocol-specific
`ifndef M_PHY_COMPLIANCE_CHECKER_SV
`define M_PHY_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module m_phy_compliance_checker (mipi_vip_if vif);
  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_mphy_gear; @(posedge vif.clk) disable iff (!vif.rst_n) vif.gear inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_mphy_gear: assert property(p_mphy_gear) l1_pass[0]++; else begin `uvm_warning("M-PHY_L1", "Gear valid failed"); l1_fail[0]++; end
  cover_p_mphy_gear: cover property(p_mphy_gear);
  property p_mphy_mode; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mode inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_mphy_mode: assert property(p_mphy_mode) l1_pass[1]++; else begin `uvm_warning("M-PHY_L1", "Mode valid failed"); l1_fail[1]++; end
  cover_p_mphy_mode: cover property(p_mphy_mode);
  property p_mphy_lane; @(posedge vif.clk) disable iff (!vif.rst_n) vif.lane_state inside {4'b0000,4'b0001,4'b0010,4'b0011,4'b0100,4'b0101,4'b0110,4'b0111,4'b1000,4'b1001,4'b1010,4'b1011,4'b1100,4'b1101,4'b1110,4'b1111}; endproperty
  assert_p_mphy_lane: assert property(p_mphy_lane) l1_pass[2]++; else begin `uvm_warning("M-PHY_L1", "Lane state valid failed"); l1_fail[2]++; end
  cover_p_mphy_lane: cover property(p_mphy_lane);
  property p_mphy_pwr; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pwr_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_mphy_pwr: assert property(p_mphy_pwr) l1_pass[3]++; else begin `uvm_warning("M-PHY_L1", "Power state valid failed"); l1_fail[3]++; end
  cover_p_mphy_pwr: cover property(p_mphy_pwr);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_mphy_hs; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_burst |-> vif.lane_state == 4'b0100; endproperty
  assert_p_mphy_hs: assert property(p_mphy_hs) l2_pass[0]++; else begin `uvm_warning("M-PHY_L2", "HS burst valid failed"); l2_fail[0]++; end
  cover_p_mphy_hs: cover property(p_mphy_hs);
  property p_mphy_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_burst |-> !$isunknown(vif.data); endproperty
  assert_p_mphy_no_x: assert property(p_mphy_no_x) l2_pass[1]++; else begin `uvm_warning("M-PHY_L2", "No X in HS failed"); l2_fail[1]++; end
  cover_p_mphy_no_x: cover property(p_mphy_no_x);
  property p_mphy_term; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_burst |-> vif.term_en; endproperty
  assert_p_mphy_term: assert property(p_mphy_term) l2_pass[2]++; else begin `uvm_warning("M-PHY_L2", "Termination on HS failed"); l2_fail[2]++; end
  cover_p_mphy_term: cover property(p_mphy_term);
  property p_mphy_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync |-> vif.lane_state == 4'b0011; endproperty
  assert_p_mphy_sync: assert property(p_mphy_sync) l2_pass[3]++; else begin `uvm_warning("M-PHY_L2", "Sync valid failed"); l2_fail[3]++; end
  cover_p_mphy_sync: cover property(p_mphy_sync);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_mphy_pwm; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pwm_burst |-> vif.lane_state == 4'b0110; endproperty
  assert_p_mphy_pwm: assert property(p_mphy_pwm) l3_pass[0]++; else begin `uvm_warning("M-PHY_L3", "PWM burst failed"); l3_fail[0]++; end
  cover_p_mphy_pwm: cover property(p_mphy_pwm);
  property p_mphy_hibern8; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hibern8 |-> vif.pwr_state == 3'b101; endproperty
  assert_p_mphy_hibern8: assert property(p_mphy_hibern8) l3_pass[1]++; else begin `uvm_warning("M-PHY_L3", "HIBERN8 failed"); l3_fail[1]++; end
  cover_p_mphy_hibern8: cover property(p_mphy_hibern8);
  property p_mphy_stall; @(posedge vif.clk) disable iff (!vif.rst_n) vif.stall |-> vif.pwr_state == 3'b010; endproperty
  assert_p_mphy_stall: assert property(p_mphy_stall) l3_pass[2]++; else begin `uvm_warning("M-PHY_L3", "STALL state failed"); l3_fail[2]++; end
  cover_p_mphy_stall: cover property(p_mphy_stall);
  property p_mphy_save; @(posedge vif.clk) disable iff (!vif.rst_n) vif.save |-> vif.pwr_state == 3'b011; endproperty
  assert_p_mphy_save: assert property(p_mphy_save) l3_pass[3]++; else begin `uvm_warning("M-PHY_L3", "SAVE state failed"); l3_fail[3]++; end
  cover_p_mphy_save: cover property(p_mphy_save);

  // ---------------- L4: M-PHY protocol-specific rules (4) ----------------
  property p_mphy_l4_gear_change; @(posedge vif.clk) disable iff (!vif.rst_n) $changed(vif.gear) |-> (!vif.hs_burst && !vif.pwm_burst); endproperty
  assert_p_mphy_l4_gear_change: assert property(p_mphy_l4_gear_change) l4_pass[0]++; else begin `uvm_warning("M-PHY_L4", "Gear change during burst failed"); l4_fail[0]++; end
  cover_p_mphy_l4_gear_change: cover property(p_mphy_l4_gear_change);
  property p_mphy_l4_sync_burst; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.hs_burst) |-> ($past(vif.sync,1) || $past(vif.sync,2)); endproperty
  assert_p_mphy_l4_sync_burst: assert property(p_mphy_l4_sync_burst) l4_pass[1]++; else begin `uvm_warning("M-PHY_L4", "Burst without SYNC failed"); l4_fail[1]++; end
  cover_p_mphy_l4_sync_burst: cover property(p_mphy_l4_sync_burst);
  property p_mphy_l4_hibern8_wake; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hibern8 |-> s_eventually (vif.pwr_state == 3'b000); endproperty
  assert_p_mphy_l4_hibern8_wake: assert property(p_mphy_l4_hibern8_wake) l4_pass[2]++; else begin `uvm_warning("M-PHY_L4", "Hibern8 without wake failed"); l4_fail[2]++; end
  cover_p_mphy_l4_hibern8_wake: cover property(p_mphy_l4_hibern8_wake);
  property p_mphy_l4_stall_save; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.pwr_state == 3'b011) |-> $past(vif.pwr_state,1) == 3'b010 || $past(vif.pwr_state,1) == 3'b011; endproperty
  assert_p_mphy_l4_stall_save: assert property(p_mphy_l4_stall_save) l4_pass[3]++; else begin `uvm_warning("M-PHY_L4", "SAVE without STALL failed"); l4_fail[3]++; end
  cover_p_mphy_l4_stall_save: cover property(p_mphy_l4_stall_save);

  final begin : sva_report
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("M-PHY_RPT", $sformatf("=== M-PHY Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("M-PHY_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("M-PHY_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("M-PHY_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("M-PHY_RPT", $sformatf("  L4 Protocol Specific:  %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("M-PHY_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
