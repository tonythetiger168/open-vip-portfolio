// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// unipro_compliance_checker.sv -- UniPro tiered compliance SVA checker (module)
// L1 = basic compliance, L2 = full protocol, L3 = advanced, L4 = protocol-specific
`ifndef UNIPRO_COMPLIANCE_CHECKER_SV
`define UNIPRO_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module unipro_compliance_checker (mipi_vip_if vif);
  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_unipro_cp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cp_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_unipro_cp: assert property(p_unipro_cp) l1_pass[0]++; else begin `uvm_warning("UNIPRO_L1", "CP valid failed"); l1_fail[0]++; end
  cover_p_unipro_cp: cover property(p_unipro_cp);
  property p_unipro_tc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tc <= 3'd7; endproperty
  assert_p_unipro_tc: assert property(p_unipro_tc) l1_pass[1]++; else begin `uvm_warning("UNIPRO_L1", "TC 0-7 failed"); l1_fail[1]++; end
  cover_p_unipro_tc: cover property(p_unipro_tc);
  property p_unipro_vc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vc <= 4'd15; endproperty
  assert_p_unipro_vc: assert property(p_unipro_vc) l1_pass[2]++; else begin `uvm_warning("UNIPRO_L1", "VC 0-15 failed"); l1_fail[2]++; end
  cover_p_unipro_vc: cover property(p_unipro_vc);
  property p_unipro_nack; @(posedge vif.clk) disable iff (!vif.rst_n) vif.nack |-> vif.valid; endproperty
  assert_p_unipro_nack: assert property(p_unipro_nack) l1_pass[3]++; else begin `uvm_warning("UNIPRO_L1", "NACK valid failed"); l1_fail[3]++; end
  cover_p_unipro_nack: cover property(p_unipro_nack);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_unipro_eof; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eof |-> $past(vif.sof,1) || vif.sof; endproperty
  assert_p_unipro_eof: assert property(p_unipro_eof) l2_pass[0]++; else begin `uvm_warning("UNIPRO_L2", "EOF follows SOF failed"); l2_fail[0]++; end
  cover_p_unipro_eof: cover property(p_unipro_eof);
  property p_unipro_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_unipro_no_x: assert property(p_unipro_no_x) l2_pass[1]++; else begin `uvm_warning("UNIPRO_L2", "No X when valid failed"); l2_fail[1]++; end
  cover_p_unipro_no_x: cover property(p_unipro_no_x);
  property p_unipro_credit; @(posedge vif.clk) disable iff (!vif.rst_n) vif.credit <= 8'd255; endproperty
  assert_p_unipro_credit: assert property(p_unipro_credit) l2_pass[2]++; else begin `uvm_warning("UNIPRO_L2", "Credit 0-255 failed"); l2_fail[2]++; end
  cover_p_unipro_credit: cover property(p_unipro_credit);
  property p_unipro_power; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pwr_mode inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_unipro_power: assert property(p_unipro_power) l2_pass[3]++; else begin `uvm_warning("UNIPRO_L2", "Power mode failed"); l2_fail[3]++; end
  cover_p_unipro_power: cover property(p_unipro_power);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: a NACKed frame must eventually be retransmitted
  property p_unipro_l3_nack_retry; @(posedge vif.clk) disable iff (!vif.rst_n) vif.nack |-> s_eventually (vif.sof && vif.valid); endproperty
  assert_p_unipro_l3_nack_retry: assert property(p_unipro_l3_nack_retry) l3_pass[0]++; else begin `uvm_warning("UNIPRO_L3", "NACK without retransmission failed"); l3_fail[0]++; end
  cover_p_unipro_l3_nack_retry: cover property(p_unipro_l3_nack_retry);
  // L3-2: link-layer credit is stable while no frame is being sent
  property p_unipro_l3_credit_idle; @(posedge vif.clk) disable iff (!vif.rst_n) (!vif.valid && !vif.sof) |-> $stable(vif.credit); endproperty
  assert_p_unipro_l3_credit_idle: assert property(p_unipro_l3_credit_idle) l3_pass[1]++; else begin `uvm_warning("UNIPRO_L3", "Credit changed while idle failed"); l3_fail[1]++; end
  cover_p_unipro_l3_credit_idle: cover property(p_unipro_l3_credit_idle);
  // L3-3: stalled transfer must hold valid until accepted
  property p_unipro_l3_valid_hold; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && !vif.ready) |=> vif.valid; endproperty
  assert_p_unipro_l3_valid_hold: assert property(p_unipro_l3_valid_hold) l3_pass[2]++; else begin `uvm_warning("UNIPRO_L3", "Valid dropped before ready failed"); l3_fail[2]++; end
  cover_p_unipro_l3_valid_hold: cover property(p_unipro_l3_valid_hold);
  // L3-4: no traffic while the CPort state is changing
  property p_unipro_l3_cp_change; @(posedge vif.clk) disable iff (!vif.rst_n) $changed(vif.cp_state) |-> !vif.valid; endproperty
  assert_p_unipro_l3_cp_change: assert property(p_unipro_l3_cp_change) l3_pass[3]++; else begin `uvm_warning("UNIPRO_L3", "Traffic during CPort state change failed"); l3_fail[3]++; end
  cover_p_unipro_l3_cp_change: cover property(p_unipro_l3_cp_change);

  // ---------------- L4: UniPro protocol-specific rules (4) ----------------
  property p_unipro_l4_sof_eof; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.sof) |-> s_eventually vif.eof; endproperty
  assert_p_unipro_l4_sof_eof: assert property(p_unipro_l4_sof_eof) l4_pass[0]++; else begin `uvm_warning("UNIPRO_L4", "SOF without EOF failed"); l4_fail[0]++; end
  cover_p_unipro_l4_sof_eof: cover property(p_unipro_l4_sof_eof);
  property p_unipro_l4_no_sof_overlap; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.sof) |-> (!vif.sof throughout (vif.eof [->1])); endproperty
  assert_p_unipro_l4_no_sof_overlap: assert property(p_unipro_l4_no_sof_overlap) l4_pass[1]++; else begin `uvm_warning("UNIPRO_L4", "Overlapping SOF failed"); l4_fail[1]++; end
  cover_p_unipro_l4_no_sof_overlap: cover property(p_unipro_l4_no_sof_overlap);
  property p_unipro_l4_credit; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && vif.sof) |-> vif.credit > 0; endproperty
  assert_p_unipro_l4_credit: assert property(p_unipro_l4_credit) l4_pass[2]++; else begin `uvm_warning("UNIPRO_L4", "Frame with zero credit failed"); l4_fail[2]++; end
  cover_p_unipro_l4_credit: cover property(p_unipro_l4_credit);
  property p_unipro_l4_pwr_idle; @(posedge vif.clk) disable iff (!vif.rst_n) $changed(vif.pwr_mode) |-> !vif.valid; endproperty
  assert_p_unipro_l4_pwr_idle: assert property(p_unipro_l4_pwr_idle) l4_pass[3]++; else begin `uvm_warning("UNIPRO_L4", "Power mode change during traffic failed"); l4_fail[3]++; end
  cover_p_unipro_l4_pwr_idle: cover property(p_unipro_l4_pwr_idle);

  final begin : sva_report
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("UNIPRO_RPT", $sformatf("=== UniPro Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("UNIPRO_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("UNIPRO_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("UNIPRO_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("UNIPRO_RPT", $sformatf("  L4 Protocol Specific:  %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("UNIPRO_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
