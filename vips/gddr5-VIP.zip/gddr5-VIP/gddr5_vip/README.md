# GDDR5 UVM VIP

**Protocol Level:** Complex
**Checkers:** 4 UVM components (Protocol L1, Data Integrity L2, Timing L2, Error L3) + module-based SVA compliance checker (L1-L4)
**License:** Apache-2.0

## Protocol Overview
GDDR5 graphics DRAM: DDR command/address with WCK data clocking and DBI (data bus inversion) support.

The VIP drives and monitors a DDR-style command/address bus
(`cs_n/act_n/ras_n/cas_n/we_n` + `{bg,ba}` bank + `addr` row/column):

| Command | cs_n | act_n | ras_n | cas_n | we_n | Address |
|---------|------|-------|-------|-------|------|---------|
| ACT     | 0    | 0     | -     | -     | -    | row     |
| RD      | 0    | 1     | 1     | 0     | 1    | column  |
| WR      | 0    | 1     | 1     | 0     | 0    | column  |
| PRE     | 0    | 1     | 0     | 1     | 0    | -       |
| REF     | 0    | 1     | 0     | 0     | 1    | -       |
| NOP     | 0    | 1     | 1     | 1     | 1    | -       |

Core timing parameters (cycles): tRCD=12, tRP=12, tRAS=16, tCL=12, tCWL=2, tRFC=40, tREFI=3900.

## Architecture
```
gddr5_vip/
|-- rtl/gddr5_if.sv                    # signal interface (+ clocking block)
|-- sequences/gddr5_sequence.sv        # transaction + directed sequence library
|-- vip/gddr5/
|   |-- gddr5_driver.sv                # protocol driver (cmd encoding, timing, DQ)
|   |-- gddr5_monitor.sv               # bus monitor (command/DQ decode -> analysis port)
|   |-- gddr5_agent.sv                 # sequencer + driver + monitor
|   |-- gddr5_coverage.sv              # 3 covergroups with crosses
|   |-- gddr5_compliance_checker.sv    # SVA module, L1-L4 (instanced in tb_top)
|   |-- gddr5_protocol_checker.sv      # L1 component (procedural sampling)
|   |-- gddr5_timing_checker.sv        # L2 component (tRCD/tRP/tRAS measurement)
|   |-- gddr5_data_integrity_checker.sv# L2 component (DQ/DBI/BL sampling)
|   |-- gddr5_error_checker.sv         # L3 component (temp/refresh/DFE monitoring)
|-- env/gddr5_env.sv                   # env + end-to-end scoreboard
|-- tests/gddr5_test.sv                # base/write/read/stress tests
|-- tb/tb_top.sv                     # TB top + DRAM memory-array functional model
|-- Makefile
```

Closed loop: sequences -> driver -> `gddr5_if` -> `gddr5_mem_model` (bank/row/col
storage in tb_top) drives read data back -> monitor decodes -> scoreboard
compares expected (driver) vs observed (monitor) end-to-end.

## Sequence Library
| Sequence | Purpose |
|----------|---------|
| `gddr5_base_sequence` | legacy fully-random items (API compatibility) |
| `gddr5_write_seq` | normal write flow: ACT, WR burst, PRE |
| `gddr5_read_seq` | normal read flow: ACT, RD burst, PRE |
| `gddr5_refresh_seq` | traffic punctuated by REF (tRFC apart) |
| `gddr5_bank_conflict_seq` | same bank, alternating rows (page misses) |
| `gddr5_back_to_back_seq` | one ACT, long alternating RD/WR stream (page hits) |
| `gddr5_stress_seq` | long protocol-legal random stream (bank-state model) |
| `gddr5_corner_seq` | all-zero/all-one row/col, boundary banks/stacks |
| `gddr5_random_sequence` | 50 random items |
| `gddr5_regression_sequence` | weighted mix of all directed sequences |

Tests: `gddr5_base_test` (regression seq), `gddr5_write_test`, `gddr5_read_test`, `gddr5_stress_test`.

## SVA Compliance Checker (vip/gddr5/gddr5_compliance_checker.sv)
- **L1 signal sanity (4):** command/address known when selected, bank group/address encoding bounds.
- **L2 timing & data integrity (8):** tRCD/tRP windows, burst length, data valid with DQS, DBI/WCK settings.
- **L3 error handling (6):** power-management state, refresh interval, over-temperature, DFE/bandwidth/latency bounds.
- **L4 GDDR5-specific (10):** ACT/RD-WR/PRE bank-state legality (3), tRCD/tRP/tRAS timing rules (3), refresh pulse width, CKE gating, family rules (WCK ratio + DBI status), refresh-interval + ACT->col->PRE covers.

## Functional Coverage (vip/gddr5/gddr5_coverage.sv)
- `cg_command`    : command distribution x bank cross (`cx_cmd_bank`)
- `cg_bank_state` : bank state transitions (ACT=>RD/WR, RD/WR=>PRE, PRE/REF=>ACT, RD<=>WR)
- `cg_addr`       : row/col/stack address patterns with `cx_row_col` cross

## Quick Start
```bash
make comp                                   # compile (VCS + UVM 1.2)
make sim                                    # run default test
make regress                                # run regression test
./simv +UVM_TESTNAME=gddr5_stress_test        # run a directed test
```
