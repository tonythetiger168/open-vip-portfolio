// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// gddr5_agent.sv -- GDDR5 UVM agent (sequencer + driver + monitor)

`ifndef GDDR5_AGENT_SV
`define GDDR5_AGENT_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
typedef class gddr5_driver;
typedef class gddr5_monitor;

class gddr5_agent extends uvm_agent;
  `uvm_component_utils(gddr5_agent)
  uvm_sequencer #(gddr5_transaction) sqr;
  gddr5_driver  drv;
  gddr5_monitor mon;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    sqr = uvm_sequencer #(gddr5_transaction)::type_id::create("sqr", this);
    drv = gddr5_driver::type_id::create("drv", this);
    mon = gddr5_monitor::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
