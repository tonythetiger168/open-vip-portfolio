// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// gddr5_test.sv -- GDDR5 UVM tests

`ifndef GDDR5_TEST_SV
`define GDDR5_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class gddr5_base_test extends uvm_test;
  `uvm_component_utils(gddr5_base_test)
  gddr5_env env;
  function new(string name="gddr5_base_test", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = gddr5_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    gddr5_regression_sequence seq;
    phase.raise_objection(this);
    seq = gddr5_regression_sequence::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: write flow only
class gddr5_write_test extends gddr5_base_test;
  `uvm_component_utils(gddr5_write_test)
  function new(string name="gddr5_write_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr5_write_seq seq;
    phase.raise_objection(this);
    seq = gddr5_write_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: read flow + refresh flow
class gddr5_read_test extends gddr5_base_test;
  `uvm_component_utils(gddr5_read_test)
  function new(string name="gddr5_read_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr5_read_seq    rd;
    gddr5_refresh_seq rf;
    phase.raise_objection(this);
    rd = gddr5_read_seq::type_id::create("rd");
    rf = gddr5_refresh_seq::type_id::create("rf");
    rd.start(env.agt.sqr);
    rf.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress test: long protocol-legal random stream
class gddr5_stress_test extends gddr5_base_test;
  `uvm_component_utils(gddr5_stress_test)
  function new(string name="gddr5_stress_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr5_stress_seq seq;
    phase.raise_objection(this);
    seq = gddr5_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
