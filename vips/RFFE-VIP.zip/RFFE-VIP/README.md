# RFFE — MIPI RFFE UVM VIP

Open-source UVM verification IP template for **MIPI RFFE** (MIPI).

## Contents

| Path | Description |
|------|-------------|
| `rffe/rffe_if.sv` | Protocol interface (master-driven SCLK idle-low + turnaround SDATA) + FSM state enum |
| `rffe/rffe_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `rffe/sva/rffe_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=4) |
| `rffe/vip/rffe/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/rffe_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with a functional RFFE slave DUT (register maps) |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged RFFE master driver**: SSC (SDATA pulse while SCLK stopped),
  command frame (SA + CMD + ADDR + even parity), data frame (8 bits + parity),
  bus park; SCLK idles low and only toggles inside frames
- **Command set**: register write/read (5-bit address), extended write/read
  (8-bit address), register-0 write (short frame, no address bits)
- **Protocol-decoding monitor**: SSC-qualified frame decode with command and
  data parity checking plus bus-park level verification
- **End-to-end scoreboard**: expected (driver) vs observed (monitor) compare of
  slave address / command / address / data contents; injected bus-park
  violations must be observed by the monitor (`inj_park == park_err`)
- **Functional DUT model**: RFFE slave at 0x3 with 32-entry primary and
  256-entry extended register maps; turnaround SDATA drive on reads with
  parity, SSC qualification rejects mid-frame SDATA transitions
- **Directed sequence library**: reg-write / reg-read / extended write+read /
  reg0-write / all-slaves sweep / bus-park error injection + random +
  regression mix
- **Functional coverage**: command x slave-address cross, register/extended
  address bins, data corners, FSM states + frame transitions, park/parity
  error bins (with direction cross)
- **SVA L4**: SSC only while SCLK stopped, command frame length limit,
  bus park drives SDATA low at frame end, SCLK idle low
