// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// rffe_pkg.sv -- MIPI RFFE UVM VIP package

package rffe_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import rffe_defs_pkg::*;
  export rffe_defs_pkg::*;

  `include "rffe_transaction.svh"
  `include "rffe_config.svh"
  `include "rffe_sequencer.svh"
  `include "rffe_driver.svh"
  `include "rffe_monitor.svh"
  `include "rffe_agent.svh"
  `include "rffe_sequences.svh"
  `include "rffe_checker.svh"
  `include "rffe_coverage.svh"
endpackage
