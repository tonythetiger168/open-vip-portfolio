// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// rffe_reg_adapter.svh -- UVM RAL adapter for the MIPI RFFE master agent
//   reg2bus: one uvm_reg_bus_op -> one rffe_transaction
//            address 0x000-0x01F -> Register Write / Register Read (ADDR[4:0])
//            address 0x100-0x1FF -> Extended Register Write / Read (ADDR[7:0], 1 byte)
//   bus2reg: rffe_transaction (driver-completed or monitor-observed) -> uvm_reg_bus_op
// The driver writes the read data frame back into the request item (rdata)
// and sends no separate response, so provides_responses = 0. RFFE has no
// slave acknowledge on these frames, so the status is UVM_NOT_OK only when
// the monitor saw a parity or bus-park error.

`ifndef RFFE_REG_ADAPTER_SVH
`define RFFE_REG_ADAPTER_SVH

class rffe_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(rffe_reg_adapter)

  bit [3:0] slave_addr = 4'h3;   // USID of the slave the register model maps

  function new(string name = "rffe_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 0;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    rffe_transaction tr = rffe_transaction::type_id::create("ral_item");
    bit ext = rw.addr[8];
    tr.slave_addr = slave_addr;
    if (rw.kind == UVM_WRITE)
      tr.cmd = ext ? rffe_transaction::RFFE_EXT_WRITE : rffe_transaction::RFFE_REG_WRITE;
    else
      tr.cmd = ext ? rffe_transaction::RFFE_EXT_READ : rffe_transaction::RFFE_REG_READ;
    tr.reg_addr = rw.addr[4:0];
    tr.ext_addr = rw.addr[7:0];
    tr.data     = (rw.kind == UVM_WRITE) ? rw.data[7:0] : 8'h0;
    tr.inj_park = 1'b0;
    return tr;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    rffe_transaction tr;
    if (!$cast(tr, bus_item)) begin
      `uvm_fatal("RFFE_RAL", "bus2reg: item is not an rffe_transaction")
      return;
    end
    rw.kind    = tr.is_read() ? UVM_READ : UVM_WRITE;
    rw.addr    = tr.is_ext() ? {1'b1, tr.ext_addr} : {4'h0, tr.reg_addr};
    rw.data    = tr.is_read() ? tr.rdata : tr.data;
    rw.n_bits  = 8;
    rw.byte_en = '1;
    rw.status  = (tr.parity_err || tr.park_err || tr.inj_park) ? UVM_NOT_OK : UVM_IS_OK;
  endfunction
endclass
`endif
