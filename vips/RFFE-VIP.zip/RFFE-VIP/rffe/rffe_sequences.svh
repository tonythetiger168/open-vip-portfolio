// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// rffe_sequences.svh -- MIPI RFFE sequence library
// Directed sequences: register write / register read / extended access /
// register-0 write / all-slave-address sweep / bus-park error injection,
// plus random and regression mix. The DUT slave sits at address 0x3.

`ifndef RFFE_SEQUENCES_SVH
`define RFFE_SEQUENCES_SVH

class rffe_base_sequence extends uvm_sequence #(rffe_transaction);
  `uvm_object_utils(rffe_base_sequence)
  int num_txns = 20;
  bit [3:0] dut_addr = 4'h3;
  function new(string name = "rffe_base_sequence"); super.new(name); endfunction
  task body();
    rffe_transaction tr;
    repeat (num_txns) begin
      tr = rffe_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: register writes with walking register addresses
class rffe_reg_write_seq extends rffe_base_sequence;
  function new(string name = "rffe_reg_write_seq"); super.new(name); endfunction
  `uvm_object_utils(rffe_reg_write_seq)
  bit [4:0] reg_start = 5'h00;
  task body();
    rffe_transaction tr;
    repeat (num_txns) begin
      tr = rffe_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { slave_addr == dut_addr;
                                  cmd == rffe_transaction::RFFE_REG_WRITE;
                                  reg_addr == reg_start;
                                  inj_park == 0; });
      finish_item(tr);
      reg_start = (reg_start + 5'h5) % 5'h20;
    end
  endtask
endclass

// Directed: register reads (read back locations written earlier)
class rffe_reg_read_seq extends rffe_base_sequence;
  function new(string name = "rffe_reg_read_seq"); super.new(name); endfunction
  `uvm_object_utils(rffe_reg_read_seq)
  task body();
    rffe_transaction tr;
    repeat (num_txns) begin
      tr = rffe_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { slave_addr == dut_addr;
                                  cmd == rffe_transaction::RFFE_REG_READ;
                                  inj_park == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: extended write followed by extended read to the same address
class rffe_ext_seq extends rffe_base_sequence;
  function new(string name = "rffe_ext_seq"); super.new(name); endfunction
  `uvm_object_utils(rffe_ext_seq)
  task body();
    rffe_transaction tr;
    repeat (num_txns) begin
      tr = rffe_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { slave_addr == dut_addr;
                                  cmd == rffe_transaction::RFFE_EXT_WRITE;
                                  inj_park == 0; });
      finish_item(tr);
      tr = rffe_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { slave_addr == dut_addr;
                                  cmd == rffe_transaction::RFFE_EXT_READ;
                                  inj_park == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: register-0 writes (short command frame, no address bits)
class rffe_reg0_write_seq extends rffe_base_sequence;
  function new(string name = "rffe_reg0_write_seq"); super.new(name); endfunction
  `uvm_object_utils(rffe_reg0_write_seq)
  task body();
    rffe_transaction tr;
    repeat (num_txns) begin
      tr = rffe_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { slave_addr == dut_addr;
                                  cmd == rffe_transaction::RFFE_REG0_WRITE;
                                  inj_park == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: sweep all 16 slave addresses (only 0x3 responds on reads)
class rffe_all_slaves_seq extends rffe_base_sequence;
  function new(string name = "rffe_all_slaves_seq"); super.new(name); endfunction
  `uvm_object_utils(rffe_all_slaves_seq)
  task body();
    rffe_transaction tr;
    for (int sa = 0; sa < 16; sa++) begin
      tr = rffe_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { slave_addr == sa[3:0];
                                  cmd inside {rffe_transaction::RFFE_REG_WRITE,
                                              rffe_transaction::RFFE_REG_READ};
                                  inj_park == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: bus park violation (SDATA driven high during park)
class rffe_error_inject_seq extends rffe_base_sequence;
  function new(string name = "rffe_error_inject_seq"); super.new(name); endfunction
  `uvm_object_utils(rffe_error_inject_seq)
  task body();
    rffe_transaction tr;
    // park violation after a write frame
    tr = rffe_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { slave_addr == dut_addr;
                                cmd == rffe_transaction::RFFE_REG_WRITE;
                                inj_park == 1; });
    finish_item(tr);
    // park violation after a read frame
    tr = rffe_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { slave_addr == dut_addr;
                                cmd == rffe_transaction::RFFE_REG_READ;
                                inj_park == 1; });
    finish_item(tr);
  endtask
endclass

class rffe_random_sequence extends rffe_base_sequence;
  `uvm_object_utils(rffe_random_sequence)
  function new(string name = "rffe_random_sequence"); super.new(name); num_txns = 50; endfunction
  task body();
    rffe_transaction tr;
    repeat (num_txns) begin
      tr = rffe_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { slave_addr dist {4'h3 := 7, [4'h0 : 4'hF] := 3};
                                  inj_park dist {0 := 15, 1 := 1}; });
      finish_item(tr);
    end
  endtask
endclass

// Regression: weighted mix of all directed sequences
class rffe_regression_sequence extends rffe_base_sequence;
  `uvm_object_utils(rffe_regression_sequence)
  function new(string name = "rffe_regression_sequence"); super.new(name); endfunction
  task body();
    rffe_reg_write_seq    wr  = rffe_reg_write_seq::type_id::create("wr");
    rffe_reg_read_seq     rd  = rffe_reg_read_seq::type_id::create("rd");
    rffe_ext_seq          ext = rffe_ext_seq::type_id::create("ext");
    rffe_reg0_write_seq   r0  = rffe_reg0_write_seq::type_id::create("r0");
    rffe_all_slaves_seq   all = rffe_all_slaves_seq::type_id::create("all");
    rffe_error_inject_seq err = rffe_error_inject_seq::type_id::create("err");
    wr.num_txns = 16; rd.num_txns = 16; ext.num_txns = 8; r0.num_txns = 8;
    wr.start(m_sequencer);
    rd.start(m_sequencer);            // read back written registers
    ext.start(m_sequencer);
    r0.start(m_sequencer);
    all.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
