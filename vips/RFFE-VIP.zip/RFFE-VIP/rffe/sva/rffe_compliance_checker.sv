// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// rffe_compliance_checker.sv -- MIPI RFFE SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = RFFE protocol-specific rules (SSC detect, command frame length,
//      bus park level, SCLK idle low). The `sclk` port is the reference
// clock; `sclk_i`/`sdata_i` are the resolved bus signals.

`ifndef RFFE_COMPLIANCE_CHECKER_SV
`define RFFE_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import rffe_defs_pkg::rffe_state_e;
import rffe_defs_pkg::*;   // enum literals (IDLE, SSC, ...)

module rffe_compliance_checker
(
  input logic sclk,
  input logic rst_n,
  input rffe_state_e state,
  input logic sdata_i,
  input logic sclk_i
);

  // ---------------- L1: signal sanity (4) ----------------
  a_rffe_l1_clk   : assert property (@(posedge sclk) disable iff (!rst_n) !$isunknown(sclk))
    else `uvm_error("SVA_L1", "rffe: clock unknown")
  a_rffe_l1_rst   : assert property (@(posedge sclk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "rffe: reset unknown")
  a_rffe_l1_state : assert property (@(posedge sclk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "rffe: state unknown")
  a_rffe_l1_valid : assert property (@(posedge sclk) disable iff (!rst_n)
    state inside {IDLE, SSC, COMMAND_SEQ, DATA_SEQ, BUS_PARK})
    else `uvm_error("SVA_L1", "rffe: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_rffe_trans_idle : assert property (@(posedge sclk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, SSC})
    else `uvm_error("SVA_L2", "rffe: illegal transition from IDLE")

  // L2-2: legal FSM transition from SSC
  a_rffe_trans_ssc : assert property (@(posedge sclk) disable iff (!rst_n)
    state == SSC |=> state inside {SSC, COMMAND_SEQ})
    else `uvm_error("SVA_L2", "rffe: illegal transition from SSC")

  // L2-3: legal FSM transition from COMMAND_SEQ
  a_rffe_trans_command_seq : assert property (@(posedge sclk) disable iff (!rst_n)
    state == COMMAND_SEQ |=> state inside {COMMAND_SEQ, DATA_SEQ})
    else `uvm_error("SVA_L2", "rffe: illegal transition from COMMAND_SEQ")

  // L2-4: legal FSM transition from DATA_SEQ
  a_rffe_trans_data_seq : assert property (@(posedge sclk) disable iff (!rst_n)
    state == DATA_SEQ |=> state inside {DATA_SEQ, BUS_PARK})
    else `uvm_error("SVA_L2", "rffe: illegal transition from DATA_SEQ")

  // L2-5: legal FSM transition from BUS_PARK
  a_rffe_trans_bus_park : assert property (@(posedge sclk) disable iff (!rst_n)
    state == BUS_PARK |=> state inside {BUS_PARK, IDLE})
    else `uvm_error("SVA_L2", "rffe: illegal transition from BUS_PARK")

  // ---------------- L3: protocol rules (4) ----------------
  a_rffe_l3_reset_idle : assert property (@(posedge sclk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "rffe: state not IDLE during reset")
  a_rffe_l3_no_stuck   : assert property (@(posedge sclk) disable iff (!rst_n)
    state == BUS_PARK |-> ##[1:8] (state != BUS_PARK))
    else `uvm_error("SVA_L3", "rffe: stuck in BUS_PARK")
  a_rffe_l3_full_cycle : cover property (@(posedge sclk) disable iff (!rst_n)
    state == IDLE ##1 state == SSC);
  a_rffe_l3_back_idle  : cover property (@(posedge sclk) disable iff (!rst_n)
    state == BUS_PARK ##1 state == IDLE);

  // ---------------- L4: RFFE protocol-specific rules (4) ----------------
  // Count bus SCLK edges inside the command frame
  int cmd_bits;
  bit sclk_d;
  initial begin cmd_bits = 0; sclk_d = 0; end
  always @(posedge sclk) begin
    sclk_d <= sclk_i;
    if (state != COMMAND_SEQ) cmd_bits <= 0;
    else if (sclk_i && !sclk_d) cmd_bits <= cmd_bits + 1;
  end

  // L4-1: SSC is only legal while SCLK is stopped (low)
  a_rffe_l4_ssc_detect : assert property (@(posedge sclk) disable iff (!rst_n)
    state == SSC |-> (sclk_i == 1'b0))
    else `uvm_error("SVA_L4", "rffe: SSC attempted while SCLK running")

  // L4-2: command frame format: at most 20 bit clocks (SA+CMD+ADDR+parity)
  a_rffe_l4_cmd_frame : assert property (@(posedge sclk) disable iff (!rst_n)
    cmd_bits <= 20)
    else `uvm_error("SVA_L4", "rffe: command frame exceeds legal length")

  // L4-3: bus park must drive SDATA low while SCLK stays low at frame end
  a_rffe_l4_bus_park : assert property (@(posedge sclk) disable iff (!rst_n)
    state == BUS_PARK |-> ##[0:3] (!sdata_i && !sclk_i))
    else `uvm_error("SVA_L4", "rffe: bus park violation (SDATA not low)")

  // L4-4: SCLK must idle low whenever the bus is idle
  a_rffe_l4_sclk_idle_low : assert property (@(posedge sclk) disable iff (!rst_n)
    state == IDLE |-> (sclk_i == 1'b0))
    else `uvm_error("SVA_L4", "rffe: SCLK not low while bus idle")

endmodule
`endif
