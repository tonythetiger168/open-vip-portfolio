// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// rffe_transaction.svh -- MIPI RFFE transaction
// One item = one RFFE frame sequence: SSC + command frame + data frame +
// bus park. Command frames:
//   register write/read : SA[3:0] CMD[2:0] ADDR[4:0] P     (13 bits)
//   extended write/read : SA[3:0] CMD[2:0] ADDR[7:0] P     (16 bits)
//   register-0 write    : SA[3:0] CMD[2:0] P               (10 bits)
// Data frame: D[7:0] P (parity = even, XOR of frame bits).

`ifndef RFFE_TRANSACTION_SVH
`define RFFE_TRANSACTION_SVH

class rffe_transaction extends uvm_sequence_item;

  typedef enum bit [2:0] {
    RFFE_REG0_WRITE = 3'b010,
    RFFE_REG_WRITE  = 3'b011,
    RFFE_EXT_WRITE  = 3'b101,
    RFFE_REG_READ   = 3'b110,
    RFFE_EXT_READ   = 3'b111
  } rffe_cmd_e;

  rand bit [3:0]  slave_addr;
  rand rffe_cmd_e cmd;
  rand bit [4:0]  reg_addr;
  rand bit [7:0]  ext_addr;      // extended-frame address
  rand bit [7:0]  data;
  rand bit        inj_park;      // error injection: drive SDATA high at bus park

  // Observed / status fields (driver + monitor)
  bit [7:0]       rdata;         // read data frame contents
  bit             park_err;      // monitor: SDATA not low during bus park
  bit             parity_err;    // monitor: command/data parity mismatch

  constraint c_inj { inj_park dist {0 := 15, 1 := 1}; }

  function bit is_read();
    return cmd inside {RFFE_REG_READ, RFFE_EXT_READ};
  endfunction
  function bit is_ext();
    return cmd inside {RFFE_EXT_WRITE, RFFE_EXT_READ};
  endfunction

  `uvm_object_utils_begin(rffe_transaction)
    `uvm_field_int(slave_addr, UVM_ALL_ON)
    `uvm_field_enum(rffe_cmd_e, cmd, UVM_ALL_ON)
    `uvm_field_int(reg_addr, UVM_ALL_ON)
    `uvm_field_int(ext_addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(inj_park, UVM_ALL_ON)
    `uvm_field_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(park_err, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(parity_err, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "rffe_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    rffe_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= (comparer.compare_field("slave_addr", slave_addr, t.slave_addr, 4) == 1);
    do_compare &= (comparer.compare_field("cmd", cmd, t.cmd, 3) == 1);
    if (is_ext()) do_compare &= (comparer.compare_field("ext_addr", ext_addr, t.ext_addr, 8) == 1);
    else if (cmd != RFFE_REG0_WRITE)
      do_compare &= (comparer.compare_field("reg_addr", reg_addr, t.reg_addr, 5) == 1);
    if (!is_read()) do_compare &= (comparer.compare_field("data", data, t.data, 8) == 1);
  endfunction

  function string cmd_name();
    case (cmd)
      RFFE_REG0_WRITE: return "REG0_WR";
      RFFE_REG_WRITE:  return "REG_WR";
      RFFE_EXT_WRITE:  return "EXT_WR";
      RFFE_REG_READ:   return "REG_RD";
      RFFE_EXT_READ:   return "EXT_RD";
      default:         return "???";
    endcase
  endfunction

  function string convert2string();
    string s = $sformatf("RFFE %s sa=0x%01h", cmd_name(), slave_addr);
    if (is_ext()) s = {s, $sformatf(" xaddr=0x%02h", ext_addr)};
    else if (cmd != RFFE_REG0_WRITE) s = {s, $sformatf(" reg=0x%02h", reg_addr)};
    if (is_read()) s = {s, $sformatf(" rdata=0x%02h", rdata)};
    else           s = {s, $sformatf(" data=0x%02h", data)};
    if (inj_park || park_err) s = {s, $sformatf(" park(inj=%0d,err=%0d)", inj_park, park_err)};
    if (parity_err) s = {s, " PARITY_ERR"};
    return s;
  endfunction
endclass
`endif
