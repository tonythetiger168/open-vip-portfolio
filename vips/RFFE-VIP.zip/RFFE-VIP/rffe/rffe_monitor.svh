// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// rffe_monitor.svh -- MIPI RFFE monitor
// Detects the SSC (SDATA pulse while SCLK is stopped), then decodes the
// command frame (SA + CMD + ADDR + parity), the data frame (8 bits +
// parity, direction from CMD) and checks the bus-park level. Publishes
// reconstructed transactions with parity/bus-park error flags.

`ifndef RFFE_MONITOR_SVH
`define RFFE_MONITOR_SVH

class rffe_monitor extends uvm_monitor;
  `uvm_component_utils(rffe_monitor)
  virtual rffe_if vif;
  uvm_analysis_port #(rffe_transaction) ap;
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual rffe_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "rffe virtual interface not set")
  endfunction

  task automatic sample_bit(output bit b);
    @(posedge vif.sclk_i);
    b = vif.sdata_i;
  endtask

  // Decode one frame sequence starting right after the SSC pulse.
  task automatic decode_frame();
    rffe_transaction tr;
    bit [15:0] cbits = '0;
    int        nbits;
    bit        b, p, dp;

    bit [2:0]  c;
    tr = rffe_transaction::type_id::create("tr");

    // command frame: slave address + command
    for (int i = 3; i >= 0; i--) begin sample_bit(b); tr.slave_addr[i] = b; cbits = {cbits[14:0], b}; end
    for (int i = 2; i >= 0; i--) begin sample_bit(b); c[i] = b; cbits = {cbits[14:0], b}; end
    tr.cmd = rffe_transaction::rffe_cmd_e'(c);
    nbits = 7;
    if (!(c inside {rffe_transaction::RFFE_REG0_WRITE, rffe_transaction::RFFE_REG_WRITE,
                    rffe_transaction::RFFE_EXT_WRITE, rffe_transaction::RFFE_REG_READ,
                    rffe_transaction::RFFE_EXT_READ})) begin
      `uvm_warning("MON", $sformatf("illegal command code 0x%0h decoded", c))
    end
    if (tr.is_ext()) begin
      for (int i = 7; i >= 0; i--) begin sample_bit(b); tr.ext_addr[i] = b; cbits = {cbits[14:0], b}; end
      nbits = 15;
    end else if (tr.cmd != rffe_transaction::RFFE_REG0_WRITE) begin
      for (int i = 4; i >= 0; i--) begin sample_bit(b); tr.reg_addr[i] = b; cbits = {cbits[14:0], b}; end
      nbits = 12;
    end
    sample_bit(p);                                   // command parity
    if (p !== ^(cbits & ((16'd1 << nbits) - 16'd1))) tr.parity_err = 1;
    @(negedge vif.sclk_i);

    // data frame
    if (tr.is_read()) begin
      for (int i = 7; i >= 0; i--) begin sample_bit(b); tr.rdata[i] = b; end
      sample_bit(dp);
      if (dp !== ^tr.rdata) tr.parity_err = 1;
    end else begin
      for (int i = 7; i >= 0; i--) begin sample_bit(b); tr.data[i] = b; end
      sample_bit(dp);
      if (dp !== ^tr.data) tr.parity_err = 1;
    end
    @(negedge vif.sclk_i);

    // bus park: SDATA must be driven low while SCLK stays stopped
    repeat (4) @(posedge vif.sclk);
    tr.park_err = vif.sdata_i;

    txn_count++;
    `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
    ap.write(tr);
  endtask

  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.sdata_i);              // SSC pulse candidate
      if (!vif.rst_n) continue;
      if (vif.sclk_i) continue;            // SSC only while SCLK stopped
      if (vif.state != rffe_defs_pkg::SSC) continue;  // mid-frame transition
      decode_frame();
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("rffe monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
