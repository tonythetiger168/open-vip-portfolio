// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// rffe_coverage.svh -- MIPI RFFE functional coverage
// cg_protocol : command / slave address / register address / data (+ cross)
// cg_fsm      : protocol FSM states and frame-sequence transitions,
//               sampled from the interface sideband on every state change
// cg_error    : bus-park violation / parity error / injection bins

`ifndef RFFE_COVERAGE_SVH
`define RFFE_COVERAGE_SVH

class rffe_coverage extends uvm_subscriber #(rffe_transaction);
  `uvm_component_utils(rffe_coverage)

  virtual rffe_if vif;
  rffe_transaction tr;
  rffe_state_e cur_state;

  covergroup cg_protocol;
    cp_cmd : coverpoint tr.cmd {
      bins reg0_wr = {rffe_transaction::RFFE_REG0_WRITE};
      bins reg_wr  = {rffe_transaction::RFFE_REG_WRITE};
      bins ext_wr  = {rffe_transaction::RFFE_EXT_WRITE};
      bins reg_rd  = {rffe_transaction::RFFE_REG_READ};
      bins ext_rd  = {rffe_transaction::RFFE_EXT_READ};
    }
    cp_slave : coverpoint tr.slave_addr {
      bins dut    = {4'h3};
      bins others = {[4'h0 : 4'hF]};
    }
    cp_reg : coverpoint tr.reg_addr iff (!tr.is_ext() &&
                                          tr.cmd != rffe_transaction::RFFE_REG0_WRITE) {
      bins low  = {[5'h00 : 5'h0F]};
      bins high = {[5'h10 : 5'h1F]};
    }
    cp_xaddr : coverpoint tr.ext_addr iff (tr.is_ext()) {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins mid  = {[8'h01 : 8'hFE]};
    }
    cp_data : coverpoint tr.data iff (!tr.is_read()) {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins walk = {[8'h01 : 8'hFE]};
    }
    cx_cmd_slave : cross cp_cmd, cp_slave;
  endgroup

  covergroup cg_fsm with function sample(rffe_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {rffe_defs_pkg::IDLE, rffe_defs_pkg::SSC,
                           rffe_defs_pkg::COMMAND_SEQ, rffe_defs_pkg::DATA_SEQ,
                           rffe_defs_pkg::BUS_PARK};
    }
    cp_trans : coverpoint s {
      bins frame_seq = (rffe_defs_pkg::IDLE    => rffe_defs_pkg::SSC     =>
                        rffe_defs_pkg::COMMAND_SEQ);
      bins data_seq  = (rffe_defs_pkg::COMMAND_SEQ => rffe_defs_pkg::DATA_SEQ =>
                        rffe_defs_pkg::BUS_PARK);
      bins park_seq  = (rffe_defs_pkg::BUS_PARK => rffe_defs_pkg::IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_dir        : coverpoint tr.is_read()  { bins wr = {0}; bins rd = {1}; }
    cp_park_err   : coverpoint tr.park_err   { bins ok = {0}; bins violation = {1}; }
    cp_parity_err : coverpoint tr.parity_err { bins ok = {0}; bins err = {1}; }
    cx_park_dir   : cross cp_park_err, cp_dir;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual rffe_if)::get(this, "", "vif", vif));
  endfunction

  // Sample the FSM covergroup on every interface state change
  task run_phase(uvm_phase phase);
    rffe_state_e prev = rffe_defs_pkg::IDLE;
    if (vif == null) return;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n === 1'b1 && vif.mon_cb.state !== prev) begin
        cur_state = vif.mon_cb.state;
        cg_fsm.sample(cur_state);
        prev = cur_state;
      end
    end
  endtask

  function void write(rffe_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction
endclass
`endif
