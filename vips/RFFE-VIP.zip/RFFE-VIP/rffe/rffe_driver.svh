// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// rffe_driver.svh -- MIPI RFFE master driver (bit-banged)
// Frame sequence per transfer: SSC (SDATA pulse while SCLK stopped) ->
// command frame (slave addr + command + address + parity) -> data frame
// (8 bits + parity, master or slave driven) -> bus park (SDATA low).
// SCLK idles low and is only toggled inside command/data frames.

`ifndef RFFE_DRIVER_SVH
`define RFFE_DRIVER_SVH

class rffe_driver extends uvm_driver #(rffe_transaction);
  `uvm_component_utils(rffe_driver)
  virtual rffe_if vif;
  rffe_config cfg;
  uvm_analysis_port #(rffe_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual rffe_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "rffe virtual interface not set")
  endfunction

  // ---- low-level line control ----
  task drv_sdata(bit v); vif.drv_cb.sdata_o <= v; vif.drv_cb.sdata_oe <= 1; endtask
  task rel_sdata();    vif.drv_cb.sdata_oe <= 0; endtask
  task drv_sclk(bit v);  vif.drv_cb.sclk_o  <= v; vif.drv_cb.sclk_oe  <= 1; endtask

  // SSC: SDATA pulse while SCLK is stopped (low)
  task rffe_ssc();
    drv_sdata(1); repeat (4) @(vif.drv_cb);
    drv_sdata(0); repeat (2) @(vif.drv_cb);
  endtask

  // Data changes while SCLK low, sampled on the rising edge
  task send_bit(bit b);
    drv_sdata(b);
    repeat (2) @(vif.drv_cb);
    drv_sclk(1); repeat (2) @(vif.drv_cb);
    drv_sclk(0); repeat (2) @(vif.drv_cb);
  endtask

  task recv_bit(output bit b);
    repeat (2) @(vif.drv_cb);
    drv_sclk(1); repeat (2) @(vif.drv_cb);
    b = vif.drv_cb.sdata_i;
    drv_sclk(0); repeat (2) @(vif.drv_cb);
  endtask

  task send_bits(bit [15:0] v, int n);
    for (int i = n - 1; i >= 0; i--) send_bit(v[i]);
  endtask

  task drive_item(rffe_transaction tr);
    bit [15:0] cbits;
    int        nbits;
    bit        p;

    // ---- SSC ----
    vif.state = rffe_defs_pkg::SSC;
    rffe_ssc();

    // ---- command frame ----
    vif.state = rffe_defs_pkg::COMMAND_SEQ;
    if (tr.is_ext()) begin
      cbits = {tr.slave_addr, tr.cmd, tr.ext_addr};
      nbits = 15;
    end else if (tr.cmd == rffe_transaction::RFFE_REG0_WRITE) begin
      cbits = {tr.slave_addr, tr.cmd};
      nbits = 7;
    end else begin
      cbits = {tr.slave_addr, tr.cmd, tr.reg_addr};
      nbits = 12;
    end
    send_bits(cbits, nbits);
    p = ^(cbits & ((16'd1 << nbits) - 16'd1));   // even parity over cmd bits
    send_bit(p);

    // ---- data frame ----
    vif.state = rffe_defs_pkg::DATA_SEQ;
    if (!tr.is_read()) begin
      send_bits({8'h00, tr.data}, 8);
      send_bit(^tr.data);
    end else begin
      bit [7:0] d;
      rel_sdata();                               // turnaround: slave drives
      for (int i = 7; i >= 0; i--) recv_bit(d[i]);
      tr.rdata = d;
      recv_bit(p);                               // slave parity bit
    end

    // ---- bus park (master drives SDATA low; error inject drives high) ----
    vif.state = rffe_defs_pkg::BUS_PARK;
    drv_sdata(tr.inj_park);
    repeat (4) @(vif.drv_cb);
    rel_sdata();
    repeat (2) @(vif.drv_cb);
    vif.state = rffe_defs_pkg::IDLE;
    repeat (2) @(vif.drv_cb);
  endtask

  task run_phase(uvm_phase phase);
    rffe_transaction tr;
    vif.drv_cb.sdata_oe <= 0;
    vif.drv_cb.sclk_o   <= 0; vif.drv_cb.sclk_oe <= 1;   // SCLK idle low
    vif.state = rffe_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      drive_item(tr);
      drv_ap.write(tr);                        // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
