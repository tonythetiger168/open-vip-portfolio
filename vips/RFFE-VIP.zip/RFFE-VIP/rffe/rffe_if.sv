// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// rffe_if.sv -- MIPI RFFE interface
// Electrical model:
//   SCLK : master driven, idle LOW (stops during SSC and bus park)
//   SDATA: master driven (idle/parked low), slave driven during read
//          data frames; priority-mux resolution (turnaround, no contention)
// The `sclk` port is the testbench reference clock; the bus clock is the
// resolved `sclk_i`. `state` is a VIP-driven sideband of the protocol phase.

interface rffe_if (input logic sclk);
  import rffe_defs_pkg::rffe_state_e;

  logic rst_n;

  // Master drives: _o = output value, _oe = output enable, _i = sensed line
  logic sdata_o, sdata_oe, sdata_i;
  logic sclk_o,  sclk_oe,  sclk_i;

  // Slave-side drive (DUT model)
  logic slv_sdata_o, slv_sdata_oe;

  rffe_state_e state;

  // Line resolution: turnaround bus, parked low when nobody drives
  assign sdata_i = sdata_oe ? sdata_o : (slv_sdata_oe ? slv_sdata_o : 1'b0);
  assign sclk_i  = sclk_oe ? sclk_o : 1'b0;

  modport MASTER (input  sclk, rst_n, sdata_i, sclk_i,
                  output sdata_o, sdata_oe, sclk_o, sclk_oe, state);
  modport SLAVE  (input  sclk, rst_n, sdata_i, sclk_i,
                  output slv_sdata_o, slv_sdata_oe);
  modport MON    (input  sclk, rst_n, sdata_i, sclk_i, state);

  clocking drv_cb @(posedge sclk);
    input  sdata_i, sclk_i, rst_n;
    output sdata_o, sdata_oe, sclk_o, sclk_oe;
  endclocking

  clocking mon_cb @(posedge sclk);
    input rst_n, sdata_i, sclk_i, state;
  endclocking
endinterface
