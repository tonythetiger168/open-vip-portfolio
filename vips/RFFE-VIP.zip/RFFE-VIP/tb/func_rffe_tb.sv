// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_rffe_tb.sv -- self-checking functional test for the MIPI RFFE slave
// model (rffe_slave_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py RFFE-VIP
//
// Model contract (from tb/top_tb.sv):
//   Sequence Start Condition (SDATA pulse with SCLK low >= 3 system clocks),
//   then bits sampled on SCLK rising edges: SA[3:0], command[2:0]:
//   Register-0 Write (010, no address), Register Write (011, 5-bit address),
//   Extended Write (101, 8-bit address), Register Read (110, 5-bit address),
//   Extended Read (111, 8-bit address); then a parity cell and a bus-park
//   cell. Writes take data[7:0] + parity from the master; reads return
//   data[7:0] + parity (^data) driven by the slave. SLAVE_ADDR = 3; other
//   addresses are ignored. 32 registers + 256 extended registers.

module func_rffe_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [3:0] SA = 4'h3;
  localparam bit [2:0] R0W = 3'b010, RW = 3'b011, EW = 3'b101, RR = 3'b110, ER = 3'b111;
  int checks = 0, fails = 0;

  logic sys = 1'b0, rst_n = 1'b0, sclk = 1'b0, sdata = 1'b0;
  wire  sd_o, sd_oe;

  always #5 sys = ~sys;

  rffe_slave_model u_dut (
    .vif_sclk(sys), .vif_rst_n(rst_n), .vif_sdata_i(sdata), .vif_sclk_i(sclk),
    .vif_slv_sdata_o(sd_o), .vif_slv_sdata_oe(sd_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  bit s_o, s_oe;
  task automatic cyc(input bit d);
    sdata = d;
    repeat (2) @(posedge sys);
    sclk = 1'b1; #1 s_o = sd_o; s_oe = sd_oe;
    repeat (2) @(posedge sys);
    sclk = 1'b0;
  endtask

  task automatic ssc();
    @(posedge sys); sdata = 1'b1;
    repeat (2) @(posedge sys); sdata = 1'b0;
    repeat (4) @(posedge sys);
  endtask

  // command frame up to and including the bus-park cell
  task automatic hdr(input [3:0] sa, input [2:0] cmd, input [7:0] addr);
    for (int i = 3; i >= 0; i--) cyc(sa[i]);
    for (int i = 2; i >= 0; i--) cyc(cmd[i]);
    if (cmd == EW || cmd == ER) for (int i = 7; i >= 0; i--) cyc(addr[i]);
    else if (cmd != R0W)        for (int i = 4; i >= 0; i--) cyc(addr[i]);
    cyc(^{sa, cmd, addr});
  endtask

  task automatic wr(input [2:0] cmd, input [7:0] addr, input [7:0] d, input [3:0] sa = SA);
    ssc();
    hdr(sa, cmd, addr);
    for (int i = 7; i >= 0; i--) cyc(d[i]);
    cyc(^d);
    cyc(1'b0);                                 // bus park
    repeat (4) @(posedge sys);
  endtask

  logic [7:0] q;
  bit         qp, drv_ok;
  task automatic rd(input [2:0] cmd, input [7:0] addr, input [3:0] sa = SA);
    ssc();
    hdr(sa, cmd, addr);
    drv_ok = 1;
    for (int i = 7; i >= 0; i--) begin cyc(1'b0); q[i] = s_o; drv_ok &= s_oe; end
    cyc(1'b0); qp = s_o; drv_ok &= s_oe;
    cyc(1'b0);
    repeat (4) @(posedge sys);
  endtask

  initial begin
    repeat (3) @(posedge sys);
    chk(sd_oe === 1'b0, "slave does not drive SDATA after power-up");
    // a frame sent while reset is asserted is ignored
    wr(RW, 8'h06, 8'h99);
    chk(u_dut.regs[6] === 8'h00 && sd_oe === 1'b0, "frame during reset ignored");
    rst_n = 1'b1;
    repeat (3) @(posedge sys);

    wr(RW, 8'h05, 8'h3C);
    chk(u_dut.regs[5] === 8'h3C, "Register Write stores data at the 5-bit address");
    rd(RR, 8'h05);
    chk(drv_ok && q === 8'h3C, "Register Read returns the byte, slave-driven");
    chk(qp === ^8'h3C, "read data parity bit is ^data");
    chk(sd_oe === 1'b0, "slave releases SDATA after the read");

    wr(R0W, 8'h00, 8'h7F);
    rd(RR, 8'h00);
    chk(q === 8'h7F, "Register-0 Write (no address field) writes register 0");

    wr(EW, 8'hC8, 8'hA5);
    chk(u_dut.xregs[8'hC8] === 8'hA5, "Extended Write stores data at the 8-bit address");
    rd(ER, 8'hC8);
    chk(q === 8'hA5 && qp === ^8'hA5, "Extended Read returns the byte with parity");
    chk(u_dut.regs[8] === 8'h00, "extended space is separate from the register space");

    rd(RR, 8'h1F);
    chk(q === 8'h00, "unwritten register reads 0");

    wr(RW, 8'h05, 8'hEE, 4'h9);
    chk(u_dut.regs[5] === 8'h3C, "write to another slave address is ignored");
    rd(RR, 8'h05, 4'h9);
    chk(!drv_ok, "read for another slave address gets no response");

    // write after an ignored frame still lands
    wr(RW, 8'h06, 8'h11);
    rd(RR, 8'h06);
    chk(q === 8'h11, "slave resynchronises on the next start condition");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #300000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
