// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- MIPI RFFE testbench top with a functional RFFE slave DUT
// The DUT is an RF front-end slave at address 0x3 with a 32-entry primary
// register map and a 256-entry extended register map. It decodes the SSC,
// command frame and data frame, serves register/extended writes and reads,
// and releases SDATA outside read data frames.

`ifndef RFFE_TB_SV
`define RFFE_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import rffe_defs_pkg::*;
import rffe_pkg::*;
import rffe_test_pkg::*;

module top_tb;
  logic sclk = 0;
  always #5ns sclk = ~sclk;

  rffe_if vif(sclk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  rffe_slave_model #(.SLAVE_ADDR(4'h3)) dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual rffe_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional MIPI RFFE slave: SSC-qualified command decoder + register map
module rffe_slave_model #(parameter bit [3:0] SLAVE_ADDR = 4'h3)
  (rffe_if vif);

  localparam bit [2:0] REG0_WRITE = 3'b010;
  localparam bit [2:0] REG_WRITE  = 3'b011;
  localparam bit [2:0] EXT_WRITE  = 3'b101;
  localparam bit [2:0] REG_READ   = 3'b110;
  localparam bit [2:0] EXT_READ   = 3'b111;

  bit [7:0] regs  [0:31];        // primary register map (2-state, reads 0)
  bit [7:0] xregs [0:255];       // extended register map

  initial begin
    vif.slv_sdata_o  = 0;
    vif.slv_sdata_oe = 0;
  end

  task automatic recv_bit(output bit b);
    @(posedge vif.sclk_i);
    b = vif.sdata_i;
  endtask

  // Drive a read data frame: MSB during the current low phase, shift on
  // falling edges, append the parity bit, then release before bus park.
  task automatic send_byte(input bit [7:0] d);
    vif.slv_sdata_oe = 1; vif.slv_sdata_o = d[7];
    for (int i = 7; i >= 0; i--) begin
      @(posedge vif.sclk_i);
      @(negedge vif.sclk_i);
      if (i > 0) begin vif.slv_sdata_oe = 1; vif.slv_sdata_o = d[i-1]; end
    end
    vif.slv_sdata_oe = 1; vif.slv_sdata_o = ^d;      // parity bit
    @(posedge vif.sclk_i);
    @(negedge vif.sclk_i);
    vif.slv_sdata_oe = 0;
  endtask

  // Qualify a real SSC: SDATA rose while SCLK stopped AND no SCLK edge
  // follows within the pulse window (rules out mid-frame transitions)
  task automatic wait_ssc();
    bit real_ssc;
    int unsigned n;
    real_ssc = 0;
    while (!real_ssc) begin
      @(posedge vif.sdata_i);
      if (vif.rst_n && !vif.sclk_i) begin
        // quiet window (no fork/disable fork): count system clocks while
        // sclk_i stays low; a data bit (sclk_i high) rules out the SSC
        n = 0;
        while (n < 3 && vif.sclk_i === 1'b0) begin
          @(posedge vif.sclk);
          if (vif.sclk_i === 1'b0) n = n + 1;
        end
        if (n >= 3) real_ssc = 1;
      end
    end
  endtask

  initial forever begin
    bit [3:0] sa;
    bit [2:0] cmd;
    bit [4:0] addr;
    bit [7:0] xaddr, d;
    bit       b, p, is_read, is_ext;

    wait_ssc();

    // ---- command frame ----
    for (int i = 3; i >= 0; i--) recv_bit(sa[i]);
    for (int i = 2; i >= 0; i--) recv_bit(cmd[i]);
    is_read = (cmd == REG_READ || cmd == EXT_READ);
    is_ext  = (cmd == EXT_WRITE || cmd == EXT_READ);
    if (sa == SLAVE_ADDR) begin              // not for us: resync on next SSC
    if (is_ext) begin
      for (int i = 7; i >= 0; i--) recv_bit(xaddr[i]);
    end else if (cmd != REG0_WRITE) begin
      for (int i = 4; i >= 0; i--) recv_bit(addr[i]);
    end
    recv_bit(p);                             // command parity (not checked)
    @(negedge vif.sclk_i);

    // ---- data frame ----
    if (!is_read) begin
      for (int i = 7; i >= 0; i--) recv_bit(d[i]);
      recv_bit(b);                           // data parity (not checked)
      @(negedge vif.sclk_i);
      case (cmd)
        REG0_WRITE: regs[5'h00] = d;
        REG_WRITE:  regs[addr]  = d;
        EXT_WRITE:  xregs[xaddr] = d;
        default: ;
      endcase
    end else begin
      d = is_ext ? xregs[xaddr] : regs[addr];
      send_byte(d);                          // data + parity, then release
    end
    end
    // bus park is master driven; resync on next SSC
  end
endmodule
`endif
