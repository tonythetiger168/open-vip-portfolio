// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// env_pkg.sv -- MIPI RFFE verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import rffe_defs_pkg::*;
  import rffe_pkg::*;

  // End-to-end scoreboard: compares driver-issued (expected) transactions
  // against monitor-decoded (observed) transactions, including data
  // contents, parity status and bus-park violation injection.
    `uvm_analysis_imp_decl(_exp)
    `uvm_analysis_imp_decl(_obs)

  class rffe_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(rffe_scoreboard)
    uvm_analysis_imp_exp #(rffe_transaction, rffe_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(rffe_transaction, rffe_scoreboard) obs_ap;

    rffe_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(rffe_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(rffe_transaction t); obs_q.push_back(t); check(); endfunction

    function bit txn_match(rffe_transaction e, rffe_transaction o);
      if (e.slave_addr != o.slave_addr) return 0;
      if (e.cmd != o.cmd) return 0;
      if (e.inj_park != o.park_err) return 0;   // injected park error observed?
      if (o.parity_err) return 0;
      if (e.is_ext()) begin
        if (e.ext_addr != o.ext_addr) return 0;
      end else if (e.cmd != rffe_transaction::RFFE_REG0_WRITE) begin
        if (e.reg_addr != o.reg_addr) return 0;
      end
      if (e.is_read()) return e.rdata == o.rdata;
      return e.data == o.data;
    endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        rffe_transaction e = exp_q.pop_front();
        rffe_transaction o = obs_q.pop_front();
        if (txn_match(e, o)) n_matches++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("rffe scoreboard: n_matches=%0d mismatches=%0d",
                n_matches, mismatches), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class rffe_env extends uvm_env;
    `uvm_component_utils(rffe_env)
    rffe_agent      agt;
    rffe_scoreboard sb;
    rffe_checker    chk;
    rffe_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = rffe_agent::type_id::create("agt", this);
      sb  = rffe_scoreboard::type_id::create("sb", this);
      chk = rffe_checker::type_id::create("chk", this);
      cov = rffe_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
