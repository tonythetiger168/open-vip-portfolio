// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// rffe_reg_model.svh -- UVM register model of the RFFE slave in tb/top_tb.sv
// (rffe_slave_model, USID 0x3):
//   REG0..REG31 @ 0x000-0x01F  primary register map (Register Write / Read)
//   XREG        @ 0x100-0x1FF  256 x 8 extended register map (Extended Write / Read)
// Every register is 8-bit RW, reset 0 (the model's arrays are 2-state).

`ifndef RFFE_REG_MODEL_SVH
`define RFFE_REG_MODEL_SVH

class rffe_data_reg extends uvm_reg;
  `uvm_object_utils(rffe_data_reg)
  rand uvm_reg_field DATA;

  function new(string name = "rffe_data_reg");
    super.new(name, 8, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    DATA = uvm_reg_field::type_id::create("DATA");
    //            parent size lsb access volatile reset has_reset rand individually_accessible
    DATA.configure(this, 8,   0,  "RW",  0,       8'h0, 1,        1,   1);
  endfunction
endclass

class rffe_reg_block extends uvm_reg_block;
  `uvm_object_utils(rffe_reg_block)
  localparam int N_REGS  = 32;
  localparam int N_XREGS = 256;
  rand rffe_data_reg REG[N_REGS];
  uvm_mem            XREG;
  uvm_reg_map        rffe_map;

  function new(string name = "rffe_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    rffe_map = create_map("rffe_map", 'h0, 1, UVM_LITTLE_ENDIAN, 1);
    default_map = rffe_map;
    foreach (REG[i]) begin
      REG[i] = rffe_data_reg::type_id::create($sformatf("REG%0d", i));
      REG[i].configure(this, null, "");
      REG[i].build();
      rffe_map.add_reg(REG[i], i, "RW");
    end
    XREG = new("XREG", N_XREGS, 8, "RW", UVM_NO_COVERAGE);
    XREG.configure(this, "");
    rffe_map.add_mem(XREG, 'h100, "RW");
  endfunction
endclass
`endif
