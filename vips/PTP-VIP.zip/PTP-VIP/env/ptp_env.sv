// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_env.sv -- PTP environment: reference-model scoreboard, checker, coverage

package ptp_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import ptp_defs_pkg::*;
  import ptp_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class ptp_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(ptp_scoreboard)
    uvm_analysis_imp_exp #(ptp_transaction, ptp_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(ptp_transaction, ptp_scoreboard) obs_ap;

    ptp_config cfg;
    ptp_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit        mvalid = 0;
    bit [79:0] mport = 0;
    bit [7:0]  mp1 = 0, mp2 = 0;
    bit [31:0] mq = 0;
    bit [63:0] mgm = 0;
    int        xs = 0;                        // 0 idle, 1 wait Follow_Up, 2 ready, 3 wait Delay_Resp
    bit [15:0] seq_s = 0, dseq = 0, dsent = 0;
    longint    t1 = 0, t2 = 0, t3 = 0, corr_s = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(ptp_config)::get(this, "", "cfg", cfg))
        cfg = ptp_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(ptp_transaction t);
      longint tr = longint'(t.t_sec) * PTP_NS_PER_S + t.t_ns;
      longint c = longint'($signed(t.corr)) >>> 16;
      t.ok = 0; t.offset = 0; t.delay = 0; t.adj = 0;
      if (t.dir) begin
        // the DUT's Delay_Req
        if (xs != 2) t.drop = 7;                 // not expected: shows as a mismatch
        t.mtype = 4'h1; t.eth_ok = 1; t.version = 2; t.mlen = 44; t.nbytes = 58; t.dom = cfg.domain;
        t.two_step = 0; t.corr = 0; t.src_clock = PTP_OWN_ID; t.src_port = PTP_OWN_PORT; t.seq = dseq;
        t.set_ts(tr); t.req_clock = 0; t.req_port = 0; t.prio1 = 0; t.quality = 0; t.prio2 = 0;
        dsent = dseq; dseq++; t3 = tr; xs = 3;
      end else begin
        bit [79:0] src = {t.src_clock, t.src_port};
        t.drop = 0;
        if (!t.eth_ok) t.drop = 1;
        else if (t.version != 2) t.drop = 2;
        else if (t.dom != cfg.domain) t.drop = 3;
        else if (t.mlen != t.nbytes - 14 || t.mlen < ptp_minlen(t.mtype) || (ptp_has_ts(t.mtype) && t.ts_ns >= PTP_NS_PER_S))
          t.drop = 4;
        else case (t.mtype)
          4'hB:
            if (!mvalid || src == mport || {t.prio1, t.quality, t.prio2, t.src_clock} < {mp1, mq, mp2, mgm}) begin
              mvalid = 1; mport = src; mp1 = t.prio1; mq = t.quality; mp2 = t.prio2; mgm = t.src_clock;
            end
          4'h0:
            if (!mvalid || src != mport) t.drop = 5;
            else begin
              t2 = tr; seq_s = t.seq; corr_s = c;
              if (t.two_step) xs = 1;
              else begin t1 = t.ts_total() + c; xs = 2; end
            end
          4'h8:
            if (!mvalid || src != mport) t.drop = 5;
            else if (xs != 1 || t.seq != seq_s) t.drop = 6;
            else begin t1 = t.ts_total() + corr_s + c; xs = 2; end
          4'h9:
            if (!mvalid || src != mport) t.drop = 5;
            else if (xs != 3 || t.seq != dsent || t.req_clock != PTP_OWN_ID || t.req_port != PTP_OWN_PORT) t.drop = 6;
            else begin
              longint t4 = t.ts_total() - c;
              longint d = ((t2 - t1) + (t4 - t3)) >>> 1;
              longint o = (t2 - t1) - d;
              t.ok = 1; t.delay = d; t.offset = o; t.adj = -o;
              xs = 0;
            end
          default: t.drop = 7;
        endcase
      end
      t.master = mvalid ? mport[79:16] : 64'h0;
    endfunction

    function void write_exp(ptp_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(ptp_transaction t);
      ptp_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active && !(t.dir)) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        ptp_transaction e = exp_q.pop_front();
        ptp_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("ptp scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class ptp_env extends uvm_env;
    `uvm_component_utils(ptp_env)
    ptp_agent      agt;
    ptp_scoreboard sb;
    ptp_checker    chk;
    ptp_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = ptp_agent     ::type_id::create("agt", this);
      sb  = ptp_scoreboard::type_id::create("sb",  this);
      chk = ptp_checker   ::type_id::create("chk", this);
      cov = ptp_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
