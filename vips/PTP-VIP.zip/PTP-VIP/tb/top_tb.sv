// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- IEEE 1588 PTP testbench top with a functional IEEE 1588 PTP DUT model

`ifndef IEEE 1588 PTP_TB_SV
`define IEEE 1588 PTP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ptp_defs_pkg::*;
import ptp_pkg::*;
import ptp_env_pkg::*;
import ptp_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ptp_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ptp_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .event_i(vif.event_i),
    .egress_req(vif.egress_req),
    .clock_time(vif.clock_time),
    .event_ts(vif.event_ts),
    .event_valid(vif.event_valid),
    .egress_ts(vif.egress_ts),
    .egress_valid(vif.egress_valid)
  );

  // Concurrent protocol checks
  ptp_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .event_i(vif.event_i), .egress_req(vif.egress_req), .clock_time(vif.clock_time), .event_ts(vif.event_ts), .event_valid(vif.event_valid), .egress_ts(vif.egress_ts), .egress_valid(vif.egress_valid)
  );

  initial begin
    uvm_config_db#(virtual ptp_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ptp_model #(
  parameter int CLOCK_STEP_NS = 8
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        event_i,
  input  logic        egress_req,
  output logic [63:0] clock_time,
  output logic [63:0] event_ts,
  output logic        event_valid,
  output logic [63:0] egress_ts,
  output logic        egress_valid
);
  logic ev_d;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      clock_time   <= '0;
      event_ts     <= '0;
      event_valid  <= 1'b0;
      egress_ts    <= '0;
      egress_valid <= 1'b0;
      ev_d         <= 1'b0;
    end else begin
      clock_time <= clock_time + CLOCK_STEP_NS;
      ev_d       <= event_i;
      if (event_i && !ev_d) begin
        event_ts    <= clock_time;
        event_valid <= 1'b1;
      end else
        event_valid <= 1'b0;
      if (egress_req) begin
        egress_ts    <= clock_time;
        egress_valid <= 1'b1;
      end else
        egress_valid <= 1'b0;
    end
  end
endmodule
`endif
