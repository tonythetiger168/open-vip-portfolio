// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- PTP testbench top with a functional PTP DUT model

`ifndef PTP_VIP_TB_SV
`define PTP_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ptp_defs_pkg::*;
import ptp_pkg::*;
import ptp_env_pkg::*;
import ptp_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ptp_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ptp_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx_valid(vif.rx_valid),
    .rx_data(vif.rx_data),
    .rx_last(vif.rx_last),
    .domain(vif.domain),
    .clock_sec(vif.clock_sec),
    .clock_ns(vif.clock_ns),
    .rx_done(vif.rx_done),
    .rx_drop(vif.rx_drop),
    .rx_type(vif.rx_type),
    .sync_ok(vif.sync_ok),
    .offset(vif.offset),
    .delay(vif.delay),
    .master_id(vif.master_id),
    .tx_valid(vif.tx_valid),
    .tx_data(vif.tx_data),
    .tx_last(vif.tx_last)
  );

  // Concurrent protocol checks
  ptp_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx_valid(vif.rx_valid),
    .rx_data(vif.rx_data),
    .rx_last(vif.rx_last),
    .domain(vif.domain),
    .clock_sec(vif.clock_sec),
    .clock_ns(vif.clock_ns),
    .rx_done(vif.rx_done),
    .rx_drop(vif.rx_drop),
    .rx_type(vif.rx_type),
    .sync_ok(vif.sync_ok),
    .offset(vif.offset),
    .delay(vif.delay),
    .master_id(vif.master_id),
    .tx_valid(vif.tx_valid),
    .tx_data(vif.tx_data),
    .tx_last(vif.tx_last)
  );

  initial begin
    uvm_config_db#(virtual ptp_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ptp_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rx_valid,
  input  logic [7:0]  rx_data,
  input  logic        rx_last,
  input  logic [7:0]  domain,
  output logic [31:0] clock_sec,
  output logic [31:0] clock_ns,
  output logic        rx_done,
  output logic [2:0]  rx_drop,
  output logic [3:0]  rx_type,
  output logic        sync_ok,
  output logic [63:0] offset,
  output logic [63:0] delay,
  output logic [63:0] master_id,
  output logic        tx_valid,
  output logic [7:0]  tx_data,
  output logic        tx_last
);
  localparam logic [63:0] NS_PER_S = 64'd1000000000;
  localparam logic [63:0] OWN_ID   = 64'h0011_22FF_FE33_4455;
  localparam logic [15:0] OWN_PORT = 16'd1;
  localparam int          TXDLY = 4, DRLEN = 58, RBMAX = 96;
  localparam logic [2:0]  S_IDLE = 3'd0, S_WFU = 3'd1, S_RDY = 3'd2, S_TX = 3'd3, S_WDR = 3'd4;

  logic [63:0]  tns, t2_sof, t1, t2, t3, corr_s;
  logic [7:0]   rb [0:RBMAX-1];
  logic [7:0]   rcnt, nb;
  logic         proc, cap3, mvalid;
  logic [2:0]   st;
  logic [3:0]   wcnt;
  logic [6:0]   tidx;
  logic [15:0]  seq_s, dseq, dsent;
  logic [79:0]  mport;
  logic [111:0] mds;                 // {priority1, clockQuality, priority2, grandmasterIdentity}
  logic [63:0]  qs, rs;

  assign qs = tns / NS_PER_S;
  assign rs = tns % NS_PER_S;
  assign clock_sec = qs[31:0];
  assign clock_ns  = rs[31:0];
  assign master_id = mvalid ? mport[79:16] : 64'h0;

  function automatic logic [15:0] minlen(input logic [3:0] mt);
    case (mt)
      4'h0, 4'h1, 4'h8: minlen = 16'd44;
      4'h9:             minlen = 16'd54;
      4'hB:             minlen = 16'd64;
      default:          minlen = 16'd34;
    endcase
  endfunction

  function automatic logic has_ts(input logic [3:0] mt);
    has_ts = (mt == 4'h0) || (mt == 4'h1) || (mt == 4'h8) || (mt == 4'h9) || (mt == 4'hB);
  endfunction

  // byte i of the DUT's Delay_Req (originTimestamp = t3)
  function automatic logic [7:0] txb(input logic [6:0] i, input logic [15:0] sq, input logic [63:0] ts,
                                     input logic [7:0] dom);
    logic [63:0] sec, ns;
    sec = ts / NS_PER_S;
    ns  = ts % NS_PER_S;
    txb = 8'h00;
    case (i)
      7'd0:  txb = 8'h01;
      7'd1:  txb = 8'h1B;
      7'd2:  txb = 8'h19;
      7'd7:  txb = 8'h11;
      7'd8:  txb = 8'h22;
      7'd9:  txb = 8'h33;
      7'd10: txb = 8'h44;
      7'd11: txb = 8'h55;
      7'd12: txb = 8'h88;
      7'd13: txb = 8'hF7;
      7'd14: txb = 8'h01;
      7'd15: txb = 8'h02;
      7'd17: txb = 8'd44;
      7'd18: txb = dom;
      7'd44: txb = sq[15:8];
      7'd45: txb = sq[7:0];
      7'd46: txb = 8'h01;
      7'd47: txb = 8'h7F;
      default: begin
        if (i >= 7'd34 && i <= 7'd41) txb = OWN_ID[8 * (41 - i) +: 8];
        if (i == 7'd43) txb = OWN_PORT[7:0];
        if (i >= 7'd48 && i <= 7'd53) txb = sec[8 * (53 - i) +: 8];
        if (i >= 7'd54 && i <= 7'd57) txb = ns[8 * (57 - i) +: 8];
      end
    endcase
  endfunction

  // frame fields of the received message
  logic [3:0]         f_mt;
  logic [15:0]        f_len, f_sq, f_port;
  logic [63:0]        f_corr, f_rq, f_ts, f_sec, f_ns, step;
  logic [79:0]        f_src;
  logic [111:0]       f_ds;
  logic               f_eth;
  logic [2:0]         d;
  logic signed [63:0] c, t4, ms, sm, dl, o;

  always_comb begin
    f_mt   = rb[14][3:0];
    f_len  = {rb[16], rb[17]};
    f_corr = {rb[22], rb[23], rb[24], rb[25], rb[26], rb[27], rb[28], rb[29]};
    f_src  = {rb[34], rb[35], rb[36], rb[37], rb[38], rb[39], rb[40], rb[41], rb[42], rb[43]};
    f_sq   = {rb[44], rb[45]};
    f_sec  = {16'h0, rb[48], rb[49], rb[50], rb[51], rb[52], rb[53]};
    f_ns   = {32'h0, rb[54], rb[55], rb[56], rb[57]};
    f_rq   = {rb[58], rb[59], rb[60], rb[61], rb[62], rb[63], rb[64], rb[65]};
    f_port = {rb[66], rb[67]};
    f_ds   = {rb[61], rb[62], rb[63], rb[64], rb[65], rb[66], rb[67], rb[68], rb[69], rb[70], rb[71], rb[72],
              rb[73], rb[74]};
    f_eth  = ({rb[0], rb[1], rb[2], rb[3], rb[4], rb[5]} == 48'h011B_1900_0000) && ({rb[12], rb[13]} == 16'h88F7);
    f_ts   = f_sec * NS_PER_S + f_ns;
    c      = $signed(f_corr) >>> 16;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tns <= 64'h0; t2_sof <= 64'h0; t1 <= 64'h0; t2 <= 64'h0; t3 <= 64'h0; corr_s <= 64'h0;
      rcnt <= 8'h0; nb <= 8'h0; proc <= 1'b0; cap3 <= 1'b0; mvalid <= 1'b0; st <= S_IDLE; wcnt <= 4'h0;
      tidx <= 7'h0; seq_s <= 16'h0; dseq <= 16'h0; dsent <= 16'h0; mport <= 80'h0; mds <= 112'h0;
      rx_done <= 1'b0; rx_drop <= 3'h0; rx_type <= 4'h0; sync_ok <= 1'b0; offset <= 64'h0; delay <= 64'h0;
      tx_valid <= 1'b0; tx_data <= 8'h0; tx_last <= 1'b0;
    end else begin
      step = 64'd8;
      rx_done <= 1'b0;
      sync_ok <= 1'b0;

      // Delay_Req transmission, TXDLY clocks after t1 is known
      case (st)
        S_RDY:
          if (wcnt == TXDLY - 1) begin
            st <= S_TX; tidx <= 7'd1; cap3 <= 1'b1; dsent <= dseq;
            tx_valid <= 1'b1; tx_data <= txb(7'd0, dseq, tns, domain); tx_last <= 1'b0;
          end else wcnt <= wcnt + 4'd1;
        S_TX: begin
          cap3 <= 1'b0;
          if (cap3) t3 <= tns;                 // the clock while the first byte is on the wire
          if (tidx == DRLEN) begin
            tx_valid <= 1'b0; tx_data <= 8'h0; tx_last <= 1'b0; st <= S_WDR; dseq <= dseq + 16'd1;
          end else begin
            tx_data <= txb(tidx, dsent, cap3 ? tns : t3, domain);
            tx_last <= (tidx == DRLEN - 1);
            tidx <= tidx + 7'd1;
          end
        end
        default: ;
      endcase

      // receive: t2 is the clock when the first byte is sampled
      if (rx_valid) begin
        if (rcnt == 8'h0) t2_sof <= tns;
        if (rcnt < RBMAX) rb[rcnt] <= rx_data;
        rcnt <= rcnt + 8'h1;
        if (rx_last) begin nb <= rcnt + 8'h1; rcnt <= 8'h0; proc <= 1'b1; end
      end

      if (proc) begin
        proc <= 1'b0;
        d = 3'd0;
        if (!f_eth) d = 3'd1;
        else if (rb[15][3:0] != 4'd2) d = 3'd2;
        else if (rb[18] != domain) d = 3'd3;
        else if (f_len != nb - 14 || f_len < minlen(f_mt) || (has_ts(f_mt) && f_ns >= NS_PER_S)) d = 3'd4;
        else case (f_mt)
          4'hB:   // Announce: keep the best master (dataset comparison, lowest wins)
            if (!mvalid || f_src == mport || f_ds < mds) begin mvalid <= 1'b1; mport <= f_src; mds <= f_ds; end
          4'h0:   // Sync
            if (!mvalid || f_src != mport) d = 3'd5;
            else begin
              t2 <= t2_sof; seq_s <= f_sq; corr_s <= c;
              if (rb[20][1]) st <= S_WFU;
              else begin t1 <= f_ts + c; st <= S_RDY; wcnt <= 4'h0; end
            end
          4'h8:   // Follow_Up
            if (!mvalid || f_src != mport) d = 3'd5;
            else if (st != S_WFU || f_sq != seq_s) d = 3'd6;
            else begin t1 <= f_ts + corr_s + c; st <= S_RDY; wcnt <= 4'h0; end
          4'h9:   // Delay_Resp
            if (!mvalid || f_src != mport) d = 3'd5;
            else if (st != S_WDR || f_sq != dsent || f_rq != OWN_ID || f_port != OWN_PORT) d = 3'd6;
            else begin
              t4 = f_ts - c;
              ms = t2 - t1;
              sm = t4 - t3;
              dl = (ms + sm) >>> 1;
              o  = ms - dl;
              offset <= o; delay <= dl; sync_ok <= 1'b1;
              step = 64'd8 - o;
              st <= S_IDLE;
            end
          default: d = 3'd7;
        endcase
        rx_done <= 1'b1; rx_drop <= d; rx_type <= f_mt;
      end
      tns <= tns + step;
    end
  end
endmodule
`endif
