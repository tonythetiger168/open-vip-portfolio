// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (IEEE 1588 timestamp capture)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened ptp_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic event_i = 1'b0;
  logic egress_req = 1'b0;
  wire  [63:0] clock_time;
  wire  [63:0] event_ts;
  wire  event_valid;
  wire  [63:0] egress_ts;
  wire  egress_valid;

  always #5 clk = ~clk;

  ptp_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .event_i(event_i), .egress_req(egress_req),
    .clock_time(clock_time), .event_ts(event_ts),
    .event_valid(event_valid), .egress_ts(egress_ts),
    .egress_valid(egress_valid)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [63:0] t0;
  initial begin
    repeat (8) step();
    chk(clock_time === 64'h0, "clock reset to zero");
    chk(event_valid === 1'b0 && egress_valid === 1'b0, "valids quiet");
    @(negedge clk); rst_n = 1'b1;

    // clock steps by 8 each cycle
    t0 = clock_time;
    repeat (5) begin step(); chk(clock_time === t0 + 8, "clock steps by 8ns"); t0 = clock_time; end

    // event capture: timestamp equals clock at the event edge
    @(negedge clk); event_i = 1'b1;
    step();
    @(negedge clk); event_i = 1'b0;
    chk(event_valid === 1'b1, "event valid strobe");
    chk(event_ts <= clock_time, "event timestamp not in the future");
    chk(event_ts >= clock_time - 16, "event timestamp near capture point");
    step();
    chk(event_valid === 1'b0, "event strobe is a pulse");

    // egress timestamping
    @(negedge clk); egress_req = 1'b1;
    step();
    chk(egress_valid === 1'b1, "egress valid");
    chk(egress_ts <= clock_time, "egress timestamp not in the future");
    @(negedge clk); egress_req = 1'b0;
    step();
    chk(egress_valid === 1'b0, "egress strobe is a pulse");

    // clock keeps running after events
    t0 = clock_time;
    repeat (4) begin step(); chk(clock_time === t0 + 8, "clock continues stepping"); t0 = clock_time; end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
