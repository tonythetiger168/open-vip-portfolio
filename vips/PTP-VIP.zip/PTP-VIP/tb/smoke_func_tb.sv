// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (PTP DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened ptp_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic rx_valid = 1'b0, rx_last = 1'b0;
  logic [7:0] rx_data = '0, domain = '0;
  wire [31:0] clock_sec, clock_ns;
  wire rx_done, sync_ok, tx_valid, tx_last;
  wire [2:0] rx_drop;
  wire [3:0] rx_type;
  wire [63:0] offset, delay, master_id;
  wire [7:0] tx_data;

  always #5 clk = ~clk;

  ptp_model u_dut (.clk(clk), .rst_n(rst_n), .rx_valid(rx_valid), .rx_data(rx_data), .rx_last(rx_last),
                   .domain(domain), .clock_sec(clock_sec), .clock_ns(clock_ns), .rx_done(rx_done),
                   .rx_drop(rx_drop), .rx_type(rx_type), .sync_ok(sync_ok), .offset(offset), .delay(delay),
                   .master_id(master_id), .tx_valid(tx_valid), .tx_data(tx_data), .tx_last(tx_last));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  localparam longint NS = 64'd1000000000;
  localparam logic [63:0] A = 64'hA0A0_A0FF_FEA0_0001, B = 64'hB0B0_B0FF_FEB0_0002, C = 64'hC0C0_C0FF_FEC0_0003;
  localparam logic [63:0] OWN = 64'h0011_22FF_FE33_4455;

  function automatic longint tot_now();
    return longint'(clock_sec) * NS + clock_ns;
  endfunction

  // monitors, all at the falling edge: clock steps, rx results, the DUT's Delay_Req
  int tcyc = 0;
  always @(posedge clk) tcyc++;
  longint ptot = 0, lstep = 0, t3_obs = 0;
  bit pv = 0;
  int nlast = 0, nstep = 0, ndone = 0, nok = 0, ndreq = 0, txn = 0, txlen = 0, t_done = 0, t_tx = 0;
  logic [2:0] ldrop = 0;
  logic [3:0] ltype = 0;
  logic [63:0] loff = 0, ldly = 0;
  logic [7:0] txf [0:79];
  always @(negedge clk) begin
    if (!rst_n) pv = 0;
    else begin
      if (pv && tot_now() != ptot + 8) begin nstep++; lstep = tot_now() - ptot - 8; end
      ptot = tot_now(); pv = 1;
      if (rx_done) begin ndone++; ldrop = rx_drop; ltype = rx_type; t_done = tcyc; end
      if (sync_ok) begin nok++; loff = offset; ldly = delay; end
      if (tx_last && !tx_valid) nlast++;
      if (tx_valid) begin
        if (txn == 0) begin t3_obs = tot_now(); t_tx = tcyc; end
        if (txn < 80) txf[txn] = tx_data;
        txn++;
        if (tx_last) begin ndreq++; txlen = txn; txn = 0; end
      end
    end
  end

  task automatic idle(input int n);
    repeat (n) @(negedge clk);
    #1;
  endtask

  // frame under construction
  logic [7:0] fb [0:99];
  int fn;
  logic [7:0] dom = 0;
  task automatic put(input int at, input int n, input logic [79:0] v);
    for (int i = 0; i < n; i++) fb[at + i] = v[8 * (n - 1 - i) +: 8];
  endtask
  function automatic int minlen(input logic [3:0] mt);
    case (mt)
      4'h0, 4'h1, 4'h8: return 44;
      4'h9:             return 54;
      4'hB:             return 64;
      default:          return 34;
    endcase
  endfunction
  task automatic set_ts(input longint t);
    put(48, 6, t / NS);
    put(54, 4, t % NS);
  endtask
  task automatic build(input logic [3:0] mt, input logic [63:0] src, input logic [15:0] port, input logic [15:0] sq,
                       input logic [63:0] corr, input bit two);
    for (int i = 0; i < 100; i++) fb[i] = 8'h00;
    fn = 14 + minlen(mt);
    put(0, 6, 48'h011B_1900_0000); put(6, 6, 48'hA0A1_A2A3_A4A5); put(12, 2, 16'h88F7);
    fb[14] = {4'h0, mt}; fb[15] = 8'h02; put(16, 2, minlen(mt)); fb[18] = dom; fb[20] = {6'b0, two, 1'b0};
    put(22, 8, corr); put(34, 8, src); put(42, 2, port); put(44, 2, sq);
  endtask
  task automatic ann(input logic [63:0] src, input logic [15:0] port, input logic [7:0] p1, input logic [31:0] q,
                     input logic [7:0] p2, input logic [63:0] gm);
    build(4'hB, src, port, 16'h0, 64'h0, 1'b0);
    fb[61] = p1; put(62, 4, q); fb[66] = p2; put(67, 8, gm);
  endtask

  // send fb[0:fn-1]; with patch the timestamp becomes (clock at the first byte) + pdelta
  bit patch = 0;
  longint pdelta = 0, t2_obs = 0;
  task automatic send();
    for (int i = 0; i < fn; i++) begin
      @(negedge clk);
      rx_valid = 1; rx_data = fb[i]; rx_last = (i == fn - 1);
      if (i == 0) begin
        t2_obs = tot_now();
        if (patch) begin set_ts(t2_obs + pdelta); patch = 0; end
      end
    end
    @(negedge clk); rx_valid = 0; rx_last = 0; rx_data = 0;
    @(negedge clk); #1;
  endtask

  int n0, nq0;
  task automatic rx(input logic [2:0] dexp, input string msg);
    n0 = ndone; nq0 = ndreq;
    send();
    chk(ndone == n0 + 1 && ldrop == dexp && ltype == fb[14][3:0],
        $sformatf("%s: drop %0d (got %0d, %0d done)", msg, dexp, ldrop, ndone - n0));
  endtask

  // wait for the DUT's Delay_Req after the last frame sent
  task automatic wait_dreq();
    for (int i = 0; i < 100 && ndreq == nq0; i++) @(negedge clk);
    #1;
  endtask

  // one-step Sync whose t2 - t1 is o + dly; Delay_Resp whose t4 - t3 is dly - o
  task automatic sync1(input logic [63:0] src, input logic [15:0] sq, input longint o, input longint dly,
                       input logic [63:0] corr);
    build(4'h0, src, 16'd1, sq, corr, 1'b0);
    patch = 1; pdelta = -(o + dly) - ($signed(corr) >>> 16);
  endtask
  task automatic dresp(input logic [63:0] src, input logic [15:0] sq, input longint o, input longint dly,
                       input logic [63:0] corr);
    build(4'h9, src, 16'd1, sq, corr, 1'b0);
    set_ts(t3_obs - o + dly + ($signed(corr) >>> 16));
    put(58, 8, OWN); put(66, 2, 16'd1);
  endtask

  int ns0;
  longint t2_a;
  initial begin
    idle(3);
    chk(clock_sec == 0 && clock_ns == 0 && !rx_done && !tx_valid && !sync_ok && master_id == 0, "reset values");
    rst_n = 1;
    idle(5);
    chk(nstep == 0 && tot_now() == 40, $sformatf("free-running clock 8 ns per cycle (%0d)", tot_now()));

    // no master selected: everything from A is dropped as not from the master
    sync1(A, 16'd1, 0, 0, 0); rx(5, "Sync before any Announce");
    build(4'h8, A, 16'd1, 16'd1, 0, 0); rx(5, "Follow_Up before any Announce");
    dresp(A, 16'd0, 0, 0, 0); rx(5, "Delay_Resp before any Announce");
    chk(master_id == 0 && ndreq == 0 && nstep == 0, "nothing selected, nothing sent");

    // best master selection
    ann(A, 16'd1, 8'd128, 32'hF8FE_FFFF, 8'd128, A); rx(0, "Announce A");
    chk(master_id == A, "A selected");
    ann(B, 16'd1, 8'd129, 32'h06FE_FFFF, 8'd1, B); rx(0, "Announce B, priority1 129");
    chk(master_id == A, "worse priority1: A kept");
    ann(B, 16'd1, 8'd128, 32'hF8FE_FFFE, 8'd255, B); rx(0, "Announce B, better clockQuality");
    chk(master_id == B, "better clockQuality: B selected");
    ann(A, 16'd1, 8'd128, 32'hF8FE_FFFE, 8'd254, A); rx(0, "Announce A, better priority2");
    chk(master_id == A, "better priority2: A selected");
    ann(C, 16'd1, 8'd128, 32'hF8FE_FFFE, 8'd254, 64'h0); rx(0, "Announce C, lower grandmasterIdentity");
    chk(master_id == C, "identity tie-break: C selected");
    ann(C, 16'd1, 8'd200, 32'hF8FE_FFFF, 8'd255, C); rx(0, "Announce C again, worse dataset");
    chk(master_id == C, "the master's own Announce updates its dataset");
    ann(A, 16'd1, 8'd199, 32'hF8FE_FFFF, 8'd255, C); rx(0, "Announce A, now better than C");
    chk(master_id == A, "A selected over C's new dataset");
    ann(A, 16'd2, 8'd199, 32'hF8FE_FFFF, 8'd255, C); rx(0, "Announce from A port 2, equal dataset");
    sync1(A, 16'd7, 0, 0, 0); fb[43] = 8'd2; rx(5, "Sync from A port 2");
    chk(nstep == 0 && ndreq == 0, "equal dataset from another port: master port kept");

    // one-step Sync, Delay_Req, Delay_Resp: slave 1 ms behind, 48 ns link
    nq0 = ndreq;
    sync1(A, 16'd7, -50000000, 48, 0); rx(0, "one-step Sync");
    t2_a = t2_obs;
    idle(2);
    chk(ndreq == nq0, "no Delay_Req before the delay");
    wait_dreq();
    chk(ndreq == nq0 + 1 && t_tx - t_done == 4, $sformatf("Delay_Req 4 clocks after the Sync (%0d)", t_tx - t_done));
    chk(txlen == 58, $sformatf("Delay_Req is 58 bytes (%0d)", txlen));
    chk({txf[0], txf[1], txf[2], txf[3], txf[4], txf[5]} == 48'h011B_1900_0000 &&
        {txf[6], txf[7], txf[8], txf[9], txf[10], txf[11]} == 48'h0011_2233_4455 && {txf[12], txf[13]} == 16'h88F7,
        "Delay_Req Ethernet header");
    chk(txf[14] == 8'h01 && txf[15] == 8'h02 && {txf[16], txf[17]} == 16'd44 && txf[18] == 8'h00 &&
        txf[20] == 0 && txf[46] == 8'h01 && txf[47] == 8'h7F, "Delay_Req message header");
    chk({txf[22], txf[23], txf[24], txf[25], txf[26], txf[27], txf[28], txf[29]} == 0, "Delay_Req correction 0");
    chk({txf[34], txf[35], txf[36], txf[37], txf[38], txf[39], txf[40], txf[41], txf[42], txf[43]} == {OWN, 16'd1},
        "Delay_Req sourcePortIdentity");
    chk({txf[44], txf[45]} == 16'd0, "first Delay_Req sequenceId 0");
    chk({txf[48], txf[49], txf[50], txf[51], txf[52], txf[53]} == t3_obs / NS &&
        {txf[54], txf[55], txf[56], txf[57]} == t3_obs % NS, $sformatf("originTimestamp = t3 (%0d)", t3_obs));
    chk(txf[19] == 0 && txf[21] == 0 && {txf[30], txf[31], txf[32], txf[33]} == 0, "reserved bytes zero");
    ns0 = nstep;
    dresp(A, 16'd0, -50000000, 48, 0); rx(0, "Delay_Resp");
    chk(nok == 1 && $signed(loff) == -50000000 && ldly == 48, $sformatf("offset -50 ms, delay 48 (%0d, %0d)",
        $signed(loff), ldly));
    chk(nstep == ns0 + 1 && lstep == 50000000, $sformatf("clock stepped +50 ms (%0d)", lstep));
    dresp(A, 16'd0, 0, 48, 0); rx(6, "second Delay_Resp for the same request");

    // two-step Sync, corrections everywhere, slave 5 us ahead, 100 ns link
    nq0 = ndreq;
    build(4'h0, A, 16'd1, 16'd8, 64'h0003_0000, 1'b1); set_ts(0); rx(0, "two-step Sync");
    t2_a = t2_obs;
    idle(10);
    chk(ndreq == nq0, "two-step: no Delay_Req before the Follow_Up");
    build(4'h8, A, 16'd1, 16'd9, 64'h0, 1'b0); set_ts(t2_a); rx(6, "Follow_Up, wrong sequenceId");
    build(4'h8, B, 16'd1, 16'd8, 64'h0, 1'b0); set_ts(t2_a); rx(5, "Follow_Up from another clock");
    build(4'h8, A, 16'd1, 16'd8, 64'h0002_0000, 1'b0); set_ts(t2_a - 5000 - 100 - 3 - 2); rx(0, "Follow_Up");
    wait_dreq();
    chk(ndreq == nq0 + 1 && {txf[44], txf[45]} == 16'd1, "second Delay_Req sequenceId 1");
    chk({txf[48], txf[49], txf[50], txf[51], txf[52], txf[53]} == t3_obs / NS &&
        {txf[54], txf[55], txf[56], txf[57]} == t3_obs % NS && txf[54] != 0,
        $sformatf("originTimestamp = t3 after the step (%0d)", t3_obs));
    build(4'h8, A, 16'd1, 16'd8, 64'h0, 1'b0); set_ts(t2_a); rx(6, "Follow_Up after the Delay_Req");
    dresp(A, 16'd0, 5000, 100, 64'h0007_0000); rx(6, "Delay_Resp, old sequenceId");
    dresp(A, 16'd1, 5000, 100, 64'h0007_0000); put(58, 8, OWN ^ 1); rx(6, "Delay_Resp, other requesting clock");
    dresp(A, 16'd1, 5000, 100, 64'h0007_0000); put(66, 2, 16'd2); rx(6, "Delay_Resp, other requesting port");
    dresp(A, 16'd1, 5000, 100, 64'h0007_0000); put(42, 2, 16'd3); rx(5, "Delay_Resp from another port");
    ns0 = nstep;
    dresp(A, 16'd1, 5000, 100, 64'h0007_0000); rx(0, "Delay_Resp, two-step");
    chk(nok == 2 && $signed(loff) == 5000 && ldly == 100, $sformatf("offset +5 us, delay 100 (%0d, %0d)",
        $signed(loff), ldly));
    chk(nstep == ns0 + 1 && lstep == -5000, $sformatf("clock stepped -5 us (%0d)", lstep));

    // asymmetric path: t2 - t1 = 300, t4 - t3 = 100
    nq0 = ndreq;
    sync1(A, 16'd9, 100, 200, 64'h0001_0000); rx(0, "one-step Sync with correction");
    wait_dreq();
    chk({txf[44], txf[45]} == 16'd2, "third Delay_Req sequenceId 2");
    dresp(A, 16'd2, 100, 200, 0); rx(0, "Delay_Resp");
    chk($signed(loff) == 100 && ldly == 200, $sformatf("offset 100, delay 200 (%0d, %0d)", $signed(loff), ldly));
    // odd sum: the mean path delay rounds down
    nq0 = ndreq;
    sync1(A, 16'd10, 0, 7, 0); rx(0, "Sync");
    wait_dreq();
    dresp(A, 16'd3, 0, 8, 0); rx(0, "Delay_Resp");
    chk(ldly == 7 && $signed(loff) == 0, $sformatf("delay (7 + 8) / 2 = 7, offset 0 (%0d, %0d)", ldly, $signed(loff)));

    // a new Sync while waiting for the Delay_Resp restarts the exchange
    nq0 = ndreq;
    sync1(A, 16'd11, 0, 10, 0); rx(0, "Sync");
    wait_dreq();
    sync1(A, 16'd12, 0, 20, 0); rx(0, "Sync again");
    nq0 = ndreq; wait_dreq();
    dresp(A, 16'd4, 0, 20, 0); rx(6, "Delay_Resp for the first Delay_Req");
    dresp(A, 16'd5, 0, 20, 0); rx(0, "Delay_Resp for the second");
    chk(ldly == 20, $sformatf("delay of the second exchange (%0d)", ldly));

    // header checks, in priority order
    sync1(A, 16'd13, 0, 0, 0); fb[0] = 8'h03; rx(1, "multicast address byte 0");
    sync1(A, 16'd13, 0, 0, 0); fb[1] = 8'h80; rx(1, "multicast address byte 1");
    sync1(A, 16'd13, 0, 0, 0); fb[2] = 8'h18; rx(1, "multicast address byte 2");
    sync1(A, 16'd13, 0, 0, 0); fb[5] = 8'h0E; rx(1, "multicast address byte 5");
    sync1(A, 16'd13, 0, 0, 0); fb[12] = 8'h08; rx(1, "EtherType high byte");
    sync1(A, 16'd13, 0, 0, 0); fb[13] = 8'hF6; rx(1, "EtherType low byte");
    sync1(A, 16'd13, 0, 0, 0); fb[12] = 8'h08; fb[15] = 8'h01; rx(1, "bad EtherType before the version");
    sync1(A, 16'd13, 0, 0, 0); fb[15] = 8'h01; rx(2, "PTP version 1");
    sync1(A, 16'd13, 0, 0, 0); fb[15] = 8'h03; rx(2, "PTP version 3");
    sync1(A, 16'd13, 0, 0, 0); fb[15] = 8'h12; rx(0, "minorVersionPTP 1 accepted");
    wait_dreq();
    sync1(A, 16'd13, 0, 0, 0); fb[15] = 8'h01; fb[18] = 8'h01; rx(2, "version before the domain");
    sync1(A, 16'd13, 0, 0, 0); fb[18] = 8'h01; rx(3, "domain 1 on a domain-0 clock");
    sync1(A, 16'd13, 0, 0, 0); fb[18] = 8'h01; put(16, 2, 16'd40); rx(3, "domain before the length");
    sync1(A, 16'd13, 0, 0, 0); put(16, 2, 16'd45); rx(4, "messageLength above the frame");
    sync1(A, 16'd13, 0, 0, 0); put(16, 2, 16'd43); rx(4, "messageLength below the frame");
    sync1(A, 16'd13, 0, 0, 0); put(16, 2, 16'd42); fn = 56; rx(4, "Sync shorter than 44");
    sync1(A, 16'd13, 0, 0, 0); put(16, 2, 16'd45); fn = 59; rx(0, "Sync with a trailing byte");
    wait_dreq();
    sync1(A, 16'd13, 0, 0, 0); put(16, 2, 16'd86); fn = 100; for (int i = 58; i < 100; i++) fb[i] = 8'hEE;
    rx(0, "100-byte Sync: bytes past the buffer ignored");
    wait_dreq();
    dresp(A, 16'd0, 0, 0, 0); put(16, 2, 16'd52); fn = 66; rx(4, "Delay_Resp shorter than 54");
    ann(A, 16'd1, 8'd1, 32'h0, 8'd1, A); put(16, 2, 16'd62); fn = 76; rx(4, "Announce shorter than 64");
    build(4'h0, A, 16'd1, 16'd13, 0, 0); put(48, 6, 48'd5); put(54, 4, 32'd1000000000); rx(4, "nanoseconds 10^9");
    build(4'h0, A, 16'd1, 16'd13, 0, 0); put(48, 6, 48'd5); put(54, 4, 32'd999999999); rx(0, "nanoseconds 10^9 - 1");
    wait_dreq();
    build(4'h8, A, 16'd1, 16'd13, 0, 0); put(54, 4, 32'hFFFF_FFFF); rx(4, "Follow_Up nanoseconds overflow");
    build(4'h9, A, 16'd1, 16'd13, 0, 0); put(54, 4, 32'hFFFF_FFFF); rx(4, "Delay_Resp nanoseconds overflow");
    ann(A, 16'd1, 8'd1, 32'h0, 8'd1, A); put(54, 4, 32'hFFFF_FFFF); rx(4, "Announce nanoseconds overflow");
    build(4'h1, A, 16'd1, 16'd13, 0, 0); put(54, 4, 32'hFFFF_FFFF); rx(4, "Delay_Req nanoseconds overflow");
    build(4'hC, A, 16'd1, 16'd13, 0, 0); put(16, 2, 16'd34); fn = 48; rx(7, "Signaling: unsupported");
    build(4'hC, A, 16'd1, 16'd13, 0, 0); put(16, 2, 16'd33); fn = 47; rx(4, "Signaling shorter than 34");
    build(4'h2, A, 16'd1, 16'd13, 0, 0); put(16, 2, 16'd44); fn = 58; put(54, 4, 32'hFFFF_FFFF);
    rx(7, "Pdelay_Req: unsupported, no timestamp check");
    build(4'h1, A, 16'd1, 16'd13, 0, 0); rx(7, "Delay_Req received: unsupported");
    build(4'h0, A, 16'd1, 16'd13, 0, 0); fb[14] = 8'h10; rx(0, "majorSdoId ignored");
    wait_dreq();

    // domain input
    dom = 8'd5; domain = 8'd5; idle(1);
    sync1(A, 16'd14, 0, 0, 0); fb[18] = 8'd0; rx(3, "domain-0 Sync on a domain-5 clock");
    ann(A, 16'd1, 8'd1, 32'h0, 8'd1, A); fb[18] = 8'd0; rx(3, "domain-0 Announce on a domain-5 clock");
    sync1(A, 16'd14, 0, 0, 0); fb[18] = 8'd5; rx(0, "domain 5 Sync accepted");
    wait_dreq();
    chk(txf[18] == 8'd5, "Delay_Req carries domainNumber 5");
    dom = 8'd0; domain = 8'd0; idle(1);

    // reset clears the master, the exchange and the clock
    rst_n = 0; idle(2);
    chk(master_id == 0 && clock_sec == 0 && clock_ns == 0 && !tx_valid, "reset clears the clock and the master");
    rst_n = 1; idle(2);
    sync1(A, 16'd1, 0, 0, 0); rx(5, "after reset no master is selected");
    ann(A, 16'd1, 8'd128, 32'h0, 8'd128, A); rx(0, "Announce A");
    nq0 = ndreq;
    sync1(A, 16'd1, 0, 0, 0); rx(0, "Sync");
    wait_dreq();
    chk({txf[44], txf[45]} == 16'd0, "Delay_Req sequenceId restarts at 0");
    dresp(A, 16'd0, 0, 0, 0); rx(0, "Delay_Resp with no delay");
    chk(ldly == 0 && loff == 0, "zero offset, zero delay");

    chk(nlast == 0, $sformatf("tx_last only with tx_valid (%0d)", nlast));
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
