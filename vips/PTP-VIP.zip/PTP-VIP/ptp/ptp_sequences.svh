// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_sequences.svh -- PTP sequences

// Random traffic: cfg.num_items constrained-random items.
class ptp_base_sequence extends uvm_sequence #(ptp_transaction);
  `uvm_object_utils(ptp_base_sequence)
  ptp_config cfg;

  function new(string name = "ptp_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ptp_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ptp_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ptp_directed_sequence extends uvm_sequence #(ptp_transaction);
  `uvm_object_utils(ptp_directed_sequence)
  ptp_config cfg;

  function new(string name = "ptp_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ptp_transaction item();
    item = ptp_transaction::type_id::create("req");
  endfunction

  task send(ptp_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ptp_transaction t;
    t = item(); t.egress = 0; t.width = 1; send(t);
    t = item(); t.egress = 0; t.width = 6; send(t);   // long pulse: one timestamp
    t = item(); t.egress = 1; send(t);
    t = item(); t.egress = 1; send(t);
    t = item(); t.egress = 0; t.width = 2; send(t);
  endtask
endclass
