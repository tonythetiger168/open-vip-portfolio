// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_sequences.svh -- PTP sequences

// Random traffic: cfg.num_items constrained-random items.
class ptp_base_sequence extends uvm_sequence #(ptp_transaction);
  `uvm_object_utils(ptp_base_sequence)
  ptp_config cfg;

  function new(string name = "ptp_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ptp_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ptp_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ptp_directed_sequence extends uvm_sequence #(ptp_transaction);
  `uvm_object_utils(ptp_directed_sequence)
  ptp_config cfg;

  function new(string name = "ptp_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ptp_transaction item();
    item = ptp_transaction::type_id::create("req");
  endfunction

  task send(ptp_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ptp_transaction t;
    // no master yet: Sync dropped; Announce from A selects it
    t = item(); t.mtype = 4'h0; t.src_clock = PTP_MASTER_A; send(t);
    t = item(); t.mtype = 4'hB; t.src_clock = PTP_MASTER_A; t.prio1 = 128; t.quality = 32'hF8FE_FFFF; t.prio2 = 128; send(t);
    // one-step and two-step exchanges, with and without corrections and master time steps
    for (int k = 0; k < 6; k++) begin
      t = item(); t.mtype = 4'h0; t.src_clock = PTP_MASTER_A; t.two_step = k[0]; t.corr = k[1] ? 64'h40_0000 : 0;
      t.jump = (k == 2) ? 16'd800 : (k == 4) ? 16'd8 : 0; send(t);
      if (k[0]) begin t = item(); t.mtype = 4'h8; t.src_clock = PTP_MASTER_A; t.corr = k[2] ? 64'h18_0000 : 0; send(t); end
      t = item(); t.mtype = 4'h9; t.src_clock = PTP_MASTER_A; t.corr = (k == 3) ? 64'h20_0000 : 0; send(t);
    end
    // every injected error on every message type it applies to
    for (int i = 1; i <= 8; i++) begin
      t = item(); t.mtype = 4'h0; t.src_clock = PTP_MASTER_A; t.two_step = 1;
      t.inj = (i inside {7, 8}) ? PTP_NONE : ptp_inj_e'(i); send(t);
      t = item(); t.mtype = 4'h8; t.src_clock = PTP_MASTER_A; t.inj = (i == 8) ? PTP_NONE : ptp_inj_e'(i); send(t);
      t = item(); t.mtype = 4'h9; t.src_clock = PTP_MASTER_A; t.inj = ptp_inj_e'(i); send(t);
    end
    // header errors on Announce and Signaling
    for (int i = 1; i <= 5; i++) begin
      t = item(); t.mtype = 4'hB; t.src_clock = PTP_MASTER_B; t.prio1 = 255; t.inj = ptp_inj_e'(i); send(t);
      if (i != 5) begin t = item(); t.mtype = 4'hC; t.src_clock = PTP_MASTER_A; t.inj = ptp_inj_e'(i); send(t); end
    end
    t = item(); t.mtype = 4'hC; t.src_clock = PTP_MASTER_A; send(t);                 // signaling: unsupported
    t = item(); t.mtype = 4'h8; t.src_clock = PTP_MASTER_A; send(t);                 // Follow_Up without a Sync
    // a worse Announce from B changes nothing, a better one takes over
    t = item(); t.mtype = 4'hB; t.src_clock = PTP_MASTER_B; t.prio1 = 200; t.quality = 32'hF8FE_FFFF; t.prio2 = 128; send(t);
    t = item(); t.mtype = 4'hB; t.src_clock = PTP_MASTER_B; t.prio1 = 64; t.quality = 32'h06FE_FFFF; t.prio2 = 128; send(t);
    t = item(); t.mtype = 4'h0; t.src_clock = PTP_MASTER_A; send(t);                 // A is no longer the master
    t = item(); t.mtype = 4'h0; t.src_clock = PTP_MASTER_B; t.jump = 16'd4000; send(t);
    t = item(); t.mtype = 4'h9; t.src_clock = PTP_MASTER_B; send(t);
    // a new Sync restarts an exchange waiting for its Delay_Resp
    t = item(); t.mtype = 4'h0; t.src_clock = PTP_MASTER_B; send(t);
    t = item(); t.mtype = 4'h0; t.src_clock = PTP_MASTER_B; send(t);
    t = item(); t.mtype = 4'h9; t.src_clock = PTP_MASTER_B; send(t);                 // answers the first Delay_Req: dropped
    t = item(); t.mtype = 4'h9; t.src_clock = PTP_MASTER_B; send(t);
    // back to A for the random traffic
    t = item(); t.mtype = 4'hB; t.src_clock = PTP_MASTER_A; t.prio1 = 1; t.quality = 32'h06FE_FFFF; t.prio2 = 1; send(t);
  endtask
endclass
