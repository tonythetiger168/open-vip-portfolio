// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_coverage.svh -- PTP functional coverage

class ptp_coverage extends uvm_subscriber #(ptp_transaction);
  `uvm_component_utils(ptp_coverage)
  ptp_config cfg;
  ptp_transaction tr;

  covergroup ptp_cg;
    cp_type  : coverpoint tr.mtype iff (!tr.dir) { bins sync = {4'h0}; bins fu = {4'h8}; bins dresp = {4'h9};
                                                   bins ann = {4'hB}; bins other = {4'hC}; }
    cp_two   : coverpoint tr.two_step iff (!tr.dir && tr.mtype == 4'h0);
    cp_drop  : coverpoint tr.drop iff (!tr.dir);
    cp_corr  : coverpoint (tr.corr != 0) iff (!tr.dir);
    cp_ok    : coverpoint tr.ok iff (!tr.dir && tr.mtype == 4'h9);
    cp_off   : coverpoint tr.offset iff (tr.ok) { bins zero = {0}; bins pos = {[1:64'h7FFF_FFFF_FFFF_FFFF]};
                                                  bins neg = {[64'h8000_0000_0000_0000:$]}; }
    cp_dreq  : coverpoint tr.dir;
    cp_master: coverpoint tr.master { bins none = {0}; bins a = {PTP_MASTER_A}; bins b = {PTP_MASTER_B}; }
    // drop codes reachable for each message type (iff per type: Verilator counts ignore_bins of a cross)
    cp_drop_sync : coverpoint tr.drop iff (!tr.dir && tr.mtype == 4'h0) { bins d[] = {[0:5]}; }
    cp_drop_fu   : coverpoint tr.drop iff (!tr.dir && tr.mtype == 4'h8) { bins d[] = {[0:6]}; }
    cp_drop_dr   : coverpoint tr.drop iff (!tr.dir && tr.mtype == 4'h9) { bins d[] = {[0:6]}; }
    cp_drop_ann  : coverpoint tr.drop iff (!tr.dir && tr.mtype == 4'hB) { bins d[] = {[0:4]}; }
    cp_drop_oth  : coverpoint tr.drop iff (!tr.dir && tr.mtype == 4'hC) { bins d[] = {[1:4], 7}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ptp_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ptp_config)::get(this, "", "cfg", cfg))
      cfg = ptp_config::type_id::create("cfg");
  endfunction

  function void write(ptp_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ptp_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("PTP coverage: %0.1f%%", ptp_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
