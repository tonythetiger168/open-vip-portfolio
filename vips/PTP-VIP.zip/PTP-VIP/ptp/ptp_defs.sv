// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_defs.sv -- PTP shared type definitions

package ptp_defs_pkg;

  typedef enum bit [1:0] {PTP_OK, PTP_ERR} ptp_status_e;

  localparam longint     PTP_NS_PER_S = 64'd1_000_000_000;
  localparam bit [63:0]  PTP_OWN_ID   = 64'h0011_22FF_FE33_4455;   // the DUT's clockIdentity
  localparam bit [15:0]  PTP_OWN_PORT = 16'd1;
  localparam bit [47:0]  PTP_DA       = 48'h011B_1900_0000;       // Annex F multicast address
  localparam bit [63:0]  PTP_MASTER_A = 64'hA0A0_A0FF_FEA0_0001;   // the agent's master clocks
  localparam bit [63:0]  PTP_MASTER_B = 64'hB0B0_B0FF_FEB0_0002;

  typedef enum bit [3:0] {PTP_NONE, PTP_BAD_ETH, PTP_BAD_VER, PTP_BAD_DOM, PTP_BAD_LEN, PTP_BAD_NS,
                          PTP_NOT_MASTER, PTP_BAD_SEQ, PTP_BAD_PORT} ptp_inj_e;

  // minimum messageLength per messageType
  function automatic int unsigned ptp_minlen(bit [3:0] mt);
    case (mt)
      4'h0, 4'h1, 4'h8: return 44;
      4'h9:             return 54;
      4'hB:             return 64;
      default:          return 34;
    endcase
  endfunction

  function automatic bit ptp_has_ts(bit [3:0] mt);
    return mt inside {4'h0, 4'h1, 4'h8, 4'h9, 4'hB};
  endfunction

endpackage
