// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_driver.svh -- IEEE 1588 PTP driver: reset, then per-item protocol stimulus

class ptp_driver extends uvm_driver #(ptp_transaction);
  `uvm_component_utils(ptp_driver)

  uvm_analysis_port #(ptp_transaction) ap;  // expected-item stream to scoreboard
  int unsigned item_cnt = 0;

  virtual ptp_if vif;
  ptp_config cfg;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction


  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ptp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ptp: virtual interface not set")
    void'(uvm_config_db#(ptp_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_item(ptp_transaction item);
    item.tag = item_cnt++;
    vif.event_i <= item.event_i;
    vif.egress_req <= item.egress_req;
    @(vif.drv_cb);
    ap.write(item);
  endtask
endclass
