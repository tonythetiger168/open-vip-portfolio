// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_driver.svh -- PTP driver: one PTP frame per item, with the timestamps of the agent's master time base; Delay_Resp answers the DUT's last Delay_Req

class ptp_driver extends uvm_driver #(ptp_transaction);
  `uvm_component_utils(ptp_driver)

  uvm_analysis_port #(ptp_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ptp_if vif;
  ptp_config cfg;

  realtime     t0 = 0, per = 0;         // master time base: clock edges counted from t0
  longint      m_off;                   // master time = 8 ns x cycle + m_off
  bit [79:0]   last_src = 0;            // last Delay_Req answered
  bit [15:0]   last_seq = 0;
  longint      last_mt = 0;
  bit [15:0]   sync_seq = 0;
  bit [15:0]   last_sync_seq = 0;
  longint      last_t1 = 0, last_corr = 0;
  // Delay_Req frames seen on tx: sequenceId, sender, master time
  bit [15:0]   dq_seq[$];
  bit [79:0]   dq_src[$];
  longint      dq_mt[$];         // master time of the first byte

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ptp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ptp: virtual interface not set")
    if (!uvm_config_db#(ptp_config)::get(this, "", "cfg", cfg))
      cfg = ptp_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ptp_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      begin   // one process: fork would run each statement in parallel
      bit [7:0] b[$];
      int unsigned c0;
      m_off = cfg.master_offset_ns;
      @(vif.drv_cb); t0 = $realtime;
      @(vif.drv_cb); per = $realtime - t0;
      forever begin
        @(vif.drv_cb);
        if (vif.drv_cb.tx_valid === 1'b1) begin
          c0 = cyc_now();
          b.delete();
          b.push_back(vif.drv_cb.tx_data);
          while (vif.drv_cb.tx_last !== 1'b1) begin
            @(vif.drv_cb);
            if (vif.drv_cb.tx_valid === 1'b1) b.push_back(vif.drv_cb.tx_data);
          end
          if (b.size() >= 46) begin
            dq_seq.push_back({b[44], b[45]});
            dq_src.push_back({b[34], b[35], b[36], b[37], b[38], b[39], b[40], b[41], b[42], b[43]});
            dq_mt.push_back(longint'(c0 - 1) * 8 + m_off);   // the DUT drove the first byte one edge earlier
          end
        end
      end
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.rx_valid <= 1'b0; vif.drv_cb.rx_data <= '0; vif.drv_cb.rx_last <= 1'b0;
    vif.drv_cb.domain <= cfg.domain;
  endtask

  task drive_item(ptp_transaction t);
    bit [7:0] f[$];
    longint c, now;
    // never overlap a Delay_Req the DUT is about to send or is sending
    repeat (12) @(vif.drv_cb);
    while (vif.drv_cb.tx_valid === 1'b1) @(vif.drv_cb);
    repeat (t.gap) @(vif.drv_cb);
    c = longint'($signed(t.corr)) >>> 16;
    t.dir = 0; t.eth_ok = (t.inj != PTP_BAD_ETH); t.version = (t.inj == PTP_BAD_VER) ? 4'd1 : 4'd2;
    t.dom = cfg.domain + (t.inj == PTP_BAD_DOM);
    t.src_port = (t.inj == PTP_NOT_MASTER) ? 16'd9 : 16'd1;
    t.req_clock = 0; t.req_port = 0;
    if (t.mtype != 4'hB) begin t.prio1 = 0; t.quality = 0; t.prio2 = 0; end
    if (t.mtype != 4'h0) t.two_step = 0;
    if (t.mtype == 4'h0) m_off += t.jump;
    now = longint'(cyc_now()) * 8 + m_off;         // master time at the edge driving the first byte
    case (t.mtype)
      4'h0: begin                                  // Sync: t1 = time on the wire - link delay
        sync_seq++; t.seq = sync_seq; last_sync_seq = sync_seq;
        last_t1 = now - cfg.link_delay_ns; last_corr = c;
        t.set_ts(t.two_step ? 0 : last_t1 - c);
      end
      4'h8: begin                                  // Follow_Up: preciseOriginTimestamp
        t.seq = last_sync_seq + (t.inj == PTP_BAD_SEQ);
        t.set_ts(last_t1 - last_corr - c);
      end
      4'h9: begin                                  // Delay_Resp for the oldest Delay_Req
        int unsigned w = 0;
        while (dq_seq.size() == 0 && w < 4) begin @(vif.drv_cb); w++; end
        if (dq_seq.size() != 0) begin
          last_src = dq_src.pop_front(); last_seq = dq_seq.pop_front(); last_mt = dq_mt.pop_front();
        end
        // no new Delay_Req: answer the last one again
        t.seq = last_seq + (t.inj == PTP_BAD_SEQ);
        t.req_clock = last_src[79:16]; t.req_port = last_src[15:0] + (t.inj == PTP_BAD_PORT);
        t.set_ts(last_mt + cfg.link_delay_ns + c);
      end
      4'hB: begin t.seq = sync_seq; t.set_ts(now); end
      default: begin t.seq = 0; t.set_ts(0); end
    endcase
    if (t.inj == PTP_BAD_NS) t.ts_ns = 32'd1_000_000_000 + t.ts_ns[7:0];
    t.mlen = ptp_minlen(t.mtype) - 2 * (t.inj == PTP_BAD_LEN);
    t.nbytes = 14 + ptp_minlen(t.mtype);
    // Ethernet header
    for (int i = 5; i >= 0; i--) f.push_back(PTP_DA[8*i +: 8]);
    for (int i = 0; i < 6; i++) f.push_back(8'hA0 + i);
    f.push_back(t.eth_ok ? 8'h88 : 8'h08); f.push_back(t.eth_ok ? 8'hF7 : 8'h00);
    // PTP header
    f.push_back({4'h0, t.mtype}); f.push_back({4'h0, t.version});
    f.push_back(t.mlen[15:8]); f.push_back(t.mlen[7:0]); f.push_back(t.dom); f.push_back(8'h00);
    f.push_back({6'b0, t.two_step, 1'b0}); f.push_back(8'h00);
    for (int i = 7; i >= 0; i--) f.push_back(t.corr[8*i +: 8]);
    repeat (4) f.push_back(8'h00);
    for (int i = 7; i >= 0; i--) f.push_back(t.src_clock[8*i +: 8]);
    f.push_back(t.src_port[15:8]); f.push_back(t.src_port[7:0]);
    f.push_back(t.seq[15:8]); f.push_back(t.seq[7:0]);
    f.push_back(8'h00); f.push_back(8'h00);
    // body: timestamp, then the type's fields
    if (ptp_has_ts(t.mtype)) begin
      for (int i = 5; i >= 0; i--) f.push_back(t.ts_sec[8*i +: 8]);
      for (int i = 3; i >= 0; i--) f.push_back(t.ts_ns[8*i +: 8]);
    end
    if (t.mtype == 4'h9) begin
      for (int i = 7; i >= 0; i--) f.push_back(t.req_clock[8*i +: 8]);
      f.push_back(t.req_port[15:8]); f.push_back(t.req_port[7:0]);
    end
    if (t.mtype == 4'hB) begin
      f.push_back(8'h00); f.push_back(8'h25); f.push_back(8'h00); f.push_back(t.prio1);
      for (int i = 3; i >= 0; i--) f.push_back(t.quality[8*i +: 8]);
      f.push_back(t.prio2);
      for (int i = 7; i >= 0; i--) f.push_back(t.src_clock[8*i +: 8]);   // grandmasterIdentity
      f.push_back(8'h00); f.push_back(8'h00); f.push_back(8'hA0);
    end
    while (f.size() < t.nbytes) f.push_back(8'h00);
    foreach (f[i]) begin
      vif.drv_cb.rx_valid <= 1'b1; vif.drv_cb.rx_data <= f[i]; vif.drv_cb.rx_last <= (i == f.size() - 1);
      @(vif.drv_cb);
    end
    vif.drv_cb.rx_valid <= 1'b0; vif.drv_cb.rx_last <= 1'b0;
  endtask

  // clock edges since t0 (no race with a counting thread)
  function int unsigned cyc_now();
    return (per == 0) ? 0 : int'(($realtime - t0) / per);   // rounds to the nearest edge
  endfunction
endclass
