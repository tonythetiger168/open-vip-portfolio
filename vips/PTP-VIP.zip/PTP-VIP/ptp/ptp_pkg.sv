// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_pkg.sv -- IEEE 1588 PTP UVM VIP package

package ptp_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ptp_defs_pkg::*;
  export ptp_defs_pkg::*;

  `include "ptp_transaction.svh"
  `include "ptp_config.svh"
  `include "ptp_sequencer.svh"
  `include "ptp_driver.svh"
  `include "ptp_monitor.svh"
  `include "ptp_agent.svh"
  `include "ptp_sequences.svh"
  `include "ptp_checker.svh"
  `include "ptp_coverage.svh"
endpackage
