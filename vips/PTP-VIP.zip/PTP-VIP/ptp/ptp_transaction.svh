// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_transaction.svh -- IEEE 1588 PTP transaction

class ptp_transaction extends uvm_sequence_item;
  `uvm_object_utils(ptp_transaction)

  rand bit event_i;
  rand bit egress_req;
  bit [63:0] clock_time_o;
  bit [63:0] event_ts_o;
  bit event_valid_o;
  bit [63:0] egress_ts_o;
  bit egress_valid_o;
  bit [31:0] tag;

  function new(string name = "ptp_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    ptp_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    event_i = rhs_.event_i;
    egress_req = rhs_.egress_req;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ptp_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           event_i == rhs_.event_i &&
           egress_req == rhs_.egress_req;
  endfunction

  function string convert2string();
    return $sformatf("IEEE 1588 PTP{tag=%0h event_i=0x%0h egress_req=0x%0h}", tag, event_i, egress_req);
  endfunction
endclass
