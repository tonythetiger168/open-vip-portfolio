// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_transaction.svh -- PTP transaction

class ptp_transaction extends uvm_sequence_item;
  `uvm_object_utils(ptp_transaction)

  // request (driven by the agent)
  bit dir;
  rand bit [3:0] mtype;
  bit eth_ok;
  bit [3:0] version;
  bit [15:0] mlen;
  bit [7:0] nbytes;
  bit [7:0] dom;
  rand bit two_step;
  rand bit [63:0] corr;
  rand bit [63:0] src_clock;
  bit [15:0] src_port;
  bit [15:0] seq;
  bit [47:0] ts_sec;
  bit [31:0] ts_ns;
  bit [63:0] req_clock;
  bit [15:0] req_port;
  rand bit [7:0] prio1;
  rand bit [31:0] quality;
  rand bit [7:0] prio2;
  // response (returned by the DUT)
  bit [2:0] drop;
  bit ok;
  bit [63:0] offset;
  bit [63:0] delay;
  bit [63:0] adj;
  bit [63:0] master;
  // bookkeeping (not compared)
  rand ptp_inj_e inj;
  rand bit signed [15:0] jump;
  rand bit [3:0] gap;
  bit [31:0] t_sec;
  bit [31:0] t_ns;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_type { mtype dist { 4'h0 := 4, 4'h8 := 4, 4'h9 := 4, 4'hB := 1, 4'hC := 1 }; }
  constraint c_src  { src_clock dist { PTP_MASTER_A := 8, PTP_MASTER_B := 1 }; }
  constraint c_ann  { prio1 inside {8'd64, 8'd128, 8'd200}; prio2 inside {8'd128, 8'd255};
                      quality inside {32'hF8FE_FFFF, 32'h06FE_FFFF}; }
  constraint c_corr { corr dist { 0 := 6, [64'h1_0000 : 64'hFF_0000] :/ 2 }; corr[15:0] == 0; }
  constraint c_inj  { inj dist { PTP_NONE := 16, [PTP_BAD_ETH : PTP_BAD_PORT] :/ 4 };
                      inj == PTP_BAD_PORT -> mtype == 4'h9;
                      inj == PTP_BAD_SEQ -> mtype inside {4'h8, 4'h9};
                      inj == PTP_BAD_NS -> mtype != 4'hC; }
  constraint c_misc { jump dist { 0 := 3, [-4000:-8] :/ 1, [8:4000] :/ 1 }; jump[2:0] == 0; gap inside {[0:6]}; }

  function new(string name = "ptp_transaction"); super.new(name); endfunction

  // total nanoseconds of the timestamp field
  function longint ts_total();
    return longint'(ts_sec) * PTP_NS_PER_S + ts_ns;
  endfunction

  function void set_ts(longint tot);
    ts_sec = tot / PTP_NS_PER_S;
    ts_ns = tot % PTP_NS_PER_S;
  endfunction

  function void do_copy(uvm_object rhs);
    ptp_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    dir = rhs_.dir;
    mtype = rhs_.mtype;
    eth_ok = rhs_.eth_ok;
    version = rhs_.version;
    mlen = rhs_.mlen;
    nbytes = rhs_.nbytes;
    dom = rhs_.dom;
    two_step = rhs_.two_step;
    corr = rhs_.corr;
    src_clock = rhs_.src_clock;
    src_port = rhs_.src_port;
    seq = rhs_.seq;
    ts_sec = rhs_.ts_sec;
    ts_ns = rhs_.ts_ns;
    req_clock = rhs_.req_clock;
    req_port = rhs_.req_port;
    prio1 = rhs_.prio1;
    quality = rhs_.quality;
    prio2 = rhs_.prio2;
    drop = rhs_.drop;
    ok = rhs_.ok;
    offset = rhs_.offset;
    delay = rhs_.delay;
    adj = rhs_.adj;
    master = rhs_.master;
    inj = rhs_.inj;
    jump = rhs_.jump;
    gap = rhs_.gap;
    t_sec = rhs_.t_sec;
    t_ns = rhs_.t_ns;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ptp_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (dir != rhs_.dir) return 0;
    if (mtype != rhs_.mtype) return 0;
    if (eth_ok != rhs_.eth_ok) return 0;
    if (version != rhs_.version) return 0;
    if (mlen != rhs_.mlen) return 0;
    if (nbytes != rhs_.nbytes) return 0;
    if (dom != rhs_.dom) return 0;
    if (two_step != rhs_.two_step) return 0;
    if (corr != rhs_.corr) return 0;
    if (src_clock != rhs_.src_clock) return 0;
    if (src_port != rhs_.src_port) return 0;
    if (seq != rhs_.seq) return 0;
    if (ts_sec != rhs_.ts_sec) return 0;
    if (ts_ns != rhs_.ts_ns) return 0;
    if (req_clock != rhs_.req_clock) return 0;
    if (req_port != rhs_.req_port) return 0;
    if (prio1 != rhs_.prio1) return 0;
    if (quality != rhs_.quality) return 0;
    if (prio2 != rhs_.prio2) return 0;
    if (drop != rhs_.drop) return 0;
    if (ok != rhs_.ok) return 0;
    if (offset != rhs_.offset) return 0;
    if (delay != rhs_.delay) return 0;
    if (adj != rhs_.adj) return 0;
    if (master != rhs_.master) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ptp_transaction rhs_);
    if (dir != rhs_.dir) return 0;
    if (mtype != rhs_.mtype) return 0;
    if (eth_ok != rhs_.eth_ok) return 0;
    if (version != rhs_.version) return 0;
    if (mlen != rhs_.mlen) return 0;
    if (nbytes != rhs_.nbytes) return 0;
    if (dom != rhs_.dom) return 0;
    if (two_step != rhs_.two_step) return 0;
    if (corr != rhs_.corr) return 0;
    if (src_clock != rhs_.src_clock) return 0;
    if (src_port != rhs_.src_port) return 0;
    if (seq != rhs_.seq) return 0;
    if (ts_sec != rhs_.ts_sec) return 0;
    if (ts_ns != rhs_.ts_ns) return 0;
    if (req_clock != rhs_.req_clock) return 0;
    if (req_port != rhs_.req_port) return 0;
    if (prio1 != rhs_.prio1) return 0;
    if (quality != rhs_.quality) return 0;
    if (prio2 != rhs_.prio2) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("PTP{tag=%0d dir=0x%0h mtype=0x%0h eth_ok=0x%0h version=0x%0h mlen=0x%0h nbytes=0x%0h dom=0x%0h two_step=0x%0h corr=0x%0h src_clock=0x%0h src_port=0x%0h seq=0x%0h ts_sec=0x%0h ts_ns=0x%0h req_clock=0x%0h req_port=0x%0h prio1=0x%0h quality=0x%0h prio2=0x%0h drop=0x%0h ok=0x%0h offset=0x%0h delay=0x%0h adj=0x%0h master=0x%0h}", tag, dir, mtype, eth_ok, version, mlen, nbytes, dom, two_step, corr, src_clock, src_port, seq, ts_sec, ts_ns, req_clock, req_port, prio1, quality, prio2, drop, ok, offset, delay, adj, master);
  endfunction
endclass
