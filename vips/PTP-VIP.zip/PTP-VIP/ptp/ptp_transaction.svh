// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_transaction.svh -- PTP transaction

class ptp_transaction extends uvm_sequence_item;
  `uvm_object_utils(ptp_transaction)

  // request (driven by the agent)
  rand bit egress;
  // response (returned by the DUT)
  bit valid;
  bit [63:0] ts_delta;
  // bookkeeping (not compared)
  rand bit [2:0] width;
  bit [63:0] ts;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_width { width inside {[1:6]}; }

  function new(string name = "ptp_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    ptp_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    egress = rhs_.egress;
    valid = rhs_.valid;
    ts_delta = rhs_.ts_delta;
    width = rhs_.width;
    ts = rhs_.ts;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ptp_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (egress != rhs_.egress) return 0;
    if (valid != rhs_.valid) return 0;
    if (ts_delta != rhs_.ts_delta) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ptp_transaction rhs_);
    if (egress != rhs_.egress) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("PTP{tag=%0d egress=0x%0h valid=0x%0h ts_delta=0x%0h}", tag, egress, valid, ts_delta);
  endfunction
endclass
