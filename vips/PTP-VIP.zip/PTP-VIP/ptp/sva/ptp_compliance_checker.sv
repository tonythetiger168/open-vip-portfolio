// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_compliance_checker.sv -- PTP concurrent assertion checks (bindable)

module ptp_compliance_checker
  (input logic clk, input logic rst_n, input logic rx_valid, input logic [7:0] rx_data, input logic rx_last, input logic [7:0] domain, input logic [31:0] clock_sec, input logic [31:0] clock_ns, input logic rx_done, input logic [2:0] rx_drop, input logic [3:0] rx_type, input logic sync_ok, input logic [63:0] offset, input logic [63:0] delay, input logic [63:0] master_id, input logic tx_valid, input logic [7:0] tx_data, input logic tx_last);

  logic [63:0] tot;
  assign tot = clock_sec * 64'd1000000000 + clock_ns;
  // outputs never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n)
                   !$isunknown({rx_done, rx_drop, sync_ok, tx_valid, tx_last, clock_sec, clock_ns}))
    else $error("PTP: X on outputs");
  assert property (@(posedge clk) disable iff (!rst_n) clock_ns < 32'd1000000000)
    else $error("PTP: clock nanoseconds >= 10^9");
  // every received frame gets one rx_done, the clock after its last byte has been processed
  assert property (@(posedge clk) disable iff (!rst_n) rx_valid && rx_last |=> ##1 rx_done)
    else $error("PTP: no rx_done after a frame");
  assert property (@(posedge clk) disable iff (!rst_n) rx_done |-> $past(rx_valid && rx_last, 2))
    else $error("PTP: rx_done without a frame");
  // an offset is produced only by a Delay_Resp that was used
  assert property (@(posedge clk) disable iff (!rst_n) sync_ok |-> rx_done && rx_drop == 3'd0 && rx_type == 4'h9)
    else $error("PTP: sync_ok without an accepted Delay_Resp");
  // the clock advances 8 ns per clock unless it is corrected
  assert property (@(posedge clk) disable iff (!rst_n) ##1 !sync_ok |-> tot == $past(tot) + 64'd8)
    else $error("PTP: clock stepped without a correction");
  // Delay_Req: contiguous bytes, starting with the PTP multicast address
  assert property (@(posedge clk) disable iff (!rst_n) tx_last |-> tx_valid)
    else $error("PTP: tx_last without tx_valid");
  assert property (@(posedge clk) disable iff (!rst_n) tx_valid && !tx_last |=> tx_valid)
    else $error("PTP: gap in the Delay_Req");
  assert property (@(posedge clk) disable iff (!rst_n) $rose(tx_valid) |-> tx_data == 8'h01)
    else $error("PTP: Delay_Req does not start with 01-1B-19");
  cover property (@(posedge clk) disable iff (!rst_n) sync_ok);
  cover property (@(posedge clk) disable iff (!rst_n) rx_done && rx_drop == 3'd5);
  cover property (@(posedge clk) disable iff (!rst_n) tx_last);
endmodule
