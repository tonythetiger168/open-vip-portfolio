// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_compliance_checker.sv -- IEEE 1588 PTP concurrent assertion checks (bindable)

module ptp_compliance_checker
  (input logic clk, input logic rst_n, input event_i, input egress_req, input [63:0] clock_time, input [63:0] event_ts, input event_valid, input [63:0] egress_ts, input egress_valid);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({clock_time, event_ts, event_valid, egress_ts, egress_valid}))
    else $error("IEEE 1588 PTP: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> clock_time == '0)
    else $error("IEEE 1588 PTP: output not in reset value");
  // captured timestamp is never ahead of the clock
  assert property (@(posedge clk) disable iff (!rst_n) event_valid |-> event_ts <= clock_time)
    else $error("PTP: event timestamp in the future");
  cover property (@(posedge clk) disable iff (!rst_n) (clock_time != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (event_valid == 1'b1));
endmodule
