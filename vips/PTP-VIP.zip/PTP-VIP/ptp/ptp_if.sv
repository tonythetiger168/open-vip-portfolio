// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_if.sv -- IEEE 1588 PTP interface

interface ptp_if (input logic clk);
  logic rst_n;

  logic event_i;
  logic egress_req;
  logic [63:0] clock_time;
  logic [63:0] event_ts;
  logic event_valid;
  logic [63:0] egress_ts;
  logic egress_valid;

  modport DUT (input clk, rst_n, event_i, egress_req, output clock_time, event_ts, event_valid, egress_ts, egress_valid);
  modport DRV (input clk, rst_n, clock_time, event_ts, event_valid, egress_ts, egress_valid, output event_i, egress_req);
  modport MON (input clk, rst_n, event_i, egress_req, clock_time, event_ts, event_valid, egress_ts, egress_valid);

  clocking drv_cb @(posedge clk);
    input rst_n, event_i, egress_req, clock_time, event_ts, event_valid, egress_ts, egress_valid;
    output event_i, egress_req;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, event_i, egress_req, clock_time, event_ts, event_valid, egress_ts, egress_valid;
  endclocking
endinterface
