// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_if.sv -- PTP interface

interface ptp_if (input logic clk);
  logic rst_n;

  logic rx_valid;
  logic [7:0] rx_data;
  logic rx_last;
  logic [7:0] domain;
  logic [31:0] clock_sec;
  logic [31:0] clock_ns;
  logic rx_done;
  logic [2:0] rx_drop;
  logic [3:0] rx_type;
  logic sync_ok;
  logic [63:0] offset;
  logic [63:0] delay;
  logic [63:0] master_id;
  logic tx_valid;
  logic [7:0] tx_data;
  logic tx_last;

  modport DUT (input clk, rst_n, input rx_valid, input rx_data, input rx_last, input domain, output clock_sec, output clock_ns, output rx_done, output rx_drop, output rx_type, output sync_ok, output offset, output delay, output master_id, output tx_valid, output tx_data, output tx_last);
  modport MON (input clk, rst_n, rx_valid, rx_data, rx_last, domain, clock_sec, clock_ns, rx_done, rx_drop, rx_type, sync_ok, offset, delay, master_id, tx_valid, tx_data, tx_last);

  clocking drv_cb @(posedge clk);
    input rst_n, clock_sec, clock_ns, rx_done, rx_drop, rx_type, sync_ok, offset, delay, master_id, tx_valid, tx_data, tx_last;
    inout rx_valid, rx_data, rx_last, domain;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, rx_valid, rx_data, rx_last, domain, clock_sec, clock_ns, rx_done, rx_drop, rx_type, sync_ok, offset, delay, master_id, tx_valid, tx_data, tx_last;
  endclocking
endinterface
