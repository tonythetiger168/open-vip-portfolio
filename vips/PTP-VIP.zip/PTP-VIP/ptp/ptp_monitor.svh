// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_monitor.svh -- PTP monitor: timestamps checked against the free-running clock_time

class ptp_monitor extends uvm_monitor;
  `uvm_component_utils(ptp_monitor)

  virtual ptp_if vif;
  uvm_analysis_port #(ptp_transaction) ap;
  ptp_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ptp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ptp: virtual interface not set")
    if (!uvm_config_db#(ptp_config)::get(this, "", "cfg", cfg))
      cfg = ptp_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      ptp_transaction ev, eg;
      bit [63:0] ev_ref, eg_ref, last_time;
      bit ev_d = 0, have_time = 0;
      forever begin
        @(vif.mon_cb);
        if (have_time && vif.mon_cb.clock_time != last_time + cfg.clock_step_ns)
          `uvm_error("MON", $sformatf("PTP clock_time stepped from %0d to %0d", last_time, vif.mon_cb.clock_time))
        last_time = vif.mon_cb.clock_time; have_time = 1;
        if (ev != null) begin
          ev.valid = vif.mon_cb.event_valid; ev.ts = vif.mon_cb.event_ts;
          ev.ts_delta = vif.mon_cb.event_ts - ev_ref;
          publish(ev); ev = null;
        end
        if (eg != null) begin
          eg.valid = vif.mon_cb.egress_valid; eg.ts = vif.mon_cb.egress_ts;
          eg.ts_delta = vif.mon_cb.egress_ts - eg_ref;
          publish(eg); eg = null;
        end
        if (vif.mon_cb.event_i && !ev_d) begin
          ev = ptp_transaction::type_id::create("ev");
          ev.egress = 0; ev_ref = vif.mon_cb.clock_time;
        end
        if (vif.mon_cb.egress_req) begin
          eg = ptp_transaction::type_id::create("eg");
          eg.egress = 1; eg_ref = vif.mon_cb.clock_time;
        end
        ev_d = vif.mon_cb.event_i;
      end
    end
  endtask

  function void publish(ptp_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
