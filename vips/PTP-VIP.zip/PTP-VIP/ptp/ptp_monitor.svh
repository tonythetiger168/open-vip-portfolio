// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_monitor.svh -- IEEE 1588 PTP monitor: decodes observed bus activity

class ptp_monitor extends uvm_monitor;
  `uvm_component_utils(ptp_monitor)

  virtual ptp_if vif;
  uvm_analysis_port #(ptp_transaction) ap;
  ptp_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ptp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ptp: virtual interface not set")
    void'(uvm_config_db#(ptp_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    ptp_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = ptp_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.event_i = vif.event_i;
        t.egress_req = vif.egress_req;
        t.clock_time_o = vif.clock_time;
        t.event_ts_o = vif.event_ts;
        t.event_valid_o = vif.event_valid;
        t.egress_ts_o = vif.egress_ts;
        t.egress_valid_o = vif.egress_valid;
        ap.write(t);
      end
    end
  endtask
endclass
