// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ptp_monitor.svh -- PTP monitor: frames in both directions parsed into items; DUT rx_done / drop code / offset / delay and the clock step; clock continuity checked

class ptp_monitor extends uvm_monitor;
  `uvm_component_utils(ptp_monitor)

  virtual ptp_if vif;
  uvm_analysis_port #(ptp_transaction) ap;
  ptp_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ptp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ptp: virtual interface not set")
    if (!uvm_config_db#(ptp_config)::get(this, "", "cfg", cfg))
      cfg = ptp_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] rb[$], tb[$];
      bit [31:0] rs, rn, ts_, tn;
      ptp_transaction pend[$];
      longint prev = -1;
      forever begin
        longint now;
        @(vif.mon_cb);
        if (vif.mon_cb.rst_n !== 1'b1) begin prev = -1; continue; end
        now = longint'(vif.mon_cb.clock_sec) * PTP_NS_PER_S + vif.mon_cb.clock_ns;
        // rx_done of the oldest received frame (the clock step shows with it)
        if (vif.mon_cb.rx_done) begin
          if (pend.size() == 0) `uvm_error("MON", "PTP rx_done without a frame")
          else begin
            ptp_transaction t = pend.pop_front();
            t.drop = vif.mon_cb.rx_drop;
            t.ok = vif.mon_cb.sync_ok;
            if (t.ok) begin t.offset = vif.mon_cb.offset; t.delay = vif.mon_cb.delay; end
            t.adj = (prev < 0) ? 0 : now - prev - 8;
            t.master = vif.mon_cb.master_id;
            if (vif.mon_cb.rx_type != t.mtype) `uvm_error("MON", "PTP rx_type differs from the frame's messageType")
            publish(t);
          end
        end else if (prev >= 0 && now != prev + 8)
          `uvm_error("MON", $sformatf("PTP clock stepped from %0d to %0d without a correction", prev, now))
        prev = now;
        if (vif.mon_cb.rx_valid) begin
          if (rb.size() == 0) begin rs = vif.mon_cb.clock_sec; rn = vif.mon_cb.clock_ns; end
          rb.push_back(vif.mon_cb.rx_data);
          if (vif.mon_cb.rx_last) begin
            ptp_transaction t = ptp_transaction::type_id::create("rx");
            parse(t, rb); t.dir = 0; t.t_sec = rs; t.t_ns = rn;
            pend.push_back(t);
            rb.delete();
          end
        end
        if (vif.mon_cb.tx_valid) begin
          if (tb.size() == 0) begin ts_ = vif.mon_cb.clock_sec; tn = vif.mon_cb.clock_ns; end
          tb.push_back(vif.mon_cb.tx_data);
          if (vif.mon_cb.tx_last) begin
            ptp_transaction t = ptp_transaction::type_id::create("tx");
            parse(t, tb); t.dir = 1; t.t_sec = ts_; t.t_ns = tn; t.master = vif.mon_cb.master_id;
            publish(t);
            tb.delete();
          end
        end
      end
    end
  endtask

  function void publish(ptp_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // fields of a PTP frame (bytes from the destination address on)
  function void parse(ptp_transaction t, bit [7:0] b[$]);
    t.nbytes = b.size();
    while (b.size() < 78) b.push_back(8'h00);
    t.eth_ok = ({b[0], b[1], b[2], b[3], b[4], b[5]} == 48'h011B_1900_0000) && ({b[12], b[13]} == 16'h88F7);
    t.mtype = b[14][3:0]; t.version = b[15][3:0]; t.mlen = {b[16], b[17]}; t.dom = b[18];
    t.two_step = b[20][1];
    for (int i = 0; i < 8; i++) t.corr = {t.corr[55:0], b[22 + i]};
    for (int i = 0; i < 8; i++) t.src_clock = {t.src_clock[55:0], b[34 + i]};
    t.src_port = {b[42], b[43]}; t.seq = {b[44], b[45]};
    for (int i = 0; i < 6; i++) t.ts_sec = {t.ts_sec[39:0], b[48 + i]};
    for (int i = 0; i < 4; i++) t.ts_ns = {t.ts_ns[23:0], b[54 + i]};
    if (t.mtype == 4'h9) begin
      for (int i = 0; i < 8; i++) t.req_clock = {t.req_clock[55:0], b[58 + i]};
      t.req_port = {b[66], b[67]};
    end
    if (t.mtype == 4'hB) begin
      t.prio1 = b[61]; t.quality = {b[62], b[63], b[64], b[65]}; t.prio2 = b[66];
    end
  endfunction
endclass
