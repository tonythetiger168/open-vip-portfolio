// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_transaction.svh -- AXI4-Stream transaction

class axi_stream_transaction extends uvm_sequence_item;
  `uvm_object_utils(axi_stream_transaction)

  // request (driven by the agent)
  bit [8:0] bytes[$];
  rand bit [3:0] id;
  rand bit [3:0] dest;
  // response (returned by the DUT)
  bit [7:0] ndata;
  bit [7:0] npos;
  bit [31:0] crc;
  bit err;
  // bookkeeping (not compared)
  rand bit [6:0] nbytes;
  rand bit [1:0] gap;
  rand bit sparse;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len { nbytes inside {[1:64]}; gap dist { 0 := 4, [1:3] :/ 1 }; }

  function new(string name = "axi_stream_transaction"); super.new(name); endfunction

  // cfg-free fill: about one byte in ten is a position byte
  function void fill_bytes(int unsigned n, int unsigned pos_pct = 10);
    bit [31:0] x = seed | 32'h1;
    bytes.delete();
    for (int unsigned i = 0; i < n; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      if (x[31:24] % 100 < pos_pct) bytes.push_back(9'h100);
      else bytes.push_back({1'b0, x[7:0]});
    end
  endfunction

  function void post_randomize();
    fill_bytes(nbytes);
  endfunction

  function void do_copy(uvm_object rhs);
    axi_stream_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    bytes = rhs_.bytes;
    id = rhs_.id;
    dest = rhs_.dest;
    ndata = rhs_.ndata;
    npos = rhs_.npos;
    crc = rhs_.crc;
    err = rhs_.err;
    nbytes = rhs_.nbytes;
    gap = rhs_.gap;
    sparse = rhs_.sparse;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    axi_stream_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (id != rhs_.id) return 0;
    if (dest != rhs_.dest) return 0;
    if (ndata != rhs_.ndata) return 0;
    if (npos != rhs_.npos) return 0;
    if (crc != rhs_.crc) return 0;
    if (err != rhs_.err) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(axi_stream_transaction rhs_);
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (id != rhs_.id) return 0;
    if (dest != rhs_.dest) return 0;
    return 1;
  endfunction

  function string qstr_bytes();
    string s = $sformatf("[%0d]{", bytes.size());
    foreach (bytes[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bytes[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("AXI4-Stream{tag=%0d bytes=%s id=0x%0h dest=0x%0h ndata=0x%0h npos=0x%0h crc=0x%0h err=0x%0h}", tag, qstr_bytes(), id, dest, ndata, npos, crc, err);
  endfunction
endclass
