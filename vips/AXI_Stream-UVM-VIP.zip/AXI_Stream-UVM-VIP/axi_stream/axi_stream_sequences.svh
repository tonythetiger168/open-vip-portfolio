// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_sequences.svh -- AXI4-Stream sequences

// Random traffic: cfg.num_items constrained-random items.
class axi_stream_base_sequence extends uvm_sequence #(axi_stream_transaction);
  `uvm_object_utils(axi_stream_base_sequence)
  axi_stream_config cfg;

  function new(string name = "axi_stream_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = axi_stream_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "axi_stream_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class axi_stream_directed_sequence extends uvm_sequence #(axi_stream_transaction);
  `uvm_object_utils(axi_stream_directed_sequence)
  axi_stream_config cfg;

  function new(string name = "axi_stream_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function axi_stream_transaction item();
    item = axi_stream_transaction::type_id::create("req");
  endfunction

  task send(axi_stream_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    axi_stream_transaction t;
    // the CRC-32 check string, then every tail length, null-heavy packets,
    // position bytes, every TID and back-to-back single-transfer packets
    begin
      string cv = "123456789";
      t = item();
      foreach (cv[i]) t.bytes.push_back({1'b0, cv[i]});
      t.id = 4'h1; t.dest = 4'h2; send(t);
    end
    for (int n = 1; n <= 8; n++) begin t = item(); t.seed = n; t.fill_bytes(n, 0); t.id = n; send(t); end
    t = item(); t.seed = 32'h77; t.sparse = 1; t.gap = 2; t.fill_bytes(40); send(t);
    t = item(); t.bytes = '{9'h100, 9'h0AA, 9'h100, 9'h100, 9'h055}; t.dest = 4'hF; send(t);
    t = item(); t.bytes = '{9'h100}; send(t);                 // position byte only
    for (int i = 0; i < 16; i++) begin t = item(); t.seed = 200 + i; t.fill_bytes(1 + i % 4, 0); t.id = i; t.dest = 15 - i; send(t); end
    t = item(); t.seed = 32'h99; t.fill_bytes(64); send(t);
  endtask
endclass
