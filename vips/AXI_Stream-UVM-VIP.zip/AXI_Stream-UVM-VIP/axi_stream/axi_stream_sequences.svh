// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_sequences.svh -- AXI4-Stream sequences

// Random traffic: cfg.num_items constrained-random items.
class axi_stream_base_sequence extends uvm_sequence #(axi_stream_transaction);
  `uvm_object_utils(axi_stream_base_sequence)
  axi_stream_config cfg;

  function new(string name = "axi_stream_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = axi_stream_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "axi_stream_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class axi_stream_directed_sequence extends uvm_sequence #(axi_stream_transaction);
  `uvm_object_utils(axi_stream_directed_sequence)
  axi_stream_config cfg;

  function new(string name = "axi_stream_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function axi_stream_transaction item();
    item = axi_stream_transaction::type_id::create("req");
  endfunction

  task send(axi_stream_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    axi_stream_transaction t;
    // the CRC-32 check string, then a length sweep 1..64 and 255, null-heavy
    // packets, position bytes, TUSER, every TID / TDEST, then interleaved streams
    begin
      string cv;
      cv = "123456789";
      t = item();
      foreach (cv[i]) t.bytes.push_back({2'b00, cv[i]});
      t.id = 4'h1; t.dest = 4'h2; send(t);
    end
    for (int n = 1; n <= 64; n++) begin t = item(); t.seed = n; t.umode = n % 4; t.fill_bytes(n, (n % 3) * 10); t.id = n % 16; t.dest = n / 4; send(t); end
    for (int n = 65; n < 256; n += 38) begin t = item(); t.seed = n; t.umode = 1; t.fill_bytes(n == 255 ? 254 : n, 5); send(t); end
    t = item(); t.seed = 32'h255; t.fill_bytes(255, 5); t.sparse = 1; send(t);
    t = item(); t.seed = 32'h77; t.sparse = 1; t.gap = 2; t.fill_bytes(40); send(t);
    t = item(); t.bytes = '{10'h100, 10'h2AA, 10'h300, 10'h100, 10'h055}; t.dest = 4'hF; send(t);
    t = item(); t.bytes = '{10'h100}; send(t);                 // position byte only
    for (int i = 0; i < 16; i++) begin t = item(); t.seed = 200 + i; t.fill_bytes(1 + i % 4, 0); t.id = i; t.dest = 15 - i; send(t); end
    // interleaved: three TIDs in flight, every TID once interleaved with each length class
    for (int i = 0; i < 48; i++) begin
      t = item(); t.seed = 300 + i; t.ilv = 1; t.umode = i % 4; t.sparse = i[2];
      t.fill_bytes((i % 4 == 0) ? 2 + i % 3 : (i % 4 == 1) ? 5 + i % 12 : (i % 4 == 2) ? 17 + i : 65 + i, 10);
      t.id = i % 16; t.dest = (i * 7) % 16; t.gap = i % 3; send(t);
    end
    t = item(); t.seed = 32'h99; t.fill_bytes(64); send(t);
  endtask
endclass
