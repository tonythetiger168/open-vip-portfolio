// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_monitor.svh -- AXI4-Stream monitor: transfers (TVALID & TREADY) collected into packets at TLAST, completed by the receiver's packet report

class axi_stream_monitor extends uvm_monitor;
  `uvm_component_utils(axi_stream_monitor)

  virtual axi_stream_if vif;
  uvm_analysis_port #(axi_stream_transaction) ap;
  axi_stream_config cfg;
  int unsigned n_obs = 0;

  axi_stream_transaction cur, done_q[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual axi_stream_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "axi_stream: virtual interface not set")
    if (!uvm_config_db#(axi_stream_config)::get(this, "", "cfg", cfg))
      cfg = axi_stream_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        @(vif.mon_cb);
        // the report of a packet comes one clock after its TLAST transfer
        if (vif.mon_cb.pkt_done) begin
          if (done_q.size() == 0)
            `uvm_error("MON", "AXI4-Stream: packet report without a TLAST transfer")
          else begin
            axi_stream_transaction t = done_q.pop_front();
            t.ndata = vif.mon_cb.pkt_ndata; t.npos = vif.mon_cb.pkt_npos; t.crc = vif.mon_cb.pkt_crc;
            t.err = vif.mon_cb.pkt_err;
            if (vif.mon_cb.pkt_id != t.id || vif.mon_cb.pkt_dest != t.dest) t.err = 1'b1;
            publish(t);
          end
        end
        if (vif.mon_cb.tvalid && vif.mon_cb.tready) begin
          if (cur == null) begin
            cur = axi_stream_transaction::type_id::create("t");
            cur.id = vif.mon_cb.tid; cur.dest = vif.mon_cb.tdest;
          end
          for (int l = 0; l < 4; l++)
            if (vif.mon_cb.tkeep[l])
              cur.bytes.push_back(vif.mon_cb.tstrb[l] ? {1'b0, vif.mon_cb.tdata[l*8 +: 8]} : 9'h100);
          if (vif.mon_cb.tlast) begin
            done_q.push_back(cur);
            cur = null;
          end
        end
      end
    end
  endtask

  function void publish(axi_stream_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
