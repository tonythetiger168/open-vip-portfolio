// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_checker.svh -- AXI4-Stream protocol checker on monitored items

class axi_stream_checker extends uvm_component;
  `uvm_component_utils(axi_stream_checker)
  uvm_analysis_imp #(axi_stream_transaction, axi_stream_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  axi_stream_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(axi_stream_config)::get(this, "", "cfg", cfg))
      cfg = axi_stream_config::type_id::create("cfg");
  endfunction

  function void fail(axi_stream_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("AXI4-Stream: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(axi_stream_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.bytes.size() == 0) fail(t, "packet with no data or position byte");
      if (t.err) fail(t, "receiver flagged a reserved TKEEP / TSTRB combination or a TDEST change inside a packet");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("AXI4-Stream checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
