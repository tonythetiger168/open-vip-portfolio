// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_driver.svh -- AXI4-Stream driver: one packet per item, bytes placed on the four lanes with random null bytes and TVALID gaps

class axi_stream_driver extends uvm_driver #(axi_stream_transaction);
  `uvm_component_utils(axi_stream_driver)

  uvm_analysis_port #(axi_stream_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual axi_stream_if vif;
  axi_stream_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual axi_stream_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "axi_stream: virtual interface not set")
    if (!uvm_config_db#(axi_stream_config)::get(this, "", "cfg", cfg))
      cfg = axi_stream_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    axi_stream_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.tvalid <= 1'b0; vif.drv_cb.tdata <= '0; vif.drv_cb.tkeep <= '0; vif.drv_cb.tstrb <= '0;
    vif.drv_cb.tlast  <= 1'b0; vif.drv_cb.tid   <= '0; vif.drv_cb.tdest <= '0;
  endtask

  task drive_item(axi_stream_transaction t);
    int unsigned idx = 0;
    while (idx < t.bytes.size()) begin
      bit [31:0] d = 0; bit [3:0] k = 0, s = 0;
      for (int l = 0; l < 4; l++) begin
        if (idx < t.bytes.size() && !(t.sparse && $urandom_range(99) < cfg.null_pct)) begin
          k[l] = 1'b1;
          s[l] = !t.bytes[idx][8];
          d[l*8 +: 8] = t.bytes[idx][7:0];
          idx++;
        end
      end
      vif.drv_cb.tvalid <= 1'b1; vif.drv_cb.tdata <= d; vif.drv_cb.tkeep <= k; vif.drv_cb.tstrb <= s;
      vif.drv_cb.tlast  <= (idx == t.bytes.size()); vif.drv_cb.tid <= t.id; vif.drv_cb.tdest <= t.dest;
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.tready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.tready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("AXI4-Stream TREADY: no response within %0d cycles", cfg.timeout_cycles))
      end
      if (t.gap != 0 && idx < t.bytes.size()) begin
        vif.drv_cb.tvalid <= 1'b0;
        repeat (t.gap) @(vif.drv_cb);
      end
    end
    vif.drv_cb.tvalid <= 1'b0;
    vif.drv_cb.tlast  <= 1'b0;
  endtask

endclass
