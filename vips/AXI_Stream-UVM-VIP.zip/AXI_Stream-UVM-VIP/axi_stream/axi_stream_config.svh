// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_config.svh -- AXI4-Stream agent configuration

class axi_stream_config extends uvm_object;
  `uvm_object_utils(axi_stream_config)
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  bit coverage_enable = 1;
  bit checks_enable   = 1;
  int unsigned num_items      = 32;     // random items per base sequence
  int unsigned timeout_cycles = 200;   // handshake / response watchdog
  int unsigned null_pct = 15;   // percent of lanes left null inside a packet
  int unsigned pos_pct  = 10;   // percent of bytes sent as position bytes
  function new(string name = "axi_stream_config"); super.new(name); endfunction
endclass
