// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_if.sv -- AXI4-Stream interface

interface axi_stream_if (input logic clk);
  logic rst_n;

  logic tvalid;
  logic tready;
  logic [31:0] tdata;
  logic [3:0] tkeep;
  logic [3:0] tstrb;
  logic tlast;
  logic [3:0] tid;
  logic [3:0] tdest;
  logic pkt_done;
  logic [7:0] pkt_ndata;
  logic [7:0] pkt_npos;
  logic [31:0] pkt_crc;
  logic [3:0] pkt_id;
  logic [3:0] pkt_dest;
  logic pkt_err;

  modport DUT (input clk, rst_n, input tvalid, input tdata, input tkeep, input tstrb, input tlast, input tid, input tdest, output tready, output pkt_done, output pkt_ndata, output pkt_npos, output pkt_crc, output pkt_id, output pkt_dest, output pkt_err);
  modport MON (input clk, rst_n, tvalid, tready, tdata, tkeep, tstrb, tlast, tid, tdest, pkt_done, pkt_ndata, pkt_npos, pkt_crc, pkt_id, pkt_dest, pkt_err);

  clocking drv_cb @(posedge clk);
    input rst_n, tready, pkt_done, pkt_ndata, pkt_npos, pkt_crc, pkt_id, pkt_dest, pkt_err;
    inout tvalid, tdata, tkeep, tstrb, tlast, tid, tdest;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, tvalid, tready, tdata, tkeep, tstrb, tlast, tid, tdest, pkt_done, pkt_ndata, pkt_npos, pkt_crc, pkt_id, pkt_dest, pkt_err;
  endclocking
endinterface
