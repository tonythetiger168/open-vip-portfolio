// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_pkg.sv -- AXI4-Stream UVM VIP package

package axi_stream_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import axi_stream_defs_pkg::*;
  export axi_stream_defs_pkg::*;

  `include "axi_stream_transaction.svh"
  `include "axi_stream_config.svh"
  `include "axi_stream_sequencer.svh"
  `include "axi_stream_driver.svh"
  `include "axi_stream_monitor.svh"
  `include "axi_stream_agent.svh"
  `include "axi_stream_sequences.svh"
  `include "axi_stream_checker.svh"
  `include "axi_stream_coverage.svh"
endpackage
