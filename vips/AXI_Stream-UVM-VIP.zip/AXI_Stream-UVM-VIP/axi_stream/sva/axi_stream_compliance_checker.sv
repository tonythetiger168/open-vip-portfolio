// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_compliance_checker.sv -- AXI4-Stream concurrent assertion checks (bindable)

module axi_stream_compliance_checker
  (input logic clk, input logic rst_n, input logic tvalid, input logic tready, input logic [31:0] tdata, input logic [3:0] tkeep, input logic [3:0] tstrb, input logic tlast, input logic [3:0] tid, input logic [3:0] tdest, input logic pkt_done, input logic [7:0] pkt_ndata, input logic [7:0] pkt_npos, input logic [31:0] pkt_crc, input logic [3:0] pkt_id, input logic [3:0] pkt_dest, input logic pkt_err);

  logic in_pkt;
  logic [3:0] p_id, p_dest;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin in_pkt <= 1'b0; p_id <= '0; p_dest <= '0; end
    else if (tvalid && tready) begin
      in_pkt <= !tlast;
      if (!in_pkt) begin p_id <= tid; p_dest <= tdest; end
    end
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tready, pkt_done}))
    else $error("AXI4-Stream: X on TREADY / report");
  assert property (@(posedge clk) disable iff (!rst_n) tvalid |-> !$isunknown({tdata & {{8{tkeep[3]}}, {8{tkeep[2]}}, {8{tkeep[1]}}, {8{tkeep[0]}}}, tkeep, tstrb, tlast, tid, tdest}))
    else $error("AXI4-Stream: X on the payload while TVALID");
  // once TVALID is high it stays high, payload stable, until TREADY
  assert property (@(posedge clk) disable iff (!rst_n) tvalid && !tready |=> tvalid && $stable({tdata, tkeep, tstrb, tlast, tid, tdest}))
    else $error("AXI4-Stream: transfer changed or withdrawn before TREADY");
  // TKEEP low with TSTRB high is reserved
  assert property (@(posedge clk) disable iff (!rst_n) tvalid |-> (tstrb & ~tkeep) == 4'h0)
    else $error("AXI4-Stream: reserved TKEEP = 0 / TSTRB = 1 combination");
  // TID and TDEST do not change inside a packet
  assert property (@(posedge clk) disable iff (!rst_n) tvalid && in_pkt |-> tid == p_id && tdest == p_dest)
    else $error("AXI4-Stream: TID / TDEST changed inside a packet");
  // a report only follows a TLAST transfer
  assert property (@(posedge clk) disable iff (!rst_n) pkt_done |-> $past(tvalid && tready && tlast))
    else $error("AXI4-Stream: packet report without TLAST");
  cover property (@(posedge clk) disable iff (!rst_n) tvalid && !tready ##1 tvalid && tready);
  cover property (@(posedge clk) disable iff (!rst_n) tvalid && tready && tkeep != 4'hF && !tlast);
  cover property (@(posedge clk) disable iff (!rst_n) tvalid && tready && (tkeep & ~tstrb) != 0);
  cover property (@(posedge clk) disable iff (!rst_n) tvalid && tready && tlast ##1 tvalid && tready && tlast);
endmodule
