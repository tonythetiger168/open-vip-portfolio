// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi_stream_coverage.svh -- AXI4-Stream functional coverage

class axi_stream_coverage extends uvm_subscriber #(axi_stream_transaction);
  `uvm_component_utils(axi_stream_coverage)
  axi_stream_config cfg;
  axi_stream_transaction tr;

  covergroup axi_stream_cg;
    cp_len  : coverpoint tr.bytes.size() { bins one = {1}; bins word = {[2:4]}; bins short_ = {[5:16]}; bins long_ = {[17:64]}; }
    cp_pos  : coverpoint tr.npos { bins none = {0}; bins some = {[1:$]}; }
    cp_tail : coverpoint tr.bytes.size() % 4;
    cp_id   : coverpoint tr.id;
    cp_dest : coverpoint tr.dest { bins lo = {[0:7]}; bins hi = {[8:15]}; }
    x_len_tail : cross cp_len, cp_tail;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    axi_stream_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(axi_stream_config)::get(this, "", "cfg", cfg))
      cfg = axi_stream_config::type_id::create("cfg");
  endfunction

  function void write(axi_stream_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    axi_stream_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("AXI4-Stream coverage: %0.1f%%", axi_stream_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
