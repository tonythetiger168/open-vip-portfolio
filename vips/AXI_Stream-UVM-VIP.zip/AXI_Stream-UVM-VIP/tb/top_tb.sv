// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- AXI4-Stream testbench top with a functional AXI4-Stream DUT model

`ifndef AXI_STREAM_UVM_VIP_TB_SV
`define AXI_STREAM_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import axi_stream_defs_pkg::*;
import axi_stream_pkg::*;
import axi_stream_env_pkg::*;
import axi_stream_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  axi_stream_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  axi_stream_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tvalid(vif.tvalid),
    .tready(vif.tready),
    .tdata(vif.tdata),
    .tkeep(vif.tkeep),
    .tstrb(vif.tstrb),
    .tlast(vif.tlast),
    .tid(vif.tid),
    .tdest(vif.tdest),
    .pkt_done(vif.pkt_done),
    .pkt_ndata(vif.pkt_ndata),
    .pkt_npos(vif.pkt_npos),
    .pkt_crc(vif.pkt_crc),
    .pkt_id(vif.pkt_id),
    .pkt_dest(vif.pkt_dest),
    .pkt_err(vif.pkt_err)
  );

  // Concurrent protocol checks
  axi_stream_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tvalid(vif.tvalid),
    .tready(vif.tready),
    .tdata(vif.tdata),
    .tkeep(vif.tkeep),
    .tstrb(vif.tstrb),
    .tlast(vif.tlast),
    .tid(vif.tid),
    .tdest(vif.tdest),
    .pkt_done(vif.pkt_done),
    .pkt_ndata(vif.pkt_ndata),
    .pkt_npos(vif.pkt_npos),
    .pkt_crc(vif.pkt_crc),
    .pkt_id(vif.pkt_id),
    .pkt_dest(vif.pkt_dest),
    .pkt_err(vif.pkt_err)
  );

  initial begin
    uvm_config_db#(virtual axi_stream_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module axi_stream_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        tvalid,
  output logic        tready,
  input  logic [31:0] tdata,
  input  logic [3:0]  tkeep,
  input  logic [3:0]  tstrb,
  input  logic        tlast,
  input  logic [3:0]  tid,
  input  logic [3:0]  tdest,
  output logic        pkt_done,
  output logic [7:0]  pkt_ndata,
  output logic [7:0]  pkt_npos,
  output logic [31:0] pkt_crc,
  output logic [3:0]  pkt_id,
  output logic [3:0]  pkt_dest,
  output logic        pkt_err
);
  logic [7:0]  lfsr;
  logic        in_pkt, err;
  logic [7:0]  nd, np;
  logic [31:0] crc;
  logic [3:0]  cur_id, cur_dest;
  // this transfer folded into the packet state
  logic [7:0]  nd_n, np_n;
  logic [31:0] crc_n;
  logic        err_n;

  assign tready = lfsr[1] | lfsr[3];

  always_comb begin
    nd_n = in_pkt ? nd : 8'd0;
    np_n = in_pkt ? np : 8'd0;
    crc_n = in_pkt ? crc : 32'hFFFF_FFFF;
    err_n = in_pkt ? err : 1'b0;
    if (in_pkt && (tid != cur_id || tdest != cur_dest)) err_n = 1'b1;
    for (int l = 0; l < 4; l++) begin
      if (tkeep[l] && tstrb[l]) begin
        nd_n = nd_n + 8'd1;
        crc_n = crc_n ^ {24'h0, tdata[l*8 +: 8]};
        for (int i = 0; i < 8; i++) crc_n = crc_n[0] ? (crc_n >> 1) ^ 32'hEDB8_8320 : crc_n >> 1;
      end else if (tkeep[l]) np_n = np_n + 8'd1;
      else if (tstrb[l]) err_n = 1'b1;           // reserved: TKEEP low, TSTRB high
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lfsr <= 8'hC3; in_pkt <= 1'b0; err <= 1'b0; nd <= '0; np <= '0; crc <= '1;
      cur_id <= '0; cur_dest <= '0;
      pkt_done <= 1'b0; pkt_ndata <= '0; pkt_npos <= '0; pkt_crc <= '0; pkt_id <= '0;
      pkt_dest <= '0; pkt_err <= 1'b0;
    end else begin
      lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};
      pkt_done <= 1'b0;
      if (tvalid && tready) begin
        if (!in_pkt) begin cur_id <= tid; cur_dest <= tdest; end
        if (tlast) begin
          in_pkt <= 1'b0;
          pkt_done <= 1'b1; pkt_ndata <= nd_n; pkt_npos <= np_n; pkt_crc <= ~crc_n;
          pkt_id <= in_pkt ? cur_id : tid; pkt_dest <= in_pkt ? cur_dest : tdest; pkt_err <= err_n;
        end else begin
          in_pkt <= 1'b1; nd <= nd_n; np <= np_n; crc <= crc_n; err <= err_n;
        end
      end
    end
  end
endmodule
`endif
