// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- AXI4-Stream testbench top with a functional AXI4-Stream DUT model

`ifndef AXI_STREAM_UVM_VIP_TB_SV
`define AXI_STREAM_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import axi_stream_defs_pkg::*;
import axi_stream_pkg::*;
import axi_stream_env_pkg::*;
import axi_stream_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  axi_stream_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  axi_stream_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tvalid(vif.tvalid),
    .tready(vif.tready),
    .tdata(vif.tdata),
    .tkeep(vif.tkeep),
    .tstrb(vif.tstrb),
    .tlast(vif.tlast),
    .tid(vif.tid),
    .tdest(vif.tdest),
    .tuser(vif.tuser),
    .pkt_done(vif.pkt_done),
    .pkt_ndata(vif.pkt_ndata),
    .pkt_npos(vif.pkt_npos),
    .pkt_nuser(vif.pkt_nuser),
    .pkt_crc(vif.pkt_crc),
    .pkt_id(vif.pkt_id),
    .pkt_dest(vif.pkt_dest),
    .pkt_err(vif.pkt_err)
  );

  // Concurrent protocol checks
  axi_stream_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tvalid(vif.tvalid),
    .tready(vif.tready),
    .tdata(vif.tdata),
    .tkeep(vif.tkeep),
    .tstrb(vif.tstrb),
    .tlast(vif.tlast),
    .tid(vif.tid),
    .tdest(vif.tdest),
    .tuser(vif.tuser),
    .pkt_done(vif.pkt_done),
    .pkt_ndata(vif.pkt_ndata),
    .pkt_npos(vif.pkt_npos),
    .pkt_nuser(vif.pkt_nuser),
    .pkt_crc(vif.pkt_crc),
    .pkt_id(vif.pkt_id),
    .pkt_dest(vif.pkt_dest),
    .pkt_err(vif.pkt_err)
  );

  initial begin
    uvm_config_db#(virtual axi_stream_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module axi_stream_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        tvalid,
  output logic        tready,
  input  logic [31:0] tdata,
  input  logic [3:0]  tkeep,
  input  logic [3:0]  tstrb,
  input  logic        tlast,
  input  logic [3:0]  tid,
  input  logic [3:0]  tdest,
  input  logic [3:0]  tuser,
  output logic        pkt_done,
  output logic [7:0]  pkt_ndata,
  output logic [7:0]  pkt_npos,
  output logic [7:0]  pkt_nuser,
  output logic [31:0] pkt_crc,
  output logic [3:0]  pkt_id,
  output logic [3:0]  pkt_dest,
  output logic        pkt_err
);
  logic [7:0]  lfsr;
  // one packet context per TID
  logic        c_in   [0:15];
  logic        c_err  [0:15];
  logic [7:0]  c_nd   [0:15];
  logic [7:0]  c_np   [0:15];
  logic [7:0]  c_nu   [0:15];
  logic [31:0] c_crc  [0:15];
  logic [3:0]  c_dest [0:15];
  // this transfer folded into its TID's packet state
  logic        in_pkt;
  logic [7:0]  nd_n, np_n, nu_n;
  logic [31:0] crc_n;
  logic        err_n;

  assign tready = lfsr[1] | lfsr[3];

  always_comb begin
    in_pkt = c_in[tid];
    nd_n  = in_pkt ? c_nd[tid] : 8'd0;
    np_n  = in_pkt ? c_np[tid] : 8'd0;
    nu_n  = in_pkt ? c_nu[tid] : 8'd0;
    crc_n = in_pkt ? c_crc[tid] : 32'hFFFF_FFFF;
    err_n = in_pkt ? c_err[tid] : 1'b0;
    if (in_pkt && tdest != c_dest[tid]) err_n = 1'b1;
    for (int l = 0; l < 4; l++) begin
      if (tkeep[l] && tstrb[l]) begin
        nd_n = nd_n + 8'd1;
        nu_n = nu_n + {7'd0, tuser[l]};
        crc_n = crc_n ^ {24'h0, tdata[l*8 +: 8]};
        for (int i = 0; i < 8; i++) crc_n = crc_n[0] ? (crc_n >> 1) ^ 32'hEDB8_8320 : crc_n >> 1;
      end else if (tkeep[l]) np_n = np_n + 8'd1;
      else if (tstrb[l]) err_n = 1'b1;           // reserved: TKEEP low, TSTRB high
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lfsr <= 8'hC3;
      for (int i = 0; i < 16; i++) begin
        c_in[i] <= 1'b0; c_err[i] <= 1'b0; c_nd[i] <= '0; c_np[i] <= '0; c_nu[i] <= '0;
        c_crc[i] <= '1; c_dest[i] <= '0;
      end
      pkt_done <= 1'b0; pkt_ndata <= '0; pkt_npos <= '0; pkt_nuser <= '0; pkt_crc <= '0; pkt_id <= '0;
      pkt_dest <= '0; pkt_err <= 1'b0;
    end else begin
      lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};
      pkt_done <= 1'b0;
      if (tvalid && tready) begin
        if (!in_pkt) c_dest[tid] <= tdest;
        if (tlast) begin
          c_in[tid] <= 1'b0;
          pkt_done <= 1'b1; pkt_ndata <= nd_n; pkt_npos <= np_n; pkt_nuser <= nu_n; pkt_crc <= ~crc_n;
          pkt_id <= tid; pkt_dest <= in_pkt ? c_dest[tid] : tdest; pkt_err <= err_n;
        end else begin
          c_in[tid] <= 1'b1; c_nd[tid] <= nd_n; c_np[tid] <= np_n; c_nu[tid] <= nu_n;
          c_crc[tid] <= crc_n; c_err[tid] <= err_n;
        end
      end
    end
  end
endmodule
`endif
