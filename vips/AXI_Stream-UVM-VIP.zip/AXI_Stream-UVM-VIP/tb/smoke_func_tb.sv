// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (AXI4-Stream DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened axi_stream_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic tvalid = 0, tlast = 0;
  logic [31:0] tdata = 0;
  logic [3:0] tkeep = 0, tstrb = 0, tid = 0, tdest = 0;
  wire tready, pkt_done, pkt_err;
  wire [7:0] pkt_ndata, pkt_npos;
  wire [31:0] pkt_crc;
  wire [3:0] pkt_id, pkt_dest;

  always #5 clk = ~clk;

  axi_stream_model u_dut (.clk(clk), .rst_n(rst_n), .tvalid(tvalid), .tready(tready), .tdata(tdata),
                          .tkeep(tkeep), .tstrb(tstrb), .tlast(tlast), .tid(tid), .tdest(tdest),
                          .pkt_done(pkt_done), .pkt_ndata(pkt_ndata), .pkt_npos(pkt_npos),
                          .pkt_crc(pkt_crc), .pkt_id(pkt_id), .pkt_dest(pkt_dest), .pkt_err(pkt_err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // reports seen (one per packet)
  int nrep = 0;
  logic [7:0] r_nd, r_np; logic [31:0] r_crc; logic [3:0] r_id, r_dest; logic r_err;
  always @(posedge clk) if (pkt_done) begin
    nrep++; r_nd = pkt_ndata; r_np = pkt_npos; r_crc = pkt_crc; r_id = pkt_id; r_dest = pkt_dest; r_err = pkt_err;
  end

  // one transfer, held until TREADY
  int stalls = 0;
  task automatic xfer(input logic [31:0] d, input logic [3:0] k, input logic [3:0] s, input logic l,
                      input logic [3:0] id, input logic [3:0] dst);
    int n;
    tvalid = 1; tdata = d; tkeep = k; tstrb = s; tlast = l; tid = id; tdest = dst;
    n = 0;
    @(posedge clk);
    while (!tready && n < 50) begin stalls++; @(posedge clk); n++; end
    #1;
    tvalid = 0; tlast = 0;
  endtask

  task automatic wait_rep(input int prev);
    int n;
    n = 0;
    while (nrep == prev && n < 20) begin @(posedge clk); n++; end
    #1;
  endtask

  initial begin
    int b;
    repeat (3) @(posedge clk);
    chk(pkt_done === 1'b0, "no report in reset");
    rst_n = 1;
    repeat (2) @(posedge clk); #1;

    // "123456789" on four lanes: CRC-32 check value 0xCBF43926
    b = nrep;
    xfer(32'h3433_3231, 4'hF, 4'hF, 0, 4'h1, 4'h2);
    xfer(32'h3837_3635, 4'hF, 4'hF, 0, 4'h1, 4'h2);
    xfer(32'h0000_0039, 4'h1, 4'h1, 1, 4'h1, 4'h2);
    wait_rep(b);
    chk(nrep == b + 1, "one report per packet");
    chk(r_crc === 32'hCBF4_3926 && r_nd == 9 && r_np == 0, "CRC-32 of 123456789 = 0xCBF43926, 9 bytes");
    chk(r_id == 4'h1 && r_dest == 4'h2 && r_err === 1'b0, "TID / TDEST reported, no error");

    // the same bytes with null lanes in between and a null transfer
    b = nrep;
    xfer(32'h0032_0031, 4'h5, 4'h5, 0, 4'h3, 4'h4);
    xfer(32'h3300_0000, 4'h8, 4'h8, 0, 4'h3, 4'h4);
    xfer(32'hFFFF_FFFF, 4'h0, 4'h0, 0, 4'h3, 4'h4);
    xfer(32'h3736_3534, 4'hF, 4'hF, 0, 4'h3, 4'h4);
    xfer(32'h0039_3800, 4'h6, 4'h6, 1, 4'h3, 4'h4);
    wait_rep(b);
    chk(r_crc === 32'hCBF4_3926 && r_nd == 9, "null bytes are dropped (same CRC, same count)");
    chk(r_id == 4'h3 && r_dest == 4'h4, "TID / TDEST of the second packet");

    // position bytes: counted, not in the CRC, their data ignored
    b = nrep;
    xfer(32'h33FF_3231, 4'hF, 4'hB, 0, 4'h5, 4'h6);
    xfer(32'h3736_3534, 4'hF, 4'hF, 0, 4'h5, 4'h6);
    xfer(32'hAA39_3800, 4'hF, 4'h6, 1, 4'h5, 4'h6);
    wait_rep(b);
    chk(r_crc === 32'hCBF4_3926 && r_nd == 9 && r_np == 3 && r_err === 1'b0, "three position bytes counted, CRC unchanged");

    // a single-byte packet and a position-only packet
    b = nrep;
    xfer(32'h0000_0061, 4'h1, 4'h1, 1, 4'h7, 4'h8);
    wait_rep(b);
    chk(r_nd == 1 && r_crc === 32'hE8B7_BE43 && r_id == 4'h7 && r_dest == 4'h8, "single byte 'a': CRC 0xE8B7BE43");
    b = nrep;
    xfer(32'h0000_0000, 4'h2, 4'h0, 1, 4'h9, 4'hA);
    wait_rep(b);
    chk(r_nd == 0 && r_np == 1 && r_crc === 32'h0 && r_err === 1'b0, "position byte only: no data, CRC of nothing is 0");

    // reserved TKEEP low / TSTRB high
    b = nrep;
    xfer(32'h0000_3231, 4'h3, 4'h7, 1, 4'h0, 4'h0);
    wait_rep(b);
    chk(r_err === 1'b1 && r_nd == 2, "TKEEP 0 / TSTRB 1 flagged, data bytes still counted");
    // TID change inside a packet, TDEST change inside a packet
    b = nrep;
    xfer(32'h3433_3231, 4'hF, 4'hF, 0, 4'h1, 4'h1);
    xfer(32'h3837_3635, 4'hF, 4'hF, 1, 4'h2, 4'h1);
    wait_rep(b);
    chk(r_err === 1'b1 && r_id == 4'h1, "TID change inside a packet flagged; the first TID reported");
    b = nrep;
    xfer(32'h3433_3231, 4'hF, 4'hF, 0, 4'h1, 4'h1);
    xfer(32'h3837_3635, 4'hF, 4'hF, 1, 4'h1, 4'h3);
    wait_rep(b);
    chk(r_err === 1'b1 && r_dest == 4'h1, "TDEST change inside a packet flagged; the first TDEST reported");
    b = nrep;
    xfer(32'h3433_3231, 4'hF, 4'hF, 1, 4'h2, 4'h3);
    wait_rep(b);
    chk(r_err === 1'b0 && r_nd == 4 && r_crc === 32'h9BE3_E0A3, "error state cleared for the next packet; CRC of 1234");

    // back to back: each single-transfer packet reported on its own
    b = nrep;
    for (int i = 0; i < 8; i++) xfer(32'h0000_0061, 4'h1, 4'h1, 1, i, i);
    repeat (3) @(posedge clk); #1;
    chk(nrep == b + 8, "eight back-to-back packets, eight reports");
    chk(r_crc === 32'hE8B7_BE43 && r_id == 4'h7 && r_nd == 1, "last of them reported correctly");

    // a long packet: 255 bytes (count width), no tail
    b = nrep;
    for (int i = 0; i < 63; i++) xfer(32'h6161_6161, 4'hF, 4'hF, 0, 4'hC, 4'hD);
    xfer(32'h0061_6161, 4'h7, 4'h7, 1, 4'hC, 4'hD);
    wait_rep(b);
    chk(r_nd == 255 && r_err === 1'b0, "255 data bytes counted");

    // TREADY is not always high: the receiver back-pressures
    chk(stalls > 0, $sformatf("TREADY low for %0d clocks of a held transfer", stalls));

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #400000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
