// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// HBM5 Timing Performance Checker (L2)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef HBM5_TIMING_CHECKER_SV
`define HBM5_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module hbm5_timing_checker (hbm5_if vif);

  // Decoded commands (same encoding as the driver and hbm5_mem_model)
  localparam int TRCD = 6, TRP = 6;
  wire is_act = !vif.cs_n && !vif.act_n;
  wire is_cas = !vif.cs_n &&  vif.act_n &&  vif.ras_n && !vif.cas_n;
  wire is_pre = !vif.cs_n &&  vif.act_n && !vif.ras_n &&  vif.cas_n && !vif.we_n;
  property p_hbm5_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) is_act |=> !is_cas [*TRCD-1]; endproperty
  assert_p_hbm5_tRCD: assert property(p_hbm5_tRCD) else `uvm_warning("HBM5", "tRCD (6 cycles ACT to RD/WR) failed");
  cover_p_hbm5_tRCD: cover property(p_hbm5_tRCD);
  property p_hbm5_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) is_pre |=> !is_act [*TRP-1]; endproperty
  assert_p_hbm5_tRP: assert property(p_hbm5_tRP) else `uvm_warning("HBM5", "tRP (6 cycles PRE to ACT) failed");
  cover_p_hbm5_tRP: cover property(p_hbm5_tRP);

endmodule : hbm5_timing_checker
`endif
