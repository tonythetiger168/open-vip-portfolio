# USB4 Test Plan（USB4-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | USB4 router lane adapter + transport layer (Gen 2 / Gen 3) |
| 家族 | USB |
| 類型 | UVM VIP |
| 交付目錄 | `USB4-VIP/` |
| 目前 L1b 狀態 | PASS |

## 2. DUT / 待測對象

- `usb4_smoke_model`（USB4 router lane adapter：兩條 lane 的 training / CLx / bonding、RS-FEC、transport packet、control path、config space、path 與 credit）
- `usb3_phy_model`、`usb4_phy_model`、`pd_controller_model`（umbrella top 的 PIPE loopback model，沿用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | in reset: both lanes CLd, nothing sent; lane detect -> Lock | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | training: 2 SLOS / 2 TS1 / 2 TS2 per step, interrupted steps restart, one answer per step | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | Gen 2 / Gen 3 selection from the TS1 Gen 3 bit and gen3_cap | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | training timeout in Lock / TS1 / TS2 -> CLd; CLD ordered set and lane detect loss | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | lane bonding: width 2 with both lanes in CL0, width-change Notification | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | CLx: CL_REQ -> CL_ACK / CL_NAK (disabled, queue busy, buffer held), WAKE -> TS2, CLx -> CLd | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | transport header HEC, length mismatch, packets outside CL0 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | control Read / Write with CRC-32, responses, ERR_ADDR / ERR_LEN / ERR_UNSUP, read-only router ID | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | retransmission (same seq and PDF) replays the stored response; Notification Ack | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | path setup, HopID translation, unknown HopID, 4 buffers per path, overflow | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | buffer release after 6 clocks, held by out_busy, Credit Grant per release | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | RS-FEC: up to 2 symbol errors corrected, uncorrectable packets, retrain after 4; Gen 2 poison | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | output queue flushed when lane 0 leaves CL0 (no half packets) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | reset in the middle of traffic | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Sideband channel (LT / AT transactions) and router enumeration |
| PT-02 | Tunneled protocol adapters (USB3 / DisplayPort / PCIe) |
| PT-03 | Gen 4 (PAM-3) and asymmetric links |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/usb4_compliance_checker.sv`（L1 signal sanity 4、L2 training 5、L3 lane states 5、L4 transport 4、L5 counters 3，加 12 個 cover）
- Functional coverage：`vip/usb4/usb4_link_pkg.sv` 的 `usb4_coverage`（cg_lane 轉移、cg_pkt 輸出封包種類、cg_err 錯誤 / 事件）
- Scoreboard：`usb4_scoreboard` 逐 clock 預測兩條 lane 與每個輸出 word（training、CLx、bonding、FEC、control response、重送、Notification、forward、Credit Grant、12 個 counter）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/USB4-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py USB4-VIP && python3 smoke/smoke_run.py USB4-VIP   # L1b
python3 tools/run_uvm_tests.py USB4-VIP       # UVM（Verilator），期望 SB_PASS
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 行為級 model 以每 clock 一個 ordered set 或一個 32-bit word 建模，計時器縮短；不含 PHY 層（PAM / 64b66b / 128b132b 編碼、sideband 波形）。

---
*文件版本：v1.8.0*
