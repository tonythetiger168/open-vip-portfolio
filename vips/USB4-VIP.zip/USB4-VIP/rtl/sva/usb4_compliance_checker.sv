// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// USB4 Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 19
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
// L4=Protocol-specific rules
`ifndef USB4_COMPLIANCE_CHECKER_SV
`define USB4_COMPLIANCE_CHECKER_SV

module usb4_compliance_checker (usb_vip_if vif);
  import uvm_pkg::*;
  import usb_vip_pkg::*;
  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_usb4_sbtx_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sbtx_valid |-> ##[1:4] vif.sbrx_valid; endproperty
  assert_p_usb4_sbtx_valid: assert property(p_usb4_sbtx_valid) l1_pass[0]++; else begin `uvm_warning("USB4_L1", "Sideband TX valid failed"); l1_fail[0]++; end
  cover_p_usb4_sbtx_valid: cover property(p_usb4_sbtx_valid);

  property p_usb4_domain_id; @(posedge vif.clk) disable iff (!vif.rst_n) vif.domain_id <= 4'd15; endproperty
  assert_p_usb4_domain_id: assert property(p_usb4_domain_id) l1_pass[1]++; else begin `uvm_warning("USB4_L1", "Domain 0-15 failed"); l1_fail[1]++; end
  cover_p_usb4_domain_id: cover property(p_usb4_domain_id);

  property p_usb4_path; @(posedge vif.clk) disable iff (!vif.rst_n) vif.path_id <= 8'd255; endproperty
  assert_p_usb4_path: assert property(p_usb4_path) l1_pass[2]++; else begin `uvm_warning("USB4_L1", "Path 0-255 failed"); l1_fail[2]++; end
  cover_p_usb4_path: cover property(p_usb4_path);

  property p_usb4_router_config; @(posedge vif.clk) disable iff (!vif.rst_n) vif.router_config |-> vif.domain_id <= 4'd15; endproperty
  assert_p_usb4_router_config: assert property(p_usb4_router_config) l1_pass[3]++; else begin `uvm_warning("USB4_L1", "Router config valid failed"); l1_fail[3]++; end
  cover_p_usb4_router_config: cover property(p_usb4_router_config);


  // ===== L2: Full Protocol (6 SVAs) =====
  property p_usb4_tunnel_usb3; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tunnel_usb3 |-> vif.link_up; endproperty
  assert_p_usb4_tunnel_usb3: assert property(p_usb4_tunnel_usb3) l2_pass[0]++; else begin `uvm_warning("USB4_L2", "USB3 tunnel failed"); l2_fail[0]++; end
  cover_p_usb4_tunnel_usb3: cover property(p_usb4_tunnel_usb3);

  property p_usb4_tunnel_dp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tunnel_dp |-> vif.link_up; endproperty
  assert_p_usb4_tunnel_dp: assert property(p_usb4_tunnel_dp) l2_pass[1]++; else begin `uvm_warning("USB4_L2", "DP tunnel failed"); l2_fail[1]++; end
  cover_p_usb4_tunnel_dp: cover property(p_usb4_tunnel_dp);

  property p_usb4_tunnel_pcie; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tunnel_pcie |-> vif.link_up; endproperty
  assert_p_usb4_tunnel_pcie: assert property(p_usb4_tunnel_pcie) l2_pass[2]++; else begin `uvm_warning("USB4_L2", "PCIe tunnel failed"); l2_fail[2]++; end
  cover_p_usb4_tunnel_pcie: cover property(p_usb4_tunnel_pcie);

  property p_usb4_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sbtx_valid |-> !$isunknown(vif.sbtx_data); endproperty
  assert_p_usb4_no_x: assert property(p_usb4_no_x) l2_pass[3]++; else begin `uvm_warning("USB4_L2", "No X when valid failed"); l2_fail[3]++; end
  cover_p_usb4_no_x: cover property(p_usb4_no_x);

  property p_usb4_cl0; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cl_state == 3'b000 |-> vif.link_up; endproperty
  assert_p_usb4_cl0: assert property(p_usb4_cl0) l2_pass[4]++; else begin `uvm_warning("USB4_L2", "CL0 active failed"); l2_fail[4]++; end
  cover_p_usb4_cl0: cover property(p_usb4_cl0);

  property p_usb4_cl1; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cl_state == 3'b001 |-> vif.link_up == 0; endproperty
  assert_p_usb4_cl1: assert property(p_usb4_cl1) l2_pass[5]++; else begin `uvm_warning("USB4_L2", "CL1 low power failed"); l2_fail[5]++; end
  cover_p_usb4_cl1: cover property(p_usb4_cl1);


  // ===== L3: Advanced Features (4 SVAs) =====
  property p_usb4_pm; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_usb4_pm: assert property(p_usb4_pm) l3_pass[0]++; else begin `uvm_warning("USB4_L3", "Power management failed"); l3_fail[0]++; end
  cover_p_usb4_pm: cover property(p_usb4_pm);

  property p_usb4_drd; @(posedge vif.clk) disable iff (!vif.rst_n) vif.drd |-> vif.role inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_usb4_drd: assert property(p_usb4_drd) l3_pass[1]++; else begin `uvm_warning("USB4_L3", "DRD role failed"); l3_fail[1]++; end
  cover_p_usb4_drd: cover property(p_usb4_drd);

  property p_usb4_bandwidth; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bw_alloc <= 8'd100; endproperty
  assert_p_usb4_bandwidth: assert property(p_usb4_bandwidth) l3_pass[2]++; else begin `uvm_warning("USB4_L3", "Bandwidth allocation failed"); l3_fail[2]++; end
  cover_p_usb4_bandwidth: cover property(p_usb4_bandwidth);

  property p_usb4_err_inject; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err_inject |-> vif.link_up == 1; endproperty
  assert_p_usb4_err_inject: assert property(p_usb4_err_inject) l3_pass[3]++; else begin `uvm_warning("USB4_L3", "Error injection failed"); l3_fail[3]++; end
  cover_p_usb4_err_inject: cover property(p_usb4_err_inject);


  // ---------------- L4: USB4 protocol-specific rules (5) ----------------
  // L4-1: no TX block start before link ready
  property p_usb4_l4_blk_link; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe4_tx_blk_start |-> vif.pipe4_link_ready; endproperty
  assert_p_usb4_l4_blk_link: assert property(p_usb4_l4_blk_link) l4_pass[0]++; else begin `uvm_warning("USB4_L4", "TX block before link ready"); l4_fail[0]++; end
  cover_p_usb4_l4_blk_link: cover property(p_usb4_l4_blk_link);

  // L4-2: RX data carries control sync header
  property p_usb4_l4_rx_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe4_link_ready && vif.pipe4_rx_valid |-> vif.pipe4_rx_sync_hdr == 4'b1010; endproperty
  assert_p_usb4_l4_rx_sync: assert property(p_usb4_l4_rx_sync) l4_pass[1]++; else begin `uvm_warning("USB4_L4", "RX sync header invalid"); l4_fail[1]++; end
  cover_p_usb4_l4_rx_sync: cover property(p_usb4_l4_rx_sync);

  // L4-3: tunneled traffic only in CL0 adapter state
  property p_usb4_l4_tunnel_cl0; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.tunnel_usb3 || vif.tunnel_pcie || vif.tunnel_dp) |-> vif.cl_state == 3'b000; endproperty
  assert_p_usb4_l4_tunnel_cl0: assert property(p_usb4_l4_tunnel_cl0) l4_pass[2]++; else begin `uvm_warning("USB4_L4", "Tunneled traffic outside CL0"); l4_fail[2]++; end
  cover_p_usb4_l4_tunnel_cl0: cover property(p_usb4_l4_tunnel_cl0);

  // L4-4: tunneled data CRC32 checked clean at EOP
  property p_usb4_l4_crc32; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid && vif.mac_eop && vif.mac_frame_num > 0 |-> !vif.crc32_error; endproperty
  assert_p_usb4_l4_crc32: assert property(p_usb4_l4_crc32) l4_pass[3]++; else begin `uvm_warning("USB4_L4", "Tunneled CRC32 error"); l4_fail[3]++; end
  cover_p_usb4_l4_crc32: cover property(p_usb4_l4_crc32);

  // L4-5: link ready within 16 cycles after reset release
  property p_usb4_l4_link_bringup; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.rst_n) |-> ##[1:16] vif.pipe4_link_ready; endproperty
  assert_p_usb4_l4_link_bringup: assert property(p_usb4_l4_link_bringup) l4_pass[4]++; else begin `uvm_warning("USB4_L4", "Link bring-up timeout"); l4_fail[4]++; end
  cover_p_usb4_l4_link_bringup: cover property(p_usb4_l4_link_bringup);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l1_hit=0, l2_hit=0, l3_hit=0;
    int l4_total=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("USB4_RPT", $sformatf("=== USB4 Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("USB4_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("USB4_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("USB4_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("USB4_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("USB4_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end

endmodule
`endif
