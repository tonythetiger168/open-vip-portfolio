// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_usb4_tb.sv -- self-checking functional test for the USB4 link model
// (tb/usb4_smoke_model.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py USB4-VIP
//
// Model contract (from tb/usb4_smoke_model.sv), one packet per rx_valid clock
// (types: 0 CTRL, 1 DATA, 2 TUNNELED, 3 TIME_SYNC):
//   * CLd -> Training on the first inbound packet unless link_disable;
//     Training needs 4 packets with the SLOS sync header (0x5) to reach CL0,
//     announced by a CTRL packet with sync header 0x5. Training without SLOS
//     for 256 clocks, or link_disable, returns to CLd.
//   * CL0: CTRL echoed with the sync header inverted; DATA with good CRC is
//     looped back with data+1, with bad CRC answered by CTRL 0xEE and
//     err_count++; TUNNELED forwarded while credit remains (credit--,
//     tun_pkt_count++), dropped with err_count++ at zero credit; TIME_SYNC
//     reflected and returns one credit (max 15). Reset credit is 8.
//   * CL0 idle for 256 clocks -> low power; inbound traffic wakes it to CL0;
//     link_disable from any state -> CLd.

module func_usb4_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam logic [2:0] CTRL = 0, DATA = 1, TUN = 2, TSYNC = 3;
  localparam logic [2:0] CLD = 0, TRAIN = 1, CL0 = 2, LOWP = 3;
  localparam logic [3:0] SLOS = 4'h5;
  int checks = 0, fails = 0;

  logic       clk = 1'b0, rst_n = 1'b0, rx_valid = 1'b0, crc_ok = 1'b1, dis = 1'b0;
  logic [2:0] rx_type = '0;
  logic [3:0] rx_sh = '0;
  logic [7:0] rx_data = '0;
  wire  [2:0] lstate, tx_type;
  wire        ready, tx_valid;
  wire  [3:0] tx_sh, credit;
  wire  [7:0] tx_data, tun_cnt, err_cnt;

  always #5 clk = ~clk;

  usb4_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .rx_valid(rx_valid), .rx_pkt_type(rx_type), .rx_sync_hdr(rx_sh),
    .rx_data(rx_data), .rx_crc_ok(crc_ok), .link_disable(dis), .link_state(lstate),
    .link_ready(ready), .tx_valid(tx_valid), .tx_pkt_type(tx_type), .tx_sync_hdr(tx_sh),
    .tx_data(tx_data), .credit(credit), .tun_pkt_count(tun_cnt), .err_count(err_cnt)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  typedef struct packed { logic [2:0] t; logic [3:0] sh; logic [7:0] d; } pkt_t;
  pkt_t txq[$];
  always @(posedge clk) if (tx_valid === 1'b1) txq.push_back('{tx_type, tx_sh, tx_data});

  task automatic rx(input [2:0] t, input [3:0] sh = 4'hA, input [7:0] d = 0, input bit ok = 1);
    @(negedge clk);
    rx_valid = 1; rx_type = t; rx_sh = sh; rx_data = d; crc_ok = ok;
    @(negedge clk);
    rx_valid = 0; crc_ok = 1;
  endtask

  task automatic idle(input int n); repeat (n) @(negedge clk); endtask

  task automatic train();
    rx(CTRL);                       // activity: CLd -> Training
    repeat (4) rx(CTRL, SLOS);
    idle(2);
  endtask

  int e0, n0;

  initial begin
    idle(2);
    rst_n = 1;
    idle(2);
    chk(lstate == CLD && !ready && credit == 8, "CLd after reset with 8 tunnel credits");

    // disabled adapter ignores traffic
    dis = 1;
    rx(CTRL); idle(2);
    chk(lstate == CLD, "link_disable keeps the link in CLd");
    dis = 0;

    // training
    rx(CTRL); idle(2);
    chk(lstate == TRAIN, "inbound activity starts training");
    rx(CTRL, 4'h3); rx(CTRL, 4'h3);
    repeat (3) rx(CTRL, SLOS);
    idle(2);
    chk(lstate == TRAIN, "three SLOS headers are not enough");
    txq.delete();
    rx(CTRL, SLOS); idle(2);
    chk(lstate == CL0 && ready, "fourth SLOS header: CL0, link_ready");
    chk(txq.size() == 1 && txq[0].t == CTRL && txq[0].sh == SLOS, "CL0 entry announced with a CTRL packet");

    // packet handling
    txq.delete();
    rx(CTRL, 4'b1010, 8'h3C); idle(1);
    chk(txq.size() == 1 && txq[0].t == CTRL && txq[0].sh == 4'b0101 && txq[0].d == 8'h3C,
        "CTRL echoed with the sync header inverted");
    rx(DATA, 4'h9, 8'h41); idle(1);
    chk(txq.size() == 2 && txq[1].t == DATA && txq[1].d == 8'h42 && txq[1].sh == 4'h9,
        "DATA with good CRC looped back with data+1");
    rx(DATA, 4'h9, 8'hFF); idle(1);
    chk(txq[2].d == 8'h00, "loopback data wraps at 0xFF");
    e0 = err_cnt;
    rx(DATA, 4'h9, 8'h41, 0); idle(1);
    chk(txq.size() == 4 && txq[3].t == CTRL && txq[3].d == 8'hEE && err_cnt == e0 + 1,
        "DATA with bad CRC answered by CTRL 0xEE, err_count++");

    // tunneled path credit flow
    txq.delete();
    for (int i = 0; i < 8; i++) rx(TUN, 4'h2, i);
    idle(1);
    chk(credit == 0 && tun_cnt == 8 && txq.size() == 8 && txq[7].t == TUN && txq[7].d == 7,
        "eight tunneled packets forwarded, credits used up");
    e0 = err_cnt;
    rx(TUN, 4'h2, 8'h99); idle(1);
    chk(txq.size() == 8 && err_cnt == e0 + 1 && tun_cnt == 8, "no credit: tunneled packet dropped, err_count++");
    rx(TSYNC, 4'h6); idle(1);
    chk(credit == 1 && txq.size() == 9 && txq[8].t == TSYNC && txq[8].sh == 4'h6,
        "TIME_SYNC reflected and returns a credit");
    rx(TUN, 4'h2, 8'h55); idle(1);
    chk(txq.size() == 10 && txq[9].d == 8'h55 && credit == 0, "returned credit lets one more packet through");
    repeat (20) rx(TSYNC);
    idle(1);
    chk(credit == 15, "credit saturates at 15");

    // idle -> low power -> wake
    idle(250);
    chk(lstate == CL0, "CL0 holds for 250 idle clocks");
    idle(10);
    chk(lstate == LOWP && !ready, "CL0 idle 256 clocks: low power");
    txq.delete();
    rx(DATA, 4'h1, 8'h10); idle(2);
    chk(lstate == CL0 && ready, "inbound traffic wakes the link to CL0");
    chk(txq.size() == 0, "the wake-up packet itself is not processed");

    // disable from CL0 and from low power
    dis = 1; idle(2);
    chk(lstate == CLD && !ready, "link_disable in CL0 -> CLd");
    dis = 0;
    train();
    chk(lstate == CL0, "retrained");
    idle(260);
    dis = 1; idle(2);
    chk(lstate == CLD, "link_disable in low power -> CLd");
    dis = 0;

    // training timeout and disable during training
    rx(CTRL); idle(250);
    chk(lstate == TRAIN, "training waits for SLOS");
    idle(10);
    chk(lstate == CLD, "training timeout returns to CLd");
    rx(CTRL); idle(2);
    dis = 1; idle(2);
    chk(lstate == CLD, "link_disable aborts training");
    dis = 0;

    // reset
    train();
    rx(TUN); rx(DATA, 0, 0, 0);
    @(negedge clk); rst_n = 0;
    @(negedge clk); rst_n = 1;
    chk(lstate == CLD && !ready && credit == 8 && tun_cnt == 0 && err_cnt == 0 && !tx_valid,
        "reset: CLd, credits and counters restored");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
