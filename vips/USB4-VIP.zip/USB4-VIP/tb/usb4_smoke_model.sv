// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Smoke-target minimal behavioral model: USB4 link transaction FSM.
// Covers CLd -> Training (SLOS-style sync-header lock) -> CL0, tunneled
// packet credit accounting, control/data packet echo with CRC checking,
// and link-disable handling. Plain ANSI ports only (no interfaces) so the
// L1b smoke harness can build it directly with iverilog.

module usb4_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rx_valid,         // inbound USB4 packet valid
  input  logic [2:0]  rx_pkt_type,      // 0=CTRL 1=DATA 2=TUNNELED 3=TIME_SYNC
  input  logic [3:0]  rx_sync_hdr,      // 128b/132b-style sync header
  input  logic [7:0]  rx_data,          // payload low byte
  input  logic        rx_crc_ok,        // packet CRC result
  input  logic        link_disable,     // adapter requests CLd
  output logic [2:0]  link_state,       // 0=CLd 1=TRAINING 2=CL0 3=LOW_POWER
  output logic        link_ready,       // link is in CL0
  output logic        tx_valid,         // outbound packet strobe
  output logic [2:0]  tx_pkt_type,      // echo / response packet type
  output logic [3:0]  tx_sync_hdr,      // outbound sync header
  output logic [7:0]  tx_data,          // outbound payload low byte
  output logic [3:0]  credit,           // remaining tunneled-path credits
  output logic [7:0]  tun_pkt_count,    // tunneled packets forwarded
  output logic [7:0]  err_count         // packets dropped on bad CRC
);

  localparam logic [2:0] PKT_CTRL      = 3'd0;
  localparam logic [2:0] PKT_DATA      = 3'd1;
  localparam logic [2:0] PKT_TUNNELED  = 3'd2;
  localparam logic [2:0] PKT_TIME_SYNC = 3'd3;

  localparam logic [2:0] LS_CLD      = 3'd0;
  localparam logic [2:0] LS_TRAINING = 3'd1;
  localparam logic [2:0] LS_CL0      = 3'd2;
  localparam logic [2:0] LS_LOW_PWR  = 3'd3;

  localparam logic [3:0] SLOS_PAT = 4'h5;   // training ordered-set marker

  logic [2:0] state;
  logic [3:0] slos_cnt;
  logic [7:0] tmo;

  always @(posedge clk) begin
    if (!rst_n) begin
      state          <= LS_CLD;
      slos_cnt       <= 4'd0;
      tmo            <= 8'd0;
      link_state     <= LS_CLD;
      link_ready     <= 1'b0;
      tx_valid       <= 1'b0;
      tx_pkt_type    <= PKT_CTRL;
      tx_sync_hdr    <= 4'd0;
      tx_data        <= 8'd0;
      credit         <= 4'd8;      // 8 tunneled-path buffers
      tun_pkt_count  <= 8'd0;
      err_count      <= 8'd0;
    end else begin
      tx_valid <= 1'b0;
      tmo      <= tmo + 8'd1;
      case (state)
        // ---- CLd: link down, wait for enable + inbound activity ----
        LS_CLD: begin
          link_state <= LS_CLD;
          link_ready <= 1'b0;
          slos_cnt   <= 4'd0;
          if (!link_disable && rx_valid) begin
            state <= LS_TRAINING;
            tmo   <= 8'd0;
          end
        end

        // ---- TRAINING: lock onto sync-header marker pattern ----
        LS_TRAINING: begin
          link_state <= LS_TRAINING;
          if (rx_valid && (rx_sync_hdr == SLOS_PAT)) begin
            tmo <= 8'd0;
            if (slos_cnt != 4'hF)
              slos_cnt <= slos_cnt + 4'd1;
            if (slos_cnt >= 4'd3) begin
              state      <= LS_CL0;          // symbol lock achieved
              link_ready <= 1'b1;
              slos_cnt   <= 4'd0;
              tx_valid   <= 1'b1;            // announce with a ctrl packet
              tx_pkt_type <= PKT_CTRL;
              tx_sync_hdr <= SLOS_PAT;
            end
          end else if (tmo == 8'hFF || link_disable) begin
            state <= LS_CLD;                 // training failed / disabled
          end
        end

        // ---- CL0: packet flow ----
        LS_CL0: begin
          link_state <= LS_CL0;
          link_ready <= 1'b1;
          if (link_disable) begin
            state      <= LS_CLD;
            link_ready <= 1'b0;
          end else if (rx_valid) begin
            tmo <= 8'd0;
            case (rx_pkt_type)
              PKT_CTRL: begin                 // ctrl packets echoed inverted
                tx_valid    <= 1'b1;
                tx_pkt_type <= PKT_CTRL;
                tx_sync_hdr <= ~rx_sync_hdr;
                tx_data     <= rx_data;
              end
              PKT_DATA: begin
                tx_valid    <= 1'b1;
                if (rx_crc_ok) begin
                  tx_pkt_type <= PKT_DATA;    // loop payload back + 1
                  tx_data     <= rx_data + 8'd1;
                  tx_sync_hdr <= rx_sync_hdr;
                end else begin
                  tx_pkt_type <= PKT_CTRL;    // CRC error: ctrl NACK
                  tx_data     <= 8'hEE;
                  tx_sync_hdr <= rx_sync_hdr;
                  err_count   <= err_count + 8'd1;
                end
              end
              PKT_TUNNELED: begin
                if (credit != 4'd0) begin     // forward while credit remains
                  credit        <= credit - 4'd1;
                  tun_pkt_count <= tun_pkt_count + 8'd1;
                  tx_valid      <= 1'b1;
                  tx_pkt_type   <= PKT_TUNNELED;
                  tx_data       <= rx_data;
                  tx_sync_hdr   <= rx_sync_hdr;
                end else begin
                  err_count <= err_count + 8'd1;   // no credit: drop
                end
              end
              PKT_TIME_SYNC: begin            // sync: reflect header + credit
                tx_valid    <= 1'b1;
                tx_pkt_type <= PKT_TIME_SYNC;
                tx_sync_hdr <= rx_sync_hdr;
                if (credit != 4'hF)
                  credit <= credit + 4'd1;    // periodic credit return
              end
              default: ;
            endcase
          end else if (tmo == 8'hFF) begin
            state <= LS_LOW_PWR;             // idle: enter low power
          end
        end

        // ---- LOW_POWER: any activity or disable returns control ----
        LS_LOW_PWR: begin
          link_state <= LS_LOW_PWR;
          link_ready <= 1'b0;
          if (link_disable) begin
            state <= LS_CLD;
          end else if (rx_valid) begin
            state <= LS_CL0;                 // wake on inbound traffic
            tmo   <= 8'd0;
          end
        end

        default: state <= LS_CLD;
      endcase
    end
  end

endmodule
