// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the USB4 router lane adapter +
// transport layer model usb4_smoke_model (tb/usb4_smoke_model.sv). The
// bench is the far-end router: it trains both lanes, sends control and
// tunneled packets (with HEC / CRC / length / RS-FEC errors), and checks
// every ordered set and packet the adapter sends: training answers, Gen 3
// selection, timeouts, config-space reads and writes, retransmissions,
// notifications, path forwarding with HopID translation, credit grants,
// buffer overflow, RS-FEC correction and retraining, lane bonding and CLx.
// Run: python3 tools/run_func_tests.py USB4-VIP

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [1:0]  lane_det = 2'b00;
  logic        gen3_cap = 1'b1;
  logic        os_valid = 1'b0, os_lane = 1'b0, os_gen3 = 1'b0;
  logic [2:0]  os_kind = 3'd0;
  logic        w_valid = 1'b0, w_first = 1'b0, w_last = 1'b0;
  logic [31:0] w_data = 32'h0;
  logic [2:0]  w_sym_err = 3'd0;
  logic        out_busy = 1'b0;
  wire  [2:0]  ls0, ls1, tx_os_kind;
  wire         gen3, tx_os_valid, tx_os_lane, tx_valid, tx_first, tx_last;
  wire  [1:0]  width;
  wire  [31:0] tx_data;
  wire  [7:0]  hec_err, len_err, crc_err, ovf_err, unk_hop, fec_corr, fec_unc, fwd_cnt, dup_cnt, notif_cnt,
               train_tmo, retrains;

  always #5 clk = ~clk;

  usb4_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .lane_det(lane_det), .gen3_cap(gen3_cap), .os_valid(os_valid), .os_lane(os_lane),
    .os_kind(os_kind), .os_gen3(os_gen3), .w_valid(w_valid), .w_first(w_first), .w_last(w_last), .w_data(w_data),
    .w_sym_err(w_sym_err), .out_busy(out_busy), .ls0(ls0), .ls1(ls1), .gen3(gen3), .width(width),
    .tx_os_valid(tx_os_valid), .tx_os_lane(tx_os_lane), .tx_os_kind(tx_os_kind), .tx_valid(tx_valid),
    .tx_first(tx_first), .tx_last(tx_last), .tx_data(tx_data), .hec_err(hec_err), .len_err(len_err),
    .crc_err(crc_err), .ovf_err(ovf_err), .unk_hop(unk_hop), .fec_corr(fec_corr), .fec_unc(fec_unc),
    .fwd_cnt(fwd_cnt), .dup_cnt(dup_cnt), .notif_cnt(notif_cnt), .train_tmo(train_tmo), .retrains(retrains));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  localparam logic [2:0] CLD = 0, LOCK = 1, TS1S = 2, TS2S = 3, CL0 = 4, CLX = 5;
  localparam logic [2:0] SLOS = 0, TS1 = 1, TS2 = 2, CLREQ = 3, OCLD = 4, WAKE = 5, ACK = 6, NAK = 7;
  localparam logic [3:0] RD = 1, RDR = 2, WR = 3, WRR = 4, NOTIF = 5, NACK = 6, CG = 4'hC;

  // ------------------------------------------------------------ encodings
  function automatic logic [7:0] hec8(input logic [23:0] d);
    logic [7:0] c;
    c = 8'h00;
    for (int i = 23; i >= 0; i--) c = (c[7] ^ d[i]) ? ({c[6:0], 1'b0} ^ 8'h07) : {c[6:0], 1'b0};
    return c;
  endfunction
  function automatic logic [31:0] crc32w(input logic [31:0] c0, input logic [31:0] w);
    logic [31:0] c;
    c = c0;
    for (int i = 31; i >= 0; i--) c = (c[31] ^ w[i]) ? ({c[30:0], 1'b0} ^ 32'h04C1_1DB7) : {c[30:0], 1'b0};
    return c;
  endfunction
  function automatic logic [31:0] mkhdr(input logic [3:0] pdf, input logic [10:0] hop, input int nw);
    logic [23:0] u;
    u = {pdf, 1'b0, hop, 8'(4 * nw)};
    return {u, hec8(u)};
  endfunction

  // ------------------------------------------------------------ capture
  int          os_q [$];                 // lane * 8 + kind
  logic [31:0] cap [0:8191];
  int          ncap = 0;
  int          pk_s [$];                 // first word index of each packet
  int          pk_n [$];                 // words (header included)
  int          cur_s = 0, cyc = 0, bad_frame = 0, tx_outside = 0;
  bit          in_f = 0;
  always @(posedge clk) begin
    cyc++;
    if (tx_os_valid === 1'b1) os_q.push_back(int'(tx_os_lane) * 8 + int'(tx_os_kind));
    if (tx_valid === 1'b1) begin
      if (ls0 != CL0) tx_outside++;
      if (tx_first) begin
        if (in_f) bad_frame++;
        in_f = 1; cur_s = ncap;
      end
      else if (!in_f) bad_frame++;
      cap[ncap % 8192] = tx_data; ncap++;
      if (tx_last) begin in_f = 0; pk_s.push_back(cur_s); pk_n.push_back(ncap - cur_s); end
    end
  end

  // ------------------------------------------------------------ stimulus
  task automatic idle(input int n); repeat (n) @(negedge clk); endtask
  task automatic os(input int lane, input logic [2:0] k, input bit g = 0);
    @(negedge clk);
    os_valid = 1'b1; os_lane = 1'(lane); os_kind = k; os_gen3 = g;
    @(negedge clk);
    os_valid = 1'b0;
  endtask
  task automatic word(input logic [31:0] d, input bit f, input bit l, input int se = 0);
    w_valid = 1'b1; w_first = f; w_last = l; w_data = d; w_sym_err = 3'(se);
    @(negedge clk);
    w_valid = 1'b0; w_first = 1'b0; w_last = 1'b0; w_sym_err = 3'd0;
  endtask
  // a packet: header + n payload words (pl[]); se_at: word with se symbol errors
  logic [31:0] pl [0:17];
  logic [31:0] wd [0:7];
  task automatic pkt(input logic [3:0] pdf, input logic [10:0] hop, input int n, input int se_at = -1,
                     input int se = 0, input bit bad_hec = 0, input int nhdr = -1);
    logic [31:0] h;
    h = mkhdr(pdf, hop, (nhdr >= 0) ? nhdr : n);
    if (bad_hec) h[0] = ~h[0];
    word(h, 1, n == 0, (se_at == 0) ? se : 0);
    for (int i = 0; i < n; i++) word(pl[i], 0, i == n - 1, (se_at == i + 1) ? se : 0);
    idle(1);
  endtask
  // control request: route, {seq, cnt, addr}, data, CRC
  task automatic ctrl(input logic [3:0] pdf, input int seq, input int addr, input int cnt, input int nd = 0,
                      input bit bad_crc = 0, input logic [31:0] route = 32'h0);
    logic [31:0] c;
    int n;
    pl[0] = route; pl[1] = {2'(seq), 8'h0, 6'(cnt), 16'(addr)}; n = 2;
    for (int i = 0; i < nd; i++) begin pl[n] = wd[i]; n++; end
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < n; i++) c = crc32w(c, pl[i]);
    pl[n] = ~c ^ 32'(bad_crc); n++;
    pkt(pdf, 11'd0, n);
  endtask

  // ------------------------------------------------------------ checks on what was sent
  task automatic expect_os(input string tag, input int lane, input logic [2:0] k);
    chk(os_q.size() > 0 && os_q[0] == lane * 8 + int'(k),
        $sformatf("%s: ordered set lane %0d kind %0d (got %0d, %0d queued)", tag, lane, k,
                  os_q.size() > 0 ? os_q[0] : -1, os_q.size()));
    if (os_q.size() > 0) void'(os_q.pop_front());
  endtask
  task automatic wait_pkts(input int n, input int max = 200);
    int t;
    t = 0;
    while (pk_s.size() < n && t < max) begin @(negedge clk); t++; end
  endtask
  // next packet: header fields and words w0.. (exp[]) of n payload words
  logic [31:0] exp [0:17];
  logic [31:0] got_w [0:17];
  task automatic expect_pkt(input string tag, input logic [3:0] pdf, input logic [10:0] hop, input int n,
                            input bit chk_words = 1);
    logic [31:0] h;
    int s, m;
    bit ok;
    wait_pkts(1);
    if (pk_s.size() == 0) begin chk(0, {tag, ": no packet"}); return; end
    s = pk_s[0]; m = pk_n[0];
    void'(pk_s.pop_front()); void'(pk_n.pop_front());
    h = cap[s % 8192];
    for (int i = 0; i < 18; i++) got_w[i] = (i < m - 1) ? cap[(s + 1 + i) % 8192] : 32'h0;
    ok = h[7:0] == hec8(h[31:8]) && h[31:28] == pdf && h[26:16] == hop && int'(h[15:8]) == 4 * n && m == n + 1;
    if (chk_words) for (int i = 0; i < n; i++) if (got_w[i] != exp[i]) ok = 0;
    chk(ok, $sformatf("%s: header %08h (want PDF %0h hop %03h %0d words), %0d words, w0 %08h w1 %08h w2 %08h",
                      tag, h, pdf, hop, n, m - 1, got_w[0], got_w[1], got_w[2]));
  endtask
  // control response: route 0, header word, data (exp[2..]), CRC
  task automatic expect_ctrl(input string tag, input logic [3:0] pdf, input logic [31:0] w1, input int nd);
    logic [31:0] c;
    exp[0] = 32'h0; exp[1] = w1;
    expect_pkt(tag, pdf, 11'd0, nd + 3, 0);
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < nd + 2; i++) c = crc32w(c, got_w[i]);
    chk(got_w[0] == 32'h0 && got_w[1] == w1 && got_w[nd + 2] == ~c,
        $sformatf("%s: route %08h word1 %08h (want %08h), CRC %08h (want %08h)", tag, got_w[0], got_w[1], w1,
                  got_w[nd + 2], ~c));
    for (int i = 0; i < nd; i++)
      chk(got_w[2 + i] == exp[2 + i], $sformatf("%s: data %0d = %08h (want %08h)", tag, i, got_w[2 + i], exp[2 + i]));
  endtask
  task automatic expect_notif(input string tag, input int code);
    logic [31:0] c;
    expect_pkt(tag, NOTIF, 11'd0, 3, 0);
    c = crc32w(crc32w(32'hFFFF_FFFF, 32'h0), {8'(code), 24'h0});
    chk(got_w[0] == 32'h0 && got_w[1] == {8'(code), 24'h0} && got_w[2] == ~c,
        $sformatf("%s: Notification code %0d (got %08h)", tag, code, got_w[1]));
  endtask
  task automatic expect_cg(input string tag, input logic [10:0] hop, input int total);
    exp[0] = {24'h0, 8'(total)};
    expect_pkt({tag, ": Credit Grant"}, CG, hop, 1);
  endtask
  task automatic expect_none(input string tag, input int t = 30);
    idle(t);
    chk(pk_s.size() == 0, $sformatf("%s: nothing sent (%0d packets)", tag, pk_s.size()));
    pk_s.delete(); pk_n.delete();
  endtask
  function automatic logic [31:0] w1of(input int seq, input int addr, input int cnt);
    return {2'(seq), 8'h0, 6'(cnt), 16'(addr)};
  endfunction

  // full training of one lane
  task automatic train(input int lane, input bit g = 0);
    os(lane, SLOS); os(lane, SLOS);
    os(lane, TS1, g); os(lane, TS1, g);
    os(lane, TS2); os(lane, TS2);
    idle(1);
    expect_os("train SLOS", lane, SLOS);
    expect_os("train TS1", lane, TS1);
    expect_os("train TS2", lane, TS2);
  endtask
  task automatic rd(input string tag, input int seq, input int addr, input int cnt);
    ctrl(RD, seq, addr, cnt);
    expect_ctrl(tag, RDR, w1of(seq, addr, cnt), cnt);
  endtask
  task automatic wr(input string tag, input int seq, input int addr, input int cnt);
    for (int i = 0; i < cnt; i++) wd[i] = exp[2 + i];
    ctrl(WR, seq, addr, cnt, cnt);
    expect_ctrl(tag, WRR, w1of(seq, addr, cnt), 0);
  endtask

  int seq = 0, n0, n1, t;

  initial begin
    idle(2);
    chk(ls0 == CLD && ls1 == CLD && !tx_valid && !tx_os_valid && width == 2'd1 && hec_err == 0 && fwd_cnt == 0,
        "in reset: both lanes CLd, nothing sent");
    rst_n = 1'b1;
    idle(3);
    chk(ls0 == CLD && ls1 == CLD, "no lane detected: CLd");

    // ---------------- lane 0 training (Gen 2: far end without Gen 3)
    lane_det = 2'b01;
    idle(2);
    chk(ls0 == LOCK && ls1 == CLD, "lane 0 detected: Lock");
    os(0, SLOS); os(0, TS1); os(0, SLOS);
    chk(ls0 == LOCK, "SLOS interrupted: still Lock");
    os(0, SLOS);
    idle(1);
    chk(ls0 == TS1S, "two SLOS in a row: Training.TS1");
    expect_os("SLOS answered", 0, SLOS);
    os(0, TS1); os(0, TS2); os(0, TS1);
    chk(ls0 == TS1S, "TS1 interrupted: still TS1");
    os(0, TS1);
    idle(1);
    chk(ls0 == TS2S && !gen3, "TS1 without the Gen 3 bit: Gen 2");
    expect_os("TS1 answered", 0, TS1);
    os(0, TS2); os(0, SLOS); os(0, TS2);
    chk(ls0 == TS2S, "TS2 interrupted by SLOS: still TS2");
    os(0, TS1); os(0, TS2);
    idle(1);
    chk(ls0 == CL0 && width == 2'd1, "two TS2 (a late TS1 between them is tolerated): CL0, one lane");
    expect_os("TS2 answered", 0, TS2);
    chk(os_q.size() == 0, "one answer per training step");

    // ---------------- training timeout on lane 1
    lane_det = 2'b11;
    idle(2);
    chk(ls1 == LOCK, "lane 1 detected: Lock");
    os(1, SLOS);
    idle(60);
    chk(ls1 == LOCK && train_tmo == 0, "62 clocks after the last SLOS: still Lock");
    idle(4);
    chk(train_tmo == 8'd1, "64 clocks without progress: training timeout");
    idle(1);
    chk(ls1 == LOCK, "lane still detected: Lock again");
    lane_det = 2'b01;
    idle(2);
    chk(ls1 == CLD, "lane 1 not detected: CLd");

    // ---------------- config space reads / writes
    exp[2] = 32'h0004_AB1D;
    rd("router ID", seq, 0, 1); seq++;
    exp[2] = {24'h0, 1'b0, 1'b0, CLD, CL0};
    rd("status: Gen 2, lane 0 CL0", seq, 2, 1); seq++;
    exp[2] = 32'hDEAD_0001; exp[3] = 32'hDEAD_0002; exp[4] = 32'hDEAD_0003;
    wr("write 3 dwords at 20", seq, 20, 3);
    exp[2] = 32'hDEAD_0001; exp[3] = 32'hDEAD_0002; exp[4] = 32'hDEAD_0003;
    rd("read them back", seq + 1, 20, 3);
    seq += 2;
    exp[2] = 32'h1111_1111; exp[3] = 32'h2222_2222;
    wr("write 2 dwords at 30", seq, 30, 2);
    exp[2] = 32'h5555_5555; exp[3] = 32'h6666_6666;
    for (int i = 0; i < 2; i++) wd[i] = exp[2 + i];
    ctrl(WR, seq, 30, 2, 2);                                      // same sequence number: retransmission
    expect_ctrl("retransmitted Write: stored response", WRR, w1of(seq, 30, 2), 0);
    chk(dup_cnt == 8'd1, "retransmission counted");
    seq++;
    exp[2] = 32'h1111_1111; exp[3] = 32'h2222_2222;
    rd("retransmission did not write", seq, 30, 2);
    ctrl(RD, seq, 30, 2);
    expect_ctrl("retransmitted Read: same data", RDR, w1of(seq, 30, 2), 2);
    seq++;
    exp[2] = 32'hFFFF_FFFF;
    wr("write the router ID", seq, 0, 1); seq++;
    exp[2] = 32'h0004_AB1D;
    rd("router ID is read-only", seq, 0, 1); seq++;
    for (int i = 0; i < 8; i++) exp[2 + i] = 32'h100 + i;
    wr("write 8 dwords at 56", seq, 56, 8); seq++;
    for (int i = 0; i < 8; i++) exp[2 + i] = 32'h100 + i;
    rd("read 8 dwords at 56 (top of the space)", seq, 56, 8); seq++;

    // ---------------- control errors
    n0 = notif_cnt;
    ctrl(RD, seq, 60, 5); expect_notif("read past the end", 2); seq++;
    ctrl(RD, seq, 4, 0);  expect_notif("read of 0 dwords", 2); seq++;
    ctrl(RD, seq, 4, 9);  expect_notif("read of 9 dwords", 2); seq++;
    wd[0] = 32'h1; ctrl(WR, seq, 4, 2, 1); expect_notif("write shorter than its count", 3); seq++;
    ctrl(RD, seq, 4, 1, 1); expect_notif("read with data words", 3); seq++;
    ctrl(4'd7, seq, 4, 1); expect_notif("unsupported PDF", 4); seq++;
    chk(notif_cnt == 8'(n0 + 6), "6 notifications");
    n0 = crc_err;
    ctrl(RD, seq, 0, 1, 0, 1); expect_none("bad CRC: dropped");
    chk(crc_err == 8'(n0 + 1), "CRC error counted");
    ctrl(RD, seq, 0, 1, 0, 0, 32'h0000_0102); expect_none("route string of another router: not answered");
    ctrl(NACK, seq, 0, 0); expect_none("Notification Ack: no answer");
    n0 = hec_err;
    pl[0] = 32'h0; pkt(RD, 11'd0, 3, -1, 0, 1); expect_none("bad HEC: dropped");
    chk(hec_err == 8'(n0 + 1), "HEC error counted");
    n0 = len_err;
    pl[0] = 32'h0; pl[1] = w1of(seq, 0, 1); pl[2] = 32'h0;
    pkt(RD, 11'd0, 3, -1, 0, 0, 4); expect_none("Length says 4 words, 3 sent: dropped");
    word(mkhdr(RD, 11'd0, 18), 1, 0);
    for (int i = 0; i < 18; i++) word(32'h0, 0, i == 17);
    expect_none("18 payload words: too long");
    chk(len_err == 8'(n0 + 2), "length errors counted");

    // ---------------- paths, forwarding, credits
    exp[2] = {1'b1, 4'h0, 11'h123, 5'h0, 11'h010};
    for (int i = 0; i < 1; i++) wd[i] = exp[2];
    ctrl(WR, seq, 8, 1, 1);
    expect_cg("path 0 enabled", 11'h010, 4);
    expect_ctrl("path 0 written", WRR, w1of(seq, 8, 1), 0); seq++;
    exp[2] = {1'b1, 4'hF, 11'h3FF, 5'h1F, 11'h020};               // reserved bits dropped
    wd[0] = exp[2];
    ctrl(WR, seq, 9, 1, 1);
    expect_cg("path 1 enabled", 11'h020, 4);
    expect_ctrl("path 1 written", WRR, w1of(seq, 9, 1), 0); seq++;
    exp[2] = {1'b1, 4'h0, 11'h3FF, 5'h0, 11'h020};
    rd("path entry: reserved bits read 0", seq, 9, 1); seq++;
    for (int i = 0; i < 3; i++) begin pl[i] = 32'hA000 + i; exp[i] = 32'hA000 + i; end
    t = cyc;
    pkt(4'h8, 11'h010, 3);
    expect_pkt("forwarded with HopID 123", 4'h8, 11'h123, 3);
    chk(fwd_cnt == 8'd1, "forward counted");
    expect_cg("buffer released", 11'h010, 5);
    for (int i = 0; i < 2; i++) begin pl[i] = 32'hB000 + i; exp[i] = 32'hB000 + i; end
    pkt(4'h9, 11'h020, 2);
    expect_pkt("path 1: HopID 3FF", 4'h9, 11'h3FF, 2);
    expect_cg("path 1 buffer released", 11'h020, 5);
    n0 = unk_hop;
    pl[0] = 32'h1; pkt(4'h8, 11'h055, 1);
    expect_none("unknown HopID: dropped");
    chk(unk_hop == 8'(n0 + 1), "unknown HopID counted");
    pkt(4'h8, 11'h010, 0);
    exp[0] = 32'h0;
    expect_pkt("header-only packet forwarded", 4'h8, 11'h123, 0);
    expect_cg("header-only buffer released", 11'h010, 6);
    // overflow while the egress is busy
    out_busy = 1'b1;
    n0 = ovf_err;
    for (int k = 0; k < 5; k++) begin pl[0] = 32'hC000 + k; pkt(4'h8, 11'h010, 1); end
    for (int k = 0; k < 4; k++) begin exp[0] = 32'hC000 + k; expect_pkt($sformatf("forward %0d of 5", k), 4'h8, 11'h123, 1); end
    chk(ovf_err == 8'(n0 + 1), "5th packet with 4 buffers held: overflow");
    expect_none("no Credit Grant while the egress is busy", 20);
    ctrl(RD, seq, 0, 1); exp[2] = 32'h0004_AB1D;
    expect_ctrl("control path still works", RDR, w1of(seq, 0, 1), 1); seq++;
    out_busy = 1'b0;
    for (int k = 0; k < 4; k++) expect_cg($sformatf("release %0d", k), 11'h010, 7 + k);
    // rewriting a path resets its credits
    out_busy = 1'b1;
    pl[0] = 32'hD000; pkt(4'h8, 11'h010, 1);
    exp[0] = 32'hD000; expect_pkt("forward before the rewrite", 4'h8, 11'h123, 1);
    wd[0] = {1'b1, 4'h0, 11'h124, 5'h0, 11'h010};
    ctrl(WR, seq, 8, 1, 1);
    expect_cg("path 0 rewritten: credits from 4", 11'h010, 4);
    expect_ctrl("path 0 rewritten", WRR, w1of(seq, 8, 1), 0); seq++;
    out_busy = 1'b0;
    expect_none("the old buffer gives no Credit Grant");
    pl[0] = 32'hD001; pkt(4'h8, 11'h010, 1);
    exp[0] = 32'hD001; expect_pkt("new out HopID 124", 4'h8, 11'h124, 1);
    expect_cg("next credit", 11'h010, 5);
    wd[0] = 32'h0; ctrl(WR, seq, 9, 1, 1);                        // path 1 disabled: no Credit Grant
    expect_ctrl("path 1 disabled", WRR, w1of(seq, 9, 1), 0); seq++;
    pl[0] = 32'h1; pkt(4'h8, 11'h020, 1);
    expect_none("disabled path: dropped");

    // ---------------- Gen 2: any symbol error poisons the packet
    n0 = fec_unc; n1 = fec_corr;
    pl[0] = 32'hE000; pkt(4'h8, 11'h010, 1, 1, 1);
    expect_none("Gen 2 symbol error: packet dropped");
    chk(fec_unc == 8'(n0 + 1) && fec_corr == n1, "Gen 2: no correction");

    // ---------------- retrain lane 0 at Gen 3
    os(0, OCLD);
    idle(1);
    chk(ls0 == LOCK || ls0 == CLD, "CLD ordered set: lane 0 down");
    idle(2);
    train(0, 1);
    chk(ls0 == CL0 && gen3, "TS1 with the Gen 3 bit: Gen 3");
    exp[2] = {24'h0, 1'b1, 1'b0, CLD, CL0};
    rd("status: Gen 3", seq, 2, 1); seq++;
    n0 = fec_unc; n1 = fec_corr;
    pl[0] = 32'hE001; pl[1] = 32'hE002;
    pkt(4'h8, 11'h010, 2, 2, 2);
    exp[0] = 32'hE001; exp[1] = 32'hE002;
    expect_pkt("2 symbol errors corrected", 4'h8, 11'h124, 2);
    expect_cg("corrected packet's buffer", 11'h010, 6);
    pl[0] = 32'hE003; pkt(4'h8, 11'h010, 1, 0, 1);
    exp[0] = 32'hE003; expect_pkt("1 symbol error in the header corrected", 4'h8, 11'h124, 1);
    expect_cg("next buffer", 11'h010, 7);
    chk(fec_corr == 8'(n1 + 2) && fec_unc == n0, "2 corrections, nothing lost");
    for (int k = 0; k < 3; k++) begin pl[0] = 32'hE100 + k; pkt(4'h8, 11'h010, 1, 1, 3); end
    expect_none("3 symbol errors: uncorrectable");
    chk(fec_unc == 8'(n0 + 3) && ls0 == CL0 && retrains == 0, "3 uncorrectable packets: still CL0");
    pl[0] = 32'hE200; pkt(4'h8, 11'h010, 1, 1, 7);
    chk(ls0 == LOCK && retrains == 8'd1, "4th uncorrectable packet: retrain from Lock");
    train(0, 1);
    for (int k = 0; k < 3; k++) begin pl[0] = 32'hE300 + k; pkt(4'h8, 11'h010, 1, 1, 3); end
    chk(ls0 == CL0, "count restarts at CL0 entry");
    gen3_cap = 1'b0;
    os(0, OCLD); idle(3); train(0, 1);
    chk(!gen3, "local port without Gen 3: Gen 2 even if the far end has it");
    gen3_cap = 1'b1;
    os(0, OCLD); idle(3); train(0, 1);
    pk_s.delete(); pk_n.delete();

    // ---------------- lane bonding
    exp[2] = 32'h1;
    wr("bonding enabled", seq, 1, 1); seq++;
    chk(width == 2'd1, "lane 1 down: width 1");
    expect_none("no width change yet", 5);
    lane_det = 2'b11;
    idle(2);
    train(1);
    idle(1);
    chk(width == 2'd2, "both lanes CL0: bonded, width 2");
    expect_notif("width 2", 7);
    exp[2] = {24'h0, 1'b1, 1'b1, CL0, CL0};
    rd("status: bonded", seq, 2, 1); seq++;
    os(1, OCLD);
    idle(1);
    chk(width == 2'd1 && ls1 != CL0, "lane 1 CLD: width 1");
    expect_notif("width back to 1", 7);
    idle(2);
    train(1);
    expect_notif("bonded again", 7);
    exp[2] = 32'h0;
    wr("bonding disabled", seq, 1, 1); seq++;
    chk(width == 2'd1, "bonding disabled: width 1");
    expect_none("no notification without bonding", 10);
    exp[2] = 32'h1;
    wr("bonding on again", seq, 1, 1); seq++;
    expect_notif("bonding on with both lanes up", 7);

    // ---------------- CLx
    os(0, CLREQ);
    idle(1);
    expect_os("CLx disabled: NAK", 0, NAK);
    chk(ls0 == CL0, "still CL0");
    exp[2] = 32'h3;
    wr("CLx enabled", seq, 1, 1); seq++;
    out_busy = 1'b1;
    pl[0] = 32'hF000; pkt(4'h8, 11'h010, 1);
    exp[0] = 32'hF000; expect_pkt("forward holding a buffer", 4'h8, 11'h124, 1);
    os(0, CLREQ);
    idle(1);
    expect_os("buffer held: NAK", 0, NAK);
    out_busy = 1'b0;
    expect_cg("buffer back", 11'h010, 8);
    idle(2);
    os(1, CLREQ);
    idle(1);
    chk(os_q.size() == 0 && ls1 == CL0, "CL_REQ on lane 1: ignored");
    os(0, CLREQ);
    idle(1);
    expect_os("idle: ACK", 0, ACK);
    chk(ls0 == CLX && ls1 == CLX, "both lanes in CLx");
    n0 = fwd_cnt;
    pl[0] = 32'hF100; pkt(4'h8, 11'h010, 1);
    expect_none("CLx: nothing received or sent");
    chk(fwd_cnt == n0, "no forward in CLx");
    os(0, WAKE);
    idle(1);
    chk(ls0 == TS2S && ls1 == CLX, "WAKE on lane 0: Training.TS2");
    os(0, TS2); os(0, TS2); os(1, WAKE); os(1, TS2); os(1, TS2);
    idle(1);
    expect_os("lane 0 back", 0, TS2);
    expect_os("lane 1 back", 1, TS2);
    chk(ls0 == CL0 && ls1 == CL0 && width == 2'd2, "both lanes CL0 again");
    expect_notif("lane 0 alone, then bonded again", 7);
    pl[0] = 32'hF200; pkt(4'h8, 11'h010, 1);
    exp[0] = 32'hF200; expect_pkt("forwarding after CLx", 4'h8, 11'h124, 1);
    expect_cg("after CLx", 11'h010, 9);

    // ---------------- lane 0 lost: queue flushed, link down
    out_busy = 1'b1;
    pl[0] = 32'hF300; pkt(4'h8, 11'h010, 1);
    lane_det = 2'b10;
    idle(2);
    chk(ls0 == CLD && ls1 == CL0, "lane 0 not detected: CLd, lane 1 stays");
    n0 = fwd_cnt;
    pl[0] = 32'hF301; pkt(4'h8, 11'h010, 1);
    chk(fwd_cnt == n0, "lane 0 down: nothing received");
    out_busy = 1'b0;

    // ---------------- reset in the middle
    lane_det = 2'b11;
    idle(3);
    rst_n = 1'b0;
    idle(2);
    chk(ls0 == CLD && ls1 == CLD && fwd_cnt == 0 && hec_err == 0 && fec_unc == 0 && notif_cnt == 0 &&
        retrains == 0 && width == 2'd1 && !gen3, "reset clears the adapter");
    rst_n = 1'b1;
    idle(2);
    pk_s.delete(); pk_n.delete();
    train(0);
    exp[2] = 32'h0;
    rd("reset: path entries cleared", 0, 8, 1);
    chk(bad_frame == 0, "every sent packet framed by first / last");
    chk(tx_outside == 0, "nothing sent outside CL0");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
