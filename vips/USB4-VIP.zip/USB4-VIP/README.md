# USB4 Protocol VIP — Unified Multi-Protocol Verification IP

## 前言概述 (Protocol Overview)

USB4 (40 Gbps) 驗證重點：control packet + tunneled
data block (USB3/PCIe/DP tunneling)、PIPE4 PHY (128-bit data path,
blk_start/sync_hdr)、SB-10B 同步、router 管理
(domain/path/CL 狀態)、adapter layer CL0/CL1、CRC32 校驗。

本 VIP 為 USB 系列統一架構：單一環境涵蓋 7 種協議
(USB 2.0 / 3.0 / 3.1 / 3.2 / USB4 / eUSB2 / USB-PD)，本專案聚焦於 **USB4 Protocol VIP**。

## 架構 (Architecture)

```
top_tb.sv
 ├─ usb_vip_if × 7 (MAC + PHY 雙層, clocking blocks, modports, IF assertions)
 └─ usb_dut (functional DUT model)
     ├─ usb2_dev_ep ×2     USB2/eUSB2 device endpoint: chirp response,
     │                      CRC16 檢查, ACK/STALL/timeout, babble detect
     ├─ usb3_phy_model ×3  PIPE PHY: LTSSM walk→U0, CRC32 check, loopback ACK
     ├─ usb4_phy_model     PIPE4 PHY: link ready, router sideband, loopback
     └─ pd_controller_model PD controller: header decode, Vbus transition
usb_env
 ├─ usb_agent × 7 (usb_sequencer / usb_driver / usb_monitor)
 ├─ usb_scoreboard  expected(drv_ap→exp_imp) vs observed(mon→analysis_imp)
 │                   pairwise compare, n_matches/n_mismatches, UVM_ERROR on mismatch
 ├─ usb_coverage_model × 4 (8 covergroups, 見下)
 └─ *_protocol_checker × 5 (procedural protocol checks + covergroups)
```

Closed loop：driver 依 transaction descriptor 送出 token/data packet
（含 CRC16/CRC32 trailer，data packet 以 `mac_frame_num` 作 sideband byte count），
DUT 依位址/endpoint/CRC 決定 ACK/STALL/timeout/babble，monitor 從 MAC/PHY
波形解碼 PID→packet type、重組 payload（剝除 CRC trailer）、觀察 handshake，
scoreboard 端到端比對。

## Sequence 清單

| Sequence | 類型 | 說明 |
|----------|------|------|
| `usb_base_sequence` | base | 共用參數/constraint |
| `usb_random_sequence` | random | protocol-weighted 隨機流量 (90% 打到 DUT 位址) |
| `usb_normal_seq` | directed | 正常 SETUP/IN/OUT/DATA, ACK 路徑 |
| `usb_error_inject_seq` | directed | CRC 腐敗 / timeout(未實作位址) / STALL(EP15) / babble(超長) |
| `usb_reset_seq` | directed | bus reset (SE0) 後重新列舉 |
| `usb_back_to_back_seq` | directed | 最小 inter-packet gap (=2) 背靠背 |
| `usb_stress_seq` | directed | 大 payload (256–512B) 高速率壓力 |
| `usb_corner_seq` | directed | ZLP / 1-byte / max-packet / DATA0-DATA1 toggle / 邊界 EP |
| `usb_sof_seq` | directed | SOF frame stream (11-bit frame number) |
| `usb_regression_sequence` | regression | 加權混合 regression |
| `usb_directed_regression_sequence` | regression | directed library 全掃 |

Tests：`usb_random_regression_test` (預設), `usb_directed_test`,
`usb_hs_test`, `usb_ss_test`, `usb_ssp_test`, `usb_ss20_test`,
`usb4_test`, `usb_eusb2_test`, `usb_pd_test`。

## SVA 清單 (rtl/sva/usb4_compliance_checker.sv, module on usb4_link_if)

每個違規都是 `UVM_ERROR`：
- **L1 signal sanity (4)**：合法 lane state 編碼、state / valid / width / gen3 無 X、送出的 word 無 X、width 只能是 1 或 2
- **L2 training (5)**：每個回送的 ordered set 對應它完成的 training 步驟、CL_ACK 只進 CLx、CL_NAK 只留在 CL0、只送允許的 ordered set
- **L3 lane states (5)**：兩條 lane 的合法轉移、lane detect 消失即 CLd、width 2 只在兩條 lane 都在 CL0、Gen 3 只在 TS1 結束時決定
- **L4 transport (4)**：word 只在 CL0 送出、first / last framing、每個 header 的 HEC、word 數等於 Length
- **L5 counters (3)**：counter 每 clock 最多加一、forward 計數對應一個封包結束、retrain 讓 lane 0 回到 Lock
- 12 個 cover：Gen 3、bonded、CLx、CL_ACK、CL_NAK、retrain、training timeout、FEC 修正、overflow、重送、Notification、Credit Grant

## Functional Coverage 清單

`usb_coverage_model` (8 covergroups，含 cross)：
`cg_txn_type` (protocol×type cross)、`cg_endpoint` (ep×type cross)、
`cg_packet_size` (size×protocol cross)、`cg_device_state` (FSM transition bins,
state×protocol cross)、`cg_phy_layer` (phy_if×term cross)、
`cg_pd_contract` (contract×voltage cross)、`cg_error_injection` (err×recovery cross)、
`cg_data_pattern` (first-byte pattern×length cross)。
Interface covergroup：`cg_usb_interface` (MAC handshake × device state cross)。
各 protocol checker 另有專屬 covergroup + cross。

## 快速上手 (Quick Start)

```sh
cd scripts
make compile           # VCS: pkg → checkers → if → sequences → env → tests → tb
make simulate TEST=usb_random_regression_test
make simulate TEST=usb_directed_test
make coverage          # 見 scripts/coverage.mk
```

環境變數 `TEST` 選擇測試；`UVM_VERBOSITY` 控制訊息等級。
regression 結束時 scoreboard 回報 `n_matches/n_mismatches`，
compliance checker 回報 L1/L2/L3/L4 tiered coverage。

## Deepened Features (v1.8.0)

- **Lane adapter + transport model** (`tb/usb4_smoke_model.sv`): two lanes with CLd / Lock / Training.TS1 / Training.TS2 / CL0 / CLx, training timeout, Gen 2 / Gen 3 selection, RS-FEC (up to 2 symbol errors corrected, uncorrectable packets, retrain after 4), CL_REQ -> CL_ACK / CL_NAK, WAKE, lane bonding with width-change Notifications; transport packets with HEC (CRC-8) and length checks, the control path (Read / Write requests with CRC-32, Read / Write Responses, Notifications ERR_ADDR / ERR_LEN / ERR_UNSUP, retransmission replay), a 64-dword config space, 4 paths with HopID translation, 4 buffers per path and Credit Grants on release, back-pressure and a 128-word output queue
- **Functional test** (`tb/smoke_func_tb.sv`): 213 self-checks (replaces `func_usb4_tb.sv`)
- **UVM agent** (`vip/usb4/usb4_link_pkg.sv` on `usb4_link_if`): far-end router driver / monitor, a scoreboard that predicts both lanes and every output word clock by clock, lane / packet / error covergroups, a 250-iteration random regression with directed training timeouts (`usb4_link_test`, runs on Verilator)
- **SVA**: `rtl/sva/usb4_compliance_checker.sv` rewritten on the link interface (21 assertions, 12 covers)
