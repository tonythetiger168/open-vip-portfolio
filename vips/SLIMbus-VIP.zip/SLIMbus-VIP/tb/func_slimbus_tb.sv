// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_slimbus_tb.sv -- self-checking functional test for the SLIMbus codec
// slave model (slimbus_codec_slave, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py SLIMbus-VIP
//
// Model contract (from tb/top_tb.sv and slimbus_defs_pkg):
//   the manager drives DATA on the rising edge, the slave samples on the
//   falling edge. A frame is SYNC (0x5A) followed by a 32-bit header
//   {opcode, logical address, channel, data}. The slave answers with one
//   byte on the following 8 rising edges (data_oe high): ENUM -> presence
//   0xC3, ASSIGN_LA / CHAN_SETUP / PAUSE / RESUME -> ACK 0xA5, STREAM ->
//   echoes the sample byte, unknown opcodes -> 0x00. ASSIGN_LA sets the
//   slave's logical address; SETUP/PAUSE/RESUME act only when addressed to it.

module func_slimbus_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [7:0] SYNC = 8'h5A, PRESENCE = 8'hC3, ACK = 8'hA5;
  localparam bit [7:0] ENUM = 8'h01, ASSIGN = 8'h02, SETUP = 8'h03, STREAM = 8'h04, PAUSE = 8'h05, RESUME = 8'h06;
  int checks = 0, fails = 0;

  logic clk = 1'b0, rst_n = 1'b0, data_i = 1'b0;
  wire  data_o, data_oe;

  always #5 clk = ~clk;

  slimbus_codec_slave u_dut (
    .clk(clk), .rst_n(rst_n), .data_i(data_i), .slv_data_o(data_o), .slv_data_oe(data_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic bits(input [31:0] v, input int n);
    for (int i = n - 1; i >= 0; i--) begin
      @(posedge clk); #1 data_i = v[i];
    end
  endtask

  // send a frame and collect the response byte (got=0 if none)
  logic [7:0] rsp;
  bit         got;
  task automatic frame(input [7:0] op, input [7:0] la, input [7:0] ch, input [7:0] d,
                       input bit with_sync = 1);
    if (with_sync) bits(SYNC, 8); else bits(8'h00, 8);
    bits({op, la, ch, d}, 32);
    got = 0; rsp = '0;
    for (int k = 0; k < 12 && !got; k++) begin
      @(negedge clk);
      if (data_oe === 1'b1) got = 1;
    end
    if (got) begin
      rsp[7] = data_o;
      for (int i = 6; i >= 0; i--) begin @(negedge clk); rsp[i] = data_o; end
    end
    @(posedge clk); #1 data_i = 1'b0;
    repeat (3) @(negedge clk);
  endtask

  int oe_width = 0;
  always @(negedge clk) if (data_oe) oe_width++;

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1'b1;

    frame(ENUM, 8'h00, 8'h00, 8'h00);
    chk(got && rsp == PRESENCE, "ENUM answered with the presence byte 0xC3");
    chk(oe_width == 8, "response occupies exactly 8 cells with data_oe high");

    frame(ASSIGN, 8'h00, 8'h00, 8'h21);
    chk(got && rsp == ACK && u_dut.my_la == 8'h21 && u_dut.la_valid, "ASSIGN_LA ACKed and sets the logical address");

    frame(SETUP, 8'h21, 8'h03, 8'h00);
    chk(got && rsp == ACK && u_dut.ch_active[3], "CHAN_SETUP to own LA ACKed and activates the channel");
    frame(SETUP, 8'h30, 8'h05, 8'h00);
    chk(!u_dut.ch_active[5], "CHAN_SETUP to another LA does not activate the channel");

    frame(STREAM, 8'h21, 8'h03, 8'h9C);
    chk(got && rsp == 8'h9C, "STREAM echoes the sample byte");
    frame(STREAM, 8'h21, 8'h03, 8'h00);
    chk(got && rsp == 8'h00, "STREAM echoes an all-zero sample");

    frame(PAUSE, 8'h21, 8'h03, 8'h00);
    chk(got && rsp == ACK && u_dut.paused, "PAUSE to own LA ACKed and pauses");
    frame(RESUME, 8'h30, 8'h03, 8'h00);
    chk(u_dut.paused, "RESUME addressed to another LA is ignored");
    frame(RESUME, 8'h21, 8'h03, 8'h00);
    chk(got && rsp == ACK && !u_dut.paused, "RESUME to own LA ACKed and resumes");

    frame(8'h7E, 8'h21, 8'h00, 8'h00);
    chk(got && rsp == 8'h00, "unknown opcode answered with 0x00");

    frame(ENUM, 8'h00, 8'h00, 8'h00, 0);
    chk(!got, "no response without the SYNC byte");

    @(negedge clk); rst_n = 1'b0;
    @(negedge clk); rst_n = 1'b1;
    chk(!u_dut.la_valid && u_dut.my_la == 8'h00 && data_oe === 1'b0, "reset clears the logical address");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
