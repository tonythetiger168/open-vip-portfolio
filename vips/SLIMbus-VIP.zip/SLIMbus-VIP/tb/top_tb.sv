// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- SLIMbus testbench top with a functional audio codec slave DUT

`ifndef SLIMBUS_TB_SV
`define SLIMBUS_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import slimbus_defs_pkg::*;
import slimbus_pkg::*;
import slimbus_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  slimbus_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  slimbus_codec_slave dut (
    .clk        (vif.clk),
    .rst_n      (vif.rst_n),
    .data_i     (vif.data_i),
    .slv_data_o (vif.slv_data_o),
    .slv_data_oe(vif.slv_data_oe)
  );

  initial begin
    uvm_config_db#(virtual slimbus_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional SLIMbus audio codec slave:
//  - answers ENUM presence queries with SB_PRESENCE
//  - latches its logical address on SB_OP_ASSIGN
//  - tracks channel setup / pause / resume
//  - echoes received stream sample bytes back in the response window
// Decode FSM samples DATA at the negedge; the response window (cells 40-47)
// is driven at the posedge so it is stable for mid-cell_idx sampling.
module slimbus_codec_slave
(
  input  logic clk,
  input  logic rst_n,
  input  logic data_i,
  output logic slv_data_o,
  output logic slv_data_oe
);
  import slimbus_defs_pkg::*;

  bit [7:0] my_la    = 8'h00;
  bit       la_valid = 0;
  bit       ch_active[16];
  bit       paused   = 0;

  // ---- negedge: hunt sync, decode 32-bit header, prepare response ----
  bit [7:0]  sr        = 0;
  bit [31:0] h32       = 0;
  bit [31:0] h         = 0;
  int        bcnt      = 0;      // header bits decoded (0..32)
  bit        armed     = 0;      // header complete, response pending
  bit [7:0]  resp_byte = 8'h00;

  // combinational response selection once header is complete
  function automatic bit [7:0] select_resp(bit [7:0] op, la, ch, dat);
    case (op)
      SB_OP_ENUM:   return SB_PRESENCE;
      SB_OP_ASSIGN: return SB_ACK;
      SB_OP_SETUP:  return SB_ACK;
      SB_OP_STREAM: return dat;             // sample echo
      SB_OP_PAUSE:  return SB_ACK;
      SB_OP_RESUME: return SB_ACK;
      default:      return 8'h00;
    endcase
  endfunction

  always @(negedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sr <= 0; h32 <= 0; bcnt <= 0; armed <= 0;
      my_la <= 0; la_valid <= 0; paused <= 0;
    end else if (!armed) begin
      sr <= {sr[6:0], data_i};
      if (bcnt == 0) begin
        if ({sr[6:0], data_i} == SB_SYNC) bcnt <= 1;
      end else begin
        h = {h32[30:0], data_i};
        h32 <= h;
        if (bcnt == 32) begin
          bcnt      <= 0;
          armed     <= 1;
          resp_byte <= select_resp(h[31:24], h[23:16], h[15:8], h[7:0]);
          case (h[31:24])
            SB_OP_ASSIGN: begin my_la <= h[7:0]; la_valid <= 1; end
            SB_OP_SETUP:  if (h[23:16] == my_la) ch_active[h[11:8]] <= 1;
            SB_OP_PAUSE:  if (h[23:16] == my_la) paused <= 1;
            SB_OP_RESUME: if (h[23:16] == my_la) paused <= 0;
            default: ;
          endcase
        end else begin
          bcnt <= bcnt + 1;
        end
      end
    end
  end

  // ---- posedge: drive the 8-bit response window ----
  int rcnt = 0;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      slv_data_o <= 1'b1; slv_data_oe <= 1'b0; rcnt <= 0;
    end else if (armed && rcnt < 8) begin
      slv_data_oe <= 1'b1;
      slv_data_o  <= resp_byte[7-rcnt];
      rcnt <= rcnt + 1;
      if (rcnt == 7) armed <= 0;
    end else begin
      slv_data_oe <= 1'b0;
      if (!armed) rcnt <= 0;
    end
  end
endmodule
`endif
