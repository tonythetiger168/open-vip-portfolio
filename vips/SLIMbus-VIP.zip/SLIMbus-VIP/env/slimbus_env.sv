// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_env.sv -- SLIMbus verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import slimbus_defs_pkg::*;
  import slimbus_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares framer-issued (expected) transactions
  // against monitor-decoded (observed) transactions.
  class slimbus_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(slimbus_scoreboard)
    uvm_analysis_imp_exp #(slimbus_transaction, slimbus_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(slimbus_transaction, slimbus_scoreboard) obs_ap;

    slimbus_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0, n_error_matches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(slimbus_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(slimbus_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        slimbus_transaction e = exp_q.pop_front();
        slimbus_transaction o = obs_q.pop_front();
        if (e.framing_err || o.framing_err) begin
          // error-injected frame: both sides must flag the framing error
          if (e.framing_err && o.framing_err) n_error_matches++;
          else begin
            n_mismatches++;
            `uvm_error("SB", $sformatf("framing flag mismatch exp{%s} obs{%s}",
                       e.convert2string(), o.convert2string()))
          end
        end else if (e.op == o.op && e.la == o.la && e.channel == o.channel &&
                     (e.op != SB_STREAM || e.sample == o.sample) &&
                     (e.op != SB_ENUM   || e.resp   == o.resp)   &&
                     (e.op == SB_STREAM || e.resp   == o.resp)) begin
          n_matches++;
        end else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("slimbus scoreboard: n_matches=%0d n_error_matches=%0d n_mismatches=%0d",
                n_matches, n_error_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  class slimbus_env extends uvm_env;
    `uvm_component_utils(slimbus_env)
    slimbus_agent      agt;
    slimbus_scoreboard sb;
    slimbus_checker    chk;
    slimbus_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = slimbus_agent::type_id::create("agt", this);
      sb  = slimbus_scoreboard::type_id::create("sb", this);
      chk = slimbus_checker::type_id::create("chk", this);
      cov = slimbus_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
