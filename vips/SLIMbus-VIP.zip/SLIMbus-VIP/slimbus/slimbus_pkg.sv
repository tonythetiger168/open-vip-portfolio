// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// slimbus_pkg.sv -- MIPI SLIMbus UVM VIP package

package slimbus_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import slimbus_defs_pkg::*;
  export slimbus_defs_pkg::*;

  `include "slimbus_transaction.svh"
  `include "slimbus_config.svh"
  `include "slimbus_sequencer.svh"
  `include "slimbus_driver.svh"
  `include "slimbus_monitor.svh"
  `include "slimbus_agent.svh"
  `include "slimbus_sequences.svh"
  `include "slimbus_checker.svh"
  `include "slimbus_coverage.svh"
endpackage
