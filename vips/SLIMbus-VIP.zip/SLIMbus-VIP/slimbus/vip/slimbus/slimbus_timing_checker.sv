// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// slimbus_timing_checker.sv -- MIPI SLIMbus timing parameter checker

`ifndef SLIMBUS_TIMING_CHECKER_SV
`define SLIMBUS_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import slimbus_defs_pkg::slimbus_state_e;

module slimbus_timing_checker
(
  input logic clk,
  input logic rst_n,
  input slimbus_state_e state
);
  a_slimbus_timing_state_known : assert property (@(posedge clk)
    disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("TIMING", "slimbus timing: state unknown")
endmodule
`endif
