// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_coverage.svh -- SLIMbus functional coverage

`ifndef SLIMBUS_COVERAGE_SVH
`define SLIMBUS_COVERAGE_SVH

class slimbus_coverage extends uvm_subscriber #(slimbus_transaction);
  `uvm_component_utils(slimbus_coverage)

  slimbus_transaction tr;

  covergroup cg_protocol;
    cp_op : coverpoint tr.op {
      bins enum_op  = {slimbus_defs_pkg::SB_ENUM};
      bins assignop = {slimbus_defs_pkg::SB_ASSIGN_LA};
      bins setup    = {slimbus_defs_pkg::SB_CHAN_SETUP};
      bins stream   = {slimbus_defs_pkg::SB_STREAM};
      bins pause    = {slimbus_defs_pkg::SB_PAUSE};
      bins resume   = {slimbus_defs_pkg::SB_RESUME};
    }
    cp_la : coverpoint tr.la {
      bins broadcast = {8'h00};
      bins assigned  = {[8'h01 : 8'h7F]};
    }
    cp_channel : coverpoint tr.channel {
      bins low  = {[0:3]};
      bins high = {[4:15]};
    }
    cp_sample : coverpoint tr.sample iff (tr.op == slimbus_defs_pkg::SB_STREAM) {
      bins zero    = {32'h0000_0000};
      bins ones    = {32'hFFFF_FFFF};
      bins max_pos = {32'h7FFF_FFFF};
      bins max_neg = {32'h8000_0000};
      bins walk    = default;
    }
    cx_op_channel : cross cp_op, cp_channel;
  endgroup

  covergroup cg_fsm with function sample(slimbus_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {slimbus_defs_pkg::IDLE, slimbus_defs_pkg::ENUMERATION,
                           slimbus_defs_pkg::CHANNEL_SETUP, slimbus_defs_pkg::STREAMING,
                           slimbus_defs_pkg::PAUSED};
    }
    cp_trans : coverpoint s {
      bins bringup = (slimbus_defs_pkg::ENUMERATION => slimbus_defs_pkg::CHANNEL_SETUP
                      => slimbus_defs_pkg::STREAMING);
      bins pause_resume = (slimbus_defs_pkg::STREAMING => slimbus_defs_pkg::PAUSED
                           => slimbus_defs_pkg::STREAMING);
    }
  endgroup

  covergroup cg_error;
    cp_framing : coverpoint tr.framing_err { bins ok = {0}; bins err = {1}; }
    cp_echo    : coverpoint tr.echo_err iff (tr.op == slimbus_defs_pkg::SB_STREAM) {
      bins ok = {0}; bins err = {1};
    }
    cp_resp    : coverpoint tr.resp iff (!tr.framing_err) {
      bins presence = {slimbus_defs_pkg::SB_PRESENCE};
      bins ack      = {slimbus_defs_pkg::SB_ACK};
      bins other    = default;
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(slimbus_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_fsm.sample(t.fsm_state);
    cg_error.sample();
  endfunction
endclass
`endif
