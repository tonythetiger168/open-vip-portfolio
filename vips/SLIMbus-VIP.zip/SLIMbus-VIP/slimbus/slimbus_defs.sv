// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_defs.sv -- SLIMbus shared type definitions and protocol constants

package slimbus_defs_pkg;
  // Bus-level FSM (driven by the framer, observed by monitor/SVA)
  typedef enum bit [2:0] {
    IDLE,
    ENUMERATION,
    CHANNEL_SETUP,
    STREAMING,
    PAUSED
  } slimbus_state_e;

  // Transaction-level operations
  typedef enum bit [2:0] {
    SB_ENUM,        // presence query (enumeration)
    SB_ASSIGN_LA,   // logical-address assignment
    SB_CHAN_SETUP,  // channel setup
    SB_STREAM,      // audio sample streaming (32-bit sample = 4 frames)
    SB_PAUSE,       // pause channel
    SB_RESUME       // resume channel (sample sequence continues)
  } slimbus_op_e;

  // 48-cell frame format (framer drives cells 0-39, slave drives 40-47):
  //   cells  0- 7 : sync  (SB_SYNC)
  //   cells  8-15 : opcode
  //   cells 16-23 : logical address (LA), 0 = broadcast for ENUM
  //   cells 24-31 : channel number
  //   cells 32-39 : data byte (sample byte for SB_STREAM, new LA for SB_ASSIGN_LA)
  //   cells 40-47 : response window (presence / ACK / sample echo)
  localparam int       SB_FRAME_CELLS = 48;
  localparam bit [7:0] SB_SYNC        = 8'h5A;
  localparam bit [7:0] SB_PRESENCE    = 8'hC3;  // codec presence response
  localparam bit [7:0] SB_ACK         = 8'hA5;  // generic slave ACK

  localparam bit [7:0] SB_OP_ENUM   = 8'h01;
  localparam bit [7:0] SB_OP_ASSIGN = 8'h02;
  localparam bit [7:0] SB_OP_SETUP  = 8'h03;
  localparam bit [7:0] SB_OP_STREAM = 8'h04;
  localparam bit [7:0] SB_OP_PAUSE  = 8'h05;
  localparam bit [7:0] SB_OP_RESUME = 8'h06;
endpackage
