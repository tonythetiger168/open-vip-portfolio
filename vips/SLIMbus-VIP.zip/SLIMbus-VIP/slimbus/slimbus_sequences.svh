// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_sequences.svh -- SLIMbus sequence library

`ifndef SLIMBUS_SEQUENCES_SVH
`define SLIMBUS_SEQUENCES_SVH

class slimbus_base_sequence extends uvm_sequence #(slimbus_transaction);
  `uvm_object_utils(slimbus_base_sequence)
  int num_txns = 20;
  function new(string name = "slimbus_base_sequence"); super.new(name); endfunction
  task body();
    slimbus_transaction tr;
    repeat (num_txns) begin
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: enumeration + logical-address assignment
class slimbus_enumeration_seq extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_enumeration_seq)
  function new(string name = "slimbus_enumeration_seq"); super.new(name); endfunction
  rand bit [7:0] la = 8'h10;
  constraint c_la { la != 0; }
  task body();
    slimbus_transaction tr;
    // presence query
    tr = slimbus_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { op == SB_ENUM; framing_err == 0; });
    finish_item(tr);
    // LA assignment attempts
    repeat (num_txns) begin
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SB_ASSIGN_LA; la == local::la; framing_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: channel setup after enumeration
class slimbus_channel_setup_seq extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_channel_setup_seq)
  function new(string name = "slimbus_channel_setup_seq"); super.new(name); endfunction
  task body();
    slimbus_transaction tr;
    for (int ch = 0; ch < 4; ch++) begin
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SB_CHAN_SETUP; channel == ch; framing_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: audio sample streaming with data corners
class slimbus_audio_stream_seq extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_audio_stream_seq)
  function new(string name = "slimbus_audio_stream_seq"); super.new(name); endfunction
  rand bit [4:0] ch = 1;
  task body();
    slimbus_transaction tr;
    bit [31:0] corners[$] = '{32'h0000_0000, 32'hFFFF_FFFF, 32'h7FFF_FFFF,
                              32'h8000_0000, 32'h5555_AAAA};
    foreach (corners[i]) begin
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SB_STREAM; channel == local::ch;
                                  sample == corners[i]; framing_err == 0; });
      finish_item(tr);
    end
    repeat (num_txns) begin
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SB_STREAM; channel == local::ch; framing_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: stream -> pause -> resume, sample sequence must continue
class slimbus_pause_resume_seq extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_pause_resume_seq)
  function new(string name = "slimbus_pause_resume_seq"); super.new(name); endfunction
  task body();
    slimbus_transaction tr;
    repeat (2) begin
      repeat (4) begin
        tr = slimbus_transaction::type_id::create("tr");
        start_item(tr);
        void'(tr.randomize() with { op == SB_STREAM; framing_err == 0; });
        finish_item(tr);
      end
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SB_PAUSE; framing_err == 0; });
      finish_item(tr);
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SB_RESUME; framing_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back streaming (no idle gap between sample groups)
class slimbus_back_to_back_seq extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_back_to_back_seq)
  function new(string name = "slimbus_back_to_back_seq"); super.new(name); endfunction
  task body();
    slimbus_transaction tr;
    repeat (num_txns) begin
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SB_STREAM; framing_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: destroyed frame sync (framing error) on control frames
class slimbus_error_inject_seq extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_error_inject_seq)
  function new(string name = "slimbus_error_inject_seq"); super.new(name); endfunction
  task body();
    slimbus_transaction tr;
    slimbus_op_e ops[$] = '{SB_ENUM, SB_ASSIGN_LA, SB_CHAN_SETUP, SB_PAUSE, SB_RESUME};
    foreach (ops[i]) begin
      // one good frame, then one corrupted frame of the same kind
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == ops[i]; framing_err == 0; });
      finish_item(tr);
      tr = slimbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == ops[i]; framing_err == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single stream issued right after reset release
// (framer autonomously enumerates / assigns LA / sets up the channel first)
class slimbus_reset_seq extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_reset_seq)
  function new(string name = "slimbus_reset_seq"); super.new(name); endfunction
  task body();
    slimbus_transaction tr = slimbus_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { op == SB_STREAM; framing_err == 0; });
    finish_item(tr);
  endtask
endclass

class slimbus_random_sequence extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_random_sequence)
  function new(string name = "slimbus_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class slimbus_regression_sequence extends slimbus_base_sequence;
  `uvm_object_utils(slimbus_regression_sequence)
  function new(string name = "slimbus_regression_sequence"); super.new(name); endfunction
  task body();
    slimbus_enumeration_seq   en  = slimbus_enumeration_seq::type_id::create("en");
    slimbus_channel_setup_seq cs  = slimbus_channel_setup_seq::type_id::create("cs");
    slimbus_audio_stream_seq  st  = slimbus_audio_stream_seq::type_id::create("st");
    slimbus_pause_resume_seq  pr  = slimbus_pause_resume_seq::type_id::create("pr");
    slimbus_back_to_back_seq  b2b = slimbus_back_to_back_seq::type_id::create("b2b");
    slimbus_error_inject_seq  err = slimbus_error_inject_seq::type_id::create("err");
    en.num_txns = 2; st.num_txns = 12; b2b.num_txns = 12;
    en.start(m_sequencer); cs.start(m_sequencer); st.start(m_sequencer);
    pr.start(m_sequencer); b2b.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
`endif
