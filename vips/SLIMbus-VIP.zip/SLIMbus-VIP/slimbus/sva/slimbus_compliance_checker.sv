// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_compliance_checker.sv -- SLIMbus SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = SLIMbus protocol-specific rules (frame alignment, channel-before-
//      stream, non-zero LA, pause/resume continuity)

`ifndef SLIMBUS_COMPLIANCE_CHECKER_SV
`define SLIMBUS_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import slimbus_defs_pkg::*;

module slimbus_compliance_checker
(
  input logic           clk,
  input logic           rst_n,
  input slimbus_state_e state,
  input logic           data_i,
  input logic [5:0]     cell_idx,
  input logic           frame_start,
  input logic           la_assigned,
  input logic           channel_active,
  input logic [7:0]     active_la,
  input logic [7:0]     sample_seq,
  input logic           error_inject
);

  // Procedural helpers: sync-pattern shift register (sampled mid-cell_idx) and
  // sample-sequence snapshot taken when a stream is paused.
  bit [7:0] sync_sr = 0;
  bit [7:0] pause_seq = 0;
  always @(negedge clk) begin
    if (!rst_n) sync_sr <= 0;
    else        sync_sr <= {sync_sr[6:0], data_i};
  end
  always @(posedge clk) begin
    if (state == PAUSED && $past(state) == STREAMING)
      pause_seq <= sample_seq;
  end

  // ---------------- L1: signal sanity (4) ----------------
  a_slimbus_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "slimbus: clock unknown")
  a_slimbus_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "slimbus: reset unknown")
  a_slimbus_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "slimbus: state unknown")
  a_slimbus_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, ENUMERATION, CHANNEL_SETUP, STREAMING, PAUSED})
    else `uvm_error("SVA_L1", "slimbus: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from IDLE
  a_slimbus_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, ENUMERATION})
    else `uvm_error("SVA_L2", "slimbus: illegal transition from IDLE")
  // L2-2: legal FSM transition from ENUMERATION
  a_slimbus_trans_enumeration : assert property (@(posedge clk) disable iff (!rst_n)
    state == ENUMERATION |=> state inside {ENUMERATION, CHANNEL_SETUP, IDLE})
    else `uvm_error("SVA_L2", "slimbus: illegal transition from ENUMERATION")
  // L2-3: legal FSM transition from CHANNEL_SETUP
  a_slimbus_trans_channel_setup : assert property (@(posedge clk) disable iff (!rst_n)
    state == CHANNEL_SETUP |=> state inside {CHANNEL_SETUP, STREAMING, IDLE})
    else `uvm_error("SVA_L2", "slimbus: illegal transition from CHANNEL_SETUP")
  // L2-4: legal FSM transition from STREAMING
  a_slimbus_trans_streaming : assert property (@(posedge clk) disable iff (!rst_n)
    state == STREAMING |=> state inside {STREAMING, PAUSED, IDLE})
    else `uvm_error("SVA_L2", "slimbus: illegal transition from STREAMING")
  // L2-5: legal FSM transition from PAUSED (resume returns to STREAMING)
  a_slimbus_trans_paused : assert property (@(posedge clk) disable iff (!rst_n)
    state == PAUSED |=> state inside {PAUSED, STREAMING, IDLE})
    else `uvm_error("SVA_L2", "slimbus: illegal transition from PAUSED")
  // L2-6: state may only change on a frame boundary
  a_slimbus_trans_aligned : assert property (@(posedge clk) disable iff (!rst_n)
    $changed(state) |-> (cell_idx == 6'd0 || $past(cell_idx) == 6'd0))
    else `uvm_error("SVA_L2", "slimbus: state change not frame aligned")

  // ---------------- L3: protocol rules (4) ----------------
  a_slimbus_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "slimbus: state not IDLE during reset")
  a_slimbus_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == PAUSED |-> ##[1:512] (state != PAUSED))
    else `uvm_error("SVA_L3", "slimbus: stuck in PAUSED")
  a_slimbus_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == ENUMERATION);
  a_slimbus_l3_back_idle  : cover property (@(posedge clk) disable iff (!rst_n)
    state == STREAMING ##1 state == PAUSED);

  // ---------------- L4: SLIMbus protocol-specific rules (4) ----------------
  // L4-1: frame boundary alignment - every frame starts with the sync pattern
  // (at cell_idx 8 the shift register holds exactly cells 0-7 of the frame)
  a_slimbus_l4_frame_sync : assert property (@(negedge clk)
    disable iff (!rst_n || error_inject)
    cell_idx == 6'd8 |-> sync_sr == SB_SYNC)
    else `uvm_error("SVA_L4", "slimbus: frame does not start with sync pattern")
  // L4-2: a channel must be established before streaming
  a_slimbus_l4_chan_before_stream : assert property (@(posedge clk) disable iff (!rst_n)
    state == STREAMING |-> channel_active)
    else `uvm_error("SVA_L4", "slimbus: streaming without established channel")
  // L4-3: assigned logical address must be non-zero
  a_slimbus_l4_la_nonzero : assert property (@(posedge clk) disable iff (!rst_n)
    (state inside {CHANNEL_SETUP, STREAMING, PAUSED}) |-> (la_assigned && active_la != 8'h00))
    else `uvm_error("SVA_L4", "slimbus: active channel with zero/unassigned LA")
  // L4-4: after pause, resume continues the sample sequence (no loss/reorder)
  a_slimbus_l4_resume_continuous : assert property (@(posedge clk) disable iff (!rst_n)
    (state == STREAMING && $past(state) == PAUSED) |-> (sample_seq == pause_seq))
    else `uvm_error("SVA_L4", "slimbus: sample sequence not continuous across pause/resume")

endmodule
`endif
