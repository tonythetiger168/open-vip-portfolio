// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_monitor.svh -- SLIMbus monitor: hunts the frame sync pattern on
// DATA, decodes opcode/LA/channel/data/response from the 48-cell_idx frame
// waveform, reassembles 32-bit audio samples (4 frames) and publishes
// reconstructed transactions.

`ifndef SLIMBUS_MONITOR_SVH
`define SLIMBUS_MONITOR_SVH

class slimbus_monitor extends uvm_monitor;
  `uvm_component_utils(slimbus_monitor)
  virtual slimbus_if vif;
  uvm_analysis_port #(slimbus_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned framing_errors = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual slimbus_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "slimbus virtual interface not set")
  endfunction

  task recv_byte(output bit [7:0] b);
    for (int i = 7; i >= 0; i--) begin
      @(negedge vif.clk);
      b[i] = vif.data_i;
    end
  endtask

  task decode_frame(output bit [7:0] op, la, ch, dat, resp);
    recv_byte(op);
    recv_byte(la);
    recv_byte(ch);
    recv_byte(dat);
    recv_byte(resp);
  endtask

  function slimbus_op_e map_op(bit [7:0] op);
    case (op)
      slimbus_defs_pkg::SB_OP_ENUM:   return slimbus_defs_pkg::SB_ENUM;
      slimbus_defs_pkg::SB_OP_ASSIGN: return slimbus_defs_pkg::SB_ASSIGN_LA;
      slimbus_defs_pkg::SB_OP_SETUP:  return slimbus_defs_pkg::SB_CHAN_SETUP;
      slimbus_defs_pkg::SB_OP_STREAM: return slimbus_defs_pkg::SB_STREAM;
      slimbus_defs_pkg::SB_OP_PAUSE:  return slimbus_defs_pkg::SB_PAUSE;
      slimbus_defs_pkg::SB_OP_RESUME: return slimbus_defs_pkg::SB_RESUME;
      default:                        return slimbus_defs_pkg::SB_ENUM;
    endcase
  endfunction

  task run_phase(uvm_phase phase);
    fork
      framing_watch();
      decode_loop();
    join
  endtask

  task decode_loop();
    bit [7:0] w, op, la, ch, dat, resp, s2;
    slimbus_transaction tr;
    forever begin
      @(negedge vif.clk);
      if (!vif.rst_n) continue;
      // ---- sync hunt: slide an 8-bit window until SB_SYNC ----
      w = {w[6:0], vif.data_i};
      if (w !== slimbus_defs_pkg::SB_SYNC) continue;

      // ---- aligned: decode the remaining 40 cells of the frame ----
      decode_frame(op, la, ch, dat, resp);
      w = 8'h00;   // clear the hunt window: next sync starts on the frame boundary
      if (op == slimbus_defs_pkg::SB_OP_STREAM) begin
        // 4 consecutive STREAM frames carry one 32-bit sample (MSB first)
        bit [7:0] bytes[4];
        bit       echo_bad = (resp !== dat);
        bit       framed   = 1;
        bytes[0] = dat;
        for (int n = 1; n < 4; n++) begin
          recv_byte(s2);
          if (s2 !== slimbus_defs_pkg::SB_SYNC) begin
            framed = 0;
            break;
          end
          decode_frame(op, la, ch, dat, resp);
          bytes[n] = dat;
          if (resp !== dat) echo_bad = 1;
        end
        if (!framed || op != slimbus_defs_pkg::SB_OP_STREAM) begin
          framing_errors++;
          tr = slimbus_transaction::type_id::create("tr");
          tr.framing_err = 1;
          tr.fsm_state   = vif.state;
          `uvm_warning("MON", "framing error inside stream group")
          ap.write(tr);
          txn_count++;
          continue;
        end
        tr = slimbus_transaction::type_id::create("tr");
        tr.op        = slimbus_defs_pkg::SB_STREAM;
        tr.la        = la;
        tr.channel   = ch[4:0];
        tr.sample    = {bytes[0], bytes[1], bytes[2], bytes[3]};
        tr.echo_err  = echo_bad;
        tr.resp      = resp;
        tr.fsm_state = vif.state;
      end else begin
        tr = slimbus_transaction::type_id::create("tr");
        tr.op        = map_op(op);
        tr.la        = la;
        tr.channel   = ch[4:0];
        tr.resp      = resp;
        tr.fsm_state = vif.state;
      end
      txn_count++;
      `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
      ap.write(tr);
    end
  endtask


  // Separate watch: a destroyed sync shows up as a long low stretch on DATA.
  // When the framer flags error injection, emit one framing-error transaction.
  task framing_watch();
    slimbus_transaction tr;
    forever begin
      @(posedge vif.error_inject);
      wait (!vif.error_inject);
      tr = slimbus_transaction::type_id::create("tr");
      tr.framing_err = 1;
      tr.fsm_state   = vif.state;
      framing_errors++;
      `uvm_info("MON", "framing error observed (sync destroyed)", UVM_HIGH)
      ap.write(tr);
      txn_count++;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("slimbus monitor observed %0d transactions, %0d framing errors",
              txn_count, framing_errors), UVM_LOW)
  endfunction
endclass
`endif
