// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_transaction.svh -- SLIMbus transaction (enumeration / channel
// setup / audio streaming / pause-resume operations)

`ifndef SLIMBUS_TRANSACTION_SVH
`define SLIMBUS_TRANSACTION_SVH

class slimbus_transaction extends uvm_sequence_item;

  rand slimbus_op_e op;
  rand bit [7:0]    la;           // logical address (assigned LA is non-zero)
  rand bit [4:0]    channel;      // channel number
  rand bit [31:0]   sample;       // audio sample (SB_STREAM: 4 frames, MSB first)
  rand bit          framing_err;  // error injection: destroy frame sync

  // Observed fields (filled by driver expectation / monitor decode)
  bit [7:0]       resp;           // response window byte (presence/ACK/echo)
  bit             echo_err;       // monitor: stream echo mismatch
  slimbus_state_e fsm_state;      // monitor: bus state when observed

  constraint c_op       { op dist { SB_STREAM := 4, SB_ENUM := 1, SB_ASSIGN_LA := 1,
                                    SB_CHAN_SETUP := 1, SB_PAUSE := 1, SB_RESUME := 1 }; }
  // REACHABILITY: LA=0 is the SLIMbus broadcast/enumeration address; allow it
  // for SB_ENUM frames so cg_protocol.broadcast bin is generatable. Assigned
  // (non-enumeration) traffic must still use a non-zero LA.
  constraint c_la       { (op == SB_ENUM) -> la inside {[8'h00 : 8'h7F]};
                          (op != SB_ENUM) -> la inside {[8'h01 : 8'h7F]}; }
  constraint c_channel  { channel inside {[0:15]}; }
  constraint c_framing  { framing_err dist { 0 := 9, 1 := 1 }; }
  constraint c_stream   { op == SB_STREAM -> framing_err == 0; }

  `uvm_object_utils_begin(slimbus_transaction)
    `uvm_field_enum(slimbus_op_e, op, UVM_ALL_ON)
    `uvm_field_int(la, UVM_ALL_ON)
    `uvm_field_int(channel, UVM_ALL_ON)
    `uvm_field_int(sample, UVM_ALL_ON)
    `uvm_field_int(framing_err, UVM_ALL_ON)
    `uvm_field_int(resp, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(echo_err, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_enum(slimbus_state_e, fsm_state, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "slimbus_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    slimbus_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    if (op == SB_STREAM)
      ok &= comparer.compare_field("sample", sample, t.sample, 32);
    ok &= comparer.compare_field("channel", channel, t.channel, 5);
    return ok;
  endfunction

  function string convert2string();
    string s = $sformatf("SLIMbus %s la=0x%02h ch=%0d", op.name(), la, channel);
    if (op == SB_STREAM) s = {s, $sformatf(" sample=0x%08h", sample)};
    if (framing_err)     s = {s, " [FRAMING_ERR]"};
    return s;
  endfunction
endclass
`endif
