// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_driver.svh -- SLIMbus framer (manager) driver.
// Bit-bangs 48-cell_idx frames: sync / opcode / LA / channel / data, releases
// DATA for the slave response window, and keeps bus-level protocol state
// (enumeration -> LA assignment -> channel setup -> streaming/pause/resume).

`ifndef SLIMBUS_DRIVER_SVH
`define SLIMBUS_DRIVER_SVH

class slimbus_driver extends uvm_driver #(slimbus_transaction);
  `uvm_component_utils(slimbus_driver)
  virtual slimbus_if vif;
  slimbus_config cfg;
  uvm_analysis_port #(slimbus_transaction) drv_ap;  // expected items for scoreboard

  protected int unsigned seq_cnt = 0;   // running stream byte sequence

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual slimbus_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "slimbus virtual interface not set")
  endfunction

  // ---- low-level cell_idx drive (framer owns cells 0-39) ----
  task send_cell(bit b, bit drv_en, int unsigned cidx);
    @(vif.drv_cb);
    vif.drv_cb.data_o <= b;
    vif.drv_cb.data_oe <= drv_en;
    vif.cell_idx        <= cidx[5:0];
    vif.frame_start <= (cidx == 0);
  endtask

  // One 48-cell_idx frame; returns the slave response-window byte.
  task send_frame(bit [7:0] opcode, bit [7:0] la, bit [7:0] ch, bit [7:0] dbyte,
                  bit framing_err, output bit [7:0] resp);
    int c = 0;
    resp = 8'hFF;
    if (framing_err) begin
      // Destroy the frame: no sync pattern, DATA held low for the whole frame
      vif.error_inject <= 1'b1;
      repeat (slimbus_defs_pkg::SB_FRAME_CELLS) begin
        send_cell(1'b0, 1'b1, c); c++;
      end
      vif.error_inject <= 1'b0;
      return;
    end
    for (int i = 7; i >= 0; i--) begin send_cell(slimbus_defs_pkg::SB_SYNC[i], 1'b1, c); c++; end
    for (int i = 7; i >= 0; i--) begin send_cell(opcode[i], 1'b1, c); c++; end
    for (int i = 7; i >= 0; i--) begin send_cell(la[i],     1'b1, c); c++; end
    for (int i = 7; i >= 0; i--) begin send_cell(ch[i],     1'b1, c); c++; end
    for (int i = 7; i >= 0; i--) begin send_cell(dbyte[i],  1'b1, c); c++; end
    // response window: slave drives cells 40-47
    for (int i = 7; i >= 0; i--) begin
      @(vif.drv_cb);
      vif.drv_cb.data_oe <= 1'b0;
      vif.cell_idx        <= c[5:0];
      vif.frame_start <= 1'b0;
      @(negedge vif.clk);
      resp[i] = vif.data_i;
      c++;
    end
  endtask

  task set_state(slimbus_state_e s);
    vif.state <= s;   // takes effect at the next posedge == cell_idx 0 of next frame
  endtask

  // ---- autonomous bus-management frames (framer duties) ----
  task do_enum();
    bit [7:0] resp;
    slimbus_transaction e = slimbus_transaction::type_id::create("enum_exp");
    set_state(slimbus_defs_pkg::ENUMERATION);
    send_frame(slimbus_defs_pkg::SB_OP_ENUM, 8'h00, 8'h00, 8'h00, 1'b0, resp);
    e.op = slimbus_defs_pkg::SB_ENUM; e.la = 0; e.channel = 0;
    e.resp = slimbus_defs_pkg::SB_PRESENCE;      // expected presence value
    if (resp !== slimbus_defs_pkg::SB_PRESENCE)
      `uvm_warning("DRV", $sformatf("no codec presence (resp=0x%02h)", resp))
    drv_ap.write(e);
  endtask

  task do_assign(bit [7:0] la);
    bit [7:0] resp;
    slimbus_transaction e = slimbus_transaction::type_id::create("assign_exp");
    set_state(slimbus_defs_pkg::ENUMERATION);
    send_frame(slimbus_defs_pkg::SB_OP_ASSIGN, la, 8'h00, la, 1'b0, resp);
    vif.la_assigned <= 1'b1;
    vif.active_la   <= la;
    e.op = slimbus_defs_pkg::SB_ASSIGN_LA; e.la = la; e.channel = 0;
    e.resp = slimbus_defs_pkg::SB_ACK;
    drv_ap.write(e);
  endtask

  task do_setup(bit [4:0] ch);
    bit [7:0] resp;
    slimbus_transaction e = slimbus_transaction::type_id::create("setup_exp");
    set_state(slimbus_defs_pkg::CHANNEL_SETUP);
    send_frame(slimbus_defs_pkg::SB_OP_SETUP, vif.active_la, {3'b000, ch}, 8'h00, 1'b0, resp);
    vif.channel_active <= 1'b1;
    e.op = slimbus_defs_pkg::SB_CHAN_SETUP; e.la = vif.active_la; e.channel = ch;
    e.resp = slimbus_defs_pkg::SB_ACK;
    drv_ap.write(e);
  endtask

  task ensure_stream_ready(bit [7:0] la, bit [4:0] ch);
    if (!vif.la_assigned) begin
      do_enum();
      do_assign(la);
    end
    if (!vif.channel_active) do_setup(ch);
  endtask

  task run_phase(uvm_phase phase);
    slimbus_transaction tr;
    bit [7:0] resp;
    vif.drv_cb.data_oe <= 1'b0;
    vif.state <= slimbus_defs_pkg::IDLE;
    vif.cell_idx <= 0; vif.frame_start <= 0;
    vif.la_assigned <= 0; vif.channel_active <= 0; vif.active_la <= 0;
    vif.sample_seq <= 0; vif.error_inject <= 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      case (tr.op)
        slimbus_defs_pkg::SB_ENUM: begin
          set_state(slimbus_defs_pkg::ENUMERATION);
          send_frame(slimbus_defs_pkg::SB_OP_ENUM, 8'h00, 8'h00, 8'h00, tr.framing_err, resp);
          if (!tr.framing_err) tr.resp = slimbus_defs_pkg::SB_PRESENCE;
        end
        slimbus_defs_pkg::SB_ASSIGN_LA: begin
          set_state(slimbus_defs_pkg::ENUMERATION);
          send_frame(slimbus_defs_pkg::SB_OP_ASSIGN, tr.la, 8'h00, tr.la, tr.framing_err, resp);
          if (!tr.framing_err) begin
            vif.la_assigned <= 1'b1;
            vif.active_la   <= tr.la;
            tr.resp = slimbus_defs_pkg::SB_ACK;
          end
        end
        slimbus_defs_pkg::SB_CHAN_SETUP: begin
          if (!vif.la_assigned) begin do_enum(); do_assign(tr.la); end
          set_state(slimbus_defs_pkg::CHANNEL_SETUP);
          send_frame(slimbus_defs_pkg::SB_OP_SETUP, vif.active_la, {3'b000, tr.channel},
                     8'h00, tr.framing_err, resp);
          if (!tr.framing_err) begin
            vif.channel_active <= 1'b1;
            tr.resp = slimbus_defs_pkg::SB_ACK;
          end
        end
        slimbus_defs_pkg::SB_STREAM: begin
          ensure_stream_ready(tr.la, tr.channel);
          set_state(slimbus_defs_pkg::STREAMING);
          for (int b = 3; b >= 0; b--) begin
            send_frame(slimbus_defs_pkg::SB_OP_STREAM, vif.active_la,
                       {3'b000, tr.channel}, tr.sample[b*8 +: 8], tr.framing_err, resp);
            if (!tr.framing_err) begin
              seq_cnt++;
              vif.sample_seq <= seq_cnt[7:0];
              if (resp !== tr.sample[b*8 +: 8])
                `uvm_warning("DRV", $sformatf("stream echo mismatch exp=0x%02h got=0x%02h",
                             tr.sample[b*8 +: 8], resp))
            end
          end
        end
        slimbus_defs_pkg::SB_PAUSE: begin
          set_state(slimbus_defs_pkg::PAUSED);
          send_frame(slimbus_defs_pkg::SB_OP_PAUSE, vif.active_la, {3'b000, tr.channel},
                     8'h00, tr.framing_err, resp);
          if (!tr.framing_err) tr.resp = slimbus_defs_pkg::SB_ACK;
        end
        slimbus_defs_pkg::SB_RESUME: begin
          set_state(slimbus_defs_pkg::STREAMING);
          send_frame(slimbus_defs_pkg::SB_OP_RESUME, vif.active_la, {3'b000, tr.channel},
                     8'h00, tr.framing_err, resp);
          if (!tr.framing_err) tr.resp = slimbus_defs_pkg::SB_ACK;
        end
      endcase
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
