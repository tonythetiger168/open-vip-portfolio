// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// slimbus_if.sv -- SLIMbus interface (CLK + DATA, framer/slave modports)
//
// The framer (VIP driver) drives DATA during cells 0-39 of each 48-cell_idx
// frame; the codec slave drives the response window (cells 40-47).
// DATA is resolved wired-AND so both sides can share the line.

interface slimbus_if (input logic clk);
  import slimbus_defs_pkg::slimbus_state_e;

  logic rst_n;

  // Framer (manager) drive
  logic data_o;
  logic data_oe;
  logic data_i;

  // Slave (codec DUT) drive
  logic slv_data_o;
  logic slv_data_oe;

  slimbus_state_e state;

  // Protocol bookkeeping (driven by framer, used by monitor/SVA/coverage)
  logic [5:0] cell_idx;           // cell_idx index within the 48-cell_idx frame
  logic       frame_start;    // high while cell_idx == 0
  logic       la_assigned;    // enumeration completed, LA assigned
  logic       channel_active; // channel established
  logic [7:0] active_la;      // currently assigned logical address (non-zero)
  logic [7:0] sample_seq;     // running stream byte sequence counter
  logic       error_inject;   // framing error injection in progress

  assign data_i = (data_oe     ? data_o     : 1'b1) &
                  (slv_data_oe ? slv_data_o : 1'b1);

  modport MASTER (input  clk, rst_n, data_i,
                  output data_o, data_oe, state, cell_idx, frame_start,
                         la_assigned, channel_active, active_la,
                         sample_seq, error_inject);
  modport SLAVE  (input  clk, rst_n, data_i,
                  output slv_data_o, slv_data_oe);
  modport MON    (input  clk, rst_n, data_i, state, cell_idx, frame_start,
                         la_assigned, channel_active, active_la,
                         sample_seq, error_inject);

  // Framer drives on the posedge; values are stable at the negedge.
  clocking drv_cb @(posedge clk);
    input  rst_n, data_i;
    output data_o, data_oe;
  endclocking

  // Monitor samples mid-cell_idx (negedge), after NBA updates settle.
  clocking mon_cb @(negedge clk);
    input rst_n, data_i, state, cell_idx, frame_start,
          la_assigned, channel_active, active_la, sample_seq, error_inject;
  endclocking
endinterface
