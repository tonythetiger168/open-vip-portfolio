# SLIMbus — MIPI SLIMbus UVM VIP

Open-source UVM verification IP template for **MIPI SLIMbus** (MIPI).

## Contents

| Path | Description |
|------|-------------|
| `slimbus/slimbus_if.sv` | Protocol interface + FSM state enum |
| `slimbus/slimbus_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `slimbus/sva/slimbus_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=4) |
| `slimbus/vip/slimbus/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/slimbus_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional audio codec slave DUT |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Cell-accurate framer driver**: bit-banged 48-cell frames (sync/opcode/LA/channel/data + slave response window), autonomous enumeration -> LA assignment -> channel setup bring-up before streaming
- **Protocol-decoding monitor**: sync hunting on DATA, frame header/response decode, 32-bit audio sample reassembly from 4 consecutive stream frames, framing-error detection
- **End-to-end scoreboard**: framer-issued vs monitor-decoded comparison (op/LA/channel/sample/presence), framing-error injection matching
- **Functional DUT model**: audio codec slave - presence response, LA latch, channel tracking, pause/resume, stream sample echo
- **Directed sequence library**: enumeration / channel-setup / audio-stream (sample corners) / pause-resume / back-to-back / framing-error-inject / reset + random + regression mix
- **Functional coverage**: op x channel cross, LA ranges, sample data corners, FSM states + bring-up/pause-resume transition sequences, framing/echo/response error bins
- **SVA L4**: frame sync alignment at cell boundaries, channel-established-before-streaming, non-zero assigned LA, sample-sequence continuity across pause/resume
