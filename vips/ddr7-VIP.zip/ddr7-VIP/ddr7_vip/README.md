# DDR7 UVM VIP

**Protocol:** DDR7 SDRAM
**License:** Apache-2.0

## 1. Protocol Overview

DDR7 SDRAM further raises bandwidth with PAM4 I/O and aggressive core timing. The VIP exercises ACT/RD/WR/PRE/REF with DDR7 timing windows and full bank/page protocol legality.

The command/address bus encodes DRAM commands on `cs_n/act_n/ras_n/cas_n/we_n`:

| Command | cs_n | act_n | ras_n | cas_n | we_n | Address bus |
|---------|------|-------|-------|-------|------|-------------|
| ACT     | 0    | 0     | -     | -     | -    | row         |
| RD      | 0    | 1     | 1     | 0     | 1    | column      |
| WR      | 0    | 1     | 1     | 0     | 0    | column      |
| PRE     | 0    | 1     | 0     | 1     | 0    | bank        |
| REF     | 0    | 1     | 0     | 0     | 1    | -           |
| NOP/DES | 1    | -     | -     | -     | -    | -           |

Timing parameters (cycles): tRCD=10, tRP=10, tRAS=24,
tCL=18, tCWL=16, tFAW=12, tRFC=32.

## 2. Architecture

```
tb/tb_top.sv                 testbench top: clk/reset, ddr7_if, DRAM memory model,
                             SVA checker instantiation (closed loop)
rtl/ddr7_if.sv                interface (CA bus + DQ + clocking block)
sequences/ddr7_sequence.sv    transaction + sequence library (below)
vip/ddr7/ddr7_driver.sv        command driver (ACT/RD/WR/PRE/REF + timing)
vip/ddr7/ddr7_monitor.sv       command/address bus decoder -> analysis port
vip/ddr7/ddr7_agent.sv         sequencer + driver + monitor
vip/ddr7/ddr7_scoreboard.sv    end-to-end expected-vs-observed comparison
vip/ddr7/ddr7_coverage.sv      functional coverage (3 covergroups, crosses)
vip/ddr7/ddr7_*_checker.sv     legacy L1/L2/L3 SVA checkers (module-based)
sva/ddr7_compliance_checker.sv consolidated L1-L4 compliance checker
env/ddr7_env.sv               environment (agent + scoreboard + coverage)
tests/ddr7_test.sv            base / directed / stress tests
```

Scoreboard flow: driver publishes expected transactions on `drv_ap`, monitor
publishes bus-decoded transactions on `ap`; the scoreboard compares them
in order and counts `n_matches`/`n_mismatches` (mismatch -> `UVM_ERROR`).

The `tb/tb_top.sv` DRAM memory model tracks bank/row state, stores write data
in a sparse `{bg,ba,row,col}` array, returns it on reads after tCL, and
counts refreshes -- closing the end-to-end data loop.

## 3. Sequence Library

| Sequence | Purpose |
|----------|---------|
| `ddr7_base_sequence`      | randomized baseline traffic |
| `ddr7_rw_round_seq`       | ACT->RD/WR->PRE round helper |
| `ddr7_write_seq`          | directed write rounds |
| `ddr7_read_seq`           | directed read rounds |
| `ddr7_refresh_seq`        | refresh traffic |
| `ddr7_bank_conflict_seq`  | same-bank ACT/PRE turnaround (tRP/tRCD pressure) |
| `ddr7_back_to_back_seq`   | inter-bank back-to-back accesses |
| `ddr7_page_hit_seq`       | corner: multiple accesses to one open row |
| `ddr7_page_miss_seq`      | corner: every access forces PRE+ACT |
| `ddr7_stress_seq`         | long randomized command mix |
| `ddr7_regression_seq`     | weighted mix of all directed sequences |

## 4. SVA Checkers (L1-L4)

Legacy tiered checkers (module-based, in `vip/ddr7/`):
- `ddr7_protocol_checker` (L1: basic compliance)
- `ddr7_timing_checker` (L2: timing windows)
- `ddr7_data_integrity_checker` (L2/L3: data rules)
- `ddr7_error_checker` (L3: error conditions)

Consolidated `sva/ddr7_compliance_checker.sv`:
- **L1 (3):** clock/command-bus/address sanity
- **L2 (3):** ACT encoding, bank-group range, CKE gating
- **L3 (2):** reset deselect, post-refresh quiet window
- **L4 (6):** tRCD (ACT->CAS), tRAS (ACT->PRE), tFAW (<=4 ACT/window),
  RD/WR only to open bank, no ACT to open bank, refresh interval (tREFI)

## 5. Functional Coverage

- `cg_cmd`        : command distribution x bank group / bank address (crosses)
- `cg_bank_state` : bank state transitions (IDLE/ACTIVE) x command (cross)
- `cg_addr`       : row/column regions, page hit/miss x burst length (cross)

## 6. Quick Start

```bash
cd ddr7_vip
make comp                                 # compile (VCS)
make sim                                  # run base test
make regress                              # directed regression test
make -C scripts SIMULATOR=vcs TEST=ddr7_directed_test   # portable flow
```

Tests: `ddr7_base_test` (default), `ddr7_directed_test`, `ddr7_stress_test`.
