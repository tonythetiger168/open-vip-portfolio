// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR7 Protocol Compliance Checker (L1) (PROTOCOL)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR7_PROTOCOL_CHECKER_SV
`define DDR7_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr7_protocol_checker (ddr7_if vif);

  property p_ddr7_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_ddr7_cmd_valid: assert property(p_ddr7_cmd_valid) else `uvm_warning("DDR7", "Command valid when CS active failed");
  cover_p_ddr7_cmd_valid: cover property(p_ddr7_cmd_valid);
  property p_ddr7_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_ddr7_addr_valid: assert property(p_ddr7_addr_valid) else `uvm_warning("DDR7", "Address valid failed");
  cover_p_ddr7_addr_valid: cover property(p_ddr7_addr_valid);
  property p_ddr7_bg; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bg <= 3'd7; endproperty
  assert_p_ddr7_bg: assert property(p_ddr7_bg) else `uvm_warning("DDR7", "Bank group 0-7 failed");
  cover_p_ddr7_bg: cover property(p_ddr7_bg);
  property p_ddr7_ba; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ba <= 2'd3; endproperty
  assert_p_ddr7_ba: assert property(p_ddr7_ba) else `uvm_warning("DDR7", "Bank address 0-3 failed");
  cover_p_ddr7_ba: cover property(p_ddr7_ba);

endmodule : ddr7_protocol_checker
`endif
