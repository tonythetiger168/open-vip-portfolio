// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR7 Error Handling Checker (L3) (ERROR)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR7_ERROR_CHECKER_SV
`define DDR7_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr7_error_checker (ddr7_if vif);

  property p_ddr7_pm; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ddr7_pm: assert property(p_ddr7_pm) else `uvm_warning("DDR7", "Power management failed");
  cover_p_ddr7_pm: cover property(p_ddr7_pm);
  property p_ddr7_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.refresh |-> ##[1:3900] vif.cs_n == 0; endproperty
  assert_p_ddr7_refresh: assert property(p_ddr7_refresh) else `uvm_warning("DDR7", "Refresh interval failed");
  cover_p_ddr7_refresh: cover property(p_ddr7_refresh);
  property p_ddr7_3ds; @(posedge vif.ck) disable iff (!vif.rst_n) vif.stack_id <= 3'd7; endproperty
  assert_p_ddr7_3ds: assert property(p_ddr7_3ds) else `uvm_warning("DDR7", "3DS stack failed");
  cover_p_ddr7_3ds: cover property(p_ddr7_3ds);
  property p_ddr7_wck; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ddr7_wck: assert property(p_ddr7_wck) else `uvm_warning("DDR7", "WCK ratio failed");
  cover_p_ddr7_wck: cover property(p_ddr7_wck);
  property p_ddr7_dfe; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dfe_tap <= 4'd15; endproperty
  assert_p_ddr7_dfe: assert property(p_ddr7_dfe) else `uvm_warning("DDR7", "DFE tap failed");
  cover_p_ddr7_dfe: cover property(p_ddr7_dfe);
  property p_ddr7_temp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp_sensor <= 8'd127; endproperty
  assert_p_ddr7_temp: assert property(p_ddr7_temp) else `uvm_warning("DDR7", "Temperature failed");
  cover_p_ddr7_temp: cover property(p_ddr7_temp);
  property p_ddr7_ecc; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ecc_en |-> vif.data_width >= 5'b01000; endproperty
  assert_p_ddr7_ecc: assert property(p_ddr7_ecc) else `uvm_warning("DDR7", "On-die ECC failed");
  cover_p_ddr7_ecc: cover property(p_ddr7_ecc);
  property p_ddr7_ca_parity; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ca_parity |-> ^vif.ca != 1'bx; endproperty
  assert_p_ddr7_ca_parity: assert property(p_ddr7_ca_parity) else `uvm_warning("DDR7", "CA parity failed");
  cover_p_ddr7_ca_parity: cover property(p_ddr7_ca_parity);

endmodule : ddr7_error_checker
`endif
