// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR7 Data Integrity Checker (L2) (DATA_INTEGRITY)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR7_DATA_INTEGRITY_CHECKER_SV
`define DDR7_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr7_data_integrity_checker (ddr7_if vif);

  property p_ddr7_bl; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {4'b1000,4'b1001,4'b1010,4'b1011}; endproperty
  assert_p_ddr7_bl: assert property(p_ddr7_bl) else `uvm_warning("DDR7", "Burst length 8/16/32/64 failed");
  cover_p_ddr7_bl: cover property(p_ddr7_bl);
  property p_ddr7_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[10:14] $fell(vif.cas_n); endproperty
  assert_p_ddr7_tRCD: assert property(p_ddr7_tRCD) else `uvm_warning("DDR7", "tRCD 10-14 cycles failed");
  cover_p_ddr7_tRCD: cover property(p_ddr7_tRCD);
  property p_ddr7_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.act_n) |-> ##[10:14] $fell(vif.act_n); endproperty
  assert_p_ddr7_tRP: assert property(p_ddr7_tRP) else `uvm_warning("DDR7", "tRP 10-14 cycles failed");
  cover_p_ddr7_tRP: cover property(p_ddr7_tRP);
  property p_ddr7_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[24:32] $rose(vif.act_n); endproperty
  assert_p_ddr7_tRAS: assert property(p_ddr7_tRAS) else `uvm_warning("DDR7", "tRAS 24-32 cycles failed");
  cover_p_ddr7_tRAS: cover property(p_ddr7_tRAS);
  property p_ddr7_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cas_n) && vif.we_n == 1 |-> ##[18:24] vif.dqs_t == 1; endproperty
  assert_p_ddr7_tCL: assert property(p_ddr7_tCL) else `uvm_warning("DDR7", "tCL 18-24 cycles failed");
  cover_p_ddr7_tCL: cover property(p_ddr7_tCL);
  property p_ddr7_odt; @(posedge vif.ck) disable iff (!vif.rst_n) vif.we_n == 0 && vif.cs_n == 0 |-> vif.odt == 1; endproperty
  assert_p_ddr7_odt: assert property(p_ddr7_odt) else `uvm_warning("DDR7", "ODT during write failed");
  cover_p_ddr7_odt: cover property(p_ddr7_odt);
  property p_ddr7_pam4; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pam4_en |-> vif.data_width >= 5'b01000; endproperty
  assert_p_ddr7_pam4: assert property(p_ddr7_pam4) else `uvm_warning("DDR7", "PAM4 mode valid failed");
  cover_p_ddr7_pam4: cover property(p_ddr7_pam4);
  property p_ddr7_fgr; @(posedge vif.ck) disable iff (!vif.rst_n) vif.fgr_mode inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ddr7_fgr: assert property(p_ddr7_fgr) else `uvm_warning("DDR7", "Fine granularity refresh failed");
  cover_p_ddr7_fgr: cover property(p_ddr7_fgr);
  property p_ddr7_dbim; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dbim inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ddr7_dbim: assert property(p_ddr7_dbim) else `uvm_warning("DDR7", "DBI mode valid failed");
  cover_p_ddr7_dbim: cover property(p_ddr7_dbim);
  property p_ddr7_crc; @(posedge vif.ck) disable iff (!vif.rst_n) vif.crc_en == 1 && vif.we_n == 0 |-> vif.crc != 8'h00; endproperty
  assert_p_ddr7_crc: assert property(p_ddr7_crc) else `uvm_warning("DDR7", "CRC on write failed");
  cover_p_ddr7_crc: cover property(p_ddr7_crc);

endmodule : ddr7_data_integrity_checker
`endif
