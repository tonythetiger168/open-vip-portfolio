// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR7 UVM agent -- sequencer + driver + monitor
`ifndef DDR7_AGENT_SV
`define DDR7_AGENT_SV

import uvm_pkg::*;
typedef class ddr7_driver;
typedef class ddr7_monitor;

class ddr7_sequencer extends uvm_sequencer #(ddr7_transaction);
  `uvm_component_utils(ddr7_sequencer)
  function new(string name = "ddr7_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

class ddr7_agent extends uvm_agent;
  `uvm_component_utils(ddr7_agent)
  ddr7_sequencer sqr;
  ddr7_driver    drv;
  ddr7_monitor   mon;

  function new(string name = "ddr7_agent", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    mon = ddr7_monitor::type_id::create("mon", this);
    if (is_active == UVM_ACTIVE) begin
      sqr = ddr7_sequencer::type_id::create("sqr", this);
      drv = ddr7_driver::type_id::create("drv", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (is_active == UVM_ACTIVE)
      drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
