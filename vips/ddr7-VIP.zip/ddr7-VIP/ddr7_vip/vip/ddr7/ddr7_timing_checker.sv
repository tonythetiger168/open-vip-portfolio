// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR7 Timing Performance Checker (L2) (TIMING)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR7_TIMING_CHECKER_SV
`define DDR7_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr7_timing_checker (ddr7_if vif);

  property p_ddr7_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[10:14] $fell(vif.cas_n); endproperty
  assert_p_ddr7_tRCD: assert property(p_ddr7_tRCD) else `uvm_warning("DDR7", "tRCD 10-14 cycles failed");
  cover_p_ddr7_tRCD: cover property(p_ddr7_tRCD);
  property p_ddr7_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.act_n) |-> ##[10:14] $fell(vif.act_n); endproperty
  assert_p_ddr7_tRP: assert property(p_ddr7_tRP) else `uvm_warning("DDR7", "tRP 10-14 cycles failed");
  cover_p_ddr7_tRP: cover property(p_ddr7_tRP);
  property p_ddr7_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[24:32] $rose(vif.act_n); endproperty
  assert_p_ddr7_tRAS: assert property(p_ddr7_tRAS) else `uvm_warning("DDR7", "tRAS 24-32 cycles failed");
  cover_p_ddr7_tRAS: cover property(p_ddr7_tRAS);
  property p_ddr7_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cas_n) && vif.we_n == 1 |-> ##[18:24] vif.dqs_t == 1; endproperty
  assert_p_ddr7_tCL: assert property(p_ddr7_tCL) else `uvm_warning("DDR7", "tCL 18-24 cycles failed");
  cover_p_ddr7_tCL: cover property(p_ddr7_tCL);

endmodule : ddr7_timing_checker
`endif
