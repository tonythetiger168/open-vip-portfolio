// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR7 UVM tests
`ifndef DDR7_TEST_SV
`define DDR7_TEST_SV

class ddr7_base_test extends uvm_test;
  `uvm_component_utils(ddr7_base_test)
  ddr7_env env;
  function new(string name = "ddr7_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = ddr7_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    ddr7_base_sequence seq;
    phase.raise_objection(this);
    seq = ddr7_base_sequence::type_id::create("seq");
    seq.num_transactions = 100;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed regression: every directed sequence in turn
class ddr7_directed_test extends ddr7_base_test;
  `uvm_component_utils(ddr7_directed_test)
  function new(string name = "ddr7_directed_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_phase(uvm_phase phase);
    ddr7_regression_seq seq;
    phase.raise_objection(this);
    seq = ddr7_regression_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress: long randomized command mix
class ddr7_stress_test extends ddr7_base_test;
  `uvm_component_utils(ddr7_stress_test)
  function new(string name = "ddr7_stress_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_phase(uvm_phase phase);
    ddr7_stress_seq seq;
    phase.raise_objection(this);
    seq = ddr7_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
