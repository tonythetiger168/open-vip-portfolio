# HDMI — HDMI 2.1 UVM VIP

Open-source UVM verification IP template for **HDMI 2.1** (Video).

## Contents

| Path | Description |
|------|-------------|
| `hdmi/hdmi_if.sv` | TMDS interface (3 pairs as 10-bit code words, hpd) + modports/clocking |
| `hdmi/hdmi_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `hdmi/sva/hdmi_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=6) |
| `hdmi/vip/hdmi/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/hdmi_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional HDMI sink DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **TMDS character-stream driver**: control preamble (8 characters, CTL tokens
  advertising HDCP/island/video), optional data island (island guard + TERC4
  packets), video guard band, pixel stream (TMDS 8b/10b code-word abstraction)
  and trailing CRC marker word; aborts video data when hpd drops
- **TERC4/TMDS encode library** (`hdmi_defs_pkg`): real control tokens, guard
  band codes, TERC4 4b/10b table, pixel 8b/10b abstraction, shared CRC-8 fold
- **Protocol-decoding monitor**: reconstructs each video data period from the
  character stream — preamble tokens (hdcp/island), guard-band check, pixel
  code-word decode, CRC recompute, hpd-drop detection
- **End-to-end scoreboard**: driver expected vs monitor observed; clean
  transfers compared field-by-field (rgb/hdcp/island/length/CRC),
  error-injected transfers by error class
- **Functional DUT model**: HDMI sink asserting hpd, decoding preamble tokens,
  accumulating the pixel-stream CRC and flagging CRC errors; drops hpd
  mid-stream on request (error injection)
- **Directed sequence library**: video / island / hdcp / long-burst /
  guard-error / hpd-error / reset + random + regression mix
- **Functional coverage**: island x length and hdcp x length crosses, pixel
  corner bins, link FSM states + guard/island/eol transition sequences,
  error-class bins (guard band, hpd drop)
- **SVA L4**: video data always preceded by guard band, preamble followed only
  by island or guard, video data only with hpd asserted (start + abort rules),
  TMDS pair complementarity, TMDS clock period stability
