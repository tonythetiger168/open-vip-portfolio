// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_hdmi_tb.sv -- self-checking functional test for the HDMI sink model
// (hdmi_sink_model in tb/top_tb.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py HDMI-VIP
//
// Model contract (from tb/top_tb.sv and hdmi_defs_pkg), tmds_cw = {ch2, ch1,
// ch0} 10-bit code words, period type on state (0 IDLE, 1 CONTROL_PREAMBLE,
// 2 DATA_ISLAND, 3 VIDEO_GUARD, 4 VIDEO_DATA):
//   * pixels are abstracted as {1, d[7:0], 0}; the last video word carries
//     {2'b11, crc} on ch0, where crc folds every pixel since the preamble:
//     crc = {crc[6:0], 0} ^ R ^ G ^ B ^ 0x1D. A mismatch pulses crc_err.
//   * a video guard band whose ch0 word is not 1011001100 is warned about.
//   * HPD: a rising edge on hpd_drop_req drops HPD for 3 clocks, starting 2
//     clocks later; requests while a drop is in progress are ignored.
//     (HPD itself is registered: low on the 4th..6th clock after the edge.)
// Known deviations (XFAIL):
//   * the pixel abstraction sets bit 9, so a blue value >= 0x80 has
//     bits [9:8] = 11 and is taken as the CRC word.
//   * preamble decoding: per HDMI 1.4b 5.2.1.1 a video preamble is
//     CTL0..3 = 1,0,0,0 (ch1 = CTRL1 token, ch2 = CTRL0 token) and a data
//     island preamble 1,0,1,0 (ch1 = ch2 = CTRL1); the model calls ch2 =
//     CTRL2 "video" and ch1 = CTRL1 "island".

module func_hdmi_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [2:0] S_IDLE = 0, S_PRE = 1, S_ISL = 2, S_VG = 3, S_VD = 4;
  localparam bit [9:0] CTRL0 = 10'b1101010100, CTRL1 = 10'b0010101011,
                       CTRL2 = 10'b0101010100, VG0 = 10'b1011001100, VG12 = 10'b0100110011;
  int checks = 0, fails = 0, xfails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, drop_req = 1'b0;
  logic [29:0] cw = '0;
  logic [2:0]  state = S_IDLE;
  wire         hpd, crc_err;

  always #5 clk = ~clk;

  hdmi_sink_model u_dut (
    .vif_tmds_clk(clk), .vif_rst_n(rst_n), .vif_tmds_cw(cw), .vif_hpd(hpd),
    .vif_hpd_drop_req(drop_req), .vif_crc_err(crc_err), .vif_state(state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  int err_pulses;
  always @(posedge clk) if (crc_err === 1'b1) err_pulses++;

  function automatic logic [9:0] pix(input [7:0] d); return {1'b1, d, 1'b0}; endfunction
  function automatic logic [7:0] crc_step(input [7:0] c, input [7:0] r, input [7:0] g, input [7:0] b);
    return {c[6:0], 1'b0} ^ r ^ g ^ b ^ 8'h1D;
  endfunction

  task automatic word(input [2:0] st, input [29:0] w);
    @(negedge clk); state = st; cw = w;
  endtask

  // one video period: preamble, guard band, n pixels, CRC word
  logic [7:0] crc;
  task automatic video(input int n, input [7:0] seed, input bit bad_crc = 0,
                       input bit bad_guard = 0, input [7:0] bmask = 8'h7F);
    logic [7:0] r, g, b;
    repeat (8) word(S_PRE, {CTRL2, CTRL1, CTRL0});
    word(S_VG, {VG12, VG12, bad_guard ? 10'h3FF : VG0});
    word(S_VG, {VG12, VG12, bad_guard ? 10'h3FF : VG0});
    crc = 8'h00;
    for (int i = 0; i < n; i++) begin
      r = seed + i; g = seed ^ (i * 5); b = (seed + 3 * i) & bmask;
      word(S_VD, {pix(r), pix(g), pix(b)});
      crc = crc_step(crc, r, g, b);
    end
    word(S_VD, {20'h0, 2'b11, crc ^ (bad_crc ? 8'h01 : 8'h00)});
    word(S_IDLE, {CTRL0, CTRL0, CTRL0});
    word(S_IDLE, {CTRL0, CTRL0, CTRL0});
  endtask

  int f0, low, first_low, t;

  initial begin
    repeat (2) @(negedge clk);
    chk(hpd === 1'b0, "HPD low in reset");
    rst_n = 1;
    repeat (2) @(negedge clk);
    chk(hpd === 1'b1, "HPD asserted after reset");

    // clean video periods
    f0 = u_dut.frame_count; err_pulses = 0;
    video(16, 8'h10);
    video(64, 8'h3A);
    chk(u_dut.frame_count == f0 + 2, "CRC word ends each video period (frame_count)");
    chk(err_pulses == 0 && u_dut.crc_err_count == 0, "matching CRC raises no error");

    // CRC restarts at every preamble
    video(1, 8'h00);
    chk(err_pulses == 0, "single-pixel period: CRC restarted at the preamble");

    // corrupted CRC
    video(16, 8'h10, 1);
    chk(err_pulses == 1 && u_dut.crc_err_count == 1, "CRC mismatch pulses crc_err once");
    video(16, 8'h10);
    chk(err_pulses == 1, "next clean period passes again");

    // corrupted pixel (CRC computed over the intended data)
    begin
      logic [7:0] c = 8'h00;
      repeat (4) word(S_PRE, {CTRL2, CTRL1, CTRL0});
      word(S_VG, {VG12, VG12, VG0});
      for (int i = 0; i < 8; i++) begin
        word(S_VD, {pix(8'h20 + i), pix(8'h40), pix(i == 5 ? 8'h01 : 8'h00)});
        c = crc_step(c, 8'h20 + i, 8'h40, 8'h00);
      end
      word(S_VD, {20'h0, 2'b11, c});
      word(S_IDLE, '0);
      word(S_IDLE, '0);
    end
    chk(err_pulses == 2, "single corrupted pixel caught by the CRC");

    // guard band check (warning only)
    video(4, 8'h01, 0, 1);
    chk(err_pulses == 2, "bad guard band does not affect the CRC");

    // pixels with blue >= 0x80
    f0 = u_dut.frame_count;
    video(8, 8'h90, 0, 0, 8'hFF);
    chk_xfail(u_dut.frame_count == f0 + 1 && err_pulses == 2,
              "blue >= 0x80 is pixel data, not the CRC word");

    // preamble decode
    word(S_IDLE, '0);
    word(S_PRE, {CTRL0, CTRL1, CTRL0});            // spec video preamble
    word(S_PRE, {CTRL0, CTRL1, CTRL0});
    chk_xfail(u_dut.preamble_video && !u_dut.preamble_island, "spec video preamble (ch1 CTRL1, ch2 CTRL0) decoded as video");
    word(S_IDLE, '0);
    @(negedge clk);
    chk(!u_dut.preamble_video && !u_dut.preamble_island, "preamble flags clear outside control periods");

    // HPD drop
    word(S_IDLE, '0);
    @(negedge clk); drop_req = 1;
    low = 0; first_low = -1;
    for (t = 0; t < 12; t++) begin
      @(negedge clk);
      drop_req = (t != 1);              // second request edge at t = 2, mid-drop
      if (!hpd) begin low++; if (first_low < 0) first_low = t; end
    end
    chk(low == 3, $sformatf("HPD low for 3 clocks (got %0d)", low));
    chk(first_low == 3, $sformatf("HPD drops on the 4th clock after the request (got %0d)", first_low));
    chk(low == 3, "a new request edge during the drop is ignored");
    drop_req = 0;
    repeat (8) @(negedge clk);
    chk(hpd === 1'b1, "HPD restored");
    // level held high does not retrigger
    @(negedge clk); drop_req = 1;
    repeat (20) @(negedge clk);
    low = 0;
    repeat (10) begin @(negedge clk); low += !hpd; end
    chk(low == 0, "a held request does not retrigger the drop");
    drop_req = 0;

    // reset mid-period
    repeat (2) word(S_PRE, {CTRL2, CTRL1, CTRL0});
    word(S_VD, {pix(1), pix(2), pix(3)});
    @(negedge clk); rst_n = 0;
    @(negedge clk);
    chk(!hpd && !crc_err && u_dut.crc_acc == 0, "reset: HPD low, CRC accumulator cleared");
    rst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
