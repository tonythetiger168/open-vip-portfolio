// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- HDMI 2.1 testbench top with a functional HDMI sink DUT model

`ifndef HDMI_TB_SV
`define HDMI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import hdmi_defs_pkg::*;
import hdmi_pkg::*;
import hdmi_test_pkg::*;

module top_tb;
  logic tmds_clk = 0;
  always #5ns tmds_clk = ~tmds_clk;

  hdmi_if vif(tmds_clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  hdmi_sink_model dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual hdmi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional HDMI sink: asserts hot-plug-detect, decodes the control
// preamble tokens, strips the guard bands, accumulates the pixel-stream
// CRC and flags mismatches on the trailing CRC marker word. Drops hpd
// mid-stream when the testbench requests it (error injection).
module hdmi_sink_model (hdmi_if vif);

  bit [7:0] crc_acc;
  int unsigned frame_count = 0;
  int unsigned crc_err_count = 0;
  int unsigned hpd_timer = 0;
  bit req_d = 0;
  bit preamble_video, preamble_island;

  // Hot-plug-detect with single mid-stream drop per request pulse
  // (2-cycle latency, 3-cycle low pulse)
  always @(posedge vif.tmds_clk) begin
    if (!vif.rst_n) begin
      vif.hpd <= 1'b0;
      hpd_timer <= 0;
      req_d <= 1'b0;
    end else begin
      req_d <= vif.hpd_drop_req;
      if (vif.hpd_drop_req && !req_d && hpd_timer == 0) hpd_timer <= 6;
      else if (hpd_timer != 0) hpd_timer <= hpd_timer - 1;
      vif.hpd <= (hpd_timer >= 2 && hpd_timer <= 4) ? 1'b0 : 1'b1;
    end
  end

  // Preamble / guard / pixel / CRC decode
  always @(posedge vif.tmds_clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      crc_acc <= 8'h00;
      vif.crc_err <= 1'b0;
      preamble_video <= 1'b0;
      preamble_island <= 1'b0;
    end else begin
      vif.crc_err <= 1'b0;
      unique case (vif.state)
        CONTROL_PREAMBLE: begin
          if (vif.tmds_cw[2] == TMDS_CTRL2) preamble_video  <= 1'b1;
          if (vif.tmds_cw[1] == TMDS_CTRL1) preamble_island <= 1'b1;
          crc_acc <= 8'h00;
        end
        VIDEO_GUARD: begin
          if (vif.tmds_cw[0] != TMDS_VGUARD_CH0)
            `uvm_warning("DUT", "sink: video guard band code not recognized")
        end
        VIDEO_DATA: begin
          if (is_tmds_crc_word(vif.tmds_cw[0])) begin
            frame_count++;
            if (vif.tmds_cw[0][7:0] != crc_acc) begin
              crc_err_count++;
              vif.crc_err <= 1'b1;
              `uvm_warning("DUT", $sformatf(
                "sink: CRC mismatch exp=%02h got=%02h",
                crc_acc, vif.tmds_cw[0][7:0]))
            end
          end else begin
            crc_acc <= hdmi_crc8(crc_acc,
                                 tmds_dec8(vif.tmds_cw[2]),
                                 tmds_dec8(vif.tmds_cw[1]),
                                 tmds_dec8(vif.tmds_cw[0]));
          end
        end
        default: begin
          preamble_video  <= 1'b0;
          preamble_island <= 1'b0;
        end
      endcase
    end
  end
endmodule
`endif
