// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdmi_if.sv -- HDMI 2.1 interface
// 3 TMDS data pairs carried as 10-bit code-word abstractions (one per
// tmds_clk = character rate), plus hot-plug-detect back-channel.

interface hdmi_if (input logic tmds_clk);
  import hdmi_defs_pkg::hdmi_state_e;

  logic rst_n;

  // Physical pairs (derived from the MSB of each code word: p = cw[9], n = ~p)
  logic [2:0] tmds_data_p;
  logic [2:0] tmds_data_n;

  // Abstract per-channel 10-bit code words (ch0 = blue, ch1 = green, ch2 = red)
  logic [9:0] tmds_cw [3];

  logic hpd;          // hot-plug detect, driven by the sink
  logic hpd_drop_req; // testbench knob: ask sink to drop hpd mid-stream
  logic crc_err;      // sink status: CRC mismatch on last video data period

  hdmi_state_e state;

  assign tmds_data_p = {tmds_cw[2][9], tmds_cw[1][9], tmds_cw[0][9]};
  assign tmds_data_n = ~tmds_data_p;

  modport SRC  (input  tmds_clk, rst_n, hpd, crc_err,
                output tmds_cw, hpd_drop_req, state);
  modport SINK (input  tmds_clk, rst_n, tmds_data_p, tmds_data_n, tmds_cw,
                       hpd_drop_req,
                output hpd, crc_err);
  modport MON  (input  tmds_clk, rst_n, tmds_data_p, tmds_data_n, tmds_cw,
                       hpd, crc_err, state);

  clocking drv_cb @(posedge tmds_clk);
    input  rst_n, hpd;
    output tmds_cw, hpd_drop_req, state;
  endclocking

  clocking mon_cb @(posedge tmds_clk);
    input rst_n, tmds_data_p, tmds_data_n, tmds_cw, hpd, crc_err, state;
  endclocking
endinterface
