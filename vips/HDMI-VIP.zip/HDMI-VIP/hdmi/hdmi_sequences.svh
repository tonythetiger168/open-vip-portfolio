// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdmi_sequences.svh -- HDMI sequence library

`ifndef HDMI_SEQUENCES_SVH
`define HDMI_SEQUENCES_SVH

class hdmi_base_sequence extends uvm_sequence #(hdmi_transaction);
  `uvm_object_utils(hdmi_base_sequence)
  int num_txns = 20;
  function new(string name = "hdmi_base_sequence"); super.new(name); endfunction
  task body();
    hdmi_transaction tr;
    repeat (num_txns) begin
      tr = hdmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: pure video data periods, no island, no errors
class hdmi_video_seq extends hdmi_base_sequence;
  function new(string name = "hdmi_video_seq"); super.new(name); endfunction
  `uvm_object_utils(hdmi_video_seq)
  task body();
    hdmi_transaction tr;
    repeat (num_txns) begin
      tr = hdmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { island == 0; err_inject == HDMI_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: every transfer carries a data island before the video period
class hdmi_island_seq extends hdmi_base_sequence;
  function new(string name = "hdmi_island_seq"); super.new(name); endfunction
  `uvm_object_utils(hdmi_island_seq)
  task body();
    hdmi_transaction tr;
    repeat (num_txns) begin
      tr = hdmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { island == 1; err_inject == HDMI_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: HDCP-encrypted content advertised in the preamble
class hdmi_hdcp_seq extends hdmi_base_sequence;
  function new(string name = "hdmi_hdcp_seq"); super.new(name); endfunction
  `uvm_object_utils(hdmi_hdcp_seq)
  task body();
    hdmi_transaction tr;
    repeat (num_txns) begin
      tr = hdmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { hdcp_en == 1; err_inject == HDMI_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: maximum-length video data periods (CRC stress)
class hdmi_long_burst_seq extends hdmi_base_sequence;
  function new(string name = "hdmi_long_burst_seq"); super.new(name); endfunction
  `uvm_object_utils(hdmi_long_burst_seq)
  task body();
    hdmi_transaction tr;
    repeat (num_txns) begin
      tr = hdmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { pixel_count == 8; err_inject == HDMI_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: corrupted video guard band
class hdmi_guard_error_seq extends hdmi_base_sequence;
  function new(string name = "hdmi_guard_error_seq"); super.new(name); endfunction
  `uvm_object_utils(hdmi_guard_error_seq)
  task body();
    hdmi_transaction tr;
    repeat (num_txns) begin
      tr = hdmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { err_inject == HDMI_ERR_GUARD; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: hot-plug-detect drops in the middle of video data
class hdmi_hpd_error_seq extends hdmi_base_sequence;
  function new(string name = "hdmi_hpd_error_seq"); super.new(name); endfunction
  `uvm_object_utils(hdmi_hpd_error_seq)
  task body();
    hdmi_transaction tr;
    repeat (num_txns) begin
      tr = hdmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { err_inject == HDMI_ERR_HPD;
                                  pixel_count inside {[4:8]}; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single small transfer right after reset release
class hdmi_reset_seq extends hdmi_base_sequence;
  function new(string name = "hdmi_reset_seq"); super.new(name); endfunction
  `uvm_object_utils(hdmi_reset_seq)
  task body();
    hdmi_transaction tr = hdmi_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { pixel_count == 1; island == 0;
                                err_inject == HDMI_ERR_NONE; });
    finish_item(tr);
  endtask
endclass

class hdmi_random_sequence extends hdmi_base_sequence;
  `uvm_object_utils(hdmi_random_sequence)
  function new(string name = "hdmi_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class hdmi_regression_sequence extends hdmi_base_sequence;
  `uvm_object_utils(hdmi_regression_sequence)
  function new(string name = "hdmi_regression_sequence"); super.new(name); endfunction
  task body();
    hdmi_video_seq       vid = hdmi_video_seq::type_id::create("vid");
    hdmi_island_seq      isl = hdmi_island_seq::type_id::create("isl");
    hdmi_hdcp_seq        enc = hdmi_hdcp_seq::type_id::create("enc");
    hdmi_long_burst_seq  br  = hdmi_long_burst_seq::type_id::create("br");
    hdmi_guard_error_seq gerr = hdmi_guard_error_seq::type_id::create("gerr");
    hdmi_hpd_error_seq   herr = hdmi_hpd_error_seq::type_id::create("herr");
    vid.num_txns = 20; isl.num_txns = 10; enc.num_txns = 10; br.num_txns = 10;
    gerr.num_txns = 4; herr.num_txns = 2;
    vid.start(m_sequencer); isl.start(m_sequencer); enc.start(m_sequencer);
    br.start(m_sequencer); gerr.start(m_sequencer); herr.start(m_sequencer);
  endtask
endclass
`endif
