// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdmi_defs.sv -- HDMI 2.1 shared type definitions
// TMDS / TERC4 10-bit code-word abstraction shared by VIP, DUT and SVA.

package hdmi_defs_pkg;
  typedef enum bit [2:0] {
    IDLE,
    CONTROL_PREAMBLE,
    DATA_ISLAND,
    VIDEO_GUARD,
    VIDEO_DATA
  } hdmi_state_e;

  // Error-injection classes
  typedef enum bit [1:0] {
    HDMI_ERR_NONE,      // clean transfer
    HDMI_ERR_GUARD,     // corrupted video guard band
    HDMI_ERR_HPD        // hot-plug-detect drops mid video data
  } hdmi_err_e;

  // ---- TMDS control-period tokens (real HDMI encodings) ----
  localparam bit [9:0] TMDS_CTRL0 = 10'b1101010100;
  localparam bit [9:0] TMDS_CTRL1 = 10'b0010101011;
  localparam bit [9:0] TMDS_CTRL2 = 10'b0101010100;
  localparam bit [9:0] TMDS_CTRL3 = 10'b1010101011;

  // ---- Guard bands ----
  localparam bit [9:0] TMDS_VGUARD_CH0  = 10'b1011001100; // video guard, ch0
  localparam bit [9:0] TMDS_VGUARD_CH12 = 10'b0100110011; // video guard, ch1/ch2
  localparam bit [9:0] TMDS_IGUARD_CH0  = 10'b1010001110; // island guard, ch0
  localparam bit [9:0] TMDS_IGUARD_CH12 = 10'b0100110011; // island guard, ch1/ch2

  // TMDS pixel encode abstraction: 8b -> 10b code word {1'b1, d, 1'b0}
  function automatic bit [9:0] tmds_enc8(bit [7:0] d);
    return {1'b1, d, 1'b0};
  endfunction

  function automatic bit [7:0] tmds_dec8(bit [9:0] c);
    return c[8:1];
  endfunction

  // TERC4 encode abstraction (HDMI data-island 4b/10b table)
  function automatic bit [9:0] terc4_enc(bit [3:0] n);
    case (n)
      4'h0: return 10'b1010011100;
      4'h1: return 10'b1001100011;
      4'h2: return 10'b1011100100;
      4'h3: return 10'b1011100010;
      4'h4: return 10'b0101110001;
      4'h5: return 10'b0100011110;
      4'h6: return 10'b0110001110;
      4'h7: return 10'b0100111100;
      4'h8: return 10'b1011001100;
      4'h9: return 10'b0100111001;
      4'hA: return 10'b0110011100;
      4'hB: return 10'b1011000110;
      4'hC: return 10'b1010001110;
      4'hD: return 10'b1001110001;
      4'hE: return 10'b0101100011;
      4'hF: return 10'b1011000011;
    endcase
  endfunction

  // CRC marker word carried on ch0 in the last VIDEO_DATA cycle
  function automatic bit [9:0] tmds_crc_word(bit [7:0] crc);
    return {2'b11, crc};
  endfunction

  function automatic bit is_tmds_crc_word(bit [9:0] c);
    return c[9:8] == 2'b11;
  endfunction

  // Pixel-stream CRC: rotate-left-1 then fold R/G/B with polynomial nibble
  function automatic bit [7:0] hdmi_crc8(bit [7:0] crc, bit [7:0] r,
                                         bit [7:0] g, bit [7:0] b);
    return {crc[6:0], 1'b0} ^ r ^ g ^ b ^ 8'h1D;
  endfunction
endpackage
