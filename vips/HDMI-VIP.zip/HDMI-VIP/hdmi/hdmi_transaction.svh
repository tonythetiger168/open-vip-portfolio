// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdmi_transaction.svh -- HDMI transaction: one video data period with
// optional preceding data island (preamble -> island -> guard -> pixels -> CRC)

`ifndef HDMI_TRANSACTION_SVH
`define HDMI_TRANSACTION_SVH

class hdmi_transaction extends uvm_sequence_item;

  rand bit [7:0]     red;
  rand bit [7:0]     green;
  rand bit [7:0]     blue;
  rand bit           hdcp_en;      // preamble advertises encrypted content
  rand bit           island;       // insert a data island before video
  rand int unsigned  pixel_count;  // pixels in the video data period
  rand hdmi_err_e    err_inject;   // error class for this transfer

  bit [7:0]          crc;          // golden CRC over the pixel stream
  bit                hpd_dropped;  // monitor: hpd fell during VIDEO_DATA
  bit                guard_bad;    // monitor: guard band code corrupted

  constraint c_pixels { pixel_count inside {[1:8]};
                        // mid-stream hpd drop needs a long enough stream
                        err_inject == HDMI_ERR_HPD -> pixel_count inside {[6:8]}; }
  constraint c_err    { err_inject dist {HDMI_ERR_NONE := 7,
                                         HDMI_ERR_GUARD := 2,
                                         HDMI_ERR_HPD := 1}; }
  constraint c_island { island dist {0 := 1, 1 := 1}; }

  `uvm_object_utils_begin(hdmi_transaction)
    `uvm_field_int(red, UVM_ALL_ON)
    `uvm_field_int(green, UVM_ALL_ON)
    `uvm_field_int(blue, UVM_ALL_ON)
    `uvm_field_int(hdcp_en, UVM_ALL_ON)
    `uvm_field_int(island, UVM_ALL_ON)
    `uvm_field_int(pixel_count, UVM_ALL_ON)
    `uvm_field_enum(hdmi_err_e, err_inject, UVM_ALL_ON)
    `uvm_field_int(crc, UVM_ALL_ON)
    `uvm_field_int(hpd_dropped, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(guard_bad, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "hdmi_transaction");
    super.new(name);
  endfunction

  function void post_randomize();
    crc = compute_crc(red, green, blue, pixel_count);
  endfunction

  // Golden pixel-stream CRC (shared polynomial in hdmi_defs_pkg)
  static function bit [7:0] compute_crc(bit [7:0] r, bit [7:0] g, bit [7:0] b,
                                        int unsigned n);
    bit [7:0] c = 8'h00;
    repeat (n) c = hdmi_defs_pkg::hdmi_crc8(c, r, g, b);
    return c;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    hdmi_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    // Error-injected transfers are compared by error class only (the wire
    // image is intentionally corrupted / truncated).
    if (err_inject != HDMI_ERR_NONE || t.err_inject != HDMI_ERR_NONE)
      do_compare &= (comparer.compare_field("err_inject", err_inject, t.err_inject, 2) == 1);
  endfunction

  function string convert2string();
    return $sformatf("HDMI rgb=(%02h,%02h,%02h) px=%0d hdcp=%0b island=%0b crc=%02h err=%s",
                     red, green, blue, pixel_count, hdcp_en, island, crc,
                     err_inject.name());
  endfunction
endclass
`endif
