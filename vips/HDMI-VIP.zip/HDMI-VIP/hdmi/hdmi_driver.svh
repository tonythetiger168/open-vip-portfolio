// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdmi_driver.svh -- HDMI source driver: drives TMDS character streams
// (control preamble -> optional data island -> video guard -> video data
// -> CRC) on the 10-bit code-word abstraction, honoring hot-plug-detect.

`ifndef HDMI_DRIVER_SVH
`define HDMI_DRIVER_SVH

class hdmi_driver extends uvm_driver #(hdmi_transaction);
  `uvm_component_utils(hdmi_driver)
  virtual hdmi_if vif;
  hdmi_config cfg;
  uvm_analysis_port #(hdmi_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hdmi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hdmi virtual interface not set")
  endfunction

  // Drive one code word per channel for n character periods
  task drive_cw(bit [9:0] c0, bit [9:0] c1, bit [9:0] c2, int n = 1);
    repeat (n) begin
      vif.drv_cb.tmds_cw[0] <= c0;
      vif.drv_cb.tmds_cw[1] <= c1;
      vif.drv_cb.tmds_cw[2] <= c2;
      @(vif.drv_cb);
    end
  endtask

  task drive_preamble(hdmi_transaction tr);
    vif.drv_cb.state <= hdmi_defs_pkg::CONTROL_PREAMBLE;
    // ch0: CTL3 advertises HDCP-encrypted content, ch1: CTL1 = island follows,
    // ch2: CTL2 = video data period follows
    drive_cw(tr.hdcp_en ? hdmi_defs_pkg::TMDS_CTRL3 : hdmi_defs_pkg::TMDS_CTRL0,
             tr.island  ? hdmi_defs_pkg::TMDS_CTRL1 : hdmi_defs_pkg::TMDS_CTRL0,
             hdmi_defs_pkg::TMDS_CTRL2, 8);
  endtask

  task drive_island(hdmi_transaction tr);
    bit [3:0] nibbles[4] = '{tr.blue[3:0], tr.blue[7:4],
                             tr.green[3:0], tr.green[7:4]};
    vif.drv_cb.state <= hdmi_defs_pkg::DATA_ISLAND;
    drive_cw(hdmi_defs_pkg::TMDS_IGUARD_CH0,
             hdmi_defs_pkg::TMDS_IGUARD_CH12,
             hdmi_defs_pkg::TMDS_IGUARD_CH12, 2);      // island guard band
    foreach (nibbles[k])                                // TERC4 island packets
      drive_cw(hdmi_defs_pkg::terc4_enc(nibbles[k]),
               hdmi_defs_pkg::terc4_enc(nibbles[k]),
               hdmi_defs_pkg::terc4_enc(nibbles[k]), 1);
  endtask

  task drive_video(hdmi_transaction tr);
    bit aborted = 0;
    vif.drv_cb.state <= hdmi_defs_pkg::VIDEO_GUARD;
    drive_cw(tr.err_inject == HDMI_ERR_GUARD ? ~hdmi_defs_pkg::TMDS_VGUARD_CH0
                                             :  hdmi_defs_pkg::TMDS_VGUARD_CH0,
             hdmi_defs_pkg::TMDS_VGUARD_CH12,
             hdmi_defs_pkg::TMDS_VGUARD_CH12, 2);      // video guard band
    if (tr.err_inject == HDMI_ERR_HPD) vif.drv_cb.hpd_drop_req <= 1'b1;
    vif.drv_cb.state <= hdmi_defs_pkg::VIDEO_DATA;
    for (int i = 0; i < tr.pixel_count; i++) begin
      if (vif.drv_cb.hpd !== 1'b1) begin                // hpd lost: abort
        `uvm_warning("DRV", "hpd dropped mid video data, aborting stream")
        aborted = 1;
        break;
      end
      drive_cw(hdmi_defs_pkg::tmds_enc8(tr.blue),
               hdmi_defs_pkg::tmds_enc8(tr.green),
               hdmi_defs_pkg::tmds_enc8(tr.red), 1);
    end
    if (!aborted)                                       // CRC marker word
      drive_cw(hdmi_defs_pkg::tmds_crc_word(tr.crc),
               hdmi_defs_pkg::tmds_crc_word(tr.crc),
               hdmi_defs_pkg::tmds_crc_word(tr.crc), 1);
    vif.drv_cb.hpd_drop_req <= 1'b0;
  endtask

  task run_phase(uvm_phase phase);
    hdmi_transaction tr;
    vif.drv_cb.state        <= hdmi_defs_pkg::IDLE;
    vif.drv_cb.tmds_cw[0]   <= hdmi_defs_pkg::TMDS_CTRL0;
    vif.drv_cb.tmds_cw[1]   <= hdmi_defs_pkg::TMDS_CTRL0;
    vif.drv_cb.tmds_cw[2]   <= hdmi_defs_pkg::TMDS_CTRL0;
    vif.drv_cb.hpd_drop_req <= 1'b0;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)

      wait (vif.hpd === 1'b1);          // sink must be hot-plugged
      drive_preamble(tr);
      if (tr.island) drive_island(tr);
      drive_video(tr);

      vif.drv_cb.state <= hdmi_defs_pkg::IDLE;
      drive_cw(hdmi_defs_pkg::TMDS_CTRL0,
               hdmi_defs_pkg::TMDS_CTRL0,
               hdmi_defs_pkg::TMDS_CTRL0, 4);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
