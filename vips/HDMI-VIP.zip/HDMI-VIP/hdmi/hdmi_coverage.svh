// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdmi_coverage.svh -- HDMI functional coverage: protocol (with crosses),
// link FSM (sampled from the interface) and error injection.

`ifndef HDMI_COVERAGE_SVH
`define HDMI_COVERAGE_SVH

class hdmi_coverage extends uvm_subscriber #(hdmi_transaction);
  `uvm_component_utils(hdmi_coverage)

  hdmi_transaction tr;
  virtual hdmi_if vif;

  covergroup cg_protocol;
    cp_hdcp  : coverpoint tr.hdcp_en { bins clr = {0}; bins enc = {1}; }
    cp_island: coverpoint tr.island  { bins no_island = {0}; bins island = {1}; }
    cp_len   : coverpoint tr.pixel_count {
      bins single = {1};
      bins short  = {[2:4]};
      bins long   = {[5:7]};
      bins burst  = {8};
    }
    cp_red   : coverpoint tr.red iff (tr.err_inject == HDMI_ERR_NONE) {
      bins zero = {8'h00}; bins ones = {8'hFF}; bins mid = {[8'h01:8'hFE]};
    }
    cp_blue  : coverpoint tr.blue iff (tr.err_inject == HDMI_ERR_NONE) {
      bins zero = {8'h00}; bins ones = {8'hFF}; bins mid = {[8'h01:8'hFE]};
    }
    cx_island_len : cross cp_island, cp_len;
    cx_hdcp_len   : cross cp_hdcp, cp_len;
  endgroup

  covergroup cg_fsm with function sample(hdmi_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, CONTROL_PREAMBLE, DATA_ISLAND,
                           VIDEO_GUARD, VIDEO_DATA};
    }
    cp_trans : coverpoint s {
      bins video_seq  = (CONTROL_PREAMBLE => VIDEO_GUARD => VIDEO_DATA);
      bins island_seq = (CONTROL_PREAMBLE => DATA_ISLAND => VIDEO_GUARD);
      bins eol_seq    = (VIDEO_DATA => IDLE => CONTROL_PREAMBLE);
    }
  endgroup

  covergroup cg_error;
    cp_err    : coverpoint tr.err_inject {
      bins clean = {HDMI_ERR_NONE};
      bins guard = {HDMI_ERR_GUARD};
      bins hpd   = {HDMI_ERR_HPD};
    }
    cp_hpd    : coverpoint tr.hpd_dropped { bins held = {0}; bins dropped = {1}; }
    cp_guard  : coverpoint tr.guard_bad   { bins good = {0}; bins bad = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual hdmi_if)::get(this, "", "vif", vif));
  endfunction

  // FSM coverage straight from the link; sampled only on state changes so
  // multi-cycle holds do not break transition chains
  task run_phase(uvm_phase phase);
    hdmi_state_e prev = hdmi_defs_pkg::IDLE;
    if (vif == null) return;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n === 1'b1 && vif.mon_cb.state != prev)
        cg_fsm.sample(vif.mon_cb.state);
      prev = vif.mon_cb.state;
    end
  endtask

  function void write(hdmi_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction
endclass
`endif
