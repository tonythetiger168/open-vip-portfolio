// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdmi_pkg.sv -- HDMI 2.1 UVM VIP package

package hdmi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import hdmi_defs_pkg::*;
  export hdmi_defs_pkg::*;

  `include "hdmi_transaction.svh"
  `include "hdmi_config.svh"
  `include "hdmi_sequencer.svh"
  `include "hdmi_driver.svh"
  `include "hdmi_monitor.svh"
  `include "hdmi_agent.svh"
  `include "hdmi_sequences.svh"
  `include "hdmi_checker.svh"
  `include "hdmi_coverage.svh"
endpackage
