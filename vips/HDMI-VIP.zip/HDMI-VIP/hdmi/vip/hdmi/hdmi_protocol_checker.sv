// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdmi_protocol_checker.sv -- HDMI 2.1 protocol rule checker

`ifndef HDMI_PROTOCOL_CHECKER_SV
`define HDMI_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import hdmi_defs_pkg::hdmi_state_e;

module hdmi_protocol_checker
(
  input logic tmds_clk,
  input logic rst_n,
  input hdmi_state_e state
);
  a_hdmi_protocol_state_known : assert property (@(posedge tmds_clk)
    disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("PROTOCOL", "hdmi protocol: state unknown")
endmodule
`endif
