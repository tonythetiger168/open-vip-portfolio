// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdmi_monitor.svh -- HDMI monitor: decodes the TMDS character stream
// (preamble tokens, island guard, video guard, pixel code words, CRC marker)
// and reconstructs one transaction per video data period.

`ifndef HDMI_MONITOR_SVH
`define HDMI_MONITOR_SVH

class hdmi_monitor extends uvm_monitor;
  `uvm_component_utils(hdmi_monitor)
  virtual hdmi_if vif;
  uvm_analysis_port #(hdmi_transaction) ap;
  int unsigned txn_count = 0;

  protected bit       hdcp_seen;    // CTRL3 token observed in preamble
  protected bit       island_seen;  // DATA_ISLAND since last video period
  protected bit       guard_bad;    // video guard band corrupted
  protected bit       hpd_dropped;  // hpd fell during VIDEO_DATA
  protected bit [7:0] pix_r, pix_g, pix_b;
  protected int unsigned pixel_cnt;
  protected bit [7:0] crc_calc;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hdmi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hdmi virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    hdmi_transaction tr;
    hdmi_state_e prev = hdmi_defs_pkg::IDLE;
    hdcp_seen = 0; island_seen = 0; guard_bad = 0; hpd_dropped = 0;
    pixel_cnt = 0; crc_calc = 8'h00;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        prev = hdmi_defs_pkg::IDLE;
        hdcp_seen = 0; island_seen = 0; guard_bad = 0; hpd_dropped = 0;
        pixel_cnt = 0; crc_calc = 8'h00;
        continue;
      end

      // Preamble decode: control tokens advertise hdcp / island / video
      if (vif.mon_cb.state == hdmi_defs_pkg::CONTROL_PREAMBLE) begin
        if (vif.mon_cb.tmds_cw[0] == hdmi_defs_pkg::TMDS_CTRL3) hdcp_seen = 1;
        if (vif.mon_cb.tmds_cw[1] == hdmi_defs_pkg::TMDS_CTRL1) island_seen = 1;
      end

      if (vif.mon_cb.state == hdmi_defs_pkg::DATA_ISLAND) island_seen = 1;

      // Video guard band check (first guard cycle)
      if (vif.mon_cb.state == hdmi_defs_pkg::VIDEO_GUARD &&
          prev != hdmi_defs_pkg::VIDEO_GUARD) begin
        if (vif.mon_cb.tmds_cw[0] != hdmi_defs_pkg::TMDS_VGUARD_CH0 ||
            vif.mon_cb.tmds_cw[1] != hdmi_defs_pkg::TMDS_VGUARD_CH12)
          guard_bad = 1;
      end

      // Video data decode: pixel code words + trailing CRC marker
      if (vif.mon_cb.state == hdmi_defs_pkg::VIDEO_DATA) begin
        if (!vif.mon_cb.hpd) hpd_dropped = 1;
        if (hdmi_defs_pkg::is_tmds_crc_word(vif.mon_cb.tmds_cw[0])) begin
          // CRC marker: publish the reconstructed transaction
          tr = hdmi_transaction::type_id::create("tr");
          tr.red         = pix_r;
          tr.green       = pix_g;
          tr.blue        = pix_b;
          tr.hdcp_en     = hdcp_seen;
          tr.island      = island_seen;
          tr.pixel_count = pixel_cnt;
          tr.crc         = crc_calc;
          tr.hpd_dropped = hpd_dropped;
          tr.guard_bad   = guard_bad;
          tr.err_inject  = guard_bad   ? HDMI_ERR_GUARD :
                           hpd_dropped ? HDMI_ERR_HPD : HDMI_ERR_NONE;
          txn_count++;
          `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
          ap.write(tr);
          hdcp_seen = 0; island_seen = 0; guard_bad = 0; hpd_dropped = 0;
          pixel_cnt = 0; crc_calc = 8'h00;
        end else begin
          if (pixel_cnt == 0) begin
            pix_b = hdmi_defs_pkg::tmds_dec8(vif.mon_cb.tmds_cw[0]);
            pix_g = hdmi_defs_pkg::tmds_dec8(vif.mon_cb.tmds_cw[1]);
            pix_r = hdmi_defs_pkg::tmds_dec8(vif.mon_cb.tmds_cw[2]);
          end
          crc_calc = hdmi_defs_pkg::hdmi_crc8(crc_calc, pix_r, pix_g, pix_b);
          pixel_cnt++;
        end
      end else if (prev == hdmi_defs_pkg::VIDEO_DATA) begin
        // Left VIDEO_DATA without a CRC marker (e.g. hpd abort)
        if (pixel_cnt > 0) begin
          tr = hdmi_transaction::type_id::create("tr");
          tr.red         = pix_r;
          tr.green       = pix_g;
          tr.blue        = pix_b;
          tr.hdcp_en     = hdcp_seen;
          tr.island      = island_seen;
          tr.pixel_count = pixel_cnt;
          tr.crc         = crc_calc;
          tr.hpd_dropped = hpd_dropped;
          tr.guard_bad   = guard_bad;
          tr.err_inject  = guard_bad   ? HDMI_ERR_GUARD :
                           hpd_dropped ? HDMI_ERR_HPD : HDMI_ERR_NONE;
          txn_count++;
          `uvm_info("MON", {"mon (truncated): ", tr.convert2string()}, UVM_HIGH)
          ap.write(tr);
        end
        hdcp_seen = 0; island_seen = 0; guard_bad = 0; hpd_dropped = 0;
        pixel_cnt = 0; crc_calc = 8'h00;
      end

      prev = vif.mon_cb.state;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("hdmi monitor observed %0d video data periods",
              txn_count), UVM_LOW)
  endfunction
endclass
`endif
