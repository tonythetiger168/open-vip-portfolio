// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdmi_compliance_checker.sv -- HDMI 2.1 SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = HDMI link-specific rules (guard band, preamble, hpd, TMDS clock)

`ifndef HDMI_COMPLIANCE_CHECKER_SV
`define HDMI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import hdmi_defs_pkg::*;

module hdmi_compliance_checker
(
  input logic tmds_clk,
  input logic rst_n,
  input hdmi_state_e state,
  input logic hpd,
  input logic [2:0] tmds_data_p,
  input logic [2:0] tmds_data_n
);

  // ---------------- L1: signal sanity (4) ----------------
  a_hdmi_l1_clk   : assert property (@(posedge tmds_clk) disable iff (!rst_n) !$isunknown(tmds_clk))
    else `uvm_error("SVA_L1", "hdmi: clock unknown")
  a_hdmi_l1_rst   : assert property (@(posedge tmds_clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "hdmi: reset unknown")
  a_hdmi_l1_state : assert property (@(posedge tmds_clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "hdmi: state unknown")
  a_hdmi_l1_valid : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    state inside {IDLE, CONTROL_PREAMBLE, DATA_ISLAND, VIDEO_GUARD, VIDEO_DATA})
    else `uvm_error("SVA_L1", "hdmi: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_hdmi_trans_idle : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, CONTROL_PREAMBLE})
    else `uvm_error("SVA_L2", "hdmi: illegal transition from IDLE")

  // L2-2: legal FSM transition from CONTROL_PREAMBLE (island or guard only)
  a_hdmi_trans_control_preamble : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    state == CONTROL_PREAMBLE |=> state inside {CONTROL_PREAMBLE, DATA_ISLAND, VIDEO_GUARD})
    else `uvm_error("SVA_L2", "hdmi: illegal transition from CONTROL_PREAMBLE")

  // L2-3: legal FSM transition from DATA_ISLAND
  a_hdmi_trans_data_island : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    state == DATA_ISLAND |=> state inside {DATA_ISLAND, VIDEO_GUARD})
    else `uvm_error("SVA_L2", "hdmi: illegal transition from DATA_ISLAND")

  // L2-4: legal FSM transition from VIDEO_GUARD
  a_hdmi_trans_video_guard : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    state == VIDEO_GUARD |=> state inside {VIDEO_GUARD, VIDEO_DATA})
    else `uvm_error("SVA_L2", "hdmi: illegal transition from VIDEO_GUARD")

  // L2-5: legal FSM transition from VIDEO_DATA
  a_hdmi_trans_video_data : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    state == VIDEO_DATA |=> state inside {VIDEO_DATA, IDLE})
    else `uvm_error("SVA_L2", "hdmi: illegal transition from VIDEO_DATA")

  // ---------------- L3: protocol rules (4) ----------------
  a_hdmi_l3_reset_idle : assert property (@(posedge tmds_clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "hdmi: state not IDLE during reset")
  a_hdmi_l3_no_stuck   : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    state == VIDEO_DATA |-> ##[1:12] (state != VIDEO_DATA))
    else `uvm_error("SVA_L3", "hdmi: stuck in VIDEO_DATA")
  a_hdmi_l3_full_cycle : cover property (@(posedge tmds_clk) disable iff (!rst_n)
    state == IDLE ##1 state == CONTROL_PREAMBLE);
  a_hdmi_l3_back_idle  : cover property (@(posedge tmds_clk) disable iff (!rst_n)
    state == VIDEO_DATA ##1 state == IDLE);

  // ---------------- L4: HDMI link-specific rules (6) ----------------
  // L4-1: every VIDEO_DATA period is immediately preceded by a guard band
  a_hdmi_l4_video_needs_guard : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    state == VIDEO_DATA |-> $past(state == VIDEO_GUARD) || $past(state == VIDEO_DATA))
    else `uvm_error("SVA_L4", "hdmi: video data without preceding guard band")

  // L4-2: after the control preamble only a data island or a guard band
  a_hdmi_l4_preamble_next : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    $past(state == CONTROL_PREAMBLE) && state != CONTROL_PREAMBLE
      |-> state inside {DATA_ISLAND, VIDEO_GUARD})
    else `uvm_error("SVA_L4", "hdmi: preamble not followed by island or guard band")

  // L4-3: video data may only start while hpd is asserted
  a_hdmi_l4_hpd_start : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    (state == VIDEO_GUARD) ##1 (state == VIDEO_DATA) |-> hpd)
    else `uvm_error("SVA_L4", "hdmi: video data started while hpd low")

  // L4-4: video data must stop on the cycle after hpd drops
  a_hdmi_l4_hpd_abort : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    $fell(hpd) && state == VIDEO_DATA |=> state != VIDEO_DATA)
    else `uvm_error("SVA_L4", "hdmi: video data continued after hpd drop")

  // L4-5: TMDS differential pairs stay complementary
  a_hdmi_l4_pair_comp : assert property (@(posedge tmds_clk) disable iff (!rst_n)
    tmds_data_n == ~tmds_data_p)
    else `uvm_error("SVA_L4", "hdmi: TMDS pair not complementary")

  // L4-6: TMDS character clock period is stable (10 ns +/- 1 ns)
  property p_hdmi_l4_clk_stable;
    realtime t0;
    @(posedge tmds_clk) disable iff (!rst_n)
      (1'b1, t0 = $realtime) |=> ($realtime - t0) >= 9.0 && ($realtime - t0) <= 11.0;
  endproperty
  a_hdmi_l4_clk_stable : assert property (p_hdmi_l4_clk_stable)
    else `uvm_error("SVA_L4", "hdmi: TMDS clock period unstable")

endmodule
`endif
