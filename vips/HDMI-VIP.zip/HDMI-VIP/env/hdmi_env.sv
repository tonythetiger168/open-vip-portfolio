// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdmi_env.sv -- HDMI 2.1 verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import hdmi_defs_pkg::*;
  import hdmi_pkg::*;

  // End-to-end scoreboard: compares driver-issued (expected) video data
  // periods against monitor-decoded (observed) ones. Error-injected
  // transfers are checked by error class, clean ones field-by-field.
    `uvm_analysis_imp_decl(_exp)
    `uvm_analysis_imp_decl(_obs)

  class hdmi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(hdmi_scoreboard)
    uvm_analysis_imp_exp #(hdmi_transaction, hdmi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(hdmi_transaction, hdmi_scoreboard) obs_ap;

    hdmi_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, mismatches = 0, error_hits = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(hdmi_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(hdmi_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        hdmi_transaction e = exp_q.pop_front();
        hdmi_transaction o = obs_q.pop_front();
        if (e.err_inject != HDMI_ERR_NONE || o.err_inject != HDMI_ERR_NONE) begin
          // Corrupted / truncated transfer: error class must line up
          if (e.err_inject == o.err_inject) error_hits++;
          else begin
            mismatches++;
            `uvm_error("SB", $sformatf("error-class mismatch exp{%s} obs{%s}",
                       e.convert2string(), o.convert2string()))
          end
        end
        else if (e.red == o.red && e.green == o.green && e.blue == o.blue &&
                 e.hdcp_en == o.hdcp_en && e.island == o.island &&
                 e.pixel_count == o.pixel_count && e.crc == o.crc)
          n_matches++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("hdmi scoreboard: n_matches=%0d error_hits=%0d mismatches=%0d",
                n_matches, error_hits, mismatches), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class hdmi_env extends uvm_env;
    `uvm_component_utils(hdmi_env)
    hdmi_agent      agt;
    hdmi_scoreboard sb;
    hdmi_checker    chk;
    hdmi_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = hdmi_agent::type_id::create("agt", this);
      sb  = hdmi_scoreboard::type_id::create("sb", this);
      chk = hdmi_checker::type_id::create("chk", this);
      cov = hdmi_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
