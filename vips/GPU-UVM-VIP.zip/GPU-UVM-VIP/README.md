# GPU UVM VIP (GPU-UVM-VIP)

UVM verification IP for the open-ip-portfolio **GPU** subsystem: GPU 2D engine: copy, fill, alpha blend and invert of RGBA8888 surfaces over AXI4.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`8e9722204875`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 1) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What GPU does (from the spec)

- One RGBA8888 pixel per 32-bit word; channel c is bits 8c+7:8c.
- MODE 0 COPY: dst = src.
- MODE 1 FILL: dst = COLOR, write-only.
- MODE 2 BLEND: per channel, dst.c = (src.c * A + COLOR.c * (256 - A)) >> 8 with A = min(ALPHA, 256).
- MODE 3 INVERT: dst = {src[31:24], ~src[23:0]}.
- PIXELS counts the pixels written by the last job.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `gpu/` -- `gpu_ral.svh` register model (generated from the spec, same
  offsets as `GPU_apb`), `gpu_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `gpu_pins_if.sv`
- `rtl/` -- `GPU_apb.sv`, `GPU_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/gpu.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | SRC_ADDR | rw |
| 0x018 | DST_ADDR | rw |
| 0x01C | LEN | rw |
| 0x020 | CTRL | rw |
| 0x024 | COLOR | rw |
| 0x028 | CMD | cmd |
| 0x02C | STATUS | ro |
| 0x030 | PIXELS | ro |
| 0x034 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR.

## Tests

| Test | Seeds |
|---|---|
| `gpu_ral_test` | 1 |
| `gpu_ops_test` | 3 |
| `gpu_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT GPU mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/gpu.f
./obj_dir/Vtop_tb +UVM_TESTNAME=gpu_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py GPU-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
