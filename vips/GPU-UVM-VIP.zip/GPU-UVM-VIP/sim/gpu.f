// GPU-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+gpu
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/GPU_top.sv
rtl/GPU_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
gpu/gpu_pins_if.sv
common/ssv_pkg.sv
gpu/gpu_pkg.sv
tb/top_tb.sv
