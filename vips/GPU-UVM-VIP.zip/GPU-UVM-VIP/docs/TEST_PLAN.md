# GPU-UVM-VIP test plan

## Register test (`gpu_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `gpu_ops_test`: 40 jobs cycling COPY / FILL / BLEND / INVERT, ALPHA 0, 1,
  128, 255, 256, 300 (clamped to 256) and random, random COLOR, lengths 1,
  16, 17, random up to 900, and line lengths 640, 1920 and 7680 (8K); four
  back-pressure settings; addresses near 4 KB boundaries. Every output
  pixel, PIXELS, STATUS, DONE / ERR, read / write counts (FILL reads
  nothing), windows, AXI ID 1.
- `gpu_err_test`: COPY from a SLVERR region (those pixels read as 0), BLEND
  into a DECERR region (untouched), FILL across a SLVERR region: DONE + ERR,
  STATUS.err; a clean job clears it.
