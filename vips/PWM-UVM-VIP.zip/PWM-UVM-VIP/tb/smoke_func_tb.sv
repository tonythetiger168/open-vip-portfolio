// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (PWM period/duty generation)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened pwm_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [15:0] period = '0;
  logic [15:0] duty = '0;
  logic enable = 1'b0;
  wire  pwm_out;
  wire  pwm_oe;

  always #5 clk = ~clk;

  pwm_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .period(period), .duty(duty), .enable(enable),
    .pwm_out(pwm_out), .pwm_oe(pwm_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(pwm_out === 1'b0, "pwm_out reset low");
    chk(pwm_oe  === 1'b0, "pwm_oe reset low");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // enabled, period=10, duty=4: exactly 4 high cycles per 10
    period = 16'd10; duty = 16'd4; enable = 1'b1;
    begin : pwm_win
      int highs = 0;
      repeat (20) begin step(); if (pwm_out === 1'b1) highs++; end
      chk(highs == 8, "50-cycle window has 2x duty=4 highs per period");
      chk(pwm_oe === 1'b1, "pwm_oe high while enabled");
    end

    // disabled: output forced low
    @(negedge clk); enable = 1'b0;
    repeat (15) begin step(); chk(pwm_out === 1'b0, "pwm_out low when disabled"); end
    chk(pwm_oe === 1'b0, "pwm_oe low when disabled");

    // duty=0: never high
    @(negedge clk); enable = 1'b1; duty = 16'd0;
    repeat (15) begin step(); chk(pwm_out === 1'b0, "pwm_out low at duty=0"); end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
