// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- PWM testbench top with a functional PWM DUT model

`ifndef PWM_TB_SV
`define PWM_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import pwm_defs_pkg::*;
import pwm_pkg::*;
import pwm_env_pkg::*;
import pwm_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  pwm_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  pwm_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .period(vif.period),
    .duty(vif.duty),
    .enable(vif.enable),
    .pwm_out(vif.pwm_out),
    .pwm_oe(vif.pwm_oe)
  );

  // Concurrent protocol checks
  pwm_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .period(vif.period), .duty(vif.duty), .enable(vif.enable), .pwm_out(vif.pwm_out), .pwm_oe(vif.pwm_oe)
  );

  initial begin
    uvm_config_db#(virtual pwm_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module pwm_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [15:0] period,
  input  logic [15:0] duty,
  input  logic        enable,
  output logic        pwm_out,
  output logic        pwm_oe
);
  logic [15:0] cnt;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cnt      <= '0;
      pwm_out  <= 1'b0;
      pwm_oe   <= 1'b0;
    end else begin
      pwm_oe  <= enable;
      if (!enable || period == 16'd0)
        cnt <= '0;
      else if (cnt >= period - 1)
        cnt <= '0;
      else
        cnt <= cnt + 1'b1;
      pwm_out <= enable && (period != 16'd0) && (cnt < duty);
    end
  end
endmodule
`endif
