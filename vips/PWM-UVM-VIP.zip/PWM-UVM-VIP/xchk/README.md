# Independent cross-check model (`xchk/`)

`pwm_xchk_tb.sv` checks the open-ip-portfolio `PWM` RTL (`rtl/PWM_top.sv`, `rtl/PWM_apb.sv`)
against the waveform computed from the documented PERIOD / DUTY rule, compared clock by clock. The model is written from the PWM rule of open-ip docs/ip/PWM.md, not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/pwm_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s pwm_xchk_tb -o xchk.vvp $OIP/rtl/PWM_top.sv $OIP/rtl/PWM_apb.sv xchk/pwm_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
