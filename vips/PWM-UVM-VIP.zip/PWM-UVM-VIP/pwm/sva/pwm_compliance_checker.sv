// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_compliance_checker.sv -- PWM concurrent assertion checks (bindable)

module pwm_compliance_checker
  (input logic clk, input logic rst_n, input [15:0] period, input [15:0] duty, input enable, input pwm_out, input pwm_oe);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({pwm_out, pwm_oe}))
    else $error("PWM: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> pwm_out == '0)
    else $error("PWM: output not in reset value");
  // pwm_out can only be high while enabled
  assert property (@(posedge clk) disable iff (!rst_n) pwm_out |-> pwm_oe)
    else $error("PWM: out high while not enabled");
  cover property (@(posedge clk) disable iff (!rst_n) (pwm_out != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (pwm_out == 1'b1));
endmodule
