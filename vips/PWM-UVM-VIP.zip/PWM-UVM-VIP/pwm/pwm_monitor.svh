// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_monitor.svh -- PWM monitor: measures pwm_out over each enable window

class pwm_monitor extends uvm_monitor;
  `uvm_component_utils(pwm_monitor)

  virtual pwm_if vif;
  uvm_analysis_port #(pwm_transaction) ap;
  pwm_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual pwm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "pwm: virtual interface not set")
    if (!uvm_config_db#(pwm_config)::get(this, "", "cfg", cfg))
      cfg = pwm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      pwm_transaction t;
      bit en_d = 0;
      int unsigned len = 0;
      forever begin
        @(vif.mon_cb);
        if (t != null) begin
          // outputs registered from the clocks enable was high
          len++;
          if (vif.mon_cb.pwm_out) t.high_cnt++;
          if (!vif.mon_cb.pwm_oe) t.oe_ok = 0;
          if (!vif.mon_cb.enable) begin
            t.periods = (t.period != 0) ? len / t.period : 0;
            if (t.period == 0 || len % t.period != 0)
              `uvm_error("MON", $sformatf("PWM enable window of %0d clocks is not whole periods", len))
            publish(t);
            t = null;
          end
        end
        if (vif.mon_cb.enable && !en_d) begin
          t = pwm_transaction::type_id::create("t");
          t.period = vif.mon_cb.period;
          t.duty   = vif.mon_cb.duty;
          t.oe_ok  = 1;
          len = 0;
        end
        en_d = vif.mon_cb.enable;
      end
    end
  endtask

  function void publish(pwm_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
