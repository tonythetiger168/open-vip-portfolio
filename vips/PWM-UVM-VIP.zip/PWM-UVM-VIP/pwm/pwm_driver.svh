// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_driver.svh -- PWM driver: enable for periods x period clocks with the item's setting, then disable

class pwm_driver extends uvm_driver #(pwm_transaction);
  `uvm_component_utils(pwm_driver)

  uvm_analysis_port #(pwm_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual pwm_if vif;
  pwm_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual pwm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "pwm: virtual interface not set")
    if (!uvm_config_db#(pwm_config)::get(this, "", "cfg", cfg))
      cfg = pwm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    pwm_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.enable <= 1'b0; vif.drv_cb.period <= '0; vif.drv_cb.duty <= '0;
  endtask

  task drive_item(pwm_transaction t);
    @(vif.drv_cb);
    vif.drv_cb.period <= t.period;
    vif.drv_cb.duty   <= t.duty;
    vif.drv_cb.enable <= 1'b1;
    repeat (t.periods * t.period) @(vif.drv_cb);
    vif.drv_cb.enable <= 1'b0;
    repeat (2) @(vif.drv_cb);   // counter back to 0 before the next setting
  endtask

endclass
