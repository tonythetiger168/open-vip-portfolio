// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_driver.svh -- PWM driver: reset, then per-item protocol stimulus

class pwm_driver extends uvm_driver #(pwm_transaction);
  `uvm_component_utils(pwm_driver)

  uvm_analysis_port #(pwm_transaction) ap;  // expected-item stream to scoreboard
  int unsigned item_cnt = 0;

  virtual pwm_if vif;
  pwm_config cfg;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction


  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual pwm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "pwm: virtual interface not set")
    void'(uvm_config_db#(pwm_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_item(pwm_transaction item);
    item.tag = item_cnt++;
    vif.period <= item.period;
    vif.duty <= item.duty;
    vif.enable <= item.enable;
    @(vif.drv_cb);
    ap.write(item);
  endtask
endclass
