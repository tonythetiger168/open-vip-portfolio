// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_transaction.svh -- PWM transaction

class pwm_transaction extends uvm_sequence_item;
  `uvm_object_utils(pwm_transaction)

  rand bit [15:0] period;
  rand bit [15:0] duty;
  rand bit enable;
  bit pwm_out_o;
  bit pwm_oe_o;
  bit [31:0] tag;

  function new(string name = "pwm_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    pwm_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    period = rhs_.period;
    duty = rhs_.duty;
    enable = rhs_.enable;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    pwm_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           period == rhs_.period &&
           duty == rhs_.duty &&
           enable == rhs_.enable;
  endfunction

  function string convert2string();
    return $sformatf("PWM{tag=%0h period=0x%0h duty=0x%0h enable=0x%0h}", tag, period, duty, enable);
  endfunction
endclass
