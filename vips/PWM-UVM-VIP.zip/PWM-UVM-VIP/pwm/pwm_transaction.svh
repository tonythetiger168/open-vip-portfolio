// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_transaction.svh -- PWM transaction

class pwm_transaction extends uvm_sequence_item;
  `uvm_object_utils(pwm_transaction)

  // request (driven by the agent)
  rand bit [15:0] period;
  rand bit [15:0] duty;
  rand bit [2:0] periods;
  // response (returned by the DUT)
  bit [15:0] high_cnt;
  bit oe_ok;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_cfg { period inside {[1:40]}; duty dist { 0 := 1, [1:40] :/ 6, [41:48] :/ 1 }; periods inside {[1:3]}; }

  function new(string name = "pwm_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    pwm_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    period = rhs_.period;
    duty = rhs_.duty;
    periods = rhs_.periods;
    high_cnt = rhs_.high_cnt;
    oe_ok = rhs_.oe_ok;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    pwm_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (period != rhs_.period) return 0;
    if (duty != rhs_.duty) return 0;
    if (periods != rhs_.periods) return 0;
    if (high_cnt != rhs_.high_cnt) return 0;
    if (oe_ok != rhs_.oe_ok) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(pwm_transaction rhs_);
    if (period != rhs_.period) return 0;
    if (duty != rhs_.duty) return 0;
    if (periods != rhs_.periods) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("PWM{tag=%0d period=0x%0h duty=0x%0h periods=0x%0h high_cnt=0x%0h oe_ok=0x%0h}", tag, period, duty, periods, high_cnt, oe_ok);
  endfunction
endclass
