// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_sequences.svh -- PWM sequences

// Random traffic: cfg.num_items constrained-random items.
class pwm_base_sequence extends uvm_sequence #(pwm_transaction);
  `uvm_object_utils(pwm_base_sequence)
  pwm_config cfg;

  function new(string name = "pwm_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = pwm_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "pwm_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class pwm_directed_sequence extends uvm_sequence #(pwm_transaction);
  `uvm_object_utils(pwm_directed_sequence)
  pwm_config cfg;

  function new(string name = "pwm_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function pwm_transaction item();
    item = pwm_transaction::type_id::create("req");
  endfunction

  task send(pwm_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    pwm_transaction t;
    t = item(); t.period = 10; t.duty = 0;  t.periods = 2; send(t);   // 0 %
    t = item(); t.period = 10; t.duty = 5;  t.periods = 3; send(t);   // 50 %
    t = item(); t.period = 10; t.duty = 10; t.periods = 1; send(t);   // 100 %
    t = item(); t.period = 10; t.duty = 15; t.periods = 2; send(t);   // duty above period
    t = item(); t.period = 1;  t.duty = 1;  t.periods = 3; send(t);
    t = item(); t.period = 1;  t.duty = 0;  t.periods = 2; send(t);
    t = item(); t.period = 40; t.duty = 1;  t.periods = 1; send(t);
  endtask
endclass
