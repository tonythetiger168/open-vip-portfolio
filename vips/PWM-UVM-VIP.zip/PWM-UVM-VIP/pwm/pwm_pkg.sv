// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_pkg.sv -- PWM UVM VIP package

package pwm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import pwm_defs_pkg::*;
  export pwm_defs_pkg::*;

  `include "pwm_transaction.svh"
  `include "pwm_config.svh"
  `include "pwm_sequencer.svh"
  `include "pwm_driver.svh"
  `include "pwm_monitor.svh"
  `include "pwm_agent.svh"
  `include "pwm_sequences.svh"
  `include "pwm_checker.svh"
  `include "pwm_coverage.svh"
endpackage
