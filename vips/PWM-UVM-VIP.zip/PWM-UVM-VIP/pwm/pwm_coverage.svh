// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_coverage.svh -- PWM functional coverage

class pwm_coverage extends uvm_subscriber #(pwm_transaction);
  `uvm_component_utils(pwm_coverage)
  pwm_config cfg;
  pwm_transaction tr;

  covergroup pwm_cg;
    cp_duty : coverpoint (tr.duty == 0 ? 0 : tr.duty < tr.period ? 1 : tr.duty == tr.period ? 2 : 3)
      { bins off = {0}; bins partial = {1}; bins full = {2}; bins over = {3}; }
    cp_per  : coverpoint tr.period { bins one = {1}; bins short_ = {[2:8]}; bins long_ = {[9:40]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    pwm_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(pwm_config)::get(this, "", "cfg", cfg))
      cfg = pwm_config::type_id::create("cfg");
  endfunction

  function void write(pwm_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    pwm_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("PWM coverage: %0.1f%%", pwm_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
