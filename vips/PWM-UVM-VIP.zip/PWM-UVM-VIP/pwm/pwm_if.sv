// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// pwm_if.sv -- PWM interface

interface pwm_if (input logic clk);
  logic rst_n;

  logic [15:0] period;
  logic [15:0] duty;
  logic enable;
  logic pwm_out;
  logic pwm_oe;

  modport DUT (input clk, rst_n, period, duty, enable, output pwm_out, pwm_oe);
  modport DRV (input clk, rst_n, pwm_out, pwm_oe, output period, duty, enable);
  modport MON (input clk, rst_n, period, duty, enable, pwm_out, pwm_oe);

  clocking drv_cb @(posedge clk);
    input rst_n, period, duty, enable, pwm_out, pwm_oe;
    output period, duty, enable;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, period, duty, enable, pwm_out, pwm_oe;
  endclocking
endinterface
