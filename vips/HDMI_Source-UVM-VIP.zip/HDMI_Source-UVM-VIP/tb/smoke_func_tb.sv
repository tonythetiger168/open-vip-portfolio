// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (HDMI source DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened hdmisrc_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;
  localparam integer HA = 64, VA = 16;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [9:0] tmds_ch0 = 10'h354, tmds_ch1 = 10'h354, tmds_ch2 = 10'h354;
  wire hpd, pix_valid, pix_sol, pix_sof, pkt_valid, pkt_ok, frm_valid;
  wire [23:0] pix_data;
  wire [31:0] pkt_hdr;
  wire [255:0] pkt_sp;
  wire [11:0] frm_lines, frm_badlen, frm_nogb;

  always #5 clk = ~clk;

  hdmisrc_model u_dut (.clk(clk), .rst_n(rst_n), .tmds_ch0(tmds_ch0), .tmds_ch1(tmds_ch1), .tmds_ch2(tmds_ch2),
                       .hpd(hpd), .pix_valid(pix_valid), .pix_data(pix_data), .pix_sol(pix_sol), .pix_sof(pix_sof),
                       .pkt_valid(pkt_valid), .pkt_hdr(pkt_hdr), .pkt_sp(pkt_sp), .pkt_ok(pkt_ok),
                       .frm_valid(frm_valid), .frm_lines(frm_lines), .frm_badlen(frm_badlen), .frm_nogb(frm_nogb));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // DVI 1.0 encoder (written from figure 3-5; the receiver only decodes)
  function automatic logic [17:0] enc(input logic [7:0] d, input integer cnt);
    logic [8:0] qm;
    logic [9:0] q;
    integer n1d, n1, n0;
    n1d = 0; for (int i = 0; i < 8; i++) n1d = n1d + d[i];
    qm[0] = d[0];
    if (n1d > 4 || (n1d == 4 && d[0] == 1'b0)) begin
      for (int i = 1; i < 8; i++) qm[i] = !(qm[i-1] ^ d[i]); qm[8] = 1'b0;
    end else begin
      for (int i = 1; i < 8; i++) qm[i] = qm[i-1] ^ d[i]; qm[8] = 1'b1;
    end
    n1 = 0; for (int i = 0; i < 8; i++) n1 = n1 + qm[i];
    n0 = 8 - n1;
    if (cnt == 0 || n1 == n0) begin
      q = {!qm[8], qm[8], qm[8] ? qm[7:0] : ~qm[7:0]};
      cnt = qm[8] ? cnt + (n1 - n0) : cnt + (n0 - n1);
    end else if ((cnt > 0 && n1 > n0) || (cnt < 0 && n0 > n1)) begin
      q = {1'b1, qm[8], ~qm[7:0]}; cnt = cnt + 2 * qm[8] + (n0 - n1);
    end else begin
      q = {1'b0, qm[8], qm[7:0]}; cnt = cnt - 2 * (!qm[8]) + (n1 - n0);
    end
    enc = {cnt[7:0], q};
  endfunction
  function automatic logic [9:0] tok(input logic vs, input logic hs);
    tok = ({vs, hs} == 2'b00) ? 10'h354 : ({vs, hs} == 2'b01) ? 10'h0AB : ({vs, hs} == 2'b10) ? 10'h154 : 10'h2AB;
  endfunction
  function automatic logic [9:0] t4(input logic [3:0] d);
    case (d)
      4'h0: t4 = 10'b1010011100; 4'h1: t4 = 10'b1001100011; 4'h2: t4 = 10'b1011100100; 4'h3: t4 = 10'b1011100010;
      4'h4: t4 = 10'b0101110001; 4'h5: t4 = 10'b0100011110; 4'h6: t4 = 10'b0110001110; 4'h7: t4 = 10'b0100111100;
      4'h8: t4 = 10'b1011001100; 4'h9: t4 = 10'b0100111001; 4'hA: t4 = 10'b0110011100; 4'hB: t4 = 10'b1011000110;
      4'hC: t4 = 10'b1010001110; 4'hD: t4 = 10'b1001110001; 4'hE: t4 = 10'b0101100011; default: t4 = 10'b1011000011;
    endcase
  endfunction
  function automatic logic [7:0] bch(input logic [55:0] bits, input integer n);
    logic [7:0] e;
    logic fb;
    e = 8'h00;
    for (int i = 0; i < 56; i++) if (i < n) begin fb = e[0] ^ bits[i]; e = e >> 1; if (fb) e = e ^ 8'h83; end
    bch = e;
  endfunction

  task automatic ch(input logic [9:0] a, input logic [9:0] b, input logic [9:0] c);
    @(negedge clk); tmds_ch0 = a; tmds_ch1 = b; tmds_ch2 = c;
  endtask
  integer np = 0, nsol = 0, nsof = 0, npk = 0, nfr = 0, nstray = 0;
  logic [23:0] pxlog [0:2047];
  logic [31:0] r_hdr; logic [255:0] r_sp; logic r_ok;
  logic [11:0] r_lines, r_bad, r_nogb;
  always @(posedge clk) begin
    if (rst_n && (pix_sol || pix_sof) && !pix_valid) nstray = nstray + 1;
    if (pix_valid) begin pxlog[np[10:0]] = pix_data; np = np + 1; if (pix_sol) nsol = nsol + 1; if (pix_sof) nsof = nsof + 1; end
    if (pkt_valid) begin npk = npk + 1; r_hdr = pkt_hdr; r_sp = pkt_sp; r_ok = pkt_ok; end
    if (frm_valid) begin nfr = nfr + 1; r_lines = frm_lines; r_bad = frm_badlen; r_nogb = frm_nogb; end
  end
  // pixel value of line l, pixel p
  function automatic logic [23:0] pv(input integer l, input integer p);
    pv = {l[7:0] ^ 8'h5A, p[7:0], l[3:0], p[3:0]} * 24'd2654435;
  endfunction
  logic [31:0] ph; logic [255:0] psp;
  // packet: AVI InfoFrame, optional bit flips (header bit fh, subpacket bit fs)
  task automatic mkpkt(input integer fh = -1, input integer fs = -1);
    logic [7:0] pb [0:27];
    logic [7:0] sum;
    for (int i = 0; i < 28; i++) pb[i] = 8'h00;
    pb[1] = 8'h50; pb[2] = 8'h08; pb[4] = 8'h10;
    sum = 8'h82 + 8'h02 + 8'h0D;
    for (int i = 1; i < 28; i++) sum = sum + pb[i];
    pb[0] = 8'h00 - sum;
    ph = {8'h00, 8'h0D, 8'h02, 8'h82};
    ph[31:24] = bch({32'h0, ph[23:0]}, 24);
    for (int k = 0; k < 4; k++) begin
      for (int i = 0; i < 7; i++) psp[64 * k + 8 * i +: 8] = pb[7 * k + i];
      psp[64 * k + 56 +: 8] = bch(psp[64 * k +: 56], 56);
    end
    if (fh >= 0) ph[fh] = ~ph[fh];
    if (fs >= 0) psp[fs] = ~psp[fs];
  endtask
  // frame: 1 front porch, 1 VSYNC, 2 back porch, VA active lines of 48 + 64 characters;
  // short = active line with HA - 1 pixels; nogb = active line without guard band; isl: island in line 2
  task automatic frame(input integer short_l = -1, input integer nogb_l = -1, input logic isl = 0,
                       input logic dvi = 0);
    integer c0, c1, c2, na, nb;
    logic [17:0] e;
    for (int l = 0; l < 4 + VA; l++) begin
      na = (l >= 4) ? ((l - 4 == short_l) ? HA - 1 : HA) : 0;
      nb = 112 - na;
      c0 = 0; c1 = 0; c2 = 0;
      for (int c = 0; c < 112; c++) if (c < nb) begin
        if (isl && l == 2 && c >= 16 && c < 60) begin
          if (c < 24) ch(tok(0, 0), 10'h0AB, 10'h0AB);
          else if (c < 26 || c >= 58) ch(t4({2'b11, 1'b0, 1'b0}), 10'h133, 10'h133);
          else ch(t4({c != 26, ph[c - 26], 1'b0, 1'b0}),
                  t4({psp[192 + 2 * (c - 26)], psp[128 + 2 * (c - 26)], psp[64 + 2 * (c - 26)], psp[2 * (c - 26)]}),
                  t4({psp[193 + 2 * (c - 26)], psp[129 + 2 * (c - 26)], psp[65 + 2 * (c - 26)], psp[1 + 2 * (c - 26)]}));
        end else if (l >= 4 && !dvi && l - 4 != nogb_l && c >= nb - 10) begin
          if (c < nb - 2) ch(tok(0, 0), 10'h0AB, 10'h354); else ch(10'h2CC, 10'h133, 10'h2CC);
        end else ch(tok(l == 1, c >= 8 && c < 16), 10'h354, 10'h354);
      end
      for (int p = 0; p < 64; p++) if (p < na) begin
        logic [9:0] a, b, d;
        logic [23:0] v;
        v = pv(l, p);
        e = enc(v[7:0], c0); a = e[9:0]; c0 = $signed(e[17:10]);
        e = enc(v[15:8], c1); b = e[9:0]; c1 = $signed(e[17:10]);
        e = enc(v[23:16], c2); d = e[9:0]; c2 = $signed(e[17:10]);
        ch(a, b, d);
      end
    end
    ch(tok(0, 0), 10'h354, 10'h354);
    repeat (4) @(negedge clk);
  endtask
  function automatic logic px_ok();
    logic ok;
    ok = (np == HA * VA);
    for (int l = 0; l < VA; l++) for (int p = 0; p < HA; p++) if (pxlog[l * HA + p] !== pv(l + 4, p)) ok = 0;
    px_ok = ok;
  endfunction

  initial begin
    repeat (3) @(posedge clk);
    chk(hpd === 1'b0 && pix_valid === 1'b0 && pix_sol === 1'b0 && pix_sof === 1'b0 && pkt_valid === 1'b0 &&
        frm_valid === 1'b0, "hpd low and no output in reset");
    rst_n = 1;
    repeat (20) @(negedge clk);
    chk(hpd === 1'b1, "hpd high after reset");
    // pixels before the first VSYNC are not captured
    for (int p = 0; p < 8; p++) ch(10'h1F0, 10'h1F0, 10'h1F0);
    ch(tok(0, 0), 10'h354, 10'h354); repeat (2) @(negedge clk);
    chk(np == 0, "no capture before a VSYNC rising edge");
    np = 0; nsol = 0; nsof = 0; npk = 0; nfr = 0;
    mkpkt(); frame(-1, -1, 1);
    chk(nfr == 1 && r_lines == VA && r_bad == 0 && r_nogb == 0, "frame report: 16 lines, no errors");
    chk(px_ok() && nsol == VA && nsof == 1, "every pixel decoded, one frame start, a line start per line");
    chk(npk == 1 && r_ok && r_hdr == ph && r_sp == psp, "AVI InfoFrame: header, subpackets, ECC ok");
    np = 0; nsol = 0; npk = 0; nfr = 0;
    mkpkt(27); frame(-1, -1, 1); chk(npk == 1 && !r_ok && r_hdr == ph, "header ECC bit flipped");
    np = 0; npk = 0; nfr = 0;
    mkpkt(-1, 130); frame(-1, -1, 1); chk(npk == 1 && !r_ok && r_sp == psp, "subpacket 2 data bit flipped");
    np = 0; nfr = 0;
    mkpkt(); frame(5, 9); chk(nfr == 1 && r_bad == 1 && r_nogb == 1 && np == HA * VA - 1, "short line and a line without guard band");
    np = 0; nfr = 0; npk = 0;
    frame(-1, -1, 0, 1); chk(nfr == 1 && r_bad == 0 && r_nogb == VA && px_ok() && npk == 0, "DVI mode: no guard bands");
    // inside a video period only a control token ends it: characters that look like guard bands are pixels
    np = 0;
    ch(tok(1, 0), 10'h354, 10'h354); ch(tok(0, 0), 10'h354, 10'h354);
    ch(10'h2CC, 10'h133, 10'h2CC); ch(10'h2CC, 10'h133, 10'h2CC);
    ch(10'h1F0, 10'h1F0, 10'h1F0); ch(10'h1F0, 10'h133, 10'h2CC); ch(10'h2CC, 10'h1F0, 10'h2CC); ch(10'h1F0, 10'h133, 10'h133);
    ch(tok(0, 0), 10'h354, 10'h354); repeat (3) @(negedge clk);
    chk(np == 4, $sformatf("guard-band-like characters in a video period are pixels (%0d)", np));
    chk(nstray == 0, "line / frame start only with a pixel");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
