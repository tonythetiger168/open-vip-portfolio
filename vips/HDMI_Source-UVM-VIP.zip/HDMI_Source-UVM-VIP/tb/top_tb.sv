// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- HDMI source testbench top with a functional HDMI source DUT model

`ifndef HDMI_SOURCE_UVM_VIP_TB_SV
`define HDMI_SOURCE_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import hdmisrc_defs_pkg::*;
import hdmisrc_pkg::*;
import hdmisrc_env_pkg::*;
import hdmisrc_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  hdmisrc_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  hdmisrc_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tmds_ch0(vif.tmds_ch0),
    .tmds_ch1(vif.tmds_ch1),
    .tmds_ch2(vif.tmds_ch2),
    .hpd(vif.hpd),
    .pix_valid(vif.pix_valid),
    .pix_data(vif.pix_data),
    .pix_sol(vif.pix_sol),
    .pix_sof(vif.pix_sof),
    .pkt_valid(vif.pkt_valid),
    .pkt_hdr(vif.pkt_hdr),
    .pkt_sp(vif.pkt_sp),
    .pkt_ok(vif.pkt_ok),
    .frm_valid(vif.frm_valid),
    .frm_lines(vif.frm_lines),
    .frm_badlen(vif.frm_badlen),
    .frm_nogb(vif.frm_nogb)
  );

  // Concurrent protocol checks
  hdmisrc_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tmds_ch0(vif.tmds_ch0),
    .tmds_ch1(vif.tmds_ch1),
    .tmds_ch2(vif.tmds_ch2),
    .hpd(vif.hpd),
    .pix_valid(vif.pix_valid),
    .pix_data(vif.pix_data),
    .pix_sol(vif.pix_sol),
    .pix_sof(vif.pix_sof),
    .pkt_valid(vif.pkt_valid),
    .pkt_hdr(vif.pkt_hdr),
    .pkt_sp(vif.pkt_sp),
    .pkt_ok(vif.pkt_ok),
    .frm_valid(vif.frm_valid),
    .frm_lines(vif.frm_lines),
    .frm_badlen(vif.frm_badlen),
    .frm_nogb(vif.frm_nogb)
  );

  initial begin
    uvm_config_db#(virtual hdmisrc_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module hdmisrc_model #(parameter int HACT = 64, parameter int VACT = 16) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [9:0]   tmds_ch0,
  input  logic [9:0]   tmds_ch1,
  input  logic [9:0]   tmds_ch2,
  output logic         hpd,
  output logic         pix_valid,
  output logic [23:0]  pix_data,
  output logic         pix_sol,
  output logic         pix_sof,
  output logic         pkt_valid,
  output logic [31:0]  pkt_hdr,
  output logic [255:0] pkt_sp,
  output logic         pkt_ok,
  output logic         frm_valid,
  output logic [11:0]  frm_lines,
  output logic [11:0]  frm_badlen,
  output logic [11:0]  frm_nogb
);
  function automatic logic [7:0] dec(input logic [9:0] q);
    logic [7:0] t, d;
    t = q[9] ? ~q[7:0] : q[7:0];
    d[0] = t[0];
    for (int i = 1; i < 8; i++) d[i] = q[8] ? (t[i] ^ t[i-1]) : !(t[i] ^ t[i-1]);
    dec = d;
  endfunction
  function automatic logic [4:0] terc4(input logic [9:0] q);
    case (q)
      10'b1010011100: terc4 = 5'h10; 10'b1001100011: terc4 = 5'h11; 10'b1011100100: terc4 = 5'h12;
      10'b1011100010: terc4 = 5'h13; 10'b0101110001: terc4 = 5'h14; 10'b0100011110: terc4 = 5'h15;
      10'b0110001110: terc4 = 5'h16; 10'b0100111100: terc4 = 5'h17; 10'b1011001100: terc4 = 5'h18;
      10'b0100111001: terc4 = 5'h19; 10'b0110011100: terc4 = 5'h1A; 10'b1011000110: terc4 = 5'h1B;
      10'b1010001110: terc4 = 5'h1C; 10'b1001110001: terc4 = 5'h1D; 10'b0101100011: terc4 = 5'h1E;
      10'b1011000011: terc4 = 5'h1F;
      default:        terc4 = 5'h00;
    endcase
  endfunction
  function automatic logic [7:0] bch(input logic [55:0] bits, input integer n);
    logic [7:0] e;
    logic fb;
    e = 8'h00;
    for (int i = 0; i < 56; i++) if (i < n) begin
      fb = e[0] ^ bits[i];
      e = e >> 1;
      if (fb) e = e ^ 8'h83;
    end
    bch = e;
  endfunction

  logic [3:0]   hcnt;
  logic         vs_q, armed, in_vid, gbs, first;
  logic [1:0]   isl;
  logic [5:0]   ni;
  logic [31:0]  h;
  logic [255:0] s;
  logic [11:0]  nlines, ll, badlen, nogb;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      hpd <= 1'b0; hcnt <= '0;
      vs_q <= 1'b0; armed <= 1'b0; in_vid <= 1'b0; gbs <= 1'b0; first <= 1'b0; isl <= '0; ni <= '0;
      h <= '0; s <= '0; nlines <= '0; ll <= '0; badlen <= '0; nogb <= '0;
      pix_valid <= 1'b0; pix_data <= '0; pix_sol <= 1'b0; pix_sof <= 1'b0;
      pkt_valid <= 1'b0; pkt_hdr <= '0; pkt_sp <= '0; pkt_ok <= 1'b0;
      frm_valid <= 1'b0; frm_lines <= '0; frm_badlen <= '0; frm_nogb <= '0;
    end else begin : step
      logic        c_ok, c_vs;
      logic [4:0]  a, b, d;
      logic [31:0] hn;
      logic [255:0] sn;
      logic        ok;
      pix_valid <= 1'b0; pix_sol <= 1'b0; pix_sof <= 1'b0; pkt_valid <= 1'b0; frm_valid <= 1'b0;
      if (hcnt != 4'hF) hcnt <= hcnt + 4'd1; else hpd <= 1'b1;
      c_ok = (tmds_ch0 == 10'h354) || (tmds_ch0 == 10'h0AB) || (tmds_ch0 == 10'h154) || (tmds_ch0 == 10'h2AB);
      c_vs = (tmds_ch0 == 10'h154) || (tmds_ch0 == 10'h2AB);
      if (c_ok) begin
        if (in_vid && armed) begin
          if (ll != HACT) badlen <= badlen + 12'd1;
          if (!gbs) nogb <= nogb + 12'd1;
          nlines <= nlines + 12'd1;
          if (nlines == VACT - 1) begin
            frm_valid <= 1'b1; frm_lines <= nlines + 12'd1;
            frm_badlen <= badlen + ((ll != HACT) ? 12'd1 : 12'd0);
            frm_nogb <= nogb + (gbs ? 12'd0 : 12'd1);
            armed <= 1'b0;
          end
        end
        in_vid <= 1'b0; gbs <= 1'b0; isl <= '0;
        if (c_vs && !vs_q) begin armed <= 1'b1; first <= 1'b1; nlines <= '0; badlen <= '0; nogb <= '0; end
        vs_q <= c_vs;
      end else if (!in_vid && tmds_ch1 == 10'h133 && tmds_ch2 == 10'h133) begin
        isl <= isl + 2'd1;
        if (isl == 2'd1) begin ni <= '0; h <= '0; s <= '0; end
      end else if (!in_vid && isl == 2'd2) begin
        a = terc4(tmds_ch0); b = terc4(tmds_ch1); d = terc4(tmds_ch2);
        hn = h; sn = s;
        hn[ni[4:0]] = a[2];
        for (int k = 0; k < 4; k++) begin
          sn[64 * k + 2 * ni[4:0]] = b[k];
          sn[64 * k + 2 * ni[4:0] + 1] = d[k];
        end
        if (ni == 6'd31) begin
          ok = (bch({32'h0, hn[23:0]}, 24) == hn[31:24]);
          for (int k = 0; k < 4; k++) if (bch(sn[64 * k +: 56], 56) != sn[64 * k + 56 +: 8]) ok = 1'b0;
          pkt_valid <= 1'b1; pkt_hdr <= hn; pkt_sp <= sn; pkt_ok <= ok;
          ni <= '0; h <= '0; s <= '0;
        end else begin
          ni <= ni + 6'd1; h <= hn; s <= sn;
        end
      end else if (!in_vid && tmds_ch0 == 10'h2CC && tmds_ch1 == 10'h133 && tmds_ch2 == 10'h2CC) begin
        gbs <= 1'b1;
      end else if (armed) begin
        pix_valid <= 1'b1;
        pix_data <= {dec(tmds_ch2), dec(tmds_ch1), dec(tmds_ch0)};
        pix_sol <= !in_vid;
        pix_sof <= !in_vid && first;
        if (!in_vid) begin ll <= 12'd1; first <= 1'b0; end else ll <= ll + 12'd1;
        in_vid <= 1'b1;
      end
    end
  end
endmodule
`endif
