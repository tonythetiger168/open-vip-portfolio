// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_defs.sv -- HDMI source shared type definitions

package hdmisrc_defs_pkg;

  typedef enum bit [1:0] {HDMISRC_OK, HDMISRC_ERR} hdmisrc_status_e;

  localparam bit [9:0] HS_GB_V02 = 10'h2CC;   // video guard band, channels 0 and 2
  localparam bit [9:0] HS_GB_V1  = 10'h133;   // video guard band channel 1, island guard band channels 1 and 2
  // DVI 1.0 figure 3-5 encoder; cnt is the running disparity of the channel
  function automatic bit [9:0] hs_enc(bit [7:0] d, ref int cnt);
    bit [8:0] qm;
    int n1d = $countones(d), n1, n0;
    qm[0] = d[0];
    if (n1d > 4 || (n1d == 4 && d[0] == 1'b0)) begin
      for (int i = 1; i < 8; i++) qm[i] = !(qm[i-1] ^ d[i]);
      qm[8] = 1'b0;
    end else begin
      for (int i = 1; i < 8; i++) qm[i] = qm[i-1] ^ d[i];
      qm[8] = 1'b1;
    end
    n1 = $countones(qm[7:0]); n0 = 8 - n1;
    if (cnt == 0 || n1 == n0) begin
      cnt = qm[8] ? cnt + (n1 - n0) : cnt + (n0 - n1);
      return {!qm[8], qm[8], qm[8] ? qm[7:0] : ~qm[7:0]};
    end
    if ((cnt > 0 && n1 > n0) || (cnt < 0 && n0 > n1)) begin
      cnt = cnt + 2 * qm[8] + (n0 - n1);
      return {1'b1, qm[8], ~qm[7:0]};
    end
    cnt = cnt - 2 * (!qm[8]) + (n1 - n0);
    return {1'b0, qm[8], qm[7:0]};
  endfunction
  function automatic bit [7:0] hs_dec(bit [9:0] q);
    bit [7:0] t = q[9] ? ~q[7:0] : q[7:0], d;
    d[0] = t[0];
    for (int i = 1; i < 8; i++) d[i] = q[8] ? (t[i] ^ t[i-1]) : !(t[i] ^ t[i-1]);
    return d;
  endfunction
  function automatic bit [9:0] hs_tok(bit c1, bit c0);
    case ({c1, c0})
      2'b00: return 10'h354;
      2'b01: return 10'h0AB;
      2'b10: return 10'h154;
      default: return 10'h2AB;
    endcase
  endfunction
  function automatic bit [2:0] hs_ctl(bit [9:0] q);    // {valid, C1, C0}
    case (q)
      10'h354: return 3'b100;
      10'h0AB: return 3'b101;
      10'h154: return 3'b110;
      10'h2AB: return 3'b111;
      default: return 3'b000;
    endcase
  endfunction
  function automatic bit [9:0] hs_terc4(bit [3:0] d);
    case (d)
      4'h0: return 10'b1010011100; 4'h1: return 10'b1001100011; 4'h2: return 10'b1011100100; 4'h3: return 10'b1011100010;
      4'h4: return 10'b0101110001; 4'h5: return 10'b0100011110; 4'h6: return 10'b0110001110; 4'h7: return 10'b0100111100;
      4'h8: return 10'b1011001100; 4'h9: return 10'b0100111001; 4'hA: return 10'b0110011100; 4'hB: return 10'b1011000110;
      4'hC: return 10'b1010001110; 4'hD: return 10'b1001110001; 4'hE: return 10'b0101100011; default: return 10'b1011000011;
    endcase
  endfunction
  function automatic bit [4:0] hs_terc4_dec(bit [9:0] q);  // {valid, d}
    for (int i = 0; i < 16; i++) if (hs_terc4(i) == q) return {1'b1, 4'(i)};
    return 5'h00;
  endfunction
  // packet ECC: BCH, G(x) = 1 + x^6 + x^7 + x^8, bit 0 first
  function automatic bit [7:0] hs_bch(bit [55:0] bits, int n);
    bit [7:0] e = 0;
    for (int i = 0; i < n; i++) begin
      bit fb = e[0] ^ bits[i];
      e = e >> 1;
      if (fb) e ^= 8'h83;
    end
    return e;
  endfunction
  // CTA-861 timing presets {h_active, h_front, h_sync, h_back, v_active, v_front, v_sync, v_back}:
  // 0 bench default 64x16, 1 640x480p60 (VIC 1), 2 1080p60 (VIC 16), 3 2160p60 (VIC 97),
  // 4 4320p60 (VIC 199; check against CTA-861 before relying on it)
  function automatic bit [15:0] hs_preset(int id, int f);
    bit [15:0] t [8];
    case (id)
      1: t = '{640, 16, 96, 48, 480, 10, 2, 33};
      2: t = '{1920, 88, 44, 148, 1080, 4, 5, 36};
      3: t = '{3840, 176, 88, 296, 2160, 8, 10, 72};
      4: t = '{7680, 552, 176, 2392, 4320, 16, 20, 44};
      default: t = '{64, 8, 8, 32, 16, 1, 1, 2};
    endcase
    return t[f];
  endfunction

endpackage
