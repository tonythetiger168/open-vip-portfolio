// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_coverage.svh -- HDMI source functional coverage

class hdmisrc_coverage extends uvm_subscriber #(hdmisrc_transaction);
  `uvm_component_utils(hdmisrc_coverage)
  hdmisrc_config cfg;
  hdmisrc_transaction tr;

  covergroup hdmisrc_cg;
    cp_pkt    : coverpoint tr.hdr.size() { bins none = {0}; bins one = {1}; }
    cp_ok     : coverpoint (tr.rok.size() ? tr.rok[0] : 1'b1) iff (tr.hdr.size()) { bins good = {1}; bins bad_ecc = {0}; }
    cp_type   : coverpoint (tr.hdr.size() ? tr.hdr[0][7:0] : 8'h00) iff (tr.hdr.size()) { bins avi = {8'h82}; bins audio = {8'h84}; }
    cp_badlen : coverpoint tr.rbadlen { bins none = {0}; bins some = {[1:$]}; }
    cp_nogb   : coverpoint tr.rnogb { bins none = {0}; bins one = {1}; bins dvi = {[2:$]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    hdmisrc_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(hdmisrc_config)::get(this, "", "cfg", cfg))
      cfg = hdmisrc_config::type_id::create("cfg");
  endfunction

  function void write(hdmisrc_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    hdmisrc_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("HDMI source coverage: %0.1f%%", hdmisrc_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
