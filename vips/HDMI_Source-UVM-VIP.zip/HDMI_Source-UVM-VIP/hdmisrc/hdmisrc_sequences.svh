// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_sequences.svh -- HDMI source sequences

// Random traffic: cfg.num_items constrained-random items.
class hdmisrc_base_sequence extends uvm_sequence #(hdmisrc_transaction);
  `uvm_object_utils(hdmisrc_base_sequence)
  hdmisrc_config cfg;

  function new(string name = "hdmisrc_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = hdmisrc_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "hdmisrc_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class hdmisrc_directed_sequence extends uvm_sequence #(hdmisrc_transaction);
  `uvm_object_utils(hdmisrc_directed_sequence)
  hdmisrc_config cfg;

  function new(string name = "hdmisrc_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function hdmisrc_transaction item();
    item = hdmisrc_transaction::type_id::create("req");
  endfunction

  task send(hdmisrc_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    hdmisrc_transaction t;
    // AVI and audio InfoFrames, ECC faults, short / long lines, missing guard band, DVI mode, colour bars
    t = item(); t.set(0, 32'h1); send(t);
    t = item(); t.set(10, 32'h2); send(t);
    t = item(); t.set(11, 32'h3); send(t);
    for (int s = 0; s < 3; s++) begin
      t = item(); t.set(4, 32'h1000 * (s + 1) + 7); send(t);
      t = item(); t.set(5, 32'h2000 * (s + 1) + 3); send(t);
      t = item(); t.set(6, 32'h300 * (s + 1)); send(t);
      t = item(); t.set(7, 32'h500 * (s + 1)); send(t);
      t = item(); t.set(8, 32'h700 * (s + 1)); send(t);
    end
    t = item(); t.set(9, 32'h9); send(t);
    t = item(); t.set(1, 32'hA5A5); send(t);
  endtask
endclass
