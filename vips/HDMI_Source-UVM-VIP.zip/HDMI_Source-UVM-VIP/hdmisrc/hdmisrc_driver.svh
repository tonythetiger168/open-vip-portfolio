// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_driver.svh -- HDMI source driver: one frame of TMDS characters per item (blanking with sync tokens, preamble, guard band, TMDS pixels, an optional InfoFrame island), after hpd is high

class hdmisrc_driver extends uvm_driver #(hdmisrc_transaction);
  `uvm_component_utils(hdmisrc_driver)

  uvm_analysis_port #(hdmisrc_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual hdmisrc_if vif;
  hdmisrc_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hdmisrc_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hdmisrc: virtual interface not set")
    if (!uvm_config_db#(hdmisrc_config)::get(this, "", "cfg", cfg))
      cfg = hdmisrc_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    hdmisrc_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.tmds_ch0 <= 10'h354;
    vif.drv_cb.tmds_ch1 <= 10'h354;
    vif.drv_cb.tmds_ch2 <= 10'h354;
  endtask

  task drive_item(hdmisrc_transaction t);
    bit [31:0] x = t.seed | 1;
    int nl = cfg.v_front + cfg.v_sync + cfg.v_back + cfg.v_active;
    int hb = cfg.h_front + cfg.h_sync + cfg.h_back;
    int fl = cfg.v_front + cfg.v_sync + cfg.v_back + (t.seed[11:8] % cfg.v_active);   // the faulty line
    bit dvi = (t.kind == 9) || !cfg.preamble_en;
    bit [31:0] ih;
    bit [63:0] isp [4];
    if (vif.drv_cb.hpd !== 1'b1) begin
      int to = 0;
      while (vif.drv_cb.hpd !== 1'b1 && to < cfg.timeout_cycles) begin @(vif.drv_cb); to++; end
      if (vif.drv_cb.hpd !== 1'b1) `uvm_error("DRV", "HDMI: hpd never went high")
    end
    @(vif.drv_cb);
    t.infoframe(ih, isp);
    t.pix.delete(); t.llen.delete(); t.gb.delete(); t.hdr.delete(); t.sp.delete();
    if (!dvi && cfg.island_en && t.has_island()) begin t.hdr.push_back(ih); foreach (isp[k]) t.sp.push_back(isp[k]); end
    for (int l = 0; l < nl; l++) begin
      bit vs = (l >= cfg.v_front && l < cfg.v_front + cfg.v_sync);
      bit act = (l >= nl - cfg.v_active);
      int na = act ? cfg.h_active + ((l == fl && t.kind == 6) ? -1 : (l == fl && t.kind == 7) ? 1 : 0) : 0;
      int nb = cfg.h_front + cfg.h_sync + cfg.h_back + cfg.h_active - na;
      int is0 = (!dvi && cfg.island_en && t.has_island() && l == cfg.v_front + cfg.v_sync) ? cfg.h_front + cfg.h_sync : -1;
      bit pre = act && !dvi && !(t.kind == 8 && l == fl);
      int c0 = 0, c1 = 0, c2 = 0;
      if (act) begin t.llen.push_back(na); t.gb.push_back(pre); end
      for (int c = 0; c < nb; c++) begin
        bit hs = (c >= cfg.h_front && c < cfg.h_front + cfg.h_sync);
        bit [9:0] a = hs_tok(vs, hs), b = 10'h354, d = 10'h354;
        if (is0 >= 0 && c >= is0 && c < is0 + 44) begin
          int k = c - is0;
          if (k < 8) begin b = 10'h0AB; d = 10'h0AB; end                            // island preamble
          else if (k < 10 || k >= 42) begin a = hs_terc4({2'b11, vs, hs}); b = HS_GB_V1; d = HS_GB_V1; end
          else begin
            int i = k - 10;
            a = hs_terc4({i != 0, ih[i], vs, hs});
            b = hs_terc4({isp[3][2 * i], isp[2][2 * i], isp[1][2 * i], isp[0][2 * i]});
            d = hs_terc4({isp[3][2 * i + 1], isp[2][2 * i + 1], isp[1][2 * i + 1], isp[0][2 * i + 1]});
          end
        end else if (pre && c >= nb - 10) begin
          if (c < nb - 2) b = 10'h0AB;                                               // video preamble, CTL0 = 1
          else begin a = HS_GB_V02; b = HS_GB_V1; d = HS_GB_V02; end
        end
        vif.drv_cb.tmds_ch0 <= a; vif.drv_cb.tmds_ch1 <= b; vif.drv_cb.tmds_ch2 <= d;
        @(vif.drv_cb);
      end
      for (int p = 0; p < na; p++) begin
        bit [23:0] px;
        int bar;
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        bar = p * 8 / cfg.h_active;
        if (t.kind == 11) px = {bar[2] ? 8'h00 : 8'hFF, bar[1] ? 8'h00 : 8'hFF, bar[0] ? 8'h00 : 8'hFF};
        else px = x[23:0];
        t.pix.push_back(px);
        vif.drv_cb.tmds_ch0 <= hs_enc(px[7:0], c0);
        vif.drv_cb.tmds_ch1 <= hs_enc(px[15:8], c1);
        vif.drv_cb.tmds_ch2 <= hs_enc(px[23:16], c2);
        @(vif.drv_cb);
      end
    end
    vif.drv_cb.tmds_ch0 <= 10'h354; vif.drv_cb.tmds_ch1 <= 10'h354; vif.drv_cb.tmds_ch2 <= 10'h354;
    @(vif.drv_cb);
  endtask

endclass
