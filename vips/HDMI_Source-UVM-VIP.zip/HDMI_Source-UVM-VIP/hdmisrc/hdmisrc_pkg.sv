// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_pkg.sv -- HDMI source UVM VIP package

package hdmisrc_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import hdmisrc_defs_pkg::*;
  export hdmisrc_defs_pkg::*;

  `include "hdmisrc_transaction.svh"
  `include "hdmisrc_config.svh"
  `include "hdmisrc_sequencer.svh"
  `include "hdmisrc_driver.svh"
  `include "hdmisrc_monitor.svh"
  `include "hdmisrc_agent.svh"
  `include "hdmisrc_sequences.svh"
  `include "hdmisrc_checker.svh"
  `include "hdmisrc_coverage.svh"
endpackage
