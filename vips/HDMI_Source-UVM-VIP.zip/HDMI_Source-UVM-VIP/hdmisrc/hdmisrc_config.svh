// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_config.svh -- HDMI source agent configuration

class hdmisrc_config extends uvm_object;
  `uvm_object_utils(hdmisrc_config)
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  bit coverage_enable = 1;
  bit checks_enable   = 1;
  int unsigned num_items      = 32;     // random items per base sequence
  int unsigned timeout_cycles = 20000;   // handshake / response watchdog
  int unsigned preset = 0;           // hs_preset() timing; 0 = bench default 64x16 (receiver model HACT x VACT)
  int unsigned h_active = 64, h_front = 8, h_sync = 8, h_back = 32;
  int unsigned v_active = 16, v_front = 1, v_sync = 1, v_back = 2;
  bit preamble_en = 1;                 // video preamble + guard band before every line
  bit island_en   = 1;                 // data islands in kinds that carry an InfoFrame
  function void load_preset(int id);
    preset = id;
    h_active = hs_preset(id, 0); h_front = hs_preset(id, 1); h_sync = hs_preset(id, 2); h_back = hs_preset(id, 3);
    v_active = hs_preset(id, 4); v_front = hs_preset(id, 5); v_sync = hs_preset(id, 6); v_back = hs_preset(id, 7);
  endfunction
  function new(string name = "hdmisrc_config"); super.new(name); endfunction
endclass
