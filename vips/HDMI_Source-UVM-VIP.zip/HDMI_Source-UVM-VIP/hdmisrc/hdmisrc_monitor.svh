// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_monitor.svh -- HDMI source monitor: decodes the character stream like a sink (sync tokens, guard bands, TMDS pixels, island packets) from a VSYNC rising edge to v_active lines, with the receiver's pixels, packets and frame report

class hdmisrc_monitor extends uvm_monitor;
  `uvm_component_utils(hdmisrc_monitor)

  virtual hdmisrc_if vif;
  uvm_analysis_port #(hdmisrc_transaction) ap;
  hdmisrc_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual hdmisrc_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hdmisrc: virtual interface not set")
    if (!uvm_config_db#(hdmisrc_config)::get(this, "", "cfg", cfg))
      cfg = hdmisrc_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit vs_q = 0, armed = 0, in_vid = 0, gbs = 0;
      int isl = 0, ni = 0, nlines = 0, ll = 0;
      bit [31:0] h;
      bit [63:0] s [4];
      hdmisrc_transaction t = hdmisrc_transaction::type_id::create("t");
      bit done = 0;
      forever begin
        bit [2:0] ct0;
        @(vif.mon_cb);
        // what the receiver delivered
        if (vif.mon_cb.pix_valid) t.rpix.push_back(vif.mon_cb.pix_data);
        if (vif.mon_cb.pkt_valid) begin
          t.rhdr.push_back(vif.mon_cb.pkt_hdr); t.rok.push_back(vif.mon_cb.pkt_ok);
          for (int k = 0; k < 4; k++) t.rsp_sp.push_back(vif.mon_cb.pkt_sp[64 * k +: 64]);
        end
        if (vif.mon_cb.frm_valid) begin
          t.rlines = vif.mon_cb.frm_lines; t.rbadlen = vif.mon_cb.frm_badlen; t.rnogb = vif.mon_cb.frm_nogb;
          if (!done) `uvm_error("MON", "HDMI: frame report before the frame ended")
          publish(t);
          t = hdmisrc_transaction::type_id::create("t");
          done = 0;
        end
        // the characters
        ct0 = hs_ctl(vif.mon_cb.tmds_ch0);
        if (ct0[2]) begin
          if (in_vid && armed && !done) begin
            t.llen.push_back(ll); t.gb.push_back(gbs);
            nlines++;
            if (nlines == cfg.v_active) begin done = 1; armed = 0; end
          end
          in_vid = 0; gbs = 0; isl = 0;
          if (ct0[1] && !vs_q && !done) begin
            armed = 1; nlines = 0; t.pix.delete(); t.llen.delete(); t.gb.delete(); t.hdr.delete(); t.sp.delete();
          end
          vs_q = ct0[1];
        end else if (!in_vid && vif.mon_cb.tmds_ch1 == HS_GB_V1 && vif.mon_cb.tmds_ch2 == HS_GB_V1) begin
          isl = (isl + 1) % 4;                     // leading guard band (2), packets, trailing guard band (2)
          if (isl == 2) begin ni = 0; h = 0; foreach (s[k]) s[k] = 0; end
        end else if (!in_vid && isl == 2) begin
          bit [4:0] a = hs_terc4_dec(vif.mon_cb.tmds_ch0), b = hs_terc4_dec(vif.mon_cb.tmds_ch1),
                    d = hs_terc4_dec(vif.mon_cb.tmds_ch2);
          h[ni] = a[2];
          for (int k = 0; k < 4; k++) begin s[k][2 * ni] = b[k]; s[k][2 * ni + 1] = d[k]; end
          ni++;
          if (ni == 32) begin
            t.hdr.push_back(h); foreach (s[k]) t.sp.push_back(s[k]);
            ni = 0; h = 0; foreach (s[k]) s[k] = 0;
          end
        end else if (!in_vid && vif.mon_cb.tmds_ch0 == HS_GB_V02 && vif.mon_cb.tmds_ch1 == HS_GB_V1 && vif.mon_cb.tmds_ch2 == HS_GB_V02) begin
          gbs = 1;
        end else if (armed && !done) begin
          if (!in_vid) ll = 0;
          in_vid = 1; ll++;
          t.pix.push_back({hs_dec(vif.mon_cb.tmds_ch2), hs_dec(vif.mon_cb.tmds_ch1), hs_dec(vif.mon_cb.tmds_ch0)});
        end
      end
    end
  endtask

  function void publish(hdmisrc_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
