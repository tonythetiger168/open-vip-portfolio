// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_compliance_checker.sv -- HDMI source concurrent assertion checks (bindable)

module hdmisrc_compliance_checker
  (input logic clk, input logic rst_n, input logic [9:0] tmds_ch0, input logic [9:0] tmds_ch1, input logic [9:0] tmds_ch2, input logic hpd, input logic pix_valid, input logic [23:0] pix_data, input logic pix_sol, input logic pix_sof, input logic pkt_valid, input logic [31:0] pkt_hdr, input logic [255:0] pkt_sp, input logic pkt_ok, input logic frm_valid, input logic [11:0] frm_lines, input logic [11:0] frm_badlen, input logic [11:0] frm_nogb);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({hpd, pix_valid, pkt_valid, frm_valid}))
    else $error("HDMI: X on hpd / valids");
  assert property (@(posedge clk) disable iff (!rst_n) pix_valid |-> !$isunknown(pix_data))
    else $error("HDMI: X in a pixel");
  assert property (@(posedge clk) disable iff (!rst_n) pix_sof |-> pix_sol && pix_valid)
    else $error("HDMI: frame start without line start");
  assert property (@(posedge clk) disable iff (!rst_n) hpd |-> !$isunknown({tmds_ch0, tmds_ch1, tmds_ch2}))
    else $error("HDMI: X on TMDS with hpd high");
  assert property (@(posedge clk) disable iff (!rst_n) $fell(hpd) |-> 0)
    else $error("HDMI: hpd dropped");
  cover property (@(posedge clk) disable iff (!rst_n) pkt_valid && pkt_ok);
  cover property (@(posedge clk) disable iff (!rst_n) pkt_valid && !pkt_ok);
  cover property (@(posedge clk) disable iff (!rst_n) frm_valid && frm_nogb != 0);
endmodule
