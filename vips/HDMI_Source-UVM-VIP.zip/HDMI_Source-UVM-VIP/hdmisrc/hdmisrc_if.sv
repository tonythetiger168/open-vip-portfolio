// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_if.sv -- HDMI source interface

interface hdmisrc_if (input logic clk);
  logic rst_n;

  logic [9:0] tmds_ch0;
  logic [9:0] tmds_ch1;
  logic [9:0] tmds_ch2;
  logic hpd;
  logic pix_valid;
  logic [23:0] pix_data;
  logic pix_sol;
  logic pix_sof;
  logic pkt_valid;
  logic [31:0] pkt_hdr;
  logic [255:0] pkt_sp;
  logic pkt_ok;
  logic frm_valid;
  logic [11:0] frm_lines;
  logic [11:0] frm_badlen;
  logic [11:0] frm_nogb;

  modport DUT (input clk, rst_n, input tmds_ch0, input tmds_ch1, input tmds_ch2, output hpd, output pix_valid, output pix_data, output pix_sol, output pix_sof, output pkt_valid, output pkt_hdr, output pkt_sp, output pkt_ok, output frm_valid, output frm_lines, output frm_badlen, output frm_nogb);
  modport MON (input clk, rst_n, tmds_ch0, tmds_ch1, tmds_ch2, hpd, pix_valid, pix_data, pix_sol, pix_sof, pkt_valid, pkt_hdr, pkt_sp, pkt_ok, frm_valid, frm_lines, frm_badlen, frm_nogb);

  clocking drv_cb @(posedge clk);
    input rst_n, hpd, pix_valid, pix_data, pix_sol, pix_sof, pkt_valid, pkt_hdr, pkt_sp, pkt_ok, frm_valid, frm_lines, frm_badlen, frm_nogb;
    inout tmds_ch0, tmds_ch1, tmds_ch2;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, tmds_ch0, tmds_ch1, tmds_ch2, hpd, pix_valid, pix_data, pix_sol, pix_sof, pkt_valid, pkt_hdr, pkt_sp, pkt_ok, frm_valid, frm_lines, frm_badlen, frm_nogb;
  endclocking
endinterface
