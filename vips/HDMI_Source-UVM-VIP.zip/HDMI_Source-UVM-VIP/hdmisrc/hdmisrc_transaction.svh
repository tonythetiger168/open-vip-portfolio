// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_transaction.svh -- HDMI source transaction

class hdmisrc_transaction extends uvm_sequence_item;
  `uvm_object_utils(hdmisrc_transaction)

  // request (driven by the agent)
  bit [23:0] pix[$];
  bit [15:0] llen[$];
  bit gb[$];
  bit [31:0] hdr[$];
  bit [63:0] sp[$];
  // response (returned by the DUT)
  bit [23:0] rpix[$];
  bit [31:0] rhdr[$];
  bit [63:0] rsp_sp[$];
  bit rok[$];
  bit [11:0] rlines;
  bit [11:0] rbadlen;
  bit [11:0] rnogb;
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "hdmisrc_transaction"); super.new(name); endfunction

  // kind: 0-3 AVI InfoFrame island, 4 header ECC flipped, 5 subpacket ECC flipped,
  // 6 one line a pixel short, 7 one line a pixel long, 8 one line without a guard
  // band, 9 DVI mode (no preamble, guard band or island), 10 audio InfoFrame,
  // 11 colour bars, 12-31 random pixels without an island
  function void set(int k, bit [31:0] s = 1); kind = k; seed = s; endfunction
  function bit has_island(); return kind inside {[0:5], 10}; endfunction
  // InfoFrame packet: header {ECC, HB2, HB1, HB0} and 4 subpackets {ECC, 7 PB}
  function void infoframe(output bit [31:0] h, output bit [63:0] s[4]);
    bit [7:0] hb [3], pb [28];
    bit [7:0] sum = 0;
    bit [31:0] x = seed | 1;
    foreach (pb[i]) pb[i] = 0;
    if (kind == 10) begin hb = '{8'h84, 8'h01, 8'h0A}; pb[1] = 8'h01; pb[4] = x[7:0] & 8'h1F; end
    else begin hb = '{8'h82, 8'h02, 8'h0D}; pb[1] = 8'h10 | {x[1:0], 5'h0}; pb[2] = 8'h08; pb[4] = x[15:8] & 8'h7F; end
    for (int i = 0; i < 3; i++) sum += hb[i];
    for (int i = 1; i < 28; i++) sum += pb[i];
    pb[0] = 8'h00 - sum;
    h[23:0] = {hb[2], hb[1], hb[0]};
    h[31:24] = hs_bch({32'h0, h[23:0]}, 24);
    if (kind == 4) h[31 - x[18:16]] ^= 1'b1;
    for (int k = 0; k < 4; k++) begin
      for (int i = 0; i < 7; i++) s[k][8 * i +: 8] = pb[7 * k + i];
      s[k][63:56] = hs_bch(s[k][55:0], 56);
    end
    if (kind == 5) s[x[21:20]][63 - x[24:22]] ^= 1'b1;
  endfunction

  function void do_copy(uvm_object rhs);
    hdmisrc_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    pix = rhs_.pix;
    llen = rhs_.llen;
    gb = rhs_.gb;
    hdr = rhs_.hdr;
    sp = rhs_.sp;
    rpix = rhs_.rpix;
    rhdr = rhs_.rhdr;
    rsp_sp = rhs_.rsp_sp;
    rok = rhs_.rok;
    rlines = rhs_.rlines;
    rbadlen = rhs_.rbadlen;
    rnogb = rhs_.rnogb;
    kind = rhs_.kind;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    hdmisrc_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (pix.size() != rhs_.pix.size()) return 0;
    foreach (pix[i]) if (pix[i] != rhs_.pix[i]) return 0;
    if (llen.size() != rhs_.llen.size()) return 0;
    foreach (llen[i]) if (llen[i] != rhs_.llen[i]) return 0;
    if (gb.size() != rhs_.gb.size()) return 0;
    foreach (gb[i]) if (gb[i] != rhs_.gb[i]) return 0;
    if (hdr.size() != rhs_.hdr.size()) return 0;
    foreach (hdr[i]) if (hdr[i] != rhs_.hdr[i]) return 0;
    if (sp.size() != rhs_.sp.size()) return 0;
    foreach (sp[i]) if (sp[i] != rhs_.sp[i]) return 0;
    if (rpix.size() != rhs_.rpix.size()) return 0;
    foreach (rpix[i]) if (rpix[i] != rhs_.rpix[i]) return 0;
    if (rhdr.size() != rhs_.rhdr.size()) return 0;
    foreach (rhdr[i]) if (rhdr[i] != rhs_.rhdr[i]) return 0;
    if (rsp_sp.size() != rhs_.rsp_sp.size()) return 0;
    foreach (rsp_sp[i]) if (rsp_sp[i] != rhs_.rsp_sp[i]) return 0;
    if (rok.size() != rhs_.rok.size()) return 0;
    foreach (rok[i]) if (rok[i] != rhs_.rok[i]) return 0;
    if (rlines != rhs_.rlines) return 0;
    if (rbadlen != rhs_.rbadlen) return 0;
    if (rnogb != rhs_.rnogb) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(hdmisrc_transaction rhs_);
    if (pix.size() != rhs_.pix.size()) return 0;
    foreach (pix[i]) if (pix[i] != rhs_.pix[i]) return 0;
    if (llen.size() != rhs_.llen.size()) return 0;
    foreach (llen[i]) if (llen[i] != rhs_.llen[i]) return 0;
    if (gb.size() != rhs_.gb.size()) return 0;
    foreach (gb[i]) if (gb[i] != rhs_.gb[i]) return 0;
    if (hdr.size() != rhs_.hdr.size()) return 0;
    foreach (hdr[i]) if (hdr[i] != rhs_.hdr[i]) return 0;
    if (sp.size() != rhs_.sp.size()) return 0;
    foreach (sp[i]) if (sp[i] != rhs_.sp[i]) return 0;
    return 1;
  endfunction

  function string qstr_pix();
    string s = $sformatf("[%0d]{", pix.size());
    foreach (pix[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", pix[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_llen();
    string s = $sformatf("[%0d]{", llen.size());
    foreach (llen[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", llen[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_gb();
    string s = $sformatf("[%0d]{", gb.size());
    foreach (gb[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", gb[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_hdr();
    string s = $sformatf("[%0d]{", hdr.size());
    foreach (hdr[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", hdr[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_sp();
    string s = $sformatf("[%0d]{", sp.size());
    foreach (sp[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", sp[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rpix();
    string s = $sformatf("[%0d]{", rpix.size());
    foreach (rpix[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rpix[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rhdr();
    string s = $sformatf("[%0d]{", rhdr.size());
    foreach (rhdr[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rhdr[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rsp_sp();
    string s = $sformatf("[%0d]{", rsp_sp.size());
    foreach (rsp_sp[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rsp_sp[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rok();
    string s = $sformatf("[%0d]{", rok.size());
    foreach (rok[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rok[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("HDMI source{tag=%0d pix=%s llen=%s gb=%s hdr=%s sp=%s rpix=%s rhdr=%s rsp_sp=%s rok=%s rlines=0x%0h rbadlen=0x%0h rnogb=0x%0h}", tag, qstr_pix(), qstr_llen(), qstr_gb(), qstr_hdr(), qstr_sp(), qstr_rpix(), qstr_rhdr(), qstr_rsp_sp(), qstr_rok(), rlines, rbadlen, rnogb);
  endfunction
endclass
