// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hdmisrc_checker.svh -- HDMI source protocol checker on monitored items

class hdmisrc_checker extends uvm_component;
  `uvm_component_utils(hdmisrc_checker)
  uvm_analysis_imp #(hdmisrc_transaction, hdmisrc_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  hdmisrc_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(hdmisrc_config)::get(this, "", "cfg", cfg))
      cfg = hdmisrc_config::type_id::create("cfg");
  endfunction

  function void fail(hdmisrc_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("HDMI source: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(hdmisrc_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.rlines != cfg.v_active) fail(t, "frame without v_active lines");
      foreach (t.hdr[i]) if (t.rok[i]) begin
        // a packet with good ECC must be an InfoFrame with a correct checksum
        bit [7:0] sum = t.hdr[i][7:0] + t.hdr[i][15:8] + t.hdr[i][23:16];
        for (int k = 0; k < 4; k++) for (int b = 0; b < 7; b++) sum += t.sp[4 * i + k][8 * b +: 8];
        if (!(t.hdr[i][7:0] inside {8'h82, 8'h84})) fail(t, "packet is not an AVI / audio InfoFrame");
        if (sum != 0) fail(t, "InfoFrame checksum");
      end
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("HDMI source checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
