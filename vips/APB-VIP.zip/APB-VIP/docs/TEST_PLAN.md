# APB Test Plan（APB-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | APB |
| 家族 | AMBA |
| 類型 | UVM VIP |
| 交付目錄 | `APB-VIP/` |
| 目前 L1b 狀態 | PASS(functional) |

## 2. DUT / 待測對象

- 合成參考 RTL（`rtl/`）+ directed testbench（`tb/`）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | in reset: no PREADY, PSLVERR or PRDATA | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | all 60 normal registers written and read back with PWUSER / PRUSER and PBUSER | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | random wait states of 0, 1 and 2 cycles in the normal region, never more | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | all 16 PSTRB values: only the strobed bytes change | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | wait-state region 0xF0-0xFF: exactly 2 wait states | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | back-to-back transfers with PSEL held, including the wait region | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | error region: PSLVERR, zero data, aliased register untouched | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | secure registers 0x80-0xBF with every PPROT: non-secure gets PSLVERR, no write, zero data | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | non-secure access just outside the secure registers completes | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | wrong PADDRCHK, PCTRLCHK, PSELCHK, PENABLECHK, PWDATACHK or PSTRBCHK: PSLVERR, nothing written | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | PWDATACHK / PSTRBCHK ignored on reads | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | parity error on the second of two back-to-back writes: only that one dropped | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | 7 idle clocks: completer still awake; 8: asleep, one extra wait state | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | PWAKEUP 1 or 3 clocks before PSEL: no extra wait state | 檢查成立，`FUNC_PASS` 輸出 |
| FS-15 | PWAKEUP held high through a long idle keeps the completer awake | 檢查成立，`FUNC_PASS` 輸出 |
| FS-16 | reset in the middle: registers and PRUSER bits cleared, completer awake | 檢查成立，`FUNC_PASS` 輸出 |
| FS-17 | PREADYCHK / PSLVERRCHK / PRDATACHK odd parity on every clock | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | PNSE (Realm Management Extension) and the four-state address space |
| PT-02 | User-signal check bits (PAUSERCHK, PWUSERCHK, PRUSERCHK, PBUSERCHK) |
| PT-03 | Several completers behind one PSEL decoder |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/apb_compliance_checker.sv`（L1–L5，含 PWAKEUP、user 訊號、parity）、`vip/apb/apb_protocol_checker.sv`、`rtl/amba_vip_if.sv`
- Functional coverage：`vip/apb/apb_coverage.svh`（cg_protocol / cg_fsm / cg_data / cg_apb5）、`amba_cov`
- Scoreboard：暫存器 + PWUSER 參考模型，預測 PSLVERR、PRDATA、PRUSER、PBUSER

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/APB-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py APB-VIP && python3 smoke/smoke_run.py APB-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 無特別備註。

---
*文件版本：v1.8.0*
