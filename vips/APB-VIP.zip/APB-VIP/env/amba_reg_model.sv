// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//============================================================================
// UVM RAL model of the top_tb APB4 slave (amba_dut, tb/top_tb.sv)
//   0x00..0xEC  REG[0..59]   32-bit RW, reset 0, zero wait states
//   0xF0..0xFC  REG[60..63]  32-bit RW, reset 0, 2 wait states (paddr[7:4]==F)
//   0xEE000000  ERR_PROBE    PSLVERR region; excluded from the built-in
//                            register sequences, used to check that an
//                            error response reaches the RAL as UVM_NOT_OK
// The DUT decodes only paddr[7:2] (plus the error region), so addresses
// 0x100 and above alias onto REG[0..63]; the model maps only one copy.
//============================================================================
`ifndef AMBA_REG_MODEL_SV
`define AMBA_REG_MODEL_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class amba_data_reg extends uvm_reg;
  `uvm_object_utils(amba_data_reg)
  rand uvm_reg_field DATA;

  function new(string name = "amba_data_reg");
    super.new(name, 32, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    DATA = uvm_reg_field::type_id::create("DATA");
    //            parent size lsb access volatile reset has_reset rand individually_accessible
    DATA.configure(this, 32,  0,  "RW",  0,       32'h0, 1,        1,   1);
  endfunction
endclass

class amba_reg_block extends uvm_reg_block;
  `uvm_object_utils(amba_reg_block)
  localparam int N_REGS     = 64;
  localparam int WAIT_FIRST = 60;            // REG[60..63] live at 0xF0..0xFC
  rand amba_data_reg REG[N_REGS];
  amba_data_reg      ERR_PROBE;
  uvm_reg_map        apb_map;

  function new(string name = "amba_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    apb_map = create_map("apb_map", 'h0, 4, UVM_LITTLE_ENDIAN, 1);
    default_map = apb_map;
    foreach (REG[i]) begin
      REG[i] = amba_data_reg::type_id::create($sformatf("REG%0d", i));
      REG[i].configure(this, null, "");
      REG[i].build();
      apb_map.add_reg(REG[i], i * 4, "RW");
    end
    ERR_PROBE = amba_data_reg::type_id::create("ERR_PROBE");
    ERR_PROBE.configure(this, null, "");
    ERR_PROBE.build();
    apb_map.add_reg(ERR_PROBE, 'hEE00_0000, "RW");
    uvm_resource_db#(bit)::set({"REG::", ERR_PROBE.get_full_name()}, "NO_REG_TESTS", 1, this);
  endfunction
endclass
`endif
