// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2025 Functional smoke testbench (APB two-phase write/read)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened APB slave amba_dut.
// DUT behaviour (from dut_amba_dut.sv):
//   - 64-entry x 32-bit register bank, reg_idx = paddr[7:2]
//   - transfer when psel && penable; pready=1 immediately, except
//     paddr[7:4]==4'hF wait region: pready after 2 wait states
//   - byte-write strobes via pstrb; prdata combinational during access
//   - paddr[31:24]==8'hEE -> pslverr and write suppressed

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        vif_aclk    = 1'b0;
  logic        vif_aresetn = 1'b0;
  logic [31:0] vif_paddr   = 32'h0;
  logic        vif_penable = 1'b0;
  logic        vif_psel    = 1'b0;
  logic [3:0]  vif_pstrb   = 4'h0;
  logic [31:0] vif_pwdata  = 32'h0;
  logic        vif_pwrite  = 1'b0;
  wire [31:0]  vif_prdata;
  wire         vif_pready;
  wire         vif_pslverr;
  // unused sibling-protocol outputs of the shared amba_dut shell
  wire         vif_awready, vif_wready, vif_bvalid, vif_arready;
  wire         vif_rlast, vif_rvalid, vif_tready, vif_hreadyout, vif_hresp;
  wire [1:0]   vif_bresp, vif_rresp;
  wire [63:0]  vif_rdata, vif_hrdata;

  always #5 vif_aclk = ~vif_aclk;

  amba_dut u_dut (
    .vif_aclk(vif_aclk), .vif_aresetn(vif_aresetn),
    .vif_awready(vif_awready), .vif_wready(vif_wready),
    .vif_bresp(vif_bresp), .vif_bvalid(vif_bvalid),
    .vif_arready(vif_arready), .vif_rdata(vif_rdata),
    .vif_rresp(vif_rresp), .vif_rlast(vif_rlast),
    .vif_rvalid(vif_rvalid), .vif_tready(vif_tready),
    .vif_hrdata(vif_hrdata), .vif_hreadyout(vif_hreadyout),
    .vif_hresp(vif_hresp),
    .vif_paddr(vif_paddr), .vif_penable(vif_penable),
    .vif_psel(vif_psel), .vif_pstrb(vif_pstrb),
    .vif_pwdata(vif_pwdata), .vif_pwrite(vif_pwrite),
    .vif_prdata(vif_prdata), .vif_pready(vif_pready),
    .vif_pslverr(vif_pslverr)
  );

  task automatic chk(input bit cond, input string name);
    begin
      checks++;
      if (!cond) begin
        fails++;
        $display("  [FAIL] %s", name);
      end
    end
  endtask

  // APB write with wait-state counting; returns number of wait cycles
  task automatic apb_write(input [31:0] addr, input [31:0] data,
                           input [3:0] strb, output int waits);
    begin
      @(negedge vif_aclk);                 // setup phase
      vif_psel = 1'b1; vif_penable = 1'b0; vif_pwrite = 1'b1;
      vif_paddr = addr; vif_pwdata = data; vif_pstrb = strb;
      @(negedge vif_aclk);                 // access phase
      vif_penable = 1'b1;
      waits = 0;
      #1;
      while (vif_pready !== 1'b1) begin
        @(negedge vif_aclk);
        waits++;
        #1;
      end
      @(posedge vif_aclk);                 // write commits here
      @(negedge vif_aclk);
      vif_psel = 1'b0; vif_penable = 1'b0; vif_pwrite = 1'b0;
      vif_pstrb = 4'h0;
    end
  endtask

  // APB read; data sampled mid access-phase once pready is high
  task automatic apb_read(input [31:0] addr, output [31:0] data,
                          output int waits);
    begin
      @(negedge vif_aclk);                 // setup phase
      vif_psel = 1'b1; vif_penable = 1'b0; vif_pwrite = 1'b0;
      vif_paddr = addr;
      @(negedge vif_aclk);                 // access phase
      vif_penable = 1'b1;
      waits = 0;
      #1;
      while (vif_pready !== 1'b1) begin
        @(negedge vif_aclk);
        waits++;
        #1;
      end
      data = vif_prdata;
      @(negedge vif_aclk);
      vif_psel = 1'b0; vif_penable = 1'b0;
    end
  endtask

  localparam [31:0] D1 = 32'hA5A5_5A5A;
  localparam [31:0] D2 = 32'h1234_5678;
  reg [31:0] rdata;
  int waits;

  initial begin
    repeat (4) @(posedge vif_aclk);
    @(negedge vif_aclk);
    vif_aresetn = 1'b1;
    @(negedge vif_aclk);
    chk(vif_pready === 1'b0, "pready low when idle (no psel)");

    // zero-wait-state write to reg 4 (addr 0x10), full strobes
    apb_write(32'h0000_0010, D1, 4'hF, waits);
    chk(waits == 0, "normal region write has zero wait states");

    // read back
    apb_read(32'h0000_0010, rdata, waits);
    chk(rdata === D1, "read-back equals written data");
    chk(waits == 0, "normal region read has zero wait states");

    // partial-strobe write: bytes 0 and 2 -> 0xFF
    apb_write(32'h0000_0010, 32'hFFFF_FFFF, 4'b0101, waits);
    apb_read(32'h0000_0010, rdata, waits);
    chk(rdata === 32'hA5FF_5AFF, "pstrb updates only enabled byte lanes");

    // wait region (paddr[7:4]==F): 2 wait states, data still correct
    apb_write(32'h0000_00F0, D2, 4'hF, waits);
    chk(waits == 2, "wait region write inserts 2 wait states");
    apb_read(32'h0000_00F0, rdata, waits);
    chk(waits == 2, "wait region read inserts 2 wait states");
    chk(rdata === D2, "wait region read-back data correct");

    // error region (paddr[31:24]==0xEE): pslverr, write suppressed
    @(negedge vif_aclk);
    vif_psel = 1'b1; vif_penable = 1'b0; vif_pwrite = 1'b0;
    vif_paddr = 32'hEE00_0004;
    @(negedge vif_aclk);
    vif_penable = 1'b1;
    #1;
    chk(vif_pslverr === 1'b1, "error region read raises pslverr");
    chk(vif_pready  === 1'b1, "error region access still completes");
    @(negedge vif_aclk);
    vif_psel = 1'b0; vif_penable = 1'b0;

    apb_write(32'hEE00_0004, 32'hDEAD_BEEF, 4'hF, waits);  // must be dropped
    apb_read(32'h0000_0004, rdata, waits);                 // same reg_idx, no error
    chk(rdata === 32'h0, "error region write is suppressed");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  // safety timeout (well below 100us budget)
  initial begin
    #80000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
