// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened APB5 slave amba_dut
// (tb/top_tb.sv): register bank with PSTRB, random and fixed wait states,
// back-to-back transfers, PSLVERR for the error region, the secure
// registers (PPROT[1]) and request parity errors, PWAKEUP with the slave
// sleeping after 8 idle clocks, PAUSER / PWUSER / PRUSER / PBUSER, and the
// response check signals.
//
// The master works on the falling edge. A transfer's ACCESS phase ends at
// the rising edge where PREADY is high; the wait states are the ACCESS
// cycles with PREADY low. In the wait-state region (paddr[7:4] == F) the
// slave always inserts 2, so a sleeping slave shows up as one more.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        vif_aclk       = 1'b0;
  logic        vif_aresetn    = 1'b0;
  logic [31:0] vif_paddr      = 32'h0;
  logic        vif_penable    = 1'b0;
  logic [2:0]  vif_pprot      = 3'b000;
  logic        vif_psel       = 1'b0;
  logic [3:0]  vif_pstrb      = 4'h0;
  logic [31:0] vif_pwdata     = 32'h0;
  logic        vif_pwrite     = 1'b0;
  logic        vif_pwakeup    = 1'b0;
  logic [7:0]  vif_pauser     = 8'h0;
  logic [7:0]  vif_pwuser     = 8'h0;
  logic [3:0]  vif_paddrchk   = 4'hF;
  logic        vif_pctrlchk   = 1'b1;
  logic        vif_pselchk    = 1'b1;
  logic        vif_penablechk = 1'b1;
  logic [3:0]  vif_pwdatachk  = 4'hF;
  logic        vif_pstrbchk   = 1'b1;
  wire  [31:0] vif_prdata;
  wire         vif_pready, vif_pslverr;
  wire  [7:0]  vif_pruser;
  wire  [3:0]  vif_pbuser;
  wire         vif_preadychk, vif_pslverrchk;
  wire  [3:0]  vif_prdatachk;
  // unused sibling-protocol outputs of the shared amba_dut shell
  wire         vif_awready, vif_wready, vif_bvalid, vif_arready;
  wire         vif_rlast, vif_rvalid, vif_tready, vif_hreadyout, vif_hresp;
  wire [1:0]   vif_bresp, vif_rresp;
  wire [63:0]  vif_rdata, vif_hrdata;

  always #5 vif_aclk = ~vif_aclk;

  amba_dut u_dut (
    .vif_aclk(vif_aclk), .vif_aresetn(vif_aresetn),
    .vif_awready(vif_awready), .vif_wready(vif_wready),
    .vif_bresp(vif_bresp), .vif_bvalid(vif_bvalid),
    .vif_arready(vif_arready), .vif_rdata(vif_rdata),
    .vif_rresp(vif_rresp), .vif_rlast(vif_rlast),
    .vif_rvalid(vif_rvalid), .vif_tready(vif_tready),
    .vif_hrdata(vif_hrdata), .vif_hreadyout(vif_hreadyout), .vif_hresp(vif_hresp),
    .vif_paddr(vif_paddr), .vif_penable(vif_penable), .vif_pprot(vif_pprot),
    .vif_psel(vif_psel), .vif_pstrb(vif_pstrb), .vif_pwdata(vif_pwdata), .vif_pwrite(vif_pwrite),
    .vif_prdata(vif_prdata), .vif_pready(vif_pready), .vif_pslverr(vif_pslverr),
    .vif_pwakeup(vif_pwakeup), .vif_pauser(vif_pauser), .vif_pwuser(vif_pwuser),
    .vif_pruser(vif_pruser), .vif_pbuser(vif_pbuser),
    .vif_paddrchk(vif_paddrchk), .vif_pctrlchk(vif_pctrlchk), .vif_pselchk(vif_pselchk),
    .vif_penablechk(vif_penablechk), .vif_pwdatachk(vif_pwdatachk), .vif_pstrbchk(vif_pstrbchk),
    .vif_preadychk(vif_preadychk), .vif_prdatachk(vif_prdatachk), .vif_pslverrchk(vif_pslverrchk)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [3:0] par4(input logic [31:0] v);
    for (int b = 0; b < 4; b++) par4[b] = ~^v[b*8 +: 8];
  endfunction

  // response check signals, every clock
  int resp_par_bad = 0, resp_par_seen = 0;
  always @(posedge vif_aclk) if (vif_aresetn) begin
    resp_par_seen++;
    if (vif_preadychk !== ~vif_pready || vif_pslverrchk !== ~vif_pslverr ||
        vif_prdatachk !== par4(vif_prdata)) resp_par_bad++;
  end

  // ------------------------------------------------------------------ model
  // copy of the slave's wait-state LFSR: the wait states of every transfer
  // are known exactly
  logic [15:0] tlfsr;
  always @(posedge vif_aclk or negedge vif_aresetn)
    if (!vif_aresetn) tlfsr <= 16'hACE1;
    else tlfsr <= {tlfsr[14:0], tlfsr[15] ^ tlfsr[13] ^ tlfsr[12] ^ tlfsr[10]};
  logic [31:0] ref_reg [0:63];
  logic [7:0]  ref_usr [0:63];
  task automatic ref_reset();
    for (int i = 0; i < 64; i++) begin ref_reg[i] = 32'h0; ref_usr[i] = 8'h0; end
  endtask
  initial ref_reset();

  // ------------------------------------------------------------ transfers
  // one transfer; when b2b the previous one left PSEL high
  logic [31:0] r_data;
  logic [7:0]  r_user;
  logic [3:0]  r_buser;
  bit          r_err;
  int          r_waits, r_need;
  logic [31:0] e_data;
  logic [7:0]  e_user;
  bit          e_err;
  logic [5:0]  ix;

  task automatic drive_chk(input int inj);
    vif_paddrchk   = par4(vif_paddr)          ^ ((inj == 1) ? 4'b0100 : 4'b0);
    vif_pctrlchk   = ~^{vif_pprot, vif_pwrite} ^ (inj == 2);
    vif_pselchk    = ~vif_psel                 ^ (inj == 3);
    vif_penablechk = ~vif_penable              ^ (inj == 4 && vif_penable);
    vif_pwdatachk  = par4(vif_pwdata)          ^ ((inj == 5) ? 4'b0001 : 4'b0);
    vif_pstrbchk   = ~^vif_pstrb               ^ (inj == 6);
  endtask

  task automatic xfer(input bit wr, input logic [31:0] a, input logic [2:0] p = 3'b000,
                      input logic [31:0] d = 32'h0, input logic [3:0] s = 4'hF,
                      input logic [7:0] au = 8'h00, input logic [7:0] wu = 8'h00,
                      input int inj = 0, input int lead = 0, input bit b2b = 0);
    // b2b: the SETUP follows on the edge that completes the previous ACCESS
    if (!b2b && lead > 0) begin
      @(negedge vif_aclk); vif_pwakeup = 1'b1;
      repeat (lead - 1) @(negedge vif_aclk);
    end
    @(negedge vif_aclk);
    // SETUP
    vif_pwakeup = 1'b1; vif_psel = 1'b1; vif_penable = 1'b0;
    vif_paddr = a; vif_pprot = p; vif_pwrite = wr;
    vif_pwdata = wr ? d : 32'h0; vif_pstrb = wr ? s : 4'h0;
    vif_pauser = au; vif_pwuser = wr ? wu : 8'h0;
    drive_chk(inj);
    r_need = (a[7:4] == 4'hF) ? 2 : (tlfsr[1:0] == 2'b11) ? 2 : (tlfsr[1:0] == 2'b10) ? 1 : 0;
    // ACCESS
    @(negedge vif_aclk);
    vif_penable = 1'b1;
    drive_chk(inj);
    r_waits = 0;
    #1;
    while (vif_pready !== 1'b1) begin
      @(negedge vif_aclk); #1;
      r_waits++;
      if (r_waits > 20) begin chk(0, "PREADY never came"); break; end
    end
    r_data = vif_prdata; r_user = vif_pruser; r_buser = vif_pbuser; r_err = vif_pslverr;
    // reference model
    ix    = a[7:2];
    e_err = a[31:24] == 8'hEE || (a[7:6] == 2'b10 && p[1]) || inj != 0;
    e_data = e_err || wr ? 32'h0 : ref_reg[ix];
    e_user = e_err || wr ? 8'h0  : ref_usr[ix];
    if (wr && !e_err) begin
      for (int b = 0; b < 4; b++) if (s[b]) ref_reg[ix][b*8 +: 8] = d[b*8 +: 8];
      ref_usr[ix] = wu;
    end
  endtask

  task automatic idle();
    @(negedge vif_aclk);
    vif_psel = 1'b0; vif_penable = 1'b0; vif_pwakeup = 1'b0;
    drive_chk(0);
  endtask

  task automatic gap(input int n);
    repeat (n) @(negedge vif_aclk);
  endtask

  // check the last transfer against the model; waits: -1 the slave's
  // random wait states, -2 one more (it was asleep), else that number
  task automatic check(input string tag, input int waits = -1);
    chk(r_err == e_err, $sformatf("%s: PSLVERR %0d, expected %0d", tag, r_err, e_err));
    chk(r_buser == vif_pauser[3:0], $sformatf("%s: PBUSER echoes PAUSER[3:0]", tag));
    if (!vif_pwrite)
      chk(r_data === e_data && r_user === e_user,
          $sformatf("%s: PRDATA %h / PRUSER %h, expected %h / %h", tag, r_data, r_user, e_data, e_user));
    if (waits == -1) waits = r_need;
    if (waits == -2) waits = r_need + 1;
    chk(r_waits == waits, $sformatf("%s: %0d wait states, expected %0d", tag, r_waits, waits));
  endtask

  // ------------------------------------------------------------------ tests
  int k, j, wmin, wmax, wcnt[0:2];
  logic [31:0] v;

  initial begin
    repeat (3) @(negedge vif_aclk);
    chk(vif_pready === 1'b0 && vif_pslverr === 1'b0 && vif_prdata === 32'h0,
        "in reset: no PREADY, PSLVERR or PRDATA");
    vif_aresetn = 1'b1;

    // 1. register bank: write every register, strobes, read back; wait states
    wcnt[0] = 0; wcnt[1] = 0; wcnt[2] = 0; wmax = 0;
    for (k = 0; k < 60; k++) begin
      v = 32'h1000_0001 * (k + 1) ^ 32'hA5C3_0F96;
      xfer(1, k * 4, 3'b000, v, 4'hF, k[7:0], 8'hC0 ^ k[7:0]); check("write");
      if (r_waits <= 2) wcnt[r_waits]++;
      if (r_waits > wmax) wmax = r_waits;
      idle();
    end
    for (k = 0; k < 60; k++) begin
      xfer(0, k * 4, 3'b000, 0, 0, 8'hFF - k[7:0]); check("read-back of every register");
      if (r_waits <= 2) wcnt[r_waits]++;
      if (r_waits > wmax) wmax = r_waits;
      idle();
    end
    chk(wcnt[0] > 10 && wcnt[1] > 5 && wcnt[2] > 5 && wmax == 2,
        $sformatf("random wait states 0/1/2: %0d/%0d/%0d, longest %0d", wcnt[0], wcnt[1], wcnt[2], wmax));
    for (k = 0; k < 16; k++) begin
      xfer(1, 32'h0000_0040, 3'b000, 32'h1122_3344 * k, k[3:0], 8'h00, k[7:0]); check("partial-strobe write");
      idle();
      xfer(0, 32'h0000_0040); check("read-back after partial strobe");
      idle();
    end
    // wait-state region: always 2
    for (k = 0; k < 4; k++) begin
      xfer(1, 32'h0000_00F0 + k * 4, 3'b000, 32'hF0F0_0000 + k, 4'hF, 8'h00, 8'h77); check("wait region write", 2);
      idle();
      xfer(0, 32'h0000_00F0 + k * 4); check("wait region read", 2);
      idle();
    end

    // 2. back-to-back: PSEL stays high, the next SETUP follows each ACCESS
    xfer(1, 32'h0000_0010, 3'b000, 32'hB2B0_0001, 4'hF, 8'h21, 8'h31);           check("back-to-back write 1");
    xfer(1, 32'h0000_0014, 3'b000, 32'hB2B0_0002, 4'hF, 8'h22, 8'h32, 0, 0, 1);  check("back-to-back write 2");
    xfer(0, 32'h0000_0010, 3'b000, 0, 0, 8'h23, 8'h00, 0, 0, 1);                 check("back-to-back read 1");
    xfer(0, 32'h0000_0014, 3'b000, 0, 0, 8'h24, 8'h00, 0, 0, 1);                 check("back-to-back read 2");
    xfer(1, 32'h0000_00F8, 3'b000, 32'hB2B0_0003, 4'hF, 8'h25, 8'h35, 0, 0, 1);  check("back-to-back wait region", 2);
    idle();

    // 3. PSLVERR: error region, secure registers, nothing written
    xfer(1, 32'hEE00_0020, 3'b000, 32'hDEAD_0000, 4'hF, 8'h01, 8'h02); check("error-region write");
    idle();
    xfer(0, 32'hEE00_0020);                                            check("error-region read: zero data");
    idle();
    xfer(0, 32'h0000_0020);                                            check("register behind the error region untouched");
    idle();
    for (k = 0; k < 8; k++) begin
      xfer(1, 32'h0000_0080 + k * 8, k[2:0], 32'h5EC0_0000 + k, 4'hF, 8'h10, 8'h50 + k[7:0]);
      check($sformatf("secure register write, PPROT %0d", k));
      idle();
      xfer(0, 32'h0000_0080 + k * 8, k[2:0]);
      check($sformatf("secure register read, PPROT %0d", k));
      idle();
      xfer(0, 32'h0000_0080 + k * 8, 3'b000);
      check("secure register read-back (secure)");
      idle();
    end
    xfer(1, 32'h0000_00C0, 3'b010, 32'h0000_C0C0, 4'hF, 8'h00, 8'h66); check("non-secure write above the secure registers");
    idle();
    xfer(1, 32'h0000_007C, 3'b010, 32'h0000_7C7C, 4'hF, 8'h00, 8'h67); check("non-secure write below the secure registers");
    idle();
    xfer(0, 32'h0000_00C0, 3'b010); check("non-secure read above");
    idle();
    xfer(0, 32'h0000_007C, 3'b010); check("non-secure read below");
    idle();

    // 4. request parity errors: PSLVERR, nothing written, no read data
    for (j = 1; j <= 6; j++) begin
      xfer(1, 32'h0000_0030, 3'b000, 32'h9A9A_0000 + j, 4'hF, 8'h40, 8'h40 + j[7:0], j);
      check($sformatf("write with check signal %0d wrong", j));
      idle();
      xfer(0, 32'h0000_0030, 3'b000, 0, 0, 8'h41, 8'h00, (j < 5) ? j : 0);
      check($sformatf("read with check signal %0d wrong", (j < 5) ? j : 0));
      idle();
    end
    // PWDATACHK / PSTRBCHK do not matter on a read
    vif_pwdata = 32'hFFFF_FFFF;
    xfer(0, 32'h0000_0030, 3'b000, 0, 0, 8'h42, 8'h00, 0); check("read: write-data checks ignored");
    idle();
    // a parity error on the second of two back-to-back transfers
    xfer(1, 32'h0000_0034, 3'b000, 32'h0B0B_0001, 4'hF, 8'h43, 8'h11);           check("back-to-back, good parity");
    xfer(1, 32'h0000_0038, 3'b000, 32'h0B0B_0002, 4'hF, 8'h44, 8'h12, 1, 0, 1);  check("back-to-back, PADDRCHK wrong");
    xfer(0, 32'h0000_0034, 3'b000, 0, 0, 8'h45, 8'h00, 0, 0, 1);                 check("back-to-back read 1");
    xfer(0, 32'h0000_0038, 3'b000, 0, 0, 8'h46, 8'h00, 0, 0, 1);                 check("back-to-back read 2");
    idle();

    // 5. PWAKEUP and sleep (wait region: 2 wait states when awake)
    gap(6);  xfer(0, 32'h0000_00F0, 3'b000, 0, 0, 8'h50);       check("7 idle clocks: still awake", 2); idle();
    gap(7);  xfer(0, 32'h0000_00F0, 3'b000, 0, 0, 8'h51);       check("8 idle clocks: asleep, one more wait", 3); idle();
    gap(12); xfer(0, 32'h0000_00F4, 3'b000, 0, 0, 8'h52, 0, 0, 1); check("asleep, PWAKEUP 1 clock early", 2); idle();
    gap(12); xfer(0, 32'h0000_00F4, 3'b000, 0, 0, 8'h53, 0, 0, 3); check("asleep, PWAKEUP 3 clocks early", 2); idle();
    gap(12); xfer(1, 32'h0000_00F8, 3'b000, 32'h5EE9_0001, 4'hF, 8'h54, 8'h99); check("asleep, write", 3); idle();
    gap(30); xfer(0, 32'h0000_00F8, 3'b000, 0, 0, 8'h55);       check("asleep, read-back", 3); idle();
    // PWAKEUP high on its own keeps the slave awake
    @(negedge vif_aclk); vif_pwakeup = 1'b1;
    gap(12);
    xfer(0, 32'h0000_00F8, 3'b000, 0, 0, 8'h56);                check("PWAKEUP held high: awake", 2); idle();
    gap(12); xfer(0, 32'h0000_0044, 3'b000, 0, 0, 8'h57);       check("asleep, normal register: one more wait", -2);
    idle();

    // 6. reset in the middle: registers and user bits cleared, awake
    gap(12);
    @(negedge vif_aclk); vif_aresetn = 1'b0;
    @(negedge vif_aclk); vif_aresetn = 1'b1;
    ref_reset();
    xfer(0, 32'h0000_00F8, 3'b000, 0, 0, 8'h60);                check("after reset: awake, register 0", 2); idle();
    xfer(0, 32'h0000_0000, 3'b000, 0, 0, 8'h61);                check("after reset: register and PRUSER 0"); idle();

    chk(resp_par_bad == 0 && resp_par_seen > 500,
        $sformatf("PREADYCHK / PSLVERRCHK / PRDATACHK odd parity on %0d clocks (%0d bad)", resp_par_seen, resp_par_bad));

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
