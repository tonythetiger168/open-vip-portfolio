// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_apb_tb.sv -- AMBA APB4 functional test for the APB completer model
// (amba_dut, flattened by smoke/flatten.py); complements smoke_func_tb.sv.
// Run: python3 tools/run_func_tests.py APB-VIP
//
// Model contract (from tb/top_tb.sv): 64 x 32-bit registers (PADDR[7:2]),
// written per PSTRB byte when PREADY is high in the access phase; PRDATA
// valid in the access phase (0 otherwise); PADDR[7:4] = Fh inserts exactly
// two wait states; PADDR[31:24] = EEh answers PSLVERR (write dropped).
// Checked against a reference register file with 400 random transfers
// (back-to-back and with idle cycles), plus PREADY / PSLVERR timing.

`timescale 1ns/1ps
module func_apb_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [31:0] paddr = '0, pwdata = '0;
  logic        psel = 0, penable = 0, pwrite = 0;
  logic [3:0]  pstrb = '0;
  wire  [31:0] prdata;
  wire         pready, pslverr;
  wire         awready, wready, bvalid, arready, rvalid, rlast, tready, hreadyout, hresp;
  wire  [1:0]  bresp, rresp;
  wire  [63:0] rdata, hrdata;

  always #5 clk = ~clk;

  amba_dut u_dut (
    .vif_aclk(clk), .vif_aresetn(rst_n),
    .vif_awready(awready), .vif_wready(wready), .vif_bresp(bresp), .vif_bvalid(bvalid),
    .vif_arready(arready), .vif_rdata(rdata), .vif_rresp(rresp), .vif_rlast(rlast),
    .vif_rvalid(rvalid), .vif_tready(tready), .vif_hrdata(hrdata), .vif_hreadyout(hreadyout),
    .vif_hresp(hresp), .vif_paddr(paddr), .vif_penable(penable), .vif_psel(psel),
    .vif_pstrb(pstrb), .vif_pwdata(pwdata), .vif_pwrite(pwrite), .vif_prdata(prdata),
    .vif_pready(pready), .vif_pslverr(pslverr)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic [31:0] ref_r [0:63];
  int          waits, bad_err, bad_rd, setup_ready;
  logic        last_err;
  logic [31:0] last_rd;

  // one APB transfer: setup phase, access phase until PREADY
  task automatic xfer(input bit wr, input [31:0] a, input [31:0] d = '0, input [3:0] s = 4'hF,
                      input bit back2back = 0);
    if (!back2back) @(negedge clk);
    psel = 1; penable = 0; pwrite = wr; paddr = a; pwdata = d; pstrb = wr ? s : 4'h0;
    #1 if (pready || pslverr || prdata !== 32'h0) setup_ready++;
    @(negedge clk);
    penable = 1;
    waits = 0;
    #1;
    while (!pready) begin @(negedge clk); waits++; #1; end
    last_err = pslverr; last_rd = prdata;
    if (wr && a[31:24] != 8'hEE)
      for (int b = 0; b < 4; b++) if (s[b]) ref_r[a[7:2]][b*8 +: 8] = d[b*8 +: 8];
    @(negedge clk);
    penable = 0;
    if (!back2back) begin psel = 0; end
  endtask

  initial begin
    for (int i = 0; i < 64; i++) ref_r[i] = 32'h0;
    repeat (2) @(negedge clk);
    rst_n = 1'b1;
    @(negedge clk);
    chk(!pready && !pslverr && prdata === 32'h0, "idle bus: PREADY, PSLVERR low, PRDATA 0");

    bad_rd = 0;
    xfer(0, 32'h00);
    if (last_rd !== 32'h0) bad_rd++;
    xfer(0, 32'hFC);
    if (last_rd !== 32'h0) bad_rd++;
    chk(bad_rd == 0, "registers 0 and 63 read 0 before any write");

    xfer(1, 32'h10, 32'h1234_5678);
    chk(waits == 0 && !last_err, "write: no wait state, PSLVERR low");
    xfer(0, 32'h10);
    chk(waits == 0 && !last_err && last_rd == 32'h1234_5678, "read: no wait state, PSLVERR low, data");

    // wait-state region
    xfer(1, 32'hF0, 32'hAAAA_5555);
    chk(waits == 2 && !last_err, "PADDR[7:4] = Fh: exactly two wait states on a write");
    xfer(0, 32'hF0);
    chk(waits == 2 && last_rd == 32'hAAAA_5555, "two wait states on a read, data correct");

    // error region
    xfer(1, 32'hEE00_0020, 32'hDEAD_BEEF);
    chk(last_err && waits == 0, "PADDR[31:24] = EEh: PSLVERR in the access phase");
    xfer(0, 32'h20);
    chk(last_rd == ref_r[8], "PSLVERR write leaves the register unchanged");

    // random traffic, with and without idle cycles between transfers
    bad_rd = 0; bad_err = 0; setup_ready = 0;
    for (int t = 0; t < 400; t++) begin
      logic [31:0] a;
      bit b2b;
      a = {($urandom_range(7) == 0) ? 8'hEE : 8'h00, 16'h0, 8'($urandom_range(63) * 4)};
      b2b = $urandom_range(1);
      if ($urandom_range(1)) xfer(1, a, $urandom, $urandom_range(15), b2b);
      else begin
        xfer(0, a, '0, 4'h0, b2b);
        if (last_rd !== ref_r[a[7:2]]) bad_rd++;
      end
      if (last_err !== (a[31:24] == 8'hEE)) bad_err++;
      if (waits != ((a[7:4] == 4'hF) ? 2 : 0)) bad_err++;
    end
    @(negedge clk); psel = 0;
    chk(bad_rd == 0, "400 random transfers with PSTRB match the reference registers");
    chk(bad_err == 0, "PSLVERR only for EEh addresses, wait states only for Fh");
    chk(setup_ready == 0, "PREADY, PSLVERR low and PRDATA 0 in every setup phase");

    // PRESETn returns every register to its reset value 0
    xfer(1, 32'h00, 32'h0BAD_CAFE);
    xfer(1, 32'h10, 32'h1234_5678);
    xfer(1, 32'hFC, 32'hCAFE_F00D);
    @(negedge clk); rst_n = 1'b0;
    repeat (2) @(negedge clk); rst_n = 1'b1;
    @(negedge clk);
    bad_rd = 0;
    xfer(0, 32'h00);
    if (last_rd !== 32'h0) bad_rd++;
    xfer(0, 32'h10);
    if (last_rd !== 32'h0) bad_rd++;
    xfer(0, 32'hFC);
    if (last_rd !== 32'h0) bad_rd++;
    @(negedge clk); psel = 0;
    chk(bad_rd == 0, "reset clears the registers written before it");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
