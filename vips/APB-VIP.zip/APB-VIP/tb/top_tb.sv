// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AMBA Testbench -- top with a functional APB5 slave DUT model (register bank)
//============================================================================
`ifndef AMBA_TB_SV
`define AMBA_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import amba_vip_pkg::*;

module top_tb;
  logic aclk = 0, aresetn;
  always #5ns aclk = ~aclk;

  initial begin
    aresetn = 0;
    #100ns;
    aresetn = 1;
  end

  amba_vip_if vif(aclk, aresetn);
  amba_dut dut(.vif(vif));

  // Tiered SVA compliance checker (module form)
  apb_compliance_checker_sva u_apb_sva_chk (.vif(vif));

  // Protocol checkers (module form)
  ahb_protocol_checker_sva u_ahb_proto_sva (.vif(vif));
  apb_protocol_checker_sva u_apb_proto_sva (.vif(vif));
  axi_protocol_checker_sva u_axi_proto_sva (.vif(vif));

  initial begin
    uvm_config_db#(virtual amba_vip_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

//----------------------------------------------------------------------------
// Functional APB5 slave: 64 x 32-bit register bank.
//   - PREADY: 0-2 random wait states (LFSR), 2 for paddr[7:4] == 4'hF
//   - low power: asleep after 8 cycles with PWAKEUP and PSEL low; waking
//     takes 2 cycles of PWAKEUP high, and an access waits until then
//   - PSLVERR (no write, PRDATA / PRUSER zero) for the error region
//     paddr[31:24] == 8'hEE, for a non-secure access (PPROT[1]) to the
//     secure registers 0x80-0xBF, and for a request parity error
//   - PSTRB byte-enable write masking
//   - PWUSER stored with each written register and returned on PRUSER;
//     PBUSER echoes PAUSER[3:0]
//   - odd parity per byte: PADDRCHK, PCTRLCHK (PPROT, PWRITE), PSELCHK,
//     PENABLECHK, PWDATACHK, PSTRBCHK checked in the access phase;
//     PRDATACHK, PREADYCHK, PSLVERRCHK driven
//----------------------------------------------------------------------------
module amba_dut(amba_vip_if vif);

  logic [31:0] regbank [0:63];
  logic [7:0]  ubank   [0:63];
  logic [1:0]  wait_cnt, need;
  logic [15:0] lfsr;
  logic        awake, wk;
  logic [2:0]  idle;

  function automatic logic [3:0] par4(input logic [31:0] v);
    for (int b = 0; b < 4; b++) par4[b] = ~^v[b*8 +: 8];
  endfunction

  wire       setup        = vif.psel && !vif.penable;
  wire       access       = vif.psel && vif.penable;
  wire       wait_region  = (vif.paddr[7:4] == 4'hF);
  wire       error_region = (vif.paddr[31:24] == 8'hEE);
  wire       prot_err     = (vif.paddr[7:6] == 2'b10) && vif.pprot[1];
  wire       par_err      = (vif.paddrchk != par4(vif.paddr)) || (vif.pctrlchk != ~^{vif.pprot, vif.pwrite}) ||
                            (vif.pselchk != ~vif.psel) || (vif.penablechk != ~vif.penable) ||
                            (vif.pwrite && ((vif.pwdatachk != par4(vif.pwdata)) || (vif.pstrbchk != ~^vif.pstrb)));
  wire       bad          = error_region || prot_err || par_err;
  wire [5:0] reg_idx      = vif.paddr[7:2];

  assign vif.pready     = access && awake && (wait_cnt >= need);
  assign vif.pslverr    = vif.pready && bad;
  assign vif.prdata     = (access && !bad) ? regbank[reg_idx] : 32'h0;
  assign vif.pruser     = (access && !vif.pwrite && !bad) ? ubank[reg_idx] : 8'h0;
  assign vif.pbuser     = access ? vif.pauser[3:0] : 4'h0;
  assign vif.prdatachk  = par4(vif.prdata);
  assign vif.preadychk  = ~vif.pready;
  assign vif.pslverrchk = ~vif.pslverr;

  always_ff @(posedge vif.aclk or negedge vif.aresetn) begin
    if (!vif.aresetn) begin
      wait_cnt <= 2'd0; need <= 2'd0;
      lfsr <= 16'hACE1;
      awake <= 1'b1; wk <= 1'b0; idle <= 3'd0;
      // registers reset to 0 (env/amba_reg_model.sv reset values)
      for (int i = 0; i < 64; i++) begin regbank[i] <= 32'h0; ubank[i] <= 8'h0; end
    end
    else begin
      lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      // wait states of the access: fixed by the SETUP phase
      if (setup) need <= wait_region ? 2'd2 : (lfsr[1:0] == 2'b11) ? 2'd2 : (lfsr[1:0] == 2'b10) ? 2'd1 : 2'd0;
      if (!access)                       wait_cnt <= 2'd0;
      else if (awake && wait_cnt < 2'd2) wait_cnt <= wait_cnt + 2'd1;
      // low-power state
      if (vif.pwakeup) begin
        idle <= 3'd0;
        if (!awake) begin
          wk <= 1'b1;
          if (wk) begin awake <= 1'b1; wk <= 1'b0; end
        end
      end
      else begin
        wk <= 1'b0;
        if (vif.psel)           idle <= 3'd0;
        else if (idle == 3'd7)  awake <= 1'b0;
        else                    idle <= idle + 3'd1;
      end
      // register write with byte enables
      if (vif.pready && vif.pwrite && !bad) begin
        for (int b = 0; b < 4; b++)
          if (vif.pstrb[b])
            regbank[reg_idx][b*8 +: 8] <= vif.pwdata[b*8 +: 8];
        ubank[reg_idx] <= vif.pwuser;
      end
    end
  end

  // Tie off unused protocol outputs (AXI/AHB) so no X propagates
  initial begin
    vif.awready = 1'b0; vif.wready = 1'b0; vif.bvalid = 1'b0; vif.bresp = 2'b00;
    vif.arready = 1'b0; vif.rvalid = 1'b0; vif.rdata = 64'h0;
    vif.rresp = 2'b00;  vif.rlast = 1'b0;  vif.tready = 1'b0;
    vif.hreadyout = 1'b0; vif.hrdata = 64'h0; vif.hresp = 1'b0;
  end
endmodule
`endif
