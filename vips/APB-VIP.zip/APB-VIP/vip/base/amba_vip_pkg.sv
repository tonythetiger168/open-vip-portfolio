// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AMBA VIP Package
// Protocols: AXI4/AXI4-Lite/AXI4-Stream, AHB5/APB4
//============================================================================
`ifndef AMBA_VIP_PKG_SV
`define AMBA_VIP_PKG_SV

// Tiered SVA compliance checker (L1/L2/L3/L4). The SVA content lives in a
// module (class-scope concurrent assertions are illegal per IEEE 1800), so
// this file must be included at compilation-unit scope, outside the package.
`include "sva/apb_compliance_checker.sv"
// Protocol checkers: SVA content lives in modules (class-scope concurrent
// assertions are illegal per IEEE 1800); thin class shells remain. Included
// at compilation-unit scope, before the package, so amba_env can see them.
`include "ahb_protocol_checker.sv"
`include "apb_protocol_checker.sv"
`include "axi_protocol_checker.sv"

package amba_vip_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef enum int { AXI4=0, AXI4_LITE=1, AXI4_STREAM=2, AHB5=3, APB4=4, AMBA_MAX=5 } amba_protocol_e;
  typedef enum logic [1:0] { BURST_FIXED=2'b00, BURST_INCR=2'b01, BURST_WRAP=2'b10, BURST_RSVD=2'b11 } axburst_e;
  typedef enum logic [2:0] { SIZE_1B=3'b000, SIZE_2B=3'b001, SIZE_4B=3'b010, SIZE_8B=3'b011,
                             SIZE_16B=3'b100, SIZE_32B=3'b101, SIZE_64B=3'b110, SIZE_128B=3'b111 } axsize_e;
  typedef enum logic [1:0] { RESP_OKAY=2'b00, RESP_EXOKAY=2'b01, RESP_SLVERR=2'b10, RESP_DECERR=2'b11 } resp_e;
  typedef enum logic [2:0] { AHB_IDLE=3'b000, AHB_BUSY=3'b001, AHB_NONSEQ=3'b010, AHB_SEQ=3'b011 } htrans_e;

  class amba_txn extends uvm_object;
    `uvm_object_utils(amba_txn)
    rand amba_protocol_e protocol;
    rand logic [31:0]   addr;
    rand logic [63:0]   data[];
    rand int            len;
    rand axburst_e      burst;
    rand axsize_e       size;
    rand logic [3:0]    cache;
    rand logic [2:0]    prot;
    rand resp_e         resp;
    rand bit            excl;
    rand int            delay;
    rand bit            write;   // 1 = write, 0 = read
    // APB4 PSTRB / byte-lane strobes of a write. Full by default (items
    // that are not randomized, such as the RAL adapter's, write every byte);
    // a sequence clears full_strb to randomize them, 4'h0 included (APB4
    // allows a write with no lane enabled). Reads always drive 4'h0.
    rand logic [3:0]    strb = 4'hF;
    bit                 full_strb = 1;
    // APB5
    rand logic [7:0]    auser;          // PAUSER of every transfer of the item
    logic [7:0]         wuser[];        // PWUSER per write transfer (0 when not given)
    logic [7:0]         ruser[];        // PRUSER per read transfer (observed)
    logic [3:0]         buser;          // PBUSER of the last transfer (observed)
    // request parity error injected on transfer par_beat:
    // 0 none, 1 PADDRCHK, 2 PCTRLCHK, 3 PSELCHK, 4 PENABLECHK, 5 PWDATACHK, 6 PSTRBCHK
    int unsigned        par_inj = 0;
    int unsigned        par_beat = 0;
    int unsigned        wake_lead = 0;  // clocks PWAKEUP is high before PSEL when it was low
    bit                 slept;          // PWAKEUP was low long enough for the slave to sleep
    int unsigned        n_wait;         // wait states seen

    constraint c_len  { len inside {[1:16]}; }
    constraint c_data { data.size() == len; }
    constraint c_resp { resp dist { RESP_OKAY := 90, RESP_SLVERR := 10 }; }
    // Inter-transfer idle cycles. Unconstrained, a random int delay is up to
    // 2^31 clock cycles in "repeat (t.delay)" in the driver, so a randomized
    // sequence effectively never finishes.
    constraint c_delay { delay inside {[0:3]}; }
    constraint c_strb  { !write -> strb == 4'h0; (write && full_strb) -> strb == 4'hF; }

    function new(string name = "amba_txn");
      super.new(name);
    endfunction

    virtual function string convert2string();
      return $sformatf("%s %s addr=0x%08X len=%0d prot=%0d resp=%s strb=%h auser=%02h%s",
                       protocol.name(), write ? "WR" : "RD", addr, len, prot,
                       resp.name(), strb, auser, par_inj ? $sformatf(" PARERR%0d@%0d", par_inj, par_beat) : "");
    endfunction
  endclass

  class amba_seq_item extends uvm_sequence_item;
    `uvm_object_utils(amba_seq_item)
    rand amba_txn txn;
    function new(string name = "amba_seq_item");
      super.new(name);
      txn = amba_txn::type_id::create("txn");
    endfunction
    virtual function string convert2string();
      return txn.convert2string();
    endfunction
  endclass

  class amba_cov extends uvm_subscriber #(amba_seq_item);
    `uvm_component_utils(amba_cov)
    amba_protocol_e protocol;
    axburst_e burst;
    axsize_e size;
    int len;
    resp_e resp;
    logic clk;
    covergroup cg_axi;
      option.per_instance = 1;
      cp_prot: coverpoint protocol { bins axi4 = {AXI4}; bins lite = {AXI4_LITE};
                                     bins stream = {AXI4_STREAM}; bins ahb = {AHB5}; bins apb = {APB4}; }
      cp_burst: coverpoint burst { bins fixed = {BURST_FIXED}; bins incr = {BURST_INCR}; bins wrap = {BURST_WRAP}; }
      cp_size: coverpoint size { bins b1 = {SIZE_1B}; bins b4 = {SIZE_4B}; bins b8 = {SIZE_8B};
                                 bins b16 = {SIZE_16B}; bins b64 = {SIZE_64B}; bins b128 = {SIZE_128B}; }
      cp_len: coverpoint len { bins single = {1}; bins burst4 = {[2:4]}; bins burst8 = {[5:8]}; bins burst16 = {[9:16]}; }
      cp_resp: coverpoint resp { bins ok = {RESP_OKAY}; bins slv = {RESP_SLVERR};
                                 // REACHABILITY: RESP_EXOKAY / RESP_DECERR can never be observed in
                                 // this TB: AHB hresp and APB pslverr are 1-bit (OKAY/ERROR only) and
                                 // the AXI DUT model drives only OKAY/SLVERR on bresp/rresp.
                                 ignore_bins ex  = {RESP_EXOKAY};
                                 ignore_bins dec = {RESP_DECERR}; }
      cross_burst_len: cross cp_burst, cp_len;
      cross_prot_size: cross cp_prot, cp_size;
    endgroup
    function new(string name = "amba_cov", uvm_component parent = null);
      super.new(name, parent);
      cg_axi = new();
    endfunction
    // uvm_subscriber write: sample observed (monitor-decoded) transactions
    function void write(amba_seq_item t);   // argument name must match uvm_subscriber::write
      sample(t.txn);
    endfunction
    function void sample(amba_txn t);
      protocol = t.protocol;
      burst    = t.burst;
      size     = t.size;
      len      = t.len;
      resp     = t.resp;
      cg_axi.sample();
    endfunction
    function real get_cov();
      return cg_axi.get_coverage();
    endfunction
  endclass

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)
  `uvm_analysis_imp_decl(_beat)

  // End-to-end scoreboard: compares driver-issued (expected) transactions
  // against monitor-decoded (observed) transactions.
  class amba_sb extends uvm_scoreboard;
    `uvm_component_utils(amba_sb)
    uvm_analysis_imp     #(amba_seq_item, amba_sb) analysis_imp;  // legacy counting port
    uvm_analysis_imp_exp #(amba_seq_item, amba_sb) exp_ap;
    uvm_analysis_imp_obs #(amba_seq_item, amba_sb) obs_ap;
    uvm_analysis_imp_beat #(amba_seq_item, amba_sb) beat_ap;   // one item per completed APB transfer

    // Reference model of the TB's APB register bank (tb/top_tb.sv): model_words
    // 32-bit registers indexed by PADDR[7:2], reset to 0, written byte lane by
    // byte lane under PSTRB, writes that end in PSLVERR ignored. Every
    // observed read is checked against it, so a DUT that ignores a strobe
    // bit fails. Off unless the env sets model_regbank.
    bit          model_regbank = 0;
    int unsigned model_words   = 64;
    logic [31:0] shadow[int unsigned];
    logic [7:0]  ushadow[int unsigned];   // PWUSER stored with each register
    int unsigned n_reads_checked = 0, n_resp_checked = 0;

    int txn_cnt, err_cnt;
    int unsigned n_matches = 0, n_mismatches = 0;
    amba_seq_item exp_q[$], obs_q[$];

    function new(string name = "amba_sb", uvm_component parent = null);
      super.new(name, parent);
      analysis_imp = new("analysis_imp", this);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
      beat_ap = new("beat_ap", this);
    endfunction

    virtual function void write_beat(amba_seq_item item);
      int unsigned idx;
      logic [31:0] cur;
      bit          exp_err;
      if (!model_regbank || item.txn.protocol != APB4) return;
      idx = (item.txn.addr >> 2) % model_words;
      cur = shadow.exists(idx) ? shadow[idx] : 32'h0;
      // PSLVERR: error region, non-secure access to the secure registers
      // 0x80-0xBF, request parity error (the monitor reports which check)
      exp_err = item.txn.addr[31:24] == 8'hEE || (item.txn.addr[7:6] == 2'b10 && item.txn.prot[1]) ||
                item.txn.par_inj != 0;
      n_resp_checked++;
      if ((item.txn.resp == RESP_SLVERR) != exp_err) begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("%s: PSLVERR %0d, expected %0d", item.convert2string(),
                   item.txn.resp == RESP_SLVERR, exp_err))
      end
      if (item.txn.buser !== item.txn.auser[3:0]) begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("%s: PBUSER %h, expected PAUSER[3:0]", item.convert2string(), item.txn.buser))
      end
      if (item.txn.write) begin
        if (!exp_err) begin
          for (int b = 0; b < 4; b++)
            if (item.txn.strb[b]) cur[b*8 +: 8] = item.txn.data[0][b*8 +: 8];
          ushadow[idx] = item.txn.wuser[0];
        end
        shadow[idx] = cur;
      end else begin
        logic [31:0] e = exp_err ? 32'h0 : cur;
        logic [7:0]  u = (exp_err || !ushadow.exists(idx)) ? 8'h0 : ushadow[idx];
        n_reads_checked++;
        if (item.txn.data[0][31:0] !== e || item.txn.ruser[0] !== u) begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("read 0x%08h returned 0x%08h / PRUSER %02h, register model expects 0x%08h / %02h",
                     item.txn.addr, item.txn.data[0][31:0], item.txn.ruser[0], e, u))
        end else n_matches++;
      end
    endfunction

    virtual function void write(amba_seq_item item);
      txn_cnt++;
      if (item.txn.resp inside {RESP_SLVERR, RESP_DECERR}) err_cnt++;
    endfunction

    virtual function void write_exp(amba_seq_item item);
      exp_q.push_back(item);
      check();
    endfunction

    virtual function void write_obs(amba_seq_item item);
      obs_q.push_back(item);
      check();
    endfunction

    virtual function void check();
      while (exp_q.size() && obs_q.size()) begin
        amba_seq_item e = exp_q.pop_front();
        amba_seq_item o = obs_q.pop_front();
        bit ok = (e.txn.addr == o.txn.addr) && (e.txn.len == o.txn.len) &&
                 (e.txn.write == o.txn.write) &&
                 (e.txn.protocol != APB4 || !e.txn.write || e.txn.strb == o.txn.strb) &&
                 (e.txn.protocol != APB4 || (e.txn.auser == o.txn.auser && e.txn.prot == o.txn.prot));
        if (ok && e.txn.protocol == APB4 && e.txn.write)
          foreach (e.txn.wuser[i]) if (i < o.txn.wuser.size() && e.txn.wuser[i] !== o.txn.wuser[i]) ok = 0;
        if (ok && e.txn.write)
          foreach (e.txn.data[i])
            // APB4 carries 32 data bits; the item's upper 32 are not driven
            if ((e.txn.protocol == APB4) ? (e.txn.data[i][31:0] !== o.txn.data[i][31:0])
                                          : (e.txn.data[i] !== o.txn.data[i])) ok = 0;
        if (ok) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    virtual function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("TXN:%0d ERR:%0d", txn_cnt, err_cnt), UVM_LOW)
      `uvm_info("SB", $sformatf("amba scoreboard: n_matches=%0d n_mismatches=%0d reads_checked=%0d",
                n_matches, n_mismatches, n_reads_checked), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  // Deepened AHB5 master UVC (sequencer/driver/monitor/agent/coverage/sequences)
  `include "apb_sequencer.svh"
  `include "apb_driver.svh"
  `include "apb_monitor.svh"
  `include "apb_agent.svh"
  `include "apb_coverage.svh"
  `include "apb_sequences.svh"

  // UVM RAL adapter (register model frontdoor over this agent)
  `include "amba_reg_adapter.svh"
endpackage
`endif
