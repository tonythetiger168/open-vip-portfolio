// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// apb_monitor.svh -- APB4 monitor: decodes SETUP/ACCESS transfers from the
// bus (completes on PSEL&PENABLE&PREADY) and publishes transactions.

`ifndef APB_MONITOR_SVH
`define APB_MONITOR_SVH

class apb_monitor extends uvm_monitor;
  `uvm_component_utils(apb_monitor)
  virtual amba_vip_if vif;
  uvm_analysis_port #(amba_seq_item) ap;
  // One single-beat item per completed transfer, written on the completing
  // clock edge. ap above coalesces bursts and so publishes a cycle late
  // (on the next transfer or PSEL low); a register predictor must use
  // beat_ap, or a late read prediction overwrites the next write's value.
  uvm_analysis_port #(amba_seq_item) beat_ap;
  int unsigned txn_count = 0;

  // Re-assemble consecutive same-direction transfers into one burst item
  protected amba_seq_item open_item;
  protected int unsigned beat_cnt;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
    beat_ap = new("beat_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "APB virtual interface not set")
  endfunction

  function automatic void flush();
    if (open_item != null) begin
      open_item.txn.len = beat_cnt;
      open_item.txn.data = new[beat_cnt](open_item.txn.data);
      open_item.txn.wuser = new[beat_cnt](open_item.txn.wuser);
      open_item.txn.ruser = new[beat_cnt](open_item.txn.ruser);
      txn_count++;
      `uvm_info("MON", {"mon: ", open_item.convert2string()}, UVM_HIGH)
      ap.write(open_item);
      open_item = null;
      beat_cnt = 0;
    end
  endfunction

  function automatic logic [3:0] par4(logic [31:0] v);
    for (int b = 0; b < 4; b++) par4[b] = ~^v[b*8 +: 8];
  endfunction

  // which request check signal is wrong in this ACCESS cycle (0 = none)
  function automatic int unsigned req_par_err();
    if (vif.mon_cb.paddrchk   !== par4(vif.mon_cb.paddr))                 return 1;
    if (vif.mon_cb.pctrlchk   !== ~^{vif.mon_cb.pprot, vif.mon_cb.pwrite}) return 2;
    if (vif.mon_cb.pselchk    !== ~vif.mon_cb.psel)                       return 3;
    if (vif.mon_cb.penablechk !== ~vif.mon_cb.penable)                    return 4;
    if (vif.mon_cb.pwrite && vif.mon_cb.pwdatachk !== par4(vif.mon_cb.pwdata)) return 5;
    if (vif.mon_cb.pwrite && vif.mon_cb.pstrbchk  !== ~^vif.mon_cb.pstrb)      return 6;
    return 0;
  endfunction

  int unsigned n_resp_par_err = 0;
  int unsigned low_cnt = 0, lead = 0, waits = 0;   // the slave is awake out of reset
  bit          wake_seen = 0, slept = 0;

  task run_phase(uvm_phase phase);
    wait (vif.aresetn === 1'b1);
    beat_cnt = 0;
    forever begin
      @(vif.mon_cb);
      // PWAKEUP: how long it was low before rising (the slave sleeps after
      // 8 idle clocks), and how many clocks it led PSEL
      if (!vif.mon_cb.psel) begin
        if (!vif.mon_cb.pwakeup) begin
          if (low_cnt < 1000) low_cnt++;
          wake_seen = 0;
        end
        else begin
          if (!wake_seen) begin slept = (low_cnt >= 8); lead = 0; wake_seen = 1; end
          lead++;
          low_cnt = 0;
        end
      end
      else if (!vif.mon_cb.penable && !wake_seen) begin   // PWAKEUP rose with PSEL
        slept = (low_cnt >= 8); lead = 0; wake_seen = 1; low_cnt = 0;
      end
      // response check signals (odd parity) whenever the slave drives them
      if (vif.mon_cb.preadychk !== ~vif.mon_cb.pready || vif.mon_cb.pslverrchk !== ~vif.mon_cb.pslverr ||
          vif.mon_cb.prdatachk !== par4(vif.mon_cb.prdata)) begin
        n_resp_par_err++;
        `uvm_error("MON", $sformatf("response parity error: PREADY %b/%b PSLVERR %b/%b PRDATA %h/%h",
                   vif.mon_cb.pready, vif.mon_cb.preadychk, vif.mon_cb.pslverr, vif.mon_cb.pslverrchk,
                   vif.mon_cb.prdata, vif.mon_cb.prdatachk))
      end
      if (vif.mon_cb.psel && vif.mon_cb.penable && !vif.mon_cb.pready) waits++;
      // Transfer completes on PSEL & PENABLE & PREADY
      if (vif.mon_cb.psel && vif.mon_cb.penable && vif.mon_cb.pready) begin
        bit wr = vif.mon_cb.pwrite;
        bit [31:0] a = vif.mon_cb.paddr;
        if (open_item != null &&
            (open_item.txn.write != wr ||
             (wr && open_item.txn.strb != vif.mon_cb.pstrb) ||
             a != open_item.txn.addr + beat_cnt * 4))
          flush();                       // direction/address discontinuity
        if (open_item == null) begin
          open_item = amba_seq_item::type_id::create("open_item");
          open_item.txn.protocol = APB4;
          open_item.txn.addr  = a;
          open_item.txn.write = wr;
          open_item.txn.len   = 1;
          open_item.txn.size  = SIZE_4B;
          open_item.txn.burst = BURST_INCR;
          open_item.txn.prot  = vif.mon_cb.pprot;
          open_item.txn.strb  = wr ? vif.mon_cb.pstrb : 4'h0;
          open_item.txn.resp  = RESP_OKAY;
          open_item.txn.data  = new[64];
          open_item.txn.wuser = new[64];
          open_item.txn.ruser = new[64];
          open_item.txn.auser = vif.mon_cb.pauser;
          open_item.txn.wake_lead = lead;
          open_item.txn.slept = slept;
          open_item.txn.n_wait = 0;
          beat_cnt = 0;
        end
        if (wr) open_item.txn.data[beat_cnt] = {32'h0, vif.mon_cb.pwdata};
        else    open_item.txn.data[beat_cnt] = {32'h0, vif.mon_cb.prdata};
        open_item.txn.wuser[beat_cnt] = wr ? vif.mon_cb.pwuser : 8'h0;
        open_item.txn.ruser[beat_cnt] = wr ? 8'h0 : vif.mon_cb.pruser;
        open_item.txn.buser = vif.mon_cb.pbuser;
        open_item.txn.n_wait += waits;
        if (req_par_err() && !open_item.txn.par_inj) begin
          open_item.txn.par_inj  = req_par_err();
          open_item.txn.par_beat = beat_cnt;
        end
        if (vif.mon_cb.pslverr) open_item.txn.resp = RESP_SLVERR;
        begin
          amba_seq_item b = amba_seq_item::type_id::create("beat_item");
          b.txn.protocol = APB4;
          b.txn.addr     = a;
          b.txn.write    = wr;
          b.txn.len      = 1;
          b.txn.size     = SIZE_4B;
          b.txn.burst    = BURST_INCR;
          b.txn.prot     = vif.mon_cb.pprot;
          b.txn.strb     = wr ? vif.mon_cb.pstrb : 4'h0;
          b.txn.resp     = vif.mon_cb.pslverr ? RESP_SLVERR : RESP_OKAY;
          b.txn.data     = new[1];
          b.txn.data[0]  = open_item.txn.data[beat_cnt];
          b.txn.wuser    = new[1];
          b.txn.ruser    = new[1];
          b.txn.wuser[0] = open_item.txn.wuser[beat_cnt];
          b.txn.ruser[0] = open_item.txn.ruser[beat_cnt];
          b.txn.auser    = vif.mon_cb.pauser;
          b.txn.buser    = vif.mon_cb.pbuser;
          b.txn.par_inj  = req_par_err();
          b.txn.n_wait   = waits;
          beat_ap.write(b);
        end
        beat_cnt++;
        waits = 0;
      end
      else if (!vif.mon_cb.psel && open_item != null)
        flush();                         // bus returned to IDLE: close burst
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("APB monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
