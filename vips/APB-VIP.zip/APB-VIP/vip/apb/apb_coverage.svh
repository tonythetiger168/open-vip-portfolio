// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// apb_coverage.svh -- APB4 functional coverage:
//   cg_protocol : transfer config (dir x prot x resp, burst len) + crosses
//   cg_fsm      : PSEL/PENABLE bus-state transitions
//   cg_data     : data pattern corners x direction

`ifndef APB_COVERAGE_SVH
`define APB_COVERAGE_SVH

class apb_coverage extends uvm_subscriber #(amba_seq_item);
  `uvm_component_utils(apb_coverage)

  amba_seq_item tr;
  bit [1:0] bus_state;   // {psel, penable}

  covergroup cg_protocol;
    option.per_instance = 1;
    cp_write: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cp_prot: coverpoint tr.txn.prot { bins normal = {3'b000}; bins priv = {3'b001};
                                      bins secure = {3'b010}; bins other = default; }
    cp_len: coverpoint tr.txn.len { bins single = {1}; bins short = {[2:4]};
                                    bins mid = {[5:8]}; bins long = {[9:16]}; }
    cp_resp: coverpoint tr.txn.resp { bins ok = {RESP_OKAY}; bins err = {RESP_SLVERR}; }
    cx_wr_prot: cross cp_write, cp_prot;
    cx_wr_len:  cross cp_write, cp_len;
    cx_wr_resp: cross cp_write, cp_resp;
  endgroup

  // Sampled every clock, so the transitions are real bus-state transitions
  // (sampling once per transaction can never see SETUP -> ACCESS).
  covergroup cg_fsm with function sample(bit [1:0] s);
    option.per_instance = 1;
    cp_state: coverpoint s {
      bins idle   = {2'b00};
      bins setup  = {2'b10};
      bins access = {2'b11};
    }
    cp_trans: coverpoint s {
      bins to_setup   = (2'b00 => 2'b10);
      bins to_access  = (2'b10 => 2'b11);
      bins complete   = (2'b11 => 2'b00);
      bins b2b_setup  = (2'b11 => 2'b10);
      bins wait_state = (2'b11 => 2'b11);
    }
  endgroup

  // APB5: wake-up, user signals, protection, parity errors, wait states
  covergroup cg_apb5;
    option.per_instance = 1;
    cp_write: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cp_lead: coverpoint tr.txn.wake_lead { bins with_psel = {0}; bins one = {1}; bins two_plus = {[2:$]}; }
    cp_slept: coverpoint tr.txn.slept { bins awake = {0}; bins asleep = {1}; }
    cp_auser: coverpoint tr.txn.auser { bins zero = {8'h00}; bins ones = {8'hFF}; bins low = {[8'h01:8'h7F]}; bins high = {[8'h80:8'hFE]}; }
    cp_secure: coverpoint {tr.txn.addr[7:6] == 2'b10, tr.txn.prot[1]} {
      bins other_s = {2'b00}; bins other_ns = {2'b01}; bins secure_s = {2'b10}; bins secure_ns = {2'b11}; }
    cp_par: coverpoint tr.txn.par_inj { bins none = {0}; bins paddr = {1}; bins pctrl = {2}; bins psel = {3};
                                        bins penable = {4}; bins pwdata = {5}; bins pstrb = {6}; }
    cp_wait: coverpoint tr.txn.n_wait { bins none = {0}; bins few = {[1:3]}; bins many = {[4:$]}; }
    cp_resp: coverpoint tr.txn.resp { bins ok = {RESP_OKAY}; bins err = {RESP_SLVERR}; }
    cx_wake: cross cp_lead, cp_slept;
    cx_secure: cross cp_secure, cp_write;
    cx_par: cross cp_par, cp_write {
      // PWDATACHK / PSTRBCHK only cover write transfers
      ignore_bins rd_wdata = binsof(cp_par.pwdata) && binsof(cp_write.rd);
      ignore_bins rd_strb  = binsof(cp_par.pstrb) && binsof(cp_write.rd); }
    cx_wait: cross cp_wait, cp_write;
  endgroup

  covergroup cg_data;
    option.per_instance = 1;
    cp_data: coverpoint tr.txn.data[0][31:0] iff (tr.txn.data.size() > 0) {
      bins zero = {32'h0};
      bins ones = {32'hFFFF_FFFF};
      bins aa55 = {32'hAAAA_AAAA, 32'h5555_5555};
      bins other = default;
    }
    cp_w: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cx_wr_data: cross cp_data, cp_w;
  endgroup

  virtual amba_vip_if vif;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_data     = new();
    cg_apb5     = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif));
  endfunction

  task run_phase(uvm_phase phase);
    if (vif == null) return;
    forever begin
      @(posedge vif.aclk);
      if (vif.aresetn === 1'b1) begin
        bus_state = {vif.psel, vif.penable};
        cg_fsm.sample(bus_state);
      end
    end
  endtask

  function void write(amba_seq_item t);
    tr = t;
    cg_protocol.sample();
    cg_data.sample();
    cg_apb5.sample();
  endfunction
endclass
`endif
