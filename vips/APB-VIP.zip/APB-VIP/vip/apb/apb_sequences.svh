// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// apb_sequences.svh -- APB4 sequence library:
//   base / write / read / back-to-back / wait-state / error-inject /
//   reset / stress / regression mix

`ifndef APB_SEQUENCES_SVH
`define APB_SEQUENCES_SVH

class apb_base_sequence extends uvm_sequence #(amba_seq_item);
  `uvm_object_utils(apb_base_sequence)
  int num_txns = 20;
  function new(string name = "apb_base_sequence");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == APB4;
                                    txn.addr[1:0] == 2'b00;
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: write bursts to the register bank
class apb_write_seq extends apb_base_sequence;
  `uvm_object_utils(apb_write_seq)
  function new(string name = "apb_write_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == APB4; txn.write == 1;
                                    txn.addr[1:0] == 2'b00;
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: read bursts of varying length
class apb_read_seq extends apb_base_sequence;
  `uvm_object_utils(apb_read_seq)
  function new(string name = "apb_read_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == APB4; txn.write == 0;
                                    txn.len inside {[1:8]};
                                    txn.addr[1:0] == 2'b00;
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: back-to-back single transfers with zero gap
class apb_back_to_back_seq extends apb_base_sequence;
  `uvm_object_utils(apb_back_to_back_seq)
  function new(string name = "apb_back_to_back_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == APB4; txn.len == 1;
                                    txn.delay == 0;
                                    txn.addr[1:0] == 2'b00;
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: wait-state region accesses (PREADY delayed, paddr[7:4]==4'hF)
class apb_wait_state_seq extends apb_base_sequence;
  `uvm_object_utils(apb_wait_state_seq)
  function new(string name = "apb_wait_state_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == APB4;
                                    txn.addr[7:4] == 4'hF;
                                    txn.addr[1:0] == 2'b00;
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Error injection: PSLVERR region (0xEE00_0000)
class apb_error_inject_seq extends apb_base_sequence;
  `uvm_object_utils(apb_error_inject_seq)
  function new(string name = "apb_error_inject_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == APB4;
                                    txn.addr[31:24] == 8'hEE;
                                    txn.len == 1; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Reset behavior: single transfer right after reset release
class apb_reset_seq extends apb_base_sequence;
  `uvm_object_utils(apb_reset_seq)
  function new(string name = "apb_reset_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item = amba_seq_item::type_id::create("item");
    start_item(item);
    if (!(item.randomize() with { txn.protocol == APB4; txn.len == 1;
                                  txn.addr[1:0] == 2'b00;
                                  txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
    finish_item(item);
  endtask
endclass

// Stress: high-volume random bursts
class apb_stress_seq extends apb_base_sequence;
  `uvm_object_utils(apb_stress_seq)
  function new(string name = "apb_stress_seq");
    super.new(name);
    num_txns = 100;
  endfunction
endclass

// Partial writes: single writes with random PSTRB (4'h0 and every single
// lane included), each followed by a read of the same register, so the
// scoreboard's register model checks which byte lanes the DUT updated.
// The first 16 writes walk every strobe value once.
class apb_partial_write_seq extends apb_base_sequence;
  `uvm_object_utils(apb_partial_write_seq)
  function new(string name = "apb_partial_write_seq");
    super.new(name);
    num_txns = 64;
  endfunction
  // No randomize(): fields are set directly ($urandom), so the sequence runs
  // on simulators that cannot solve the nested amba_txn constraints.
  function amba_seq_item mk(string name, bit wr, logic [31:0] a, logic [3:0] strb);
    amba_seq_item it = amba_seq_item::type_id::create(name);
    it.txn.protocol = APB4;     it.txn.burst = BURST_INCR;  it.txn.size  = SIZE_4B;
    it.txn.len      = 1;        it.txn.write = wr;          it.txn.cache = 4'h0;
    it.txn.addr     = a;        it.txn.prot  = $urandom_range(7);
    it.txn.resp     = RESP_OKAY; it.txn.excl = 1'b0;        it.txn.delay = $urandom_range(3);
    it.txn.full_strb = 0;       it.txn.strb  = wr ? strb : 4'h0;
    it.txn.data     = new[1];   it.txn.data[0] = {32'h0, $urandom};
    return it;
  endfunction
  task body();
    amba_seq_item wr, rd;
    for (int n = 0; n < num_txns; n++) begin
      // the first 16 writes walk every PSTRB value, 4'h0 included
      logic [3:0]  strb = (n < 16) ? n[3:0] : 4'($urandom_range(15));
      logic [31:0] a    = $urandom & 32'h00FF_FFFC;   // outside the PSLVERR region
      wr = mk("wr", 1, a, strb);
      start_item(wr);
      finish_item(wr);
      rd = mk("rd", 0, a, 4'h0);
      start_item(rd);
      finish_item(rd);
    end
  endtask
endclass

// Coverage sweep: every PPROT value x direction x length class, in the
// zero-wait and the wait-state regions, with corner data patterns, then
// num_txns random transfers. No randomize(): every field is set directly
// ($urandom for the random part), so the sequence runs on simulators that
// cannot solve the nested amba_txn constraints (Verilator).
class apb_cov_sweep_seq extends apb_base_sequence;
  `uvm_object_utils(apb_cov_sweep_seq)
  function new(string name = "apb_cov_sweep_seq");
    super.new(name);
    num_txns = 100;
  endfunction
  function logic [63:0] pattern(int n);
    case (n % 5)
      0: return 64'h0;
      1: return 64'hFFFF_FFFF;
      2: return 64'hAAAA_AAAA;
      3: return 64'h5555_5555;
      default: return {32'h0, $urandom};
    endcase
  endfunction
  task send(bit wr, logic [2:0] p, int l, logic [31:0] a, int n, int dly = 0);
    amba_seq_item item = amba_seq_item::type_id::create("item");
    start_item(item);
    item.txn.protocol = APB4;      item.txn.burst = BURST_INCR; item.txn.size = SIZE_4B;
    item.txn.len      = l;         item.txn.write = wr;         item.txn.cache = 4'h0;
    item.txn.addr     = a;         item.txn.prot  = p;          item.txn.resp  = RESP_OKAY;
    item.txn.excl     = 1'b0;      item.txn.delay = dly;
    item.txn.strb     = wr ? 4'hF : 4'h0;
    item.txn.data     = new[l];
    foreach (item.txn.data[i]) item.txn.data[i] = pattern(n + i);
    finish_item(item);
  endtask
  task body();
    int lens[4] = '{1, 3, 6, 12};
    int n = 0;
    for (int p = 0; p < 8; p++) foreach (lens[l]) begin
      // alternate the zero-wait region and the 2-wait-state region (paddr[7:4] == F)
      logic [31:0] a = (n % 2) ? 32'h0000_00F0 : ((n * 16) % 128);
      send(1, p[2:0], lens[l], a, n);
      send(0, p[2:0], lens[l], a, n);
      n++;
    end
    // random traffic: word aligned, outside the PSLVERR region
    repeat (num_txns)
      send($urandom_range(1), $urandom_range(7), $urandom_range(16, 1),
           ($urandom & 32'h00FF_FFFC), n++, $urandom_range(3));
  endtask
endclass

// Random sequence (compatibility name)
class apb_random_sequence extends apb_base_sequence;
  `uvm_object_utils(apb_random_sequence)
  function new(string name = "apb_random_sequence");
    super.new(name);
    num_txns = 50;
  endfunction
endclass

// Regression: weighted mix of all directed sequences
class apb_regression_sequence extends apb_base_sequence;
  `uvm_object_utils(apb_regression_sequence)
  function new(string name = "apb_regression_sequence");
    super.new(name);
  endfunction
  task body();
    apb_write_seq        wr  = apb_write_seq::type_id::create("wr");
    apb_read_seq         rd  = apb_read_seq::type_id::create("rd");
    apb_back_to_back_seq b2b = apb_back_to_back_seq::type_id::create("b2b");
    apb_wait_state_seq   ws  = apb_wait_state_seq::type_id::create("ws");
    apb_error_inject_seq err = apb_error_inject_seq::type_id::create("err");
    apb_stress_seq       str = apb_stress_seq::type_id::create("str");
    apb_partial_write_seq pw = apb_partial_write_seq::type_id::create("pw");
    wr.num_txns = 20; rd.num_txns = 20; b2b.num_txns = 20;
    ws.num_txns = 10; err.num_txns = 5; str.num_txns = 40; pw.num_txns = 32;
    wr.start(m_sequencer);  rd.start(m_sequencer);
    b2b.start(m_sequencer); ws.start(m_sequencer);
    err.start(m_sequencer); str.start(m_sequencer);
    pw.start(m_sequencer);
  endtask
endclass
`endif
