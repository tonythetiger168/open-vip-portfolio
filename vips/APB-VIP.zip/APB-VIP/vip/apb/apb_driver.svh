// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// apb_driver.svh -- APB5 master driver: SETUP -> ACCESS state progression,
// PREADY wait-state handling, PSLVERR capture, PSTRB byte enables, PWAKEUP,
// PAUSER / PWUSER, odd-parity check signals with optional error injection.

`ifndef APB_DRIVER_SVH
`define APB_DRIVER_SVH

class apb_driver extends uvm_driver #(amba_seq_item);
  `uvm_component_utils(apb_driver)
  virtual amba_vip_if vif;
  uvm_analysis_port #(amba_seq_item) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "APB virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    amba_seq_item item;
    vif.drv_cb.psel    <= 1'b0;
    vif.drv_cb.penable <= 1'b0;
    vif.drv_cb.paddr   <= '0;
    vif.drv_cb.pwrite  <= 1'b0;
    vif.drv_cb.pwdata  <= '0;
    vif.drv_cb.pstrb   <= 4'h0;
    vif.drv_cb.pprot   <= 3'b000;
    vif.drv_cb.pwakeup <= 1'b0;
    vif.drv_cb.pauser  <= 8'h0;
    vif.drv_cb.pwuser  <= 8'h0;
    drive_chk(1'b0, 1'b0, 0);
    wait (vif.aresetn === 1'b1);
    forever begin
      seq_item_port.get_next_item(item);
      `uvm_info("DRV", {"drive: ", item.convert2string()}, UVM_HIGH)
      drive_xfer(item);
      drv_ap.write(item);           // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask

  function automatic logic [3:0] par4(logic [31:0] v);
    for (int b = 0; b < 4; b++) par4[b] = ~^v[b*8 +: 8];
  endfunction

  // odd-parity check signals of the request; inj flips one of them
  task drive_chk(bit sel, bit en, int unsigned inj, logic [31:0] a = 0, logic [2:0] p = 0,
                 bit wr = 0, logic [31:0] d = 0, logic [3:0] s = 0);
    vif.drv_cb.paddrchk   <= par4(a)        ^ ((inj == 1) ? 4'b0001 << (a[1:0] + a[3:2]) : 4'b0);
    vif.drv_cb.pctrlchk   <= ~^{p, wr}      ^ (inj == 2);
    vif.drv_cb.pselchk    <= ~sel           ^ (inj == 3);
    vif.drv_cb.penablechk <= ~en            ^ (inj == 4 && en);
    vif.drv_cb.pwdatachk  <= par4(d)        ^ ((inj == 5) ? 4'b1000 : 4'b0);
    vif.drv_cb.pstrbchk   <= ~^s            ^ (inj == 6);
  endtask

  // One APB transfer per data word (APB is single-beat); words of a burst
  // are issued back-to-back: PSEL stays high, and the next SETUP phase starts
  // on the edge that completes the previous ACCESS phase, so SETUP is always
  // one cycle (the checkers require PENABLE on the cycle after SETUP).
  // PWAKEUP rises t.wake_lead clocks before PSEL (with PSEL when 0), stays
  // high through the item and drops when the item ends.
  task drive_xfer(amba_seq_item item);
    amba_txn t = item.txn;
    logic [31:0] a, d;
    logic [3:0]  s;
    int unsigned inj;
    if (t.wuser.size() != t.len) t.wuser = new[t.len](t.wuser);
    t.ruser = new[t.len];
    repeat (t.delay) @(vif.drv_cb);
    t.resp = RESP_OKAY;
    t.n_wait = 0;
    @(vif.drv_cb);
    if (t.wake_lead > 0) begin
      vif.drv_cb.pwakeup <= 1'b1;
      repeat (t.wake_lead) @(vif.drv_cb);
    end
    for (int i = 0; i < t.len; i++) begin
      a   = t.addr + i * 4;
      d   = t.write ? t.data[i][31:0] : 32'h0;
      s   = t.write ? t.strb : 4'h0;
      inj = (t.par_inj && i == t.par_beat) ? t.par_inj : 0;
      // ---- SETUP phase ----
      vif.drv_cb.pwakeup <= 1'b1;
      vif.drv_cb.psel    <= 1'b1;
      vif.drv_cb.penable <= 1'b0;
      vif.drv_cb.paddr   <= a;
      vif.drv_cb.pwrite  <= t.write;
      vif.drv_cb.pprot   <= t.prot;
      vif.drv_cb.pstrb   <= s;
      vif.drv_cb.pauser  <= t.auser;
      vif.drv_cb.pwuser  <= t.write ? t.wuser[i] : 8'h0;
      vif.drv_cb.pwdata  <= d;
      drive_chk(1'b1, 1'b0, inj, a, t.prot, t.write, d, s);
      // ---- ACCESS phase ----
      @(vif.drv_cb);
      vif.drv_cb.penable <= 1'b1;
      drive_chk(1'b1, 1'b1, inj, a, t.prot, t.write, d, s);
      // wait for PREADY (wait states)
      @(vif.drv_cb);
      while (vif.drv_cb.pready !== 1'b1) begin t.n_wait++; @(vif.drv_cb); end
      if (vif.drv_cb.pslverr === 1'b1) t.resp = RESP_SLVERR;
      if (!t.write) begin
        t.data[i]  = {32'h0, vif.drv_cb.prdata};
        t.ruser[i] = vif.drv_cb.pruser;
      end
      t.buser = vif.drv_cb.pbuser;
      vif.drv_cb.penable <= 1'b0;    // SETUP of next word follows on this edge
    end
    // ---- IDLE at item end ----
    vif.drv_cb.psel    <= 1'b0;
    vif.drv_cb.pwakeup <= 1'b0;
    drive_chk(1'b0, 1'b0, 0);
  endtask
endclass
`endif
