# APB — APB5 UVM VIP

Open-source UVM verification IP for **AMBA APB5** (peripheral bus, APB4 compatible), sharing
the common `amba_vip_if` / `amba_vip_pkg` skeleton with the AHB and AXI VIPs.

## Protocol overview

APB4 is a two-cycle non-pipelined bus: a SETUP cycle (`PSEL=1, PENABLE=0`)
followed by ACCESS cycles (`PSEL=1, PENABLE=1`) that complete when the slave
drives `PREADY=1`. Slaves may insert wait states and signal errors with
`PSLVERR` (valid only when `PSEL & PENABLE & PREADY`). Writes use `PSTRB`
byte enables. APB5 adds `PWAKEUP` (the master raises it before or with
`PSEL` so a clock-gated completer can wake), user signals (`PAUSER`,
`PWUSER`, `PRUSER`, `PBUSER`) and interface parity: one odd-parity check
bit per byte of `PADDR` / `PWDATA` / `PRDATA` and one per control signal
(`PCTRLCHK`, `PSELCHK`, `PENABLECHK`, `PSTRBCHK`, `PREADYCHK`,
`PSLVERRCHK`).

## Architecture

| Path | Description |
|------|-------------|
| `rtl/amba_vip_if.sv` | AXI4+AHB5+APB4 interface, `drv_cb`/`mon_cb` clocking blocks, modports, inline SVA + covergroup |
| `vip/base/amba_vip_pkg.sv` | `amba_txn`/`amba_seq_item`, `amba_cov`, end-to-end `amba_sb` scoreboard; includes APB UVC + SVA checker |
| `vip/apb/apb_driver.svh` | APB5 master driver: SETUP→ACCESS progression, PREADY wait states, PSLVERR capture, PSTRB generation, back-to-back bursts, PWAKEUP lead (`wake_lead`), PAUSER / PWUSER, check signals with error injection (`par_inj` / `par_beat`) |
| `vip/apb/apb_monitor.svh` | APB5 monitor: decodes completed transfers, reassembles consecutive words into burst items, records user signals, wait states, PWAKEUP lead and whether the completer slept, reports request parity errors and flags response parity errors |
| `vip/apb/apb_agent.svh` / `apb_sequencer.svh` | Active agent (sequencer + driver + monitor) |
| `vip/apb/apb_sequences.svh` | Directed sequence library (see below) |
| `vip/apb/apb_coverage.svh` | Functional coverage (4 covergroups + crosses) |
| `vip/apb/apb_protocol_checker.sv` | Class-based protocol checker (properties + `cg_apb`) |
| `rtl/sva/apb_compliance_checker.sv` | Tiered SVA compliance checker (L1-L5) |
| `env/amba_env.sv` | Environment: agent, scoreboard, coverage, checkers, analysis connections |
| `tests/amba_tests.sv` | `amba_base_test` / `amba_axi_test` / `amba_ahb_test` / `amba_apb_test` / `amba_apb_err_test` / `amba_ral_test` / `amba_apb_strb_test` |
| `tb/top_tb.sv` | Testbench top + APB5 slave DUT: 64×32-bit register bank with PWUSER per register, 0-2 random wait states (2 in `0xF0-0xFF`), sleep after 8 idle clocks, PSLVERR for `0xEE??_????`, non-secure access to `0x80-0xBF` and request parity errors, response check signals |
| `tb/smoke_func_tb.sv` | Self-checking functional smoke (587 checks) against the flattened slave |
| `scripts/` | Makefile + coverage-driven regression (line/fsm/toggle/SVA, 100% goal) |

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `apb_base_sequence` | Random APB4 transactions |
| `apb_write_seq` | Directed write bursts |
| `apb_read_seq` | Directed read bursts (1–8 words) |
| `apb_back_to_back_seq` | Zero-gap back-to-back single transfers |
| `apb_wait_state_seq` | Accesses to wait-state region (`paddr[7:4]==4'hF`) |
| `apb_error_inject_seq` | PSLVERR error region (`0xEE??_????`) |
| `apb_reset_seq` | Transfer right after reset release |
| `apb_stress_seq` | 100 random bursts |
| `apb_partial_write_seq` | Single writes with random `PSTRB` (`4'h0`, every single lane, all 16 values first), each read back |
| `apb_cov_sweep_seq` | PPROT × direction × length in both wait regions, random traffic, then PWAKEUP lead / sleep, user signals, secure registers and every request parity error |
| `apb_regression_sequence` | Weighted mix of all directed sequences |

## SVA compliance (rtl/sva/apb_compliance_checker.sv)

- **L1 Basic (4)**: PSEL→PENABLE, PENABLE timing, PWRITE/PADDR stability
- **L2 Full protocol (2)**: PWDATA stable on write, PREADY response
- **L3 Advanced (4)**: IDLE or SETUP after a transfer, PWDATA known in ACCESS, PSTRB zero on reads, PREADY only in ACCESS
- **L4 APB4-specific (4)**: PENABLE requires PSEL, PSLVERR only at access completion, control stable during wait states, PENABLE deasserts after transfer
- **L5 APB5 (5)**: PWAKEUP high with PSEL, PAUSER / PWUSER stable in ACCESS, response check signals, request parity error answered with PSLVERR, PRUSER zero on writes and errors

## Functional coverage (vip/apb/apb_coverage.svh)

- `cg_protocol`: write × prot × resp, burst length bins + crosses
- `cg_fsm`: PSEL/PENABLE state + transition bins (idle→setup→access, back-to-back, wait states)
- `cg_data`: data pattern corners (all-0/all-1/0xAA…/0x55…) × write cross
- `cg_apb5`: PWAKEUP lead × completer asleep, PAUSER ranges, secure registers × PPROT[1] × direction, each parity check × direction, wait states × direction

## UVM RAL (register model)

- `env/amba_reg_model.sv` -- `amba_reg_block` modelling the `amba_dut` slave in
  `tb/top_tb.sv`: REG0..REG63 (0x00-0xFC, REG60-63 in the 2-wait-state region), all RW with reset 0, plus `ERR_PROBE` at
  0xEE000000 (error region, excluded from the built-in sequences). Map: apb_map (4 bytes).
- `vip/base/amba_reg_adapter.svh` -- `amba_reg_adapter` (single-beat APB4
  `amba_seq_item`; `protocol` / `bus_bytes` set by the env).
- `amba_env` builds the model, sets the adapter on the agent sequencer and
  keeps the mirror with a `uvm_reg_predictor` fed by the monitor
  (explicit prediction).
- `amba_ral_test` -- `uvm_reg_hw_reset_seq`, `uvm_reg_bit_bash_seq`,
  random write + `mirror(UVM_CHECK)`, and the error response returning `UVM_NOT_OK`.
  Runs on Verilator: `python3 tools/run_uvm_tests.py APB-VIP` from the
  portfolio repo (see docs/RAL.md there).

## Byte strobes and the register model scoreboard

`amba_txn.strb` is the write's `PSTRB`. It is `4'hF` unless a sequence clears
`full_strb` before `randomize()` (`apb_partial_write_seq` does), so the RAL
adapter and the older sequences still write whole words. `amba_sb` checks the
strobes of every write against the bus, and with `model_regbank` set (the env
does) it keeps a model of the `tb/top_tb.sv` register bank (64 registers at
`PADDR[7:2]`, reset 0, byte lanes under `PSTRB`, no write on `PSLVERR`) and
checks every read against it. It also predicts PSLVERR (error region, secure
registers, request parity errors), the PRUSER of every read (the PWUSER last
written to the register) and PBUSER (PAUSER[3:0]). `amba_apb_strb_test` runs 200 partial writes
with read-back and prints `SB_PASS checks=<n>`; a DUT that ignores one
`PSTRB` bit fails it.

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
TEST=amba_apb_test make all
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

## Deepened Features (v1.8.0)

- **PWAKEUP and low power**: the completer sleeps after 8 idle clocks with PWAKEUP low and needs 2 clocks of PWAKEUP to wake; the driver raises PWAKEUP 0-3 clocks before PSEL
- **User signals**: PAUSER, PWUSER stored per register and returned on PRUSER, PBUSER
- **Interface parity**: every APB5 check signal driven and checked, with injection of a wrong check bit on any transfer of a burst
- **Protection**: non-secure access to the secure registers answered with PSLVERR, no write, zero read data
- **Random wait states** in the normal register region

## Deepened Features (v1.6.0)

- **APB4 master driver**: SETUP/ACCESS state machine, PREADY wait-state handling, PSLVERR capture, back-to-back word bursts
- **Transfer-decoding monitor**: reassembles consecutive completed transfers into burst transactions on an analysis port
- **End-to-end scoreboard**: driver-issued (expected) vs monitor-decoded (observed) compare with `n_matches`/`n_mismatches` and `UVM_ERROR` on mismatch
- **Functional DUT model**: APB4 slave register bank with wait-state region, PSLVERR region and PSTRB byte-enable masking
- **Directed sequence library**: 9 sequences (write / read / back-to-back / wait-state / error / reset / stress / regression)
- **SVA L4**: 4 APB4-specific rules
- **Functional coverage**: 3 covergroups with cross coverage

License: Apache-2.0
