// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_env.sv -- eSPI environment: reference-model scoreboard, checker, coverage

package espi_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import espi_defs_pkg::*;
  import espi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class espi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(espi_scoreboard)
    uvm_analysis_imp_exp #(espi_transaction, espi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(espi_transaction, espi_scoreboard) obs_ap;

    espi_config cfg;
    espi_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [7:0] io [16];
    bit [7:0] mem [64];
    bit [31:0] gen = 32'h0000_000F;
    bit pc_en = 1;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(espi_config)::get(this, "", "cfg", cfg))
        cfg = espi_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(espi_transaction t);
      // independent embedded-controller model: windows, registers, response codes
      int cl = espi_cls(t.opcode), n = espi_n(t.opcode);
      bit [31:0] w = 0, v = 0;
      foreach (t.wdata[i]) if (i < 4) w[8*i +: 8] = t.wdata[i];
      t.rdata.delete(); t.status = 0; t.rcrc_ok = 0; t.rcode = 8'hFF;
      if (cl != 7 && !t.bad_crc) begin
        t.rcode = 8'h08; t.status = ESPI_STATUS; t.rcrc_ok = 1;
        if ((cl == 3 || cl == 4) && (!pc_en || t.addr[15:4] != 12'h006 || int'(t.addr[3:0]) + n > 16)) t.rcode = 8'h02;
        if ((cl == 5 || cl == 6) && (!pc_en || t.addr[31:6] != 26'h3F8_2C00 || int'(t.addr[5:0]) + n > 64)) t.rcode = 8'h02;
        if (t.rcode == 8'h08) case (cl)
          1: begin
            case (t.addr[11:0])
              12'h004: v = 32'h0000_0001;
              12'h008: v = gen;
              12'h010: v = {30'h0, 1'b1, pc_en};
              default: v = 0;
            endcase
            for (int i = 0; i < 4; i++) t.rdata.push_back(v[8*i +: 8]);
          end
          2: begin
            if (t.addr[11:0] == 12'h008) gen[31:16] = w[31:16];
            if (t.addr[11:0] == 12'h010) pc_en = w[0];
          end
          3: for (int i = 0; i < n; i++) t.rdata.push_back(io[int'(t.addr[3:0]) + i]);
          4: for (int i = 0; i < n; i++) io[int'(t.addr[3:0]) + i] = t.wdata[i];
          5: for (int i = 0; i < n; i++) t.rdata.push_back(mem[int'(t.addr[5:0]) + i]);
          6: for (int i = 0; i < n; i++) mem[int'(t.addr[5:0]) + i] = t.wdata[i];
          default: ;
        endcase
      end
    endfunction

    function void write_exp(espi_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(espi_transaction t);
      espi_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        espi_transaction e = exp_q.pop_front();
        espi_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("espi scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class espi_env extends uvm_env;
    `uvm_component_utils(espi_env)
    espi_agent      agt;
    espi_scoreboard sb;
    espi_checker    chk;
    espi_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = espi_agent     ::type_id::create("agt", this);
      sb  = espi_scoreboard::type_id::create("sb",  this);
      chk = espi_checker   ::type_id::create("chk", this);
      cov = espi_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
