// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_if.sv -- eSPI interface

interface espi_if (input logic clk);
  logic rst_n;

  logic cs_n;
  logic sclk;
  logic mosi;
  logic miso;
  logic miso_oe;

  modport DUT (input clk, rst_n, input cs_n, input sclk, input mosi, output miso, output miso_oe);
  modport MON (input clk, rst_n, cs_n, sclk, mosi, miso, miso_oe);

  clocking drv_cb @(posedge clk);
    input rst_n, miso, miso_oe;
    inout cs_n, sclk, mosi;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, cs_n, sclk, mosi, miso, miso_oe;
  endclocking
endinterface
