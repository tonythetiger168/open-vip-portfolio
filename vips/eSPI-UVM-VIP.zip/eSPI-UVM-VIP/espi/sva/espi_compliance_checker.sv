// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_compliance_checker.sv -- eSPI concurrent assertion checks (bindable)

module espi_compliance_checker
  (input logic clk, input logic rst_n, input logic cs_n, input logic sclk, input logic mosi, input logic miso, input logic miso_oe);

  logic sclk_d, cs_d;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin sclk_d <= 1'b0; cs_d <= 1'b1; end else begin sclk_d <= sclk; cs_d <= cs_n; end
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({cs_n, miso, miso_oe}))
    else $error("eSPI: X on CS# / MISO");
  // the target only drives MISO while selected
  assert property (@(posedge clk) disable iff (!rst_n) cs_n && cs_d |-> !miso_oe)
    else $error("eSPI: target drives MISO while CS# is high");
  // MISO changes only after a SCLK falling edge (or when released at CS# rise)
  assert property (@(posedge clk) disable iff (!rst_n) $changed(miso) |-> $past(cs_n) || ($past(!sclk) && $past(sclk_d)))
    else $error("eSPI: MISO changed outside a SCLK low phase");
  // a released MISO reads high
  assert property (@(posedge clk) disable iff (!rst_n) !miso_oe |-> miso)
    else $error("eSPI: MISO low while released");
  cover property (@(posedge clk) disable iff (!rst_n) $rose(miso_oe));
  cover property (@(posedge clk) disable iff (!rst_n) $rose(cs_n) && !$past(miso_oe, 2));
endmodule
