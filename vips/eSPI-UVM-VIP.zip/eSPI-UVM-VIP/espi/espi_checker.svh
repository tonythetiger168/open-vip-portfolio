// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_checker.svh -- eSPI protocol checker on monitored items

class espi_checker extends uvm_component;
  `uvm_component_utils(espi_checker)
  uvm_analysis_imp #(espi_transaction, espi_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  espi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(espi_config)::get(this, "", "cfg", cfg))
      cfg = espi_config::type_id::create("cfg");
  endfunction

  function void fail(espi_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("eSPI: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(espi_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (!(t.rcode inside {8'h08, 8'h02, 8'hFF})) fail(t, $sformatf("response code 0x%02h", t.rcode));
      if (t.rcode != 8'hFF && !t.rcrc_ok) fail(t, "response CRC");
      if (t.rcode != 8'hFF && t.bad_crc) fail(t, "target answered a command with a CRC error");
      if (t.rcode == 8'h08 && t.rdata.size() != espi_rdata_len(t.opcode)) fail(t, "ACCEPT with the wrong amount of data");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("eSPI checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
