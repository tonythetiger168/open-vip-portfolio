// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_monitor.svh -- eSPI monitor: transactions between CS# fall and rise: command bytes from MOSI, two turn-around cycles, response bytes from MISO, all on SCLK rising edges

class espi_monitor extends uvm_monitor;
  `uvm_component_utils(espi_monitor)

  virtual espi_if vif;
  uvm_analysis_port #(espi_transaction) ap;
  espi_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual espi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "espi: virtual interface not set")
    if (!uvm_config_db#(espi_config)::get(this, "", "cfg", cfg))
      cfg = espi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] b[$], r[$];
      bit [7:0] sh = 0;
      int unsigned nbit = 0, len = 0;
      bit sclk_p = 0, cs_p = 1;
      forever begin
        @(vif.mon_cb);
        if (!vif.mon_cb.cs_n && cs_p) begin b.delete(); r.delete(); nbit = 0; len = 1; end
        if (!vif.mon_cb.cs_n && vif.mon_cb.sclk && !sclk_p) begin
          // bits 0 .. 8*len-1 command, then two turn-around cycles, then response
          if (nbit < 8 * len) sh = {sh[6:0], vif.mon_cb.mosi};
          else if (nbit >= 8 * len + 2) sh = {sh[6:0], vif.mon_cb.miso};
          nbit++;
          if (nbit <= 8 * len && nbit % 8 == 0) begin
            b.push_back(sh);
            if (nbit == 8) len = espi_cmd_len(sh);
          end else if (nbit > 8 * len + 2 && (nbit - 8 * len - 2) % 8 == 0) r.push_back(sh);
        end
        if (vif.mon_cb.cs_n && !cs_p) begin
          if (b.size() != len || b.size() < 2)
            `uvm_error("MON", $sformatf("eSPI: transaction cut short (%0d of %0d command bytes)", b.size(), len))
          else begin
            espi_transaction t = espi_transaction::type_id::create("t");
            t.from_cmd(b);
            t.from_rsp(r);
            publish(t);
          end
        end
        sclk_p = vif.mon_cb.sclk; cs_p = vif.mon_cb.cs_n;
      end
    end
  endtask

  function void publish(espi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
