// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_pkg.sv -- eSPI UVM VIP package

package espi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import espi_defs_pkg::*;
  export espi_defs_pkg::*;

  `include "espi_transaction.svh"
  `include "espi_config.svh"
  `include "espi_sequencer.svh"
  `include "espi_driver.svh"
  `include "espi_monitor.svh"
  `include "espi_agent.svh"
  `include "espi_sequences.svh"
  `include "espi_checker.svh"
  `include "espi_coverage.svh"
endpackage
