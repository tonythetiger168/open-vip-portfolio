// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_sequences.svh -- eSPI sequences

// Random traffic: cfg.num_items constrained-random items.
class espi_base_sequence extends uvm_sequence #(espi_transaction);
  `uvm_object_utils(espi_base_sequence)
  espi_config cfg;

  function new(string name = "espi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = espi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "espi_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class espi_directed_sequence extends uvm_sequence #(espi_transaction);
  `uvm_object_utils(espi_directed_sequence)
  espi_config cfg;

  function new(string name = "espi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function espi_transaction item();
    item = espi_transaction::type_id::create("req");
  endfunction

  task send(espi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    espi_transaction t;
    // status and the configuration registers (read-only, partly writable, unimplemented)
    t = item(); t.opcode = 8'h25; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h004; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h008; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h010; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h020; send(t);
    t = item(); t.opcode = 8'h22; t.addr = 32'h008; t.wdata = '{8'h5A, 8'h5A, 8'hA5, 8'hA5}; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h008; send(t);
    t = item(); t.opcode = 8'h22; t.addr = 32'h004; t.wdata = '{8'hFF, 8'hFF, 8'hFF, 8'hFF}; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h004; send(t);
    // I/O cycles of every length, the window edges, outside the window
    t = item(); t.opcode = 8'h47; t.addr = 32'h60; t.wdata = '{8'h11, 8'h22, 8'h33, 8'h44}; send(t);
    t = item(); t.opcode = 8'h43; t.addr = 32'h60; send(t);
    t = item(); t.opcode = 8'h40; t.addr = 32'h63; send(t);
    t = item(); t.opcode = 8'h45; t.addr = 32'h6E; t.wdata = '{8'hAA, 8'hBB}; send(t);
    t = item(); t.opcode = 8'h41; t.addr = 32'h6E; send(t);
    t = item(); t.opcode = 8'h43; t.addr = 32'h6E; send(t);
    t = item(); t.opcode = 8'h44; t.addr = 32'h80; t.wdata = '{8'h01}; send(t);
    t = item(); t.opcode = 8'h44; t.addr = 32'h5F; t.wdata = '{8'h01}; send(t);
    // memory cycles
    t = item(); t.opcode = 8'h4F; t.addr = 32'hFE0B_0000; t.wdata = '{8'hDE, 8'hAD, 8'hBE, 8'hEF}; send(t);
    t = item(); t.opcode = 8'h4B; t.addr = 32'hFE0B_0000; send(t);
    t = item(); t.opcode = 8'h4D; t.addr = 32'hFE0B_003E; t.wdata = '{8'h12, 8'h34}; send(t);
    t = item(); t.opcode = 8'h49; t.addr = 32'hFE0B_003E; send(t);
    t = item(); t.opcode = 8'h4B; t.addr = 32'hFE0B_003E; send(t);
    t = item(); t.opcode = 8'h48; t.addr = 32'hFE0C_0000; send(t);
    // command CRC error and unsupported opcodes: no response, no side effect
    t = item(); t.opcode = 8'h44; t.addr = 32'h60; t.wdata = '{8'h99}; t.bad_crc = 1; send(t);
    t = item(); t.opcode = 8'h40; t.addr = 32'h60; send(t);
    t = item(); t.opcode = 8'h42; t.addr = 32'h60; send(t);
    t = item(); t.opcode = 8'h25; t.bad_crc = 1; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h008; t.bad_crc = 1; send(t);
    t = item(); t.opcode = 8'h22; t.addr = 32'h008; t.wdata = '{8'h00, 8'h00, 8'h00, 8'h00}; t.bad_crc = 1; send(t);
    t = item(); t.opcode = 8'h43; t.addr = 32'h64; t.bad_crc = 1; send(t);
    t = item(); t.opcode = 8'h4B; t.addr = 32'hFE0B_0010; t.bad_crc = 1; send(t);
    t = item(); t.opcode = 8'h4F; t.addr = 32'hFE0B_0010; t.wdata = '{8'h01, 8'h02, 8'h03, 8'h04}; t.bad_crc = 1; send(t);
    t = item(); t.opcode = 8'h4D; t.addr = 32'hFE0B_0040; t.wdata = '{8'h01, 8'h02}; send(t);
    t = item(); t.opcode = 8'h30; t.addr = 32'h60; send(t);
    // peripheral channel disabled, then enabled again
    t = item(); t.opcode = 8'h22; t.addr = 32'h010; t.wdata = '{8'h00, 8'h00, 8'h00, 8'h00}; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h010; send(t);
    t = item(); t.opcode = 8'h40; t.addr = 32'h60; send(t);
    t = item(); t.opcode = 8'h4C; t.addr = 32'hFE0B_0000; t.wdata = '{8'h00}; send(t);
    t = item(); t.opcode = 8'h22; t.addr = 32'h010; t.wdata = '{8'hFF, 8'hFF, 8'hFF, 8'hFF}; send(t);
    t = item(); t.opcode = 8'h40; t.addr = 32'h60; send(t);
  endtask
endclass
