// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_transaction.svh -- eSPI transaction

class espi_transaction extends uvm_sequence_item;
  `uvm_object_utils(espi_transaction)

  // request (driven by the agent)
  rand bit [7:0] opcode;
  rand bit [31:0] addr;
  bit [7:0] wdata[$];
  rand bit bad_crc;
  // response (returned by the DUT)
  bit [7:0] rcode;
  bit [7:0] rdata[$];
  bit [15:0] status;
  bit rcrc_ok;
  // bookkeeping (not compared)
  rand bit [31:0] seed;
  rand bit [1:0] where;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_op   { opcode dist { 8'h25 := 2, 8'h21 := 3, 8'h22 := 2,
                                    8'h40 := 3, 8'h41 := 3, 8'h43 := 3, 8'h44 := 3, 8'h45 := 3, 8'h47 := 3,
                                    8'h48 := 3, 8'h49 := 3, 8'h4B := 3, 8'h4C := 3, 8'h4D := 3, 8'h4F := 3,
                                    8'h42 := 1, 8'h30 := 1 }; }
  constraint c_crc  { bad_crc dist { 0 := 24, 1 := 1 }; }
  constraint c_where { where dist { 0 := 12, 1 := 1, 2 := 1 }; }
  constraint c_addr {
    (opcode == 8'h25) -> addr == 0;
    (opcode inside {8'h21, 8'h22}) -> addr inside {32'h004, 32'h008, 32'h010, 32'h020};
    (opcode inside {[8'h40:8'h47], 8'h30}) -> addr[31:16] == 0;
    (opcode inside {[8'h40:8'h47], 8'h30} && where == 0) -> addr[15:4] == 12'h006;
    (opcode inside {[8'h40:8'h47], 8'h30} && where == 1) -> addr[15:4] == 12'h005;
    (opcode inside {[8'h40:8'h47], 8'h30} && where == 2) -> addr[15:4] == 12'h007;
    (opcode inside {[8'h48:8'h4F]} && where == 0) -> addr[31:6] == 26'h3F8_2C00;
    (opcode inside {[8'h48:8'h4F]} && where == 1) -> addr[31:4] == 28'hFE0_AFFF;
    (opcode inside {[8'h48:8'h4F]} && where == 2) -> addr[31:4] == 28'hFE0_B004;
  }

  function new(string name = "espi_transaction"); super.new(name); endfunction

  function int cls(); return espi_cls(opcode); endfunction

  // write data from the seed; a SET_CONFIGURATION of the channel register
  // mostly keeps the channel enabled
  function void post_randomize();
    bit [31:0] x = seed | 1;
    wdata.delete();
    for (int i = 0; i < espi_wdata_len(opcode); i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      wdata.push_back(x[7:0]);
    end
    if (opcode == 8'h22 && addr == 32'h010) wdata[0][0] = (x[9:8] != 2'd0);
  endfunction

  // command fields from the controller's bytes (CRC included)
  function void from_cmd(bit [7:0] b[$]);
    bit [7:0] c = 0;
    int na, nw;
    opcode = b[0]; na = espi_addr_len(opcode); nw = espi_wdata_len(opcode);
    addr = 0; wdata.delete();
    for (int k = 1; k <= na; k++) addr = {addr[23:0], b[k]};
    for (int k = 0; k < nw; k++) wdata.push_back(b[1 + na + k]);
    for (int k = 0; k + 1 < b.size(); k++) c = espi_crc8(c, b[k]);
    bad_crc = (b[b.size() - 1] != c);
  endfunction

  // response fields from the bytes clocked back (0xFF where nobody drove)
  function void from_rsp(bit [7:0] r[$]);
    bit [7:0] c = 0;
    int nd;
    rcode = (r.size() != 0) ? r[0] : 8'hFF;
    rdata.delete(); status = 0; rcrc_ok = 0;
    nd = (rcode == 8'h08) ? espi_rdata_len(opcode) : (rcode == 8'h02) ? 0 : -1;
    if (nd >= 0 && r.size() >= nd + 4) begin
      for (int i = 0; i < nd; i++) rdata.push_back(r[1 + i]);
      status = {r[nd + 2], r[nd + 1]};
      for (int i = 0; i < nd + 3; i++) c = espi_crc8(c, r[i]);
      rcrc_ok = (r[nd + 3] == c);
    end
  endfunction

  function void do_copy(uvm_object rhs);
    espi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    opcode = rhs_.opcode;
    addr = rhs_.addr;
    wdata = rhs_.wdata;
    bad_crc = rhs_.bad_crc;
    rcode = rhs_.rcode;
    rdata = rhs_.rdata;
    status = rhs_.status;
    rcrc_ok = rhs_.rcrc_ok;
    seed = rhs_.seed;
    where = rhs_.where;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    espi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (opcode != rhs_.opcode) return 0;
    if (addr != rhs_.addr) return 0;
    if (wdata.size() != rhs_.wdata.size()) return 0;
    foreach (wdata[i]) if (wdata[i] != rhs_.wdata[i]) return 0;
    if (bad_crc != rhs_.bad_crc) return 0;
    if (rcode != rhs_.rcode) return 0;
    if (rdata.size() != rhs_.rdata.size()) return 0;
    foreach (rdata[i]) if (rdata[i] != rhs_.rdata[i]) return 0;
    if (status != rhs_.status) return 0;
    if (rcrc_ok != rhs_.rcrc_ok) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(espi_transaction rhs_);
    if (opcode != rhs_.opcode) return 0;
    if (addr != rhs_.addr) return 0;
    if (wdata.size() != rhs_.wdata.size()) return 0;
    foreach (wdata[i]) if (wdata[i] != rhs_.wdata[i]) return 0;
    if (bad_crc != rhs_.bad_crc) return 0;
    return 1;
  endfunction

  function string qstr_wdata();
    string s = $sformatf("[%0d]{", wdata.size());
    foreach (wdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", wdata[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rdata();
    string s = $sformatf("[%0d]{", rdata.size());
    foreach (rdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rdata[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("eSPI{tag=%0d opcode=0x%0h addr=0x%0h wdata=%s bad_crc=0x%0h rcode=0x%0h rdata=%s status=0x%0h rcrc_ok=0x%0h}", tag, opcode, addr, qstr_wdata(), bad_crc, rcode, qstr_rdata(), status, rcrc_ok);
  endfunction
endclass
