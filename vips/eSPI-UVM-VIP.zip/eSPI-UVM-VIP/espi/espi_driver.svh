// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_driver.svh -- eSPI driver: one eSPI transaction per item: command bytes and CRC on MOSI, two turn-around cycles, the response clocked back from MISO

class espi_driver extends uvm_driver #(espi_transaction);
  `uvm_component_utils(espi_driver)

  uvm_analysis_port #(espi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual espi_if vif;
  espi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual espi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "espi: virtual interface not set")
    if (!uvm_config_db#(espi_config)::get(this, "", "cfg", cfg))
      cfg = espi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    espi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.cs_n <= 1'b1;
    vif.drv_cb.sclk <= 1'b0;
    vif.drv_cb.mosi <= 1'b1;
  endtask

  task drive_item(espi_transaction t);
    bit [7:0] b[$], r[$];
    bit [7:0] c = 0;
    bit in;
    b.push_back(t.opcode);
    for (int i = espi_addr_len(t.opcode) - 1; i >= 0; i--) b.push_back(t.addr[8*i +: 8]);
    foreach (t.wdata[i]) b.push_back(t.wdata[i]);
    foreach (b[i]) c = espi_crc8(c, b[i]);
    b.push_back(c ^ {7'h0, t.bad_crc});
    @(vif.drv_cb);
    vif.drv_cb.cs_n <= 1'b0; vif.drv_cb.sclk <= 1'b0; vif.drv_cb.mosi <= 1'b1;
    repeat (cfg.half) @(vif.drv_cb);
    foreach (b[i]) for (int k = 7; k >= 0; k--) cyc(b[i][k], in);
    repeat (2) cyc(1'b1, in);                                 // turn-around
    for (int i = 0; i < espi_rsp_len(t.opcode); i++) begin
      bit [7:0] x;
      for (int k = 7; k >= 0; k--) begin cyc(1'b1, in); x[k] = in; end
      r.push_back(x);
    end
    vif.drv_cb.sclk <= 1'b0;
    repeat (cfg.half) @(vif.drv_cb);
    vif.drv_cb.cs_n <= 1'b1;
    repeat (2 * cfg.half) @(vif.drv_cb);
    t.from_rsp(r);
  endtask

  // one SCLK cycle: MOSI changes with SCLK low, MISO taken as SCLK rises
  task cyc(bit o, output bit i);
    vif.drv_cb.sclk <= 1'b0; vif.drv_cb.mosi <= o;
    repeat (cfg.half) @(vif.drv_cb);
    i = vif.drv_cb.miso;
    vif.drv_cb.sclk <= 1'b1;
    repeat (cfg.half) @(vif.drv_cb);
  endtask
endclass
