// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_defs.sv -- eSPI shared type definitions

package espi_defs_pkg;

  typedef enum bit [1:0] {ESPI_OK, ESPI_ERR} espi_status_e;

  // eSPI CRC-8: x^8 + x^2 + x + 1, init 0, MSB first
  function automatic bit [7:0] espi_crc8(bit [7:0] c, bit [7:0] b);
    c ^= b;
    for (int k = 0; k < 8; k++) c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
    return c;
  endfunction
  localparam bit [15:0] ESPI_STATUS = 16'h030F;
  // 0 GET_STATUS, 1 GET_CONFIGURATION, 2 SET_CONFIGURATION, 3 I/O read,
  // 4 I/O write, 5 memory read, 6 memory write, 7 not supported
  function automatic int espi_cls(bit [7:0] op);
    case (op)
      8'h25: return 0;
      8'h21: return 1;
      8'h22: return 2;
      8'h40, 8'h41, 8'h43: return 3;
      8'h44, 8'h45, 8'h47: return 4;
      8'h48, 8'h49, 8'h4B: return 5;
      8'h4C, 8'h4D, 8'h4F: return 6;
      default: return 7;
    endcase
  endfunction
  function automatic int espi_n(bit [7:0] op); return (op[1:0] == 2'd3) ? 4 : op[1:0] + 1; endfunction
  function automatic int espi_addr_len(bit [7:0] op);
    int c = espi_cls(op);
    return (c == 0) ? 0 : (c == 5 || c == 6) ? 4 : 2;
  endfunction
  function automatic int espi_wdata_len(bit [7:0] op);
    int c = espi_cls(op);
    return (c == 2) ? 4 : (c == 4 || c == 6) ? espi_n(op) : 0;
  endfunction
  function automatic int espi_rdata_len(bit [7:0] op);
    int c = espi_cls(op);
    return (c == 1) ? 4 : (c == 3 || c == 5) ? espi_n(op) : 0;
  endfunction
  // bytes the controller sends (with the CRC) and clocks back (an ACCEPT)
  function automatic int espi_cmd_len(bit [7:0] op); return 2 + espi_addr_len(op) + espi_wdata_len(op); endfunction
  function automatic int espi_rsp_len(bit [7:0] op); return 4 + espi_rdata_len(op); endfunction

endpackage
