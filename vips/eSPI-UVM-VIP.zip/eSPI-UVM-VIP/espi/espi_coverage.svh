// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// espi_coverage.svh -- eSPI functional coverage

class espi_coverage extends uvm_subscriber #(espi_transaction);
  `uvm_component_utils(espi_coverage)
  espi_config cfg;
  espi_transaction tr;

  covergroup espi_cg;
    cp_cls  : coverpoint tr.cls() { bins status = {0}; bins get_cfg = {1}; bins set_cfg = {2}; bins iord = {3};
                                    bins iowr = {4}; bins memrd = {5}; bins memwr = {6}; bins unsupported = {7}; }
    cp_n    : coverpoint espi_n(tr.opcode) { bins one = {1}; bins two = {2}; bins four = {4}; }
    cp_code : coverpoint tr.rcode { bins accept = {8'h08}; bins non_fatal = {8'h02}; bins none = {8'hFF}; }
    cp_crc  : coverpoint tr.bad_crc;
    x_cls_code : cross cp_cls, cp_code {
      ignore_bins cfg_nf = (binsof(cp_cls.status) || binsof(cp_cls.get_cfg) || binsof(cp_cls.set_cfg)) && binsof(cp_code.non_fatal);
      ignore_bins unsup = binsof(cp_cls.unsupported) && !binsof(cp_code.none);
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    espi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(espi_config)::get(this, "", "cfg", cfg))
      cfg = espi_config::type_id::create("cfg");
  endfunction

  function void write(espi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    espi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("eSPI coverage: %0.1f%%", espi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
