// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (eSPI DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened espi_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic cs_n = 1, sclk = 0, mosi = 1;
  wire miso, miso_oe;

  always #5 clk = ~clk;

  espi_model u_dut (.clk(clk), .rst_n(rst_n), .cs_n(cs_n), .sclk(sclk), .mosi(mosi), .miso(miso), .miso_oe(miso_oe));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic bit [7:0] crc8(bit [7:0] c, bit [7:0] b);
    c ^= b;
    for (int k = 0; k < 8; k++) c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
    return c;
  endfunction

  // bus rules watched all the time
  int oe_hi = 0, miso_chg = 0, oe_cnt = 0;
  logic sclk_q = 1'b0, miso_q = 1'b1, cs_q = 1'b1;
  always @(posedge clk) begin
    if (rst_n && cs_n && cs_q && miso_oe) oe_hi++;
    if (rst_n && sclk && sclk_q && miso !== miso_q) miso_chg++;
    if (miso_oe) oe_cnt++;
    sclk_q <= sclk; miso_q <= miso; cs_q <= cs_n;
  end

  task automatic w(input int n); repeat (n) @(posedge clk); #1; endtask
  task automatic cyc(input logic o, output logic i);
    sclk = 0; mosi = o; w(2); i = miso; sclk = 1; w(2);
  endtask

  // pk: command bytes (the CRC is appended); rr: nr response bytes clocked back
  bit [7:0] pk[$], rr[$];
  logic tar_oe;
  task automatic xfer(input int nr, input bit bad = 0, input int cut = -1);
    bit [7:0] c, x;
    logic b;
    int nbt;
    c = 0; nbt = 0; x = 0;
    rr.delete();
    foreach (pk[i]) c = crc8(c, pk[i]);
    pk.push_back(c ^ {7'h0, bad});
    cs_n = 0; w(2);
    foreach (pk[i]) begin
      x = pk[i];
      for (int k = 7; k >= 0; k--)
        if (cut < 0 || nbt < cut) begin cyc(x[k], b); nbt++; end
    end
    tar_oe = 0;
    if (cut < 0) begin
      cyc(1, b); tar_oe = tar_oe | miso_oe;
      cyc(1, b); tar_oe = tar_oe | miso_oe;
      for (int i = 0; i < nr; i++) begin
        for (int k = 7; k >= 0; k--) begin cyc(1, b); x[k] = b; end
        rr.push_back(x);
      end
    end
    sclk = 0; w(2); cs_n = 1; w(4);
    pk.delete();
  endtask

  // response: code, nd data bytes, status 0x030F LSB first, CRC, then 0xFF
  task automatic chk_rsp(input bit [7:0] code, input int nd, input string msg);
    bit [7:0] c;
    bit ok;
    c = 0;
    ok = (rr.size() >= nd + 4) && rr[0] == code && rr[nd + 1] == 8'h0F && rr[nd + 2] == 8'h03;
    for (int i = 0; i < nd + 3; i++) c = crc8(c, rr[i]);
    ok = ok && rr[nd + 3] == c;
    for (int i = nd + 4; i < rr.size(); i++) ok = ok && rr[i] == 8'hFF;
    chk(ok && tar_oe === 1'b0, msg);
  endtask
  task automatic chk_none(input string msg);
    bit ok;
    ok = 1;
    foreach (rr[i]) ok = ok && rr[i] == 8'hFF;
    chk(ok, msg);
  endtask

  task automatic get_cfg(input bit [11:0] a);
    pk.push_back(8'h21); pk.push_back({4'h0, a[11:8]}); pk.push_back(a[7:0]); xfer(8);
  endtask
  task automatic set_cfg(input bit [11:0] a, input bit [31:0] v, input bit bad = 0);
    pk.push_back(8'h22); pk.push_back({4'h0, a[11:8]}); pk.push_back(a[7:0]);
    pk.push_back(v[7:0]); pk.push_back(v[15:8]); pk.push_back(v[23:16]); pk.push_back(v[31:24]);
    xfer(4, bad);
  endtask
  task automatic io(input bit [7:0] op, input bit [15:0] a, input bit [31:0] d, input bit bad = 0);
    int n;
    n = (op[1:0] == 2'd3) ? 4 : op[1:0] + 1;
    pk.push_back(op); pk.push_back(a[15:8]); pk.push_back(a[7:0]);
    if (op[2]) for (int i = 0; i < n; i++) pk.push_back(d[8*i +: 8]);
    xfer(op[2] ? 4 : 4 + n, bad);
  endtask
  task automatic memop(input bit [7:0] op, input bit [31:0] a, input bit [31:0] d);
    int n;
    n = (op[1:0] == 2'd3) ? 4 : op[1:0] + 1;
    pk.push_back(op); pk.push_back(a[31:24]); pk.push_back(a[23:16]); pk.push_back(a[15:8]); pk.push_back(a[7:0]);
    if (op[2]) for (int i = 0; i < n; i++) pk.push_back(d[8*i +: 8]);
    xfer(op[2] ? 4 : 4 + n);
  endtask
  function automatic bit [31:0] rd32();
    rd32 = {rr[4], rr[3], rr[2], rr[1]};
  endfunction

  initial begin
    int oe0;
    repeat (3) @(posedge clk);
    chk(miso === 1'b1 && miso_oe === 1'b0, "MISO released during reset");
    rst_n = 1;
    w(3);

    pk.push_back(8'h25); xfer(4);
    chk_rsp(8'h08, 0, "GET_STATUS: ACCEPT, status 0x030F, CRC");

    // configuration registers
    get_cfg(12'h004); chk_rsp(8'h08, 4, "GET_CONFIGURATION: ACCEPT with 4 data bytes");
    chk(rd32() == 32'h0000_0001, $sformatf("device ID 0x00000001 (%h)", rd32()));
    get_cfg(12'h008); chk(rd32() == 32'h0000_000F, "general capabilities 0x0000000F after reset");
    get_cfg(12'h010); chk(rd32() == 32'h0000_0003, "peripheral channel enabled and ready after reset");
    get_cfg(12'h020); chk(rd32() == 32'h0, "unimplemented register reads 0");
    set_cfg(12'h008, 32'hA5A5_5A5A); chk_rsp(8'h08, 0, "SET_CONFIGURATION: ACCEPT, no data");
    get_cfg(12'h008); chk(rd32() == 32'hA5A5_000F, $sformatf("only bits 31:16 of 0x08 written (%h)", rd32()));
    set_cfg(12'h008, 32'h1234_0000, 1); chk_none("SET_CONFIGURATION with a CRC error: no response");
    get_cfg(12'h008); chk(rd32() == 32'hA5A5_000F, "and no write");
    set_cfg(12'h004, 32'hFFFF_FFFF); get_cfg(12'h004);
    chk(rd32() == 32'h0000_0001, "device ID is read-only");
    set_cfg(12'h020, 32'hFFFF_FFFF); get_cfg(12'h020);
    chk(rd32() == 32'h0, "unimplemented register ignores writes");

    // peripheral channel disabled: short cycles get NON_FATAL_ERROR
    set_cfg(12'h010, 32'hFFFF_FFFE); get_cfg(12'h010);
    chk(rd32() == 32'h0000_0002, "channel disabled, ready bit read-only");
    io(8'h40, 16'h0060, 0); chk_rsp(8'h02, 0, "I/O read, channel disabled: NON_FATAL_ERROR");
    memop(8'h48, 32'hFE0B_0000, 0); chk_rsp(8'h02, 0, "memory read, channel disabled: NON_FATAL_ERROR");
    io(8'h44, 16'h0061, 32'h77); chk_rsp(8'h02, 0, "I/O write, channel disabled: NON_FATAL_ERROR");
    set_cfg(12'h010, 32'h0000_0001); get_cfg(12'h010);
    chk(rd32() == 32'h0000_0003, "channel enabled again");

    // I/O window
    io(8'h43, 16'h0060, 0); chk_rsp(8'h08, 4, "I/O read 4 bytes: ACCEPT");
    chk(rd32() == 32'h0, "I/O registers 0 after reset (and the disabled write did nothing)");
    io(8'h47, 16'h0060, 32'h4433_2211); chk_rsp(8'h08, 0, "I/O write 4 bytes: ACCEPT, no data");
    io(8'h43, 16'h0060, 0); chk(rd32() == 32'h4433_2211, $sformatf("I/O read back, LSB first (%h)", rd32()));
    io(8'h40, 16'h0063, 0); chk_rsp(8'h08, 1, "I/O read 1 byte"); chk(rr[1] == 8'h44, "1-byte read at an offset");
    io(8'h41, 16'h0061, 0); chk_rsp(8'h08, 2, "I/O read 2 bytes"); chk(rr[1] == 8'h22 && rr[2] == 8'h33, "2-byte read");
    io(8'h45, 16'h006E, 32'hBBAA); io(8'h41, 16'h006E, 0);
    chk(rr[1] == 8'hAA && rr[2] == 8'hBB, "2-byte write and read at the window end");
    io(8'h44, 16'h0062, 32'h5C); io(8'h43, 16'h0060, 0);
    chk(rd32() == 32'h445C_2211, "1-byte write leaves the neighbours");
    io(8'h43, 16'h006E, 0); chk_rsp(8'h02, 0, "4-byte read across the window end: NON_FATAL_ERROR, rest released");
    io(8'h44, 16'h0080, 32'h1); chk_rsp(8'h02, 0, "I/O write above the window: NON_FATAL_ERROR");
    io(8'h44, 16'h005F, 32'h1); chk_rsp(8'h02, 0, "I/O write below the window: NON_FATAL_ERROR");
    io(8'h44, 16'h0160, 32'h1); chk_rsp(8'h02, 0, "I/O 0x0160 (upper address bits) outside the window");
    io(8'h43, 16'h0060, 0); chk(rd32() == 32'h445C_2211, "rejected writes changed nothing");

    // memory window
    memop(8'h4B, 32'hFE0B_0000, 0); chk_rsp(8'h08, 4, "memory read 4 bytes: ACCEPT");
    chk(rd32() == 32'h0, "memory 0 after reset");
    memop(8'h4F, 32'hFE0B_0000, 32'hEFBE_ADDE); chk_rsp(8'h08, 0, "memory write 4 bytes: ACCEPT");
    memop(8'h4B, 32'hFE0B_0000, 0); chk_rsp(8'h08, 4, "memory read 4 bytes");
    chk(rr[1] == 8'hDE && rr[2] == 8'hAD && rr[3] == 8'hBE && rr[4] == 8'hEF, "memory read back");
    memop(8'h48, 32'hFE0B_0001, 0); chk(rr[1] == 8'hAD, "1-byte memory read at an offset");
    memop(8'h4D, 32'hFE0B_003E, 32'h3412); memop(8'h49, 32'hFE0B_003E, 0);
    chk_rsp(8'h08, 2, "2-byte memory read at the window end"); chk(rr[1] == 8'h12 && rr[2] == 8'h34, "window end data");
    memop(8'h4B, 32'hFE0B_003E, 0); chk_rsp(8'h02, 0, "memory read across the window end: NON_FATAL_ERROR");
    memop(8'h48, 32'hFE0B_0040, 0); chk_rsp(8'h02, 0, "memory read above the window: NON_FATAL_ERROR");
    memop(8'h48, 32'hFE0A_FFFF, 0); chk_rsp(8'h02, 0, "memory read below the window: NON_FATAL_ERROR");
    memop(8'h48, 32'hFF0B_0000, 0); chk_rsp(8'h02, 0, "memory read with other upper address bits: NON_FATAL_ERROR");

    // no response: CRC error, bad length code, unknown opcode
    oe0 = oe_cnt;
    io(8'h44, 16'h0060, 32'h99, 1); chk_none("I/O write with a command CRC error: no response");
    pk.push_back(8'h42); pk.push_back(8'h00); pk.push_back(8'h60); xfer(4);
    chk_none("length code 0b10: no response");
    pk.push_back(8'h30); pk.push_back(8'h00); pk.push_back(8'h60); xfer(4);
    chk_none("unknown opcode: no response");
    chk(oe_cnt == oe0, "MISO never driven for those");
    io(8'h40, 16'h0060, 0); chk(rr[1] == 8'h11, "the write with the CRC error did not happen");

    // a command cut short by CS#, then a normal one
    pk.push_back(8'h21); pk.push_back(8'h00); pk.push_back(8'h08); xfer(0, 0, 12);
    pk.push_back(8'h25); xfer(4);
    chk_rsp(8'h08, 0, "command cut short by CS#: the next one is fine");
    // a response cut short by CS#, then a normal one
    pk.push_back(8'h21); pk.push_back(8'h00); pk.push_back(8'h04); xfer(2);
    get_cfg(12'h004); chk_rsp(8'h08, 4, "response cut short by CS#: the next one is fine");

    chk(oe_hi == 0, "MISO released whenever CS# is high");
    chk(miso_chg == 0, $sformatf("MISO changes only while SCLK is low (%0d)", miso_chg));
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #3000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
