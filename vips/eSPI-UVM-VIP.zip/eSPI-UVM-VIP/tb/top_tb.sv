// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- eSPI testbench top with a functional eSPI DUT model

`ifndef ESPI_UVM_VIP_TB_SV
`define ESPI_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import espi_defs_pkg::*;
import espi_pkg::*;
import espi_env_pkg::*;
import espi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  espi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  espi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cs_n(vif.cs_n),
    .sclk(vif.sclk),
    .mosi(vif.mosi),
    .miso(vif.miso),
    .miso_oe(vif.miso_oe)
  );

  // Concurrent protocol checks
  espi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cs_n(vif.cs_n),
    .sclk(vif.sclk),
    .mosi(vif.mosi),
    .miso(vif.miso),
    .miso_oe(vif.miso_oe)
  );

  initial begin
    uvm_config_db#(virtual espi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module espi_model (
  input  logic clk,
  input  logic rst_n,
  input  logic cs_n,
  input  logic sclk,
  input  logic mosi,
  output logic miso,
  output logic miso_oe
);
  localparam logic [15:0] ESPI_ST = 16'h030F;   // PC / NP / VW / OOB / flash free
  logic [7:0]  io  [0:15];
  logic [7:0]  mem [0:63];
  logic [7:0]  cb  [0:9];     // command bytes before the CRC
  logic [31:0] gen;
  logic        pc_en, cs_p, sclk_p, tar;
  logic [3:0]  nb, len;
  logic [2:0]  bitc;
  logic [6:0]  sh;
  logic [7:0]  crc;
  logic [1:0]  ph;            // 0 command, 1 turn-around, 2 response, 3 idle / ignore
  logic [63:0] rsp;
  logic [6:0]  rbits;

  wire       rise = !cs_n && sclk && !sclk_p;
  wire       fall = !cs_n && !sclk && sclk_p;
  wire [7:0] byte_in = {sh, mosi};

  function automatic logic [7:0] crc8(input logic [7:0] c, input logic [7:0] b);
    logic [7:0] x;
    x = c ^ b;
    for (int k = 0; k < 8; k++) x = x[7] ? ((x << 1) ^ 8'h07) : (x << 1);
    crc8 = x;
  endfunction

  // command length in bytes with the CRC; 0 = not supported
  function automatic logic [3:0] cmd_len(input logic [7:0] op);
    logic [3:0] n;
    n = (op[1:0] == 2'd3) ? 4'd4 : {2'b0, op[1:0]} + 4'd1;
    case (op)
      8'h25:               cmd_len = 4'd2;
      8'h21:               cmd_len = 4'd4;
      8'h22:               cmd_len = 4'd8;
      8'h40, 8'h41, 8'h43: cmd_len = 4'd4;
      8'h44, 8'h45, 8'h47: cmd_len = 4'd4 + n;
      8'h48, 8'h49, 8'h4B: cmd_len = 4'd6;
      8'h4C, 8'h4D, 8'h4F: cmd_len = 4'd6 + n;
      default:             cmd_len = 4'd0;
    endcase
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 16; i++) io[i] <= '0;
      for (int i = 0; i < 64; i++) mem[i] <= '0;
      for (int i = 0; i < 10; i++) cb[i] <= '0;
      gen <= 32'h0000_000F; pc_en <= 1'b1; cs_p <= 1'b1; sclk_p <= 1'b0; tar <= 1'b0;
      nb <= '0; len <= '0; bitc <= '0; sh <= '0; crc <= '0; ph <= 2'd3;
      rsp <= '0; rbits <= '0; miso <= 1'b1; miso_oe <= 1'b0;
    end else begin
      cs_p <= cs_n; sclk_p <= sclk;
      if (cs_n) begin
        ph <= 2'd3; miso <= 1'b1; miso_oe <= 1'b0; rbits <= '0;
      end else if (cs_p) begin                     // CS# fall: a new command
        ph <= 2'd0; nb <= '0; len <= '0; bitc <= '0; crc <= '0; tar <= 1'b0;
      end else if (rise && ph == 2'd0) begin
        bitc <= bitc + 3'd1;
        sh <= byte_in[6:0];
        if (bitc == 3'd7) begin : got_byte
          logic [3:0]  l, rl;
          logic [7:0]  op, code, c;
          logic [31:0] a, w, v;
          logic [2:0]  n;
          logic [63:0] r;
          l = (nb == 4'd0) ? cmd_len(byte_in) : len;
          cb[nb] <= byte_in;
          nb <= nb + 4'd1;
          if (nb == 4'd0) len <= l;
          if (l == 4'd0) ph <= 2'd3;                 // not supported: stay silent
          else if (nb + 4'd1 < l) crc <= crc8(crc, byte_in);
          else begin                                 // byte_in is the command CRC
            op = cb[0];
            n = (op[1:0] == 2'd3) ? 3'd4 : {1'b0, op[1:0]} + 3'd1;
            a = (op[7:3] == 5'b01001) ? {cb[1], cb[2], cb[3], cb[4]} : {16'h0, cb[1], cb[2]};
            w = {cb[6], cb[5], cb[4], cb[3]};
            code = 8'h08;
            if (byte_in != crc) code = 8'hFF;
            else if (op[7:3] == 5'b01000 &&
                     (!pc_en || a[15:4] != 12'h006 || {1'b0, a[3:0]} + {2'b0, n} > 5'd16)) code = 8'h02;
            else if (op[7:3] == 5'b01001 &&
                     (!pc_en || a[31:6] != 26'h3F8_2C00 || {1'b0, a[5:0]} + {4'b0, n} > 7'd64)) code = 8'h02;
            if (code == 8'hFF) ph <= 2'd3;           // CRC error: no response
            else begin
              r = {56'h0, code}; rl = 4'd1;
              if (code == 8'h08) begin
                if (op == 8'h21) begin
                  case (a[11:0])
                    12'h004: v = 32'h0000_0001;
                    12'h008: v = gen;
                    12'h010: v = {30'h0, 1'b1, pc_en};
                    default: v = 32'h0;
                  endcase
                  r = {r[31:0], v[7:0], v[15:8], v[23:16], v[31:24]}; rl = rl + 4'd4;
                end
                if (op == 8'h22) begin
                  if (a[11:0] == 12'h008) gen <= {w[31:16], gen[15:0]};
                  if (a[11:0] == 12'h010) pc_en <= w[0];
                end
                for (int k = 0; k < 4; k++)
                  if (k < n) begin
                    if (op[7:2] == 6'b010000) begin r = {r[55:0], io[a[3:0] + 4'(k)]}; rl = rl + 4'd1; end
                    if (op[7:2] == 6'b010001) io[a[3:0] + 4'(k)] <= cb[3 + k];
                    if (op[7:2] == 6'b010010) begin r = {r[55:0], mem[a[5:0] + 6'(k)]}; rl = rl + 4'd1; end
                    if (op[7:2] == 6'b010011) mem[a[5:0] + 6'(k)] <= cb[5 + k];
                  end
              end
              r = {r[47:0], ESPI_ST[7:0], ESPI_ST[15:8]}; rl = rl + 4'd2;
              c = 8'h00;
              for (int k = 0; k < 8; k++) if (k < rl) c = crc8(c, r[8 * (rl - 1 - k) +: 8]);
              r = {r[55:0], c}; rl = rl + 4'd1;
              rsp <= r << (7'd64 - {rl, 3'b000});
              rbits <= {rl, 3'b000};
              ph <= 2'd1; tar <= 1'b0;
            end
          end
        end
      end else if (rise && ph == 2'd1) begin       // two turn-around cycles
        tar <= 1'b1;
        if (tar) ph <= 2'd2;
      end else if (fall && ph == 2'd2) begin        // response: MISO changes with SCLK low
        if (rbits != 0) begin
          miso <= rsp[63]; miso_oe <= 1'b1; rsp <= rsp << 1; rbits <= rbits - 7'd1;
        end else begin
          miso <= 1'b1; miso_oe <= 1'b0;
        end
      end
    end
  end
endmodule
`endif
