// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_lpi_tb.sv -- self-checking functional test for the AMBA LPI Q-channel
// device model (lpi_device_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py LPI-VIP
//
// Model contract (from tb/top_tb.sv), Q-channel handshake:
//   Q_RUN     (QREQn=1, QACCEPTn=1, QDENY=0)
//   Q_REQUEST (QREQn=0) -> QACCEPTn falls (Q_STOPPED) when QACTIVE=0,
//                          QDENY rises (Q_DENIED) when QACTIVE=1
//   QREQn=1 from Q_STOPPED -> QACCEPTn rises (Q_EXIT -> Q_RUN)
//   QREQn=1 from Q_DENIED  -> QDENY falls (Q_CONTINUE -> Q_RUN)
//   reset: QACCEPTn=0 (Q_STOPPED); QACCEPTn rises once QREQn is high.

module func_lpi_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic clk = 1'b0, resetn = 1'b0, qreqn = 1'b0, qactive = 1'b0;
  wire  qacceptn, qdeny;

  always #5 clk = ~clk;

  lpi_device_model u_dut (
    .vif_aclk(clk), .vif_aresetn(resetn), .vif_qreqn(qreqn),
    .vif_qacceptn(qacceptn), .vif_qdeny(qdeny), .vif_qactive(qactive)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic clks(input int n); repeat (n) @(negedge clk); endtask

  // QACCEPTn / QDENY must never be low/high together (illegal Q-channel state)
  int illegal = 0;
  always @(posedge clk) if (resetn && qacceptn === 1'b0 && qdeny === 1'b1) illegal++;

  initial begin
    clks(2);
    chk(qacceptn === 1'b0 && qdeny === 1'b0, "reset state is Q_STOPPED (QACCEPTn=0, QDENY=0)");
    resetn = 1'b1;
    clks(2);
    chk(qacceptn === 1'b0, "device stays stopped while QREQn is low after reset");
    qreqn = 1'b1;
    clks(1);
    chk(qacceptn === 1'b1 && qdeny === 1'b0, "QREQn high exits to Q_RUN (QACCEPTn rises)");

    // accepted quiescence request
    qactive = 1'b0; qreqn = 1'b0;
    clks(1);
    chk(qacceptn === 1'b0 && qdeny === 1'b0, "idle device accepts the request (Q_STOPPED)");
    clks(3);
    chk(qacceptn === 1'b0, "Q_STOPPED is held while QREQn stays low");
    qreqn = 1'b1;
    clks(1);
    chk(qacceptn === 1'b1, "exit from Q_STOPPED back to Q_RUN");

    // denied request
    qactive = 1'b1; qreqn = 1'b0;
    clks(1);
    chk(qdeny === 1'b1 && qacceptn === 1'b1, "busy device denies the request (Q_DENIED)");
    qactive = 1'b0;
    clks(2);
    chk(qdeny === 1'b1 && qacceptn === 1'b1, "Q_DENIED held until QREQn returns high");
    qreqn = 1'b1;
    clks(1);
    chk(qdeny === 1'b0 && qacceptn === 1'b1, "QDENY falls when QREQn returns high (Q_CONTINUE)");

    // a fresh request after a denial can be accepted
    qreqn = 1'b0;
    clks(1);
    chk(qacceptn === 1'b0 && qdeny === 1'b0, "request after denial accepted once idle");
    qreqn = 1'b1;
    clks(1);

    // asynchronous reset from Q_RUN
    @(negedge clk); resetn = 1'b0;
    #1;
    chk(qacceptn === 1'b0 && qdeny === 1'b0, "reset forces Q_STOPPED");
    resetn = 1'b1;

    chk(illegal == 0, "QACCEPTn low together with QDENY high never observed");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
