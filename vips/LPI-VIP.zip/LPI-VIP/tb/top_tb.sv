// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- ARM Q-Channel LPI testbench top with a functional
//              Q-Channel device DUT model

`ifndef LPI_TB_SV
`define LPI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import lpi_defs_pkg::*;
import lpi_pkg::*;
import lpi_test_pkg::*;

module top_tb;
  logic aclk = 0;
  always #5ns aclk = ~aclk;

  lpi_if vif(aclk);

  initial begin
    vif.aresetn = 0;
    #100ns;
    vif.aresetn = 1;
  end

  lpi_device_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual lpi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional Q-Channel device: answers quiescence requests per the Q-Channel
// state machine. A request arriving while the device is active (qactive=1)
// is denied (qdeny); an idle device accepts (qacceptn falls). Responses are
// released when qreqn returns high.
module lpi_device_model (lpi_if vif);

  initial begin
    vif.qacceptn = 1'b0;
    vif.qdeny    = 1'b0;
  end

  always @(posedge vif.aclk or negedge vif.aresetn) begin
    if (!vif.aresetn) begin
      vif.qacceptn <= 1'b0;      // Q_STOPPED out of reset
      vif.qdeny    <= 1'b0;
    end else begin
      if (!vif.qreqn && vif.qacceptn && !vif.qdeny) begin
        // new quiescence request: decide accept vs deny
        if (vif.qactive) vif.qdeny    <= 1'b1;   // still active: deny
        else             vif.qacceptn <= 1'b0;   // idle: accept
      end else if (vif.qreqn && vif.qdeny) begin
        vif.qdeny <= 1'b0;                          // deny handshake complete
      end else if (vif.qreqn && !vif.qacceptn) begin
        vif.qacceptn <= 1'b1;                       // exit quiescence
      end
    end
  end
endmodule
`endif
