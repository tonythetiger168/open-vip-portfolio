# LPI — ARM Q-Channel Low Power Interface UVM VIP

Open-source UVM verification IP template for **ARM Q-Channel Low Power Interface** (Power).

## Contents

| Path | Description |
|------|-------------|
| `lpi/lpi_if.sv` | Protocol interface + FSM state enum |
| `lpi/lpi_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `lpi/sva/lpi_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=5) |
| `lpi/vip/lpi/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/lpi_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional Q-Channel device DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Synchronous Q-Channel controller driver**: full FSM walk Q_RUN -> Q_REQUEST -> (Q_STOPPED -> Q_EXIT | Q_DENIED -> Q_CONTINUE) -> Q_RUN, deny control via pre-request qactive, protocol-violation stimulus (qactive raised during Q_DENIED)
- **Handshake-decoding monitor**: reconstructs accept/deny outcomes, detects qactive glitches during Q_DENIED, distinguishes standalone activity pulses from pre-request activity
- **End-to-end scoreboard**: deny/accept outcome and glitch flag compared bit-exact against the issued handshake
- **Functional DUT model**: Q-Channel device that denies while active (qactive=1) and accepts while idle, releasing responses when qreqn returns high
- **Directed sequence library**: accept / deny / mixed / long-stop / active-hint / back-to-back / error-inject (qactive glitch) + regression mix
- **Functional coverage**: request x deny cross, stop-duration bins, FSM states + accept/deny sequences, glitch and outcome error bins
- **SVA L4**: request must get accept/deny response, deny/accept mutual exclusion, exit requires qreqn high, no qactive glitch in Q_STOPPED, deny completes
