// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpi_coverage.svh -- Q-Channel functional coverage

`ifndef LPI_COVERAGE_SVH
`define LPI_COVERAGE_SVH

class lpi_coverage extends uvm_subscriber #(lpi_transaction);
  `uvm_component_utils(lpi_coverage)

  lpi_transaction tr;
  lpi_defs_pkg::lpi_state_e cur_state;
  virtual lpi_if vif;

  covergroup cg_protocol;
    cp_request : coverpoint tr.request { bins req = {1}; bins pulse = {0}; }
    cp_deny    : coverpoint tr.deny iff (tr.request) {
      bins accept = {0}; bins deny = {1};
    }
    cp_hint    : coverpoint tr.active_hint { bins low = {0}; bins high = {1}; }
    cp_stop    : coverpoint tr.stop_cycles iff (tr.request && !tr.deny) {
      bins short = {[2:7]};
      bins mid   = {[8:13]};
      bins long  = {[14:20]};
    }
    cx_req_deny : cross cp_request, cp_deny;
  endgroup

  covergroup cg_fsm with function sample(lpi_defs_pkg::lpi_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {lpi_defs_pkg::Q_STOPPED, lpi_defs_pkg::Q_EXIT,
                           lpi_defs_pkg::Q_RUN, lpi_defs_pkg::Q_REQUEST,
                           lpi_defs_pkg::Q_DENIED, lpi_defs_pkg::Q_CONTINUE};
    }
    cp_trans : coverpoint s {
      bins accept_seq = (lpi_defs_pkg::Q_RUN => lpi_defs_pkg::Q_REQUEST =>
                         lpi_defs_pkg::Q_STOPPED => lpi_defs_pkg::Q_EXIT =>
                         lpi_defs_pkg::Q_RUN);
      bins deny_seq   = (lpi_defs_pkg::Q_RUN => lpi_defs_pkg::Q_REQUEST =>
                         lpi_defs_pkg::Q_DENIED => lpi_defs_pkg::Q_CONTINUE =>
                         lpi_defs_pkg::Q_RUN);
    }
  endgroup

  covergroup cg_error;
    cp_glitch : coverpoint tr.qactive_glitch { bins none = {0}; bins glitch = {1}; }
    cp_outcome : coverpoint {tr.denied, tr.accepted} iff (tr.request) {
      bins accepted = {2'b01};
      bins denied   = {2'b10};
    }
    cx_deny_glitch : cross cp_glitch, cp_outcome;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual lpi_if)::get(this, "", "vif", vif));
  endfunction

  function void write(lpi_transaction t);
    tr = t;
    if (vif != null) cur_state = vif.state;
    cg_protocol.sample();
    cg_fsm.sample(cur_state);
    cg_error.sample();
  endfunction
endclass
`endif
