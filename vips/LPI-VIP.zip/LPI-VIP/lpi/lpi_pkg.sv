// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lpi_pkg.sv -- ARM Q-Channel Low Power Interface UVM VIP package

package lpi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import lpi_defs_pkg::*;
  export lpi_defs_pkg::*;

  `include "lpi_transaction.svh"
  `include "lpi_config.svh"
  `include "lpi_sequencer.svh"
  `include "lpi_driver.svh"
  `include "lpi_monitor.svh"
  `include "lpi_agent.svh"
  `include "lpi_sequences.svh"
  `include "lpi_checker.svh"
  `include "lpi_coverage.svh"
endpackage
