// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lpi_protocol_checker.sv -- ARM Q-Channel Low Power Interface protocol rule checker

`ifndef LPI_PROTOCOL_CHECKER_SV
`define LPI_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import lpi_defs_pkg::lpi_state_e;

module lpi_protocol_checker
(
  input logic aclk,
  input logic aresetn,
  input lpi_state_e state
);
  a_lpi_protocol_state_known : assert property (@(posedge aclk)
    disable iff (!aresetn) !$isunknown(state))
    else `uvm_error("PROTOCOL", "lpi protocol: state unknown")
endmodule
`endif
