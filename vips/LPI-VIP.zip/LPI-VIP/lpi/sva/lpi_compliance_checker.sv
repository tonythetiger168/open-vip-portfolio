// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lpi_compliance_checker.sv -- ARM Q-Channel LPI SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = Q-Channel protocol-specific rules

`ifndef LPI_COMPLIANCE_CHECKER_SV
`define LPI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import lpi_defs_pkg::*;

module lpi_compliance_checker
(
  input logic aclk,
  input logic aresetn,
  input lpi_state_e state,
  input logic qreqn,
  input logic qacceptn,
  input logic qdeny,
  input logic qactive
);

  // ---------------- L1: signal sanity (4) ----------------
  a_lpi_l1_clk   : assert property (@(posedge aclk) disable iff (!aresetn) !$isunknown(aclk))
    else `uvm_error("SVA_L1", "lpi: clock unknown")
  a_lpi_l1_rst   : assert property (@(posedge aclk) !$isunknown(aresetn))
    else `uvm_error("SVA_L1", "lpi: reset unknown")
  a_lpi_l1_state : assert property (@(posedge aclk) disable iff (!aresetn) !$isunknown(state))
    else `uvm_error("SVA_L1", "lpi: state unknown")
  a_lpi_l1_valid : assert property (@(posedge aclk) disable iff (!aresetn)
    state inside {Q_STOPPED, Q_EXIT, Q_RUN, Q_REQUEST, Q_DENIED, Q_CONTINUE})
    else `uvm_error("SVA_L1", "lpi: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from Q_STOPPED
  a_lpi_trans_q_stopped : assert property (@(posedge aclk) disable iff (!aresetn)
    state == Q_STOPPED |=> state inside {Q_STOPPED, Q_EXIT})
    else `uvm_error("SVA_L2", "lpi: illegal transition from Q_STOPPED")

  // L2-2: legal FSM transition from Q_EXIT
  a_lpi_trans_q_exit : assert property (@(posedge aclk) disable iff (!aresetn)
    state == Q_EXIT |=> state inside {Q_EXIT, Q_RUN})
    else `uvm_error("SVA_L2", "lpi: illegal transition from Q_EXIT")

  // L2-3: legal FSM transition from Q_RUN
  a_lpi_trans_q_run : assert property (@(posedge aclk) disable iff (!aresetn)
    state == Q_RUN |=> state inside {Q_RUN, Q_REQUEST})
    else `uvm_error("SVA_L2", "lpi: illegal transition from Q_RUN")

  // L2-4: legal FSM transition from Q_REQUEST (accept -> Q_STOPPED, deny -> Q_DENIED)
  a_lpi_trans_q_request : assert property (@(posedge aclk) disable iff (!aresetn)
    state == Q_REQUEST |=> state inside {Q_REQUEST, Q_STOPPED, Q_DENIED})
    else `uvm_error("SVA_L2", "lpi: illegal transition from Q_REQUEST")

  // L2-5: legal FSM transition from Q_DENIED
  a_lpi_trans_q_denied : assert property (@(posedge aclk) disable iff (!aresetn)
    state == Q_DENIED |=> state inside {Q_DENIED, Q_CONTINUE})
    else `uvm_error("SVA_L2", "lpi: illegal transition from Q_DENIED")

  // L2-6: legal FSM transition from Q_CONTINUE (handshake completes to Q_RUN)
  a_lpi_trans_q_continue : assert property (@(posedge aclk) disable iff (!aresetn)
    state == Q_CONTINUE |=> state inside {Q_CONTINUE, Q_RUN})
    else `uvm_error("SVA_L2", "lpi: illegal transition from Q_CONTINUE")

  // ---------------- L3: protocol rules (4) ----------------
  a_lpi_l3_reset_idle : assert property (@(posedge aclk)
    $fell(aresetn) |-> ##[1:4] (state == Q_STOPPED))
    else `uvm_error("SVA_L3", "lpi: state not Q_STOPPED during reset")
  a_lpi_l3_no_stuck   : assert property (@(posedge aclk) disable iff (!aresetn)
    state == Q_CONTINUE |-> ##[1:8] (state != Q_CONTINUE))
    else `uvm_error("SVA_L3", "lpi: stuck in Q_CONTINUE")
  a_lpi_l3_full_cycle : cover property (@(posedge aclk) disable iff (!aresetn)
    state == Q_STOPPED ##1 state == Q_EXIT);
  a_lpi_l3_back_run   : cover property (@(posedge aclk) disable iff (!aresetn)
    state == Q_CONTINUE ##1 state == Q_RUN);

  // ---------------- L4: Q-Channel protocol-specific rules (5) ----------------
  // L4-1: a quiescence request (qreqn low) must be answered by accept or deny
  a_lpi_l4_req_response : assert property (@(posedge aclk) disable iff (!aresetn)
    $fell(qreqn) |-> ##[1:16] ($fell(qacceptn) or $rose(qdeny)))
    else `uvm_error("SVA_L4", "lpi: qreqn low without accept or deny response")

  // L4-2: qacceptn may not be low while qdeny is asserted
  a_lpi_l4_deny_mutex : assert property (@(posedge aclk) disable iff (!aresetn)
    qdeny |-> qacceptn)
    else `uvm_error("SVA_L4", "lpi: qacceptn low during deny")

  // L4-3: quiescence exit (qacceptn rising) requires qreqn high
  a_lpi_l4_exit_needs_req : assert property (@(posedge aclk) disable iff (!aresetn)
    $rose(qacceptn) |-> qreqn)
    else `uvm_error("SVA_L4", "lpi: qacceptn rose while qreqn low")

  // L4-4: qactive must not glitch while the channel is stopped
  a_lpi_l4_no_glitch_stopped : assert property (@(posedge aclk) disable iff (!aresetn)
    state == Q_STOPPED |-> qactive == 1'b0)
    else `uvm_error("SVA_L4", "lpi: qactive glitch in Q_STOPPED")

  // L4-5: a deny completes (qdeny clears) once qreqn returns high
  a_lpi_l4_deny_completes : assert property (@(posedge aclk) disable iff (!aresetn)
    $rose(qdeny) |-> ##[1:16] $fell(qdeny))
    else `uvm_error("SVA_L4", "lpi: qdeny stuck after deny")

endmodule
`endif
