// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpi_sequences.svh -- Q-Channel sequence library

`ifndef LPI_SEQUENCES_SVH
`define LPI_SEQUENCES_SVH

class lpi_base_sequence extends uvm_sequence #(lpi_transaction);
  `uvm_object_utils(lpi_base_sequence)
  int num_txns = 20;
  function new(string name = "lpi_base_sequence"); super.new(name); endfunction
  task body();
    lpi_transaction tr;
    repeat (num_txns) begin
      tr = lpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: quiescence accept path (Q_RUN -> Q_STOPPED -> Q_EXIT -> Q_RUN)
class lpi_accept_seq extends lpi_base_sequence;
  function new(string name = "lpi_accept_seq"); super.new(name); endfunction
  `uvm_object_utils(lpi_accept_seq)
  task body();
    lpi_transaction tr;
    repeat (num_txns) begin
      tr = lpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { request == 1; deny == 0; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: quiescence deny path (Q_REQUEST -> Q_DENIED -> Q_CONTINUE -> Q_RUN)
class lpi_deny_seq extends lpi_base_sequence;
  function new(string name = "lpi_deny_seq"); super.new(name); endfunction
  `uvm_object_utils(lpi_deny_seq)
  task body();
    lpi_transaction tr;
    repeat (num_txns) begin
      tr = lpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { request == 1; deny == 1; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: alternating accept / deny requests
class lpi_mixed_seq extends lpi_base_sequence;
  function new(string name = "lpi_mixed_seq"); super.new(name); endfunction
  `uvm_object_utils(lpi_mixed_seq)
  task body();
    lpi_transaction tr;
    bit d = 0;
    repeat (num_txns) begin
      tr = lpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { request == 1; deny == d; error_inject == 0; });
      d = !d;
      finish_item(tr);
    end
  endtask
endclass

// Directed: long occupancy of Q_STOPPED
class lpi_long_stop_seq extends lpi_base_sequence;
  function new(string name = "lpi_long_stop_seq"); super.new(name); endfunction
  `uvm_object_utils(lpi_long_stop_seq)
  task body();
    lpi_transaction tr;
    repeat (num_txns) begin
      tr = lpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { request == 1; deny == 0; error_inject == 0;
                                  stop_cycles inside {[12:16]}; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: qactive activity pulses without quiescence requests
class lpi_active_hint_seq extends lpi_base_sequence;
  function new(string name = "lpi_active_hint_seq"); super.new(name); endfunction
  `uvm_object_utils(lpi_active_hint_seq)
  task body();
    lpi_transaction tr;
    repeat (num_txns) begin
      tr = lpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { request == 0; active_hint == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back requests with no idle gap
class lpi_back_to_back_seq extends lpi_base_sequence;
  function new(string name = "lpi_back_to_back_seq"); super.new(name); endfunction
  `uvm_object_utils(lpi_back_to_back_seq)
  task body();
    lpi_transaction tr;
    repeat (num_txns) begin
      tr = lpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { request == 1; idle_cycles == 0; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: qactive raised during Q_DENIED (protocol violation)
class lpi_error_inject_seq extends lpi_base_sequence;
  function new(string name = "lpi_error_inject_seq"); super.new(name); endfunction
  `uvm_object_utils(lpi_error_inject_seq)
  task body();
    lpi_transaction tr;
    repeat (num_txns) begin
      tr = lpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 1; });
      finish_item(tr);
    end
  endtask
endclass

class lpi_random_sequence extends lpi_base_sequence;
  `uvm_object_utils(lpi_random_sequence)
  function new(string name = "lpi_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class lpi_regression_sequence extends lpi_base_sequence;
  `uvm_object_utils(lpi_regression_sequence)
  function new(string name = "lpi_regression_sequence"); super.new(name); endfunction
  task body();
    lpi_accept_seq       acc  = lpi_accept_seq::type_id::create("acc");
    lpi_deny_seq         den  = lpi_deny_seq::type_id::create("den");
    lpi_mixed_seq        mix  = lpi_mixed_seq::type_id::create("mix");
    lpi_long_stop_seq    lng  = lpi_long_stop_seq::type_id::create("lng");
    lpi_active_hint_seq  act  = lpi_active_hint_seq::type_id::create("act");
    lpi_back_to_back_seq b2b  = lpi_back_to_back_seq::type_id::create("b2b");
    lpi_error_inject_seq err  = lpi_error_inject_seq::type_id::create("err");
    lpi_random_sequence  rnd  = lpi_random_sequence::type_id::create("rnd");
    acc.num_txns = 8; den.num_txns = 8; mix.num_txns = 8; lng.num_txns = 4;
    act.num_txns = 4; b2b.num_txns = 6; err.num_txns = 6; rnd.num_txns = 20;
    acc.start(m_sequencer); den.start(m_sequencer); mix.start(m_sequencer);
    lng.start(m_sequencer); act.start(m_sequencer); b2b.start(m_sequencer);
    err.start(m_sequencer); rnd.start(m_sequencer);
  endtask
endclass
`endif
