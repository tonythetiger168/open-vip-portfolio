// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpi_driver.svh -- Q-Channel controller driver
//
// Drives the quiescence handshake synchronously to aclk and walks the
// protocol FSM on vif.state:
//   Q_RUN -> Q_REQUEST -> (Q_STOPPED -> Q_EXIT | Q_DENIED -> Q_CONTINUE) -> Q_RUN
// Deny control: qactive is raised before qreqn falls (an active device denies
// quiescence) and lowered as the request starts. error_inject raises qactive
// again during Q_DENIED (protocol violation stimulus).

`ifndef LPI_DRIVER_SVH
`define LPI_DRIVER_SVH

class lpi_driver extends uvm_driver #(lpi_transaction);
  `uvm_component_utils(lpi_driver)
  virtual lpi_if vif;
  lpi_config cfg;
  uvm_analysis_port #(lpi_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual lpi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "lpi virtual interface not set")
  endfunction

  // bring the channel from reset (Q_STOPPED) to Q_RUN
  task automatic channel_startup();
    vif.state = lpi_defs_pkg::Q_STOPPED;
    wait (vif.aresetn === 1'b1);
    repeat (2) @(vif.drv_cb);
    vif.drv_cb.qreqn <= 1'b1;
    @(vif.drv_cb);
    vif.state = lpi_defs_pkg::Q_EXIT;
    wait (vif.qacceptn === 1'b1);
    @(vif.drv_cb);
    vif.state = lpi_defs_pkg::Q_RUN;
  endtask

  task automatic do_request(lpi_transaction tr);
    // present activity: an active device will deny the request
    if (tr.deny) begin
      vif.drv_cb.qactive <= 1'b1;
      repeat (2) @(vif.drv_cb);
    end
    vif.drv_cb.qreqn <= 1'b0;
    @(vif.drv_cb);
    vif.state = lpi_defs_pkg::Q_REQUEST;
    if (tr.deny) vif.drv_cb.qactive <= 1'b0;   // device now quiescing

    wait (vif.qacceptn === 1'b0 || vif.qdeny === 1'b1);
    if (vif.qdeny === 1'b1) begin
      // ---- deny path: Q_REQUEST -> Q_DENIED -> Q_CONTINUE -> Q_RUN ----
      vif.state = lpi_defs_pkg::Q_DENIED;
      if (tr.error_inject) begin
        // violation stimulus: qactive pulled high while denied
        vif.drv_cb.qactive <= 1'b1;
        repeat (2) @(vif.drv_cb);
        vif.drv_cb.qactive <= 1'b0;
        @(vif.drv_cb);
      end
      vif.drv_cb.qreqn <= 1'b1;
      @(vif.drv_cb);
      vif.state = lpi_defs_pkg::Q_CONTINUE;
      wait (vif.qdeny === 1'b0);
      @(vif.drv_cb);
      vif.state = lpi_defs_pkg::Q_RUN;
    end else begin
      // ---- accept path: Q_REQUEST -> Q_STOPPED -> Q_EXIT -> Q_RUN ----
      vif.state = lpi_defs_pkg::Q_STOPPED;
      vif.drv_cb.qactive <= 1'b0;
      repeat (tr.stop_cycles) @(vif.drv_cb);
      vif.drv_cb.qreqn <= 1'b1;
      @(vif.drv_cb);
      vif.state = lpi_defs_pkg::Q_EXIT;
      wait (vif.qacceptn === 1'b1);
      @(vif.drv_cb);
      vif.state = lpi_defs_pkg::Q_RUN;
    end
  endtask

  task run_phase(uvm_phase phase);
    lpi_transaction tr;
    vif.drv_cb.qreqn   <= 1'b0;
    vif.drv_cb.qactive <= 1'b0;
    vif.state = lpi_defs_pkg::Q_STOPPED;
    channel_startup();
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      if (tr.request) begin
        do_request(tr);
      end else begin
        // activity hint only: pulse qactive, no quiescence request
        vif.drv_cb.qactive <= 1'b1;
        repeat (tr.active_cycles) @(vif.drv_cb);
        vif.drv_cb.qactive <= 1'b0;
        @(vif.drv_cb);
      end
      repeat (tr.idle_cycles) @(vif.drv_cb);
      drv_ap.write(tr);                      // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
