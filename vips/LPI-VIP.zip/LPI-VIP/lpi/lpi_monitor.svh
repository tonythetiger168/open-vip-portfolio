// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpi_monitor.svh -- Q-Channel monitor: observes qreqn/qacceptn/qdeny/qactive
// and reconstructs handshake transactions: quiescence requests with their
// accept/deny outcome, qactive glitches during Q_DENIED, and standalone
// activity pulses. A qactive rise shortly before qreqn falls is recognized
// as pre-request device activity, not as a standalone pulse.

`ifndef LPI_MONITOR_SVH
`define LPI_MONITOR_SVH

class lpi_monitor extends uvm_monitor;
  `uvm_component_utils(lpi_monitor)
  virtual lpi_if vif;
  uvm_analysis_port #(lpi_transaction) ap;
  int unsigned txn_count = 0;

  protected bit qreqn_d, qacceptn_d, qdeny_d, qactive_d;
  protected bit pending;       // request handshake in progress
  protected bit act_pending;   // standalone activity pulse in progress
  protected bit denied, accepted, glitch;
  protected int unsigned stop_cnt;  // measured Q_STOPPED occupancy
  protected lpi_transaction tr;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual lpi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "lpi virtual interface not set")
  endfunction

  function void clear_flags();
    pending = 0; act_pending = 0;
    denied = 0; accepted = 0; glitch = 0;
  endfunction

  task run_phase(uvm_phase phase);
    clear_flags();
    qreqn_d = 1; qacceptn_d = 0; qdeny_d = 0; qactive_d = 0;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.aresetn !== 1'b1) begin
        clear_flags();
        qreqn_d = 1; qacceptn_d = 0; qdeny_d = 0; qactive_d = 0;
        continue;
      end

      // ---- request start: qreqn falls ----
      if (!pending && qreqn_d === 1'b1 && vif.mon_cb.qreqn === 1'b0) begin
        act_pending = 0;              // pre-request activity, not a pulse
        pending   = 1;
        denied    = 0;
        accepted  = 0;
        glitch    = 0;
        tr = lpi_transaction::type_id::create("tr");
        tr.request = 1;
        stop_cnt   = 0;
      end

      if (pending) begin
        if (accepted && vif.mon_cb.qreqn === 1'b0) stop_cnt++;
        if (!denied && !accepted && vif.mon_cb.qdeny === 1'b1)    denied   = 1;
        if (!denied && !accepted && vif.mon_cb.qacceptn === 1'b0) accepted = 1;
        if (denied && vif.mon_cb.qactive === 1'b1)                glitch   = 1;

        // ---- handshake completion: qreqn high and response released ----
        if (vif.mon_cb.qreqn === 1'b1) begin
          if (denied && qdeny_d === 1'b1 && vif.mon_cb.qdeny === 1'b0) begin
            tr.denied         = 1;
            tr.deny           = 1;
            tr.qactive_glitch = glitch;
            tr.error_inject   = glitch;
            txn_count++;
            `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
            ap.write(tr);
            pending = 0;
          end else if (accepted && qacceptn_d === 1'b0 && vif.mon_cb.qacceptn === 1'b1) begin
            tr.accepted    = 1;
            tr.deny        = 0;
            tr.stop_cycles = stop_cnt;
            txn_count++;
            `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
            ap.write(tr);
            pending = 0;
          end
        end
      end else begin
        // ---- standalone activity pulse (no quiescence request) ----
        if (!act_pending && vif.mon_cb.qreqn === 1'b1 &&
            vif.mon_cb.qactive === 1'b1 && qactive_d === 1'b0) begin
          act_pending = 1;
          tr = lpi_transaction::type_id::create("tr");
          tr.request     = 0;
          tr.active_hint = 1;
        end
        if (act_pending && vif.mon_cb.qactive === 1'b0 && qactive_d === 1'b1) begin
          txn_count++;
          `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
          ap.write(tr);
          act_pending = 0;
        end
      end

      qreqn_d    = vif.mon_cb.qreqn;
      qacceptn_d = vif.mon_cb.qacceptn;
      qdeny_d    = vif.mon_cb.qdeny;
      qactive_d  = vif.mon_cb.qactive;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("lpi monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
