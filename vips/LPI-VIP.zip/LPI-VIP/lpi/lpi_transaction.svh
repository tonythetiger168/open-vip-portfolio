// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpi_transaction.svh -- Q-Channel handshake transaction
//
// One transaction = one quiescence request handshake:
//   request=1: qreqn falls; the device either accepts (qacceptn falls,
//   channel enters Q_STOPPED) or denies (qdeny rises, Q_DENIED). The
//   controller ends the handshake by raising qreqn again.
//   request=0: pure activity-hint stimulus (qactive pulse, no request).

`ifndef LPI_TRANSACTION_SVH
`define LPI_TRANSACTION_SVH

class lpi_transaction extends uvm_sequence_item;

  rand bit        request;      // 1 = issue a quiescence request
  rand bit        deny;         // 1 = present activity so the device denies
  rand bit        active_hint;  // 1 = keep qactive high while in Q_RUN
  rand bit        error_inject; // 1 = raise qactive during Q_DENIED (violation)
  rand int unsigned stop_cycles;   // aclk cycles spent in Q_STOPPED (accept)
  rand int unsigned active_cycles; // qactive pulse length when request=0
  rand int unsigned idle_cycles;   // gap after the handshake

  // Observed by the monitor
  bit accepted;        // device accepted (qacceptn fell)
  bit denied;          // device denied (qdeny rose)
  bit qactive_glitch;  // qactive seen high while the channel was denied

  constraint c_req    { request dist {1 := 9, 0 := 1}; }
  constraint c_deny   { deny -> request; }
  constraint c_err    { error_inject dist {0 := 8, 1 := 2};
                        error_inject -> (request && deny); }
  constraint c_stop   { stop_cycles inside {[2:16]}; }
  constraint c_active { active_cycles inside {[1:4]}; }
  constraint c_idle   { idle_cycles inside {[0:4]}; }

  `uvm_object_utils_begin(lpi_transaction)
    `uvm_field_int(request, UVM_ALL_ON)
    `uvm_field_int(deny, UVM_ALL_ON)
    `uvm_field_int(active_hint, UVM_ALL_ON)
    `uvm_field_int(error_inject, UVM_ALL_ON)
    `uvm_field_int(accepted, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(denied, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(qactive_glitch, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "lpi_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    lpi_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= (comparer.compare_field("request", request, t.request, 1) == 1);
    if (request) begin
      do_compare &= (comparer.compare_field("deny", deny, t.deny, 1) == 1);
      do_compare &= (comparer.compare_field("accepted", accepted, t.accepted, 1) == 1);
      do_compare &= (comparer.compare_field("denied", denied, t.denied, 1) == 1);
      do_compare &= (comparer.compare_field("qactive_glitch", qactive_glitch,
                                   t.qactive_glitch, 1) == 1);
    end
  endfunction

  function string convert2string();
    if (!request)
      return $sformatf("LPI activity pulse (active_hint=%0b)", active_hint);
    return $sformatf("LPI request deny=%0b%s -> %s%s (stop=%0d)",
                     deny, error_inject ? " [QACTIVE_GLITCH]" : "",
                     denied ? "DENIED" : (accepted ? "ACCEPTED" : "PENDING"),
                     qactive_glitch ? " +glitch" : "", stop_cycles);
  endfunction
endclass
`endif
