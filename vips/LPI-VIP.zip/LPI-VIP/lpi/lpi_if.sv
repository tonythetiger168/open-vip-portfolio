// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lpi_if.sv -- ARM Q-Channel Low Power Interface (qreqn/qacceptn/qdeny/qactive)
//
//   qreqn   : quiescence request, active low (controller -> device), VIP driver
//   qacceptn: quiescence accept, active low (device -> controller), DUT
//   qdeny   : quiescence deny (device -> controller), DUT
//   qactive : device activity indication. In this VIP the driver models the
//             device-activity stimulus: the DUT denies a request that arrives
//             while qactive is high, mirroring a real active device.
//
// All signals are synchronous to aclk (driven/sampled on the rising edge).

interface lpi_if (input logic aclk);
  import lpi_defs_pkg::lpi_state_e;

  logic aresetn;
  logic qreqn    = 1'b0;
  logic qacceptn = 1'b0;
  logic qdeny    = 1'b0;
  logic qactive  = 1'b0;

  lpi_state_e state;   // protocol FSM bookkeeping (driven by the VIP driver)

  modport CTRL (input  aclk, aresetn, qacceptn, qdeny,
                output qreqn, qactive, state);
  modport DUT  (input  aclk, aresetn, qreqn, qactive,
                output qacceptn, qdeny);
  modport MON  (input  aclk, aresetn, qreqn, qacceptn, qdeny, qactive, state);

  // Controller drives synchronously on the rising edge of aclk.
  clocking drv_cb @(posedge aclk);
    input  aresetn, qacceptn, qdeny;
    output qreqn, qactive;
  endclocking

  clocking mon_cb @(posedge aclk);
    input aresetn, qreqn, qacceptn, qdeny, qactive, state;
  endclocking
endinterface
