// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eth_avb_tsn_driver.svh -- Ethernet AVB/TSN driver
// Composes complete Ethernet frames on the RX (ingress) side of the DUT:
// preamble/SFD/DA/SA/[VLAN]/ethertype/payload/FCS streamed as 64-bit beats,
// with AVB stream/SR-class sideband, TSN gate control, 802.3br preemption
// fragments (SMD markers) and valid/ready flow control. Supports error
// injection (bad FCS / runt / jabber / alignment). Publishes every driven
// frame as the scoreboard's expected transaction.

`ifndef ETH_AVB_TSN_DRIVER_SVH
`define ETH_AVB_TSN_DRIVER_SVH

class eth_avb_tsn_driver extends uvm_driver #(eth_avb_tsn_transaction);
  `uvm_component_utils(eth_avb_tsn_driver)

  virtual eth_avb_tsn_if vif;
  eth_avb_tsn_config cfg;

  // Expected-transaction port for the end-to-end scoreboard
  uvm_analysis_port #(eth_avb_tsn_transaction) drv_ap;

  function new(string name = "eth_avb_tsn_driver", uvm_component parent = null);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "eth_avb_tsn_if virtual interface not found")
    if (!uvm_config_db#(eth_avb_tsn_config)::get(this, "", "cfg", cfg)) begin
      cfg = eth_avb_tsn_config::type_id::create("cfg");
      `uvm_warning("NOCFG", "Using default configuration")
    end
  endfunction

  // IEEE 802.3 CRC-32 over the frame body (DA..payload)
  function automatic bit [31:0] eth_crc32(ref bit [7:0] bytes[$]);
    bit [31:0] crc;
    crc = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 32'hEDB8_8320 : (crc >> 1);
    end
    return ~crc;
  endfunction

  task run_phase(uvm_phase phase);
    reset_signals();
    wait (vif.rst_n === 1'b1);
    forever begin
      eth_avb_tsn_transaction txn;
      seq_item_port.get_next_item(txn);
      drive_txn(txn);
      seq_item_port.item_done();
    end
  endtask

  task reset_signals();
    vif.drv_cb.rx_data       <= '0;
    vif.drv_cb.rx_data_valid <= '0;   // rx_valid is the |rx_data_valid alias
    vif.drv_cb.rx_sof        <= 1'b0; // rx_preamble aliases rx_sof
    vif.drv_cb.gate_states   <= 8'h0F;// rx_gate_ctrl aliases gate_states[3:0]
    vif.smd                  <= 1'b0; // smd_valid aliases smd
  endtask

  // Build the complete wire image: preamble | SFD | DA | SA | [VLAN] | ET |
  // payload | FCS, with error-injection mutations.
  virtual function void build_frame(eth_avb_tsn_transaction txn, ref bit [7:0] bytes[$]);
    bit [31:0] fcs;
    bit [7:0]  body[$];
    bytes.delete();
    for (int i = 0; i < 7; i++) bytes.push_back(8'h55);   // preamble
    bytes.push_back(8'hD5);                                // SFD
    body.delete();
    for (int i = 5; i >= 0; i--) body.push_back(txn.dst_addr[i*8 +: 8]);
    for (int i = 5; i >= 0; i--) body.push_back(txn.src_addr[i*8 +: 8]);
    if (txn.vid != 0) begin                                 // 802.1Q tag
      body.push_back(8'h81); body.push_back(8'h00);
      body.push_back({txn.pcp, txn.cfi, txn.vid[11:8]});
      body.push_back(txn.vid[7:0]);
    end
    body.push_back(txn.ethertype[15:8]);
    body.push_back(txn.ethertype[7:0]);
    for (int i = 0; i < txn.payload.size(); i++)
      body.push_back(txn.payload[i]);
    fcs = eth_crc32(body);
    if (txn.fcs_error || txn.with_error || txn.alignment_error)
      fcs = fcs ^ 32'hA5A5_5A5A;                            // corrupt FCS
    foreach (body[i]) bytes.push_back(body[i]);
    for (int i = 0; i < 4; i++) bytes.push_back(fcs[i*8 +: 8]);
    if (txn.length_error) begin
      // runt: truncate below the 64-byte minimum frame
      while (bytes.size() > 30) void'(bytes.pop_back());
    end else if (txn.jabber_error) begin
      // jabber: extend well beyond the 1522-byte maximum
      while (bytes.size() < 1600) bytes.push_back(8'hAA);
    end
  endfunction

  task drive_txn(eth_avb_tsn_transaction txn);
    bit [7:0] bytes[$];
    int idx;
    int frag_len;
    int frag_no;

    `uvm_info("DRIVER", $sformatf("Driving frame: %s", txn.convert2string()), UVM_MEDIUM)

    build_frame(txn, bytes);

    // AVB/TSN sideband
    // AVB/TSN sideband signals are not in drv_cb; drive them directly
    vif.stream_id         <= txn.stream_id;
    vif.sr_class          <= {6'b0, ((txn.sr_class == 66) ? 2'd1 : (txn.sr_class == 65) ? 2'd0 : 2'd0)};
    vif.vid               <= txn.vid;
    vif.pcp               <= txn.pcp;
    vif.sequence_num      <= txn.sequence_num;
    vif.presentation_time <= {32'h0, txn.presentation_time[31:0]};
    vif.preemptable       <= txn.preemptable;
    vif.drv_cb.gate_states<= {4'h0, txn.gate_states[3:0]};

    // Frame preemption (802.3br): split a preemptable frame into two
    // fragments with SMD markers at the fragment boundary.
    frag_len = bytes.size();
    frag_no  = 0;
    if (cfg.preemption_enabled && txn.preemptable && bytes.size() > 128)
      frag_len = 64 + ($urandom_range(0, (bytes.size() - 129) / 8) * 8);
    vif.frag_count <= (frag_len < bytes.size()) ? 6'd2 : 6'(txn.frag_count);

    idx = 0;
    while (idx < bytes.size()) begin
      logic [63:0] beat;
      int n;
      int limit;
      beat = '0;
      limit = (frag_no == 0 && frag_len < bytes.size()) ? frag_len : bytes.size();
      n = (limit - idx < 8) ? (limit - idx) : 8;
      for (int j = 0; j < n; j++)
        beat[j*8 +: 8] = bytes[idx + j];
      // valid/ready flow control
      @(vif.drv_cb);
      while (vif.rx_ready !== 1'b1) @(vif.drv_cb);
      vif.drv_cb.rx_data_valid <= 8'hFF;
      vif.drv_cb.rx_data       <= beat;
      vif.drv_cb.rx_sof        <= (idx == 0);   // rx_preamble aliases rx_sof
      // SMD marker at fragment boundaries (SMD-S start / SMD-C continuation)
      if (frag_len < bytes.size()) begin
        // SMD marker at the boundary (interface carries 1-bit smd, aliased
        // as smd_valid; the 8-bit SMD code is not representable)
        vif.smd <= ((idx == 0) || (idx == frag_len));
      end
      idx += n;
      if (frag_len < bytes.size() && idx == frag_len && frag_no == 0) begin
        // fragment boundary: inter-fragment gap, then continuation
        @(vif.drv_cb);
        vif.drv_cb.rx_data_valid <= '0;
        vif.drv_cb.rx_sof        <= 1'b0;
        repeat (2) @(vif.drv_cb);
        frag_no = 1;
      end
    end
    @(vif.drv_cb);
    vif.drv_cb.rx_data_valid <= '0;
    vif.drv_cb.rx_sof        <= 1'b0;
    vif.smd                  <= 1'b0;
    // inter-frame gap
    repeat (2) @(vif.drv_cb);

    drv_ap.write(txn);   // broadcast expected transaction
  endtask

  task drive_ptp(eth_avb_tsn_transaction txn);
    // gPTP timing is driven by the DUT clock model; forward a PTP frame
    drive_txn(txn);
  endtask

  task drive_avb_stream(eth_avb_tsn_transaction txn);
    // AVB streaming with rate control
    drive_txn(txn);
    #(1us);   // AVB rate limit
  endtask
endclass
`endif
