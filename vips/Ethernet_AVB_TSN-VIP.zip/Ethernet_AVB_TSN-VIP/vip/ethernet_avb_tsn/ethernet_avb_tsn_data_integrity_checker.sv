// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// ethernet_avb_tsn Data Integrity Checker
`ifndef ETHERNET_AVB_TSN_CHK_SV
`define ETHERNET_AVB_TSN_CHK_SV

class ethernet_avb_tsn_data_integrity_checker extends uvm_component;
  `uvm_component_utils(ethernet_avb_tsn_data_integrity_checker)
  virtual eth_avb_tsn_if vif;
  function new(string name="ethernet_avb_tsn_chk", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "ethernet_avb_tsn: vif not found"); endfunction
  property p_avb_fcs; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fcs_error == 1 |-> vif.rx_eof == 1; endproperty
  assert_p_avb_fcs: assert property(p_avb_fcs) else `uvm_warning("ETHERNET_AVB_TSN", "FCS error detection failed");
  cover_p_avb_fcs: cover property(p_avb_fcs);
  property p_avb_stream; @(posedge vif.clk) disable iff (!vif.rst_n) vif.stream_id != 32'h00000000 |-> vif.sr_class > 0; endproperty
  assert_p_avb_stream: assert property(p_avb_stream) else `uvm_warning("ETHERNET_AVB_TSN", "Stream ID non-zero failed");
  cover_p_avb_stream: cover property(p_avb_stream);
  property p_avb_seq; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sequence_num <= 16'hFFFF; endproperty
  assert_p_avb_seq: assert property(p_avb_seq) else `uvm_warning("ETHERNET_AVB_TSN", "Sequence number valid failed");
  cover_p_avb_seq: cover property(p_avb_seq);
endclass
`endif