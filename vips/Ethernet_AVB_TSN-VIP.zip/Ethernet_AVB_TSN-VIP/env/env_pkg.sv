// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// env_pkg.sv -- Ethernet AVB/TSN verification environment package
// End-to-end scoreboard (driver-expected vs monitor-observed) + environment
// wiring agent, coverage, protocol checker and tiered SVA compliance checker.

`ifndef ENV_PKG_SV
`define ENV_PKG_SV

// Guarded includes keep compilation order independent
`include "common_pkg.sv"
`include "eth_avb_tsn_pkg.sv"

// The tiered L1/L2 + L4 SVA compliance checker
// (ethernet_avb_tsn_compliance_checker_sva) is a compilation-unit module and
// cannot be referenced from inside this package; it is instantiated in
// top_tb and the file is compiled standalone.

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import eth_avb_tsn_pkg::*;

  //==========================================================================
  // End-to-end scoreboard
  //==========================================================================
  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  class eth_avb_tsn_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(eth_avb_tsn_scoreboard)

    uvm_analysis_imp_exp #(eth_avb_tsn_transaction, eth_avb_tsn_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(eth_avb_tsn_transaction, eth_avb_tsn_scoreboard) obs_ap;

    eth_avb_tsn_transaction exp_q[$], obs_q[$];
    int unsigned n_matches;
    int unsigned n_mismatches;
    int unsigned n_errors_detected;

    function new(string name = "eth_avb_tsn_scoreboard", uvm_component parent = null);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
      n_matches = 0;
      n_mismatches = 0;
      n_errors_detected = 0;
    endfunction

    virtual function void write_exp(eth_avb_tsn_transaction t);
      exp_q.push_back(t);
      check();
    endfunction

    virtual function void write_obs(eth_avb_tsn_transaction t);
      obs_q.push_back(t);
      check();
    endfunction

    virtual function void check();
      while (exp_q.size() > 0 && obs_q.size() > 0) begin
        eth_avb_tsn_transaction e = exp_q.pop_front();
        eth_avb_tsn_transaction o = obs_q.pop_front();
        if (compare_txn(e, o)) begin
          n_matches++;
          if (e.with_error || e.fcs_error || e.length_error || e.jabber_error)
            n_errors_detected++;
        end else begin
          n_mismatches++;
          `uvm_error("SCOREBOARD", $sformatf("end-to-end mismatch\n  exp: %s\n  obs: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    // Injected errors count as a match only when actually detected by the
    // monitor (bad FCS / runt / jabber classification).
    virtual function bit compare_txn(eth_avb_tsn_transaction e,
                                     eth_avb_tsn_transaction o);
      if (e.length_error)
        return (o.length_error == 1'b1);
      if (e.jabber_error)
        return (o.jabber_error == 1'b1) || (o.payload_len > 1500);
      if (e.fcs_error || e.with_error || e.alignment_error)
        return (o.fcs_error == 1'b1) || (o.with_error == 1'b1);
      if (o.with_error) return 0;
      if (e.dst_addr != o.dst_addr) return 0;
      if (e.src_addr != o.src_addr) return 0;
      if (e.ethertype != o.ethertype) return 0;
      if (e.payload_len != o.payload_len) return 0;
      for (int i = 0; i < e.payload_len; i++)
        if (e.payload[i] != o.payload[i]) return 0;
      return 1;
    endfunction

    virtual function void report_phase(uvm_phase phase);
      super.report_phase(phase);
      `uvm_info("SCOREBOARD", $sformatf(
                "n_matches=%0d n_mismatches=%0d errors_detected=%0d",
                n_matches, n_mismatches, n_errors_detected), UVM_LOW)
      if (n_mismatches > 0)
        `uvm_error("SCOREBOARD", "end-to-end n_mismatches detected")
    endfunction
  endclass

  //==========================================================================
  // Environment
  //==========================================================================
  class eth_avb_tsn_env extends uvm_env;
    `uvm_component_utils(eth_avb_tsn_env)

    eth_avb_tsn_agent               agt;
    eth_avb_tsn_scoreboard          sb;

    function new(string name = "eth_avb_tsn_env", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      // agent internally carries the protocol checker + coverage collector
      agt     = eth_avb_tsn_agent::type_id::create("agt", this);
      sb      = eth_avb_tsn_scoreboard::type_id::create("sb", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      // end-to-end: expected (driver) vs observed (monitor)
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
    endfunction

    function void report_phase(uvm_phase phase);
      super.report_phase(phase);
      `uvm_info("ENV", "eth_avb_tsn_env done", UVM_LOW)
    endfunction
  endclass

endpackage
`endif
