# Ethernet_AVB_TSN-VIP

UVM verification IP for Ethernet AVB / TSN (Time-Sensitive Networking).

## Protocol Overview

This VIP models an Ethernet MAC/bridge endpoint with AVB and TSN features:

- **IEEE 802.1Q AVB/TSN base**: VLAN tagging (PCP/CFI/VID), Stream Reservation
  (SR) classes A/B, stream IDs and presentation time.
- **IEEE 802.1Qav** — Credit-Based Shaping for SR-class traffic.
- **IEEE 802.1Qbv** — Time-Aware Shaper: gate control list (GCL), gate states
  per traffic class, cycle time / cycle time extension.
- **IEEE 802.1Qbu / 802.3br** — Frame preemption: express vs. preemptable
  mPackets, SMD (start mPacket delimiter) markers, fragment handling
  (`frag_last`), hold/release advance.
- **IEEE 802.1AS (gPTP)** — generalized Precision Time Protocol: local/master
  clock, sync interval and sync validity tracking.
- **IEEE 802.1Qci / 802.1CB** — per-stream filtering/policing and frame
  replication/elimination hooks (checker level).

## Architecture

```
eth_avb_tsn/eth_avb_tsn_if.sv  Interface: MAC TX/RX beats, frame fields (addr,
                             ethertype, VLAN TCI), AVB (stream_id, sr_class,
                             presentation_time), TSN (gate states, cycle time),
                             preemption (smd, preemptable, express), gPTP clock
eth_avb_tsn/eth_avb_tsn_transaction.svh  Frame transaction (addr/len/PCP/VID/SR/preempt/err)
eth_avb_tsn/eth_avb_tsn_config.svh       Agent configuration
eth_avb_tsn/eth_avb_tsn_sequencer.svh    Sequencer
eth_avb_tsn/eth_avb_tsn_driver.svh       Driver (express/preemptable beat generation)
eth_avb_tsn/eth_avb_tsn_monitor.svh      Monitor (passive sampling, analysis port)
eth_avb_tsn/eth_avb_tsn_checker.svh      Transaction-level protocol checker
eth_avb_tsn/eth_avb_tsn_coverage.svh     Functional coverage collector
eth_avb_tsn/eth_avb_tsn_agent.svh        Agent (driver+monitor+sequencer)
eth_avb_tsn/eth_avb_tsn_sequences.svh    Sequence library
eth_avb_tsn/sva/ethernet_avb_tsn_compliance_checker.sv  Tiered L1/L2/L3/L4 SVA checker
eth_avb_tsn/vip/ethernet_avb_tsn/  Protocol/timing/error/data-integrity checkers
env/                         UVM environment
tests/eth_avb_tsn_tests.sv   Test library
tb/top_tb.sv                 Top-level testbench
eth_avb_tsn/scripts/         Makefile + coverage regression flow
```

## Sequence Library

Defined in `eth_avb_tsn/eth_avb_tsn_sequences.svh`:

| Sequence | Purpose |
|---|---|
| `eth_avb_tsn_base_sequence` | Base sequence (common knobs) |
| `eth_avb_tsn_random_sequence` | Fully random frames |
| `eth_avb_stream_sequence` | AVB stream traffic (SR class, stream ID) |
| `eth_tsn_preempt_sequence` | 802.1Qbu/802.3br preemption scenarios |
| `eth_ptp_sync_sequence` | gPTP sync/follow-up traffic |
| `eth_vlan_sequence` | VLAN tag / PCP / VID sweeps |
| `eth_error_inject_sequence` | FCS/error injection |
| `eth_cov_sequence` | Coverage closure: frame type x PCP x preemption, tag x error, gate state x frame class, fragment counts, payload sizes |

Error injection is off by default (soft constraints). Only the error-injection
and coverage sequences turn it on, and `error_inject_test`, `cov_test` and
`regression_test` demote the expected bad-FCS reports to info. The scoreboard
still requires every injected error to be detected.

Tests (`tests/eth_avb_tsn_tests.sv`): `base_test`, `avb_stream_test`,
`tsn_preempt_test`, `ptp_sync_test`, `error_inject_test`, `gate_control_test`,
`corner_test`, `cov_test`, `regression_test`.

## Testbench DUT model

`tb/top_tb.sv` holds a store-and-forward switch model. It captures the valid
bytes of each ingress beat (`rx_data_valid` is a per-byte mask), ends a frame at
`rx_eof` (so 802.3br fragments are reassembled), and forwards frames in order
with a per-byte `tx_data_valid` mask. A closed 802.1Qbv gate holds `rx_ready`
low. The driver keeps a beat on the bus until it is accepted, and opens the gate
after `cfg.gate_closed_cycles` clocks. The monitor takes each frame's sideband
(frame class, stream ID, SR class, gate state) from the ingress and pairs it
with the egress frame in order.

## SVA Compliance Checker (L1–L4)

`eth_avb_tsn/sva/ethernet_avb_tsn_compliance_checker.sv` — tiered assertions with
per-level pass/fail counters and a coverage report.

- **L1 Basic Compliance (4)**: `p_avb_pcp` (PCP known), `p_avb_vid` (VID known),
  `p_avb_sr_class` (SR class encoding), `p_avb_ethertype` (ethertype >= 0x0600).
- **L2 Full Protocol (6)**: `p_avb_fcs` (FCS error only at RX EOF),
  `p_avb_stream` (non-zero stream ID implies SR class),
  `p_avb_seq` (sequence number known), `p_avb_cycle` (cycle time > 0),
  `p_avb_sync` (sync interval known), `p_avb_gptp` (sync valid implies
  local clock running).
- **L3 Advanced Features (4)**: `p_avb_l3_stream_ethertype` (stream frames use
  AVTP/gPTP EtherType), `p_avb_l3_seq_incr` (sequence number +1 between
  accepted frames of the same stream), `p_avb_l3_sync_interval`,
  `p_avb_l3_expr_preempt` (not both express and preemptable).
- **L4 Protocol-Specific (5)**: `p_eth_l4_sfd` (SFD 0xD5 terminates preamble),
  `p_eth_l4_preamble` (preamble flag on first ingress beat),
  `p_eth_l4_forward` (every ingress frame is forwarded),
  `p_eth_l4_gate_bp` (802.1Qbv closed gate applies backpressure),
  `p_eth_l4_smd` (802.3br SMD markers only on preemptable traffic).

## Functional Coverage

`eth_avb_tsn/eth_avb_tsn_coverage.svh`:

- **eth_frame_cg**: `type_cp` (frame type), `pcp_cp` (low/mid/high),
  `vid_cp` (untagged/tagged), `len_cp` (min/normal), `sr_cp`
  (none/class A/class B), `preempt_cp`, `frag_cp`, `error_cp`;
  crosses: type x PCP, type x preemptable, VID x error.
- **eth_addr_cg**: `dst_mc_cp` (I/G bit, address bit 40), `src_valid_cp`.
- **eth_fsm_cg**: gate state, fragment count, frame class, frame-class
  transitions, payload size; crosses gate x class and fragments x class.
- Bins the VIP never generates are `ignore_bins` with a `REACHABILITY` comment:
  jumbo payloads, AVB with PCP 0..2, a non-preemptable TSN_PREEMPT frame, and
  fragment counts on frames other than TSN_PREEMPT.
- Interface-level covergroups in `eth_avb_tsn_if.sv` (activity/handshake).

## Quick Start

```sh
# Full coverage-driven regression (default: vcs, goal 100% line/fsm/toggle/assert)
cd scripts
./coverage_regression.sh

# Custom run
SIMULATOR=questa COV_GOAL=95 TESTS="base_test tsn_preempt_test" \
SEEDS="1 2 3" JOBS=8 ./coverage_regression.sh

# Manual make targets
make cov_build  SIMULATOR=vcs
make cov_run_one SIMULATOR=vcs TEST=base_test SEED=12345
make cov_merge cov_report cov_check SIMULATOR=vcs
```

`coverage_regression.sh` builds with coverage instrumentation, runs the
test x seed matrix in parallel, merges coverage, and gates on the coverage
goal (`scripts/cov_check.py`).
