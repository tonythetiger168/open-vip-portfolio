# Ethernet_AVB_TSN-VIP

UVM verification IP for Ethernet AVB / TSN (Time-Sensitive Networking).

## Protocol Overview

This VIP models an Ethernet MAC/bridge endpoint with AVB and TSN features:

- **IEEE 802.1Q AVB/TSN base**: VLAN tagging (PCP/CFI/VID), Stream Reservation
  (SR) classes A/B, stream IDs and presentation time.
- **IEEE 802.1Qav** — Credit-Based Shaping for SR-class traffic.
- **IEEE 802.1Qbv** — Time-Aware Shaper: gate control list (GCL), gate states
  per traffic class, cycle time / cycle time extension.
- **IEEE 802.1Qbu / 802.3br** — Frame preemption: express vs. preemptable
  mPackets, SMD (start mPacket delimiter) markers, fragment handling
  (`frag_last`), hold/release advance.
- **IEEE 802.1AS (gPTP)** — generalized Precision Time Protocol: local/master
  clock, sync interval and sync validity tracking.
- **IEEE 802.1Qci / 802.1CB** — per-stream filtering/policing and frame
  replication/elimination hooks (checker level).

## Architecture

```
eth_avb_tsn_if.sv            Interface: MAC TX/RX beats, frame fields (addr,
                             ethertype, VLAN TCI), AVB (stream_id, sr_class,
                             presentation_time), TSN (gate states, cycle time),
                             preemption (smd, preemptable, express), gPTP clock
eth_avb_tsn_transaction.svh  Frame transaction (addr/len/PCP/VID/SR/preempt/err)
eth_avb_tsn_config.svh       Agent configuration
eth_avb_tsn_sequencer.svh    Sequencer
eth_avb_tsn_driver.svh       Driver (express/preemptable beat generation)
eth_avb_tsn_monitor.svh      Monitor (passive sampling, analysis port)
eth_avb_tsn_checker.svh      Transaction-level protocol checker
eth_avb_tsn_coverage.svh     Functional coverage collector
eth_avb_tsn_agent.svh        Agent (driver+monitor+sequencer)
eth_avb_tsn_sequences.svh    Sequence library
sva/ethernet_avb_tsn_compliance_checker.sv  Tiered L1/L2/L3/L4 SVA checker
vip/ethernet_avb_tsn/        Protocol/timing/error/data-integrity checkers
env/                         UVM environment
tests/eth_avb_tsn_tests.sv   Test library
tb/top_tb.sv                 Top-level testbench
scripts/                     Makefile + coverage regression flow
```

## Sequence Library

Defined in `eth_avb_tsn/eth_avb_tsn_sequences.svh`:

| Sequence | Purpose |
|---|---|
| `eth_avb_tsn_base_sequence` | Base sequence (common knobs) |
| `eth_avb_tsn_random_sequence` | Fully random frames |
| `eth_avb_stream_sequence` | AVB stream traffic (SR class, stream ID) |
| `eth_tsn_preempt_sequence` | 802.1Qbu/802.3br preemption scenarios |
| `eth_ptp_sync_sequence` | gPTP sync/follow-up traffic |
| `eth_vlan_sequence` | VLAN tag / PCP / VID sweeps |
| `eth_error_inject_sequence` | FCS/error injection |

Tests (`tests/eth_avb_tsn_tests.sv`): `base_test`, `avb_stream_test`,
`tsn_preempt_test`, `ptp_sync_test`, `error_inject_test`, `gate_control_test`,
`corner_test`, `regression_test`.

## SVA Compliance Checker (L1–L4)

`sva/ethernet_avb_tsn_compliance_checker.sv` — tiered assertions with
per-level pass/fail counters and a coverage report.

- **L1 Basic Compliance (4)**: `p_avb_pcp` (PCP 0-7), `p_avb_vid` (VID 0-4095),
  `p_avb_sr_class` (SR class encoding), `p_avb_ethertype` (ethertype >= 0x0600).
- **L2 Full Protocol (6)**: `p_avb_fcs` (FCS error only at RX EOF),
  `p_avb_stream` (non-zero stream ID implies SR class),
  `p_avb_seq` (sequence number range), `p_avb_cycle` (cycle time > 0),
  `p_avb_sync` (sync interval range), `p_avb_gptp` (sync valid implies
  local clock running).
- **L3 Advanced Features (0)**: reserved tier (reported, no assertions yet).
- **L4 Protocol-Specific (5)**: `p_eth_l4_sfd` (SFD 0xD5 terminates preamble),
  `p_eth_l4_preamble` (preamble flag on first ingress beat),
  `p_eth_l4_forward` (every ingress frame is forwarded),
  `p_eth_l4_gate_bp` (802.1Qbv closed gate applies backpressure),
  `p_eth_l4_smd` (802.3br SMD markers only on preemptable traffic).

## Functional Coverage

`eth_avb_tsn/eth_avb_tsn_coverage.svh`:

- **eth_frame_cg**: `type_cp` (frame type), `pcp_cp` (low/mid/high),
  `vid_cp` (untagged/tagged), `len_cp` (min/normal/jumbo), `sr_cp`
  (none/class A/class B), `preempt_cp`, `frag_cp`, `error_cp`;
  crosses: type x PCP, type x preemptable, VID x error.
- **eth_addr_cg**: `dst_mc_cp` (multicast bit), `src_valid_cp`.
- Interface-level covergroups in `eth_avb_tsn_if.sv` (activity/handshake).

## Quick Start

```sh
# Full coverage-driven regression (default: vcs, goal 100% line/fsm/toggle/assert)
cd scripts
./coverage_regression.sh

# Custom run
SIMULATOR=questa COV_GOAL=95 TESTS="base_test tsn_preempt_test" \
SEEDS="1 2 3" JOBS=8 ./coverage_regression.sh

# Manual make targets
make cov_build  SIMULATOR=vcs
make cov_run_one SIMULATOR=vcs TEST=base_test SEED=12345
make cov_merge cov_report cov_check SIMULATOR=vcs
```

`coverage_regression.sh` builds with coverage instrumentation, runs the
test x seed matrix in parallel, merges coverage, and gates on the coverage
goal (`scripts/cov_check.py`).
