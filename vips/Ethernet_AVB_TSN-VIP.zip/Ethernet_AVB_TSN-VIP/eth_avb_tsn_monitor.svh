// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eth_avb_tsn_monitor.svh -- Ethernet AVB/TSN monitor
// Reassembles frames from the TX (egress) waveform of the DUT: beat
// collection SOF->EOF, preamble/SFD strip, MAC/VLAN header decode, payload
// reconstruction and CRC-32 re-computation. Runt / jabber / bad-FCS frames
// are classified via the transaction error flags and published on the
// analysis port.

`ifndef ETH_AVB_TSN_MONITOR_SVH
`define ETH_AVB_TSN_MONITOR_SVH

class eth_avb_tsn_monitor extends uvm_monitor;
  `uvm_component_utils(eth_avb_tsn_monitor)

  virtual eth_avb_tsn_if vif;
  eth_avb_tsn_config cfg;
  uvm_analysis_port #(eth_avb_tsn_transaction) ap;

  function new(string name = "eth_avb_tsn_monitor", uvm_component parent = null);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "eth_avb_tsn_if virtual interface not found")
    if (!uvm_config_db#(eth_avb_tsn_config)::get(this, "", "cfg", cfg)) begin
      cfg = eth_avb_tsn_config::type_id::create("cfg");
    end
  endfunction

  // IEEE 802.3 CRC-32 over the frame body (DA..payload)
  function automatic bit [31:0] eth_crc32(ref bit [7:0] bytes[$]);
    bit [31:0] crc;
    crc = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 32'hEDB8_8320 : (crc >> 1);
    end
    return ~crc;
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    forever monitor_txn();
  endtask

  task monitor_txn();
    eth_avb_tsn_transaction txn;
    bit [7:0] bytes[$];
    bit [7:0] body[$];
    bit [7:0] crc_all[$];
    bit [7:0] t0, t1;
    bit [31:0] rcv_fcs, calc_fcs;
    int hdr_len;

    @(vif.mon_cb);
    while (vif.mon_cb.tx_sof !== 1'b1 || (|vif.mon_cb.tx_data_valid) !== 1'b1)
      @(vif.mon_cb);

    txn = eth_avb_tsn_transaction::type_id::create("txn");
    // sideband captured at frame start
    txn.stream_id    = vif.mon_cb.stream_id;
    txn.sr_class     = (vif.mon_cb.sr_class == 2'd1) ? 8'd66 :
                       (vif.mon_cb.sr_class == 2'd0 && vif.mon_cb.stream_id != 0) ? 8'd65 : 8'd0;
    txn.vid          = vif.mon_cb.vid;
    txn.pcp          = vif.mon_cb.pcp;
    txn.sequence_num = vif.mon_cb.sequence_num;
    txn.presentation_time = vif.mon_cb.presentation_time;
    txn.preemptable  = vif.mon_cb.preemptable;
    txn.frag_count   = {2'b00, vif.mon_cb.frag_count};
    txn.gate_states  = {4'h0, vif.mon_cb.gate_states[3:0]};

    // collect beats SOF -> EOF
    bytes.delete();
    for (int j = 0; j < 8; j++)
      bytes.push_back(vif.mon_cb.tx_data[j*8 +: 8]);
    while (vif.mon_cb.tx_eof !== 1'b1) begin
      @(vif.mon_cb);
      if ((|vif.mon_cb.tx_data_valid) === 1'b1)
        for (int j = 0; j < 8; j++)
          bytes.push_back(vif.mon_cb.tx_data[j*8 +: 8]);
    end

    // strip preamble (7 x 0x55) + SFD (0xD5)
    repeat (8) if (bytes.size() > 0) void'(bytes.pop_front());
    crc_all = bytes;   // header + payload + FCS, for CRC re-computation

    if (bytes.size() < 18) begin
      // runt / truncated frame
      txn.length_error = 1;
      txn.with_error   = 1;
      txn.payload_len  = bytes.size();
      txn.payload      = new[bytes.size()];
      foreach (bytes[i]) txn.payload[i] = bytes[i];
      `uvm_warning("MONITOR", $sformatf("Runt frame observed (%0d bytes)", bytes.size()))
      ap.write(txn);
      return;
    end

    for (int i = 5; i >= 0; i--) txn.dst_addr[i*8 +: 8] = bytes.pop_front();
    for (int i = 5; i >= 0; i--) txn.src_addr[i*8 +: 8] = bytes.pop_front();
    t0 = bytes.pop_front(); t1 = bytes.pop_front();
    txn.ethertype = {t0, t1};
    hdr_len = 14;
    if (txn.ethertype == 16'h8100) begin
      logic [15:0] tci;
      t0 = bytes.pop_front(); t1 = bytes.pop_front();
      tci = {t0, t1};
      txn.pcp = tci[15:13];
      txn.cfi = tci[12];
      txn.vid = tci[11:0];
      t0 = bytes.pop_front(); t1 = bytes.pop_front();
      txn.ethertype = {t0, t1};
      hdr_len = 18;
    end

    // trailing FCS
    body = bytes;
    for (int i = 0; i < 4; i++)
      rcv_fcs[i*8 +: 8] = body[body.size() - 4 + i];
    repeat (4) void'(body.pop_back());
    txn.payload_len = body.size();
    txn.payload = new[body.size()];
    foreach (body[i]) txn.payload[i] = body[i];

    // CRC-32 re-computation over header + payload (exclude trailing FCS)
    repeat (4) void'(crc_all.pop_back());
    calc_fcs = eth_crc32(crc_all);
    txn.fcs = rcv_fcs;

    // classification
    txn.fcs_error    = (calc_fcs != rcv_fcs);
    txn.length_error = (hdr_len + txn.payload_len + 4 < 64);
    txn.jabber_error = (hdr_len + txn.payload_len + 4 > 1522);
    txn.with_error   = txn.fcs_error | txn.length_error | txn.jabber_error;
    if (txn.with_error)
      `uvm_warning("MONITOR", $sformatf("Frame error: fcs=%0b runt=%0b jabber=%0b len=%0d",
                   txn.fcs_error, txn.length_error, txn.jabber_error, txn.payload_len))

    `uvm_info("MONITOR", $sformatf("Observed frame: %s", txn.convert2string()), UVM_HIGH)
    ap.write(txn);
  endtask
endclass
`endif
