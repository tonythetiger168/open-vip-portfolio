// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- Ethernet AVB/TSN testbench top
// Single AVB/TSN interface + functional DUT (eth_avb_tsn_dut): a
// store-and-forward TSN switch model with gate-control backpressure,
// plus a free-running gPTP clock. Closes the loop: driver ingress (rx_*)
// -> switch -> monitor egress (tx_*).

`ifndef TOP_TB_SV
`define TOP_TB_SV

`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import eth_avb_tsn_pkg::*;
import env_pkg::*;

module top_tb;

  logic clk = 0;
  logic rst_n;
  always #4ns clk = ~clk;   // 125MHz (1G MAC)

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  eth_avb_tsn_if eth_if (.clk(clk), .rst_n(rst_n));

  eth_avb_tsn_dut dut (.vif(eth_if));

  // Tiered SVA compliance checker (module form)
  ethernet_avb_tsn_compliance_checker_sva u_avb_sva_chk (.vif(eth_if));

  // Data-integrity SVA checker (module form; the vip/ checker files share a
  // single include guard, so exactly this one checker module is compiled)
  ethernet_avb_tsn_data_integrity_checker u_avb_integrity_chk (.vif(eth_if));

  initial begin
    uvm_config_db#(virtual eth_avb_tsn_if)::set(null, "*", "eth_vif", eth_if);
    run_test();
  end
endmodule

//==========================================================================
// Functional DUT: store-and-forward AVB/TSN switch
//  - captures ingress frames beat by beat
//  - forwards them to the egress after a small switching latency
//  - honors the gate control: when the driver's gate vector is 0 the
//    switch applies backpressure (rx_ready low) and delays egress
//  - free-running gPTP clock (local_clock / sync_valid / ts_*)
//==========================================================================
module eth_avb_tsn_dut (eth_avb_tsn_if vif);

  bit [7:0]  frame_q[$];
  bit        in_frame;
  int        fwd_timer;
  bit [31:0] gptp_cnt;

  // Egress FSM state (declared before first use)
  typedef enum logic [1:0] {EG_IDLE, EG_WAIT, EG_SEND} eg_state_e;
  eg_state_e eg_state;

  //------------------------- gPTP clock model ------------------------------
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      gptp_cnt        <= 0;
      vif.local_clock <= 64'h0000_0001_0000_0000;
      vif.sync_valid  <= 1'b0;
      vif.ts_sec      <= 48'h0;
      vif.ts_nsec     <= 32'h0;
      vif.ptp_pulse   <= 1'b0;
    end else begin
      gptp_cnt        <= gptp_cnt + 1;
      vif.local_clock <= vif.local_clock + 8;   // 8ns per cycle
      vif.ts_nsec     <= vif.ts_nsec + 8;
      if (vif.ts_nsec >= 32'd1_000_000_000) begin
        vif.ts_nsec <= vif.ts_nsec - 32'd1_000_000_000;
        vif.ts_sec  <= vif.ts_sec + 1;
      end
      // sync pulse every 1024 cycles
      vif.sync_valid <= (gptp_cnt[9:0] == 10'h000);
      vif.ptp_pulse  <= (gptp_cnt[9:0] == 10'h200);
    end
  end

  //------------------------- ingress: ready + capture -----------------------
  // Gate closed (rx_gate_ctrl == 0) -> backpressure; the switch also applies
  // backpressure while a frame is being forwarded (single buffer).
  assign vif.rx_ready = (vif.rx_gate_ctrl != 4'h0) && (eg_state == EG_IDLE);

  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      frame_q.delete();
      in_frame <= 0;
    end else begin
      if (vif.rx_valid && vif.rx_ready) begin
        if (vif.rx_sof) begin
          frame_q.delete();
          in_frame <= 1;
        end
        if (in_frame || vif.rx_sof) begin
          for (int j = 0; j < 8; j++)
            frame_q.push_back(vif.rx_data[j*8 +: 8]);
        end
      end else if (in_frame) begin
        in_frame <= 0;   // ingress idle: frame complete
      end
    end
  end

  //------------------------- egress: store-and-forward ----------------------
  int        eg_idx;
  int        eg_total;

  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      eg_state          <= EG_IDLE;
      eg_idx            <= 0;
      eg_total          <= 0;
      fwd_timer         <= 0;
      vif.tx_data_valid  <= 8'h00;
      vif.tx_sof        <= 1'b0;
      vif.tx_eof        <= 1'b0;
      vif.tx_data       <= '0;
      vif.tx_gate_state <= 4'hF;
    end else begin
      case (eg_state)
        EG_IDLE: begin
          vif.tx_data_valid <= 8'h00;
          vif.tx_sof   <= 1'b0;
          vif.tx_eof   <= 1'b0;
          // frame fully captured when ingress goes idle after activity
          // smoke fix: do not claim the queue in the same cycle the ingress
          // may accept a new SOF (delete/push races the size() snapshot,
          // causing out-of-bounds queue reads and X on tx_data)
          if (!in_frame && frame_q.size() > 0 && !(vif.rx_valid && vif.rx_ready)) begin
            eg_total  <= frame_q.size();
            eg_idx    <= 0;
            fwd_timer <= 4;         // switching latency
            eg_state  <= EG_WAIT;
            vif.tx_gate_state <= vif.rx_gate_ctrl;
          end
        end
        EG_WAIT: begin
          if (fwd_timer > 0) fwd_timer <= fwd_timer - 1;
          else eg_state <= EG_SEND;
        end
        EG_SEND: begin
          logic [63:0] beat;
          int n;
          beat = '0;
          n = (eg_total - eg_idx < 8) ? (eg_total - eg_idx) : 8;
          for (int j = 0; j < n; j++)
            beat[j*8 +: 8] = frame_q[eg_idx + j];
          vif.tx_data_valid <= 8'hFF;
          vif.tx_data  <= beat;
          vif.tx_sof   <= (eg_idx == 0);
          vif.tx_eof   <= (eg_idx + n >= eg_total);
          eg_idx <= eg_idx + n;
          if (eg_idx + n >= eg_total) begin
            eg_state <= EG_IDLE;
            frame_q.delete();
          end
        end
        default: eg_state <= EG_IDLE;
      endcase
    end
  end
endmodule
`endif
