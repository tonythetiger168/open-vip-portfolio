// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- Ethernet AVB/TSN testbench top
// Single AVB/TSN interface + functional DUT (eth_avb_tsn_dut): a
// store-and-forward TSN switch model with gate-control backpressure,
// plus a free-running gPTP clock. Closes the loop: driver ingress (rx_*)
// -> switch -> monitor egress (tx_*).

`ifndef TOP_TB_SV
`define TOP_TB_SV

`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import eth_avb_tsn_pkg::*;
import env_pkg::*;

module top_tb;

  logic clk = 0;
  logic rst_n;
  always #4ns clk = ~clk;   // 125MHz (1G MAC)

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  eth_avb_tsn_if eth_if (.clk(clk), .rst_n(rst_n));

  eth_avb_tsn_dut dut (.vif(eth_if));

  // Tiered SVA compliance checker (module form)
  ethernet_avb_tsn_compliance_checker_sva u_avb_sva_chk (.vif(eth_if));

  // Data-integrity SVA checker (module form; the vip/ checker files share a
  // single include guard, so exactly this one checker module is compiled)
  ethernet_avb_tsn_data_integrity_checker u_avb_integrity_chk (.vif(eth_if));

  initial begin
    uvm_config_db#(virtual eth_avb_tsn_if)::set(null, "*", "eth_vif", eth_if);
    run_test();
  end
endmodule

//==========================================================================
// Functional DUT: store-and-forward AVB/TSN switch
//  - captures ingress frames beat by beat (a frame ends when rx_valid
//    drops or the next SOF arrives; an rx_ready stall does not end it)
//  - forwards them to the egress after a small switching latency
//  - honors the gate control: when the driver's gate vector is 0 the
//    switch applies backpressure (rx_ready low) and delays egress
//  - free-running gPTP clock (local_clock / sync_valid / ts_*)
//==========================================================================
module eth_avb_tsn_dut (eth_avb_tsn_if vif);

  bit [7:0]  cap_q[$];       // frame being received
  bit [7:0]  fifo_b[$];      // completed frames waiting for the egress
  int        fifo_n[$];      //   (their byte counts)
  bit [7:0]  eg_q[$];        // frame being forwarded
  bit        in_frame;
  int        fwd_timer;
  bit [31:0] gptp_cnt;

  // Egress FSM state (declared before first use)
  typedef enum logic [1:0] {EG_IDLE, EG_WAIT, EG_SEND} eg_state_e;
  eg_state_e eg_state;

  //------------------------- gPTP clock model ------------------------------
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      gptp_cnt        <= 0;
      vif.local_clock <= 64'h0000_0001_0000_0000;
      vif.sync_valid  <= 1'b0;
      vif.ts_sec      <= 48'h0;
      vif.ts_nsec     <= 32'h0;
      vif.ptp_pulse   <= 1'b0;
    end else begin
      gptp_cnt        <= gptp_cnt + 1;
      vif.local_clock <= vif.local_clock + 8;   // 8ns per cycle
      // ts_nsec stays in 0 .. 999_999_999: the carry goes to ts_sec
      if (vif.ts_nsec + 32'd8 >= 32'd1_000_000_000) begin
        vif.ts_nsec <= vif.ts_nsec + 32'd8 - 32'd1_000_000_000;
        vif.ts_sec  <= vif.ts_sec + 1;
      end else begin
        vif.ts_nsec <= vif.ts_nsec + 32'd8;
      end
      // sync pulse every 1024 cycles
      vif.sync_valid <= (gptp_cnt[9:0] == 10'h000);
      vif.ptp_pulse  <= (gptp_cnt[9:0] == 10'h200);
    end
  end

  //------------------------- ingress: ready -------------------------------
  // Gate closed (rx_gate_ctrl == 0) -> backpressure; the switch also applies
  // backpressure while a frame is being forwarded (single egress buffer).
  assign vif.rx_ready = (vif.rx_gate_ctrl != 4'h0) && (eg_state == EG_IDLE);

  //------------------------- store-and-forward ----------------------------
  // A frame starts with rx_sof and ends when rx_valid drops (a stall on
  // rx_ready does not end it) or when the next SOF arrives; it is then
  // queued for the egress, which sends it after the switching latency.
  int        eg_idx;
  int        eg_total;

  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      cap_q.delete(); fifo_b.delete(); fifo_n.delete(); eg_q.delete();
      in_frame          <= 0;
      eg_state          <= EG_IDLE;
      eg_idx            <= 0;
      eg_total          <= 0;
      fwd_timer         <= 0;
      vif.tx_data_valid <= 8'h00;
      vif.tx_sof        <= 1'b0;
      vif.tx_eof        <= 1'b0;
      vif.tx_data       <= '0;
      vif.tx_gate_state <= 4'hF;
    end else begin
      // egress first: it takes frames completed in an earlier clock
      case (eg_state)
        EG_IDLE: begin
          vif.tx_data_valid <= 8'h00;
          vif.tx_sof   <= 1'b0;
          vif.tx_eof   <= 1'b0;
          if (fifo_n.size() > 0) begin
            int n;
            n = fifo_n.pop_front();
            eg_q.delete();
            for (int j = 0; j < n; j++) eg_q.push_back(fifo_b.pop_front());
            eg_total  <= n;
            eg_idx    <= 0;
            fwd_timer <= 4;         // switching latency
            eg_state  <= EG_WAIT;
            vif.tx_gate_state <= vif.rx_gate_ctrl;
          end
        end
        EG_WAIT: begin
          if (fwd_timer > 0) fwd_timer <= fwd_timer - 1;
          else eg_state <= EG_SEND;
        end
        EG_SEND: begin
          logic [63:0] beat;
          int n;
          beat = '0;
          n = (eg_total - eg_idx < 8) ? (eg_total - eg_idx) : 8;
          for (int j = 0; j < n; j++)
            beat[j*8 +: 8] = eg_q[eg_idx + j];
          vif.tx_data_valid <= 8'hFF;
          vif.tx_data  <= beat;
          vif.tx_sof   <= (eg_idx == 0);
          vif.tx_eof   <= (eg_idx + n >= eg_total);
          eg_idx <= eg_idx + n;
          if (eg_idx + n >= eg_total) eg_state <= EG_IDLE;
        end
        default: eg_state <= EG_IDLE;
      endcase

      // ingress capture
      if (vif.rx_valid && vif.rx_ready) begin
        if (vif.rx_sof) begin
          if (in_frame && cap_q.size() > 0) begin   // back-to-back: previous frame done
            foreach (cap_q[j]) fifo_b.push_back(cap_q[j]);
            fifo_n.push_back(cap_q.size());
          end
          cap_q.delete();
          in_frame <= 1;
        end
        if (in_frame || vif.rx_sof) begin
          for (int j = 0; j < 8; j++)
            cap_q.push_back(vif.rx_data[j*8 +: 8]);
        end
      end else if (in_frame && !vif.rx_valid) begin
        in_frame <= 0;                              // ingress idle: frame complete
        foreach (cap_q[j]) fifo_b.push_back(cap_q[j]);
        fifo_n.push_back(cap_q.size());
        cap_q.delete();
      end
    end
  end
endmodule
`endif
