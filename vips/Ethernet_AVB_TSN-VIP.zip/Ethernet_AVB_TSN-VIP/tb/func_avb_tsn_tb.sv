// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_avb_tsn_tb.sv -- self-checking functional test for the AVB/TSN bridge
// model (eth_avb_tsn_dut, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py Ethernet_AVB_TSN-VIP
//
// Model contract (from tb/top_tb.sv):
//   gPTP time base: local_clock (reset 1_0000_0000h) and ts_nsec advance
//   8 ns per clock, ts_nsec (always < 1e9) carries into ts_sec at 1 s; sync_valid pulses
//   every 1024 clocks, ptp_pulse 512 clocks later.
//   Store-and-forward: rx_ready = (rx_gate_ctrl != 0) && egress idle. A
//   frame starts with rx_sof and ends when rx_valid drops (not on an
//   rx_ready stall) or at the next rx_sof; it is then sent
//   on tx in 8-byte beats (tx_sof first, tx_eof last, tx_data_valid FFh)
//   after a fixed delay, with tx_gate_state = the gate control at that time.
//   Not modelled: Qbv gate scheduling, credit-based shaping, preemption.

module func_avb_tsn_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, rx_sof = 1'b0, rx_valid = 1'b0, rx_eof = 1'b0;
  logic [7:0]  rx_dv = 8'h00;     // per-byte valid; rx_valid is its OR
  logic [63:0] rx_data = '0;
  logic [3:0]  gate = 4'hF;
  wire  [63:0] tx_data, local_clock;
  wire  [7:0]  tx_dv;
  wire         tx_sof, tx_eof, rx_ready, sync_valid, ptp_pulse;
  wire  [47:0] ts_sec;
  wire  [31:0] ts_nsec;
  wire  [3:0]  tx_gate_state;

  always #5 clk = ~clk;

  eth_avb_tsn_dut u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_tx_data(tx_data), .vif_tx_data_valid(tx_dv),
    .vif_tx_sof(tx_sof), .vif_tx_eof(tx_eof), .vif_rx_data(rx_data), .vif_rx_sof(rx_sof),
    .vif_rx_data_valid(rx_dv), .vif_rx_eof(rx_eof),
    .vif_rx_ready(rx_ready), .vif_local_clock(local_clock), .vif_sync_valid(sync_valid),
    .vif_rx_valid(rx_valid), .vif_rx_gate_ctrl(gate), .vif_ts_sec(ts_sec),
    .vif_ts_nsec(ts_nsec), .vif_ptp_pulse(ptp_pulse), .vif_tx_gate_state(tx_gate_state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  int cyc = 0;   // clock count (declared before its first use)
  // ---- tx monitor: frames as beat lists ----
  logic [63:0] tq [0:255];
  bit          tsof [0:255], teof [0:255];
  int          tn = 0, bad_dv = 0, first_sof_t;
  always @(posedge clk) begin
    if (tx_dv != 0) begin
      tq[tn] = tx_data; tsof[tn] = tx_sof; teof[tn] = tx_eof; tn++;
      if (tx_dv != 8'hFF) bad_dv++;
      if (tx_sof && first_sof_t < 0) first_sof_t = cyc;
    end else if (rst_n && (tx_sof || tx_eof)) bad_dv++;    // framing without data
  end
  always @(posedge clk) cyc++;

  // ---- rx driver: one beat per clock while rx_ready ----
  logic [63:0] fr [0:63];
  int          last_beat_t;
  task automatic send(input int n, input int seed, input bit gap_after = 1);
    for (int i = 0; i < n; i++) fr[i] = {8'hD5, 24'(seed), 16'(i), 16'(n)};
    for (int i = 0; i < n; i++) begin
      @(negedge clk);
      rx_valid = 1'b1; rx_dv = 8'hFF; rx_data = fr[i]; rx_sof = (i == 0);
      rx_eof = (i == n - 1);      // the switch closes a frame at rx_eof
      // the beat is taken at the first rising edge that sees rx_ready
      @(posedge clk);
      while (rx_ready !== 1'b1) @(posedge clk);
      #1 last_beat_t = cyc - 1;
    end
    if (gap_after) begin
      @(negedge clk);
      rx_valid = 1'b0; rx_dv = 8'h00; rx_sof = 1'b0; rx_eof = 1'b0;
    end
  endtask

  // tx beats tq[from..] form exactly one frame equal to fr[0..n-1]?
  function automatic bit fwd_ok(input int from, input int n);
    if (tn - from != n) return 0;
    for (int i = 0; i < n; i++) begin
      if (tq[from + i] != fr[i]) return 0;
      if (tsof[from + i] != (i == 0) || teof[from + i] != (i == n - 1)) return 0;
    end
    return 1;
  endfunction

  logic [63:0] t0;
  int s0, n_sync, n_ptp, sync_t, ptp_t, per_bad, t_from, lat;
  bit mono_ok;
  logic [31:0] ns_prev;
  logic [47:0] sec_prev;

  initial begin
    first_sof_t = -1;
    repeat (2) @(negedge clk);
    chk(local_clock == 64'h1_0000_0000 && ts_nsec == 0 && ts_sec == 0 && tx_dv == 0 &&
        tx_gate_state == 4'hF, "reset: clocks at their reset values, no tx, gates open");
    chk(!sync_valid && !ptp_pulse && !tx_sof && !tx_eof, "reset: no sync / PTP pulse, no tx framing");
    rst_n = 1'b1;

    // ---- gPTP time base ----
    @(negedge clk); t0 = local_clock; s0 = ts_nsec;
    chk(sync_valid && !ptp_pulse, "first sync_valid on the first clock after reset (gPTP count 0)");
    repeat (100) @(negedge clk);
    chk(local_clock - t0 == 800 && ts_nsec - s0 == 800, "local_clock and ts_nsec advance 8 ns per clock");
    n_sync = 0; n_ptp = 0; per_bad = 0; sync_t = -1; ptp_t = -1;
    for (int i = 0; i < 3 * 1024; i++) begin
      @(negedge clk);
      if (sync_valid) begin
        if (sync_t >= 0 && cyc - sync_t != 1024) per_bad++;
        sync_t = cyc; n_sync++;
      end
      if (ptp_pulse && sync_t >= 0) begin
        if (cyc - sync_t != 512) per_bad++;
        ptp_t = cyc; n_ptp++;
      end
    end
    chk(n_sync == 3 && n_ptp >= 2 && per_bad == 0,
        "sync_valid every 1024 clocks, ptp_pulse 512 clocks after it (single-clock pulses)");

    // second boundary (time base preset close to 1 s)
    @(negedge clk);
    force u_dut.vif_ts_nsec = 32'd999_999_976;
    @(negedge clk);
    release u_dut.vif_ts_nsec;
    sec_prev = ts_sec; ns_prev = ts_nsec; mono_ok = 1;
    for (int i = 0; i < 6; i++) begin
      @(negedge clk);
      if (ts_nsec >= 32'd1_000_000_000) mono_ok = 0;
      if (ts_sec == sec_prev && ts_nsec != ns_prev + 8) mono_ok = 0;
      if (ts_sec == sec_prev + 1 && ts_nsec != ns_prev + 8 - 32'd1_000_000_000) mono_ok = 0;
      sec_prev = ts_sec; ns_prev = ts_nsec;
    end
    chk(ts_sec == 1, "ts_sec increments at the 1 s boundary");
    chk(mono_ok, "ts_nsec stays below 1e9 and advances 8 ns per clock across the second");

    // ---- store and forward ----
    gate = 4'h5;
    t_from = tn; first_sof_t = -1;
    send(4, 1);
    repeat (12) @(negedge clk);
    chk(fwd_ok(t_from, 4), "4-beat frame forwarded intact, SOF / EOF on the first / last beat");
    chk(bad_dv == 0, "tx_data_valid = FFh on every beat, no SOF / EOF without data");
    chk(tx_gate_state == 4'h5, "tx_gate_state reports the gate control of the forwarded frame");
    lat = first_sof_t - last_beat_t;
    // the frame is complete at its rx_eof beat (not when rx_valid drops)
    chk(lat == 8, "fixed store-and-forward delay: tx SOF 8 clocks after the last rx beat");
    t_from = tn;
    send(1, 2);
    repeat (12) @(negedge clk);
    chk(fwd_ok(t_from, 1), "single-beat frame forwarded with SOF and EOF together");
    t_from = tn;
    send(32, 3);
    repeat (44) @(negedge clk);
    chk(fwd_ok(t_from, 32), "32-beat frame forwarded intact");

    // ---- ingress rules ----
    t_from = tn;
    @(negedge clk); rx_valid = 1'b1; rx_dv = 8'hFF; rx_sof = 1'b0; rx_eof = 1'b0; rx_data = 64'hBAD;
    repeat (3) @(negedge clk); rx_valid = 1'b0; rx_dv = 8'h00;
    repeat (12) @(negedge clk);
    chk(tn == t_from, "beats without a preceding SOF are dropped");
    gate = 4'h0;
    @(negedge clk);
    chk(rx_ready === 1'b0, "all gates closed: rx_ready low");
    fork
      send(2, 4);
      begin
        repeat (10) @(negedge clk);
        chk(tn == t_from, "frame held off while the gates are closed");
        gate = 4'h3;
      end
    join
    repeat (12) @(negedge clk);
    chk(fwd_ok(t_from, 2) && tx_gate_state == 4'h3, "frame accepted and forwarded once a gate opens");

    // egress busy: rx_ready low until the frame has left
    t_from = tn;
    send(8, 5);
    repeat (2) @(negedge clk);
    chk(rx_ready === 1'b0, "rx_ready low while the previous frame is being forwarded");
    send(2, 6);
    repeat (12) @(negedge clk);
    chk(tn - t_from == 10 && tq[t_from + 8] == fr[0], "frame sent during egress is accepted afterwards");

    // back-to-back frames (SOF right after the last beat)
    t_from = tn;
    send(3, 7, 0);
    send(2, 8);
    repeat (20) @(negedge clk);
    chk(tn - t_from == 5 && tq[t_from] == {8'hD5, 24'(7), 16'(0), 16'(3)} && tq[t_from + 3] == fr[0] &&
        tsof[t_from] && teof[t_from + 2] && tsof[t_from + 3] && teof[t_from + 4],
        "back-to-back frames (SOF directly after the last beat) both forwarded");

    // gate closing in the middle of a frame
    t_from = tn;
    fork
      send(6, 9);
      begin
        repeat (3) @(negedge clk);
        gate = 4'h0;
        repeat (4) @(negedge clk);
        gate = 4'hF;
      end
    join
    repeat (20) @(negedge clk);
    chk(fwd_ok(t_from, 6), "frame stalled by a gate closure is forwarded whole once the gate reopens");

    // ---- reset during forwarding ----
    t_from = tn;
    send(16, 10);
    repeat (9) @(negedge clk);
    rst_n = 1'b0;
    @(negedge clk);
    chk(tx_dv == 0 && !tx_sof && !tx_eof && local_clock == 64'h1_0000_0000,
        "reset stops forwarding and reloads the time base");
    rst_n = 1'b1;
    t0 = tn;
    repeat (20) @(negedge clk);
    chk(tn == t0, "no stale frame after reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
