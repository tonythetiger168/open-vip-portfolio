// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eth_avb_tsn_tests.sv -- Ethernet AVB/TSN test library
// base_test builds the env and wires vif/cfg; derived tests select stimulus.

`ifndef ETH_AVB_TSN_TESTS_SV
`define ETH_AVB_TSN_TESTS_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import common_pkg::*;
import eth_avb_tsn_pkg::*;
import env_pkg::*;

class base_test extends uvm_test;
  `uvm_component_utils(base_test)

  eth_avb_tsn_env    env;
  eth_avb_tsn_config cfg;

  function new(string name = "base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    virtual eth_avb_tsn_if vif;
    super.build_phase(phase);
    if (!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "eth_vif", vif))
      `uvm_fatal("NOVIF", "eth_avb_tsn_if virtual interface not found")
    cfg = eth_avb_tsn_config::type_id::create("cfg");
    uvm_config_db#(virtual eth_avb_tsn_if)::set(this, "env.agt.*", "vif", vif);
    uvm_config_db#(virtual eth_avb_tsn_if)::set(this, "env.sva_chk", "vif", vif);
    uvm_config_db#(eth_avb_tsn_config)::set(this, "env.agt.*", "cfg", cfg);
    env = eth_avb_tsn_env::type_id::create("env", this);
  endfunction

  virtual task run_phase(uvm_phase phase);
    eth_avb_tsn_base_sequence seq;
    phase.raise_objection(this);
    seq = eth_avb_tsn_base_sequence::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class avb_stream_test extends base_test;
  `uvm_component_utils(avb_stream_test)
  function new(string name = "avb_stream_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    eth_avb_stream_sequence seq;
    phase.raise_objection(this);
    seq = eth_avb_stream_sequence::type_id::create("seq");
    seq.num_txns = 16;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class tsn_preempt_test extends base_test;
  `uvm_component_utils(tsn_preempt_test)
  function new(string name = "tsn_preempt_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    eth_tsn_preempt_sequence seq;
    phase.raise_objection(this);
    seq = eth_tsn_preempt_sequence::type_id::create("seq");
    seq.num_txns = 8;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class ptp_sync_test extends base_test;
  `uvm_component_utils(ptp_sync_test)
  function new(string name = "ptp_sync_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    eth_ptp_sync_sequence seq;
    phase.raise_objection(this);
    seq = eth_ptp_sync_sequence::type_id::create("seq");
    seq.num_txns = 8;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class error_inject_test extends base_test;
  `uvm_component_utils(error_inject_test)
  function new(string name = "error_inject_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    eth_error_inject_sequence seq;
    phase.raise_objection(this);
    seq = eth_error_inject_sequence::type_id::create("seq");
    seq.num_txns = 12;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class gate_control_test extends base_test;
  `uvm_component_utils(gate_control_test)
  function new(string name = "gate_control_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    eth_gate_sequence seq;
    phase.raise_objection(this);
    seq = eth_gate_sequence::type_id::create("seq");
    seq.num_txns = 16;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class corner_test extends base_test;
  `uvm_component_utils(corner_test)
  function new(string name = "corner_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    eth_max_frame_sequence max_seq;
    eth_min_frame_sequence min_seq;
    phase.raise_objection(this);
    max_seq = eth_max_frame_sequence::type_id::create("max_seq");
    max_seq.num_txns = 4;
    max_seq.start(env.agt.sqr);
    min_seq = eth_min_frame_sequence::type_id::create("min_seq");
    min_seq.num_txns = 4;
    min_seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class regression_test extends base_test;
  `uvm_component_utils(regression_test)
  function new(string name = "regression_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    eth_regression_sequence seq;
    phase.raise_objection(this);
    seq = eth_regression_sequence::type_id::create("seq");
    seq.num_txns = 40;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
