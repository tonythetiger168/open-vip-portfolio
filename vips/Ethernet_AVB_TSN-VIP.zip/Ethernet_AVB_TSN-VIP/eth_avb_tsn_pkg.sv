// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_pkg.sv

// Common base classes (guarded include keeps compilation order independent)
`ifndef ETH_AVB_TSN_PKG_SV
`define ETH_AVB_TSN_PKG_SV

`include "common_pkg.sv"

package eth_avb_tsn_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  `include "eth_avb_tsn_config.svh"
  `include "eth_avb_tsn_transaction.svh"
  `include "eth_avb_tsn_sequencer.svh"
  `include "eth_avb_tsn_driver.svh"
  `include "eth_avb_tsn_monitor.svh"
  `include "eth_avb_tsn_checker.svh"
  `include "eth_avb_tsn_coverage.svh"
  `include "eth_avb_tsn_agent.svh"
  `include "eth_avb_tsn_sequences.svh"
endpackage

`endif // ETH_AVB_TSN_PKG_SV
