// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_monitor.svh

class eth_avb_tsn_monitor extends uvm_monitor;
  `uvm_component_utils(eth_avb_tsn_monitor)
  virtual eth_avb_tsn_if vif;
  uvm_analysis_port #(eth_avb_tsn_transaction) ap;
  eth_avb_tsn_config cfg;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ETH AVB/TSN virtual interface not found")
    if (!uvm_config_db#(eth_avb_tsn_config)::get(this, "", "cfg", cfg))
      cfg = eth_avb_tsn_config::type_id::create("cfg");
  endfunction
  task run_phase(uvm_phase phase);
    eth_avb_tsn_transaction tx;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.tx_sof) begin
        tx = eth_avb_tsn_transaction::type_id::create("tx");
        tx.dst_addr = vif.mon_cb.dst_addr;
        tx.src_addr = vif.mon_cb.src_addr;
        tx.ethertype = vif.mon_cb.ethertype;
        tx.vid = vif.mon_cb.vid;
        tx.pcp = vif.mon_cb.pcp;
        tx.cfi = vif.mon_cb.cfi;
        tx.stream_id = vif.mon_cb.stream_id;
        tx.sr_class = vif.mon_cb.sr_class;
        tx.preemptable = vif.mon_cb.preemptable;
        tx.express = vif.mon_cb.express;
        tx.frag_count = vif.mon_cb.frag_count;
        tx.frag_last = vif.mon_cb.frag_last;
        tx.stream_handle = vif.mon_cb.stream_handle;
        tx.sequence_num = vif.mon_cb.sequence_num;
        tx.duplicate = vif.mon_cb.duplicate;
        if (tx.ethertype == 16'h22F0) tx.frame_type = eth_avb_tsn_transaction::AVB_STREAM;
        else if (tx.ethertype == 16'h88F7) tx.frame_type = eth_avb_tsn_transaction::PTP_SYNC;
        else if (tx.preemptable) tx.frame_type = eth_avb_tsn_transaction::TSN_PREEMPT;
        else tx.frame_type = eth_avb_tsn_transaction::STANDARD_ETH;
        ap.write(tx);
        `uvm_info("ETH_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_MEDIUM)
      end
    end
  endtask
endclass
