// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eth_avb_tsn_monitor.svh -- Ethernet AVB/TSN monitor
// Reassembles frames from the TX (egress) waveform of the DUT: beat
// collection SOF->EOF, preamble/SFD strip, MAC/VLAN header decode, payload
// reconstruction and CRC-32 re-computation. Runt / jabber / bad-FCS frames
// are classified via the transaction error flags and published on the
// analysis port.

`ifndef ETH_AVB_TSN_MONITOR_SVH
`define ETH_AVB_TSN_MONITOR_SVH

class eth_avb_tsn_monitor extends uvm_monitor;
  `uvm_component_utils(eth_avb_tsn_monitor)

  virtual eth_avb_tsn_if vif;
  eth_avb_tsn_config cfg;
  uvm_analysis_port #(eth_avb_tsn_transaction) ap;

  function new(string name = "eth_avb_tsn_monitor", uvm_component parent = null);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "eth_avb_tsn_if virtual interface not found")
    if (!uvm_config_db#(eth_avb_tsn_config)::get(this, "", "cfg", cfg)) begin
      cfg = eth_avb_tsn_config::type_id::create("cfg");
    end
  endfunction

  // IEEE 802.3 CRC-32 over the frame body (DA..payload)
  function automatic bit [31:0] eth_crc32(ref bit [7:0] bytes[$]);
    bit [31:0] crc;
    crc = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 32'hEDB8_8320 : (crc >> 1);
    end
    return ~crc;
  endfunction

  // Sideband of each frame, taken on the ingress when its first beat is
  // offered. The switch forwards frames in order, so the egress side pops
  // them in the same order.
  eth_avb_tsn_transaction side_q[$];

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    fork
      watch_ingress();
      forever monitor_txn();
    join
  endtask

  task watch_ingress();
    bit offered = 0;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rx_sof === 1'b1 && (|vif.mon_cb.rx_data_valid) === 1'b1) begin
        if (!offered) begin
          eth_avb_tsn_transaction sb;
          sb = eth_avb_tsn_transaction::type_id::create("side");
          sb.frame_type   = eth_avb_tsn_transaction::eth_frame_type_e'(vif.mon_cb.frame_type);
          sb.stream_id    = vif.mon_cb.stream_id;
          sb.sr_class     = (vif.mon_cb.sr_class == 8'd1) ? 8'd65 :
                            (vif.mon_cb.sr_class == 8'd2) ? 8'd66 : 8'd0;
          sb.sequence_num = vif.mon_cb.sequence_num;
          sb.stream_handle = vif.mon_cb.stream_handle;
          sb.presentation_time = vif.mon_cb.presentation_time;
          sb.preemptable  = vif.mon_cb.preemptable;
          sb.express      = vif.mon_cb.express;
          sb.frag_count   = vif.mon_cb.frag_count;
          sb.frag_last    = vif.mon_cb.frag_last;
          sb.gate_states  = vif.mon_cb.gate_states;
          sb.cycle_time   = vif.mon_cb.cycle_time;
          side_q.push_back(sb);
        end
        offered = (vif.mon_cb.rx_ready !== 1'b1);   // held until accepted
      end
    end
  endtask

  task monitor_txn();
    eth_avb_tsn_transaction txn;
    bit [7:0] bytes[$];
    bit [7:0] body[$];
    bit [7:0] crc_all[$];
    bit [7:0] t0, t1;
    bit [31:0] rcv_fcs, calc_fcs;
    int hdr_len;

    @(vif.mon_cb);
    while (vif.mon_cb.tx_sof !== 1'b1 || (|vif.mon_cb.tx_data_valid) !== 1'b1)
      @(vif.mon_cb);

    txn = eth_avb_tsn_transaction::type_id::create("txn");
    // sideband of the matching ingress frame (VID/PCP come from the tag)
    if (side_q.size() > 0) begin
      eth_avb_tsn_transaction sb = side_q.pop_front();
      txn.frame_type   = sb.frame_type;
      txn.stream_id    = sb.stream_id;
      txn.sr_class     = sb.sr_class;
      txn.sequence_num = sb.sequence_num;
      txn.stream_handle = sb.stream_handle;
      txn.presentation_time = sb.presentation_time;
      txn.preemptable  = sb.preemptable;
      txn.express      = sb.express;
      txn.frag_count   = sb.frag_count;
      txn.frag_last    = sb.frag_last;
      txn.gate_states  = sb.gate_states;
      txn.cycle_time   = sb.cycle_time;
    end
    else `uvm_error("MONITOR", "egress frame without a matching ingress frame")
    txn.vid = 0;
    txn.pcp = 0;

    // collect the valid bytes of each beat, SOF -> EOF
    bytes.delete();
    forever begin
      for (int j = 0; j < 8; j++)
        if (vif.mon_cb.tx_data_valid[j] === 1'b1)
          bytes.push_back(vif.mon_cb.tx_data[j*8 +: 8]);
      if (vif.mon_cb.tx_eof === 1'b1) break;
      @(vif.mon_cb);
    end

    // strip preamble (7 x 0x55) + SFD (0xD5)
    repeat (8) if (bytes.size() > 0) void'(bytes.pop_front());
    crc_all = bytes;   // header + payload + FCS, for CRC re-computation

    if (bytes.size() < 18) begin
      // runt / truncated frame
      txn.length_error = 1;
      txn.with_error   = 1;
      txn.payload_len  = bytes.size();
      txn.payload      = new[bytes.size()];
      foreach (bytes[i]) txn.payload[i] = bytes[i];
      `uvm_warning("MONITOR", $sformatf("Runt frame observed (%0d bytes)", bytes.size()))
      ap.write(txn);
      return;
    end

    for (int i = 5; i >= 0; i--) txn.dst_addr[i*8 +: 8] = bytes.pop_front();
    for (int i = 5; i >= 0; i--) txn.src_addr[i*8 +: 8] = bytes.pop_front();
    t0 = bytes.pop_front(); t1 = bytes.pop_front();
    txn.ethertype = {t0, t1};
    hdr_len = 14;
    if (txn.ethertype == 16'h8100) begin
      logic [15:0] tci;
      t0 = bytes.pop_front(); t1 = bytes.pop_front();
      tci = {t0, t1};
      txn.pcp = tci[15:13];
      txn.cfi = tci[12];
      txn.vid = tci[11:0];
      t0 = bytes.pop_front(); t1 = bytes.pop_front();
      txn.ethertype = {t0, t1};
      hdr_len = 18;
    end

    // trailing FCS
    body = bytes;
    for (int i = 0; i < 4; i++)
      rcv_fcs[i*8 +: 8] = body[body.size() - 4 + i];
    repeat (4) void'(body.pop_back());
    txn.payload_len = body.size();
    txn.payload = new[body.size()];
    foreach (body[i]) txn.payload[i] = body[i];

    // CRC-32 re-computation over header + payload (exclude trailing FCS)
    repeat (4) void'(crc_all.pop_back());
    calc_fcs = eth_crc32(crc_all);
    txn.fcs = rcv_fcs;

    // classification
    txn.fcs_error    = (calc_fcs != rcv_fcs);
    txn.length_error = (hdr_len + txn.payload_len + 4 < 64);
    txn.jabber_error = (hdr_len + txn.payload_len + 4 > 1522);
    txn.with_error   = txn.fcs_error | txn.length_error | txn.jabber_error;
    if (txn.with_error)
      `uvm_warning("MONITOR", $sformatf("Frame error: fcs=%0b runt=%0b jabber=%0b len=%0d",
                   txn.fcs_error, txn.length_error, txn.jabber_error, txn.payload_len))

    `uvm_info("MONITOR", $sformatf("Observed frame: %s", txn.convert2string()), UVM_HIGH)
    ap.write(txn);
  endtask
endclass
`endif
