// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// Ethernet-AVB-TSN Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 14
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
`ifndef ETHERNET_AVB_TSN_COMPLIANCE_CHECKER_SV
`define ETHERNET_AVB_TSN_COMPLIANCE_CHECKER_SV



import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// ethernet_avb_tsn_compliance_checker_sva -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module ethernet_avb_tsn_compliance_checker_sva (eth_avb_tsn_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  real l1_cov, l2_cov, l3_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_avb_pcp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pcp <= 3'd7; endproperty
  assert_p_avb_pcp: assert property(p_avb_pcp) l1_pass[0]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L1", "PCP 0-7 failed"); l1_fail[0]++; end
  cover_p_avb_pcp: cover property(p_avb_pcp);
  property p_avb_vid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vid <= 12'd4095; endproperty
  assert_p_avb_vid: assert property(p_avb_vid) l1_pass[1]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L1", "VID 0-4095 failed"); l1_fail[1]++; end
  cover_p_avb_vid: cover property(p_avb_vid);
  property p_avb_sr_class; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sr_class inside {8'h00,8'h01,8'h02}; endproperty
  assert_p_avb_sr_class: assert property(p_avb_sr_class) l1_pass[2]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L1", "SR class failed"); l1_fail[2]++; end
  cover_p_avb_sr_class: cover property(p_avb_sr_class);
  property p_avb_ethertype; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ethertype >= 16'h0600; endproperty
  assert_p_avb_ethertype: assert property(p_avb_ethertype) l1_pass[3]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L1", "Ethertype failed"); l1_fail[3]++; end
  cover_p_avb_ethertype: cover property(p_avb_ethertype);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_avb_fcs; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fcs_error == 1 |-> vif.rx_eof == 1; endproperty
  assert_p_avb_fcs: assert property(p_avb_fcs) l2_pass[0]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L2", "FCS error failed"); l2_fail[0]++; end
  cover_p_avb_fcs: cover property(p_avb_fcs);
  property p_avb_stream; @(posedge vif.clk) disable iff (!vif.rst_n) vif.stream_id != 32'h00000000 |-> vif.sr_class > 0; endproperty
  assert_p_avb_stream: assert property(p_avb_stream) l2_pass[1]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L2", "Stream ID failed"); l2_fail[1]++; end
  cover_p_avb_stream: cover property(p_avb_stream);
  property p_avb_seq; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sequence_num <= 16'hFFFF; endproperty
  assert_p_avb_seq: assert property(p_avb_seq) l2_pass[2]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L2", "Sequence failed"); l2_fail[2]++; end
  cover_p_avb_seq: cover property(p_avb_seq);
  property p_avb_cycle; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cycle_time > 0; endproperty
  assert_p_avb_cycle: assert property(p_avb_cycle) l2_pass[3]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L2", "Cycle time failed"); l2_fail[3]++; end
  cover_p_avb_cycle: cover property(p_avb_cycle);
  property p_avb_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_interval <= 16'hFFFF; endproperty
  assert_p_avb_sync: assert property(p_avb_sync) l2_pass[4]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L2", "Sync interval failed"); l2_fail[4]++; end
  cover_p_avb_sync: cover property(p_avb_sync);
  property p_avb_gptp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_valid == 1 |-> vif.local_clock > 0; endproperty
  assert_p_avb_gptp: assert property(p_avb_gptp) l2_pass[5]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L2", "gPTP sync failed"); l2_fail[5]++; end
  cover_p_avb_gptp: cover property(p_avb_gptp);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: AVB stream traffic must use the AVTP (0x22F0) or gPTP (0x88F7) EtherType
  property p_avb_l3_stream_ethertype; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.rx_sof && vif.stream_id != 32'h0) |-> vif.ethertype inside {16'h22F0, 16'h88F7}; endproperty
  assert_p_avb_l3_stream_ethertype: assert property(p_avb_l3_stream_ethertype) l3_pass[0]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L3", "Stream frame without AVTP/gPTP ethertype failed"); l3_fail[0]++; end
  cover_p_avb_l3_stream_ethertype: cover property(p_avb_l3_stream_ethertype);
  // L3-2: AVTP sequence number increments by one between packets of the same stream
  property p_avb_l3_seq_incr; @(posedge vif.clk) disable iff (!vif.rst_n) ($rose(vif.rx_sof) && vif.stream_id == $past(vif.stream_id,1) && vif.stream_id != 32'h0) |-> (vif.sequence_num == $past(vif.sequence_num,1) + 16'h1); endproperty
  assert_p_avb_l3_seq_incr: assert property(p_avb_l3_seq_incr) l3_pass[1]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L3", "AVTP sequence gap failed"); l3_fail[1]++; end
  cover_p_avb_l3_seq_incr: cover property(p_avb_l3_seq_incr);
  // L3-3: a valid gPTP sync requires a programmed non-zero sync interval
  property p_avb_l3_sync_interval; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_valid |-> vif.sync_interval > 0; endproperty
  assert_p_avb_l3_sync_interval: assert property(p_avb_l3_sync_interval) l3_pass[2]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L3", "Sync valid with zero interval failed"); l3_fail[2]++; end
  cover_p_avb_l3_sync_interval: cover property(p_avb_l3_sync_interval);
  // L3-4: a frame cannot be both express and preemptable (802.3br)
  property p_avb_l3_expr_preempt; @(posedge vif.clk) disable iff (!vif.rst_n) !(vif.express && vif.preemptable); endproperty
  assert_p_avb_l3_expr_preempt: assert property(p_avb_l3_expr_preempt) l3_pass[3]++; else begin `uvm_warning("ETHERNET-AVB-TSN_L3", "Frame both express and preemptable failed"); l3_fail[3]++; end
  cover_p_avb_l3_expr_preempt: cover property(p_avb_l3_expr_preempt);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l1_hit=0, l2_hit=0, l3_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    total_cov = (l1_total+l2_total+l3_total>0) ? ((l1_hit+l2_hit+l3_hit)*100.0/(l1_total+l2_total+l3_total)) : 0;
    `uvm_info("ETHERNET-AVB-TSN_RPT", $sformatf("=== Ethernet-AVB-TSN Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("ETHERNET-AVB-TSN_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("ETHERNET-AVB-TSN_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("ETHERNET-AVB-TSN_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("ETHERNET-AVB-TSN_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit, l1_total+l2_total+l3_total), UVM_LOW)
  end
endmodule

// ============================================================================
// ethernet_avb_tsn_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the ethernet_avb_tsn_compliance_checker_sva module above)
// ============================================================================
class ethernet_avb_tsn_compliance_checker extends uvm_component;
  `uvm_component_utils(ethernet_avb_tsn_compliance_checker)
  function new(string name = "ethernet_avb_tsn_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

`endif
