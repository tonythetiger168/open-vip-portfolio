// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_if.sv
// Ethernet AVB / TSN Interface (IEEE 802.1Qav / 802.1Qbv / 802.1Qbu / 802.3br / 802.1Qci / 802.1CB)

interface eth_avb_tsn_if (input logic clk, input logic rst_n);
  // MAC signals
  logic [63:0] tx_data;
  logic [7:0]  tx_data_valid;
  logic        tx_sof;
  logic        tx_eof;
  logic        tx_ready;
  logic [63:0] rx_data;
  logic [7:0]  rx_data_valid;
  logic        rx_sof;
  logic        rx_eof;
  logic        rx_ready;
  // Frame fields
  logic [47:0] dst_addr;
  logic [47:0] src_addr;
  logic [15:0] ethertype;
  logic [15:0] vlan_tci;     // VLAN tag control info
  logic [2:0]  pcp;          // priority code point
  logic        cfi;
  logic [11:0] vid;          // VLAN ID
  // AVB specific
  logic [31:0] stream_id;
  logic [63:0] presentation_time;
  logic [15:0] max_frame_size;
  logic [15:0] max_interval_frames;
  logic [7:0]  sr_class;     // SR class A/B
  // TSN specific
  logic        gate_control_list_valid;
  logic [7:0]  gate_states;
  logic [31:0] cycle_time;
  logic [31:0] cycle_time_extension;
  logic        preemptable;
  logic        express;
  logic [31:0] hold_advance;
  logic [31:0] release_advance;
  // Time sync (gPTP / 802.1AS)
  logic [63:0] local_clock;
  logic [63:0] master_clock;
  logic [15:0] sync_interval;
  logic        sync_valid;
  // Frame preemption (802.1Qbu / 802.3br)
  logic        smd;          // start mPacket delimiter
  logic [5:0]  frag_count;
  logic        frag_last;
  // PSFP / FRER (802.1Qci / 802.1CB)
  logic [15:0] stream_handle;
  logic [15:0] sequence_num;
  logic        duplicate;

  //========================================================================
  // Compliance alias signals (used by the tiered SVA compliance checker)
  // Aliases derived combinationally from the native signals above.
  //========================================================================
  logic       rx_valid;       assign rx_valid      = |rx_data_valid;
  logic       rx_preamble;    assign rx_preamble   = rx_sof;   // first-beat marker
  logic [3:0] rx_gate_ctrl;   assign rx_gate_ctrl  = gate_states[3:0];
  logic       smd_valid;      assign smd_valid     = smd;
  // gPTP timestamp sideband (driven by the DUT clock model)
  logic [47:0] ts_sec;
  logic [31:0] ts_nsec;
  logic        ptp_pulse;
  // Egress gate-state observability (driven by the DUT)
  logic [3:0]  tx_gate_state;

  // Errors
  logic        fcs_error;
  logic        jabber_error;
  logic        alignment_error;
  logic        length_error;

  modport DUT (
    input  clk, rst_n, rx_data, rx_data_valid, rx_sof, rx_eof, rx_ready,
    input  tx_ready, gate_control_list_valid, gate_states, cycle_time,
    input  cycle_time_extension, local_clock, master_clock, sync_interval, sync_valid,
    output tx_data, tx_data_valid, tx_sof, tx_eof, dst_addr, src_addr,
    output ethertype, vlan_tci, pcp, cfi, vid, stream_id, presentation_time,
    output max_frame_size, max_interval_frames, sr_class, preemptable, express,
    output hold_advance, release_advance, smd, frag_count, frag_last,
    output stream_handle, sequence_num, duplicate, fcs_error, jabber_error,
    output alignment_error, length_error
  );

  modport TB (
    input  clk, rst_n, tx_data, tx_data_valid, tx_sof, tx_eof, dst_addr,
    input  src_addr, ethertype, vlan_tci, pcp, cfi, vid, stream_id,
    input  presentation_time, max_frame_size, max_interval_frames, sr_class,
    input  preemptable, express, hold_advance, release_advance, smd, frag_count,
    input  frag_last, stream_handle, sequence_num, duplicate, fcs_error,
    input  jabber_error, alignment_error, length_error,
    output rx_data, rx_data_valid, rx_sof, rx_eof, rx_ready, tx_ready,
    output gate_control_list_valid, gate_states, cycle_time, cycle_time_extension,
    output local_clock, master_clock, sync_interval, sync_valid
  );

  clocking mon_cb @(posedge clk);
    input tx_data, tx_data_valid, tx_sof, tx_eof, rx_data, rx_data_valid;
    input rx_sof, rx_eof, dst_addr, src_addr, ethertype, vlan_tci, pcp, vid;
    input stream_id, sr_class, preemptable, express, smd, frag_count, frag_last;
    input stream_handle, sequence_num, duplicate, fcs_error, jabber_error;
    input alignment_error, length_error;
    input cfi, gate_states, presentation_time;
  endclocking

  clocking drv_cb @(posedge clk);
    output rx_data, rx_data_valid, rx_sof, rx_eof, rx_ready, tx_ready;
    output gate_control_list_valid, gate_states, cycle_time, sync_valid;
    input  tx_sof, tx_eof;
  endclocking
endinterface
