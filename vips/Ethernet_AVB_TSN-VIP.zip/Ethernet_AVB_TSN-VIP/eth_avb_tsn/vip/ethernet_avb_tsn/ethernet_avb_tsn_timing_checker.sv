// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// ethernet_avb_tsn Timing Performance Checker
`ifndef ETHERNET_AVB_TSN_CHK_SV
`define ETHERNET_AVB_TSN_CHK_SV

class ethernet_avb_tsn_timing_performance_checker extends uvm_component;
  `uvm_component_utils(ethernet_avb_tsn_timing_performance_checker)
  virtual eth_avb_tsn_if vif;
  function new(string name="ethernet_avb_tsn_chk", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "ethernet_avb_tsn: vif not found"); endfunction
  property p_avb_cycle; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cycle_time > 0; endproperty
  assert_p_avb_cycle: assert property(p_avb_cycle) else `uvm_warning("ETHERNET_AVB_TSN", "Cycle time valid failed");
  cover_p_avb_cycle: cover property(p_avb_cycle);
  property p_avb_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_interval <= 16'hFFFF; endproperty
  assert_p_avb_sync: assert property(p_avb_sync) else `uvm_warning("ETHERNET_AVB_TSN", "Sync interval valid failed");
  cover_p_avb_sync: cover property(p_avb_sync);
  property p_avb_gptp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_valid == 1 |-> vif.local_clock > 0; endproperty
  assert_p_avb_gptp: assert property(p_avb_gptp) else `uvm_warning("ETHERNET_AVB_TSN", "gPTP with sync failed");
  cover_p_avb_gptp: cover property(p_avb_gptp);
endclass
`endif