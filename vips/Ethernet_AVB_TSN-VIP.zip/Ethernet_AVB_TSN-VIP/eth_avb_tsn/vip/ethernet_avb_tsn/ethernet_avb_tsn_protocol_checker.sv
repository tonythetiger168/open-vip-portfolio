// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// ethernet_avb_tsn Protocol Compliance Checker
`ifndef ETHERNET_AVB_TSN_CHK_SV
`define ETHERNET_AVB_TSN_CHK_SV

class ethernet_avb_tsn_protocol_compliance_checker extends uvm_component;
  `uvm_component_utils(ethernet_avb_tsn_protocol_compliance_checker)
  virtual eth_avb_tsn_if vif;
  function new(string name="ethernet_avb_tsn_chk", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "ethernet_avb_tsn: vif not found"); endfunction
  property p_avb_pcp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pcp <= 3'd7; endproperty
  assert_p_avb_pcp: assert property(p_avb_pcp) else `uvm_warning("ETHERNET_AVB_TSN", "PCP 0-7 failed");
  cover_p_avb_pcp: cover property(p_avb_pcp);
  property p_avb_vid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vid <= 12'd4095; endproperty
  assert_p_avb_vid: assert property(p_avb_vid) else `uvm_warning("ETHERNET_AVB_TSN", "VID 0-4095 failed");
  cover_p_avb_vid: cover property(p_avb_vid);
  property p_avb_sr_class; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sr_class inside {8'h00,8'h01,8'h02}; endproperty
  assert_p_avb_sr_class: assert property(p_avb_sr_class) else `uvm_warning("ETHERNET_AVB_TSN", "SR class A/B failed");
  cover_p_avb_sr_class: cover property(p_avb_sr_class);
  property p_avb_ethertype; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ethertype >= 16'h0600; endproperty
  assert_p_avb_ethertype: assert property(p_avb_ethertype) else `uvm_warning("ETHERNET_AVB_TSN", "Ethertype valid failed");
  cover_p_avb_ethertype: cover property(p_avb_ethertype);
endclass
`endif