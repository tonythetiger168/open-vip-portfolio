// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// ethernet_avb_tsn Error Handling Checker
`ifndef ETHERNET_AVB_TSN_CHK_SV
`define ETHERNET_AVB_TSN_CHK_SV

class ethernet_avb_tsn_error_handling_checker extends uvm_component;
  `uvm_component_utils(ethernet_avb_tsn_error_handling_checker)
  virtual eth_avb_tsn_if vif;
  function new(string name="ethernet_avb_tsn_chk", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "ethernet_avb_tsn: vif not found"); endfunction
  property p_avb_jabber; @(posedge vif.clk) disable iff (!vif.rst_n) vif.jabber_error == 1 |-> vif.length_error == 1; endproperty
  assert_p_avb_jabber: assert property(p_avb_jabber) else `uvm_warning("ETHERNET_AVB_TSN", "Jabber error failed");
  cover_p_avb_jabber: cover property(p_avb_jabber);
  property p_avb_align; @(posedge vif.clk) disable iff (!vif.rst_n) vif.alignment_error == 1 |-> vif.rx_eof == 1; endproperty
  assert_p_avb_align: assert property(p_avb_align) else `uvm_warning("ETHERNET_AVB_TSN", "Alignment error failed");
  cover_p_avb_align: cover property(p_avb_align);
  property p_avb_preempt; @(posedge vif.clk) disable iff (!vif.rst_n) vif.preemptable == 1 |-> vif.express == 0; endproperty
  assert_p_avb_preempt: assert property(p_avb_preempt) else `uvm_warning("ETHERNET_AVB_TSN", "Preemption valid failed");
  cover_p_avb_preempt: cover property(p_avb_preempt);
endclass
`endif