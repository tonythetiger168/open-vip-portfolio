// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_coverage.svh

class eth_avb_tsn_coverage extends coverage_collector_base;
  `uvm_component_utils(eth_avb_tsn_coverage)
  uvm_analysis_imp #(eth_avb_tsn_transaction, eth_avb_tsn_coverage) analysis_export;

  // Coverpoint sample variables (declared before the covergroups that
  // reference them, per IEEE 1800 declaration-before-use rules)
  eth_avb_tsn_transaction tx;
  int sample_count = 0;

  covergroup eth_frame_cg;
    option.per_instance = 1;
    type_cp: coverpoint tx.frame_type {
      bins standard  = {eth_avb_tsn_transaction::STANDARD_ETH};
      bins avb       = {eth_avb_tsn_transaction::AVB_STREAM};
      bins tsn_tt    = {eth_avb_tsn_transaction::TSN_TIME_TRIGGERED};
      bins tsn_pre   = {eth_avb_tsn_transaction::TSN_PREEMPT};
      bins cut_thru  = {eth_avb_tsn_transaction::TSN_CUT_THROUGH};
      bins ptp       = {eth_avb_tsn_transaction::PTP_SYNC};
      bins diag      = {eth_avb_tsn_transaction::DIAGNOSTIC};
    }
    pcp_cp: coverpoint tx.pcp { bins low = {[0:2]}; bins mid = {[3:5]}; bins high = {[6:7]}; }
    vid_cp: coverpoint tx.vid { bins untagged = {0}; bins tag = {[1:4094]}; }
    len_cp: coverpoint tx.payload_len { bins min = {[46:63]}; bins normal = {[64:1518]}; bins jumbo = {[1519:9000]}; }
    sr_cp: coverpoint tx.sr_class { bins none = {0}; bins class_a = {65}; bins class_b = {66}; }
    preempt_cp: coverpoint tx.preemptable;
    frag_cp: coverpoint tx.frag_last;
    error_cp: coverpoint tx.with_error;
    cross type_cp, pcp_cp;
    cross type_cp, preempt_cp;
    cross vid_cp, error_cp;
  endgroup

  covergroup eth_addr_cg;
    option.per_instance = 1;
    dst_mc_cp: coverpoint tx.dst_addr[0];
    src_valid_cp: coverpoint tx.src_addr[0];
  endgroup


  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    eth_frame_cg = new();
    eth_addr_cg = new();
  endfunction
  function void write(eth_avb_tsn_transaction tx_); begin tx = tx_; sample_coverage(tx); end endfunction
  virtual function void sample_coverage(uvm_sequence_item tx_);
    eth_avb_tsn_transaction etx;
    if (!$cast(etx, tx_)) return;
    tx = etx;
    eth_frame_cg.sample();
    eth_addr_cg.sample();
    sample_count++;
  endfunction
  function void report_phase(uvm_phase phase);
    `uvm_info("ETH_COV", $sformatf("Sampled %0d transactions", sample_count), UVM_LOW)
    `uvm_info("ETH_COV", $sformatf("Frame coverage = %0.2f%%", eth_frame_cg.get_coverage()), UVM_LOW)
  endfunction
endclass
