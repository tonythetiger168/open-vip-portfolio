// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eth_avb_tsn_driver.svh -- Ethernet AVB/TSN driver
// Composes complete Ethernet frames on the RX (ingress) side of the DUT:
// preamble/SFD/DA/SA/[VLAN]/ethertype/payload/FCS streamed as 64-bit beats,
// with AVB stream/SR-class sideband, TSN gate control, 802.3br preemption
// fragments (SMD markers) and valid/ready flow control. Supports error
// injection (bad FCS / runt / jabber / alignment). Publishes every driven
// frame as the scoreboard's expected transaction.

`ifndef ETH_AVB_TSN_DRIVER_SVH
`define ETH_AVB_TSN_DRIVER_SVH

class eth_avb_tsn_driver extends uvm_driver #(eth_avb_tsn_transaction);
  `uvm_component_utils(eth_avb_tsn_driver)

  virtual eth_avb_tsn_if vif;
  eth_avb_tsn_config cfg;
  bit cur_bad_fcs;     // the frame being driven carries a bad FCS

  // Expected-transaction port for the end-to-end scoreboard
  uvm_analysis_port #(eth_avb_tsn_transaction) drv_ap;

  function new(string name = "eth_avb_tsn_driver", uvm_component parent = null);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "eth_avb_tsn_if virtual interface not found")
    if (!uvm_config_db#(eth_avb_tsn_config)::get(this, "", "cfg", cfg)) begin
      cfg = eth_avb_tsn_config::type_id::create("cfg");
      `uvm_warning("NOCFG", "Using default configuration")
    end
  endfunction

  // IEEE 802.3 CRC-32 over the frame body (DA..payload)
  function automatic bit [31:0] eth_crc32(ref bit [7:0] bytes[$]);
    bit [31:0] crc;
    crc = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 32'hEDB8_8320 : (crc >> 1);
    end
    return ~crc;
  endfunction

  task run_phase(uvm_phase phase);
    reset_signals();
    wait (vif.rst_n === 1'b1);
    forever begin
      eth_avb_tsn_transaction txn;
      seq_item_port.get_next_item(txn);
      drive_txn(txn);
      seq_item_port.item_done();
    end
  endtask

  task reset_signals();
    vif.rx_data       <= '0;
    vif.rx_data_valid <= '0;   // rx_valid is the |rx_data_valid alias
    vif.rx_sof        <= 1'b0; // rx_preamble aliases rx_sof
    vif.rx_eof        <= 1'b0;
    vif.tx_ready      <= 1'b1;
    vif.gate_states   <= 8'hFF;// rx_gate_ctrl aliases gate_states[3:0]
    vif.gate_control_list_valid <= 1'b0;
    vif.cycle_time    <= 32'd125000;   // 125 us 802.1Qbv cycle
    vif.smd                  <= 1'b0; // smd_valid aliases smd
    // Frame sideband: defined values between frames
    vif.frame_type           <= 3'd0;
    vif.dst_addr             <= '0;
    vif.src_addr             <= '0;
    vif.ethertype            <= 16'h0800;
    vif.vlan_tci             <= '0;
    vif.pcp                  <= '0;
    vif.cfi                  <= 1'b0;
    vif.vid                  <= '0;
    vif.stream_id            <= '0;
    vif.sr_class             <= '0;
    vif.presentation_time    <= '0;
    vif.max_frame_size       <= 16'(cfg.max_frame_size);
    vif.max_interval_frames  <= 16'd1;
    vif.preemptable          <= 1'b0;
    vif.express              <= 1'b0;
    vif.hold_advance         <= '0;
    vif.release_advance      <= '0;
    vif.frag_count           <= '0;
    vif.frag_last            <= 1'b0;
    vif.stream_handle        <= '0;
    vif.sequence_num         <= '0;
    vif.duplicate            <= 1'b0;
    vif.master_clock         <= '0;
    vif.sync_interval        <= 16'd1024;     // gPTP sync every 1024 clocks
    vif.cycle_time_extension <= '0;
    vif.fcs_error            <= 1'b0;
    vif.jabber_error         <= 1'b0;
    vif.alignment_error      <= 1'b0;
    vif.length_error         <= 1'b0;
  endtask

  // Build the complete wire image: preamble | SFD | DA | SA | [VLAN] | ET |
  // payload | FCS, with error-injection mutations.
  virtual function void build_frame(eth_avb_tsn_transaction txn, ref bit [7:0] bytes[$]);
    bit [31:0] fcs;
    bit [7:0]  body[$];
    bytes.delete();
    for (int i = 0; i < 7; i++) bytes.push_back(8'h55);   // preamble
    bytes.push_back(8'hD5);                                // SFD
    body.delete();
    for (int i = 5; i >= 0; i--) body.push_back(txn.dst_addr[i*8 +: 8]);
    for (int i = 5; i >= 0; i--) body.push_back(txn.src_addr[i*8 +: 8]);
    if (txn.vid != 0) begin                                 // 802.1Q tag
      body.push_back(8'h81); body.push_back(8'h00);
      body.push_back({txn.pcp, txn.cfi, txn.vid[11:8]});
      body.push_back(txn.vid[7:0]);
    end
    body.push_back(txn.ethertype[15:8]);
    body.push_back(txn.ethertype[7:0]);
    for (int i = 0; i < txn.payload.size(); i++)
      body.push_back(txn.payload[i]);
    fcs = eth_crc32(body);
    if (txn.fcs_error || txn.with_error || txn.alignment_error)
      fcs = fcs ^ 32'hA5A5_5A5A;                            // corrupt FCS
    foreach (body[i]) bytes.push_back(body[i]);
    for (int i = 0; i < 4; i++) bytes.push_back(fcs[i*8 +: 8]);
    if (txn.length_error) begin
      // runt: truncate below the 64-byte minimum frame
      while (bytes.size() > 30) void'(bytes.pop_back());
    end else if (txn.jabber_error) begin
      // jabber: extend well beyond the 1522-byte maximum
      while (bytes.size() < 1600) bytes.push_back(8'hAA);
    end
  endfunction

  // Present one beat and hold it until the DUT accepts it (rx_valid &&
  // rx_ready at a clock edge, both as sampled by the clocking block). While
  // the 802.1Qbv gate is closed the switch holds rx_ready low; after
  // cfg.gate_closed_cycles the gate control list advances and opens it.
  task send_beat(logic [63:0] beat, int n, bit sof, bit eof, bit smd);
    int waited = 0;
    // Pins change on the falling edge and the DUT/monitor sample them on the
    // rising edge. A clocking-block drive issued right after the clocking
    // event lands in that same time step under Verilator, so the switch
    // model could take the next beat (or valid low) at the edge that was
    // meant to accept the current one.
    @(negedge vif.clk);
    vif.rx_data_valid = 8'hFF >> (8 - n);
    vif.rx_data       = beat;
    vif.rx_sof        = sof;      // rx_preamble aliases rx_sof
    vif.rx_eof        = eof;
    vif.smd           = smd;
    vif.fcs_error     = eof && cur_bad_fcs;
    forever begin
      @(posedge vif.clk);
      if (vif.rx_ready === 1'b1) break;     // accepted at this edge
      if (++waited == cfg.gate_closed_cycles) begin
        @(negedge vif.clk);
        vif.gate_states = 8'hFF;
      end
    end
  endtask

  // Idle the ingress pins on the falling edge after the last accepted beat
  task idle_rx();
    @(negedge vif.clk);
    vif.rx_data_valid = '0;
    vif.rx_sof        = 1'b0;
    vif.rx_eof        = 1'b0;
    vif.smd           = 1'b0;
    vif.fcs_error     = 1'b0;
  endtask

  task drive_txn(eth_avb_tsn_transaction txn);
    bit [7:0] bytes[$];
    int idx;
    int frag_len;
    bit fragmented;

    `uvm_info("DRIVER", $sformatf("Driving frame: %s", txn.convert2string()), UVM_MEDIUM)

    build_frame(txn, bytes);
    cur_bad_fcs = txn.fcs_error || txn.with_error || txn.alignment_error;

    // AVB/TSN sideband for this frame; SR class A/B is encoded 1/2 (0 = none)
    vif.frame_type        <= txn.frame_type;
    vif.dst_addr          <= txn.dst_addr;
    vif.src_addr          <= txn.src_addr;
    vif.ethertype         <= txn.ethertype;
    vif.vlan_tci          <= {txn.pcp, txn.cfi, txn.vid};
    vif.cfi               <= txn.cfi;
    vif.stream_id         <= txn.stream_id;
    vif.sr_class          <= (txn.sr_class == 65) ? 8'd1 : (txn.sr_class == 66) ? 8'd2 : 8'd0;
    vif.vid               <= txn.vid;
    vif.pcp               <= txn.pcp;
    vif.sequence_num      <= txn.sequence_num;
    vif.stream_handle     <= txn.stream_handle;
    vif.duplicate         <= txn.duplicate;
    vif.presentation_time <= {32'h0, txn.presentation_time[31:0]};
    vif.preemptable       <= txn.preemptable;
    vif.express           <= txn.express;
    vif.frag_last         <= txn.frag_last;
    vif.length_error      <= txn.length_error;
    vif.jabber_error      <= txn.jabber_error;
    vif.alignment_error   <= txn.alignment_error;
    vif.gate_states       <= txn.gate_states;
    vif.gate_control_list_valid <= (txn.frame_type == eth_avb_tsn_transaction::TSN_TIME_TRIGGERED);
    vif.cycle_time        <= txn.cycle_time;

    // Frame preemption (802.3br): split a preemptable frame into two
    // fragments with SMD markers at the fragment boundary.
    frag_len   = bytes.size();
    fragmented = cfg.preemption_enabled && txn.preemptable && bytes.size() > 128;
    if (fragmented)
      frag_len = 64 + ($urandom_range(0, (bytes.size() - 129) / 8) * 8);
    vif.frag_count <= fragmented ? 6'd2 : 6'(txn.frag_count);

    @(posedge vif.clk);
    idx = 0;
    while (idx < bytes.size()) begin
      logic [63:0] beat;
      int n;
      int limit;
      bit sof;
      beat  = '0;
      limit = (fragmented && idx < frag_len) ? frag_len : bytes.size();
      n = (limit - idx < 8) ? (limit - idx) : 8;
      for (int j = 0; j < n; j++)
        beat[j*8 +: 8] = bytes[idx + j];
      sof = (idx == 0);
      // SMD marker on the first beat of each fragment (SMD-S / SMD-C)
      send_beat(beat, n, sof, idx + n >= bytes.size(),
                fragmented && (sof || idx == frag_len));
      idx += n;
      if (fragmented && idx == frag_len) begin
        // fragment boundary: inter-fragment gap, then continuation
        idle_rx();
        repeat (2) @(posedge vif.clk);
      end
    end
    idle_rx();
    // inter-frame gap
    repeat (2) @(posedge vif.clk);

    drv_ap.write(txn);   // broadcast expected transaction
  endtask

  task drive_ptp(eth_avb_tsn_transaction txn);
    // gPTP timing is driven by the DUT clock model; forward a PTP frame
    drive_txn(txn);
  endtask

  task drive_avb_stream(eth_avb_tsn_transaction txn);
    // AVB streaming with rate control
    drive_txn(txn);
    #(1us);   // AVB rate limit
  endtask
endclass
`endif
