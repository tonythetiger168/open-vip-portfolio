// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_driver.svh

class eth_avb_tsn_driver extends uvm_driver #(eth_avb_tsn_transaction);
  `uvm_component_utils(eth_avb_tsn_driver)
  virtual eth_avb_tsn_if vif;
  eth_avb_tsn_config cfg;
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual eth_avb_tsn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ETH AVB/TSN virtual interface not found")
    if (!uvm_config_db#(eth_avb_tsn_config)::get(this, "", "cfg", cfg))
      cfg = eth_avb_tsn_config::type_id::create("cfg");
  endfunction
  task run_phase(uvm_phase phase);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      seq_item_port.item_done();
    end
  endtask
  task drive_item(eth_avb_tsn_transaction tx);
    `uvm_info("ETH_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)
    vif.drv_cb.rx_ready <= 1;
    vif.drv_cb.tx_ready <= 1;
    vif.drv_cb.gate_control_list_valid <= 1;
    vif.drv_cb.gate_states <= tx.gate_states;
    vif.drv_cb.cycle_time <= tx.cycle_time;
    // Drive RX preamble + SFD
    vif.drv_cb.rx_data <= 64'hD555555555555555;
    vif.drv_cb.rx_data_valid <= 8'hFF;
    vif.drv_cb.rx_sof <= 1;
    @(vif.drv_cb);
    vif.drv_cb.rx_sof <= 0;
    repeat (tx.payload_len / 8 + 2) @(vif.drv_cb);
    vif.drv_cb.rx_eof <= 1;
    @(vif.drv_cb);
    vif.drv_cb.rx_eof <= 0;
  endtask
endclass
