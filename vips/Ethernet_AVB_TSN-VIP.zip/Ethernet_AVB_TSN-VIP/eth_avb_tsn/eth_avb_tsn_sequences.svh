// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_sequences.svh

class eth_avb_tsn_base_sequence extends uvm_sequence #(eth_avb_tsn_transaction);
  `uvm_object_utils(eth_avb_tsn_base_sequence)
  function new(string name = "eth_avb_tsn_base_sequence");
    super.new(name);
  endfunction
endclass

class eth_avb_tsn_random_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_avb_tsn_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "eth_avb_tsn_random_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "ETH AVB/TSN tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_avb_stream_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_avb_stream_sequence)
  rand int num_txns = 50;
  function new(string name = "eth_avb_stream_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type == eth_avb_tsn_transaction::AVB_STREAM; pcp >= 3; })
        `uvm_error("RANDFAIL", "AVB stream randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_tsn_preempt_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_tsn_preempt_sequence)
  rand int num_txns = 30;
  function new(string name = "eth_tsn_preempt_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type == eth_avb_tsn_transaction::TSN_PREEMPT; preemptable == 1; frag_count >= 2; })
        `uvm_error("RANDFAIL", "TSN preempt randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_ptp_sync_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_ptp_sync_sequence)
  rand int num_txns = 20;
  function new(string name = "eth_ptp_sync_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type == eth_avb_tsn_transaction::PTP_SYNC; dst_addr[47:24] == 24'h0180C2; })
        `uvm_error("RANDFAIL", "PTP sync randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_vlan_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_vlan_sequence)
  rand int num_txns = 30;
  function new(string name = "eth_vlan_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { vid inside {[1:4094]}; ethertype == 16'h8100; })
        `uvm_error("RANDFAIL", "VLAN randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_error_inject_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_error_inject_sequence)
  rand int num_txns = 20;
  function new(string name = "eth_error_inject_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { with_error == 1; fcs_error == 1; })
        `uvm_error("RANDFAIL", "ETH error inject randomization failed")
      finish_item(tx);
    end
  endtask
endclass
