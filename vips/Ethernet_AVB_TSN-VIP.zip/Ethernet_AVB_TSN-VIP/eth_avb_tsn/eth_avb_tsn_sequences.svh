// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_sequences.svh

class eth_avb_tsn_base_sequence extends uvm_sequence #(eth_avb_tsn_transaction);
  `uvm_object_utils(eth_avb_tsn_base_sequence)
  function new(string name = "eth_avb_tsn_base_sequence");
    super.new(name);
  endfunction
endclass

class eth_avb_tsn_random_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_avb_tsn_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "eth_avb_tsn_random_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "ETH AVB/TSN tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_avb_stream_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_avb_stream_sequence)
  rand int num_txns = 50;
  function new(string name = "eth_avb_stream_sequence");
    super.new(name);
  endfunction
  // One talker stream: a fixed stream ID and consecutive sequence numbers
  task body();
    eth_avb_tsn_transaction tx;
    bit [31:0] sid = $urandom_range(32'h7FFF_FFFF, 1);
    bit [15:0] seq_no = $urandom;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type == eth_avb_tsn_transaction::AVB_STREAM; pcp >= 3;
                                 stream_id == sid; sequence_num == seq_no; })
        `uvm_error("RANDFAIL", "AVB stream randomization failed")
      finish_item(tx);
      seq_no++;
    end
  endtask
endclass

class eth_tsn_preempt_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_tsn_preempt_sequence)
  rand int num_txns = 30;
  function new(string name = "eth_tsn_preempt_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type == eth_avb_tsn_transaction::TSN_PREEMPT; preemptable == 1; frag_count >= 2; })
        `uvm_error("RANDFAIL", "TSN preempt randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_ptp_sync_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_ptp_sync_sequence)
  rand int num_txns = 20;
  function new(string name = "eth_ptp_sync_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type == eth_avb_tsn_transaction::PTP_SYNC; dst_addr[47:24] == 24'h0180C2; })
        `uvm_error("RANDFAIL", "PTP sync randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_vlan_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_vlan_sequence)
  rand int num_txns = 30;
  function new(string name = "eth_vlan_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { vid inside {[1:4094]}; })
        `uvm_error("RANDFAIL", "VLAN randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class eth_error_inject_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_error_inject_sequence)
  rand int num_txns = 20;
  function new(string name = "eth_error_inject_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { with_error == 1; fcs_error == 1; })
        `uvm_error("RANDFAIL", "ETH error inject randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Directed: minimum-gap back-to-back frames (stress)
// ---------------------------------------------------------------------------
class eth_back_to_back_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_back_to_back_sequence)
  rand int num_txns = 30;
  function new(string name = "eth_back_to_back_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        payload_len inside {[46:128]};
        with_error == 0; fcs_error == 0; length_error == 0; jabber_error == 0;
      }) `uvm_error("RANDFAIL", "ETH b2b randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Corner: maximum-length frames (1500-byte payload, MTU boundary)
// ---------------------------------------------------------------------------
class eth_max_frame_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_max_frame_sequence)
  rand int num_txns = 8;
  function new(string name = "eth_max_frame_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        payload_len == 1500;
        with_error == 0; fcs_error == 0; length_error == 0; jabber_error == 0;
      }) `uvm_error("RANDFAIL", "ETH max-frame randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Corner: minimum-length frames (46-byte payload, 64-byte frame boundary)
// ---------------------------------------------------------------------------
class eth_min_frame_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_min_frame_sequence)
  rand int num_txns = 8;
  function new(string name = "eth_min_frame_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        payload_len == 46;
        with_error == 0; fcs_error == 0; length_error == 0; jabber_error == 0;
      }) `uvm_error("RANDFAIL", "ETH min-frame randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Reset behavior: single frame issued right after reset release
// ---------------------------------------------------------------------------
class eth_reset_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_reset_sequence)
  function new(string name = "eth_reset_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    tx = eth_avb_tsn_transaction::type_id::create("tx");
    start_item(tx);
    if (!tx.randomize() with {
      payload_len == 64;
      with_error == 0; fcs_error == 0; length_error == 0; jabber_error == 0;
    }) `uvm_error("RANDFAIL", "ETH reset randomization failed")
    finish_item(tx);
  endtask
endclass

// ---------------------------------------------------------------------------
// Directed: TSN time-triggered traffic with gate-control state sweeps
// ---------------------------------------------------------------------------
class eth_gate_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_gate_sequence)
  rand int num_txns = 16;
  function new(string name = "eth_gate_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_transaction tx;
    repeat (num_txns) begin
      tx = eth_avb_tsn_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        frame_type == TSN_TIME_TRIGGERED;
        gate_states inside {8'h00, 8'h01, 8'h03, 8'h0F, 8'hFF};
        cycle_time inside {[125000:1000000]};
        with_error == 0; fcs_error == 0; length_error == 0; jabber_error == 0;
      }) `uvm_error("RANDFAIL", "ETH gate randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Coverage closure: directed sweeps over frame type x PCP x preemption,
// tag x error, gate state x frame type, fragment counts and payload sizes.
// Item fields are set through inline constraints on short frames.
// ---------------------------------------------------------------------------
class eth_cov_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_cov_sequence)
  function new(string name = "eth_cov_sequence");
    super.new(name);
  endfunction

  task send(eth_avb_tsn_transaction::eth_frame_type_e t, int p, bit pre,
            bit tag_on, bit err, bit [7:0] gate, int len, int frag = -1);
    eth_avb_tsn_transaction tx = eth_avb_tsn_transaction::type_id::create("tx");
    if (t == eth_avb_tsn_transaction::AVB_STREAM) tag_on = 1;   // SR streams are tagged
    start_item(tx);
    if (!tx.randomize() with {
          frame_type == t; pcp == p; payload_len == len;
          (t != eth_avb_tsn_transaction::TSN_PREEMPT) -> preemptable == pre;
          tag_on -> vid != 0; !tag_on -> vid == 0;
          with_error == err; fcs_error == err;
          gate_states == gate;
          (frag >= 0) -> frag_count == frag;
        }) `uvm_error("RANDFAIL", "coverage item randomization failed")
    finish_item(tx);
  endtask

  task body();
    eth_avb_tsn_transaction::eth_frame_type_e t;
    bit [7:0] gates[5] = '{8'h00, 8'h01, 8'h03, 8'h0F, 8'hFF};
    int pcps[3] = '{1, 4, 6};
    int lens[4] = '{46, 100, 600, 1200};
    // frame type x PCP x preemption (types in enum order, so the
    // STANDARD->AVB and AVB->TIME_TRIGGERED transitions are taken)
    for (int i = 0; i <= 6; i++)
      foreach (pcps[k])
        for (int pre = 0; pre < 2; pre++) begin
          t = eth_avb_tsn_transaction::eth_frame_type_e'(i);
          if (t == eth_avb_tsn_transaction::AVB_STREAM && pcps[k] < 3) continue;
          send(t, pcps[k], pre, 1, 0, 8'hFF, 46 + 8 * k);   // tagged: PCP is on the wire
        end
    send(eth_avb_tsn_transaction::STANDARD_ETH, 0, 0, 0, 0, 8'hFF, 46);
    send(eth_avb_tsn_transaction::PTP_SYNC, 0, 0, 0, 0, 8'hFF, 46);   // STANDARD->PTP
    // tag x error
    for (int tg = 0; tg < 2; tg++)
      for (int e = 0; e < 2; e++)
        send(eth_avb_tsn_transaction::STANDARD_ETH, 2, 0, tg, e, 8'hFF, 64);
    // gate state x frame class
    foreach (gates[g]) begin
      send(eth_avb_tsn_transaction::STANDARD_ETH,       0, 0, 0, 0, gates[g], 46);
      send(eth_avb_tsn_transaction::AVB_STREAM,         5, 0, 0, 0, gates[g], 46);
      send(eth_avb_tsn_transaction::TSN_TIME_TRIGGERED, 6, 0, 0, 0, gates[g], 46);
      send(eth_avb_tsn_transaction::PTP_SYNC,           7, 0, 0, 0, gates[g], 46);
    end
    // fragment counts on short (unfragmented) preemptable frames, then a
    // long frame the driver splits into two 802.3br fragments
    send(eth_avb_tsn_transaction::TSN_PREEMPT, 1, 1, 0, 0, 8'hFF, 46, 3);
    send(eth_avb_tsn_transaction::TSN_PREEMPT, 1, 1, 0, 0, 8'hFF, 46, 40);
    send(eth_avb_tsn_transaction::TSN_PREEMPT, 1, 1, 0, 0, 8'hFF, 600);
    // payload sizes
    foreach (lens[l])
      send(eth_avb_tsn_transaction::STANDARD_ETH, 3, 0, 0, 0, 8'hFF, lens[l]);
    send(eth_avb_tsn_transaction::STANDARD_ETH, 3, 0, 0, 0, 8'hFF, 1500);
  endtask
endclass

// ---------------------------------------------------------------------------
// Regression: weighted mix of every directed sequence
// ---------------------------------------------------------------------------
class eth_regression_sequence extends eth_avb_tsn_base_sequence;
  `uvm_object_utils(eth_regression_sequence)
  rand int num_txns = 40;
  function new(string name = "eth_regression_sequence");
    super.new(name);
  endfunction
  task body();
    eth_avb_tsn_random_sequence rnd_seq;
    eth_avb_stream_sequence   avb_seq;
    eth_tsn_preempt_sequence  pmt_seq;
    eth_vlan_sequence         vlan_seq;
    eth_back_to_back_sequence b2b_seq;
    eth_max_frame_sequence    max_seq;
    eth_min_frame_sequence    min_seq;
    eth_gate_sequence         gate_seq;
    eth_error_inject_sequence err_seq;

    rnd_seq = eth_avb_tsn_random_sequence::type_id::create("rnd_seq");
    rnd_seq.num_txns = num_txns / 4;
    rnd_seq.start(m_sequencer);

    avb_seq = eth_avb_stream_sequence::type_id::create("avb_seq");
    avb_seq.num_txns = num_txns / 8 + 1;
    avb_seq.start(m_sequencer);

    pmt_seq = eth_tsn_preempt_sequence::type_id::create("pmt_seq");
    pmt_seq.num_txns = 4;
    pmt_seq.start(m_sequencer);

    vlan_seq = eth_vlan_sequence::type_id::create("vlan_seq");
    vlan_seq.num_txns = num_txns / 8 + 1;
    vlan_seq.start(m_sequencer);

    b2b_seq = eth_back_to_back_sequence::type_id::create("b2b_seq");
    b2b_seq.num_txns = num_txns / 4;
    b2b_seq.start(m_sequencer);

    max_seq = eth_max_frame_sequence::type_id::create("max_seq");
    max_seq.num_txns = 4;
    max_seq.start(m_sequencer);

    min_seq = eth_min_frame_sequence::type_id::create("min_seq");
    min_seq.num_txns = 4;
    min_seq.start(m_sequencer);

    gate_seq = eth_gate_sequence::type_id::create("gate_seq");
    gate_seq.num_txns = 8;
    gate_seq.start(m_sequencer);

    err_seq = eth_error_inject_sequence::type_id::create("err_seq");
    err_seq.num_txns = 4;
    err_seq.start(m_sequencer);
  endtask
endclass
