// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_checker.svh

class eth_avb_tsn_checker extends protocol_checker_base;
  `uvm_component_utils(eth_avb_tsn_checker)
  uvm_analysis_imp #(eth_avb_tsn_transaction, eth_avb_tsn_checker) analysis_export;
  eth_avb_tsn_config cfg;
  int tx_count = 0;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(eth_avb_tsn_config)::get(this, "", "cfg", cfg))
      cfg = eth_avb_tsn_config::type_id::create("cfg");
  endfunction
  function void write(eth_avb_tsn_transaction tx);
    tx_count++;
    check_dst_addr(tx);
    check_src_addr(tx);
    check_payload_len(tx);
    check_ethertype(tx);
    check_vlan(tx);
    check_avb(tx);
    check_tsn_preempt(tx);
    check_fcs(tx);
    check_psfp(tx);
    check_pcp(tx);
  endfunction
  function void check_dst_addr(eth_avb_tsn_transaction tx);
    if (tx.dst_addr == 48'h0)
      check_protocol_error("Destination address is all zeros");
    if (tx.dst_addr[0] == 1'b1 && tx.dst_addr[47:24] != 24'h0180C2)
      check_protocol_warning("Multicast address outside IANA range");
  endfunction
  function void check_src_addr(eth_avb_tsn_transaction tx);
    if (tx.src_addr[0] == 1'b1)
      check_protocol_error("Source address is multicast");
  endfunction
  function void check_payload_len(eth_avb_tsn_transaction tx);
    if (tx.payload_len < 46 && !tx.length_error)
      check_protocol_warning($sformatf("Payload %0d < 46 bytes (min Ethernet)", tx.payload_len));
    if (tx.payload_len > cfg.max_frame_size && !tx.jabber_error)
      check_protocol_warning($sformatf("Payload %0d > %0d bytes", tx.payload_len, cfg.max_frame_size));
  endfunction
  function void check_ethertype(eth_avb_tsn_transaction tx);
    if (tx.frame_type == eth_avb_tsn_transaction::AVB_STREAM && tx.ethertype != 16'h22F0)
      check_protocol_error($sformatf("AVB stream with wrong ethertype 0x%0x (expected 0x22F0)", tx.ethertype));
    if (tx.frame_type == eth_avb_tsn_transaction::PTP_SYNC && tx.ethertype != 16'h88F7)
      check_protocol_error($sformatf("PTP sync with wrong ethertype 0x%0x (expected 0x88F7)", tx.ethertype));
  endfunction
  function void check_vlan(eth_avb_tsn_transaction tx);
    if (tx.vid > 4094 && tx.vid != 4095)
      check_protocol_error($sformatf("Invalid VLAN ID %0d", tx.vid));
  endfunction
  function void check_avb(eth_avb_tsn_transaction tx);
    if (tx.frame_type == eth_avb_tsn_transaction::AVB_STREAM) begin
      if (tx.sr_class != 65 && tx.sr_class != 66)
        check_protocol_error($sformatf("Invalid SR class %0d (expected 65='A' or 66='B')", tx.sr_class));
      if (tx.pcp < 3)
        check_protocol_warning($sformatf("AVB stream with low PCP %0d", tx.pcp));
    end
  endfunction
  function void check_tsn_preempt(eth_avb_tsn_transaction tx);
    if (tx.preemptable && tx.express)
      check_protocol_error("Frame marked as both preemptable and express");
    if (tx.frame_type == eth_avb_tsn_transaction::TSN_PREEMPT && tx.frag_count == 0)
      check_protocol_warning("Preempted frame with zero fragment count");
  endfunction
  function void check_fcs(eth_avb_tsn_transaction tx);
    if (tx.fcs_error)
      check_protocol_error("FCS error detected");
  endfunction
  function void check_psfp(eth_avb_tsn_transaction tx);
    if (cfg.psfp_enabled && tx.stream_handle == 0 && tx.frame_type inside {eth_avb_tsn_transaction::AVB_STREAM, eth_avb_tsn_transaction::TSN_TIME_TRIGGERED})
      check_protocol_warning("PSFP enabled but stream handle is zero");
  endfunction
  function void check_pcp(eth_avb_tsn_transaction tx);
    if (tx.pcp > 7)
      check_protocol_error($sformatf("PCP %0d > 7", tx.pcp));
  endfunction
  task run_phase(uvm_phase phase); endtask
  function void report_phase(uvm_phase phase);
    `uvm_info("ETH_CHK", $sformatf("Checked %0d transactions, %0d errors, %0d warnings",
      tx_count, error_count, warning_count), UVM_LOW)
  endfunction
endclass
