// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_config.svh

class eth_avb_tsn_config extends uvm_object;
  `uvm_object_utils(eth_avb_tsn_config)
  bit enable_checker  = 1;
  bit enable_coverage = 1;
  bit avb_enabled     = 1;
  bit tsn_enabled     = 1;
  bit preemption_enabled = 1;
  bit psfp_enabled    = 1;
  bit frer_enabled    = 1;
  int max_frame_size  = 1522;  // max without jumbo
  int min_frame_size  = 64;
  int jumbo_frame_size = 9000;
  int num_sr_classes  = 2;     // A and B
  int num_gate_states = 8;
  bit [47:0] multicast_base = 48'h0180C2000000;
  function new(string name = "eth_avb_tsn_config");
    super.new(name);
  endfunction
endclass
