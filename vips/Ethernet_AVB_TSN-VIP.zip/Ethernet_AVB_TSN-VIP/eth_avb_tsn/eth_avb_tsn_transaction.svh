// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_transaction.svh

class eth_avb_tsn_transaction extends uvm_sequence_item;
  `uvm_object_utils(eth_avb_tsn_transaction)

  typedef enum bit [2:0] {
    STANDARD_ETH = 3'd0,
    AVB_STREAM   = 3'd1,
    TSN_TIME_TRIGGERED = 3'd2,
    TSN_PREEMPT  = 3'd3,
    TSN_CUT_THROUGH = 3'd4,
    PTP_SYNC     = 3'd5,
    DIAGNOSTIC   = 3'd6,
    RESERVED     = 3'd7
  } eth_frame_type_e;

  rand eth_frame_type_e frame_type;
  rand bit [47:0]  dst_addr;
  rand bit [47:0]  src_addr;
  rand bit [15:0]  ethertype;
  rand bit [11:0]  vid;
  rand bit [2:0]   pcp;
  rand bit         cfi;
  rand bit [15:0]  payload_len;
  rand bit [7:0]   payload[];
  rand bit [31:0]  fcs;
  // AVB
  rand bit [31:0]  stream_id;
  rand bit [63:0]  presentation_time;
  rand bit [7:0]   sr_class;
  // TSN
  rand bit         preemptable;
  rand bit         express;
  rand bit [5:0]   frag_count;
  rand bit         frag_last;
  rand bit [31:0]  cycle_time;
  rand bit [7:0]   gate_states;
  // PSFP / FRER
  rand bit [15:0]  stream_handle;
  rand bit [15:0]  sequence_num;
  rand bit         duplicate;
  // Errors
  rand bit         with_error;
  rand bit         fcs_error;
  rand bit         jabber_error;
  rand bit         alignment_error;
  rand bit         length_error;

  constraint c_dst_addr {
    dst_addr != 48'h0;
    if (frame_type == PTP_SYNC) dst_addr[47:24] == 24'h0180C2;
  }
  constraint c_ethertype {
    if (frame_type == AVB_STREAM) ethertype == 16'h22F0;
    else if (frame_type == PTP_SYNC) ethertype == 16'h88F7;
    else if (vid != 0) ethertype == 16'h8100;
    else ethertype inside {16'h0800, 16'h0806, 16'h86DD, 16'h8847, 16'h8906};
  }
  constraint c_payload_len {
    payload_len inside {[46:1522]};
    payload.size() == payload_len;
  }
  constraint c_pcp {
    if (frame_type == AVB_STREAM) pcp inside {[3:7]};
    else pcp inside {[0:7]};
  }
  constraint c_vid { vid inside {[0:4094]}; }
  constraint c_sr_class {
    if (frame_type == AVB_STREAM) sr_class inside {65, 66}; // 'A' or 'B'
    else sr_class == 0;
  }
  constraint c_preemption {
    if (frame_type == TSN_PREEMPT) { preemptable == 1; express == 0; }
    else if (preemptable == 1) express == 0;
  }
  constraint c_frag {
    if (frame_type == TSN_PREEMPT) { frag_count inside {[1:63]}; frag_last dist {0:=20, 1:=80}; }
    else { frag_count == 0; frag_last == 0; }
  }
  constraint c_sequence {
    if (frame_type inside {AVB_STREAM, TSN_TIME_TRIGGERED}) sequence_num inside {[0:65535]};
  }
  constraint c_error {
    with_error dist {0:=95, 1:=5};
    fcs_error       dist {0:=98, 1:=2};
    jabber_error    dist {0:=98, 1:=2};
    alignment_error dist {0:=98, 1:=2};
    length_error    dist {0:=98, 1:=2};
  }

  function new(string name = "eth_avb_tsn_transaction");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("ETH: type=%s dst=0x%0x src=0x%0x eth=0x%0x vid=%0d pcp=%0d len=%0d avb=%b tsn=%b preempt=%b seq=%0d err=%b",
      frame_type.name(), dst_addr, src_addr, ethertype, vid, pcp, payload_len,
      (frame_type==AVB_STREAM), (frame_type inside {TSN_TIME_TRIGGERED, TSN_PREEMPT}),
      preemptable, sequence_num, with_error);
  endfunction
endclass
