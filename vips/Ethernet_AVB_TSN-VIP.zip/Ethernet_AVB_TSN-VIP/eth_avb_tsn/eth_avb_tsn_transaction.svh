// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// eth_avb_tsn_transaction.svh

class eth_avb_tsn_transaction extends uvm_sequence_item;
  `uvm_object_utils(eth_avb_tsn_transaction)

  typedef enum bit [2:0] {
    STANDARD_ETH = 3'd0,
    AVB_STREAM   = 3'd1,
    TSN_TIME_TRIGGERED = 3'd2,
    TSN_PREEMPT  = 3'd3,
    TSN_CUT_THROUGH = 3'd4,
    PTP_SYNC     = 3'd5,
    DIAGNOSTIC   = 3'd6,
    RESERVED     = 3'd7
  } eth_frame_type_e;

  rand eth_frame_type_e frame_type;
  rand bit [47:0]  dst_addr;
  rand bit [47:0]  src_addr;
  rand bit [15:0]  ethertype;
  rand bit [11:0]  vid;
  rand bit [2:0]   pcp;
  rand bit         cfi;
  rand bit [15:0]  payload_len;
  rand bit [7:0]   payload[];
  rand bit [31:0]  fcs;
  // AVB
  rand bit [31:0]  stream_id;
  rand bit [63:0]  presentation_time;
  rand bit [7:0]   sr_class;
  // TSN
  rand bit         preemptable;
  rand bit         express;
  rand bit [5:0]   frag_count;
  rand bit         frag_last;
  rand bit [31:0]  cycle_time;
  rand bit [7:0]   gate_states;
  // PSFP / FRER
  rand bit [15:0]  stream_handle;
  rand bit [15:0]  sequence_num;
  rand bit         duplicate;
  // Errors
  rand bit         with_error;
  rand bit         fcs_error;
  rand bit         jabber_error;
  rand bit         alignment_error;
  rand bit         length_error;

  // Address bit 40 is the I/G bit (LSB of the first octet on the wire).
  // gPTP uses the 01-80-C2-00-00-0E multicast; other traffic is unicast.
  constraint c_dst_addr {
    dst_addr != 48'h0;
    if (frame_type == PTP_SYNC) dst_addr == 48'h0180C200000E;
    else dst_addr[40] == 1'b0;
  }
  constraint c_src_addr {
    src_addr != 48'h0;
    src_addr[40] == 1'b0;
  }
  // ethertype is the type after the optional 802.1Q tag (the driver
  // inserts the 0x8100 TPID itself when vid != 0)
  constraint c_ethertype {
    if (frame_type == AVB_STREAM) ethertype == 16'h22F0;
    else if (frame_type == PTP_SYNC) ethertype == 16'h88F7;
    else ethertype inside {16'h0800, 16'h0806, 16'h86DD, 16'h8847, 16'h8906};
  }
  // 802.3 payload: 46..1500 bytes (1500 + 18-byte tagged header + FCS
  // stays inside the 1522-byte maximum)
  constraint c_payload_len {
    payload_len inside {[46:1500]};
    payload.size() == payload_len;
  }
  constraint c_stream {
    if (frame_type != AVB_STREAM) stream_id == 0;
    else stream_id != 0;
  }
  // gate vectors of the 802.1Qbv control list used by the tests
  constraint c_gate { gate_states dist {8'h00 := 1, 8'h01 := 2, 8'h03 := 2, 8'h0F := 2, 8'hFF := 8}; }
  constraint c_cycle_time { cycle_time inside {[1000:1000000]}; }
  constraint c_pcp {
    if (frame_type == AVB_STREAM) pcp inside {[3:7]};
    else pcp inside {[0:7]};
  }
  // half untagged; SR-class streams always carry the 802.1Q tag (PCP).
  // A plain rand bit picks tagged/untagged: Verilator draws a dist value
  // before solving, so "vid dist {0, ...}" failed every randomize() that
  // also needed vid != 0 (AVB streams, tagged-frame sequences).
  rand bit vid_tag;
  constraint c_vid {
    vid_tag  -> vid inside {[1:4094]};
    !vid_tag -> vid == 0;
    (frame_type == AVB_STREAM) -> vid_tag;
  }
  constraint c_sr_class {
    if (frame_type == AVB_STREAM) sr_class inside {65, 66}; // 'A' or 'B'
    else sr_class == 0;
  }
  constraint c_preemption {
    if (frame_type == TSN_PREEMPT) { preemptable == 1; express == 0; }
    else if (preemptable == 1) express == 0;
  }
  constraint c_frag {
    if (frame_type == TSN_PREEMPT) { frag_count inside {[1:63]}; frag_last dist {0:=20, 1:=80}; }
    else { frag_count == 0; frag_last == 0; }
  }
  constraint c_sequence {
    if (frame_type inside {AVB_STREAM, TSN_TIME_TRIGGERED}) sequence_num inside {[0:65535]};
  }
  // Errors are injected only when a sequence asks for them
  constraint c_error {
    soft with_error == 0;
    soft fcs_error == 0;
    soft jabber_error == 0;
    soft alignment_error == 0;
    soft length_error == 0;
  }

  function new(string name = "eth_avb_tsn_transaction");
    super.new(name);
  endfunction

  // Some solvers leave the dynamic array unsized even though the
  // constraint ties its size to payload_len; size and fill it here
  function void post_randomize();
    if (payload.size() != payload_len) begin
      payload = new[payload_len];
      foreach (payload[i]) payload[i] = 8'($urandom);
    end
  endfunction

  function string convert2string();
    return $sformatf("ETH: type=%s dst=0x%0x src=0x%0x eth=0x%0x vid=%0d pcp=%0d len=%0d avb=%b tsn=%b preempt=%b seq=%0d err=%b",
      frame_type.name(), dst_addr, src_addr, ethertype, vid, pcp, payload_len,
      (frame_type==AVB_STREAM), (frame_type inside {TSN_TIME_TRIGGERED, TSN_PREEMPT}),
      preemptable, sequence_num, with_error);
  endfunction
endclass
