// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AMBA Tests (AHB5 deepened: each test launches a directed AHB sequence)
//============================================================================
`ifndef AMBA_TESTS_SV
`define AMBA_TESTS_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import amba_vip_pkg::*;

class amba_base_test extends uvm_test;
  `uvm_component_utils(amba_base_test)
  amba_env env;
  function new(string name = "amba_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = amba_env::type_id::create("env", this);
  endfunction
  virtual task run_phase(uvm_phase phase);
    ahb_base_sequence seq = ahb_base_sequence::type_id::create("seq");
    phase.raise_objection(this);
    seq.start(env.agt.sqr);
    #1000ns;
    phase.drop_objection(this);
  endtask
endclass

// Regression mix of all directed AHB sequences
class amba_axi_test extends amba_base_test;
  `uvm_component_utils(amba_axi_test)
  function new(string name = "amba_axi_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    ahb_regression_sequence seq = ahb_regression_sequence::type_id::create("seq");
    phase.raise_objection(this);
    seq.start(env.agt.sqr);
    #2000ns;
    phase.drop_objection(this);
  endtask
endclass

// Back-to-back + burst stress
class amba_ahb_test extends amba_base_test;
  `uvm_component_utils(amba_ahb_test)
  function new(string name = "amba_ahb_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    ahb_incr_burst_seq   inc = ahb_incr_burst_seq::type_id::create("inc");
    ahb_back_to_back_seq b2b = ahb_back_to_back_seq::type_id::create("b2b");
    ahb_wrap_burst_seq   wrp = ahb_wrap_burst_seq::type_id::create("wrp");
    phase.raise_objection(this);
    inc.start(env.agt.sqr);
    wrp.start(env.agt.sqr);
    b2b.start(env.agt.sqr);
    #2000ns;
    phase.drop_objection(this);
  endtask
endclass

// Error-injection (HRESP ERROR region) + reset behavior
class amba_apb_test extends amba_base_test;
  `uvm_component_utils(amba_apb_test)
  function new(string name = "amba_apb_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    ahb_error_inject_seq err = ahb_error_inject_seq::type_id::create("err");
    ahb_reset_seq        rst = ahb_reset_seq::type_id::create("rst");
    phase.raise_objection(this);
    err.start(env.agt.sqr);
    rst.start(env.agt.sqr);
    #2000ns;
    phase.drop_objection(this);
  endtask
endclass
// UVM RAL: built-in register/memory sequences plus directed frontdoor checks
// against the model in env/amba_reg_model.sv.
//   1. uvm_reg_hw_reset_seq  -- every register reads its reset value
//   2. uvm_reg_bit_bash_seq  -- every bit of every RW register writes 0/1 and reads back
//   3. uvm_mem_walk_seq      -- walking write/read over every MEM word
//   4. random write + mirror(UVM_CHECK) on every register, random MEM
//      write/read round trips
//   5. ERR_PROBE (error region) write and read return UVM_NOT_OK
// Prints "RAL_PASS checks=<n>" when no UVM_ERROR/UVM_FATAL was reported.
class amba_ral_test extends amba_base_test;
  `uvm_component_utils(amba_ral_test)
  int unsigned checks;
  function new(string name = "amba_ral_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual task run_phase(uvm_phase phase);
    uvm_reg_hw_reset_seq rst_seq;
    uvm_reg_bit_bash_seq bb_seq;
    uvm_mem_walk_seq     walk_seq;
    uvm_status_e         status;
    uvm_reg_data_t       val, exp;
    amba_reg_block       rm = env.regmodel;
    phase.raise_objection(this);

    rst_seq = uvm_reg_hw_reset_seq::type_id::create("rst_seq");
    rst_seq.model = rm;
    rst_seq.start(null);
    checks += rm.N_REGS;

    bb_seq = uvm_reg_bit_bash_seq::type_id::create("bb_seq");
    bb_seq.model = rm;
    bb_seq.start(null);
    checks += rm.N_REGS * 64;

    walk_seq = uvm_mem_walk_seq::type_id::create("walk_seq");
    walk_seq.model = rm;
    walk_seq.start(null);
    checks += rm.MEM.get_size();

    foreach (rm.REG[i]) begin
      exp = {$urandom(), $urandom()};
      rm.REG[i].write(status, exp);
      if (status != UVM_IS_OK) `uvm_error("RAL", $sformatf("REG%0d write status %s", i, status.name()))
    end
    foreach (rm.REG[i]) begin
      exp = rm.REG[i].get_mirrored_value();
      rm.REG[i].mirror(status, UVM_CHECK);
      rm.REG[i].read(status, val);
      if (status != UVM_IS_OK || val != exp)
        `uvm_error("RAL", $sformatf("REG%0d read 0x%016h status %s, expected 0x%016h",
                   i, val, status.name(), exp))
      checks += 2;
    end
    repeat (32) begin
      uvm_reg_addr_t off = $urandom_range(rm.MEM.get_size() - 1);
      exp = {$urandom(), $urandom()};
      rm.MEM.write(status, off, exp);
      rm.MEM.read(status, off, val);
      if (status != UVM_IS_OK || val != exp)
        `uvm_error("RAL", $sformatf("MEM[%0d] read 0x%016h status %s, expected 0x%016h",
                   off, val, status.name(), exp))
      checks++;
    end

    rm.ERR_PROBE.write(status, 64'hDEAD_BEEF_0BAD_F00D);
    if (status != UVM_NOT_OK) `uvm_error("RAL", "ERR_PROBE write did not return UVM_NOT_OK")
    rm.ERR_PROBE.read(status, val);
    if (status != UVM_NOT_OK) `uvm_error("RAL", "ERR_PROBE read did not return UVM_NOT_OK")
    checks += 2;

    #100ns;
    phase.drop_objection(this);
  endtask

  virtual function void report_phase(uvm_phase phase);
    uvm_report_server rs = uvm_report_server::get_server();
    super.report_phase(phase);
    if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0)
      $display("RAL_PASS checks=%0d", checks);
    else
      $display("RAL_FAIL errors=%0d", rs.get_severity_count(UVM_ERROR));
  endfunction
endclass
// AHB coverage closure: legal HBURST x HSIZE sweep, random legal traffic and
// ERROR-response injection (issue #31)
class amba_ahb_cov_test extends amba_base_test;
  `uvm_component_utils(amba_ahb_cov_test)
  function new(string name = "amba_ahb_cov_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    ahb_cov_sweep_seq    sw  = ahb_cov_sweep_seq::type_id::create("sw");
    ahb_error_inject_seq err = ahb_error_inject_seq::type_id::create("err");
    phase.raise_objection(this);
    sw.start(env.agt.sqr);
    err.num_txns = 10;
    err.start(env.agt.sqr);
    #100ns;
    phase.drop_objection(this);
  endtask
  virtual function void report_phase(uvm_phase phase);
    uvm_report_server rs = uvm_report_server::get_server();
    super.report_phase(phase);
    if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0 && env.sb.n_matches > 0)
      $display("SB_PASS checks=%0d", env.sb.n_matches);
  endfunction
endclass
`endif
