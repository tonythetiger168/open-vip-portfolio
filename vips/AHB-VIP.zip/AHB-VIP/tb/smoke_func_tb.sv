// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened AHB5 slave amba_dut
// (tb/top_tb.sv): pipelined SINGLE / INCR / WRAP bursts of every size, BUSY
// cycles inside bursts, random wait states, write strobes, the two-cycle
// ERROR response with the master cancelling the rest of the burst, the
// secure region (HNONSEC), and exclusive access with one monitor per
// HMASTER (HEXCL / HEXOKAY).
//
// The master below works one clock at a time on the falling edge: with
// HREADYOUT high the data phase in progress completes at the next rising
// edge and the transfer on the address lines becomes the data phase. A
// byte-wide reference memory and a copy of the exclusive monitors predict
// every read lane, every response and the memory left by failed exclusive
// writes and cancelled bursts.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        vif_aclk    = 1'b0;
  logic        vif_aresetn = 1'b0;
  logic [31:0] vif_haddr   = 32'h0;
  logic [2:0]  vif_hsize   = 3'd3;
  logic [1:0]  vif_htrans  = 2'b00;
  logic [63:0] vif_hwdata  = 64'h0;
  logic        vif_hwrite  = 1'b0;
  logic        vif_hnonsec = 1'b0;
  logic        vif_hexcl   = 1'b0;
  logic [3:0]  vif_hmaster = 4'h0;
  logic [7:0]  vif_hwstrb  = 8'h0;
  wire  [63:0] vif_hrdata;
  wire         vif_hreadyout;
  wire         vif_hresp;
  wire         vif_hexokay;
  // unused sibling-protocol outputs of the shared amba_dut shell
  wire         vif_awready, vif_wready, vif_bvalid, vif_arready;
  wire         vif_rlast, vif_rvalid, vif_tready, vif_pready, vif_pslverr;
  wire [1:0]   vif_bresp, vif_rresp;
  wire [63:0]  vif_rdata;
  wire [31:0]  vif_prdata;

  always #5 vif_aclk = ~vif_aclk;

  amba_dut u_dut (
    .vif_aclk(vif_aclk), .vif_aresetn(vif_aresetn),
    .vif_awready(vif_awready), .vif_wready(vif_wready),
    .vif_bresp(vif_bresp), .vif_bvalid(vif_bvalid),
    .vif_arready(vif_arready), .vif_rdata(vif_rdata),
    .vif_rresp(vif_rresp), .vif_rlast(vif_rlast),
    .vif_rvalid(vif_rvalid), .vif_tready(vif_tready),
    .vif_haddr(vif_haddr), .vif_hsize(vif_hsize), .vif_htrans(vif_htrans),
    .vif_hwdata(vif_hwdata), .vif_hwrite(vif_hwrite),
    .vif_hrdata(vif_hrdata), .vif_hreadyout(vif_hreadyout), .vif_hresp(vif_hresp),
    .vif_hnonsec(vif_hnonsec), .vif_hexcl(vif_hexcl), .vif_hmaster(vif_hmaster),
    .vif_hexokay(vif_hexokay), .vif_hwstrb(vif_hwstrb),
    .vif_prdata(vif_prdata), .vif_pready(vif_pready), .vif_pslverr(vif_pslverr)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // ------------------------------------------------------------------ model
  logic [7:0]  ref_mem [0:8191];
  logic        mon_v   [0:15];
  logic [9:0]  mon_w   [0:15];
  initial begin
    for (int i = 0; i < 8192; i++) ref_mem[i] = 8'h0;
    for (int i = 0; i < 16; i++) begin mon_v[i] = 1'b0; mon_w[i] = 10'h0; end
  end

  // ------------------------------------------------------------- one burst
  // inputs
  bit          b_wr, b_wrap, b_ns, b_ex;
  logic [31:0] b_addr;
  logic [2:0]  b_size;
  int          b_len;
  logic [3:0]  b_m;
  logic [15:0] b_busy;              // BUSY before SEQ beat i when bit i is set
  logic [63:0] b_data [0:15];
  logic [7:0]  b_strb [0:15];
  // results
  logic [63:0] r_data [0:15];
  int          r_done, r_err_beat, r_waits, r_busy, r_maxw, r_errw;
  bit          r_exok;
  // expectations
  int          e_err_beat;
  bit          e_exok;
  // scratch
  int          a, d, pres, run, i, bb, k;
  bit          busy_now, bad, acc;
  logic [31:0] ba;
  logic [7:0]  ln;

  function automatic logic [31:0] beat_addr(input int n);
    logic [31:0] nb, wb;
    nb = 32'd1 << b_size;
    if (!b_wrap) return b_addr + n * nb;
    wb = nb * b_len;
    return (b_addr & ~(wb - 1)) | ((b_addr + n * nb) & (wb - 1));
  endfunction

  function automatic logic [7:0] beat_lanes(input logic [31:0] ad);
    logic [8:0] m;
    m = (9'd1 << (4'd1 << b_size[1:0])) - 9'd1;
    return m[7:0] << ad[2:0];
  endfunction

  function automatic bit beat_err(input logic [31:0] ad);
    return ad[31:24] == 8'hEE || b_size > 3'd3 ||
           (ad[2:0] & ((3'd1 << b_size[1:0]) - 3'd1)) != 3'd0 ||
           (b_ns && ad[12:11] == 2'b10);
  endfunction

  task automatic present(input logic [1:0] tr, input int n);
    vif_htrans  = tr;
    vif_haddr   = beat_addr(n);
    vif_hsize   = b_size;
    vif_hwrite  = b_wr;
    vif_hnonsec = b_ns;
    vif_hexcl   = b_ex;
    vif_hmaster = b_m;
  endtask

  // drive the burst and record what came back
  task automatic run_burst();
    a = 0; d = -1; pres = -1;
    r_done = 0; r_err_beat = -1; r_waits = 0; r_busy = 0; r_maxw = 0; r_exok = 0; r_errw = 0;
    run = 0;
    for (i = 0; i < 16; i++) r_data[i] = 64'hX;
    @(negedge vif_aclk);
    present(2'b10, 0); pres = 0; a = 1; acc = 1;   // the bus is idle: taken at the next edge
    while (1) begin
      @(negedge vif_aclk);
      if (acc) begin d = pres; acc = 0; end         // the transfer taken at the last edge
      if (d < 0 && a >= b_len) break;
      if (d >= 0 && b_wr) begin vif_hwdata = b_data[d]; vif_hwstrb = b_strb[d]; end
      if (vif_hreadyout === 1'b1) begin
        // the data phase of beat d completes at the next edge
        run = 0;
        if (d >= 0) begin
          r_done = d + 1;
          if (!b_wr) r_data[d] = vif_hrdata;
          if (vif_hresp === 1'b1) r_err_beat = d;
          if (vif_hexokay === 1'b1) r_exok = 1;
        end
        if (r_err_beat >= 0) begin
          present(2'b00, 0); vif_hexcl = 1'b0;
          break;
        end
        busy_now = (pres >= 0) && (a < b_len) && b_busy[a];
        if (busy_now) begin
          present(2'b01, a); pres = -1; r_busy++;
        end
        else if (a < b_len) begin
          present(2'b11, a); pres = a; a++;
        end
        else begin
          present(2'b00, 0); vif_hexcl = 1'b0; pres = -1;
        end
        acc = 1;
      end
      else begin
        r_waits++; run++;
        if (run > r_maxw) r_maxw = run;
        if (vif_hresp === 1'b1) begin            // first ERROR cycle: cancel
          r_errw++;
          present(2'b00, 0); vif_hexcl = 1'b0; pres = -1; a = b_len;
        end
      end
    end
    @(negedge vif_aclk);
    vif_hwstrb = 8'h0;
  endtask

  // update the reference model with the burst and check the results
  task automatic check_burst(input string tag);
    e_err_beat = -1; e_exok = 0; bad = 0;
    for (bb = 0; bb < b_len; bb++) if (e_err_beat < 0) begin
      ba = beat_addr(bb);
      ln = beat_lanes(ba);
      if (beat_err(ba)) e_err_beat = bb;
      else if (b_wr) begin
        if (!b_ex || (mon_v[b_m] && mon_w[b_m] == ba[12:3])) begin
          if (b_ex) e_exok = 1;
          for (k = 0; k < 8; k++)
            if (ln[k] && b_strb[bb][k]) ref_mem[{ba[12:3], 3'b000} + k] = b_data[bb][k*8 +: 8];
          for (k = 0; k < 16; k++) if (mon_w[k] == ba[12:3]) mon_v[k] = 1'b0;
        end
      end
      else begin
        for (k = 0; k < 8; k++)
          if (ln[k] && r_data[bb][k*8 +: 8] !== ref_mem[{ba[12:3], 3'b000} + k]) bad = 1;
        if (b_ex) begin e_exok = 1; mon_v[b_m] = 1'b1; mon_w[b_m] = ba[12:3]; end
      end
    end
    if (e_err_beat >= 0) begin
      chk(r_err_beat == e_err_beat && r_done == e_err_beat + 1,
          $sformatf("%s: ERROR on beat %0d, burst stopped after %0d beats (expected beat %0d)",
                    tag, r_err_beat, r_done, e_err_beat));
      chk(r_errw == 1, $sformatf("%s: two-cycle ERROR response (%0d low cycles with ERROR)", tag, r_errw));
      if (!b_wr) chk(r_data[e_err_beat] === 64'h0, $sformatf("%s: ERROR beat returns zero data", tag));
    end
    else chk(r_err_beat < 0 && r_done == b_len, $sformatf("%s: %0d of %0d beats OKAY", tag, r_done, b_len));
    if (!b_wr) chk(!bad, $sformatf("%s: read lanes match the reference memory", tag));
    if (b_ex) chk(r_exok == e_exok, $sformatf("%s: HEXOKAY %0d, expected %0d", tag, r_exok, e_exok));
  endtask

  task automatic set(input bit wr, input logic [31:0] ad, input logic [2:0] sz, input int ln_,
                     input bit wrap = 0, input logic [15:0] busy = 0, input bit ns = 0,
                     input bit ex = 0, input logic [3:0] m = 0, input logic [7:0] sb = 8'hFF,
                     input int seed = 0);
    b_wr = wr; b_addr = ad; b_size = sz; b_len = ln_; b_wrap = wrap; b_busy = busy;
    b_ns = ns; b_ex = ex; b_m = m;
    for (i = 0; i < 16; i++) begin
      b_data[i] = {32'(32'hA5000000 + seed * 256 + i), 32'(32'h3C000000 ^ (seed * 7919 + i * 131))};
      b_strb[i] = sb;
    end
  endtask

  task automatic xfer(input string tag);
    run_burst();
    check_burst(tag);
  endtask

  // ------------------------------------------------------------------ tests
  int tot_waits, max_run, tot_busy, n, t, w, j;
  logic [31:0] ad;

  initial begin
    tot_waits = 0; max_run = 0; tot_busy = 0;
    repeat (4) @(posedge vif_aclk);
    @(negedge vif_aclk);
    chk(vif_hreadyout === 1'b1 && vif_hresp === 1'b0 && vif_hrdata === 64'h0 && vif_hexokay === 1'b0,
        "in reset: HREADYOUT high, OKAY, no read data, no EXOKAY");
    vif_aresetn = 1'b1;
    @(negedge vif_aclk);
    chk(vif_hreadyout === 1'b1 && vif_hresp === 1'b0, "HREADYOUT high and HRESP OKAY out of reset");
    chk(vif_hrdata === 64'h0 && vif_hexokay === 1'b0, "no read data or EXOKAY with the bus idle");

    // 1. SINGLE transfers of every size at every legal offset
    n = 0;
    for (t = 0; t < 4; t++)
      for (j = 0; j < 8; j = j + (1 << t)) begin
        set(1, 32'h0000_0040 + j, t[2:0], 1, 0, 0, 0, 0, 0, 8'hFF, n);
        run_burst(); check_burst("single write");
        n++;
      end
    set(0, 32'h0000_0040, 3'd3, 1); xfer("SINGLE 8-byte read-back of the narrow writes");
    set(0, 32'h0000_0000, 3'd3, 1); xfer("first word reads 0 before any write");
    set(0, 32'h0000_1FF8, 3'd3, 1); xfer("last word reads 0 before any write");

    // 2. INCR4/8/16 and WRAP4/8/16 of every size, with and without BUSY
    n = 0;
    for (w = 0; w < 2; w++) begin
      for (t = 0; t < 4; t++) begin
        for (j = 4; j <= 16; j = j * 2) begin
          ad = 32'h0000_0400 + n * 64 + (w ? (1 << t) : 0);
          set(1, ad, t[2:0], j, w, (n % 2) ? 16'hAAAA : 16'h0000, 0, 0, 0, 8'hFF, 100 + n);
          run_burst(); check_burst($sformatf("%s%0d size %0d write", w ? "WRAP" : "INCR", j, 1 << t));
          tot_waits += r_waits; tot_busy += r_busy; if (r_maxw > max_run) max_run = r_maxw;
          set(0, ad, t[2:0], j, w, (n % 2) ? 16'h5555 : 16'hFFFF, 0, 0, 0, 8'hFF, 100 + n);
          run_burst(); check_burst($sformatf("%s%0d size %0d read", w ? "WRAP" : "INCR", j, 1 << t));
          tot_waits += r_waits; tot_busy += r_busy; if (r_maxw > max_run) max_run = r_maxw;
          n++;
        end
      end
    end
    chk(tot_busy > 20, $sformatf("BUSY cycles inside bursts ignored by the slave (%0d)", tot_busy));
    chk(tot_waits > 20 && max_run == 2, $sformatf("wait states of 1 and 2 cycles (%0d, longest %0d)", tot_waits, max_run));

    // 3. undefined-length INCR with sparse strobes, read back
    set(1, 32'h0000_0A00, 3'd3, 7, 0, 16'h0024, 0, 0, 0, 8'h5A, 300); xfer("INCR7 strobe 5A write");
    set(1, 32'h0000_0A08, 3'd2, 3, 0, 0, 0, 0, 0, 8'hF0, 301);       xfer("INCR3 4-byte strobe F0 write");
    set(0, 32'h0000_0A00, 3'd3, 7, 0, 16'h0008);                     xfer("INCR7 read-back of strobed writes");

    // 4. ERROR responses: error region, unaligned, wider than the bus,
    //    error part-way through a burst (rest cancelled)
    set(0, 32'hEE00_0100, 3'd3, 1);           xfer("read of the error region");
    set(1, 32'hEE00_0100, 3'd3, 4, 0, 0);     xfer("INCR4 write to the error region");
    set(1, 32'h0000_0062, 3'd2, 1);           xfer("unaligned 4-byte write");
    set(0, 32'h0000_0060, 3'd4, 1);           xfer("16-byte read on a 64-bit bus");
    set(1, 32'h0000_0FE8, 3'd3, 6, 0, 16'h0002, 1, 0, 0, 8'hFF, 400);
    xfer("non-secure INCR6 running into the secure region");
    set(0, 32'h0000_0FE8, 3'd3, 2);           xfer("read-back below the secure region");
    set(0, 32'h0000_1000, 3'd3, 4);           xfer("secure read: cancelled beats not written");
    @(negedge vif_aclk);
    chk(vif_hresp === 1'b0 && vif_hreadyout === 1'b1, "slave back to OKAY after the ERROR bursts");

    // 5. secure region 0x1000-0x17FF
    set(1, 32'h0000_1200, 3'd3, 4, 0, 0, 0, 0, 0, 8'hFF, 500); xfer("secure INCR4 write to the secure region");
    set(0, 32'h0000_1200, 3'd3, 4, 0, 0, 1);                   xfer("non-secure read of the secure region");
    set(1, 32'h0000_17F8, 3'd3, 1, 0, 0, 1, 0, 0, 8'hFF, 501); xfer("non-secure write to the top of the secure region");
    set(0, 32'h0000_1200, 3'd3, 4);                            xfer("secure read-back: data unchanged");
    set(1, 32'h0000_1800, 3'd3, 2, 0, 0, 1, 0, 0, 8'hFF, 502); xfer("non-secure write just above the secure region");
    set(0, 32'h0000_1800, 3'd3, 2, 0, 0, 1);                   xfer("non-secure read just above the secure region");

    // 6. exclusive access, one monitor per master
    for (t = 0; t < 4; t++) begin
      ad = 32'h0000_0200 + t * 8;
      set(0, ad, 3'd3, 1, 0, 0, 0, 1, t[3:0]);                         xfer("LDREX");
      set(1, ad, 3'd3, 1, 0, 0, 0, 1, t[3:0], 8'hFF, 600 + t);         xfer("STREX after LDREX passes");
      set(1, ad, 3'd3, 1, 0, 0, 0, 1, t[3:0], 8'hFF, 610 + t);         xfer("second STREX fails, memory kept");
      set(0, ad, 3'd3, 1, 0, 0, 0, 1, t[3:0]);                         xfer("LDREX again");
      set(1, ad, 3'd2, 1, 0, 0, 0, 0, t[3:0] + 4'd8, 8'hFF, 620 + t); xfer("another master writes the word");
      set(1, ad, 3'd3, 1, 0, 0, 0, 1, t[3:0], 8'hFF, 630 + t);         xfer("STREX after the other write fails");
    end
    set(0, 32'h0000_0280, 3'd3, 1, 0, 0, 0, 1, 4'd1);                  xfer("master 1 LDREX");
    set(0, 32'h0000_0280, 3'd3, 1, 0, 0, 0, 1, 4'd2);                  xfer("master 2 LDREX of the same word");
    set(1, 32'h0000_0280, 3'd3, 1, 0, 0, 0, 1, 4'd2, 8'hFF, 640);      xfer("master 2 STREX passes");
    set(1, 32'h0000_0280, 3'd3, 1, 0, 0, 0, 1, 4'd1, 8'hFF, 641);      xfer("master 1 STREX fails");
    set(0, 32'h0000_0288, 3'd3, 1, 0, 0, 0, 1, 4'd3);                  xfer("master 3 LDREX");
    set(1, 32'h0000_0290, 3'd3, 1, 0, 0, 0, 1, 4'd3, 8'hFF, 642);      xfer("master 3 STREX to another word fails");
    // an exclusive read on an IDLE (or BUSY) cycle is not a transfer: no monitor
    @(negedge vif_aclk);
    vif_htrans = 2'b00; vif_haddr = 32'h0000_02A0; vif_hwrite = 1'b0; vif_hexcl = 1'b1; vif_hmaster = 4'd5;
    @(negedge vif_aclk);
    vif_hexcl = 1'b0;
    set(1, 32'h0000_02A0, 3'd3, 1, 0, 0, 0, 1, 4'd5, 8'hFF, 643);      xfer("STREX after an IDLE cycle with HEXCL fails");
    set(0, 32'h0000_0200, 3'd3, 8);                                    xfer("read-back of the exclusive words");
    set(0, 32'h0000_0280, 3'd3, 3);                                    xfer("read-back of the shared exclusive word");

    // 7. reset in the middle: exclusive monitors cleared, memory kept
    set(1, 32'h0000_0000, 3'd3, 1, 0, 0, 0, 0, 0, 8'hFF, 700);         xfer("write the first word");
    set(0, 32'h0000_0300, 3'd3, 1, 0, 0, 0, 1, 4'd0);                  xfer("master 0 LDREX before reset");
    set(0, 32'h0000_0308, 3'd3, 1, 0, 0, 0, 1, 4'd15);                 xfer("master 15 LDREX before reset");
    @(negedge vif_aclk);
    vif_aresetn = 1'b0;
    @(negedge vif_aclk);
    chk(vif_hreadyout === 1'b1 && vif_hresp === 1'b0 && vif_hrdata === 64'h0 && vif_hexokay === 1'b0,
        "reset again: HREADYOUT high, OKAY, no read data, no EXOKAY");
    @(negedge vif_aclk);
    vif_aresetn = 1'b1;
    for (i = 0; i < 16; i++) mon_v[i] = 1'b0;
    set(1, 32'h0000_0300, 3'd3, 1, 0, 0, 0, 1, 4'd0, 8'hFF, 701);      xfer("master 0 STREX after reset fails");
    set(1, 32'h0000_0308, 3'd3, 1, 0, 0, 0, 1, 4'd15, 8'hFF, 702);     xfer("master 15 STREX after reset fails");
    set(0, 32'h0000_0000, 3'd3, 1);                                    xfer("memory kept through reset");
    set(0, 32'h0000_0300, 3'd3, 2);                                    xfer("words of the failed STREX unchanged");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
