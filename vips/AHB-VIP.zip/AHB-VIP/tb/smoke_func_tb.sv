// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2025 Functional smoke testbench (AHB write/read + error response)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened AHB slave amba_dut.
// DUT behaviour (from dut_amba_dut.sv):
//   - single AHB slave, 64-bit data, internal mem[0:1023]
//   - address phase sampled when hreadyout && htrans != IDLE
//   - write commits mem[ap_addr] <= hwdata in the data phase
//   - read data hrdata = mem[ap_addr[12:3]] combinationally in data phase
//   - haddr[31:24]==8'hEE -> two-cycle ERROR response (wait, then complete)
// Write-then-read consistency therefore pairs write addr Wa (<=1023) with
// read addr (Wa << 3) so both hit the same mem entry.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        vif_aclk    = 1'b0;
  logic        vif_aresetn = 1'b0;
  logic [31:0] vif_haddr   = 32'h0;
  logic [1:0]  vif_htrans  = 2'b00;
  logic [63:0] vif_hwdata  = 64'h0;
  logic        vif_hwrite  = 1'b0;
  wire [63:0]  vif_hrdata;
  wire         vif_hreadyout;
  wire         vif_hresp;
  // unused sibling-protocol outputs of the shared amba_dut shell
  wire         vif_awready, vif_wready, vif_bvalid, vif_arready;
  wire         vif_rlast, vif_rvalid, vif_tready, vif_pready, vif_pslverr;
  wire [1:0]   vif_bresp, vif_rresp;
  wire [63:0]  vif_rdata;
  wire [31:0]  vif_prdata;

  always #5 vif_aclk = ~vif_aclk;

  amba_dut u_dut (
    .vif_aclk(vif_aclk), .vif_aresetn(vif_aresetn),
    .vif_awready(vif_awready), .vif_wready(vif_wready),
    .vif_bresp(vif_bresp), .vif_bvalid(vif_bvalid),
    .vif_arready(vif_arready), .vif_rdata(vif_rdata),
    .vif_rresp(vif_rresp), .vif_rlast(vif_rlast),
    .vif_rvalid(vif_rvalid), .vif_tready(vif_tready),
    .vif_haddr(vif_haddr), .vif_htrans(vif_htrans),
    .vif_hwdata(vif_hwdata), .vif_hwrite(vif_hwrite),
    .vif_hrdata(vif_hrdata), .vif_hreadyout(vif_hreadyout),
    .vif_hresp(vif_hresp), .vif_prdata(vif_prdata),
    .vif_pready(vif_pready), .vif_pslverr(vif_pslverr)
  );

  task automatic chk(input bit cond, input string name);
    begin
      checks++;
      if (!cond) begin
        fails++;
        $display("  [FAIL] %s", name);
      end
    end
  endtask

  // one AHB write: address phase (NONSEQ/SEQ) then data phase
  task automatic ahb_write(input [1:0] trans, input [31:0] addr,
                           input [63:0] data);
    begin
      @(negedge vif_aclk);
      vif_haddr = addr; vif_htrans = trans; vif_hwrite = 1'b1;
      @(negedge vif_aclk);          // address phase sampled at posedge
      chk(vif_hreadyout === 1'b1, "write address phase accepted (hreadyout=1)");
      vif_hwdata = data; vif_htrans = 2'b00;   // data phase, bus back to IDLE
      @(negedge vif_aclk);          // write committed at posedge
      chk(vif_hreadyout === 1'b1 && vif_hresp === 1'b0,
          "write data phase completed OKAY");
      vif_hwrite = 1'b0;
    end
  endtask

  // one AHB read: returns data sampled mid data-phase
  task automatic ahb_read(input [31:0] addr, output [63:0] data);
    begin
      @(negedge vif_aclk);
      vif_haddr = addr; vif_htrans = 2'b10; vif_hwrite = 1'b0;
      @(negedge vif_aclk);          // address phase sampled
      data = vif_hrdata;            // combinational read data in data phase
      chk(vif_hreadyout === 1'b1 && vif_hresp === 1'b0,
          "read data phase OKAY response");
      vif_htrans = 2'b00;
    end
  endtask

  localparam [63:0] D1 = 64'hDEAD_BEEF_1234_5678;
  localparam [63:0] D2 = 64'h0BAD_F00D_CAFE_0001;
  reg [63:0] rdata;

  initial begin
    // reset
    repeat (4) @(posedge vif_aclk);
    @(negedge vif_aclk);
    vif_aresetn = 1'b1;
    @(negedge vif_aclk);
    chk(vif_hreadyout === 1'b1, "hreadyout high out of reset");
    chk(vif_hresp === 1'b0,     "hresp OKAY out of reset");

    // NONSEQ write then read-back (write idx 8  <-> read addr 0x40)
    ahb_write(2'b10, 32'h0000_0008, D1);
    ahb_read(32'h0000_0040, rdata);
    chk(rdata === D1, "read data equals written data (NONSEQ)");

    // SEQ write then read-back (write idx 9 <-> read addr 0x48)
    ahb_write(2'b11, 32'h0000_0009, D2);
    ahb_read(32'h0000_0048, rdata);
    chk(rdata === D2, "read data equals written data (SEQ)");

    // idle bus drives hrdata to zero
    @(negedge vif_aclk);
    chk(vif_hrdata === 64'h0, "hrdata zero when no read in data phase");

    // error region haddr[31:24]==0xEE -> 2-cycle ERROR response
    @(negedge vif_aclk);
    vif_haddr = 32'hEE00_0000; vif_htrans = 2'b10; vif_hwrite = 1'b0;
    @(negedge vif_aclk);
    chk(vif_hreadyout === 1'b0 && vif_hresp === 1'b1,
        "error region cycle 1: wait state with HRESP=ERROR");
    vif_htrans = 2'b00;
    @(negedge vif_aclk);
    chk(vif_hreadyout === 1'b1 && vif_hresp === 1'b1,
        "error region cycle 2: complete with HRESP=ERROR");
    @(negedge vif_aclk);
    chk(vif_hreadyout === 1'b1 && vif_hresp === 1'b0,
        "slave recovers to OKAY after error");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  // safety timeout (well below 100us budget)
  initial begin
    #80000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
