// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_ahb_tb.sv -- functional test for the AHB slave of the shared AMBA
// DUT model (amba_dut, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py AHB-VIP
//
// Model contract (from tb/top_tb.sv): 64-bit AHB-Lite slave, 1024-word
// memory, no wait states; an address phase is taken when HREADYOUT=1 and
// HTRANS != IDLE; HADDR[31:24] = 0xEE answers with the two-cycle ERROR
// response. The AXI/APB/stream ports of the shared shell are tied off.
// Known model defects (XFAIL): the write data phase indexes the memory with
// the whole byte address while reads use HADDR[12:3], so a read of the
// written address returns another word; BUSY transfers are not ignored.
// The other checks use the model's own addressing (write index N is read
// back at byte address N*8), as smoke_func_tb.sv does.

module func_ahb_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [31:0] haddr = '0;
  logic [1:0]  htrans = 2'b00;
  logic [63:0] hwdata = '0;
  logic        hwrite = 1'b0;
  wire  [63:0] hrdata, rdata;
  wire         hreadyout, hresp;
  wire         awready, wready, bvalid, arready, rlast, rvalid, tready, pready, pslverr;
  wire  [1:0]  bresp, rresp;
  wire  [31:0] prdata;

  always #5 clk = ~clk;

  amba_dut u_dut (
    .vif_aclk(clk), .vif_aresetn(rst_n),
    .vif_awready(awready), .vif_wready(wready), .vif_bresp(bresp), .vif_bvalid(bvalid),
    .vif_arready(arready), .vif_rdata(rdata), .vif_rresp(rresp), .vif_rlast(rlast),
    .vif_rvalid(rvalid), .vif_tready(tready),
    .vif_haddr(haddr), .vif_htrans(htrans), .vif_hwdata(hwdata), .vif_hwrite(hwrite),
    .vif_hrdata(hrdata), .vif_hreadyout(hreadyout), .vif_hresp(hresp),
    .vif_prdata(prdata), .vif_pready(pready), .vif_pslverr(pslverr)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (ok) begin fails++; $display("  [XPASS] %s", msg); end
    else    begin xfails++; $display("  [XFAIL] %s", msg); end
  endtask

  localparam [1:0] IDLE = 2'b00, BUSY = 2'b01, NONSEQ = 2'b10, SEQ = 2'b11;

  // single transfers: address phase, then data phase with the bus idle
  task automatic write(input [31:0] a, input [63:0] d, input [1:0] tr = NONSEQ);
    @(negedge clk);
    haddr = a; htrans = tr; hwrite = 1'b1;
    @(negedge clk);
    htrans = IDLE; hwdata = d;
    @(negedge clk);
    hwrite = 1'b0;
  endtask
  logic [63:0] got;
  task automatic read(input [31:0] a);
    @(negedge clk);
    haddr = a; htrans = NONSEQ; hwrite = 1'b0;
    @(negedge clk);
    htrans = IDLE;
    got = hrdata;
  endtask

  initial begin
    // reset values (checked while reset is held)
    repeat (2) @(negedge clk);
    chk(hreadyout === 1'b1 && hresp === 1'b0 && hrdata === 64'h0, "reset: HREADYOUT=1, OKAY, HRDATA=0");
    chk(awready === 0 && wready === 0 && bvalid === 0 && bresp === 0 && arready === 0 &&
        rvalid === 0 && rlast === 0 && rresp === 0 && rdata === 0 && tready === 0,
        "AXI / stream ports of the shared shell tied off");
    chk(pready === 0 && pslverr === 0 && prdata === 0, "APB ports of the shared shell tied off");
    // a transfer presented during reset is ignored
    haddr = 32'h0000_0003; htrans = NONSEQ; hwrite = 1'b1;
    @(negedge clk); hwdata = 64'hBAD0_BAD0_BAD0_BAD0;
    @(negedge clk); htrans = IDLE; hwrite = 1'b0;
    rst_n = 1'b1;

    // unwritten memory reads 0, first and last word
    read(32'h0000_0000); chk(got === 64'h0, "word 0 reads 0 after power-up");
    read(32'h0000_1FF8); chk(got === 64'h0, "word 1023 reads 0 after power-up");
    read(32'h0000_0018); chk(got === 64'h0, "transfer during reset did not write");

    // the model's addressing defect
    write(32'h0000_0040, 64'h1111_2222_3333_4444);
    read(32'h0000_0040);
    chk_xfail(got === 64'h1111_2222_3333_4444, "read of a written byte address returns the written word");

    // write / read round trip with the model's addressing
    write(32'h0000_0005, 64'hA5A5_0000_0000_0005);
    write(32'h0000_0006, 64'hA5A5_0000_0000_0006, SEQ);
    read(32'h0000_0028); chk(got === 64'hA5A5_0000_0000_0005, "NONSEQ write reads back");
    read(32'h0000_0030); chk(got === 64'hA5A5_0000_0000_0006, "SEQ write reads back");
    chk(hresp === 1'b0 && hreadyout === 1'b1, "OKAY response, no wait states");
    @(negedge clk);
    chk(hrdata === 64'h0, "HRDATA is 0 outside a read data phase");

    // pipelined: write data phase overlaps the next read address phase
    @(negedge clk);
    haddr = 32'h0000_0007; htrans = NONSEQ; hwrite = 1'b1;
    @(negedge clk);
    hwdata = 64'h7777_0000_0000_0007; haddr = 32'h0000_0028; htrans = NONSEQ; hwrite = 1'b0;
    @(negedge clk);
    got = hrdata; htrans = IDLE;
    chk(got === 64'hA5A5_0000_0000_0005, "pipelined read after a write returns its own word");
    read(32'h0000_0038); chk(got === 64'h7777_0000_0000_0007, "pipelined write landed");

    // IDLE cycles with HWRITE high and changing HWDATA write nothing
    @(negedge clk);
    haddr = 32'h0000_0005; hwrite = 1'b1; htrans = IDLE;
    repeat (3) begin @(negedge clk); hwdata = $urandom; end
    hwrite = 1'b0;
    read(32'h0000_0028); chk(got === 64'hA5A5_0000_0000_0005, "IDLE transfers do not write");
    // write data phase followed by idle cycles: written once, not overwritten
    write(32'h0000_0009, 64'h9999_0000_0000_0009);
    @(negedge clk); hwdata = 64'hFFFF_FFFF_FFFF_FFFF;
    repeat (2) @(negedge clk);
    read(32'h0000_0048); chk(got === 64'h9999_0000_0000_0009, "stale HWDATA after the data phase is not written");

    // BUSY must be ignored by a slave
    write(32'h0000_000A, 64'hB0B0_0000_0000_000A, BUSY);
    read(32'h0000_0050);
    chk_xfail(got === 64'h0, "BUSY transfer is ignored");

    // error region: two-cycle ERROR, no side effects
    @(negedge clk);
    haddr = 32'hEE00_0028; htrans = NONSEQ; hwrite = 1'b1;
    @(negedge clk);
    htrans = IDLE; hwdata = 64'hEEEE_EEEE_EEEE_EEEE;
    chk(hreadyout === 1'b0 && hresp === 1'b1 && hrdata === 64'h0, "error cycle 1: wait state, ERROR, no read data");
    @(negedge clk);
    chk(hreadyout === 1'b1 && hresp === 1'b1 && hrdata === 64'h0, "error cycle 2: ERROR completes");
    @(negedge clk);
    hwrite = 1'b0;
    chk(hreadyout === 1'b1 && hresp === 1'b0, "OKAY again after the error");
    read(32'h0000_0028); chk(got === 64'hA5A5_0000_0000_0005, "write to the error region has no side effect");
    read(32'h0000_0038); chk(got === 64'h7777_0000_0000_0007, "previous write target untouched by the error transfer");
    // error read: no data in either error cycle
    @(negedge clk);
    haddr = 32'hEE00_0000; htrans = NONSEQ; hwrite = 1'b0;
    @(negedge clk); htrans = IDLE;
    @(negedge clk);
    chk(hrdata === 64'h0 && hresp === 1'b1, "error read returns no data");

    // reset mid read data phase (word 0 holds data, so a stale data phase
    // pointing at the reset address would show up on HRDATA)
    write(32'h0000_0000, 64'h0F0F_0F0F_0F0F_0F0F);
    @(negedge clk);
    haddr = 32'h0000_0028; htrans = NONSEQ;
    @(negedge clk);
    htrans = IDLE; rst_n = 1'b0;
    #1;
    chk(hrdata === 64'h0 && hreadyout === 1'b1 && hresp === 1'b0, "reset aborts the data phase");
    @(negedge clk); rst_n = 1'b1;

    // random writes / reads against a reference (model addressing)
    begin
      logic [63:0] m [64];
      int bad = 0;
      foreach (m[i]) m[i] = 64'h0;
      for (int i = 16; i < 64; i++) begin
        m[i] = {$urandom, $urandom};
        write(32'(i), m[i], $urandom_range(1) ? NONSEQ : SEQ);
      end
      for (int t = 0; t < 64; t++) begin
        int i;
        i = $urandom_range(16, 63);
        read(32'(i * 8));
        if (got !== m[i]) bad++;
      end
      chk(bad == 0, $sformatf("64 random reads match the reference (%0d bad)", bad));
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
