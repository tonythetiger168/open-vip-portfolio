// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AMBA Testbench -- top with a functional AHB5 slave DUT model (memory map)
//============================================================================
`ifndef AMBA_TB_SV
`define AMBA_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import amba_vip_pkg::*;

module top_tb;
  logic aclk = 0, aresetn;
  always #5ns aclk = ~aclk;

  initial begin
    aresetn = 0;
    #100ns;
    aresetn = 1;
  end

  amba_vip_if vif(aclk, aresetn);
  amba_dut dut(.vif(vif));

  // Tiered SVA compliance checker (module form)
  ahb_compliance_checker_sva u_ahb_sva_chk (.vif(vif));

  // Protocol checkers (module form)
  ahb_protocol_checker_sva u_ahb_proto_sva (.vif(vif));
  apb_protocol_checker_sva u_apb_proto_sva (.vif(vif));
  axi_protocol_checker_sva u_axi_proto_sva (.vif(vif));

  initial begin
    uvm_config_db#(virtual amba_vip_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

//----------------------------------------------------------------------------
// Functional AHB5 slave (IHI 0033B): 8 KiB memory, 64-bit data bus.
//   - every NONSEQ / SEQ transfer gets 0, 1 or 2 wait states (LFSR); IDLE
//     and BUSY transfers are ignored
//   - a beat writes the byte lanes of its address and HSIZE that also have
//     HWSTRB set
//   - two-cycle ERROR response, no write and no read data, for: the error
//     region haddr[31:24] == 8'hEE, a transfer not aligned to HSIZE, HSIZE
//     wider than the bus, and a non-secure transfer (HNONSEC = 1) to the
//     secure region 0x1000-0x17FF
//   - exclusive access (HEXCL): an exclusive read sets the monitor of its
//     HMASTER to the word and answers HEXOKAY; an exclusive write succeeds
//     (HEXOKAY, written) only while its master's monitor still holds the
//     word, otherwise it is not written and HEXOKAY stays low; every
//     completed write to a word clears the monitors holding it
//----------------------------------------------------------------------------
module amba_dut(amba_vip_if vif);

  logic [63:0] mem [0:1023];       // 8 KiB word-addressed memory
  initial for (int i = 0; i < 1024; i++) mem[i] = 64'h0;

  // data phase of the transfer accepted at the last HREADY edge
  logic        dp_valid, dp_write, dp_err, dp_excl, dp_exok;
  logic [31:0] dp_addr;
  logic [2:0]  dp_size;
  logic        rdy, rsp;           // HREADYOUT, HRESP
  logic [1:0]  wcnt;               // wait states left
  logic [15:0] lfsr;
  logic        mon_v [0:15];       // exclusive monitor per HMASTER
  logic [9:0]  mon_w [0:15];
  logic [7:0]  dp_lanes;

  wire [9:0] dp_word = dp_addr[12:3];
  wire [9:0] a_word  = vif.haddr[12:3];
  // NONSEQ/SEQ only: IDLE and BUSY transfers are ignored by a slave
  wire       aphase  = rdy && vif.htrans[1];
  wire       a_err   = (vif.haddr[31:24] == 8'hEE) || (vif.hsize > 3'd3) ||
                       ((vif.haddr[2:0] & ((3'd1 << vif.hsize[1:0]) - 3'd1)) != 3'd0) ||
                       (vif.hnonsec && vif.haddr[12:11] == 2'b10);
  // the data phase completes at this edge with a write
  wire       wr_done = rdy && dp_valid && dp_write && !dp_err && (!dp_excl || dp_exok);

  function automatic logic [7:0] lanes(input logic [31:0] a, input logic [2:0] size);
    logic [3:0] nb;
    nb = 4'd1 << size[1:0];
    lanes = 8'((9'd1 << nb) - 9'd1) << a[2:0];
  endfunction

  assign dp_lanes      = lanes(dp_addr, dp_size) & vif.hwstrb;
  assign vif.hreadyout = rdy;
  assign vif.hresp     = rsp;
  assign vif.hrdata    = (dp_valid && !dp_write && !dp_err) ? mem[dp_word] : 64'h0;
  assign vif.hexokay   = rdy && dp_valid && !dp_err && dp_excl && dp_exok;

  always_ff @(posedge vif.aclk or negedge vif.aresetn) begin
    if (!vif.aresetn) begin
      rdy <= 1'b1; rsp <= 1'b0; wcnt <= 2'd0;
      dp_valid <= 1'b0; dp_write <= 1'b0; dp_err <= 1'b0; dp_excl <= 1'b0; dp_exok <= 1'b0;
      dp_addr <= 32'h0; dp_size <= 3'd0;
      lfsr <= 16'h1D2C;
      for (int m = 0; m < 16; m++) begin mon_v[m] <= 1'b0; mon_w[m] <= 10'h0; end
    end
    else begin
      lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      if (rdy) begin
        // -------- data phase completes --------
        if (wr_done) begin
          for (int b = 0; b < 8; b++)
            if (dp_lanes[b]) mem[dp_word][b*8 +: 8] <= vif.hwdata[b*8 +: 8];
          for (int m = 0; m < 16; m++) if (mon_w[m] == dp_word) mon_v[m] <= 1'b0;
        end
        // -------- next address phase --------
        dp_valid <= aphase;
        dp_write <= vif.hwrite;
        dp_addr  <= vif.haddr;
        dp_size  <= vif.hsize;
        dp_err   <= aphase && a_err;
        dp_excl  <= vif.hexcl;
        dp_exok  <= vif.hwrite ? (mon_v[vif.hmaster] && mon_w[vif.hmaster] == a_word &&
                                  !(wr_done && dp_word == a_word)) : 1'b1;
        if (aphase && !a_err && vif.hexcl && !vif.hwrite) begin
          mon_v[vif.hmaster] <= 1'b1;
          mon_w[vif.hmaster] <= a_word;
        end
        if (aphase && a_err) begin
          rdy <= 1'b0; rsp <= 1'b1; wcnt <= 2'd0;            // ERROR: HRESP held into the next cycle
        end
        else if (aphase && lfsr[1]) begin
          rdy <= 1'b0; rsp <= 1'b0; wcnt <= {1'b0, lfsr[2]};  // 1 or 2 wait states
        end
        else begin
          rdy <= 1'b1; rsp <= 1'b0;
        end
      end
      else if (wcnt == 2'd0) rdy <= 1'b1;
      else wcnt <= wcnt - 2'd1;
    end
  end

  // Tie off unused protocol outputs (AXI/APB) so no X propagates
  initial begin
    vif.awready = 1'b0; vif.wready = 1'b0; vif.bvalid = 1'b0; vif.bresp = 2'b00;
    vif.arready = 1'b0; vif.rvalid = 1'b0; vif.rdata = 64'h0;
    vif.rresp = 2'b00;  vif.rlast = 1'b0;  vif.tready = 1'b0;
    vif.pready = 1'b0;  vif.prdata = 32'h0; vif.pslverr = 1'b0;
  end
endmodule
`endif
