// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AMBA Testbench -- top with a functional AHB5 slave DUT model (memory map)
//============================================================================
`ifndef AMBA_TB_SV
`define AMBA_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import amba_vip_pkg::*;

module top_tb;
  logic aclk = 0, aresetn;
  always #5ns aclk = ~aclk;

  initial begin
    aresetn = 0;
    #100ns;
    aresetn = 1;
  end

  amba_vip_if vif(aclk, aresetn);
  amba_dut dut(.vif(vif));

  // Tiered SVA compliance checker (module form)
  ahb_compliance_checker_sva u_ahb_sva_chk (.vif(vif));

  // Protocol checkers (module form)
  ahb_protocol_checker_sva u_ahb_proto_sva (.vif(vif));
  apb_protocol_checker_sva u_apb_proto_sva (.vif(vif));
  axi_protocol_checker_sva u_axi_proto_sva (.vif(vif));

  initial begin
    uvm_config_db#(virtual amba_vip_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

//----------------------------------------------------------------------------
// Functional AHB5 slave: zero-wait-state memory model with an ERROR region
// (0xEE00_0000 -> two-cycle HRESP=ERROR). Address phase is captured when
// HREADYOUT=1 and HTRANS is NONSEQ/SEQ; the data phase follows one cycle
// later, matching AHB pipelining.
//----------------------------------------------------------------------------
module amba_dut(amba_vip_if vif);

  localparam logic [1:0] HTRANS_IDLE = 2'b00;

  logic [63:0] mem [0:1023];       // 8 KiB word-addressed memory
  initial for (int i = 0; i < 1024; i++) mem[i] = 64'h0;

  logic        ap_valid;           // pending data phase
  logic        ap_write;
  logic [31:0] ap_addr;
  logic        err_cycle;          // first cycle of two-cycle error response

  wire [9:0] waddr = ap_addr[12:3];

  wire error_region = (vif.haddr[31:24] == 8'hEE);
  wire aphase = vif.hreadyout && (vif.htrans != HTRANS_IDLE);

  // Read data is combinational during the data phase (zero wait-state slave)
  assign vif.hrdata = (ap_valid && !ap_write) ? mem[waddr] : 64'h0;

  always_ff @(posedge vif.aclk or negedge vif.aresetn) begin
    if (!vif.aresetn) begin
      vif.hreadyout <= 1'b1;
      vif.hresp     <= 1'b0;
      ap_valid      <= 1'b0;
      ap_write      <= 1'b0;
      ap_addr       <= 32'h0;
      err_cycle     <= 1'b0;
    end
    else begin
      // -------- data phase of previous beat --------
      if (ap_valid && vif.hreadyout && ap_write)
        mem[ap_addr] = vif.hwdata;

      // -------- address phase / response generation --------
      if (err_cycle) begin
        // second cycle of ERROR response: HREADYOUT=1, HRESP=ERROR
        vif.hreadyout <= 1'b1;
        vif.hresp     <= 1'b1;
        err_cycle     <= 1'b0;
        ap_valid      <= 1'b0;
      end
      else if (aphase && error_region) begin
        // first cycle of ERROR response: HREADYOUT=0, HRESP=ERROR
        vif.hreadyout <= 1'b0;
        vif.hresp     <= 1'b1;
        err_cycle     <= 1'b1;
        ap_valid      <= 1'b0;
      end
      else begin
        vif.hreadyout <= 1'b1;
        vif.hresp     <= 1'b0;
        ap_valid      <= aphase;
        ap_write      <= vif.hwrite;
        ap_addr       <= vif.haddr;
      end
    end
  end

  // Tie off unused protocol outputs (AXI/APB) so no X propagates
  initial begin
    vif.awready = 1'b0; vif.wready = 1'b0; vif.bvalid = 1'b0; vif.bresp = 2'b00;
    vif.arready = 1'b0; vif.rvalid = 1'b0; vif.rdata = 64'h0;
    vif.rresp = 2'b00;  vif.rlast = 1'b0;  vif.tready = 1'b0;
    vif.pready = 1'b0;  vif.prdata = 32'h0; vif.pslverr = 1'b0;
  end
endmodule
`endif
