# AHB Test Plan（AHB-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | AHB |
| 家族 | AMBA |
| 類型 | UVM VIP |
| 交付目錄 | `AHB-VIP/` |
| 目前 L1b 狀態 | PASS(functional) |

## 2. DUT / 待測對象

- 合成參考 RTL（`rtl/`）+ directed testbench（`tb/`）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | write address phase accepted (hreadyout=1) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | write data phase completed OKAY | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | read data phase OKAY response | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | hreadyout high out of reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | hresp OKAY out of reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | read data equals written data (NONSEQ) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | read data equals written data (SEQ) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | hrdata zero when no read in data phase | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | error region cycle 1: wait state with HRESP=ERROR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | error region cycle 2: complete with HRESP=ERROR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | slave recovers to OKAY after error | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Agent reset and first-transaction bring-up |
| PT-02 | Constrained-random sequence sweep (base sequence extended) |
| PT-03 | Error injection and protocol-violation response |
| PT-04 | Backpressure / wait-state interaction |
| PT-05 | End-to-end scoreboard matching (exp vs obs streams) |
| PT-06 | Coverage closure toward the self-served COV_GOAL=100 checklist |

## 5. 覆蓋與檢查

- （本 VIP 無獨立 SVA/coverage 檔案，覆蓋由 directed tb 之通過/失敗判定承擔。）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/AHB-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py AHB-VIP && python3 smoke/smoke_run.py AHB-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 無特別備註。

---
*文件版本：v1.7.5 自動產生*
