# AHB Test Plan（AHB-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | AHB |
| 家族 | AMBA |
| 類型 | UVM VIP |
| 交付目錄 | `AHB-VIP/` |
| 目前 L1b 狀態 | PASS(functional) |

## 2. DUT / 待測對象

- 合成參考 RTL（`rtl/`）+ directed testbench（`tb/`）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | reset: HREADYOUT high, HRESP OKAY, no read data or EXOKAY | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | SINGLE transfers of 1, 2, 4 and 8 bytes at every legal offset; read back on 8-byte lanes | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | INCR4/8/16 of every size, write and read back against the byte reference memory | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | WRAP4/8/16 of every size from an unaligned start, wrapping at the burst boundary | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | BUSY cycles inside INCR and WRAP bursts are ignored by the slave (data not shifted) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | random wait states of 1 and 2 cycles; address, control and write data held | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | undefined-length INCR with sparse HWSTRB: only the strobed lanes are written | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | read of the error region: two-cycle ERROR, zero data | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | INCR4 write to the error region: ERROR on the first beat, burst cancelled | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | unaligned transfer and HSIZE wider than the bus: ERROR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | non-secure burst running into the secure region: ERROR on that beat, rest cancelled and not written | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | slave back to OKAY after ERROR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | secure transfers to 0x1000-0x17FF complete; non-secure ones get ERROR and leave memory unchanged | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | non-secure transfers outside the secure region complete | 檢查成立，`FUNC_PASS` 輸出 |
| FS-15 | LDREX then STREX: HEXOKAY and the write lands | 檢查成立，`FUNC_PASS` 輸出 |
| FS-16 | second STREX without a new LDREX fails: OKAY, memory kept | 檢查成立，`FUNC_PASS` 輸出 |
| FS-17 | STREX after another master wrote the word fails | 檢查成立，`FUNC_PASS` 輸出 |
| FS-18 | two masters LDREX one word: the first STREX passes and clears the other monitor | 檢查成立，`FUNC_PASS` 輸出 |
| FS-19 | STREX to a word other than the monitored one fails | 檢查成立，`FUNC_PASS` 輸出 |
| FS-20 | read-back of all exclusive words matches the reference model | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Several masters through an interconnect (HSEL, multi-layer) |
| PT-02 | HMASTLOCK locked sequences |
| PT-03 | Back-to-back bursts without an IDLE between them |
| PT-04 | Wider data buses (128 / 256 bits) |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/ahb_compliance_checker.sv`（L1–L5，含 BUSY、HEXCL、HWSTRB lane、HEXOKAY）、`vip/ahb/ahb_protocol_checker.sv`（wait-state hold、ERROR cancel）、`rtl/amba_vip_if.sv`
- Functional coverage：`vip/ahb/ahb_coverage.svh`（cg_protocol / cg_fsm / cg_data / cg_ahb5）、`amba_cov`、`ahb_protocol_checker_sva.cg_ahb`
- Scoreboard：exp/obs 逐 burst 比對 + 8 KB byte 參考記憶體與每個 HMASTER 的 exclusive monitor 模型

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/AHB-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py AHB-VIP && python3 smoke/smoke_run.py AHB-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 無特別備註。

---
*文件版本：v1.8.0*
