// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AMBA Interface
// AXI4 + AHB5 + APB4
//============================================================================
`ifndef AMBA_VIP_IF_SV
`define AMBA_VIP_IF_SV
`include "uvm_macros.svh"

interface amba_vip_if (input logic aclk, input logic aresetn);

  // AXI4 Address Write
  logic [31:0] awaddr;
  logic [7:0]  awlen;
  logic [2:0]  awsize;
  logic [1:0]  awburst;
  logic [3:0]  awcache;
  logic [2:0]  awprot;
  logic        awvalid;
  logic        awready;
  // AXI4 Write Data
  logic [63:0] wdata;
  logic [7:0]  wstrb;
  logic        wlast;
  logic        wvalid;
  logic        wready;
  // AXI4 Write Response
  logic [1:0]  bresp;
  logic        bvalid;
  logic        bready;
  // AXI4 Address Read
  logic [31:0] araddr;
  logic [7:0]  arlen;
  logic [2:0]  arsize;
  logic [1:0]  arburst;
  logic        arvalid;
  logic        arready;
  // AXI4 Read Data
  logic [63:0] rdata;
  logic [1:0]  rresp;
  logic        rlast;
  logic        rvalid;
  logic        rready;
  // AXI4-Stream
  logic [63:0] tdata;
  logic        tvalid;
  logic        tready;
  logic        tlast;
  // AHB5
  logic [31:0] haddr;
  logic [2:0]  hburst;
  logic        hmastlock;
  logic [6:0]  hprot;
  logic [2:0]  hsize;
  logic [1:0]  htrans;
  logic [63:0] hwdata;
  logic        hwrite;
  logic [63:0] hrdata;
  logic        hreadyout;
  logic        hresp;
  // AHB5 extensions (IHI 0033B): secure / non-secure transfers, exclusive
  // access with a per-master monitor, write strobes
  logic        hnonsec;
  logic        hexcl;
  logic [3:0]  hmaster;
  logic        hexokay;
  logic [7:0]  hwstrb;
  // APB4
  logic [31:0] paddr;
  logic        penable;
  logic [2:0]  pprot;
  logic        psel;
  logic [3:0]  pstrb;
  logic [31:0] pwdata;
  logic        pwrite;
  logic [31:0] prdata;
  logic        pready;
  logic        pslverr;

  // Driver clocking block (master drives request, samples response)
  clocking drv_cb @(posedge aclk);
    default input #1step output #1ns;
    // AXI master
    output awaddr, awlen, awsize, awburst, awcache, awprot, awvalid;
    input  awready;
    output wdata, wstrb, wlast, wvalid;
    input  wready;
    input  bresp, bvalid;
    output bready;
    output araddr, arlen, arsize, arburst, arvalid;
    input  arready;
    input  rdata, rresp, rlast, rvalid;
    output rready;
    output tdata, tvalid, tlast;
    input  tready;
    // AHB master
    output haddr, hburst, hmastlock, hprot, hsize, htrans, hwdata, hwrite, hnonsec, hexcl, hmaster, hwstrb;
    input  hrdata, hreadyout, hresp, hexokay;
    // APB master
    output paddr, penable, pprot, psel, pstrb, pwdata, pwrite;
    input  prdata, pready, pslverr;
  endclocking

  // Monitor clocking block (passive sampling of everything)
  clocking mon_cb @(posedge aclk);
    default input #1step;
    input awaddr, awlen, awsize, awburst, awcache, awprot, awvalid, awready;
    input wdata, wstrb, wlast, wvalid, wready;
    input bresp, bvalid, bready;
    input araddr, arlen, arsize, arburst, arvalid, arready;
    input rdata, rresp, rlast, rvalid, rready;
    input tdata, tvalid, tready, tlast;
    input haddr, hburst, hmastlock, hprot, hsize, htrans, hwdata, hwrite, hnonsec, hexcl, hmaster, hwstrb;
    input hrdata, hreadyout, hresp, hexokay;
    input paddr, penable, pprot, psel, pstrb, pwdata, pwrite;
    input prdata, pready, pslverr;
  endclocking

  modport master_mp  (clocking drv_cb, input aclk, input aresetn);
  modport monitor_mp (clocking mon_cb, input aclk, input aresetn);
  modport slave_mp   (input aclk, input aresetn,
                      input awaddr, awlen, awsize, awburst, awcache, awprot, awvalid,
                      output awready,
                      input wdata, wstrb, wlast, wvalid, output wready,
                      output bresp, bvalid, input bready,
                      input araddr, arlen, arsize, arburst, arvalid, output arready,
                      output rdata, rresp, rlast, rvalid, input rready,
                      input tdata, tvalid, tlast, output tready,
                      input haddr, hburst, hmastlock, hprot, hsize, htrans, hwdata, hwrite,
                      input hnonsec, hexcl, hmaster, hwstrb,
                      output hrdata, hreadyout, hresp, hexokay,
                      input paddr, penable, pprot, psel, pstrb, pwdata, pwrite,
                      output prdata, pready, pslverr);

  // Assertions
  property p_axi_awvalid_ready;
    @(posedge aclk) disable iff (!aresetn) awvalid |-> ##[0:16] awready;   // AWREADY may already be high
  endproperty
  assert_axi_aw: assert property (p_axi_awvalid_ready)
    else `uvm_error("AMBA_IF", "AXI AW timeout");

  // WLAST marks beat AWLEN+1 of the burst. (The earlier form,
  // wvalid && wlast |-> $past(wvalid), failed on every single-beat burst.)
  // Tracks one outstanding write burst, which is all the AXI agent issues.
  logic [7:0] wl_awlen, wl_beat;
  always @(posedge aclk or negedge aresetn)
    if (!aresetn) begin
      wl_awlen <= 8'h0;
      wl_beat  <= 8'h0;
    end
    else begin
      if (awvalid && awready) begin
        wl_awlen <= awlen;
        wl_beat  <= 8'h0;
      end
      else if (wvalid && wready)
        wl_beat <= wlast ? 8'h0 : wl_beat + 8'h1;
    end
  property p_axi_wlast;
    @(posedge aclk) disable iff (!aresetn) (wvalid && wready) |-> (wlast == (wl_beat == wl_awlen));
  endproperty
  assert_axi_wlast: assert property (p_axi_wlast)
    else `uvm_error("AMBA_IF", "AXI WLAST without data");

  property p_axi_bresp_valid;
    @(posedge aclk) disable iff (!aresetn) bvalid |-> !$isunknown(bresp);
  endproperty
  assert_axi_bresp: assert property (p_axi_bresp_valid)
    else `uvm_error("AMBA_IF", "AXI BRESP invalid");

  property p_ahb_htrans;
    @(posedge aclk) disable iff (!aresetn) hreadyout |-> !$isunknown(htrans);
  endproperty
  assert_ahb_trans: assert property (p_ahb_htrans)
    else `uvm_error("AMBA_IF", "AHB HTRANS invalid");

  property p_apb_penable;
    @(posedge aclk) disable iff (!aresetn) (psel && !penable) |-> ##1 penable;
  endproperty
  assert_apb_en: assert property (p_apb_penable)
    else `uvm_error("AMBA_IF", "APB PENABLE timing violation");

  // Coverage
  // Coverage of the shared interface, one group per bus: an AXI, AHB or APB
  // environment drives only its own bus, so a single group mixing the three
  // could never be fully covered (the coverage report scopes each group to
  // the VIP whose protocol it names).
  covergroup cg_amba_axi @(posedge aclk);
    option.per_instance = 1;
    cp_awvalid: coverpoint awvalid { bins off = {0}; bins on = {1}; }
    cp_arvalid: coverpoint arvalid { bins off = {0}; bins on = {1}; }
    cp_wvalid:  coverpoint wvalid  { bins off = {0}; bins on = {1}; }
    cp_rvalid:  coverpoint rvalid  { bins off = {0}; bins on = {1}; }
    cp_bvalid:  coverpoint bvalid  { bins off = {0}; bins on = {1}; }
    // REACHABILITY: the AXI agent issues one transfer at a time, so AWVALID
    // and ARVALID are never high together
    cross_aw_ar:  cross cp_awvalid, cp_arvalid {
      ignore_bins aw_and_ar = binsof(cp_awvalid.on) && binsof(cp_arvalid.on); }
  endgroup
  covergroup cg_amba_ahb @(posedge aclk);
    option.per_instance = 1;
    cp_htrans:  coverpoint htrans  { bins idle = {2'b00}; bins busy = {2'b01};
                                     bins nonseq = {2'b10}; bins seq = {2'b11}; }
    cp_wait:    coverpoint hreadyout { bins ready = {1}; bins wait_ = {0}; }
    cross_trans_wait: cross cp_htrans, cp_wait {
      // REACHABILITY: this master returns to IDLE between bursts, so a NONSEQ
      // never sits in the address phase while the slave inserts wait states
      ignore_bins nonseq_wait = binsof(cp_htrans.nonseq) && binsof(cp_wait.wait_); }
  endgroup
  covergroup cg_amba_apb @(posedge aclk);
    option.per_instance = 1;
    cp_psel:    coverpoint psel    { bins off = {0}; bins on = {1}; }
    cp_penable: coverpoint penable { bins off = {0}; bins on = {1}; }
    // PENABLE without PSEL is a protocol error the checkers report
    cross_psel_en: cross cp_psel, cp_penable {
      ignore_bins en_without_sel = binsof(cp_psel.off) && binsof(cp_penable.on); }
  endgroup

  cg_amba_axi cg_axi = new();
  cg_amba_ahb cg_ahb = new();
  cg_amba_apb cg_apb = new();

endinterface
`endif
