// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// AHB Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 16
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
`ifndef AHB_COMPLIANCE_CHECKER_SV
`define AHB_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================================
// ahb_compliance_checker_sva -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module ahb_compliance_checker_sva (amba_vip_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; l4_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_ahb_htrans_valid; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.htrans inside {3'b000,3'b001,3'b010,3'b011}; endproperty
  assert_p_ahb_htrans_valid: assert property(p_ahb_htrans_valid) l1_pass[0]++; else begin `uvm_warning("AHB_L1", "HTRANS valid failed"); l1_fail[0]++; end
  cover_p_ahb_htrans_valid: cover property(p_ahb_htrans_valid);
  property p_ahb_hburst_valid; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.hburst inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ahb_hburst_valid: assert property(p_ahb_hburst_valid) l1_pass[1]++; else begin `uvm_warning("AHB_L1", "HBURST valid failed"); l1_fail[1]++; end
  cover_p_ahb_hburst_valid: cover property(p_ahb_hburst_valid);
  property p_ahb_hsize_valid; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.hsize inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ahb_hsize_valid: assert property(p_ahb_hsize_valid) l1_pass[2]++; else begin `uvm_warning("AHB_L1", "HSIZE valid failed"); l1_fail[2]++; end
  cover_p_ahb_hsize_valid: cover property(p_ahb_hsize_valid);
  property p_ahb_hresp_valid; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.hresp inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ahb_hresp_valid: assert property(p_ahb_hresp_valid) l1_pass[3]++; else begin `uvm_warning("AHB_L1", "HRESP valid failed"); l1_fail[3]++; end
  cover_p_ahb_hresp_valid: cover property(p_ahb_hresp_valid);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_ahb_hready_resp; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.htrans != 3'b000 |-> ##[1:16] vif.hreadyout; endproperty
  assert_p_ahb_hready_resp: assert property(p_ahb_hready_resp) l2_pass[0]++; else begin `uvm_warning("AHB_L2", "HREADYOUT follows transfer failed"); l2_fail[0]++; end
  cover_p_ahb_hready_resp: cover property(p_ahb_hready_resp);
  property p_ahb_lock_burst; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.hmastlock |-> vif.htrans inside {3'b010,3'b011}; endproperty
  assert_p_ahb_lock_burst: assert property(p_ahb_lock_burst) l2_pass[1]++; else begin `uvm_warning("AHB_L2", "HMASTLOCK with burst failed"); l2_fail[1]++; end
  cover_p_ahb_lock_burst: cover property(p_ahb_lock_burst);
  property p_ahb_addr_align; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.htrans != 3'b000 |-> (vif.haddr & ((1<<vif.hsize)-1)) == 0; endproperty
  assert_p_ahb_addr_align: assert property(p_ahb_addr_align) l2_pass[2]++; else begin `uvm_warning("AHB_L2", "Address aligned failed"); l2_fail[2]++; end
  cover_p_ahb_addr_align: cover property(p_ahb_addr_align);
  property p_ahb_write_data; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.hwrite && vif.htrans != 3'b000 |-> !$isunknown(vif.hwdata); endproperty
  assert_p_ahb_write_data: assert property(p_ahb_write_data) l2_pass[3]++; else begin `uvm_warning("AHB_L2", "HWDATA valid on write failed"); l2_fail[3]++; end
  cover_p_ahb_write_data: cover property(p_ahb_write_data);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: a completed BUSY beat must be followed by BUSY or SEQ of the same burst
  property p_ahb_l3_busy_continue;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.htrans == 2'b01 && vif.hreadyout) |=> (vif.htrans inside {2'b01, 2'b11} || !vif.hreadyout && $stable(vif.htrans));
  endproperty
  assert_p_ahb_l3_busy_continue: assert property(p_ahb_l3_busy_continue) l3_pass[0]++;
    else begin `uvm_warning("AHB_L3", "BUSY not followed by BUSY/SEQ"); l3_fail[0]++; end
  cover_p_ahb_l3_busy_continue: cover property(p_ahb_l3_busy_continue);

  // L3-2: control (HWRITE/HSIZE/HBURST) must stay stable across beats of a burst
  property p_ahb_l3_burst_ctrl_stable;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.htrans == 2'b11 && vif.hreadyout) |->
      (vif.hwrite == $past(vif.hwrite) && vif.hsize == $past(vif.hsize) && vif.hburst == $past(vif.hburst));
  endproperty
  assert_p_ahb_l3_burst_ctrl_stable: assert property(p_ahb_l3_burst_ctrl_stable) l3_pass[1]++;
    else begin `uvm_warning("AHB_L3", "Control changed mid-burst"); l3_fail[1]++; end
  cover_p_ahb_l3_burst_ctrl_stable: cover property(p_ahb_l3_burst_ctrl_stable);

  // L3-3: INCR-type bursts must not cross a 1KB address boundary
  property p_ahb_l3_incr_1kb;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.htrans == 2'b11 && vif.hreadyout && vif.hburst[0] == 1'b1) |->
      (vif.haddr[31:10] == $past(vif.haddr[31:10]));
  endproperty
  assert_p_ahb_l3_incr_1kb: assert property(p_ahb_l3_incr_1kb) l3_pass[2]++;
    else begin `uvm_warning("AHB_L3", "INCR burst crossed 1KB boundary"); l3_fail[2]++; end
  cover_p_ahb_l3_incr_1kb: cover property(p_ahb_l3_incr_1kb);

  // L3-4: WRAP burst SEQ address steps by beat size or wraps back to the boundary
  property p_ahb_l3_wrap_boundary;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.htrans == 2'b11 && vif.hreadyout && vif.hburst[2:1] == 2'b01) |->
      (((vif.haddr - $past(vif.haddr)) == (32'h1 << vif.hsize)) ||
       ((vif.haddr & ((((32'h1 << vif.hsize) << (vif.hburst == 3'b010 ? 2 : vif.hburst == 3'b100 ? 3 : 4))) - 32'h1)) == 32'h0));
  endproperty
  assert_p_ahb_l3_wrap_boundary: assert property(p_ahb_l3_wrap_boundary) l3_pass[3]++;
    else begin `uvm_warning("AHB_L3", "WRAP burst address not within wrap boundary"); l3_fail[3]++; end
  cover_p_ahb_l3_wrap_boundary: cover property(p_ahb_l3_wrap_boundary);

  // ---------------- L4: AHB5 protocol-specific rules (4) ----------------
  // L4-1: NONSEQ must not be followed by SEQ when HREADYOUT was low is illegal;
  //       SEQ may only follow NONSEQ/SEQ of the same burst (control stable check)
  property p_ahb_l4_seq_follows;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.htrans == 2'b11 && vif.hreadyout) |->
      ($past(vif.htrans) inside {2'b10, 2'b11});
  endproperty
  assert_p_ahb_l4_seq_follows: assert property(p_ahb_l4_seq_follows) l4_pass[0]++;
    else begin `uvm_warning("AHB_L4", "SEQ without preceding NONSEQ/SEQ"); l4_fail[0]++; end
  cover_p_ahb_l4_seq_follows: cover property(p_ahb_l4_seq_follows);

  // L4-2: during wait states (HREADYOUT=0) address-phase control must hold stable
  property p_ahb_l4_wait_stable;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (!vif.hreadyout) |=> $stable({vif.haddr, vif.htrans, vif.hwrite, vif.hsize, vif.hburst});
  endproperty
  assert_p_ahb_l4_wait_stable: assert property(p_ahb_l4_wait_stable) l4_pass[1]++;
    else begin `uvm_warning("AHB_L4", "Control changed during wait state"); l4_fail[1]++; end
  cover_p_ahb_l4_wait_stable: cover property(p_ahb_l4_wait_stable);

  // L4-3: two-cycle ERROR response: HRESP=ERROR with HREADYOUT=0 must be
  //       followed by HREADYOUT=1 with HRESP still ERROR
  property p_ahb_l4_err_two_cycle;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.hresp && !vif.hreadyout) |=> (vif.hresp && vif.hreadyout);
  endproperty
  assert_p_ahb_l4_err_two_cycle: assert property(p_ahb_l4_err_two_cycle) l4_pass[2]++;
    else begin `uvm_warning("AHB_L4", "ERROR response not two-cycle"); l4_fail[2]++; end
  cover_p_ahb_l4_err_two_cycle: cover property(p_ahb_l4_err_two_cycle);

  // L4-4: WRAP burst address must stay inside the wrap boundary:
  //       consecutive beat address delta equals beat size (or wraps)
  property p_ahb_l4_incr_addr;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.htrans == 2'b11 && vif.hreadyout && vif.hburst[0] == 1'b1) |->
      ((vif.haddr - $past(vif.haddr)) == (32'h1 << vif.hsize));
  endproperty
  assert_p_ahb_l4_incr_addr: assert property(p_ahb_l4_incr_addr) l4_pass[3]++;
    else begin `uvm_warning("AHB_L4", "INCR burst address step mismatch"); l4_fail[3]++; end
  cover_p_ahb_l4_incr_addr: cover property(p_ahb_l4_incr_addr);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0;
    int l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ?
                ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("AHB_RPT", $sformatf("=== AHB Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("AHB_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("AHB_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("AHB_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("AHB_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("AHB_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov,
              l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule

// ============================================================================
// ahb_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the ahb_compliance_checker_sva module above)
// ============================================================================
class ahb_compliance_checker extends uvm_component;
  `uvm_component_utils(ahb_compliance_checker)
  function new(string name = "ahb_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

`endif
