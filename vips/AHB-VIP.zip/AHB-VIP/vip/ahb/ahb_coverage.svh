// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_coverage.svh -- AHB5 functional coverage:
//   cg_protocol : transfer config (dir x burst x size x len, resp) + crosses
//   cg_fsm      : HTRANS bus-state transitions
//   cg_data     : data pattern corners

`ifndef AHB_COVERAGE_SVH
`define AHB_COVERAGE_SVH

class ahb_coverage extends uvm_subscriber #(amba_seq_item);
  `uvm_component_utils(ahb_coverage)

  amba_seq_item tr;
  logic [1:0] cur_htrans;

  covergroup cg_protocol;
    option.per_instance = 1;
    cp_write: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cp_burst: coverpoint tr.txn.burst { bins fixed = {BURST_FIXED};
                                        bins incr  = {BURST_INCR};
                                        bins wrap  = {BURST_WRAP}; }
    cp_size: coverpoint tr.txn.size { bins b1 = {SIZE_1B}; bins b2 = {SIZE_2B};
                                      bins b4 = {SIZE_4B}; bins b8 = {SIZE_8B}; }
    cp_len: coverpoint tr.txn.len { bins single = {1}; bins b4 = {4};
                                    bins b8 = {8}; bins b16 = {16};
                                    bins other = default; }
    cp_resp: coverpoint tr.txn.resp { bins ok = {RESP_OKAY}; bins err = {RESP_SLVERR}; }
    cx_wr_burst: cross cp_write, cp_burst;
    cx_wr_len:   cross cp_write, cp_len;
    cx_burst_size: cross cp_burst, cp_size;
  endgroup

  covergroup cg_fsm with function sample(logic [1:0] s);
    option.per_instance = 1;
    cp_state: coverpoint s {
      bins idle   = {2'b00};
      bins busy   = {2'b01};
      bins nonseq = {2'b10};
      bins seq    = {2'b11};
    }
    cp_trans: coverpoint s {
      bins start_burst = (2'b00 => 2'b10);
      bins burst_cont  = (2'b10 => 2'b11);
      bins seq_chain   = (2'b11 => 2'b11);
      bins burst_end   = (2'b11 => 2'b00);
      bins b2b         = (2'b11 => 2'b10);
    }
  endgroup

  covergroup cg_data;
    option.per_instance = 1;
    cp_data: coverpoint tr.txn.data[0] iff (tr.txn.data.size() > 0) {
      bins zero = {64'h0};
      bins ones = {64'hFFFF_FFFF_FFFF_FFFF};
      bins aa55 = {64'hAAAA_AAAA_AAAA_AAAA, 64'h5555_5555_5555_5555};
      bins other = default;
    }
    cp_w: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cx_wr_data: cross cp_data, cp_w;
  endgroup

  virtual amba_vip_if vif;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_data     = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif));
  endfunction

  function void write(amba_seq_item t);
    tr = t;
    cur_htrans = (vif != null) ? vif.htrans : 2'b00;
    cg_protocol.sample();
    cg_fsm.sample(cur_htrans);
    cg_data.sample();
  endfunction
endclass
`endif
