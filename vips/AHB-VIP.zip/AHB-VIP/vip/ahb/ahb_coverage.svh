// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_coverage.svh -- AHB5 functional coverage:
//   cg_protocol : transfer config (dir x burst x size x len, resp) + crosses
//   cg_fsm      : HTRANS bus-state transitions
//   cg_data     : data pattern corners

`ifndef AHB_COVERAGE_SVH
`define AHB_COVERAGE_SVH

class ahb_coverage extends uvm_subscriber #(amba_seq_item);
  `uvm_component_utils(ahb_coverage)

  amba_seq_item tr;

  covergroup cg_protocol;
    option.per_instance = 1;
    cp_write: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    // REACHABILITY: AHB has no FIXED burst (c_ahb_legal never generates it)
    cp_burst: coverpoint tr.txn.burst { ignore_bins fixed = {BURST_FIXED, BURST_RSVD};
                                        bins incr  = {BURST_INCR};
                                        bins wrap  = {BURST_WRAP}; }
    cp_size: coverpoint tr.txn.size { bins b1 = {SIZE_1B}; bins b2 = {SIZE_2B};
                                      bins b4 = {SIZE_4B}; bins b8 = {SIZE_8B}; }
    cp_len: coverpoint tr.txn.len { bins single = {1}; bins b4 = {4};
                                    bins b8 = {8}; bins b16 = {16};
                                    bins other = default; }
    cp_resp: coverpoint tr.txn.resp { bins ok = {RESP_OKAY}; bins err = {RESP_SLVERR}; bins exok = {RESP_EXOKAY}; }
    cx_wr_burst: cross cp_write, cp_burst;
    cx_wr_len:   cross cp_write, cp_len;
    cx_burst_size: cross cp_burst, cp_size;
  endgroup

  bit sparse;   // a write beat with a strobe off inside its byte lanes

  // AHB5: BUSY inside bursts, wait states, secure / non-secure, exclusive
  // access, write strobes
  covergroup cg_ahb5;
    option.per_instance = 1;
    cp_write: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cp_busy: coverpoint tr.txn.n_busy iff (tr.txn.len > 1) { bins none = {0}; bins one = {1}; bins more = {[2:$]}; }
    cp_burst: coverpoint tr.txn.burst { bins incr = {BURST_INCR}; bins wrap = {BURST_WRAP}; }
    cp_wait: coverpoint tr.txn.n_wait { bins none = {0}; bins few = {[1:2]}; bins many = {[3:$]}; }
    cp_nonsec: coverpoint tr.txn.nonsec { bins secure = {0}; bins nonsec = {1}; }
    cp_secreg: coverpoint (tr.txn.addr[12:11] == 2'b10) { bins other = {0}; bins secure_region = {1}; }
    cp_excl: coverpoint {tr.txn.excl, tr.txn.write, tr.txn.resp == RESP_EXOKAY} {
      bins normal = {3'b000, 3'b010}; bins ex_rd = {3'b101}; bins ex_wr_ok = {3'b111}; bins ex_wr_fail = {3'b110}; }
    cp_strb: coverpoint sparse iff (tr.txn.write) { bins full = {0}; bins partial = {1}; }
    cp_master: coverpoint tr.txn.id { bins m[4] = {[0:15]}; }
    cx_busy_burst: cross cp_busy, cp_burst;
    cx_wait_write: cross cp_wait, cp_write;
    cx_sec: cross cp_nonsec, cp_secreg, cp_write;
  endgroup

  // Sampled every clock on which an address phase is accepted (HREADYOUT=1),
  // so the transitions are real bus-state transitions.
  covergroup cg_fsm with function sample(logic [1:0] s);
    option.per_instance = 1;
    cp_state: coverpoint s {
      bins idle   = {2'b00};
      bins busy   = {2'b01};
      bins nonseq = {2'b10};
      bins seq    = {2'b11};
    }
    cp_trans: coverpoint s {
      bins start_burst = (2'b00 => 2'b10);
      bins burst_cont  = (2'b10 => 2'b11);
      bins seq_chain   = (2'b11 => 2'b11);
      bins burst_end   = (2'b11 => 2'b00);
      bins single_end  = (2'b10 => 2'b00);
      bins seq_busy    = (2'b11 => 2'b01);
      bins busy_seq    = (2'b01 => 2'b11);
      bins nonseq_busy = (2'b10 => 2'b01);
    }
  endgroup

  covergroup cg_data;
    option.per_instance = 1;
    cp_data: coverpoint tr.txn.data[0] iff (tr.txn.data.size() > 0) {
      bins zero = {64'h0};
      bins ones = {64'hFFFF_FFFF_FFFF_FFFF};
      bins aa55 = {64'hAAAA_AAAA_AAAA_AAAA, 64'h5555_5555_5555_5555};
      bins other = default;
    }
    cp_w: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cx_wr_data: cross cp_data, cp_w;
  endgroup

  virtual amba_vip_if vif;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_data     = new();
    cg_ahb5     = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif));
  endfunction

  task run_phase(uvm_phase phase);
    if (vif == null) return;
    forever begin
      @(posedge vif.aclk);
      if (vif.aresetn === 1'b1 && vif.hreadyout === 1'b1) cg_fsm.sample(vif.htrans);
    end
  endtask

  function void write(amba_seq_item t);
    tr = t;
    sparse = 0;
    foreach (t.txn.strb[i]) if (t.txn.strb[i] != t.txn.beat_lanes(i)) sparse = 1;
    cg_protocol.sample();
    cg_data.sample();
    cg_ahb5.sample();
  endfunction
endclass
`endif
