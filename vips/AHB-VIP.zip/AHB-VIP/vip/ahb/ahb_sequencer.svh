// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_sequencer.svh -- AHB5 master sequencer

`ifndef AHB_SEQUENCER_SVH
`define AHB_SEQUENCER_SVH

class ahb_sequencer extends uvm_sequencer #(amba_seq_item);
  `uvm_component_utils(ahb_sequencer)
  function new(string name = "ahb_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

`endif
