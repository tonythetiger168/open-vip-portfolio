// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_driver.svh -- AHB5 master driver: pipelined address/data phases,
// burst progression (NONSEQ -> SEQ), wait-state handling via HREADYOUT,
// HRESP error detection.

`ifndef AHB_DRIVER_SVH
`define AHB_DRIVER_SVH

class ahb_driver extends uvm_driver #(amba_seq_item);
  `uvm_component_utils(ahb_driver)
  virtual amba_vip_if vif;
  uvm_analysis_port #(amba_seq_item) drv_ap;  // expected items for scoreboard

  // AHB HTRANS encodings (2-bit on the wire)
  localparam logic [1:0] HTRANS_IDLE   = 2'b00;
  localparam logic [1:0] HTRANS_BUSY   = 2'b01;
  localparam logic [1:0] HTRANS_NONSEQ = 2'b10;
  localparam logic [1:0] HTRANS_SEQ    = 2'b11;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "AHB virtual interface not set")
  endfunction

  // Bytes per beat for a given HSIZE encoding
  function automatic int unsigned bytes_per_beat(axsize_e sz);
    return (1 << int'(sz));
  endfunction

  function automatic logic [2:0] hburst_of(amba_txn t);
    if (t.len == 1) return 3'b000;                          // SINGLE
    if (t.burst == BURST_WRAP)
      case (t.len)
        4:  return 3'b010;                                  // WRAP4
        8:  return 3'b100;                                  // WRAP8
        default: return 3'b110;                             // WRAP16
      endcase
    else
      case (t.len)
        4:  return 3'b011;                                  // INCR4
        8:  return 3'b101;                                  // INCR8
        16: return 3'b111;                                  // INCR16
        default: return 3'b001;                             // INCR (undefined length)
      endcase
  endfunction

  task drive_addr(logic [1:0] trans, logic [31:0] addr, amba_txn t);
    vif.drv_cb.htrans <= trans;
    vif.drv_cb.haddr  <= addr;
    vif.drv_cb.hwrite <= t.write;
    vif.drv_cb.hsize  <= t.size;
    vif.drv_cb.hburst <= hburst_of(t);
    vif.drv_cb.hprot  <= {3'b000, t.prot, 1'b0};
    vif.drv_cb.hmastlock <= 1'b0;
  endtask

  task run_phase(uvm_phase phase);
    amba_seq_item item;
    // Idle the bus
    vif.drv_cb.htrans <= HTRANS_IDLE;
    vif.drv_cb.haddr  <= '0;
    vif.drv_cb.hwrite <= 1'b0;
    vif.drv_cb.hsize  <= 3'b010;
    vif.drv_cb.hburst <= 3'b000;
    vif.drv_cb.hwdata <= '0;
    wait (vif.aresetn === 1'b1);
    forever begin
      seq_item_port.get_next_item(item);
      `uvm_info("DRV", {"drive: ", item.convert2string()}, UVM_HIGH)
      drive_burst(item);
      drv_ap.write(item);          // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask

  // Compute address of beat i within the burst
  function automatic logic [31:0] beat_addr(amba_txn t, int i, int unsigned bpb);
    if (t.burst == BURST_WRAP) begin
      int unsigned wrap_bytes = t.len * bpb;
      logic [31:0] base = t.addr - (t.addr % wrap_bytes);
      return base + ((t.addr + i * bpb) % wrap_bytes);
    end
    else if (t.burst == BURST_FIXED) return t.addr;
    else return t.addr + i * bpb;
  endfunction

  // Pipelined burst: address phase of beat i+1 overlaps data phase of beat i.
  // Edge e (1..len)   : address beat e-1 completes; data beat e-2 completes.
  // Edge len+1        : data beat len-1 completes.
  task drive_burst(amba_seq_item item);
    amba_txn t = item.txn;
    int unsigned bpb = bytes_per_beat(t.size);
    bit err_seen = 1'b0;

    repeat (t.delay) @(vif.drv_cb);

    // Beat 0 address phase (NONSEQ)
    @(vif.drv_cb);
    drive_addr(HTRANS_NONSEQ, t.addr, t);

    for (int e = 1; e <= t.len && !err_seen; e++) begin
      do @(vif.drv_cb); while (vif.drv_cb.hreadyout !== 1'b1);
      // finish data phase of beat e-2
      if (e >= 2) begin
        if (vif.drv_cb.hresp === 1'b1) begin
          err_seen = 1'b1;
          t.resp = RESP_SLVERR;
          t.len  = e - 1;
          vif.drv_cb.htrans <= HTRANS_IDLE;
          break;
        end
        if (!t.write) t.data[e-2] = vif.drv_cb.hrdata;
      end
      // address phase of beat e (or IDLE at burst end)
      if (e < t.len) drive_addr(HTRANS_SEQ, beat_addr(t, e, bpb), t);
      else           vif.drv_cb.htrans <= HTRANS_IDLE;
      // write data phase of beat e-1
      if (t.write) vif.drv_cb.hwdata <= t.data[e-1];
    end

    // trailing edge: complete last data beat
    if (!err_seen) begin
      do @(vif.drv_cb); while (vif.drv_cb.hreadyout !== 1'b1);
      if (vif.drv_cb.hresp === 1'b1) begin
        err_seen = 1'b1;
        t.resp = RESP_SLVERR;
      end
      else if (!t.write) t.data[t.len-1] = vif.drv_cb.hrdata;
    end

    vif.drv_cb.htrans <= HTRANS_IDLE;
    if (!err_seen) t.resp = RESP_OKAY;
  endtask

endclass
`endif
