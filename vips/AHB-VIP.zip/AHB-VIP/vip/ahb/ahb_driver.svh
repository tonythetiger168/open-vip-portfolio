// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_driver.svh -- AHB5 master driver: pipelined address/data phases,
// burst progression (NONSEQ -> SEQ), wait-state handling via HREADYOUT,
// HRESP error detection.

`ifndef AHB_DRIVER_SVH
`define AHB_DRIVER_SVH

class ahb_driver extends uvm_driver #(amba_seq_item);
  `uvm_component_utils(ahb_driver)
  virtual amba_vip_if vif;
  uvm_analysis_port #(amba_seq_item) drv_ap;  // expected items for scoreboard

  // AHB HTRANS encodings (2-bit on the wire)
  localparam logic [1:0] HTRANS_IDLE   = 2'b00;
  localparam logic [1:0] HTRANS_BUSY   = 2'b01;
  localparam logic [1:0] HTRANS_NONSEQ = 2'b10;
  localparam logic [1:0] HTRANS_SEQ    = 2'b11;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "AHB virtual interface not set")
  endfunction

  // Bytes per beat for a given HSIZE encoding
  function automatic int unsigned bytes_per_beat(axsize_e sz);
    return (1 << int'(sz));
  endfunction

  function automatic logic [2:0] hburst_of(amba_txn t);
    if (t.len == 1) return 3'b000;                          // SINGLE
    if (t.burst == BURST_WRAP)
      case (t.len)
        4:  return 3'b010;                                  // WRAP4
        8:  return 3'b100;                                  // WRAP8
        default: return 3'b110;                             // WRAP16
      endcase
    else
      case (t.len)
        4:  return 3'b011;                                  // INCR4
        8:  return 3'b101;                                  // INCR8
        16: return 3'b111;                                  // INCR16
        default: return 3'b001;                             // INCR (undefined length)
      endcase
  endfunction

  task drive_addr(logic [1:0] trans, logic [31:0] addr, amba_txn t);
    vif.drv_cb.htrans  <= trans;
    vif.drv_cb.haddr   <= addr;
    vif.drv_cb.hwrite  <= t.write;
    vif.drv_cb.hsize   <= t.size;
    vif.drv_cb.hburst  <= hburst_of(t);
    vif.drv_cb.hprot   <= {3'b000, t.prot, 1'b0};
    vif.drv_cb.hmastlock <= t.lock && trans != HTRANS_IDLE;
    vif.drv_cb.hnonsec <= t.nonsec;
    vif.drv_cb.hexcl   <= t.excl;
    vif.drv_cb.hmaster <= t.id;
  endtask

  task run_phase(uvm_phase phase);
    amba_seq_item item;
    // Idle the bus
    vif.drv_cb.htrans  <= HTRANS_IDLE;
    vif.drv_cb.haddr   <= '0;
    vif.drv_cb.hwrite  <= 1'b0;
    vif.drv_cb.hsize   <= 3'b010;
    vif.drv_cb.hburst  <= 3'b000;
    vif.drv_cb.hwdata  <= '0;
    vif.drv_cb.hwstrb  <= '0;
    vif.drv_cb.hnonsec <= 1'b0;
    vif.drv_cb.hexcl   <= 1'b0;
    vif.drv_cb.hmastlock <= 1'b0;
    vif.drv_cb.hmaster <= 4'h0;
    wait (vif.aresetn === 1'b1);
    forever begin
      seq_item_port.get_next_item(item);
      `uvm_info("DRV", {"drive: ", item.convert2string()}, UVM_HIGH)
      drive_burst(item);
      drv_ap.write(item);          // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask

  // Pipelined burst, one clock at a time. At every edge with HREADY high the
  // data phase in progress completes and the transfer in the address phase
  // (unless IDLE or BUSY) becomes the data phase. Address, control and write
  // data are held through wait states. Before each SEQ beat a BUSY cycle is
  // inserted with t.busy_pct percent chance (HADDR already the next beat's).
  // In the first cycle of a two-cycle ERROR response (HRESP=ERROR,
  // HREADYOUT=0) the master cancels the rest of the burst by driving
  // HTRANS=IDLE (IHI 0033 5.1.3).
  task drive_burst(amba_seq_item item);
    amba_txn t = item.txn;
    int  a = 0;          // next beat to put in the address phase
    int  d = -1;         // beat in the data phase
    int  done_beats = 0;
    bit  in_addr = 0;    // a beat (not BUSY) is in the address phase
    bit  err = 0, exok = 0;
    logic [7:0] s[];

    s = new[t.len];
    foreach (s[i]) s[i] = ((t.strb.size() > i) ? t.strb[i] : 8'hFF) & t.beat_lanes(i);
    t.strb = s;
    if (t.data.size() != t.len) t.data = new[t.len](t.data);

    repeat (t.delay) @(vif.drv_cb);
    @(vif.drv_cb);
    drive_addr(HTRANS_NONSEQ, t.beat_addr(0), t);
    in_addr = 1; a = 1;
    forever begin
      @(vif.drv_cb);
      if (vif.drv_cb.hreadyout !== 1'b1) begin
        if (vif.drv_cb.hresp === 1'b1) begin   // cancel
          vif.drv_cb.htrans <= HTRANS_IDLE; vif.drv_cb.hmastlock <= 1'b0;
        end
        continue;
      end
      // ---- data phase of beat d completes ----
      if (d >= 0) begin
        done_beats = d + 1;
        if (vif.drv_cb.hresp === 1'b1) err = 1;
        if (!t.write) t.data[d] = vif.drv_cb.hrdata;
        if (vif.drv_cb.hexokay === 1'b1) exok = 1;
      end
      if (err) break;
      d = in_addr ? a - 1 : -1;
      // ---- next address phase ----
      if (a < t.len && (d >= 0 || !in_addr)) begin
        if (in_addr && $urandom_range(99) < t.busy_pct) begin
          drive_addr(HTRANS_BUSY, t.beat_addr(a), t);
          in_addr = 0;
        end
        else begin
          drive_addr(HTRANS_SEQ, t.beat_addr(a), t);
          in_addr = 1; a++;
        end
      end
      else begin
        vif.drv_cb.htrans <= HTRANS_IDLE;
        vif.drv_cb.hexcl  <= 1'b0; vif.drv_cb.hmastlock <= 1'b0;
        in_addr = 0;
      end
      // ---- write data of the new data phase ----
      if (d >= 0 && t.write) begin
        vif.drv_cb.hwdata <= t.data[d];
        vif.drv_cb.hwstrb <= t.strb[d];
      end
      if (d < 0 && !in_addr && a >= t.len) break;
    end
    vif.drv_cb.htrans <= HTRANS_IDLE;
    vif.drv_cb.hexcl  <= 1'b0; vif.drv_cb.hmastlock <= 1'b0;
    if (done_beats < t.len) begin
      t.len  = done_beats;
      t.data = new[done_beats](t.data);
      t.strb = new[done_beats](t.strb);
    end
    t.resp = err ? RESP_SLVERR : (exok ? RESP_EXOKAY : RESP_OKAY);
  endtask

endclass
`endif
