// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_monitor.svh -- AHB5 monitor: reconstructs burst transactions from the
// pipelined address/data phases on the bus and publishes them via analysis
// port.

`ifndef AHB_MONITOR_SVH
`define AHB_MONITOR_SVH

class ahb_monitor extends uvm_monitor;
  `uvm_component_utils(ahb_monitor)
  virtual amba_vip_if vif;
  uvm_analysis_port #(amba_seq_item) ap;
  int unsigned txn_count = 0;

  localparam logic [1:0] HTRANS_IDLE   = 2'b00;
  localparam logic [1:0] HTRANS_BUSY   = 2'b01;
  localparam logic [1:0] HTRANS_NONSEQ = 2'b10;
  localparam logic [1:0] HTRANS_SEQ    = 2'b11;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "AHB virtual interface not set")
  endfunction

  function automatic int burst_len_of(logic [2:0] hburst);
    case (hburst)
      3'b000:  return 1;    // SINGLE
      3'b010, 3'b011: return 4;
      3'b100, 3'b101: return 8;
      3'b110, 3'b111: return 16;
      default: return -1;   // INCR undefined length
    endcase
  endfunction

  task run_phase(uvm_phase phase);
    amba_seq_item item;
    int beat;
    int exp_len;
    bit in_burst;
    bit pend_write;                 // data-phase write flag (1-cycle pipe)
    bit pend_valid;
    wait (vif.aresetn === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.hreadyout !== 1'b1) continue;  // both phases extended

      // ---- data phase of the previous address beat ----
      if (pend_valid && item != null) begin
        if (pend_write) item.txn.data[beat] = vif.mon_cb.hwdata;
        else            item.txn.data[beat] = vif.mon_cb.hrdata;
        beat++;
        if (vif.mon_cb.hresp === 1'b1) begin
          item.txn.resp = RESP_SLVERR;
          item.txn.len  = beat;
          item.txn.data = new[beat](item.txn.data);
          txn_count++;
          `uvm_info("MON", {"mon(ERROR): ", item.convert2string()}, UVM_HIGH)
          ap.write(item);
          item = null;
          in_burst = 1'b0;
        end
        else if (beat >= exp_len && exp_len > 0) begin
          item.txn.len = beat;
          item.txn.data = new[beat](item.txn.data);
          txn_count++;
          `uvm_info("MON", {"mon: ", item.convert2string()}, UVM_HIGH)
          ap.write(item);
          item = null;
          in_burst = 1'b0;
        end
      end
      pend_valid = 1'b0;

      // ---- address phase ----
      if (vif.mon_cb.htrans == HTRANS_NONSEQ) begin
        // close any dangling burst (error-terminated INCR)
        if (item != null && in_burst) begin
          item.txn.len = beat;
          item.txn.data = new[beat](item.txn.data);
          txn_count++;
          ap.write(item);
        end
        item = amba_seq_item::type_id::create("item");
        item.txn.protocol = AHB5;
        item.txn.addr  = vif.mon_cb.haddr;
        item.txn.write = vif.mon_cb.hwrite;
        item.txn.size  = axsize_e'(vif.mon_cb.hsize);
        item.txn.burst = (vif.mon_cb.hburst[0]) ? BURST_WRAP : BURST_INCR;
        if (vif.mon_cb.hburst == 3'b000 || vif.mon_cb.hburst == 3'b001)
          item.txn.burst = BURST_INCR;
        item.txn.resp  = RESP_OKAY;
        exp_len = burst_len_of(vif.mon_cb.hburst);
        if (exp_len < 0) exp_len = 64;         // INCR: close on IDLE/NONSEQ
        item.txn.data = new[exp_len];
        beat = 0;
        in_burst = 1'b1;
        pend_write  = vif.mon_cb.hwrite;
        pend_valid  = 1'b1;
      end
      else if (vif.mon_cb.htrans == HTRANS_SEQ && in_burst && item != null) begin
        pend_write = item.txn.write;
        pend_valid = 1'b1;
      end
      else begin
        // IDLE/BUSY: close an open undefined-length burst
        if (item != null && in_burst && beat > 0) begin
          item.txn.len = beat;
          item.txn.data = new[beat](item.txn.data);
          txn_count++;
          `uvm_info("MON", {"mon: ", item.convert2string()}, UVM_HIGH)
          ap.write(item);
          item = null;
        end
        in_burst = 1'b0;
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("AHB monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
