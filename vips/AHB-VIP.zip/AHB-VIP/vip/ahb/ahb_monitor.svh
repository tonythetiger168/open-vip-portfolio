// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_monitor.svh -- AHB5 monitor: reconstructs burst transactions from the
// pipelined address/data phases on the bus and publishes them via analysis
// port.

`ifndef AHB_MONITOR_SVH
`define AHB_MONITOR_SVH

class ahb_monitor extends uvm_monitor;
  `uvm_component_utils(ahb_monitor)
  virtual amba_vip_if vif;
  uvm_analysis_port #(amba_seq_item) ap;
  int unsigned txn_count = 0;

  localparam logic [1:0] HTRANS_IDLE   = 2'b00;
  localparam logic [1:0] HTRANS_BUSY   = 2'b01;
  localparam logic [1:0] HTRANS_NONSEQ = 2'b10;
  localparam logic [1:0] HTRANS_SEQ    = 2'b11;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "AHB virtual interface not set")
  endfunction

  function automatic int burst_len_of(logic [2:0] hburst);
    case (hburst)
      3'b000:  return 1;    // SINGLE
      3'b010, 3'b011: return 4;
      3'b100, 3'b101: return 8;
      3'b110, 3'b111: return 16;
      default: return -1;   // INCR undefined length
    endcase
  endfunction

  function void publish(amba_seq_item item);
    txn_count++;
    `uvm_info("MON", {"mon: ", item.convert2string()}, UVM_HIGH)
    ap.write(item);
  endfunction

  // At every edge with HREADY high the data phase in progress completes
  // (write data / strobes, or read data, with HRESP and HEXOKAY) and the
  // address phase is taken: NONSEQ opens a burst, SEQ adds a beat, BUSY
  // keeps the burst open, IDLE (or a NONSEQ) closes it.
  task run_phase(uvm_phase phase);
    amba_seq_item item;
    logic [63:0] d[$];
    logic [7:0]  st[$];
    bit pend, closed, exok;
    int unsigned waits;
    forever begin
      @(vif.mon_cb);
      if (vif.aresetn !== 1'b1) begin item = null; pend = 0; d.delete(); st.delete(); continue; end
      if (vif.mon_cb.hreadyout !== 1'b1) begin
        if (pend && vif.mon_cb.hresp !== 1'b1) waits++;
        continue;
      end
      // ---- data phase completes ----
      if (pend && item != null) begin
        d.push_back(item.txn.write ? vif.mon_cb.hwdata : vif.mon_cb.hrdata);
        st.push_back(vif.mon_cb.hwstrb);
        if (vif.mon_cb.hexokay === 1'b1) exok = 1;
        if (vif.mon_cb.hresp === 1'b1) begin
          item.txn.resp = RESP_SLVERR;
          closed = 1;
        end
      end
      pend = 0;
      // ---- address phase ----
      if (item != null && (closed || vif.mon_cb.htrans inside {HTRANS_IDLE, HTRANS_NONSEQ})) begin
        item.txn.len  = d.size();
        item.txn.data = new[d.size()];
        item.txn.strb = new[item.txn.write ? d.size() : 0];
        foreach (d[k]) begin
          item.txn.data[k] = d[k];
          if (item.txn.write) item.txn.strb[k] = st[k];
        end
        if (item.txn.resp != RESP_SLVERR && exok) item.txn.resp = RESP_EXOKAY;
        item.txn.n_wait = waits;
        publish(item);
        item = null;
        if (closed && vif.mon_cb.htrans != HTRANS_IDLE)
          `uvm_error("MON", "transfer in the address phase after an ERROR response was not cancelled")
      end
      if (vif.mon_cb.htrans == HTRANS_NONSEQ) begin
        item = amba_seq_item::type_id::create("item");
        item.txn.protocol = AHB5;
        item.txn.addr   = vif.mon_cb.haddr;
        item.txn.write  = vif.mon_cb.hwrite;
        item.txn.size   = axsize_e'(vif.mon_cb.hsize);
        // HBURST: WRAP4/8/16 are 010/100/110; SINGLE, INCR and INCRx are INCR
        item.txn.burst  = (vif.mon_cb.hburst inside {3'b010, 3'b100, 3'b110}) ? BURST_WRAP : BURST_INCR;
        item.txn.resp   = RESP_OKAY;
        item.txn.id     = vif.mon_cb.hmaster;
        item.txn.excl   = vif.mon_cb.hexcl;
        item.txn.nonsec = vif.mon_cb.hnonsec;
        item.txn.n_busy = 0;
        d.delete(); st.delete();
        closed = 0; exok = 0; waits = 0;
        pend = 1;
      end
      else if (vif.mon_cb.htrans == HTRANS_SEQ) begin
        if (item == null) `uvm_error("MON", "SEQ transfer outside a burst")
        else pend = 1;
      end
      else if (vif.mon_cb.htrans == HTRANS_BUSY) begin
        if (item == null) `uvm_error("MON", "BUSY transfer outside a burst")
        else item.txn.n_busy++;
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("AHB monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
