// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_sequences.svh -- AHB5 sequence library:
//   base / single / incr burst / wrap burst / back-to-back /
//   error-inject (HRESP ERROR region) / reset / stress / regression mix

`ifndef AHB_SEQUENCES_SVH
`define AHB_SEQUENCES_SVH

class ahb_base_sequence extends uvm_sequence #(amba_seq_item);
  `uvm_object_utils(ahb_base_sequence)
  int num_txns = 20;
  function new(string name = "ahb_base_sequence");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AHB5; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: SINGLE beat transfers
class ahb_single_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_single_seq)
  function new(string name = "ahb_single_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AHB5; txn.len == 1; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: INCR4/8/16 bursts
class ahb_incr_burst_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_incr_burst_seq)
  function new(string name = "ahb_incr_burst_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AHB5;
                                    txn.burst == BURST_INCR;
                                    txn.len inside {4, 8, 16};
                                    txn.addr[3:0] == 4'h0; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: WRAP4/8/16 bursts (cache-line fill corner case)
class ahb_wrap_burst_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_wrap_burst_seq)
  function new(string name = "ahb_wrap_burst_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AHB5;
                                    txn.burst == BURST_WRAP;
                                    txn.len inside {4, 8, 16}; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: back-to-back single transfers with zero inter-burst delay
class ahb_back_to_back_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_back_to_back_seq)
  function new(string name = "ahb_back_to_back_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AHB5;
                                    txn.len inside {[1:2]};
                                    txn.delay == 0; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Error injection: accesses to the HRESP ERROR region (0xEE00_0000)
class ahb_error_inject_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_error_inject_seq)
  function new(string name = "ahb_error_inject_seq");
    super.new(name);
  endfunction
  task body();
    // No randomize(): fields are set directly ($urandom for the rest), so
    // the sequence runs on simulators that cannot solve the nested amba_txn
    // constraints (Verilator).
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      item.txn.protocol = AHB5;      item.txn.burst = BURST_INCR; item.txn.size = SIZE_4B;
      item.txn.len      = 1;         item.txn.write = $urandom_range(1);
      item.txn.cache    = 4'h0;      item.txn.prot  = $urandom_range(7);
      item.txn.addr     = {8'hEE, 16'($urandom), 8'h00} | (32'($urandom_range(63)) << 2);
      item.txn.resp     = RESP_OKAY; item.txn.excl  = 1'b0;   item.txn.delay = $urandom_range(3);
      item.txn.data     = new[1];    item.txn.data[0] = {$urandom, $urandom};
      finish_item(item);
    end
  endtask
endclass

// Reset behavior: single transfer issued right after reset release
class ahb_reset_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_reset_seq)
  function new(string name = "ahb_reset_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item = amba_seq_item::type_id::create("item");
    start_item(item);
    if (!(item.randomize() with { txn.protocol == AHB5; txn.len == 1; })) `uvm_error("RANDFAIL", "randomize() failed");
    finish_item(item);
  endtask
endclass

// Stress: long random bursts, high volume
class ahb_stress_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_stress_seq)
  function new(string name = "ahb_stress_seq");
    super.new(name);
    num_txns = 100;
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AHB5;
                                    txn.len inside {[4:16]}; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Coverage sweep: every legal HBURST x HSIZE combination as a write followed
// by a read-back, with corner data patterns, then num_txns random legal
// transfers. No randomize(): every field is set directly ($urandom for the
// random part), so the sequence runs on simulators that cannot solve the
// nested amba_txn constraints (Verilator).
class ahb_cov_sweep_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_cov_sweep_seq)
  function new(string name = "ahb_cov_sweep_seq");
    super.new(name);
    num_txns = 100;
  endfunction
  function logic [63:0] pattern(int n);
    case (n % 5)
      0: return 64'h0;
      1: return 64'hFFFF_FFFF_FFFF_FFFF;
      2: return 64'hAAAA_AAAA_AAAA_AAAA;
      3: return 64'h5555_5555_5555_5555;
      default: return {$urandom, $urandom};
    endcase
  endfunction
  task send(axburst_e b, axsize_e s, int l, bit wr, int n, logic [31:0] a,
            logic [2:0] p = 3'b000, int dly = 0);
    amba_seq_item item = amba_seq_item::type_id::create("item");
    start_item(item);
    item.txn.protocol = AHB5;  item.txn.burst = b;  item.txn.size = s;
    item.txn.len      = l;     item.txn.write = wr; item.txn.cache = 4'h0;
    item.txn.addr     = a;     item.txn.prot  = p;  item.txn.resp  = RESP_OKAY;
    item.txn.excl     = 1'b0;  item.txn.delay = dly;
    item.txn.data     = new[l];
    foreach (item.txn.data[i]) item.txn.data[i] = pattern(n + i);
    finish_item(item);
  endtask
  task body();
    axburst_e bursts[2] = '{BURST_INCR, BURST_WRAP};
    axsize_e  sizes[4]  = '{SIZE_1B, SIZE_2B, SIZE_4B, SIZE_8B};
    int       lens[6]   = '{1, 3, 4, 8, 12, 16};
    int       wlens[3]  = '{4, 8, 16};
    int n = 0;
    foreach (bursts[b]) foreach (sizes[s]) foreach (lens[l]) begin
      logic [31:0] a;
      if (bursts[b] == BURST_WRAP && !(lens[l] inside {4, 8, 16})) continue;
      // 128-byte aligned slots: an INCR16 of 8-byte beats stays inside 1 KB
      a = (n * 128) % 1024 + 32'h400 * (n / 8);
      send(bursts[b], sizes[s], lens[l], 1, n, a);
      send(bursts[b], sizes[s], lens[l], 0, n, a);
      n++;
    end
    // random legal traffic (AHB5: aligned, WRAP 4/8/16, INCR inside 1 KB)
    repeat (num_txns) begin
      axburst_e    rb = bursts[$urandom_range(1)];
      int unsigned rs = $urandom_range(3);
      int          rl = (rb == BURST_WRAP) ? wlens[$urandom_range(2)] : $urandom_range(16, 1);
      int unsigned span = (rb == BURST_INCR) ? (rl << rs) : (1 << rs);
      logic [31:0] ra = ($urandom & 32'h00FF_FC00) |
                        (($urandom_range(1024 - span) >> rs) << rs);
      send(rb, sizes[rs], rl, $urandom_range(1), n++, ra, $urandom_range(7), $urandom_range(3));
    end
    ahb5_sweep(n);
  endtask
  // AHB5 features: BUSY inside bursts, secure region, exclusive access,
  // write strobes, several masters
  task send5(axburst_e b, axsize_e s, int l, bit wr, int n, logic [31:0] a,
             int busy = 0, bit ns = 0, bit ex = 0, logic [3:0] m = 0,
             logic [7:0] sb = 8'hFF, bit lk = 0);
    amba_seq_item item = amba_seq_item::type_id::create("item");
    start_item(item);
    item.txn.protocol = AHB5;  item.txn.burst = b;  item.txn.size = s;
    item.txn.len      = l;     item.txn.write = wr; item.txn.cache = 4'h0;
    item.txn.addr     = a;     item.txn.prot  = 3'b011; item.txn.resp = RESP_OKAY;
    item.txn.excl     = ex;    item.txn.delay = 0;
    item.txn.busy_pct = busy;  item.txn.nonsec = ns; item.txn.id = m;
    item.txn.lock     = lk;
    item.txn.data     = new[l];
    item.txn.strb     = new[l];
    foreach (item.txn.data[i]) begin
      item.txn.data[i] = pattern(n + i + 1);
      item.txn.strb[i] = sb;
    end
    finish_item(item);
  endtask
  task ahb5_sweep(ref int n);
    // BUSY: INCR and WRAP, reads and writes, light and heavy
    for (int k = 0; k < 24; k++) begin
      axburst_e bb = (k % 2) ? BURST_WRAP : BURST_INCR;
      int       ll = (k % 3 == 0) ? 4 : (k % 3 == 1) ? 8 : 16;
      logic [31:0] a = 32'h0000_0800 + (k % 8) * 128;
      send5(bb, SIZE_4B, ll, 1, n++, a, (k < 12) ? 20 : 50);
      send5(bb, SIZE_4B, ll, 0, n++, a, (k < 12) ? 20 : 50);
    end
    // secure region 0x1000-0x17FF: secure passes, non-secure gets ERROR
    for (int k = 0; k < 8; k++) begin
      logic [31:0] a = 32'h0000_1000 + k * 64;
      send5(BURST_INCR, SIZE_4B, 1 + k % 4, 1, n++, a, 0, 0);
      send5(BURST_INCR, SIZE_4B, 1 + k % 4, 0, n++, a, 0, 0);
      send5(BURST_INCR, SIZE_4B, 1 + k % 4, 1, n++, a, 0, 1);
      send5(BURST_INCR, SIZE_4B, 1 + k % 4, 0, n++, a, 0, 1);
      send5(BURST_INCR, SIZE_4B, 2, 0, n++, 32'h0000_0400 + k * 16, 0, 1);  // non-secure elsewhere
      send5(BURST_INCR, SIZE_4B, 2, 1, n++, 32'h0000_0400 + k * 16, 0, 1);
    end
    // exclusive access per master: pass, fail after another master's write,
    // fail without a monitor
    for (int m = 0; m < 16; m++) begin
      logic [31:0] a = 32'h0000_0200 + m * 8;
      send5(BURST_INCR, SIZE_8B, 1, 0, n++, a, 0, 0, 1, m);           // LDREX
      send5(BURST_INCR, SIZE_8B, 1, 1, n++, a, 0, 0, 1, m);           // STREX ok
      send5(BURST_INCR, SIZE_8B, 1, 1, n++, a, 0, 0, 1, m);           // STREX fail (monitor cleared)
      send5(BURST_INCR, SIZE_8B, 1, 0, n++, a, 0, 0, 1, m);           // LDREX
      send5(BURST_INCR, SIZE_8B, 1, 1, n++, a, 0, 0, 0, (m + 1) % 16); // other master writes
      send5(BURST_INCR, SIZE_8B, 1, 1, n++, a, 0, 0, 1, m);           // STREX fail
      send5(BURST_INCR, SIZE_8B, 1, 0, n++, a, 0, 0, 0, m);
    end
    // locked read-modify-write bursts (HMASTLOCK), with BUSY
    for (int k = 0; k < 4; k++) begin
      send5(BURST_INCR, SIZE_4B, 4, 0, n++, 32'h0000_0700 + k * 16, 30, 0, 0, 2, 8'hFF, 1);
      send5(BURST_INCR, SIZE_4B, 4, 1, n++, 32'h0000_0700 + k * 16, 30, 0, 0, 2, 8'hFF, 1);
    end
    // sparse write strobes on all sizes, read back
    for (int k = 0; k < 16; k++) begin
      logic [7:0] sb = 8'h01 << (k % 8) | 8'h80 >> (k % 3);
      logic [31:0] a = 32'h0000_0600 + k * 32;
      send5(BURST_INCR, axsize_e'(k % 4), 4, 1, n++, a, 0, 0, 0, k, sb);
      send5(BURST_INCR, axsize_e'(k % 4), 4, 0, n++, a, 0, 0, 0, k);
    end
  endtask
endclass

// Random sequence (compatibility name)
class ahb_random_sequence extends ahb_base_sequence;
  `uvm_object_utils(ahb_random_sequence)
  function new(string name = "ahb_random_sequence");
    super.new(name);
    num_txns = 50;
  endfunction
endclass

// Regression: weighted mix of all directed sequences
class ahb_regression_sequence extends ahb_base_sequence;
  `uvm_object_utils(ahb_regression_sequence)
  function new(string name = "ahb_regression_sequence");
    super.new(name);
  endfunction
  task body();
    ahb_single_seq      sgl = ahb_single_seq::type_id::create("sgl");
    ahb_incr_burst_seq  inc = ahb_incr_burst_seq::type_id::create("inc");
    ahb_wrap_burst_seq  wrp = ahb_wrap_burst_seq::type_id::create("wrp");
    ahb_back_to_back_seq b2b = ahb_back_to_back_seq::type_id::create("b2b");
    ahb_error_inject_seq err = ahb_error_inject_seq::type_id::create("err");
    ahb_stress_seq       str = ahb_stress_seq::type_id::create("str");
    sgl.num_txns = 20; inc.num_txns = 15; wrp.num_txns = 10;
    b2b.num_txns = 20; err.num_txns = 5;  str.num_txns = 40;
    sgl.start(m_sequencer); inc.start(m_sequencer);
    wrp.start(m_sequencer); b2b.start(m_sequencer);
    err.start(m_sequencer); str.start(m_sequencer);
  endtask
endclass
`endif
