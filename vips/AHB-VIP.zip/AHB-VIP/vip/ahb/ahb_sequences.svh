// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ahb_sequences.svh -- AHB5 sequence library:
//   base / single / incr burst / wrap burst / back-to-back /
//   error-inject (HRESP ERROR region) / reset / stress / regression mix

`ifndef AHB_SEQUENCES_SVH
`define AHB_SEQUENCES_SVH

class ahb_base_sequence extends uvm_sequence #(amba_seq_item);
  `uvm_object_utils(ahb_base_sequence)
  int num_txns = 20;
  function new(string name = "ahb_base_sequence");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { txn.protocol == AHB5; });
      finish_item(item);
    end
  endtask
endclass

// Directed: SINGLE beat transfers
class ahb_single_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_single_seq)
  function new(string name = "ahb_single_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { txn.protocol == AHB5; txn.len == 1; });
      finish_item(item);
    end
  endtask
endclass

// Directed: INCR4/8/16 bursts
class ahb_incr_burst_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_incr_burst_seq)
  function new(string name = "ahb_incr_burst_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { txn.protocol == AHB5;
                                    txn.burst == BURST_INCR;
                                    txn.len inside {4, 8, 16};
                                    txn.addr[3:0] == 4'h0; });
      finish_item(item);
    end
  endtask
endclass

// Directed: WRAP4/8/16 bursts (cache-line fill corner case)
class ahb_wrap_burst_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_wrap_burst_seq)
  function new(string name = "ahb_wrap_burst_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { txn.protocol == AHB5;
                                    txn.burst == BURST_WRAP;
                                    txn.len inside {4, 8, 16}; });
      finish_item(item);
    end
  endtask
endclass

// Directed: back-to-back single transfers with zero inter-burst delay
class ahb_back_to_back_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_back_to_back_seq)
  function new(string name = "ahb_back_to_back_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { txn.protocol == AHB5;
                                    txn.len inside {[1:2]};
                                    txn.delay == 0; });
      finish_item(item);
    end
  endtask
endclass

// Error injection: accesses to the HRESP ERROR region (0xEE00_0000)
class ahb_error_inject_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_error_inject_seq)
  function new(string name = "ahb_error_inject_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { txn.protocol == AHB5;
                                    txn.addr[31:24] == 8'hEE;
                                    txn.len == 1; });
      finish_item(item);
    end
  endtask
endclass

// Reset behavior: single transfer issued right after reset release
class ahb_reset_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_reset_seq)
  function new(string name = "ahb_reset_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item = amba_seq_item::type_id::create("item");
    start_item(item);
    void'(item.randomize() with { txn.protocol == AHB5; txn.len == 1; });
    finish_item(item);
  endtask
endclass

// Stress: long random bursts, high volume
class ahb_stress_seq extends ahb_base_sequence;
  `uvm_object_utils(ahb_stress_seq)
  function new(string name = "ahb_stress_seq");
    super.new(name);
    num_txns = 100;
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { txn.protocol == AHB5;
                                    txn.len inside {[4:16]}; });
      finish_item(item);
    end
  endtask
endclass

// Random sequence (compatibility name)
class ahb_random_sequence extends ahb_base_sequence;
  `uvm_object_utils(ahb_random_sequence)
  function new(string name = "ahb_random_sequence");
    super.new(name);
    num_txns = 50;
  endfunction
endclass

// Regression: weighted mix of all directed sequences
class ahb_regression_sequence extends ahb_base_sequence;
  `uvm_object_utils(ahb_regression_sequence)
  function new(string name = "ahb_regression_sequence");
    super.new(name);
  endfunction
  task body();
    ahb_single_seq      sgl = ahb_single_seq::type_id::create("sgl");
    ahb_incr_burst_seq  inc = ahb_incr_burst_seq::type_id::create("inc");
    ahb_wrap_burst_seq  wrp = ahb_wrap_burst_seq::type_id::create("wrp");
    ahb_back_to_back_seq b2b = ahb_back_to_back_seq::type_id::create("b2b");
    ahb_error_inject_seq err = ahb_error_inject_seq::type_id::create("err");
    ahb_stress_seq       str = ahb_stress_seq::type_id::create("str");
    sgl.num_txns = 20; inc.num_txns = 15; wrp.num_txns = 10;
    b2b.num_txns = 20; err.num_txns = 5;  str.num_txns = 40;
    sgl.start(m_sequencer); inc.start(m_sequencer);
    wrp.start(m_sequencer); b2b.start(m_sequencer);
    err.start(m_sequencer); str.start(m_sequencer);
  endtask
endclass
`endif
