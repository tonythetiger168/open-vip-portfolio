# AHB — AHB5 UVM VIP

Open-source UVM verification IP for **AMBA AHB5** (bus), sharing the common
`amba_vip_if` / `amba_vip_pkg` skeleton with the AXI and APB VIPs.

## Protocol overview

AHB5 is a pipelined bus: the address phase of beat *i+1* overlaps the data
phase of beat *i*. Transfers start with `HTRANS=NONSEQ` and continue with
`HTRANS=SEQ`; bursts are SINGLE / INCR / INCR4/8/16 / WRAP4/8/16
(`HBURST`). The slave inserts wait states with `HREADYOUT` and signals
errors with a two-cycle `HRESP=ERROR` response.

## Architecture

| Path | Description |
|------|-------------|
| `rtl/amba_vip_if.sv` | AXI4+AHB5+APB4 interface, `drv_cb`/`mon_cb` clocking blocks, modports, inline SVA + covergroup |
| `vip/base/amba_vip_pkg.sv` | `amba_txn`/`amba_seq_item`, `amba_cov`, end-to-end `amba_sb` scoreboard; includes AHB UVC + SVA checker |
| `vip/ahb/ahb_driver.svh` | AHB5 master driver: pipelined NONSEQ→SEQ burst driving, wait-state handling, HRESP ERROR detection |
| `vip/ahb/ahb_monitor.svh` | AHB5 monitor: reconstructs bursts from pipelined addr/data phases, publishes via analysis port |
| `vip/ahb/ahb_agent.svh` / `ahb_sequencer.svh` | Active agent (sequencer + driver + monitor) |
| `vip/ahb/ahb_sequences.svh` | Directed sequence library (see below) |
| `vip/ahb/ahb_coverage.svh` | Functional coverage (3 covergroups + crosses) |
| `vip/ahb/ahb_protocol_checker.sv` | Class-based protocol checker (properties + `cg_ahb`) |
| `rtl/sva/ahb_compliance_checker.sv` | Tiered SVA compliance checker (L1/L2/L3/L4) |
| `env/amba_env.sv` | Environment: agent, scoreboard, coverage, checkers, analysis connections |
| `tests/amba_tests.sv` | `amba_base_test` / `amba_axi_test` / `amba_ahb_test` / `amba_apb_test` |
| `tb/top_tb.sv` | Testbench top + functional AHB5 slave DUT (memory model, ERROR region `0xEE00_0000`) |
| `scripts/` | Makefile + coverage-driven regression (line/fsm/toggle/SVA, 100% goal) |

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `ahb_base_sequence` | Random AHB5 transactions |
| `ahb_single_seq` | SINGLE-beat directed transfers |
| `ahb_incr_burst_seq` | INCR4/8/16 bursts (aligned) |
| `ahb_wrap_burst_seq` | WRAP4/8/16 cache-line corner case |
| `ahb_back_to_back_seq` | Zero-delay back-to-back transfers |
| `ahb_error_inject_seq` | Accesses to HRESP ERROR region (`0xEE??_????`) |
| `ahb_reset_seq` | Transfer right after reset release |
| `ahb_stress_seq` | 100 long random bursts |
| `ahb_regression_sequence` | Weighted mix of all directed sequences |

## SVA compliance (rtl/sva/ahb_compliance_checker.sv)

- **L1 Basic (4)**: HTRANS/HBURST/HSIZE/HRESP legal encodings
- **L2 Full protocol (4)**: HREADYOUT response, HMASTLOCK with burst, address alignment, HWDATA valid on write
- **L3 Advanced (0)**: reserved
- **L4 AHB5-specific (4)**: SEQ only after NONSEQ/SEQ, control stable during wait states, two-cycle ERROR response, INCR address step = beat size

## Functional coverage (vip/ahb/ahb_coverage.svh)

- `cg_protocol`: write × burst × size × len, response bins + crosses
- `cg_fsm`: HTRANS state + transition bins (IDLE→NONSEQ→SEQ→IDLE, back-to-back)
- `cg_data`: data pattern corners (all-0/all-1/0xAA…/0x55…) × write cross

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
TEST=amba_ahb_test make all
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

## Deepened Features (v1.6.0)

- **Pipelined AHB5 master driver**: NONSEQ→SEQ burst progression, INCR/WRAP address generation, wait-state and two-cycle ERROR response handling
- **Burst-reconstructing monitor**: decodes pipelined address/data phases into transactions published on an analysis port
- **End-to-end scoreboard**: driver-issued (expected) vs monitor-decoded (observed) compare with `n_matches`/`n_mismatches` and `UVM_ERROR` on mismatch
- **Functional DUT model**: AHB5 slave memory with ERROR region closing the driver→DUT→monitor loop
- **Directed sequence library**: 9 sequences (single / incr / wrap / back-to-back / error / reset / stress / regression)
- **SVA L4**: 4 AHB5-specific rules
- **Functional coverage**: 3 covergroups with cross coverage

License: Apache-2.0
