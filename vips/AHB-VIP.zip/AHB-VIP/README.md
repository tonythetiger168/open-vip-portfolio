# AHB — AHB5 UVM VIP

Open-source UVM verification IP for **AMBA AHB5** (bus), sharing the common
`amba_vip_if` / `amba_vip_pkg` skeleton with the AXI and APB VIPs.

## Protocol overview

AHB5 is a pipelined bus: the address phase of beat *i+1* overlaps the data
phase of beat *i*. Transfers start with `HTRANS=NONSEQ` and continue with
`HTRANS=SEQ`; bursts are SINGLE / INCR / INCR4/8/16 / WRAP4/8/16
(`HBURST`). The slave inserts wait states with `HREADYOUT` and signals
errors with a two-cycle `HRESP=ERROR` response. A master may insert `BUSY`
cycles inside a burst. AHB5 adds `HNONSEC` (secure / non-secure),
`HEXCL` / `HMASTER` / `HEXOKAY` (exclusive access) and `HWSTRB` (write
strobes).

## Architecture

| Path | Description |
|------|-------------|
| `rtl/amba_vip_if.sv` | AXI4+AHB5+APB4 interface, `drv_cb`/`mon_cb` clocking blocks, modports, inline SVA + covergroup |
| `vip/base/amba_vip_pkg.sv` | `amba_txn`/`amba_seq_item`, `amba_cov`, end-to-end `amba_sb` scoreboard; includes AHB UVC + SVA checker |
| `vip/ahb/ahb_driver.svh` | AHB5 master driver: cycle-accurate pipelined bursts, BUSY insertion (`busy_pct`), HWSTRB from the beat lanes, HNONSEC / HEXCL / HMASTER, cancel to IDLE in the first ERROR cycle, EXOKAY / SLVERR result |
| `vip/ahb/ahb_monitor.svh` | AHB5 monitor: reconstructs bursts from the address / data phases at each HREADY edge, counts BUSY and wait cycles, captures HWSTRB / HEXOKAY, checks the cancel after ERROR |
| `vip/ahb/ahb_agent.svh` / `ahb_sequencer.svh` | Active agent (sequencer + driver + monitor) |
| `vip/ahb/ahb_sequences.svh` | Directed sequence library (see below) |
| `vip/ahb/ahb_coverage.svh` | Functional coverage (4 covergroups + crosses) |
| `vip/ahb/ahb_protocol_checker.sv` | Class-based protocol checker (properties + `cg_ahb`) |
| `rtl/sva/ahb_compliance_checker.sv` | Tiered SVA compliance checker (L1-L5, 21 properties) |
| `env/amba_env.sv` | Environment: agent, scoreboard, coverage, checkers, analysis connections |
| `tests/amba_tests.sv` | `amba_base_test` / `amba_axi_test` / `amba_ahb_test` / `amba_apb_test` |
| `tb/top_tb.sv` | Testbench top + AHB5 slave DUT: 8 KB memory with byte strobes, random 0-2 wait states, ERROR for `0xEE??_????` / unaligned / HSIZE > 64 bits / non-secure access to `0x1000-0x17FF`, one exclusive monitor per HMASTER |
| `tb/smoke_func_tb.sv` | Self-checking functional smoke (192 checks) against the flattened slave |
| `scripts/` | Makefile + coverage-driven regression (line/fsm/toggle/SVA, 100% goal) |

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `ahb_base_sequence` | Random AHB5 transactions |
| `ahb_single_seq` | SINGLE-beat directed transfers |
| `ahb_incr_burst_seq` | INCR4/8/16 bursts (aligned) |
| `ahb_wrap_burst_seq` | WRAP4/8/16 cache-line corner case |
| `ahb_back_to_back_seq` | Zero-delay back-to-back transfers |
| `ahb_error_inject_seq` | Accesses to HRESP ERROR region (`0xEE??_????`) |
| `ahb_reset_seq` | Transfer right after reset release |
| `ahb_stress_seq` | 100 long random bursts |
| `ahb_cov_sweep_seq` | Every burst type × size, then BUSY, secure region, exclusive pass / fail per master, sparse strobes |
| `ahb_regression_sequence` | Weighted mix of all directed sequences |

## SVA compliance (rtl/sva/ahb_compliance_checker.sv)

- **L1 Basic (4)**: HTRANS/HBURST/HSIZE/HRESP legal encodings
- **L2 Full protocol (4)**: HREADYOUT response, HMASTLOCK with burst, address alignment, HWDATA valid on write
- **L3 Advanced (4)**: BUSY followed by BUSY/SEQ, control stable inside a burst, INCR inside 1 KB, WRAP address step
- **L4 AHB5-specific (4)**: SEQ only after NONSEQ/SEQ/BUSY, control stable during wait states, two-cycle ERROR response, INCR address step = beat size
- **L5 AHB5 extensions (5)**: BUSY only inside a burst, SEQ after BUSY keeps the address, HEXCL only on SINGLE, HWSTRB within the byte lanes, HEXOKAY only in an exclusive data phase

## Functional coverage (vip/ahb/ahb_coverage.svh)

- `cg_protocol`: write × burst × size × len, response bins + crosses
- `cg_fsm`: HTRANS state + transition bins (IDLE→NONSEQ→SEQ→IDLE, BUSY in and out of a burst)
- `cg_ahb5`: BUSY count × burst, wait states × direction, HNONSEC × secure region × direction, exclusive read / write pass / write fail, sparse strobes, HMASTER
- `cg_data`: data pattern corners (all-0/all-1/0xAA…/0x55…) × write cross

## UVM RAL (register model)

- `env/amba_reg_model.sv` -- `amba_reg_block` modelling the `amba_dut` slave in
  `tb/top_tb.sv`: REG0..REG7 (0x00-0x38) + MEM 1016x64 (0x40-0x1FF8), all RW with reset 0, plus `ERR_PROBE` at
  0xEE000000 (error region, excluded from the built-in sequences). Map: ahb_map (8 bytes).
- `vip/base/amba_reg_adapter.svh` -- `amba_reg_adapter` (single-beat AHB5
  `amba_seq_item`; `protocol` / `bus_bytes` set by the env).
- `amba_env` builds the model, sets the adapter on the agent sequencer and
  keeps the mirror with a `uvm_reg_predictor` fed by the monitor
  (explicit prediction).
- `amba_ral_test` -- `uvm_reg_hw_reset_seq`, `uvm_reg_bit_bash_seq`, `uvm_mem_walk_seq`,
  random write + `mirror(UVM_CHECK)`, and the error response returning `UVM_NOT_OK`.
  Runs on Verilator: `python3 tools/run_uvm_tests.py AHB-VIP` from the
  portfolio repo (see docs/RAL.md there).

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
TEST=amba_ahb_test make all
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

## Deepened Features (v1.8.0)

- **BUSY and wait states**: the driver inserts BUSY before SEQ beats, the slave inserts 0-2 random wait states; the monitor counts both
- **Secure region**: non-secure transfers to `0x1000-0x17FF` get ERROR, the rest of the burst is cancelled and not written
- **Exclusive access**: LDREX / STREX with one monitor per HMASTER, cleared by any write to the word; a failed STREX returns OKAY and leaves memory unchanged
- **Write strobes**: HWSTRB per beat, limited to the transfer's byte lanes; the scoreboard keeps a byte-wide reference memory
- **SVA L5** and protocol-checker rules for wait-state hold and ERROR cancel

## Deepened Features (v1.6.0)

- **Pipelined AHB5 master driver**: NONSEQ→SEQ burst progression, INCR/WRAP address generation, wait-state and two-cycle ERROR response handling
- **Burst-reconstructing monitor**: decodes pipelined address/data phases into transactions published on an analysis port
- **End-to-end scoreboard**: driver-issued (expected) vs monitor-decoded (observed) compare with `n_matches`/`n_mismatches` and `UVM_ERROR` on mismatch
- **Functional DUT model**: AHB5 slave memory with ERROR region closing the driver→DUT→monitor loop
- **Directed sequence library**: 9 sequences (single / incr / wrap / back-to-back / error / reset / stress / regression)
- **SVA L4**: 4 AHB5-specific rules
- **Functional coverage**: 3 covergroups with cross coverage

License: Apache-2.0
