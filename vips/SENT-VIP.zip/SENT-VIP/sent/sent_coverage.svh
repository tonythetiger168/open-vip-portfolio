// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_coverage.svh -- SENT functional coverage

class sent_coverage extends uvm_subscriber #(sent_transaction);
  `uvm_component_utils(sent_coverage)
  sent_config cfg;
  sent_transaction tr;

  covergroup sent_cg;
    coverpoint tr.sens_out;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(sent_config)::get(this, "*", "cfg", cfg));
    sent_cg = new();
  endfunction

  function void write(sent_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    sent_cg.sample();
  endfunction
endclass
