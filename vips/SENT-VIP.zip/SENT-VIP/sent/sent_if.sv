// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_if.sv -- SENT interface

interface sent_if (input logic clk);
  logic rst_n;

  logic sens_out;
  logic [3:0] nibble;
  logic nibble_valid;
  logic [7:0] tick_cnt;

  modport DUT (input clk, rst_n, sens_out, output nibble, nibble_valid, tick_cnt);
  modport DRV (input clk, rst_n, nibble, nibble_valid, tick_cnt, output sens_out);
  modport MON (input clk, rst_n, sens_out, nibble, nibble_valid, tick_cnt);

  clocking drv_cb @(posedge clk);
    input rst_n, sens_out, nibble, nibble_valid, tick_cnt;
    output sens_out;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, sens_out, nibble, nibble_valid, tick_cnt;
  endclocking
endinterface
