// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_monitor.svh -- SENT monitor: decodes pulse low times on sens_out into frames, with the DUT's nibble reports

class sent_monitor extends uvm_monitor;
  `uvm_component_utils(sent_monitor)

  virtual sent_if vif;
  uvm_analysis_port #(sent_transaction) ap;
  sent_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual sent_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sent: virtual interface not set")
    if (!uvm_config_db#(sent_config)::get(this, "", "cfg", cfg))
      cfg = sent_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      sent_transaction t;
      int unsigned low = 0;
      bit so_d = 1;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.nibble_valid) begin
          if (t == null) `uvm_error("MON", "SENT nibble_valid outside a frame")
          else t.dut_nib.push_back(vif.mon_cb.nibble);
        end
        if (!vif.mon_cb.sens_out) low++;
        else if (!so_d) begin                      // rising edge: end of a pulse
          if (low > 27) begin                      // sync pulse: new frame
            if (t != null) `uvm_error("MON", "SENT frame cut short by a sync pulse")
            t = sent_transaction::type_id::create("t");
          end else if (t != null) t.nib.push_back(low - 3);
          low = 0;
        end
        so_d = vif.mon_cb.sens_out;
        if (t != null && t.nib.size() == 8 && t.dut_nib.size() == 8) begin
          t.status = t.nib[0];
          for (int i = 0; i < 6; i++) t.data[(5 - i) * 4 +: 4] = t.nib[i + 1];
          publish(t);
          t = null;
        end
      end
    end
  endtask

  function void publish(sent_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
