// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_transaction.svh -- SENT transaction

class sent_transaction extends uvm_sequence_item;
  `uvm_object_utils(sent_transaction)

  rand bit sens_out;
  bit [3:0] nibble_o;
  bit nibble_valid_o;
  bit [7:0] tick_cnt_o;
  bit [31:0] tag;

  function new(string name = "sent_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    sent_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    sens_out = rhs_.sens_out;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sent_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           sens_out == rhs_.sens_out;
  endfunction

  function string convert2string();
    return $sformatf("SENT{tag=%0h sens_out=0x%0h}", tag, sens_out);
  endfunction
endclass
