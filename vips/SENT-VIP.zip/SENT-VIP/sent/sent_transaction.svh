// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_transaction.svh -- SENT transaction

class sent_transaction extends uvm_sequence_item;
  `uvm_object_utils(sent_transaction)

  // request (driven by the agent)
  bit [3:0] nib[$];
  // response (returned by the DUT)
  bit [3:0] dut_nib[$];
  // bookkeeping (not compared)
  rand bit [3:0] status;
  rand bit [23:0] data;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "sent_transaction"); super.new(name); endfunction

  // J2716 4-bit CRC (x^4+x^3+x^2+1, seed 5) over the data nibbles, with the
  // recommended extra zero nibble
  static function bit [3:0] crc4(bit [3:0] d[$]);
    bit [3:0] tbl [16] = '{0, 13, 7, 10, 14, 3, 9, 4, 1, 12, 6, 11, 15, 2, 8, 5};
    bit [3:0] c = 4'd5;
    foreach (d[i]) c = tbl[c] ^ d[i];
    return tbl[c];
  endfunction

  function void build();
    bit [3:0] d[$];
    for (int i = 5; i >= 0; i--) d.push_back(data[i*4 +: 4]);
    nib.delete();
    nib.push_back(status);
    foreach (d[i]) nib.push_back(d[i]);
    nib.push_back(crc4(d));
  endfunction

  function void post_randomize(); build(); endfunction

  function void do_copy(uvm_object rhs);
    sent_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    nib = rhs_.nib;
    dut_nib = rhs_.dut_nib;
    status = rhs_.status;
    data = rhs_.data;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sent_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (nib.size() != rhs_.nib.size()) return 0;
    foreach (nib[i]) if (nib[i] != rhs_.nib[i]) return 0;
    if (dut_nib.size() != rhs_.dut_nib.size()) return 0;
    foreach (dut_nib[i]) if (dut_nib[i] != rhs_.dut_nib[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(sent_transaction rhs_);
    if (nib.size() != rhs_.nib.size()) return 0;
    foreach (nib[i]) if (nib[i] != rhs_.nib[i]) return 0;
    return 1;
  endfunction

  function string qstr_nib();
    string s = $sformatf("[%0d]{", nib.size());
    foreach (nib[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", nib[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_dut_nib();
    string s = $sformatf("[%0d]{", dut_nib.size());
    foreach (dut_nib[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", dut_nib[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SENT{tag=%0d nib=%s dut_nib=%s}", tag, qstr_nib(), qstr_dut_nib());
  endfunction
endclass
