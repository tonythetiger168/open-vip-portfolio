// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_compliance_checker.sv -- SENT concurrent assertion checks (bindable)

module sent_compliance_checker
  (input logic clk, input logic rst_n, input sens_out, input [3:0] nibble, input nibble_valid, input [7:0] tick_cnt);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({nibble, nibble_valid, tick_cnt}))
    else $error("SENT: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> nibble == '0)
    else $error("SENT: output not in reset value");
  // nibble_valid only with a legal pulse width
  assert property (@(posedge clk) disable iff (!rst_n) $rose(nibble_valid) |-> $fell(so_d))
    else $error("SENT: invalid nibble strobe");
  cover property (@(posedge clk) disable iff (!rst_n) (nibble != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (nibble_valid == 1'b1));
endmodule
