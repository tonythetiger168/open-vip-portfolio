// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_pkg.sv -- SENT UVM VIP package

package sent_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import sent_defs_pkg::*;
  export sent_defs_pkg::*;

  `include "sent_transaction.svh"
  `include "sent_config.svh"
  `include "sent_sequencer.svh"
  `include "sent_driver.svh"
  `include "sent_monitor.svh"
  `include "sent_agent.svh"
  `include "sent_sequences.svh"
  `include "sent_checker.svh"
  `include "sent_coverage.svh"
endpackage
