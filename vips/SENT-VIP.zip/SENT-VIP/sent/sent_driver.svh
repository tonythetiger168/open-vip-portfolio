// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_driver.svh -- SENT driver: sync pulse, then status, six data and the CRC nibble as low pulses of nibble + 3 clocks

class sent_driver extends uvm_driver #(sent_transaction);
  `uvm_component_utils(sent_driver)

  uvm_analysis_port #(sent_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual sent_if vif;
  sent_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sent_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sent: virtual interface not set")
    if (!uvm_config_db#(sent_config)::get(this, "", "cfg", cfg))
      cfg = sent_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    sent_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.sens_out <= 1'b1;
  endtask

  task drive_item(sent_transaction t);
    @(vif.drv_cb);
    pulse(cfg.sync_low);
    foreach (t.nib[i]) pulse(t.nib[i] + 3);
    repeat (8) @(vif.drv_cb);              // pause before the next frame
  endtask

  task pulse(int unsigned low);
    vif.drv_cb.sens_out <= 1'b0;
    repeat (low) @(vif.drv_cb);
    vif.drv_cb.sens_out <= 1'b1;
    repeat (cfg.high_clks) @(vif.drv_cb);
  endtask
endclass
