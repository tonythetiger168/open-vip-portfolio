// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_sequences.svh -- SENT sequences

// Random traffic: cfg.num_items constrained-random items.
class sent_base_sequence extends uvm_sequence #(sent_transaction);
  `uvm_object_utils(sent_base_sequence)
  sent_config cfg;

  function new(string name = "sent_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = sent_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "sent_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class sent_directed_sequence extends uvm_sequence #(sent_transaction);
  `uvm_object_utils(sent_directed_sequence)
  sent_config cfg;

  function new(string name = "sent_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function sent_transaction item();
    item = sent_transaction::type_id::create("req");
  endfunction

  task send(sent_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    sent_transaction t;
    t = item(); t.status = 4'h0; t.data = 24'h000000; t.build(); send(t);
    t = item(); t.status = 4'hF; t.data = 24'hFFFFFF; t.build(); send(t);
    t = item(); t.status = 4'h5; t.data = 24'h0123AB; t.build(); send(t);
    t = item(); t.status = 4'hA; t.data = 24'hFEDCBA; t.build(); send(t);
  endtask
endclass
