// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sent_tests.sv -- SENT test package

package sent_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sent_defs_pkg::*;
  import sent_pkg::*;
  import sent_env_pkg::*;

  class sent_base_test extends uvm_test;
    `uvm_component_utils(sent_base_test)
    sent_env env;
    sent_config cfg;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      cfg = sent_config::type_id::create("cfg", this);
      uvm_config_db#(sent_config)::set(this, "*", "cfg", cfg);
      env = sent_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
      sent_base_sequence seq = sent_base_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass
endpackage
