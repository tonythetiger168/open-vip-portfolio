// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SENT testbench top with a functional SENT DUT model

`ifndef SENT_TB_SV
`define SENT_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sent_defs_pkg::*;
import sent_pkg::*;
import sent_env_pkg::*;
import sent_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  sent_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  sent_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .sens_out(vif.sens_out),
    .nibble(vif.nibble),
    .nibble_valid(vif.nibble_valid),
    .tick_cnt(vif.tick_cnt)
  );

  // Concurrent protocol checks
  sent_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .sens_out(vif.sens_out), .nibble(vif.nibble), .nibble_valid(vif.nibble_valid), .tick_cnt(vif.tick_cnt)
  );

  initial begin
    uvm_config_db#(virtual sent_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module sent_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       sens_out,
  output logic [3:0] nibble,
  output logic       nibble_valid,
  output logic [7:0] tick_cnt
);
  logic [7:0] low_cnt;
  logic       so_d;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      low_cnt      <= '0;
      so_d         <= 1'b1;
      nibble       <= '0;
      nibble_valid <= 1'b0;
      tick_cnt     <= '0;
    end else begin
      so_d    <= sens_out;
      tick_cnt <= tick_cnt + 1'b1;
      if (!sens_out)
        low_cnt <= low_cnt + 1'b1;
      if (so_d == 1'b0 && sens_out == 1'b1) begin
        // rising edge: measured low time maps to nibble (3..27 ticks -> 0..F)
        if (low_cnt >= 8'd3 && low_cnt <= 8'd27) begin
          nibble       <= low_cnt[3:0] - 4'd3;
          nibble_valid <= 1'b1;
        end
        low_cnt <= '0;
      end else
        nibble_valid <= 1'b0;
    end
  end
endmodule
`endif
