// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (SENT nibble decoding)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened sent_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic sens_out = 1'b1;
  wire  [3:0] nibble;
  wire  nibble_valid;
  wire  [7:0] tick_cnt;

  always #5 clk = ~clk;

  sent_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .sens_out(sens_out),
    .nibble(nibble), .nibble_valid(nibble_valid),
    .tick_cnt(tick_cnt)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [7:0] t0;
  initial begin
    repeat (8) step();
    chk(nibble_valid === 1'b0 && nibble === 4'h0, "decoder quiet out of reset");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();
    t0 = tick_cnt;
    repeat (5) begin step(); chk(tick_cnt === t0 + 1, "tick counter increments"); t0 = tick_cnt; end

    // nibble 5 -> low pulse of 8 ticks
    begin : n5
      int to = 0;
      @(negedge clk); sens_out = 1'b0;
      repeat (8) step();
      @(negedge clk); sens_out = 1'b1;
      while (nibble_valid !== 1'b1 && to < 10) begin step(); to++; end
      chk(nibble_valid === 1'b1, "nibble valid strobe");
      chk(nibble === 4'd5, "nibble 5 decoded (8 ticks)");
    end
    step();
    chk(nibble_valid === 1'b0, "valid strobe is a pulse");

    // nibble 12 -> low pulse of 15 ticks
    begin : n12
      int to = 0;
      @(negedge clk); sens_out = 1'b0;
      repeat (15) step();
      @(negedge clk); sens_out = 1'b1;
      while (nibble_valid !== 1'b1 && to < 10) begin step(); to++; end
      chk(nibble_valid === 1'b1, "second nibble strobe");
      chk(nibble === 4'd12, "nibble 12 decoded (15 ticks)");
    end

    // pulse too short (<3 ticks): no strobe
    begin : short
      int to = 0;
      step();
      @(negedge clk); sens_out = 1'b0;
      repeat (2) step();
      @(negedge clk); sens_out = 1'b1;
      repeat (6) begin step(); to++; end
      chk(nibble_valid !== 1'b1, "illegal short pulse ignored");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
