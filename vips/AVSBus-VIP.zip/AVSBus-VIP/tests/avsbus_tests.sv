// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// avsbus_tests.sv -- AVSBus (Adaptive Voltage Scaling) UVM tests

package avsbus_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import avsbus_pkg::*;
  import env_pkg::*;

  class avsbus_base_test extends uvm_test;
    `uvm_component_utils(avsbus_base_test)
    avsbus_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = avsbus_env::type_id::create("env", this);
    endfunction
  endclass

  class avsbus_random_test extends avsbus_base_test;
    `uvm_component_utils(avsbus_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      avsbus_random_sequence seq = avsbus_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class avsbus_regression_test extends avsbus_base_test;
    `uvm_component_utils(avsbus_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      avsbus_regression_sequence seq = avsbus_regression_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  // UVM RAL on the regulator's VOUT register (env/avsbus_reg_model.svh):
  //   1. uvm_reg_hw_reset_seq   -- VOUT reads its reset value 0x60
  //   2. legal SetVoltage values (VMIN, VMAX, patterns, 64 pseudo-random)
  //      each followed by mirror(UVM_CHECK) and a read
  //   3. out-of-range SetVoltage values must return UVM_NOT_OK and leave
  //      VOUT unchanged (mirror check)
  // Uses no randomize(). Prints "RAL_PASS checks=<n>" when no UVM_ERROR or
  // UVM_FATAL was reported.
  class avsbus_ral_test extends avsbus_base_test;
    `uvm_component_utils(avsbus_ral_test)
    int unsigned checks;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task check_legal(avsbus_reg_block rm, bit [7:0] v);
      uvm_status_e   status;
      uvm_reg_data_t val;
      rm.VOUT.write(status, v);
      if (status != UVM_IS_OK) `uvm_error("RAL", $sformatf("VOUT write 0x%02h status %s", v, status.name()))
      rm.VOUT.mirror(status, UVM_CHECK);
      rm.VOUT.read(status, val);
      if (status != UVM_IS_OK || val != v)
        `uvm_error("RAL", $sformatf("VOUT read 0x%02h status %s, expected 0x%02h", val, status.name(), v))
      checks += 2;
    endtask

    task check_rejected(avsbus_reg_block rm, bit [7:0] v);
      uvm_status_e   status;
      uvm_reg_data_t keep = rm.VOUT.get_mirrored_value();
      rm.VOUT.write(status, v);
      if (status != UVM_NOT_OK)
        `uvm_error("RAL", $sformatf("out-of-range VOUT write 0x%02h returned %s", v, status.name()))
      // the write was rejected: put the mirror back, then check the DUT kept it
      void'(rm.VOUT.predict(keep));
      rm.VOUT.mirror(status, UVM_CHECK);
      checks += 2;
    endtask

    task run_phase(uvm_phase phase);
      uvm_reg_hw_reset_seq rst_seq;
      avsbus_reg_block     rm = env.regmodel;
      bit [7:0] legal[$] = '{avsbus_reg_block::VMIN, avsbus_reg_block::VMAX, 8'h55, 8'hAA, 8'h80, 8'h21, 8'hBF};
      bit [7:0] bad[$]   = '{8'h00, 8'h1F, 8'hC1, 8'hFF};
      phase.raise_objection(this);

      rst_seq = uvm_reg_hw_reset_seq::type_id::create("rst_seq");
      rst_seq.model = rm;
      rst_seq.start(null);
      checks++;

      foreach (legal[i]) check_legal(rm, legal[i]);
      foreach (bad[i])   check_rejected(rm, bad[i]);
      repeat (64) check_legal(rm, $urandom_range(avsbus_reg_block::VMAX, avsbus_reg_block::VMIN));

      #100ns;
      phase.drop_objection(this);
    endtask

    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      super.report_phase(phase);
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0)
        $display("RAL_PASS checks=%0d", checks);
      else
        $display("RAL_FAIL errors=%0d", rs.get_severity_count(UVM_ERROR));
    endfunction
  endclass
endpackage
