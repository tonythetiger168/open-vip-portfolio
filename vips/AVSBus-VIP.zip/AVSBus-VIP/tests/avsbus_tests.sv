// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// avsbus_tests.sv -- AVSBus (Adaptive Voltage Scaling) UVM tests

package avsbus_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import avsbus_pkg::*;
  import env_pkg::*;

  class avsbus_base_test extends uvm_test;
    `uvm_component_utils(avsbus_base_test)
    avsbus_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = avsbus_env::type_id::create("env", this);
    endfunction
  endclass

  class avsbus_random_test extends avsbus_base_test;
    `uvm_component_utils(avsbus_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      avsbus_random_sequence seq = avsbus_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class avsbus_regression_test extends avsbus_base_test;
    `uvm_component_utils(avsbus_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      avsbus_regression_sequence seq = avsbus_regression_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass
endpackage
