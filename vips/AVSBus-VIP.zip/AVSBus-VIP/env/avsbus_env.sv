// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// avsbus_env.sv -- AVSBus verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import avsbus_defs_pkg::*;
  import avsbus_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) commands against
  // monitor-decoded (observed) frames, predicts the slave status per opcode
  // legality, and shadows the regulator output voltage (vout) so response
  // payloads are checked end-to-end.
  class avsbus_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(avsbus_scoreboard)
    uvm_analysis_imp_exp #(avsbus_transaction, avsbus_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(avsbus_transaction, avsbus_scoreboard) obs_ap;

    avsbus_transaction exp_q[$], obs_q[$];
    int unsigned matched = 0, mismatched = 0;
    bit [7:0] sh_vout = 8'h60;   // shadow vout, mirrors the DUT reset value

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(avsbus_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(avsbus_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        avsbus_transaction e = exp_q.pop_front();
        avsbus_transaction o = obs_q.pop_front();
        bit ok = (e.opcode == o.opcode) && (e.voltage_id == o.voltage_id) &&
                 (e.resp_req == o.resp_req) && (e.error_inject == o.error_inject) &&
                 !o.parity_bad;
        if (ok && e.resp_req) begin
          // response must appear, with status per opcode legality, and the
          // response voltage must match the (possibly updated) shadow vout
          bit [7:0] new_vout = (e.opcode == avsbus_transaction::OP_SET_VOLT &&
                                e.op_legal()) ? e.voltage_id : sh_vout;
          bit [3:0] exp_stat = e.op_legal() ? avsbus_transaction::ST_ACK
                                            : avsbus_transaction::ST_ERR;
          ok = o.resp_seen && (o.status == exp_stat) && (o.resp_voltage == new_vout);
          if (o.resp_seen && o.status == avsbus_transaction::ST_ACK && e.op_legal())
            sh_vout = new_vout;
        end else if (ok) begin
          ok = !o.resp_seen;    // fire-and-forget: no response expected
          if (e.opcode == avsbus_transaction::OP_SET_VOLT && e.op_legal())
            sh_vout = e.voltage_id;
        end
        if (ok) matched++;
        else begin
          mismatched++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("avsbus scoreboard: matched=%0d mismatched=%0d",
                matched, mismatched), UVM_LOW)
      if (mismatched) `uvm_error("SB", "end-to-end mismatched detected")
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("unmatched transactions: exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
    endfunction
  endclass

  class avsbus_env extends uvm_env;
    `uvm_component_utils(avsbus_env)
    avsbus_agent      agt;
    avsbus_scoreboard sb;
    avsbus_checker    chk;
    avsbus_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = avsbus_agent::type_id::create("agt", this);
      sb  = avsbus_scoreboard::type_id::create("sb", this);
      chk = avsbus_checker::type_id::create("chk", this);
      cov = avsbus_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
