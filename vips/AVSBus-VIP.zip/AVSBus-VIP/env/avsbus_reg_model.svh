// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// avsbus_reg_model.svh -- UVM register model of the AVSBus regulator in
// tb/top_tb.sv (avsbus_regulator_model):
//   VOUT @ 0x0  8-bit output voltage id, reset 0x60. SetVoltage writes it,
//               GetVoltage reads it. Only 0x20..0xC0 is accepted; other
//               values are rejected with ST_ERR and leave VOUT unchanged, so
//               the register is excluded from bit-bash (NO_REG_BIT_BASH_TEST).
// ENABLE / DISABLE change no readable state and are not modelled.

`ifndef AVSBUS_REG_MODEL_SVH
`define AVSBUS_REG_MODEL_SVH

class avsbus_vout_reg extends uvm_reg;
  `uvm_object_utils(avsbus_vout_reg)
  rand uvm_reg_field VID;
  constraint c_legal { VID.value inside {[8'h20 : 8'hC0]}; }

  function new(string name = "avsbus_vout_reg");
    super.new(name, 8, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    VID = uvm_reg_field::type_id::create("VID");
    //           parent size lsb access volatile reset  has_reset rand individually_accessible
    VID.configure(this, 8,   0,  "RW",  0,       8'h60, 1,        1,   1);
  endfunction
endclass

class avsbus_reg_block extends uvm_reg_block;
  `uvm_object_utils(avsbus_reg_block)
  localparam bit [7:0] VMIN = 8'h20, VMAX = 8'hC0;
  rand avsbus_vout_reg VOUT;
  uvm_reg_map          avs_map;

  function new(string name = "avsbus_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    avs_map = create_map("avs_map", 'h0, 1, UVM_LITTLE_ENDIAN, 1);
    default_map = avs_map;
    VOUT = avsbus_vout_reg::type_id::create("VOUT");
    VOUT.configure(this, null, "");
    VOUT.build();
    avs_map.add_reg(VOUT, 'h0, "RW");
    uvm_resource_db#(bit)::set({"REG::", VOUT.get_full_name()}, "NO_REG_BIT_BASH_TEST", 1, this);
  endfunction
endclass
`endif
