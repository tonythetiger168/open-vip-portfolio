// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// avsbus_sequences.svh -- AVSBus sequence library

`ifndef AVSBUS_SEQUENCES_SVH
`define AVSBUS_SEQUENCES_SVH

class avsbus_base_sequence extends uvm_sequence #(avsbus_transaction);
  `uvm_object_utils(avsbus_base_sequence)
  int num_txns = 20;
  function new(string name = "avsbus_base_sequence"); super.new(name); endfunction
  task body();
    avsbus_transaction tr;
    repeat (num_txns) begin
      tr = avsbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: voltage programming sweep across the legal range
class avsbus_set_voltage_seq extends avsbus_base_sequence;
  function new(string name = "avsbus_set_voltage_seq"); super.new(name); endfunction
  `uvm_object_utils(avsbus_set_voltage_seq)
  task body();
    avsbus_transaction tr;
    repeat (num_txns) begin
      tr = avsbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode == avsbus_transaction::OP_SET_VOLT;
                                  resp_req == 1; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: voltage readback
class avsbus_get_voltage_seq extends avsbus_base_sequence;
  function new(string name = "avsbus_get_voltage_seq"); super.new(name); endfunction
  `uvm_object_utils(avsbus_get_voltage_seq)
  task body();
    avsbus_transaction tr;
    repeat (num_txns) begin
      tr = avsbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode == avsbus_transaction::OP_GET_VOLT;
                                  resp_req == 1; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: regulator enable / disable control
class avsbus_enable_seq extends avsbus_base_sequence;
  function new(string name = "avsbus_enable_seq"); super.new(name); endfunction
  `uvm_object_utils(avsbus_enable_seq)
  task body();
    avsbus_transaction tr;
    repeat (num_txns) begin
      tr = avsbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode inside {avsbus_transaction::OP_ENABLE,
                                                 avsbus_transaction::OP_DISABLE};
                                  resp_req == 1; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: corner voltages (min / max of the legal range)
class avsbus_corner_voltage_seq extends avsbus_base_sequence;
  function new(string name = "avsbus_corner_voltage_seq"); super.new(name); endfunction
  `uvm_object_utils(avsbus_corner_voltage_seq)
  task body();
    avsbus_transaction tr;
    bit [7:0] corners[$] = '{avsbus_transaction::VMIN, avsbus_transaction::VMAX};
    repeat (num_txns) begin
      tr = avsbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode == avsbus_transaction::OP_SET_VOLT;
                                  voltage_id inside {corners};
                                  resp_req == 1; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: fire-and-forget commands (resp_req=0, no slave response)
class avsbus_no_resp_seq extends avsbus_base_sequence;
  function new(string name = "avsbus_no_resp_seq"); super.new(name); endfunction
  `uvm_object_utils(avsbus_no_resp_seq)
  task body();
    avsbus_transaction tr;
    repeat (num_txns) begin
      tr = avsbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { resp_req == 0; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back frames with no idle gap
class avsbus_back_to_back_seq extends avsbus_base_sequence;
  function new(string name = "avsbus_back_to_back_seq"); super.new(name); endfunction
  `uvm_object_utils(avsbus_back_to_back_seq)
  task body();
    avsbus_transaction tr;
    repeat (num_txns) begin
      tr = avsbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { idle_cycles == 0; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: illegal (undefined) opcodes, slave must answer ERR
class avsbus_error_inject_seq extends avsbus_base_sequence;
  function new(string name = "avsbus_error_inject_seq"); super.new(name); endfunction
  `uvm_object_utils(avsbus_error_inject_seq)
  task body();
    avsbus_transaction tr;
    repeat (num_txns) begin
      tr = avsbus_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 1; resp_req == 1; });
      finish_item(tr);
    end
  endtask
endclass

class avsbus_random_sequence extends avsbus_base_sequence;
  `uvm_object_utils(avsbus_random_sequence)
  function new(string name = "avsbus_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class avsbus_regression_sequence extends avsbus_base_sequence;
  `uvm_object_utils(avsbus_regression_sequence)
  function new(string name = "avsbus_regression_sequence"); super.new(name); endfunction
  task body();
    avsbus_set_voltage_seq    set_  = avsbus_set_voltage_seq::type_id::create("set_");
    avsbus_get_voltage_seq    get_  = avsbus_get_voltage_seq::type_id::create("get_");
    avsbus_enable_seq         en    = avsbus_enable_seq::type_id::create("en");
    avsbus_corner_voltage_seq corn  = avsbus_corner_voltage_seq::type_id::create("corn");
    avsbus_no_resp_seq        noresp= avsbus_no_resp_seq::type_id::create("noresp");
    avsbus_back_to_back_seq   b2b   = avsbus_back_to_back_seq::type_id::create("b2b");
    avsbus_error_inject_seq   err   = avsbus_error_inject_seq::type_id::create("err");
    avsbus_random_sequence    rnd   = avsbus_random_sequence::type_id::create("rnd");
    set_.num_txns = 10; get_.num_txns = 6; en.num_txns = 6; corn.num_txns = 6;
    noresp.num_txns = 4; b2b.num_txns = 8; err.num_txns = 8; rnd.num_txns = 20;
    set_.start(m_sequencer);  get_.start(m_sequencer); en.start(m_sequencer);
    corn.start(m_sequencer);  noresp.start(m_sequencer);
    b2b.start(m_sequencer);   err.start(m_sequencer);  rnd.start(m_sequencer);
  endtask
endclass
`endif
