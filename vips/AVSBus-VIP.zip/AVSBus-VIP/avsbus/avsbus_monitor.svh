// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// avsbus_monitor.svh -- AVSBus monitor: decodes the master command frame
// (avs_mdata while avs_ctrl=1) and the slave response frame (avs_sdata),
// publishing reconstructed transactions. A missing response inside the
// timeout window is flagged with resp_seen=0.

`ifndef AVSBUS_MONITOR_SVH
`define AVSBUS_MONITOR_SVH

class avsbus_monitor extends uvm_monitor;
  `uvm_component_utils(avsbus_monitor)
  virtual avsbus_if vif;
  uvm_analysis_port #(avsbus_transaction) ap;
  int unsigned txn_count = 0;

  localparam int FRAME_BITS   = 15;
  localparam int RESP_TIMEOUT = 16;

  typedef enum bit [1:0] {M_IDLE, M_FRAME, M_WAIT, M_RESP} mstate_e;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual avsbus_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avsbus virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    mstate_e st = M_IDLE;
    bit [14:0] msh, ssh;
    int unsigned mcnt = 0, rcnt = 0, to_cnt = 0;
    avsbus_transaction tr;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        st = M_IDLE; mcnt = 0; rcnt = 0; to_cnt = 0;
        continue;
      end
      case (st)
        // ---- wait for frame start (ctrl high, first bit = start) ----
        M_IDLE: begin
          if (vif.mon_cb.avs_ctrl) begin
            tr  = avsbus_transaction::type_id::create("tr");
            msh = {14'h0, vif.mon_cb.avs_mdata};
            mcnt = 1;
            st  = M_FRAME;
          end
        end
        // ---- master frame: 14 more bits ----
        M_FRAME: begin
          msh = {msh[13:0], vif.mon_cb.avs_mdata};
          mcnt++;
          if (mcnt == FRAME_BITS) begin
            tr.opcode     = msh[13:10];
            tr.resp_req   = msh[9];
            tr.voltage_id = msh[8:1];
            tr.error_inject = !tr.op_legal();
            tr.parity_bad = (msh[14] !== 1'b1) || (^msh[13:1] != msh[0]);
            if (tr.parity_bad)
              `uvm_warning("MON", "master frame parity/start error")
            if (tr.resp_req && !tr.parity_bad) begin
              to_cnt = 0;
              st = M_WAIT;
            end else begin
              tr.resp_seen = 0;
              txn_count++;
              `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
              ap.write(tr);
              st = M_IDLE;
            end
          end
        end
        // ---- wait for the slave response start bit ----
        M_WAIT: begin
          to_cnt++;
          if (vif.mon_cb.avs_sdata === 1'b1) begin
            ssh  = {14'h0, 1'b1};
            rcnt = 1;
            st   = M_RESP;
          end else if (to_cnt >= RESP_TIMEOUT) begin
            tr.resp_seen = 0;
            `uvm_warning("MON", "slave response timeout")
            txn_count++;
            ap.write(tr);
            st = M_IDLE;
          end
        end
        // ---- slave response frame: 14 more bits ----
        M_RESP: begin
          ssh = {ssh[13:0], vif.mon_cb.avs_sdata};
          rcnt++;
          if (rcnt == FRAME_BITS) begin
            tr.resp_seen    = 1;
            tr.status       = ssh[13:10];
            tr.resp_voltage = ssh[8:1];
            if (ssh[14] !== 1'b1 || ^ssh[13:1] != ssh[0])
              `uvm_warning("MON", "slave response parity/start error")
            txn_count++;
            `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
            ap.write(tr);
            st = M_IDLE;
          end
        end
        default: st = M_IDLE;
      endcase
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("avsbus monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
