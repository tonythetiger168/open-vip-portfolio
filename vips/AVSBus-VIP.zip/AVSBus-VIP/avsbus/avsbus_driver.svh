// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// avsbus_driver.svh -- AVSBus master driver (bit-banged command/voltage frame)
//
// The master shifts a 15-bit frame MSB-first onto avs_mdata while avs_ctrl
// is high, then waits through a fixed response window (ACK state). If
// resp_req is set, the voltage regulator slave answers on avs_sdata within
// the window. Lines idle low between transfers.

`ifndef AVSBUS_DRIVER_SVH
`define AVSBUS_DRIVER_SVH

class avsbus_driver extends uvm_driver #(avsbus_transaction);
  `uvm_component_utils(avsbus_driver)
  virtual avsbus_if vif;
  avsbus_config cfg;
  uvm_analysis_port #(avsbus_transaction) drv_ap;  // expected items for scoreboard

  localparam int FRAME_BITS = 15;   // start + opcode + resp_req + vid + parity
  localparam int RESP_GAP   = 3;    // slave response gap (avs_clk cycles)
  localparam int ACK_WINDOW = RESP_GAP + FRAME_BITS + 3;  // response window

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual avsbus_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avsbus virtual interface not set")
  endfunction

  task automatic send_frame(avsbus_transaction tr);
    bit [14:0] f;
    f[14]   = 1'b1;                                        // start
    f[13:10]= tr.opcode;
    f[9]    = tr.resp_req;
    f[8:1]  = tr.voltage_id;
    f[0]    = ^{tr.opcode, tr.resp_req, tr.voltage_id};    // even parity
    // command phase: start + opcode + resp_req (6 bits)
    vif.drv_cb.avs_ctrl  <= 1'b1;
    vif.drv_cb.avs_mdata <= f[14];
    @(vif.drv_cb);
    vif.state = avsbus_defs_pkg::COMMAND;
    for (int i = 13; i >= 9; i--) begin
      vif.drv_cb.avs_mdata <= f[i];
      @(vif.drv_cb);
    end
    // data phase: voltage_id + parity (9 bits)
    vif.state = avsbus_defs_pkg::DATA_PHASE;
    for (int i = 8; i >= 0; i--) begin
      vif.drv_cb.avs_mdata <= f[i];
      @(vif.drv_cb);
    end
    // end of frame: ctrl low, mdata idle low
    vif.drv_cb.avs_ctrl  <= 1'b0;
    vif.drv_cb.avs_mdata <= 1'b0;
  endtask

  task run_phase(uvm_phase phase);
    avsbus_transaction tr;
    vif.drv_cb.avs_ctrl  <= 1'b0;
    vif.drv_cb.avs_mdata <= 1'b0;
    vif.state = avsbus_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      send_frame(tr);
      // response window (slave answers on avs_sdata when resp_req=1)
      vif.state = avsbus_defs_pkg::ACK;
      repeat (ACK_WINDOW) @(vif.drv_cb);
      vif.state = avsbus_defs_pkg::IDLE;
      repeat (tr.idle_cycles) @(vif.drv_cb);
      drv_ap.write(tr);                          // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
