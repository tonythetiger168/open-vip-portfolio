// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// avsbus_compliance_checker.sv -- AVSBus SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = AVSBus protocol-specific rules

`ifndef AVSBUS_COMPLIANCE_CHECKER_SV
`define AVSBUS_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import avsbus_defs_pkg::*;

module avsbus_compliance_checker
(
  input logic avs_clk,
  input logic rst_n,
  input avsbus_state_e state,
  input logic avs_mdata,
  input logic avs_sdata,
  input logic avs_ctrl
);

  localparam bit [3:0] OP_SET_VOLT = 4'h1, OP_GET_VOLT = 4'h2,
                       OP_ENABLE = 4'h3, OP_DISABLE = 4'h4;
  localparam bit [3:0] ST_ACK = 4'hA, ST_ERR = 4'hF;
  localparam bit [7:0] VMIN = 8'h20, VMAX = 8'hC0;

  // ---- helper logic: frame capture for L4 checks ----
  bit [14:0]  msh_q, ssh_q;
  int unsigned ctrl_cnt, rsp_cnt;
  bit         rsp_wait, rsp_active, resp_done;

  wire op_legal = msh_q[13:10] inside {OP_SET_VOLT, OP_GET_VOLT, OP_ENABLE, OP_DISABLE};
  wire frame_ok = (msh_q[14] === 1'b1) && (^msh_q[13:1] == msh_q[0]);

  always @(posedge avs_clk or negedge rst_n) begin
    if (!rst_n) begin
      msh_q <= '0; ssh_q <= '0;
      ctrl_cnt <= 0; rsp_cnt <= 0;
      rsp_wait <= 0; rsp_active <= 0; resp_done <= 0;
    end else begin
      resp_done <= 1'b0;
      // master frame capture (15 bits while ctrl high)
      if (avs_ctrl) begin
        msh_q    <= {msh_q[13:0], avs_mdata};
        ctrl_cnt <= ctrl_cnt + 1;
      end else begin
        if (ctrl_cnt == 15 && msh_q[9] && frame_ok) rsp_wait <= 1'b1;
        ctrl_cnt <= 0;
      end
      // slave response capture (start bit + 14 bits)
      if (rsp_wait && avs_sdata === 1'b1) begin
        rsp_wait   <= 1'b0;
        rsp_active <= 1'b1;
        ssh_q      <= 15'h1;
        rsp_cnt    <= 1;
      end else if (rsp_active) begin
        ssh_q   <= {ssh_q[13:0], avs_sdata};
        rsp_cnt <= rsp_cnt + 1;
        if (rsp_cnt == 14) rsp_active <= 1'b0;   // 15th bit shifted this cycle
      end else if (rsp_cnt == 15) begin
        rsp_cnt   <= 0;
        resp_done <= 1'b1;                        // ssh_q complete
      end
    end
  end

  // ---------------- L1: signal sanity (4) ----------------
  a_avsbus_l1_clk   : assert property (@(posedge avs_clk) disable iff (!rst_n) !$isunknown(avs_clk))
    else `uvm_error("SVA_L1", "avsbus: clock unknown")
  a_avsbus_l1_rst   : assert property (@(posedge avs_clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "avsbus: reset unknown")
  a_avsbus_l1_state : assert property (@(posedge avs_clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "avsbus: state unknown")
  a_avsbus_l1_valid : assert property (@(posedge avs_clk) disable iff (!rst_n)
    state inside {IDLE, COMMAND, DATA_PHASE, ACK})
    else `uvm_error("SVA_L1", "avsbus: state outside legal encoding")

  // ---------------- L2: FSM legality (4) ----------------
  // L2-1: legal FSM transition from IDLE
  a_avsbus_trans_idle : assert property (@(posedge avs_clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, COMMAND})
    else `uvm_error("SVA_L2", "avsbus: illegal transition from IDLE")

  // L2-2: legal FSM transition from COMMAND
  a_avsbus_trans_command : assert property (@(posedge avs_clk) disable iff (!rst_n)
    state == COMMAND |=> state inside {COMMAND, DATA_PHASE})
    else `uvm_error("SVA_L2", "avsbus: illegal transition from COMMAND")

  // L2-3: legal FSM transition from DATA_PHASE
  a_avsbus_trans_data_phase : assert property (@(posedge avs_clk) disable iff (!rst_n)
    state == DATA_PHASE |=> state inside {DATA_PHASE, ACK})
    else `uvm_error("SVA_L2", "avsbus: illegal transition from DATA_PHASE")

  // L2-4: legal FSM transition from ACK
  a_avsbus_trans_ack : assert property (@(posedge avs_clk) disable iff (!rst_n)
    state == ACK |=> state inside {ACK, IDLE})
    else `uvm_error("SVA_L2", "avsbus: illegal transition from ACK")

  // ---------------- L3: protocol rules (4) ----------------
  a_avsbus_l3_reset_idle : assert property (@(posedge avs_clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "avsbus: state not IDLE during reset")
  // ACK state spans the full response window (gap + 15-bit response + margin)
  a_avsbus_l3_no_stuck   : assert property (@(posedge avs_clk) disable iff (!rst_n)
    state == ACK |-> ##[1:24] (state != ACK))
    else `uvm_error("SVA_L3", "avsbus: stuck in ACK")
  a_avsbus_l3_full_cycle : cover property (@(posedge avs_clk) disable iff (!rst_n)
    state == IDLE ##1 state == COMMAND);
  a_avsbus_l3_back_idle  : cover property (@(posedge avs_clk) disable iff (!rst_n)
    state == ACK ##1 state == IDLE);

  // ---------------- L4: AVSBus protocol-specific rules (6) ----------------
  // L4-1: frame format - every frame starts with a start bit (mdata=1 at ctrl rise)
  a_avsbus_l4_frame_start : assert property (@(posedge avs_clk) disable iff (!rst_n)
    $rose(avs_ctrl) |-> (avs_mdata == 1'b1))
    else `uvm_error("SVA_L4", "avsbus: frame without start bit")

  // L4-2: frame format - avs_ctrl is high for exactly 15 cycles per frame
  a_avsbus_l4_frame_width : assert property (@(posedge avs_clk) disable iff (!rst_n)
    $fell(avs_ctrl) |-> (ctrl_cnt == 15))
    else `uvm_error("SVA_L4", "avsbus: frame width not exactly 15 cycles")

  // L4-3: response timeout - a frame requesting a response is answered within 16 cycles
  a_avsbus_l4_resp_timeout : assert property (@(posedge avs_clk) disable iff (!rst_n)
    ($fell(avs_ctrl) && msh_q[9] && frame_ok) |-> ##[1:16] $rose(avs_sdata))
    else `uvm_error("SVA_L4", "avsbus: slave response timeout")

  // L4-4: voltage range - SET_VOLT commands carry a voltage id in [VMIN:VMAX]
  a_avsbus_l4_volt_range : assert property (@(posedge avs_clk) disable iff (!rst_n)
    ($fell(avs_ctrl) && frame_ok && msh_q[13:10] == OP_SET_VOLT)
    |-> (msh_q[8:1] >= VMIN && msh_q[8:1] <= VMAX))
    else `uvm_error("SVA_L4", "avsbus: SET_VOLT voltage id out of range")

  // L4-5: illegal opcodes are answered with ERR, legal ones with ACK
  a_avsbus_l4_status_legal : assert property (@(posedge avs_clk) disable iff (!rst_n)
    resp_done |-> (op_legal ? (ssh_q[13:10] == ST_ACK) : (ssh_q[13:10] == ST_ERR)))
    else `uvm_error("SVA_L4", "avsbus: status does not match opcode legality")

  // L4-6: idle line state (settled IDLE): mdata/sdata/ctrl all low
  a_avsbus_l4_idle_line : assert property (@(posedge avs_clk) disable iff (!rst_n)
    (state == IDLE && $past(state) == IDLE)
    |-> (avs_mdata == 1'b0 && avs_sdata == 1'b0 && avs_ctrl == 1'b0))
    else `uvm_error("SVA_L4", "avsbus: idle line state violated")

endmodule
`endif
