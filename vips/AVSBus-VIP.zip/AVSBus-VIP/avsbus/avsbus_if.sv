// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// avsbus_if.sv -- AVSBus (Adaptive Voltage Scaling) interface
//
//   avs_clk  : bus clock (interface input, free-running)
//   avs_mdata: master -> slave serial data (command/voltage frame, MSB-first)
//   avs_ctrl : master frame-valid strobe (high for exactly FRAME_BITS cycles)
//   avs_sdata: slave -> master serial data (status/voltage response, MSB-first)
//
// Bits change on the falling edge of avs_clk and are sampled on the rising edge.

interface avsbus_if (input logic avs_clk);
  import avsbus_defs_pkg::avsbus_state_e;

  logic rst_n;
  logic avs_mdata = 1'b0;
  logic avs_sdata = 1'b0;
  logic avs_ctrl  = 1'b0;

  avsbus_state_e state;   // protocol bookkeeping (driven by the VIP driver)

  modport MASTER (input  avs_clk, rst_n, avs_sdata,
                  output avs_mdata, avs_ctrl, state);
  modport DUT    (input  avs_clk, rst_n, avs_mdata, avs_ctrl,
                  output avs_sdata);
  modport MON    (input  avs_clk, rst_n, avs_mdata, avs_sdata, avs_ctrl, state);

  // Master drives on the falling edge of avs_clk.
  clocking drv_cb @(negedge avs_clk);
    input  rst_n, avs_sdata;
    output avs_mdata, avs_ctrl;
  endclocking

  // Monitor samples on the rising edge of avs_clk.
  clocking mon_cb @(posedge avs_clk);
    input rst_n, avs_mdata, avs_sdata, avs_ctrl, state;
  endclocking
endinterface
