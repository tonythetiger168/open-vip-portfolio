// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// avsbus_coverage.svh -- AVSBus functional coverage

`ifndef AVSBUS_COVERAGE_SVH
`define AVSBUS_COVERAGE_SVH

class avsbus_coverage extends uvm_subscriber #(avsbus_transaction);
  `uvm_component_utils(avsbus_coverage)

  avsbus_transaction tr;
  avsbus_defs_pkg::avsbus_state_e cur_state;
  virtual avsbus_if vif;

  covergroup cg_protocol;
    cp_opcode : coverpoint tr.opcode {
      bins set_volt = {avsbus_transaction::OP_SET_VOLT};
      bins get_volt = {avsbus_transaction::OP_GET_VOLT};
      bins enable   = {avsbus_transaction::OP_ENABLE};
      bins dis      = {avsbus_transaction::OP_DISABLE};
      bins illegal[] = {[4'h0 : 4'hF]} with (!(item inside {avsbus_transaction::OP_SET_VOLT,
                                                            avsbus_transaction::OP_GET_VOLT,
                                                            avsbus_transaction::OP_ENABLE,
                                                            avsbus_transaction::OP_DISABLE}));
    }
    cp_volt : coverpoint tr.voltage_id {
      bins vmin = {avsbus_transaction::VMIN};
      bins vmax = {avsbus_transaction::VMAX};
      bins low  = {[avsbus_transaction::VMIN+1 : 8'h6F]};
      bins high = {[8'h70 : avsbus_transaction::VMAX-1]};
    }
    cp_resp : coverpoint tr.resp_req { bins no = {0}; bins yes = {1}; }
    cx_op_volt : cross cp_opcode, cp_volt;
    cx_op_resp : cross cp_opcode, cp_resp;
  endgroup

  covergroup cg_fsm with function sample(avsbus_defs_pkg::avsbus_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {avsbus_defs_pkg::IDLE, avsbus_defs_pkg::COMMAND,
                           avsbus_defs_pkg::DATA_PHASE, avsbus_defs_pkg::ACK};
    }
    cp_trans : coverpoint s {
      bins frame_seq = (avsbus_defs_pkg::IDLE => avsbus_defs_pkg::COMMAND =>
                        avsbus_defs_pkg::DATA_PHASE => avsbus_defs_pkg::ACK =>
                        avsbus_defs_pkg::IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_status : coverpoint tr.status iff (tr.resp_seen) {
      bins ack = {avsbus_transaction::ST_ACK};
      bins err = {avsbus_transaction::ST_ERR};
    }
    cp_illegal : coverpoint tr.error_inject { bins legal = {0}; bins illegal = {1}; }
    cp_no_resp : coverpoint tr.resp_seen { bins seen = {1}; bins missing = {0}; }
    cx_op_status : cross cp_illegal, cp_status;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual avsbus_if)::get(this, "", "vif", vif));
  endfunction

  function void write(avsbus_transaction t);
    tr = t;
    if (vif != null) cur_state = vif.state;
    cg_protocol.sample();
    cg_fsm.sample(cur_state);
    cg_error.sample();
  endfunction
endclass
`endif
