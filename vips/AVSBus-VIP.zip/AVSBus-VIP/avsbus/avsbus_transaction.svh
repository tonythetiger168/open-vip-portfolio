// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// avsbus_transaction.svh -- AVSBus command/response transaction
//
// Master frame (15 bits, MSB-first on avs_mdata while avs_ctrl=1):
//   start(1) opcode(4) resp_req(1) voltage_id(8) parity(1, even)
// Slave response (15 bits, MSB-first on avs_sdata):
//   start(1) status(4) rsv(1) resp_voltage(8) parity(1, even)

`ifndef AVSBUS_TRANSACTION_SVH
`define AVSBUS_TRANSACTION_SVH

class avsbus_transaction extends uvm_sequence_item;

  // opcodes
  localparam bit [3:0] OP_SET_VOLT = 4'h1;  // program a new voltage id
  localparam bit [3:0] OP_GET_VOLT = 4'h2;  // read back the current voltage id
  localparam bit [3:0] OP_ENABLE   = 4'h3;  // enable the regulator output
  localparam bit [3:0] OP_DISABLE  = 4'h4;  // disable the regulator output

  // status codes
  localparam bit [3:0] ST_ACK = 4'hA;       // command accepted
  localparam bit [3:0] ST_ERR = 4'hF;       // illegal opcode / rejected

  // legal voltage id range (0.60 V .. 1.20 V in 5 mV-ish steps, abstract)
  localparam bit [7:0] VMIN = 8'h20;
  localparam bit [7:0] VMAX = 8'hC0;

  rand bit [3:0]  opcode;
  rand bit [7:0]  voltage_id;
  rand bit        resp_req;      // 1 = slave must answer on avs_sdata
  rand bit        error_inject;  // 1 = use an illegal (undefined) opcode
  rand int unsigned idle_cycles; // idle cycles after the response window

  // Observed by the monitor
  bit [3:0]  status;             // decoded response status
  bit [7:0]  resp_voltage;       // decoded response voltage id
  bit        resp_seen;          // a response frame was observed
  bit        parity_bad;         // master-frame parity mismatch (should not occur)

  constraint c_op {
    !error_inject -> opcode inside {OP_SET_VOLT, OP_GET_VOLT, OP_ENABLE, OP_DISABLE};
    error_inject  -> !(opcode inside {OP_SET_VOLT, OP_GET_VOLT, OP_ENABLE, OP_DISABLE});
  }
  constraint c_volt { voltage_id inside {[VMIN:VMAX]}; }
  constraint c_err  { error_inject dist {0 := 8, 1 := 2}; }
  constraint c_resp { resp_req dist {1 := 8, 0 := 2}; }
  constraint c_idle { idle_cycles inside {[0:6]}; }

  `uvm_object_utils_begin(avsbus_transaction)
    `uvm_field_int(opcode, UVM_ALL_ON)
    `uvm_field_int(voltage_id, UVM_ALL_ON)
    `uvm_field_int(resp_req, UVM_ALL_ON)
    `uvm_field_int(error_inject, UVM_ALL_ON)
    `uvm_field_int(status, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(resp_voltage, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "avsbus_transaction");
    super.new(name);
  endfunction

  function bit op_legal();
    return opcode inside {OP_SET_VOLT, OP_GET_VOLT, OP_ENABLE, OP_DISABLE};
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    avsbus_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= (comparer.compare_field("opcode", opcode, t.opcode, 4) == 1);
    do_compare &= (comparer.compare_field("voltage_id", voltage_id, t.voltage_id, 8) == 1);
    do_compare &= (comparer.compare_field("resp_req", resp_req, t.resp_req, 1) == 1);
    if (resp_seen)
      do_compare &= (comparer.compare_field("status", status, t.status, 4) == 1);
  endfunction

  function string convert2string();
    return $sformatf("AVS op=0x%01h vid=0x%02h resp_req=%0b%s -> %s vout=0x%02h%s",
                     opcode, voltage_id, resp_req,
                     error_inject ? " [ILLEGAL_OP]" : "",
                     resp_seen ? (status == ST_ACK ? "ACK" : "ERR") : "NO-RESP",
                     resp_voltage, parity_bad ? " [PARITY_BAD]" : "");
  endfunction
endclass
`endif
