// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// avsbus_reg_adapter.svh -- UVM RAL adapter for the AVSBus master agent
//   reg2bus: UVM_WRITE -> SetVoltage(voltage_id = data), UVM_READ -> GetVoltage,
//            both with resp_req = 1 so the regulator answers
//   bus2reg: avsbus_transaction (driver-completed or monitor-observed) -> uvm_reg_bus_op
// The driver writes the response (resp_seen / status / resp_voltage) back into
// the request item and sends no separate response, so provides_responses = 0.
// Status is UVM_IS_OK only for an ACK response; a rejected (out-of-range)
// SetVoltage or a missing response is UVM_NOT_OK, so the mirror is not updated.
// A SetVoltage sent without resp_req is taken silently when it is in range.

`ifndef AVSBUS_REG_ADAPTER_SVH
`define AVSBUS_REG_ADAPTER_SVH

class avsbus_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(avsbus_reg_adapter)

  function new(string name = "avsbus_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 0;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    avsbus_transaction tr = avsbus_transaction::type_id::create("ral_item");
    tr.opcode       = (rw.kind == UVM_WRITE) ? avsbus_transaction::OP_SET_VOLT
                                             : avsbus_transaction::OP_GET_VOLT;
    tr.voltage_id   = (rw.kind == UVM_WRITE) ? rw.data[7:0] : 8'h0;
    tr.resp_req     = 1'b1;
    tr.error_inject = 1'b0;
    tr.idle_cycles  = 2;
    return tr;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    avsbus_transaction tr;
    bit is_set, is_get;
    if (!$cast(tr, bus_item)) begin
      `uvm_fatal("AVS_RAL", "bus2reg: item is not an avsbus_transaction")
      return;
    end
    is_set = (tr.opcode == avsbus_transaction::OP_SET_VOLT);
    is_get = (tr.opcode == avsbus_transaction::OP_GET_VOLT);
    rw.kind    = is_set ? UVM_WRITE : UVM_READ;
    rw.addr    = 0;
    rw.data    = is_set ? tr.voltage_id : tr.resp_voltage;
    rw.n_bits  = 8;
    rw.byte_en = '1;
    if (tr.resp_req)
      rw.status = (tr.resp_seen && tr.status == avsbus_transaction::ST_ACK && (is_set || is_get))
                  ? UVM_IS_OK : UVM_NOT_OK;
    else   // fire-and-forget: the regulator silently takes an in-range SetVoltage
      rw.status = (is_set && tr.voltage_id inside {[avsbus_transaction::VMIN : avsbus_transaction::VMAX]})
                  ? UVM_IS_OK : UVM_NOT_OK;
    // anything that did not read or change VOUT (ENABLE / DISABLE, rejected or
    // unanswered frames) goes to an unmapped address, so the predictor skips it
    if (rw.status != UVM_IS_OK) rw.addr = 'h100;
  endfunction
endclass
`endif
