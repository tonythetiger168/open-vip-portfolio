// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// avsbus_error_checker.sv -- AVSBus (Adaptive Voltage Scaling) error injection / detection checker

`ifndef AVSBUS_ERROR_CHECKER_SV
`define AVSBUS_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import avsbus_defs_pkg::avsbus_state_e;

module avsbus_error_checker
(
  input logic avs_clk,
  input logic rst_n,
  input avsbus_state_e state
);
  a_avsbus_error_state_known : assert property (@(posedge avs_clk)
    disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("ERROR", "avsbus error: state unknown")
endmodule
`endif
