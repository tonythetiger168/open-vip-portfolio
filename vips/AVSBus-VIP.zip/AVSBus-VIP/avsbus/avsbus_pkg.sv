// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// avsbus_pkg.sv -- AVSBus (Adaptive Voltage Scaling) UVM VIP package

package avsbus_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import avsbus_defs_pkg::*;
  export avsbus_defs_pkg::*;

  `include "avsbus_transaction.svh"
  `include "avsbus_config.svh"
  `include "avsbus_sequencer.svh"
  `include "avsbus_driver.svh"
  `include "avsbus_monitor.svh"
  `include "avsbus_agent.svh"
  `include "avsbus_sequences.svh"
  `include "avsbus_checker.svh"
  `include "avsbus_coverage.svh"
endpackage
