// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_avsbus_tb.sv -- self-checking functional test for the AVSBus regulator
// model (avsbus_regulator_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py AVSBus-VIP
//
// Model contract (from tb/top_tb.sv):
//   master frame: 15 bits MSB first on avs_mdata, sampled on posedge, first
//   bit flagged by avs_ctrl: [14]=start(1) [13:10]=opcode [9]=resp_req
//   [8:1]=voltage id [0]=even parity over [13:1].
//   opcodes SET_VOLT=1 GET_VOLT=2 ENABLE=3 DISABLE=4; SET_VOLT accepted for
//   0x20 <= vid <= 0xC0. With resp_req the slave answers on avs_sdata after
//   3 clocks: [14]=start [13:10]=status (ACK=A, ERR=F) [9]=0 [8:1]=vout
//   [0]=parity, MSB first, one bit per clock.

module func_avsbus_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [3:0] SET = 4'h1, GET = 4'h2, EN = 4'h3, DIS = 4'h4, ACK = 4'hA, ERR = 4'hF;
  int checks = 0, fails = 0;

  logic clk = 1'b0, rst_n = 1'b0, mdata = 1'b0, ctrl = 1'b0;
  wire  sdata;

  always #5 clk = ~clk;

  avsbus_regulator_model u_dut (
    .vif_avs_clk(clk), .vif_rst_n(rst_n), .vif_avs_mdata(mdata),
    .vif_avs_sdata(sdata), .vif_avs_ctrl(ctrl)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // drive one master frame; bad_par flips the parity bit
  task automatic send(input [3:0] op, input bit resp, input [7:0] vid, input bit bad_par = 0);
    bit [14:0] f;
    f[14] = 1'b1; f[13:10] = op; f[9] = resp; f[8:1] = vid;
    f[0] = ^f[13:1] ^ bad_par;
    for (int i = 14; i >= 0; i--) begin
      @(negedge clk);
      mdata = f[i]; ctrl = (i == 14);
    end
    @(negedge clk);
    mdata = 1'b0; ctrl = 1'b0;
  endtask

  // capture a slave response frame; got=0 if no start bit within 'win' clocks
  task automatic recv(output bit got, output [14:0] r, input int win = 12);
    got = 0; r = '0;
    for (int k = 0; k < win && !got; k++) begin
      @(posedge clk);
      if (sdata === 1'b1) got = 1;
    end
    if (got) begin
      r[14] = 1'b1;
      for (int i = 13; i >= 0; i--) begin
        @(posedge clk);
        r[i] = sdata;
      end
    end
  endtask

  // send with response and decode it
  bit [14:0] r;
  bit        got;
  task automatic xact(input [3:0] op, input [7:0] vid, input bit bad_par = 0);
    fork
      send(op, 1'b1, vid, bad_par);
      begin
        // the response cannot start before the frame ends
        repeat (15) @(posedge clk);
        recv(got, r);
      end
    join
  endtask

  function automatic bit rsp_ok(input [3:0] st, input [7:0] v);
    return got && r[13:10] == st && r[9] == 1'b0 && r[8:1] == v &&
           r[0] == ^{st, 1'b0, v};
  endfunction

  initial begin
    // frame during reset is ignored (model waits for reset release)
    send(SET, 1'b0, 8'h40);
    @(negedge clk); rst_n = 1'b1;
    repeat (3) @(posedge clk);

    xact(GET, 8'h00);
    chk(rsp_ok(ACK, 8'h60), "GET_VOLT returns the reset voltage 0x60 (SET sent during reset ignored)");
    chk(got && r[14] == 1'b1 && r[9] == 1'b0, "response frame start bit / reserved bit");

    xact(SET, 8'h80);
    chk(rsp_ok(ACK, 8'h80), "SET_VOLT in range is ACKed and echoes the new voltage");
    xact(GET, 8'h00);
    chk(rsp_ok(ACK, 8'h80), "GET_VOLT reads back the programmed voltage");

    xact(SET, 8'h1F);
    chk(rsp_ok(ERR, 8'h80), "SET_VOLT below VMIN is rejected with ERR, voltage unchanged");
    xact(SET, 8'hC1);
    chk(rsp_ok(ERR, 8'h80), "SET_VOLT above VMAX is rejected with ERR");
    xact(SET, 8'h20);
    chk(rsp_ok(ACK, 8'h20), "SET_VOLT at VMIN boundary accepted");
    xact(SET, 8'hC0);
    chk(rsp_ok(ACK, 8'hC0), "SET_VOLT at VMAX boundary accepted");

    xact(SET, 8'h50, 1'b1);
    chk(rsp_ok(ERR, 8'hC0), "parity error is rejected with ERR and not applied");
    xact(4'h7, 8'h50);
    chk(rsp_ok(ERR, 8'hC0), "unknown opcode is rejected with ERR");

    xact(EN, 8'h00);
    chk(rsp_ok(ACK, 8'hC0) && u_dut.enabled === 1'b1, "ENABLE is ACKed and enables the rail");
    xact(DIS, 8'h00);
    chk(rsp_ok(ACK, 8'hC0) && u_dut.enabled === 1'b0, "DISABLE is ACKed and disables the rail");

    // no response requested: command applies silently
    fork
      send(SET, 1'b0, 8'h44);
      begin repeat (15) @(posedge clk); recv(got, r, 25); end
    join
    chk(!got, "no response frame when resp_req=0");
    xact(GET, 8'h00);
    chk(rsp_ok(ACK, 8'h44), "silent SET_VOLT was applied");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
