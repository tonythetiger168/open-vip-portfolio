// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- AVSBus testbench top with a functional voltage regulator
//              slave DUT model

`ifndef AVSBUS_TB_SV
`define AVSBUS_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import avsbus_defs_pkg::*;
import avsbus_pkg::*;
import avsbus_test_pkg::*;

module top_tb;
  logic avs_clk = 0;
  always #5ns avs_clk = ~avs_clk;

  avsbus_if vif(avs_clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  avsbus_regulator_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual avsbus_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional AVSBus voltage regulator slave: receives 15-bit command frames
// on avs_mdata (while avs_ctrl=1), executes the opcode against its register
// file, and answers with a 15-bit status/voltage frame on avs_sdata when the
// frame requests a response. Illegal opcodes are rejected with ST_ERR.
module avsbus_regulator_model (avsbus_if vif);
  localparam bit [3:0] OP_SET_VOLT = 4'h1, OP_GET_VOLT = 4'h2,
                       OP_ENABLE = 4'h3, OP_DISABLE = 4'h4;
  localparam bit [3:0] ST_ACK = 4'hA, ST_ERR = 4'hF;
  localparam bit [7:0] VMIN = 8'h20, VMAX = 8'hC0;
  localparam int FRAME_BITS = 15;
  localparam int RESP_GAP   = 3;    // avs_clk cycles between frame and response

  bit [7:0] vout    = 8'h60;        // current output voltage id
  bit       enabled = 1'b0;

  initial vif.avs_sdata = 1'b0;

  task automatic send_response(bit [3:0] status);
    bit [14:0] r;
    r[14]    = 1'b1;
    r[13:10] = status;
    r[9]     = 1'b0;
    r[8:1]   = vout;
    r[0]     = ^{status, 1'b0, vout};
    repeat (RESP_GAP) @(negedge vif.avs_clk);
    for (int i = 14; i >= 0; i--) begin
      vif.avs_sdata = r[i];
      @(negedge vif.avs_clk);
    end
    vif.avs_sdata = 1'b0;
  endtask

  initial forever begin
    bit [14:0] msh;
    bit [3:0]  opcode;
    bit        resp_req;
    bit [7:0]  vid;
    bit        legal, volt_ok;

    wait (vif.rst_n === 1'b1);
    // collect a 15-bit master frame while ctrl is high
    do @(posedge vif.avs_clk); while (!vif.avs_ctrl);
    msh = {14'h0, vif.avs_mdata};
    for (int i = 1; i < FRAME_BITS; i++) begin
      @(posedge vif.avs_clk);
      msh = {msh[13:0], vif.avs_mdata};
    end

    opcode   = msh[13:10];
    resp_req = msh[9];
    vid      = msh[8:1];
    legal    = (msh[14] === 1'b1) && (^msh[13:1] == msh[0]) &&
               (opcode inside {OP_SET_VOLT, OP_GET_VOLT, OP_ENABLE, OP_DISABLE});
    volt_ok  = (vid >= VMIN) && (vid <= VMAX);

    // execute
    if (legal) begin
      case (opcode)
        OP_SET_VOLT: if (volt_ok) vout = vid;
        OP_ENABLE:   enabled = 1'b1;
        OP_DISABLE:  enabled = 1'b0;
        default: ;
      endcase
    end

    // respond when requested
    if (resp_req) begin
      if (!legal || (opcode == OP_SET_VOLT && !volt_ok)) send_response(ST_ERR);
      else                                               send_response(ST_ACK);
    end
  end
endmodule
`endif
