# AVSBus — AVSBus (Adaptive Voltage Scaling) UVM VIP

Open-source UVM verification IP template for **AVSBus (Adaptive Voltage Scaling)** (Power).

## Contents

| Path | Description |
|------|-------------|
| `avsbus/avsbus_if.sv` | Protocol interface + FSM state enum |
| `avsbus/avsbus_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `avsbus/sva/avsbus_compliance_checker.sv` | SVA compliance checker (L1=4, L2=4, L3=4, L4=6) |
| `avsbus/vip/avsbus/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/avsbus_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional voltage regulator slave DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged master driver**: 15-bit command frame (start/opcode/resp_req/voltage_id/even parity, MSB-first) on avs_mdata with avs_ctrl frame strobe, fixed response window, idle-low lines
- **Protocol-decoding monitor**: master frame decode while avs_ctrl high, slave response decode with 16-cycle timeout detection (`resp_seen`)
- **End-to-end scoreboard with regulator shadow**: predicts ACK/ERR status per opcode legality, shadows vout, checks response voltage payload
- **Functional DUT model**: voltage regulator slave executing SET/GET/ENABLE/DISABLE against a vout register (0x60 reset), ERR on illegal opcodes, optional fire-and-forget (resp_req=0)
- **Directed sequence library**: set-voltage sweep / get-voltage / enable-disable / corner voltages / no-response / back-to-back / error-inject (illegal opcode) + regression mix
- **Functional coverage**: opcode x voltage-range and opcode x resp_req crosses, FSM frame sequence, status (ACK/ERR) and illegal-opcode error bins
- **SVA L4**: frame start bit, ctrl width exactly 15, response timeout, SET voltage range, status vs opcode legality, idle line state
