# Display_Controller UVM VIP (Display_Controller-UVM-VIP)

UVM verification IP for the open-ip-portfolio **Display_Controller** subsystem: Display controller: frame scan-out over AXI4 to a pixel stream with sync markers and a frame CRC.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`8e9722204875`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 4) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What Display_Controller does (from the spec)

- Reads LEN RGBA8888 pixels (one per word) at SRC and sends them on pix_valid / pix_data / pix_ready.
- pix_hsync is high with the last pixel of each line (LINE_WORDS pixels; LINE_WORDS 0: every pixel) and with the last pixel of the frame; pix_vsync with the last pixel of the frame.
- FRAME_CRC = CRC-32 (IEEE 802.3: reflected, polynomial 0xEDB88320, init 0xFFFFFFFF, final XOR 0xFFFFFFFF) of the pixels sent, bytes in little-endian order.
- UNDERRUNS counts clocks in which pix_ready was high, the frame was not finished and no pixel was available.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `display_controller/` -- `display_controller_ral.svh` register model (generated from the spec, same
  offsets as `Display_Controller_apb`), `display_controller_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `display_controller_pins_if.sv` (pix_valid, pix_data, pix_hsync, pix_vsync, pix_ready)
- `rtl/` -- `Display_Controller_apb.sv`, `Display_Controller_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/display_controller.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | SRC_ADDR | rw |
| 0x018 | LEN | rw |
| 0x01C | LINE | rw |
| 0x020 | CMD | cmd |
| 0x024 | STATUS | ro |
| 0x028 | FRAME_CRC | ro |
| 0x02C | UNDERRUNS | ro |
| 0x030 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR.

## Tests

| Test | Seeds |
|---|---|
| `display_controller_ral_test` | 1 |
| `display_controller_scan_test` | 3 |
| `display_controller_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT Display_Controller mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/display_controller.f
./obj_dir/Vtop_tb +UVM_TESTNAME=display_controller_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py Display_Controller-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
