// Display_Controller-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+display_controller
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/Display_Controller_top.sv
rtl/Display_Controller_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
display_controller/display_controller_pins_if.sv
common/ssv_pkg.sv
display_controller/display_controller_pkg.sv
tb/top_tb.sv
