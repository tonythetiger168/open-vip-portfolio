# Display_Controller-UVM-VIP test plan

## Register test (`display_controller_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `display_controller_scan_test`: 20 frames: LINE_WORDS 0, 1, 7, 640, 1920
  and 7680 (8K), frames of 1..3 lines plus a partial line; panel always
  ready, 70 % and 30 % ready; four AXI back-pressure settings. Every pixel in
  order, hsync / vsync on exactly the right pixels, FRAME_CRC, UNDERRUNS =
  the panel's own count, no AXI write at all, reads inside SRC only, AXI ID 4.
- `display_controller_err_test`: a frame read across a SLVERR and a DECERR region (those
  pixels arrive as 0 and enter the CRC as 0): DONE + ERR, STATUS.err; a clean
  frame clears it.
