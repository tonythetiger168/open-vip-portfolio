// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wtb_compliance_checker.sv -- WTB concurrent assertion checks (bindable)

module wtb_compliance_checker
  (input logic clk, input logic rst_n, input [31:0] wt_data, input wt_valid, input wt_afvalid, input wt_flush, input wt_ready, input wt_afready);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({wt_ready, wt_afready}))
    else $error("WTB: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> wt_ready == '0)
    else $error("WTB: output not in reset value");
  // afready only in response to afvalid
  assert property (@(posedge clk) disable iff (!rst_n) wt_afready |-> wt_afvalid || $past(wt_afvalid))
    else $error("WTB: afready without afvalid");
  cover property (@(posedge clk) disable iff (!rst_n) (wt_ready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (wt_valid == 1'b1));
endmodule
