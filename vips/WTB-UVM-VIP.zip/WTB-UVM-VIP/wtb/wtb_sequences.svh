// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wtb_sequences.svh -- WTB sequences

// Random traffic: cfg.num_items constrained-random items.
class wtb_base_sequence extends uvm_sequence #(wtb_transaction);
  `uvm_object_utils(wtb_base_sequence)
  wtb_config cfg;

  function new(string name = "wtb_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = wtb_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "wtb_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class wtb_directed_sequence extends uvm_sequence #(wtb_transaction);
  `uvm_object_utils(wtb_directed_sequence)
  wtb_config cfg;

  function new(string name = "wtb_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function wtb_transaction item();
    item = wtb_transaction::type_id::create("req");
  endfunction

  task send(wtb_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    wtb_transaction t;
    t = item(); t.data = 32'h0; send(t);
    t = item(); t.data = 32'hFFFF_FFFF; send(t);
    for (int i = 0; i < 8; i++) begin t = item(); t.data = 32'h1 << (i * 4); send(t); end
    t = item(); t.flush = 1; send(t);
    t = item(); t.data = 32'hCAFE_F00D; send(t);
    t = item(); t.flush = 1; send(t);
    t = item(); t.flush = 1; send(t);
  endtask
endclass
