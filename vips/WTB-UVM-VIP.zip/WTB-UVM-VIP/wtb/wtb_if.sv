// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wtb_if.sv -- WTB interface

interface wtb_if (input logic clk);
  logic rst_n;

  logic [31:0] wt_data;
  logic wt_valid;
  logic wt_afvalid;
  logic wt_flush;
  logic wt_ready;
  logic wt_afready;

  modport DUT (input clk, rst_n, wt_data, wt_valid, wt_afvalid, wt_flush, output wt_ready, wt_afready);
  modport DRV (input clk, rst_n, wt_ready, wt_afready, output wt_data, wt_valid, wt_afvalid, wt_flush);
  modport MON (input clk, rst_n, wt_data, wt_valid, wt_afvalid, wt_flush, wt_ready, wt_afready);

  clocking drv_cb @(posedge clk);
    input rst_n, wt_data, wt_valid, wt_afvalid, wt_flush, wt_ready, wt_afready;
    output wt_data, wt_valid, wt_afvalid, wt_flush;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, wt_data, wt_valid, wt_afvalid, wt_flush, wt_ready, wt_afready;
  endclocking
endinterface
