// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wtb_transaction.svh -- WTB transaction

class wtb_transaction extends uvm_sequence_item;
  `uvm_object_utils(wtb_transaction)

  rand bit [31:0] wt_data;
  rand bit wt_valid;
  rand bit wt_afvalid;
  rand bit wt_flush;
  bit wt_ready_o;
  bit wt_afready_o;
  bit [31:0] tag;

  function new(string name = "wtb_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    wtb_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    wt_data = rhs_.wt_data;
    wt_valid = rhs_.wt_valid;
    wt_afvalid = rhs_.wt_afvalid;
    wt_flush = rhs_.wt_flush;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    wtb_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           wt_data == rhs_.wt_data &&
           wt_valid == rhs_.wt_valid &&
           wt_afvalid == rhs_.wt_afvalid &&
           wt_flush == rhs_.wt_flush;
  endfunction

  function string convert2string();
    return $sformatf("WTB{tag=%0h wt_data=0x%0h wt_valid=0x%0h wt_afvalid=0x%0h wt_flush=0x%0h}", tag, wt_data, wt_valid, wt_afvalid, wt_flush);
  endfunction
endclass
