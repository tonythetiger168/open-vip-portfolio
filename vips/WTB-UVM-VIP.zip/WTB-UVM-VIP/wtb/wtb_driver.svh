// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wtb_driver.svh -- WTB driver: one trace beat (VALID/READY) or one flush handshake (AFVALID/AFREADY)

class wtb_driver extends uvm_driver #(wtb_transaction);
  `uvm_component_utils(wtb_driver)

  uvm_analysis_port #(wtb_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual wtb_if vif;
  wtb_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual wtb_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "wtb: virtual interface not set")
    if (!uvm_config_db#(wtb_config)::get(this, "", "cfg", cfg))
      cfg = wtb_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wtb_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.wt_valid <= 1'b0; vif.drv_cb.wt_data <= '0;
    vif.drv_cb.wt_afvalid <= 1'b0; vif.drv_cb.wt_flush <= 1'b0;
  endtask

  task drive_item(wtb_transaction t);
    @(vif.drv_cb);
    if (!t.flush) begin
      vif.drv_cb.wt_valid <= 1'b1;
      vif.drv_cb.wt_data  <= t.data;
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.wt_ready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.wt_ready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("WTB READY: no response within %0d cycles", cfg.timeout_cycles))
      end
      vif.drv_cb.wt_valid <= 1'b0;
    end else begin
      vif.drv_cb.wt_afvalid <= 1'b1;
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.wt_afready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.wt_afready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("WTB AFREADY: no response within %0d cycles", cfg.timeout_cycles))
      end
      vif.drv_cb.wt_afvalid <= 1'b0;
    end
  endtask

endclass
