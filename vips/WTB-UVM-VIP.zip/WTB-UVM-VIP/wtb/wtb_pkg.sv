// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wtb_pkg.sv -- WTB UVM VIP package

package wtb_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import wtb_defs_pkg::*;
  export wtb_defs_pkg::*;

  `include "wtb_transaction.svh"
  `include "wtb_config.svh"
  `include "wtb_sequencer.svh"
  `include "wtb_driver.svh"
  `include "wtb_monitor.svh"
  `include "wtb_agent.svh"
  `include "wtb_sequences.svh"
  `include "wtb_checker.svh"
  `include "wtb_coverage.svh"
endpackage
