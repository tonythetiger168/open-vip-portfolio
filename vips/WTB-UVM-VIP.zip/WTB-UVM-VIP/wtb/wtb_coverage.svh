// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wtb_coverage.svh -- WTB functional coverage

class wtb_coverage extends uvm_subscriber #(wtb_transaction);
  `uvm_component_utils(wtb_coverage)
  wtb_config cfg;
  wtb_transaction tr;

  covergroup wtb_cg;
    cp_kind : coverpoint tr.flush { bins beat = {0}; bins flush = {1}; }
    cp_data : coverpoint tr.data { bins zero = {0}; bins ones = {32'hFFFF_FFFF}; bins other = default; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    wtb_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(wtb_config)::get(this, "", "cfg", cfg))
      cfg = wtb_config::type_id::create("cfg");
  endfunction

  function void write(wtb_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    wtb_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("WTB coverage: %0.1f%%", wtb_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
