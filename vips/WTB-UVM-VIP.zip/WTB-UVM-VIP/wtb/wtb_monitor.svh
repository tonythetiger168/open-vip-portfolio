// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wtb_monitor.svh -- WTB monitor: decodes observed bus activity

class wtb_monitor extends uvm_monitor;
  `uvm_component_utils(wtb_monitor)

  virtual wtb_if vif;
  uvm_analysis_port #(wtb_transaction) ap;
  wtb_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual wtb_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "wtb: virtual interface not set")
    void'(uvm_config_db#(wtb_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    wtb_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = wtb_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.wt_data = vif.wt_data;
        t.wt_valid = vif.wt_valid;
        t.wt_afvalid = vif.wt_afvalid;
        t.wt_flush = vif.wt_flush;
        t.wt_ready_o = vif.wt_ready;
        t.wt_afready_o = vif.wt_afready;
        ap.write(t);
      end
    end
  endtask
endclass
