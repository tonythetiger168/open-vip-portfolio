// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (WTB flush/afready handshake)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened wtb_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [31:0] wt_data = '0;
  logic wt_valid = 1'b0;
  logic wt_afvalid = 1'b0;
  logic wt_flush = 1'b0;
  wire  wt_ready;
  wire  wt_afready;

  always #5 clk = ~clk;

  wtb_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .wt_data(wt_data), .wt_valid(wt_valid),
    .wt_afvalid(wt_afvalid), .wt_flush(wt_flush),
    .wt_ready(wt_ready), .wt_afready(wt_afready)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(wt_ready === 1'b0 && wt_afready === 1'b0, "handshakes reset low");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // no afvalid -> no afready
    repeat (4) begin step(); chk(wt_afready === 1'b0, "no afready without afvalid"); end

    // afvalid accepted: afready follows while not flushing
    @(negedge clk); wt_afvalid = 1;
    step(); step();
    chk(wt_afready === 1'b1, "afready after afvalid");
    @(negedge clk); wt_afvalid = 0;
    step();
    chk(wt_afready === 1'b0, "afready drops after afvalid");

    // valid beats are accepted on alternating cycles
    begin : beats
      int acc = 0;
      @(negedge clk); wt_valid = 1;
      repeat (10) begin
        step();
        if (wt_ready === 1'b1) acc++;
      end
      chk(acc >= 3, "trace beats accepted over time");
      @(negedge clk); wt_valid = 0;
    end

    // flush suppresses afready
    @(negedge clk); wt_afvalid = 1; wt_flush = 1;
    step(); step();
    chk(wt_afready === 1'b0, "flush suppresses afready");
    @(negedge clk); wt_flush = 0; wt_afvalid = 0;
    step();

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
