// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- WTB testbench top with a functional WTB DUT model

`ifndef WTB_TB_SV
`define WTB_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import wtb_defs_pkg::*;
import wtb_pkg::*;
import wtb_env_pkg::*;
import wtb_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  wtb_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  wtb_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .wt_data(vif.wt_data),
    .wt_valid(vif.wt_valid),
    .wt_afvalid(vif.wt_afvalid),
    .wt_flush(vif.wt_flush),
    .wt_ready(vif.wt_ready),
    .wt_afready(vif.wt_afready)
  );

  // Concurrent protocol checks
  wtb_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .wt_data(vif.wt_data), .wt_valid(vif.wt_valid), .wt_afvalid(vif.wt_afvalid), .wt_flush(vif.wt_flush), .wt_ready(vif.wt_ready), .wt_afready(vif.wt_afready)
  );

  initial begin
    uvm_config_db#(virtual wtb_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module wtb_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [31:0] wt_data,
  input  logic        wt_valid,
  input  logic        wt_afvalid,
  input  logic        wt_flush,
  output logic        wt_ready,
  output logic        wt_afready
);
  logic flush_d;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wt_ready   <= 1'b0;
      wt_afready <= 1'b0;
      flush_d    <= 1'b0;
    end else begin
      // sink alternates accept cycles
      wt_ready   <= wt_valid && !wt_ready;
      wt_afready <= wt_afvalid && !flush_d;
      flush_d    <= wt_flush;
    end
  end
endmodule
`endif
