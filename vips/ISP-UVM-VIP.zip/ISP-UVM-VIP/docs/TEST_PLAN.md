# ISP-UVM-VIP test plan

## Register test (`isp_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `isp_tpg_test`: 24 test-pattern frames: SEED 0, 0xFF and random; BLACK 0,
  255 and random; GAIN 16 (1.0), 0, 1, 255 and random (clipping to 255);
  LINE_WORDS 0, 1, 7, 160 (640 px), 480 (1080p line) and 1920 (8K line),
  lengths that end mid-line; four back-pressure settings. Every output word,
  STAT_SUM, STATUS, DONE / ERR, no AXI read at all, writes inside DST only,
  AXI ID 3.
- `isp_sensor_test`: 16 frames from the sensor stream with the sensor
  sending continuously, in bursts, and with long gaps: the ISP takes exactly
  LEN words (the rest stay queued for the next job), output = the model of
  the words taken in order, STAT_SUM, sns_ready never high outside a job.
- `isp_err_test`: a frame written across a SLVERR and a DECERR region (those
  words untouched): DONE + ERR, STATUS.err; a clean frame clears it.
