# ISP UVM VIP (ISP-UVM-VIP)

UVM verification IP for the open-ip-portfolio **ISP** subsystem: Camera ISP: black level and digital gain on raw frames from a test pattern or sensor stream, written over AXI4.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`8e9722204875`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 3) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What ISP does (from the spec)

- Four 8-bit pixels per word, byte 0 first; the job writes LEN words at DST.
- out = min(255, (max(0, p - BLACK) * GAIN) >> 4); GAIN is unsigned Q4.4 (16 = 1.0).
- SRC_SEL 0: test pattern, pixel b of word x of line y = ((4x + b + y) mod 256) ^ SEED, LINE_WORDS words per line (x restarts at 0 when x + 1 >= LINE_WORDS).
- SRC_SEL 1: the sensor stream sns_valid / sns_data / sns_ready, one word per beat (sns_ready is high only while a job can take a word).
- STAT_SUM is the sum of all output pixels of the last frame.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `isp/` -- `isp_ral.svh` register model (generated from the spec, same
  offsets as `ISP_apb`), `isp_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `isp_pins_if.sv` (sns_valid, sns_data, sns_ready)
- `rtl/` -- `ISP_apb.sv`, `ISP_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/isp.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | DST_ADDR | rw |
| 0x018 | LEN | rw |
| 0x01C | CTRL | rw |
| 0x020 | LINE | rw |
| 0x024 | CMD | cmd |
| 0x028 | STATUS | ro |
| 0x02C | STAT_SUM | ro |
| 0x030 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR.

## Tests

| Test | Seeds |
|---|---|
| `isp_ral_test` | 1 |
| `isp_tpg_test` | 3 |
| `isp_sensor_test` | 3 |
| `isp_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT ISP mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/isp.f
./obj_dir/Vtop_tb +UVM_TESTNAME=isp_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py ISP-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
