// ISP-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+isp
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/ISP_top.sv
rtl/ISP_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
isp/isp_pins_if.sv
common/ssv_pkg.sv
isp/isp_pkg.sv
tb/top_tb.sv
