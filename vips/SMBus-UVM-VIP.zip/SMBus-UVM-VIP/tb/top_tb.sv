// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SMBus/PMBus testbench top with a functional SMBus/PMBus DUT model

`ifndef SMBUS_UVM_VIP_TB_SV
`define SMBUS_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import smbus_defs_pkg::*;
import smbus_pkg::*;
import smbus_env_pkg::*;
import smbus_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  smbus_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  smbus_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .scl(vif.scl),
    .sda(vif.sda),
    .scl_o(vif.scl_o),
    .sda_o(vif.sda_o)
  );

  // Concurrent protocol checks
  smbus_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .scl(vif.scl),
    .sda(vif.sda),
    .scl_o(vif.scl_o),
    .sda_o(vif.sda_o)
  );

  initial begin
    uvm_config_db#(virtual smbus_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module smbus_model (
  input  logic clk,
  input  logic rst_n,
  input  logic scl,
  input  logic sda,
  output logic scl_o,
  output logic sda_o
);
  localparam logic [6:0] ADDR = 7'h5A;

  logic       scl_p, sda_p, active, rep, drop, tx, mack, pec_ok, pre;
  logic [3:0] bitn;
  logic [7:0] sh, crc, cmd, txb, cml, operation;
  logic [15:0] vout;
  logic [7:0] wb [0:3];
  logic [7:0] rv0, rv1;
  logic [3:0] nb, nw, ntx;
  logic [2:0] stretch;

  function automatic logic [7:0] f_crc8(input logic [7:0] c, input logic [7:0] b);
    logic [7:0] x;
    x = c ^ b;
    for (int k = 0; k < 8; k++) x = x[7] ? ((x << 1) ^ 8'h07) : (x << 1);
    return x;
  endfunction

  // PMBus command table: bytes written / read (4'hF = not allowed)
  function automatic logic [3:0] f_wlen(input logic [7:0] c);
    case (c) 8'h01: f_wlen = 4'd1; 8'h03: f_wlen = 4'd0; 8'h21: f_wlen = 4'd2; default: f_wlen = 4'hF; endcase
  endfunction
  function automatic logic [3:0] f_rlen(input logic [7:0] c);
    case (c)
      8'h01, 8'h78, 8'h7E, 8'h98: f_rlen = 4'd1;
      8'h21, 8'h8B: f_rlen = 4'd2;
      default: f_rlen = 4'hF;
    endcase
  endfunction

  wire start = scl && scl_p && sda_p && !sda;
  wire stop  = scl && scl_p && !sda_p && sda;
  wire rise  = scl && !scl_p;
  wire fall  = !scl && scl_p;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      scl_p <= 1'b1; sda_p <= 1'b1; scl_o <= 1'b1; sda_o <= 1'b1;
      active <= 1'b0; rep <= 1'b0; drop <= 1'b0; tx <= 1'b0; mack <= 1'b0; pec_ok <= 1'b0; pre <= 1'b0;
      bitn <= '0; sh <= '0; crc <= '0; cmd <= '0; txb <= '0; nb <= '0; nw <= '0; ntx <= '0;
      cml <= 8'h00; operation <= 8'h80; vout <= 16'h0; stretch <= '0; rv0 <= '0; rv1 <= '0;
      for (int i = 0; i < 4; i++) wb[i] <= '0;
    end else begin
      scl_p <= scl; sda_p <= sda;
      if (stretch != 0) begin
        stretch <= stretch - 3'd1;
        if (stretch == 3'd1) scl_o <= 1'b1;
      end
      if (start) begin
        if (!active) begin
          rep <= 1'b0; drop <= 1'b0; nb <= '0; nw <= '0; crc <= '0; pec_ok <= 1'b0;
        end else
          rep <= 1'b1;
        active <= 1'b1; tx <= 1'b0; bitn <= '0; sda_o <= 1'b1;
        pre <= 1'b1;                                   // the SCL fall of the START itself
      end else if (stop) begin
        // a complete, error-free write takes effect at STOP
        if (active && !rep && !drop && nb >= 4'd2 && f_wlen(cmd) != 4'hF && nw >= f_wlen(cmd)) begin
          case (cmd)
            8'h01: operation <= wb[0];
            8'h03: cml <= 8'h00;
            8'h21: vout <= {wb[1], wb[0]};
            default: ;
          endcase
        end
        active <= 1'b0; tx <= 1'b0; sda_o <= 1'b1;
      end else if (active && rise) begin
        if (bitn < 4'd8) begin
          if (!tx) sh <= {sh[6:0], sda};
        end else if (tx)
          mack <= !sda;
      end else if (active && fall && pre) begin
        pre <= 1'b0;
      end else if (active && fall) begin
        if (bitn == 4'd7) begin
          bitn <= 4'd8;
          if (tx) sda_o <= 1'b1;                       // release for the host's ACK
          else begin : rx_byte
            logic ack;
            ack = 1'b0;
            if (drop) ack = 1'b0;
            else if (nb == 4'd0) begin                 // address, write
              ack = (sh[7:1] == ADDR) && !sh[0];
              crc <= f_crc8(8'h00, sh);
              if (!ack) drop <= 1'b1;
            end else if (!rep && nb == 4'd1) begin     // command
              ack = (f_wlen(sh) != 4'hF) || (f_rlen(sh) != 4'hF);
              cmd <= sh;
              crc <= f_crc8(crc, sh);
              if (!ack) begin cml[7] <= 1'b1; drop <= 1'b1; end
            end else if (!rep) begin                   // data / PEC
              if (f_wlen(cmd) == 4'hF || nw > f_wlen(cmd)) begin
                cml[6] <= 1'b1; drop <= 1'b1;
              end else if (nw < f_wlen(cmd)) begin
                ack = 1'b1; wb[nw[1:0]] <= sh; crc <= f_crc8(crc, sh);
              end else if (sh == crc) begin
                ack = 1'b1; pec_ok <= 1'b1;
              end else begin
                cml[5] <= 1'b1; drop <= 1'b1;
              end
              nw <= nw + 4'd1;
            end else begin                             // address after repeated START
              ack = (sh[7:1] == ADDR) && sh[0] && nb == 4'd2 && f_rlen(cmd) != 4'hF;
              if (sh[7:1] == ADDR && sh[0] && nb == 4'd2 && f_rlen(cmd) == 4'hF) cml[7] <= 1'b1;
              if (ack) begin
                crc <= f_crc8(crc, sh);
                case (cmd)
                  8'h01: begin rv0 <= operation; rv1 <= 8'h00; end
                  8'h21, 8'h8B: begin rv0 <= vout[7:0]; rv1 <= vout[15:8]; end
                  8'h78: begin rv0 <= {6'h0, cml != 8'h00, 1'b0}; rv1 <= 8'h00; end
                  8'h7E: begin rv0 <= cml; rv1 <= 8'h00; end
                  default: begin rv0 <= 8'h33; rv1 <= 8'h00; end
                endcase
              end else
                drop <= 1'b1;
            end
            nb <= nb + 4'd1;
            sda_o <= !ack;
          end
        end else if (bitn == 4'd8) begin              // end of the ACK bit
          bitn <= '0;
          if (!tx) begin
            sda_o <= 1'b1;
            if (sda_o == 1'b0 && (nb == 4'd1 || (rep && nb == 4'd3))) begin
              // stretch SCL after an address ACK
              scl_o <= 1'b0; stretch <= 3'd6;
            end
            if (rep && nb == 4'd3 && !drop) begin       // start sending read data
              tx <= 1'b1; ntx <= 4'd1;
              txb <= rv0; sda_o <= rv0[7];
              crc <= f_crc8(crc, rv0);
            end
          end else if (mack) begin                     // host wants another byte
            logic [7:0] nxt;
            nxt = (ntx == 4'd1 && f_rlen(cmd) == 4'd2) ? rv1
                : (ntx == f_rlen(cmd)) ? crc : 8'hFF;
            if (ntx < f_rlen(cmd)) crc <= f_crc8(crc, nxt);
            ntx <= ntx + 4'd1;
            txb <= nxt; sda_o <= nxt[7];
          end else begin
            tx <= 1'b0; drop <= 1'b1; sda_o <= 1'b1;   // host NACK: done until STOP
          end
        end else begin
          bitn <= bitn + 4'd1;
          if (tx) sda_o <= txb[3'd6 - bitn[2:0]];
        end
      end
    end
  end
endmodule
`endif
