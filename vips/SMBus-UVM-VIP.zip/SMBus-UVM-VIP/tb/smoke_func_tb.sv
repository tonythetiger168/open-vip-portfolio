// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SMBus/PMBus DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened smbus_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic scl_m = 1, sda_m = 1;
  wire  scl_o, sda_o;
  wire  scl = scl_m & scl_o;
  wire  sda = sda_m & sda_o;

  always #5 clk = ~clk;

  smbus_model u_dut (.clk(clk), .rst_n(rst_n), .scl(scl), .sda(sda), .scl_o(scl_o), .sda_o(sda_o));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [7:0] crc8(input logic [7:0] c, input logic [7:0] b);
    c = c ^ b;
    for (int k = 0; k < 8; k++) c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
    return c;
  endfunction

  task automatic clks(input int n); repeat (n) @(posedge clk); #1; endtask
  task automatic scl_up; scl_m = 1; clks(1); while (!scl) clks(1); endtask
  task automatic start_c; sda_m = 1; clks(2); scl_up(); clks(4); sda_m = 0; clks(4); scl_m = 0; clks(2); endtask
  task automatic stop_c; sda_m = 0; clks(2); scl_up(); clks(4); sda_m = 1; clks(8); endtask
  task automatic bitx(input logic o, output logic i);
    sda_m = o; clks(2); scl_up(); clks(2); i = sda; clks(2); scl_m = 0; clks(2);
  endtask
  task automatic wbyte(input logic [7:0] b, output logic ack);
    logic i;
    for (int k = 7; k >= 0; k--) bitx(b[k], i);
    bitx(1'b1, i); ack = !i;
  endtask
  task automatic rbyte(input logic ack, output logic [7:0] b);
    logic i;
    for (int k = 7; k >= 0; k--) begin bitx(1'b1, i); b[k] = i; end
    bitx(!ack, i);
    if (!ack) chk(i === 1'b1, "device releases SDA for the master NACK");
  endtask

  // clock stretches by the device (falling edges of scl_o)
  int nstr = 0;
  logic scl_o_p = 1'b1;
  always @(posedge clk) begin scl_o_p <= scl_o; if (scl_o_p && !scl_o) nstr++; end

  // read one byte of command c, with PEC
  task automatic rd1(input logic [7:0] c, output logic [7:0] d, output logic pec_ok);
    logic a; logic [7:0] p, x;
    start_c(); wbyte(8'hB4, a); wbyte(c, a);
    start_c(); wbyte(8'hB5, a);
    rbyte(1, d); rbyte(0, p); stop_c();
    x = crc8(crc8(crc8(crc8(0, 8'hB4), c), 8'hB5), d);
    pec_ok = (p == x);
  endtask

  initial begin
    logic a, ok; logic [7:0] d, d1;
    clks(3);
    chk(scl_o === 1'b1 && sda_o === 1'b1, "bus released in reset");
    rst_n = 1; clks(4);

    // PMBUS_REVISION and OPERATION default, PEC checked
    rd1(8'h98, d, ok); chk(d === 8'h33 && ok, "PMBUS_REVISION = 0x33 with a good PEC");
    rd1(8'h01, d, ok); chk(d === 8'h80 && ok, "OPERATION resets to 0x80");

    // write VOUT_COMMAND with PEC, read it back through READ_VOUT
    start_c(); wbyte(8'hB4, a); chk(a, "address ACK");
    wbyte(8'h21, a); chk(a, "VOUT_COMMAND ACK");
    wbyte(8'hE4, a); wbyte(8'h0C, a);
    wbyte(crc8(crc8(crc8(crc8(0, 8'hB4), 8'h21), 8'hE4), 8'h0C), a); chk(a, "good PEC ACKed");
    stop_c();
    start_c(); wbyte(8'hB4, a); wbyte(8'h8B, a); start_c(); wbyte(8'hB5, a);
    rbyte(1, d); rbyte(0, d1); stop_c();
    chk({d1, d} === 16'h0CE4, "READ_VOUT returns the commanded value");

    // bad PEC: NACK, write discarded, STATUS_CML[5]
    start_c(); wbyte(8'hB4, a); wbyte(8'h21, a); wbyte(8'h00, a); wbyte(8'h00, a);
    wbyte(8'h5A, a); chk(!a, "bad PEC NACKed"); stop_c();
    rd1(8'h7E, d, ok); chk(d === 8'h20, "STATUS_CML[5] PEC failed");
    rd1(8'h78, d, ok); chk(d === 8'h02, "STATUS_BYTE CML bit");
    start_c(); wbyte(8'hB4, a); wbyte(8'h21, a); start_c(); wbyte(8'hB5, a);
    rbyte(1, d); rbyte(0, d1); stop_c();
    chk({d1, d} === 16'h0CE4, "discarded write left VOUT_COMMAND unchanged");

    // unsupported command, wrong address, CLEAR_FAULTS
    start_c(); wbyte(8'hB4, a); wbyte(8'h55, a); chk(!a, "unsupported command NACKed"); stop_c();
    rd1(8'h7E, d, ok); chk(d === 8'hA0, "STATUS_CML[7] invalid command");
    start_c(); wbyte(8'h20, a); chk(!a, "other address NACKed"); stop_c();
    start_c(); wbyte(8'hB4, a); wbyte(8'h03, a); stop_c();
    rd1(8'h7E, d, ok); chk(d === 8'h00, "CLEAR_FAULTS clears STATUS_CML");

    // clock stretching only after an ACKed address: once per write, twice per read
    begin : stretch
      int n0;
      n0 = nstr;
      start_c(); wbyte(8'hB4, a); wbyte(8'h01, a); wbyte(8'h80, a); stop_c();
      chk(nstr - n0 == 1, "one stretch in a write (after the address)");
      n0 = nstr;
      rd1(8'h98, d, ok);
      chk(nstr - n0 == 2, "two stretches in a read (after each address)");
      n0 = nstr;
      start_c(); wbyte(8'h20, a); stop_c();
      chk(nstr - n0 == 0, "no stretch after a NACKed address");
    end
    // too many data bytes: NACK and STATUS_CML[6]
    start_c(); wbyte(8'hB4, a); wbyte(8'h01, a); wbyte(8'h40, a);
    wbyte(crc8(crc8(crc8(0, 8'hB4), 8'h01), 8'h40), a); chk(a, "PEC after one data byte ACKed");
    wbyte(8'h12, a); chk(!a, "extra byte after the PEC NACKed"); stop_c();
    rd1(8'h7E, d, ok); chk(d === 8'h40, "STATUS_CML[6] invalid data");
    rd1(8'h01, d, ok); chk(d === 8'h80, "write with extra bytes discarded");
    start_c(); wbyte(8'hB4, a); wbyte(8'h03, a); stop_c();
    // read of a write-only command and read with another address: NACK
    start_c(); wbyte(8'hB4, a); wbyte(8'h03, a); start_c(); wbyte(8'hB5, a); stop_c();
    chk(!a, "read of a send-byte command NACKed");
    rd1(8'h7E, d, ok); chk(d === 8'h80, "STATUS_CML[7] for the read of a write-only command");
    start_c(); wbyte(8'hB4, a); wbyte(8'h03, a); stop_c();
    start_c(); wbyte(8'hB4, a); wbyte(8'h98, a); start_c(); wbyte(8'h21, a); stop_c();
    chk(!a, "repeated start to another address NACKed");
    start_c(); wbyte(8'hB4, a); wbyte(8'h98, a); start_c(); wbyte(8'hB4, a); stop_c();
    chk(!a, "repeated start with the write bit NACKed");
    rd1(8'h7E, d, ok); chk(d === 8'h00, "no fault from a foreign or write repeated start");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
