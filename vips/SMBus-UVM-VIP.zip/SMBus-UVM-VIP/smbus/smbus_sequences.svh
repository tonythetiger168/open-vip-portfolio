// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_sequences.svh -- SMBus/PMBus sequences

// Random traffic: cfg.num_items constrained-random items.
class smbus_base_sequence extends uvm_sequence #(smbus_transaction);
  `uvm_object_utils(smbus_base_sequence)
  smbus_config cfg;

  function new(string name = "smbus_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = smbus_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "smbus_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class smbus_directed_sequence extends uvm_sequence #(smbus_transaction);
  `uvm_object_utils(smbus_directed_sequence)
  smbus_config cfg;

  function new(string name = "smbus_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function smbus_transaction item();
    item = smbus_transaction::type_id::create("req");
  endfunction

  task send(smbus_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    smbus_transaction t;
    // revision, defaults, then VOUT write / read back with and without PEC
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h98; send(t);
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h01; t.use_pec = 1; send(t);
    t = item(); t.kind = WRITE_WORD; t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h21; t.wdata = 16'h0CE4; send(t);
    t = item(); t.kind = READ_WORD;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h8B; t.use_pec = 1; send(t);
    t = item(); t.kind = WRITE_WORD; t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h21; t.wdata = 16'h1A2B; t.use_pec = 1; send(t);
    t = item(); t.kind = READ_WORD;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h21; send(t);
    // bad PEC: write discarded, CML[5] set, visible in STATUS_BYTE and STATUS_CML
    t = item(); t.kind = WRITE_WORD; t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h21; t.wdata = 16'hFFFF; t.use_pec = 1; t.bad_pec = 1; send(t);
    t = item(); t.kind = READ_WORD;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h8B; send(t);
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h78; send(t);
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h7E; t.use_pec = 1; send(t);
    // unsupported command (CML[7]), data to a read-only command (CML[6])
    t = item(); t.kind = WRITE_BYTE; t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h55; t.wdata = 16'h12; send(t);
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'hD0; send(t);
    t = item(); t.kind = WRITE_BYTE; t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h78; t.wdata = 16'h01; send(t);
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h7E; send(t);
    // CLEAR_FAULTS with a bad PEC is ignored, with a good PEC clears STATUS_CML
    t = item(); t.kind = SEND_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h03; t.use_pec = 1; t.bad_pec = 1; send(t);
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h7E; send(t);
    t = item(); t.kind = SEND_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h03; t.use_pec = 1; send(t);
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h78; t.use_pec = 1; send(t);
    // another address: nothing ACKed, reads float high
    t = item(); t.kind = WRITE_BYTE; t.addr = 7'h10; t.cmd = 8'h01; t.wdata = 16'h00; send(t);
    t = item(); t.kind = READ_WORD;  t.addr = 7'h10; t.cmd = 8'h21; send(t);
    t = item(); t.kind = WRITE_BYTE; t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h01; t.wdata = 16'h40; t.use_pec = 1; send(t);
    t = item(); t.kind = READ_BYTE;  t.addr = SMBUS_DEV_ADDR; t.cmd = 8'h01; send(t);
  endtask
endclass
