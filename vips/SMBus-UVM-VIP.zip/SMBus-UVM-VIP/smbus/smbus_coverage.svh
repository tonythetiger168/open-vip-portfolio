// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_coverage.svh -- SMBus/PMBus functional coverage

class smbus_coverage extends uvm_subscriber #(smbus_transaction);
  `uvm_component_utils(smbus_coverage)
  smbus_config cfg;
  smbus_transaction tr;

  covergroup smbus_cg;
    cp_kind : coverpoint tr.kind;
    cp_cmd  : coverpoint tr.cmd { bins op = {8'h01}; bins clr = {8'h03}; bins vcmd = {8'h21};
                                  bins sb = {8'h78}; bins cml = {8'h7E}; bins rv = {8'h8B};
                                  bins rev = {8'h98}; bins bad = {8'h55, 8'hD0}; }
    cp_pec  : coverpoint {tr.use_pec, tr.bad_pec} { bins none = {2'b00}; bins good = {2'b10}; bins bad = {2'b11}; }
    cp_addr : coverpoint tr.acks[0] { bins nack = {0}; bins ack = {1}; }
    x_kind_pec : cross cp_kind, cp_pec { ignore_bins rd_bad = binsof(cp_kind) intersect {READ_BYTE, READ_WORD} && binsof(cp_pec.bad); }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    smbus_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(smbus_config)::get(this, "", "cfg", cfg))
      cfg = smbus_config::type_id::create("cfg");
  endfunction

  function void write(smbus_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    smbus_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SMBus/PMBus coverage: %0.1f%%", smbus_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
