// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_defs.sv -- SMBus/PMBus shared type definitions

package smbus_defs_pkg;

  typedef enum bit [1:0] {SMBUS_OK, SMBUS_ERR} smbus_status_e;

  typedef enum bit [2:0] {SEND_BYTE, WRITE_BYTE, WRITE_WORD, READ_BYTE, READ_WORD} smbus_kind_e;
  localparam bit [6:0] SMBUS_DEV_ADDR = 7'h5A;

  // SMBus PEC: CRC-8, polynomial x^8 + x^2 + x + 1, initial value 0, MSB first
  function automatic bit [7:0] crc8(bit [7:0] c, bit [7:0] b);
    c ^= b;
    for (int k = 0; k < 8; k++) c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
    return c;
  endfunction

  // PMBus command table of the device: bytes written / read, -1 = not allowed
  function automatic int wlen(bit [7:0] cmd);
    case (cmd)
      8'h01: return 1;
      8'h03: return 0;
      8'h21: return 2;
      default: return -1;
    endcase
  endfunction

  function automatic int rlen(bit [7:0] cmd);
    case (cmd)
      8'h01, 8'h78, 8'h7E, 8'h98: return 1;
      8'h21, 8'h8B: return 2;
      default: return -1;
    endcase
  endfunction

  function automatic bit valid_cmd(bit [7:0] cmd);
    return wlen(cmd) >= 0 || rlen(cmd) >= 0;
  endfunction

endpackage
