// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_monitor.svh -- SMBus/PMBus monitor: START / repeated START / STOP and bytes with their ACK bit from the SCL/SDA wires; decoded with the PMBus command table

class smbus_monitor extends uvm_monitor;
  `uvm_component_utils(smbus_monitor)

  virtual smbus_if vif;
  uvm_analysis_port #(smbus_transaction) ap;
  smbus_config cfg;
  int unsigned n_obs = 0;

  bit [7:0] seg0[$], seg1[$]; bit ack0[$], ack1[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual smbus_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "smbus: virtual interface not set")
    if (!uvm_config_db#(smbus_config)::get(this, "", "cfg", cfg))
      cfg = smbus_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit scl_p = 1, sda_p = 1, in_xfer = 0, rep = 0;
      int unsigned nbit = 0, held = 0;
      bit [7:0] sh = 0;
      forever begin
        bit scl, sda;
        @(vif.mon_cb);
        scl = vif.mon_cb.scl; sda = vif.mon_cb.sda;
        if (!scl && !vif.mon_cb.scl_o) held++;
        if (scl && scl_p && sda_p && !sda) begin            // START or repeated START
          if (!in_xfer) begin seg0.delete(); seg1.delete(); ack0.delete(); ack1.delete(); held = 0; rep = 0; end
          else rep = 1;
          in_xfer = 1; nbit = 0;
        end else if (scl && scl_p && !sda_p && sda) begin   // STOP
          if (in_xfer) decode(held);
          in_xfer = 0;
        end else if (in_xfer && scl && !scl_p) begin        // SCL rising: sample
          if (nbit < 8) sh = {sh[6:0], sda};
          else if (rep) begin seg1.push_back(sh); ack1.push_back(!sda); end
          else begin seg0.push_back(sh); ack0.push_back(!sda); end
          nbit = (nbit == 8) ? 0 : nbit + 1;
        end
        scl_p = scl; sda_p = sda;
      end
    end
  endtask

  function void publish(smbus_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // rebuild the transfer from the two segments (before / after repeated START)
  function void decode(int unsigned held);
    smbus_transaction t = smbus_transaction::type_id::create("t");
    int nb = 0, d, L;
    bit [7:0] crc = 0;
    if (seg0.size() < 2) begin
      `uvm_error("MON", $sformatf("SMBus: transfer with %0d bytes before STOP / repeated START", seg0.size()))
      return;
    end
    t.addr = seg0[0][7:1];
    t.cmd  = seg0[1];
    t.stretch = held;
    foreach (seg0[i]) t.acks[nb++] = ack0[i];
    d = seg0.size() - 2;
    if (seg1.size() == 0) begin                       // write: A C data [PEC]
      L = wlen(t.cmd);
      t.use_pec = (L >= 0 && d == L + 1);
      if (L < 0 || !t.use_pec) L = d;
      t.kind = (L == 0) ? SEND_BYTE : (L == 1) ? WRITE_BYTE : WRITE_WORD;
      for (int i = 0; i < L && i < 2; i++) t.wdata[8*i +: 8] = seg0[2 + i];
      if (t.use_pec) begin
        for (int i = 0; i < 2 + L; i++) crc = crc8(crc, seg0[i]);
        t.bad_pec = (seg0[2 + L] != crc);
      end
    end else begin                                    // read: A C Sr A data [PEC]
      int r = seg1.size() - 1;
      t.acks[nb++] = ack1[0];
      L = rlen(t.cmd);
      t.use_pec = (L >= 0 && r == L + 1);
      if (L < 0 || !t.use_pec) L = r;
      t.kind = (L == 1) ? READ_BYTE : READ_WORD;
      for (int i = 0; i < L && i < 2; i++) t.rdata[8*i +: 8] = seg1[1 + i];
      if (t.use_pec) t.rpec = seg1[1 + L];
      // the host ACKs every byte but the last
      for (int i = 1; i < seg1.size(); i++)
        if (ack1[i] != (i != seg1.size() - 1))
          `uvm_error("MON", $sformatf("SMBus: host ACK/NACK wrong on read byte %0d", i - 1))
    end
    publish(t);
  endfunction
endclass
