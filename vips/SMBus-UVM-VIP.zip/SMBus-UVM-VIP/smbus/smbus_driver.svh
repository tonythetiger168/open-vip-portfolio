// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_driver.svh -- SMBus/PMBus driver: bit-level open-drain host: START, bytes MSB first with ACK, repeated START, STOP; honours clock stretching

class smbus_driver extends uvm_driver #(smbus_transaction);
  `uvm_component_utils(smbus_driver)

  uvm_analysis_port #(smbus_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual smbus_if vif;
  smbus_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual smbus_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "smbus: virtual interface not set")
    if (!uvm_config_db#(smbus_config)::get(this, "", "cfg", cfg))
      cfg = smbus_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    smbus_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.scl_m <= 1'b1;
    vif.drv_cb.sda_m <= 1'b1;
  endtask

  task drive_item(smbus_transaction t);
    bit [7:0] crc = 0, b, wb[$];
    bit ack;
    int unsigned nb = 0, nr;
    t.acks = 0; t.rdata = 0; t.rpec = 0; t.stretch = 0;
    // host-written bytes of the first segment
    wb.push_back({t.addr, 1'b0});
    wb.push_back(t.cmd);
    for (int i = 0; i < t.nwrite(); i++) wb.push_back(t.wdata[8*i +: 8]);
    if (t.use_pec && !t.is_read()) begin
      foreach (wb[i]) crc = crc8(crc, wb[i]);
      wb.push_back(crc ^ {7'h0, t.bad_pec});
    end
    @(vif.drv_cb);
    start_cond(t, 0);
    foreach (wb[i]) begin wr_byte(t, wb[i], ack); t.acks[nb++] = ack; end
    if (t.is_read()) begin
      start_cond(t, 1);
      wr_byte(t, {t.addr, 1'b1}, ack); t.acks[nb++] = ack;
      nr = t.nread() + (t.use_pec ? 1 : 0);
      for (int i = 0; i < nr; i++) begin
        rd_byte(t, i != nr - 1, b);
        if (i < t.nread()) t.rdata[8*i +: 8] = b; else t.rpec = b;
      end
    end
    stop_cond(t);
  endtask

  task wait_clk(int unsigned n); repeat (n) @(vif.drv_cb); endtask

  // release SCL and wait until the wire is high (the device may stretch)
  task scl_high(smbus_transaction t);
    int unsigned to = 0;
    vif.drv_cb.scl_m <= 1'b1;
    @(vif.drv_cb);
    while (vif.drv_cb.scl !== 1'b1 && to < cfg.timeout_cycles) begin @(vif.drv_cb); to++; t.stretch++; end
    if (vif.drv_cb.scl !== 1'b1) `uvm_error("TIMEOUT", "SMBus: SCL held low")
  endtask

  task start_cond(smbus_transaction t, bit repeated);
    if (repeated) begin
      vif.drv_cb.sda_m <= 1'b1; wait_clk(cfg.half / 2);
      scl_high(t); wait_clk(cfg.half);
    end
    vif.drv_cb.sda_m <= 1'b0; wait_clk(cfg.half);
    vif.drv_cb.scl_m <= 1'b0; wait_clk(cfg.half / 2);
  endtask

  task stop_cond(smbus_transaction t);
    vif.drv_cb.sda_m <= 1'b0; wait_clk(cfg.half / 2);
    scl_high(t); wait_clk(cfg.half);
    vif.drv_cb.sda_m <= 1'b1; wait_clk(2 * cfg.half);
  endtask

  // one bit: SDA set while SCL is low, sampled half way through SCL high
  task bit_xfer(smbus_transaction t, bit out, output bit in);
    vif.drv_cb.sda_m <= out; wait_clk(cfg.half / 2);
    scl_high(t); wait_clk(cfg.half / 2);
    in = vif.drv_cb.sda;
    wait_clk(cfg.half / 2);
    vif.drv_cb.scl_m <= 1'b0; wait_clk(cfg.half / 2);
  endtask

  task wr_byte(smbus_transaction t, bit [7:0] b, output bit ack);
    bit in;
    for (int i = 7; i >= 0; i--) bit_xfer(t, b[i], in);
    bit_xfer(t, 1'b1, in);
    ack = !in;
  endtask

  task rd_byte(smbus_transaction t, bit ack, output bit [7:0] b);
    bit in;
    for (int i = 7; i >= 0; i--) begin bit_xfer(t, 1'b1, in); b[i] = in; end
    bit_xfer(t, !ack, in);
  endtask
endclass
