// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_if.sv -- SMBus/PMBus interface

// Open-drain bus: each side pulls low (0) or releases (1); the wires are
// the wired AND of both sides.
interface smbus_if (input logic clk);
  logic rst_n;

  logic scl_m, sda_m;     // host (agent) side
  logic scl_o, sda_o;     // device (DUT) side
  wire  scl = scl_m & scl_o;
  wire  sda = sda_m & sda_o;

  modport DUT (input clk, rst_n, scl, sda, output scl_o, sda_o);
  modport MON (input clk, rst_n, scl, sda, scl_o, sda_o);

  clocking drv_cb @(posedge clk);
    input rst_n, scl, sda;
    inout scl_m, sda_m;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, scl, sda, scl_o, sda_o;
  endclocking
endinterface
