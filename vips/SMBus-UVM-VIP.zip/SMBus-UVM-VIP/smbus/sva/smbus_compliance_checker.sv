// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_compliance_checker.sv -- SMBus/PMBus concurrent assertion checks (bindable)

module smbus_compliance_checker
  (input logic clk, input logic rst_n, input logic scl, input logic sda, input logic scl_o, input logic sda_o);

  // device outputs never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({scl_o, sda_o}))
    else $error("SMBus: X on device outputs");
  // the device changes SDA only while SCL is low (a change while SCL is high
  // would be a START or STOP)
  assert property (@(posedge clk) disable iff (!rst_n) scl && $past(scl) |-> $stable(sda_o))
    else $error("SMBus: device changed SDA while SCL was high");
  // clock stretching is bounded
  assert property (@(posedge clk) disable iff (!rst_n) $fell(scl_o) |-> ##[1:8] scl_o)
    else $error("SMBus: device held SCL low too long");
  // the device never pulls SCL low while the host holds it high in the middle of a bit
  cover property (@(posedge clk) disable iff (!rst_n) !scl_o);
  cover property (@(posedge clk) disable iff (!rst_n) scl && $fell(sda));
  cover property (@(posedge clk) disable iff (!rst_n) scl && $rose(sda));
endmodule
