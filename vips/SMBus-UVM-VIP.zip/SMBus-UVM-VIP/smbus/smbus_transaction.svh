// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_transaction.svh -- SMBus/PMBus transaction

class smbus_transaction extends uvm_sequence_item;
  `uvm_object_utils(smbus_transaction)

  // request (driven by the agent)
  rand smbus_kind_e kind;
  rand bit [6:0] addr;
  rand bit [7:0] cmd;
  rand bit [15:0] wdata;
  rand bit use_pec;
  rand bit bad_pec;
  // response (returned by the DUT)
  bit [7:0] acks;
  bit [15:0] rdata;
  bit [7:0] rpec;
  // bookkeeping (not compared)
  int unsigned stretch;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_addr { addr dist { SMBUS_DEV_ADDR := 9, [7'h00 : 7'h7F] :/ 1 }; }
  constraint c_cmd  { cmd inside {8'h01, 8'h03, 8'h21, 8'h78, 8'h7E, 8'h8B, 8'h98, 8'h55, 8'hD0}; }
  constraint c_kind {
    (cmd == 8'h01) -> kind inside {WRITE_BYTE, READ_BYTE};
    (cmd == 8'h03) -> kind == SEND_BYTE;
    (cmd == 8'h21) -> kind inside {WRITE_WORD, READ_WORD};
    (cmd inside {8'h78, 8'h7E, 8'h98}) -> kind inside {READ_BYTE, WRITE_BYTE};
    (cmd == 8'h8B) -> kind inside {READ_WORD, WRITE_WORD};
    (cmd inside {8'h55, 8'hD0}) -> kind inside {WRITE_BYTE, READ_BYTE};
  }
  // PEC only where the monitor can tell it from data (the command allows the kind)
  constraint c_pec {
    (cmd inside {8'h55, 8'hD0}) -> !use_pec;
    (cmd inside {8'h78, 8'h7E, 8'h98, 8'h8B} && kind inside {WRITE_BYTE, WRITE_WORD}) -> !use_pec;
    bad_pec -> use_pec;
    (kind inside {READ_BYTE, READ_WORD}) -> !bad_pec;
    bad_pec dist { 0 := 4, 1 := 1 };
  }
  constraint c_wd {
    (kind == WRITE_BYTE) -> wdata[15:8] == 0;
    (kind inside {SEND_BYTE, READ_BYTE, READ_WORD}) -> wdata == 0;
  }

  function new(string name = "smbus_transaction"); super.new(name); endfunction

  function int unsigned nwrite();   // data bytes written
    case (kind) WRITE_BYTE: return 1; WRITE_WORD: return 2; default: return 0; endcase
  endfunction
  function int unsigned nread();    // data bytes read
    case (kind) READ_BYTE: return 1; READ_WORD: return 2; default: return 0; endcase
  endfunction
  function bit is_read(); return kind inside {READ_BYTE, READ_WORD}; endfunction

  function void do_copy(uvm_object rhs);
    smbus_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    kind = rhs_.kind;
    addr = rhs_.addr;
    cmd = rhs_.cmd;
    wdata = rhs_.wdata;
    use_pec = rhs_.use_pec;
    bad_pec = rhs_.bad_pec;
    acks = rhs_.acks;
    rdata = rhs_.rdata;
    rpec = rhs_.rpec;
    stretch = rhs_.stretch;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    smbus_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (kind != rhs_.kind) return 0;
    if (addr != rhs_.addr) return 0;
    if (cmd != rhs_.cmd) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (use_pec != rhs_.use_pec) return 0;
    if (bad_pec != rhs_.bad_pec) return 0;
    if (acks != rhs_.acks) return 0;
    if (rdata != rhs_.rdata) return 0;
    if (rpec != rhs_.rpec) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(smbus_transaction rhs_);
    if (kind != rhs_.kind) return 0;
    if (addr != rhs_.addr) return 0;
    if (cmd != rhs_.cmd) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (use_pec != rhs_.use_pec) return 0;
    if (bad_pec != rhs_.bad_pec) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("SMBus/PMBus{tag=%0d kind=0x%0h addr=0x%0h cmd=0x%0h wdata=0x%0h use_pec=0x%0h bad_pec=0x%0h acks=0x%0h rdata=0x%0h rpec=0x%0h}", tag, kind, addr, cmd, wdata, use_pec, bad_pec, acks, rdata, rpec);
  endfunction
endclass
