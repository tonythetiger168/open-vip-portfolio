// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_checker.svh -- SMBus/PMBus protocol checker on monitored items

class smbus_checker extends uvm_component;
  `uvm_component_utils(smbus_checker)
  uvm_analysis_imp #(smbus_transaction, smbus_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  smbus_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(smbus_config)::get(this, "", "cfg", cfg))
      cfg = smbus_config::type_id::create("cfg");
  endfunction

  function void fail(smbus_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("SMBus/PMBus: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(smbus_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      // every byte the device returns with PEC must carry a correct PEC
      if (t.is_read() && t.use_pec && t.acks[2]) begin
        bit [7:0] c = 0;
        c = crc8(c, {t.addr, 1'b0}); c = crc8(c, t.cmd); c = crc8(c, {t.addr, 1'b1});
        for (int i = 0; i < t.nread(); i++) c = crc8(c, t.rdata[8*i +: 8]);
        if (t.rpec != c) fail(t, $sformatf("read PEC 0x%02h, expected 0x%02h", t.rpec, c));
      end
      if (t.acks[0] && t.stretch == 0) fail(t, "device ACKed its address but never stretched SCL");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("SMBus/PMBus checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
