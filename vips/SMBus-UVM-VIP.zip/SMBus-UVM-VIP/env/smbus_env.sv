// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// smbus_env.sv -- SMBus/PMBus environment: reference-model scoreboard, checker, coverage

package smbus_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import smbus_defs_pkg::*;
  import smbus_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class smbus_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(smbus_scoreboard)
    uvm_analysis_imp_exp #(smbus_transaction, smbus_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(smbus_transaction, smbus_scoreboard) obs_ap;

    smbus_config cfg;
    smbus_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [7:0]  operation = 8'h80;
    bit [15:0] vout = 16'h0;
    bit [7:0]  cml = 8'h0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(smbus_config)::get(this, "", "cfg", cfg))
        cfg = smbus_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(smbus_transaction t);
      // independent model of the device: ACK of every host byte, data, PEC, faults
      bit drop = 0, ok;
      bit [7:0] crc = 0, val[2];
      int nb = 0, L;
      t.acks = 0; t.rdata = 0; t.rpec = 0;
      // address (write)
      ok = (t.addr == SMBUS_DEV_ADDR);
      t.acks[nb++] = ok; drop = !ok;
      crc = crc8(crc, {t.addr, 1'b0});
      // command
      if (!drop) begin
        ok = valid_cmd(t.cmd);
        if (!ok) begin cml[7] = 1; drop = 1; end
        t.acks[nb++] = ok;
      end else nb++;
      crc = crc8(crc, t.cmd);
      if (!t.is_read()) begin
        bit [7:0] wb[$];
        for (int i = 0; i < t.nwrite(); i++) wb.push_back(t.wdata[8*i +: 8]);
        if (t.use_pec) begin
          bit [7:0] c = crc;
          foreach (wb[i]) c = crc8(c, wb[i]);
          wb.push_back(c ^ {7'h0, t.bad_pec});
        end
        L = wlen(t.cmd);
        foreach (wb[i]) begin
          if (drop) ok = 0;
          else if (L < 0 || i > L) begin ok = 0; cml[6] = 1; drop = 1; end
          else if (i < L) begin ok = 1; crc = crc8(crc, wb[i]); end
          else begin                                      // i == L: PEC
            ok = (wb[i] == crc);
            if (!ok) begin cml[5] = 1; drop = 1; end
          end
          t.acks[nb++] = ok;
        end
        // STOP: a complete, error-free write takes effect
        if (!drop && L >= 0 && wb.size() >= L) begin
          case (t.cmd)
            8'h01: operation = t.wdata[7:0];
            8'h03: cml = 8'h0;
            8'h21: vout = t.wdata;
          endcase
        end
      end else begin
        bit ra;
        int nr = t.nread() + (t.use_pec ? 1 : 0);
        ra = !drop && t.addr == SMBUS_DEV_ADDR && rlen(t.cmd) >= 0;
        if (!drop && t.addr == SMBUS_DEV_ADDR && rlen(t.cmd) < 0) cml[7] = 1;
        t.acks[nb++] = ra;
        if (ra) begin
          crc = crc8(crc, {t.addr, 1'b1});
          case (t.cmd)
            8'h01: begin val[0] = operation; val[1] = 8'h0; end
            8'h21, 8'h8B: begin val[0] = vout[7:0]; val[1] = vout[15:8]; end
            8'h78: begin val[0] = {6'h0, cml != 8'h0, 1'b0}; val[1] = 8'h0; end
            8'h7E: begin val[0] = cml; val[1] = 8'h0; end
            8'h98: begin val[0] = 8'h33; val[1] = 8'h0; end
          endcase
          L = rlen(t.cmd);
          for (int i = 0; i < nr; i++) begin
            bit [7:0] b = (i < L) ? val[i] : (i == L) ? crc : 8'hFF;
            if (i < L) crc = crc8(crc, b);
            if (i < t.nread()) t.rdata[8*i +: 8] = b; else t.rpec = b;
          end
        end else begin
          for (int i = 0; i < t.nread(); i++) t.rdata[8*i +: 8] = 8'hFF;
          if (t.use_pec) t.rpec = 8'hFF;
        end
      end
    endfunction

    function void write_exp(smbus_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(smbus_transaction t);
      smbus_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        smbus_transaction e = exp_q.pop_front();
        smbus_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("smbus scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class smbus_env extends uvm_env;
    `uvm_component_utils(smbus_env)
    smbus_agent      agt;
    smbus_scoreboard sb;
    smbus_checker    chk;
    smbus_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = smbus_agent     ::type_id::create("agt", this);
      sb  = smbus_scoreboard::type_id::create("sb",  this);
      chk = smbus_checker   ::type_id::create("chk", this);
      cov = smbus_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
