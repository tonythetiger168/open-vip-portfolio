// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_env.sv -- CAM environment: reference-model scoreboard, checker, coverage

package cam_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import cam_defs_pkg::*;
  import cam_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class cam_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(cam_scoreboard)
    uvm_analysis_imp_exp #(cam_transaction, cam_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(cam_transaction, cam_scoreboard) obs_ap;

    cam_config cfg;
    cam_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // the CAM (scoreboard copy), kept across items
    localparam int RDY_DLY = 20, WAIT = 2, RS_DLY = 10, PROC = 16, BUF = 64;
    localparam bit [14:0] COR_ADDR = 15'h0FFE;
    localparam bit [5:0] CFG_IDX = 6'h0F;
    localparam bit [7:0] KEY = 8'hC5;
    bit        rdy = 0, io = 0, hc = 0, hc_ok = 0, sr = 0, daie = 0, frie = 0, rsh = 0, we = 0, re = 0;
    bit        proc = 0, regl = 0, tscr = 0, wn = 1, mv = 0, ms = 0;
    int        rc = 0, rcnt = 0, icnt = 0, sz = 0, pc = 0, pn = 0, on = 0, op = 0, wc = 0, tidx = 0;
    bit [7:0]  cor = 0, dl = 0, md = 0;
    bit [14:0] al = 0;
    bit [3:0]  st_q = 0;
    bit [7:0]  ib [64], ob [64];

    function bit fr(); return !rsh && rcnt == 0 && !proc && on == 0; endfunction
    function bit [7:0] attr(bit [14:0] ad);
      if (ad[0]) return 8'hFF;
      if (ad == COR_ADDR) return cor;
      return cam_cis(ad[14:1]);
    endfunction
    // the CAM pins for host pins m with the state before the clock edge
    function bit [20:0] outs(bit [41:0] m);
      bit [7:0] di = 0;
      bit da = on != 0;
      if (m[41] && !m[40] && rdy && !m[15]) begin
        if (!m[13]) di = m[14] ? 8'hFF : attr(m[39:25]);
        else if (!m[11] && io && !m[14])
          case (m[26:25])
            2'd0: di = da ? ob[op] : 8'h00;
            2'd1: di = {da, fr(), 4'h0, we, re};
            2'd2: di = 8'(on);
            default: di = 8'(on >> 8);
          endcase
      end
      return {1'b0, di, wn, io ? !((daie && da) || (frie && fr())) : rdy, md, mv, ms};
    endfunction
    function void clear();
      hc = 0; sr = 0; daie = 0; frie = 0; rsh = 0; rcnt = 0; we = 0; re = 0;
      proc = 0; on = 0; st_q = 0; wn = 1;
    endfunction
    function void step(bit [41:0] m);
      bit [3:0] st;
      if (!m[41]) begin
        rdy = 0; rc = 0; io = 0; cor = 0; clear(); mv = 0; ms = 0; md = 0; tidx = 0;
        return;
      end
      st = (rdy && !m[15]) ? {!m[10], !m[11], !m[12], !m[13]} : 4'h0;
      if (m[40]) begin rdy = 0; rc = 0; io = 0; cor = 0; clear(); end
      else begin
        if (!rdy) begin rc++; if (rc == RDY_DLY) rdy = 1; end
        if (rcnt != 0) rcnt--;
        if (proc) begin
          pc--;
          if (pc == 0) begin
            for (int i = 0; i < BUF; i++) ob[i] = (i < 2) ? ib[i] : ib[i] ^ 8'h5A;
            on = pn; op = 0; proc = 0;
          end
        end
        if (st != 0) begin al = m[39:25]; dl = m[24:17]; regl = m[14]; end
        if (st != 0 && st_q == 0) wc = WAIT;
        else if (st != 0 && wc != 0) wc--;
        wn = !(st != 0 && wc != 0);
        if (st == 0 && st_q != 0 && !regl) begin
          if (st_q[1] && al == COR_ADDR) begin cor = dl; io = dl[5:0] == CFG_IDX; end
          if (st_q[2] && io && al[1:0] == 2'd0) begin
            if (on != 0) begin op++; if (op == on) on = 0; end
            else re = 1;
          end
          if (st_q[3] && io)
            case (al[1:0])
              2'd0: begin
                if (hc && hc_ok) begin
                  if (icnt < BUF) ib[icnt] = dl; else we = 1;
                  if (icnt < 65535) icnt++;
                end else we = 1;
              end
              2'd1: begin
                daie = dl[7]; frie = dl[6];
                if (dl[3]) begin
                  hc = 0; proc = 0; on = 0; we = 0; re = 0; rsh = 1;
                end else begin
                  if (rsh) begin rsh = 0; rcnt = RS_DLY; end
                  if (dl[2] && !sr && on == 0 && !proc) begin ob[0] = 8'(BUF >> 8); ob[1] = 8'(BUF); on = 2; op = 0; end
                  sr = dl[2];
                  if (dl[0] && !hc) begin hc = 1; hc_ok = fr(); icnt = 0; end
                  else if (!dl[0] && hc) begin
                    hc = 0;
                    if (hc_ok && icnt != 0) begin
                      if (icnt == sz && icnt <= BUF) begin proc = 1; pc = PROC; pn = icnt; end
                      else we = 1;
                    end
                  end
                end
              end
              2'd2: sz = (sz & 32'hFF00) | int'(dl);
              default: sz = (sz & 32'h00FF) | (int'(dl) << 8);
            endcase
        end
        st_q = st;
      end
      // the stream through the CAM
      mv = m[1]; ms = m[1] && m[0];
      if (m[1]) begin
        tidx = m[0] ? 0 : (tidx == 255 ? 255 : tidx + 1);
        if (tidx == 3) begin tscr = m[9:8] != 0; md = {2'b00, m[7:2]}; end
        else if (tidx >= 4 && tscr) md = m[9:2] ^ (KEY ^ 8'(tidx));
        else md = m[9:2];
      end else md = 0;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(cam_config)::get(this, "", "cfg", cfg))
        cfg = cam_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(cam_transaction t);
      foreach (t.pre[i]) step(t.pre[i]);
      t.so.delete();
      foreach (t.mo[i]) begin
        t.so.push_back(outs(t.mo[i]));
        step(t.mo[i]);
      end
    endfunction

    function void write_exp(cam_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(cam_transaction t);
      cam_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        cam_transaction e = exp_q.pop_front();
        cam_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("cam scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class cam_env extends uvm_env;
    `uvm_component_utils(cam_env)
    cam_agent      agt;
    cam_scoreboard sb;
    cam_checker    chk;
    cam_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = cam_agent     ::type_id::create("agt", this);
      sb  = cam_scoreboard::type_id::create("sb",  this);
      chk = cam_checker   ::type_id::create("chk", this);
      cov = cam_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
