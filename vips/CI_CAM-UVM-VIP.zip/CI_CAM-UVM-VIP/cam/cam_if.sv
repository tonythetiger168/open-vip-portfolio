// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_if.sv -- CAM interface

interface cam_if (input logic clk);
  logic rst_n;

  logic ci_vcc_en;
  logic ci_reset;
  logic [14:0] ci_a;
  logic [7:0] ci_d_o;
  logic ci_d_oe;
  logic ci_ce_n;
  logic ci_reg_n;
  logic ci_oe_n;
  logic ci_we_n;
  logic ci_iord_n;
  logic ci_iowr_n;
  logic [7:0] ci_mo_data;
  logic ci_mo_val;
  logic ci_mo_strt;
  logic ci_cd_n;
  logic [7:0] ci_d_i;
  logic ci_wait_n;
  logic ci_ireq_n;
  logic [7:0] ci_mi_data;
  logic ci_mi_val;
  logic ci_mi_strt;

  modport DUT (input clk, rst_n, input ci_vcc_en, input ci_reset, input ci_a, input ci_d_o, input ci_d_oe, input ci_ce_n, input ci_reg_n, input ci_oe_n, input ci_we_n, input ci_iord_n, input ci_iowr_n, input ci_mo_data, input ci_mo_val, input ci_mo_strt, output ci_cd_n, output ci_d_i, output ci_wait_n, output ci_ireq_n, output ci_mi_data, output ci_mi_val, output ci_mi_strt);
  modport MON (input clk, rst_n, ci_vcc_en, ci_reset, ci_a, ci_d_o, ci_d_oe, ci_ce_n, ci_reg_n, ci_oe_n, ci_we_n, ci_iord_n, ci_iowr_n, ci_mo_data, ci_mo_val, ci_mo_strt, ci_cd_n, ci_d_i, ci_wait_n, ci_ireq_n, ci_mi_data, ci_mi_val, ci_mi_strt);

  clocking drv_cb @(posedge clk);
    input rst_n, ci_cd_n, ci_d_i, ci_wait_n, ci_ireq_n, ci_mi_data, ci_mi_val, ci_mi_strt;
    inout ci_vcc_en, ci_reset, ci_a, ci_d_o, ci_d_oe, ci_ce_n, ci_reg_n, ci_oe_n, ci_we_n, ci_iord_n, ci_iowr_n, ci_mo_data, ci_mo_val, ci_mo_strt;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, ci_vcc_en, ci_reset, ci_a, ci_d_o, ci_d_oe, ci_ce_n, ci_reg_n, ci_oe_n, ci_we_n, ci_iord_n, ci_iowr_n, ci_mo_data, ci_mo_val, ci_mo_strt, ci_cd_n, ci_d_i, ci_wait_n, ci_ireq_n, ci_mi_data, ci_mi_val, ci_mi_strt;
  endclocking
endinterface
