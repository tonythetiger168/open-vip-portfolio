// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_compliance_checker.sv -- CAM concurrent assertion checks (bindable)

module cam_compliance_checker
  (input logic clk, input logic rst_n, input logic ci_vcc_en, input logic ci_reset, input logic [14:0] ci_a, input logic [7:0] ci_d_o, input logic ci_d_oe, input logic ci_ce_n, input logic ci_reg_n, input logic ci_oe_n, input logic ci_we_n, input logic ci_iord_n, input logic ci_iowr_n, input logic [7:0] ci_mo_data, input logic ci_mo_val, input logic ci_mo_strt, input logic ci_cd_n, input logic [7:0] ci_d_i, input logic ci_wait_n, input logic ci_ireq_n, input logic [7:0] ci_mi_data, input logic ci_mi_val, input logic ci_mi_strt);

  assert property (@(posedge clk) disable iff (!rst_n)
    !$isunknown({ci_cd_n, ci_d_i, ci_wait_n, ci_ireq_n, ci_mi_data, ci_mi_val, ci_mi_strt}))
    else $error("CAM: X on a CAM output");
  assert property (@(posedge clk) disable iff (!rst_n) ci_ce_n |-> ci_d_i == 8'h00)
    else $error("CAM: data driven with CE# high");
  assert property (@(posedge clk) disable iff (!rst_n) ci_mi_strt |-> ci_mi_val)
    else $error("CAM: MISTRT without MIVAL");
  cover property (@(posedge clk) disable iff (!rst_n) !ci_wait_n);
endmodule
