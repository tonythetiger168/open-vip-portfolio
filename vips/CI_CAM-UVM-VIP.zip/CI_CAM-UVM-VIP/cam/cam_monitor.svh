// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_monitor.svh -- CAM monitor: every host and CAM pin at every clock; a clock with CE# high and the address at 0x7FFF ends an item (such clocks before an item's first clock are kept apart as idle)

class cam_monitor extends uvm_monitor;
  `uvm_component_utils(cam_monitor)

  virtual cam_if vif;
  uvm_analysis_port #(cam_transaction) ap;
  cam_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual cam_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cam: virtual interface not set")
    if (!uvm_config_db#(cam_config)::get(this, "", "cfg", cfg))
      cfg = cam_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        cam_transaction t;
        bit [41:0] m;
        t = cam_transaction::type_id::create("t");
        forever begin
          @(vif.mon_cb);
          m = {vif.mon_cb.ci_vcc_en, vif.mon_cb.ci_reset, vif.mon_cb.ci_a, vif.mon_cb.ci_d_o, vif.mon_cb.ci_d_oe,
               vif.mon_cb.ci_ce_n, vif.mon_cb.ci_reg_n, vif.mon_cb.ci_oe_n, vif.mon_cb.ci_we_n, vif.mon_cb.ci_iord_n,
               vif.mon_cb.ci_iowr_n, vif.mon_cb.ci_mo_data, vif.mon_cb.ci_mo_val, vif.mon_cb.ci_mo_strt};
          if (t.mo.size() == 0 && m[15] && m[39:25] == 15'h7FFF) begin t.pre.push_back(m); continue; end
          t.mo.push_back(m);
          t.so.push_back({vif.mon_cb.ci_cd_n, vif.mon_cb.ci_d_i, vif.mon_cb.ci_wait_n, vif.mon_cb.ci_ireq_n,
                          vif.mon_cb.ci_mi_data, vif.mon_cb.ci_mi_val, vif.mon_cb.ci_mi_strt});
          if ((m[15] && m[39:25] == 15'h7FFF) || t.mo.size() >= 65536) break;
        end
        publish(t);
      end
    end
  endtask

  function void publish(cam_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
