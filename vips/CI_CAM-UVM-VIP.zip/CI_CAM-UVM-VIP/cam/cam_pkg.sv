// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_pkg.sv -- CAM UVM VIP package

package cam_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import cam_defs_pkg::*;
  export cam_defs_pkg::*;

  `include "cam_transaction.svh"
  `include "cam_config.svh"
  `include "cam_sequencer.svh"
  `include "cam_driver.svh"
  `include "cam_monitor.svh"
  `include "cam_agent.svh"
  `include "cam_sequences.svh"
  `include "cam_checker.svh"
  `include "cam_coverage.svh"
endpackage
