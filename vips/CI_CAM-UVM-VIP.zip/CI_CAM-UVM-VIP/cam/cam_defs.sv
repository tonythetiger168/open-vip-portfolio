// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_defs.sv -- CAM shared type definitions

package cam_defs_pkg;

  typedef enum bit [1:0] {CAM_OK, CAM_ERR} cam_status_e;

  function automatic bit [7:0] cam_cis(bit [13:0] k);
    bit [7:0] v;
    case (k)
      14'd0: v = 8'h1D; 14'd1: v = 8'h04; 14'd2: v = 8'h00; 14'd3: v = 8'hDB; 14'd4: v = 8'h08; 14'd5: v = 8'hFF;
      14'd6: v = 8'h1C; 14'd7: v = 8'h03; 14'd8: v = 8'h00; 14'd9: v = 8'h08; 14'd10: v = 8'hFF; 14'd11: v = 8'h15;
      14'd12: v = 8'h0E; 14'd13: v = 8'h05; 14'd14: v = 8'h00; 14'd15: v = 8'h44; 14'd16: v = 8'h56; 14'd17: v = 8'h42;
      14'd18: v = 8'h20; 14'd19: v = 8'h43; 14'd20: v = 8'h41; 14'd21: v = 8'h4D; 14'd22: v = 8'h00; 14'd23: v = 8'h56;
      14'd24: v = 8'h31; 14'd25: v = 8'h00; 14'd26: v = 8'hFF; 14'd27: v = 8'h1A; 14'd28: v = 8'h15; 14'd29: v = 8'h01;
      14'd30: v = 8'h0F; 14'd31: v = 8'hFE; 14'd32: v = 8'h0F; 14'd33: v = 8'h01; 14'd34: v = 8'hC0; 14'd35: v = 8'h0E;
      14'd36: v = 8'h41; 14'd37: v = 8'h02; 14'd38: v = 8'h44; 14'd39: v = 8'h56; 14'd40: v = 8'h42; 14'd41: v = 8'h5F;
      14'd42: v = 8'h43; 14'd43: v = 8'h49; 14'd44: v = 8'h5F; 14'd45: v = 8'h56; 14'd46: v = 8'h31; 14'd47: v = 8'h2E;
      14'd48: v = 8'h30; 14'd49: v = 8'h30; 14'd50: v = 8'h1B; 14'd51: v = 8'h02; 14'd52: v = 8'hCF; 14'd53: v = 8'h00;
      14'd54: v = 8'h14; 14'd55: v = 8'h00; 14'd56: v = 8'hFF;
      default: v = 8'hFF;
    endcase
    return v;
  endfunction

endpackage
