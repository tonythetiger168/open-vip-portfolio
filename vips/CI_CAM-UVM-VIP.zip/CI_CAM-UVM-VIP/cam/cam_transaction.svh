// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_transaction.svh -- CAM transaction

class cam_transaction extends uvm_sequence_item;
  `uvm_object_utils(cam_transaction)

  // request (driven by the agent)
  bit [41:0] mo[$];
  // response (returned by the DUT)
  bit [20:0] so[$];
  // bookkeeping (not compared)
  bit [41:0] pre[$];
  bit [7:0] rd[$];
  rand bit [3:0] kind;
  rand bit [6:0] cnt;
  rand bit [1:0] sup;
  rand bit [1:0] stb;
  rand bit [1:0] hld;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "cam_transaction"); super.new(name); endfunction

  // kind: 0 power up (VCC, RESET, wait READY), 1 power off, 2 CIS read (cnt % 64 + 1 bytes), 3 COR write
  // (seed % 3: 01 / 0F / 4F) and read-back, 4 interface reset, 5 send a message (cnt % 66 + 1 bytes), 6 read
  // a reply, 7 send and read, 8 DATA read with nothing to read, 9 buffer size (SR), 10 a TS packet
  // (seed[0] scrambled, seed[1] with gaps), 11 I/O read in memory mode and a common-memory read, 12 write to
  // the CIS and read it back, 13 COMMAND with DAIE / FRIE (seed[1:0]), 14 DATA write without HC, 15 a
  // message whose size does not match
  function void set(int k, int n = 0, bit [31:0] s = 32'h1); kind = k; cnt = n; seed = s; sup = 0; stb = 0; hld = 0; endfunction
  function bit [7:0] wbyte(int i);
    bit [31:0] x = (seed | 1) ^ (32'(i) * 32'h9E37_79B9);
    x ^= x >> 13; x *= 32'h5BD1_E995; x ^= x >> 15;
    return x[7:0];
  endfunction

  function void do_copy(uvm_object rhs);
    cam_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mo = rhs_.mo;
    so = rhs_.so;
    pre = rhs_.pre;
    rd = rhs_.rd;
    kind = rhs_.kind;
    cnt = rhs_.cnt;
    sup = rhs_.sup;
    stb = rhs_.stb;
    hld = rhs_.hld;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    cam_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(cam_transaction rhs_);
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    return 1;
  endfunction

  function string qstr_mo();
    string s = $sformatf("[%0d]{", mo.size());
    foreach (mo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", mo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_pre();
    string s = $sformatf("[%0d]{", pre.size());
    foreach (pre[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", pre[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rd();
    string s = $sformatf("[%0d]{", rd.size());
    foreach (rd[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rd[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("CAM{tag=%0d mo=%s so=%s}", tag, qstr_mo(), qstr_so());
  endfunction
endclass
