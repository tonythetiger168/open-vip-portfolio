// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_sequences.svh -- CAM sequences

// Random traffic: cfg.num_items constrained-random items.
class cam_base_sequence extends uvm_sequence #(cam_transaction);
  `uvm_object_utils(cam_base_sequence)
  cam_config cfg;

  function new(string name = "cam_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = cam_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "cam_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class cam_directed_sequence extends uvm_sequence #(cam_transaction);
  `uvm_object_utils(cam_directed_sequence)
  cam_config cfg;

  function new(string name = "cam_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function cam_transaction item();
    item = cam_transaction::type_id::create("req");
  endfunction

  task send(cam_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    cam_transaction t;
    t = item(); t.set(2, 3); send(t);            // off: nothing answers
    t = item(); t.set(0); send(t);
    t = item(); t.set(2, 63); send(t);           // the whole CIS and past it
    t = item(); t.set(11); send(t);
    t = item(); t.set(5, 4); send(t);            // memory mode: I/O ignored
    t = item(); t.set(3, 0, 32'd0); send(t);     // COR 01: no I/O mode
    t = item(); t.set(3, 0, 32'd2); send(t);     // COR 4F: I/O mode
    t = item(); t.set(4); send(t);
    t = item(); t.set(9); send(t);               // buffer size
    t = item(); t.set(5, 9); send(t);
    t = item(); t.set(6); send(t);
    t = item(); t.set(7, 63, 32'h55); send(t);   // 64 bytes
    t = item(); t.set(5, 64); send(t);           // 65 bytes: WE
    t = item(); t.set(6); send(t);
    t = item(); t.set(4); send(t);
    t = item(); t.set(15, 5); send(t);
    t = item(); t.set(14); send(t);
    t = item(); t.set(8); send(t);
    t = item(); t.set(4); send(t);
    t = item(); t.set(5, 3); send(t);
    t = item(); t.set(5, 3, 32'h9); send(t);     // FR low: the second message is refused
    t = item(); t.set(6); send(t);
    t = item(); t.set(13, 0, 32'd3); send(t);
    t = item(); t.set(5, 7); send(t);
    t = item(); t.set(13, 0, 32'd1); send(t);
    t = item(); t.set(6); send(t);
    t = item(); t.set(13, 0, 32'd0); send(t);
    t = item(); t.set(10, 0, 32'd0); send(t);
    t = item(); t.set(10, 0, 32'd1); send(t);
    t = item(); t.set(10, 0, 32'd3); send(t);
    t = item(); t.set(12, 2); send(t);
    t = item(); t.set(3, 0, 32'd1); send(t);
    t = item(); t.set(5, 2); send(t);
    t = item(); t.set(0); send(t);               // RESET with a reply pending
    t = item(); t.set(11); send(t);
    t = item(); t.set(1); send(t);
    t = item(); t.set(10, 0, 32'd1); send(t);    // off: no stream
    t = item(); t.set(0); send(t);
    t = item(); t.set(3, 0, 32'd1); send(t);
    for (int i = 0; i < 4; i++) begin
      t = item(); t.set(7, 20 + i, i); t.sup = i; t.stb = 3 - i; t.hld = i % 3; send(t);
    end
  endtask
endclass
