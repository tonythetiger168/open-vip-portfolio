// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_driver.svh -- CAM driver: one item per host operation (power, CIS, COR, interface reset, message, reply, TS packet ...), each bus cycle with setup / strobe / hold of the item's sup / stb / hld, then cfg.gap idle clocks and one clock with CE# high and the address at 0x7FFF that ends the item

class cam_driver extends uvm_driver #(cam_transaction);
  `uvm_component_utils(cam_driver)

  uvm_analysis_port #(cam_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual cam_if vif;
  cam_config cfg;

  bit             vcc = 0, rs = 0, doe = 0, ce = 1, rg = 1, oe = 1, we = 1, ir = 1, iw = 1, tv = 0, tst = 0;
  bit [14:0]      a = 15'h7FFF;
  bit [7:0]       d = 0, td = 0;
  bit [20:0]      rsp;
  cam_transaction cur;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual cam_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cam: virtual interface not set")
    if (!uvm_config_db#(cam_config)::get(this, "", "cfg", cfg))
      cfg = cam_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    cam_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.ci_vcc_en <= 1'b0; vif.drv_cb.ci_reset <= 1'b0; vif.drv_cb.ci_a <= 15'h7FFF; vif.drv_cb.ci_d_o <= 8'h00;
    vif.drv_cb.ci_d_oe <= 1'b0; vif.drv_cb.ci_ce_n <= 1'b1; vif.drv_cb.ci_reg_n <= 1'b1; vif.drv_cb.ci_oe_n <= 1'b1;
    vif.drv_cb.ci_we_n <= 1'b1; vif.drv_cb.ci_iord_n <= 1'b1; vif.drv_cb.ci_iowr_n <= 1'b1;
    vif.drv_cb.ci_mo_data <= 8'h00; vif.drv_cb.ci_mo_val <= 1'b0; vif.drv_cb.ci_mo_strt <= 1'b0;
  endtask

  task drive_item(cam_transaction t);
    bit ok;
    bit [7:0] s;
    cur = t;
    t.mo.delete(); t.rd.delete();
    a = 0;
    case (t.kind)
      0: begin
        vcc = 1; idle(4); rs = 1; idle(10); rs = 0; idle(2);
        for (int i = 0; i < 40 && !rsp[10]; i++) rd1(0, 15'd0);
      end
      1: begin vcc = 0; rs = 0; idle(10); end
      2: for (int i = 0; i <= t.cnt % 64; i++) rd1(0, 15'(2 * i));
      3: begin
        s = (t.seed % 3 == 0) ? 8'h01 : (t.seed % 3 == 1) ? 8'h0F : 8'h4F;
        wr1(1, 15'h0FFE, s); rd1(0, 15'h0FFE); status(s);
      end
      4: begin wr1(3, 15'd1, 8'h08); idle(2); wr1(3, 15'd1, 8'h00); poll(6, 12, ok); end
      5: send(t.cnt % 66 + 1, 1'b0);
      6: recv();
      7: begin send(t.cnt % 66 + 1, 1'b0); recv(); end
      8: begin rd1(2, 15'd0); rd1(2, 15'd0); status(s); end
      9: begin wr1(3, 15'd1, 8'h04); recv(); end
      10: begin
        for (int i = 0; i < 188; i++) begin
          td = (i == 0) ? 8'h47 : (i == 3) ? (t.seed[0] ? 8'hD3 : 8'h13) : t.wbyte(i);
          tv = 1; tst = (i == 0);
          clk1();
          if (t.seed[1] && i % 50 == 25) begin tv = 0; tst = 0; td = 0; idle(2); end
        end
        tv = 0; tst = 0; td = 0; idle(3);
      end
      11: begin rd1(2, 15'd1); rd1(4, 15'd0); rd1(4, 15'h0FFE); end
      12: begin wr1(1, 15'(2 * (t.cnt % 8)), 8'hAA); rd1(0, 15'(2 * (t.cnt % 8))); wr1(4, 15'h0FFE, 8'h00); rd1(0, 15'h0FFE); end
      13: begin wr1(3, 15'd1, {t.seed[0], t.seed[1], 6'b0}); status(s); idle(4); end
      14: begin wr1(3, 15'd0, 8'h33); status(s); end
      default: begin send(t.cnt % 20 + 2, 1'b1); idle(20); status(s); end
    endcase
    idle(cfg.gap);
    a = 15'h7FFF; clk1(); a = 0;
  endtask

  function bit [41:0] pk();
    return {vcc, rs, a, d, doe, ce, rg, oe, we, ir, iw, td, tv, tst};
  endfunction
  // one clock: drive the pins, record them, sample the CAM
  task automatic clk1();
    vif.drv_cb.ci_vcc_en  <= vcc; vif.drv_cb.ci_reset <= rs; vif.drv_cb.ci_a <= a; vif.drv_cb.ci_d_o <= d;
    vif.drv_cb.ci_d_oe    <= doe; vif.drv_cb.ci_ce_n <= ce; vif.drv_cb.ci_reg_n <= rg; vif.drv_cb.ci_oe_n <= oe;
    vif.drv_cb.ci_we_n    <= we; vif.drv_cb.ci_iord_n <= ir; vif.drv_cb.ci_iowr_n <= iw;
    vif.drv_cb.ci_mo_data <= td; vif.drv_cb.ci_mo_val <= tv; vif.drv_cb.ci_mo_strt <= tst;
    cur.mo.push_back(pk());
    @(vif.drv_cb);
    rsp = {vif.drv_cb.ci_cd_n, vif.drv_cb.ci_d_i, vif.drv_cb.ci_wait_n, vif.drv_cb.ci_ireq_n,
           vif.drv_cb.ci_mi_data, vif.drv_cb.ci_mi_val, vif.drv_cb.ci_mi_strt};
  endtask
  task automatic idle(int n); repeat (n) clk1(); endtask
  // a bus cycle: k 0 attribute read, 1 attribute write, 2 I/O read, 3 I/O write, 4 common-memory read
  task automatic cyc(int k, bit [14:0] ad, bit [7:0] wd, output bit [7:0] rd);
    int n = 0;
    ce = 0; rg = (k == 4); a = ad;
    if (k == 1 || k == 3) begin d = wd; doe = 1; end
    repeat (cur.sup + 1) clk1();
    case (k) 1: we = 0; 2: ir = 0; 3: iw = 0; default: oe = 0; endcase
    repeat (cur.stb + 3) clk1();
    while (!rsp[11] && n < 64) begin clk1(); n++; end
    clk1();
    rd = rsp[19:12];
    oe = 1; we = 1; ir = 1; iw = 1;
    repeat (cur.hld + 1) clk1();
    ce = 1; rg = 1; doe = 0; d = 0; a = 0;
    clk1();
  endtask
  task automatic rd1(int k, bit [14:0] ad);
    bit [7:0] x;
    cyc(k, ad, 8'h00, x);
    cur.rd.push_back(x);
  endtask
  task automatic wr1(int k, bit [14:0] ad, bit [7:0] v);
    bit [7:0] x;
    cyc(k, ad, v, x);
  endtask
  task automatic status(output bit [7:0] s); cyc(2, 15'd1, 8'h00, s); cur.rd.push_back(s); endtask
  // poll STATUS until bit b is set (at most n reads)
  task automatic poll(int b, int n, output bit ok);
    bit [7:0] s;
    ok = 0;
    for (int i = 0; i < n && !ok; i++) begin status(s); ok = s[b]; end
  endtask
  task automatic send(int n, bit mism);
    bit ok;
    bit [7:0] s;
    poll(6, 12, ok);
    for (int t = 0; t < 3; t++) begin
      wr1(3, 15'd1, 8'h01);
      status(s);
      if (s[6]) break;
      wr1(3, 15'd1, 8'h00);
    end
    wr1(3, 15'd2, 8'(n)); wr1(3, 15'd3, 8'(n >> 8));
    for (int i = 0; i < n - mism; i++) wr1(3, 15'd0, cur.wbyte(i));
    wr1(3, 15'd1, 8'h00);
  endtask
  task automatic recv();
    bit ok;
    bit [7:0] lo, hi;
    poll(7, 12, ok);
    if (!ok) return;
    wr1(3, 15'd1, 8'h04);
    cyc(2, 15'd2, 8'h00, lo); cyc(2, 15'd3, 8'h00, hi);
    wr1(3, 15'd1, 8'h00);
    for (int i = 0; i < {hi, lo} && i < 80; i++) rd1(2, 15'd0);
    status(lo);
  endtask
endclass
