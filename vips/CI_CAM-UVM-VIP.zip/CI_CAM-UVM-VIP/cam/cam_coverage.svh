// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cam_coverage.svh -- CAM functional coverage

class cam_coverage extends uvm_subscriber #(cam_transaction);
  `uvm_component_utils(cam_coverage)
  cam_config cfg;
  cam_transaction tr;

  covergroup cam_cg;
    cp_kind : coverpoint tr.kind;
    cp_tim  : coverpoint {tr.sup, tr.stb} { bins s[] = {[0:15]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cam_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(cam_config)::get(this, "", "cfg", cfg))
      cfg = cam_config::type_id::create("cfg");
  endfunction

  function void write(cam_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    cam_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CAM coverage: %0.1f%%", cam_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
