// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CAM testbench top with a functional CAM DUT model

`ifndef CI_CAM_UVM_VIP_TB_SV
`define CI_CAM_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import cam_defs_pkg::*;
import cam_pkg::*;
import cam_env_pkg::*;
import cam_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  cam_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  cam_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .ci_vcc_en(vif.ci_vcc_en),
    .ci_reset(vif.ci_reset),
    .ci_a(vif.ci_a),
    .ci_d_o(vif.ci_d_o),
    .ci_d_oe(vif.ci_d_oe),
    .ci_ce_n(vif.ci_ce_n),
    .ci_reg_n(vif.ci_reg_n),
    .ci_oe_n(vif.ci_oe_n),
    .ci_we_n(vif.ci_we_n),
    .ci_iord_n(vif.ci_iord_n),
    .ci_iowr_n(vif.ci_iowr_n),
    .ci_mo_data(vif.ci_mo_data),
    .ci_mo_val(vif.ci_mo_val),
    .ci_mo_strt(vif.ci_mo_strt),
    .ci_cd_n(vif.ci_cd_n),
    .ci_d_i(vif.ci_d_i),
    .ci_wait_n(vif.ci_wait_n),
    .ci_ireq_n(vif.ci_ireq_n),
    .ci_mi_data(vif.ci_mi_data),
    .ci_mi_val(vif.ci_mi_val),
    .ci_mi_strt(vif.ci_mi_strt)
  );

  // Concurrent protocol checks
  cam_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .ci_vcc_en(vif.ci_vcc_en),
    .ci_reset(vif.ci_reset),
    .ci_a(vif.ci_a),
    .ci_d_o(vif.ci_d_o),
    .ci_d_oe(vif.ci_d_oe),
    .ci_ce_n(vif.ci_ce_n),
    .ci_reg_n(vif.ci_reg_n),
    .ci_oe_n(vif.ci_oe_n),
    .ci_we_n(vif.ci_we_n),
    .ci_iord_n(vif.ci_iord_n),
    .ci_iowr_n(vif.ci_iowr_n),
    .ci_mo_data(vif.ci_mo_data),
    .ci_mo_val(vif.ci_mo_val),
    .ci_mo_strt(vif.ci_mo_strt),
    .ci_cd_n(vif.ci_cd_n),
    .ci_d_i(vif.ci_d_i),
    .ci_wait_n(vif.ci_wait_n),
    .ci_ireq_n(vif.ci_ireq_n),
    .ci_mi_data(vif.ci_mi_data),
    .ci_mi_val(vif.ci_mi_val),
    .ci_mi_strt(vif.ci_mi_strt)
  );

  initial begin
    uvm_config_db#(virtual cam_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module cam_model #(
  parameter int          RDY_DLY  = 20,
  parameter int          WAIT     = 2,
  parameter int          RS_DLY   = 10,
  parameter int          PROC     = 16,
  parameter int          BUF      = 64,
  parameter logic [14:0] COR_ADDR = 15'h0FFE,
  parameter logic [5:0]  CFG_IDX  = 6'h0F,
  parameter logic [7:0]  KEY      = 8'hC5
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        ci_vcc_en,
  input  logic        ci_reset,
  input  logic [14:0] ci_a,
  input  logic [7:0]  ci_d_o,
  input  logic        ci_d_oe,
  input  logic        ci_ce_n,
  input  logic        ci_reg_n,
  input  logic        ci_oe_n,
  input  logic        ci_we_n,
  input  logic        ci_iord_n,
  input  logic        ci_iowr_n,
  input  logic [7:0]  ci_mo_data,
  input  logic        ci_mo_val,
  input  logic        ci_mo_strt,
  output logic        ci_cd_n,
  output logic [7:0]  ci_d_i,
  output logic        ci_wait_n,
  output logic        ci_ireq_n,
  output logic [7:0]  ci_mi_data,
  output logic        ci_mi_val,
  output logic        ci_mi_strt
);
  localparam int AW = $clog2(BUF);

  function automatic logic [7:0] cis(input logic [13:0] k);
    case (k)
      14'd0: cis = 8'h1D; 14'd1: cis = 8'h04; 14'd2: cis = 8'h00; 14'd3: cis = 8'hDB; 14'd4: cis = 8'h08; 14'd5: cis = 8'hFF;
      14'd6: cis = 8'h1C; 14'd7: cis = 8'h03; 14'd8: cis = 8'h00; 14'd9: cis = 8'h08; 14'd10: cis = 8'hFF; 14'd11: cis = 8'h15;
      14'd12: cis = 8'h0E; 14'd13: cis = 8'h05; 14'd14: cis = 8'h00; 14'd15: cis = 8'h44; 14'd16: cis = 8'h56; 14'd17: cis = 8'h42;
      14'd18: cis = 8'h20; 14'd19: cis = 8'h43; 14'd20: cis = 8'h41; 14'd21: cis = 8'h4D; 14'd22: cis = 8'h00; 14'd23: cis = 8'h56;
      14'd24: cis = 8'h31; 14'd25: cis = 8'h00; 14'd26: cis = 8'hFF; 14'd27: cis = 8'h1A; 14'd28: cis = 8'h15; 14'd29: cis = 8'h01;
      14'd30: cis = 8'h0F; 14'd31: cis = 8'hFE; 14'd32: cis = 8'h0F; 14'd33: cis = 8'h01; 14'd34: cis = 8'hC0; 14'd35: cis = 8'h0E;
      14'd36: cis = 8'h41; 14'd37: cis = 8'h02; 14'd38: cis = 8'h44; 14'd39: cis = 8'h56; 14'd40: cis = 8'h42; 14'd41: cis = 8'h5F;
      14'd42: cis = 8'h43; 14'd43: cis = 8'h49; 14'd44: cis = 8'h5F; 14'd45: cis = 8'h56; 14'd46: cis = 8'h31; 14'd47: cis = 8'h2E;
      14'd48: cis = 8'h30; 14'd49: cis = 8'h30; 14'd50: cis = 8'h1B; 14'd51: cis = 8'h02; 14'd52: cis = 8'hCF; 14'd53: cis = 8'h00;
      14'd54: cis = 8'h14; 14'd55: cis = 8'h00; 14'd56: cis = 8'hFF;
      default: cis = 8'hFF;
    endcase
  endfunction

  logic        rdy, io, hc, hc_ok, sr, daie, frie, rsh, we, re, proc, regl, tscr, wn;
  logic [15:0] rc, rcnt, icnt, sz, pc, pn, on, op;
  logic [7:0]  cor, wc, dl, tidx;
  logic [14:0] al;
  logic [3:0]  st_q;
  logic [7:0]  ib [0:BUF-1];
  logic [7:0]  ob [0:BUF-1];
  wire         fr     = !rsh && rcnt == 16'd0 && !proc && on == 16'd0;
  wire         da     = on != 16'd0;
  wire  [3:0]  st_now = (rdy && !ci_ce_n) ? {!ci_iowr_n, !ci_iord_n, !ci_we_n, !ci_oe_n} : 4'h0;

  function automatic logic [7:0] attr(input logic [14:0] ad);
    if (ad[0]) attr = 8'hFF;
    else if (ad == COR_ADDR) attr = cor;
    else attr = cis(ad[14:1]);
  endfunction

  assign ci_cd_n   = 1'b0;                      // inserted
  assign ci_wait_n = wn;
  assign ci_ireq_n = io ? !((daie && da) || (frie && fr)) : rdy;
  always_comb begin
    ci_d_i = 8'h00;
    if (ci_vcc_en && !ci_reset && rdy && !ci_ce_n) begin
      if (!ci_oe_n) ci_d_i = ci_reg_n ? 8'hFF : attr(ci_a);
      else if (!ci_iord_n && io && !ci_reg_n)
        case (ci_a[1:0])
          2'd0:    ci_d_i = da ? ob[op[AW-1:0]] : 8'h00;
          2'd1:    ci_d_i = {da, fr, 4'h0, we, re};
          2'd2:    ci_d_i = on[7:0];
          default: ci_d_i = on[15:8];
        endcase
    end
  end

  // no reset of its own: a PC card starts over when VCC is off (rst_n and ci_d_oe are not used)
  always_ff @(posedge clk) begin
    begin : step
      logic        v_rdy, v_io, v_hc, v_hc_ok, v_sr, v_daie, v_frie, v_rsh, v_we, v_re, v_proc, v_regl,
                   v_tscr, v_wn, v_fr;
      logic [15:0] v_rc, v_rcnt, v_icnt, v_sz, v_pc, v_pn, v_on, v_op;
      logic [7:0]  v_cor, v_wc, v_dl, v_tidx, v_md;
      logic [14:0] v_al;
      logic [3:0]  v_st_q, st;
      v_rdy = rdy; v_io = io; v_hc = hc; v_hc_ok = hc_ok; v_sr = sr; v_daie = daie; v_frie = frie; v_rsh = rsh;
      v_we = we; v_re = re; v_proc = proc; v_regl = regl; v_tscr = tscr; v_wn = wn;
      v_rc = rc; v_rcnt = rcnt; v_icnt = icnt; v_sz = sz; v_pc = pc; v_pn = pn; v_on = on; v_op = op;
      v_cor = cor; v_wc = wc; v_dl = dl; v_tidx = tidx; v_al = al; v_st_q = st_q;
      st = st_now;
      if (!ci_vcc_en || ci_reset) begin
        // power off or RESET: the card starts over (power off also stops the stream)
        v_rdy = 1'b0; v_rc = '0; v_io = 1'b0; v_cor = '0;
        v_hc = 1'b0; v_sr = 1'b0; v_daie = 1'b0; v_frie = 1'b0; v_rsh = 1'b0; v_rcnt = '0;
        v_we = 1'b0; v_re = 1'b0; v_proc = 1'b0; v_on = '0; v_st_q = '0; v_wn = 1'b1;
      end else begin
        if (!v_rdy) begin v_rc = v_rc + 16'd1; if (v_rc == 16'(RDY_DLY)) v_rdy = 1'b1; end
        if (v_rcnt != 0) v_rcnt = v_rcnt - 16'd1;
        if (v_proc) begin
          v_pc = v_pc - 16'd1;
          if (v_pc == 0) begin
            for (int i = 0; i < BUF; i++) ob[i] <= (i < 2) ? ib[i] : ib[i] ^ 8'h5A;   // read up to v_pn
            v_on = v_pn; v_op = '0; v_proc = 1'b0;
          end
        end
        if (st != 0) begin v_al = ci_a; v_dl = ci_d_o; v_regl = ci_reg_n; end
        if (st != 0 && v_st_q == 0) v_wc = 8'(WAIT);
        else if (st != 0 && v_wc != 0) v_wc = v_wc - 8'd1;
        v_wn = !(st != 0 && v_wc != 0);
        if (st == 0 && v_st_q != 0 && !v_regl) begin
          if (v_st_q[1] && v_al == COR_ADDR) begin v_cor = v_dl; v_io = v_dl[5:0] == CFG_IDX; end
          if (v_st_q[2] && v_io && v_al[1:0] == 2'd0) begin
            if (v_on != 0) begin
              v_op = v_op + 16'd1;
              if (v_op == v_on) v_on = '0;
            end else v_re = 1'b1;
          end
          if (v_st_q[3] && v_io)
            case (v_al[1:0])
              2'd0: begin
                if (v_hc && v_hc_ok) begin
                  if (v_icnt < 16'(BUF)) ib[v_icnt[AW-1:0]] <= v_dl; else v_we = 1'b1;
                  if (v_icnt != 16'hFFFF) v_icnt = v_icnt + 16'd1;
                end else v_we = 1'b1;
              end
              2'd1: begin
                v_daie = v_dl[7]; v_frie = v_dl[6];
                if (v_dl[3]) begin
                  v_hc = 1'b0; v_proc = 1'b0; v_on = '0; v_we = 1'b0; v_re = 1'b0; v_rsh = 1'b1;
                end else begin
                  if (v_rsh) begin v_rsh = 1'b0; v_rcnt = 16'(RS_DLY); end
                  if (v_dl[2] && !v_sr && v_on == 0 && !v_proc) begin
                    {ob[0], ob[1]} <= 16'(BUF); v_on = 16'd2; v_op = '0;
                  end
                  v_sr = v_dl[2];
                  v_fr = !v_rsh && v_rcnt == 0 && !v_proc && v_on == 0;
                  if (v_dl[0] && !v_hc) begin v_hc = 1'b1; v_hc_ok = v_fr; v_icnt = '0; end
                  else if (!v_dl[0] && v_hc) begin
                    v_hc = 1'b0;
                    if (v_hc_ok && v_icnt != 0) begin
                      if (v_icnt == v_sz && v_icnt <= 16'(BUF)) begin v_proc = 1'b1; v_pc = 16'(PROC); v_pn = v_icnt; end
                      else v_we = 1'b1;
                    end
                  end
                end
              end
              2'd2:    v_sz[7:0]  = v_dl;
              default: v_sz[15:8] = v_dl;
            endcase
        end
        v_st_q = st;
      end
      // the stream through the CAM
      v_md = '0;
      if (!ci_vcc_en) begin
        v_tidx = '0;
        ci_mi_val <= 1'b0; ci_mi_strt <= 1'b0;
      end else begin
        if (ci_mo_val) begin
          v_tidx = ci_mo_strt ? 8'd0 : (v_tidx == 8'hFF) ? 8'hFF : v_tidx + 8'd1;
          if (v_tidx == 8'd3) begin v_tscr = ci_mo_data[7:6] != 2'b00; v_md = {2'b00, ci_mo_data[5:0]}; end
          else if (v_tidx >= 8'd4 && v_tscr) v_md = ci_mo_data ^ (KEY ^ v_tidx);
          else v_md = ci_mo_data;
        end
        ci_mi_val <= ci_mo_val; ci_mi_strt <= ci_mo_val && ci_mo_strt;
      end
      ci_mi_data <= v_md;
      rdy <= v_rdy; io <= v_io; hc <= v_hc; hc_ok <= v_hc_ok; sr <= v_sr; daie <= v_daie; frie <= v_frie;
      rsh <= v_rsh; we <= v_we; re <= v_re; proc <= v_proc; regl <= v_regl; tscr <= v_tscr;
      wn <= v_wn; rc <= v_rc; rcnt <= v_rcnt; icnt <= v_icnt; sz <= v_sz; pc <= v_pc; pn <= v_pn; on <= v_on;
      op <= v_op; cor <= v_cor; wc <= v_wc; dl <= v_dl; tidx <= v_tidx; al <= v_al; st_q <= v_st_q;
    end
  end
endmodule
`endif
