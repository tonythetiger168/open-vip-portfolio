// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (CAM DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened cam_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b1;
  initial #1 rst_n = 1'b0;
  always #5 clk = ~clk;

  logic        vcc = 0, rs = 0, doe = 0, ce = 1, rg = 1, oe = 1, we = 1, ir = 1, iw = 1, tv = 0, tst = 0;
  logic [14:0] a = 0;
  logic [7:0]  d = 0, td = 0;
  wire         cd_n, wait_n, ireq_n, mv, ms;
  wire  [7:0]  di, md;

  cam_model u_dut (.clk(clk), .rst_n(rst_n), .ci_vcc_en(vcc), .ci_reset(rs), .ci_a(a), .ci_d_o(d), .ci_d_oe(doe),
                   .ci_ce_n(ce), .ci_reg_n(rg), .ci_oe_n(oe), .ci_we_n(we), .ci_iord_n(ir), .ci_iowr_n(iw),
                   .ci_mo_data(td), .ci_mo_val(tv), .ci_mo_strt(tst), .ci_cd_n(cd_n), .ci_d_i(di),
                   .ci_wait_n(wait_n), .ci_ireq_n(ireq_n), .ci_mi_data(md), .ci_mi_val(mv), .ci_mi_strt(ms));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one clock: inputs change after the falling edge, outputs are looked at just before the rising edge
  integer nwait;
  task automatic clk1();
    @(negedge clk);
    @(posedge clk); #1;
  endtask
  task automatic idle(input integer n); repeat (n) clk1(); endtask
  integer sup = 0, stb = 3, hld = 0;
  logic [7:0] rd;
  // k 0 attribute read, 1 attribute write, 2 I/O read, 3 I/O write, 4 common read, 5 common write
  task automatic cyc(input integer k, input logic [14:0] ad, input logic [7:0] wd);
    @(negedge clk);
    ce = 0; rg = (k >= 4); a = ad;
    if (k == 1 || k == 3 || k == 5) begin d = wd; doe = 1; end
    repeat (sup + 1) clk1();
    @(negedge clk);
    case (k) 1, 5: we = 0; 2: ir = 0; 3: iw = 0; default: oe = 0; endcase
    nwait = 0;
    repeat (stb + 1) begin @(posedge clk); #1; if (!wait_n) nwait = nwait + 1; @(negedge clk); end
    while (!wait_n) begin @(posedge clk); #1; if (!wait_n) nwait = nwait + 1; @(negedge clk); end
    rd = di;
    oe = 1; we = 1; ir = 1; iw = 1;
    repeat (hld + 1) clk1();
    @(negedge clk);
    ce = 1; rg = 1; doe = 0; d = 0; a = 0;
  endtask
  task automatic st_rd(); cyc(2, 15'd1, 8'h00); endtask
  task automatic cmd(input logic [7:0] c); cyc(3, 15'd1, c); endtask
  logic [7:0] r [0:127];
  integer nr;
  task automatic msg_out(input integer n, input integer seed, input integer short_by);
    cmd(8'h01); cyc(3, 15'd2, 8'(n)); cyc(3, 15'd3, 8'(n >> 8));
    for (int i = 0; i < n - short_by; i++) cyc(3, 15'd0, 8'(i * 13 + seed));
    cmd(8'h00);
  endtask
  task automatic msg_in();
    logic [7:0] lo, hi;
    cmd(8'h04); cyc(2, 15'd2, 0); lo = rd; cyc(2, 15'd3, 0); hi = rd; cmd(8'h00);
    nr = {hi, lo};
    for (int i = 0; i < nr && i < 128; i++) begin cyc(2, 15'd0, 0); r[i] = rd; end
  endtask
  function automatic logic [7:0] cisb(input integer k);
    logic [7:0] t [0:56];
    t = '{8'h1D, 8'h04, 8'h00, 8'hDB, 8'h08, 8'hFF, 8'h1C, 8'h03, 8'h00, 8'h08, 8'hFF, 8'h15, 8'h0E, 8'h05, 8'h00,
          8'h44, 8'h56, 8'h42, 8'h20, 8'h43, 8'h41, 8'h4D, 8'h00, 8'h56, 8'h31, 8'h00, 8'hFF, 8'h1A, 8'h15, 8'h01,
          8'h0F, 8'hFE, 8'h0F, 8'h01, 8'hC0, 8'h0E, 8'h41, 8'h02, 8'h44, 8'h56, 8'h42, 8'h5F, 8'h43, 8'h49, 8'h5F,
          8'h56, 8'h31, 8'h2E, 8'h30, 8'h30, 8'h1B, 8'h02, 8'hCF, 8'h00, 8'h14, 8'h00, 8'hFF};
    return t[k];
  endfunction
  logic ok;
  integer n, cnt;

  // the stream: send a packet, compare what comes out one clock later
  logic [7:0] pin [0:187];
  logic [7:0] pout [$];
  logic       sop [$];
  always @(posedge clk) if (mv) begin pout.push_back(md); sop.push_back(ms); end
  task automatic ts_pkt(input logic scr, input logic gaps);
    pout.delete(); sop.delete();
    for (int i = 0; i < 188; i++) begin
      pin[i] = (i == 0) ? 8'h47 : (i == 3) ? (scr ? 8'hD3 : 8'h13) : 8'(i * 31 + 7);
      @(negedge clk); td = pin[i]; tv = 1; tst = (i == 0);
      if (gaps && i == 90) begin @(negedge clk); tv = 0; tst = 0; end
    end
    @(negedge clk); tv = 0; tst = 0; td = 0;
    idle(3);
  endtask

  initial begin
    repeat (3) @(posedge clk);
    rst_n = 1;
    idle(2);
    chk(cd_n === 1'b0, "card detect low");
    chk(ireq_n === 1'b0 && wait_n === 1'b1 && di === 8'h00 && md === 8'h00 && !mv, "VCC off: outputs idle");
    cyc(0, 15'd0, 0); chk(rd === 8'h00, "VCC off: no data");
    // power up: READY RDY_DLY clocks after RESET falls
    @(negedge clk); vcc = 1; idle(3);
    @(negedge clk); rs = 1; idle(10);
    chk(ireq_n === 1'b0, "READY low in RESET");
    @(negedge clk); rs = 0;
    cnt = 0;
    while (!ireq_n && cnt < 100) begin cyc(0, 15'd0, 0); cnt = cnt + 1; if (!ireq_n) chk(rd === 8'h00, "not ready: no data"); end
    chk(ireq_n === 1'b1, "READY after RESET");
    @(negedge clk); rs = 1; @(negedge clk); rs = 0; cnt = 0;
    while (!ireq_n) begin @(posedge clk); #1; cnt = cnt + 1; end
    chk(cnt == 20, "READY 20 clocks after RESET");
    // the CIS, odd addresses, beyond it, common memory, I/O in memory mode
    ok = 1;
    for (int k = 0; k < 57; k++) begin cyc(0, 15'(2 * k), 0); if (rd !== cisb(k)) ok = 0; end
    chk(ok, "CIS bytes at even addresses");
    cyc(0, 15'd1, 0); chk(rd === 8'hFF, "odd attribute address FF");
    cyc(0, 15'd114, 0); chk(rd === 8'hFF, "past the CIS FF");
    cyc(0, 15'h7FFE, 0); chk(rd === 8'hFF, "top of attribute memory FF");
    cyc(4, 15'd0, 0); chk(rd === 8'hFF, "common memory FF");
    chk(nwait == 2, "WAIT# low for 2 clocks of the strobe");
    cyc(2, 15'd1, 0); chk(rd === 8'h00, "I/O read in memory mode: not driven");
    cyc(0, 15'h0FFE, 0); chk(rd === 8'h00, "COR 00 after RESET");
    // read-only CIS; common writes ignored
    cyc(1, 15'd4, 8'h55); cyc(0, 15'd4, 0); chk(rd === 8'h00, "CIS not writable");
    cyc(5, 15'h0FFE, 8'h0F); cyc(0, 15'h0FFE, 0); chk(rd === 8'h00, "common-memory write is not the COR");
    // COR
    cyc(1, 15'h0FFE, 8'h01); cyc(0, 15'h0FFE, 0); chk(rd === 8'h01, "COR read back");
    st_rd(); chk(rd === 8'h00, "COR 01: still memory mode");
    chk(ireq_n === 1'b1, "memory mode: READY on IREQ#");
    cyc(1, 15'h0FFC, 8'h0F); st_rd(); chk(rd === 8'h00, "a write next to the COR is not the COR");
    cyc(1, 15'h0FFE, 8'h4F); st_rd(); chk(rd === 8'h40, "COR 4F: I/O mode, FR");
    cyc(1, 15'h0FFE, 8'h0E); st_rd(); chk(rd === 8'h00, "COR 0E leaves I/O mode");
    cyc(1, 15'h0FFE, 8'h0F); st_rd(); chk(rd === 8'h40, "COR 0F: I/O mode");
    // memory-mode reads still work in I/O mode
    cyc(0, 15'd2, 0); chk(rd === 8'h04, "attribute read in I/O mode");
    // interface reset
    cmd(8'h08); st_rd(); chk(rd === 8'h00, "RS: FR low");
    cmd(8'h00); cnt = 0;
    st_rd(); chk(rd === 8'h00, "FR still low just after RS");
    idle(10); st_rd(); chk(rd === 8'h40, "FR back after RS_DLY");
    // buffer size
    cmd(8'h04); st_rd(); chk(rd === 8'h80, "SR: DA, FR low");
    cyc(2, 15'd2, 0); chk(rd === 8'h02, "size 2");
    cyc(2, 15'd3, 0); chk(rd === 8'h00, "size MS 0");
    cmd(8'h00);
    cyc(2, 15'd0, 0); chk(rd === 8'h00, "buffer size MS");
    st_rd(); chk(rd === 8'h80, "one byte left, FR low while a reply waits");
    cyc(2, 15'd0, 0); chk(rd === 8'h40, "buffer size LS 64");
    st_rd(); chk(rd === 8'h40, "read out: DA clear, FR");
    cyc(2, 15'd0, 0); st_rd(); chk(rd === 8'h41, "empty DATA read: RE");
    cmd(8'h08); cmd(8'h00); idle(12); st_rd(); chk(rd === 8'h40, "RS clears RE");
    // a 10-byte message and its reply
    msg_out(10, 3, 0);
    st_rd(); chk(rd === 8'h00, "processing: FR low, no DA");
    idle(16); st_rd(); chk(rd === 8'h80, "reply ready: DA");
    msg_in(); ok = nr == 10;
    for (int i = 0; i < 10; i++) if (r[i] !== ((i < 2) ? 8'(i * 13 + 3) : 8'(i * 13 + 3) ^ 8'h5A)) ok = 0;
    chk(ok, "reply: link header kept, body XOR 5A");
    st_rd(); chk(rd === 8'h40, "reply read: FR");
    // processing time: HC cleared (with DAIE) to IREQ#
    cmd(8'h01); cyc(3, 15'd2, 8'h01); cyc(3, 15'd3, 8'h00); cyc(3, 15'd0, 8'h77);
    @(negedge clk); ce = 0; rg = 0; a = 15'd1; d = 8'h80; doe = 1; clk1(); @(negedge clk); iw = 0; repeat (4) clk1();
    @(negedge clk); iw = 1; cnt = 0;
    while (ireq_n && cnt < 100) begin @(posedge clk); #1; cnt = cnt + 1; end
    @(negedge clk); ce = 1; rg = 1; doe = 0; a = 0; d = 0;
    chk(cnt == 17, "reply PROC clocks after HC is cleared");
    cmd(8'h00); msg_in(); chk(nr == 1 && r[0] === 8'h77, "1-byte message");
    // 64 bytes is the most
    msg_out(64, 9, 0); idle(20); msg_in(); chk(nr == 64 && r[63] === (8'(63 * 13 + 9) ^ 8'h5A) && r[1] === 8'(13 + 9), "64-byte message");
    msg_out(65, 1, 0); st_rd(); chk(rd === 8'h42, "65 bytes: WE");
    idle(20); st_rd(); chk(rd === 8'h42, "and no reply");
    cmd(8'h08); cmd(8'h00); idle(12); st_rd(); chk(rd === 8'h40, "RS clears WE");
    // size mismatch, DATA without HC
    msg_out(6, 1, 1); idle(20); st_rd(); chk(rd === 8'h42, "size mismatch: WE, no reply");
    cmd(8'h08); cmd(8'h00); idle(12);
    cyc(3, 15'd0, 8'h11); st_rd(); chk(rd === 8'h42, "DATA write without HC: WE");
    cmd(8'h08); cmd(8'h00); idle(12);
    cmd(8'h00); cyc(3, 15'd0, 8'h11); st_rd(); chk(rd === 8'h42, "COMMAND 00 opens no message");
    cmd(8'h08); cmd(8'h00); idle(12);
    cmd(8'h01); cyc(3, 15'd0, 8'h21); cmd(8'h01); cyc(3, 15'd0, 8'h22); cyc(3, 15'd2, 8'h02); cyc(3, 15'd3, 8'h00);
    cmd(8'h00); idle(20); msg_in(); chk(nr == 2 && r[0] === 8'h21 && r[1] === 8'h22, "HC written twice: one message");
    cmd(8'h08); cmd(8'h00); idle(12);
    // HC while FR is low: refused
    msg_out(3, 5, 0); msg_out(3, 6, 0); st_rd(); chk(rd === 8'h82, "message while FR low (reply waiting): WE");
    idle(20); msg_in(); chk(nr == 3 && r[2] === (8'(26 + 5) ^ 8'h5A), "only the first is answered");
    cmd(8'h08); cmd(8'h00); idle(12);
    // the size registers follow the reply; SR with a reply waiting does not queue the buffer size
    msg_out(5, 2, 0); idle(20); cmd(8'h04); cyc(2, 15'd2, 0); chk(rd === 8'h05, "SIZE shows the reply");
    cmd(8'h00); for (int i = 0; i < 5; i++) cyc(2, 15'd0, 0); st_rd(); chk(rd === 8'h40, "no buffer size after a reply");
    // a message of 256 + 2 bytes: SIZE_MS counts
    cmd(8'h01); cyc(3, 15'd2, 8'h02); cyc(3, 15'd3, 8'h01); cyc(3, 15'd0, 8'h01); cyc(3, 15'd0, 8'h02); cmd(8'h00);
    st_rd(); chk(rd === 8'h42, "SIZE_MS: 258 does not match 2");
    cmd(8'h08); cmd(8'h00); idle(12);
    // IREQ#
    cmd(8'h40); chk(ireq_n === 1'b0, "FRIE with FR: IREQ# low");
    cmd(8'h80); chk(ireq_n === 1'b1, "DAIE without DA: IREQ# high");
    cmd(8'h81); cyc(3, 15'd2, 8'h02); cyc(3, 15'd3, 0); cyc(3, 15'd0, 8'hAA); cyc(3, 15'd0, 8'hBB); cmd(8'h80);
    idle(20); chk(ireq_n === 1'b0, "DAIE with DA: IREQ# low");
    cmd(8'hC0); chk(ireq_n === 1'b0, "both");
    cmd(8'h00); chk(ireq_n === 1'b1, "disabled");
    for (int i = 0; i < 2; i++) cyc(2, 15'd0, 0);
    chk(rd === 8'hBB, "the reply of the IREQ message");
    // the stream
    ts_pkt(0, 0); ok = pout.size() == 188 && sop.size() == 188 && sop[0] && !sop[1];
    for (int i = 0; i < 188 && ok; i++) if (pout[i] !== pin[i]) ok = 0;
    chk(ok, "clear packet passes unchanged");
    ts_pkt(1, 1); ok = pout.size() == 188 && pout[3] === 8'h13 && pout[0] === 8'h47 && pout[2] === pin[2];
    for (int i = 4; i < 188 && ok; i++) if (pout[i] !== (pin[i] ^ 8'hC5 ^ 8'(i))) ok = 0;
    chk(ok, "scrambled packet with a gap: SC cleared, payload descrambled");
    @(negedge clk); td = 8'h47; tv = 1; tst = 1; #1;
    chk(!mv, "the stream is registered"); @(posedge clk); #1; chk(mv && ms && md === 8'h47, "and comes out after the clock");
    @(negedge clk); td = 8'h12; tst = 0; tv = 0; @(posedge clk); #1; @(posedge clk); #1; chk(!mv && md === 8'h00, "MIVAL low: data 0");
    // RESET in I/O mode with a reply waiting: everything cleared
    msg_out(4, 7, 0); idle(20);
    @(negedge clk); rs = 1; @(posedge clk); #1; chk(di === 8'h00, "RESET: no data");
    idle(2); @(negedge clk); rs = 0; idle(25);
    st_rd(); chk(rd === 8'h00, "after RESET: memory mode");
    cyc(0, 15'h0FFE, 0); chk(rd === 8'h00, "COR cleared");
    cyc(1, 15'h0FFE, 8'h0F); st_rd(); chk(rd === 8'h40, "I/O mode again, no reply left");
    cyc(2, 15'd0, 0); chk(rd === 8'h00, "DATA empty");
    msg_out(3, 8, 0); idle(20); msg_in(); chk(nr == 3 && r[2] === (8'(26 + 8) ^ 8'h5A), "a message right after RESET");
    // the cycle uses the address and data of the strobe's last clock, not what follows it
    cmd(8'h08); cmd(8'h00); idle(12);
    @(negedge clk); ce = 0; rg = 0; a = 15'd1; d = 8'h40; doe = 1; clk1();
    @(negedge clk); iw = 0; repeat (5) clk1();
    @(negedge clk); iw = 1; a = 15'd0; d = 8'h99; clk1();
    @(negedge clk); ce = 1; rg = 1; doe = 0; a = 0; d = 0;
    chk(ireq_n === 1'b0, "COMMAND written from the strobe's address (FRIE)");
    cmd(8'h00); cyc(2, 15'd0, 0); st_rd(); chk(rd === 8'h41, "and no DATA write");
    cmd(8'h08); cmd(8'h00); idle(12);
    // power off (with SR set, the stream running)
    cmd(8'h04); msg_in();
    cmd(8'h04);
    ts_pkt(1, 0);
    @(negedge clk); vcc = 0; td = 8'h47; tv = 1; tst = 1; idle(3);
    chk(!mv && md === 8'h00 && ireq_n === 1'b0, "VCC off: no stream, no READY");
    @(negedge clk); tv = 0; tst = 0; vcc = 1; idle(25);
    st_rd(); chk(rd === 8'h00, "power cycle: memory mode");
    cyc(1, 15'h0FFE, 8'h0F); cmd(8'h04); st_rd(); chk(rd === 8'h80, "SR after power: buffer size");
    cmd(8'h00); msg_in(); cyc(1, 15'h0FFE, 8'h00);
    cyc(0, 15'h0FFE, 0); chk(rd === 8'h00, "COR cleared by power");
    // setup / strobe / hold variety: the CAM answers the same
    sup = 3; stb = 5; hld = 2; cyc(0, 15'd30, 0); chk(rd === cisb(15), "long cycle");
    sup = 0; stb = 0; hld = 0; cyc(0, 15'd30, 0); chk(rd === cisb(15), "short strobe: WAIT# stretches it");
    chk(nwait == 2, "WAIT# 2 clocks");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
