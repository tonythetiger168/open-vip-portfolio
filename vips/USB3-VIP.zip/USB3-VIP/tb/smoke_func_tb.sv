// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the USB 3.2 link-layer device model
// usb3_smoke_model (tb/usb3_smoke_model.sv). The bench plays the
// downstream (host) port: LFPS and TS1/TS2 training, header packets with
// CRC-16 / CRC-5 and HdrSeq, link commands (LGOOD_n, LCRD_x, LRTY, LBAD,
// LGO_Ux, LPMA), LMPs, ITP, TP, DPH + DPP with CRC-32, Gen2 block headers.
// It records every link command and header the device sends and compares
// them, in order, with what the USB 3.2 link layer requires.
// Run: python3 tools/run_func_tests.py USB3-VIP

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic         clk = 1'b0, rst_n = 1'b0;
  logic         far = 1'b0, lfps = 1'b0, g2cap = 1'b0;
  logic         rx_valid = 1'b0, ts_rst = 1'b0, rx_last = 1'b0;
  logic [2:0]   rx_kind = 3'd0;
  logic [127:0] rx_hdr = 128'h0;
  logic [15:0]  rx_lc = 16'h0;
  logic [31:0]  rx_dw = 32'h0;
  logic [3:0]   rx_blk = 4'h0;
  logic         busy = 1'b0;
  wire  [3:0]   ltssm;
  wire          gen2, lc_v, hp_v, force_pm;
  wire  [15:0]  lc_w;
  wire  [127:0] hp_w;
  wire  [2:0]   rx_free, tx_cred;
  wire  [7:0]   hp_good, hp_bad, rec_cnt, dpp_good, dpp_bad, tp_mine, itp_cnt, u2_tmo, blk_fix, blk_drop;
  wire  [26:0]  itp_ts;

  always #5 clk = ~clk;

  usb3_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .far_end_ready(far), .lfps(lfps), .gen2_cap(g2cap),
    .rx_valid(rx_valid), .rx_kind(rx_kind), .rx_ts_reset(ts_rst), .rx_hdr(rx_hdr),
    .rx_lc(rx_lc), .rx_dw(rx_dw), .rx_last(rx_last), .rx_blk(rx_blk), .app_busy(busy),
    .ltssm(ltssm), .gen2(gen2), .tx_lc_valid(lc_v), .tx_lc(lc_w), .tx_hp_valid(hp_v),
    .tx_hp(hp_w), .rx_free(rx_free), .tx_credits(tx_cred), .hp_good(hp_good), .hp_bad(hp_bad),
    .rec_cnt(rec_cnt), .dpp_good(dpp_good), .dpp_bad(dpp_bad), .tp_mine(tp_mine),
    .itp_cnt(itp_cnt), .itp_ts(itp_ts), .u2_tmo(u2_tmo), .force_pm(force_pm),
    .blk_fix(blk_fix), .blk_drop(blk_drop)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  localparam logic [3:0] RXDET = 0, PLFPS = 1, PACT = 2, PCFG = 3, U0 = 4, U1 = 5, U2 = 6, U3 = 7,
                         RACT = 8, RCFG = 9, HRST = 10;
  localparam logic [2:0] TS1 = 0, TS2 = 1, HP = 2, LC = 3, DPP = 4;

  // ------------------------------------------------------------ encodings
  function automatic logic [4:0] crc5(input logic [10:0] d);
    logic [4:0] c;
    c = 5'h1F;
    for (int i = 0; i < 11; i++) c = (c[4] ^ d[i]) ? ({c[3:0], 1'b0} ^ 5'h05) : {c[3:0], 1'b0};
    return ~c;
  endfunction
  function automatic logic [15:0] crc16(input logic [95:0] d);
    logic [15:0] c;
    c = 16'hFFFF;
    for (int i = 0; i < 96; i++) c = (c[15] ^ d[i]) ? ({c[14:0], 1'b0} ^ 16'h100B) : {c[14:0], 1'b0};
    return ~c;
  endfunction
  function automatic logic [31:0] crc32(input logic [31:0] c0, input logic [31:0] d);
    logic [31:0] c;
    c = c0;
    for (int i = 0; i < 32; i++) c = (c[31] ^ d[i]) ? ({c[30:0], 1'b0} ^ 32'h04C1_1DB7) : {c[30:0], 1'b0};
    return c;
  endfunction
  function automatic logic [15:0] lcw(input logic [1:0] cls, input logic [1:0] typ, input logic [3:0] sub);
    return {crc5({cls, typ, 3'b000, sub}), cls, typ, 3'b000, sub};
  endfunction
  function automatic logic [15:0] G(input int n);   return lcw(2'b00, 2'b00, 4'(n % 8)); endfunction
  function automatic logic [15:0] CR(input int x);  return lcw(2'b00, 2'b01, 4'(x % 4)); endfunction
  function automatic logic [15:0] RTY();            return lcw(2'b00, 2'b10, 4'd0); endfunction
  function automatic logic [15:0] BAD();            return lcw(2'b00, 2'b11, 4'd0); endfunction
  function automatic logic [15:0] GO(input int x);  return lcw(2'b01, 2'b00, 4'(x)); endfunction
  function automatic logic [15:0] LAU();            return lcw(2'b01, 2'b01, 4'd0); endfunction
  function automatic logic [15:0] LXU();            return lcw(2'b01, 2'b10, 4'd0); endfunction
  function automatic logic [15:0] LPMA();           return lcw(2'b01, 2'b11, 4'd0); endfunction
  function automatic logic [127:0] seal(input logic [95:0] h, input int seq);
    logic [10:0] l;
    l = {8'h00, 3'(seq)};
    return {crc5(l), l, crc16(h), h};
  endfunction
  // header bodies
  function automatic logic [95:0] lmp(input int sub, input logic [7:0] f, input logic [31:0] dw1 = 0);
    return {32'h0, dw1, 15'h0, f, 4'(sub), 5'b00000};
  endfunction
  function automatic logic [95:0] tp(input logic [6:0] a);   return {64'h0, a, 20'h0, 5'b00100}; endfunction
  function automatic logic [95:0] itp(input logic [26:0] t); return {64'h0, t, 5'b01100}; endfunction
  function automatic logic [95:0] dph(input logic [15:0] len); return {32'h0, len, 16'h0, 32'h0000_0008}; endfunction
  function automatic logic [95:0] dev_cap(input bit g2);
    return {32'h0, 14'h0, 2'b01, 8'h00, 8'h04, 15'h0, g2 ? 8'h03 : 8'h01, 4'd4, 5'b00000};
  endfunction

  // ------------------------------------------------------- capture
  logic [15:0]  lc_q [$];
  logic [127:0] hp_q [$];
  always @(posedge clk) begin
    if (lc_v === 1'b1) lc_q.push_back(lc_w);
    if (hp_v === 1'b1) hp_q.push_back(hp_w);
  end

  logic [15:0] ex [$];
  int rc = 0;                                  // LCRD index the device sends next
  task automatic e(input logic [15:0] w); ex.push_back(w); endtask
  task automatic ecr(); ex.push_back(CR(rc)); rc++; endtask
  // drop what was captured, keeping the LCRD index in step
  task automatic flush();
    logic [15:0] w;
    foreach (lc_q[i]) begin w = lc_q[i]; if (w[10:7] == 4'b0001) rc++; end
    lc_q.delete();
  endtask
  // check a stretch of link commands whose interleaving depends on timing:
  // the LCRDs keep their order, the rest are listed in want order
  task automatic expect_mixed(input string tag, input int n_lcrd);
    bit ok;
    int j;
    logic [15:0] w;
    ok = 1; j = 0;
    foreach (lc_q[i]) begin
      w = lc_q[i];
      if (w[10:7] == 4'b0001) begin
        if (lc_q[i] !== CR(rc)) ok = 0;
        rc++; n_lcrd--;
      end
      else begin
        if (j >= ex.size() || lc_q[i] !== ex[j]) ok = 0;
        j++;
      end
    end
    chk(ok && j == ex.size() && n_lcrd == 0, $sformatf("%s (%0d commands)", tag, lc_q.size()));
    if (!ok || j != ex.size() || n_lcrd != 0) foreach (lc_q[i]) $display("     got  %04h", lc_q[i]);
    lc_q.delete(); ex.delete();
  endtask
  task automatic expect_lc(input string tag);
    bit ok;
    ok = lc_q.size() == ex.size();
    for (int i = 0; ok && i < ex.size(); i++) if (lc_q[i] !== ex[i]) ok = 0;
    chk(ok, $sformatf("%s: link commands (got %0d, want %0d)", tag, lc_q.size(), ex.size()));
    if (!ok) begin
      foreach (lc_q[i]) $display("     got  %04h", lc_q[i]);
      foreach (ex[i])   $display("     want %04h", ex[i]);
    end
    lc_q.delete(); ex.delete();
  endtask
  task automatic expect_hp(input string tag, input logic [95:0] h, input int seq);
    chk(hp_q.size() == 1 && hp_q[0] === seal(h, seq),
        $sformatf("%s: one header, HdrSeq %0d, CRC-16 and CRC-5 (got %0d)", tag, seq, hp_q.size()));
    hp_q.delete();
  endtask

  // ------------------------------------------------------- stimulus
  logic [3:0] blk_ts = 4'b0011, blk_pk = 4'b1100;
  task automatic idle(input int n); repeat (n) @(negedge clk); endtask
  // each item takes one clock; call at a negedge, returns at the next
  task automatic item_end();
    @(negedge clk);
    rx_valid = 1'b0; ts_rst = 1'b0; rx_last = 1'b0;
  endtask
  task automatic ts(input logic [2:0] k, input bit rst = 0, input logic [3:0] b = 4'hF);
    rx_valid = 1'b1; rx_kind = k; ts_rst = rst; rx_blk = (b == 4'hF) ? blk_ts : b;
    item_end();
  endtask
  task automatic hp(input logic [127:0] w, input logic [3:0] b = 4'hF);
    rx_valid = 1'b1; rx_kind = HP; rx_hdr = w; rx_blk = (b == 4'hF) ? blk_pk : b;
    item_end();
  endtask
  task automatic lc(input logic [15:0] w, input logic [3:0] b = 4'hF);
    rx_valid = 1'b1; rx_kind = LC; rx_lc = w; rx_blk = (b == 4'hF) ? blk_pk : b;
    item_end();
  endtask
  task automatic dw(input logic [31:0] w, input bit last, input logic [3:0] b = 4'hF);
    rx_valid = 1'b1; rx_kind = DPP; rx_dw = w; rx_last = last; rx_blk = (b == 4'hF) ? blk_pk : b;
    item_end();
  endtask
  task automatic burst(input bit g2);
    lfps = 1'b1; g2cap = g2; @(negedge clk); lfps = 1'b0; g2cap = 1'b0;
  endtask
  task automatic train(input bit g2);
    far = 1'b1; idle(2);
    repeat (4) begin burst(g2); idle(1); end
    repeat (8) ts(TS1);
    repeat (8) ts(TS2);
  endtask
  task automatic recover();
    repeat (8) ts(TS1);
    repeat (8) ts(TS2);
  endtask

  // the host side of the link: next HdrSeq to send, next LCRD to give
  int hseq = 0, hcrd = 0, dseq = 0, dcrd = 0;
  // send a good header with the next HdrSeq; the device answers LGOOD and,
  // 4 clocks later, LCRD
  task automatic hdr(input logic [95:0] h);
    hp(seal(h, hseq)); hseq++;
  endtask
  task automatic give_credit(); lc(CR(hcrd)); hcrd++; endtask
  task automatic ack(); lc(G(dseq)); dseq++; endtask

  int k, n0, t;
  logic [31:0] c, pay [0:7];

  initial begin
    idle(2);
    chk(ltssm === RXDET && rx_free === 3'd4 && tx_cred === 3'd0 && lc_v === 1'b0 && hp_v === 1'b0 &&
        gen2 === 1'b0 && hp_good === 8'd0 && rec_cnt === 8'd0, "in reset: RxDetect, outputs cleared");
    rst_n = 1'b1;
    idle(5);
    chk(ltssm == RXDET, "no far-end termination: stays in RxDetect");

    // ---------------- Polling.LFPS timeout
    far = 1'b1; idle(2);
    chk(ltssm == PLFPS, "far-end termination: Polling.LFPS");
    repeat (3) begin burst(1); idle(1); end
    chk(ltssm == PLFPS, "3 LFPS bursts are not enough");
    idle(126);
    chk(ltssm == PLFPS, "Polling.LFPS waits 128 clocks");
    idle(1);
    chk(ltssm == RXDET, "Polling.LFPS timeout: back to RxDetect");

    // ---------------- Polling: Gen1 (one burst without SCD2)
    idle(2);
    burst(1); idle(1); burst(1); idle(1); burst(0); idle(1); burst(1); idle(1);
    chk(ltssm == PACT && gen2 === 1'b0, "4 bursts, one without SCD2: Polling.Active at Gen1");
    repeat (7) ts(TS1);
    chk(ltssm == PACT, "7 TS1 stay in Polling.Active");
    ts(TS2);
    chk(ltssm == PCFG, "8 TS1/TS2: Polling.Configuration");
    repeat (4) ts(TS1);
    chk(ltssm == PCFG, "TS1 does not count in Polling.Configuration");
    repeat (7) ts(TS2);
    chk(ltssm == PCFG && lc_q.size() == 0, "7 TS2 stay in Polling.Configuration");
    ts(TS2);
    chk(ltssm == U0, "8 TS2: U0");
    idle(7);
    e(G(7)); ecr(); ecr(); ecr(); ecr();
    expect_lc("U0 entry after Polling: LGOOD_7 and LCRD_A..D");
    chk(hp_q.size() == 0 && rx_free == 3'd4, "no header without a credit; 4 free buffers");

    // ---------------- device Port Capability needs a credit, then LGOOD
    give_credit();
    idle(1);
    expect_hp("Port Capability LMP after Polling", dev_cap(0), 0);
    chk(tx_cred == 3'd0, "the header used the credit");
    idle(3);
    chk(ltssm == U0, "LGOOD outstanding for 4 clocks: still U0");
    lc(G(3));
    idle(1);
    chk(ltssm == RACT && rec_cnt == 8'd1, "LGOOD_3 for header 0: Recovery");
    recover();
    chk(ltssm == U0, "Recovery.Active 8 TS + Recovery.Configuration 8 TS2: U0");
    idle(7);
    e(G(7)); ecr(); ecr(); ecr(); ecr();
    expect_lc("U0 entry after Recovery: same advertisement, LCRD indices continue mod 4");
    lc(G(7));                                           // the host advertisement: nothing received
    give_credit();                                      // LCRD indices continue across Recovery
    idle(1);
    expect_hp("not acknowledged: resent after Recovery", dev_cap(0), 0);
    ack();
    idle(2);
    chk(ltssm == U0 && hp_q.size() == 0, "LGOOD_0 acknowledges it");
    lc(G(0));
    idle(1);
    chk(ltssm == U0, "repeated LGOOD of the last acknowledged header is ignored");

    // ---------------- receive: LGOOD, buffer, LCRD 4 clocks later
    hdr(lmp(4, 8'h01, 32'h0001_0004));                  // host Port Capability
    chk(rx_free == 3'd3, "a good header takes a buffer");
    idle(3);
    chk(rx_free == 3'd3, "buffer still busy 3 clocks later");
    idle(1);
    chk(rx_free == 3'd4, "freed 4 clocks after it arrived");
    idle(3);
    e(G(0)); ecr();
    expect_lc("Port Capability: LGOOD_0 then LCRD_A");

    // Port Configuration -> Port Configuration Response (accept 5G)
    hdr(lmp(5, 8'h01));
    idle(1);
    chk(hp_q.size() == 0, "the response waits for a credit");
    give_credit();
    idle(1);
    expect_hp("Port Configuration Response: accept", lmp(6, 8'h01), 1);
    ack();
    idle(6);
    e(G(1)); ecr();
    expect_lc("Port Configuration: LGOOD_1, LCRD_B");
    // 10G requested on a Gen1 link: reject
    hdr(lmp(5, 8'h02));
    give_credit();
    idle(1);
    expect_hp("Port Configuration Response: reject 10G on Gen1", lmp(6, 8'h00), 2);
    ack();
    idle(6);
    e(G(2)); ecr();
    expect_lc("LGOOD_2, LCRD_C");

    // ---------------- bad CRC-16 / CRC-5: LBAD, ignore until LRTY
    rx_hdr = seal(tp(7'd5), hseq); rx_hdr[20] = ~rx_hdr[20];
    hp(rx_hdr);
    chk(hp_bad == 8'd1 && rx_free == 3'd4, "CRC-16 error: no buffer");
    hp(seal(tp(7'd5), hseq));
    chk(hp_good == 8'd3 && rx_free == 3'd4, "headers after LBAD are dropped until LRTY");
    lc(RTY());
    hdr(tp(7'd5));
    idle(6);
    e(BAD()); e(G(3)); ecr();
    expect_lc("LBAD once, then LGOOD_3 after LRTY");
    chk(tp_mine == 8'd1, "TP for this device counted");
    rx_hdr = seal(tp(7'd5), hseq); rx_hdr[125] = ~rx_hdr[125];
    hp(rx_hdr);
    rx_hdr[125] = ~rx_hdr[125]; rx_hdr[113] = ~rx_hdr[113];
    hp(rx_hdr);
    lc(RTY());
    hdr(tp(7'd9));
    idle(6);
    e(BAD()); e(G(4)); ecr();
    expect_lc("CRC-5 and link-control-word errors: one LBAD");
    chk(hp_bad == 8'd3 && tp_mine == 8'd1, "TP for another address not counted");

    // a link command with a bad CRC-5 is ignored
    rx_lc = lcw(2'b01, 2'b00, 4'd3); rx_lc[15] = ~rx_lc[15];
    lc(rx_lc);
    idle(3);
    chk(lc_q.size() == 0 && ltssm == U0, "link command with a bad CRC-5 ignored");

    // ---------------- ITP, DPH + DPP
    hdr(itp(27'h5A5_A5A5));
    idle(6);
    chk(itp_cnt == 8'd1 && itp_ts == 27'h5A5_A5A5, "ITP timestamp latched");
    e(G(5)); ecr();
    expect_lc("ITP: LGOOD_5");
    for (k = 0; k < 8; k++) pay[k] = 32'h1111_1111 * k + 32'h0102_0304;
    hdr(dph(16'd32));
    c = 32'hFFFF_FFFF;
    for (k = 0; k < 8; k++) begin dw(pay[k], 0); c = crc32(c, pay[k]); end
    dw(~c, 1);
    idle(1);
    chk(dpp_good == 8'd1 && dpp_bad == 8'd0, "DPP: CRC-32 and length match the DPH");
    hdr(dph(16'd32));
    for (k = 0; k < 8; k++) dw(pay[k], 0);
    dw(c, 1);
    idle(1);
    chk(dpp_good == 8'd1 && dpp_bad == 8'd1, "DPP with a bad CRC-32");
    hdr(dph(16'd28));
    for (k = 0; k < 8; k++) dw(pay[k], 0);
    dw(~c, 1);
    idle(1);
    chk(dpp_bad == 8'd2, "DPP length differs from the DPH");
    dw(32'h0, 1);
    idle(1);
    chk(dpp_bad == 8'd3, "DPP without a DPH");
    idle(6);
    e(G(6)); ecr(); e(G(7)); ecr(); e(G(0)); ecr();
    expect_lc("DPH x3: LGOOD_6, 7, 0 (HdrSeq wraps)");

    // ---------------- overrun: 4 buffers
    for (k = 0; k < 4; k++) hdr(tp(7'd1));
    chk(rx_free == 3'd0, "4 headers in 4 clocks: no buffer free yet");
    hdr(tp(7'd1));
    chk(ltssm == U0 && rx_free == 3'd0, "5th header takes the buffer freed in the same clock");
    n0 = rec_cnt;
    hdr(tp(7'd1));
    chk(ltssm == RACT && rec_cnt == 8'(n0 + 1), "header with no free buffer: Recovery");
    hseq--;                                              // that one was not taken
    t = 0;
    while (rx_free != 3'd4 && t < 40) begin idle(1); t++; end
    recover();
    idle(10);
    for (k = 5; k > 0; k--) e(G(hseq - k));
    e(G(hseq - 1));
    expect_mixed("5 LGOODs, LCRDs for the buffers freed in U0, then the advertisement", 1 + 4);
    lc(G(dseq - 1));

    // ---------------- buffers held by the protocol layer across Recovery
    busy = 1'b1;
    hdr(tp(7'd2)); hdr(tp(7'd2));
    idle(20);
    chk(rx_free == 3'd2, "app_busy: the 2 buffers stay taken");
    e(G(hseq - 2)); e(G(hseq - 1));
    expect_lc("app_busy: LGOOD only, no LCRD");
    ts(TS1);
    recover();
    idle(7);
    e(G(hseq - 1)); ecr(); ecr();
    expect_lc("advertisement: LCRD only for the 2 free buffers");
    lc(G(dseq - 1));
    busy = 1'b0;
    idle(9);
    ecr(); ecr();
    expect_lc("released after app_busy drops: 2 LCRDs, 4 clocks apart");

    // ---------------- out-of-sequence header
    hp(seal(tp(7'd5), hseq + 1));
    chk(ltssm == RACT, "HdrSeq out of order: Recovery");
    recover();
    idle(7);
    e(G(hseq - 1)); ecr(); ecr(); ecr(); ecr();
    expect_lc("advertisement after the bad HdrSeq");
    lc(G(dseq - 1));
    hdr(tp(7'd5));
    idle(6);
    e(G(hseq - 1)); ecr();
    expect_lc("the expected HdrSeq is accepted again");

    // ---------------- LCRD order and credit limit
    lc(CR(hcrd + 1));
    chk(ltssm == RACT, "LCRD out of order: Recovery");
    recover(); idle(7); flush(); lc(G(dseq - 1));
    for (k = 0; k < 4; k++) give_credit();
    chk(tx_cred == 3'd4 && ltssm == U0, "4 credits");
    give_credit();
    chk(ltssm == RACT, "a 5th credit: Recovery");
    hcrd--;
    recover(); idle(7); flush(); lc(G(dseq - 1));

    // ---------------- transmit retry: LBAD -> LRTY + resend
    hdr(lmp(5, 8'h01));                                  // device queues a response
    idle(6); flush();
    give_credit();
    idle(1);
    expect_hp("response sent", lmp(6, 8'h01), dseq);
    lc(BAD());
    idle(1);
    chk(hp_q.size() == 0 && tx_cred == 3'd1, "LBAD: the credit comes back, LRTY first");
    idle(2);
    expect_hp("LBAD: resent with the same HdrSeq", lmp(6, 8'h01), dseq);
    e(RTY());
    expect_lc("LRTY before the resend");
    ack();
    // pending-header timer
    hdr(lmp(5, 8'h01));
    give_credit();
    idle(1);
    expect_hp("another response", lmp(6, 8'h01), dseq);
    idle(60);
    chk(ltssm == U0, "62 clocks without LGOOD: still U0");
    idle(4);
    chk(ltssm == RACT, "64 clocks without LGOOD: Recovery");
    recover(); idle(7); flush();
    lc(G(dseq));                                         // the host did receive it
    give_credit();
    idle(3);
    chk(hp_q.size() == 0, "the advertisement acknowledged it: nothing resent");
    dseq++;

    // ---------------- link power management
    lc(GO(1));
    idle(2);
    e(LXU());
    expect_lc("LGO_U1 without Force_LinkPM_Accept: LXU");
    hdr(lmp(1, 8'h00) | 96'h400);                       // Set Link Function, Force_LinkPM_Accept
    hdr(lmp(2, 8'h02));                                  // U2 inactivity timeout = 2
    idle(8); flush();
    chk(force_pm && u2_tmo == 8'd2, "Set Link Function and U2 Inactivity Timeout LMPs");
    lc(GO(1));
    idle(2);
    e(LAU());
    expect_lc("LGO_U1 with Force_LinkPM_Accept: LAU");
    lc(LPMA());
    chk(ltssm == U1, "LPMA: U1");
    idle(47);
    chk(ltssm == U1, "U1 for 47 clocks");
    idle(1);
    chk(ltssm == U2, "U2 inactivity timeout 2: U2 after (2 + 1) x 16 clocks");
    burst(0);
    chk(ltssm == RACT, "LFPS exits U2 through Recovery");
    recover(); idle(7); flush(); lc(G(dseq - 1));
    lc(GO(3));
    idle(2);
    lc(LPMA());
    chk(ltssm == U3, "LGO_U3, LAU, LPMA: U3");
    idle(100);
    chk(ltssm == U3, "U3 does not time out");
    burst(0);
    recover(); idle(7); flush(); lc(G(dseq - 1));
    lc(GO(2));
    idle(31);
    chk(ltssm == U0, "LAU without LPMA for 31 clocks: U0");
    idle(2);
    chk(ltssm == RACT, "no LPMA 32 clocks after LAU: Recovery");
    recover(); idle(7); flush(); lc(G(dseq - 1));
    hdr(lmp(5, 8'h01));                                  // a header waiting for LGOOD
    idle(6);
    flush();
    lc(GO(2));
    idle(2);
    e(LXU());
    expect_lc("LGO_U2 with a header waiting: LXU");
    give_credit(); idle(1); hp_q.delete(); ack();
    lc(GO(0));
    idle(2);
    chk(lc_q.size() == 0, "LGO_U0 is not a request");
    lc(LPMA());
    idle(2);
    chk(ltssm == U0 && lc_q.size() == 0, "LPMA without LAU is ignored");
    lc(LXU());
    chk(ltssm == U0, "a power-management command other than LPMA does not enter Ux");
    // DPP cut by Recovery: the next lone DPP word has no DPH
    n0 = dpp_bad;
    hdr(dph(16'd16));
    dw(pay[0], 0); dw(pay[1], 0);
    ts(TS1);
    recover(); idle(7); flush(); lc(G(dseq - 1));
    dw(32'h0, 0);
    idle(1);
    chk(dpp_bad == 8'(n0 + 1), "Recovery ends the DPP: a later DPP word has no DPH");
    dw(32'h0, 1);
    idle(1);
    chk(dpp_bad == 8'(n0 + 2), "and neither has its CRC word");
    // LGOOD for a header the device never sent
    hdr(lmp(5, 8'h01));
    idle(6); flush();
    give_credit();
    idle(1); hp_q.delete();
    lc(G(dseq + 1));
    chk(ltssm == RACT, "LGOOD beyond the headers sent: Recovery");
    recover(); idle(7); flush();
    lc(G(dseq));                                         // advertisement acknowledges it
    dseq++;
    idle(2);

    // ---------------- Hot Reset
    ts(TS1);
    chk(ltssm == RACT, "TS1 in U0: Recovery");
    ts(TS1, 1);
    chk(ltssm == HRST, "TS1 with Hot Reset: Hot Reset");
    ts(TS2, 1);
    idle(3);
    chk(ltssm == HRST, "TS2 with Hot Reset still set");
    ts(TS2, 0);
    chk(ltssm == U0, "TS2 without Hot Reset: U0");
    rc = 0;
    idle(7);
    e(G(7)); ecr(); ecr(); ecr(); ecr();
    expect_lc("Hot Reset: HdrSeq and credits restart");
    hseq = 0; hcrd = 0; dseq = 0;
    hdr(tp(7'd5));
    idle(6);
    e(G(0)); ecr();
    expect_lc("HdrSeq 0 after Hot Reset");

    // ---------------- Recovery timeout
    ts(TS1);
    idle(127);
    chk(ltssm == RACT, "Recovery.Active waits 128 clocks");
    idle(1);
    chk(ltssm == RXDET, "Recovery timeout: RxDetect");

    // ---------------- Gen2: block headers
    far = 1'b0; idle(2); flush(); hp_q.delete();
    train(1);
    chk(ltssm == U0 && gen2 === 1'b1, "every burst with SCD2: Gen2");
    hseq = 0; hcrd = 0; dseq = 0;
    give_credit();                                       // in the first U0 clock
    chk(hp_v === 1'b1, "a credit in the first U0 clock sends the header in that clock");
    rc = 0;
    idle(7);
    e(G(7)); ecr(); ecr(); ecr(); ecr();
    expect_lc("Gen2 U0 entry");
    expect_hp("Gen2 Port Capability (5G and 10G)", dev_cap(1), 0);
    ack();
    hdr(lmp(4, 8'h03));
    hdr(lmp(5, 8'h02));
    give_credit();
    idle(1);
    expect_hp("10G accepted on Gen2", lmp(6, 8'h01), 1);
    ack();
    idle(8); flush();
    n0 = blk_fix; t = tp_mine;
    hp(seal(tp(7'd5), hseq), 4'b1101); hseq++;          // 1 bit off: corrected
    hp(seal(tp(7'd5), hseq), 4'b1010);                  // 2 bits off: dropped
    hp(seal(tp(7'd5), hseq), 4'b0011);                  // control block: dropped
    hp(seal(tp(7'd5), hseq)); hseq++;
    idle(8);
    chk(blk_fix == 8'(n0 + 1) && blk_drop == 8'd2 && tp_mine == 8'(t + 2),
        $sformatf("Gen2: 1-bit block header corrected, 2-bit and wrong-kind blocks dropped (%0d %0d %0d st%0d free%0d)", blk_fix-n0, blk_drop, tp_mine, ltssm, rx_free));
    e(G(2)); e(G(3));
    expect_mixed("dropped blocks are not acknowledged", 2);
    ts(TS1, 0, 4'b1100);
    chk(ltssm == U0, "TS1 in a data block: dropped");
    ts(TS1, 0, 4'b0111);
    chk(ltssm == RACT, "TS1 with a 1-bit control header: corrected, Recovery");
    recover(); idle(7); flush(); lc(G(dseq - 1));
    hdr(dph(16'd8));
    dw(pay[0], 0); dw(pay[1], 0, 4'b0000);
    c = crc32(crc32(32'hFFFF_FFFF, pay[0]), pay[1]);
    dw(~c, 1);
    idle(1);
    chk(dpp_bad == 8'd6, "Gen2: a DPP word in a dropped block spoils the DPP");
    hdr(dph(16'd8));
    dw(pay[0], 0); dw(pay[1], 0, 4'b1110);
    dw(~c, 1);
    idle(1);
    chk(dpp_good == 8'd2, "Gen2: a corrected block keeps the DPP");
    hdr(dph(16'd4));
    dw(pay[0], 0); dw(pay[1], 0, 4'b0000);
    dw(~crc32(32'hFFFF_FFFF, pay[0]), 1);
    idle(1);
    chk(dpp_bad == 8'd7 && dpp_good == 8'd2, "Gen2: a dropped DPP word spoils it even when length and CRC fit the rest");

    // ---------------- reset in the middle
    rst_n = 1'b0;
    idle(2);
    chk(ltssm == RXDET && gen2 === 1'b0 && rx_free == 3'd4 && hp_good == 8'd0 && dpp_good == 8'd0 &&
        itp_cnt == 8'd0 && force_pm === 1'b0 && u2_tmo == 8'd0 && blk_fix == 8'd0, "reset clears the link");
    rst_n = 1'b1;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
