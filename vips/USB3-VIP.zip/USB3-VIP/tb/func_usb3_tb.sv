// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_usb3_tb.sv -- self-checking functional test for the USB 3.x
// SuperSpeed link model (tb/usb3_smoke_model.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py USB3-VIP
//
// Model contract (from tb/usb3_smoke_model.sv), one item per rx_valid clock
// (rx_os: 0 TS1, 1 TS2, 2 header packet, 3 data packet, 6 LCRD):
//   * RxDetect -> Polling when far_end_ready; Polling needs 4 TS1 then 2 TS2
//     to reach U0, which advertises 4 header credits with an LCRD strobe.
//     Polling with no progress for 256 clocks falls back to RxDetect.
//   * U0: a good header packet is answered with LGOOD, takes a credit and
//     opens a data phase; its data packet returns the credit with LCRD.
//     A bad header (CRC) is answered with LBAD and enters Recovery. An LCRD
//     from the partner adds a credit (max 15). TS1 from the partner or 256
//     idle clocks enter Recovery.
//   * Recovery: 2 TS1/TS2 return to U0; 256 clocks without them -> RxDetect.
//   * link_state follows the internal state one clock later.

module func_usb3_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam logic [3:0] TS1 = 0, TS2 = 1, HP = 2, DP = 3, LGOOD = 4, LBAD = 5, LCRD = 6;
  localparam logic [3:0] RXDET = 0, POLL = 1, U0 = 2, RECOV = 3;
  int checks = 0, fails = 0;

  logic       clk = 1'b0, rst_n = 1'b0, rx_valid = 1'b0, crc_ok = 1'b1, far = 1'b0;
  logic [3:0] rx_os = '0;
  logic [7:0] rx_data = '0;
  wire  [3:0] lstate, tx_lc, credits;
  wire        link_up, lc_valid;
  wire  [7:0] hp_count, lbad_count;

  always #5 clk = ~clk;

  usb3_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .rx_valid(rx_valid), .rx_os(rx_os), .rx_data(rx_data),
    .rx_crc_ok(crc_ok), .far_end_ready(far), .link_state(lstate), .link_up(link_up),
    .tx_lc(tx_lc), .tx_lc_valid(lc_valid), .credit_cnt(credits), .hp_count(hp_count),
    .lbad_count(lbad_count)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // link command strobes, in order
  logic [3:0] lc_q[$];
  always @(posedge clk) if (lc_valid === 1'b1) lc_q.push_back(tx_lc);

  // send one item; returns at the following negedge
  task automatic rx(input [3:0] os, input bit ok = 1, input [7:0] d = 0);
    @(negedge clk);
    rx_valid = 1; rx_os = os; crc_ok = ok; rx_data = d;
    @(negedge clk);
    rx_valid = 0; crc_ok = 1;
  endtask

  task automatic idle(input int n); repeat (n) @(negedge clk); endtask

  task automatic train();
    repeat (4) rx(TS1);
    repeat (2) rx(TS2);
    idle(2);
  endtask

  initial begin
    idle(2);
    rst_n = 1;
    idle(3);
    chk(lstate == RXDET && !link_up && credits == 0, "RxDetect with no partner");

    // training sequence order matters
    far = 1;
    idle(3);
    chk(lstate == POLL, "far-end receiver detected: Polling");
    repeat (2) rx(TS2);
    repeat (3) rx(TS1);
    rx(TS2);
    idle(2);
    chk(lstate == POLL, "TS2 before four TS1 does not complete training");
    rx(TS1);
    rx(TS1);                                         // fifth TS1 is ignored
    rx(TS2);
    idle(2);
    chk(lstate == POLL, "one TS2 is not enough");
    lc_q.delete();
    rx(TS2);
    idle(2);
    chk(lstate == U0 && link_up, "4 TS1 + 2 TS2: link up in U0");
    chk(credits == 4 && lc_q.size() == 1 && lc_q[0] == LCRD, "U0 entry advertises 4 credits with LCRD");

    // header + data flow
    lc_q.delete();
    rx(HP); idle(1);
    chk(lc_q.size() == 1 && lc_q[0] == LGOOD && hp_count == 1, "good header ACKed with LGOOD");
    chk(credits == 3, "header consumes a credit");
    rx(DP); idle(1);
    chk(lc_q.size() == 2 && lc_q[1] == LCRD && credits == 4, "data packet returns the credit with LCRD");
    lc_q.delete();
    rx(DP); idle(1);
    chk(lc_q.size() == 0 && credits == 4, "data packet without a header is not credited");

    // credits run out
    repeat (4) rx(HP);
    idle(1);
    chk(credits == 0 && hp_count == 5, "four headers use all four credits");
    rx(HP); idle(1);
    chk(credits == 0, "credit count does not wrap below zero");
    rx(LCRD); rx(LCRD); idle(1);
    chk(credits == 2, "partner LCRDs add credits");
    repeat (20) rx(LCRD);
    idle(1);
    chk(credits == 15, "credit count saturates at 15");
    rx(HP); rx(LCRD); rx(DP); idle(1);
    chk(credits == 15, "credit returned by a data packet also saturates at 15");

    // bad header -> LBAD + Recovery, then retrain
    lc_q.delete();
    rx(HP, 0); idle(2);
    chk(lc_q.size() == 1 && lc_q[0] == LBAD && lbad_count == 1, "bad header answered with LBAD");
    chk(lstate == RECOV, "bad header enters Recovery");
    rx(TS1); idle(1);
    chk(lstate == RECOV, "one ordered set is not enough to leave Recovery");
    rx(TS2); idle(2);
    chk(lstate == U0 && link_up, "Recovery back to U0 after two ordered sets");

    // partner TS1 in U0 -> Recovery
    rx(TS1); idle(2);
    chk(lstate == RECOV, "TS1 in U0 enters Recovery");
    rx(TS1); rx(TS1); idle(2);
    chk(lstate == U0, "retrained to U0");

    // U0 idle timeout
    idle(250);
    chk(lstate == U0, "U0 holds for 250 idle clocks");
    idle(10);
    chk(lstate == RECOV && link_up, "U0 inactivity (256 clocks) enters Recovery");

    // Recovery timeout -> RxDetect, then Polling timeout
    far = 0;
    idle(260);
    chk(lstate == RXDET && !link_up, "Recovery without ordered sets times out to RxDetect");
    far = 1;
    idle(3);
    chk(lstate == POLL, "partner detected again");
    far = 0;
    idle(260);
    chk(lstate == RXDET, "Polling without training times out to RxDetect");

    // reset
    far = 1; idle(3); train();
    chk(lstate == U0, "trained again");
    @(negedge clk); rst_n = 0;
    @(negedge clk); rst_n = 1;
    chk(lstate == RXDET && !link_up && credits == 0 && hp_count == 0 && lbad_count == 0,
        "reset returns to RxDetect and clears counters");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
