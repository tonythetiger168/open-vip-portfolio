// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Smoke-target minimal behavioral model: USB 3.x SuperSpeed link FSM.
// Covers RxDetect -> Polling (TS1/TS2 ordered-set exchange) -> U0, header
// packet acknowledgement with LGOOD/LBAD link commands, LCRD credit
// accounting, and Recovery re-entry. Plain ANSI ports only (no interfaces)
// so the L1b smoke harness can build it directly with iverilog.

module usb3_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rx_valid,        // inbound ordered set / packet valid
  input  logic [3:0]  rx_os,           // 0=TS1 1=TS2 2=HP 3=DP 4=LGOOD 5=LBAD 6=LCRD
  input  logic [7:0]  rx_data,         // header/payload low byte
  input  logic        rx_crc_ok,       // CRC-5/16 result for header packet
  input  logic        far_end_ready,   // link partner detected (RxDetect)
  output logic [3:0]  link_state,      // 0=RxDetect 1=Polling 2=U0 3=Recovery
  output logic        link_up,         // link is in U0/Recovery
  output logic [3:0]  tx_lc,           // tx link command: 4=LGOOD 5=LBAD 6=LCRD
  output logic        tx_lc_valid,     // tx link command strobe
  output logic [3:0]  credit_cnt,      // advertised RX header credits
  output logic [7:0]  hp_count,        // header packets acknowledged (LGOOD)
  output logic [7:0]  lbad_count       // bad headers seen (LBAD sent)
);

  // Ordered-set / link-command encodings on rx_os / tx_lc
  localparam logic [3:0] OS_TS1   = 4'd0;
  localparam logic [3:0] OS_TS2   = 4'd1;
  localparam logic [3:0] OS_HP    = 4'd2;
  localparam logic [3:0] OS_DP    = 4'd3;
  localparam logic [3:0] LC_LGOOD = 4'd4;
  localparam logic [3:0] LC_LBAD  = 4'd5;
  localparam logic [3:0] LC_LCRD  = 4'd6;

  localparam logic [3:0] LS_RXDETECT = 4'd0;
  localparam logic [3:0] LS_POLLING  = 4'd1;
  localparam logic [3:0] LS_U0       = 4'd2;
  localparam logic [3:0] LS_RECOVERY = 4'd3;

  logic [3:0] state;
  logic [3:0] ts_cnt;    // ordered-set counter during training
  logic [7:0] tmo;       // inactivity timeout
  logic       hp_open;   // a header packet is expecting its data payload

  wire rx_ts1 = rx_valid && (rx_os == OS_TS1);
  wire rx_ts2 = rx_valid && (rx_os == OS_TS2);

  always @(posedge clk) begin
    if (!rst_n) begin
      state       <= LS_RXDETECT;
      ts_cnt      <= 4'd0;
      tmo         <= 8'd0;
      hp_open     <= 1'b0;
      link_state  <= LS_RXDETECT;
      link_up     <= 1'b0;
      tx_lc       <= 4'd0;
      tx_lc_valid <= 1'b0;
      credit_cnt  <= 4'd0;
      hp_count    <= 8'd0;
      lbad_count  <= 8'd0;
    end else begin
      tx_lc_valid <= 1'b0;   // link commands are single-cycle strobes
      tmo         <= tmo + 8'd1;
      case (state)
        // ---- RxDetect: wait for a far-end low-impedance partner ----
        LS_RXDETECT: begin
          link_state <= LS_RXDETECT;
          link_up    <= 1'b0;
          ts_cnt     <= 4'd0;
          if (far_end_ready) begin
            state <= LS_POLLING;
            tmo   <= 8'd0;
          end
        end

        // ---- Polling: TS1 x4 then TS2 x2, then advertise credit ----
        LS_POLLING: begin
          link_state <= LS_POLLING;
          if (rx_ts1 && ts_cnt < 4'd4)
            ts_cnt <= ts_cnt + 4'd1;
          else if (rx_ts2 && ts_cnt >= 4'd4)
            ts_cnt <= ts_cnt + 4'd1;
          if (ts_cnt >= 4'd5 && rx_ts2) begin
            state       <= LS_U0;          // training complete
            link_up     <= 1'b1;
            ts_cnt      <= 4'd0;
            tmo         <= 8'd0;
            credit_cnt  <= 4'd4;           // 4 header buffers
            tx_lc       <= LC_LCRD;        // advertise initial credits
            tx_lc_valid <= 1'b1;
          end else if (tmo == 8'hFF) begin
            state <= LS_RXDETECT;          // polling timeout
          end
        end

        // ---- U0: header/data packet flow with LGOOD/LBAD handshake ----
        LS_U0: begin
          link_state <= LS_U0;
          link_up    <= 1'b1;
          if (rx_valid) begin
            tmo <= 8'd0;
            case (rx_os)
              OS_HP: begin
                if (rx_crc_ok) begin
                  tx_lc       <= LC_LGOOD;      // ACK the header
                  tx_lc_valid <= 1'b1;
                  hp_count    <= hp_count + 8'd1;
                  hp_open     <= 1'b1;
                  if (credit_cnt != 4'd0)
                    credit_cnt <= credit_cnt - 4'd1;
                end else begin
                  tx_lc       <= LC_LBAD;       // bad header: go recover
                  tx_lc_valid <= 1'b1;
                  lbad_count  <= lbad_count + 8'd1;
                  hp_open     <= 1'b0;
                  state       <= LS_RECOVERY;
                end
              end
              OS_DP: begin
                if (hp_open) begin              // payload follows its header
                  hp_open     <= 1'b0;
                  tx_lc       <= LC_LCRD;       // return the credit
                  tx_lc_valid <= 1'b1;
                  if (credit_cnt != 4'hF)
                    credit_cnt <= credit_cnt + 4'd1;
                end
              end
              LC_LCRD: begin
                if (credit_cnt != 4'hF)
                  credit_cnt <= credit_cnt + 4'd1;
              end
              OS_TS1: begin
                state   <= LS_RECOVERY;         // partner requests retrain
                ts_cnt  <= 4'd0;
              end
              default: ;
            endcase
          end else if (tmo == 8'hFF) begin
            state    <= LS_RECOVERY;            // U0 inactivity -> Recovery
            ts_cnt   <= 4'd0;
          end
        end

        // ---- Recovery: short TS1/TS2 re-exchange back to U0 ----
        LS_RECOVERY: begin
          link_state <= LS_RECOVERY;
          if ((rx_ts1 || rx_ts2) && ts_cnt != 4'hF)
            ts_cnt <= ts_cnt + 4'd1;
          if (ts_cnt >= 4'd2) begin
            state    <= LS_U0;
            link_up  <= 1'b1;
            ts_cnt   <= 4'd0;
            tmo      <= 8'd0;
          end else if (tmo == 8'hFF) begin
            state   <= LS_RXDETECT;             // recovery failed: redetect
            link_up <= 1'b0;
            ts_cnt  <= 4'd0;
          end
        end

        default: state <= LS_RXDETECT;
      endcase
    end
  end

endmodule
