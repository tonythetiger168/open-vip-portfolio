// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Protocol Interface
// Supports: USB 2.0/3.x, USB4, eUSB2, USB-PD
// Dual-layer: MAC + PHY
//============================================================================
`ifndef USB_VIP_IF_SV
`define USB_VIP_IF_SV

interface usb_vip_if #(parameter int DATA_WIDTH = 32,
                       parameter int PROTOCOL   = 0)
                      (input logic clk, input logic rst_n);
  import uvm_pkg::*;
  import usb_vip_pkg::*;

  //========================================================================
  // MAC Layer Common Signals
  //========================================================================
  logic                   mac_valid;
  logic                   mac_ready;
  logic [DATA_WIDTH-1:0]  mac_data;
  logic [7:0]             mac_pid;
  logic [6:0]             mac_addr;
  logic [3:0]             mac_endpoint;
  logic [10:0]            mac_frame_num;
  logic                   mac_sop;
  logic                   mac_eop;
  logic                   mac_crc_ok;

  //========================================================================
  // USB 2.0 / eUSB2 PHY Layer Signals (UTMI/ULPI)
  //========================================================================
  logic [7:0]             utmi_data;
  logic                   utmi_txvalid;
  logic                   utmi_txready;
  logic                   utmi_rxvalid;
  logic                   utmi_rxactive;
  logic                   utmi_rxerror;
  logic [1:0]             utmi_linestate;   // 00=SE0, 01=J, 10=K, 11=SE1
  logic [1:0]             utmi_op_mode;
  logic [1:0]             utmi_xcvr_select;
  logic                   utmi_term_select;
  logic                   utmi_suspend;

  //========================================================================
  // USB 3.x PHY Layer Signals (PIPE)
  //========================================================================
  logic [31:0]            pipe_tx_data;
  logic [3:0]             pipe_tx_datak;
  logic                   pipe_tx_det;
  logic                   pipe_tx_elecidle;
  logic [2:0]             pipe_tx_deemph;
  logic [1:0]             pipe_tx_margin;
  logic                   pipe_tx_swing;
  logic [31:0]            pipe_rx_data;
  logic [3:0]             pipe_rx_datak;
  logic                   pipe_rx_valid;
  logic                   pipe_rx_status;
  logic                   pipe_rx_elecidle;
  logic [2:0]             pipe_rx_polarity;
  logic                   pipe_power_down;
  logic [1:0]             pipe_power_state;
  logic                   pipe_phy_status;
  logic                   pipe_phy_ready;

  //========================================================================
  // USB4 PHY Layer Signals (PIPE4 / Thunderbolt)
  //========================================================================
  logic [127:0]           pipe4_tx_data;
  logic [15:0]            pipe4_tx_datak;
  logic                   pipe4_tx_blk_start;
  logic [3:0]             pipe4_tx_sync_hdr;
  logic [127:0]           pipe4_rx_data;
  logic [15:0]            pipe4_rx_datak;
  logic                   pipe4_rx_blk_start;
  logic [3:0]             pipe4_rx_sync_hdr;
  logic                   pipe4_rx_valid;
  logic                   pipe4_rx_status;
  logic                   pipe4_link_ready;

  //========================================================================
  // USB-PD PHY Layer Signals (SBU - Sideband Unit)
  //========================================================================
  logic                   pd_cc1;
  logic                   pd_cc2;
  logic                   pd_vbus_present;
  logic                   pd_vbus_valid;
  logic [10:0]            pd_vbus_voltage;  // mV / 25 (11b: EPR up to 48V=1920)
  logic                   pd_vconn_present;
  logic [2:0]             pd_role;          // 0=Sink, 1=Source, 2=DRP, 3=Accessory
  logic                   pd_msg_valid;
  logic [2:0]             pd_msg_type;
  logic [31:0]            pd_header;
  logic [7:0]             pd_payload[];

  //========================================================================
  // Device State
  //========================================================================
  usb_device_state_e      dev_state;
  logic                   dev_connected;
  logic                   dev_suspended;
  logic                   dev_reset;

  //========================================================================
  // Error Signals
  //========================================================================
  logic                   crc5_error;
  logic                   crc16_error;
  logic                   crc32_error;
  logic                   timeout_error;
  logic                   babble_error;
  logic                   bit_stuff_error;
  logic                   disconnect_error;

  //========================================================================
  // Compliance alias signals
  // Aliases used by the tiered SVA compliance checkers. Where a direct
  // native equivalent exists the alias is derived combinationally; the
  // remaining protocol sideband flags are driven by the DUT model.
  //========================================================================
  logic                   valid;           assign valid           = mac_valid;
  logic                   ready;           assign ready           = mac_ready;
  logic                   sop;             assign sop             = mac_sop;
  logic                   eop;             assign eop             = mac_eop;
  logic [31:0]            data;            assign data            = mac_data;
  logic [1:0]             power_state;     assign power_state     = pipe_power_state;
  logic [1:0]             role;            assign role            = pd_role[1:0];
  logic [1:0]             pipe_rate;       assign pipe_rate       = pipe_tx_margin;
  logic                   pipe_txelecidle; assign pipe_txelecidle = pipe_tx_elecidle;
  logic                   pipe_rxvalid;    assign pipe_rxvalid    = pipe_rx_valid;
  logic [31:0]            pipe_rxdata;     assign pipe_rxdata     = pipe_rx_data;
  logic                   pipe_phystatus;  assign pipe_phystatus  = pipe_phy_status;
  logic                   hs_preamble;     assign hs_preamble     = (utmi_xcvr_select == 2'b01) && (utmi_op_mode == 2'b10);
  logic                   hs_mode;         assign hs_mode         = (utmi_xcvr_select == 2'b01);
  logic                   pd_valid;        assign pd_valid        = pd_msg_valid;
  logic [7:0]             pd_data;         assign pd_data         = pd_header[7:0];
  logic [7:0]             pd_voltage;      assign pd_voltage      = pd_vbus_voltage[7:0];

  // DUT-model driven alias/sideband flags
  logic                   link_up;
  logic [3:0]             ltssm_state;
  logic                   lfps_detect;
  logic                   training;
  logic                   ts1_valid;
  logic                   ts2_valid;
  logic                   training_done;
  logic                   hot_reset;
  logic                   hs_chirp;
  logic                   resume;
  logic                   repeater_mode;
  logic [31:0]            bandwidth;
  // USB4 sideband aliases
  logic [7:0]             bw_alloc;
  logic [7:0]             path_id;
  logic [3:0]             domain_id;
  logic [2:0]             cl_state;
  logic [2:0]             pm_state;
  logic                   drd;
  logic                   err_inject;
  logic                   router_config;
  logic                   sbtx_valid;
  logic                   sbrx_valid;
  logic [7:0]             sbtx_data;
  logic                   tunnel_dp;
  logic                   tunnel_pcie;
  logic                   tunnel_usb3;
  // USB-PD sideband aliases
  logic                   ams_start;
  logic                   ams_end;
  logic                   pd_bist;
  logic                   pd_crc_ok;
  logic                   pd_eop;
  logic                   pd_hard_reset;
  logic                   pd_power_contract;
  logic                   pd_sop;
  logic                   pps_en;
  logic [2:0]             pd_message_id;

  //========================================================================
  // Clocking Blocks
  //========================================================================
  clocking mac_driver_cb @(posedge clk);
    output mac_valid, mac_data, mac_pid, mac_addr, mac_endpoint;
    output mac_frame_num, mac_sop, mac_eop;
    input  mac_ready, mac_crc_ok;
    output dev_state, dev_connected, dev_suspended, dev_reset;
  endclocking

  clocking mac_monitor_cb @(posedge clk);
    input  mac_valid, mac_ready, mac_data, mac_pid, mac_addr, mac_endpoint;
    input  mac_frame_num, mac_sop, mac_eop, mac_crc_ok;
    input  dev_state, dev_connected, dev_suspended, dev_reset;
    input  crc5_error, crc16_error, crc32_error, timeout_error;
    input  babble_error, bit_stuff_error, disconnect_error;
  endclocking

  clocking phy_driver_cb @(posedge clk);
    output utmi_data, utmi_txvalid, utmi_op_mode, utmi_xcvr_select;
    output utmi_term_select, utmi_suspend;
    output pipe_tx_data, pipe_tx_datak, pipe_tx_det, pipe_tx_elecidle;
    output pipe_tx_deemph, pipe_tx_margin, pipe_tx_swing;
    output pipe_power_down, pipe_rx_polarity;
    output pipe4_tx_data, pipe4_tx_datak, pipe4_tx_blk_start, pipe4_tx_sync_hdr;
    output pd_cc1, pd_cc2, pd_vbus_present, pd_vbus_valid, pd_vconn_present;
    output pd_role, pd_msg_valid, pd_msg_type, pd_header;
    input  utmi_txready, utmi_rxvalid, utmi_rxactive, utmi_rxerror, utmi_linestate;
    input  pipe_rx_data, pipe_rx_datak, pipe_rx_valid, pipe_rx_status;
    input  pipe_rx_elecidle, pipe_phy_status, pipe_phy_ready, pipe_power_state;
    input  pipe4_rx_data, pipe4_rx_datak, pipe4_rx_valid, pipe4_rx_status, pipe4_link_ready;
    input  pd_vbus_voltage;
  endclocking

  clocking phy_monitor_cb @(posedge clk);
    input  utmi_data, utmi_txvalid, utmi_txready, utmi_rxvalid, utmi_rxactive;
    input  utmi_rxerror, utmi_linestate, utmi_op_mode, utmi_xcvr_select;
    input  utmi_term_select, utmi_suspend;
    input  pipe_tx_data, pipe_tx_datak, pipe_rx_data, pipe_rx_datak;
    input  pipe_rx_valid, pipe_rx_status, pipe_rx_elecidle, pipe_phy_status;
    input  pipe_phy_ready, pipe_power_down, pipe_power_state;
    input  pipe4_tx_data, pipe4_tx_datak, pipe4_tx_blk_start, pipe4_tx_sync_hdr;
    input  pipe4_rx_data, pipe4_rx_datak, pipe4_rx_valid, pipe4_rx_status, pipe4_link_ready;
    input  pd_cc1, pd_cc2, pd_vbus_present, pd_vbus_valid, pd_vbus_voltage;
    input  pd_vconn_present, pd_role, pd_msg_valid, pd_msg_type, pd_header;
  endclocking

  //========================================================================
  // Modports
  //========================================================================
  modport mac_driver_mp (clocking mac_driver_cb, input clk, rst_n);
  modport mac_monitor_mp (clocking mac_monitor_cb, input clk, rst_n);
  modport phy_driver_mp (clocking phy_driver_cb, input clk, rst_n);
  modport phy_monitor_mp (clocking phy_monitor_cb, input clk, rst_n);

  // DUT (device/PHY model) modport: observes host-driven MAC/PHY signals
  // and drives device-side responses plus compliance sideband flags.
  modport monitor_mp (
    input  clk, rst_n,
    input  mac_valid, mac_data, mac_pid, mac_addr, mac_endpoint,
    input  mac_frame_num, mac_sop, mac_eop,
    output mac_ready, mac_crc_ok,
    input  utmi_txvalid, utmi_op_mode, utmi_xcvr_select,
    input  utmi_term_select, utmi_suspend,
    output utmi_data,
    output utmi_txready, utmi_rxvalid, utmi_rxactive, utmi_rxerror, utmi_linestate,
    input  pipe_tx_data, pipe_tx_datak, pipe_tx_elecidle, pipe_power_down,
    output pipe_rx_data, pipe_rx_datak, pipe_rx_valid, pipe_rx_status,
    output pipe_rx_elecidle, pipe_phy_status, pipe_phy_ready, pipe_power_state,
    input  pipe4_tx_data, pipe4_tx_datak, pipe4_tx_blk_start, pipe4_tx_sync_hdr,
    output pipe4_rx_data, pipe4_rx_datak, pipe4_rx_blk_start, pipe4_rx_sync_hdr,
    output pipe4_rx_valid, pipe4_rx_status, pipe4_link_ready,
    input  pd_cc1, pd_cc2, pd_vbus_present, pd_vbus_valid, pd_vconn_present,
    input  pd_role, pd_msg_valid, pd_msg_type, pd_header,
    output pd_vbus_voltage,
    input  dev_state, dev_connected, dev_suspended, dev_reset,
    output crc5_error, crc16_error, crc32_error, timeout_error,
    output babble_error, bit_stuff_error, disconnect_error,
    output link_up, ltssm_state, lfps_detect, training, ts1_valid, ts2_valid,
    output training_done, hot_reset, hs_chirp, resume, repeater_mode, bandwidth,
    output bw_alloc, path_id, domain_id, cl_state, pm_state, drd, err_inject,
    output router_config, sbtx_valid, sbrx_valid, sbtx_data,
    output tunnel_dp, tunnel_pcie, tunnel_usb3,
    output ams_start, ams_end, pd_bist, pd_crc_ok, pd_eop, pd_hard_reset,
    output pd_power_contract, pd_sop, pps_en, pd_message_id
  );

  //========================================================================
  // MAC Layer Assertions
  //========================================================================
  property p_mac_valid_ready;
    @(posedge clk) disable iff (!rst_n)
      mac_valid |-> ##[1:16] mac_ready;
  endproperty
  assert_mac_valid_ready: assert property(p_mac_valid_ready)
    else `uvm_error("USB_IF", "MAC valid-ready handshake timeout");

  property p_mac_sop_eop;
    @(posedge clk) disable iff (!rst_n)
      mac_sop |-> !mac_eop ##[1:64] mac_eop;
  endproperty
  assert_mac_sop_eop: assert property(p_mac_sop_eop)
    else `uvm_error("USB_IF", "MAC SOP-EOP alignment violation");

  property p_mac_pid_valid;
    @(posedge clk) disable iff (!rst_n)
      (mac_valid && mac_sop)
      |-> mac_pid[1:0] inside {2'b01, 2'b10, 2'b11};
  endproperty
  assert_mac_pid: assert property(p_mac_pid_valid)
    else `uvm_error("USB_IF", "MAC invalid PID encoding");

  property p_dev_state_valid;
    @(posedge clk) disable iff (!rst_n)
      dev_state inside {USB_STATE_DEFAULT, USB_STATE_ADDRESS, USB_STATE_CONFIGURED,
                        USB_STATE_SUSPENDED, USB_STATE_RESUME, USB_STATE_RESET,
                        USB_STATE_POWERED, USB_STATE_TEST, USB_STATE_WUSB};
  endproperty
  assert_dev_state: assert property(p_dev_state_valid)
    else `uvm_error("USB_IF", "Invalid USB device state");

  //========================================================================
  // PHY Layer Assertions
  //========================================================================
  property p_utmi_linestate;
    @(posedge clk) disable iff (!rst_n)
      utmi_linestate inside {2'b00, 2'b01, 2'b10};
  endproperty
  assert_utmi_ls: assert property(p_utmi_linestate)
    else `uvm_error("USB_IF", "UTMI invalid linestate (SE1 not allowed)");

  property p_pipe_power_state;
    @(posedge clk) disable iff (!rst_n)
      pipe_power_state inside {2'b00, 2'b01, 2'b10, 2'b11};
  endproperty
  assert_pipe_pwr: assert property(p_pipe_power_state)
    else `uvm_error("USB_IF", "PIPE invalid power state");

  property p_pipe4_link_ready;
    @(posedge clk) disable iff (!rst_n)
      (!pipe4_link_ready)
      |-> pipe4_rx_valid == 1'b0;
  endproperty
  assert_pipe4_ready: assert property(p_pipe4_link_ready)
    else `uvm_error("USB_IF", "PIPE4 data while link not ready");

  property p_pd_vbus_range;
    @(posedge clk) disable iff (!rst_n)
      (pd_vbus_present)
      |-> pd_vbus_voltage inside {[0:1920]};  // 0-48V in 25mV steps
  endproperty
  assert_pd_vbus: assert property(p_pd_vbus_range)
    else `uvm_error("USB_IF", "USB-PD Vbus voltage out of range");

  //========================================================================
  // Coverage: Interface Activity
  //========================================================================
  covergroup cg_usb_interface @(posedge clk);
    option.per_instance = 1;
    cp_mac_valid: coverpoint mac_valid {
      bins inactive = {0};
      bins active   = {1};
    }
    cp_mac_ready: coverpoint mac_ready {
      bins inactive = {0};
      bins active   = {1};
    }
    cp_mac_hs: coverpoint {mac_valid, mac_ready} {
      bins idle       = {2'b00};
      bins wait_ready = {2'b10};
      bins transfer   = {2'b11};
      bins wait_valid = {2'b01};
    }
    cp_dev_state: coverpoint dev_state;
    cp_utmi_ls: coverpoint utmi_linestate {
      bins se0 = {2'b00};
      bins j   = {2'b01};
      bins k   = {2'b10};
    }
    cp_pipe_pwr: coverpoint pipe_power_state {
      bins p0 = {2'b00};
      bins p1 = {2'b01};
      bins p2 = {2'b10};
      bins p3 = {2'b11};
    }
    cp_pd_role: coverpoint pd_role {
      bins sink      = {3'b000};
      bins source    = {3'b001};
      bins drp       = {3'b010};
      bins accessory = {3'b011};
    }
    cp_error: coverpoint {crc5_error, crc16_error, crc32_error, timeout_error, babble_error} {
      bins no_error    = {5'b00000};
      bins crc5_err    = {5'b10000};
      bins crc16_err   = {5'b01000};
      bins crc32_err   = {5'b00100};
      bins timeout_err = {5'b00010};
      bins babble_err  = {5'b00001};
    }
    cross_mac_state: cross cp_mac_hs, cp_dev_state;
  endgroup

  // Initialize coverage
  initial begin
    cg_usb_interface cg = new();
  end

endinterface
`endif
