// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// USB 3.x Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 21
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
// L4=Protocol-specific rules
`ifndef USB3_COMPLIANCE_CHECKER_SV
`define USB3_COMPLIANCE_CHECKER_SV

module usb3_compliance_checker (usb_vip_if vif);
  import uvm_pkg::*;
  import usb_vip_pkg::*;
  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[6], l3_fail[6];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_usb3_pipe_power_down; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe_power_down inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_usb3_pipe_power_down: assert property(p_usb3_pipe_power_down) l1_pass[0]++; else begin `uvm_warning("USB3_L1", "Power down valid failed"); l1_fail[0]++; end
  cover_p_usb3_pipe_power_down: cover property(p_usb3_pipe_power_down);

  property p_usb3_pipe_rate; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe_rate inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_usb3_pipe_rate: assert property(p_usb3_pipe_rate) l1_pass[1]++; else begin `uvm_warning("USB3_L1", "Rate valid failed"); l1_fail[1]++; end
  cover_p_usb3_pipe_rate: cover property(p_usb3_pipe_rate);

  property p_usb3_ltssm_u0; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ltssm_state == 4'b0000 |-> vif.link_up; endproperty
  assert_p_usb3_ltssm_u0: assert property(p_usb3_ltssm_u0) l1_pass[2]++; else begin `uvm_warning("USB3_L1", "U0 active failed"); l1_fail[2]++; end
  cover_p_usb3_ltssm_u0: cover property(p_usb3_ltssm_u0);

  property p_usb3_ltssm_recovery; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ltssm_state == 4'b0111 |-> vif.link_up == 0; endproperty
  assert_p_usb3_ltssm_recovery: assert property(p_usb3_ltssm_recovery) l1_pass[3]++; else begin `uvm_warning("USB3_L1", "Recovery from error failed"); l1_fail[3]++; end
  cover_p_usb3_ltssm_recovery: cover property(p_usb3_ltssm_recovery);


  // ===== L2: Full Protocol (6 SVAs) =====
  property p_usb3_pipe_txelec; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe_txelecidle |-> vif.pipe_power_down != 2'b00; endproperty
  assert_p_usb3_pipe_txelec: assert property(p_usb3_pipe_txelec) l2_pass[0]++; else begin `uvm_warning("USB3_L2", "TX electrical idle failed"); l2_fail[0]++; end
  cover_p_usb3_pipe_txelec: cover property(p_usb3_pipe_txelec);

  property p_usb3_pipe_rxvalid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe_rxvalid |-> !$isunknown(vif.pipe_rxdata); endproperty
  assert_p_usb3_pipe_rxvalid: assert property(p_usb3_pipe_rxvalid) l2_pass[1]++; else begin `uvm_warning("USB3_L2", "RX valid with data failed"); l2_fail[1]++; end
  cover_p_usb3_pipe_rxvalid: cover property(p_usb3_pipe_rxvalid);

  property p_usb3_pipe_phystatus; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe_phystatus |-> vif.pipe_power_down inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_usb3_pipe_phystatus: assert property(p_usb3_pipe_phystatus) l2_pass[2]++; else begin `uvm_warning("USB3_L2", "PHY status failed"); l2_fail[2]++; end
  cover_p_usb3_pipe_phystatus: cover property(p_usb3_pipe_phystatus);

  property p_usb3_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe_rxvalid |-> !$isunknown(vif.pipe_rxdata); endproperty
  assert_p_usb3_no_x: assert property(p_usb3_no_x) l2_pass[3]++; else begin `uvm_warning("USB3_L2", "No X when valid failed"); l2_fail[3]++; end
  cover_p_usb3_no_x: cover property(p_usb3_no_x);

  property p_usb3_u1_u2; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ltssm_state inside {4'b0001,4'b0010} |-> vif.link_up == 1; endproperty
  assert_p_usb3_u1_u2: assert property(p_usb3_u1_u2) l2_pass[4]++; else begin `uvm_warning("USB3_L2", "U1/U2 exit failed"); l2_fail[4]++; end
  cover_p_usb3_u1_u2: cover property(p_usb3_u1_u2);

  property p_usb3_u3; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ltssm_state == 4'b0011 |-> vif.link_up == 0; endproperty
  assert_p_usb3_u3: assert property(p_usb3_u3) l2_pass[5]++; else begin `uvm_warning("USB3_L2", "U3 suspend failed"); l2_fail[5]++; end
  cover_p_usb3_u3: cover property(p_usb3_u3);


  // ===== L3: Advanced Features (6 SVAs) =====
  property p_usb3_lfps; @(posedge vif.clk) disable iff (!vif.rst_n) vif.lfps_detect |-> vif.ltssm_state == 4'b0010; endproperty
  assert_p_usb3_lfps: assert property(p_usb3_lfps) l3_pass[0]++; else begin `uvm_warning("USB3_L3", "LFPS signaling failed"); l3_fail[0]++; end
  cover_p_usb3_lfps: cover property(p_usb3_lfps);

  property p_usb3_ts1_ts2; @(posedge vif.clk) disable iff (!vif.rst_n) vif.training |-> vif.ts1_valid || vif.ts2_valid; endproperty
  assert_p_usb3_ts1_ts2: assert property(p_usb3_ts1_ts2) l3_pass[1]++; else begin `uvm_warning("USB3_L3", "TS1/TS2 handshake failed"); l3_fail[1]++; end
  cover_p_usb3_ts1_ts2: cover property(p_usb3_ts1_ts2);

  property p_usb3_link_training; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ltssm_state == 4'b0100 |-> vif.training_done == 0; endproperty
  assert_p_usb3_link_training: assert property(p_usb3_link_training) l3_pass[2]++; else begin `uvm_warning("USB3_L3", "Link training failed"); l3_fail[2]++; end
  cover_p_usb3_link_training: cover property(p_usb3_link_training);

  property p_usb3_hot_reset; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hot_reset |-> ##[1:100] vif.ltssm_state == 4'b0000; endproperty
  assert_p_usb3_hot_reset: assert property(p_usb3_hot_reset) l3_pass[3]++; else begin `uvm_warning("USB3_L3", "Hot reset failed"); l3_fail[3]++; end
  cover_p_usb3_hot_reset: cover property(p_usb3_hot_reset);

  property p_usb3_pm; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_usb3_pm: assert property(p_usb3_pm) l3_pass[4]++; else begin `uvm_warning("USB3_L3", "Power management failed"); l3_fail[4]++; end
  cover_p_usb3_pm: cover property(p_usb3_pm);

  property p_usb3_bandwidth; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bandwidth <= 32'hFFFFFFFF; endproperty
  assert_p_usb3_bandwidth: assert property(p_usb3_bandwidth) l3_pass[5]++; else begin `uvm_warning("USB3_L3", "Bandwidth valid failed"); l3_fail[5]++; end
  cover_p_usb3_bandwidth: cover property(p_usb3_bandwidth);


  // ---------------- L4: USB 3.x protocol-specific rules (5) ----------------
  // L4-1: U0 reached within 20 cycles after training done
  property p_usb3_l4_u0_entry; @(posedge vif.clk) disable iff (!vif.rst_n) vif.training_done |-> ##[1:20] vif.ltssm_state == 4'b0000; endproperty
  assert_p_usb3_l4_u0_entry: assert property(p_usb3_l4_u0_entry) l4_pass[0]++; else begin `uvm_warning("USB3_L4", "U0 entry timeout"); l4_fail[0]++; end
  cover_p_usb3_l4_u0_entry: cover property(p_usb3_l4_u0_entry);

  // L4-2: RX valid only when not in electrical idle
  property p_usb3_l4_rxvalid_idle; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pipe_rx_valid |-> !vif.pipe_rx_elecidle; endproperty
  assert_p_usb3_l4_rxvalid_idle: assert property(p_usb3_l4_rxvalid_idle) l4_pass[1]++; else begin `uvm_warning("USB3_L4", "RX valid during electrical idle"); l4_fail[1]++; end
  cover_p_usb3_l4_rxvalid_idle: cover property(p_usb3_l4_rxvalid_idle);

  // L4-3: header packet (K-characters) precedes data payload on TX
  property p_usb3_l4_datak; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid && vif.mac_sop |-> vif.pipe_tx_datak != 4'b0000; endproperty
  assert_p_usb3_l4_datak: assert property(p_usb3_l4_datak) l4_pass[2]++; else begin `uvm_warning("USB3_L4", "Header without K-characters"); l4_fail[2]++; end
  cover_p_usb3_l4_datak: cover property(p_usb3_l4_datak);

  // L4-4: data packet CRC32 checked clean at EOP
  property p_usb3_l4_crc32; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid && vif.mac_eop && vif.mac_frame_num > 0 |-> !vif.crc32_error; endproperty
  assert_p_usb3_l4_crc32: assert property(p_usb3_l4_crc32) l4_pass[3]++; else begin `uvm_warning("USB3_L4", "Data CRC32 error"); l4_fail[3]++; end
  cover_p_usb3_l4_crc32: cover property(p_usb3_l4_crc32);

  // L4-5: link up implies P0 power state
  property p_usb3_l4_p0_link; @(posedge vif.clk) disable iff (!vif.rst_n) vif.link_up |-> vif.pipe_power_state == 2'b00; endproperty
  assert_p_usb3_l4_p0_link: assert property(p_usb3_l4_p0_link) l4_pass[4]++; else begin `uvm_warning("USB3_L4", "Link up outside P0"); l4_fail[4]++; end
  cover_p_usb3_l4_p0_link: cover property(p_usb3_l4_p0_link);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l1_hit=0, l2_hit=0, l3_hit=0;
    int l4_total=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("USB3_RPT", $sformatf("=== USB3 Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("USB3_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("USB3_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("USB3_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("USB3_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("USB3_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end

endmodule
`endif
