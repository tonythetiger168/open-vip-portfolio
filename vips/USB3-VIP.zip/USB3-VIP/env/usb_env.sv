// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Protocol Verification Environment
// 7-protocol agents + end-to-end scoreboard + coverage + protocol checkers.
//============================================================================
`ifndef USB_ENV_SV
`define USB_ENV_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_env extends uvm_env;
  `uvm_component_utils(usb_env)

  usb_agent usb2_agent;
  usb_agent usb3_agent;
  usb_agent usb3p_agent;
  usb_agent usb32_agent;
  usb_agent usb4_agent;
  usb_agent eusb2_agent;
  usb_agent usbpd_agent;

  usb_scoreboard sb;

  usb_coverage_model usb2_cov;
  usb_coverage_model usb3_cov;
  usb_coverage_model usb4_cov;
  usb_coverage_model usbpd_cov;

  // Per-protocol checkers
  usb2_protocol_checker  usb2_chk;
  usb3_protocol_checker  usb3_chk;
  usb4_protocol_checker  usb4_chk;
  eusb2_protocol_checker eusb2_chk;
  usbpd_protocol_checker usbpd_chk;

  bit enable_usb2   = 1;
  bit enable_usb3   = 1;
  bit enable_usb3p  = 1;
  bit enable_usb32  = 1;
  bit enable_usb4   = 1;
  bit enable_eusb2  = 1;
  bit enable_usbpd  = 1;

  function new(string name = "usb_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  // Bind the named top-level virtual interface to a checker component
  function void set_chk_vif(uvm_component chk, string key);
    virtual usb_vip_if v;
    if (uvm_config_db#(virtual usb_vip_if)::get(this, "", key, v))
      uvm_config_db#(virtual usb_vip_if)::set(chk, "", "vif", v);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::get(this, "", "enable_usb2",  enable_usb2);
    uvm_config_db#(bit)::get(this, "", "enable_usb3",  enable_usb3);
    uvm_config_db#(bit)::get(this, "", "enable_usb3p", enable_usb3p);
    uvm_config_db#(bit)::get(this, "", "enable_usb32", enable_usb32);
    uvm_config_db#(bit)::get(this, "", "enable_usb4",  enable_usb4);
    uvm_config_db#(bit)::get(this, "", "enable_eusb2", enable_eusb2);
    uvm_config_db#(bit)::get(this, "", "enable_usbpd", enable_usbpd);

    if (enable_usb2) begin
      usb2_agent = usb_agent::type_id::create("usb2_agent", this);
      uvm_config_db#(usb_protocol_e)::set(usb2_agent, "", "protocol", USB_HS);
    end
    if (enable_usb3) begin
      usb3_agent = usb_agent::type_id::create("usb3_agent", this);
      uvm_config_db#(usb_protocol_e)::set(usb3_agent, "", "protocol", USB_SS);
    end
    if (enable_usb3p) begin
      usb3p_agent = usb_agent::type_id::create("usb3p_agent", this);
      uvm_config_db#(usb_protocol_e)::set(usb3p_agent, "", "protocol", USB_SS_P);
    end
    if (enable_usb32) begin
      usb32_agent = usb_agent::type_id::create("usb32_agent", this);
      uvm_config_db#(usb_protocol_e)::set(usb32_agent, "", "protocol", USB_SS_20);
    end
    if (enable_usb4) begin
      usb4_agent = usb_agent::type_id::create("usb4_agent", this);
      uvm_config_db#(usb_protocol_e)::set(usb4_agent, "", "protocol", USB4);
    end
    if (enable_eusb2) begin
      eusb2_agent = usb_agent::type_id::create("eusb2_agent", this);
      uvm_config_db#(usb_protocol_e)::set(eusb2_agent, "", "protocol", EUSB2);
    end
    if (enable_usbpd) begin
      usbpd_agent = usb_agent::type_id::create("usbpd_agent", this);
      uvm_config_db#(usb_protocol_e)::set(usbpd_agent, "", "protocol", USB_PD);
    end

    sb = usb_scoreboard::type_id::create("sb", this);

    usb2_cov  = usb_coverage_model::type_id::create("usb2_cov", this);
    usb3_cov  = usb_coverage_model::type_id::create("usb3_cov", this);
    usb4_cov  = usb_coverage_model::type_id::create("usb4_cov", this);
    usbpd_cov = usb_coverage_model::type_id::create("usbpd_cov", this);

    // Create per-protocol checkers (vif bound before build of children)
    if (enable_usb2) begin
      usb2_chk = usb2_protocol_checker::type_id::create("usb2_chk", this);
      set_chk_vif(usb2_chk, "usb2_vif");
    end
    if (enable_usb3 || enable_usb3p || enable_usb32) begin
      usb3_chk = usb3_protocol_checker::type_id::create("usb3_chk", this);
      set_chk_vif(usb3_chk, "usb3_vif");
    end
    if (enable_usb4) begin
      usb4_chk = usb4_protocol_checker::type_id::create("usb4_chk", this);
      set_chk_vif(usb4_chk, "usb4_vif");
    end
    if (enable_eusb2) begin
      eusb2_chk = eusb2_protocol_checker::type_id::create("eusb2_chk", this);
      set_chk_vif(eusb2_chk, "eusb2_vif");
    end
    if (enable_usbpd) begin
      usbpd_chk = usbpd_protocol_checker::type_id::create("usbpd_chk", this);
      set_chk_vif(usbpd_chk, "usbpd_vif");
    end
  endfunction

  // Connect one agent: monitor -> scoreboard(observed) + coverage,
  // driver -> scoreboard(expected).
  function void connect_agent(usb_agent agt, usb_coverage_model cov);
    if (agt == null) return;
    if (agt.mon != null) begin
      agt.mon.analysis_port.connect(sb.analysis_imp);   // observed
      agt.mon.cov_model = cov;
    end
    if (agt.drv != null)
      agt.drv.drv_ap.connect(sb.exp_imp);               // expected
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    connect_agent(usb2_agent,  usb2_cov);
    connect_agent(usb3_agent,  usb3_cov);
    connect_agent(usb3p_agent, usb3_cov);
    connect_agent(usb32_agent, usb3_cov);
    connect_agent(usb4_agent,  usb4_cov);
    connect_agent(eusb2_agent, usb2_cov);
    connect_agent(usbpd_agent, usbpd_cov);
  endfunction

  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("ENV_REPORT", "==========================================", UVM_LOW)
    `uvm_info("ENV_REPORT", "USB Protocol VIP Regression Complete", UVM_LOW)
    `uvm_info("ENV_REPORT", "==========================================", UVM_LOW)
    if (usb2_cov != null)
      `uvm_info("COVERAGE", $sformatf("USB2/eUSB2 Coverage: %0.2f%%", usb2_cov.get_coverage()), UVM_LOW)
    if (usb3_cov != null)
      `uvm_info("COVERAGE", $sformatf("USB3 Coverage:      %0.2f%%", usb3_cov.get_coverage()), UVM_LOW)
    if (usb4_cov != null)
      `uvm_info("COVERAGE", $sformatf("USB4 Coverage:      %0.2f%%", usb4_cov.get_coverage()), UVM_LOW)
    if (usbpd_cov != null)
      `uvm_info("COVERAGE", $sformatf("USB-PD Coverage:    %0.2f%%", usbpd_cov.get_coverage()), UVM_LOW)
  endfunction
endclass
`endif
