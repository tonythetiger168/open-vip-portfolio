// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Base Test
//============================================================================
`ifndef USB_BASE_TEST_SV
`define USB_BASE_TEST_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_base_test extends uvm_test;
  `uvm_component_utils(usb_base_test)

  usb_env env;

  function new(string name = "usb_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = usb_env::type_id::create("env", this);
  endfunction

  function void start_of_simulation_phase(uvm_phase phase);
    super.start_of_simulation_phase(phase);
    uvm_top.print_topology();
  endfunction

  // Return the sequencer of the agent servicing protocol p
  function usb_sequencer get_sequencer(usb_protocol_e p);
    case (p)
      USB_HS:     return (env.usb2_agent  != null) ? env.usb2_agent.sqr  : null;
      USB_SS:     return (env.usb3_agent  != null) ? env.usb3_agent.sqr  : null;
      USB_SS_P:   return (env.usb3p_agent != null) ? env.usb3p_agent.sqr : null;
      USB_SS_20:  return (env.usb32_agent != null) ? env.usb32_agent.sqr : null;
      USB4:       return (env.usb4_agent  != null) ? env.usb4_agent.sqr  : null;
      EUSB2:      return (env.eusb2_agent != null) ? env.eusb2_agent.sqr : null;
      USB_PD:     return (env.usbpd_agent != null) ? env.usbpd_agent.sqr : null;
      default:    return null;
    endcase
  endfunction

  virtual task run_phase(uvm_phase phase);
    phase.raise_objection(this);
    `uvm_info("TEST", "Base test running", UVM_LOW)
    #1000;
    phase.drop_objection(this);
  endtask
endclass
`endif
