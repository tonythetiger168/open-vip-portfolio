// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Random Regression Test
//============================================================================
`ifndef USB_RANDOM_REGRESSION_TEST_SV
`define USB_RANDOM_REGRESSION_TEST_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_random_regression_test extends usb_base_test;
  `uvm_component_utils(usb_random_regression_test)

  function new(string name = "usb_random_regression_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_random_sequence seq;
    phase.raise_objection(this);
    // Weighted random traffic on every enabled agent
    begin
      usb_regression_sequence rseq;
      rseq = usb_regression_sequence::type_id::create("rseq");
      if (!rseq.randomize()) `uvm_error("TEST", "Sequence randomization failed")
      // The regression mix targets each protocol through its own sequencer
      fork
        begin
          seq = usb_random_sequence::type_id::create("seq_u2");
          seq.num_transactions = 200; seq.target_protocol = USB_HS;
          seq.start(get_sequencer(USB_HS));
        end
        begin
          seq = usb_random_sequence::type_id::create("seq_u3");
          seq.num_transactions = 100; seq.target_protocol = USB_SS;
          seq.start(get_sequencer(USB_SS));
        end
        begin
          seq = usb_random_sequence::type_id::create("seq_u4");
          seq.num_transactions = 50; seq.target_protocol = USB4;
          seq.start(get_sequencer(USB4));
        end
        begin
          seq = usb_random_sequence::type_id::create("seq_eu2");
          seq.num_transactions = 100; seq.target_protocol = EUSB2;
          seq.start(get_sequencer(EUSB2));
        end
        begin
          seq = usb_random_sequence::type_id::create("seq_pd");
          seq.num_transactions = 50; seq.target_protocol = USB_PD;
          seq.start(get_sequencer(USB_PD));
        end
      join
    end
    phase.drop_objection(this);
  endtask
endclass
`endif

//============================================================================
// USB Directed Test: full directed sequence library on USB 2.0 HS
//============================================================================
`ifndef USB_DIRECTED_TEST_SV
`define USB_DIRECTED_TEST_SV

class usb_directed_test extends usb_base_test;
  `uvm_component_utils(usb_directed_test)

  usb_protocol_e test_protocol = USB_HS;

  function new(string name = "usb_directed_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_directed_regression_sequence dseq;
    phase.raise_objection(this);
    dseq = usb_directed_regression_sequence::type_id::create("dseq");
    dseq.target_protocol = test_protocol;
    dseq.num_transactions = 16;
    dseq.start(get_sequencer(test_protocol));
    phase.drop_objection(this);
  endtask
endclass
`endif

//============================================================================
// USB HS Test
//============================================================================
`ifndef USB_HS_TEST_SV
`define USB_HS_TEST_SV

class usb_hs_test extends usb_base_test;
  `uvm_component_utils(usb_hs_test)

  function new(string name = "usb_hs_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3p", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb32", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb4", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eusb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usbpd", 0);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_random_sequence seq;
    phase.raise_objection(this);
    seq = usb_random_sequence::type_id::create("seq");
    seq.num_transactions = 2000;
    seq.target_protocol = USB_HS;
    seq.start(get_sequencer(USB_HS));
    phase.drop_objection(this);
  endtask
endclass
`endif

//============================================================================
// USB SS Test
//============================================================================
`ifndef USB_SS_TEST_SV
`define USB_SS_TEST_SV

class usb_ss_test extends usb_base_test;
  `uvm_component_utils(usb_ss_test)

  function new(string name = "usb_ss_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_usb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3p", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb32", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb4", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eusb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usbpd", 0);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_random_sequence seq;
    phase.raise_objection(this);
    seq = usb_random_sequence::type_id::create("seq");
    seq.num_transactions = 2000;
    seq.target_protocol = USB_SS;
    seq.start(get_sequencer(USB_SS));
    phase.drop_objection(this);
  endtask
endclass
`endif

//============================================================================
// USB SS+ Test
//============================================================================
`ifndef USB_SSP_TEST_SV
`define USB_SSP_TEST_SV

class usb_ssp_test extends usb_base_test;
  `uvm_component_utils(usb_ssp_test)

  function new(string name = "usb_ssp_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_usb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb32", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb4", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eusb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usbpd", 0);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_random_sequence seq;
    phase.raise_objection(this);
    seq = usb_random_sequence::type_id::create("seq");
    seq.num_transactions = 2000;
    seq.target_protocol = USB_SS_P;
    seq.start(get_sequencer(USB_SS_P));
    phase.drop_objection(this);
  endtask
endclass
`endif

//============================================================================
// USB SS20 Test
//============================================================================
`ifndef USB_SS20_TEST_SV
`define USB_SS20_TEST_SV

class usb_ss20_test extends usb_base_test;
  `uvm_component_utils(usb_ss20_test)

  function new(string name = "usb_ss20_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_usb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3p", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb4", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eusb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usbpd", 0);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_random_sequence seq;
    phase.raise_objection(this);
    seq = usb_random_sequence::type_id::create("seq");
    seq.num_transactions = 2000;
    seq.target_protocol = USB_SS_20;
    seq.start(get_sequencer(USB_SS_20));
    phase.drop_objection(this);
  endtask
endclass
`endif

//============================================================================
// USB4 Test
//============================================================================
`ifndef USB4_TEST_SV
`define USB4_TEST_SV

class usb4_test extends usb_base_test;
  `uvm_component_utils(usb4_test)

  function new(string name = "usb4_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_usb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3p", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb32", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eusb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usbpd", 0);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_random_sequence seq;
    phase.raise_objection(this);
    seq = usb_random_sequence::type_id::create("seq");
    seq.num_transactions = 2000;
    seq.target_protocol = USB4;
    seq.start(get_sequencer(USB4));
    phase.drop_objection(this);
  endtask
endclass
`endif

//============================================================================
// eUSB2 Test
//============================================================================
`ifndef USB_EUSB2_TEST_SV
`define USB_EUSB2_TEST_SV

class usb_eusb2_test extends usb_base_test;
  `uvm_component_utils(usb_eusb2_test)

  function new(string name = "usb_eusb2_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_usb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3p", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb32", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb4", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usbpd", 0);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_random_sequence seq;
    phase.raise_objection(this);
    seq = usb_random_sequence::type_id::create("seq");
    seq.num_transactions = 2000;
    seq.target_protocol = EUSB2;
    seq.start(get_sequencer(EUSB2));
    phase.drop_objection(this);
  endtask
endclass
`endif

//============================================================================
// USB-PD Test
//============================================================================
`ifndef USB_PD_TEST_SV
`define USB_PD_TEST_SV

class usb_pd_test extends usb_base_test;
  `uvm_component_utils(usb_pd_test)

  function new(string name = "usb_pd_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_usb2", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb3p", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb32", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_usb4", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eusb2", 0);
  endfunction

  virtual task run_phase(uvm_phase phase);
    usb_random_sequence seq;
    phase.raise_objection(this);
    seq = usb_random_sequence::type_id::create("seq");
    seq.num_transactions = 2000;
    seq.target_protocol = USB_PD;
    seq.start(get_sequencer(USB_PD));
    phase.drop_objection(this);
  endtask
endclass
`endif
