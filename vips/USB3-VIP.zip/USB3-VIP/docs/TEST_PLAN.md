# USB3 Test Plan（USB3-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | USB 3.2 link layer (Gen1 / Gen2) |
| 家族 | USB |
| 類型 | UVM VIP |
| 交付目錄 | `USB3-VIP/` |
| 目前 L1b 狀態 | PASS |

## 2. DUT / 待測對象

- `usb3_smoke_model`（USB 3.2 upstream port link layer：LTSSM、header packet / link command、retry buffer、credits、LMP、Gen2 block header）
- `usb3_phy_model`、`usb4_phy_model`、`pd_controller_model`（umbrella top 的 PIPE loopback model，沿用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | in reset: RxDetect, nothing sent; CRC-5 / CRC-16 / CRC-32 encodings | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | RxDetect -> Polling.LFPS on far-end termination; Polling.LFPS timeout back to RxDetect | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | Polling: Gen1 (one LFPS burst without SCD2) and Gen2 (SCD2) speed selection, TS1 / TS2 -> U0 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | U0 entry advertisement: LGOOD_(seq-1) and one LCRD per free buffer; device Port Capability waits for a credit | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | receive: LGOOD per good header, buffer freed and LCRD_A..D in order 4 clocks later | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | bad CRC-16 / CRC-5: LBAD, every header ignored until LRTY | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | ITP (timestamp), TP to this address, DPH + DPP with good / bad CRC-32 and short length | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | overrun of the 4 receive buffers and an out-of-sequence header: Recovery | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | buffers held by the protocol layer across Recovery; LCRD index continues | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | transmit: credit limit, HdrSeq, LBAD from the host -> LRTY + resend from the oldest unacknowledged header | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | link power management: LGO_U1 / U2 / U3 -> LAU or LXU, LPMA, U1 -> U2 inactivity timer, LFPS exit | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | Hot Reset from a TS with the reset bit; Recovery timeout to RxDetect | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | Gen2 block headers: 1-bit errors corrected, 2+ bits dropped | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | LMP: Set Link Function (force PM), U2 Inactivity Timeout, Port Capability / Configuration -> Response | 檢查成立，`FUNC_PASS` 輸出 |
| FS-15 | reset in the middle of traffic | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Gen2x2 lane bonding and SKP ordered sets |
| PT-02 | Isochronous timestamp packets with bus-interval adjustment |
| PT-03 | Downstream (host) port model and a device-side BFM |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/usb3_compliance_checker.sv`（L1 signal sanity 4、L2 link layer 5、L3 LTSSM 6、L4 link power 4、L5 counters / Gen2 5，加 12 個 cover）
- Functional coverage：`vip/usb3/usb3_link_pkg.sv` 的 `usb3_coverage`（cg_ltssm 轉移、cg_lc 雙向 link command、cg_hdr header 錯誤 / LMP / block header）
- Scoreboard：`usb3_scoreboard` 預測 device link layer（LGOOD / LBAD / LRTY / LAU / LXU 順序、LCRD 順序、advertisement、HdrSeq 與 CRC、resend、LMP response、U1 -> U2 計時、DPP / ITP / TP 計數）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/USB3-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py USB3-VIP && python3 smoke/smoke_run.py USB3-VIP   # L1b
python3 tools/run_uvm_tests.py USB3-VIP       # UVM（Verilator），期望 SB_PASS
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 行為級 model 以每 clock 一個 symbol / link item 建模，不含 PHY 類比層（BMC / 8b10b / 128b132b 串列化、LFPS 波形）。

---
*文件版本：v1.8.0*
