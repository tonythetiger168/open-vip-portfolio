// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Random Sequence
//============================================================================
`ifndef USB_RANDOM_SEQUENCE_SV
`define USB_RANDOM_SEQUENCE_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_random_sequence extends usb_base_sequence;
  `uvm_object_utils(usb_random_sequence)

  rand bit enable_usb2;
  rand bit enable_usb3;
  rand bit enable_usb4;
  rand bit enable_eusb2;
  rand bit enable_usbpd;

  constraint c_protocol_dist {
    if (enable_usb2)  target_protocol inside {USB_HS, EUSB2};
    if (enable_usb3)  target_protocol inside {USB_SS, USB_SS_P, USB_SS_20};
    if (enable_usb4)  target_protocol == USB4;
    if (enable_eusb2) target_protocol == EUSB2;
    if (enable_usbpd) target_protocol == USB_PD;
  }

  function new(string name = "usb_random_sequence");
    super.new(name);
  endfunction

  virtual task body();
    super.body();
    repeat (num_transactions) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol == target_protocol;
        // 90% of traffic targets the functional DUT endpoint
        txn.device_addr dist { USB_DUT_DEV_ADDR := 9, [7'h1:7'h7F] :/ 1 };
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
