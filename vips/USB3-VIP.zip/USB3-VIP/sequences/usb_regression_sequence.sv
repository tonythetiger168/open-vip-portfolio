// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Regression Sequence
// Weighted random mix + full directed sequence library sweep.
//============================================================================
`ifndef USB_REGRESSION_SEQUENCE_SV
`define USB_REGRESSION_SEQUENCE_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_regression_sequence extends uvm_sequence #(usb_sequence_item);
  `uvm_object_utils(usb_regression_sequence)

  rand int usb2_weight, usb3_weight, usb4_weight, eusb2_weight, pd_weight;

  constraint c_weights {
    usb2_weight  inside {[1:10]};
    usb3_weight  inside {[1:10]};
    usb4_weight  inside {[1:10]};
    eusb2_weight inside {[1:10]};
    pd_weight    inside {[1:10]};
  }

  function new(string name = "usb_regression_sequence");
    super.new(name);
  endfunction

  virtual task body();
    usb_random_sequence seq;
    int total = 5000;
    int sum_w = usb2_weight + usb3_weight + usb4_weight + eusb2_weight + pd_weight;

    `uvm_info("REGRESSION", "Starting USB Coverage-Driven Regression", UVM_LOW)

    seq = usb_random_sequence::type_id::create("usb2_seq");
    seq.num_transactions = total * usb2_weight / sum_w;
    seq.enable_usb2 = 1; seq.enable_usb3 = 0; seq.enable_usb4 = 0;
    seq.enable_eusb2 = 0; seq.enable_usbpd = 0;
    seq.start(m_sequencer);

    seq = usb_random_sequence::type_id::create("usb3_seq");
    seq.num_transactions = total * usb3_weight / sum_w;
    seq.enable_usb3 = 1;
    seq.start(m_sequencer);

    seq = usb_random_sequence::type_id::create("usb4_seq");
    seq.num_transactions = total * usb4_weight / sum_w;
    seq.enable_usb4 = 1;
    seq.start(m_sequencer);

    seq = usb_random_sequence::type_id::create("eusb2_seq");
    seq.num_transactions = total * eusb2_weight / sum_w;
    seq.enable_eusb2 = 1;
    seq.start(m_sequencer);

    seq = usb_random_sequence::type_id::create("pd_seq");
    seq.num_transactions = total * pd_weight / sum_w;
    seq.enable_usbpd = 1;
    seq.start(m_sequencer);

    seq = usb_random_sequence::type_id::create("stress_seq");
    seq.num_transactions = total / 5;
    seq.enable_usb2 = 1; seq.enable_usb3 = 1; seq.enable_usb4 = 1;
    seq.enable_eusb2 = 1; seq.enable_usbpd = 1;
    seq.start(m_sequencer);

    `uvm_info("REGRESSION", "Regression Complete", UVM_LOW)
  endtask
endclass

//============================================================================
// Directed regression: sweeps the full directed sequence library on the
// current sequencer (protocol bound by the enclosing test).
//============================================================================
class usb_directed_regression_sequence extends uvm_sequence #(usb_sequence_item);
  `uvm_object_utils(usb_directed_regression_sequence)

  usb_protocol_e target_protocol = USB_HS;
  int            num_transactions = 20;

  function new(string name = "usb_directed_regression_sequence");
    super.new(name);
  endfunction

  virtual task body();
    usb_normal_seq       nrm = usb_normal_seq::type_id::create("nrm");
    usb_error_inject_seq err = usb_error_inject_seq::type_id::create("err");
    usb_reset_seq        rst = usb_reset_seq::type_id::create("rst");
    usb_back_to_back_seq b2b = usb_back_to_back_seq::type_id::create("b2b");
    usb_stress_seq       str = usb_stress_seq::type_id::create("str");
    usb_corner_seq       cor = usb_corner_seq::type_id::create("cor");
    usb_sof_seq          sof = usb_sof_seq::type_id::create("sof");

    nrm.target_protocol = target_protocol; nrm.num_transactions = num_transactions;
    err.target_protocol = target_protocol; err.num_transactions = num_transactions;
    rst.target_protocol = target_protocol; rst.num_transactions = 4;
    b2b.target_protocol = target_protocol; b2b.num_transactions = num_transactions;
    str.target_protocol = target_protocol; str.num_transactions = 32;
    cor.target_protocol = target_protocol; cor.num_transactions = 16;
    sof.target_protocol = target_protocol; sof.num_transactions = 8;

    `uvm_info("REGRESSION", "Directed sequence sweep starting", UVM_LOW)
    nrm.start(m_sequencer);
    err.start(m_sequencer);
    rst.start(m_sequencer);
    b2b.start(m_sequencer);
    cor.start(m_sequencer);
    sof.start(m_sequencer);
    str.start(m_sequencer);
    `uvm_info("REGRESSION", "Directed sequence sweep complete", UVM_LOW)
  endtask
endclass
`endif
