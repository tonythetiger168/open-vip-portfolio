// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Base Sequence + Directed Sequence Library
// Directed coverage: normal / error-inject / reset / back-to-back / stress /
// corner-case / SOF-frame sequences.
//============================================================================
`ifndef USB_BASE_SEQUENCE_SV
`define USB_BASE_SEQUENCE_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_base_sequence extends uvm_sequence #(usb_sequence_item);
  `uvm_object_utils(usb_base_sequence)

  rand int num_transactions;
  rand usb_protocol_e target_protocol;

  constraint c_num_txn { num_transactions inside {[10:1000]}; }

  function new(string name = "usb_base_sequence");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info("SEQ", $sformatf("Starting %0d transactions for %s",
        num_transactions, target_protocol.name()), UVM_LOW)
  endtask

  // Helper: issue one item with a with-constraint applied by callers
  virtual task send_item(usb_sequence_item item);
    start_item(item);
    finish_item(item);
  endtask
endclass

//============================================================================
// Directed: normal traffic - addressed to the DUT endpoint, ACK expected.
// Control SETUP + bulk data with legal payload sizes.
//============================================================================
class usb_normal_seq extends usb_base_sequence;
  `uvm_object_utils(usb_normal_seq)

  function new(string name = "usb_normal_seq");
    super.new(name);
  endfunction

  virtual task body();
    super.body();
    repeat (num_transactions) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type    inside {TOK_SETUP, TOK_IN, TOK_OUT, DATA_DATA0, DATA_DATA1};
        txn.packet_len  inside {[1:64]};
        txn.inject_crc_err == 0; txn.inject_timeout == 0;
        txn.inject_stall   == 0; txn.inject_babble  == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass

//============================================================================
// Directed: error injection - CRC corruption (bad CRC16/CRC32 trailer),
// timeout (unimplemented address), STALL (unimplemented endpoint 15),
// babble (over-length packet).
//============================================================================
class usb_error_inject_seq extends usb_base_sequence;
  `uvm_object_utils(usb_error_inject_seq)

  function new(string name = "usb_error_inject_seq");
    super.new(name);
  endfunction

  virtual task body();
    super.body();
    // CRC error: corrupt trailer on a data packet
    repeat (num_transactions / 4 + 1) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type    == DATA_DATA0;
        txn.packet_len  inside {[4:64]};
        txn.inject_crc_err == 1; txn.inject_timeout == 0;
        txn.inject_stall   == 0; txn.inject_babble  == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
    // Timeout: token to an address with no device
    repeat (num_transactions / 4 + 1) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.device_addr == 7'h7E;
        txn.txn_type    inside {TOK_IN, TOK_OUT};
        txn.inject_crc_err == 0; txn.inject_stall == 0; txn.inject_babble == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
    // STALL: request to unimplemented endpoint 15
    repeat (num_transactions / 4 + 1) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type    inside {TOK_IN, TOK_OUT};
        txn.endpoint    == 4'hF;
        txn.inject_crc_err == 0; txn.inject_babble == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
    // Babble: over-length data packet (>64 beats without EOP)
    repeat (2) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type    == DATA_DATA1;
        txn.packet_len  == 300;
        txn.inject_babble == 1; txn.inject_crc_err == 0; txn.inject_stall == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass

//============================================================================
// Directed: reset behavior - bus reset (SE0) then re-enumeration traffic.
//============================================================================
class usb_reset_seq extends usb_base_sequence;
  `uvm_object_utils(usb_reset_seq)

  function new(string name = "usb_reset_seq");
    super.new(name);
  endfunction

  virtual task body();
    super.body();
    repeat (num_transactions / 2 + 1) begin
      // Item tagged RESET: driver asserts bus reset before the packet
      usb_sequence_item rst_item = usb_sequence_item::type_id::create("rst_item");
      start_item(rst_item);
      if (!rst_item.randomize() with {
        txn.protocol    == target_protocol;
        txn.dev_state   == USB_STATE_RESET;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type    == TOK_SOF;
        txn.inject_crc_err == 0; txn.inject_timeout == 0;
        txn.inject_stall   == 0; txn.inject_babble  == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(rst_item);
      // Post-reset SETUP (re-enumeration)
      begin
        usb_sequence_item item = usb_sequence_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          txn.protocol    == target_protocol;
          txn.device_addr == USB_DUT_DEV_ADDR;
          txn.txn_type    == TOK_SETUP;
          txn.packet_len  == 8;
          txn.inject_crc_err == 0; txn.inject_timeout == 0;
          txn.inject_stall   == 0; txn.inject_babble  == 0;
        }) `uvm_error("SEQ", "Randomization failed")
        finish_item(item);
      end
    end
  endtask
endclass

//============================================================================
// Directed: back-to-back packets with the minimum inter-packet gap (2).
//============================================================================
class usb_back_to_back_seq extends usb_base_sequence;
  `uvm_object_utils(usb_back_to_back_seq)

  function new(string name = "usb_back_to_back_seq");
    super.new(name);
  endfunction

  virtual task body();
    super.body();
    repeat (num_transactions) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type    inside {TOK_OUT, DATA_DATA0, DATA_DATA1};
        txn.inter_packet_gap == 2;
        txn.packet_len  inside {[1:16]};
        txn.inject_crc_err == 0; txn.inject_timeout == 0;
        txn.inject_stall   == 0; txn.inject_babble  == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass

//============================================================================
// Directed: stress - large payloads at maximum rate, all endpoints.
//============================================================================
class usb_stress_seq extends usb_base_sequence;
  `uvm_object_utils(usb_stress_seq)

  function new(string name = "usb_stress_seq");
    super.new(name);
    num_transactions = 200;
  endfunction

  virtual task body();
    super.body();
    repeat (num_transactions) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type    inside {DATA_DATA0, DATA_DATA1};
        txn.packet_len  inside {[256:512]};
        txn.inter_packet_gap inside {[2:4]};
        txn.inject_crc_err == 0; txn.inject_timeout == 0;
        txn.inject_stall   == 0; txn.inject_babble  == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass

//============================================================================
// Directed: corner cases - zero-length packet, 1-byte, max-packet,
// boundary addresses and endpoints, alternating DATA0/DATA1 toggle.
//============================================================================
class usb_corner_seq extends usb_base_sequence;
  `uvm_object_utils(usb_corner_seq)

  function new(string name = "usb_corner_seq");
    super.new(name);
  endfunction

  virtual task body();
    super.body();
    // Zero-length packet (status stage)
    begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol == target_protocol;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type == DATA_DATA1;
        txn.packet_len == 0;
        txn.inject_crc_err == 0; txn.inject_timeout == 0;
        txn.inject_stall   == 0; txn.inject_babble  == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
    // 1-byte and max-size payloads, DATA0/DATA1 toggle
    for (int i = 0; i < num_transactions; i++) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.device_addr == USB_DUT_DEV_ADDR;
        txn.txn_type    == ((i % 2 == 0) ? DATA_DATA0 : DATA_DATA1);
        txn.packet_len  inside {1, 63, 64, 511, 512};
        txn.endpoint    inside {4'h0, 4'h7, 4'h8};
        txn.inject_crc_err == 0; txn.inject_timeout == 0;
        txn.inject_stall   == 0; txn.inject_babble  == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass

//============================================================================
// Directed: SOF frame stream - 11-bit frame numbers, 1ms cadence model.
//============================================================================
class usb_sof_seq extends usb_base_sequence;
  `uvm_object_utils(usb_sof_seq)

  function new(string name = "usb_sof_seq");
    super.new(name);
  endfunction

  virtual task body();
    super.body();
    for (int f = 0; f < num_transactions; f++) begin
      usb_sequence_item item = usb_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.txn_type    == TOK_SOF;
        txn.frame_number == f[10:0];
        txn.packet_len  == 0;
        txn.inject_crc_err == 0; txn.inject_timeout == 0;
        txn.inject_stall   == 0; txn.inject_babble  == 0;
      }) `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
