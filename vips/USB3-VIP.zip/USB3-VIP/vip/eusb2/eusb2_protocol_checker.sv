// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// eUSB2 Protocol Checker
// ULPI / UTMI layer assertions for embedded USB2 (1.2V single-ended)
//============================================================================
`ifndef EUSB2_PROTOCOL_CHECKER_SV
`define EUSB2_PROTOCOL_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class eusb2_protocol_checker extends uvm_component;
  `uvm_component_utils(eusb2_protocol_checker)

  // Coverage sample shadow variables (covergroups sample these on the checker clock)
  logic [3:0] cov_pid;
  logic [1:0] cov_op_mode;
  logic [1:0] cov_linestate;
  bit cov_suspend;


  covergroup cg_eusb2;
    option.per_instance = 1;
    cp_pid: coverpoint cov_pid {
      bins sof   = {4'b0101};
      bins setup = {4'b1101};
      bins tok_in  = {4'b1001};
      bins tok_out = {4'b0001};
      bins data0 = {4'b0011};
      bins data1 = {4'b1011};
      bins ack   = {4'b0010};
      bins nak   = {4'b1010};
      bins stall = {4'b1110};
    }
    cp_op_mode: coverpoint cov_op_mode {
      bins normal  = {2'b00};
      bins nondrv  = {2'b01};
      bins nostuff = {2'b10};
      bins op_reset = {2'b11};
    }
    cp_ls: coverpoint cov_linestate {
      bins se0 = {2'b00};
      bins j   = {2'b01};
      bins k   = {2'b10};
    }
    cp_suspend: coverpoint cov_suspend {
      bins act  = {0};
      bins susp = {1};
    }
    cross_pid_op: cross cp_pid, cp_op_mode;
  endgroup


  virtual usb_vip_if vif;

  int pid_err_cnt;
  int crc_err_cnt;
  int ulpi_err_cnt;
  int reg_err_cnt;

  function new(string name = "eusb2_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
    cg_eusb2 = new();
    pid_err_cnt  = 0;
    crc_err_cnt  = 0;
    ulpi_err_cnt = 0;
    reg_err_cnt  = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usb_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "eUSB2 checker: Virtual interface not found")
  endfunction

  // Procedural ULPI/UTMI checks sampled on the link clock
  virtual task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) continue;

      // ULPI command encoding: TX command byte must be valid when not in RX
      if (vif.utmi_txvalid && !vif.utmi_rxactive &&
          !(vif.utmi_data[7:6] inside {2'b00, 2'b01, 2'b10, 2'b11})) begin
        `uvm_error("EUSB2_CHK", "eUSB2 ULPI command invalid")
        ulpi_err_cnt++;
      end

      // ULPI register access: op_mode must hold a valid encoding
      if (vif.utmi_txvalid && vif.utmi_op_mode == 2'b01 &&
          !(vif.utmi_op_mode inside {2'b00, 2'b01, 2'b10, 2'b11})) begin
        `uvm_error("EUSB2_CHK", "eUSB2 ULPI register access invalid")
        reg_err_cnt++;
      end

      // PID complement: PID[7:4] == ~PID[3:0]
      if (vif.mac_valid && vif.mac_sop && (vif.mac_pid[7:4] != ~vif.mac_pid[3:0])) begin
        `uvm_error("EUSB2_CHK", "eUSB2 PID complement mismatch")
        pid_err_cnt++;
      end

      // Token CRC5
      if (vif.mac_valid && vif.mac_sop &&
          vif.mac_pid[3:0] inside {4'b0101,4'b1101,4'b1001,4'b0001} &&
          vif.crc5_error) begin
        `uvm_error("EUSB2_CHK", "eUSB2 CRC5 error in token")
        crc_err_cnt++;
      end

      // Data CRC16 at EOP
      if (vif.mac_valid && vif.mac_eop &&
          vif.mac_pid[3:0] inside {4'b0011,4'b1011} && vif.crc16_error) begin
        `uvm_error("EUSB2_CHK", "eUSB2 CRC16 error in data")
        crc_err_cnt++;
      end

      // eUSB2 linestate: SE1 illegal (single-ended 1.2V)
      if (vif.utmi_linestate == 2'b11)
        `uvm_error("EUSB2_CHK", "eUSB2 SE1 illegal state");
      cov_pid = vif.mac_pid[3:0];
      cov_op_mode = vif.utmi_op_mode;
      cov_linestate = vif.utmi_linestate;
      cov_suspend = vif.utmi_suspend;
      cg_eusb2.sample();
    end
  endtask



  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("EUSB2_CHK_RPT", $sformatf(
      "eUSB2 Chk | PID:%0d CRC:%0d ULPI:%0d REG:%0d",
      pid_err_cnt, crc_err_cnt, ulpi_err_cnt, reg_err_cnt), UVM_LOW)
  endfunction
endclass
`endif
