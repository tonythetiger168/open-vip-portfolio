// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Protocol Agent
//============================================================================
`ifndef USB_AGENT_SV
`define USB_AGENT_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_agent extends uvm_agent;
  `uvm_component_utils(usb_agent)

  usb_sequencer    sqr;
  usb_driver       drv;
  usb_monitor      mon;

  usb_protocol_e     protocol;
  usb_protocol_cfg_t cfg;
  bit                is_active = 1;

  function new(string name = "usb_agent", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  // Map protocol -> top-level virtual interface config-db key
  function string vif_key();
    case (protocol)
      USB_HS:     return "usb2_vif";
      USB_SS:     return "usb3_vif";
      USB_SS_P:   return "usb3p_vif";
      USB_SS_20:  return "usb32_vif";
      USB4:       return "usb4_vif";
      EUSB2:      return "eusb2_vif";
      USB_PD:     return "usbpd_vif";
      default:    return "usb2_vif";
    endcase
  endfunction

  function void build_phase(uvm_phase phase);
    virtual usb_vip_if agent_vif;
    super.build_phase(phase);
    if (!uvm_config_db#(usb_protocol_e)::get(this, "", "protocol", protocol))
      protocol = USB_HS;
    if (!uvm_config_db#(bit)::get(this, "", "is_active", is_active))
      is_active = 1;

    // Derive a default protocol configuration when none is supplied
    if (!uvm_config_db#(usb_protocol_cfg_t)::get(this, "", "cfg", cfg)) begin
      usb_protocol_config pc = new("pc", protocol);
      cfg = pc.cfg;
    end

    // Forward protocol/cfg to children before they are built
    uvm_config_db#(usb_protocol_e)::set(this, "*", "protocol", protocol);
    uvm_config_db#(usb_protocol_cfg_t)::set(this, "*", "cfg", cfg);

    // Fetch this protocol's interface from the top level and forward it
    // to driver/monitor under the well-known "vif" key.
    if (uvm_config_db#(virtual usb_vip_if)::get(this, "", vif_key(), agent_vif)) begin
      uvm_config_db#(virtual usb_vip_if)::set(this, "drv", "vif", agent_vif);
      uvm_config_db#(virtual usb_vip_if)::set(this, "mon", "vif", agent_vif);
    end else begin
      `uvm_fatal("CONFIG", $sformatf("No virtual interface for key '%s'", vif_key()))
    end

    mon = usb_monitor::type_id::create("mon", this);
    if (is_active) begin
      sqr = usb_sequencer::type_id::create("sqr", this);
      drv = usb_driver::type_id::create("drv", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (is_active) begin
      drv.seq_item_port.connect(sqr.seq_item_export);
    end
  endfunction

  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    if (sqr != null) uvm_config_db#(usb_protocol_e)::set(sqr, "", "protocol", protocol);
    if (drv != null) uvm_config_db#(usb_protocol_e)::set(drv, "", "protocol", protocol);
    if (mon != null) uvm_config_db#(usb_protocol_e)::set(mon, "", "protocol", protocol);
    if (drv != null) uvm_config_db#(usb_protocol_cfg_t)::set(drv, "", "cfg", cfg);
    if (mon != null) uvm_config_db#(usb_protocol_cfg_t)::set(mon, "", "cfg", cfg);
  endfunction
endclass
`endif
