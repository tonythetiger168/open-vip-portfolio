// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Protocol Monitor
// Observes MAC + PHY layer transactions: decodes PID -> packet type,
// reconstructs payload (using the sideband byte count, stripping the CRC
// trailer), observes the device handshake response and error flags, then
// publishes the reconstructed transaction.
//============================================================================
`ifndef USB_MONITOR_SV
`define USB_MONITOR_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_monitor extends uvm_monitor;
  `uvm_component_utils(usb_monitor)

  virtual usb_vip_if vif;
  usb_protocol_e     protocol;

  uvm_analysis_port #(usb_sequence_item) analysis_port;

  int txn_count;
  int error_count;

  usb_coverage_model cov_model;

  function new(string name = "usb_monitor", uvm_component parent = null);
    super.new(name, parent);
    analysis_port = new("analysis_port", this);
    txn_count = 0;
    error_count = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usb_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "Virtual interface not found")
    if (!uvm_config_db#(usb_protocol_e)::get(this, "", "protocol", protocol))
      protocol = USB_HS;
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    `uvm_info("MONITOR", "Monitor started", UVM_MEDIUM)
    forever begin
      collect_transaction();
    end
  endtask

  virtual task collect_transaction();
    usb_sequence_item item;
    usb_txn_descriptor txn;

    // Wait for MAC SOP (packet start); ignore bus-reset windows
    @(vif.mac_monitor_cb);
    while ((vif.mac_monitor_cb.mac_sop !== 1'b1 ||
            vif.mac_monitor_cb.mac_valid !== 1'b1) ||
           vif.mac_monitor_cb.dev_reset === 1'b1)
      @(vif.mac_monitor_cb);

    item = usb_sequence_item::type_id::create("item");
    txn = item.txn;
    txn.protocol = protocol;
    txn.start_time = $time;

    case (protocol)
      USB_HS, EUSB2:             collect_usb2(txn);
      USB_SS, USB_SS_P, USB_SS_20: collect_usb3(txn);
      USB4:                      collect_usb4(txn);
      USB_PD:                    collect_usbpd(txn);
      default:                   collect_usb2(txn);
    endcase

    txn.dev_state = vif.mac_monitor_cb.dev_state;
    if (cov_model != null)
      cov_model.sample_transaction(txn);

    analysis_port.write(item);
    txn_count++;
    if (txn.status inside {XFER_CRC_ERR, XFER_TIMEOUT, XFER_STALL, XFER_BABBLE})
      error_count++;
  endtask

  //==========================================================================
  // Shared payload collector: gathers MAC data beats until EOP, keeping
  // 'total' bytes (sideband count), then strips the CRC trailer.
  // beat_bytes = bus beat width in bytes (4 for UTMI/PIPE, 16 for PIPE4).
  //==========================================================================
  virtual task collect_payload(usb_txn_descriptor txn, int total, int crc_bytes,
                               int beat_bytes);
    int data_idx = 0;
    logic [127:0] d;
    txn.payload = new[0];
    while (vif.mac_monitor_cb.mac_eop !== 1'b1 && data_idx < total) begin
      @(vif.mac_monitor_cb);
      if (vif.mac_monitor_cb.mac_valid && vif.mac_monitor_cb.mac_eop !== 1'b1) begin
        d = 128'h0;
        d[31:0] = vif.mac_monitor_cb.mac_data;
        for (int j = 0; j < beat_bytes && data_idx < total; j++) begin
          txn.payload = new[txn.payload.size() + 1](txn.payload);
          txn.payload[data_idx] = d[j*8 +: 8];
          data_idx++;
        end
      end
    end
    // Drain any remaining cycles until EOP is observed
    while (vif.mac_monitor_cb.mac_eop !== 1'b1)
      @(vif.mac_monitor_cb);

    // Strip CRC trailer into the crc fields
    if (data_idx >= crc_bytes && crc_bytes > 0) begin
      int raw_len = data_idx;
      if (crc_bytes == 2)
        txn.crc16 = {txn.payload[raw_len-1], txn.payload[raw_len-2]};
      else if (crc_bytes == 4)
        txn.crc32 = {txn.payload[raw_len-1], txn.payload[raw_len-2],
                     txn.payload[raw_len-3], txn.payload[raw_len-4]};
      txn.payload = new[raw_len - crc_bytes](txn.payload);
      data_idx = raw_len - crc_bytes;
    end
    txn.packet_len = data_idx;
  endtask

  //==========================================================================
  // USB 2.0 / eUSB2: PID decode, payload + CRC16, UTMI handshake observe
  //==========================================================================
  virtual task collect_usb2(usb_txn_descriptor txn);
    bit is_data;
    int total;
    txn.pid          = vif.mac_monitor_cb.mac_pid;
    txn.device_addr  = vif.mac_monitor_cb.mac_addr;
    txn.endpoint     = vif.mac_monitor_cb.mac_endpoint;
    txn.txn_type     = usb_pid_decode(txn.pid);
    txn.frame_number = vif.mac_monitor_cb.mac_frame_num;

    is_data = usb_type_has_payload(txn.txn_type);
    total   = is_data ? int'(txn.frame_number) : 0;   // sideband byte count
    collect_payload(txn, total, is_data ? 2 : 0, 4);

    // PHY layer observations
    txn.phy_term    = vif.phy_monitor_cb.utmi_term_select;
    txn.phy_suspend = vif.phy_monitor_cb.utmi_suspend;
    txn.phy_if      = (vif.phy_monitor_cb.utmi_linestate == 2'b01) ? PHY_UTMI : PHY_ULPI;

    // Device handshake observation (after EOP, except SOF)
    if (txn.txn_type == TOK_SOF) begin
      txn.status = XFER_OK;
    end else begin
      int to = 0;
      bit got = 0;
      bit [7:0] hs_byte = 8'h00;
      while (to < 24 && !got) begin
        @(vif.phy_monitor_cb);
        if (vif.phy_monitor_cb.utmi_rxvalid === 1'b1 &&
            vif.phy_monitor_cb.utmi_rxactive === 1'b1) begin
          hs_byte = vif.phy_monitor_cb.utmi_data;
          got = 1;
        end
        to++;
      end
      if (!got) begin
        txn.status = XFER_TIMEOUT;
      end else begin
        case (usb_pid_decode(hs_byte))
          HS_ACK:   txn.status = XFER_OK;
          HS_NAK:   txn.status = XFER_OK;
          HS_STALL: txn.status = XFER_STALL;
          default:  txn.status = XFER_OK;
        endcase
      end
    end

    // Device-flagged errors take precedence
    if (vif.mac_monitor_cb.crc5_error || vif.mac_monitor_cb.crc16_error)
      txn.status = XFER_CRC_ERR;
    else if (vif.mac_monitor_cb.babble_error)
      txn.status = XFER_BABBLE;
    else if (vif.mac_monitor_cb.bit_stuff_error)
      txn.status = XFER_BIT_STUFF;
    txn.set_complete(txn.status);
  endtask

  //==========================================================================
  // USB 3.x: header decode, payload + CRC32, PIPE link-layer response
  //==========================================================================
  virtual task collect_usb3(usb_txn_descriptor txn);
    bit is_data;
    int total;
    txn.pid         = vif.mac_monitor_cb.mac_pid;
    txn.device_addr = vif.mac_monitor_cb.mac_addr;
    txn.endpoint    = vif.mac_monitor_cb.mac_endpoint;
    txn.txn_type    = usb_pid_decode_proto(protocol, txn.pid);
    txn.frame_number = vif.mac_monitor_cb.mac_frame_num;

    is_data = usb_type_has_payload(txn.txn_type);
    total   = is_data ? int'(txn.frame_number) : 0;
    collect_payload(txn, total, is_data ? 4 : 0, 4);

    txn.phy_if      = PHY_PIPE;
    txn.phy_term    = (vif.phy_monitor_cb.pipe_power_state == 2'b00);
    txn.phy_suspend = (vif.phy_monitor_cb.pipe_power_state == 2'b11);

    // Link-layer response after EOP (loopback ACK pulse / CRC32 flag)
    begin
      int to = 0;
      bit got = 0;
      while (to < 24 && !got) begin
        @(vif.phy_monitor_cb);
        if (vif.phy_monitor_cb.pipe_rx_valid === 1'b1) got = 1;
        to++;
      end
      if (vif.mac_monitor_cb.crc32_error)
        txn.status = XFER_CRC_ERR;
      else if (got)
        txn.status = XFER_OK;
      else
        txn.status = XFER_TIMEOUT;
    end
    txn.set_complete(txn.status);
  endtask

  //==========================================================================
  // USB4: control/tunneled block decode + CRC32, PIPE4 link response
  //==========================================================================
  virtual task collect_usb4(usb_txn_descriptor txn);
    bit is_data;
    int total;
    txn.pid         = vif.mac_monitor_cb.mac_pid;
    txn.device_addr = vif.mac_monitor_cb.mac_addr;
    txn.endpoint    = vif.mac_monitor_cb.mac_endpoint;
    txn.txn_type    = usb_pid_decode_proto(protocol, txn.pid);
    txn.frame_number = vif.mac_monitor_cb.mac_frame_num;

    is_data = usb_type_has_payload(txn.txn_type);
    total   = is_data ? int'(txn.frame_number) : 0;
    collect_payload(txn, total, is_data ? 4 : 0, 4);

    txn.phy_if   = PHY_PIPE4;
    txn.phy_term = vif.phy_monitor_cb.pipe4_link_ready;

    // Link-layer response after EOP
    begin
      int to = 0;
      bit got = 0;
      while (to < 24 && !got) begin
        @(vif.phy_monitor_cb);
        if (vif.phy_monitor_cb.pipe4_rx_valid === 1'b1) got = 1;
        to++;
      end
      if (vif.mac_monitor_cb.crc32_error)
        txn.status = XFER_CRC_ERR;
      else if (got)
        txn.status = XFER_OK;
      else
        txn.status = XFER_TIMEOUT;
    end
    txn.set_complete(txn.status);
  endtask

  //==========================================================================
  // USB-PD: message header decode, contract decode from Vbus
  //==========================================================================
  virtual task collect_usbpd(usb_txn_descriptor txn);
    txn.pid      = vif.mac_monitor_cb.mac_pid;
    txn.txn_type = usb_pid_decode_proto(protocol, txn.pid);
    if (txn.txn_type == USB_UNKNOWN)
      txn.txn_type = PD_CTRL_GOODCRC;
    txn.voltage_mv  = vif.phy_monitor_cb.pd_vbus_voltage * 25;
    txn.pd_contract = PD_5V_3A;   // Default

    // Decode PD header
    begin
      logic [31:0] hdr = vif.phy_monitor_cb.pd_header;
      txn.current_ma = hdr[15:8];
      txn.voltage_mv = hdr[31:16];
    end

    // Decode contract from voltage/current
    if (txn.voltage_mv == 5000 && txn.current_ma <= 150)
      txn.pd_contract = PD_5V_0P5A;
    else if (txn.voltage_mv == 5000 && txn.current_ma <= 900)
      txn.pd_contract = PD_5V_0P9A;
    else if (txn.voltage_mv == 5000 && txn.current_ma <= 1500)
      txn.pd_contract = PD_5V_1P5A;
    else if (txn.voltage_mv == 5000 && txn.current_ma <= 3000)
      txn.pd_contract = PD_5V_3A;
    else if (txn.voltage_mv == 9000)
      txn.pd_contract = PD_9V_3A;
    else if (txn.voltage_mv == 15000)
      txn.pd_contract = PD_15V_3A;
    else if (txn.voltage_mv == 20000 && txn.current_ma <= 3000)
      txn.pd_contract = PD_20V_3A;
    else if (txn.voltage_mv == 20000 && txn.current_ma <= 5000)
      txn.pd_contract = PD_20V_5A;
    else if (txn.voltage_mv > 20000)
      txn.pd_contract = PD_EPR;

    // Collect data objects (one byte per MAC beat, no CRC trailer)
    begin
      int data_idx = 0;
      txn.payload = new[0];
      while (vif.mac_monitor_cb.mac_eop !== 1'b1) begin
        @(vif.mac_monitor_cb);
        if (vif.mac_monitor_cb.mac_valid && vif.mac_monitor_cb.mac_eop !== 1'b1) begin
          txn.payload = new[txn.payload.size() + 1](txn.payload);
          txn.payload[data_idx] = vif.mac_monitor_cb.mac_data[7:0];
          data_idx++;
        end
      end
      txn.packet_len = data_idx;
    end

    txn.status = (vif.phy_monitor_cb.pd_vbus_valid) ? XFER_OK : XFER_TIMEOUT;
    txn.set_complete(txn.status);
  endtask

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("MONITOR_REPORT", $sformatf(
      "Protocol: %s | Total Collected: %0d | Errors: %0d",
      protocol.name(), txn_count, error_count), UVM_LOW)
  endfunction
endclass
`endif
