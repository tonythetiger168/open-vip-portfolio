// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Protocol Driver
// Handles MAC + PHY layer driving for all USB protocols.
// Real protocol behavior: token/data/handshake packet phases with proper
// PID encoding, CRC16/CRC32 trailer append, HS chirp negotiation, bus-reset
// signaling and device state-machine advancement.
//============================================================================
`ifndef USB_DRIVER_SV
`define USB_DRIVER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_driver extends uvm_driver #(usb_sequence_item);
  `uvm_component_utils(usb_driver)

  virtual usb_vip_if vif;
  usb_protocol_e     protocol;
  usb_protocol_cfg_t cfg;

  // Expected-transaction analysis port (scoreboard reference model)
  uvm_analysis_port #(usb_sequence_item) drv_ap;

  int txn_count;
  int error_count;

  protected bit chirp_done = 0;

  function new(string name = "usb_driver", uvm_component parent = null);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
    txn_count = 0;
    error_count = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usb_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "Virtual interface not found")
    if (!uvm_config_db#(usb_protocol_e)::get(this, "", "protocol", protocol))
      protocol = USB_HS;
    if (!uvm_config_db#(usb_protocol_cfg_t)::get(this, "", "cfg", cfg))
      `uvm_warning("CONFIG", "Protocol config not found, using defaults")
  endfunction

  task run_phase(uvm_phase phase);
    // Idle all host-driven PHY outputs
    vif.phy_driver_cb.utmi_txvalid    <= 1'b0;
    vif.phy_driver_cb.pipe_tx_elecidle<= 1'b1;
    vif.phy_driver_cb.pipe_power_down <= 1'b1;
    vif.phy_driver_cb.pd_msg_valid    <= 1'b0;
    vif.mac_driver_cb.mac_valid       <= 1'b0;
    vif.mac_driver_cb.dev_connected   <= 1'b0;
    vif.mac_driver_cb.dev_reset       <= 1'b0;
    vif.mac_driver_cb.dev_state       <= USB_STATE_POWERED;
    wait (vif.rst_n === 1'b1);
    forever begin
      usb_sequence_item req_item;
      seq_item_port.get_next_item(req_item);
      drive_item(req_item);
      seq_item_port.item_done();
    end
  endtask

  virtual task drive_item(usb_sequence_item item);
    usb_txn_descriptor txn = item.txn;
    `uvm_info("DRIVER", $sformatf("Driving: %s", txn.convert2string()), UVM_HIGH)
    wait (vif.rst_n === 1'b1);

    // Bus reset request from sequence: assert SE0 reset signaling first
    if (txn.dev_state == USB_STATE_RESET)
      do_bus_reset();

    txn.pid = usb_pid_encode(txn.txn_type);
    case (txn.protocol)
      USB_HS, EUSB2:             drive_usb2(txn);
      USB_SS, USB_SS_P, USB_SS_20: drive_usb3(txn);
      USB4:                      drive_usb4(txn);
      USB_PD:                    drive_usbpd(txn);
      default:                   drive_usb2(txn);
    endcase

    advance_state(txn);
    txn_count++;
    if (txn.status inside {XFER_CRC_ERR, XFER_TIMEOUT, XFER_STALL, XFER_BABBLE})
      error_count++;
    drv_ap.write(item);   // publish expected transaction
  endtask

  //==========================================================================
  // Device state machine advancement (POWERED->DEFAULT->ADDRESS->CONFIGURED)
  //==========================================================================
  virtual task advance_state(usb_txn_descriptor txn);
    @(vif.mac_driver_cb);
    vif.mac_driver_cb.dev_connected <= 1'b1;
    if (txn.dev_state == USB_STATE_RESET) begin
      vif.mac_driver_cb.dev_state <= USB_STATE_DEFAULT;
    end else if (txn.txn_type == TOK_SETUP) begin
      vif.mac_driver_cb.dev_state <= USB_STATE_ADDRESS;
    end else if (txn.txn_type inside {DATA_DATA0, DATA_DATA1, DATA_DATA2, DATA_MDATA,
                                      SS_DP_START, USB4_DATA, USB4_TUNNEL} &&
                 txn.status == XFER_OK) begin
      vif.mac_driver_cb.dev_state <= USB_STATE_CONFIGURED;
    end
    txn.dev_state = vif.dev_state;
  endtask

  //==========================================================================
  // Bus reset: SE0 for >= 2.5us (modeled as 16 cycles) then recovery to J
  //==========================================================================
  virtual task do_bus_reset();
    `uvm_info("DRIVER", "Asserting USB bus reset (SE0)", UVM_MEDIUM)
    @(vif.mac_driver_cb);
    vif.mac_driver_cb.dev_reset <= 1'b1;
    vif.mac_driver_cb.dev_state <= USB_STATE_RESET;
    repeat (16) @(vif.mac_driver_cb);
    vif.mac_driver_cb.dev_reset <= 1'b0;
    repeat (4) @(vif.mac_driver_cb);   // reset recovery interval
  endtask

  //==========================================================================
  // HS chirp negotiation: host asserts chirp K, device (DUT) answers with
  // alternating K/J; link then operates in HS mode.
  //==========================================================================
  virtual task usb2_chirp();
    int to = 0;
    `uvm_info("DRIVER", "HS chirp handshake (K -> device K/J response)", UVM_MEDIUM)
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.utmi_xcvr_select <= 2'b01;   // HS transceiver
    vif.phy_driver_cb.utmi_op_mode     <= 2'b10;   // disable bit-stuff/NRZI during chirp
    vif.phy_driver_cb.utmi_term_select <= 1'b1;    // HS termination
    // wait for device chirp response on linestate (K then J)
    while (vif.utmi_linestate !== 2'b10 && to < 40) begin
      @(posedge vif.clk); to++;
    end
    to = 0;
    while (vif.utmi_linestate !== 2'b01 && to < 40) begin
      @(posedge vif.clk); to++;
    end
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.utmi_op_mode <= 2'b00;       // resume normal NRZI operation
    chirp_done = 1;
  endtask

  //==========================================================================
  // Wait for device handshake response on UTMI (ACK/STALL/NAK) with timeout
  //==========================================================================
  virtual task usb2_wait_handshake(usb_txn_descriptor txn);
    int to = 0;
    bit got = 0;
    bit [7:0] hs_byte = 8'h00;
    while (to < 24 && !got) begin
      @(posedge vif.clk);
      if (vif.utmi_rxvalid === 1'b1 && vif.utmi_rxactive === 1'b1) begin
        hs_byte = vif.utmi_data;
        got = 1;
      end
      to++;
    end
    if (!got) begin
      txn.set_complete(XFER_TIMEOUT);
    end else begin
      case (usb_pid_decode(hs_byte))
        HS_ACK:   txn.set_complete(XFER_OK);
        HS_STALL: txn.set_complete(XFER_STALL);
        HS_NAK:   txn.set_complete(XFER_OK);   // NAK = flow control, retry later
        default:  txn.set_complete(XFER_OK);
      endcase
    end
    // Babble / CRC errors flagged by the device model take precedence
    if (txn.inject_babble)                    txn.set_complete(XFER_BABBLE);
    else if (txn.inject_crc_err)            txn.set_complete(XFER_CRC_ERR);
  endtask

  //==========================================================================
  // USB 2.0 / eUSB2 MAC + PHY Driving (UTMI/ULPI)
  // Packet format: SYNC + PID + (ADDR/EP | payload) + CRC16 trailer + EOP
  //==========================================================================
  virtual task drive_usb2(usb_txn_descriptor txn);
    int beats;
    int data_idx = 0;
    int total_len;
    bit is_data;
    bit is_token;
    bit [15:0] crc_t;

    is_data  = txn.txn_type inside {DATA_DATA0, DATA_DATA1, DATA_DATA2, DATA_MDATA};
    is_token = txn.txn_type inside {TOK_SOF, TOK_SETUP, TOK_IN, TOK_OUT, TOK_PING, TOK_SPLIT};
    crc_t = txn.crc16;
    if (txn.inject_crc_err) crc_t = crc_t ^ 16'h0001;   // corrupt CRC trailer
    total_len = is_data ? txn.packet_len + 2 : 0;

    // HS chirp negotiation once after reset
    if (protocol == USB_HS && !chirp_done) usb2_chirp();

    // ---- Token/Data packet header (MAC) ----
    @(vif.mac_driver_cb);
    vif.mac_driver_cb.mac_valid    <= 1'b1;
    vif.mac_driver_cb.mac_sop      <= 1'b1;
    vif.mac_driver_cb.mac_pid      <= txn.pid;
    vif.mac_driver_cb.mac_addr     <= txn.device_addr;
    vif.mac_driver_cb.mac_endpoint <= txn.endpoint;
    // Sideband: data packets carry total byte count (payload + CRC trailer)
    if (is_data)
      vif.mac_driver_cb.mac_frame_num <= total_len[10:0];
    else if (txn.txn_type == TOK_SOF)
      vif.mac_driver_cb.mac_frame_num <= txn.frame_number;
    else
      vif.mac_driver_cb.mac_frame_num <= 11'h0;

    // ---- PHY byte transmit (UTMI), NRZI/bit-stuff handled by PHY ----
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.utmi_txvalid     <= 1'b1;
    vif.phy_driver_cb.utmi_op_mode     <= 2'b00;   // normal operation
    vif.phy_driver_cb.utmi_term_select <= (protocol == USB_HS);
    vif.phy_driver_cb.utmi_data        <= txn.pid;

    // ---- Data phase (payload + CRC16 trailer) ----
    if (total_len > 0) begin
      beats = (total_len + 3) / 4;
      for (int i = 0; i < beats; i++) begin
        logic [31:0] beat_data = 32'h0;
        @(vif.mac_driver_cb);
        vif.mac_driver_cb.mac_sop <= 1'b0;
        for (int j = 0; j < 4 && data_idx < total_len; j++) begin
          if (data_idx < txn.packet_len)
            beat_data[j*8 +: 8] = txn.payload[data_idx];
          else if (data_idx == txn.packet_len)
            beat_data[j*8 +: 8] = crc_t[7:0];      // CRC16 low byte
          else
            beat_data[j*8 +: 8] = crc_t[15:8];     // CRC16 high byte
          data_idx++;
        end
        vif.mac_driver_cb.mac_data <= beat_data;
        @(vif.phy_driver_cb);
        vif.phy_driver_cb.utmi_data <= beat_data[7:0];
      end
    end

    // ---- EOP ----
    @(vif.mac_driver_cb);
    vif.mac_driver_cb.mac_eop   <= 1'b1;
    vif.mac_driver_cb.mac_valid <= 1'b0;
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.utmi_txvalid <= 1'b0;

    // ---- Inter-packet gap (min 2 bit times) ----
    repeat (txn.inter_packet_gap) @(vif.phy_driver_cb);

    // ---- Handshake phase from device (all except SOF/isochronous) ----
    if (txn.txn_type != TOK_SOF)
      usb2_wait_handshake(txn);
    else
      txn.set_complete(XFER_OK);
  endtask

  //==========================================================================
  // USB 3.x MAC + PHY Driving (PIPE)
  // Header packet then data packet with CRC32 trailer.
  //==========================================================================
  virtual task drive_usb3(usb_txn_descriptor txn);
    int beats;
    int data_idx = 0;
    int total_len;
    bit is_data;
    bit [31:0] crc_t;

    is_data = txn.txn_type inside {SS_DP_START, DATA_DATA0, DATA_DATA1};
    crc_t = txn.crc32;
    if (txn.inject_crc_err) crc_t = crc_t ^ 32'h0000_0001;
    total_len = is_data ? txn.packet_len + 4 : 0;

    // ---- Link training: exit electrical idle, wait PHY ready (U0) ----
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.pipe_power_down  <= 1'b0;
    vif.phy_driver_cb.pipe_tx_elecidle <= 1'b0;
    wait (vif.phy_driver_cb.pipe_phy_ready === 1'b1);

    // ---- Header packet (MAC) ----
    @(vif.mac_driver_cb);
    vif.mac_driver_cb.mac_valid    <= 1'b1;
    vif.mac_driver_cb.mac_sop      <= 1'b1;
    vif.mac_driver_cb.mac_pid      <= txn.pid;
    vif.mac_driver_cb.mac_addr     <= txn.device_addr;
    vif.mac_driver_cb.mac_endpoint <= txn.endpoint;
    vif.mac_driver_cb.mac_frame_num <= total_len[10:0];   // sideband length

    // ---- PIPE TX: header uses K-characters ----
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.pipe_tx_data  <= {txn.device_addr, txn.endpoint, txn.pid, 8'h00};
    vif.phy_driver_cb.pipe_tx_datak <= 4'b1111;   // K-char for header

    // ---- Data packet payload (+ CRC32 trailer) ----
    if (total_len > 0) begin
      beats = (total_len + 3) / 4;
      for (int i = 0; i < beats; i++) begin
        logic [31:0] beat_data = 32'h0;
        @(vif.mac_driver_cb);
        vif.mac_driver_cb.mac_sop <= 1'b0;
        for (int j = 0; j < 4 && data_idx < total_len; j++) begin
          if (data_idx < txn.packet_len)
            beat_data[j*8 +: 8] = txn.payload[data_idx];
          else begin
            int crc_idx = data_idx - txn.packet_len;
            beat_data[j*8 +: 8] = crc_t[crc_idx*8 +: 8];
          end
          data_idx++;
        end
        vif.mac_driver_cb.mac_data <= beat_data;
        @(vif.phy_driver_cb);
        vif.phy_driver_cb.pipe_tx_data  <= beat_data;
        vif.phy_driver_cb.pipe_tx_datak <= 4'b0000;   // D-char for data
      end
    end

    // ---- End packet: return to electrical idle ----
    @(vif.mac_driver_cb);
    vif.mac_driver_cb.mac_eop   <= 1'b1;
    vif.mac_driver_cb.mac_valid <= 1'b0;
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.pipe_tx_elecidle <= 1'b1;

    // ---- Device link-layer response: loopback rx_valid = ACK/timeout ----
    begin
      int to = 0;
      bit got = 0;
      while (to < 24 && !got) begin
        @(posedge vif.clk);
        if (vif.pipe_rx_valid === 1'b1) got = 1;
        to++;
      end
      if (!got)                              txn.set_complete(XFER_TIMEOUT);
      else if (vif.crc32_error === 1'b1)     txn.set_complete(XFER_CRC_ERR);
      else                                   txn.set_complete(XFER_OK);
    end
  endtask

  //==========================================================================
  // USB4 MAC + PHY Driving (PIPE4)
  // Control block then tunneled data blocks with CRC32 trailer.
  //==========================================================================
  virtual task drive_usb4(usb_txn_descriptor txn);
    int beats;
    int data_idx = 0;
    int total_len;
    bit [31:0] crc_t;

    crc_t = txn.crc32;
    if (txn.inject_crc_err) crc_t = crc_t ^ 32'h0000_0001;
    total_len = (txn.txn_type inside {USB4_DATA, USB4_TUNNEL}) ?
                txn.packet_len + 4 : 0;

    // ---- Wait for link ready (adapter layer up) ----
    wait (vif.phy_driver_cb.pipe4_link_ready === 1'b1);

    // ---- Control packet (MAC) ----
    @(vif.mac_driver_cb);
    vif.mac_driver_cb.mac_valid <= 1'b1;
    vif.mac_driver_cb.mac_sop   <= 1'b1;
    vif.mac_driver_cb.mac_pid   <= txn.pid;
    vif.mac_driver_cb.mac_addr  <= txn.device_addr;
    vif.mac_driver_cb.mac_endpoint <= txn.endpoint;
    vif.mac_driver_cb.mac_frame_num <= total_len[10:0];   // sideband length

    // ---- PIPE4 TX: control sync header + block start ----
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.pipe4_tx_sync_hdr  <= 4'b1010;   // Control sync
    vif.phy_driver_cb.pipe4_tx_blk_start <= 1'b1;
    vif.phy_driver_cb.pipe4_tx_data      <= {96'h0, txn.device_addr, txn.endpoint, txn.pid, 16'h0};
    vif.phy_driver_cb.pipe4_tx_datak     <= {14'h0, 2'b11};

    // ---- Tunneled data blocks ----
    if (total_len > 0) begin
      beats = (total_len + 15) / 16;
      for (int i = 0; i < beats; i++) begin
        logic [127:0] beat_data = 128'h0;
        @(vif.mac_driver_cb);
        vif.mac_driver_cb.mac_sop <= 1'b0;
        for (int j = 0; j < 16 && data_idx < total_len; j++) begin
          if (data_idx < txn.packet_len)
            beat_data[j*8 +: 8] = txn.payload[data_idx];
          else begin
            int crc_idx = data_idx - txn.packet_len;
            beat_data[j*8 +: 8] = crc_t[crc_idx*8 +: 8];
          end
          data_idx++;
        end
        vif.mac_driver_cb.mac_data <= beat_data[31:0];
        @(vif.phy_driver_cb);
        vif.phy_driver_cb.pipe4_tx_data      <= beat_data;
        vif.phy_driver_cb.pipe4_tx_blk_start <= 1'b0;
      end
    end

    @(vif.mac_driver_cb);
    vif.mac_driver_cb.mac_eop   <= 1'b1;
    vif.mac_driver_cb.mac_valid <= 1'b0;

    // ---- Link-layer response via loopback ----
    begin
      int to = 0;
      bit got = 0;
      while (to < 24 && !got) begin
        @(posedge vif.clk);
        if (vif.pipe4_rx_valid === 1'b1) got = 1;
        to++;
      end
      if (!got)                              txn.set_complete(XFER_TIMEOUT);
      else if (vif.crc32_error === 1'b1)     txn.set_complete(XFER_CRC_ERR);
      else                                   txn.set_complete(XFER_OK);
    end
  endtask

  //==========================================================================
  // USB-PD MAC + PHY Driving (SBU / BMC on CC line)
  // SOP* message: header + data objects, then GoodCRC from partner and
  // (for Request) PS_RDY followed by the Vbus transition.
  //==========================================================================
  virtual task drive_usbpd(usb_txn_descriptor txn);
    // ---- CC line state: source presents Vbus ----
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.pd_role         <= 3'b001;   // Source
    vif.phy_driver_cb.pd_vbus_present <= 1'b1;
    vif.phy_driver_cb.pd_vbus_valid   <= 1'b1;

    // ---- PD message (MAC) ----
    @(vif.mac_driver_cb);
    vif.mac_driver_cb.mac_valid <= 1'b1;
    vif.mac_driver_cb.mac_sop   <= 1'b1;
    vif.mac_driver_cb.mac_pid   <= txn.pid;
    vif.mac_driver_cb.mac_addr  <= txn.device_addr;
    vif.mac_driver_cb.mac_endpoint <= txn.endpoint;
    vif.mac_driver_cb.mac_frame_num <= 11'h0;

    // ---- SBU PHY: BMC-encodes message on CC (differential CC1/CC2) ----
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.pd_cc1       <= 1'b1;
    vif.phy_driver_cb.pd_cc2       <= 1'b0;
    vif.phy_driver_cb.pd_msg_valid <= 1'b1;
    vif.phy_driver_cb.pd_msg_type  <= txn.pd_contract[2:0];
    vif.phy_driver_cb.pd_header    <= {txn.voltage_mv[15:0], txn.current_ma[7:0], 8'h00};

    // ---- Data objects (if any) ----
    if (txn.packet_len > 0) begin
      for (int i = 0; i < txn.packet_len && i < 260; i++) begin
        @(vif.mac_driver_cb);
        vif.mac_driver_cb.mac_sop  <= 1'b0;
        vif.mac_driver_cb.mac_data <= {24'h0, txn.payload[i]};
      end
    end

    @(vif.mac_driver_cb);
    vif.mac_driver_cb.mac_eop   <= 1'b1;
    vif.mac_driver_cb.mac_valid <= 1'b0;
    @(vif.phy_driver_cb);
    vif.phy_driver_cb.pd_msg_valid <= 1'b0;
    vif.phy_driver_cb.pd_cc1       <= 1'b0;
    vif.phy_driver_cb.pd_cc2       <= 1'b1;

    // ---- Wait for contract establishment: PD controller model moves Vbus
    //      to the requested voltage after Accept/PS_RDY ----
    begin
      int to = 0;
      bit got = 0;
      int target = txn.voltage_mv / 25;
      while (to < 60 && !got) begin
        @(posedge vif.clk);
        if (vif.pd_vbus_voltage == target[10:0]) got = 1;
        to++;
      end
      if (got) txn.set_complete(XFER_OK);
      else     txn.set_complete(XFER_TIMEOUT);
    end
  endtask

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("DRIVER_REPORT", $sformatf(
      "Protocol: %s | Total Driven: %0d | Errors: %0d",
      protocol.name(), txn_count, error_count), UVM_LOW)
  endfunction
endclass
`endif
