// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB 3.2 link-layer UVM agent (downstream / host port) for an upstream
// device port on usb3_link_if:
//   usb3_item / usb3_driver   one LFPS burst, ordered set, header packet,
//                             link command or DPP word per clock
//   usb3_monitor              host items and device link commands / headers
//   usb3_scoreboard           predicts the device link layer: LGOOD_n /
//                             LBAD / LRTY / LAU / LXU in order, LCRD_A..D
//                             order, U0-entry advertisement, HdrSeq and
//                             CRC-16 / CRC-5 of device headers, resend
//                             after LBAD and Recovery, Port Capability and
//                             Port Configuration Response contents, LPMA
//                             before Ux, U1 -> U2 inactivity timing,
//                             DPP / ITP / TP counters
//   usb3_coverage             LTSSM transitions, link commands both ways,
//                             LMP subtypes, header errors, Gen1/Gen2 blocks
//   sequences + usb3_env + usb3_link_test
`ifndef USB3_LINK_PKG_SV
`define USB3_LINK_PKG_SV

package usb3_link_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // LTSSM encoding of the device (ltssm output)
  localparam logic [3:0] S_RXDET = 4'd0, S_PLFPS = 4'd1, S_PACT = 4'd2, S_PCFG = 4'd3,
                         S_U0 = 4'd4, S_U1 = 4'd5, S_U2 = 4'd6, S_U3 = 4'd7,
                         S_RACT = 4'd8, S_RCFG = 4'd9, S_HRST = 4'd10;
  localparam logic [4:0] T_LMP = 5'b00000, T_TP = 5'b00100, T_DPH = 5'b01000, T_ITP = 5'b01100;
  localparam logic [6:0] DEV_ADDR = 7'd5;

  typedef enum int { K_TS1, K_TS2, K_HP, K_LC, K_DPP, K_LFPS, K_IDLE, K_FAR, K_BUSY } usb3_kind_e;

  // ------------------------------------------------------------ encodings
  function automatic logic [4:0] crc5(input logic [10:0] d);
    logic [4:0] c;
    c = 5'h1F;
    for (int i = 0; i < 11; i++) c = (c[4] ^ d[i]) ? ({c[3:0], 1'b0} ^ 5'h05) : {c[3:0], 1'b0};
    return ~c;
  endfunction
  function automatic logic [15:0] crc16(input logic [95:0] d);
    logic [15:0] c;
    c = 16'hFFFF;
    for (int i = 0; i < 96; i++) c = (c[15] ^ d[i]) ? ({c[14:0], 1'b0} ^ 16'h100B) : {c[14:0], 1'b0};
    return ~c;
  endfunction
  function automatic logic [31:0] crc32(input logic [31:0] c0, input logic [31:0] d);
    logic [31:0] c;
    c = c0;
    for (int i = 0; i < 32; i++) c = (c[31] ^ d[i]) ? ({c[30:0], 1'b0} ^ 32'h04C1_1DB7) : {c[30:0], 1'b0};
    return c;
  endfunction
  function automatic logic [15:0] lcw(input logic [1:0] cls, input logic [1:0] typ, input logic [3:0] sub);
    return {crc5({cls, typ, 3'b000, sub}), cls, typ, 3'b000, sub};
  endfunction
  function automatic logic [15:0] lc_lgood(input int n); return lcw(2'b00, 2'b00, 4'(n % 8)); endfunction
  function automatic logic [15:0] lc_lcrd(input int x);  return lcw(2'b00, 2'b01, 4'(x % 4)); endfunction
  function automatic logic [15:0] lc_lrty();             return lcw(2'b00, 2'b10, 4'd0); endfunction
  function automatic logic [15:0] lc_lbad();             return lcw(2'b00, 2'b11, 4'd0); endfunction
  function automatic logic [15:0] lc_lgo(input int x);   return lcw(2'b01, 2'b00, 4'(x)); endfunction
  function automatic logic [15:0] lc_lau();              return lcw(2'b01, 2'b01, 4'd0); endfunction
  function automatic logic [15:0] lc_lxu();              return lcw(2'b01, 2'b10, 4'd0); endfunction
  function automatic logic [15:0] lc_lpma();             return lcw(2'b01, 2'b11, 4'd0); endfunction
  function automatic logic [127:0] seal(input logic [95:0] h, input int seq);
    logic [10:0] l;
    l = {8'h00, 3'(seq)};
    return {crc5(l), l, crc16(h), h};
  endfunction
  function automatic logic [95:0] hdr_lmp(input int sub, input logic [7:0] f, input logic [31:0] dw1 = 0);
    return {32'h0, dw1, 15'h0, f, 4'(sub), T_LMP};
  endfunction
  function automatic logic [95:0] hdr_tp(input logic [6:0] a);     return {64'h0, a, 20'h0, T_TP}; endfunction
  function automatic logic [95:0] hdr_itp(input logic [26:0] t);   return {64'h0, t, T_ITP}; endfunction
  function automatic logic [95:0] hdr_dph(input logic [15:0] len); return {32'h0, len, 16'h0, 27'h0, T_DPH}; endfunction
  function automatic logic [95:0] hdr_dev_cap(input bit g2);
    return {32'h0, 14'h0, 2'b01, 8'h00, 8'h04, 15'h0, g2 ? 8'h03 : 8'h01, 4'd4, T_LMP};
  endfunction
  function automatic string lc_name(input logic [15:0] w);
    case (w[10:7])
      4'b0000: return $sformatf("LGOOD_%0d", w[2:0]);
      4'b0001: return $sformatf("LCRD_%s", string'(8'h41 + w[1:0]));
      4'b0010: return "LRTY";
      4'b0011: return "LBAD";
      4'b0100: return $sformatf("LGO_U%0d", w[1:0]);
      4'b0101: return "LAU";
      4'b0110: return "LXU";
      4'b0111: return "LPMA";
      default: return $sformatf("LC(%04h)", w);
    endcase
  endfunction

  // ------------------------------------------------------------ item
  class usb3_item extends uvm_sequence_item;
    `uvm_object_utils(usb3_item)
    usb3_kind_e   kind = K_IDLE;
    logic [127:0] hdr  = '0;
    logic [15:0]  lc   = '0;
    logic [31:0]  dw   = '0;
    bit           last;
    bit           ts_reset;
    bit           gen2cap;
    bit           level;        // K_FAR / K_BUSY
    int           n = 1;        // K_IDLE clocks
    bit           blk_set;      // drive blk instead of the right block header
    logic [3:0]   blk;
    function new(string name = "usb3_item"); super.new(name); endfunction
    virtual function string convert2string();
      case (kind)
        K_HP:    return $sformatf("HP seq=%0d type=%02h", hdr[114:112], hdr[4:0]);
        K_LC:    return lc_name(lc);
        K_DPP:   return $sformatf("DPP %08h%s", dw, last ? " (CRC)" : "");
        default: return kind.name();
      endcase
    endfunction
  endclass

  // observed on the link (both directions, one clock)
  class usb3_obs extends uvm_object;
    `uvm_object_utils(usb3_obs)
    bit           rx_valid;
    logic [2:0]   rx_kind;
    logic [127:0] rx_hdr;
    logic [15:0]  rx_lc;
    logic [31:0]  rx_dw;
    bit           rx_last, rx_ts_reset, lfps, app_busy;
    logic [3:0]   rx_blk;
    logic [3:0]   ltssm, ltssm_next;
    bit           gen2;
    logic [2:0]   rx_free;
    bit           tx_lc_valid, tx_hp_valid;
    logic [15:0]  tx_lc;
    logic [127:0] tx_hp;
    function new(string name = "usb3_obs"); super.new(name); endfunction
  endclass

  typedef uvm_sequencer #(usb3_item) usb3_sequencer;

  // ------------------------------------------------------------ driver
  class usb3_driver extends uvm_driver #(usb3_item);
    `uvm_component_utils(usb3_driver)
    virtual usb3_link_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual usb3_link_if)::get(this, "", "usb3_vif", vif))
        `uvm_fatal("NOVIF", "usb3_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      usb3_item t;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(t);
        drive(t);
        seq_item_port.item_done();
      end
    endtask
    task drive(usb3_item t);
      @(negedge vif.clk);
      case (t.kind)
        K_IDLE: begin repeat (t.n - 1) @(negedge vif.clk); return; end
        K_FAR:  begin vif.far_end_ready = t.level; return; end
        K_BUSY: begin vif.app_busy = t.level; return; end
        K_LFPS: begin vif.lfps = 1'b1; vif.gen2_cap = t.gen2cap; end
        default: begin
          vif.rx_valid = 1'b1;
          vif.rx_kind  = (t.kind == K_TS1) ? 3'd0 : (t.kind == K_TS2) ? 3'd1 : (t.kind == K_HP) ? 3'd2 :
                         (t.kind == K_LC) ? 3'd3 : 3'd4;
          vif.rx_ts_reset = t.ts_reset;
          vif.rx_hdr  = t.hdr;
          vif.rx_lc   = t.lc;
          vif.rx_dw   = t.dw;
          vif.rx_last = t.last;
          vif.rx_blk  = t.blk_set ? t.blk : (t.kind == K_TS1 || t.kind == K_TS2) ? 4'b0011 : 4'b1100;
        end
      endcase
      @(posedge vif.clk);
      #1;
      vif.rx_valid = 1'b0; vif.lfps = 1'b0; vif.gen2_cap = 1'b0; vif.rx_ts_reset = 1'b0; vif.rx_last = 1'b0;
    endtask
  endclass

  // ------------------------------------------------------------ monitor
  class usb3_monitor extends uvm_monitor;
    `uvm_component_utils(usb3_monitor)
    virtual usb3_link_if vif;
    uvm_analysis_port #(usb3_obs) ap;
    function new(string name, uvm_component parent); super.new(name, parent); ap = new("ap", this); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual usb3_link_if)::get(this, "", "usb3_vif", vif))
        `uvm_fatal("NOVIF", "usb3_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      usb3_obs o;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n !== 1'b1) continue;
        o = usb3_obs::type_id::create("o");
        o.rx_valid = vif.rx_valid; o.rx_kind = vif.rx_kind; o.rx_hdr = vif.rx_hdr; o.rx_lc = vif.rx_lc;
        o.rx_dw = vif.rx_dw; o.rx_last = vif.rx_last; o.rx_ts_reset = vif.rx_ts_reset; o.lfps = vif.lfps;
        o.rx_blk = vif.rx_blk; o.app_busy = vif.app_busy; o.ltssm = vif.ltssm; o.gen2 = vif.gen2;
        o.rx_free = vif.rx_free; o.tx_lc_valid = vif.tx_lc_valid; o.tx_lc = vif.tx_lc;
        o.tx_hp_valid = vif.tx_hp_valid; o.tx_hp = vif.tx_hp;
        #1 o.ltssm_next = vif.ltssm;
        ap.write(o);
      end
    endtask
  endclass

  // ------------------------------------------------------------ scoreboard
  class usb3_scoreboard extends uvm_subscriber #(usb3_obs);
    `uvm_component_utils(usb3_scoreboard)
    virtual usb3_link_if vif;
    // receive-side prediction
    int unsigned rx_seq, n_lgood, n_lbad, n_hp_bad, n_tp, n_itp, n_dpp_good, n_dpp_bad;
    bit          wait_lrty, in_dpp, dpp_err, cap_seen, force_pm, port_cap_due;
    logic [15:0] dpp_len, dpp_got;
    logic [31:0] dpp_crc;
    logic [7:0]  u2_tmo;
    logic [15:0] exp_lc [$];
    logic [95:0] exp_hp [$];      // headers the device must send, in order (not yet sent)
    // transmit side
    logic [95:0] dev_unacked [$]; // device headers sent and not acknowledged
    int unsigned dev_seq_ack;     // HdrSeq of the oldest unacked device header
    int unsigned dev_sent;        // of the unacked ones, sent since the last (re)start
    int unsigned lcrd_idx, n_dev_hp, n_resend, n_lc_seen, errors;
    bit          lau_pending, lpma_seen;
    int unsigned lau_target, u1_clocks;
    logic [3:0]  prev_ltssm;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      void'(uvm_config_db#(virtual usb3_link_if)::get(this, "", "usb3_vif", vif));
      prev_ltssm = S_RXDET;
      link_init();
    endfunction
    function void link_init();
      rx_seq = 0; wait_lrty = 0; in_dpp = 0; cap_seen = 0; lcrd_idx = 0;
      dev_unacked.delete(); exp_hp.delete(); dev_seq_ack = 0; dev_sent = 0;
      lau_pending = 0; lpma_seen = 0;
    endfunction
    function void err(string m);
      errors++;
      `uvm_error("USB3_SB", m)
    endfunction
    function bit blk_ok(usb3_obs o);
      logic [3:0] want, x;
      want = (o.rx_kind <= 3'd1) ? 4'b0011 : 4'b1100;
      x = o.rx_blk ^ want;
      return !o.gen2 || x == 4'b0000 || (x[0] + x[1] + x[2] + x[3]) == 1;
    endfunction

    function void write(usb3_obs o);
      bit item;
      logic [95:0] h;
      logic [10:0] l;
      item = o.rx_valid && blk_ok(o);

      // link initialisation and U0 entry
      if (o.ltssm == S_RXDET && o.ltssm_next == S_PLFPS) begin link_init(); port_cap_due = 1; end
      if (o.ltssm == S_HRST && o.ltssm_next == S_U0) begin
        link_init(); port_cap_due = 0;
        exp_lc.push_back(lc_lgood(7));
      end
      else if (o.ltssm != S_U0 && o.ltssm_next == S_U0) begin
        exp_lc.push_back(lc_lgood(rx_seq + 7));
        dev_sent = 0;
        if (port_cap_due && o.ltssm == S_PCFG) begin
          exp_hp.push_back(hdr_dev_cap(o.gen2)); port_cap_due = 0;
        end
      end
      if (o.ltssm == S_U0 && o.ltssm_next == S_RACT) begin in_dpp = 0; lau_pending = 0; end

      // receive path
      if (o.ltssm == S_U0 && item && o.rx_kind == 3'd2) begin
        h = o.rx_hdr[95:0];
        l = o.rx_hdr[122:112];
        if (o.rx_hdr[111:96] != crc16(h) || o.rx_hdr[127:123] != crc5(l)) begin
          n_hp_bad++;
          if (!wait_lrty) exp_lc.push_back(lc_lbad());
          wait_lrty = 1;
        end
        else if (wait_lrty) ;
        else if (l[2:0] != 3'(rx_seq) || (o.rx_free == 3'd0 && (o.app_busy || o.ltssm_next == S_RACT))) begin
          // a buffer freed in this clock takes the header; otherwise no buffer: Recovery
          if (o.ltssm_next != S_RACT) err($sformatf("header seq %0d (want %0d) free %0d: no Recovery",
                                                     l[2:0], rx_seq % 8, o.rx_free));
        end
        else begin
          exp_lc.push_back(lc_lgood(rx_seq));
          rx_seq++; n_lgood++;
          case (h[4:0])
            T_LMP: case (h[8:5])
                     4'd1: force_pm = h[10];
                     4'd2: u2_tmo = h[16:9];
                     4'd4: cap_seen = 1;
                     4'd5: exp_hp.push_back(hdr_lmp(6, (cap_seen && (h[16:9] == 8'h01 ||
                                                         (h[16:9] == 8'h02 && o.gen2))) ? 8'h01 : 8'h00));
                     default: ;
                   endcase
            T_TP:  if (h[31:25] == DEV_ADDR) n_tp++;
            T_ITP: n_itp++;
            T_DPH: begin in_dpp = 1; dpp_len = h[63:48]; dpp_got = 0; dpp_crc = '1; dpp_err = 0; end
            default: ;
          endcase
        end
      end
      if (o.ltssm == S_U0 && o.rx_valid && o.rx_kind == 3'd4) begin
        if (!item) begin if (in_dpp) dpp_err = 1; end
        else if (!in_dpp) n_dpp_bad++;
        else if (o.rx_last) begin
          in_dpp = 0;
          if (!dpp_err && o.rx_dw == ~dpp_crc && dpp_got == dpp_len) n_dpp_good++; else n_dpp_bad++;
        end
        else begin dpp_crc = crc32(dpp_crc, o.rx_dw); dpp_got += 4; end
      end
      if (o.ltssm == S_U0 && item && o.rx_kind == 3'd3 && o.rx_lc[15:11] == crc5(o.rx_lc[10:0]))
        host_lc(o);

      // Ux bookkeeping
      if (o.ltssm_next inside {S_U1, S_U2, S_U3} && o.ltssm == S_U0) begin
        if (!lpma_seen) err("Ux entered without LPMA after LAU");
        if (o.ltssm_next != S_U1 + 4'(lau_target - 1)) err("Ux state differs from the LGO target");
        lpma_seen = 0; u1_clocks = 0;
      end
      if (o.ltssm == S_U1) begin
        u1_clocks++;
        if (o.ltssm_next == S_U2 && (u2_tmo == 0 || u1_clocks != (u2_tmo + 1) * 16))
          err($sformatf("U1 -> U2 after %0d clocks, timeout %0d", u1_clocks, u2_tmo));
        if (o.ltssm_next == S_U1 && u2_tmo != 0 && u1_clocks >= (u2_tmo + 1) * 16)
          err("U1 inactivity timeout missed");
      end

      // device link commands
      if (o.tx_lc_valid) begin
        n_lc_seen++;
        if (o.tx_lc[15:11] != crc5(o.tx_lc[10:0])) err($sformatf("device LC %04h bad CRC-5", o.tx_lc));
        else if (o.tx_lc[10:7] == 4'b0001) begin
          if (o.tx_lc[1:0] != 2'(lcrd_idx)) err($sformatf("%s out of order (want LCRD_%s)",
                                                lc_name(o.tx_lc), string'(8'h41 + lcrd_idx % 4)));
          lcrd_idx++;
        end
        else if (exp_lc.size() == 0) err($sformatf("unexpected %s", lc_name(o.tx_lc)));
        else begin
          if (o.tx_lc !== exp_lc[0]) err($sformatf("device sent %s, want %s", lc_name(o.tx_lc), lc_name(exp_lc[0])));
          if (o.tx_lc[10:7] == 4'b0101) begin lau_pending = 1; lpma_seen = 0; end
          void'(exp_lc.pop_front());
        end
      end

      // device headers
      if (o.tx_hp_valid) device_hp(o);
      prev_ltssm = o.ltssm_next;
    endfunction

    function void host_lc(usb3_obs o);
      int unsigned d, k;
      case (o.rx_lc[10:7])
        4'b0010: wait_lrty = 0;                                        // LRTY
        4'b0000: begin                                                 // LGOOD_n
          d = (o.rx_lc[2:0] - dev_seq_ack) % 8;
          if (d < dev_unacked.size()) begin
            for (k = 0; k <= d; k++) void'(dev_unacked.pop_front());
            dev_seq_ack = (dev_seq_ack + d + 1) % 8;
            dev_sent = (dev_sent > d + 1) ? dev_sent - d - 1 : 0;
          end
        end
        4'b0011: begin                                                 // LBAD
          exp_lc.push_back(lc_lrty());
          dev_sent = 0;
        end
        4'b0100:                                                       // LGO_Ux
          if (!lau_pending && o.rx_lc[1:0] != 2'd0) begin
            lau_target = o.rx_lc[1:0];
            if (o.rx_lc[1:0] == 2'd3 || (force_pm && dev_unacked.size() == 0 && exp_hp.size() == 0))
              exp_lc.push_back(lc_lau());
            else exp_lc.push_back(lc_lxu());
          end
        4'b0111: if (lau_pending) begin lpma_seen = 1; lau_pending = 0; end   // LPMA
        default: ;
      endcase
    endfunction

    function void device_hp(usb3_obs o);
      logic [95:0] h;
      int unsigned seq;
      h = o.tx_hp[95:0];
      seq = o.tx_hp[114:112];
      n_dev_hp++;
      if (o.tx_hp[111:96] != crc16(h) || o.tx_hp[127:123] != crc5(o.tx_hp[122:112]))
        err("device header with a bad CRC-16 / CRC-5");
      if (seq != (dev_seq_ack + dev_sent) % 8)
        err($sformatf("device HdrSeq %0d, want %0d", seq, (dev_seq_ack + dev_sent) % 8));
      if (dev_sent < dev_unacked.size()) begin                         // resend
        n_resend++;
        if (h !== dev_unacked[dev_sent]) err("resent header differs");
      end
      else if (exp_hp.size() == 0) err($sformatf("unexpected device header %024h", h));
      else begin
        if (h !== exp_hp[0]) err($sformatf("device header %024h, want %024h", h, exp_hp[0]));
        dev_unacked.push_back(h);
        void'(exp_hp.pop_front());
      end
      dev_sent++;
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_lc.size() != 0) err($sformatf("%0d expected link commands not sent (first %s)",
                                            exp_lc.size(), lc_name(exp_lc[0])));
      if (vif != null) begin
        if (vif.hp_good != 8'(n_lgood)) err($sformatf("hp_good %0d, predicted %0d", vif.hp_good, n_lgood));
        if (vif.dpp_good != 8'(n_dpp_good) || vif.dpp_bad != 8'(n_dpp_bad))
          err($sformatf("DPP good/bad %0d/%0d, predicted %0d/%0d", vif.dpp_good, vif.dpp_bad, n_dpp_good, n_dpp_bad));
        if (vif.tp_mine != 8'(n_tp) || vif.itp_cnt != 8'(n_itp)) err("TP / ITP counts differ");
      end
    endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("USB3_SB", $sformatf("checks=%0d headers LGOOD=%0d bad=%0d device headers=%0d (resent %0d) LCs=%0d DPP %0d/%0d errors=%0d",
                n_lc_seen + n_dev_hp + n_lgood, n_lgood, n_hp_bad, n_dev_hp, n_resend, n_lc_seen,
                n_dpp_good, n_dpp_bad, errors), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ coverage
  class usb3_coverage extends uvm_subscriber #(usb3_obs);
    `uvm_component_utils(usb3_coverage)
    logic [3:0] from_s, to_s;
    logic [3:0] lc_t;
    logic [3:0] lmp_sub;
    int         herr;           // 0 good 1 CRC-16 2 CRC-5 3 seq 4 overrun
    int         blk;            // 0 exact 1 corrected 2 dropped
    bit         g2, dir_dev;
    logic [7:0] u2;
    covergroup cg_ltssm;
      cp_tr: coverpoint {from_s, to_s} {
        bins rxdet_poll = {8'h01};
        bins poll_tmo   = {8'h10};
        bins act_cfg    = {8'h23};
        bins cfg_u0     = {8'h34};
        bins u0_u1      = {8'h45};
        bins u0_u2      = {8'h46};
        bins u0_u3      = {8'h47};
        bins u0_rec     = {8'h48};
        bins u1_u2      = {8'h56};
        bins u2_rec     = {8'h68};
        bins u3_rec     = {8'h78};
        bins rec_cfg    = {8'h89};
        bins rcfg_u0    = {8'h94};
        bins rec_hrst   = {8'h8A};
        bins hrst_u0    = {8'hA4};
        bins rec_tmo    = {8'h80};
      }
      cp_gen: coverpoint g2;
    endgroup
    covergroup cg_lc;
      cp_dev:  coverpoint lc_t iff (dir_dev) { bins lgood = {0}; bins lcrd = {1}; bins lrty = {2};
                                                bins lbad = {3}; bins lau = {5}; bins lxu = {6}; }
      cp_host: coverpoint lc_t iff (!dir_dev) { bins lgood = {0}; bins lcrd = {1}; bins lrty = {2};
                                                bins lbad = {3}; bins lgo = {4}; bins lpma = {7}; }
    endgroup
    covergroup cg_hdr;
      cp_err: coverpoint herr { bins good = {0}; bins crc16 = {1}; bins crc5 = {2}; bins seq = {3}; bins overrun = {4}; }
      cp_lmp: coverpoint lmp_sub { bins slf = {1}; bins u2t = {2}; bins pcap = {4}; bins pcfg = {5}; bins pcfg_rsp = {6}; }
      cp_blk: coverpoint blk { bins exact = {0}; bins fixed = {1}; bins dropped = {2}; }
      cp_u2: coverpoint u2 { bins off = {0}; bins on = {[1:255]}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      cg_ltssm = new(); cg_lc = new(); cg_hdr = new();
    endfunction
    function void write(usb3_obs o);
      logic [3:0] x;
      g2 = o.gen2;
      if (o.ltssm != o.ltssm_next) begin from_s = o.ltssm; to_s = o.ltssm_next; cg_ltssm.sample(); end
      if (o.tx_lc_valid) begin lc_t = o.tx_lc[10:7]; dir_dev = 1; cg_lc.sample(); end
      if (o.rx_valid && o.rx_kind == 3'd3 && o.ltssm == S_U0) begin lc_t = o.rx_lc[10:7]; dir_dev = 0; cg_lc.sample(); end
      lmp_sub = 4'd0; herr = -1; blk = -1; u2 = 8'hFF;
      if (o.rx_valid && o.gen2) begin
        x = o.rx_blk ^ ((o.rx_kind <= 3'd1) ? 4'b0011 : 4'b1100);
        blk = (x == 0) ? 0 : ((x[0] + x[1] + x[2] + x[3]) == 1) ? 1 : 2;
      end
      if (o.rx_valid && o.rx_kind == 3'd2 && o.ltssm == S_U0) begin
        if (o.rx_hdr[111:96] != crc16(o.rx_hdr[95:0])) herr = 1;
        else if (o.rx_hdr[127:123] != crc5(o.rx_hdr[122:112])) herr = 2;
        else if (o.ltssm_next == S_RACT) herr = (o.rx_free == 0) ? 4 : 3;
        else herr = 0;
        if (o.rx_hdr[4:0] == T_LMP) begin
          lmp_sub = o.rx_hdr[8:5];
          if (lmp_sub == 4'd2) u2 = o.rx_hdr[16:9];
        end
      end
      if (o.tx_hp_valid && o.tx_hp[4:0] == T_LMP) lmp_sub = o.tx_hp[8:5];
      if (herr >= 0 || blk >= 0 || lmp_sub != 0 || u2 != 8'hFF) cg_hdr.sample();
    endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("USB3_COV", $sformatf("ltssm %0.1f%%  link commands %0.1f%%  headers %0.1f%%",
                cg_ltssm.get_coverage(), cg_lc.get_coverage(), cg_hdr.get_coverage()), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ sequences
  class usb3_base_seq extends uvm_sequence #(usb3_item);
    `uvm_object_utils(usb3_base_seq)
    virtual usb3_link_if vif;
    int hseq, hcrd, dseq;           // host HdrSeq, next LCRD to give, next device header to ack
    function new(string name = "usb3_base_seq"); super.new(name); endfunction
    task pre_body();
      if (vif == null) void'(uvm_config_db#(virtual usb3_link_if)::get(null, "*", "usb3_vif", vif));
    endtask
    task send(usb3_item t); start_item(t); finish_item(t); endtask
    function void note(string m);
      `uvm_info("USB3_SEQ", $sformatf("%s: ltssm=%0d gen2=%0d hp_good=%0d", m, vif.ltssm, vif.gen2, vif.hp_good), UVM_LOW)
    endfunction
    task one(usb3_kind_e k, bit rst = 0, bit lvl = 0, bit g2 = 0);
      usb3_item t = usb3_item::type_id::create("t");
      t.kind = k; t.ts_reset = rst; t.level = lvl; t.gen2cap = g2;
      send(t);
    endtask
    task idle(int n);
      usb3_item t = usb3_item::type_id::create("t");
      t.kind = K_IDLE; t.n = n;
      send(t);
    endtask
    task hp(logic [127:0] w, bit bset = 0, logic [3:0] b = 0);
      usb3_item t = usb3_item::type_id::create("t");
      t.kind = K_HP; t.hdr = w; t.blk_set = bset; t.blk = b;
      send(t);
    endtask
    // a header needs a device receive buffer: wait for a credit (up to 40 clocks)
    task wait_credit();
      int t = 0;
      while (vif.ltssm == S_U0 && vif.rx_free == 3'd0 && !vif.app_busy && t < 40) begin idle(1); t++; end
    endtask
    task hdr(logic [95:0] h); wait_credit(); hp(seal(h, hseq)); hseq++; endtask
    task lc(logic [15:0] w);
      usb3_item t = usb3_item::type_id::create("t");
      t.kind = K_LC; t.lc = w;
      send(t);
    endtask
    task dw(logic [31:0] w, bit last, bit bset = 0, logic [3:0] b = 0);
      usb3_item t = usb3_item::type_id::create("t");
      t.kind = K_DPP; t.dw = w; t.last = last; t.blk_set = bset; t.blk = b;
      send(t);
    endtask
    task give_credit(); lc(lc_lcrd(hcrd)); hcrd++; endtask
    task ack(); lc(lc_lgood(dseq)); dseq++; endtask
    task train(bit g2);
      one(K_FAR, 0, 1); idle(2);
      repeat (4) begin one(K_LFPS, 0, 0, g2); idle(1); end
      repeat (8) one(K_TS1);
      repeat (8) one(K_TS2);
      hseq = 0; hcrd = 0; dseq = 0;
    endtask
    task recover();
      repeat (8) one(K_TS1);
      repeat (8) one(K_TS2);
      idle(8);
      lc(lc_lgood(dseq + 7));                     // host advertisement
    endtask
    // data packet: DPH + n words + CRC-32 (bad_crc / short spoil it)
    task data(int n, bit bad_crc = 0, bit short_len = 0);
      logic [31:0] c, w;
      hdr(hdr_dph(16'(4 * n + (short_len ? 4 : 0))));
      c = '1;
      for (int i = 0; i < n; i++) begin w = $urandom; dw(w, 0); c = crc32(c, w); end
      dw(bad_crc ? c : ~c, 1);
    endtask
    // a device header arrives after a credit: acknowledge it
    task credit_and_ack();
      int t;
      give_credit();
      t = 0;
      while (vif.tx_hp_valid !== 1'b1 && t < 20) begin idle(1); t++; end
      idle(1);
      if (t < 20) ack();
    endtask
  endclass

  // every link-layer feature in order, then random traffic
  class usb3_regression_seq extends usb3_base_seq;
    `uvm_object_utils(usb3_regression_seq)
    int n_random = 300;
    function new(string name = "usb3_regression_seq"); super.new(name); endfunction
    task body();
      logic [127:0] w;
      // Polling timeout
      one(K_FAR, 0, 1); idle(2);
      repeat (2) begin one(K_LFPS, 0, 0, 1); idle(1); end
      idle(140);
      one(K_FAR, 0, 0); idle(2);
      // Gen1 link, LMP exchange
      note("Gen1 link, LMP exchange");
      train(0);
      idle(8);
      credit_and_ack();                                       // device Port Capability
      hdr(hdr_lmp(4, 8'h01, 32'h0001_0004));
      hdr(hdr_lmp(5, 8'h01));
      credit_and_ack();
      hdr(hdr_lmp(5, 8'h02));                                 // 10G on Gen1: reject
      credit_and_ack();
      // header errors
      note("header errors");
      w = seal(hdr_tp(DEV_ADDR), hseq); w[30] = ~w[30]; hp(w);
      hp(seal(hdr_tp(DEV_ADDR), hseq));
      lc(lc_lrty());
      hdr(hdr_tp(DEV_ADDR));
      w = seal(hdr_tp(DEV_ADDR), hseq); w[126] = ~w[126]; hp(w);
      lc(lc_lrty());
      hdr(hdr_itp(27'h123_4567));
      hdr(hdr_tp(7'd9));
      data(8); data(4, 1); data(4, 0, 1);
      dw(32'h0, 1);                                           // DPP without DPH
      idle(10);
      // overrun with the protocol layer busy, then Recovery
      note("overrun with the protocol layer busy, then Recovery");
      one(K_BUSY, 0, 1);
      repeat (4) hdr(hdr_tp(DEV_ADDR));
      hp(seal(hdr_tp(DEV_ADDR), hseq));                       // no buffer: Recovery
      recover();
      one(K_BUSY, 0, 0);
      idle(20);
      hp(seal(hdr_tp(DEV_ADDR), hseq + 2));                   // out of sequence
      recover();
      // transmit retry and pending timer
      note("transmit retry and pending timer");
      hdr(hdr_lmp(5, 8'h01));
      idle(6);
      give_credit(); idle(2);
      lc(lc_lbad()); idle(4);
      ack();
      hdr(hdr_lmp(5, 8'h01));
      idle(6); give_credit();
      idle(70);                                               // no LGOOD: Recovery
      repeat (8) one(K_TS1); repeat (8) one(K_TS2); idle(8);
      lc(lc_lgood(dseq)); dseq++;                             // it did arrive
      // power management
      note("power management");
      lc(lc_lgo(1)); idle(3);
      hdr(hdr_lmp(1, 8'h00) | 96'h400);
      hdr(hdr_lmp(2, 8'h01));
      idle(8);
      lc(lc_lgo(1)); idle(2); lc(lc_lpma());
      idle(40);                                               // U1 -> U2 after 32 clocks
      one(K_LFPS); recover();
      lc(lc_lgo(3)); idle(2); lc(lc_lpma()); idle(20);
      one(K_LFPS); recover();
      lc(lc_lgo(2)); idle(40);                                // no LPMA
      recover();
      hdr(hdr_lmp(2, 8'h00));
      idle(6);
      lc(lc_lgo(2)); idle(2); lc(lc_lpma()); idle(10);
      one(K_LFPS); recover();
      // Hot Reset
      note("Hot Reset");
      one(K_TS1);
      one(K_TS1, 1); one(K_TS2, 1); one(K_TS2, 0);
      hseq = 0; hcrd = 0; dseq = 0;
      idle(8);
      // Recovery timeout, Gen2 link
      note("Recovery timeout, Gen2 link");
      one(K_TS1); idle(140);
      one(K_FAR, 0, 0); idle(2);
      train(1);
      idle(8);
      credit_and_ack();
      hdr(hdr_lmp(4, 8'h03));
      hdr(hdr_lmp(5, 8'h02));
      credit_and_ack();
      hp(seal(hdr_tp(DEV_ADDR), hseq), 1, 4'b1110); hseq++;   // corrected
      hp(seal(hdr_tp(DEV_ADDR), hseq), 1, 4'b1010);           // dropped
      hdr(hdr_tp(DEV_ADDR));
      idle(8);
      // random traffic
      note("random traffic");
      for (int i = 0; i < n_random; i++) begin
        case ($urandom_range(9))
          0, 1, 2: hdr(hdr_tp($urandom_range(1) ? DEV_ADDR : 7'(1 + $urandom_range(100))));
          3:       hdr(hdr_itp(27'($urandom)));
          4:       data($urandom_range(1, 6), $urandom_range(9) == 0);
          5:       begin hdr(hdr_lmp(5, 8'($urandom_range(1, 2)))); idle(6); credit_and_ack(); end
          6:       begin w = seal(hdr_tp(DEV_ADDR), hseq); w[$urandom_range(111)] ^= 1'b1; hp(w); lc(lc_lrty()); end
          7:       begin wait_credit(); hp(seal(hdr_tp(DEV_ADDR), hseq), 1, 4'b1100 ^ (4'b0001 << $urandom_range(3))); hseq++; end
          default: idle($urandom_range(1, 6));
        endcase
        if (i % 50 == 49) begin one(K_TS1); recover(); note($sformatf("random %0d", i)); end
        else if (vif.ltssm != S_U0) begin recover(); note($sformatf("random %0d: link recovered", i)); end
      end
      idle(40);
    endtask
  endclass

  // ------------------------------------------------------------ env / test
  class usb3_env extends uvm_env;
    `uvm_component_utils(usb3_env)
    usb3_sequencer  sqr;
    usb3_driver     drv;
    usb3_monitor    mon;
    usb3_scoreboard sb;
    usb3_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      sqr = usb3_sequencer::type_id::create("sqr", this);
      drv = usb3_driver::type_id::create("drv", this);
      mon = usb3_monitor::type_id::create("mon", this);
      sb  = usb3_scoreboard::type_id::create("sb", this);
      cov = usb3_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(sb.analysis_export);
      mon.ap.connect(cov.analysis_export);
    endfunction
  endclass

  class usb3_link_test extends uvm_test;
    `uvm_component_utils(usb3_link_test)
    usb3_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      env = usb3_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      usb3_regression_seq s = usb3_regression_seq::type_id::create("s");
      phase.raise_objection(this);
      s.start(env.sqr);
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0 &&
          env.sb.n_lgood > 100 && env.sb.n_dev_hp > 5)
        $display("SB_PASS checks=%0d", env.sb.n_lc_seen + env.sb.n_dev_hp + env.sb.n_lgood);
      else `uvm_error("TEST", "USB3_LINK_TEST FAILED")
    endfunction
  endclass
endpackage

`endif
