// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB 3.x Protocol Checker
// PIPE / LTSSM assertions for SuperSpeed links
//============================================================================
`ifndef USB3_PROTOCOL_CHECKER_SV
`define USB3_PROTOCOL_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb3_protocol_checker extends uvm_component;
  `uvm_component_utils(usb3_protocol_checker)

  // Coverage sample shadow variables (covergroups sample these on the checker clock)
  logic [1:0] cov_pwr_state;
  logic [2:0] cov_tx_deemph;
  logic [1:0] cov_tx_margin;
  bit cov_phy_ready;
  bit cov_rx_status;
  logic [3:0] cov_ltssm;


  covergroup cg_usb3;
    option.per_instance = 1;
    cp_pipe_pwr: coverpoint cov_pwr_state {
      bins p0 = {2'b00};
      bins p1 = {2'b01};
      bins p2 = {2'b10};
      bins p3 = {2'b11};
    }
    cp_tx_deemph: coverpoint cov_tx_deemph {
      bins d0 = {3'b000};
      bins d1 = {3'b001};
      bins d2 = {3'b010};
      bins d3 = {3'b011};
    }
    cp_tx_margin: coverpoint cov_tx_margin {
      bins m0 = {2'b00};
      bins m1 = {2'b01};
      bins m2 = {2'b10};
      bins m3 = {2'b11};
    }
    cp_phy_rdy: coverpoint cov_phy_ready {
      bins rdy_off = {0};
      bins rdy_on  = {1};
    }
    cp_rx_status: coverpoint cov_rx_status {
      bins sts_ok  = {0};
      bins sts_err = {1};
    }
    cp_ltssm: coverpoint cov_ltssm {
      bins u0       = {4'b0000};
      bins rxdet    = {4'b0001};
      bins polling  = {4'b0100};
      bins recovery = {4'b0111};
    }
    cross_pwr_rdy: cross cp_pipe_pwr, cp_phy_rdy;
  endgroup


  virtual usb_vip_if vif;

  int lfps_err_cnt;
  int ts_err_cnt;
  int crc32_err_cnt;
  int link_err_cnt;
  int power_err_cnt;

  function new(string name = "usb3_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
    cg_usb3 = new();
    lfps_err_cnt  = 0;
    ts_err_cnt    = 0;
    crc32_err_cnt = 0;
    link_err_cnt  = 0;
    power_err_cnt = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usb_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "USB3 checker: Virtual interface not found")
  endfunction

  // Procedural PIPE/LTSSM checks sampled on the link clock
  virtual task run_phase(uvm_phase phase);
    bit wait_rdy = 0;
    int rdy_cnt = 0;
    bit wait_ts = 0;
    int ts_cnt = 0;
    bit wait_rec = 0;
    int rec_cnt = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin
        wait_rdy = 0; rdy_cnt = 0; wait_ts = 0; ts_cnt = 0;
        wait_rec = 0; rec_cnt = 0;
        continue;
      end

      // LFPS polling: PHY ready within 1000 cycles after P0 entry
      if (vif.pipe_power_state == 2'b00 && !vif.pipe_phy_ready && !wait_rdy) begin
        wait_rdy = 1; rdy_cnt = 0;
      end
      if (wait_rdy) begin
        if (vif.pipe_phy_ready) wait_rdy = 0;
        else begin
          rdy_cnt++;
          if (rdy_cnt > 1000) begin
            `uvm_error("USB3_CHK", "USB3 LFPS polling timeout")
            lfps_err_cnt++;
            wait_rdy = 0;
          end
        end
      end

      // TS1/TS2 ordered set handshake during training
      if (vif.training && !vif.pipe_tx_elecidle && !wait_ts && !vif.training_done) begin
        wait_ts = 1; ts_cnt = 0;
      end
      if (wait_ts) begin
        if (vif.ts1_valid || vif.ts2_valid || vif.training_done) wait_ts = 0;
        else begin
          ts_cnt++;
          if (ts_cnt > 64) begin
            `uvm_error("USB3_CHK", "USB3 TS1/TS2 handshake failed")
            ts_err_cnt++;
            wait_ts = 0;
          end
        end
      end

      // CRC32 on all data packets
      if (vif.mac_valid && vif.mac_eop && vif.mac_frame_num > 0 && vif.crc32_error) begin
        `uvm_error("USB3_CHK", "USB3 CRC32 error")
        crc32_err_cnt++;
      end

      // Link recovery on training failure
      if (vif.pipe_rx_status && !vif.pipe_phy_ready && !wait_rec) begin
        wait_rec = 1; rec_cnt = 0;
      end
      if (wait_rec) begin
        if (vif.pipe_power_state == 2'b10 || vif.pipe_phy_ready) wait_rec = 0;
        else begin
          rec_cnt++;
          if (rec_cnt > 100) begin
            `uvm_error("USB3_CHK", "USB3 link recovery not triggered")
            link_err_cnt++;
            wait_rec = 0;
          end
        end
      end

      // U0 implies link up
      if (vif.ltssm_state == 4'b0000 && !vif.link_up) begin
        `uvm_error("USB3_CHK", "USB3 U0 without link up")
        link_err_cnt++;
      end
      cov_pwr_state = vif.pipe_power_state;
      cov_tx_deemph = vif.pipe_tx_deemph;
      cov_tx_margin = vif.pipe_tx_margin;
      cov_phy_ready = vif.pipe_phy_ready;
      cov_rx_status = vif.pipe_rx_status;
      cov_ltssm = vif.ltssm_state;
      cg_usb3.sample();
    end
  endtask



  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("USB3_CHK_RPT", $sformatf(
      "USB3 Chk | LFPS:%0d TS:%0d CRC32:%0d Link:%0d Pwr:%0d",
      lfps_err_cnt, ts_err_cnt, crc32_err_cnt, link_err_cnt, power_err_cnt), UVM_LOW)
  endfunction
endclass
`endif
