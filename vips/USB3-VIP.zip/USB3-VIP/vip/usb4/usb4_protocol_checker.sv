// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB4 Protocol Checker
// PIPE4 / router layer assertions for USB4 links
//============================================================================
`ifndef USB4_PROTOCOL_CHECKER_SV
`define USB4_PROTOCOL_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb4_protocol_checker extends uvm_component;
  `uvm_component_utils(usb4_protocol_checker)

  // Coverage sample shadow variables (covergroups sample these on the checker clock)
  logic [3:0] cov_sync_hdr;
  bit cov_link_ready;
  bit cov_rx_valid;
  bit cov_blk_start;
  logic [2:0] cov_cl_state;


  covergroup cg_usb4;
    option.per_instance = 1;
    cp_sync_hdr: coverpoint cov_sync_hdr {
      bins hdr_ctrl = {4'b1010};
      bins hdr_data = {4'b1001};
      bins hdr_tsn  = {4'b0110};
      bins hdr_idle = {4'b0101};
    }
    cp_link_rdy: coverpoint cov_link_ready {
      bins rdy_off = {0};
      bins rdy_on  = {1};
    }
    cp_rx_valid: coverpoint cov_rx_valid {
      bins rxv_off = {0};
      bins rxv_on  = {1};
    }
    cp_blk_start: coverpoint cov_blk_start {
      bins blk_off = {0};
      bins blk_on  = {1};
    }
    cp_cl_state: coverpoint cov_cl_state {
      bins cl0 = {3'b000};
      bins cld = {3'b001};
      bins cls = {3'b101};
    }
    cross_sync_link: cross cp_sync_hdr, cp_link_rdy;
  endgroup


  virtual usb_vip_if vif;

  int sync_err_cnt;
  int lane_err_cnt;
  int crc_err_cnt;
  int tunnel_err_cnt;

  function new(string name = "usb4_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
    cg_usb4 = new();
    sync_err_cnt   = 0;
    lane_err_cnt   = 0;
    crc_err_cnt    = 0;
    tunnel_err_cnt = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usb_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "USB4 checker: Virtual interface not found")
  endfunction

  // Procedural PIPE4/router checks sampled on the link clock
  virtual task run_phase(uvm_phase phase);
    bit wait_rx = 0;
    int rx_cnt = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin
        wait_rx = 0; rx_cnt = 0;
        continue;
      end

      // SB-10B sync header valid at block start
      if (vif.pipe4_tx_blk_start &&
          !(vif.pipe4_tx_sync_hdr inside {4'b1010, 4'b1001, 4'b0110, 4'b0101})) begin
        `uvm_error("USB4_CHK", "USB4 invalid SB-10B sync header")
        sync_err_cnt++;
      end

      // RX data must carry the control sync header
      if (vif.pipe4_link_ready && vif.pipe4_rx_valid &&
          vif.pipe4_rx_sync_hdr != 4'b1010) begin
        `uvm_error("USB4_CHK", "USB4 data before link ready")
        lane_err_cnt++;
      end

      // Lane polarity/lock: RX data must follow MAC traffic within 100 cycles
      if (vif.pipe4_link_ready && vif.mac_valid && vif.mac_sop && !wait_rx) begin
        wait_rx = 1; rx_cnt = 0;
      end
      if (wait_rx) begin
        if (vif.pipe4_rx_valid) wait_rx = 0;
        else begin
          rx_cnt++;
          if (rx_cnt > 100) begin
            `uvm_error("USB4_CHK", "USB4 lane polarity lock failed")
            lane_err_cnt++;
            wait_rx = 0;
          end
        end
      end

      // Tunneled packet CRC
      if (vif.mac_valid && vif.mac_eop && vif.mac_frame_num > 0 && vif.crc32_error) begin
        `uvm_error("USB4_CHK", "USB4 tunneled CRC error")
        crc_err_cnt++;
      end

      // Tunneled traffic only when adapter layer is up (CL0)
      if ((vif.tunnel_usb3 || vif.tunnel_pcie || vif.tunnel_dp) &&
          vif.cl_state != 3'b000) begin
        `uvm_error("USB4_CHK", "USB4 tunneled traffic outside CL0")
        tunnel_err_cnt++;
      end
      cov_sync_hdr = vif.pipe4_tx_sync_hdr;
      cov_link_ready = vif.pipe4_link_ready;
      cov_rx_valid = vif.pipe4_rx_valid;
      cov_blk_start = vif.pipe4_tx_blk_start;
      cov_cl_state = vif.cl_state;
      cg_usb4.sample();
    end
  endtask



  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("USB4_CHK_RPT", $sformatf(
      "USB4 Chk | Sync:%0d Lane:%0d CRC:%0d Tnl:%0d",
      sync_err_cnt, lane_err_cnt, crc_err_cnt, tunnel_err_cnt), UVM_LOW)
  endfunction
endclass
`endif
