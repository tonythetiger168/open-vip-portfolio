// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB 2.0 Protocol Checker
// MAC + PHY layer procedural checks for USB 2.0 HS / FS / LS
// (PID complement, token CRC5, data CRC16, turnaround timeout, bit-stuff,
// handshake legality, UTMI linestate).
//============================================================================
`ifndef USB2_PROTOCOL_CHECKER_SV
`define USB2_PROTOCOL_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb2_protocol_checker extends uvm_component;
  `uvm_component_utils(usb2_protocol_checker)

  // Coverage sample shadow variables (covergroups sample these on the checker clock)
  logic [3:0] cov_pid;
  logic [6:0] cov_addr;
  logic [3:0] cov_ep;
  usb_device_state_e cov_state;
  logic [1:0] cov_linestate;


  covergroup cg_usb2;
    option.per_instance = 1;
    cp_pid: coverpoint cov_pid {
      bins sof   = {4'b0101};
      bins setup = {4'b1101};
      bins tok_in  = {4'b1001};
      bins tok_out = {4'b0001};
      bins ping  = {4'b0100};
      bins data0 = {4'b0011};
      bins data1 = {4'b1011};
      bins data2 = {4'b0111};
      bins mdata = {4'b1111};
      bins ack   = {4'b0010};
      bins nak   = {4'b1010};
      bins stall = {4'b1110};
      bins nyet  = {4'b0110};
      bins split = {4'b1000};
    }
    cp_addr: coverpoint cov_addr {
      bins a0      = {0};
      bins a1_7    = {[1:7]};
      bins a8_63   = {[8:63]};
      bins a64_127 = {[64:127]};
    }
    cp_ep: coverpoint cov_ep {
      bins ep0    = {0};
      bins ep1_7  = {[1:7]};
      bins ep8_15 = {[8:15]};
    }
    cp_state: coverpoint cov_state {
      bins def  = {USB_STATE_DEFAULT};
      bins addr = {USB_STATE_ADDRESS};
      bins cfg  = {USB_STATE_CONFIGURED};
      bins susp = {USB_STATE_SUSPENDED};
    }
    cp_ls: coverpoint cov_linestate {
      bins se0 = {2'b00};
      bins j   = {2'b01};
      bins k   = {2'b10};
    }
    cross_pid_state: cross cp_pid, cp_state;
  endgroup


  virtual usb_vip_if vif;

  int pid_err_cnt;
  int crc5_err_cnt;
  int crc16_err_cnt;
  int timeout_err_cnt;
  int bitstuff_err_cnt;
  int handshake_err_cnt;

  function new(string name = "usb2_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
    cg_usb2 = new();
    pid_err_cnt       = 0;
    crc5_err_cnt      = 0;
    crc16_err_cnt     = 0;
    timeout_err_cnt   = 0;
    bitstuff_err_cnt  = 0;
    handshake_err_cnt = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usb_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "USB2 checker: Virtual interface not found")
  endfunction

  // Procedural protocol checks sampled on the MAC/PHY clock
  virtual task run_phase(uvm_phase phase);
    bit prev_valid = 0;
    bit prev_sop   = 0;
    bit wait_hs    = 0;
    int timeout_cnt = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin
        wait_hs = 0; timeout_cnt = 0;
        prev_valid = 0; prev_sop = 0;
        continue;
      end

      // PID complement: PID[7:4] == ~PID[3:0]
      if (vif.mac_valid && vif.mac_sop && (vif.mac_pid[7:4] != ~vif.mac_pid[3:0])) begin
        `uvm_error("USB2_CHK", "USB2 PID complement mismatch")
        pid_err_cnt++;
      end

      // Token CRC5 (SOF/SETUP/IN/OUT/PING)
      if (vif.mac_valid && vif.mac_sop &&
          vif.mac_pid[3:0] inside {4'b0101,4'b1101,4'b1001,4'b0001,4'b0100} &&
          vif.crc5_error) begin
        `uvm_error("USB2_CHK", "USB2 CRC5 error in token")
        crc5_err_cnt++;
      end

      // Data CRC16 (DATA0/DATA1/DATA2/MDATA)
      if (vif.mac_valid && vif.mac_eop &&
          vif.mac_pid[3:0] inside {4'b0011,4'b1011,4'b0111,4'b1111} &&
          vif.crc16_error) begin
        `uvm_error("USB2_CHK", "USB2 CRC16 error in data")
        crc16_err_cnt++;
      end

      // Response timeout: IN/OUT to the device must get a handshake
      if (vif.mac_valid && vif.mac_sop &&
          vif.mac_pid[3:0] inside {4'b1001,4'b0001} &&
          vif.mac_addr inside {7'h20, 7'h00}) begin
        wait_hs = 1;
        timeout_cnt = 0;
      end
      if (wait_hs) begin
        if (vif.utmi_rxvalid) begin
          wait_hs = 0;
        end else begin
          timeout_cnt++;
          if (timeout_cnt > 24) begin
            `uvm_error("USB2_CHK", "USB2 response timeout")
            timeout_err_cnt++;
            wait_hs = 0;
          end
        end
      end

      // Bit stuff error during RX active
      if (vif.utmi_rxactive && vif.utmi_rxvalid && vif.bit_stuff_error) begin
        `uvm_error("USB2_CHK", "USB2 bit stuff error")
        bitstuff_err_cnt++;
      end

      // Handshake validity: ACK/NAK/STALL/NYET only in response phase
      if (vif.mac_valid &&
          vif.mac_pid[3:0] inside {4'b0010,4'b1010,4'b1110,4'b0110} &&
          !(prev_valid && !prev_sop)) begin
        `uvm_error("USB2_CHK", "USB2 handshake without prior token")
        handshake_err_cnt++;
      end

      // UTMI linestate valid (SE1 is illegal)
      if (vif.utmi_linestate == 2'b11)
        `uvm_error("USB2_CHK", "USB2 UTMI SE1 illegal state");

      prev_valid = vif.mac_valid;
      prev_sop   = vif.mac_sop;
      cov_pid = vif.mac_pid[3:0];
      cov_addr = vif.mac_addr;
      cov_ep = vif.mac_endpoint;
      cov_state = vif.dev_state;
      cov_linestate = vif.utmi_linestate;
      cg_usb2.sample();
    end
  endtask



  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("USB2_CHK_RPT", $sformatf(
      "USB2 Chk | PID:%0d CRC5:%0d CRC16:%0d T/O:%0d BS:%0d HS:%0d",
      pid_err_cnt, crc5_err_cnt, crc16_err_cnt, timeout_err_cnt,
      bitstuff_err_cnt, handshake_err_cnt), UVM_LOW)
  endfunction
endclass
`endif
