// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB-PD Protocol Checker
// BMC / CC-line and contract negotiation assertions
//============================================================================
`ifndef USBPD_PROTOCOL_CHECKER_SV
`define USBPD_PROTOCOL_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usbpd_protocol_checker extends uvm_component;
  `uvm_component_utils(usbpd_protocol_checker)

  // Coverage sample shadow variables (covergroups sample these on the checker clock)
  logic [2:0] cov_pd_role;
  logic [2:0] cov_msg_type;
  logic [10:0] cov_vbus_voltage;
  bit cov_vconn;


  covergroup cg_usbpd;
    option.per_instance = 1;
    cp_role: coverpoint cov_pd_role {
      bins sink   = {3'b000};
      bins source = {3'b001};
      bins drp    = {3'b010};
      bins acc    = {3'b011};
    }
    cp_msg_type: coverpoint cov_msg_type {
      bins mt_ctrl = {3'b001};
      bins mt_data = {3'b011};
      bins mt_ext  = {3'b101};
    }
    cp_contract: coverpoint cov_vbus_voltage {
      bins v5  = {[200:239]};
      bins v9  = {[360:399]};
      bins v15 = {[600:639]};
      bins v20 = {[800:839]};
      bins v28 = {[1120:1439]};
      bins v48 = {[1440:1920]};
    }
    cp_vconn: coverpoint cov_vconn {
      bins vconn_off = {0};
      bins vconn_on  = {1};
    }
    cross_role_contract: cross cp_role, cp_contract;
  endgroup


  virtual usb_vip_if vif;

  int bmc_err_cnt;
  int crc_err_cnt;
  int goodcrc_err_cnt;
  int vbus_err_cnt;
  int contract_err_cnt;

  function new(string name = "usbpd_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
    cg_usbpd = new();
    bmc_err_cnt      = 0;
    crc_err_cnt      = 0;
    goodcrc_err_cnt  = 0;
    vbus_err_cnt     = 0;
    contract_err_cnt = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usb_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "USB-PD checker: Virtual interface not found")
  endfunction

  // Procedural BMC/contract checks sampled on the CC logic clock
  virtual task run_phase(uvm_phase phase);
    bit wait_gcrc = 0;
    int gcrc_cnt = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin
        wait_gcrc = 0; gcrc_cnt = 0;
        continue;
      end

      // BMC encoding: CC1 and CC2 must be differential
      if (vif.pd_msg_valid && (vif.pd_cc1 == vif.pd_cc2)) begin
        `uvm_error("USBPD_CHK", "USB-PD BMC not differential")
        bmc_err_cnt++;
      end

      // GoodCRC response within tReceive (195us modeled as 195 cycles)
      if (vif.pd_msg_valid && vif.pd_msg_type == 3'b001 && !wait_gcrc) begin
        wait_gcrc = 1; gcrc_cnt = 0;
      end
      if (wait_gcrc) begin
        if (!vif.pd_msg_valid) wait_gcrc = 0;
        else begin
          gcrc_cnt++;
          if (gcrc_cnt > 195) begin
            `uvm_error("USBPD_CHK", "USB-PD GoodCRC timeout")
            goodcrc_err_cnt++;
            wait_gcrc = 0;
          end
        end
      end

      // Vbus safe range: 0-48V (1920 * 25mV)
      if (vif.pd_vbus_present && vif.pd_role == 3'b001 &&
          vif.pd_vbus_voltage > 11'd1920) begin
        `uvm_error("USBPD_CHK", "USB-PD Vbus exceeds 48V")
        vbus_err_cnt++;
      end

      // Contract minimum: sink must see >= 5V when connected
      if (vif.pd_vbus_valid && vif.pd_vconn_present &&
          vif.pd_vbus_voltage < 11'd200) begin
        `uvm_error("USBPD_CHK", "USB-PD contract below 5V")
        contract_err_cnt++;
      end

      // CRC-32 on PD data message
      if (vif.pd_msg_valid && vif.pd_msg_type == 3'b011 && !vif.pd_crc_ok) begin
        `uvm_error("USBPD_CHK", "USB-PD CRC-32 error")
        crc_err_cnt++;
      end

      // Sink must have Vbus valid when present
      if (vif.pd_vbus_present && vif.pd_role == 3'b000 && !vif.pd_vbus_valid)
        `uvm_error("USBPD_CHK", "USB-PD Sink without Vbus valid");

      // Explicit contract: power_contract flag implies negotiated Vbus >= 5V
      if (vif.pd_power_contract && vif.pd_vbus_voltage < 11'd200) begin
        `uvm_error("USBPD_CHK", "USB-PD explicit contract below vSafe5V")
        contract_err_cnt++;
      end
      cov_pd_role = vif.pd_role;
      cov_msg_type = vif.pd_msg_type;
      cov_vbus_voltage = vif.pd_vbus_voltage;
      cov_vconn = vif.pd_vconn_present;
      cg_usbpd.sample();
    end
  endtask



  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("USBPD_CHK_RPT", $sformatf(
      "USB-PD Chk | BMC:%0d CRC:%0d GCRC:%0d Vbus:%0d Ctr:%0d",
      bmc_err_cnt, crc_err_cnt, goodcrc_err_cnt, vbus_err_cnt, contract_err_cnt), UVM_LOW)
  endfunction
endclass
`endif
