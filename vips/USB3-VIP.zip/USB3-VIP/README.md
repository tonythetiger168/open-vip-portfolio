# USB 3.x Protocol VIP — Unified Multi-Protocol Verification IP

## 前言概述 (Protocol Overview)

USB 3.x SuperSpeed (5/10/20 Gbps) 驗證重點：
header packet (K-character) + data packet、CRC32 校驗、
PIPE PHY 介面 (tx_data/rx_data/datak/elecidle/power_down)、
LTSSM 狀態機 (Rx.Detect→Polling→U0, U1/U2/U3 電源管理)、
LFPS 信號、TS1/TS2 ordered set 訓練、link-layer loopback。

本 VIP 為 USB 系列統一架構：單一環境涵蓋 7 種協議
(USB 2.0 / 3.0 / 3.1 / 3.2 / USB4 / eUSB2 / USB-PD)，本專案聚焦於 **USB 3.x Protocol VIP**。

## 架構 (Architecture)

```
top_tb.sv
 ├─ usb_vip_if × 7 (MAC + PHY 雙層, clocking blocks, modports, IF assertions)
 └─ usb_dut (functional DUT model)
     ├─ usb2_dev_ep ×2     USB2/eUSB2 device endpoint: chirp response,
     │                      CRC16 檢查, ACK/STALL/timeout, babble detect
     ├─ usb3_phy_model ×3  PIPE PHY: LTSSM walk→U0, CRC32 check, loopback ACK
     ├─ usb4_phy_model     PIPE4 PHY: link ready, router sideband, loopback
     └─ pd_controller_model PD controller: header decode, Vbus transition
usb_env
 ├─ usb_agent × 7 (usb_sequencer / usb_driver / usb_monitor)
 ├─ usb_scoreboard  expected(drv_ap→exp_imp) vs observed(mon→analysis_imp)
 │                   pairwise compare, n_matches/n_mismatches, UVM_ERROR on mismatch
 ├─ usb_coverage_model × 4 (8 covergroups, 見下)
 └─ *_protocol_checker × 5 (procedural protocol checks + covergroups)
```

Closed loop：driver 依 transaction descriptor 送出 token/data packet
（含 CRC16/CRC32 trailer，data packet 以 `mac_frame_num` 作 sideband byte count），
DUT 依位址/endpoint/CRC 決定 ACK/STALL/timeout/babble，monitor 從 MAC/PHY
波形解碼 PID→packet type、重組 payload（剝除 CRC trailer）、觀察 handshake，
scoreboard 端到端比對。

## Sequence 清單

| Sequence | 類型 | 說明 |
|----------|------|------|
| `usb_base_sequence` | base | 共用參數/constraint |
| `usb_random_sequence` | random | protocol-weighted 隨機流量 (90% 打到 DUT 位址) |
| `usb_normal_seq` | directed | 正常 SETUP/IN/OUT/DATA, ACK 路徑 |
| `usb_error_inject_seq` | directed | CRC 腐敗 / timeout(未實作位址) / STALL(EP15) / babble(超長) |
| `usb_reset_seq` | directed | bus reset (SE0) 後重新列舉 |
| `usb_back_to_back_seq` | directed | 最小 inter-packet gap (=2) 背靠背 |
| `usb_stress_seq` | directed | 大 payload (256–512B) 高速率壓力 |
| `usb_corner_seq` | directed | ZLP / 1-byte / max-packet / DATA0-DATA1 toggle / 邊界 EP |
| `usb_sof_seq` | directed | SOF frame stream (11-bit frame number) |
| `usb_regression_sequence` | regression | 加權混合 regression |
| `usb_directed_regression_sequence` | regression | directed library 全掃 |

Tests：`usb_random_regression_test` (預設), `usb_directed_test`,
`usb_hs_test`, `usb_ss_test`, `usb_ssp_test`, `usb_ss20_test`,
`usb4_test`, `usb_eusb2_test`, `usb_pd_test`。

## SVA 清單 (rtl/sva/usb3_compliance_checker.sv, module on usb3_link_if)

每個違規都是 `UVM_ERROR`：
- **L1 signal sanity (4)**：合法 LTSSM 編碼、state / valid 無 X、送出的 link command / header 無 X、buffer / credit ≤ 4
- **L2 link layer (5)**：link command CRC-5、header CRC-16 / CRC-5、header 只在 U0、LCRD_A..D 順序、LGOOD_n 序列與 U0 進入 advertisement
- **L3 LTSSM (6)**：合法轉移、RxDetect 需要 far-end、U0 由 TS2 進入、Ux 由 LFPS 離開、Gen2 只在 Polling.LFPS 決定、Hot Reset 只來自 reset bit 的 TS
- **L4 link power (4)**：Ux 前必有 LAU + LPMA、LAU / LXU 只回應 LGO_Ux、U1 → U2 只在 timeout、buffer 只被 header 佔用
- **L5 counters / Gen2 (5)**：block 修正 / 丟棄、bad header、DPP、ITP 各自對應原因
- 12 個 cover：U0 Gen1 / Gen2、U1 → U2、U3、Hot Reset、LBAD、LRTY、LAU、LXU、device header、block 修正、Recovery timeout

## Functional Coverage 清單

`usb_coverage_model` (8 covergroups，含 cross)：
`cg_txn_type` (protocol×type cross)、`cg_endpoint` (ep×type cross)、
`cg_packet_size` (size×protocol cross)、`cg_device_state` (FSM transition bins,
state×protocol cross)、`cg_phy_layer` (phy_if×term cross)、
`cg_pd_contract` (contract×voltage cross)、`cg_error_injection` (err×recovery cross)、
`cg_data_pattern` (first-byte pattern×length cross)。
Interface covergroup：`cg_usb_interface` (MAC handshake × device state cross)。
各 protocol checker 另有專屬 covergroup + cross。

## 快速上手 (Quick Start)

```sh
cd scripts
make compile           # VCS: pkg → checkers → if → sequences → env → tests → tb
make simulate TEST=usb_random_regression_test
make simulate TEST=usb_directed_test
make coverage          # 見 scripts/coverage.mk
```

環境變數 `TEST` 選擇測試；`UVM_VERBOSITY` 控制訊息等級。
regression 結束時 scoreboard 回報 `n_matches/n_mismatches`，
compliance checker 回報 L1/L2/L3/L4 tiered coverage。

## Deepened Features (v1.8.0)

- **Link-layer model** (`tb/usb3_smoke_model.sv`): USB 3.2 upstream port with RxDetect / Polling (Gen1 or Gen2 by SCD2) / U0 / U1 / U2 / U3 / Recovery / Hot Reset, 4 receive buffers with LCRD_A..D, LGOOD / LBAD / LRTY, retry buffer and resend, LGO_Ux / LAU / LXU / LPMA, U2 inactivity timer, LMPs (Set Link Function, U2 Inactivity Timeout, Port Capability / Configuration), ITP / TP / DPH + DPP, Gen2 block headers with 1-bit correction
- **Functional test** (`tb/smoke_func_tb.sv`): 107 self-checks over every state and link command
- **UVM agent** (`vip/usb3/usb3_link_pkg.sv` on `usb3_link_if`): host-port driver / monitor, a scoreboard that predicts the device link layer, LTSSM / link-command / header covergroups, a 300-item random regression (`usb3_link_test`, runs on Verilator)
- **SVA**: `rtl/sva/usb3_compliance_checker.sv` rewritten on the link interface (24 assertions, 12 covers)

