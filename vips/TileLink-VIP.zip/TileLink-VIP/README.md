# TileLink — TileLink (TL-UL/TL-C) UVM VIP

Open-source UVM verification IP template for **TileLink (TL-UL/TL-C)** (Interconnect).

## Contents

| Path | Description |
|------|-------------|
| `tilelink/tilelink_if.sv` | Protocol interface + FSM state enum |
| `tilelink/tilelink_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `tilelink/sva/tilelink_compliance_checker.sv` | SVA compliance checker (L1=4, L2=4, L3=4, L4=5) |
| `tilelink/vip/tilelink/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/tilelink_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional TL-UL device DUT |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **TileLink host driver**: A-channel valid/ready handshake with payload held stable while stalled, D-channel response collection (`d_ready` always high)
- **Protocol-decoding monitor**: pairs A-channel requests with their D-channel responses from the bus waveforms, flags illegal opcodes
- **End-to-end scoreboard**: matches host vs monitor transactions and checks Get read data against a shadow memory (PutFullData -> Get consistency, Get must return AccessAckData)
- **Functional DUT model**: TL-UL device with registered `a_ready` (~80%, no combinational ready<-valid loop), single outstanding request, associative memory, AccessAck/AccessAckData responses, illegal-opcode acknowledgement
- **Directed sequence library**: put / get / write-read-same-address / size sweep / data corners / address sweep / error-inject (illegal opcode) / reset + regression mix
- **Functional coverage**: opcode x size and opcode x d_opcode crosses, address ranges, FSM state + transition sequences, illegal-opcode error bins
- **SVA L4**: A payload stable while stalled, every A answered by D, Get returns AccessAckData, ready/valid independence (no comb loop)
