# TileLink — TileLink TL-UH UVM VIP

Open-source UVM verification IP for **TileLink Uncached Heavyweight (TL-UH)**
(SiFive TileLink spec 1.8.1, chapters 5-7) on a 32-bit data bus.

## Protocol overview

A host sends requests on the A channel and the device answers on the D
channel; both channels use valid / ready. TL-UH operations:

| A message | param | D message |
|-----------|-------|-----------|
| PutFullData / PutPartialData (`a_mask`) | 0 | AccessAck |
| ArithmeticData | MIN, MAX, MINU, MAXU, ADD | AccessAckData (old value) |
| LogicalData | XOR, OR, AND, SWAP | AccessAckData (old value) |
| Get | 0 | AccessAckData |
| Intent | PrefetchRead, PrefetchWrite | HintAck |

A message of 2^`size` bytes larger than the bus is a burst of one beat per
4 bytes (Put / atomics on A, AccessAckData on D). Every operation has a
`source` ID that stays busy until its D message completes, so several
operations can be in flight and complete in any order. `d_denied` refuses
an operation; denied AccessAckData beats carry `d_corrupt`. `a_corrupt`
marks a bad request data beat.

## Contents

| Path | Description |
|------|-------------|
| `tilelink/tilelink_defs.sv` | Opcode / param encodings, beats, byte lanes, atomic reference function |
| `tilelink/tilelink_if.sv` | A and D channels with `drv_cb` / `mon_cb` clocking blocks |
| `tilelink/tilelink_transaction.svh` | One operation: A message (data / mask / corrupt per beat) and the D message |
| `tilelink/tilelink_driver.svh` | Host: A and D threads, up to 4 operations in flight on free sources, `nb` items, random `a_valid` gaps and `d_ready` |
| `tilelink/tilelink_monitor.svh` | Assembles A and D messages per source, publishes in completion order, reports protocol errors |
| `tilelink/tilelink_coverage.svh` | `cg_protocol` (opcode × size, × denied), `cg_atomic` (every param × size), `cg_flow` (in flight, out of order, stalls, bursts, partial masks, a_corrupt) |
| `tilelink/sva/tilelink_compliance_checker.sv` | SVA: L1 sanity (4), L2 handshake (4), L3 A rules (6), L4 D rules (4), L5 source tracking (4), 10 covers |
| `tilelink/tilelink_sequences.svh` | put/get, partial, atomic, intent, denied, corrupt, outstanding, cov sweep, random, regression |
| `env/` | Environment, end-to-end scoreboard with a byte reference memory, RAL model |
| `tests/tilelink_tests.sv` | random / regression / RAL / coverage tests |
| `tb/top_tb.sv` | Testbench top with the TL-UH device DUT and the SVA checker |
| `tb/smoke_func_tb.sv` | Self-checking functional smoke (about 2000 checks) against the flattened device |
| `scripts/` | Makefile + coverage-driven regression |

## Device model (tb/top_tb.sv)

- 4 KB memory at `addr[11:2]` (aliased above 0x1000); 0x2000-0x2FFF denied
- holds up to 4 operations, collects all A beats of a message, answers the
  complete ones in a random order (out of order across sources)
- carries an operation out when its response starts (Get data is a
  snapshot), so completion order is execution order
- Put writes the `a_mask` bytes of beats without `a_corrupt`; atomics on
  1, 2 or 4 bytes; Intent has no effect
- registered `a_ready` (random, low when no slot is free), random gaps
  before a response, D payload held while `d_ready` is low

## UVM RAL (register model)

- `env/tilelink_reg_model.svh` -- `tilelink_reg_block`: REG0..REG15
  (0x000-0x03C) and `MEM` (1008 x 32-bit, 0x040-0xFFC), all RW with reset 0.
  Map: tl_map (4 bytes).
- `tilelink/tilelink_reg_adapter.svh` -- UVM_WRITE -> PutFullData,
  UVM_READ -> Get, 4 bytes, blocking (`nb = 0`); `UVM_IS_OK` only for the
  matching D opcode without `d_denied`.
- `tilelink_ral_test` -- `uvm_reg_hw_reset_seq`, `uvm_reg_bit_bash_seq`,
  `uvm_mem_walk_seq`, random write + `mirror(UVM_CHECK)` and random `MEM`
  round trips. Runs on Verilator: `python3 tools/run_uvm_tests.py TileLink-VIP`.

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.8.0)

- **TL-UH**: PutPartialData, ArithmeticData, LogicalData, Intent, bursts up to 64 bytes
- **Concurrency**: up to 4 operations in flight on different sources, out-of-order completion, D back-pressure
- **Errors**: `d_denied` region, `d_corrupt` on denied data, `a_corrupt` request beats
- **Checking**: byte-wide reference memory with an independent atomic model; SVA for handshakes, message rules and source tracking

## Deepened Features (v1.6.0, TL-UL, replaced by v1.8.0)

- **TileLink host driver**: A-channel valid/ready handshake with payload held stable while stalled, D-channel response collection (`d_ready` always high)
- **Protocol-decoding monitor**: pairs A-channel requests with their D-channel responses from the bus waveforms, flags illegal opcodes
- **End-to-end scoreboard**: matches host vs monitor transactions and checks Get read data against a shadow memory (PutFullData -> Get consistency, Get must return AccessAckData)
- **Functional DUT model**: TL-UL device with registered `a_ready` (~80%, no combinational ready<-valid loop), single outstanding request, associative memory, AccessAck/AccessAckData responses, illegal-opcode acknowledgement
- **Directed sequence library**: put / get / write-read-same-address / size sweep / data corners / address sweep / error-inject (illegal opcode) / reset + regression mix
- **Functional coverage**: opcode x size and opcode x d_opcode crosses, address ranges, FSM state + transition sequences, illegal-opcode error bins
- **SVA L4**: A payload stable while stalled, every A answered by D, Get returns AccessAckData, ready/valid independence (no comb loop)
