# TileLink (TL-UL/TL-C) Test Plan（TileLink-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | TileLink (TL-UL/TL-C) |
| 家族 | Interconnect |
| 類型 | UVM VIP |
| 交付目錄 | `TileLink-VIP/` |
| 目前 L1b 狀態 | PASS(verilator) |

## 2. DUT / 待測對象

- `tilelink_device_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | in reset: a_ready and d_valid low | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | PutFullData / Get of 1, 2, 4, 8, 16, 32 and 64 bytes at every legal offset, bursts of up to 16 beats, read back | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | words never written read 0 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | PutPartialData with sparse and empty masks on single beats and bursts | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | ArithmeticData MIN / MAX / MINU / MAXU / ADD and LogicalData XOR / OR / AND / SWAP on 1, 2 and 4 bytes return the old value and update memory (signed / unsigned corners) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | Intent PrefetchRead / PrefetchWrite of every size: HintAck, memory unchanged | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | denied region 0x2000-0x2FFF: every opcode answered with d_denied, AccessAckData beats d_corrupt and zero, aliased memory untouched | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | a_corrupt on a Put / PutPartial / atomic beat: that beat is not written | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | every D message: opcode, size, beat count, denied and corrupt as the reference expects | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | 400 random operations with up to 4 in flight on different sources | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | 4 operations in flight; a_ready held low while the device holds 4 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | operations complete out of order | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | D payload held while d_ready is low | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | the whole memory read back against the reference | 檢查成立，`FUNC_PASS` 輸出 |
| FS-15 | reset in the middle: memory cleared, nothing in flight | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | TL-C: Acquire / Probe / Release / Grant on the B, C and E channels |
| PT-02 | Multi-beat atomics (ArithmeticData / LogicalData above the bus width) |
| PT-03 | Wider data buses (64 / 128 bits) and per-beat a_mask on bursts |

## 5. 覆蓋與檢查

- SVA：`tilelink/sva/tilelink_compliance_checker.sv`（L1 signal sanity、L2 valid/ready handshake、L3 A message、L4 D message、L5 source tracking，加上 burst / 亂序 / denied / corrupt / partial / HintAck 的 cover）
- Functional coverage：`tilelink/tilelink_coverage.svh`（cg_protocol / cg_atomic / cg_flow）
- Scoreboard：driver 與 monitor 的 operation 逐一比對，加上 4 KB byte 參考記憶體（denied、mask、a_corrupt、atomics）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/TileLink-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py TileLink-VIP && python3 smoke/smoke_run.py TileLink-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- atomics 限 1、2、4 bytes（單一 beat）；TL-C 未實作。

---
*文件版本：v1.8.0*
