// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_reg_adapter.svh -- UVM RAL adapter for the TileLink (TL-UL) host agent
//   reg2bus: one uvm_reg_bus_op -> one tilelink_transaction
//            (UVM_WRITE -> PutFullData, UVM_READ -> Get, a_size = 2 / 4 bytes)
//   bus2reg: tilelink_transaction (driver-completed or monitor-observed) -> uvm_reg_bus_op
// The driver completes the request item in place (d_opcode and d_data are
// written back) and sends no separate response, so provides_responses = 0.
// Byte enables (a_mask) are not on this interface, so every access is a full
// 32-bit word. The interface has no d_denied / d_corrupt, so the status is
// UVM_IS_OK only when the D opcode matches the request (Get -> AccessAckData,
// PutFullData -> AccessAck) and UVM_NOT_OK otherwise.

`ifndef TILELINK_REG_ADAPTER_SVH
`define TILELINK_REG_ADAPTER_SVH

class tilelink_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(tilelink_reg_adapter)

  function new(string name = "tilelink_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 0;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    tilelink_transaction tr = tilelink_transaction::type_id::create("ral_item");
    tr.opcode       = (rw.kind == UVM_WRITE) ? tilelink_transaction::TL_PUTFULL
                                             : tilelink_transaction::TL_GET;
    tr.addr         = rw.addr[31:0];
    tr.data         = (rw.kind == UVM_WRITE) ? rw.data[31:0] : 32'h0;
    tr.size         = 3'd2;
    tr.error_inject = 1'b0;
    return tr;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    tilelink_transaction tr;
    bit is_put;
    if (!$cast(tr, bus_item)) begin
      `uvm_fatal("TL_RAL", "bus2reg: item is not a tilelink_transaction")
      return;
    end
    is_put     = (tr.opcode == tilelink_transaction::TL_PUTFULL);
    rw.kind    = is_put ? UVM_WRITE : UVM_READ;
    rw.addr    = tr.addr;
    rw.data    = is_put ? tr.data : tr.d_data;
    rw.n_bits  = 32;
    rw.byte_en = '1;
    rw.status  = (!tr.error_inject &&
                  tr.d_opcode == (is_put ? tilelink_transaction::TL_ACCESS_ACK
                                         : tilelink_transaction::TL_ACCESS_ACK_DATA))
                 ? UVM_IS_OK : UVM_NOT_OK;
  endfunction
endclass
`endif
