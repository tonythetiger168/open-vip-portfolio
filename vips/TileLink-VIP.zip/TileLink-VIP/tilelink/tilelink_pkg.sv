// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_pkg.sv -- TileLink (TL-UL/TL-C) UVM VIP package

package tilelink_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import tilelink_defs_pkg::*;
  export tilelink_defs_pkg::*;

  `include "tilelink_transaction.svh"
  `include "tilelink_config.svh"
  `include "tilelink_sequencer.svh"
  `include "tilelink_driver.svh"
  `include "tilelink_monitor.svh"
  `include "tilelink_agent.svh"
  `include "tilelink_sequences.svh"
  `include "tilelink_checker.svh"
  `include "tilelink_coverage.svh"
endpackage
