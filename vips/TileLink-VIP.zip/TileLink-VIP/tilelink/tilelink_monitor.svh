// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_monitor.svh -- TileLink monitor: decodes A-channel requests and
// pairs them with their D-channel responses from the bus waveforms.

`ifndef TILELINK_MONITOR_SVH
`define TILELINK_MONITOR_SVH

class tilelink_monitor extends uvm_monitor;
  `uvm_component_utils(tilelink_monitor)
  virtual tilelink_if vif;
  uvm_analysis_port #(tilelink_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned err_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual tilelink_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tilelink virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    tilelink_transaction tr;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.reset_n !== 1'b1) continue;
      // A-channel handshake: capture the request
      if (vif.mon_cb.a_valid && vif.mon_cb.a_ready) begin
        tr = tilelink_transaction::type_id::create("tr");
        tr.addr = vif.mon_cb.a_address;
        tr.data = vif.mon_cb.a_data;
        tr.size = vif.mon_cb.a_size;
        if (vif.mon_cb.a_opcode == tilelink_transaction::TL_PUTFULL)
          tr.opcode = tilelink_transaction::TL_PUTFULL;
        else if (vif.mon_cb.a_opcode == tilelink_transaction::TL_GET)
          tr.opcode = tilelink_transaction::TL_GET;
        else begin
          tr.opcode = tilelink_transaction::TL_PUTFULL;  // placeholder
          tr.error_inject = 1;
          err_count++;
        end
        // D-channel handshake: pair the response (single outstanding)
        do begin
          @(vif.mon_cb);
        end while (!(vif.mon_cb.d_valid && vif.mon_cb.d_ready));
        tr.d_opcode = vif.mon_cb.d_opcode;
        tr.d_data   = vif.mon_cb.d_data;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("tilelink monitor observed %0d transactions (%0d illegal opcodes)",
              txn_count, err_count), UVM_LOW)
  endfunction
endclass
`endif
