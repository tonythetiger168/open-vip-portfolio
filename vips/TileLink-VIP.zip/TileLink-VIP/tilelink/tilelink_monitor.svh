// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_monitor.svh -- TL-UH monitor: assembles A messages (one beat
// per 4 bytes for messages with data), pairs them with the D message on
// the same source, and publishes the operation when its last D beat is
// seen (completion order). Reports protocol errors: source reused while in
// flight, D on an idle source, wrong D opcode or size, misaligned address,
// mask outside the lanes, illegal opcode / param, A beats of one message
// that disagree.

`ifndef TILELINK_MONITOR_SVH
`define TILELINK_MONITOR_SVH

class tilelink_monitor extends uvm_monitor;
  `uvm_component_utils(tilelink_monitor)
  virtual tilelink_if vif;
  uvm_analysis_port #(tilelink_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned err_count = 0;

  protected tilelink_transaction pend[16];
  protected bit                  busy[16];
  protected int unsigned         issue_no[16], dbeat[16], seq_no;
  protected tilelink_transaction cur_a;      // A message being received
  protected int unsigned         a_got;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual tilelink_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tilelink virtual interface not set")
  endfunction

  function void err(string msg);
    err_count++;
    `uvm_error("MON", msg)
  endfunction

  function int unsigned n_busy();
    n_busy = 0;
    foreach (busy[k]) if (busy[k]) n_busy++;
  endfunction

  function void check_a(tilelink_transaction tr);
    bit [3:0] ln = tilelink_defs_pkg::tl_lanes(tr.addr, tr.size);
    if (tr.opcode > 3'd5) err($sformatf("illegal A opcode %0d", tr.opcode));
    if ((tr.opcode inside {3'd0, 3'd1, 3'd4} && tr.param != 0) ||
        (tr.opcode == 3'd2 && tr.param > 4) || (tr.opcode == 3'd3 && tr.param > 3) ||
        (tr.opcode == 3'd5 && tr.param > 1))
      err($sformatf("illegal param %0d for %s", tr.param, tilelink_defs_pkg::tl_a_name(tr.opcode)));
    if ((tr.addr & ((32'h1 << tr.size) - 1)) != 0)
      err($sformatf("address 0x%08h not aligned to size %0d", tr.addr, tr.size));
    if (tr.size > tilelink_defs_pkg::TL_MAX_SIZE) err($sformatf("size %0d above the device maximum", tr.size));
  endfunction

  task run_phase(uvm_phase phase);
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.reset_n !== 1'b1) begin
        foreach (busy[k]) busy[k] = 0;
        cur_a = null;
        continue;
      end
      if (vif.mon_cb.a_valid && !vif.mon_cb.a_ready && cur_a != null) cur_a.a_stall++;
      // ---------------- A beat ----------------
      if (vif.mon_cb.a_valid && vif.mon_cb.a_ready) begin
        bit [3:0] ln;
        if (cur_a == null) begin
          bit [3:0] s = vif.mon_cb.a_source;
          cur_a = tilelink_transaction::type_id::create("tr");
          cur_a.opcode = vif.mon_cb.a_opcode;
          cur_a.param  = vif.mon_cb.a_param;
          cur_a.size   = vif.mon_cb.a_size;
          cur_a.source = s;
          cur_a.addr   = vif.mon_cb.a_address;
          cur_a.data   = new[0];
          cur_a.mask   = new[0];
          cur_a.corrupt = new[0];
          cur_a.d_data = new[0];
          cur_a.auto_source = 0;
          a_got = 0;
          check_a(cur_a);
          if (busy[s]) err($sformatf("source %0d reused while in flight", s));
          busy[s] = 1;
          pend[s] = cur_a;
          issue_no[s] = seq_no++;
          dbeat[s] = 0;
          cur_a.outst = n_busy();
        end
        else if (vif.mon_cb.a_opcode != cur_a.opcode || vif.mon_cb.a_param != cur_a.param ||
                 vif.mon_cb.a_size != cur_a.size || vif.mon_cb.a_source != cur_a.source ||
                 vif.mon_cb.a_address != cur_a.addr)
          err($sformatf("A beat %0d of a message changes its header", a_got));
        ln = tilelink_defs_pkg::tl_lanes(cur_a.addr, cur_a.size);
        if ((vif.mon_cb.a_mask & ~ln) != 0 ||
            (cur_a.opcode != tilelink_defs_pkg::TL_PUT_PARTIAL && vif.mon_cb.a_mask != ln))
          err($sformatf("a_mask %b for %s of size %0d at 0x%08h", vif.mon_cb.a_mask,
                         tilelink_defs_pkg::tl_a_name(cur_a.opcode), cur_a.size, cur_a.addr));
        cur_a.mask = new[a_got + 1](cur_a.mask);
        cur_a.mask[a_got] = vif.mon_cb.a_mask;
        cur_a.corrupt = new[a_got + 1](cur_a.corrupt);
        cur_a.corrupt[a_got] = vif.mon_cb.a_corrupt;
        if (tilelink_defs_pkg::tl_a_has_data(cur_a.opcode)) begin
          cur_a.data = new[a_got + 1](cur_a.data);
          cur_a.data[a_got] = vif.mon_cb.a_data;
        end
        a_got++;
        if (a_got >= cur_a.a_beats()) cur_a = null;
      end
      // ---------------- D beat ----------------
      if (vif.mon_cb.d_valid && !vif.mon_cb.d_ready && busy[vif.mon_cb.d_source])
        pend[vif.mon_cb.d_source].d_stall++;
      if (vif.mon_cb.d_valid && vif.mon_cb.d_ready) begin
        bit [3:0] s = vif.mon_cb.d_source;
        if (!busy[s]) err($sformatf("D message on source %0d with nothing in flight", s));
        else begin
          tilelink_transaction tr = pend[s];
          int unsigned nb;
          if (dbeat[s] == 0) begin
            bit [2:0] exp_op = (tr.opcode inside {3'd0, 3'd1}) ? tilelink_defs_pkg::TL_ACCESS_ACK :
                               (tr.opcode == 3'd5) ? tilelink_defs_pkg::TL_HINT_ACK :
                                                     tilelink_defs_pkg::TL_ACCESS_ACK_DATA;
            tr.d_opcode = vif.mon_cb.d_opcode;
            tr.d_param  = vif.mon_cb.d_param;
            tr.d_size   = vif.mon_cb.d_size;
            tr.d_denied = vif.mon_cb.d_denied;
            if (tr.d_opcode != exp_op)
              err($sformatf("%s answered with D opcode %0d", tilelink_defs_pkg::tl_a_name(tr.opcode), tr.d_opcode));
            if (tr.d_size != tr.size) err($sformatf("d_size %0d for a request of size %0d", tr.d_size, tr.size));
          end
          if (vif.mon_cb.d_corrupt) tr.d_corrupt = 1;
          if (tr.d_opcode == tilelink_defs_pkg::TL_ACCESS_ACK_DATA) begin
            tr.d_data = new[tr.d_data.size() + 1](tr.d_data);
            tr.d_data[tr.d_data.size() - 1] = vif.mon_cb.d_data;
            if (vif.mon_cb.d_denied && !vif.mon_cb.d_corrupt) err("denied AccessAckData beat without d_corrupt");
            nb = tilelink_defs_pkg::tl_beats(tr.d_size);
          end
          else nb = 1;
          dbeat[s]++;
          if (dbeat[s] >= nb) begin
            tr.ooo = 0;
            foreach (busy[k]) if (busy[k] && k != s && issue_no[k] < issue_no[s]) tr.ooo = 1;
            busy[s] = 0;
            txn_count++;
            `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
            ap.write(tr);
          end
        end
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("tilelink monitor observed %0d operations (%0d protocol errors)",
              txn_count, err_count), UVM_LOW)
  endfunction
endclass
`endif
