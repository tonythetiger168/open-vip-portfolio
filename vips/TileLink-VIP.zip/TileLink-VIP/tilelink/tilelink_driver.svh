// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_driver.svh -- TileLink host driver
// Issues A-channel requests (valid/ready handshake, payload held while
// stalled) and collects the matching D-channel response.

`ifndef TILELINK_DRIVER_SVH
`define TILELINK_DRIVER_SVH

class tilelink_driver extends uvm_driver #(tilelink_transaction);
  `uvm_component_utils(tilelink_driver)
  virtual tilelink_if vif;
  tilelink_config cfg;
  uvm_analysis_port #(tilelink_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual tilelink_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tilelink virtual interface not set")
  endfunction

  task drive_req(tilelink_transaction tr);
    int unsigned tmo = 0;
    `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
    // A channel: assert valid, hold payload stable until accepted (a_ready)
    vif.state = tilelink_defs_pkg::A_CHANNEL;
    vif.drv_cb.a_valid   <= 1'b1;
    vif.drv_cb.a_opcode  <= tr.a_opcode_enc();
    vif.drv_cb.a_address <= tr.addr;
    vif.drv_cb.a_data    <= tr.data;
    vif.drv_cb.a_size    <= tr.size;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "tilelink A-channel stall timeout")
    end while (!vif.drv_cb.a_ready);
    vif.drv_cb.a_valid <= 1'b0;
    // D channel: wait for the device response
    vif.state = tilelink_defs_pkg::D_CHANNEL;
    tmo = 0;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "tilelink D-channel timeout")
    end while (!vif.drv_cb.d_valid);
    tr.d_opcode = vif.drv_cb.d_opcode;
    tr.d_data   = vif.drv_cb.d_data;
    if (tr.error_inject) begin
      vif.state = tilelink_defs_pkg::RETRY;
      `uvm_info("DRV", "illegal opcode injected; device returned AccessAck", UVM_MEDIUM)
      @(vif.drv_cb);
    end
    vif.state = tilelink_defs_pkg::IDLE;
  endtask

  task run_phase(uvm_phase phase);
    tilelink_transaction tr;
    vif.drv_cb.a_valid <= 1'b0;
    vif.drv_cb.d_ready <= 1'b1;   // host always ready for responses
    vif.state = tilelink_defs_pkg::IDLE;
    wait (vif.reset_n === 1'b1);
    repeat (2) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(tr);
      drive_req(tr);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
