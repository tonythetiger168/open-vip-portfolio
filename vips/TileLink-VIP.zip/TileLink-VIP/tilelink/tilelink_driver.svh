// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_driver.svh -- TL-UH host (master) driver
//   * the A and D channels run as separate threads, so up to
//     max_outstanding operations are in flight, each on its own source ID
//     (a source is reused only after its D message completed, TL 5.4)
//   * an item with nb = 0 (the default, e.g. register accesses) completes
//     before item_done; nb = 1 lets the next item start at once
//   * multi-beat A messages (Put / atomics of more than 4 bytes) keep their
//     beats in order; random a_valid gaps between beats (bp_pct)
//   * d_ready is low bp_pct percent of the clocks; D beats are matched to
//     the operation by d_source and the completed item goes to drv_ap in
//     completion order

`ifndef TILELINK_DRIVER_SVH
`define TILELINK_DRIVER_SVH

class tilelink_driver extends uvm_driver #(tilelink_transaction);
  `uvm_component_utils(tilelink_driver)
  virtual tilelink_if vif;
  tilelink_config cfg;
  uvm_analysis_port #(tilelink_transaction) drv_ap;  // expected items for scoreboard

  int unsigned max_outstanding = 4;
  int unsigned bp_pct          = 20;

  protected tilelink_transaction aq[$];        // waiting for the A channel
  protected tilelink_transaction inflight[16];  // by source
  protected bit                  busy[16];
  protected int unsigned         issue_no[16], dbeat[16];
  protected int unsigned         n_inflight, seq_no;
  protected bit [3:0]            next_src;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual tilelink_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tilelink virtual interface not set")
  endfunction

  // next free source, round robin
  function int free_src();
    for (int k = 0; k < 16; k++) begin
      bit [3:0] s = next_src + k;
      if (!busy[s]) return s;
    end
    return -1;
  endfunction

  task run_phase(uvm_phase phase);
    tilelink_transaction tr;
    vif.drv_cb.a_valid   <= 1'b0;
    vif.drv_cb.a_corrupt <= 1'b0;
    vif.drv_cb.d_ready   <= 1'b0;
    wait (vif.reset_n === 1'b1);
    repeat (2) @(vif.drv_cb);
    fork
      a_thread();
      d_thread();
    join_none
    forever begin
      seq_item_port.get_next_item(tr);
      tr.prepare();
      `uvm_info("DRV", {"issue: ", tr.convert2string()}, UVM_HIGH)
      while (n_inflight >= max_outstanding ||
             (tr.auto_source ? free_src() < 0 : busy[tr.source])) @(vif.drv_cb);
      if (tr.auto_source) begin
        tr.source = free_src();
        next_src  = tr.source + 1;
      end
      busy[tr.source]     = 1;
      inflight[tr.source] = tr;
      issue_no[tr.source] = seq_no++;
      dbeat[tr.source]    = 0;
      n_inflight++;
      tr.outst = n_inflight;
      tr.done  = 0;
      tr.d_data = new[0];
      tr.d_corrupt = 0;
      aq.push_back(tr);
      if (!tr.nb) wait (tr.done);
      seq_item_port.item_done();
    end
  endtask

  task a_thread();
    forever begin
      tilelink_transaction tr;
      while (aq.size() == 0) @(vif.drv_cb);
      tr = aq.pop_front();
      repeat (tr.delay) @(vif.drv_cb);
      for (int i = 0; i < tr.a_beats(); i++) begin
        while ($urandom_range(99) < bp_pct) begin vif.drv_cb.a_valid <= 1'b0; @(vif.drv_cb); end
        vif.drv_cb.a_opcode  <= tr.opcode;
        vif.drv_cb.a_param   <= tr.param;
        vif.drv_cb.a_size    <= tr.size;
        vif.drv_cb.a_source  <= tr.source;
        vif.drv_cb.a_address <= tr.addr;
        vif.drv_cb.a_mask    <= tr.mask[i];
        vif.drv_cb.a_data    <= tilelink_defs_pkg::tl_a_has_data(tr.opcode) ? tr.data[i] : 32'h0;
        vif.drv_cb.a_corrupt <= tr.corrupt[i];
        vif.drv_cb.a_valid   <= 1'b1;
        @(vif.drv_cb);
        while (vif.drv_cb.a_ready !== 1'b1) begin tr.a_stall++; @(vif.drv_cb); end
      end
      vif.drv_cb.a_valid   <= 1'b0;
      vif.drv_cb.a_corrupt <= 1'b0;
    end
  endtask

  task d_thread();
    forever begin
      bit rdy = ($urandom_range(99) >= bp_pct);
      vif.drv_cb.d_ready <= rdy;
      @(vif.drv_cb);
      if (vif.drv_cb.d_valid === 1'b1) begin
        bit [3:0] s = vif.drv_cb.d_source;
        tilelink_transaction tr = inflight[s];
        if (!busy[s]) `uvm_error("DRV", $sformatf("D beat on source %0d with nothing in flight", s))
        else if (!rdy) tr.d_stall++;
        else begin
          int unsigned nb;
          if (dbeat[s] == 0) begin
            tr.d_opcode = vif.drv_cb.d_opcode;
            tr.d_param  = vif.drv_cb.d_param;
            tr.d_size   = vif.drv_cb.d_size;
            tr.d_denied = vif.drv_cb.d_denied;
          end
          if (vif.drv_cb.d_corrupt === 1'b1) tr.d_corrupt = 1;
          if (tr.d_opcode == tilelink_defs_pkg::TL_ACCESS_ACK_DATA) begin
            tr.d_data = new[tr.d_data.size() + 1](tr.d_data);
            tr.d_data[tr.d_data.size() - 1] = vif.drv_cb.d_data;
            nb = tilelink_defs_pkg::tl_beats(tr.d_size);
          end
          else nb = 1;
          dbeat[s]++;
          if (dbeat[s] >= nb) complete(s);
        end
      end
    end
  endtask

  function void complete(bit [3:0] s);
    tilelink_transaction tr = inflight[s];
    tr.ooo = 0;
    foreach (busy[k]) if (busy[k] && k != s && issue_no[k] < issue_no[s]) tr.ooo = 1;
    busy[s] = 0;
    n_inflight--;
    tr.done = 1;
    drv_ap.write(tr);
  endfunction
endclass
`endif
