// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_if.sv -- TileLink (TL-UL) interface
// A channel (host -> device): valid/ready/opcode/address/data/size
// D channel (device -> host): valid/ready/opcode/data
// A opcodes: 0=PutFullData 4=Get ; D opcodes: 0=AccessAck 1=AccessAckData

interface tilelink_if (input logic clk);
  import tilelink_defs_pkg::tilelink_state_e;

  logic        reset_n;
  // A channel: request (host drives, device receives)
  logic        a_valid;
  logic        a_ready;
  logic [2:0]  a_opcode;
  logic [31:0] a_address;
  logic [31:0] a_data;
  logic [2:0]  a_size;        // log2(bytes): 0=1B 1=2B 2=4B
  // D channel: response (device drives, host receives)
  logic        d_valid;
  logic        d_ready;
  logic [2:0]  d_opcode;
  logic [31:0] d_data;

  tilelink_state_e state;

  modport HOST   (input  clk, reset_n, a_ready, d_valid, d_opcode, d_data,
                  output a_valid, a_opcode, a_address, a_data, a_size, d_ready, state);
  modport DEVICE (input  clk, reset_n, a_valid, a_opcode, a_address, a_data, a_size,
                        d_ready,
                  output a_ready, d_valid, d_opcode, d_data);
  modport MON    (input  clk, reset_n, a_valid, a_ready, a_opcode, a_address, a_data,
                        a_size, d_valid, d_ready, d_opcode, d_data, state);

  clocking drv_cb @(posedge clk);
    input  reset_n, a_ready, d_valid, d_opcode, d_data;
    output a_valid, a_opcode, a_address, a_data, a_size, d_ready;
  endclocking

  clocking mon_cb @(posedge clk);
    input reset_n, a_valid, a_ready, a_opcode, a_address, a_data, a_size,
          d_valid, d_ready, d_opcode, d_data, state;
  endclocking
endinterface
