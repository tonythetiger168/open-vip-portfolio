// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_if.sv -- TileLink TL-UH interface, 32-bit data bus
// A channel (host -> device): opcode / param / size / source / address /
//   mask / data / corrupt; D channel (device -> host): opcode / param /
//   size / source / sink / denied / data / corrupt. Both channels use a
//   valid / ready handshake; a beat moves on a clock edge with both high.

interface tilelink_if (input logic clk);
  logic        reset_n;
  // A channel
  logic        a_valid;
  logic        a_ready;
  logic [2:0]  a_opcode;
  logic [2:0]  a_param;
  logic [2:0]  a_size;
  logic [3:0]  a_source;
  logic [31:0] a_address;
  logic [3:0]  a_mask;
  logic [31:0] a_data;
  logic        a_corrupt;
  // D channel
  logic        d_valid;
  logic        d_ready;
  logic [2:0]  d_opcode;
  logic [1:0]  d_param;
  logic [2:0]  d_size;
  logic [3:0]  d_source;
  logic        d_sink;
  logic        d_denied;
  logic [31:0] d_data;
  logic        d_corrupt;

  modport HOST   (input  clk, reset_n, a_ready, d_valid, d_opcode, d_param, d_size, d_source,
                         d_sink, d_denied, d_data, d_corrupt,
                  output a_valid, a_opcode, a_param, a_size, a_source, a_address, a_mask,
                         a_data, a_corrupt, d_ready);
  modport DEVICE (input  clk, reset_n, a_valid, a_opcode, a_param, a_size, a_source, a_address,
                         a_mask, a_data, a_corrupt, d_ready,
                  output a_ready, d_valid, d_opcode, d_param, d_size, d_source, d_sink,
                         d_denied, d_data, d_corrupt);
  modport MON    (input  clk, reset_n, a_valid, a_ready, a_opcode, a_param, a_size, a_source,
                         a_address, a_mask, a_data, a_corrupt, d_valid, d_ready, d_opcode,
                         d_param, d_size, d_source, d_sink, d_denied, d_data, d_corrupt);

  clocking drv_cb @(posedge clk);
    input  reset_n, a_ready, d_valid, d_opcode, d_param, d_size, d_source, d_sink, d_denied,
           d_data, d_corrupt;
    output a_valid, a_opcode, a_param, a_size, a_source, a_address, a_mask, a_data, a_corrupt,
           d_ready;
  endclocking

  clocking mon_cb @(posedge clk);
    input reset_n, a_valid, a_ready, a_opcode, a_param, a_size, a_source, a_address, a_mask,
          a_data, a_corrupt, d_valid, d_ready, d_opcode, d_param, d_size, d_source, d_sink,
          d_denied, d_data, d_corrupt;
  endclocking
endinterface
