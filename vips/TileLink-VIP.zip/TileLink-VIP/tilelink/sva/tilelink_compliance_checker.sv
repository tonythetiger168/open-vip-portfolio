// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_compliance_checker.sv -- TileLink TL-UH SVA compliance checker
//   L1 signal sanity (4)        L2 valid / ready handshake (4)
//   L3 A message rules (6)      L4 D message rules (4)
//   L5 source tracking (4)      + cover properties for the flow corners

`ifndef TILELINK_COMPLIANCE_CHECKER_SV
`define TILELINK_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import tilelink_defs_pkg::*;

module tilelink_compliance_checker
(
  input logic        clk,
  input logic        reset_n,
  input logic        a_valid,
  input logic        a_ready,
  input logic [2:0]  a_opcode,
  input logic [2:0]  a_param,
  input logic [2:0]  a_size,
  input logic [3:0]  a_source,
  input logic [31:0] a_address,
  input logic [3:0]  a_mask,
  input logic [31:0] a_data,
  input logic        a_corrupt,
  input logic        d_valid,
  input logic        d_ready,
  input logic [2:0]  d_opcode,
  input logic [1:0]  d_param,
  input logic [2:0]  d_size,
  input logic [3:0]  d_source,
  input logic        d_sink,
  input logic        d_denied,
  input logic [31:0] d_data,
  input logic        d_corrupt
);

  // ---------------- message / source tracking ----------------
  logic        a_mid;                  // inside a multi-beat A message
  logic [4:0]  a_left;                 // beats still to come
  logic [2:0]  a_op_h, a_prm_h, a_sz_h;
  logic [3:0]  a_src_h;
  logic [31:0] a_adr_h;
  logic        busy   [0:15];
  logic [2:0]  s_op   [0:15];
  logic [2:0]  s_size [0:15];
  logic [7:0]  s_age  [0:15];          // issue stamp
  logic [7:0]  stamp;
  logic [4:0]  d_left;                 // D beats still to come of the current message
  logic [2:0]  d_op_h, d_sz_h;
  logic [3:0]  d_src_h;
  logic        d_den_h;
  logic [4:0]  n_busy;

  wire a_fire = a_valid && a_ready;
  wire d_fire = d_valid && d_ready;
  wire a_first = a_fire && !a_mid;
  wire [4:0] a_nbeats = tl_a_has_data(a_opcode) ? 5'(tl_beats(a_size)) : 5'd1;
  wire [2:0] exp_d_op = (s_op[d_source] inside {TL_PUT_FULL, TL_PUT_PARTIAL}) ? TL_ACCESS_ACK :
                        (s_op[d_source] == TL_INTENT) ? TL_HINT_ACK : TL_ACCESS_ACK_DATA;
  wire [4:0] d_nbeats = (d_opcode == TL_ACCESS_ACK_DATA) ? 5'(tl_beats(d_size)) : 5'd1;
  wire       d_first  = d_fire && d_left == 5'd0;
  wire [3:0] lanes    = tl_lanes(a_address, a_size);

  logic older_busy;                    // a source issued before d_source is still in flight
  always_comb begin
    older_busy = 1'b0; n_busy = 5'd0;
    for (int k = 0; k < 16; k++) begin
      if (busy[k]) n_busy = n_busy + 5'd1;
      if (busy[k] && k != d_source && 8'(s_age[k] - s_age[d_source]) > 8'd127) older_busy = 1'b1;
    end
  end

  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
      a_mid <= 1'b0; a_left <= 5'd0; d_left <= 5'd0; stamp <= 8'd0;
      for (int k = 0; k < 16; k++) busy[k] <= 1'b0;
    end
    else begin
      if (a_first) begin
        a_op_h <= a_opcode; a_prm_h <= a_param; a_sz_h <= a_size; a_src_h <= a_source; a_adr_h <= a_address;
        a_mid  <= a_nbeats > 5'd1;
        a_left <= a_nbeats - 5'd1;
        busy[a_source]   <= 1'b1;
        s_op[a_source]   <= a_opcode;
        s_size[a_source] <= a_size;
        s_age[a_source]  <= stamp;
        stamp <= stamp + 8'd1;
      end
      else if (a_fire) begin
        a_left <= a_left - 5'd1;
        if (a_left == 5'd1) a_mid <= 1'b0;
      end
      if (d_fire) begin
        if (d_left == 5'd0) begin
          d_op_h <= d_opcode; d_sz_h <= d_size; d_src_h <= d_source; d_den_h <= d_denied;
          if (d_nbeats == 5'd1) busy[d_source] <= 1'b0;
          else d_left <= d_nbeats - 5'd1;
        end
        else begin
          d_left <= d_left - 5'd1;
          if (d_left == 5'd1) busy[d_source] <= 1'b0;
        end
      end
    end
  end

  // ---------------- L1: signal sanity (4) ----------------
  a_tl_l1_valid_known : assert property (@(posedge clk) disable iff (!reset_n)
    !$isunknown({a_valid, d_valid, a_ready, d_ready}))
    else `uvm_error("SVA_L1", "tilelink: valid / ready unknown")
  a_tl_l1_a_known : assert property (@(posedge clk) disable iff (!reset_n)
    a_valid |-> !$isunknown({a_opcode, a_param, a_size, a_source, a_address, a_mask, a_corrupt}))
    else `uvm_error("SVA_L1", "tilelink: A header unknown while a_valid")
  a_tl_l1_d_known : assert property (@(posedge clk) disable iff (!reset_n)
    d_valid |-> !$isunknown({d_opcode, d_param, d_size, d_source, d_sink, d_denied, d_corrupt}))
    else `uvm_error("SVA_L1", "tilelink: D header unknown while d_valid")
  a_tl_l1_reset : assert property (@(posedge clk) !reset_n |-> !d_valid)
    else `uvm_error("SVA_L1", "tilelink: d_valid during reset")

  // ---------------- L2: valid / ready handshake (4) ----------------
  a_tl_l2_a_hold : assert property (@(posedge clk) disable iff (!reset_n)
    (a_valid && !a_ready) |=> a_valid)
    else `uvm_error("SVA_L2", "tilelink: a_valid dropped before a_ready")
  a_tl_l2_a_stable : assert property (@(posedge clk) disable iff (!reset_n)
    (a_valid && !a_ready) |=> $stable({a_opcode, a_param, a_size, a_source, a_address, a_mask, a_data, a_corrupt}))
    else `uvm_error("SVA_L2", "tilelink: A payload changed while stalled")
  a_tl_l2_d_hold : assert property (@(posedge clk) disable iff (!reset_n)
    (d_valid && !d_ready) |=> d_valid)
    else `uvm_error("SVA_L2", "tilelink: d_valid dropped before d_ready")
  a_tl_l2_d_stable : assert property (@(posedge clk) disable iff (!reset_n)
    (d_valid && !d_ready) |=> $stable({d_opcode, d_param, d_size, d_source, d_sink, d_denied, d_data, d_corrupt}))
    else `uvm_error("SVA_L2", "tilelink: D payload changed while stalled")

  // ---------------- L3: A message rules (6) ----------------
  a_tl_l3_opcode : assert property (@(posedge clk) disable iff (!reset_n)
    a_valid |-> a_opcode <= TL_INTENT)
    else `uvm_error("SVA_L3", "tilelink: illegal A opcode")
  a_tl_l3_param : assert property (@(posedge clk) disable iff (!reset_n)
    a_valid |-> ((a_opcode inside {TL_PUT_FULL, TL_PUT_PARTIAL, TL_GET}) ? a_param == 3'd0 :
                 (a_opcode == TL_ARITHMETIC) ? a_param <= TL_ADD :
                 (a_opcode == TL_LOGICAL) ? a_param <= TL_SWAP : a_param <= TL_PREFETCH_WRITE))
    else `uvm_error("SVA_L3", "tilelink: illegal param for the A opcode")
  a_tl_l3_align : assert property (@(posedge clk) disable iff (!reset_n)
    a_valid |-> (a_address & ((32'h1 << a_size) - 32'h1)) == 32'h0)
    else `uvm_error("SVA_L3", "tilelink: address not aligned to size")
  a_tl_l3_mask : assert property (@(posedge clk) disable iff (!reset_n)
    a_valid |-> ((a_mask & ~lanes) == 4'h0) && (a_opcode == TL_PUT_PARTIAL || a_mask == lanes))
    else `uvm_error("SVA_L3", "tilelink: a_mask outside the lanes, or not full")
  a_tl_l3_size : assert property (@(posedge clk) disable iff (!reset_n)
    a_valid |-> a_size <= 3'(TL_MAX_SIZE) && (!(a_opcode inside {TL_ARITHMETIC, TL_LOGICAL}) || a_size <= 3'd2))
    else `uvm_error("SVA_L3", "tilelink: size above what the device supports")
  a_tl_l3_beats : assert property (@(posedge clk) disable iff (!reset_n)
    (a_valid && a_mid) |-> {a_opcode, a_param, a_size, a_source, a_address} == {a_op_h, a_prm_h, a_sz_h, a_src_h, a_adr_h})
    else `uvm_error("SVA_L3", "tilelink: beats of one A message disagree")

  // ---------------- L4: D message rules (4) ----------------
  a_tl_l4_opcode : assert property (@(posedge clk) disable iff (!reset_n)
    d_valid |-> d_opcode inside {TL_ACCESS_ACK, TL_ACCESS_ACK_DATA, TL_HINT_ACK} && d_param == 2'd0)
    else `uvm_error("SVA_L4", "tilelink: illegal D opcode or param")
  a_tl_l4_denied_corrupt : assert property (@(posedge clk) disable iff (!reset_n)
    (d_valid && d_opcode == TL_ACCESS_ACK_DATA && d_denied) |-> d_corrupt)
    else `uvm_error("SVA_L4", "tilelink: denied AccessAckData without d_corrupt")
  a_tl_l4_no_data_corrupt : assert property (@(posedge clk) disable iff (!reset_n)
    (d_valid && d_opcode != TL_ACCESS_ACK_DATA) |-> !d_corrupt)
    else `uvm_error("SVA_L4", "tilelink: d_corrupt on a message without data")
  a_tl_l4_beats : assert property (@(posedge clk) disable iff (!reset_n)
    (d_valid && d_left != 5'd0) |-> {d_opcode, d_size, d_source, d_denied} == {d_op_h, d_sz_h, d_src_h, d_den_h})
    else `uvm_error("SVA_L4", "tilelink: beats of one D message disagree")

  // ---------------- L5: source tracking (4) ----------------
  a_tl_l5_source_free : assert property (@(posedge clk) disable iff (!reset_n)
    a_first |-> !busy[a_source])
    else `uvm_error("SVA_L5", "tilelink: source reused while in flight")
  a_tl_l5_d_source : assert property (@(posedge clk) disable iff (!reset_n)
    d_valid |-> busy[d_source])
    else `uvm_error("SVA_L5", "tilelink: D message on a source with nothing in flight")
  a_tl_l5_d_opcode : assert property (@(posedge clk) disable iff (!reset_n)
    d_valid |-> d_opcode == exp_d_op)
    else `uvm_error("SVA_L5", "tilelink: D opcode does not answer the A opcode")
  a_tl_l5_d_size : assert property (@(posedge clk) disable iff (!reset_n)
    d_valid |-> d_size == s_size[d_source])
    else `uvm_error("SVA_L5", "tilelink: d_size differs from the request")

  // ---------------- covers ----------------
  c_tl_a_burst     : cover property (@(posedge clk) disable iff (!reset_n) a_first && a_nbeats > 5'd1);
  c_tl_d_burst     : cover property (@(posedge clk) disable iff (!reset_n) d_first && d_nbeats > 5'd1);
  c_tl_a_stall     : cover property (@(posedge clk) disable iff (!reset_n) a_valid && !a_ready);
  c_tl_d_stall     : cover property (@(posedge clk) disable iff (!reset_n) d_valid && !d_ready);
  c_tl_ooo         : cover property (@(posedge clk) disable iff (!reset_n) d_first && older_busy);
  c_tl_four_flight : cover property (@(posedge clk) disable iff (!reset_n) n_busy >= 5'd4);
  c_tl_denied      : cover property (@(posedge clk) disable iff (!reset_n) d_fire && d_denied);
  c_tl_a_corrupt   : cover property (@(posedge clk) disable iff (!reset_n) a_fire && a_corrupt);
  c_tl_partial     : cover property (@(posedge clk) disable iff (!reset_n) a_fire && a_opcode == TL_PUT_PARTIAL && a_mask != lanes);
  c_tl_hint        : cover property (@(posedge clk) disable iff (!reset_n) d_fire && d_opcode == TL_HINT_ACK);
endmodule
`endif
