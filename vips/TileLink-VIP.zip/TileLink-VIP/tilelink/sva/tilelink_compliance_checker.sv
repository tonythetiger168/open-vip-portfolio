// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_compliance_checker.sv -- TileLink (TL-UL) SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules, L4 = TileLink-specific rules

`ifndef TILELINK_COMPLIANCE_CHECKER_SV
`define TILELINK_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import tilelink_defs_pkg::*;

module tilelink_compliance_checker
(
  input logic clk,
  input logic reset_n,
  input tilelink_state_e state,
  input logic a_valid,
  input logic a_ready,
  input logic [2:0] a_opcode,
  input logic [31:0] a_address,
  input logic [31:0] a_data,
  input logic [2:0] a_size,
  input logic d_valid,
  input logic d_ready,
  input logic [2:0] d_opcode,
  input logic [31:0] d_data
);

  localparam bit [2:0] A_GET = 3'd4;
  localparam bit [2:0] D_ACCESS_ACK_DATA = 3'd1;

  // ---------------- L1: signal sanity (4) ----------------
  a_tilelink_l1_clk   : assert property (@(posedge clk) disable iff (!reset_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "tilelink: clock unknown")
  a_tilelink_l1_rst   : assert property (@(posedge clk) !$isunknown(reset_n))
    else `uvm_error("SVA_L1", "tilelink: reset unknown")
  a_tilelink_l1_state : assert property (@(posedge clk) disable iff (!reset_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "tilelink: state unknown")
  a_tilelink_l1_valid : assert property (@(posedge clk) disable iff (!reset_n)
    state inside {IDLE, A_CHANNEL, D_CHANNEL, RETRY})
    else `uvm_error("SVA_L1", "tilelink: state outside legal encoding")

  // ---------------- L2: FSM legality (4) ----------------
  // L2-1: legal FSM transition from IDLE
  a_tilelink_trans_idle : assert property (@(posedge clk) disable iff (!reset_n)
    state == IDLE |=> state inside {IDLE, A_CHANNEL})
    else `uvm_error("SVA_L2", "tilelink: illegal transition from IDLE")

  // L2-2: legal FSM transition from A_CHANNEL
  a_tilelink_trans_a_channel : assert property (@(posedge clk) disable iff (!reset_n)
    state == A_CHANNEL |=> state inside {A_CHANNEL, D_CHANNEL})
    else `uvm_error("SVA_L2", "tilelink: illegal transition from A_CHANNEL")

  // L2-3: legal FSM transition from D_CHANNEL
  a_tilelink_trans_d_channel : assert property (@(posedge clk) disable iff (!reset_n)
    state == D_CHANNEL |=> state inside {D_CHANNEL, RETRY})
    else `uvm_error("SVA_L2", "tilelink: illegal transition from D_CHANNEL")

  // L2-4: legal FSM transition from RETRY
  a_tilelink_trans_retry : assert property (@(posedge clk) disable iff (!reset_n)
    state == RETRY |=> state inside {RETRY, IDLE})
    else `uvm_error("SVA_L2", "tilelink: illegal transition from RETRY")

  // ---------------- L3: protocol rules (4) ----------------
  a_tilelink_l3_reset_idle : assert property (@(posedge clk)
    $fell(reset_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "tilelink: state not IDLE during reset")
  a_tilelink_l3_no_stuck   : assert property (@(posedge clk) disable iff (!reset_n)
    state == RETRY |-> ##[1:8] (state != RETRY))
    else `uvm_error("SVA_L3", "tilelink: stuck in RETRY")
  a_tilelink_l3_full_cycle : cover property (@(posedge clk) disable iff (!reset_n)
    state == IDLE ##1 state == A_CHANNEL);
  a_tilelink_l3_back_idle  : cover property (@(posedge clk) disable iff (!reset_n)
    state == RETRY ##1 state == IDLE);

  // ---------------- L4: TileLink protocol-specific rules (4) ----------------
  // L4-1: while a_valid is high and the transfer is not accepted, the whole
  //       A-channel payload must remain stable
  a_tilelink_l4_payload_stable : assert property (@(posedge clk) disable iff (!reset_n)
    (a_valid && !a_ready) |=>
    $stable({a_opcode, a_address, a_data, a_size}) && a_valid)
    else `uvm_error("SVA_L4", "tilelink: A payload changed while stalled")

  // L4-2: every accepted A-channel request is answered by a D-channel response
  a_tilelink_l4_a_needs_d : assert property (@(posedge clk) disable iff (!reset_n)
    (a_valid && a_ready) |-> ##[1:8] (d_valid && d_ready))
    else `uvm_error("SVA_L4", "tilelink: A request without D response")

  // L4-3: a Get request must be answered with AccessAckData (carries data)
  a_tilelink_l4_get_has_data : assert property (@(posedge clk) disable iff (!reset_n)
    (a_valid && a_ready && a_opcode == A_GET) |->
    ##[1:8] (d_valid && d_opcode == D_ACCESS_ACK_DATA))
    else `uvm_error("SVA_L4", "tilelink: Get without AccessAckData")

  // L4-4: ready/valid independence -- a_ready/d_ready must be registered and
  //       must never combinationally depend on valid (no comb ready<-valid
  //       loop); structurally they may never be unknown while valid toggles.
  a_tilelink_l4_ready_known : assert property (@(posedge clk) disable iff (!reset_n)
    (a_valid || d_valid) |-> !$isunknown({a_ready, d_ready}))
    else `uvm_error("SVA_L4", "tilelink: ready unknown (possible comb loop)")
  a_tilelink_l4_no_comb_loop : cover property (@(posedge clk) disable iff (!reset_n)
    (!a_valid ##1 a_ready) or (!d_valid ##1 d_ready));

endmodule
`endif
