// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_defs.sv -- TileLink TL-UH message encodings (TileLink spec 1.8.1,
// chapters 5-7). 32-bit data bus: one beat carries 4 bytes, a message of
// 2^size bytes larger than that is 2^size / 4 beats.

package tilelink_defs_pkg;
  // A channel opcodes
  localparam bit [2:0] TL_PUT_FULL    = 3'd0;
  localparam bit [2:0] TL_PUT_PARTIAL = 3'd1;
  localparam bit [2:0] TL_ARITHMETIC  = 3'd2;
  localparam bit [2:0] TL_LOGICAL     = 3'd3;
  localparam bit [2:0] TL_GET         = 3'd4;
  localparam bit [2:0] TL_INTENT      = 3'd5;
  // D channel opcodes
  localparam bit [2:0] TL_ACCESS_ACK      = 3'd0;
  localparam bit [2:0] TL_ACCESS_ACK_DATA = 3'd1;
  localparam bit [2:0] TL_HINT_ACK        = 3'd2;
  // ArithmeticData params
  localparam bit [2:0] TL_MIN = 3'd0, TL_MAX = 3'd1, TL_MINU = 3'd2, TL_MAXU = 3'd3, TL_ADD = 3'd4;
  // LogicalData params
  localparam bit [2:0] TL_XOR = 3'd0, TL_OR = 3'd1, TL_AND = 3'd2, TL_SWAP = 3'd3;
  // Intent params
  localparam bit [2:0] TL_PREFETCH_READ = 3'd0, TL_PREFETCH_WRITE = 3'd1;

  localparam int TL_BEAT_BYTES = 4;
  localparam int TL_MAX_SIZE   = 6;     // 64-byte messages, 16 beats

  // beats of a message of 2^size bytes
  function automatic int unsigned tl_beats(input bit [2:0] size);
    return (size <= 2) ? 1 : (1 << (size - 2));
  endfunction

  // A messages that carry data (one beat per 4 bytes)
  function automatic bit tl_a_has_data(input bit [2:0] opcode);
    return opcode inside {TL_PUT_FULL, TL_PUT_PARTIAL, TL_ARITHMETIC, TL_LOGICAL};
  endfunction

  // byte lanes of a beat for an access of 2^size bytes at addr
  function automatic bit [3:0] tl_lanes(input bit [31:0] addr, input bit [2:0] size);
    case (size)
      3'd0:    return 4'b0001 << addr[1:0];
      3'd1:    return addr[1] ? 4'b1100 : 4'b0011;
      default: return 4'b1111;
    endcase
  endfunction

  // atomic operation on the 2^size-byte operand at byte offset off of a
  // word: returns the new word (ArithmeticData when arith, else LogicalData)
  function automatic bit [31:0] tl_amo(input bit [31:0] old, input bit [31:0] wd, input bit arith,
                                       input bit [2:0] prm, input bit [2:0] size, input bit [1:0] off);
    bit [31:0] m, a, b, r;
    int        sh;
    longint    sa, sb;
    m  = (size == 0) ? 32'h0000_00FF : (size == 1) ? 32'h0000_FFFF : 32'hFFFF_FFFF;
    sh = (size == 0) ? off * 8 : (size == 1) ? off[1] * 16 : 0;
    a  = (old >> sh) & m;
    b  = (wd >> sh) & m;
    sa = (size == 0) ? longint'($signed(a[7:0])) : (size == 1) ? longint'($signed(a[15:0])) : longint'($signed(a));
    sb = (size == 0) ? longint'($signed(b[7:0])) : (size == 1) ? longint'($signed(b[15:0])) : longint'($signed(b));
    if (arith)
      case (prm)
        TL_MIN:  r = (sa < sb) ? a : b;
        TL_MAX:  r = (sa > sb) ? a : b;
        TL_MINU: r = (a < b) ? a : b;
        TL_MAXU: r = (a > b) ? a : b;
        default: r = (a + b) & m;
      endcase
    else
      case (prm)
        TL_XOR:  r = a ^ b;
        TL_OR:   r = a | b;
        TL_AND:  r = a & b;
        default: r = b;
      endcase
    return (old & ~(m << sh)) | ((r & m) << sh);
  endfunction

  function automatic string tl_a_name(input bit [2:0] opcode);
    case (opcode)
      TL_PUT_FULL:    return "PutFullData";
      TL_PUT_PARTIAL: return "PutPartialData";
      TL_ARITHMETIC:  return "ArithmeticData";
      TL_LOGICAL:     return "LogicalData";
      TL_GET:         return "Get";
      TL_INTENT:      return "Intent";
      default:        return $sformatf("A?%0d", opcode);
    endcase
  endfunction
endpackage
