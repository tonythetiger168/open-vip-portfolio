// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_transaction.svh -- one TL-UH operation: the A message (request)
// and the D message (response) that answers it.

`ifndef TILELINK_TRANSACTION_SVH
`define TILELINK_TRANSACTION_SVH

class tilelink_transaction extends uvm_sequence_item;

  // ---- A message ----
  rand bit [2:0]  opcode;        // TL_PUT_FULL .. TL_INTENT
  rand bit [2:0]  param;         // atomic / intent sub-operation
  rand bit [2:0]  size;          // 2^size bytes
  rand bit [3:0]  source;        // used when auto_source = 0
  rand bit [31:0] addr;
  bit      [31:0] data[];        // one word per A beat (messages with data; empty otherwise)
  bit      [3:0]  mask[];        // a_mask per beat: Get / Intent one beat
  bit             corrupt[];     // a_corrupt per A beat
  bit             auto_source = 1;  // the driver picks a free source
  bit             nb = 0;        // 1: the next item may start before this one completes
  int unsigned    delay = 0;     // idle clocks before the first A beat

  // ---- D message (filled by the driver / monitor) ----
  bit [2:0]       d_opcode;
  bit [1:0]       d_param;
  bit [2:0]       d_size;
  bit             d_denied;
  bit             d_corrupt;     // any D beat with d_corrupt
  bit [31:0]      d_data[];      // one word per AccessAckData beat

  // ---- annotations ----
  int unsigned    outst;         // operations in flight when this one was issued (incl. itself)
  bit             ooo;           // completed before an older operation
  int unsigned    a_stall, d_stall;  // clocks with valid and no ready
  bit             done;

  constraint c_op    { opcode <= 3'd5; size <= 3'd6;
                       (opcode inside {3'd2, 3'd3}) -> size <= 3'd2; }
  constraint c_param { (opcode inside {3'd0, 3'd1, 3'd4}) -> param == 3'd0;
                       (opcode == 3'd2) -> param <= 3'd4;
                       (opcode == 3'd3) -> param <= 3'd3;
                       (opcode == 3'd5) -> param <= 3'd1; }
  constraint c_align { (addr & ((32'h1 << size) - 32'h1)) == 32'h0;
                       addr[31:16] == 16'h0; }

  `uvm_object_utils(tilelink_transaction)

  function new(string name = "tilelink_transaction");
    super.new(name);
  endfunction

  function int unsigned beats();
    return tilelink_defs_pkg::tl_beats(size);
  endfunction

  function int unsigned a_beats();
    return tilelink_defs_pkg::tl_a_has_data(opcode) ? beats() : 1;
  endfunction

  function bit [31:0] beat_addr(int unsigned i);
    return addr + i * 4;
  endfunction

  // fill data / mask / corrupt for the opcode: full lanes, PutPartialData
  // keeps masks already given (limited to the lanes)
  function void prepare();
    int unsigned n = a_beats();
    bit [3:0] ln = tilelink_defs_pkg::tl_lanes(addr, size);
    int unsigned nd = tilelink_defs_pkg::tl_a_has_data(opcode) ? n : 0;
    if (data.size() != nd) data = new[nd](data);
    if (corrupt.size() != n) corrupt = new[n](corrupt);
    if (mask.size() != n || opcode != tilelink_defs_pkg::TL_PUT_PARTIAL) begin
      bit [3:0] m[] = mask;
      mask = new[n];
      foreach (mask[i])
        mask[i] = (opcode == tilelink_defs_pkg::TL_PUT_PARTIAL && i < m.size()) ? (m[i] & ln) : ln;
    end
    else foreach (mask[i]) mask[i] &= ln;
  endfunction

  // set up an operation without randomize()
  function void set(bit [2:0] op, bit [31:0] a, bit [2:0] sz, bit [2:0] prm = 0);
    opcode = op; addr = a; size = sz; param = prm;
    data = new[0]; mask = new[0]; corrupt = new[0];
    prepare();
  endfunction

  function void post_randomize();
    prepare();
    foreach (data[i]) data[i] = $urandom;
  endfunction

  function string convert2string();
    string s = $sformatf("TL %s param=%0d size=%0d src=%0d addr=0x%08h",
                         tilelink_defs_pkg::tl_a_name(opcode), param, size, source, addr);
    if (data.size()) s = {s, $sformatf(" data[0]=0x%08h mask[0]=%h", data[0], mask[0])};
    s = {s, $sformatf(" -> D op=%0d denied=%0b corrupt=%0b", d_opcode, d_denied, d_corrupt)};
    if (d_data.size()) s = {s, $sformatf(" d_data[0]=0x%08h", d_data[0])};
    return s;
  endfunction

  function void do_copy(uvm_object rhs);
    tilelink_transaction t;
    super.do_copy(rhs);
    if (!$cast(t, rhs)) return;
    opcode = t.opcode; param = t.param; size = t.size; source = t.source; addr = t.addr;
    data = t.data; mask = t.mask; corrupt = t.corrupt;
    auto_source = t.auto_source; nb = t.nb; delay = t.delay;
    d_opcode = t.d_opcode; d_param = t.d_param; d_size = t.d_size; d_denied = t.d_denied;
    d_corrupt = t.d_corrupt; d_data = t.d_data;
  endfunction
endclass
`endif
