// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_transaction.svh -- TileLink TL-UL transaction (A + D channels)

`ifndef TILELINK_TRANSACTION_SVH
`define TILELINK_TRANSACTION_SVH

class tilelink_transaction extends uvm_sequence_item;

  typedef enum bit [2:0] {TL_PUTFULL = 3'd0, TL_GET = 3'd4} tl_a_opcode_e;
  typedef enum bit [2:0] {TL_ACCESS_ACK      = 3'd0,
                          TL_ACCESS_ACK_DATA = 3'd1} tl_d_opcode_e;

  rand tl_a_opcode_e opcode;
  rand bit [31:0]    addr;
  rand bit [31:0]    data;
  rand bit [2:0]     size;          // log2(bytes): 0=1B 1=2B 2=4B
  rand bit           error_inject;  // 1 = drive a reserved/illegal A opcode

  bit [2:0]          d_opcode;      // driver/monitor: observed D response opcode
  bit [31:0]         d_data;        // driver/monitor: observed read data

  constraint c_size  { size inside {0, 1, 2}; }
  constraint c_align { addr[1:0] == 2'b00;         // word aligned
                       addr[31:16] == 16'h0; }     // 64 KB device space
  constraint c_err   { error_inject dist {0 := 7, 1 := 3}; }

  `uvm_object_utils_begin(tilelink_transaction)
    `uvm_field_enum(tl_a_opcode_e, opcode, UVM_ALL_ON)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(size, UVM_ALL_ON)
    `uvm_field_int(error_inject, UVM_ALL_ON)
    `uvm_field_int(d_opcode, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(d_data, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "tilelink_transaction");
    super.new(name);
  endfunction

  // A-channel opcode actually driven on the bus (illegal when injecting)
  function bit [2:0] a_opcode_enc();
    return error_inject ? 3'd7 : opcode;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    tilelink_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    ok &= comparer.compare_field("addr", addr, t.addr, 32);
    ok &= comparer.compare_field("size", size, t.size, 3);
    if (opcode == TL_PUTFULL)
      ok &= comparer.compare_field("data", data, t.data, 32);
    return ok;
  endfunction

  function string convert2string();
    return $sformatf("TL %s addr=0x%08h data=0x%08h size=%0d d_op=%0d d_data=0x%08h err=%0b",
                     opcode == TL_GET ? "Get" : "PutFullData",
                     addr, data, size, d_opcode, d_data, error_inject);
  endfunction
endclass
`endif
