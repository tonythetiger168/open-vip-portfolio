// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_data_integrity_checker.sv -- TileLink (TL-UL/TL-C) data integrity (CRC/E2E) checker

`ifndef TILELINK_DATA_INTEGRITY_CHECKER_SV
`define TILELINK_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import tilelink_defs_pkg::tilelink_state_e;

module tilelink_data_integrity_checker
(
  input logic clk,
  input logic reset_n,
  input tilelink_state_e state
);
  a_tilelink_data_integrity_state_known : assert property (@(posedge clk)
    disable iff (!reset_n) !$isunknown(state))
    else `uvm_error("DATA_INTEGRITY", "tilelink data_integrity: state unknown")
endmodule
`endif
