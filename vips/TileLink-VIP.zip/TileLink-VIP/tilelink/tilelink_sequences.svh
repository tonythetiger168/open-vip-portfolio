// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_sequences.svh -- TileLink TL-UH sequence library. The directed
// sequences set every field with tilelink_transaction::set() (no
// randomize()), so they also run on Verilator.

`ifndef TILELINK_SEQUENCES_SVH
`define TILELINK_SEQUENCES_SVH

class tilelink_base_sequence extends uvm_sequence #(tilelink_transaction);
  `uvm_object_utils(tilelink_base_sequence)
  int num_txns = 20;
  function new(string name = "tilelink_base_sequence"); super.new(name); endfunction

  // one operation; data words given by seed, nb: do not wait for completion
  task op(bit [2:0] opc, bit [31:0] a, bit [2:0] sz, bit [2:0] prm = 0, int seed = 0,
          bit nb = 1, bit [3:0] pmask = 4'hF, int cor_beat = -1, int dly = 0);
    tilelink_transaction tr = tilelink_transaction::type_id::create("tr");
    start_item(tr);
    tr.set(opc, a, sz, prm);
    foreach (tr.data[i]) tr.data[i] = 32'h9E37_79B9 * (seed * 17 + i + 1) ^ (seed << 8);
    if (opc == TL_PUT_PARTIAL) begin
      foreach (tr.mask[i]) tr.mask[i] = (pmask ^ i[3:0]) & tl_lanes(a, sz);
    end
    if (cor_beat >= 0 && cor_beat < tr.corrupt.size()) tr.corrupt[cor_beat] = 1;
    tr.nb    = nb;
    tr.delay = dly;
    finish_item(tr);
  endtask

  task body();
    tilelink_transaction tr;
    repeat (num_txns) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      if (!(tr.randomize())) `uvm_error("RANDFAIL", "randomize() failed");
      tr.nb = 1;
      finish_item(tr);
    end
  endtask
endclass

// PutFullData then Get of every size, read back
class tilelink_put_get_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_put_get_seq)
  function new(string name = "tilelink_put_get_seq"); super.new(name); endfunction
  task body();
    for (int sz = 0; sz <= 6; sz++)
      for (int k = 0; k < 4; k++) begin
        bit [31:0] a = 32'h0000_0400 + sz * 64 + ((sz < 2) ? k << sz : 0) + ((sz >= 2) ? 0 : 0);
        op(TL_PUT_FULL, a, sz, 0, sz * 4 + k, 0);
        op(TL_GET, a, sz, 0, 0, 0);
        if (sz >= 2) break;
      end
  endtask
endclass

// PutPartialData with sparse and empty masks, read back
class tilelink_partial_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_partial_seq)
  function new(string name = "tilelink_partial_seq"); super.new(name); endfunction
  task body();
    for (int k = 0; k < 16; k++) begin
      bit [2:0] sz = (k < 8) ? 3'd2 : 3'd4;
      bit [31:0] a = 32'h0000_0600 + k * 16;
      op(TL_PUT_PARTIAL, a, sz, 0, 100 + k, 0, k[3:0]);
      op(TL_GET, a, sz, 0, 0, 0);
    end
  endtask
endclass

// every ArithmeticData / LogicalData param on 1, 2 and 4 bytes, with
// operands chosen to hit signed / unsigned corners
class tilelink_atomic_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_atomic_seq)
  function new(string name = "tilelink_atomic_seq"); super.new(name); endfunction
  task body();
    int n = 0;
    for (int arith = 1; arith >= 0; arith--)
      for (int prm = 0; prm <= (arith ? 4 : 3); prm++)
        for (int sz = 0; sz <= 2; sz++) begin
          bit [31:0] a = 32'h0000_0800 + n * 4 + ((sz == 0) ? (n % 4) : (sz == 1) ? (n % 2) * 2 : 0);
          op(TL_PUT_FULL, {a[31:2], 2'b00}, 2, 0, 200 + n, 0);          // seed the word
          op(arith ? TL_ARITHMETIC : TL_LOGICAL, a, sz, prm, 300 + n, 0);
          op(arith ? TL_ARITHMETIC : TL_LOGICAL, a, sz, prm, 400 + n, 0);
          op(TL_GET, {a[31:2], 2'b00}, 2, 0, 0, 0);
          n++;
        end
  endtask
endclass

// up to 4 operations in flight on different sources: responses come back
// out of order; bursts mixed with single beats
class tilelink_outstanding_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_outstanding_seq)
  function new(string name = "tilelink_outstanding_seq"); super.new(name); num_txns = 120; endfunction
  task body();
    // disjoint 64-byte windows per slot of a batch, so order between them
    // does not matter to the data
    for (int k = 0; k < num_txns; k++) begin
      bit [2:0]  sz  = $urandom_range(6);
      int        w   = k % 8;
      bit [31:0] a   = 32'h0000_0C00 + w * 64;
      bit [2:0]  opc;
      case ($urandom_range(5))
        0: opc = TL_PUT_FULL;
        1: opc = TL_PUT_PARTIAL;
        2: opc = TL_GET;
        3: opc = TL_INTENT;
        4: begin opc = TL_ARITHMETIC; sz = $urandom_range(2); end
        default: begin opc = TL_LOGICAL; sz = $urandom_range(2); end
      endcase
      a = a + (($urandom_range(63) >> sz) << sz);
      a = a & ~((32'h1 << sz) - 1);
      op(opc, a, sz, (opc == TL_ARITHMETIC) ? $urandom_range(4) : (opc == TL_LOGICAL) ? $urandom_range(3) :
                      (opc == TL_INTENT) ? $urandom_range(1) : 0,
         500 + k, 1, $urandom_range(15), ($urandom_range(9) == 0) ? 0 : -1, $urandom_range(2) == 0 ? 2 : 0);
    end
  endtask
endclass

// denied region 0x2000-0x2FFF: every opcode, single and burst
class tilelink_denied_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_denied_seq)
  function new(string name = "tilelink_denied_seq"); super.new(name); endfunction
  task body();
    for (int opc = 0; opc <= 5; opc++) begin
      bit [2:0] sz = (opc == TL_ARITHMETIC || opc == TL_LOGICAL) ? 3'd2 : 3'd4;
      op(opc, 32'h0000_2040 + opc * 16, sz, 0, 600 + opc, 0, 4'hA);
      op(opc, 32'h0000_2000 + opc * 4, 3'd2, 0, 610 + opc, 1, 4'h5);
    end
    // the aliased word below the denied region is unchanged
    op(TL_GET, 32'h0000_0040, 3'd4, 0, 0, 0);
  endtask
endclass

// Intent (PrefetchRead / PrefetchWrite) of every size: HintAck, no effect
class tilelink_intent_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_intent_seq)
  function new(string name = "tilelink_intent_seq"); super.new(name); endfunction
  task body();
    for (int sz = 0; sz <= 6; sz++) begin
      op(TL_INTENT, 32'h0000_0400 & ~((32'h1 << sz) - 1), sz, sz % 2, 0, 0);
    end
    op(TL_GET, 32'h0000_0400, 3'd6, 0, 0, 0);
  endtask
endclass

// a_corrupt on a beat of a Put / atomic: that beat is not written
class tilelink_corrupt_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_corrupt_seq)
  function new(string name = "tilelink_corrupt_seq"); super.new(name); endfunction
  task body();
    for (int k = 0; k < 4; k++) begin
      op(TL_PUT_FULL, 32'h0000_0E00 + k * 64, 3'd6, 0, 700 + k, 0, 4'hF, k * 5);
      op(TL_PUT_PARTIAL, 32'h0000_0E00 + k * 64 + 32, 3'd3, 0, 710 + k, 0, 4'hC, k % 2);
      op(TL_LOGICAL, 32'h0000_0E00 + k * 64 + 16, 3'd2, TL_XOR, 720 + k, 0, 4'hF, (k % 2) ? 0 : -1);
      op(TL_GET, 32'h0000_0E00 + k * 64, 3'd6, 0, 0, 0);
    end
  endtask
endclass

// Coverage sweep: all of the above
class tilelink_cov_sweep_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_cov_sweep_seq)
  function new(string name = "tilelink_cov_sweep_seq"); super.new(name); endfunction
  task body();
    tilelink_put_get_seq     pg  = tilelink_put_get_seq::type_id::create("pg");
    tilelink_partial_seq     pp  = tilelink_partial_seq::type_id::create("pp");
    tilelink_atomic_seq      at  = tilelink_atomic_seq::type_id::create("at");
    tilelink_intent_seq      in_ = tilelink_intent_seq::type_id::create("in_");
    tilelink_denied_seq      dn  = tilelink_denied_seq::type_id::create("dn");
    tilelink_corrupt_seq     cr  = tilelink_corrupt_seq::type_id::create("cr");
    tilelink_outstanding_seq os  = tilelink_outstanding_seq::type_id::create("os");
    pg.start(m_sequencer); pp.start(m_sequencer); at.start(m_sequencer);
    in_.start(m_sequencer); dn.start(m_sequencer); cr.start(m_sequencer);
    os.start(m_sequencer);
    // drain: a blocking Get waits for everything in flight
    op(TL_GET, 32'h0, 3'd2, 0, 0, 0);
  endtask
endclass

class tilelink_random_sequence extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_random_sequence)
  function new(string name = "tilelink_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: all directed sequences
class tilelink_regression_sequence extends tilelink_cov_sweep_seq;
  `uvm_object_utils(tilelink_regression_sequence)
  function new(string name = "tilelink_regression_sequence"); super.new(name); endfunction
endclass
`endif
