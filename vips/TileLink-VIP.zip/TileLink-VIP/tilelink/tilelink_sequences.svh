// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_sequences.svh -- TileLink sequence library

`ifndef TILELINK_SEQUENCES_SVH
`define TILELINK_SEQUENCES_SVH

class tilelink_base_sequence extends uvm_sequence #(tilelink_transaction);
  `uvm_object_utils(tilelink_base_sequence)
  int num_txns = 20;
  function new(string name = "tilelink_base_sequence"); super.new(name); endfunction
  task body();
    tilelink_transaction tr;
    repeat (num_txns) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: PutFullData writes across the device space
class tilelink_put_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_put_seq)

  function new(string name = "tilelink_put_seq"); super.new(name); endfunction

  task body();
    tilelink_transaction tr;
    repeat (num_txns) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode == TL_PUTFULL; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: Get reads across the device space
class tilelink_get_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_get_seq)

  function new(string name = "tilelink_get_seq"); super.new(name); endfunction

  task body();
    tilelink_transaction tr;
    repeat (num_txns) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode == TL_GET; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: write-then-read the same address (data consistency)
class tilelink_wr_rd_same_addr_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_wr_rd_same_addr_seq)

  function new(string name = "tilelink_wr_rd_same_addr_seq"); super.new(name); endfunction

  rand bit [31:0] target = 32'h0000_0100;
  constraint c_t { target[1:0] == 2'b00; target[31:16] == 16'h0; }
  task body();
    tilelink_transaction tr;
    repeat (num_txns / 2) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode == TL_PUTFULL; addr == target;
                                  error_inject == 0; });
      finish_item(tr);
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode == TL_GET; addr == target;
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: size sweep (1B / 2B / 4B accesses)
class tilelink_size_sweep_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_size_sweep_seq)

  function new(string name = "tilelink_size_sweep_seq"); super.new(name); endfunction

  task body();
    tilelink_transaction tr;
    for (int s = 0; s <= 2; s++) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { size == s; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: data corner values (all-0 / all-1 / alternating)
class tilelink_data_corner_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_data_corner_seq)

  function new(string name = "tilelink_data_corner_seq"); super.new(name); endfunction

  task body();
    tilelink_transaction tr;
    bit [31:0] corners[$] = '{32'h0, 32'hFFFF_FFFF, 32'hAAAA_AAAA, 32'h5555_5555};
    foreach (corners[i]) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { opcode == TL_PUTFULL; data == corners[i];
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: address boundary sweep
class tilelink_addr_sweep_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_addr_sweep_seq)

  function new(string name = "tilelink_addr_sweep_seq"); super.new(name); endfunction

  task body();
    tilelink_transaction tr;
    bit [31:0] addrs[$] = '{32'h0000, 32'h0004, 32'h7FFC, 32'h8000, 32'hFFFC};
    foreach (addrs[i]) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { addr == addrs[i]; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: reserved/illegal A-channel opcodes
class tilelink_error_inject_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_error_inject_seq)

  function new(string name = "tilelink_error_inject_seq"); super.new(name); endfunction

  task body();
    tilelink_transaction tr;
    repeat (6) begin
      tr = tilelink_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single transfer right after reset release
class tilelink_reset_seq extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_reset_seq)

  function new(string name = "tilelink_reset_seq"); super.new(name); endfunction

  task body();
    tilelink_transaction tr = tilelink_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { opcode == TL_PUTFULL; addr == 32'h0;
                                error_inject == 0; });
    finish_item(tr);
  endtask
endclass

class tilelink_random_sequence extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_random_sequence)
  function new(string name = "tilelink_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class tilelink_regression_sequence extends tilelink_base_sequence;
  `uvm_object_utils(tilelink_regression_sequence)
  function new(string name = "tilelink_regression_sequence"); super.new(name); endfunction
  task body();
    tilelink_put_seq            put = tilelink_put_seq::type_id::create("put");
    tilelink_get_seq            get = tilelink_get_seq::type_id::create("get");
    tilelink_wr_rd_same_addr_seq wa = tilelink_wr_rd_same_addr_seq::type_id::create("wa");
    tilelink_size_sweep_seq     sz  = tilelink_size_sweep_seq::type_id::create("sz");
    tilelink_data_corner_seq    dc  = tilelink_data_corner_seq::type_id::create("dc");
    tilelink_addr_sweep_seq     asw = tilelink_addr_sweep_seq::type_id::create("asw");
    tilelink_error_inject_seq   err = tilelink_error_inject_seq::type_id::create("err");
    put.num_txns = 20; get.num_txns = 20; wa.num_txns = 10;
    wa.randomize();
    put.start(m_sequencer); get.start(m_sequencer); wa.start(m_sequencer);
    sz.start(m_sequencer); dc.start(m_sequencer); asw.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
