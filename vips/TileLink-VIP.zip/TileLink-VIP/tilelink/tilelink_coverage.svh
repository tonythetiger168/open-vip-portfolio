// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_coverage.svh -- TileLink functional coverage

`ifndef TILELINK_COVERAGE_SVH
`define TILELINK_COVERAGE_SVH

class tilelink_coverage extends uvm_subscriber #(tilelink_transaction);
  `uvm_component_utils(tilelink_coverage)

  tilelink_transaction tr;
  tilelink_state_e cur_state;
  virtual tilelink_if vif;

  covergroup cg_protocol;
    cp_opcode : coverpoint tr.opcode {
      bins put = {tilelink_transaction::TL_PUTFULL};
      bins get = {tilelink_transaction::TL_GET};
    }
    cp_d_opcode : coverpoint tr.d_opcode {
      bins ack      = {tilelink_transaction::TL_ACCESS_ACK};
      bins ack_data = {tilelink_transaction::TL_ACCESS_ACK_DATA};
    }
    cp_size : coverpoint tr.size {
      bins b1 = {0};
      bins b2 = {1};
      bins b4 = {2};
    }
    cp_addr : coverpoint tr.addr[15:2] {
      bins low  = {[14'h0000 : 14'h1FFF]};
      bins mid  = {[14'h2000 : 14'h2FFF]};
      bins high = {[14'h3000 : 14'h3FFF]};
    }
    cx_op_size : cross cp_opcode, cp_size;
    cx_op_dop  : cross cp_opcode, cp_d_opcode {
      // PutFullData always returns AccessAck; Get always returns AccessAckData
      ignore_bins put_ackdata = binsof(cp_opcode.put) && binsof(cp_d_opcode.ack_data);
      ignore_bins get_ack     = binsof(cp_opcode.get) && binsof(cp_d_opcode.ack);
    }
  endgroup

  covergroup cg_fsm with function sample(tilelink_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, A_CHANNEL, D_CHANNEL, RETRY};
    }
    cp_trans : coverpoint s {
      bins req_seq = (IDLE => A_CHANNEL => D_CHANNEL => IDLE);
      bins err_seq = (D_CHANNEL => RETRY => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.error_inject {
      bins legal = {0};
      bins bad_opcode = {1};
    }
    cp_data_corner : coverpoint tr.data {
      bins zero = {32'h0};
      bins ones = {32'hFFFF_FFFF};
      bins alt  = {32'hAAAA_AAAA, 32'h5555_5555};
      bins misc = default;
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual tilelink_if)::get(this, "", "vif", vif));
  endfunction

  function void write(tilelink_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction

  // Sample the link FSM every cycle so all states/transitions are observable
  task run_phase(uvm_phase phase);
    if (vif == null) begin
      `uvm_warning("COV", "tilelink coverage: no vif, FSM coverage disabled")
      return;
    end
    forever begin
      @(posedge vif.clk);
      cur_state = vif.state;
      cg_fsm.sample(cur_state);
    end
  endtask
endclass
`endif
