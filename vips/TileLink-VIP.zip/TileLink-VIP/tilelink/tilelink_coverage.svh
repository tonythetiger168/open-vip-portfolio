// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_coverage.svh -- TL-UH functional coverage, sampled on every
// operation the monitor completes.

`ifndef TILELINK_COVERAGE_SVH
`define TILELINK_COVERAGE_SVH

class tilelink_coverage extends uvm_subscriber #(tilelink_transaction);
  `uvm_component_utils(tilelink_coverage)

  tilelink_transaction tr;
  virtual tilelink_if vif;
  bit partial, corrupt, zero_mask;

  covergroup cg_protocol;
    option.per_instance = 1;
    cp_opcode : coverpoint tr.opcode {
      bins put_full = {TL_PUT_FULL};  bins put_partial = {TL_PUT_PARTIAL};
      bins arith    = {TL_ARITHMETIC}; bins logical    = {TL_LOGICAL};
      bins get      = {TL_GET};       bins intent      = {TL_INTENT};
    }
    cp_size : coverpoint tr.size {
      bins b1 = {0}; bins b2 = {1}; bins b4 = {2}; bins b8 = {3}; bins b16 = {4}; bins b32 = {5}; bins b64 = {6};
    }
    cp_d_opcode : coverpoint tr.d_opcode {
      bins ack = {TL_ACCESS_ACK}; bins ack_data = {TL_ACCESS_ACK_DATA}; bins hint_ack = {TL_HINT_ACK};
    }
    cp_denied : coverpoint tr.d_denied { bins ok = {0}; bins denied = {1}; }
    cx_op_size : cross cp_opcode, cp_size {
      // atomics on this 32-bit device are 1, 2 or 4 bytes
      ignore_bins atomic_burst = binsof(cp_opcode) intersect {TL_ARITHMETIC, TL_LOGICAL} &&
                                 binsof(cp_size) intersect {[3:6]};
    }
    cx_op_denied : cross cp_opcode, cp_denied;
  endgroup

  covergroup cg_atomic;
    option.per_instance = 1;
    cp_arith : coverpoint tr.param iff (tr.opcode == TL_ARITHMETIC) {
      bins min = {TL_MIN}; bins max = {TL_MAX}; bins minu = {TL_MINU}; bins maxu = {TL_MAXU}; bins add = {TL_ADD};
    }
    cp_logic : coverpoint tr.param iff (tr.opcode == TL_LOGICAL) {
      bins xor_ = {TL_XOR}; bins or_ = {TL_OR}; bins and_ = {TL_AND}; bins swap = {TL_SWAP};
    }
    cp_intent : coverpoint tr.param iff (tr.opcode == TL_INTENT) {
      bins prefetch_read = {TL_PREFETCH_READ}; bins prefetch_write = {TL_PREFETCH_WRITE};
    }
    cp_size : coverpoint tr.size iff (tr.opcode inside {TL_ARITHMETIC, TL_LOGICAL}) {
      bins b1 = {0}; bins b2 = {1}; bins b4 = {2};
    }
    cx_arith_size : cross cp_arith, cp_size;
    cx_logic_size : cross cp_logic, cp_size;
  endgroup

  covergroup cg_flow;
    option.per_instance = 1;
    cp_outst : coverpoint tr.outst { bins one = {1}; bins two = {2}; bins three = {3}; bins four_plus = {[4:$]}; }
    cp_ooo : coverpoint tr.ooo { bins in_order = {0}; bins out_of_order = {1}; }
    cp_source : coverpoint tr.source { bins src[4] = {[0:15]}; }
    cp_a_stall : coverpoint tr.a_stall { bins none = {0}; bins some = {[1:3]}; bins many = {[4:$]}; }
    cp_d_stall : coverpoint tr.d_stall { bins none = {0}; bins some = {[1:$]}; }
    cp_burst : coverpoint (tr.size > 2) { bins single = {0}; bins burst = {1}; }
    cp_partial : coverpoint partial iff (tr.opcode == TL_PUT_PARTIAL) { bins full_lanes = {0}; bins sparse = {1}; }
    cp_zero_mask : coverpoint zero_mask iff (tr.opcode == TL_PUT_PARTIAL) { bins some = {0}; bins none = {1}; }
    cp_corrupt : coverpoint corrupt iff (tl_a_has_data(tr.opcode)) { bins clean = {0}; bins corrupt = {1}; }
    cx_ooo_burst : cross cp_ooo, cp_burst;
    cx_outst_ooo : cross cp_outst, cp_ooo {
      ignore_bins one_ooo = binsof(cp_outst.one) && binsof(cp_ooo.out_of_order);   // alone in flight
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_atomic   = new();
    cg_flow     = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual tilelink_if)::get(this, "", "vif", vif));
  endfunction

  function void write(tilelink_transaction t);
    bit [3:0] ln = tl_lanes(t.addr, t.size);
    tr = t;
    partial = 0; corrupt = 0; zero_mask = 0;
    foreach (t.mask[i]) begin
      if (t.mask[i] != ln) partial = 1;
      if (t.mask[i] == 4'h0) zero_mask = 1;
    end
    foreach (t.corrupt[i]) if (t.corrupt[i]) corrupt = 1;
    cg_protocol.sample();
    cg_atomic.sample();
    cg_flow.sample();
  endfunction
endclass
`endif
