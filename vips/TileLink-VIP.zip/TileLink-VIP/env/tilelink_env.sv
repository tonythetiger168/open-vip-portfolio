// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_env.sv -- TileLink verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import tilelink_defs_pkg::*;
  import tilelink_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: match_cnt host-issued A-channel requests against
  // monitor-decoded A/D pairs and checks Get read data against a shadow
  // memory updated by every PutFullData (A -> D data consistency).
  class tilelink_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(tilelink_scoreboard)
    uvm_analysis_imp_exp #(tilelink_transaction, tilelink_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(tilelink_transaction, tilelink_scoreboard) obs_ap;

    tilelink_transaction exp_q[$], obs_q[$];
    bit [31:0] shadow_mem [bit [31:0]];
    int unsigned match_cnt = 0, mismatches = 0, get_checks = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(tilelink_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(tilelink_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        tilelink_transaction e = exp_q.pop_front();
        tilelink_transaction o = obs_q.pop_front();
        if (e.error_inject != o.error_inject || e.addr != o.addr || e.size != o.size ||
            (!e.error_inject && e.opcode != o.opcode) ||
            (!e.error_inject && e.opcode == tilelink_transaction::TL_PUTFULL &&
             e.data != o.data)) begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
          continue;
        end
        if (!o.error_inject) begin
          if (o.opcode == tilelink_transaction::TL_PUTFULL)
            shadow_mem[o.addr] = o.data;
          if (o.opcode == tilelink_transaction::TL_GET) begin
            if (o.d_opcode != tilelink_transaction::TL_ACCESS_ACK_DATA) begin
              mismatches++;
              `uvm_error("SB", $sformatf("Get without AccessAckData: %s",
                         o.convert2string()))
              continue;
            end
            if (shadow_mem.exists(o.addr)) begin
              get_checks++;
              if (o.d_data !== shadow_mem[o.addr]) begin
                mismatches++;
                `uvm_error("SB", $sformatf(
                           "Get data mismatch addr=0x%08h exp=0x%08h obs=0x%08h",
                           o.addr, shadow_mem[o.addr], o.d_data))
                continue;
              end
            end
          end
        end
        match_cnt++;
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("tilelink scoreboard: matches=%0d mismatches=%0d get_data_checks=%0d",
                match_cnt, mismatches, get_checks), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class tilelink_env extends uvm_env;
    `uvm_component_utils(tilelink_env)
    tilelink_agent      agt;
    tilelink_scoreboard sb;
    tilelink_checker    chk;
    tilelink_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = tilelink_agent::type_id::create("agt", this);
      sb  = tilelink_scoreboard::type_id::create("sb", this);
      chk = tilelink_checker::type_id::create("chk", this);
      cov = tilelink_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
