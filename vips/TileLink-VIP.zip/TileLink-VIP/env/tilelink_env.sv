// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tilelink_env.sv -- TileLink verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import tilelink_defs_pkg::*;
  import tilelink_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  `include "tilelink_reg_model.svh"

  // End-to-end scoreboard: every operation the host completed (driver,
  // completion order) against the one the monitor decoded from the bus, and
  // the monitor's operations against a reference model of the device in
  // tb/top_tb.sv: 4 KB of bytes (aliased), 0x2000-0x2FFF denied, Put writes
  // the masked bytes of beats without a_corrupt, atomics return the old
  // value, Get returns memory, Intent gets HintAck. The device carries out
  // an operation when its response starts and answers one at a time, so
  // completion order is execution order.
  class tilelink_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(tilelink_scoreboard)
    uvm_analysis_imp_exp #(tilelink_transaction, tilelink_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(tilelink_transaction, tilelink_scoreboard) obs_ap;

    tilelink_transaction exp_q[$], obs_q[$];
    bit [7:0]    ref_mem [4096];
    int unsigned match_cnt = 0, mismatches = 0, get_checks = 0;
    int unsigned n_ooo = 0, n_denied = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(tilelink_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(tilelink_transaction t); obs_q.push_back(t); check(); endfunction

    function void bad(string what, tilelink_transaction t);
      mismatches++;
      `uvm_error("SB", $sformatf("%s: %s", what, t.convert2string()))
    endfunction

    function bit [31:0] word(bit [31:0] a);
      bit [11:0] base = {a[11:2], 2'b00};
      return {ref_mem[base + 3], ref_mem[base + 2], ref_mem[base + 1], ref_mem[base]};
    endfunction

    function void set_word(bit [31:0] a, bit [31:0] w, bit [3:0] m);
      bit [11:0] base = {a[11:2], 2'b00};
      for (int l = 0; l < 4; l++) if (m[l]) ref_mem[base + l] = w[l*8 +: 8];
    endfunction

    // replay one operation on the reference model
    function void model(tilelink_transaction t);
      bit       den = (t.addr[15:12] == 4'h2);
      bit [2:0] eop = (t.opcode inside {TL_PUT_FULL, TL_PUT_PARTIAL}) ? TL_ACCESS_ACK :
                      (t.opcode == TL_INTENT) ? TL_HINT_ACK : TL_ACCESS_ACK_DATA;
      bit       ecor = den && eop == TL_ACCESS_ACK_DATA;
      if (den) n_denied++;
      if (t.d_opcode != eop || t.d_denied != den || t.d_corrupt != ecor || t.d_size != t.size || t.d_param != 0)
        bad($sformatf("response: expected D opcode %0d denied %0b corrupt %0b", eop, den, ecor), t);
      case (t.opcode)
        TL_GET: begin
          if (t.d_data.size() != t.beats()) bad("AccessAckData beat count", t);
          else foreach (t.d_data[b]) begin
            bit [31:0] e = den ? 32'h0 : word(t.beat_addr(b));
            get_checks++;
            if (t.d_data[b] !== e) bad($sformatf("Get beat %0d data 0x%08h, reference 0x%08h", b, t.d_data[b], e), t);
          end
        end
        TL_PUT_FULL, TL_PUT_PARTIAL:
          if (!den) foreach (t.data[b]) if (!t.corrupt[b]) set_word(t.beat_addr(b), t.data[b], t.mask[b]);
        TL_ARITHMETIC, TL_LOGICAL: begin
          bit [31:0] old = word(t.addr);
          get_checks++;
          if (t.d_data.size() != 1 || t.d_data[0] !== (den ? 32'h0 : old))
            bad($sformatf("atomic returned 0x%08h, reference old value 0x%08h",
                          t.d_data.size() ? t.d_data[0] : 32'hX, den ? 32'h0 : old), t);
          if (!den && !t.corrupt[0])
            set_word(t.addr, tl_amo(old, t.data[0], t.opcode == TL_ARITHMETIC, t.param, t.size, t.addr[1:0]), 4'hF);
        end
        default: ;
      endcase
    endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        tilelink_transaction e = exp_q.pop_front();
        tilelink_transaction o = obs_q.pop_front();
        bit ok = e.opcode == o.opcode && e.param == o.param && e.size == o.size &&
                 e.source == o.source && e.addr == o.addr && e.data.size() == o.data.size() &&
                 e.mask.size() == o.mask.size() && e.d_opcode == o.d_opcode &&
                 e.d_denied == o.d_denied && e.d_corrupt == o.d_corrupt &&
                 e.d_data.size() == o.d_data.size() && e.ooo == o.ooo;
        if (ok) foreach (e.data[i]) if (e.data[i] !== o.data[i] || e.corrupt[i] != o.corrupt[i]) ok = 0;
        if (ok) foreach (e.mask[i]) if (e.mask[i] !== o.mask[i]) ok = 0;
        if (ok) foreach (e.d_data[i]) if (e.d_data[i] !== o.d_data[i]) ok = 0;
        if (!ok) begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}", e.convert2string(), o.convert2string()))
          continue;
        end
        if (o.ooo) n_ooo++;
        model(o);
        match_cnt++;
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d completed / %0d observed operations left unmatched", exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("tilelink scoreboard: matches=%0d mismatches=%0d data_checks=%0d out_of_order=%0d denied=%0d",
                match_cnt, mismatches, get_checks, n_ooo, n_denied), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class tilelink_env extends uvm_env;
    `uvm_component_utils(tilelink_env)
    tilelink_agent      agt;
    tilelink_scoreboard sb;
    tilelink_checker    chk;
    tilelink_coverage   cov;
    // UVM RAL: register model of the TL-UL device, frontdoor through the
    // agent, mirror kept by an explicit predictor fed by the monitor
    tilelink_reg_block                             regmodel;
    tilelink_reg_adapter                           reg_adapter;
    uvm_reg_predictor #(tilelink_transaction)      reg_predictor;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = tilelink_agent::type_id::create("agt", this);
      sb  = tilelink_scoreboard::type_id::create("sb", this);
      chk = tilelink_checker::type_id::create("chk", this);
      cov = tilelink_coverage::type_id::create("cov", this);
      if (!uvm_config_db#(tilelink_reg_block)::get(this, "", "regmodel", regmodel)) begin
        regmodel = tilelink_reg_block::type_id::create("regmodel");
        regmodel.configure(null, "");
        regmodel.build();
        regmodel.lock_model();
      end
      reg_adapter   = tilelink_reg_adapter::type_id::create("reg_adapter");
      reg_predictor = uvm_reg_predictor#(tilelink_transaction)::type_id::create("reg_predictor", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
      regmodel.default_map.set_sequencer(agt.sqr, reg_adapter);
      regmodel.default_map.set_auto_predict(0);
      reg_predictor.map     = regmodel.default_map;
      reg_predictor.adapter = reg_adapter;
      agt.mon.ap.connect(reg_predictor.bus_in);
    endfunction
  endclass
endpackage
