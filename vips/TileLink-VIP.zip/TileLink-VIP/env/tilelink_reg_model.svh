// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//============================================================================
// UVM RAL model of the top_tb TL-UL device (tilelink_device_model,
// tb/top_tb.sv), 32-bit data, word addressed:
//   0x000..0x03C  REG[0..15]  32-bit RW, reset 0
//   0x040..0xFFC  MEM         1008 x 32-bit RW memory (uvm_mem_walk_seq)
// The device stores every address in an associative memory that reads 0
// until written, so all registers and MEM words reset to 0. The 64 KB
// device space is not decoded further; the model maps the first 4 KB.
// The interface has no d_denied, so the device cannot return an error and
// there is no error-region register.
// Included inside env_pkg (env/tilelink_env.sv).
//============================================================================
`ifndef TILELINK_REG_MODEL_SVH
`define TILELINK_REG_MODEL_SVH

class tilelink_data_reg extends uvm_reg;
  `uvm_object_utils(tilelink_data_reg)
  rand uvm_reg_field DATA;

  function new(string name = "tilelink_data_reg");
    super.new(name, 32, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    DATA = uvm_reg_field::type_id::create("DATA");
    //            parent size lsb access volatile reset has_reset rand individually_accessible
    DATA.configure(this, 32,  0,  "RW",  0,       32'h0, 1,        1,   1);
  endfunction
endclass

class tilelink_reg_block extends uvm_reg_block;
  `uvm_object_utils(tilelink_reg_block)
  localparam int N_REGS  = 16;
  localparam int N_WORDS = 1024;
  rand tilelink_data_reg REG[N_REGS];
  uvm_mem                MEM;
  uvm_reg_map            tl_map;

  function new(string name = "tilelink_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    tl_map = create_map("tl_map", 'h0, 4, UVM_LITTLE_ENDIAN, 1);
    default_map = tl_map;
    foreach (REG[i]) begin
      REG[i] = tilelink_data_reg::type_id::create($sformatf("REG%0d", i));
      REG[i].configure(this, null, "");
      REG[i].build();
      tl_map.add_reg(REG[i], i * 4, "RW");
    end
    MEM = new("MEM", N_WORDS - N_REGS, 32, "RW", UVM_NO_COVERAGE);
    MEM.configure(this, "");
    tl_map.add_mem(MEM, N_REGS * 4, "RW");
  endfunction
endclass
`endif
