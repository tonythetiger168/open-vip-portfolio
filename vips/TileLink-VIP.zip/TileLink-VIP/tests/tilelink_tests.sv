// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tilelink_tests.sv -- TileLink (TL-UL/TL-C) UVM tests

package tilelink_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import tilelink_pkg::*;
  import env_pkg::*;

  class tilelink_base_test extends uvm_test;
    `uvm_component_utils(tilelink_base_test)
    tilelink_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = tilelink_env::type_id::create("env", this);
    endfunction
  endclass

  class tilelink_random_test extends tilelink_base_test;
    `uvm_component_utils(tilelink_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      tilelink_random_sequence seq = tilelink_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class tilelink_regression_test extends tilelink_base_test;
    `uvm_component_utils(tilelink_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      tilelink_regression_sequence seq = tilelink_regression_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  // UVM RAL: built-in register/memory sequences plus directed frontdoor checks
  // against the model in env/tilelink_reg_model.svh.
  //   1. uvm_reg_hw_reset_seq  -- every register reads its reset value
  //   2. uvm_reg_bit_bash_seq  -- every bit of every RW register writes 0/1 and reads back
  //   3. uvm_mem_walk_seq      -- walking write/read over every MEM word
  //   4. random write + mirror(UVM_CHECK) on every register, random MEM
  //      write/read round trips
  // Uses no randomize(), so it runs on Verilator (tools/run_uvm_tests.py).
  // Prints "RAL_PASS checks=<n>" when no UVM_ERROR/UVM_FATAL was reported.
  class tilelink_ral_test extends tilelink_base_test;
    `uvm_component_utils(tilelink_ral_test)
    int unsigned checks;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task run_phase(uvm_phase phase);
      uvm_reg_hw_reset_seq rst_seq;
      uvm_reg_bit_bash_seq bb_seq;
      uvm_mem_walk_seq     walk_seq;
      uvm_status_e         status;
      uvm_reg_data_t       val, exp;
      tilelink_reg_block        rm = env.regmodel;
      phase.raise_objection(this);

      rst_seq = uvm_reg_hw_reset_seq::type_id::create("rst_seq");
      rst_seq.model = rm;
      rst_seq.start(null);
      checks += rm.N_REGS;

      bb_seq = uvm_reg_bit_bash_seq::type_id::create("bb_seq");
      bb_seq.model = rm;
      bb_seq.start(null);
      checks += rm.N_REGS * 32;

      walk_seq = uvm_mem_walk_seq::type_id::create("walk_seq");
      walk_seq.model = rm;
      walk_seq.start(null);
      checks += rm.MEM.get_size();

      foreach (rm.REG[i]) begin
        exp = $urandom();
        rm.REG[i].write(status, exp);
        if (status != UVM_IS_OK) `uvm_error("RAL", $sformatf("REG%0d write status %s", i, status.name()))
      end
      foreach (rm.REG[i]) begin
        exp = rm.REG[i].get_mirrored_value();
        rm.REG[i].mirror(status, UVM_CHECK);
        rm.REG[i].read(status, val);
        if (status != UVM_IS_OK || val != exp)
          `uvm_error("RAL", $sformatf("REG%0d read 0x%08h status %s, expected 0x%08h",
                     i, val, status.name(), exp))
        checks += 2;
      end
      repeat (32) begin
        uvm_reg_addr_t off = $urandom_range(rm.MEM.get_size() - 1);
        exp = $urandom();
        rm.MEM.write(status, off, exp);
        rm.MEM.read(status, off, val);
        if (status != UVM_IS_OK || val != exp)
          `uvm_error("RAL", $sformatf("MEM[%0d] read 0x%08h status %s, expected 0x%08h",
                     off, val, status.name(), exp))
        checks++;
      end

      #100ns;
      phase.drop_objection(this);
    endtask

    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      super.report_phase(phase);
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0)
        $display("RAL_PASS checks=%0d", checks);
      else
        $display("RAL_FAIL errors=%0d", rs.get_severity_count(UVM_ERROR));
    endfunction
  endclass

  // Coverage closure (#31): size x region sweep with corner data, random
  // legal traffic, then illegal-opcode injection. Prints "SB_PASS checks=<n>"
  // when no UVM_ERROR/UVM_FATAL was reported.
  class tilelink_cov_test extends tilelink_base_test;
    `uvm_component_utils(tilelink_cov_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      tilelink_cov_sweep_seq    sw  = tilelink_cov_sweep_seq::type_id::create("sw");
      tilelink_error_inject_seq err = tilelink_error_inject_seq::type_id::create("err");
      // the device model reports each injected illegal opcode; that is the
      // expected response here, not a VIP failure
      uvm_root::get().set_report_severity_id_override(UVM_WARNING, "DUT", UVM_INFO);
      phase.raise_objection(this);
      sw.start(env.agt.sqr);
      err.start(env.agt.sqr);
      #100ns;
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      super.report_phase(phase);
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0 &&
          env.sb.get_checks > 0)
        $display("SB_PASS checks=%0d", env.sb.match_cnt);
    endfunction
  endclass
endpackage
