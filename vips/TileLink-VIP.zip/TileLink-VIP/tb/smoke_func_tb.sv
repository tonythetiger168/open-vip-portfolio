// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened TL-UH device
// tilelink_device_model (tb/top_tb.sv): PutFullData / PutPartialData / Get
// of 1 to 64 bytes (bursts of up to 16 beats), every ArithmeticData and
// LogicalData param on 1, 2 and 4 bytes, Intent, the denied region,
// a_corrupt, up to 4 operations in flight on different sources with
// out-of-order completion, D back-pressure, and reset.
//
// The host drives the A channel from the test process; an always block
// takes the D beats (d_ready random), and when the last beat of an
// operation arrives it replays the operation on a byte-wide reference
// memory, in completion order, which is the order the device carries the
// operations out.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        vif_clk       = 1'b0;
  logic        vif_reset_n   = 1'b0;
  logic        vif_a_valid   = 1'b0;
  wire         vif_a_ready;
  logic [2:0]  vif_a_opcode  = 3'd0;
  logic [2:0]  vif_a_param   = 3'd0;
  logic [2:0]  vif_a_size    = 3'd0;
  logic [3:0]  vif_a_source  = 4'd0;
  logic [31:0] vif_a_address = 32'h0;
  logic [3:0]  vif_a_mask    = 4'h0;
  logic [31:0] vif_a_data    = 32'h0;
  logic        vif_a_corrupt = 1'b0;
  wire         vif_d_valid;
  logic        vif_d_ready   = 1'b0;
  wire  [2:0]  vif_d_opcode;
  wire  [1:0]  vif_d_param;
  wire  [2:0]  vif_d_size;
  wire  [3:0]  vif_d_source;
  wire         vif_d_sink;
  wire         vif_d_denied;
  wire  [31:0] vif_d_data;
  wire         vif_d_corrupt;

  always #5 vif_clk = ~vif_clk;

  tilelink_device_model u_dut (
    .vif_clk(vif_clk), .vif_reset_n(vif_reset_n),
    .vif_a_valid(vif_a_valid), .vif_a_ready(vif_a_ready), .vif_a_opcode(vif_a_opcode),
    .vif_a_param(vif_a_param), .vif_a_size(vif_a_size), .vif_a_source(vif_a_source),
    .vif_a_address(vif_a_address), .vif_a_mask(vif_a_mask), .vif_a_data(vif_a_data),
    .vif_a_corrupt(vif_a_corrupt),
    .vif_d_valid(vif_d_valid), .vif_d_ready(vif_d_ready), .vif_d_opcode(vif_d_opcode),
    .vif_d_param(vif_d_param), .vif_d_size(vif_d_size), .vif_d_source(vif_d_source),
    .vif_d_sink(vif_d_sink), .vif_d_denied(vif_d_denied), .vif_d_data(vif_d_data),
    .vif_d_corrupt(vif_d_corrupt)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  localparam [2:0] PUTF = 3'd0, PUTP = 3'd1, ARI = 3'd2, LOG = 3'd3, GET = 3'd4, INT = 3'd5;

  // ------------------------------------------------------------------ model
  logic [7:0] ref_mem [0:4095];
  task automatic ref_clear();
    for (int i = 0; i < 4096; i++) ref_mem[i] = 8'h0;
  endtask
  initial ref_clear();

  function automatic [31:0] ref_word(input [31:0] a);
    ref_word = {ref_mem[{a[11:2], 2'b11}], ref_mem[{a[11:2], 2'b10}],
                ref_mem[{a[11:2], 2'b01}], ref_mem[{a[11:2], 2'b00}]};
  endfunction

  function automatic [31:0] sx(input [31:0] v, input [2:0] size);
    sx = (size == 3'd0) ? {{24{v[7]}}, v[7:0]} : (size == 3'd1) ? {{16{v[15]}}, v[15:0]} : v;
  endfunction

  // independent atomic reference: operand of 2^size bytes at byte offset off
  function automatic [31:0] ref_amo(input [31:0] old, input [31:0] wd, input [2:0] op,
                                    input [2:0] prm, input [2:0] size, input [1:0] off);
    logic [31:0] m, a, b, r;
    integer      sh;
    m  = (size == 3'd0) ? 32'hFF : (size == 3'd1) ? 32'hFFFF : 32'hFFFF_FFFF;
    sh = (size == 3'd0) ? off * 8 : (size == 3'd1) ? off[1] * 16 : 0;
    a  = (old >> sh) & m;
    b  = (wd >> sh) & m;
    r  = b;
    if (op == ARI) begin
      if (prm == 3'd0) r = ($signed(sx(a, size)) <= $signed(sx(b, size))) ? a : b;
      if (prm == 3'd1) r = ($signed(sx(a, size)) >= $signed(sx(b, size))) ? a : b;
      if (prm == 3'd2) r = (a <= b) ? a : b;
      if (prm == 3'd3) r = (a >= b) ? a : b;
      if (prm == 3'd4) r = (a + b) & m;
    end
    else begin
      if (prm == 3'd0) r = a ^ b;
      if (prm == 3'd1) r = a | b;
      if (prm == 3'd2) r = a & b;
      if (prm == 3'd3) r = b;
    end
    ref_amo = (old & ~(m << sh)) | ((r & m) << sh);
  endfunction

  function automatic [3:0] lanes(input [31:0] a, input [2:0] size);
    lanes = (size == 3'd0) ? (4'b0001 << a[1:0]) : (size == 3'd1) ? (a[1] ? 4'b1100 : 4'b0011) : 4'b1111;
  endfunction

  function automatic integer nbeats(input [2:0] size);
    nbeats = (size <= 3'd2) ? 1 : (1 << (size - 3'd2));
  endfunction

  // ------------------------------------------------------- operation table
  logic        s_busy [0:15];
  logic [2:0]  s_op   [0:15];
  logic [2:0]  s_prm  [0:15];
  logic [2:0]  s_size [0:15];
  logic [31:0] s_addr [0:15];
  integer      s_age  [0:15];
  logic [31:0] s_data [0:255];        // source * 16 + beat
  logic [3:0]  s_mask [0:255];
  logic        s_cor  [0:255];
  // response being collected, per source
  integer      r_cnt  [0:15];
  logic [2:0]  r_op   [0:15];
  logic        r_den  [0:15];
  logic        r_corr [0:15];
  logic [2:0]  r_size [0:15];
  logic [31:0] r_data [0:255];
  integer      stamp = 0, n_flight = 0, max_flight = 0, n_ooo = 0, n_done = 0;
  integer      a_stall_full = 0, d_held_bad = 0, d_held_seen = 0, n_dstall = 0;
  integer      bp_pct = 25;
  initial for (int k = 0; k < 16; k++) s_busy[k] = 1'b0;

  // ---------------------------------------------------- replay on the model
  integer      xb, xi;
  logic        c_den, c_ok, c_older;
  logic [2:0]  c_exp_op;
  logic [31:0] c_w, c_old;
  logic [4:0]  c_src;

  task automatic complete(input [3:0] s);
    c_den    = s_addr[s][15:12] == 4'h2;
    c_exp_op = (s_op[s] == PUTF || s_op[s] == PUTP) ? 3'd0 : (s_op[s] == INT) ? 3'd2 : 3'd1;
    chk(r_op[s] == c_exp_op && r_size[s] == s_size[s] && r_den[s] == c_den &&
        r_corr[s] == (c_den && c_exp_op == 3'd1),
        $sformatf("op %0d size %0d @%h: D opcode %0d size %0d denied %0d corrupt %0d",
                  s_op[s], s_size[s], s_addr[s], r_op[s], r_size[s], r_den[s], r_corr[s]));
    chk(r_cnt[s] == ((c_exp_op == 3'd1) ? nbeats(s_size[s]) : 1),
        $sformatf("op %0d size %0d: %0d D beats", s_op[s], s_size[s], r_cnt[s]));
    c_ok = 1'b1;
    if (s_op[s] == GET)
      for (xb = 0; xb < nbeats(s_size[s]); xb++)
        if (r_data[{s, xb[3:0]}] !== (c_den ? 32'h0 : ref_word(s_addr[s] + xb * 4))) c_ok = 1'b0;
    if (s_op[s] == ARI || s_op[s] == LOG) begin
      c_old = ref_word(s_addr[s]);
      if (r_data[{s, 4'd0}] !== (c_den ? 32'h0 : c_old)) c_ok = 1'b0;
      if (!c_den && !s_cor[{s, 4'd0}]) begin
        c_w = ref_amo(c_old, s_data[{s, 4'd0}], s_op[s], s_prm[s], s_size[s], s_addr[s][1:0]);
        for (xi = 0; xi < 4; xi++) ref_mem[{s_addr[s][11:2], xi[1:0]}] = c_w[xi*8 +: 8];
      end
    end
    if ((s_op[s] == PUTF || s_op[s] == PUTP) && !c_den)
      for (xb = 0; xb < nbeats(s_size[s]); xb++)
        if (!s_cor[{s, xb[3:0]}])
          for (xi = 0; xi < 4; xi++)
            if (s_mask[{s, xb[3:0]}][xi])
              ref_mem[{s_addr[s][11:2] + xb[9:0], xi[1:0]}] = s_data[{s, xb[3:0]}][xi*8 +: 8];
    if (s_op[s] == GET || s_op[s] == ARI || s_op[s] == LOG)
      chk(c_ok, $sformatf("op %0d param %0d size %0d @%h: data matches the reference",
                          s_op[s], s_prm[s], s_size[s], s_addr[s]));
    c_older = 1'b0;
    for (xi = 0; xi < 16; xi++) if (s_busy[xi] && xi != s && s_age[xi] < s_age[s]) c_older = 1'b1;
    if (c_older) n_ooo++;
    s_busy[s] = 1'b0;
    n_flight--;
    n_done++;
  endtask

  // ------------------------------------------------------------ D channel
  logic        d_rdy;
  logic        pv_valid;
  logic [47:0] pv_payload;
  always @(negedge vif_clk) vif_d_ready = ($urandom_range(99) >= bp_pct);
  always @(posedge vif_clk) begin
    if (vif_reset_n) begin
      // payload held while d_ready is low
      if (pv_valid) begin
        d_held_seen++;
        if (!vif_d_valid || {vif_d_opcode, vif_d_size, vif_d_source, vif_d_denied, vif_d_corrupt,
                              vif_d_data[31:0]} !== pv_payload[45:0]) d_held_bad++;
      end
      pv_valid   = vif_d_valid && !vif_d_ready;
      pv_payload = {2'b00, vif_d_opcode, vif_d_size, vif_d_source, vif_d_denied, vif_d_corrupt, vif_d_data};
      if (vif_d_valid && !vif_d_ready) n_dstall++;
      if (vif_a_valid && !vif_a_ready && n_flight >= 4) a_stall_full++;
      if (vif_d_valid && vif_d_ready) begin
        c_src = {1'b0, vif_d_source};
        if (!s_busy[vif_d_source]) chk(0, $sformatf("D beat on idle source %0d", vif_d_source));
        else begin
          if (r_cnt[vif_d_source] == 0) begin
            r_op[vif_d_source]   = vif_d_opcode;
            r_size[vif_d_source] = vif_d_size;
            r_den[vif_d_source]  = vif_d_denied;
            r_corr[vif_d_source] = 1'b0;
          end
          if (vif_d_corrupt) r_corr[vif_d_source] = 1'b1;
          r_data[{vif_d_source, r_cnt[vif_d_source][3:0]}] = vif_d_data;
          r_cnt[vif_d_source] = r_cnt[vif_d_source] + 1;
          if (vif_d_opcode != 3'd1 || r_cnt[vif_d_source] == nbeats(vif_d_size))
            complete(vif_d_source);
        end
      end
    end
    else pv_valid = 1'b0;
  end

  // ------------------------------------------- timing mirror (one op alone)
  // With a single operation in the device, a_ready after a clock edge is
  // exactly lfsr[5:4] != 0 at that edge, and a queued operation starts its
  // response at the first edge where lfsr[7:6] != 0. The bench mirrors the
  // device LFSR (seed 16'h5EED) and checks both, cycle by cycle.
  logic [15:0] tl = 16'h5EED;
  logic        solo = 1'b0, m_have = 1'b0, m_dchk = 1'b0, m_ar = 1'b0, m_dv = 1'b0, m_pend = 1'b0;
  integer      m_acc = 0, m_ar_bad = 0, m_dv_bad = 0, m_ar_seen = 0, m_dv_seen = 0;
  always @(posedge vif_clk) begin
    if (vif_reset_n) begin
      if (m_have && solo) begin
        m_ar_seen++;
        if (vif_a_ready !== m_ar) m_ar_bad++;
        if (m_dchk) begin
          m_dv_seen++;
          if (vif_d_valid !== m_dv) m_dv_bad++;
        end
      end
      m_have = solo;
      m_ar   = (tl[5:4] != 2'b00);
      m_dchk = !vif_d_valid;   // 2-state safe: only a rising edge is predicted
      m_dv   = m_pend && tl[7:6] != 2'b00;
      if (vif_d_valid) m_pend = 1'b0;
      if (!vif_d_valid && m_pend && tl[7:6] != 2'b00) m_pend = 1'b0;
      if (vif_a_valid && vif_a_ready) begin
        m_acc++;
        if (m_acc == (((vif_a_opcode == GET) || (vif_a_opcode == INT)) ? 1 : nbeats(vif_a_size))) begin
          m_acc = 0; m_pend = 1'b1;
        end
      end
      tl = {tl[14:0], tl[15] ^ tl[13] ^ tl[12] ^ tl[10]};
    end
    else begin
      tl = 16'h5EED; m_have = 1'b0; m_pend = 1'b0; m_acc = 0;
    end
  end

  // ------------------------------------------------------------ A channel
  integer      a_src, ab, si, gap_pct = 15;
  logic [3:0]  next_src = 4'd0;

  // issue one operation; returns once its A beats are accepted
  task automatic issue(input [2:0] op, input [31:0] addr, input [2:0] size, input [2:0] prm,
                       input [31:0] seed, input [3:0] pmask = 4'hF, input integer cor_beat = -1,
                       input integer max_out = 4);
    // a free source, and at most max_out in flight
    a_src = -1;
    while (a_src < 0) begin
      if (n_flight < max_out)
        for (si = 15; si >= 0; si--) if (!s_busy[4'(next_src + si)]) a_src = 4'(next_src + si);
      if (a_src < 0) @(negedge vif_clk);
    end
    next_src = a_src + 1;
    s_busy[a_src] = 1'b1; s_op[a_src] = op; s_prm[a_src] = prm; s_size[a_src] = size;
    s_addr[a_src] = addr; s_age[a_src] = stamp; stamp++;
    r_cnt[a_src] = 0;
    n_flight++;
    if (n_flight > max_flight) max_flight = n_flight;
    for (ab = 0; ab < 16; ab++) begin
      s_data[{a_src[3:0], ab[3:0]}] = seed * 32'h9E37_79B9 + ab * 32'h0101_0101;
      s_mask[{a_src[3:0], ab[3:0]}] = (op == PUTP) ? ((pmask ^ ab[3:0]) & lanes(addr, size)) : lanes(addr, size);
      s_cor[{a_src[3:0], ab[3:0]}]  = (ab == cor_beat);
    end
    for (ab = 0; ab < ((op == GET || op == INT) ? 1 : nbeats(size)); ab++) begin
      @(negedge vif_clk);
      while ($urandom_range(99) < gap_pct) begin vif_a_valid = 1'b0; @(negedge vif_clk); end
      vif_a_valid = 1'b1; vif_a_opcode = op; vif_a_param = prm; vif_a_size = size;
      vif_a_source = a_src[3:0]; vif_a_address = addr; vif_a_mask = s_mask[{a_src[3:0], ab[3:0]}];
      vif_a_data = (op == GET || op == INT) ? 32'h0 : s_data[{a_src[3:0], ab[3:0]}];
      vif_a_corrupt = s_cor[{a_src[3:0], ab[3:0]}];
      @(posedge vif_clk);
      while (vif_a_ready !== 1'b1) @(posedge vif_clk);
    end
    @(negedge vif_clk);
    vif_a_valid = 1'b0; vif_a_corrupt = 1'b0;
  endtask

  task automatic drain();
    si = 0;
    while (n_flight > 0 && si < 2000) begin @(negedge vif_clk); si++; end
    chk(n_flight == 0, "all operations completed");
  endtask

  // issue and wait for completion
  task automatic op1(input [2:0] op, input [31:0] addr, input [2:0] size, input [2:0] prm,
                     input [31:0] seed, input [3:0] pmask = 4'hF, input integer cor_beat = -1);
    solo = 1'b1;
    issue(op, addr, size, prm, seed, pmask, cor_beat, 1);
    drain();
    solo = 1'b0;
  endtask

  // ------------------------------------------------------------------ tests
  integer t, sz, k, p, n;
  logic [31:0] ad;

  initial begin
    repeat (3) @(negedge vif_clk);
    chk(vif_a_ready === 1'b0 && vif_d_valid === 1'b0, "in reset: a_ready and d_valid low");
    chk(vif_d_sink === 1'b0 && vif_d_denied === 1'b0 && vif_d_corrupt === 1'b0 &&
        vif_d_data === 32'h0 && vif_d_source === 4'h0, "in reset: D fields are zero");
    vif_reset_n = 1'b1;

    // 1. PutFullData / Get of every size, read back
    for (sz = 0; sz <= 6; sz++) begin
      ad = 32'h0000_0400 + sz * 64;
      for (k = 0; k < ((sz < 2) ? 4 : 1); k++) begin
        op1(PUTF, ad + k * (1 << sz), sz, 0, 10 + sz * 4 + k);
        op1(GET,  ad + k * (1 << sz), sz, 0, 0);
      end
      op1(GET, ad, 3'd2, 0, 0);
    end
    op1(GET, 32'h0000_0FC0, 3'd6, 0, 0);      // never written: zero

    // 2. PutPartialData, empty and sparse masks
    for (k = 0; k < 16; k++) begin
      op1(PUTP, 32'h0000_0600 + k * 16, (k < 8) ? 3'd2 : 3'd4, 0, 100 + k, k[3:0]);
      op1(GET,  32'h0000_0600 + k * 16, 3'd4, 0, 0);
    end

    // 3. atomics: every param, 1 / 2 / 4 bytes, signed and unsigned corners
    n = 0;
    for (t = 0; t < 2; t++)
      for (p = 0; p <= ((t == 0) ? 4 : 3); p++)
        for (sz = 0; sz <= 2; sz++) begin
          ad = 32'h0000_0800 + n * 4;
          op1(PUTF, ad, 3'd2, 0, 200 + n);
          ad = ad + ((sz == 0) ? (n % 4) : (sz == 1) ? (n % 2) * 2 : 0);
          op1((t == 0) ? ARI : LOG, ad, sz, p, 300 + n);
          op1((t == 0) ? ARI : LOG, ad, sz, p, 32'h8000_0000 + n);
          op1(GET, ad & ~32'h3, 3'd2, 0, 0);
          n++;
        end

    // 4. Intent of every size: HintAck, nothing changes
    for (sz = 0; sz <= 6; sz++) op1(INT, 32'h0000_0400, sz, sz % 2, 0);
    op1(GET, 32'h0000_0400, 3'd6, 0, 0);

    // 5. denied region: every opcode, nothing read or written
    for (t = 0; t <= 5; t++) begin
      op1(t, 32'h0000_2040 + t * 16, (t == ARI || t == LOG) ? 3'd2 : 3'd4, 0, 600 + t, 4'hA);
      op1(t, 32'h0000_2400 + t * 4, 3'd2, 0, 610 + t);
    end
    op1(GET, 32'h0000_0040, 3'd6, 0, 0);       // the aliased words are untouched

    // 6. a_corrupt: that beat is not written
    for (k = 0; k < 4; k++) begin
      op1(PUTF, 32'h0000_0E00 + k * 64, 3'd6, 0, 700 + k, 4'hF, k * 5);
      op1(PUTP, 32'h0000_0E00 + k * 64 + 32, 3'd3, 0, 710 + k, 4'hC, k % 2);
      op1(LOG,  32'h0000_0E00 + k * 64 + 16, 3'd2, 0, 720 + k, 4'hF, (k % 2) ? 0 : -1);
      op1(GET,  32'h0000_0E00 + k * 64, 3'd6, 0, 0);
    end

    // 7. up to 4 in flight on different sources, random mix
    for (k = 0; k < 400; k++) begin
      t  = $urandom_range(5);
      sz = (t == ARI || t == LOG) ? $urandom_range(2) : $urandom_range(6);
      ad = 32'h0000_0C00 + ($urandom_range(1023) & ~((1 << sz) - 1));
      if (k % 50 == 49) ad = ad | 32'h0000_2000;
      issue(t, ad, sz, (t == ARI) ? $urandom_range(4) : (t == LOG) ? $urandom_range(3) :
                       (t == INT) ? $urandom_range(1) : 0,
            900 + k, $urandom_range(15), ($urandom_range(9) == 0) ? 0 : -1, 4);
    end
    drain();
    chk(max_flight == 4, $sformatf("4 operations in flight (max %0d)", max_flight));
    chk(n_ooo > 20, $sformatf("operations complete out of order (%0d)", n_ooo));
    chk(a_stall_full > 0, "the device holds a_ready low while it holds 4 operations");
    chk(n_dstall > 20 && d_held_seen > 20 && d_held_bad == 0,
        $sformatf("D payload held while d_ready is low (%0d stalls, %0d bad)", d_held_seen, d_held_bad));

    // 7b. full device: D stalled, 1 response + 4 queued, the next A waits
    bp_pct = 100;
    // the last one is a 4-beat burst: its final beat must not leave a_ready high
    for (k = 0; k < 4; k++) issue(GET, 32'h0000_0C00 + k * 4, 3'd2, 0, 0, 4'hF, -1, 5);
    issue(PUTF, 32'h0000_0C80, 3'd4, 0, 77, 4'hF, -1, 5);
    repeat (10) @(negedge vif_clk);
    vif_a_valid = 1'b1; vif_a_opcode = GET; vif_a_size = 3'd2; vif_a_source = 4'hF;
    vif_a_address = 32'h0000_0C40; vif_a_mask = 4'hF; vif_a_data = 32'h0;
    n = 0;
    repeat (40) begin @(posedge vif_clk); if (vif_a_ready === 1'b1) n++; end
    @(negedge vif_clk); vif_a_valid = 1'b0;
    chk(n == 0, $sformatf("a_ready stays low with 4 queued and D stalled (%0d)", n));
    bp_pct = 25;
    drain();

    // 8. everything read back
    for (k = 0; k < 64; k++) op1(GET, k * 64, 3'd6, 0, 0);

    // 9. reset in the middle: memory cleared, nothing in flight
    issue(PUTF, 32'h0000_0100, 3'd2, 0, 999, 4'hF, -1, 4);
    drain();
    @(negedge vif_clk); vif_reset_n = 1'b0;
    @(negedge vif_clk);
    chk(vif_a_ready === 1'b0 && vif_d_valid === 1'b0, "reset again: a_ready and d_valid low");
    chk(vif_d_sink === 1'b0 && vif_d_denied === 1'b0 && vif_d_corrupt === 1'b0 &&
        vif_d_data === 32'h0, "reset again: D fields are zero");
    vif_reset_n = 1'b1;
    ref_clear();
    op1(GET, 32'h0000_0100, 3'd2, 0, 0);
    op1(GET, 32'h0000_0000, 3'd6, 0, 0);

    chk(n_done > 600, $sformatf("%0d operations completed", n_done));
    chk(m_ar_seen > 1000 && m_ar_bad == 0,
        $sformatf("a_ready follows the device LFSR (%0d edges, %0d bad)", m_ar_seen, m_ar_bad));
    chk(m_dv_seen > 1000 && m_dv_bad == 0,
        $sformatf("responses start at the predicted edge (%0d edges, %0d bad)", m_dv_seen, m_dv_bad));
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #5000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
