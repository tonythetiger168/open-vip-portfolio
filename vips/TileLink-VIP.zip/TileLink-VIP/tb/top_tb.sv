// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- TileLink testbench top with a functional TL-UL device DUT model

`ifndef TILELINK_TB_SV
`define TILELINK_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import tilelink_defs_pkg::*;
import tilelink_pkg::*;
import tilelink_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  tilelink_if vif(clk);

  initial begin
    vif.reset_n = 0;
    #100ns;
    vif.reset_n = 1;
  end

  tilelink_device_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual tilelink_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional TL-UL device: registered a_ready (~80%, no combinational
// dependence on a_valid), single outstanding request, 1-cycle response,
// small associative memory; Get -> AccessAckData, PutFullData -> AccessAck,
// illegal opcodes -> AccessAck without a memory update.
module tilelink_device_model (tilelink_if vif);
  localparam bit [2:0] A_PUTFULL = 3'd0, A_GET = 3'd4;
  localparam bit [2:0] D_ACCESS_ACK = 3'd0, D_ACCESS_ACK_DATA = 3'd1;

  bit [31:0] mem [bit [31:0]];
  bit        pend;
  bit [2:0]  pend_op;
  bit [31:0] pend_addr, pend_wdata;

  initial begin
    vif.a_ready  = 0;
    vif.d_valid  = 0;
    vif.d_opcode = '0;
    vif.d_data   = '0;
    pend         = 0;
  end

  always_ff @(posedge vif.clk or negedge vif.reset_n) begin
    if (!vif.reset_n) begin
      vif.a_ready  <= 0;
      vif.d_valid  <= 0;
      vif.d_opcode <= '0;
      vif.d_data   <= '0;
      pend         <= 0;
    end else begin
      // Registered ready: ~80% while idle; never combinationally depends
      // on a_valid (no combinational ready <- valid loop).
      vif.a_ready <= !pend && ($urandom_range(4) != 0);
      vif.d_valid <= 1'b0;

      // A-channel handshake: latch the request
      if (vif.a_valid && vif.a_ready) begin
        pend       <= 1;
        pend_op    <= vif.a_opcode;
        pend_addr  <= vif.a_address;
        pend_wdata <= vif.a_data;
      end

      // D channel: respond one cycle later (host holds d_ready high)
      if (pend) begin
        pend        <= 0;
        vif.d_valid <= 1'b1;
        case (pend_op)
          A_GET: begin
            vif.d_opcode <= D_ACCESS_ACK_DATA;
            vif.d_data   <= mem.exists(pend_addr) ? mem[pend_addr] : 32'h0;
          end
          A_PUTFULL: begin
            vif.d_opcode <= D_ACCESS_ACK;
            vif.d_data   <= 32'h0;
            mem[pend_addr] = pend_wdata;
          end
          default: begin
            // Illegal opcode: acknowledge without touching memory
            `uvm_warning("DUT", $sformatf("tilelink device: illegal A opcode 0x%0h", pend_op))
            vif.d_opcode <= D_ACCESS_ACK;
            vif.d_data   <= 32'h0;
          end
        endcase
      end
    end
  end
endmodule
`endif
