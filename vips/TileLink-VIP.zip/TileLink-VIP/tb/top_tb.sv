// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- TileLink testbench top with a functional TL-UH device DUT model

`ifndef TILELINK_TB_SV
`define TILELINK_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import tilelink_defs_pkg::*;
import tilelink_pkg::*;
import tilelink_test_pkg::*;
`include "sva/tilelink_compliance_checker.sv"

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  tilelink_if vif(clk);

  initial begin
    vif.reset_n = 0;
    #100ns;
    vif.reset_n = 1;
  end

  tilelink_device_model dut(.vif(vif));

  tilelink_compliance_checker u_sva (
    .clk(clk), .reset_n(vif.reset_n),
    .a_valid(vif.a_valid), .a_ready(vif.a_ready), .a_opcode(vif.a_opcode), .a_param(vif.a_param),
    .a_size(vif.a_size), .a_source(vif.a_source), .a_address(vif.a_address), .a_mask(vif.a_mask),
    .a_data(vif.a_data), .a_corrupt(vif.a_corrupt),
    .d_valid(vif.d_valid), .d_ready(vif.d_ready), .d_opcode(vif.d_opcode), .d_param(vif.d_param),
    .d_size(vif.d_size), .d_source(vif.d_source), .d_sink(vif.d_sink), .d_denied(vif.d_denied),
    .d_data(vif.d_data), .d_corrupt(vif.d_corrupt));

  initial begin
    uvm_config_db#(virtual tilelink_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional TL-UH device (TileLink 1.8.1 chapters 5-7), 32-bit data bus:
//   * 4 KB memory at word address addr[11:2] (aliased above 0x1000);
//     0x2000-0x2FFF is denied: d_denied, nothing read or written, data
//     beats of AccessAckData marked d_corrupt
//   * up to 4 operations held at once (one per slot); A beats of a message
//     with data are collected before it can be answered
//   * responses are picked from the complete operations in a random order,
//     so operations on different sources complete out of order; the
//     operation is carried out when its response starts (Get data is a
//     snapshot of that moment)
//   * PutFullData / PutPartialData write the bytes of a_mask, except in
//     beats with a_corrupt; ArithmeticData (MIN, MAX, MINU, MAXU, ADD) and
//     LogicalData (XOR, OR, AND, SWAP) of 1, 2 or 4 bytes return the old
//     value; Intent is answered with HintAck
//   * registered a_ready (random, low when no slot is free), random gaps
//     before a response, D payload held while d_ready is low
module tilelink_device_model (tilelink_if vif);
  localparam bit [2:0] A_PUTFULL = 3'd0, A_PUTPART = 3'd1, A_ARITH = 3'd2, A_LOGIC = 3'd3,
                       A_GET = 3'd4, A_INTENT = 3'd5;
  localparam bit [2:0] D_ACK = 3'd0, D_ACK_DATA = 3'd1, D_HINT_ACK = 3'd2;

  logic [31:0] mem    [0:1023];
  // operation slots (parallel arrays)
  logic        q_v    [0:3];
  logic        q_full [0:3];
  logic [2:0]  q_op   [0:3];
  logic [2:0]  q_prm  [0:3];
  logic [2:0]  q_size [0:3];
  logic [3:0]  q_src  [0:3];
  logic [31:0] q_addr [0:3];
  logic [4:0]  q_nb   [0:3];
  logic [31:0] q_data [0:63];     // slot * 16 + beat
  logic [3:0]  q_mask [0:63];
  logic        q_cor  [0:63];
  // A message in progress
  logic        a_busy;
  logic [1:0]  a_slot;
  // response in progress
  logic        r_act;
  logic [4:0]  r_beat, r_n;
  logic [31:0] r_buf  [0:15];
  logic [15:0] lfsr;
  // combinational helpers
  logic [1:0]  free_k, pick_k;
  logic        free_ok, pick_ok;
  logic [2:0]  n_free;
  logic        den;               // scratch of the response start
  logic [9:0]  wi;
  logic [31:0] w;

  function automatic [4:0] beats_of(input [2:0] op, input [2:0] size);
    if (op == A_GET || op == A_INTENT || size <= 3'd2) return 5'd1;
    return 5'd1 << (size - 3'd2);
  endfunction

  function automatic [4:0] d_beats_of(input [2:0] op, input [2:0] size);
    if (op == A_PUTFULL || op == A_PUTPART || op == A_INTENT || size <= 3'd2) return 5'd1;
    return 5'd1 << (size - 3'd2);
  endfunction

  function automatic [31:0] sext(input [31:0] v, input [2:0] size);
    case (size)
      3'd0:    return {{24{v[7]}}, v[7:0]};
      3'd1:    return {{16{v[15]}}, v[15:0]};
      default: return v;
    endcase
  endfunction

  // atomic operation on the 2^size-byte operand at byte offset off
  function automatic [31:0] amo(input [31:0] old, input [31:0] wd, input [2:0] op,
                                input [2:0] prm, input [2:0] size, input [1:0] off);
    logic [31:0] m, a, b, r;
    logic [4:0]  sh;
    m  = (size == 3'd0) ? 32'h0000_00FF : (size == 3'd1) ? 32'h0000_FFFF : 32'hFFFF_FFFF;
    sh = (size == 3'd0) ? {off, 3'b000} : (size == 3'd1) ? {off[1], 4'b0000} : 5'd0;
    a  = (old >> sh) & m;
    b  = (wd >> sh) & m;
    if (op == A_ARITH)
      case (prm)
        3'd0:    r = ($signed(sext(a, size)) < $signed(sext(b, size))) ? a : b;   // MIN
        3'd1:    r = ($signed(sext(a, size)) > $signed(sext(b, size))) ? a : b;   // MAX
        3'd2:    r = (a < b) ? a : b;                                            // MINU
        3'd3:    r = (a > b) ? a : b;                                            // MAXU
        default: r = (a + b) & m;                                                // ADD
      endcase
    else
      case (prm)
        3'd0:    r = a ^ b;                                                      // XOR
        3'd1:    r = a | b;                                                      // OR
        3'd2:    r = a & b;                                                      // AND
        default: r = b;                                                          // SWAP
      endcase
    return (old & ~(m << sh)) | ((r & m) << sh);
  endfunction

  always_comb begin
    free_ok = 1'b0; free_k = 2'd0; n_free = 3'd0;
    for (int k = 3; k >= 0; k--)
      if (!q_v[k]) begin free_ok = 1'b1; free_k = k[1:0]; n_free = n_free + 3'd1; end
    pick_ok = 1'b0; pick_k = 2'd0;
    for (int i = 3; i >= 0; i--)
      if (q_v[2'(lfsr[1:0] + i)] && q_full[2'(lfsr[1:0] + i)]) begin
        pick_ok = 1'b1; pick_k = 2'(lfsr[1:0] + i);
      end
  end

  initial begin
    vif.a_ready = 1'b0; vif.d_valid = 1'b0;
  end

  always_ff @(posedge vif.clk or negedge vif.reset_n) begin
    if (!vif.reset_n) begin
      vif.a_ready  <= 1'b0;
      vif.d_valid  <= 1'b0;
      vif.d_opcode <= 3'd0; vif.d_param <= 2'd0; vif.d_size <= 3'd0; vif.d_source <= 4'd0;
      vif.d_sink   <= 1'b0; vif.d_denied <= 1'b0; vif.d_data <= 32'h0; vif.d_corrupt <= 1'b0;
      a_busy <= 1'b0; a_slot <= 2'd0;
      r_act  <= 1'b0; r_beat <= 5'd0; r_n <= 5'd0;
      lfsr   <= 16'h5EED;
      for (int k = 0; k < 4; k++) begin q_v[k] <= 1'b0; q_full[k] <= 1'b0; end
      for (int w = 0; w < 1024; w++) mem[w] <= 32'h0;
    end
    else begin
      lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      // ---------------- A channel ----------------
      if (vif.a_valid && vif.a_ready) begin
        if (!a_busy) begin
          q_v[free_k]    <= 1'b1;
          q_op[free_k]   <= vif.a_opcode;
          q_prm[free_k]  <= vif.a_param;
          q_size[free_k] <= vif.a_size;
          q_src[free_k]  <= vif.a_source;
          q_addr[free_k] <= vif.a_address;
          q_nb[free_k]   <= 5'd1;
          q_data[{free_k, 4'd0}] <= vif.a_data;
          q_mask[{free_k, 4'd0}] <= vif.a_mask;
          q_cor[{free_k, 4'd0}]  <= vif.a_corrupt;
          if (beats_of(vif.a_opcode, vif.a_size) == 5'd1) q_full[free_k] <= 1'b1;
          else begin q_full[free_k] <= 1'b0; a_busy <= 1'b1; a_slot <= free_k; end
        end
        else begin
          q_data[{a_slot, q_nb[a_slot][3:0]}] <= vif.a_data;
          q_mask[{a_slot, q_nb[a_slot][3:0]}] <= vif.a_mask;
          q_cor[{a_slot, q_nb[a_slot][3:0]}]  <= vif.a_corrupt;
          q_nb[a_slot] <= q_nb[a_slot] + 5'd1;
          if (q_nb[a_slot] + 5'd1 == beats_of(q_op[a_slot], q_size[a_slot])) begin
            q_full[a_slot] <= 1'b1; a_busy <= 1'b0;
          end
        end
      end
      // registered ready: a message in progress continues; a new one needs
      // a free slot that this edge does not take
      vif.a_ready <= lfsr[5:4] != 2'b00 &&
                     ((a_busy && !(vif.a_valid && vif.a_ready &&
                                   q_nb[a_slot] + 5'd1 == beats_of(q_op[a_slot], q_size[a_slot]))) ||
                      (vif.a_valid && vif.a_ready && !a_busy && beats_of(vif.a_opcode, vif.a_size) != 5'd1) ||
                      (n_free > ((vif.a_valid && vif.a_ready && !a_busy) ? 3'd1 : 3'd0)));
      // ---------------- D channel ----------------
      if (r_act) begin
        if (vif.d_ready) begin
          if (r_beat + 5'd1 == r_n) begin
            vif.d_valid <= 1'b0; vif.d_corrupt <= 1'b0; r_act <= 1'b0;
          end
          else begin
            r_beat     <= r_beat + 5'd1;
            vif.d_data <= r_buf[r_beat[3:0] + 4'd1];
          end
        end
      end
      else if (pick_ok && lfsr[7:6] != 2'b00) begin
        // carry out the operation of slot pick_k and start its response
        den = q_addr[pick_k][15:12] == 4'h2;
        wi  = q_addr[pick_k][11:2];
        for (int b = 0; b < 16; b++) r_buf[b] <= 32'h0;
        case (q_op[pick_k])
          A_GET:
            if (!den) for (int b = 0; b < 16; b++)
              if (b < d_beats_of(A_GET, q_size[pick_k])) r_buf[b] <= mem[wi + b[9:0]];
          A_PUTFULL, A_PUTPART:
            if (!den) for (int b = 0; b < 16; b++)
              if (b < beats_of(A_PUTFULL, q_size[pick_k]) && !q_cor[{pick_k, b[3:0]}]) begin
                w = mem[wi + b[9:0]];
                for (int l = 0; l < 4; l++)
                  if (q_mask[{pick_k, b[3:0]}][l]) w[l*8 +: 8] = q_data[{pick_k, b[3:0]}][l*8 +: 8];
                mem[wi + b[9:0]] <= w;
              end
          A_ARITH, A_LOGIC:
            if (!den) begin
              r_buf[0] <= mem[wi];
              if (!q_cor[{pick_k, 4'd0}])
                mem[wi] <= amo(mem[wi], q_data[{pick_k, 4'd0}], q_op[pick_k], q_prm[pick_k],
                               q_size[pick_k], q_addr[pick_k][1:0]);
            end
          default: ;                                   // Intent: nothing to do
        endcase
        q_v[pick_k]  <= 1'b0;
        r_act        <= 1'b1;
        r_beat       <= 5'd0;
        r_n          <= d_beats_of(q_op[pick_k], q_size[pick_k]);
        vif.d_valid  <= 1'b1;
        vif.d_opcode <= (q_op[pick_k] == A_PUTFULL || q_op[pick_k] == A_PUTPART) ? D_ACK :
                        (q_op[pick_k] == A_INTENT) ? D_HINT_ACK : D_ACK_DATA;
        vif.d_param  <= 2'd0;
        vif.d_size   <= q_size[pick_k];
        vif.d_source <= q_src[pick_k];
        vif.d_sink   <= 1'b0;
        vif.d_denied <= den;
        vif.d_corrupt <= den && !(q_op[pick_k] == A_PUTFULL || q_op[pick_k] == A_PUTPART ||
                                  q_op[pick_k] == A_INTENT);
        vif.d_data   <= (den || q_op[pick_k] != A_GET && q_op[pick_k] != A_ARITH && q_op[pick_k] != A_LOGIC)
                        ? 32'h0 : mem[wi];
      end
    end
  end
endmodule
`endif
