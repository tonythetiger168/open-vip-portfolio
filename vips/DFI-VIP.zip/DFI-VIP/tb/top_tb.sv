// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- DFI testbench top with a functional DFI DUT model

`ifndef DFI_VIP_TB_SV
`define DFI_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import dfi_defs_pkg::*;
import dfi_pkg::*;
import dfi_env_pkg::*;
import dfi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  dfi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  dfi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .init_start(vif.init_start),
    .frequency(vif.frequency),
    .cke(vif.cke),
    .cs_n(vif.cs_n),
    .act_n(vif.act_n),
    .ras_n(vif.ras_n),
    .cas_n(vif.cas_n),
    .we_n(vif.we_n),
    .bank(vif.bank),
    .address(vif.address),
    .wrdata_en(vif.wrdata_en),
    .wrdata(vif.wrdata),
    .wrdata_mask(vif.wrdata_mask),
    .rddata_en(vif.rddata_en),
    .ctrlupd_req(vif.ctrlupd_req),
    .phyupd_ack(vif.phyupd_ack),
    .lp_ctrl_req(vif.lp_ctrl_req),
    .lp_wakeup(vif.lp_wakeup),
    .tb_phyupd(vif.tb_phyupd),
    .init_complete(vif.init_complete),
    .freq(vif.freq),
    .rddata(vif.rddata),
    .rddata_valid(vif.rddata_valid),
    .ctrlupd_ack(vif.ctrlupd_ack),
    .phyupd_req(vif.phyupd_req),
    .phyupd_type(vif.phyupd_type),
    .lp_ack(vif.lp_ack),
    .error(vif.error),
    .error_info(vif.error_info)
  );

  // Concurrent protocol checks
  dfi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .init_start(vif.init_start),
    .frequency(vif.frequency),
    .cke(vif.cke),
    .cs_n(vif.cs_n),
    .act_n(vif.act_n),
    .ras_n(vif.ras_n),
    .cas_n(vif.cas_n),
    .we_n(vif.we_n),
    .bank(vif.bank),
    .address(vif.address),
    .wrdata_en(vif.wrdata_en),
    .wrdata(vif.wrdata),
    .wrdata_mask(vif.wrdata_mask),
    .rddata_en(vif.rddata_en),
    .ctrlupd_req(vif.ctrlupd_req),
    .phyupd_ack(vif.phyupd_ack),
    .lp_ctrl_req(vif.lp_ctrl_req),
    .lp_wakeup(vif.lp_wakeup),
    .tb_phyupd(vif.tb_phyupd),
    .init_complete(vif.init_complete),
    .freq(vif.freq),
    .rddata(vif.rddata),
    .rddata_valid(vif.rddata_valid),
    .ctrlupd_ack(vif.ctrlupd_ack),
    .phyupd_req(vif.phyupd_req),
    .phyupd_type(vif.phyupd_type),
    .lp_ack(vif.lp_ack),
    .error(vif.error),
    .error_info(vif.error_info)
  );

  initial begin
    uvm_config_db#(virtual dfi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module dfi_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        init_start,
  input  logic [4:0]  frequency,
  input  logic        cke,
  input  logic        cs_n,
  input  logic        act_n,
  input  logic        ras_n,
  input  logic        cas_n,
  input  logic        we_n,
  input  logic [2:0]  bank,
  input  logic [13:0] address,
  input  logic        wrdata_en,
  input  logic [31:0] wrdata,
  input  logic [3:0]  wrdata_mask,
  input  logic        rddata_en,
  input  logic        ctrlupd_req,
  input  logic        phyupd_ack,
  input  logic        lp_ctrl_req,
  input  logic [3:0]  lp_wakeup,
  input  logic        tb_phyupd,
  output logic        init_complete,
  output logic [4:0]  freq,
  output logic [31:0] rddata,
  output logic        rddata_valid,
  output logic        ctrlupd_ack,
  output logic        phyupd_req,
  output logic [1:0]  phyupd_type,
  output logic        lp_ack,
  output logic        error,
  output logic [2:0]  error_info
);
  localparam int BL = 4, WRLAT = 3, RDEN = 3, TRCD = 4, TRP = 4, TRAS = 8, TRFC = 12, TINIT = 10;
  localparam int CU_MIN = 4, CU_MAX = 24, PU_RESP = 12, PU_BUSY = 4, LP_RESP = 3;

  logic [31:0] mem [0:4095];
  logic [31:0] cyc, ref_c;
  logic [31:0] act_c [0:7];
  logic [31:0] pre_c [0:7];
  logic [7:0]  open_b;
  logic [13:0] row_q [0:7];
  logic [7:0]  wexp, wst, rexp, rst_m;   // expected data-enable windows (bit 0: this cycle), window starts
  logic [11:0] wbase_n, wbase, rbase_n, rbase;
  logic [1:0]  wbeat, rbeat;
  logic        wcap;
  logic [11:0] wcap_i;
  logic [3:0]  vld_sr;
  logic [31:0] dat_sr [0:3];
  logic        init_q, tbp_q, lp_q;
  logic [4:0]  icnt, freq_n, pu_cnt;
  logic [5:0]  cu_len;
  logic [1:0]  pu_st, pu_type, lp_st;
  logic [3:0]  lp_cnt;

  initial for (int i = 0; i < 4096; i++) mem[i] = 32'h5A5A_0000 | i;

  function automatic logic [11:0] f_idx(input logic [2:0] b, input logic [13:0] r, input logic [9:0] c);
    f_idx = {b, r[2:0], c[5:0]};
  endfunction
  function automatic logic [11:0] f_beat(input logic [11:0] base, input logic [1:0] k);
    f_beat = {base[11:6], base[5:0] + {4'b0, k}};
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cyc <= '0; ref_c <= 32'hFFFF_FF00; open_b <= '0;
      for (int i = 0; i < 8; i++) begin act_c[i] <= '0; pre_c[i] <= 32'hFFFF_FF00; row_q[i] <= '0; end
      wexp <= '0; wst <= '0; rexp <= '0; rst_m <= '0;
      wbase_n <= '0; wbase <= '0; rbase_n <= '0; rbase <= '0; wbeat <= '0; rbeat <= '0;
      wcap <= 1'b0; wcap_i <= '0; vld_sr <= '0;
      for (int i = 0; i < 4; i++) dat_sr[i] <= '0;
      init_q <= 1'b0; tbp_q <= 1'b0; lp_q <= 1'b0; icnt <= '0; freq_n <= '0; pu_cnt <= '0; cu_len <= '0;
      pu_st <= '0; pu_type <= '0; lp_st <= '0; lp_cnt <= '0;
      init_complete <= 1'b0; freq <= '0; rddata <= '0; rddata_valid <= 1'b0; ctrlupd_ack <= 1'b0;
      phyupd_req <= 1'b0; phyupd_type <= '0; lp_ack <= 1'b0; error <= 1'b0; error_info <= '0;
    end else begin : step
      logic [2:0]  e, ce, de;          // handshake, command and data errors of this cycle
      logic [7:0]  wx, wsx, rx, rsx;
      logic [11:0] wi, ri;
      e = 3'd0; ce = 3'd0; de = 3'd0;
      cyc <= cyc + 32'd1;
      error <= 1'b0;
      wx = wexp >> 1; wsx = wst >> 1; rx = rexp >> 1; rsx = rst_m >> 1;

      // initialisation / frequency change
      init_q <= init_start;
      if (init_start && !init_q) begin
        if (open_b != 8'h0) e = 3'd2;
        init_complete <= 1'b0; icnt <= TINIT - 1; freq_n <= frequency;
      end else if (icnt != 5'd0) begin
        icnt <= icnt - 5'd1;
        if (icnt == 5'd1) begin init_complete <= 1'b1; freq <= freq_n; end
      end

      // controller update: ack while requested, tctrlupd_min .. max cycles
      if (ctrlupd_req) begin
        ctrlupd_ack <= 1'b1;
        if (cu_len != 6'd63) cu_len <= cu_len + 6'd1;
      end else begin
        ctrlupd_ack <= 1'b0; cu_len <= '0;
        if (cu_len != 6'd0 && (cu_len < CU_MIN || cu_len > CU_MAX)) e = 3'd6;
      end

      // PHY update, started by tb_phyupd (the PHY's own need for one)
      tbp_q <= tb_phyupd;
      case (pu_st)
        2'd0:
          if (tb_phyupd && !tbp_q) begin
            pu_st <= 2'd1; phyupd_req <= 1'b1; phyupd_type <= pu_type; pu_type <= pu_type + 2'd1; pu_cnt <= '0;
          end
        2'd1:
          if (phyupd_ack) begin pu_st <= 2'd2; pu_cnt <= '0; end
          else begin
            if (pu_cnt != 5'd31) pu_cnt <= pu_cnt + 5'd1;
            if (pu_cnt == PU_RESP) e = 3'd6;          // no ack within tphyupd_resp
          end
        2'd2:
          if (!phyupd_ack) begin e = 3'd6; pu_st <= 2'd0; phyupd_req <= 1'b0; end   // ack dropped during the update
          else begin
            pu_cnt <= pu_cnt + 5'd1;
            if (pu_cnt == PU_BUSY - 1) begin phyupd_req <= 1'b0; pu_st <= 2'd3; end
          end
        default:
          if (!phyupd_ack) pu_st <= 2'd0;
      endcase

      // low power: ack tlp_resp cycles after the request (declined when
      // lp_wakeup is 0), dropped lp_wakeup cycles after the request ends
      lp_q <= lp_ctrl_req;
      case (lp_st)
        2'd0:
          if (lp_ctrl_req && !lp_q && lp_wakeup != 4'd0) begin lp_st <= 2'd1; lp_cnt <= LP_RESP - 1; end
        2'd1:
          if (!lp_ctrl_req) lp_st <= 2'd0;
          else if (lp_cnt == 4'd0) begin lp_ack <= 1'b1; lp_st <= 2'd2; end
          else lp_cnt <= lp_cnt - 4'd1;
        2'd2:
          if (!lp_ctrl_req) begin lp_st <= 2'd3; lp_cnt <= lp_wakeup; end
        default:
          if (lp_cnt <= 4'd1) begin lp_ack <= 1'b0; lp_st <= 2'd0; end
          else lp_cnt <= lp_cnt - 4'd1;
      endcase

      // command channel
      if (cke && !cs_n) begin
        if (!init_complete || ctrlupd_ack || phyupd_ack || lp_ack) ce = 3'd5;
        else if (!act_n) begin                                     // ACT
          if (open_b[bank]) ce = 3'd2;
          else if ($signed(cyc - pre_c[bank]) < TRP || $signed(cyc - ref_c) < TRFC) ce = 3'd1;
          else begin open_b[bank] <= 1'b1; row_q[bank] <= address; act_c[bank] <= cyc; end
        end else if (ras_n && !cas_n) begin                        // RD (we_n 1) / WR (we_n 0)
          if (!open_b[bank]) ce = 3'd2;
          else if ($signed(cyc - act_c[bank]) < TRCD) ce = 3'd1;
          else begin
            if (we_n) begin
              rx = rx | (8'hF << (RDEN - 1)); rsx = rsx | (8'h1 << (RDEN - 1));
              rbase_n <= f_idx(bank, row_q[bank], address[9:0]);
            end else begin
              wx = wx | (8'hF << (WRLAT - 1)); wsx = wsx | (8'h1 << (WRLAT - 1));
              wbase_n <= f_idx(bank, row_q[bank], address[9:0]);
            end
            if (address[10]) begin open_b[bank] <= 1'b0; pre_c[bank] <= cyc + BL; end   // auto-precharge
          end
        end else if (!ras_n && cas_n && !we_n) begin               // PRE / PREA
          if (address[10]) begin
            for (int i = 0; i < 8; i++) if (open_b[i] && $signed(cyc - act_c[i]) < TRAS) ce = 3'd1;
            if (ce == 3'd0)
              for (int i = 0; i < 8; i++) if (open_b[i]) begin open_b[i] <= 1'b0; pre_c[i] <= cyc; end
          end else if (open_b[bank]) begin
            if ($signed(cyc - act_c[bank]) < TRAS) ce = 3'd1;
            else begin open_b[bank] <= 1'b0; pre_c[bank] <= cyc; end
          end
        end else if (!ras_n && !cas_n && we_n) begin               // REF
          if (open_b != 8'h0) ce = 3'd2;
          else begin
            for (int i = 0; i < 8; i++) if ($signed(cyc - pre_c[i]) < TRP) ce = 3'd1;
            if ($signed(cyc - ref_c) < TRFC) ce = 3'd1;
            if (ce == 3'd0) ref_c <= cyc;
          end
        end
      end

      // write data: enable exactly in the window, data one cycle later
      if (wrdata_en != wexp[0]) de = 3'd3;
      wi = f_beat(wbase, wbeat);
      if (wexp[0]) begin
        if (wst[0]) begin wi = wbase_n; wbase <= wbase_n; wbeat <= 2'd1; end
        else wbeat <= wbeat + 2'd1;
      end
      wcap <= wrdata_en && wexp[0];
      wcap_i <= wi;
      if (wcap)
        mem[wcap_i] <= {wrdata_mask[3] ? mem[wcap_i][31:24] : wrdata[31:24],
                        wrdata_mask[2] ? mem[wcap_i][23:16] : wrdata[23:16],
                        wrdata_mask[1] ? mem[wcap_i][15:8]  : wrdata[15:8],
                        wrdata_mask[0] ? mem[wcap_i][7:0]   : wrdata[7:0]};

      // read data: enable exactly in the window, valid data registered four cycles later
      if (rddata_en != rexp[0] && de == 3'd0) de = 3'd4;
      ri = f_beat(rbase, rbeat);
      if (rexp[0]) begin
        if (rst_m[0]) begin ri = rbase_n; rbase <= rbase_n; rbeat <= 2'd1; end
        else rbeat <= rbeat + 2'd1;
      end
      vld_sr <= {vld_sr[2:0], rddata_en && rexp[0]};
      dat_sr[0] <= mem[ri];
      for (int i = 1; i < 4; i++) dat_sr[i] <= dat_sr[i - 1];
      rddata_valid <= vld_sr[3];
      rddata <= vld_sr[3] ? dat_sr[3] : 32'h0;

      wexp <= wx; wst <= wsx; rexp <= rx; rst_m <= rsx;
      if (e == 3'd0) e = ce;
      if (e == 3'd0) e = de;
      if (e != 3'd0) begin error <= 1'b1; error_info <= e; end
    end
  end
endmodule
`endif
