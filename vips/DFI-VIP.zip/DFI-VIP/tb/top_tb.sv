// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- DFI 5.0 (MC-PHY Interface) testbench top with a
// functional DDR PHY + DRAM DUT model

`ifndef DFI_TB_SV
`define DFI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import dfi_defs_pkg::*;
import dfi_pkg::*;
import dfi_test_pkg::*;

module top_tb;
  logic dfi_clk = 0;
  always #5ns dfi_clk = ~dfi_clk;

  dfi_if vif(dfi_clk);

  initial begin
    vif.dfi_reset_n = 0;
    vif.state       = IDLE;
    #100ns;
    vif.dfi_reset_n = 1;
  end

  dfi_dram_model #(.RL(DFI_RL)) dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual dfi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional DDR PHY + DRAM model: per-bank open-row tracking, tRCD/tRP
// cycle checks (dfi_error pulse + command dropped on violation), bank
// memory, and an RL-deep read pipeline returning dfi_rddata_valid.
// Commands are ignored while dfi_cke is low.
module dfi_dram_model #(parameter int unsigned RL = DFI_RL) (dfi_if vif);
  import dfi_defs_pkg::*;

  bit [31:0]   mem [bit [16:0]];            // bank+address keyed array
  bit          row_open  [DFI_BANKS];
  bit [13:0]   open_row  [DFI_BANKS];
  int unsigned act_cycle [DFI_BANKS];
  int unsigned pre_cycle;
  int unsigned cnt;
  bit          vld_sr  [RL];                // read-valid pipeline
  bit [31:0]   data_sr [RL];                // read-data pipeline

  function automatic bit [31:0] mem_read(input bit [2:0] b, input bit [13:0] a);
    bit [16:0] k = {b, a};
    return mem.exists(k) ? mem[k] : 32'h5A5A_0000;   // deterministic default
  endfunction

  always @(posedge vif.dfi_clk or negedge vif.dfi_reset_n) begin
    if (!vif.dfi_reset_n) begin
      cnt       <= 0;
      pre_cycle <= 32'hFFFF_F000;           // far in the past
      foreach (row_open[i])  row_open[i]  <= 1'b0;
      foreach (open_row[i])  open_row[i]  <= 14'h0;
      foreach (act_cycle[i]) act_cycle[i] <= 0;
      foreach (vld_sr[i])    vld_sr[i]    <= 1'b0;
      foreach (data_sr[i])   data_sr[i]   <= 32'h0;
      vif.dfi_rddata       <= 32'h0;
      vif.dfi_rddata_valid <= 1'b0;
      vif.dfi_error        <= 1'b0;
    end else begin
      cnt          <= cnt + 1;
      vif.dfi_error <= 1'b0;
      // read pipeline shift (RL stages)
      for (int i = RL - 1; i > 0; i--) begin
        vld_sr[i]  <= vld_sr[i-1];
        data_sr[i] <= data_sr[i-1];
      end
      vld_sr[0]            <= 1'b0;
      vif.dfi_rddata_valid <= vld_sr[RL-1];
      vif.dfi_rddata       <= data_sr[RL-1];

      if (vif.dfi_cke && !vif.dfi_cs_n) begin
        case (vif.dfi_cmd)
          DFI_CMD_ACT: begin
            if (cnt - pre_cycle < DFI_TRP) begin
              vif.dfi_error <= 1'b1;
              `uvm_warning("DUT", "ACT violates tRP")
            end else begin
              row_open[vif.dfi_bank]  <= 1'b1;
              open_row[vif.dfi_bank]  <= vif.dfi_address;
              act_cycle[vif.dfi_bank] <= cnt;
            end
          end
          DFI_CMD_RD: begin
            if (!row_open[vif.dfi_bank] || cnt - act_cycle[vif.dfi_bank] < DFI_TRCD) begin
              vif.dfi_error <= 1'b1;
              `uvm_warning("DUT", "RD violates tRCD or no open row")
            end else begin
              vld_sr[0]  <= 1'b1;
              data_sr[0] <= mem_read(vif.dfi_bank, vif.dfi_address);
            end
          end
          DFI_CMD_WR: begin
            if (!row_open[vif.dfi_bank] || cnt - act_cycle[vif.dfi_bank] < DFI_TRCD) begin
              vif.dfi_error <= 1'b1;
              `uvm_warning("DUT", "WR violates tRCD or no open row")
            end else begin
              mem[{vif.dfi_bank, vif.dfi_address}] = vif.dfi_wrdata;
              `uvm_info("DUT", $sformatf("WR bank=%0d addr=0x%04h data=0x%08h",
                        vif.dfi_bank, vif.dfi_address, vif.dfi_wrdata), UVM_HIGH)
            end
          end
          DFI_CMD_PRE: begin
            row_open[vif.dfi_bank] <= 1'b0;
            pre_cycle <= cnt;
          end
          DFI_CMD_REF: begin
            foreach (row_open[i]) row_open[i] <= 1'b0;
            pre_cycle <= cnt;
            `uvm_info("DUT", "refresh all banks", UVM_HIGH)
          end
          default: ;                       // NOP
        endcase
      end
    end
  end
endmodule
`endif
