// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_dfi_tb.sv -- self-checking functional test for the DFI DRAM model
// (dfi_dram_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py DFI-VIP
//
// Model contract (from tb/top_tb.sv and dfi_defs_pkg):
//   commands on dfi_cmd (ACT=1 RD=2 WR=3 PRE=4 REF=5) when cke=1 and cs_n=0;
//   ACT opens a row; RD/WR need an open row and tRCD=3 clocks since ACT;
//   ACT needs tRP=3 clocks since the last PRE/REF; a violation pulses
//   dfi_error for one clock and the command is dropped. Write data is taken
//   from dfi_wrdata at the command edge; read data appears with a one-clock
//   dfi_rddata_valid pulse RL=4 clocks after the command. Unwritten
//   locations read 0x5A5A_0000. Storage is keyed by {bank, column}: the row
//   address is not part of the key (model limitation, not tested here).

module func_dfi_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [2:0] NOP = 3'd0, ACT = 3'd1, RD = 3'd2, WR = 3'd3, PRE = 3'd4, REF = 3'd5;
  localparam int RL = 4;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [13:0] address = '0;
  logic [2:0]  bank = '0, cmd = NOP;
  logic        cs_n = 1'b1, cke = 1'b1;
  logic [31:0] wrdata = '0;
  wire  [31:0] rddata;
  wire         rddata_valid, dfi_error;

  always #5 clk = ~clk;

  dfi_dram_model u_dut (
    .vif_dfi_clk(clk), .vif_dfi_reset_n(rst_n), .vif_dfi_address(address),
    .vif_dfi_bank(bank), .vif_dfi_cs_n(cs_n), .vif_dfi_cke(cke),
    .vif_dfi_wrdata(wrdata), .vif_dfi_rddata(rddata),
    .vif_dfi_rddata_valid(rddata_valid), .vif_dfi_cmd(cmd), .vif_dfi_error(dfi_error)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // issue one command (sampled at P0); returns at N0 with err = dfi_error
  // as seen after the command edge
  bit err;
  task automatic issue(input [2:0] c, input [2:0] b, input [13:0] a,
                       input [31:0] d = '0, input bit sel = 1'b1);
    @(negedge clk);
    cmd = c; bank = b; address = a; wrdata = d; cs_n = !sel;
    @(posedge clk);
    @(negedge clk);
    err = dfi_error;
    cmd = NOP; cs_n = 1'b1;
  endtask

  task automatic idle(input int n);
    repeat (n) @(negedge clk);
  endtask

  // read: returns the data of the first rddata_valid pulse and the number of
  // clocks from the command edge to it (-1 if none within 2*RL)
  task automatic rd(input [2:0] b, input [13:0] col, output [31:0] d, output int lat,
                    output bit e);
    lat = -1; d = 'x;
    issue(RD, b, col);                    // at N0
    e = err;
    for (int k = 0; k <= 2 * RL; k++) begin     // at N(k)
      if (rddata_valid && lat < 0) begin lat = k; d = rddata; end
      @(negedge clk);
    end
  endtask

  logic [31:0] d;
  int          lat;
  bit          e;
  int          vcount;

  initial begin
    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    idle(4);

    // read with no open row
    rd(0, 14'h010, d, lat, e);
    chk(e === 1'b1, "RD to a closed bank raises dfi_error");
    chk(lat < 0, "RD to a closed bank returns no data");
    @(negedge clk);
    chk(dfi_error === 1'b0, "dfi_error is a single-clock pulse");

    // ACT, then RD/WR before tRCD
    issue(ACT, 0, 14'h0100);
    chk(err === 1'b0, "ACT accepted after reset");
    issue(WR, 0, 14'h010, 32'hBAD0_0001);   // 1 clock after ACT
    chk(err === 1'b1, "WR before tRCD raises dfi_error");
    idle(2);
    issue(WR, 0, 14'h010, 32'hCAFE_0010);
    chk(err === 1'b0, "WR after tRCD accepted");
    rd(0, 14'h010, d, lat, e);
    chk(!e && d === 32'hCAFE_0010, "read returns written data (early WR was dropped)");
    chk(lat == RL, "rddata_valid arrives RL clocks after RD");

    // unwritten column
    rd(0, 14'h011, d, lat, e);
    chk(d === 32'h5A5A_0000, "unwritten column returns the fill pattern");

    // back-to-back reads stay ordered, one valid per read
    issue(WR, 0, 14'h012, 32'h1111_2222);
    @(negedge clk); cmd = RD; bank = 0; address = 14'h010; cs_n = 1'b0;
    @(negedge clk); address = 14'h012;
    @(negedge clk); cmd = NOP; cs_n = 1'b1;
    vcount = 0;
    repeat (2 * RL) begin
      if (rddata_valid) begin
        vcount++;
        if (vcount == 1) chk(rddata === 32'hCAFE_0010, "pipelined read 1 data");
        if (vcount == 2) chk(rddata === 32'h1111_2222, "pipelined read 2 data in order");
      end
      @(negedge clk);
    end
    chk(vcount == 2, "two back-to-back reads give exactly two valid beats");

    // bank independence
    issue(ACT, 5, 14'h0100);
    idle(3);
    issue(WR, 5, 14'h010, 32'h5555_0010);
    rd(5, 14'h010, d, lat, e);
    chk(d === 32'h5555_0010, "bank 5 holds its own data");
    rd(0, 14'h010, d, lat, e);
    chk(d === 32'hCAFE_0010, "bank 0 unaffected by bank 5 write");

    // PRE closes only its bank; ACT before tRP is rejected
    issue(PRE, 0, '0);
    rd(0, 14'h010, d, lat, e);
    chk(e && lat < 0, "PRE closes the bank (RD rejected)");
    rd(5, 14'h010, d, lat, e);
    chk(!e && d === 32'h5555_0010, "PRE leaves other banks open");
    issue(PRE, 1, '0);
    issue(ACT, 0, 14'h0100);
    chk(err === 1'b1, "ACT before tRP raises dfi_error");
    idle(3);
    issue(ACT, 0, 14'h0100);
    chk(err === 1'b0, "ACT after tRP accepted");
    idle(3);
    rd(0, 14'h010, d, lat, e);
    chk(d === 32'hCAFE_0010, "data retained across PRE/ACT");

    // exact timing boundaries: consecutive issue() calls are 2 clocks apart
    issue(ACT, 6, 14'h0200);
    idle(1);
    issue(WR, 6, 14'h020, 32'h6666_0020);    // exactly tRCD = 3 clocks after ACT
    chk(err === 1'b0, "WR exactly tRCD after ACT accepted");
    issue(ACT, 7, 14'h0200);
    idle(1);
    rd(7, 14'h020, d, lat, e);              // exactly tRCD
    chk(!e && lat == RL, "RD exactly tRCD after ACT accepted");
    issue(PRE, 6, '0);
    idle(1);
    issue(ACT, 6, 14'h0200);                 // exactly tRP = 3 clocks after PRE
    chk(err === 1'b0, "ACT exactly tRP after PRE accepted");
    idle(3);
    rd(6, 14'h020, d, lat, e);
    chk(!e && d === 32'h6666_0020, "data written at the tRCD boundary reads back");

    // REF closes all banks
    issue(REF, 0, '0);
    rd(5, 14'h010, d, lat, e);
    chk(e && lat < 0, "REF closes all banks");

    // CKE low / CS_n high: command ignored
    idle(3);
    issue(ACT, 2, 14'h0001, '0, 1'b0);
    rd(2, 14'h000, d, lat, e);
    chk(e, "ACT with CS_n high is ignored");
    @(negedge clk); cke = 1'b0;
    issue(ACT, 2, 14'h0001);
    @(negedge clk); cke = 1'b1;
    idle(3);
    rd(2, 14'h000, d, lat, e);
    chk(e, "ACT with CKE low is ignored");

    // reset closes open rows
    issue(ACT, 3, 14'h0001);
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk); rst_n = 1'b1;
    chk(rddata_valid === 1'b0 && dfi_error === 1'b0, "outputs cleared by reset");
    begin
      bit spurious;
      spurious = 0;
      repeat (2 * RL) begin @(negedge clk); if (rddata_valid) spurious = 1; end
      chk(!spurious, "no read data valid from the read pipeline after reset");
    end
    idle(4);
    rd(3, 14'h000, d, lat, e);
    chk(e, "reset closes open rows");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
