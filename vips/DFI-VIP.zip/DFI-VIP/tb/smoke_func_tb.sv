// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (DFI DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened dfi_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic init_start = 1'b0, cke = 1'b1, cs_n = 1'b1, act_n = 1'b1, ras_n = 1'b1, cas_n = 1'b1, we_n = 1'b1;
  logic [4:0] frequency = '0;
  logic [2:0] bank = '0;
  logic [13:0] address = '0;
  logic wrdata_en = 1'b0, rddata_en = 1'b0, ctrlupd_req = 1'b0, phyupd_ack = 1'b0, lp_ctrl_req = 1'b0, tb_phyupd = 1'b0;
  logic [31:0] wrdata = '0;
  logic [3:0] wrdata_mask = '0, lp_wakeup = '0;
  wire init_complete, rddata_valid, ctrlupd_ack, phyupd_req, lp_ack, error;
  wire [4:0] freq;
  wire [31:0] rddata;
  wire [1:0] phyupd_type;
  wire [2:0] error_info;

  always #5 clk = ~clk;

  dfi_model u_dut (.clk(clk), .rst_n(rst_n), .init_start(init_start), .frequency(frequency), .cke(cke), .cs_n(cs_n),
                   .act_n(act_n), .ras_n(ras_n), .cas_n(cas_n), .we_n(we_n), .bank(bank), .address(address),
                   .wrdata_en(wrdata_en), .wrdata(wrdata), .wrdata_mask(wrdata_mask), .rddata_en(rddata_en),
                   .ctrlupd_req(ctrlupd_req), .phyupd_ack(phyupd_ack), .lp_ctrl_req(lp_ctrl_req), .lp_wakeup(lp_wakeup),
                   .tb_phyupd(tb_phyupd), .init_complete(init_complete), .freq(freq), .rddata(rddata),
                   .rddata_valid(rddata_valid), .ctrlupd_ack(ctrlupd_ack), .phyupd_req(phyupd_req),
                   .phyupd_type(phyupd_type), .lp_ack(lp_ack), .error(error), .error_info(error_info));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // error codes seen since the last clear (bit k: code k)
  logic [7:0] errs = '0;
  int nerr = 0;
  always @(negedge clk) if (error) begin errs = errs | (8'h1 << error_info); nerr++; end

  // read data returned since the last clear
  logic [31:0] rd [0:15];
  int nrd = 0, t_rd = -1, tcyc = 0;
  always @(posedge clk) tcyc++;
  always @(negedge clk) begin
    if (rddata_valid && nrd < 16) begin rd[nrd] = rddata; nrd++; if (t_rd < 0) t_rd = tcyc; end
  end

  // tasks return 1 ns after a falling edge, after the monitors above ran
  task automatic idle(input int n);
    repeat (n) @(negedge clk);
    #1;
  endtask

  // one command, sampled on the next rising edge; returns one cycle later
  int t_cmd;
  task automatic cmd(input logic [2:0] rcw, input logic an, input logic [2:0] b, input logic [13:0] a);
    @(negedge clk); cs_n = 0; act_n = an; {ras_n, cas_n, we_n} = rcw; bank = b; address = a; t_cmd = tcyc;
    @(negedge clk); cs_n = 1; act_n = 1; {ras_n, cas_n, we_n} = 3'b111;
    #1;
  endtask

  task automatic act(input logic [2:0] b, input logic [13:0] r); cmd(3'b111, 1'b0, b, r); endtask
  task automatic pre(input logic [2:0] b, input logic all); cmd(3'b010, 1'b1, b, all ? 14'h400 : 14'h0); endtask
  task automatic refr(); cmd(3'b001, 1'b1, 3'd0, 14'h0); endtask

  // WR / RD with the data enable at cycle lat after the command for n cycles
  logic [31:0] wd [0:7];
  logic [3:0]  wm [0:7];
  task automatic wr(input logic [2:0] b, input logic [9:0] c, input logic ap, input int lat, input int n);
    cmd(3'b100, 1'b1, b, {3'b0, ap, c});
    for (int k = 1; k < lat + n + 8; k++) begin
      wrdata_en = (k >= lat && k < lat + n);
      if (k - 1 >= lat && k - 1 < lat + n) begin wrdata = wd[k - 1 - lat]; wrdata_mask = wm[k - 1 - lat]; end
      else begin wrdata = '0; wrdata_mask = '0; end
      @(negedge clk);
    end
    wrdata_en = 0;
    #1;
  endtask
  task automatic rdc(input logic [2:0] b, input logic [9:0] c, input logic ap, input int lat, input int n);
    nrd = 0; t_rd = -1;
    cmd(3'b101, 1'b1, b, {3'b0, ap, c});
    for (int k = 1; k < lat + n + 10; k++) begin
      rddata_en = (k >= lat && k < lat + n);
      @(negedge clk);
    end
    rddata_en = 0;
    #1;
  endtask

  function automatic logic [31:0] pat(input logic [2:0] b, input logic [2:0] r, input logic [5:0] c);
    pat = 32'h5A5A_0000 | {b, r, c};
  endfunction

  int t0, k0;

  initial begin
    repeat (3) @(posedge clk);
    chk(!init_complete && !rddata_valid && !ctrlupd_ack && !phyupd_req && !lp_ack && !error && error_info == 3'd0 &&
        freq == 5'd0 && rddata == 32'h0 && phyupd_type == 2'd0, "outputs clear in reset");
    @(negedge clk); rst_n = 1;

    // before init
    errs = 0; act(3'd1, 14'h5); idle(1);
    chk(errs == 8'h20, $sformatf("command before init: busy error (%02h)", errs));
    // init at frequency 2
    @(negedge clk); init_start = 1; frequency = 5'd2; t0 = tcyc;
    while (!init_complete && tcyc - t0 < 40) @(negedge clk);
    chk(tcyc - t0 == 10, $sformatf("init complete 10 cycles after init start (%0d)", tcyc - t0));
    chk(freq == 5'd2, "frequency taken at init");
    @(negedge clk); init_start = 0; idle(2);

    // write, read back
    errs = 0;
    act(3'd0, 14'h10); idle(3);
    for (int i = 0; i < 4; i++) begin wd[i] = 32'h1111_0000 * (i + 1) + i; wm[i] = 4'h0; end
    wr(3'd0, 10'd0, 1'b0, 3, 4);
    rdc(3'd0, 10'd0, 1'b0, 3, 4);
    chk(errs == 8'h0, $sformatf("legal ACT / WR / RD: no error (%02h)", errs));
    chk(nrd == 4 && rd[0] == wd[0] && rd[1] == wd[1] && rd[2] == wd[2] && rd[3] == wd[3], "read returns the written burst");
    chk(t_rd - t_cmd == 8, $sformatf("first read beat 8 cycles after RD (%0d)", t_rd - t_cmd));
    rdc(3'd0, 10'd8, 1'b0, 3, 4);
    chk(nrd == 4 && rd[0] == pat(0, 0, 8) && rd[3] == pat(0, 0, 11), "unwritten columns read the default pattern");
    // byte masks and the column wrap inside the row
    for (int i = 0; i < 4; i++) begin wd[i] = 32'hA0B0_C0D0 + i; wm[i] = 4'h0; end
    wm[1] = 4'b0101;
    wr(3'd0, 10'd62, 1'b0, 3, 4);
    rdc(3'd0, 10'd62, 1'b0, 3, 4);
    chk(rd[0] == wd[0] && rd[1] == {wd[1][31:24], 8'h5A, wd[1][15:8], 8'h3F} && rd[2] == wd[2], "byte masks keep masked bytes");
    rdc(3'd0, 10'd0, 1'b0, 3, 4);
    chk(rd[0] == wd[2] && rd[1] == wd[3] && rd[2] == 32'h3333_0002, "burst wraps inside the 64-column row");
    // rows alias above bit 2
    act(3'd3, 14'h8); idle(3);
    rdc(3'd3, 10'd5, 1'b0, 3, 4);
    chk(errs == 8'h0 && rd[0] == pat(3, 0, 5), "row 8 reads the row-0 location");

    // timing boundaries: tRCD, tRAS, tRP, tRFC
    errs = 0; act(3'd1, 14'h1); idle(1); rdc(3'd1, 10'd0, 1'b0, 3, 4);
    chk(errs == 8'h12, $sformatf("RD 3 cycles after ACT: tRCD error, read enable error (%02h)", errs));
    errs = 0; act(3'd2, 14'h1); idle(2); rdc(3'd2, 10'd0, 1'b0, 3, 4);
    chk(errs == 8'h0 && nrd == 4, "RD 4 cycles after ACT accepted");
    errs = 0; act(3'd4, 14'h1); idle(5); pre(3'd4, 1'b0);
    chk(errs == 8'h02, $sformatf("PRE 7 cycles after ACT: tRAS error (%02h)", errs));
    errs = 0; pre(3'd4, 1'b0);
    chk(errs == 8'h0, "PRE 8 cycles after ACT accepted");
    errs = 0; idle(1); act(3'd4, 14'h2);
    chk(errs == 8'h02, $sformatf("ACT 3 cycles after PRE: tRP error (%02h)", errs));
    errs = 0; act(3'd4, 14'h2);
    chk(errs == 8'h0, "ACT 5 cycles after PRE accepted");
    pre(3'd3, 1'b0); idle(2); errs = 0; act(3'd3, 14'h8);
    chk(errs == 8'h0, "ACT 4 cycles after PRE accepted");
    // NOP and other commands (MRS) with cs_n low change nothing
    errs = 0; cmd(3'b111, 1'b1, 3'd3, 14'h0); cmd(3'b000, 1'b1, 3'd3, 14'h0); cmd(3'b110, 1'b1, 3'd3, 14'h0);
    idle(2); rdc(3'd3, 10'd5, 1'b0, 3, 4);
    chk(errs == 8'h0 && nrd == 4, "NOP / MRS / ZQ commands ignored, bank still open");
    // bank state
    errs = 0; act(3'd4, 14'h2);
    chk(errs == 8'h04, "ACT to an open bank: bank error");
    errs = 0; rdc(3'd5, 10'd0, 1'b0, 3, 4);
    chk(errs == 8'h14 && nrd == 0, $sformatf("RD to a closed bank: bank error, no data (%02h)", errs));
    errs = 0; refr();
    chk(errs == 8'h04, "REF with banks open: bank error");
    errs = 0; pre(3'd6, 1'b0);
    chk(errs == 8'h0, "PRE of a closed bank is a no-op");
    idle(8);
    errs = 0; act(3'd5, 14'h1); pre(3'd0, 1'b1);
    chk(errs == 8'h02, "PREA with a bank inside tRAS: timing error");
    idle(3); rdc(3'd0, 10'd0, 1'b0, 3, 4);
    chk(nrd == 4, "rejected PREA closes nothing");
    idle(4);
    errs = 0; pre(3'd0, 1'b1);
    chk(errs == 8'h0, "PREA closes all banks");
    errs = 0; rdc(3'd2, 10'd0, 1'b0, 3, 4);
    chk(errs == 8'h14, "bank closed by PREA");
    errs = 0; refr();
    chk(errs == 8'h0, "REF with all banks closed");
    idle(9); errs = 0; act(3'd0, 14'h1);
    chk(errs == 8'h02, "ACT 11 cycles after REF: tRFC error");
    errs = 0; act(3'd0, 14'h1);
    chk(errs == 8'h0, "ACT 12 cycles after REF accepted");
    idle(8); pre(3'd0, 1'b0); idle(1);
    errs = 0; refr();
    chk(errs == 8'h02, $sformatf("REF 3 cycles after PRE: tRP error (%02h)", errs));
    errs = 0; refr();
    chk(errs == 8'h0, "REF 5 cycles after PRE accepted");
    idle(8); errs = 0; refr();
    chk(errs == 8'h02, "REF 10 cycles after REF: tRFC error");
    errs = 0; refr();
    chk(errs == 8'h0, "REF 12 cycles after REF accepted");
    // auto-precharge
    idle(12); act(3'd1, 14'h3); idle(3);
    errs = 0; rdc(3'd1, 10'd0, 1'b1, 3, 4);
    chk(errs == 8'h0 && nrd == 4, "RD with auto-precharge");
    errs = 0; rdc(3'd1, 10'd0, 1'b0, 3, 4);
    chk(errs == 8'h14, "auto-precharge closed the bank");
    act(3'd1, 14'h3); idle(3);
    errs = 0; wr(3'd1, 10'd4, 1'b1, 3, 4); act(3'd1, 14'h3);
    chk(errs == 8'h0, "WR with auto-precharge, ACT after the burst and tRP");
    idle(3); pre(3'd1, 1'b0); idle(4);
    act(3'd1, 14'h3); idle(3);
    errs = 0; cmd(3'b100, 1'b1, 3'd1, 14'h400); act(3'd1, 14'h3);
    chk(errs == 8'h02, $sformatf("ACT right after WR with auto-precharge: tRP error (%02h)", errs));
    idle(12);
    // auto-precharge starts tRP after the burst: ACT 7 cycles after RD-AP is early, 8 is in time
    act(3'd1, 14'h3); idle(3);
    cmd(3'b101, 1'b1, 3'd1, 14'h400); idle(5); errs = 0; act(3'd1, 14'h3);
    chk(errs[2:1] == 2'b01, $sformatf("ACT 7 cycles after RD with auto-precharge: tRP error (%02h)", errs));
    idle(12); act(3'd1, 14'h3); idle(3);
    cmd(3'b101, 1'b1, 3'd1, 14'h400); idle(6); errs = 0; act(3'd1, 14'h3);
    chk(errs[2:1] == 2'b00, $sformatf("ACT 8 cycles after RD with auto-precharge accepted (%02h)", errs));
    idle(8); pre(3'd1, 1'b0); idle(12);

    // data enable windows
    act(3'd2, 14'h4); idle(3);
    for (int i = 0; i < 6; i++) begin wd[i] = 32'hC0DE_0000 + i; wm[i] = 4'h0; end
    errs = 0; wr(3'd2, 10'd0, 1'b0, 2, 4);
    chk(errs == 8'h08, "write enable one cycle early: wrdata error");
    rdc(3'd2, 10'd0, 1'b0, 3, 4);
    chk(rd[0] == wd[1] && rd[2] == wd[3] && rd[3] == pat(2, 4, 3), "early write: beats inside the window are written");
    errs = 0; wr(3'd2, 10'd8, 1'b0, 4, 4);
    chk(errs == 8'h08, "write enable one cycle late");
    errs = 0; wr(3'd2, 10'd8, 1'b0, 3, 3);
    chk(errs == 8'h08, "write burst one beat short");
    errs = 0; wr(3'd2, 10'd8, 1'b0, 3, 5);
    chk(errs == 8'h08, "write burst one beat long");
    errs = 0; rdc(3'd2, 10'd8, 1'b0, 2, 4);
    chk(errs == 8'h10 && nrd == 3, $sformatf("read enable one cycle early: rddata error, 3 beats (%0d)", nrd));
    errs = 0; rdc(3'd2, 10'd8, 1'b0, 4, 4);
    chk(errs == 8'h10 && nrd == 3, "read enable one cycle late: 3 beats");
    errs = 0; rdc(3'd2, 10'd8, 1'b0, 3, 5);
    chk(errs == 8'h10 && nrd == 4, "read enable one beat long: 4 beats");
    errs = 0; wr(3'd7, 10'd0, 1'b0, 3, 4);
    chk(errs == 8'h0C, "WR to a closed bank: bank and wrdata errors");
    // clock disabled: commands ignored
    cke = 0; errs = 0; act(3'd7, 14'h1); cke = 1; idle(4);
    rdc(3'd7, 10'd0, 1'b0, 3, 4);
    chk(errs == 8'h14, "ACT with cke low ignored");

    // controller update
    pre(3'd0, 1'b1); idle(4);
    @(negedge clk); ctrlupd_req = 1; @(negedge clk);
    chk(ctrlupd_ack, "ctrlupd_ack one cycle after the request");
    errs = 0; act(3'd0, 14'h1);
    chk(errs == 8'h20, "command during ctrlupd_ack: busy error");
    idle(1); ctrlupd_req = 0; idle(1);
    chk(!ctrlupd_ack && errs == 8'h20, "4-cycle update ends without a handshake error");
    for (int n = 3; n <= 25; n += 22) begin
      errs = 0; ctrlupd_req = 1; idle(n); ctrlupd_req = 0; idle(2);
      chk(errs == 8'h40, $sformatf("%0d-cycle update: handshake error", n));
      errs = 0; ctrlupd_req = 1; idle(n == 3 ? 4 : 24); ctrlupd_req = 0; idle(2);
      chk(errs == 8'h0, $sformatf("%0d-cycle update accepted", n == 3 ? 4 : 24));
    end

    // a very long update saturates the cycle counter: still one error at the end
    nerr = 0; errs = 0; ctrlupd_req = 1; idle(70); ctrlupd_req = 0; idle(2);
    chk(errs == 8'h40 && nerr == 1, $sformatf("70-cycle update: one handshake error (%0d)", nerr));

    // PHY update
    for (int k = 0; k < 3; k++) begin
      errs = 0;
      @(negedge clk); tb_phyupd = 1; @(negedge clk); tb_phyupd = 0;
      chk(phyupd_req && phyupd_type == k, $sformatf("PHY update request %0d with type %0d", k, phyupd_type));
      idle(11 + k); phyupd_ack = 1;
      @(negedge clk);
      t0 = tcyc; while (phyupd_req && tcyc - t0 < 20) @(negedge clk);
      chk(tcyc - t0 == 4, $sformatf("PHY update takes 4 cycles after the ack (%0d)", tcyc - t0));
      phyupd_ack = 0; idle(2);
      chk(errs == (k == 2 ? 8'h40 : 8'h0), $sformatf("ack %0d cycles after the request: %s", 12 + k, k == 2 ? "late" : "in time"));
    end
    // an ack 40 cycles late: one error
    nerr = 0; errs = 0;
    @(negedge clk); tb_phyupd = 1; @(negedge clk); tb_phyupd = 0;
    idle(40); phyupd_ack = 1; idle(6); phyupd_ack = 0; idle(2);
    chk(errs == 8'h40 && nerr == 1 && !phyupd_req, $sformatf("ack 40 cycles late: one handshake error (%0d)", nerr));
    errs = 0;
    @(negedge clk); tb_phyupd = 1; @(negedge clk); tb_phyupd = 0;
    idle(2); phyupd_ack = 1; @(negedge clk);
    errs = 0; act(3'd0, 14'h1);
    chk(errs == 8'h20, "command during phyupd_ack: busy error");
    phyupd_ack = 0; idle(2);
    chk(errs == 8'h60 && !phyupd_req, "ack dropped during the update: handshake error, request withdrawn");

    // low power
    lp_wakeup = 3; @(negedge clk); lp_ctrl_req = 1; idle(3);
    chk(!lp_ack, "no lp_ack before tlp_resp");
    @(negedge clk);
    chk(lp_ack, "lp_ack four cycles after the request");
    errs = 0; act(3'd0, 14'h1);
    chk(errs == 8'h20, "command during lp_ack: busy error");
    lp_ctrl_req = 0; t0 = tcyc;
    @(negedge clk); while (lp_ack && tcyc - t0 < 20) @(negedge clk);
    chk(tcyc - t0 == 4, $sformatf("lp_ack drops lp_wakeup + 1 cycles after the request (%0d)", tcyc - t0));
    lp_wakeup = 0; lp_ctrl_req = 1; idle(8); lp_ctrl_req = 0; idle(2);
    chk(!lp_ack, "lp_wakeup 0: request declined");
    lp_wakeup = 2; lp_ctrl_req = 1; idle(3); lp_ctrl_req = 0; idle(6);
    chk(!lp_ack, "request withdrawn before the ack: no ack");
    lp_ctrl_req = 1; idle(5); lp_ctrl_req = 0; @(negedge clk);
    chk(lp_ack, "ack held while waking up");
    idle(2);
    chk(!lp_ack, "lp_wakeup 2: ack dropped 3 cycles after the request");

    // frequency change
    act(3'd6, 14'h1); idle(2);
    errs = 0; @(negedge clk); init_start = 1; frequency = 5'd1; @(negedge clk);
    chk(!init_complete, "frequency change: init_complete drops");
    while (!init_complete) @(negedge clk);
    @(negedge clk); init_start = 0;
    chk(errs == 8'h04 && freq == 5'd1, "frequency change with a bank open: bank error, new frequency");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
