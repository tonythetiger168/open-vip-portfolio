// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_env.sv -- DFI environment: reference-model scoreboard, checker, coverage

package dfi_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import dfi_defs_pkg::*;
  import dfi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class dfi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(dfi_scoreboard)
    uvm_analysis_imp_exp #(dfi_transaction, dfi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(dfi_transaction, dfi_scoreboard) obs_ap;

    dfi_config cfg;
    dfi_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [31:0] mem [bit [11:0]];
    bit       open_b [8];
    bit [13:0] row_q [8];
    int       act_c [8] = '{default: 0};
    int       pre_c [8] = '{default: -1000};
    int       ref_c = -1000;
    bit       init_done = 0;
    bit [1:0] pu_type = 0;

    function bit [31:0] rd_mem(bit [11:0] i);
      return mem.exists(i) ? mem[i] : (32'h5A5A_0000 | i);
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(dfi_config)::get(this, "", "cfg", cfg))
        cfg = dfi_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(dfi_transaction t);
      int c = t.cyc;
      bit [2:0] ce = 0;
      bit acc = 0;
      t.err = 0; t.rdata.delete(); t.acked = 0; t.ptype = 0; t.freq_o = 0; t.lat_o = 0;
      case (t.kind)
        K_INIT: begin
          if (open_b.or() != 0) t.err[DFI_E_BANK] = 1;
          init_done = 1; t.acked = 1; t.freq_o = t.fsel; t.lat_o = DFI_TINIT;
        end
        K_CTRLUPD: begin
          t.acked = 1;
          if (t.len < DFI_TCTRLUPD_MIN || t.len > DFI_TCTRLUPD_MAX) t.err[DFI_E_HSHAKE] = 1;
          if (t.intrude) t.err[DFI_E_BUSY] = 1;
        end
        K_PHYUPD: begin
          t.ptype = pu_type; pu_type++;
          if (t.resp >= DFI_TPHYUPD_RESP || t.early) t.err[DFI_E_HSHAKE] = 1;
        end
        K_LP: begin
          t.acked = (t.wakeup != 0) && (t.len > DFI_TLP_RESP);
          if (t.acked) t.lat_o = t.wakeup + 1;
          if (t.intrude && t.acked) t.err[DFI_E_BUSY] = 1;
        end
        default: begin
          if (!init_done) ce = DFI_E_BUSY;
          else case (t.kind)
            K_ACT:
              if (open_b[t.bank]) ce = DFI_E_BANK;
              else if (c - pre_c[t.bank] < DFI_TRP || c - ref_c < DFI_TRFC) ce = DFI_E_TIMING;
              else begin open_b[t.bank] = 1; row_q[t.bank] = t.row; act_c[t.bank] = c; end
            K_RD, K_WR:
              if (!open_b[t.bank]) ce = DFI_E_BANK;
              else if (c - act_c[t.bank] < DFI_TRCD) ce = DFI_E_TIMING;
              else acc = 1;
            K_PRE:
              if (open_b[t.bank]) begin
                if (c - act_c[t.bank] < DFI_TRAS) ce = DFI_E_TIMING;
                else begin open_b[t.bank] = 0; pre_c[t.bank] = c; end
              end
            K_PREA: begin
              foreach (open_b[i]) if (open_b[i] && c - act_c[i] < DFI_TRAS) ce = DFI_E_TIMING;
              if (ce == 0) foreach (open_b[i]) if (open_b[i]) begin open_b[i] = 0; pre_c[i] = c; end
            end
            default:                                       // REF
              if (open_b.or() != 0) ce = DFI_E_BANK;
              else begin
                foreach (pre_c[i]) if (c - pre_c[i] < DFI_TRP) ce = DFI_E_TIMING;
                if (c - ref_c < DFI_TRFC) ce = DFI_E_TIMING;
                if (ce == 0) ref_c = c;
              end
          endcase
          if (ce != 0) t.err[ce] = 1;
          if (t.kind inside {K_RD, K_WR}) begin
            int nom = (t.kind == K_WR) ? DFI_TPHY_WRLAT : DFI_TRDDATA_EN;
            bit [11:0] base = dfi_idx(t.bank, row_q[t.bank], t.col);
            if (acc ? (t.lat != nom || t.beats != DFI_BL) : (t.beats != 0))
              t.err[(t.kind == K_WR) ? DFI_E_WRDATA : DFI_E_RDDATA] = 1;
            if (acc) begin
              // beats inside the expected window move data
              for (int j = 0; j < t.beats; j++) begin
                int k = t.lat + j - nom;
                if (k >= 0 && k < DFI_BL) begin
                  bit [11:0] i = dfi_beat(base, k);
                  if (t.kind == K_WR) mem[i] = dfi_merge(rd_mem(i), t.wdata[j], t.wmask[j]);
                  else t.rdata.push_back(rd_mem(i));
                end
              end
              if (t.ap) begin open_b[t.bank] = 0; pre_c[t.bank] = c + DFI_BL; end
            end
          end
        end
      endcase
    endfunction

    function void write_exp(dfi_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(dfi_transaction t);
      dfi_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        dfi_transaction e = exp_q.pop_front();
        dfi_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("dfi scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class dfi_env extends uvm_env;
    `uvm_component_utils(dfi_env)
    dfi_agent      agt;
    dfi_scoreboard sb;
    dfi_checker    chk;
    dfi_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = dfi_agent     ::type_id::create("agt", this);
      sb  = dfi_scoreboard::type_id::create("sb",  this);
      chk = dfi_checker   ::type_id::create("chk", this);
      cov = dfi_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
