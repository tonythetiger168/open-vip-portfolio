// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_pkg.sv -- DFI 5.0 (MC-PHY Interface) UVM VIP package

package dfi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import dfi_defs_pkg::*;
  export dfi_defs_pkg::*;

  `include "dfi_transaction.svh"
  `include "dfi_config.svh"
  `include "dfi_sequencer.svh"
  `include "dfi_driver.svh"
  `include "dfi_monitor.svh"
  `include "dfi_agent.svh"
  `include "dfi_sequences.svh"
  `include "dfi_checker.svh"
  `include "dfi_coverage.svh"
endpackage
