// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_transaction.svh -- DFI transaction: one DRAM operation scheduled by
// the MC (read / write / refresh) with ACT + data phase + PRE.

class dfi_transaction extends uvm_sequence_item;

  // Error-injection knobs (timing modelled in dfi_clk cycles)
  typedef enum bit [1:0] {
    DFI_ERR_NONE,  // legal schedule
    DFI_ERR_TRCD,  // RD/WR issued before tRCD after ACT
    DFI_ERR_TRP    // ACT issued before tRP after PRE
  } dfi_err_e;

  rand bit [1:0]  cmd;           // DFI_OP_READ / DFI_OP_WRITE / DFI_OP_REF
  rand bit [13:0] addr;          // row (ACT) / column (RD/WR) address
  rand bit [2:0]  bank;
  rand bit [31:0] wdata;
  rand dfi_err_e  error_inject;

  // Observed by monitor / driver (not randomized)
  bit [31:0] rdata;              // read data returned with dfi_rddata_valid
  bit        timing_violation;   // PHY flagged a tRCD/tRP violation

  constraint c_cmd { cmd inside {dfi_defs_pkg::DFI_OP_READ,
                                 dfi_defs_pkg::DFI_OP_WRITE,
                                 dfi_defs_pkg::DFI_OP_REF};
                     cmd dist {dfi_defs_pkg::DFI_OP_READ  := 4,
                               dfi_defs_pkg::DFI_OP_WRITE := 4,
                               dfi_defs_pkg::DFI_OP_REF   := 1}; }
  constraint c_err { error_inject dist {DFI_ERR_NONE := 8,
                                        DFI_ERR_TRCD := 1,
                                        DFI_ERR_TRP  := 1}; }

  `uvm_object_utils_begin(dfi_transaction)
    `uvm_field_int(cmd, UVM_ALL_ON)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_int(bank, UVM_ALL_ON)
    `uvm_field_int(wdata, UVM_ALL_ON)
    `uvm_field_enum(dfi_err_e, error_inject, UVM_ALL_ON)
    `uvm_field_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(timing_violation, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "dfi_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    dfi_transaction t;
    bit ok = 1;
    ok &= super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    ok &= comparer.compare_field("cmd", cmd, t.cmd, 2);
    ok &= comparer.compare_field("addr", addr, t.addr, 14);
    ok &= comparer.compare_field("bank", bank, t.bank, 3);
    if (cmd == dfi_defs_pkg::DFI_OP_WRITE)
      ok &= comparer.compare_field("wdata", wdata, t.wdata, 32);
    return ok;
  endfunction

  function string convert2string();
    string op;
    case (cmd)
      dfi_defs_pkg::DFI_OP_READ:  op = "RD";
      dfi_defs_pkg::DFI_OP_WRITE: op = "WR";
      default:                    op = "REF";
    endcase
    return $sformatf("DFI %s bank=%0d addr=0x%04h wdata=0x%08h rdata=0x%08h err=%s%s",
                     op, bank, addr, wdata, rdata, error_inject.name(),
                     timing_violation ? " TIMING_VIOL" : "");
  endfunction
endclass
