// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_transaction.svh -- DFI transaction

class dfi_transaction extends uvm_sequence_item;
  `uvm_object_utils(dfi_transaction)

  // request (driven by the agent)
  rand dfi_kind_e kind;
  rand bit [2:0] bank;
  rand bit [13:0] row;
  rand bit [9:0] col;
  rand bit ap;
  rand bit [3:0] lat;
  rand bit [3:0] beats;
  bit [31:0] wdata[$];
  bit [3:0] wmask[$];
  rand bit [4:0] fsel;
  rand bit [5:0] len;
  rand bit [3:0] wakeup;
  rand bit [4:0] resp;
  rand bit early;
  rand bit intrude;
  // response (returned by the DUT)
  bit [7:0] err;
  bit [31:0] rdata[$];
  bit acked;
  bit [1:0] ptype;
  bit [4:0] freq_o;
  bit [5:0] lat_o;
  // bookkeeping (not compared)
  rand bit [3:0] gap;
  rand bit [31:0] seed;
  int unsigned cyc;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { kind dist { K_ACT := 5, K_RD := 4, K_WR := 4, K_PRE := 3, K_PREA := 1, K_REF := 1,
                                  K_CTRLUPD := 1, K_PHYUPD := 1, K_LP := 1, K_INIT := 1 }; }
  constraint c_addr { bank dist { [0:1] := 3, [2:7] := 1 }; row[13:3] dist { 0 := 3, [1:2047] := 1 };
                      col[9:6] dist { 0 := 3, [1:15] := 1 }; ap dist { 0 := 3, 1 := 1 }; }
  // RD and WR share the nominal latency (DFI_TPHY_WRLAT == DFI_TRDDATA_EN)
  constraint c_data { lat dist { 3 := 12, 2 := 1, 4 := 1 }; beats dist { 4 := 12, 3 := 1, 5 := 1 }; }
  constraint c_hs   { len inside {[1:30]}; len dist { [DFI_TCTRLUPD_MIN:DFI_TCTRLUPD_MAX] := 8, [1:3] := 1, [25:30] := 1 };
                      resp dist { [0:DFI_TPHYUPD_RESP - 1] := 8, [DFI_TPHYUPD_RESP:20] := 1 };
                      early dist { 0 := 8, 1 := 1 }; intrude dist { 0 := 6, 1 := 1 };
                      intrude -> (len >= 8 && wakeup != 0); fsel inside {[0:3]}; }
  constraint c_gap  { gap dist { 0 := 1, [1:3] := 2, [4:9] := 4 }; }

  function new(string name = "dfi_transaction"); super.new(name); endfunction

  // clear the fields the kind does not use and build the write data
  function void post_randomize();
    bit [31:0] x = seed | 1;
    if (kind != K_ACT) row = 0;
    if (!(kind inside {K_RD, K_WR})) begin col = 0; ap = 0; lat = 0; beats = 0; end
    if (kind inside {K_PREA, K_REF, K_INIT, K_CTRLUPD, K_PHYUPD, K_LP}) bank = 0;
    if (kind != K_INIT) fsel = 0;
    if (!(kind inside {K_CTRLUPD, K_LP})) begin len = 0; intrude = 0; end
    if (kind != K_LP) wakeup = 0;
    if (kind != K_PHYUPD) begin resp = 0; early = 0; end
    wdata.delete(); wmask.delete();
    if (kind == K_WR)
      for (int i = 0; i < beats; i++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        wdata.push_back(x);
        wmask.push_back((x[31:28] == 4'hF) ? x[3:0] : 4'h0);
      end
  endfunction

  function void do_copy(uvm_object rhs);
    dfi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    kind = rhs_.kind;
    bank = rhs_.bank;
    row = rhs_.row;
    col = rhs_.col;
    ap = rhs_.ap;
    lat = rhs_.lat;
    beats = rhs_.beats;
    wdata = rhs_.wdata;
    wmask = rhs_.wmask;
    fsel = rhs_.fsel;
    len = rhs_.len;
    wakeup = rhs_.wakeup;
    resp = rhs_.resp;
    early = rhs_.early;
    intrude = rhs_.intrude;
    err = rhs_.err;
    rdata = rhs_.rdata;
    acked = rhs_.acked;
    ptype = rhs_.ptype;
    freq_o = rhs_.freq_o;
    lat_o = rhs_.lat_o;
    gap = rhs_.gap;
    seed = rhs_.seed;
    cyc = rhs_.cyc;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    dfi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (kind != rhs_.kind) return 0;
    if (bank != rhs_.bank) return 0;
    if (row != rhs_.row) return 0;
    if (col != rhs_.col) return 0;
    if (ap != rhs_.ap) return 0;
    if (lat != rhs_.lat) return 0;
    if (beats != rhs_.beats) return 0;
    if (wdata.size() != rhs_.wdata.size()) return 0;
    foreach (wdata[i]) if (wdata[i] != rhs_.wdata[i]) return 0;
    if (wmask.size() != rhs_.wmask.size()) return 0;
    foreach (wmask[i]) if (wmask[i] != rhs_.wmask[i]) return 0;
    if (fsel != rhs_.fsel) return 0;
    if (len != rhs_.len) return 0;
    if (wakeup != rhs_.wakeup) return 0;
    if (resp != rhs_.resp) return 0;
    if (early != rhs_.early) return 0;
    if (intrude != rhs_.intrude) return 0;
    if (err != rhs_.err) return 0;
    if (rdata.size() != rhs_.rdata.size()) return 0;
    foreach (rdata[i]) if (rdata[i] != rhs_.rdata[i]) return 0;
    if (acked != rhs_.acked) return 0;
    if (ptype != rhs_.ptype) return 0;
    if (freq_o != rhs_.freq_o) return 0;
    if (lat_o != rhs_.lat_o) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(dfi_transaction rhs_);
    if (kind != rhs_.kind) return 0;
    if (bank != rhs_.bank) return 0;
    if (row != rhs_.row) return 0;
    if (col != rhs_.col) return 0;
    if (ap != rhs_.ap) return 0;
    if (lat != rhs_.lat) return 0;
    if (beats != rhs_.beats) return 0;
    if (wdata.size() != rhs_.wdata.size()) return 0;
    foreach (wdata[i]) if (wdata[i] != rhs_.wdata[i]) return 0;
    if (wmask.size() != rhs_.wmask.size()) return 0;
    foreach (wmask[i]) if (wmask[i] != rhs_.wmask[i]) return 0;
    if (fsel != rhs_.fsel) return 0;
    if (len != rhs_.len) return 0;
    if (wakeup != rhs_.wakeup) return 0;
    if (resp != rhs_.resp) return 0;
    if (early != rhs_.early) return 0;
    if (intrude != rhs_.intrude) return 0;
    return 1;
  endfunction

  function string qstr_wdata();
    string s = $sformatf("[%0d]{", wdata.size());
    foreach (wdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", wdata[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_wmask();
    string s = $sformatf("[%0d]{", wmask.size());
    foreach (wmask[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", wmask[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rdata();
    string s = $sformatf("[%0d]{", rdata.size());
    foreach (rdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rdata[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("DFI{tag=%0d kind=0x%0h bank=0x%0h row=0x%0h col=0x%0h ap=0x%0h lat=0x%0h beats=0x%0h wdata=%s wmask=%s fsel=0x%0h len=0x%0h wakeup=0x%0h resp=0x%0h early=0x%0h intrude=0x%0h err=0x%0h rdata=%s acked=0x%0h ptype=0x%0h freq_o=0x%0h lat_o=0x%0h}", tag, kind, bank, row, col, ap, lat, beats, qstr_wdata(), qstr_wmask(), fsel, len, wakeup, resp, early, intrude, err, qstr_rdata(), acked, ptype, freq_o, lat_o);
  endfunction
endclass
