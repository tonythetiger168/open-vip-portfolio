// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_if.sv -- DFI 5.0 (MC-PHY Interface) interface
//
// MC (memory controller) drives the command channel (dfi_cmd/dfi_address/
// dfi_bank/dfi_cs_n/dfi_cke) and dfi_wrdata; the PHY returns dfi_rddata
// with dfi_rddata_valid after the programmed read latency. dfi_error is
// a PHY-side timing/protocol violation flag.

interface dfi_if (input logic dfi_clk);
  import dfi_defs_pkg::dfi_state_e;

  logic        dfi_reset_n;
  logic [13:0] dfi_address;
  logic [2:0]  dfi_bank;
  logic        dfi_cs_n;
  logic        dfi_cke;
  logic [31:0] dfi_wrdata;
  logic [31:0] dfi_rddata;
  logic        dfi_rddata_valid;
  logic [2:0]  dfi_cmd;      // ACT/RD/WR/PRE/REF/NOP encoding (see dfi_defs_pkg)
  logic        dfi_error;    // PHY timing/protocol violation pulse

  dfi_state_e state;         // MC command-scheduler phase marker

  modport MC  (input  dfi_clk, dfi_reset_n, dfi_rddata, dfi_rddata_valid, dfi_error,
               output dfi_cmd, dfi_address, dfi_bank, dfi_cs_n, dfi_cke,
               dfi_wrdata, state);
  modport PHY (input  dfi_clk, dfi_reset_n, dfi_cmd, dfi_address, dfi_bank,
               dfi_cs_n, dfi_cke, dfi_wrdata,
               output dfi_rddata, dfi_rddata_valid, dfi_error);
  modport MON (input  dfi_clk, dfi_reset_n, dfi_cmd, dfi_address, dfi_bank,
               dfi_cs_n, dfi_cke, dfi_wrdata, dfi_rddata, dfi_rddata_valid,
               dfi_error, state);

  clocking drv_cb @(posedge dfi_clk);
    input  dfi_reset_n, dfi_rddata, dfi_rddata_valid, dfi_error;
    output dfi_cmd, dfi_address, dfi_bank, dfi_cs_n, dfi_cke, dfi_wrdata;
  endclocking

  clocking mon_cb @(posedge dfi_clk);
    input dfi_reset_n, dfi_cmd, dfi_address, dfi_bank, dfi_cs_n, dfi_cke,
          dfi_wrdata, dfi_rddata, dfi_rddata_valid, dfi_error, state;
  endclocking
endinterface
