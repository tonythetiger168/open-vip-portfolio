// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_if.sv -- DFI interface

interface dfi_if (input logic clk);
  logic rst_n;

  logic init_start;
  logic [4:0] frequency;
  logic cke;
  logic cs_n;
  logic act_n;
  logic ras_n;
  logic cas_n;
  logic we_n;
  logic [2:0] bank;
  logic [13:0] address;
  logic wrdata_en;
  logic [31:0] wrdata;
  logic [3:0] wrdata_mask;
  logic rddata_en;
  logic ctrlupd_req;
  logic phyupd_ack;
  logic lp_ctrl_req;
  logic [3:0] lp_wakeup;
  logic tb_phyupd;
  logic init_complete;
  logic [4:0] freq;
  logic [31:0] rddata;
  logic rddata_valid;
  logic ctrlupd_ack;
  logic phyupd_req;
  logic [1:0] phyupd_type;
  logic lp_ack;
  logic error;
  logic [2:0] error_info;

  modport DUT (input clk, rst_n, input init_start, input frequency, input cke, input cs_n, input act_n, input ras_n, input cas_n, input we_n, input bank, input address, input wrdata_en, input wrdata, input wrdata_mask, input rddata_en, input ctrlupd_req, input phyupd_ack, input lp_ctrl_req, input lp_wakeup, input tb_phyupd, output init_complete, output freq, output rddata, output rddata_valid, output ctrlupd_ack, output phyupd_req, output phyupd_type, output lp_ack, output error, output error_info);
  modport MON (input clk, rst_n, init_start, frequency, cke, cs_n, act_n, ras_n, cas_n, we_n, bank, address, wrdata_en, wrdata, wrdata_mask, rddata_en, ctrlupd_req, phyupd_ack, lp_ctrl_req, lp_wakeup, tb_phyupd, init_complete, freq, rddata, rddata_valid, ctrlupd_ack, phyupd_req, phyupd_type, lp_ack, error, error_info);

  clocking drv_cb @(posedge clk);
    input rst_n, init_complete, freq, rddata, rddata_valid, ctrlupd_ack, phyupd_req, phyupd_type, lp_ack, error, error_info;
    inout init_start, frequency, cke, cs_n, act_n, ras_n, cas_n, we_n, bank, address, wrdata_en, wrdata, wrdata_mask, rddata_en, ctrlupd_req, phyupd_ack, lp_ctrl_req, lp_wakeup, tb_phyupd;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, init_start, frequency, cke, cs_n, act_n, ras_n, cas_n, we_n, bank, address, wrdata_en, wrdata, wrdata_mask, rddata_en, ctrlupd_req, phyupd_ack, lp_ctrl_req, lp_wakeup, tb_phyupd, init_complete, freq, rddata, rddata_valid, ctrlupd_ack, phyupd_req, phyupd_type, lp_ack, error, error_info;
  endclocking
endinterface
