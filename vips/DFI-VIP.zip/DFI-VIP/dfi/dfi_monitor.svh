// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_monitor.svh -- DFI monitor: decodes the MC command channel
// (dfi_cmd/address/bank/wrdata), captures dfi_rddata on dfi_rddata_valid,
// tracks PHY timing-violation pulses, and publishes one transaction per
// DRAM operation (RD/WR published at PRE, REF published immediately).

class dfi_monitor extends uvm_monitor;
  `uvm_component_utils(dfi_monitor)
  virtual dfi_if vif;
  uvm_analysis_port #(dfi_transaction) ap;
  int unsigned txn_count = 0;

  protected dfi_transaction cur;
  protected bit          pending = 0;
  protected bit          rd_wait = 0;
  protected int unsigned rd_timeout = 0;
  protected bit          trp_pending = 0;   // dfi_error pulse before RD/WR decode

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual dfi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "dfi virtual interface not set")
  endfunction

  function void new_txn();
    cur = dfi_transaction::type_id::create("cur");
    pending = 1;
  endfunction

  function void publish();
    if (!pending) return;
    if (cur.timing_violation) begin
      // error_inject classification is refined by the scoreboard fields
    end else cur.error_inject = dfi_transaction::DFI_ERR_NONE;
    txn_count++;
    `uvm_info("MON", {"mon: ", cur.convert2string()}, UVM_HIGH)
    ap.write(cur);
    pending = 0;
  endfunction

  task run_phase(uvm_phase phase);
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.dfi_reset_n !== 1'b1) begin
        pending = 0; rd_wait = 0; trp_pending = 0;
        continue;
      end

      // PHY timing-violation pulse -> mark the in-flight transaction;
      // a pulse before any RD/WR decode belongs to the ACT phase (tRP)
      if (vif.mon_cb.dfi_error === 1'b1) begin
        if (pending) begin
          cur.timing_violation = 1;
          cur.error_inject     = dfi_transaction::DFI_ERR_TRCD;
        end else trp_pending = 1;
      end

      // Read data return (RL after RD)
      if (rd_wait) begin
        if (vif.mon_cb.dfi_rddata_valid === 1'b1) begin
          cur.rdata = vif.mon_cb.dfi_rddata;
          rd_wait = 0;
        end else if (rd_timeout++ > dfi_defs_pkg::DFI_RL + 4)
          rd_wait = 0;                 // e.g. RD dropped after timing violation
      end

      if (vif.mon_cb.dfi_cke === 1'b1) begin
        case (vif.mon_cb.dfi_cmd)
          dfi_defs_pkg::DFI_CMD_RD: begin
            new_txn();
            cur.cmd  = dfi_defs_pkg::DFI_OP_READ;
            cur.bank = vif.mon_cb.dfi_bank;
            cur.addr = vif.mon_cb.dfi_address;
            rd_wait    = 1;
            rd_timeout = 0;
          end
          dfi_defs_pkg::DFI_CMD_WR: begin
            new_txn();
            cur.cmd   = dfi_defs_pkg::DFI_OP_WRITE;
            cur.bank  = vif.mon_cb.dfi_bank;
            cur.addr  = vif.mon_cb.dfi_address;
            cur.wdata = vif.mon_cb.dfi_wrdata;
          end
          dfi_defs_pkg::DFI_CMD_PRE: publish();   // RD/WR operation complete
          dfi_defs_pkg::DFI_CMD_REF: begin
            new_txn();
            cur.cmd  = dfi_defs_pkg::DFI_OP_REF;
            cur.bank = vif.mon_cb.dfi_bank;
            cur.addr = vif.mon_cb.dfi_address;
            publish();
          end
          default: ;                               // NOP / ACT
        endcase
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("dfi monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
