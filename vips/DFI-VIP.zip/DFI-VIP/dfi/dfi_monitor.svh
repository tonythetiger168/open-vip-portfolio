// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_monitor.svh -- DFI monitor: commands with their data windows and the handshakes, with the error codes seen while each item is active

class dfi_monitor extends uvm_monitor;
  `uvm_component_utils(dfi_monitor)

  virtual dfi_if vif;
  uvm_analysis_port #(dfi_transaction) ap;
  dfi_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual dfi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "dfi: virtual interface not set")
    if (!uvm_config_db#(dfi_config)::get(this, "", "cfg", cfg))
      cfg = dfi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      dfi_transaction cur;
      int unsigned cyc = 0, age = 0, r_cyc = 0, f_cyc = 0;
      bit done = 0, wen_q = 0, is_q = 0, cu_q = 0, lp_q = 0, tbp_q = 0, req_seen = 0, ack_seen = 0, req_low = 0;
      forever begin
        bit cmd, in_win, start;
        @(vif.mon_cb);
        if (vif.mon_cb.rst_n !== 1'b1) begin cur = null; cyc = 0; continue; end
        cyc++;
        cmd = vif.mon_cb.cke && !vif.mon_cb.cs_n;
        in_win = cur != null && (cur.kind inside {K_CTRLUPD, K_LP}) && !done;
        // 1. the current item: errors, data, handshake progress
        if (cur != null) begin
          age++;
          if (vif.mon_cb.error) cur.err |= 8'h1 << vif.mon_cb.error_info;
          if (done) begin publish(cur); cur = null; end
        end
        if (cur != null) begin
          case (cur.kind)
            K_WR: begin
              if (vif.mon_cb.wrdata_en) begin if (cur.beats == 0) cur.lat = cyc - cur.cyc; cur.beats++; end
              if (wen_q) begin cur.wdata.push_back(vif.mon_cb.wrdata); cur.wmask.push_back(vif.mon_cb.wrdata_mask); end
              if (age >= 18) done = 1;
            end
            K_RD: begin
              if (vif.mon_cb.rddata_en) begin if (cur.beats == 0) cur.lat = cyc - cur.cyc; cur.beats++; end
              if (vif.mon_cb.rddata_valid) cur.rdata.push_back(vif.mon_cb.rddata);
              if (age >= 18) done = 1;
            end
            K_INIT: begin
              if (vif.mon_cb.init_complete && !cur.acked) begin cur.acked = 1; cur.lat_o = cyc - cur.cyc; end
              cur.freq_o = vif.mon_cb.freq;
              if (!vif.mon_cb.init_start) done = 1;
            end
            K_CTRLUPD: begin
              if (vif.mon_cb.ctrlupd_ack) cur.acked = 1;
              if (vif.mon_cb.ctrlupd_req) begin cur.len++; if (cmd) cur.intrude = 1; end
              else done = 1;
            end
            K_PHYUPD: begin
              if (vif.mon_cb.phyupd_req && !req_seen) begin req_seen = 1; r_cyc = cyc; cur.ptype = vif.mon_cb.phyupd_type; end
              if (vif.mon_cb.phyupd_ack && !ack_seen) begin ack_seen = 1; cur.resp = cyc - r_cyc - 1; end
              if (ack_seen && !vif.mon_cb.phyupd_ack && vif.mon_cb.phyupd_req) cur.early = 1;
              if (req_seen && !vif.mon_cb.phyupd_req && !vif.mon_cb.phyupd_ack) done = 1;
              if (age >= 64) done = 1;
            end
            K_LP: begin
              if (vif.mon_cb.lp_ack) cur.acked = 1;
              if (vif.mon_cb.lp_ctrl_req && !req_low) begin cur.len++; if (cmd) cur.intrude = 1; end
              else if (!req_low) begin req_low = 1; f_cyc = cyc; end
              if (req_low && !vif.mon_cb.lp_ack) begin
                if (cur.acked) cur.lat_o = cyc - f_cyc;
                done = 1;
              end
            end
            default: if (age >= 2) done = 1;
          endcase
        end
        // 2. a new item starts
        start = (cmd && !in_win) || (vif.mon_cb.init_start && !is_q) || (vif.mon_cb.ctrlupd_req && !cu_q) ||
                (vif.mon_cb.lp_ctrl_req && !lp_q) || (vif.mon_cb.tb_phyupd && !tbp_q);
        if (start) begin
          if (cur != null) publish(cur);
          cur = dfi_transaction::type_id::create("t");
          cur.cyc = cyc; age = 0; done = 0; req_seen = 0; ack_seen = 0; req_low = 0;
          if (cmd && !in_win) begin
            bit [2:0] rcw = {vif.mon_cb.ras_n, vif.mon_cb.cas_n, vif.mon_cb.we_n};
            cur.bank = vif.mon_cb.bank;
            if (!vif.mon_cb.act_n) begin cur.kind = K_ACT; cur.row = vif.mon_cb.address; end
            else if (rcw == 3'b101 || rcw == 3'b100) begin
              cur.kind = (rcw == 3'b101) ? K_RD : K_WR;
              cur.col = vif.mon_cb.address[9:0]; cur.ap = vif.mon_cb.address[10];
            end else if (rcw == 3'b010) begin
              cur.kind = vif.mon_cb.address[10] ? K_PREA : K_PRE;
              if (cur.kind == K_PREA) cur.bank = 0;
            end else begin cur.kind = K_REF; cur.bank = 0; end
          end else if (vif.mon_cb.init_start && !is_q) begin cur.kind = K_INIT; cur.fsel = vif.mon_cb.frequency; end
          else if (vif.mon_cb.ctrlupd_req && !cu_q) begin cur.kind = K_CTRLUPD; cur.len = 1; end
          else if (vif.mon_cb.lp_ctrl_req && !lp_q) begin cur.kind = K_LP; cur.len = 1; cur.wakeup = vif.mon_cb.lp_wakeup; end
          else cur.kind = K_PHYUPD;
        end
        wen_q = vif.mon_cb.wrdata_en;
        is_q = vif.mon_cb.init_start; cu_q = vif.mon_cb.ctrlupd_req; lp_q = vif.mon_cb.lp_ctrl_req;
        tbp_q = vif.mon_cb.tb_phyupd;
      end
    end
  endtask

  function void publish(dfi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
