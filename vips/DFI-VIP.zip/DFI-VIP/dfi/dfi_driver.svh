// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_driver.svh -- DFI driver: idle cycles, then one command with its data window, or one handshake

class dfi_driver extends uvm_driver #(dfi_transaction);
  `uvm_component_utils(dfi_driver)

  uvm_analysis_port #(dfi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual dfi_if vif;
  dfi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual dfi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "dfi: virtual interface not set")
    if (!uvm_config_db#(dfi_config)::get(this, "", "cfg", cfg))
      cfg = dfi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    dfi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.init_start <= 1'b0; vif.drv_cb.frequency <= '0; vif.drv_cb.cke <= 1'b1;
    vif.drv_cb.cs_n <= 1'b1; vif.drv_cb.act_n <= 1'b1; vif.drv_cb.ras_n <= 1'b1; vif.drv_cb.cas_n <= 1'b1;
    vif.drv_cb.we_n <= 1'b1; vif.drv_cb.bank <= '0; vif.drv_cb.address <= '0;
    vif.drv_cb.wrdata_en <= 1'b0; vif.drv_cb.wrdata <= '0; vif.drv_cb.wrdata_mask <= '0; vif.drv_cb.rddata_en <= 1'b0;
    vif.drv_cb.ctrlupd_req <= 1'b0; vif.drv_cb.phyupd_ack <= 1'b0; vif.drv_cb.lp_ctrl_req <= 1'b0;
    vif.drv_cb.lp_wakeup <= '0; vif.drv_cb.tb_phyupd <= 1'b0;
  endtask

  task drive_item(dfi_transaction t);
    repeat (t.gap) @(vif.drv_cb);
    case (t.kind)
      K_INIT: begin
        int unsigned w = 0;
        vif.drv_cb.init_start <= 1'b1; vif.drv_cb.frequency <= t.fsel;
        repeat (2) @(vif.drv_cb);          // a frequency change drops init_complete first
        while (vif.drv_cb.init_complete !== 1'b1 && w < 64) begin @(vif.drv_cb); w++; end
        @(vif.drv_cb);
        vif.drv_cb.init_start <= 1'b0;
        @(vif.drv_cb);
      end
      K_CTRLUPD: begin
        for (int i = 0; i < t.len; i++) begin
          vif.drv_cb.ctrlupd_req <= 1'b1;
          if (t.intrude && i == 2) command(3'b001, 1'b1, 3'd0, 14'h0);
          @(vif.drv_cb);
          nop();
        end
        vif.drv_cb.ctrlupd_req <= 1'b0;
        repeat (2) @(vif.drv_cb);
      end
      K_PHYUPD: begin
        int unsigned w = 0;
        vif.drv_cb.tb_phyupd <= 1'b1; @(vif.drv_cb); vif.drv_cb.tb_phyupd <= 1'b0;
        while (vif.drv_cb.phyupd_req !== 1'b1 && w < 16) begin @(vif.drv_cb); w++; end
        repeat (t.resp) @(vif.drv_cb);
        vif.drv_cb.phyupd_ack <= 1'b1;
        @(vif.drv_cb);
        if (t.early) begin vif.drv_cb.phyupd_ack <= 1'b0; @(vif.drv_cb); end
        w = 0;
        while (vif.drv_cb.phyupd_req !== 1'b0 && w < 32) begin @(vif.drv_cb); w++; end
        vif.drv_cb.phyupd_ack <= 1'b0;
        repeat (2) @(vif.drv_cb);
      end
      K_LP: begin
        int unsigned w = 0;
        bit done = 0;
        vif.drv_cb.lp_wakeup <= t.wakeup;
        for (int i = 0; i < t.len; i++) begin
          vif.drv_cb.lp_ctrl_req <= 1'b1;
          if (t.intrude && !done && i < t.len - 1 && vif.drv_cb.lp_ack === 1'b1) begin
            command(3'b001, 1'b1, 3'd0, 14'h0); done = 1;
          end
          @(vif.drv_cb);
          nop();
        end
        vif.drv_cb.lp_ctrl_req <= 1'b0;
        @(vif.drv_cb);
        while (vif.drv_cb.lp_ack !== 1'b0 && w < 32) begin @(vif.drv_cb); w++; end
        @(vif.drv_cb);
      end
      default: begin
        bit [13:0] a;
        case (t.kind)
          K_ACT:  begin a = t.row; end
          K_RD, K_WR: a = {3'b0, t.ap, t.col};
          K_PREA: a = 14'h400;
          default: a = 14'h0;
        endcase
        case (t.kind)
          K_ACT:  command(3'b111, 1'b0, t.bank, a);
          K_RD:   command(3'b101, 1'b1, t.bank, a);
          K_WR:   command(3'b100, 1'b1, t.bank, a);
          K_PRE, K_PREA: command(3'b010, 1'b1, t.bank, a);
          default: command(3'b001, 1'b1, t.bank, a);   // REF
        endcase
        // cycle i after the command: data enable at lat .. lat + beats - 1,
        // write data one cycle after each enable
        if (t.kind inside {K_RD, K_WR}) begin
          for (int i = 0; i < t.lat + t.beats + 1 + cfg.tail_cycles; i++) begin
            @(vif.drv_cb);
            if (i == 0) nop();
            if (t.kind == K_WR) begin
              vif.drv_cb.wrdata_en <= (i + 1 >= t.lat && i + 1 < t.lat + t.beats);
              if (i >= t.lat && i < t.lat + t.beats) begin
                vif.drv_cb.wrdata <= t.wdata[i - t.lat]; vif.drv_cb.wrdata_mask <= t.wmask[i - t.lat];
              end else begin
                vif.drv_cb.wrdata <= '0; vif.drv_cb.wrdata_mask <= '0;
              end
            end else
              vif.drv_cb.rddata_en <= (i + 1 >= t.lat && i + 1 < t.lat + t.beats);
          end
        end else begin
          @(vif.drv_cb);
          nop();
        end
      end
    endcase
  endtask

  // drive one command for the next clock (ras_n cas_n we_n, act_n)
  task command(bit [2:0] rcw, bit act_n, bit [2:0] b, bit [13:0] a);
    vif.drv_cb.cs_n <= 1'b0; vif.drv_cb.act_n <= act_n;
    vif.drv_cb.ras_n <= rcw[2]; vif.drv_cb.cas_n <= rcw[1]; vif.drv_cb.we_n <= rcw[0];
    vif.drv_cb.bank <= b; vif.drv_cb.address <= a;
  endtask

  task nop();
    vif.drv_cb.cs_n <= 1'b1; vif.drv_cb.act_n <= 1'b1;
    vif.drv_cb.ras_n <= 1'b1; vif.drv_cb.cas_n <= 1'b1; vif.drv_cb.we_n <= 1'b1;
  endtask
endclass
