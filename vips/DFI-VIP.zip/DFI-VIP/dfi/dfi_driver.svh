// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_driver.svh -- DFI memory-controller driver. Schedules DRAM commands
// on the dfi_cmd channel with modelled tRCD/tRP timing (cycle counted),
// captures dfi_rddata after the programmed read latency, auto-issues
// periodic refresh (tREFI), supports tRCD/tRP violation injection and
// publishes expected transactions on drv_ap.

class dfi_driver extends uvm_driver #(dfi_transaction);
  `uvm_component_utils(dfi_driver)
  virtual dfi_if vif;
  dfi_config cfg;
  uvm_analysis_port #(dfi_transaction) drv_ap;  // expected items for scoreboard

  protected int unsigned cyc      = 0;   // driver cycle counter
  protected int unsigned last_pre = 0;   // cycle of last PRE issue
  protected int unsigned last_ref = 0;   // cycle of last REF issue

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual dfi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "dfi virtual interface not set")
  endfunction

  // ---------------- cycle-accurate command channel ----------------
  task automatic tick();
    @(vif.drv_cb);
    cyc++;
  endtask

  task automatic drive_nop();
    vif.drv_cb.dfi_cmd <= dfi_defs_pkg::DFI_CMD_NOP;
    tick();
  endtask

  // Issue one command (visible to the PHY for exactly one cycle)
  task automatic issue(input bit [2:0] c, input bit [2:0] b,
                       input bit [13:0] a, input bit [31:0] d = 32'h0);
    vif.drv_cb.dfi_cmd     <= c;
    vif.drv_cb.dfi_bank    <= b;
    vif.drv_cb.dfi_address <= a;
    vif.drv_cb.dfi_wrdata  <= d;
    tick();
    vif.drv_cb.dfi_cmd     <= dfi_defs_pkg::DFI_CMD_NOP;
  endtask

  // PHY reacts one cycle after the command; dfi_error is visible one
  // cycle after that -> sample two cycles post-issue.
  task automatic check_error(output bit viol);
    tick();
    tick();
    viol = (vif.drv_cb.dfi_error === 1'b1);
  endtask

  // ---------------- operation flows ----------------
  task automatic do_write(dfi_transaction tr);
    int gap = (tr.error_inject == dfi_transaction::DFI_ERR_TRP) ? 1 : dfi_defs_pkg::DFI_TRP;
    bit viol;
    while (cyc - last_pre < gap) drive_nop();
    vif.state = dfi_defs_pkg::ACTIVATE;
    issue(dfi_defs_pkg::DFI_CMD_ACT, tr.bank, tr.addr);
    if (tr.error_inject == dfi_transaction::DFI_ERR_TRP) begin
      check_error(viol);
      tr.timing_violation = viol;
      if (viol) `uvm_warning("DRV", "tRP violation flagged by PHY (error injection)")
    end else repeat (dfi_defs_pkg::DFI_TRCD - 1) drive_nop();
    vif.state = dfi_defs_pkg::READ;                       // pass-through phase
    if (tr.error_inject == dfi_transaction::DFI_ERR_TRCD) begin
      issue(dfi_defs_pkg::DFI_CMD_WR, tr.bank, tr.addr, tr.wdata);  // too early
      check_error(viol);
      tr.timing_violation = viol;
      if (viol) `uvm_warning("DRV", "tRCD violation flagged by PHY (error injection)")
    end else repeat (2) drive_nop();
    vif.state = dfi_defs_pkg::WRITE;
    if (tr.error_inject == dfi_transaction::DFI_ERR_TRCD) repeat (2) drive_nop();
    else begin
      issue(dfi_defs_pkg::DFI_CMD_WR, tr.bank, tr.addr, tr.wdata);
      check_error(viol);
      tr.timing_violation = viol;
    end
    vif.state = dfi_defs_pkg::PRECHARGE;
    issue(dfi_defs_pkg::DFI_CMD_PRE, tr.bank, tr.addr);
    last_pre = cyc;
    drive_nop();
    vif.state = dfi_defs_pkg::REFRESH;                    // pass-through phase
    repeat (2) drive_nop();
  endtask

  task automatic do_read(dfi_transaction tr);
    int gap = (tr.error_inject == dfi_transaction::DFI_ERR_TRP) ? 1 : dfi_defs_pkg::DFI_TRP;
    bit viol;
    int unsigned to;
    while (cyc - last_pre < gap) drive_nop();
    vif.state = dfi_defs_pkg::ACTIVATE;
    issue(dfi_defs_pkg::DFI_CMD_ACT, tr.bank, tr.addr);
    if (tr.error_inject == dfi_transaction::DFI_ERR_TRP) begin
      check_error(viol);
      tr.timing_violation = viol;
      if (viol) `uvm_warning("DRV", "tRP violation flagged by PHY (error injection)")
    end else repeat (dfi_defs_pkg::DFI_TRCD - 1) drive_nop();
    vif.state = dfi_defs_pkg::READ;
    if (tr.error_inject == dfi_transaction::DFI_ERR_TRCD) begin
      issue(dfi_defs_pkg::DFI_CMD_RD, tr.bank, tr.addr);  // too early
      check_error(viol);
      tr.timing_violation = viol;
      if (viol) `uvm_warning("DRV", "tRCD violation flagged by PHY (error injection)")
    end else begin
      issue(dfi_defs_pkg::DFI_CMD_RD, tr.bank, tr.addr);
      check_error(viol);
      tr.timing_violation = viol;
    end
    // capture read data when the PHY raises dfi_rddata_valid (RL latency)
    to = 0;
    while (vif.drv_cb.dfi_rddata_valid !== 1'b1 && to < dfi_defs_pkg::DFI_RL + 4) begin
      tick();
      to++;
    end
    if (vif.drv_cb.dfi_rddata_valid === 1'b1) tr.rdata = vif.drv_cb.dfi_rddata;
    vif.state = dfi_defs_pkg::WRITE;                      // pass-through phase
    repeat (2) drive_nop();
    vif.state = dfi_defs_pkg::PRECHARGE;
    issue(dfi_defs_pkg::DFI_CMD_PRE, tr.bank, tr.addr);
    last_pre = cyc;
    drive_nop();
    vif.state = dfi_defs_pkg::REFRESH;                    // pass-through phase
    repeat (2) drive_nop();
  endtask

  task automatic do_refresh(dfi_transaction tr);
    vif.state = dfi_defs_pkg::ACTIVATE;                   // pass-through phases
    repeat (2) drive_nop();
    vif.state = dfi_defs_pkg::READ;
    repeat (2) drive_nop();
    vif.state = dfi_defs_pkg::WRITE;
    repeat (2) drive_nop();
    vif.state = dfi_defs_pkg::PRECHARGE;
    issue(dfi_defs_pkg::DFI_CMD_PRE, tr.bank, tr.addr);
    last_pre = cyc;
    drive_nop();
    vif.state = dfi_defs_pkg::REFRESH;
    issue(dfi_defs_pkg::DFI_CMD_REF, tr.bank, tr.addr);
    last_ref = cyc;
    repeat (2) drive_nop();
  endtask

  task run_phase(uvm_phase phase);
    dfi_transaction tr;
    vif.drv_cb.dfi_cmd     <= dfi_defs_pkg::DFI_CMD_NOP;
    vif.drv_cb.dfi_cs_n    <= 1'b0;
    vif.drv_cb.dfi_cke     <= 1'b0;
    vif.drv_cb.dfi_address <= 14'h0;
    vif.drv_cb.dfi_bank    <= 3'h0;
    vif.drv_cb.dfi_wrdata  <= 32'h0;
    vif.state = dfi_defs_pkg::IDLE;
    wait (vif.dfi_reset_n === 1'b1);
    repeat (4) tick();
    vif.drv_cb.dfi_cke <= 1'b1;
    repeat (2) tick();
    last_pre = cyc;
    last_ref = cyc;
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      // MC refresh logic: auto-refresh when tREFI expires
      if (cyc - last_ref > dfi_defs_pkg::DFI_REFI) begin
        dfi_transaction ref_tr = dfi_transaction::type_id::create("ref_tr");
        void'(ref_tr.randomize() with { cmd == dfi_defs_pkg::DFI_OP_REF;
                                        error_inject == DFI_ERR_NONE; });
        do_refresh(ref_tr);
        vif.state = dfi_defs_pkg::IDLE;
        drv_ap.write(ref_tr);
      end
      case (tr.cmd)
        dfi_defs_pkg::DFI_OP_READ:  do_read(tr);
        dfi_defs_pkg::DFI_OP_WRITE: do_write(tr);
        default:                    do_refresh(tr);
      endcase
      vif.state = dfi_defs_pkg::IDLE;
      repeat (2) drive_nop();
      drv_ap.write(tr);                      // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask

endclass
