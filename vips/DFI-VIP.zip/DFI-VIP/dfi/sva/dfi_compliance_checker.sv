// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_compliance_checker.sv -- DFI concurrent assertion checks (bindable)

module dfi_compliance_checker
  (input logic clk, input logic rst_n, input logic init_start, input logic [4:0] frequency, input logic cke, input logic cs_n, input logic act_n, input logic ras_n, input logic cas_n, input logic we_n, input logic [2:0] bank, input logic [13:0] address, input logic wrdata_en, input logic [31:0] wrdata, input logic [3:0] wrdata_mask, input logic rddata_en, input logic ctrlupd_req, input logic phyupd_ack, input logic lp_ctrl_req, input logic [3:0] lp_wakeup, input logic tb_phyupd, input logic init_complete, input logic [4:0] freq, input logic [31:0] rddata, input logic rddata_valid, input logic ctrlupd_ack, input logic phyupd_req, input logic [1:0] phyupd_type, input logic lp_ack, input logic error, input logic [2:0] error_info);

  // outputs never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n)
                   !$isunknown({init_complete, rddata_valid, ctrlupd_ack, phyupd_req, lp_ack, error, error_info}))
    else $error("DFI: X on outputs");
  // an error always carries a code
  assert property (@(posedge clk) disable iff (!rst_n) error |-> error_info != 3'd0)
    else $error("DFI: dfi_error without dfi_error_info");
  // init completes only while the controller requests it
  assert property (@(posedge clk) disable iff (!rst_n) $rose(init_complete) |-> init_start)
    else $error("DFI: dfi_init_complete without dfi_init_start");
  // the PHY acks a controller update only while it is requested
  assert property (@(posedge clk) disable iff (!rst_n) ctrlupd_ack |-> $past(ctrlupd_req))
    else $error("DFI: dfi_ctrlupd_ack without a request");
  // low-power ack only after a request
  assert property (@(posedge clk) disable iff (!rst_n) $rose(lp_ack) |-> lp_ctrl_req)
    else $error("DFI: dfi_lp_ack without dfi_lp_ctrl_req");
  // the controller acks a PHY update only while it is requested
  assert property (@(posedge clk) disable iff (!rst_n) $rose(phyupd_ack) |-> phyupd_req)
    else $error("DFI: dfi_phyupd_ack without dfi_phyupd_req");
  // a command while an update or low-power ack is high is flagged
  assert property (@(posedge clk) disable iff (!rst_n)
                   cke && !cs_n && (ctrlupd_ack || phyupd_ack || lp_ack) |=> error && error_info == 3'd5)
    else $error("DFI: command during an update / low power not flagged");
  cover property (@(posedge clk) disable iff (!rst_n) rddata_valid);
  cover property (@(posedge clk) disable iff (!rst_n) error && error_info == 3'd1);
  cover property (@(posedge clk) disable iff (!rst_n) $fell(lp_ack));
endmodule
