// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_compliance_checker.sv -- DFI 5.0 (MC-PHY Interface) SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = DFI/DRAM specific rules

`ifndef DFI_COMPLIANCE_CHECKER_SV
`define DFI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import dfi_defs_pkg::dfi_state_e;
import dfi_defs_pkg::DFI_CMD_NOP;
import dfi_defs_pkg::DFI_CMD_ACT;
import dfi_defs_pkg::DFI_CMD_RD;
import dfi_defs_pkg::DFI_CMD_WR;
import dfi_defs_pkg::DFI_CMD_PRE;
import dfi_defs_pkg::DFI_CMD_REF;
import dfi_defs_pkg::DFI_TRCD;
import dfi_defs_pkg::DFI_TRP;
import dfi_defs_pkg::DFI_RL;
import dfi_defs_pkg::DFI_REFI_MAX;
import dfi_defs_pkg::*;   // enum literals (IDLE, ACTIVATE, READ, WRITE, PRECHARGE, REFRESH)

module dfi_compliance_checker
(
  input logic dfi_clk,
  input logic dfi_reset_n,
  input dfi_state_e state,
  input logic [2:0] dfi_cmd,
  input logic dfi_cke,
  input logic dfi_rddata_valid
);

  // ---------------- L1: signal sanity (4) ----------------
  a_dfi_l1_clk   : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n) !$isunknown(dfi_clk))
    else `uvm_error("SVA_L1", "dfi: clock unknown")
  a_dfi_l1_rst   : assert property (@(posedge dfi_clk) !$isunknown(dfi_reset_n))
    else `uvm_error("SVA_L1", "dfi: reset unknown")
  a_dfi_l1_state : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "dfi: state unknown")
  a_dfi_l1_valid : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state inside {IDLE, ACTIVATE, READ, WRITE, PRECHARGE, REFRESH})
    else `uvm_error("SVA_L1", "dfi: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from IDLE
  a_dfi_trans_idle : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == IDLE |=> state inside {IDLE, ACTIVATE})
    else `uvm_error("SVA_L2", "dfi: illegal transition from IDLE")

  // L2-2: legal FSM transition from ACTIVATE
  a_dfi_trans_activate : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == ACTIVATE |=> state inside {ACTIVATE, READ})
    else `uvm_error("SVA_L2", "dfi: illegal transition from ACTIVATE")

  // L2-3: legal FSM transition from READ
  a_dfi_trans_read : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == READ |=> state inside {READ, WRITE})
    else `uvm_error("SVA_L2", "dfi: illegal transition from READ")

  // L2-4: legal FSM transition from WRITE
  a_dfi_trans_write : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == WRITE |=> state inside {WRITE, PRECHARGE})
    else `uvm_error("SVA_L2", "dfi: illegal transition from WRITE")

  // L2-5: legal FSM transition from PRECHARGE
  a_dfi_trans_precharge : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == PRECHARGE |=> state inside {PRECHARGE, REFRESH})
    else `uvm_error("SVA_L2", "dfi: illegal transition from PRECHARGE")

  // L2-6: legal FSM transition from REFRESH
  a_dfi_trans_refresh : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == REFRESH |=> state inside {REFRESH, IDLE})
    else `uvm_error("SVA_L2", "dfi: illegal transition from REFRESH")

  // ---------------- L3: protocol rules (4) ----------------
  a_dfi_l3_reset_idle : assert property (@(posedge dfi_clk)
    $fell(dfi_reset_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "dfi: state not IDLE during reset")
  a_dfi_l3_no_stuck   : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == REFRESH |-> ##[1:8] (state != REFRESH))
    else `uvm_error("SVA_L3", "dfi: stuck in REFRESH")
  a_dfi_l3_full_cycle : cover property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == IDLE ##1 state == ACTIVATE);
  a_dfi_l3_back_idle  : cover property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    state == REFRESH ##1 state == IDLE);

  // ---------------- L4: DFI/DRAM specific rules (5) ----------------
  // Cycles since the last REF command (for refresh periodicity check)
  int unsigned since_ref;
  always @(posedge dfi_clk or negedge dfi_reset_n) begin
    if (!dfi_reset_n)              since_ref <= 0;
    else if (dfi_cmd == DFI_CMD_REF) since_ref <= 0;
    else                           since_ref <= since_ref + 1;
  end

  // L4-1: after ACT, no RD/WR may follow within tRCD cycles
  a_dfi_l4_trcd : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    dfi_cmd == DFI_CMD_ACT |=> !(dfi_cmd inside {DFI_CMD_RD, DFI_CMD_WR})[* (DFI_TRCD-1)])
    else `uvm_error("SVA_L4", "dfi: RD/WR issued before tRCD after ACT")

  // L4-2: read data valid must follow a read command within the RL window
  a_dfi_l4_rl_valid : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    dfi_cmd == DFI_CMD_RD |-> ##[DFI_RL:DFI_RL+2] dfi_rddata_valid)
    else `uvm_error("SVA_L4", "dfi: dfi_rddata_valid not returned within RL window")

  // L4-3: refresh must occur periodically (bounded gap between REFs)
  a_dfi_l4_ref_periodic : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    since_ref < DFI_REFI_MAX)
    else `uvm_error("SVA_L4", "dfi: refresh periodicity violated")

  // L4-4: no command may be issued while CKE is low
  a_dfi_l4_cke : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    !dfi_cke |-> dfi_cmd == DFI_CMD_NOP)
    else `uvm_error("SVA_L4", "dfi: command issued while CKE low")

  // L4-5: after PRE, no ACT may follow within tRP cycles
  a_dfi_l4_trp : assert property (@(posedge dfi_clk) disable iff (!dfi_reset_n)
    dfi_cmd == DFI_CMD_PRE |=> !(dfi_cmd == DFI_CMD_ACT)[* (DFI_TRP-1)])
    else `uvm_error("SVA_L4", "dfi: ACT issued before tRP after PRE")

endmodule
`endif
