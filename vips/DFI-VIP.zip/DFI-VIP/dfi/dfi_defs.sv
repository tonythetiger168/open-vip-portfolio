// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_defs.sv -- DFI 5.0 (MC-PHY Interface) shared type definitions

package dfi_defs_pkg;
  typedef enum bit [2:0] {
    IDLE,
    ACTIVATE,
    READ,
    WRITE,
    PRECHARGE,
    REFRESH
  } dfi_state_e;

  // ---- dfi_cmd bus encodings (MC -> PHY command channel) ----
  localparam bit [2:0] DFI_CMD_NOP = 3'd0;
  localparam bit [2:0] DFI_CMD_ACT = 3'd1;  // bank activate (dfi_address = row)
  localparam bit [2:0] DFI_CMD_RD  = 3'd2;  // read  (dfi_address = column)
  localparam bit [2:0] DFI_CMD_WR  = 3'd3;  // write (dfi_address = column)
  localparam bit [2:0] DFI_CMD_PRE = 3'd4;  // precharge bank
  localparam bit [2:0] DFI_CMD_REF = 3'd5;  // refresh

  // ---- transaction operation codes ----
  localparam bit [1:0] DFI_OP_READ  = 2'd0;
  localparam bit [1:0] DFI_OP_WRITE = 2'd1;
  localparam bit [1:0] DFI_OP_REF   = 2'd2;

  // ---- timing model (in dfi_clk cycles) ----
  localparam int unsigned DFI_TRCD     = 3;    // ACT -> RD/WR
  localparam int unsigned DFI_TRP      = 3;    // PRE -> ACT
  localparam int unsigned DFI_RL       = 4;    // read latency to dfi_rddata_valid
  localparam int unsigned DFI_TRFC     = 4;    // refresh cycle time
  localparam int unsigned DFI_REFI     = 256;  // MC auto-refresh threshold
  localparam int unsigned DFI_REFI_MAX = 512;  // refresh periodicity bound (SVA)
  localparam int unsigned DFI_BANKS    = 8;
endpackage
