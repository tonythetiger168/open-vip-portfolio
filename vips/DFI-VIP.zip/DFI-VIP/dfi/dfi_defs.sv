// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_defs.sv -- DFI shared type definitions

package dfi_defs_pkg;

  typedef enum bit [1:0] {DFI_OK, DFI_ERR} dfi_status_e;

  localparam int DFI_BL           = 4;    // data cycles per RD / WR (BL8)
  localparam int DFI_TPHY_WRLAT   = 3;    // WR to dfi_wrdata_en
  localparam int DFI_TPHY_WRDATA  = 1;    // dfi_wrdata_en to dfi_wrdata
  localparam int DFI_TRDDATA_EN   = 3;    // RD to dfi_rddata_en
  localparam int DFI_TRCD = 4, DFI_TRP = 4, DFI_TRAS = 8, DFI_TRFC = 12;
  localparam int DFI_TINIT        = 10;   // dfi_init_start to dfi_init_complete
  localparam int DFI_TCTRLUPD_MIN = 4, DFI_TCTRLUPD_MAX = 24;
  localparam int DFI_TPHYUPD_RESP = 12;   // the controller must ack a PHY update within this
  localparam int DFI_TLP_RESP     = 3;

  typedef enum bit [3:0] {K_INIT, K_ACT, K_RD, K_WR, K_PRE, K_PREA, K_REF, K_CTRLUPD, K_PHYUPD, K_LP} dfi_kind_e;

  // dfi_error_info codes
  localparam bit [2:0] DFI_E_TIMING = 3'd1, DFI_E_BANK = 3'd2, DFI_E_WRDATA = 3'd3,
                       DFI_E_RDDATA = 3'd4, DFI_E_BUSY = 3'd5, DFI_E_HSHAKE = 3'd6;

  // DUT model memory index: bank, row[2:0], column[5:0]
  function automatic bit [11:0] dfi_idx(bit [2:0] b, bit [13:0] r, bit [9:0] c);
    return {b, r[2:0], c[5:0]};
  endfunction

  function automatic bit [11:0] dfi_beat(bit [11:0] base, int unsigned k);
    bit [5:0] c = base[5:0] + k;
    return {base[11:6], c};
  endfunction

  function automatic bit [31:0] dfi_merge(bit [31:0] old, bit [31:0] d, bit [3:0] m);
    for (int i = 0; i < 4; i++) if (!m[i]) old[8*i +: 8] = d[8*i +: 8];
    return old;
  endfunction

endpackage
