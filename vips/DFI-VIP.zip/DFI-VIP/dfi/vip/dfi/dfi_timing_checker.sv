// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_timing_checker.sv -- DFI 5.0 (MC-PHY Interface) timing parameter checker

`ifndef DFI_TIMING_CHECKER_SV
`define DFI_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import dfi_defs_pkg::dfi_state_e;

module dfi_timing_checker
(
  input logic dfi_clk,
  input logic dfi_reset_n,
  input dfi_state_e state
);
  a_dfi_timing_state_known : assert property (@(posedge dfi_clk)
    disable iff (!dfi_reset_n) !$isunknown(state))
    else `uvm_error("TIMING", "dfi timing: state unknown")
endmodule
`endif
