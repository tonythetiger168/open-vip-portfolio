// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_coverage.svh -- DFI functional coverage: protocol (command x bank
// cross), MC scheduler FSM, and timing-error coverage.

class dfi_coverage extends uvm_subscriber #(dfi_transaction);
  `uvm_component_utils(dfi_coverage)

  dfi_transaction tr;
  dfi_state_e cur_state;

  covergroup cg_protocol;
    cp_cmd : coverpoint tr.cmd {
      bins rd  = {dfi_defs_pkg::DFI_OP_READ};
      bins wr  = {dfi_defs_pkg::DFI_OP_WRITE};
      bins refresh = {dfi_defs_pkg::DFI_OP_REF};
    }
    cp_bank : coverpoint tr.bank {
      bins banks[] = {[0 : dfi_defs_pkg::DFI_BANKS-1]};
    }
    cp_addr : coverpoint tr.addr {
      bins low  = {[14'h0000 : 14'h04FF]};
      bins mid  = {[14'h0500 : 14'h0FFF]};
      bins high = {[14'h1000 : 14'h3FFF]};
    }
    cp_wdata : coverpoint tr.wdata iff (tr.cmd == dfi_defs_pkg::DFI_OP_WRITE) {
      bins zero = {32'h0000_0000};
      bins ones = {32'hFFFF_FFFF};
      bins data = default;
    }
    cx_cmd_bank : cross cp_cmd, cp_bank;
  endgroup

  covergroup cg_fsm with function sample(dfi_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, ACTIVATE, READ, WRITE, PRECHARGE, REFRESH};
    }
    cp_trans : coverpoint s {
      bins rd_flow = (ACTIVATE => READ);
      bins wr_flow = (READ => WRITE);
      bins pre_ref = (WRITE => PRECHARGE => REFRESH);
      bins op_done = (REFRESH => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.error_inject {
      bins none = {dfi_transaction::DFI_ERR_NONE};
      bins trcd = {dfi_transaction::DFI_ERR_TRCD};
      bins trp  = {dfi_transaction::DFI_ERR_TRP};
    }
    cp_viol : coverpoint tr.timing_violation { bins no = {0}; bins yes = {1}; }
    cx_err_cmd : cross cp_err, cp_viol;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(dfi_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_fsm.sample(cur_state);
    cg_error.sample();
  endfunction
endclass
