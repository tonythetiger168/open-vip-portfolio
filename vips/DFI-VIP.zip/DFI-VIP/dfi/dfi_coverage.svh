// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_coverage.svh -- DFI functional coverage

class dfi_coverage extends uvm_subscriber #(dfi_transaction);
  `uvm_component_utils(dfi_coverage)
  dfi_config cfg;
  dfi_transaction tr;

  covergroup dfi_cg;
    cp_kind  : coverpoint tr.kind;
    cp_bank  : coverpoint tr.bank iff (tr.kind inside {K_ACT, K_RD, K_WR, K_PRE});
    cp_ap    : coverpoint tr.ap iff (tr.kind inside {K_RD, K_WR});
    cp_wlat  : coverpoint tr.lat iff (tr.kind == K_WR) { bins early = {2}; bins nom = {3}; bins late = {4}; }
    cp_rlat  : coverpoint tr.lat iff (tr.kind == K_RD) { bins early = {2}; bins nom = {3}; bins late = {4}; }
    cp_beats : coverpoint tr.beats iff (tr.kind inside {K_RD, K_WR}) { bins short_ = {3}; bins bl = {4}; bins long_ = {5}; }
    cp_e_tim : coverpoint tr.err[1];
    cp_e_bank: coverpoint tr.err[2];
    cp_e_wr  : coverpoint tr.err[3];
    cp_e_rd  : coverpoint tr.err[4];
    cp_e_busy: coverpoint tr.err[5];
    cp_e_hs  : coverpoint tr.err[6];
    cp_cu    : coverpoint tr.len iff (tr.kind == K_CTRLUPD) { bins short_ = {[1:3]}; bins ok = {[4:24]}; bins long_ = {[25:63]}; }
    cp_pu    : coverpoint tr.resp iff (tr.kind == K_PHYUPD) { bins ok = {[0:11]}; bins late = {[12:31]}; }
    cp_ptype : coverpoint tr.ptype iff (tr.kind == K_PHYUPD);
    cp_lp    : coverpoint tr.acked iff (tr.kind == K_LP);
    cp_fsel  : coverpoint tr.fsel iff (tr.kind == K_INIT) { bins f[] = {[0:3]}; }
    cp_cmd   : coverpoint tr.kind { bins c[] = {K_ACT, K_RD, K_WR, K_PRE, K_PREA, K_REF}; }
    cp_bad   : coverpoint tr.err { bins ok = {0}; bins bad = {[1:255]}; }
    x_cmd_bad: cross cp_cmd, cp_bad;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    dfi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(dfi_config)::get(this, "", "cfg", cfg))
      cfg = dfi_config::type_id::create("cfg");
  endfunction

  function void write(dfi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    dfi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("DFI coverage: %0.1f%%", dfi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
