// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// dfi_sequences.svh -- DFI sequences

// Random traffic: cfg.num_items constrained-random items.
class dfi_base_sequence extends uvm_sequence #(dfi_transaction);
  `uvm_object_utils(dfi_base_sequence)
  dfi_config cfg;

  bit inited = 0;

  function new(string name = "dfi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin
      if (!inited) begin
        dfi_transaction i0 = dfi_transaction::type_id::create("init");
        i0.kind = K_INIT; i0.gap = 2;
        start_item(i0); finish_item(i0);
        inited = 1;
      end
      req = dfi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "dfi_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class dfi_directed_sequence extends uvm_sequence #(dfi_transaction);
  `uvm_object_utils(dfi_directed_sequence)
  dfi_config cfg;

  function new(string name = "dfi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function dfi_transaction item();
    item = dfi_transaction::type_id::create("req");
  endfunction

  task send(dfi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    dfi_transaction t;
    // a command before init is refused
    t = item(); t.kind = K_ACT; t.bank = 1; t.row = 5; t.gap = 3; send(t);
    t = item(); t.kind = K_INIT; t.fsel = 2; send(t);
    // write, read back and close every bank, with and without auto-precharge
    for (int b = 0; b < 8; b++) begin
      t = item(); t.kind = K_ACT; t.bank = b; t.row = 14'h10 + b; t.gap = 2; send(t);
      t = item(); t.kind = K_WR; t.bank = b; t.col = 8 * b; t.lat = DFI_TPHY_WRLAT; t.beats = DFI_BL;
      t.seed = 100 + b; t.gap = 4; t.post_randomize(); send(t);
      t = item(); t.kind = K_RD; t.bank = b; t.col = 8 * b; t.ap = b[0]; t.lat = DFI_TRDDATA_EN; t.beats = DFI_BL;
      t.gap = 1; t.post_randomize(); send(t);
      if (!b[0]) begin t = item(); t.kind = K_PRE; t.bank = b; t.gap = 1; send(t); end
    end
    // masked write, column wrap inside the row, read back
    t = item(); t.kind = K_ACT; t.bank = 2; t.row = 3; t.gap = 5; send(t);
    t = item(); t.kind = K_WR; t.bank = 2; t.col = 62; t.lat = DFI_TPHY_WRLAT; t.beats = DFI_BL; t.seed = 7;
    t.gap = 4; t.post_randomize(); t.wmask[1] = 4'b0101; t.wmask[2] = 4'hF; send(t);
    t = item(); t.kind = K_RD; t.bank = 2; t.col = 62; t.lat = DFI_TRDDATA_EN; t.beats = DFI_BL; t.post_randomize(); send(t);
    // data enable one cycle early / late, one beat short / long
    for (int k = 0; k < 4; k++) begin
      t = item(); t.kind = K_WR; t.bank = 2; t.col = 4 * k; t.lat = DFI_TPHY_WRLAT + (k == 1) - (k == 0);
      t.beats = DFI_BL + (k == 3) - (k == 2); t.seed = 20 + k; t.post_randomize(); send(t);
      t = item(); t.kind = K_RD; t.bank = 2; t.col = 4 * k; t.lat = DFI_TRDDATA_EN + (k == 1) - (k == 0);
      t.beats = DFI_BL + (k == 3) - (k == 2); t.post_randomize(); send(t);
    end
    // timing and bank-state violations
    t = item(); t.kind = K_PRE; t.bank = 2; send(t);
    t = item(); t.kind = K_ACT; t.bank = 2; t.row = 9; send(t);                   // inside tRP
    t = item(); t.kind = K_ACT; t.bank = 2; t.row = 9; t.gap = 4; send(t);
    t = item(); t.kind = K_RD; t.bank = 2; t.lat = DFI_TRDDATA_EN; t.beats = DFI_BL; t.post_randomize(); send(t);   // inside tRCD
    t = item(); t.kind = K_ACT; t.bank = 2; t.row = 9; send(t);                   // bank already open
    t = item(); t.kind = K_PRE; t.bank = 2; send(t);                              // inside tRAS (RD tail counts)
    t = item(); t.kind = K_RD; t.bank = 5; t.lat = DFI_TRDDATA_EN; t.beats = DFI_BL; t.post_randomize(); send(t);   // closed bank
    t = item(); t.kind = K_REF; send(t);                                          // bank 2 open
    t = item(); t.kind = K_PREA; t.gap = 9; send(t);
    t = item(); t.kind = K_REF; t.gap = 4; send(t);
    t = item(); t.kind = K_ACT; t.bank = 0; t.row = 1; send(t);                   // inside tRFC
    t = item(); t.kind = K_REF; t.gap = 9; send(t);                               // inside tRFC of the last REF
    // handshakes
    t = item(); t.kind = K_CTRLUPD; t.len = 6; t.gap = 9; send(t);
    t = item(); t.kind = K_CTRLUPD; t.len = 2; send(t);
    t = item(); t.kind = K_CTRLUPD; t.len = 26; send(t);
    t = item(); t.kind = K_CTRLUPD; t.len = 8; t.intrude = 1; send(t);
    for (int k = 0; k < 5; k++) begin
      t = item(); t.kind = K_PHYUPD; t.resp = (k == 3) ? DFI_TPHYUPD_RESP : 2 * k; t.early = (k == 4); send(t);
    end
    t = item(); t.kind = K_LP; t.len = 6; t.wakeup = 3; send(t);
    t = item(); t.kind = K_LP; t.len = 6; t.wakeup = 0; send(t);                  // declined
    t = item(); t.kind = K_LP; t.len = 2; t.wakeup = 5; send(t);                  // withdrawn before the ack
    t = item(); t.kind = K_LP; t.len = 10; t.wakeup = 1; t.intrude = 1; send(t);
    // frequency change with a bank open, then with all banks closed
    t = item(); t.kind = K_ACT; t.bank = 6; t.row = 2; t.gap = 9; send(t);
    t = item(); t.kind = K_INIT; t.fsel = 1; send(t);
    t = item(); t.kind = K_PREA; t.gap = 9; send(t);
    t = item(); t.kind = K_INIT; t.fsel = 3; t.gap = 5; send(t);
  endtask
endclass
