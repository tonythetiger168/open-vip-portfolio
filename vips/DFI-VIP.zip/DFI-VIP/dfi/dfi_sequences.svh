// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dfi_sequences.svh -- DFI sequence library: each item is one scheduled
// DRAM operation (ACT + RD/WR + PRE, or PRE + REF).

class dfi_base_sequence extends uvm_sequence #(dfi_transaction);
  `uvm_object_utils(dfi_base_sequence)
  int num_txns = 20;
  function new(string name = "dfi_base_sequence"); super.new(name); endfunction
  task body();
    dfi_transaction tr;
    repeat (num_txns) begin
      tr = dfi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: reads across banks/rows
class dfi_read_seq extends dfi_base_sequence;
  `uvm_object_utils(dfi_read_seq)

  function new(string name = "dfi_read_seq"); super.new(name); endfunction

  task body();
    dfi_transaction tr;
    repeat (num_txns) begin
      tr = dfi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == dfi_defs_pkg::DFI_OP_READ;
                                  error_inject == DFI_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: writes across banks/rows
class dfi_write_seq extends dfi_base_sequence;
  `uvm_object_utils(dfi_write_seq)

  function new(string name = "dfi_write_seq"); super.new(name); endfunction

  task body();
    dfi_transaction tr;
    repeat (num_txns) begin
      tr = dfi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == dfi_defs_pkg::DFI_OP_WRITE;
                                  error_inject == DFI_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: alternating read/write to the same bank+address (read-after-write)
class dfi_read_write_seq extends dfi_base_sequence;
  `uvm_object_utils(dfi_read_write_seq)

  function new(string name = "dfi_read_write_seq"); super.new(name); endfunction

  rand bit [13:0] addr = 14'h0100;
  rand bit [2:0]  bank = 3'd2;
  task body();
    dfi_transaction tr;
    repeat (num_txns) begin
      tr = dfi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == dfi_defs_pkg::DFI_OP_WRITE;
                                  error_inject == DFI_ERR_NONE;
                                  addr == local::addr; bank == local::bank; });
      finish_item(tr);
      tr = dfi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == dfi_defs_pkg::DFI_OP_READ;
                                  error_inject == DFI_ERR_NONE;
                                  addr == local::addr; bank == local::bank; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: explicit refresh operations
class dfi_refresh_seq extends dfi_base_sequence;
  `uvm_object_utils(dfi_refresh_seq)

  function new(string name = "dfi_refresh_seq"); super.new(name); endfunction

  task body();
    dfi_transaction tr;
    repeat (num_txns) begin
      tr = dfi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == dfi_defs_pkg::DFI_OP_REF;
                                  error_inject == DFI_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: RD/WR issued before tRCD after ACT
class dfi_trcd_violation_seq extends dfi_base_sequence;
  `uvm_object_utils(dfi_trcd_violation_seq)

  function new(string name = "dfi_trcd_violation_seq"); super.new(name); endfunction

  task body();
    dfi_transaction tr;
    repeat (num_txns) begin
      tr = dfi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd inside {dfi_defs_pkg::DFI_OP_READ,
                                              dfi_defs_pkg::DFI_OP_WRITE};
                                  error_inject == DFI_ERR_TRCD; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: ACT issued before tRP after PRE
class dfi_trp_violation_seq extends dfi_base_sequence;
  `uvm_object_utils(dfi_trp_violation_seq)

  function new(string name = "dfi_trp_violation_seq"); super.new(name); endfunction

  task body();
    dfi_transaction tr;
    repeat (num_txns) begin
      tr = dfi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd inside {dfi_defs_pkg::DFI_OP_READ,
                                              dfi_defs_pkg::DFI_OP_WRITE};
                                  error_inject == DFI_ERR_TRP; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: one write right after reset release
class dfi_reset_seq extends dfi_base_sequence;
  `uvm_object_utils(dfi_reset_seq)

  function new(string name = "dfi_reset_seq"); super.new(name); endfunction

  task body();
    dfi_transaction tr = dfi_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { cmd == dfi_defs_pkg::DFI_OP_WRITE;
                                error_inject == DFI_ERR_NONE; });
    finish_item(tr);
  endtask
endclass

class dfi_random_sequence extends dfi_base_sequence;
  `uvm_object_utils(dfi_random_sequence)
  function new(string name = "dfi_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class dfi_regression_sequence extends dfi_base_sequence;
  `uvm_object_utils(dfi_regression_sequence)
  function new(string name = "dfi_regression_sequence"); super.new(name); endfunction
  task body();
    dfi_read_seq           rd  = dfi_read_seq::type_id::create("rd");
    dfi_write_seq          wr  = dfi_write_seq::type_id::create("wr");
    dfi_read_write_seq     rw  = dfi_read_write_seq::type_id::create("rw");
    dfi_refresh_seq        rfr = dfi_refresh_seq::type_id::create("rfr");
    dfi_trcd_violation_seq rcd = dfi_trcd_violation_seq::type_id::create("rcd");
    dfi_trp_violation_seq  rp  = dfi_trp_violation_seq::type_id::create("rp");
    rd.num_txns = 12; wr.num_txns = 12; rw.num_txns = 5;
    rfr.num_txns = 4; rcd.num_txns = 4; rp.num_txns = 4;
    rd.start(m_sequencer);  wr.start(m_sequencer);
    rw.start(m_sequencer);  rfr.start(m_sequencer);
    rcd.start(m_sequencer); rp.start(m_sequencer);
  endtask
endclass
