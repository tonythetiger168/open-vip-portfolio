# DFI — DFI 5.0 (MC-PHY Interface) UVM VIP

Open-source UVM verification IP template for **DFI 5.0 (MC-PHY Interface)** (Memory).

## Contents

| Path | Description |
|------|-------------|
| `dfi/dfi_if.sv` | Protocol interface + FSM state enum |
| `dfi/dfi_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `dfi/sva/dfi_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4) |
| `dfi/vip/dfi/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/dfi_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with FSM-walking DUT stub |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Cycle-accurate MC driver**: schedules ACT → RD/WR → PRE on the dfi_cmd channel with modelled tRCD/tRP timing, captures dfi_rddata on dfi_rddata_valid after the programmed read latency (RL=4), auto-issues periodic refresh (tREFI=256) like a real controller
- **Command-decoding monitor**: decodes the MC command channel (ACT/RD/WR/PRE/REF, bank/address/wrdata), captures read data returns, classifies tRCD vs tRP violations from the PHY error pulse phase
- **End-to-end scoreboard**: compares driver-issued vs monitor-decoded operations (cmd, bank, address, wdata, rdata, violation flags)
- **Functional DUT model**: DDR PHY + DRAM with per-bank open-row tracking, tRCD/tRP cycle checks (dfi_error pulse + dropped command), bank memory, RL-deep read pipeline, CKE gating
- **Directed sequence library**: read / write / read-after-write same address / refresh / tRCD-violation / tRP-violation / reset + regression mix
- **Functional coverage**: command × bank cross, address ranges, wdata corners, scheduler FSM states + transitions, timing-error coverage
- **SVA L4**: tRCD after ACT, rddata_valid within RL window after RD, bounded refresh periodicity, no commands while CKE low, tRP after PRE

Note: `state` is the MC command-scheduler phase marker; every operation
walks the full phase sequence (phases without bus commands are brief
pass-throughs) so FSM coverage and L2 transition checks hold for all ops.
