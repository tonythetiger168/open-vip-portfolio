# NPU-UVM-VIP test plan

## Register test (`npu_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `npu_conv_test`: 36 jobs: identity (W0 = 1), moving sum, a high-pass
  [1, -2, 1, 0], all four taps at +127 / -128, random weights; BIAS 0,
  +-32767 / -32768 and random; SHIFT 0..15; RELU on and off; lengths 1, 2,
  16, 17 and random up to 600 words; four back-pressure settings. Every
  output word, SATURATIONS, STATUS, DONE / ERR, read / write counts, windows,
  AXI ID 2; history is reset between jobs (the same input twice gives the
  same output).
- `npu_err_test`: SLVERR in the source (those samples are 0 and the
  convolution runs across them), DECERR in the destination (untouched):
  DONE + ERR, STATUS.err; a clean job clears it.
