# NPU UVM VIP (NPU-UVM-VIP)

UVM verification IP for the open-ip-portfolio **NPU** subsystem: NPU: int8 4-tap 1-D convolution engine with bias, ReLU and requantization over AXI4.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`8e9722204875`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 2) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What NPU does (from the spec)

- Input and output: four signed int8 samples per word, byte 0 first; sample n of the job is byte n mod 4 of word n / 4.
- acc[n] = BIAS + W0*x[n] + W1*x[n-1] + W2*x[n-2] + W3*x[n-3], with x[-1] = x[-2] = x[-3] = 0 (each job starts from zero history).
- y[n] = sat8((RELU ? max(acc[n], 0) : acc[n]) >>> SHIFT): arithmetic shift, then clip to -128..127.
- SATURATIONS counts the results that were clipped in the last job (saturating).

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `npu/` -- `npu_ral.svh` register model (generated from the spec, same
  offsets as `NPU_apb`), `npu_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `npu_pins_if.sv`
- `rtl/` -- `NPU_apb.sv`, `NPU_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/npu.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | SRC_ADDR | rw |
| 0x018 | DST_ADDR | rw |
| 0x01C | LEN | rw |
| 0x020 | WEIGHTS | rw |
| 0x024 | CTRL | rw |
| 0x028 | CMD | cmd |
| 0x02C | STATUS | ro |
| 0x030 | SATURATIONS | ro |
| 0x034 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR.

## Tests

| Test | Seeds |
|---|---|
| `npu_ral_test` | 1 |
| `npu_conv_test` | 3 |
| `npu_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT NPU mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/npu.f
./obj_dir/Vtop_tb +UVM_TESTNAME=npu_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py NPU-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
