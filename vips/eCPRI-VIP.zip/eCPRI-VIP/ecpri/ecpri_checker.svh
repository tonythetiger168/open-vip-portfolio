// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ecpri_checker.svh -- eCPRI transaction checker: verifies payload length
// against the header size field implicitly (driver constrains it) and
// checks FCS error flags for consistency with injected errors is left to
// the scoreboard; here we verify basic header field sanity.

`ifndef ECPRI_CHECKER_SVH
`define ECPRI_CHECKER_SVH

class ecpri_checker extends uvm_component;
  `uvm_component_utils(ecpri_checker)
  uvm_analysis_imp #(ecpri_transaction, ecpri_checker) chk_ap;
  int unsigned checked = 0, errors = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    chk_ap = new("chk_ap", this);
  endfunction

  function void write(ecpri_transaction tr);
    checked++;
    // payload length must be within the 16-bit size field in bytes
    if (tr.payload.size() == 0 || tr.payload.size() > 8) begin
      errors++;
      `uvm_error("CHK", $sformatf("illegal payload word count %0d", tr.payload.size()))
    end
    // unknown msg_type must only appear on purpose-built error traffic
    if (tr.msg_type >= 4'h8 && !tr.unknown_type) begin
      errors++;
      `uvm_error("CHK", $sformatf("unexpected reserved msg_type 0x%01h", tr.msg_type))
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHECKER", $sformatf("ecpri: checked=%0d errors=%0d", checked, errors), UVM_LOW)
  endfunction
endclass
`endif
