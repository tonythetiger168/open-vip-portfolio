// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ecpri_transaction.svh -- eCPRI message: 64-bit common header
// (revision / msg_type / payload size / pc_id / seq_id), payload words
// and a trailing CRC-32 FCS word.

`ifndef ECPRI_TRANSACTION_SVH
`define ECPRI_TRANSACTION_SVH

class ecpri_transaction extends uvm_sequence_item;

  rand bit [3:0]  msg_type;        // ecpri_msg_type_e (8..15 = unknown, injected)
  rand bit [15:0] pc_id;           // physical channel / RTC identifier
  rand bit [63:0] payload[$];      // 64-bit payload words
  rand bit [15:0] seq_id;          // sequence identifier
  rand bit        inject_fcs_err;  // error injection: corrupt the FCS word
  rand bit        unknown_type;    // error injection: reserved msg_type

  bit        fcs_err;              // monitor: observed FCS mismatch
  bit [31:0] fcs;                  // monitor/driver: FCS word on the wire

  constraint c_type    { (unknown_type == 0) -> msg_type inside {[4'h0:4'h7]};
                         (unknown_type == 1) -> msg_type inside {[4'h8:4'hF]};
                         unknown_type dist {0 := 9, 1 := 1}; }
  constraint c_len     { payload.size() inside {[1:8]}; }
  constraint c_fcs     { inject_fcs_err dist {0 := 9, 1 := 1};
                         solve unknown_type before inject_fcs_err;
                         (unknown_type == 1) -> (inject_fcs_err == 0); }
  constraint c_pc_id   { pc_id dist {16'h0 := 1, [16'h1:16'hFFFE] := 8, 16'hFFFF := 1}; }

  `uvm_object_utils_begin(ecpri_transaction)
    `uvm_field_int(msg_type, UVM_ALL_ON)
    `uvm_field_int(pc_id, UVM_ALL_ON)
    `uvm_field_queue_int(payload, UVM_ALL_ON)
    `uvm_field_int(seq_id, UVM_ALL_ON)
    `uvm_field_int(fcs_err, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(inject_fcs_err, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(unknown_type, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "ecpri_transaction");
    super.new(name);
  endfunction

  // 64-bit eCPRI common header word
  function bit [63:0] header_word();
    return {ecpri_defs_pkg::ECPRI_REV, 4'h0, 4'h0, msg_type,
            16'(payload.size() * 8), pc_id, seq_id};
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ecpri_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= comparer.compare_field("msg_type", msg_type, t.msg_type, 4);
    do_compare &= comparer.compare_field("pc_id",    pc_id,    t.pc_id,    16);
    do_compare &= comparer.compare_field("seq_id",   seq_id,   t.seq_id,   16);
    do_compare &= comparer.compare_field("plen",     payload.size(), t.payload.size(), 32);
  endfunction

  function string convert2string();
    return $sformatf("eCPRI type=0x%01h pc_id=0x%04h seq=%0d plen=%0d fcs_err=%0b",
                     msg_type, pc_id, seq_id, payload.size(), fcs_err);
  endfunction
endclass
`endif
