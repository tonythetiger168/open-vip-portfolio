// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ecpri_monitor.svh -- eCPRI monitor: decodes the 64-bit valid/ready stream.
// Reconstructs messages (common header -> payload -> FCS), recomputes the
// CRC-32 to flag FCS errors, and publishes one transaction per message.

`ifndef ECPRI_MONITOR_SVH
`define ECPRI_MONITOR_SVH

class ecpri_monitor extends uvm_monitor;
  `uvm_component_utils(ecpri_monitor)
  virtual ecpri_if vif;
  uvm_analysis_port #(ecpri_transaction) ap;
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ecpri_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ecpri virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    ecpri_transaction tr;
    bit [63:0] words[$];
    bit [31:0] crc;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) continue;
      if (vif.mon_cb.tx_valid && vif.mon_cb.tx_ready) begin
        case (vif.mon_cb.state)
          ecpri_defs_pkg::HEADER: begin
            tr = ecpri_transaction::type_id::create("tr");
            tr.msg_type = vif.mon_cb.tx_data[51:48];
            tr.pc_id    = vif.mon_cb.tx_data[31:16];
            tr.seq_id   = vif.mon_cb.tx_data[15:0];
            tr.fcs_err  = 1'b0;
            tr.unknown_type = (vif.mon_cb.tx_data[51:48] >= 4'h8);
            words.delete();
            words.push_back(vif.mon_cb.tx_data);
          end
          ecpri_defs_pkg::PAYLOAD: begin
            if (tr != null) begin
              tr.payload.push_back(vif.mon_cb.tx_data);
              words.push_back(vif.mon_cb.tx_data);
            end
          end
          ecpri_defs_pkg::FCS: begin
            if (tr != null) begin
              crc = ecpri_defs_pkg::ecpri_crc32(words);
              tr.fcs     = vif.mon_cb.tx_data[31:0];
              tr.fcs_err = (vif.mon_cb.tx_data[31:0] !== crc);
              txn_count++;
              `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
              ap.write(tr);
              tr = null;
            end
          end
          default: ;
        endcase
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("ecpri monitor observed %0d messages", txn_count), UVM_LOW)
  endfunction
endclass
`endif
