// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ecpri_sequences.svh -- eCPRI sequence library

`ifndef ECPRI_SEQUENCES_SVH
`define ECPRI_SEQUENCES_SVH

class ecpri_base_sequence extends uvm_sequence #(ecpri_transaction);
  `uvm_object_utils(ecpri_base_sequence)
  int num_txns = 20;
  function new(string name = "ecpri_base_sequence"); super.new(name); endfunction
  task body();
    ecpri_transaction tr;
    repeat (num_txns) begin
      tr = ecpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: IQ data messages
class ecpri_iq_data_seq extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_iq_data_seq)
  function new(string name = "ecpri_iq_data_seq"); super.new(name); endfunction
  task body();
    ecpri_transaction tr;
    repeat (num_txns) begin
      tr = ecpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { msg_type == ecpri_defs_pkg::ECPRI_IQ_DATA;
                                  unknown_type == 0; inject_fcs_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: real-time control command messages
class ecpri_cmd_seq extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_cmd_seq)
  function new(string name = "ecpri_cmd_seq"); super.new(name); endfunction
  task body();
    ecpri_transaction tr;
    repeat (num_txns) begin
      tr = ecpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { msg_type == ecpri_defs_pkg::ECPRI_RTC_CMD;
                                  unknown_type == 0; inject_fcs_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: request messages (endpoint replies with a response)
class ecpri_req_rsp_seq extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_req_rsp_seq)
  function new(string name = "ecpri_req_rsp_seq"); super.new(name); num_txns = 10; endfunction
  task body();
    ecpri_transaction tr;
    repeat (num_txns) begin
      tr = ecpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { msg_type == ecpri_defs_pkg::ECPRI_REQ;
                                  unknown_type == 0; inject_fcs_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: sync (one-way delay measurement) messages
class ecpri_sync_seq extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_sync_seq)
  function new(string name = "ecpri_sync_seq"); super.new(name); endfunction
  task body();
    ecpri_transaction tr;
    repeat (num_txns) begin
      tr = ecpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { msg_type == ecpri_defs_pkg::ECPRI_SYNC;
                                  unknown_type == 0; inject_fcs_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: maximum-length payloads
class ecpri_max_payload_seq extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_max_payload_seq)
  function new(string name = "ecpri_max_payload_seq"); super.new(name); endfunction
  task body();
    ecpri_transaction tr;
    repeat (num_txns) begin
      tr = ecpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { payload.size() == 8;
                                  unknown_type == 0; inject_fcs_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back single-word messages (min gap on the stream)
class ecpri_back_to_back_seq extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_back_to_back_seq)
  function new(string name = "ecpri_back_to_back_seq"); super.new(name); endfunction
  task body();
    ecpri_transaction tr;
    repeat (num_txns) begin
      tr = ecpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { payload.size() == 1;
                                  unknown_type == 0; inject_fcs_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: FCS corruption and unknown (reserved) msg_type
class ecpri_error_inject_seq extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_error_inject_seq)
  function new(string name = "ecpri_error_inject_seq"); super.new(name); num_txns = 12; endfunction
  task body();
    ecpri_transaction tr;
    repeat (num_txns) begin
      tr = ecpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inject_fcs_err dist {0 := 1, 1 := 1};
                                  unknown_type    dist {0 := 1, 1 := 1}; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single message right after reset release
class ecpri_reset_seq extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_reset_seq)
  function new(string name = "ecpri_reset_seq"); super.new(name); endfunction
  task body();
    ecpri_transaction tr = ecpri_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { payload.size() == 1;
                                unknown_type == 0; inject_fcs_err == 0; });
    finish_item(tr);
  endtask
endclass

class ecpri_random_sequence extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_random_sequence)
  function new(string name = "ecpri_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class ecpri_regression_sequence extends ecpri_base_sequence;
  `uvm_object_utils(ecpri_regression_sequence)
  function new(string name = "ecpri_regression_sequence"); super.new(name); endfunction
  task body();
    ecpri_iq_data_seq      iq  = ecpri_iq_data_seq::type_id::create("iq");
    ecpri_cmd_seq          cmd = ecpri_cmd_seq::type_id::create("cmd");
    ecpri_req_rsp_seq      req = ecpri_req_rsp_seq::type_id::create("req");
    ecpri_sync_seq         syn = ecpri_sync_seq::type_id::create("syn");
    ecpri_max_payload_seq  mxp = ecpri_max_payload_seq::type_id::create("mxp");
    ecpri_back_to_back_seq b2b = ecpri_back_to_back_seq::type_id::create("b2b");
    ecpri_error_inject_seq err = ecpri_error_inject_seq::type_id::create("err");
    iq.start(m_sequencer);
    cmd.start(m_sequencer);
    req.start(m_sequencer);
    syn.start(m_sequencer);
    mxp.start(m_sequencer);
    b2b.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
