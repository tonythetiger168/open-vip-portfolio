// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ecpri_compliance_checker.sv -- eCPRI SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = eCPRI message-format rules

`ifndef ECPRI_COMPLIANCE_CHECKER_SV
`define ECPRI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import ecpri_defs_pkg::*;

module ecpri_compliance_checker
(
  input logic        clk,
  input logic        rst_n,
  input ecpri_state_e state,
  input logic        tx_valid,
  input logic        tx_ready,
  input logic [63:0] tx_data,
  input logic        fcs_err
);

  // ---------------- L1: signal sanity (4) ----------------
  a_ecpri_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "ecpri: clock unknown")
  a_ecpri_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "ecpri: reset unknown")
  a_ecpri_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "ecpri: state unknown")
  a_ecpri_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, HEADER, PAYLOAD, FCS})
    else `uvm_error("SVA_L1", "ecpri: state outside legal encoding")

  // ---------------- L2: FSM legality (4) ----------------
  // L2-1: legal FSM transition from IDLE
  a_ecpri_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, HEADER})
    else `uvm_error("SVA_L2", "ecpri: illegal transition from IDLE")

  // L2-2: legal FSM transition from HEADER
  a_ecpri_trans_header : assert property (@(posedge clk) disable iff (!rst_n)
    state == HEADER |=> state inside {HEADER, PAYLOAD})
    else `uvm_error("SVA_L2", "ecpri: illegal transition from HEADER")

  // L2-3: legal FSM transition from PAYLOAD
  a_ecpri_trans_payload : assert property (@(posedge clk) disable iff (!rst_n)
    state == PAYLOAD |=> state inside {PAYLOAD, FCS})
    else `uvm_error("SVA_L2", "ecpri: illegal transition from PAYLOAD")

  // L2-4: legal FSM transition from FCS
  a_ecpri_trans_fcs : assert property (@(posedge clk) disable iff (!rst_n)
    state == FCS |=> state inside {FCS, IDLE})
    else `uvm_error("SVA_L2", "ecpri: illegal transition from FCS")

  // ---------------- L3: protocol rules (4) ----------------
  a_ecpri_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "ecpri: state not IDLE during reset")
  a_ecpri_l3_valid_held : assert property (@(posedge clk) disable iff (!rst_n)
    (tx_valid && !tx_ready) |=> tx_valid)
    else `uvm_error("SVA_L3", "ecpri: tx_valid dropped before tx_ready")
  a_ecpri_l3_msg_start  : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == HEADER);
  a_ecpri_l3_msg_done   : cover property (@(posedge clk) disable iff (!rst_n)
    state == FCS ##1 state == IDLE);

  // ---------------- L4: eCPRI message-format rules (5) ----------------
  // L4-1: common header fixed format (revision=1, reserved/concatenation=0,
  //       msg_type upper nibble=0)
  a_ecpri_l4_header_fmt : assert property (@(posedge clk) disable iff (!rst_n)
    (state == HEADER && tx_valid) |->
    (tx_data[63:60] == ECPRI_REV && tx_data[59:56] == 4'h0 && tx_data[55:52] == 4'h0))
    else `uvm_error("SVA_L4", "ecpri: common header format violation")

  // L4-2: payload length matches the header payload-size field
  int unsigned exp_words = 0, pay_cnt = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      exp_words <= 0;
      pay_cnt   <= 0;
    end else if (tx_valid && tx_ready) begin
      if (state == HEADER) begin
        exp_words <= tx_data[47:32] / 8;
        pay_cnt   <= 0;
      end else if (state == PAYLOAD) begin
        pay_cnt <= pay_cnt + 1;
      end else if (state == FCS) begin
        a_ecpri_l4_payload_len : assert (pay_cnt == exp_words)
          else `uvm_error("SVA_L4", "ecpri: payload length mismatch vs header size")
      end
    end
  end

  // L4-3: tx_data stable while tx_valid is high and tx_ready is low
  a_ecpri_l4_data_stable : assert property (@(posedge clk) disable iff (!rst_n)
    (tx_valid && !tx_ready) |=> $stable(tx_data))
    else `uvm_error("SVA_L4", "ecpri: tx_data changed during backpressure")

  // L4-4: endpoint FCS-error flag may only pulse around the FCS phase
  a_ecpri_l4_fcs_err_phase : assert property (@(posedge clk) disable iff (!rst_n)
    fcs_err |-> (state inside {FCS, IDLE}))
    else `uvm_error("SVA_L4", "ecpri: fcs_err flagged outside FCS phase")

  // L4-5: cover the FCS error case (injected corruption detected by endpoint)
  c_ecpri_l4_fcs_err_seen : cover property (@(posedge clk) disable iff (!rst_n)
    fcs_err ##1 !fcs_err);

endmodule
`endif
