// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ecpri_coverage.svh -- eCPRI functional coverage.
// cg_protocol samples decoded messages (msg_type x payload-length cross),
// cg_fsm samples the transmit FSM from the interface on state changes,
// cg_error covers FCS errors and unknown message types.

`ifndef ECPRI_COVERAGE_SVH
`define ECPRI_COVERAGE_SVH

class ecpri_coverage extends uvm_subscriber #(ecpri_transaction);
  `uvm_component_utils(ecpri_coverage)

  virtual ecpri_if vif;
  ecpri_transaction tr;

  covergroup cg_protocol;
    cp_type : coverpoint tr.msg_type {
      bins iq   = {ecpri_defs_pkg::ECPRI_IQ_DATA};
      bins bitq = {ecpri_defs_pkg::ECPRI_BIT_SEQ};
      bins cmd  = {ecpri_defs_pkg::ECPRI_RTC_CMD};
      bins gen  = {ecpri_defs_pkg::ECPRI_GEN_DATA};
      bins req  = {ecpri_defs_pkg::ECPRI_REQ};
      bins rsp  = {ecpri_defs_pkg::ECPRI_RSP};
      bins sync = {ecpri_defs_pkg::ECPRI_SYNC};
      bins evt  = {ecpri_defs_pkg::ECPRI_EVT};
      bins unknown[] = {[4'h8:4'hF]};
    }
    cp_len  : coverpoint tr.payload.size() {
      bins single = {1};
      bins short  = {[2:4]};
      bins long   = {[5:7]};
      bins max    = {8};
    }
    cp_pcid : coverpoint tr.pc_id {
      bins zero = {16'h0000};
      bins low  = {[16'h0001:16'h00FF]};
      bins mid  = {[16'h0100:16'hFFFE]};
      bins ones = {16'hFFFF};
    }
    cp_seq  : coverpoint tr.seq_id {
      bins zero = {16'h0000};
      bins val  = {[16'h0001:16'hFFFE]};
      bins ones = {16'hFFFF};
    }
    cx_type_len : cross cp_type, cp_len;
  endgroup

  covergroup cg_fsm with function sample(ecpri_state_e s);
    cp_state : coverpoint s {
      bins states[] = {IDLE, HEADER, PAYLOAD, FCS};
    }
    cp_trans : coverpoint s {
      bins msg_seq = (IDLE => HEADER => PAYLOAD => FCS => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_fcs_err : coverpoint tr.fcs_err { bins ok = {0}; bins err = {1}; }
    cp_unknown : coverpoint (tr.msg_type >= 4'h8) { bins known = {0}; bins unknown = {1}; }
    cx_err     : cross cp_fcs_err, cp_unknown;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ecpri_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ecpri virtual interface not set")
  endfunction

  function void write(ecpri_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction

  task run_phase(uvm_phase phase);
    ecpri_state_e prev;
    prev = ecpri_state_e'('x);
    forever begin
      @(posedge vif.clk);
      if (vif.rst_n === 1'b1) begin
        // sample FSM on state change so the chained transition bin can hit
        if (vif.state !== prev) begin
          cg_fsm.sample(vif.state);
          prev = vif.state;
        end
      end
    end
  endtask
endclass
`endif
