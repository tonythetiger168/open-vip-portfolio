// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ecpri_if.sv -- eCPRI over Ethernet interface
// 64-bit valid/ready stream. tx_* is the initiator (VIP driver) direction;
// rx_* carries endpoint (DUT) responses. fcs_err is flagged by the endpoint
// when a received message fails its CRC-32 check.

interface ecpri_if (input logic clk);
  import ecpri_defs_pkg::ecpri_state_e;

  logic        rst_n;
  logic        tx_valid;
  logic        tx_ready;
  logic [63:0] tx_data;
  logic        rx_valid;
  logic        rx_ready;
  logic [63:0] rx_data;
  logic        fcs_err;      // endpoint: FCS mismatch on received message

  ecpri_state_e state;       // initiator transmit FSM (driven by VIP driver)

  modport DUT (input  clk, rst_n, tx_valid, tx_data, rx_ready,
               output tx_ready, rx_valid, rx_data, fcs_err);
  modport TB  (input  clk, tx_ready, rx_valid, rx_data, fcs_err,
               output rst_n, tx_valid, tx_data, rx_ready, state);
  modport MON (input  clk, rst_n, tx_valid, tx_ready, tx_data,
                      rx_valid, rx_ready, rx_data, fcs_err, state);

  clocking drv_cb @(posedge clk);
    output tx_valid, tx_data, rx_ready, state;
    input  rst_n, tx_ready, rx_valid, rx_data, fcs_err;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, tx_valid, tx_ready, tx_data,
          rx_valid, rx_ready, rx_data, fcs_err, state;
  endclocking
endinterface
