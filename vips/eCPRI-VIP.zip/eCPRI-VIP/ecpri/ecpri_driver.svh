// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ecpri_driver.svh -- eCPRI initiator driver.
// Serializes each message onto the 64-bit valid/ready stream:
// common header word -> payload words -> CRC-32 FCS word.
// Bus signals are driven with blocking assignments on the negedge (and
// sampled on the posedge) so every word is visible for exactly one
// transfer window -- no clocking-drive races or double sampling.
// Supports FCS corruption and unknown msg_type error injection.
// Expected messages are broadcast on drv_ap for the scoreboard.

`ifndef ECPRI_DRIVER_SVH
`define ECPRI_DRIVER_SVH

class ecpri_driver extends uvm_driver #(ecpri_transaction);
  `uvm_component_utils(ecpri_driver)
  virtual ecpri_if vif;
  ecpri_config cfg;
  uvm_analysis_port #(ecpri_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ecpri_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ecpri virtual interface not set")
  endfunction

  // Drive one 64-bit word and wait for its transfer (valid && ready at a
  // posedge). Returns at the negedge after the transfer with valid low.
  task send_word(bit [63:0] w);
    @(negedge vif.clk);
    vif.tx_data  = w;
    vif.tx_valid = 1'b1;
    @(posedge vif.clk);
    while (!vif.tx_ready) @(posedge vif.clk);   // hold word stable under backpressure
    @(negedge vif.clk);
    vif.tx_valid = 1'b0;
  endtask

  task run_phase(uvm_phase phase);
    ecpri_transaction tr;
    bit [63:0] words[$];
    bit [31:0] crc;
    // Deterministic drives during reset so SVA never samples X.
    vif.tx_valid = 1'b0;
    vif.tx_data  = 64'h0;
    vif.rx_ready = 1'b1;
    vif.state    = ecpri_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    @(negedge vif.clk);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)

      // common header (send_word enters at a negedge)
      vif.state = ecpri_defs_pkg::HEADER;
      send_word(tr.header_word());
      words.delete();
      words.push_back(tr.header_word());

      // payload (each send_word returns at a negedge)
      vif.state = ecpri_defs_pkg::PAYLOAD;
      foreach (tr.payload[i]) begin
        send_word(tr.payload[i]);
        words.push_back(tr.payload[i]);
      end

      // FCS (CRC-32 over header + payload), optionally corrupted
      crc = ecpri_defs_pkg::ecpri_crc32(words);
      if (tr.inject_fcs_err) crc = crc ^ 32'h0000_0001;
      tr.fcs = crc;
      vif.state = ecpri_defs_pkg::FCS;
      send_word({32'h0, crc});

      vif.state    = ecpri_defs_pkg::IDLE;
      vif.tx_data  = 64'h0;
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
      repeat (2) @(negedge vif.clk);
    end
  endtask
endclass
`endif
