// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ecpri_defs.sv -- eCPRI over Ethernet shared type definitions

package ecpri_defs_pkg;
  // Transmit FSM: one 64-bit common-header word, N payload words, one FCS word
  typedef enum bit [1:0] {
    IDLE,
    HEADER,
    PAYLOAD,
    FCS
  } ecpri_state_e;

  // eCPRI message types (subset, upper nibble always zero)
  typedef enum bit [3:0] {
    ECPRI_IQ_DATA  = 4'h0,   // IQ Data
    ECPRI_BIT_SEQ  = 4'h1,   // Bit Sequence
    ECPRI_RTC_CMD  = 4'h2,   // Real-Time Control Data
    ECPRI_GEN_DATA = 4'h3,   // Generic Data Transfer
    ECPRI_REQ      = 4'h4,   // Remote Memory Access / request
    ECPRI_RSP      = 4'h5,   // Response to a request
    ECPRI_SYNC     = 4'h6,   // One-Way Delay Measurement / sync
    ECPRI_EVT      = 4'h7    // Event Indication
  } ecpri_msg_type_e;

  localparam bit [3:0] ECPRI_REV = 4'h1;   // eCPRI protocol revision

  // IEEE 802.3 CRC-32 over a queue of 64-bit words (LSB-first per byte)
  function automatic bit [31:0] ecpri_crc32(const ref bit [63:0] words[$]);
    bit [31:0] crc;
    crc = 32'hFFFF_FFFF;
    foreach (words[i]) begin
      for (int b = 0; b < 8; b++) begin
        crc ^= words[i][b*8 +: 8];
        for (int k = 0; k < 8; k++)
          crc = crc[0] ? (crc >> 1) ^ 32'hEDB8_8320 : (crc >> 1);
      end
    end
    return ~crc;
  endfunction
endpackage
