// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_ecpri_tb.sv -- self-checking functional test for the eCPRI endpoint
// model (ecpri_endpoint_dut, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py eCPRI-VIP
//
// Model contract (from ecpri_defs.sv / ecpri_driver.svh), 64-bit words with
// valid/ready on both directions:
//   frame = header {rev 1, 0, 0, msg_type[3:0], payload bytes, PC_ID, SEQ_ID},
//   payload words (payload bytes / 8), FCS word {0, CRC-32 over header and
//   payload, LSB byte first}. tx_ready is low one clock in five.
//   A bad FCS pulses fcs_err. A Remote Memory Access request (type 4) with a
//   good FCS is answered on rx: header with type 5 (same size, PC_ID,
//   SEQ_ID), the payload echoed, and the response FCS.

module func_ecpri_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, tx_valid = 1'b0, rx_ready = 1'b1;
  logic [63:0] tx_data = '0;
  wire         tx_ready, rx_valid, fcs_err;
  wire  [63:0] rx_data;

  always #5 clk = ~clk;

  ecpri_endpoint_dut u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_tx_valid(tx_valid), .vif_tx_ready(tx_ready),
    .vif_tx_data(tx_data), .vif_rx_valid(rx_valid), .vif_rx_ready(rx_ready),
    .vif_rx_data(rx_data), .vif_fcs_err(fcs_err)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // reference CRC-32 over 64-bit words, LSB byte first
  logic [63:0] fw [0:15];
  function automatic logic [31:0] crc(input int n);
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < n; i++)
      for (int b = 0; b < 8; b++) begin
        c ^= fw[i][b*8 +: 8];
        for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
      end
    return ~c;
  endfunction

  // ---- tx side ----
  int stalls;
  task automatic send_word(input [63:0] w);
    @(negedge clk);
    tx_data = w; tx_valid = 1'b1;
    while (tx_ready !== 1'b1) begin stalls++; @(negedge clk); end
    @(negedge clk);
    tx_valid = 1'b0;
  endtask
  task automatic send(input [3:0] t, input int nw, input [15:0] pc, input [15:0] seq,
                      input bit bad_fcs = 0, input int plen = -1);
    logic [31:0] c;
    fw[0] = {4'h1, 4'h0, 4'h0, t, 16'(plen < 0 ? nw * 8 : plen), pc, seq};
    for (int i = 1; i <= nw; i++) fw[i] = {pc, seq, 16'(i), 16'hC0DE ^ 16'(t)};
    for (int i = 0; i <= nw; i++) send_word(fw[i]);
    c = crc(nw + 1) ^ (bad_fcs ? 32'h1 : 32'h0);
    send_word({32'h0, c});
  endtask

  // ---- rx side ----
  logic [63:0] rq [0:63];
  int          rn = 0;
  always @(posedge clk) if (rx_valid && rx_ready) begin rq[rn] = rx_data; rn++; end
  int fe;
  always @(posedge clk) if (fcs_err) fe++;

  // a response for request fw[0..nw] arrived at rq[from..]?
  function automatic bit rsp_ok(input int from, input int nw);
    logic [63:0] rw [0:15];
    logic [63:0] save [0:15];
    logic [31:0] c;
    if (rn - from != nw + 2) return 0;
    if (rq[from] != {fw[0][63:52], 4'h5, fw[0][47:0]}) return 0;
    for (int i = 1; i <= nw; i++) if (rq[from + i] != fw[i]) return 0;
    for (int i = 0; i <= nw; i++) save[i] = fw[i];
    for (int i = 0; i <= nw; i++) fw[i] = rq[from + i];
    c = crc(nw + 1);
    for (int i = 0; i <= nw; i++) fw[i] = save[i];
    return rq[from + nw + 1] == {32'h0, c};
  endfunction

  int r0, k, gaps, n_ready_low;
  bit valid_dropped;
  initial begin
    // reference CRC self-check: "12345678" as one LSB-first word
    fw[0] = 64'h3837_3635_3433_3231;
    chk(crc(1) == 32'h9AE0_DAAF, "reference CRC-32 of \"12345678\" = 9AE0DAAF");

    repeat (2) @(negedge clk);
    chk(!rx_valid && !fcs_err, "reset: no response, no FCS error");
    rst_n = 1'b1;

    // tx_ready pattern: low one clock in five
    n_ready_low = 0;
    for (int i = 0; i < 50; i++) begin @(negedge clk); if (!tx_ready) n_ready_low++; end
    chk(n_ready_low == 10, "tx_ready low exactly one clock in five");

    // ---- request -> response ----
    r0 = rn; fe = 0; stalls = 0;
    send(4'h4, 3, 16'h1234, 16'h0001);
    repeat (10) @(negedge clk);
    chk(rsp_ok(r0, 3), "request (type 4): response type 5, same size/PC_ID/SEQ_ID, payload echoed, valid FCS");
    chk(fe == 0, "no FCS error on a good frame");
    chk(stalls > 0, "(sender saw tx_ready back-pressure)");
    chk(!rx_valid, "rx_valid drops after the response FCS word");

    for (int n = 1; n <= 8; n += 7) begin
      r0 = rn;
      send(4'h4, n, 16'hFFFF, 16'(n));
      repeat (14) @(negedge clk);
      chk(rsp_ok(r0, n), $sformatf("%0d-word request answered", n));
    end

    // ---- other message types: no response ----
    r0 = rn;
    for (int t = 0; t < 16; t++) if (t != 4) send(4'(t), 2, 16'h0042, 16'(t));
    repeat (10) @(negedge clk);
    chk(rn == r0 && fe == 0, "message types other than 4 (incl. unknown 8..F) are not answered");

    // ---- FCS errors ----
    r0 = rn; fe = 0;
    send(4'h4, 2, 16'h0007, 16'h0100, 1);
    repeat (10) @(negedge clk);
    chk(fe == 1, "corrupted FCS: one fcs_err pulse");
    chk(rn == r0, "request with a bad FCS is not answered");
    fe = 0;
    send(4'h0, 4, 16'h0008, 16'h0101, 1);
    repeat (4) @(negedge clk);
    chk(fe == 1, "FCS checked on IQ data frames too");
    r0 = rn;
    send(4'h4, 2, 16'h0009, 16'h0102);
    repeat (10) @(negedge clk);
    chk(rsp_ok(r0, 2), "next good request answered after an FCS error");

    // ---- rx back-pressure ----
    r0 = rn;
    rx_ready = 1'b0;
    send(4'h4, 2, 16'h000A, 16'h0200);
    repeat (6) @(negedge clk);
    chk_xfail(rx_valid === 1'b1, "rx_valid asserted without waiting for rx_ready");
    rx_ready = 1'b1;
    // stall the sink on the FCS beat
    k = 0; valid_dropped = 0;
    while (!(rx_valid && rx_data[63:32] == 0 && rn - r0 == 3) && k < 20) begin @(negedge clk); k++; end
    rx_ready = 1'b0;
    repeat (3) @(negedge clk);
    if (!rx_valid) valid_dropped = 1;
    rx_ready = 1'b1;
    repeat (4) @(negedge clk);
    chk_xfail(!valid_dropped && rsp_ok(r0, 2), "FCS beat held while rx_ready is low");

    // ---- request while a response is pending ----
    rx_ready = 1'b0;
    r0 = rn;
    send(4'h4, 1, 16'h000B, 16'h0300);
    send(4'h4, 1, 16'h000C, 16'h0301);
    rx_ready = 1'b1;
    repeat (20) @(negedge clk);
    chk_xfail(rn - r0 == 6, "request received while a response is pending is answered too");

    // ---- zero-length payload ----
    r0 = rn; fe = 0;
    send(4'h4, 0, 16'h000D, 16'h0400);
    repeat (10) @(negedge clk);
    chk_xfail(rn - r0 == 2, "zero-length request is terminated by its FCS word and answered");
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk); rst_n = 1'b1;
    chk(!rx_valid && !fcs_err, "reset clears the response path");
    r0 = rn;
    send(4'h4, 2, 16'h000E, 16'h0500);
    repeat (10) @(negedge clk);
    chk(rsp_ok(r0, 2), "request answered after reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
