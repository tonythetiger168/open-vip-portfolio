// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- eCPRI testbench top with a functional eCPRI endpoint DUT model

`ifndef ECPRI_TB_SV
`define ECPRI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ecpri_defs_pkg::*;
import ecpri_pkg::*;
import ecpri_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ecpri_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  ecpri_endpoint_dut dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual ecpri_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional eCPRI endpoint: accepts the 64-bit stream (with occasional
// backpressure), parses the common header, verifies the CRC-32 FCS
// (flagging fcs_err on mismatch), and answers ECPRI_REQ messages with an
// ECPRI_RSP echo on rx_valid/rx_data.
module ecpri_endpoint_dut (ecpri_if vif);
  import ecpri_defs_pkg::*;

  typedef enum bit [1:0] {EP_IDLE, EP_HEADER, EP_PAYLOAD, EP_FCS} ep_state_e;

  ep_state_e   st;
  bit [3:0]    msg_type;
  bit [15:0]   pc_id, seq_id, plen_bytes;
  bit [63:0]   words[$];
  bit [63:0]   pay[$];
  int unsigned rd_stall;
  bit [63:0]   rsp_hdr;
  bit [63:0]   rsp_q[$];     // response words (header, payload, FCS) of all
                             // answered requests, in order

  // Module-local IEEE 802.3 CRC-32 (LSB-first per byte), equivalent to
  // ecpri_defs_pkg::ecpri_crc32 but expressed over module-scope queues so
  // that no queue-typed function arguments are needed.
  function automatic bit [31:0] crc32_byte(input bit [31:0] crc, input bit [7:0] d);
    bit [31:0] c;
    c = crc ^ d;
    for (int k = 0; k < 8; k++)
      c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    return c;
  endfunction

  function automatic bit [31:0] crc32_word(input bit [31:0] crc, input bit [63:0] v);
    bit [31:0] c;
    c = crc;
    for (int b = 0; b < 8; b++) c = crc32_byte(c, v[b*8 +: 8]);
    return c;
  endfunction

  function automatic bit [31:0] crc32_of_words();
    bit [31:0] c;
    c = 32'hFFFF_FFFF;
    foreach (words[i]) c = crc32_word(c, words[i]);
    return ~c;
  endfunction

  // Receive one complete message (task-style, driven from always block below)
  task automatic rx_word(input bit [63:0] w);
    case (st)
      EP_IDLE: begin
        msg_type   = w[51:48];
        plen_bytes = w[47:32];
        pc_id      = w[31:16];
        seq_id     = w[15:0];
        words.delete();
        pay.delete();
        words.push_back(w);
        st <= (plen_bytes == 0) ? EP_FCS : EP_PAYLOAD;
      end
      EP_PAYLOAD: begin
        words.push_back(w);
        pay.push_back(w);
        if (pay.size() == (plen_bytes + 7) / 8) st <= EP_FCS;
      end
      EP_FCS: begin
        if (crc32_of_words() !== w[31:0]) begin
          vif.fcs_err <= 1'b1;
          `uvm_info("DUT", "endpoint detected FCS mismatch", UVM_HIGH)
        end
        // REQ -> RSP response (only for FCS-clean requests); queued behind
        // any response still being sent
        if (msg_type == ECPRI_REQ && crc32_of_words() === w[31:0]) begin
          bit [31:0] ctmp;
          rsp_hdr = {ECPRI_REV, 4'h0, 4'h0, ECPRI_RSP, plen_bytes, pc_id, seq_id};
          ctmp = crc32_word(32'hFFFF_FFFF, rsp_hdr);
          rsp_q.push_back(rsp_hdr);
          foreach (pay[i]) begin
            rsp_q.push_back(pay[i]);
            ctmp = crc32_word(ctmp, pay[i]);
          end
          rsp_q.push_back({32'h0, ~ctmp});
        end
        st <= EP_IDLE;
      end
      default: st <= EP_IDLE;
    endcase
  endtask

  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      st          <= EP_IDLE;
      vif.tx_ready <= 1'b1;
      vif.rx_valid <= 1'b0;
      vif.rx_data  <= 64'h0;
      vif.fcs_err  <= 1'b0;
      rd_stall    <= 0;
      rsp_q.delete();
    end else begin
      vif.fcs_err <= 1'b0;   // single-cycle flag
      // Backpressure: stall one cycle out of every five
      rd_stall <= (rd_stall == 4) ? 0 : rd_stall + 1;
      vif.tx_ready <= (rd_stall != 4);

      // Response channel (valid/ready): rx_valid does not wait for
      // rx_ready, and a word is held until it is taken
      if (!vif.rx_valid || vif.rx_ready) begin
        if (rsp_q.size() > 0) begin
          vif.rx_valid <= 1'b1;
          vif.rx_data  <= rsp_q.pop_front();
        end else begin
          vif.rx_valid <= 1'b0;
        end
      end

      // Receive path
      if (vif.tx_valid && vif.tx_ready) rx_word(vif.tx_data);
    end
  end
endmodule
`endif
