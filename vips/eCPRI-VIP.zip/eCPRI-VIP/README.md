# eCPRI — eCPRI over Ethernet UVM VIP

Open-source UVM verification IP template for **eCPRI over Ethernet** (Telecom).

## Contents

| Path | Description |
|------|-------------|
| `ecpri/ecpri_if.sv` | 64-bit valid/ready stream interface + transmit FSM state enum |
| `ecpri/ecpri_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `ecpri/sva/ecpri_compliance_checker.sv` | SVA compliance checker (L1=4, L2=4, L3=4, L4=5) |
| `ecpri/vip/ecpri/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/ecpri_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional eCPRI endpoint DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **eCPRI common header**: 64-bit header word (revision / msg_type / payload-size / pc_id / seq_id) followed by payload words and a trailing CRC-32 FCS word (IEEE 802.3, real `ecpri_crc32` in `ecpri_defs_pkg`)
- **Valid/ready stream driver**: serializes header -> payload -> FCS honoring tx_ready backpressure (data held stable during stalls); broadcasts expected messages on `drv_ap`
- **Waveform-decoding monitor**: reconstructs messages from the stream, recomputes the CRC-32 and flags FCS mismatches and unknown message types
- **Message types**: IQ_DATA / BIT_SEQ / RTC_CMD / GEN_DATA / REQ / RSP / SYNC / EVT enum; error injection of FCS corruption and reserved msg_type values
- **Functional DUT model**: eCPRI endpoint with periodic backpressure, header parsing, FCS verification (fcs_err flag), and REQ -> RSP payload-echo responses
- **End-to-end scoreboard**: expected vs observed messages (msg_type / pc_id / seq_id / payload words); observed FCS-error flag must equal the injected-error intent
- **Directed sequence library**: iq-data / cmd / req-rsp / sync / max-payload / back-to-back / error-inject / reset + random + regression mix
- **Functional coverage**: msg_type x payload-length cross, pc_id/seq_id corners, transmit FSM state + message sequence transitions, FCS-error x unknown-type error cross
- **SVA L4**: common-header fixed format, payload length vs header size field, tx_data stable during backpressure, fcs_err phase legality, FCS-error cover
