// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ocp_env.sv -- OCP verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import ocp_defs_pkg::*;
  import ocp_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: match_cnt driver-issued commands against
  // monitor-decoded transactions and checks read data against a shadow
  // memory updated by every accepted write (WR -> RD data consistency).
  class ocp_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(ocp_scoreboard)
    uvm_analysis_imp_exp #(ocp_transaction, ocp_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(ocp_transaction, ocp_scoreboard) obs_ap;

    ocp_transaction exp_q[$], obs_q[$];
    bit [31:0] shadow_mem [bit [31:0]];
    int unsigned match_cnt = 0, mismatches = 0, rd_checks = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(ocp_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(ocp_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        ocp_transaction e = exp_q.pop_front();
        ocp_transaction o = obs_q.pop_front();
        if (e.cmd != o.cmd || e.addr != o.addr ||
            (e.cmd == ocp_transaction::OCP_CMD_WR && e.data != o.data) ||
            e.sresp != o.sresp) begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
          continue;
        end
        if (o.cmd == ocp_transaction::OCP_CMD_WR &&
            o.sresp == ocp_transaction::OCP_RESP_DVA)
          shadow_mem[o.addr] = o.data;
        if (o.cmd == ocp_transaction::OCP_CMD_RD &&
            o.sresp == ocp_transaction::OCP_RESP_DVA && shadow_mem.exists(o.addr)) begin
          rd_checks++;
          if (o.rdata !== shadow_mem[o.addr]) begin
            mismatches++;
            `uvm_error("SB", $sformatf(
                       "read data mismatch addr=0x%08h exp=0x%08h obs=0x%08h",
                       o.addr, shadow_mem[o.addr], o.rdata))
            continue;
          end
        end
        match_cnt++;
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("ocp scoreboard: matches=%0d mismatches=%0d rd_data_checks=%0d",
                match_cnt, mismatches, rd_checks), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class ocp_env extends uvm_env;
    `uvm_component_utils(ocp_env)
    ocp_agent      agt;
    ocp_scoreboard sb;
    ocp_checker    chk;
    ocp_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = ocp_agent::type_id::create("agt", this);
      sb  = ocp_scoreboard::type_id::create("sb", this);
      chk = ocp_checker::type_id::create("chk", this);
      cov = ocp_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
