// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//============================================================================
// UVM RAL model of the top_tb OCP slave (ocp_slave_model, tb/top_tb.sv),
// 32-bit data, word addressed, 4 KB device space:
//   0x000..0x03C  REG[0..15]  32-bit RW, reset 0
//   0x040..0xEFC  MEM         944 x 32-bit RW memory (uvm_mem_walk_seq)
//   0xF00         ERR_PROBE   error region (maddr[11:8] == 0xF, SResp=ERR);
//                             excluded from the built-in register sequences,
//                             used to check that an error response reaches
//                             the RAL as UVM_NOT_OK
// The slave stores every non-error address in an associative memory that
// reads 0 until written, so all registers and MEM words reset to 0.
// Included inside env_pkg (env/ocp_env.sv).
//============================================================================
`ifndef OCP_REG_MODEL_SVH
`define OCP_REG_MODEL_SVH

class ocp_data_reg extends uvm_reg;
  `uvm_object_utils(ocp_data_reg)
  rand uvm_reg_field DATA;

  function new(string name = "ocp_data_reg");
    super.new(name, 32, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    DATA = uvm_reg_field::type_id::create("DATA");
    //            parent size lsb access volatile reset has_reset rand individually_accessible
    DATA.configure(this, 32,  0,  "RW",  0,       32'h0, 1,        1,   1);
  endfunction
endclass

class ocp_reg_block extends uvm_reg_block;
  `uvm_object_utils(ocp_reg_block)
  localparam int N_REGS   = 16;
  localparam int N_WORDS  = 'hF00 / 4;        // everything below the error region
  localparam int ERR_ADDR = 'hF00;
  rand ocp_data_reg REG[N_REGS];
  uvm_mem           MEM;
  ocp_data_reg      ERR_PROBE;
  uvm_reg_map       ocp_map;

  function new(string name = "ocp_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    ocp_map = create_map("ocp_map", 'h0, 4, UVM_LITTLE_ENDIAN, 1);
    default_map = ocp_map;
    foreach (REG[i]) begin
      REG[i] = ocp_data_reg::type_id::create($sformatf("REG%0d", i));
      REG[i].configure(this, null, "");
      REG[i].build();
      ocp_map.add_reg(REG[i], i * 4, "RW");
    end
    MEM = new("MEM", N_WORDS - N_REGS, 32, "RW", UVM_NO_COVERAGE);
    MEM.configure(this, "");
    ocp_map.add_mem(MEM, N_REGS * 4, "RW");
    ERR_PROBE = ocp_data_reg::type_id::create("ERR_PROBE");
    ERR_PROBE.configure(this, null, "");
    ERR_PROBE.build();
    ocp_map.add_reg(ERR_PROBE, ERR_ADDR, "RW");
    uvm_resource_db#(bit)::set({"REG::", ERR_PROBE.get_full_name()}, "NO_REG_TESTS", 1, this);
  endfunction
endclass
`endif
