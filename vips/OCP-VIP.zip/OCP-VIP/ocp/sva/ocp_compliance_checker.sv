// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ocp_compliance_checker.sv -- OCP-IP Open Core Protocol SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules, L4 = OCP-specific rules

`ifndef OCP_COMPLIANCE_CHECKER_SV
`define OCP_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import ocp_defs_pkg::*;

module ocp_compliance_checker
(
  input logic mclk,
  input logic mreset_n,
  input ocp_state_e state,
  input logic [2:0] mcmd,
  input logic [31:0] maddr,
  input logic [31:0] mdata,
  input logic scmdaccept,
  input logic [1:0] sresp,
  input logic [31:0] sdata
);

  localparam logic [2:0] CMD_WR = 3'b001, CMD_RD = 3'b010;
  localparam logic [1:0] RESP_NULL = 2'b00, RESP_DVA = 2'b01;

  // Outstanding-command counter and shadow memory for L4 checks
  int unsigned outstanding;
  bit [31:0]   sb_mem [bit [31:0]];
  bit          exp_v;
  bit [31:0]   exp_d;

  always @(posedge mclk or negedge mreset_n) begin
    if (!mreset_n) begin
      outstanding <= 0;
      exp_v       <= 0;
      exp_d       <= '0;
    end else begin
      if (mcmd != 3'b000 && scmdaccept) outstanding <= outstanding + 1;
      if (sresp != RESP_NULL)           outstanding <= outstanding - 1;
      // Shadow memory: track accepted writes outside the error region
      if (mcmd == CMD_WR && scmdaccept && maddr[11:8] != 4'hF)
        sb_mem[maddr] = mdata;
      // Expectation for the next DVA read response
      if (mcmd == CMD_RD && scmdaccept && sb_mem.exists(maddr) && maddr[11:8] != 4'hF) begin
        exp_v <= 1;
        exp_d <= sb_mem[maddr];
      end else if (sresp != RESP_NULL) begin
        exp_v <= 0;
      end
    end
  end

  // ---------------- L1: signal sanity (4) ----------------
  a_ocp_l1_clk   : assert property (@(posedge mclk) disable iff (!mreset_n) !$isunknown(mclk))
    else `uvm_error("SVA_L1", "ocp: clock unknown")
  a_ocp_l1_rst   : assert property (@(posedge mclk) !$isunknown(mreset_n))
    else `uvm_error("SVA_L1", "ocp: reset unknown")
  a_ocp_l1_state : assert property (@(posedge mclk) disable iff (!mreset_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "ocp: state unknown")
  a_ocp_l1_valid : assert property (@(posedge mclk) disable iff (!mreset_n)
    state inside {IDLE, WRITE, READ, WAIT_RESP, ERROR_RESP})
    else `uvm_error("SVA_L1", "ocp: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_ocp_trans_idle : assert property (@(posedge mclk) disable iff (!mreset_n)
    state == IDLE |=> state inside {IDLE, WRITE})
    else `uvm_error("SVA_L2", "ocp: illegal transition from IDLE")

  // L2-2: legal FSM transition from WRITE
  a_ocp_trans_write : assert property (@(posedge mclk) disable iff (!mreset_n)
    state == WRITE |=> state inside {WRITE, READ})
    else `uvm_error("SVA_L2", "ocp: illegal transition from WRITE")

  // L2-3: legal FSM transition from READ
  a_ocp_trans_read : assert property (@(posedge mclk) disable iff (!mreset_n)
    state == READ |=> state inside {READ, WAIT_RESP})
    else `uvm_error("SVA_L2", "ocp: illegal transition from READ")

  // L2-4: legal FSM transition from WAIT_RESP
  a_ocp_trans_wait_resp : assert property (@(posedge mclk) disable iff (!mreset_n)
    state == WAIT_RESP |=> state inside {WAIT_RESP, ERROR_RESP})
    else `uvm_error("SVA_L2", "ocp: illegal transition from WAIT_RESP")

  // L2-5: legal FSM transition from ERROR_RESP
  a_ocp_trans_error_resp : assert property (@(posedge mclk) disable iff (!mreset_n)
    state == ERROR_RESP |=> state inside {ERROR_RESP, IDLE})
    else `uvm_error("SVA_L2", "ocp: illegal transition from ERROR_RESP")

  // ---------------- L3: protocol rules (4) ----------------
  a_ocp_l3_reset_idle : assert property (@(posedge mclk)
    $fell(mreset_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "ocp: state not IDLE during reset")
  a_ocp_l3_no_stuck   : assert property (@(posedge mclk) disable iff (!mreset_n)
    state == ERROR_RESP |-> ##[1:8] (state != ERROR_RESP))
    else `uvm_error("SVA_L3", "ocp: stuck in ERROR_RESP")
  a_ocp_l3_full_cycle : cover property (@(posedge mclk) disable iff (!mreset_n)
    state == IDLE ##1 state == WRITE);
  a_ocp_l3_back_idle  : cover property (@(posedge mclk) disable iff (!mreset_n)
    state == ERROR_RESP ##1 state == IDLE);

  // ---------------- L4: OCP protocol-specific rules (4) ----------------
  // L4-1: command/address must be held stable until the slave accepts them
  a_ocp_l4_cmd_held : assert property (@(posedge mclk) disable iff (!mreset_n)
    (mcmd != 3'b000 && !scmdaccept) |=>
    (mcmd == $past(mcmd) && maddr == $past(maddr) &&
     (mcmd != CMD_WR || mdata == $past(mdata))))
    else `uvm_error("SVA_L4", "ocp: command not held until SCmdAccept")

  // L4-2: SResp may only be returned while a command is outstanding
  a_ocp_l4_resp_outstanding : assert property (@(posedge mclk) disable iff (!mreset_n)
    (sresp != RESP_NULL) |-> (outstanding > 0))
    else `uvm_error("SVA_L4", "ocp: SResp with no outstanding command")

  // L4-3: addresses must be word aligned
  a_ocp_l4_addr_aligned : assert property (@(posedge mclk) disable iff (!mreset_n)
    (mcmd == CMD_WR || mcmd == CMD_RD) |-> (maddr[1:0] == 2'b00))
    else `uvm_error("SVA_L4", "ocp: unaligned address")

  // L4-4: a read to a previously written address returns the written data
  a_ocp_l4_wr_rd_consistent : assert property (@(posedge mclk) disable iff (!mreset_n)
    (sresp == RESP_DVA && exp_v) |-> (sdata == exp_d))
    else `uvm_error("SVA_L4", "ocp: WR->RD data inconsistency")

endmodule
`endif
