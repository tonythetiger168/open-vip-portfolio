// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ocp_coverage.svh -- OCP functional coverage

`ifndef OCP_COVERAGE_SVH
`define OCP_COVERAGE_SVH

class ocp_coverage extends uvm_subscriber #(ocp_transaction);
  `uvm_component_utils(ocp_coverage)

  ocp_transaction tr;
  ocp_state_e cur_state;
  virtual ocp_if vif;

  covergroup cg_protocol;
    cp_cmd : coverpoint tr.cmd {
      bins wr = {ocp_transaction::OCP_CMD_WR};
      bins rd = {ocp_transaction::OCP_CMD_RD};
    }
    cp_addr : coverpoint tr.addr[11:2] {
      bins low  = {[10'h000 : 10'h0FF]};
      bins mid  = {[10'h100 : 10'h2FF]};
      bins high = {[10'h300 : 10'h3BF]};
      bins err_region = {[10'h3C0 : 10'h3FF]};  // addr[11:8] == 4'hF
    }
    cp_sresp : coverpoint tr.sresp {
      bins dva = {ocp_transaction::OCP_RESP_DVA};
      bins err = {ocp_transaction::OCP_RESP_ERR};
    }
    cp_latency : coverpoint tr.resp_latency {
      bins fast = {[1:2]};
      bins mid  = {[3:4]};
      bins slow = {[5:8]};
    }
    cx_cmd_resp : cross cp_cmd, cp_sresp;
  endgroup

  covergroup cg_fsm with function sample(ocp_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, WRITE, READ, WAIT_RESP, ERROR_RESP};
    }
    cp_trans : coverpoint s {
      bins wr_seq  = (IDLE => WRITE => WAIT_RESP => IDLE);
      bins rd_seq  = (IDLE => READ => WAIT_RESP => IDLE);
      bins err_seq = (WAIT_RESP => ERROR_RESP => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.error_inject {
      bins legal = {0};
      bins err   = {1};
    }
    cp_err_resp : coverpoint tr.sresp iff (tr.error_inject) {
      bins err = {ocp_transaction::OCP_RESP_ERR};
    }
    cp_data_corner : coverpoint tr.data {
      bins zero = {32'h0};
      bins ones = {32'hFFFF_FFFF};
      bins misc = default;
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual ocp_if)::get(this, "", "vif", vif));
  endfunction

  function void write(ocp_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction

  // Sample the link FSM every cycle so all states/transitions are observable
  task run_phase(uvm_phase phase);
    if (vif == null) begin
      `uvm_warning("COV", "ocp coverage: no vif, FSM coverage disabled")
      return;
    end
    forever begin
      @(posedge vif.mclk);
      cur_state = vif.state;
      cg_fsm.sample(cur_state);
    end
  endtask
endclass
`endif
