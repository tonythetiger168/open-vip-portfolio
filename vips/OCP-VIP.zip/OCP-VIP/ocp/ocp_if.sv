// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ocp_if.sv -- OCP-IP Open Core Protocol interface
// Master command phase (MCmd/MAddr/MData) with slave accept backpressure
// (SCmdAccept), followed by the response phase (SResp/SData).
// MCmd : 0=IDLE 1=WR 2=RD ; SResp : 0=NULL 1=DVA 2=FAIL 3=ERR

interface ocp_if (input logic mclk);
  import ocp_defs_pkg::ocp_state_e;

  logic        mreset_n;
  // Command phase (master -> slave)
  logic [2:0]  mcmd;
  logic [31:0] maddr;
  logic [31:0] mdata;
  // Slave accept backpressure
  logic        scmdaccept;
  // Response phase (slave -> master)
  logic [1:0]  sresp;
  logic [31:0] sdata;

  ocp_state_e state;

  modport MASTER (input  mclk, mreset_n, scmdaccept, sresp, sdata,
                  output mcmd, maddr, mdata, state);
  modport SLAVE  (input  mclk, mreset_n, mcmd, maddr, mdata,
                  output scmdaccept, sresp, sdata);
  modport MON    (input  mclk, mreset_n, mcmd, maddr, mdata,
                        scmdaccept, sresp, sdata, state);

  clocking drv_cb @(posedge mclk);
    input  mreset_n, scmdaccept, sresp, sdata;
    output mcmd, maddr, mdata;
  endclocking

  clocking mon_cb @(posedge mclk);
    input mreset_n, mcmd, maddr, mdata, scmdaccept, sresp, sdata, state;
  endclocking
endinterface
