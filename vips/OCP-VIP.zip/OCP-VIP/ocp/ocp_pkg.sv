// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ocp_pkg.sv -- OCP-IP Open Core Protocol UVM VIP package

package ocp_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ocp_defs_pkg::*;
  export ocp_defs_pkg::*;

  `include "ocp_transaction.svh"
  `include "ocp_config.svh"
  `include "ocp_sequencer.svh"
  `include "ocp_driver.svh"
  `include "ocp_monitor.svh"
  `include "ocp_agent.svh"
  `include "ocp_sequences.svh"
  `include "ocp_checker.svh"
  `include "ocp_coverage.svh"
endpackage
