// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ocp_transaction.svh -- OCP transaction (command phase + response phase)

`ifndef OCP_TRANSACTION_SVH
`define OCP_TRANSACTION_SVH

class ocp_transaction extends uvm_sequence_item;

  typedef enum bit [2:0] {OCP_CMD_IDLE = 3'b000,
                          OCP_CMD_WR   = 3'b001,
                          OCP_CMD_RD   = 3'b010} ocp_cmd_e;
  typedef enum bit [1:0] {OCP_RESP_NULL = 2'b00,
                          OCP_RESP_DVA  = 2'b01,
                          OCP_RESP_FAIL = 2'b10,
                          OCP_RESP_ERR  = 2'b11} ocp_resp_e;

  rand ocp_cmd_e   cmd;
  rand bit [31:0]  addr;
  rand bit [31:0]  data;
  rand bit         error_inject;   // target the slave error region -> SResp=ERR

  int unsigned     resp_latency;   // monitor: cycles from accept to sresp
  ocp_resp_e       sresp;          // driver/monitor: observed response
  bit [31:0]       rdata;          // driver/monitor: read data returned

  constraint c_cmd  { cmd inside {OCP_CMD_WR, OCP_CMD_RD}; }
  constraint c_addr { addr[1:0] == 2'b00;        // word aligned
                      addr[31:12] == 20'h0; }    // 4 KB device space
  constraint c_err  { error_inject dist {0 := 7, 1 := 3}; }

  `uvm_object_utils_begin(ocp_transaction)
    `uvm_field_enum(ocp_cmd_e, cmd, UVM_ALL_ON)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(error_inject, UVM_ALL_ON)
    `uvm_field_enum(ocp_resp_e, sresp, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(resp_latency, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "ocp_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ocp_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    ok &= comparer.compare_field("addr", addr, t.addr, 32);
    if (cmd == OCP_CMD_WR)
      ok &= comparer.compare_field("data", data, t.data, 32);
    return ok;
  endfunction

  function string convert2string();
    return $sformatf("OCP %s addr=0x%08h data=0x%08h sresp=%0d rdata=0x%08h lat=%0d err=%0b",
                     cmd == OCP_CMD_RD ? "RD" : "WR", addr, data,
                     sresp, rdata, resp_latency, error_inject);
  endfunction
endclass
`endif
