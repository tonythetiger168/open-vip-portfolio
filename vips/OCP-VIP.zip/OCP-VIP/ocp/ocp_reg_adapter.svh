// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ocp_reg_adapter.svh -- UVM RAL adapter for the OCP master agent
//   reg2bus: one uvm_reg_bus_op -> one ocp_transaction (WR / RD, no error injection)
//   bus2reg: ocp_transaction (driver-completed or monitor-observed) -> uvm_reg_bus_op
// The driver completes the request item in place (sresp and rdata are written
// back) and sends no separate response, so provides_responses = 0. OCP has no
// byte enables on this interface (MByteEn is not modelled), so every access
// is a full 32-bit word. SResp=DVA maps to UVM_IS_OK, anything else
// (ERR / FAIL) to UVM_NOT_OK.

`ifndef OCP_REG_ADAPTER_SVH
`define OCP_REG_ADAPTER_SVH

class ocp_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(ocp_reg_adapter)

  function new(string name = "ocp_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 0;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    ocp_transaction tr = ocp_transaction::type_id::create("ral_item");
    tr.cmd          = (rw.kind == UVM_WRITE) ? ocp_transaction::OCP_CMD_WR
                                             : ocp_transaction::OCP_CMD_RD;
    tr.addr         = rw.addr[31:0];
    tr.data         = (rw.kind == UVM_WRITE) ? rw.data[31:0] : 32'h0;
    tr.error_inject = 1'b0;
    return tr;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    ocp_transaction tr;
    if (!$cast(tr, bus_item)) begin
      `uvm_fatal("OCP_RAL", "bus2reg: item is not an ocp_transaction")
      return;
    end
    rw.kind    = (tr.cmd == ocp_transaction::OCP_CMD_WR) ? UVM_WRITE : UVM_READ;
    rw.addr    = tr.addr;
    rw.data    = (tr.cmd == ocp_transaction::OCP_CMD_WR) ? tr.data : tr.rdata;
    rw.n_bits  = 32;
    rw.byte_en = '1;
    rw.status  = (tr.sresp == ocp_transaction::OCP_RESP_DVA) ? UVM_IS_OK : UVM_NOT_OK;
  endfunction
endclass
`endif
