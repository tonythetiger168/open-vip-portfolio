// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ocp_sequences.svh -- OCP sequence library

`ifndef OCP_SEQUENCES_SVH
`define OCP_SEQUENCES_SVH

class ocp_base_sequence extends uvm_sequence #(ocp_transaction);
  `uvm_object_utils(ocp_base_sequence)
  int num_txns = 20;
  function new(string name = "ocp_base_sequence"); super.new(name); endfunction
  task body();
    ocp_transaction tr;
    repeat (num_txns) begin
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: posted writes across the whole device space
class ocp_write_seq extends ocp_base_sequence;
  `uvm_object_utils(ocp_write_seq)

  function new(string name = "ocp_write_seq"); super.new(name); endfunction

  task body();
    ocp_transaction tr;
    repeat (num_txns) begin
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == OCP_CMD_WR; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: reads across the device space
class ocp_read_seq extends ocp_base_sequence;
  `uvm_object_utils(ocp_read_seq)

  function new(string name = "ocp_read_seq"); super.new(name); endfunction

  task body();
    ocp_transaction tr;
    repeat (num_txns) begin
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == OCP_CMD_RD; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: write-then-read to the same address (data consistency)
class ocp_wr_rd_same_addr_seq extends ocp_base_sequence;
  `uvm_object_utils(ocp_wr_rd_same_addr_seq)

  function new(string name = "ocp_wr_rd_same_addr_seq"); super.new(name); endfunction

  rand bit [31:0] target = 32'h0000_0040;
  constraint c_t { target[1:0] == 2'b00; target[31:12] == 20'h0; target[11:8] != 4'hF; }
  task body();
    ocp_transaction tr;
    repeat (num_txns / 2) begin
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == OCP_CMD_WR; addr == target; error_inject == 0; });
      finish_item(tr);
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == OCP_CMD_RD; addr == target; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back command phase stress (slave backpressure)
class ocp_backpressure_seq extends ocp_base_sequence;
  `uvm_object_utils(ocp_backpressure_seq)

  function new(string name = "ocp_backpressure_seq"); super.new(name); endfunction

  task body();
    ocp_transaction tr;
    num_txns = 30;
    repeat (num_txns) begin
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 0; addr[11:8] != 4'hF; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: address boundary sweep (first / last / aligned corners)
class ocp_addr_sweep_seq extends ocp_base_sequence;
  `uvm_object_utils(ocp_addr_sweep_seq)

  function new(string name = "ocp_addr_sweep_seq"); super.new(name); endfunction

  task body();
    ocp_transaction tr;
    bit [31:0] addrs[$] = '{32'h000, 32'h004, 32'h7FC, 32'h800, 32'hEFC};
    foreach (addrs[i]) begin
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { addr == addrs[i]; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: write data corner values then read them back
class ocp_data_corner_seq extends ocp_base_sequence;
  `uvm_object_utils(ocp_data_corner_seq)

  function new(string name = "ocp_data_corner_seq"); super.new(name); endfunction

  task body();
    ocp_transaction tr;
    bit [31:0] corners[$] = '{32'h0, 32'hFFFF_FFFF, 32'hAAAA_AAAA, 32'h5555_5555};
    foreach (corners[i]) begin
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == OCP_CMD_WR; data == corners[i];
                                  addr == 32'h80; error_inject == 0; });
      finish_item(tr);
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == OCP_CMD_RD; addr == 32'h80;
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: access the slave error region (addr[11:8]=0xF) -> SResp=ERR
class ocp_error_inject_seq extends ocp_base_sequence;
  `uvm_object_utils(ocp_error_inject_seq)

  function new(string name = "ocp_error_inject_seq"); super.new(name); endfunction

  task body();
    ocp_transaction tr;
    repeat (6) begin
      tr = ocp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 1; addr[11:8] == 4'hF; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single transfer right after reset release
class ocp_reset_seq extends ocp_base_sequence;
  `uvm_object_utils(ocp_reset_seq)

  function new(string name = "ocp_reset_seq"); super.new(name); endfunction

  task body();
    ocp_transaction tr = ocp_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { cmd == OCP_CMD_WR; addr == 32'h0; error_inject == 0; });
    finish_item(tr);
  endtask
endclass

class ocp_random_sequence extends ocp_base_sequence;
  `uvm_object_utils(ocp_random_sequence)
  function new(string name = "ocp_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class ocp_regression_sequence extends ocp_base_sequence;
  `uvm_object_utils(ocp_regression_sequence)
  function new(string name = "ocp_regression_sequence"); super.new(name); endfunction
  task body();
    ocp_write_seq          wr  = ocp_write_seq::type_id::create("wr");
    ocp_read_seq           rd  = ocp_read_seq::type_id::create("rd");
    ocp_wr_rd_same_addr_seq wa = ocp_wr_rd_same_addr_seq::type_id::create("wa");
    ocp_backpressure_seq   bp  = ocp_backpressure_seq::type_id::create("bp");
    ocp_addr_sweep_seq     sw  = ocp_addr_sweep_seq::type_id::create("sw");
    ocp_data_corner_seq    dc  = ocp_data_corner_seq::type_id::create("dc");
    ocp_error_inject_seq   err = ocp_error_inject_seq::type_id::create("err");
    wr.num_txns = 20; rd.num_txns = 20; wa.num_txns = 10;
    wa.randomize();
    wr.start(m_sequencer); rd.start(m_sequencer); wa.start(m_sequencer);
    bp.start(m_sequencer); sw.start(m_sequencer); dc.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
