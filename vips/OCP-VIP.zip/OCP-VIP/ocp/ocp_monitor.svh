// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ocp_monitor.svh -- OCP monitor: decodes command accepts and their
// responses from the OCP waveform, measuring response latency.

`ifndef OCP_MONITOR_SVH
`define OCP_MONITOR_SVH

class ocp_monitor extends uvm_monitor;
  `uvm_component_utils(ocp_monitor)
  virtual ocp_if vif;
  uvm_analysis_port #(ocp_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned err_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ocp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ocp virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    ocp_transaction tr;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.mreset_n !== 1'b1) continue;
      // Command accepted -> start of a transaction
      if (vif.mon_cb.mcmd != ocp_transaction::OCP_CMD_IDLE && vif.mon_cb.scmdaccept) begin
        tr = ocp_transaction::type_id::create("tr");
        tr.cmd  = ocp_transaction::ocp_cmd_e'(vif.mon_cb.mcmd);
        tr.addr = vif.mon_cb.maddr;
        tr.data = vif.mon_cb.mdata;
        tr.resp_latency = 0;
        // Wait for the response phase, counting cycles
        do begin
          @(vif.mon_cb);
          tr.resp_latency++;
          if (tr.resp_latency > 1000) `uvm_fatal("MON", "ocp response timeout")
        end while (vif.mon_cb.sresp == ocp_transaction::OCP_RESP_NULL);
        tr.sresp = ocp_transaction::ocp_resp_e'(vif.mon_cb.sresp);
        if (tr.cmd == ocp_transaction::OCP_CMD_RD &&
            tr.sresp == ocp_transaction::OCP_RESP_DVA)
          tr.rdata = vif.mon_cb.sdata;
        if (tr.sresp == ocp_transaction::OCP_RESP_ERR) begin
          tr.error_inject = 1;
          err_count++;
        end
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("ocp monitor observed %0d transactions (%0d error responses)",
              txn_count, err_count), UVM_LOW)
  endfunction
endclass
`endif
