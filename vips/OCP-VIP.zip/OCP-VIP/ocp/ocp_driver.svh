// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ocp_driver.svh -- OCP master driver
// Holds MCmd/MAddr/MData until SCmdAccept, then waits for SResp/SData.

`ifndef OCP_DRIVER_SVH
`define OCP_DRIVER_SVH

class ocp_driver extends uvm_driver #(ocp_transaction);
  `uvm_component_utils(ocp_driver)
  virtual ocp_if vif;
  ocp_config cfg;
  uvm_analysis_port #(ocp_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ocp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ocp virtual interface not set")
  endfunction

  task drive_cmd(ocp_transaction tr);
    int unsigned tmo = 0;
    `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
    // Command phase: hold the command stable until the slave accepts it
    vif.state = (tr.cmd == ocp_transaction::OCP_CMD_WR)
                ? ocp_defs_pkg::WRITE : ocp_defs_pkg::READ;
    vif.drv_cb.mcmd  <= tr.cmd;
    vif.drv_cb.maddr <= tr.addr;
    vif.drv_cb.mdata <= tr.data;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "ocp command accept timeout")
    end while (!vif.drv_cb.scmdaccept);
    vif.drv_cb.mcmd <= ocp_transaction::OCP_CMD_IDLE;
    // Response phase: wait for SResp (DVA / ERR), capture read data
    vif.state = ocp_defs_pkg::WAIT_RESP;
    tmo = 0;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "ocp response timeout")
    end while (vif.drv_cb.sresp == ocp_transaction::OCP_RESP_NULL);
    tr.sresp = ocp_transaction::ocp_resp_e'(vif.drv_cb.sresp);
    if (tr.cmd == ocp_transaction::OCP_CMD_RD && tr.sresp == ocp_transaction::OCP_RESP_DVA)
      tr.rdata = vif.drv_cb.sdata;
    if (tr.sresp == ocp_transaction::OCP_RESP_ERR) begin
      vif.state = ocp_defs_pkg::ERROR_RESP;
      `uvm_info("DRV", $sformatf("OCP error response on addr=0x%08h", tr.addr), UVM_MEDIUM)
    end
    @(vif.drv_cb);
    vif.state = ocp_defs_pkg::IDLE;
  endtask

  task run_phase(uvm_phase phase);
    ocp_transaction tr;
    vif.drv_cb.mcmd  <= ocp_transaction::OCP_CMD_IDLE;
    vif.drv_cb.maddr <= '0;
    vif.drv_cb.mdata <= '0;
    vif.state = ocp_defs_pkg::IDLE;
    wait (vif.mreset_n === 1'b1);
    repeat (2) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(tr);
      drive_cmd(tr);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
