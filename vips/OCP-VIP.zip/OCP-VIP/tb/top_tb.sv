// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- OCP testbench top with a functional OCP slave DUT model

`ifndef OCP_TB_SV
`define OCP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ocp_defs_pkg::*;
import ocp_pkg::*;
import ocp_test_pkg::*;

module top_tb;
  logic mclk = 0;
  always #5ns mclk = ~mclk;

  ocp_if vif(mclk);

  initial begin
    vif.mreset_n = 0;
    #100ns;
    vif.mreset_n = 1;
  end

  ocp_slave_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual ocp_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional OCP slave: random SCmdAccept backpressure (~75%), single
// outstanding command, response delayed 1-4 cycles, small associative
// memory for WR/RD, SResp=ERR for the error region (addr[11:8] == 0xF).
module ocp_slave_model (ocp_if vif);
  localparam logic [2:0] CMD_WR = 3'b001, CMD_RD = 3'b010;
  localparam logic [1:0] RESP_NULL = 2'b00, RESP_DVA = 2'b01, RESP_ERR = 2'b11;

  bit [31:0]  mem [bit [31:0]];
  bit         pend;
  bit [2:0]   pend_cmd;
  bit [31:0]  pend_addr, pend_wdata;
  int unsigned rsp_timer;

  initial begin
    vif.scmdaccept = 0;
    vif.sresp      = RESP_NULL;
    vif.sdata      = '0;
    pend           = 0;
    rsp_timer      = 0;
  end

  always_ff @(posedge vif.mclk or negedge vif.mreset_n) begin
    if (!vif.mreset_n) begin
      vif.scmdaccept <= 0;
      vif.sresp      <= RESP_NULL;
      vif.sdata      <= '0;
      pend           <= 0;
      rsp_timer      <= 0;
    end else begin
      // Backpressure: accept ~75% of cycles while no command is outstanding
      vif.scmdaccept <= (vif.mcmd != 3'b000) && !pend && ($urandom_range(3) != 0);
      vif.sresp      <= RESP_NULL;

      // Command accept: latch and start the response timer
      if (vif.mcmd != 3'b000 && vif.scmdaccept) begin
        pend       <= 1;
        pend_cmd   <= vif.mcmd;
        pend_addr  <= vif.maddr;
        pend_wdata <= vif.mdata;
        rsp_timer  <= $urandom_range(1, 4);
      end

      // Response phase: 1-4 cycle latency
      if (pend) begin
        if (rsp_timer > 1) begin
          rsp_timer <= rsp_timer - 1;
        end else begin
          pend <= 0;
          if (pend_addr[11:8] == 4'hF) begin
            vif.sresp <= RESP_ERR;        // error-injection region
          end else begin
            vif.sresp <= RESP_DVA;
            if (pend_cmd == CMD_WR) begin
              mem[pend_addr] = pend_wdata;
            end else begin
              vif.sdata <= mem.exists(pend_addr) ? mem[pend_addr] : 32'h0;
            end
          end
        end
      end
    end
  end
endmodule
`endif
