// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_ocp_tb.sv -- self-checking functional test for the OCP slave model
// (ocp_slave_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py OCP-VIP
//
// Model contract (from tb/top_tb.sv), OCP 2.x basic signals:
//   MCmd (WR=1, RD=2) is held until SCmdAccept (randomly throttled, low while
//   a request is outstanding). After 1..4 clocks a one-clock SResp returns
//   DVA (with SData for reads) or ERR for MAddr[11:8] == 0xF. Unwritten
//   addresses read 0.

module func_ocp_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [2:0] IDLE = 3'b000, WR = 3'b001, RD = 3'b010;
  localparam bit [1:0] NULL = 2'b00, DVA = 2'b01, ERR = 2'b11;
  int checks = 0, fails = 0, xfails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [2:0]  mcmd = IDLE;
  logic [31:0] maddr = '0, mdata = '0;
  wire         accept;
  wire  [1:0]  sresp;
  wire  [31:0] sdata;

  always #5 clk = ~clk;

  ocp_slave_model u_dut (
    .vif_mclk(clk), .vif_mreset_n(rst_n), .vif_mcmd(mcmd), .vif_maddr(maddr),
    .vif_mdata(mdata), .vif_scmdaccept(accept), .vif_sresp(sresp), .vif_sdata(sdata)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  int accept_while_pending = 0, resp_pulses = 0;
  always @(posedge clk) begin
    if (rst_n && u_dut.pend && accept) accept_while_pending++;
    if (sresp != NULL) resp_pulses++;
  end

  logic [1:0]  r;
  logic [31:0] d;
  int          lat, held_ok;
  task automatic req(input [2:0] c, input [31:0] a, input [31:0] wd = '0);
    @(negedge clk);
    mcmd = c; maddr = a; mdata = wd;
    held_ok = 1;
    while (accept !== 1'b1) begin
      @(negedge clk);
      if (mcmd !== c || maddr !== a) held_ok = 0;
    end
    @(negedge clk);
    mcmd = IDLE; maddr = '1; mdata = '1;
    lat = 0;
    while (sresp === NULL && lat < 20) begin @(negedge clk); lat++; end
    r = sresp; d = sdata;
  endtask

  int bad = 0;
  int lat_seen [6];
  logic [31:0] ref_mem [16];

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1'b1;
    @(negedge clk);
    chk(accept === 1'b0 && sresp === NULL, "no accept / no response with MCmd idle");

    req(WR, 32'h0000_0040, 32'hCAFE_0040);
    chk(r == DVA, "write gets DVA response");
    req(RD, 32'h0000_0040);
    chk(r == DVA && d == 32'hCAFE_0040, "read returns DVA with the written data");
    req(RD, 32'h0000_0044);
    chk(r == DVA && d == 32'h0, "unwritten address reads 0");
    req(WR, 32'h0000_0F00, 32'h1);
    chk(r == ERR, "write to MAddr[11:8]=0xF returns ERR");
    req(RD, 32'h0000_0F04);
    chk(r == ERR, "read from the error region returns ERR");
    req(WR, 32'h0000_0040, 32'hBEEF_0040);
    req(RD, 32'h0000_0040);
    chk(d == 32'hBEEF_0040, "second write overwrites the first");

    // random read/write mix against a reference model
    foreach (ref_mem[i]) ref_mem[i] = 32'h0;
    foreach (lat_seen[i]) lat_seen[i] = 0;
    for (int i = 0; i < 60; i++) begin
      int idx;
      idx = $urandom_range(15);
      if ($urandom_range(1)) begin
        logic [31:0] v;
        v = $urandom;
        req(WR, 32'h1000 + idx * 4, v);
        ref_mem[idx] = v;
        if (r != DVA || lat < 1 || lat > 4) bad++;
      end else begin
        req(RD, 32'h1000 + idx * 4);
        if (r != DVA || d != ref_mem[idx] || lat < 1 || lat > 4) bad++;
      end
      if (!held_ok) bad++;
      lat_seen[lat > 5 ? 5 : lat]++;
    end
    chk(bad == 0, "60 random reads/writes: data, DVA and 1..4 clock latency all correct");
    repeat (2) @(negedge clk);
    chk(lat_seen[1] > 0 && lat_seen[2] > 0 && lat_seen[3] > 0 && lat_seen[4] > 0,
        $sformatf("every response latency 1..4 occurs (%0d/%0d/%0d/%0d)",
                  lat_seen[1], lat_seen[2], lat_seen[3], lat_seen[4]));
    chk(resp_pulses == 67, "exactly one single-clock SResp per request");
    chk(accept_while_pending == 0, "SCmdAccept low while a request is outstanding");

    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(accept === 1'b0 && sresp === NULL && u_dut.pend === 1'b0, "reset clears accept, response and pending state");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
