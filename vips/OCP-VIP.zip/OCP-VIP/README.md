# OCP — OCP-IP Open Core Protocol UVM VIP

Open-source UVM verification IP template for **OCP-IP Open Core Protocol** (Interconnect).

## Contents

| Path | Description |
|------|-------------|
| `ocp/ocp_if.sv` | Protocol interface + FSM state enum |
| `ocp/ocp_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `ocp/sva/ocp_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=4) |
| `ocp/vip/ocp/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/ocp_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional OCP slave DUT |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **OCP master driver**: command phase (`MCmd`/`MAddr`/`MData`) held until `SCmdAccept`, response phase waits for `SResp`/`SData` and captures read data
- **Protocol-decoding monitor**: decodes accepted commands and their responses from the waveform, measuring per-transaction response latency
- **End-to-end scoreboard**: matches driver vs monitor transactions and checks read data against a shadow memory (WR -> RD consistency)
- **Functional DUT model**: OCP slave with ~75% `SCmdAccept` backpressure, 1-4 cycle response latency, associative memory, and `SResp=ERR` error region (`addr[11:8]==0xF`)
- **Directed sequence library**: write / read / write-read-same-address / backpressure stress / address sweep / data corners / error-inject (resp error code) / reset + regression mix
- **Functional coverage**: cmd x sresp cross, address ranges incl. error region, response latency bins, FSM state + transition sequences, error/data-corner bins
- **SVA L4**: command held until accept, `SResp` only with outstanding command, word-aligned addresses, WR->RD data consistency (shadow memory)
