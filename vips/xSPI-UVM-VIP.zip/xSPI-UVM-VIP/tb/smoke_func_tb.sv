// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (xSPI DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened xspi_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic cs_n = 1, ck = 0, dq_m_oe = 0;
  logic [7:0] dq_m = 0;
  wire [7:0] dq_s;
  wire dq_s_oe, ds;

  always #5 clk = ~clk;

  xspi_model u_dut (.clk(clk), .rst_n(rst_n), .cs_n(cs_n), .ck(ck), .dq_m(dq_m), .dq_m_oe(dq_m_oe),
                    .dq_s(dq_s), .dq_s_oe(dq_s_oe), .ds(ds));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic bt(input logic oe, input logic [7:0] d);
    @(negedge clk); ck = !ck; dq_m_oe = oe; dq_m = d;
  endtask

  // command [+ address] [+ data] [+ dummy and n read bytes]; returns read bytes
  logic [7:0] rbuf [0:15];
  task automatic xfer(input logic [7:0] op, input logic hasaddr, input logic [31:0] a,
                      input int nw, input logic [7:0] w0, input int nr);
    logic dsp;
    int k;
    @(negedge clk); cs_n = 0;
    bt(1, op); bt(1, ~op);
    if (hasaddr) for (int i = 3; i >= 0; i--) bt(1, a[8*i +: 8]);
    for (int i = 0; i < nw; i++) bt(1, w0 + 8'(i));
    k = 0; dsp = ds;
    if (nr > 0) for (int i = 0; i < 16 + nr + 2; i++) begin
      if (i < 16 + nr) bt(0, 0); else @(negedge clk);
      if (ds != dsp && k < 16) begin rbuf[k] = dq_s; k++; end
      dsp = ds;
    end
    @(negedge clk); dq_m_oe = 0; cs_n = 1;
    repeat (2) @(negedge clk);
  endtask

  task automatic wait_ready;
    int n = 0;
    do begin xfer(8'h05, 1, 0, 0, 0, 1); n++; end while (rbuf[0][0] && n < 20);
    chk(rbuf[0][0] === 1'b0, "WIP clears");
  endtask

  initial begin
    repeat (3) @(posedge clk);
    chk(dq_s_oe === 1'b0, "DQ released in reset");
    rst_n = 1;
    repeat (3) @(posedge clk);

    xfer(8'h9F, 1, 0, 0, 0, 7);
    chk(rbuf[0] === 8'h5A && rbuf[1] === 8'h81 && rbuf[2] === 8'h1A, "RDID");
    chk(rbuf[3] === 8'h5A && rbuf[4] === 8'h81 && rbuf[5] === 8'h1A && rbuf[6] === 8'h5A, "RDID repeats every 3 bytes");
    xfer(8'hEE, 1, 32'h40, 0, 0, 2);
    chk(rbuf[0] === 8'hFF && rbuf[1] === 8'hFF, "erased array reads 0xFF");
    xfer(8'h12, 1, 32'h40, 2, 8'h10, 0);                    // no WEL
    xfer(8'hEE, 1, 32'h40, 0, 0, 1);
    chk(rbuf[0] === 8'hFF, "program without WEL ignored");
    xfer(8'h06, 0, 0, 0, 0, 0);
    xfer(8'h05, 1, 0, 0, 0, 1);
    chk(rbuf[0] === 8'h02, "WREN sets WEL");
    xfer(8'h12, 1, 32'h40, 3, 8'h10, 0);
    xfer(8'h05, 1, 0, 0, 0, 1);
    chk(rbuf[0] === 8'h03, "WIP and WEL while programming");
    wait_ready();
    xfer(8'h05, 1, 0, 0, 0, 1);
    chk(rbuf[0] === 8'h00, "WEL cleared after program");
    xfer(8'hEE, 1, 32'h40, 0, 0, 4);
    chk(rbuf[0] === 8'h10 && rbuf[1] === 8'h11 && rbuf[2] === 8'h12 && rbuf[3] === 8'hFF, "programmed bytes read back");
    xfer(8'hEE, 1, 32'h3F, 0, 0, 2);
    chk(rbuf[0] === 8'hFF && rbuf[1] === 8'h10, "read from another address");
    // a program issued while busy is ignored (data and mask untouched)
    xfer(8'h06, 0, 0, 0, 0, 0);
    xfer(8'h12, 1, 32'h48, 2, 8'hF0, 0);
    xfer(8'h12, 1, 32'h48, 2, 8'h00, 0);
    wait_ready();
    xfer(8'hEE, 1, 32'h48, 0, 0, 2);
    chk(rbuf[0] === 8'hF0 && rbuf[1] === 8'hF1, "program while WIP ignored");
    // WRDI clears WEL: the following program does nothing
    xfer(8'h06, 0, 0, 0, 0, 0);
    xfer(8'h04, 0, 0, 0, 0, 0);
    xfer(8'h05, 1, 0, 0, 0, 1);
    chk(rbuf[0] === 8'h00, "WRDI clears WEL");
    xfer(8'h12, 1, 32'h50, 1, 8'h00, 0);
    xfer(8'hEE, 1, 32'h50, 0, 0, 1);
    chk(rbuf[0] === 8'hFF, "program after WRDI ignored");
    xfer(8'h06, 0, 0, 0, 0, 0);
    xfer(8'h21, 1, 32'h0, 0, 0, 0);
    wait_ready();
    xfer(8'hEE, 1, 32'h40, 0, 0, 1);
    chk(rbuf[0] === 8'hFF, "sector erase");
    // wrong extension: no response
    @(negedge clk); cs_n = 0; bt(1, 8'h9F); bt(1, 8'h9F);
    for (int i = 0; i < 4; i++) bt(1, 0);
    begin
      logic dsp; dsp = ds;
      repeat (20) bt(0, 0);
      chk(ds === dsp && dq_s_oe === 1'b0, "wrong command extension ignored");
    end
    @(negedge clk); cs_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
