// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- xSPI testbench top with a functional xSPI DUT model

`ifndef XSPI_UVM_VIP_TB_SV
`define XSPI_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import xspi_defs_pkg::*;
import xspi_pkg::*;
import xspi_env_pkg::*;
import xspi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  xspi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  xspi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cs_n(vif.cs_n),
    .ck(vif.ck),
    .dq_m(vif.dq_m),
    .dq_m_oe(vif.dq_m_oe),
    .dq_s(vif.dq_s),
    .dq_s_oe(vif.dq_s_oe),
    .ds(vif.ds)
  );

  // Concurrent protocol checks
  xspi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cs_n(vif.cs_n),
    .ck(vif.ck),
    .dq_m(vif.dq_m),
    .dq_m_oe(vif.dq_m_oe),
    .dq_s(vif.dq_s),
    .dq_s_oe(vif.dq_s_oe),
    .ds(vif.ds)
  );

  initial begin
    uvm_config_db#(virtual xspi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module xspi_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       cs_n,
  input  logic       ck,
  input  logic [7:0] dq_m,
  input  logic       dq_m_oe,
  output logic [7:0] dq_s,
  output logic       dq_s_oe,
  output logic       ds
);
  localparam int DUMMY = 16;
  logic [7:0]  mem [0:8191];
  logic [7:0]  pbuf [0:255];
  logic [255:0] pmask;
  logic [7:0]  op;
  logic        ext_ok, wel, cs_p, ck_p, rd;
  logic [31:0] addr, paddr;    // transfer address, program / erase address
  logic [8:0]  nb;            // host beats (command, extension, address, data)
  logic [7:0]  dcnt, rcnt;    // dummy beats, read beats
  logic [7:0]  busy;          // WIP countdown
  logic [1:0]  pend;          // 1 = program, 2 = erase after busy

  wire wip  = (busy != 0);
  wire edge_ = !cs_n && (ck != ck_p);
  wire addr_cmd = !(op == 8'h06 || op == 8'h04);

  function automatic logic [7:0] rd_byte(input logic [7:0] o, input logic [31:0] a, input logic [7:0] i);
    case (o)
      8'h05: rd_byte = {6'h0, wel, wip};
      8'h9F: rd_byte = (i % 3 == 0) ? 8'h5A : (i % 3 == 1) ? 8'h81 : 8'h1A;
      default: rd_byte = mem[(a + i) & 32'h1FFF];
    endcase
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 8192; i++) mem[i] <= 8'hFF;
      for (int i = 0; i < 256; i++) pbuf[i] <= 8'hFF;
      pmask <= '0; paddr <= '0; op <= '0; ext_ok <= 1'b0; wel <= 1'b0; cs_p <= 1'b1; ck_p <= 1'b0; rd <= 1'b0;
      addr <= '0; nb <= '0; dcnt <= '0; rcnt <= '0; busy <= '0; pend <= '0;
      dq_s <= '0; dq_s_oe <= 1'b0; ds <= 1'b0;
    end else begin
      cs_p <= cs_n; ck_p <= ck;
      if (busy != 0) begin
        busy <= busy - 8'd1;
        if (busy == 8'd1) begin
          wel <= 1'b0;
          if (pend == 2'd1) begin
            for (int i = 0; i < 256; i++)
              if (pmask[i]) mem[{paddr[12:8], 8'(i)}] <= mem[{paddr[12:8], 8'(i)}] & pbuf[i];
          end else if (pend == 2'd2)
            for (int i = 0; i < 4096; i++) mem[{paddr[12], 12'(i)}] <= 8'hFF;
          pend <= '0;
          pmask <= '0;
        end
      end
      if (!cs_n && cs_p) begin                     // CS# fall: new transfer
        nb <= '0; dcnt <= '0; rcnt <= '0; rd <= 1'b0;
        if (!wip) pmask <= '0;                     // keep a pending program's data
      end
      if (edge_ && dq_m_oe) begin                  // host beat
        nb <= nb + 9'd1;
        if (nb == 9'd0) op <= dq_m;
        else if (nb == 9'd1) ext_ok <= (dq_m == ~op);
        else if (nb < 9'd6 && addr_cmd) addr <= {addr[23:0], dq_m};
        else if (op == 8'h12 && ext_ok && wel && !wip) begin
          logic [7:0] col;
          col = addr[7:0] + 8'(nb - 9'd6);
          pbuf[col] <= pmask[col] ? (pbuf[col] & dq_m) : dq_m;
          pmask[col] <= 1'b1;
        end
      end else if (edge_ && !dq_m_oe) begin        // dummy / read beat
        if (ext_ok && (op == 8'h05 || ((op == 8'h9F || op == 8'hEE) && !wip))) begin
          if (dcnt < DUMMY[7:0]) dcnt <= dcnt + 8'd1;
          else begin
            dq_s <= rd_byte(op, addr, rcnt);
            dq_s_oe <= 1'b1;
            ds <= !ds;
            rcnt <= rcnt + 8'd1;
          end
        end
      end
      if (cs_n) dq_s_oe <= 1'b0;
      if (cs_n && !cs_p && ext_ok) begin           // CS# rise: execute
        if (op == 8'h06 && !wip) wel <= 1'b1;
        else if (op == 8'h04 && !wip) wel <= 1'b0;
        else if (op == 8'h12 && wel && !wip && nb > 9'd6) begin busy <= 8'd60; pend <= 2'd1; paddr <= addr; end
        else if (op == 8'h21 && wel && !wip && nb >= 9'd6) begin busy <= 8'd120; pend <= 2'd2; paddr <= addr; end
      end
    end
  end
endmodule
`endif
