// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_coverage.svh -- xSPI functional coverage

class xspi_coverage extends uvm_subscriber #(xspi_transaction);
  `uvm_component_utils(xspi_coverage)
  xspi_config cfg;
  xspi_transaction tr;

  covergroup xspi_cg;
    cp_op   : coverpoint tr.opcode { bins wren = {8'h06}; bins wrdi = {8'h04}; bins rdsr = {8'h05};
                                     bins rdid = {8'h9F}; bins rd = {8'hEE}; bins pp = {8'h12};
                                     bins se = {8'h21}; bins unknown = default; }
    cp_ext  : coverpoint tr.bad_ext;
    cp_wrap : coverpoint (tr.opcode == 8'h12 && tr.addr[7:0] + tr.wdata.size() > 256) { bins wrap = {1}; }
    cp_rlen : coverpoint tr.nread { bins none = {0}; bins short_ = {[1:4]}; bins long_ = {[5:$]}; }
    x_op_ext : cross cp_op, cp_ext;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    xspi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(xspi_config)::get(this, "", "cfg", cfg))
      cfg = xspi_config::type_id::create("cfg");
  endfunction

  function void write(xspi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    xspi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("xSPI coverage: %0.1f%%", xspi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
