// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_transaction.svh -- xSPI transaction

class xspi_transaction extends uvm_sequence_item;
  `uvm_object_utils(xspi_transaction)

  // request (driven by the agent)
  rand bit [7:0] opcode;
  rand bit bad_ext;
  rand bit [31:0] addr;
  bit [7:0] wdata[$];
  rand bit [7:0] nread;
  // response (returned by the DUT)
  bit [7:0] rdata[$];
  // bookkeeping (not compared)
  rand bit [5:0] len;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_op   { opcode dist { 8'h06 := 3, 8'h04 := 1, 8'h05 := 2, 8'h9F := 1, 8'hEE := 4,
                                    8'h12 := 3, 8'h21 := 1, 8'hAB := 1 }; }
  constraint c_ext  { bad_ext dist { 0 := 15, 1 := 1 }; }
  constraint c_addr { addr[31:13] == 0;
                      (opcode inside {8'h06, 8'h04, 8'h05, 8'h9F, 8'hAB}) -> addr == 0; }
  constraint c_nrd  { (opcode == 8'hEE) -> nread inside {[1:48]};
                      (opcode == 8'h05) -> nread == 2;
                      (opcode == 8'h9F) -> nread inside {[3:6]};
                      !(opcode inside {8'hEE, 8'h05, 8'h9F}) -> nread == 0; }

  function new(string name = "xspi_transaction"); super.new(name); endfunction

  function bit has_addr(); return !(opcode inside {8'h06, 8'h04}); endfunction
  function bit is_read(); return opcode inside {8'h05, 8'h9F, 8'hEE}; endfunction

  // Page Program data from len / seed (no queue constraint for the solver)
  function void post_randomize();
    bit [31:0] x = seed | 1;
    wdata.delete();
    if (opcode == 8'h12)
      for (int i = 0; i <= len; i++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        wdata.push_back(x[7:0]);
      end
  endfunction

  function void do_copy(uvm_object rhs);
    xspi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    opcode = rhs_.opcode;
    bad_ext = rhs_.bad_ext;
    addr = rhs_.addr;
    wdata = rhs_.wdata;
    nread = rhs_.nread;
    rdata = rhs_.rdata;
    len = rhs_.len;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    xspi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (opcode != rhs_.opcode) return 0;
    if (bad_ext != rhs_.bad_ext) return 0;
    if (addr != rhs_.addr) return 0;
    if (wdata.size() != rhs_.wdata.size()) return 0;
    foreach (wdata[i]) if (wdata[i] != rhs_.wdata[i]) return 0;
    if (nread != rhs_.nread) return 0;
    if (rdata.size() != rhs_.rdata.size()) return 0;
    foreach (rdata[i]) if (rdata[i] != rhs_.rdata[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(xspi_transaction rhs_);
    if (opcode != rhs_.opcode) return 0;
    if (bad_ext != rhs_.bad_ext) return 0;
    if (addr != rhs_.addr) return 0;
    if (wdata.size() != rhs_.wdata.size()) return 0;
    foreach (wdata[i]) if (wdata[i] != rhs_.wdata[i]) return 0;
    if (nread != rhs_.nread) return 0;
    return 1;
  endfunction

  function string qstr_wdata();
    string s = $sformatf("[%0d]{", wdata.size());
    foreach (wdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", wdata[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rdata();
    string s = $sformatf("[%0d]{", rdata.size());
    foreach (rdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rdata[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("xSPI{tag=%0d opcode=0x%0h bad_ext=0x%0h addr=0x%0h wdata=%s nread=0x%0h rdata=%s}", tag, opcode, bad_ext, addr, qstr_wdata(), nread, qstr_rdata());
  endfunction
endclass
