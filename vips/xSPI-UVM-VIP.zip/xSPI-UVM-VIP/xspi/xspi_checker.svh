// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_checker.svh -- xSPI protocol checker on monitored items

class xspi_checker extends uvm_component;
  `uvm_component_utils(xspi_checker)
  uvm_analysis_imp #(xspi_transaction, xspi_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  xspi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(xspi_config)::get(this, "", "cfg", cfg))
      cfg = xspi_config::type_id::create("cfg");
  endfunction

  function void fail(xspi_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("xSPI: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(xspi_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.is_read() && !t.bad_ext && t.rdata.size() != t.nread)
        fail(t, $sformatf("device drove %0d bytes for %0d read beats", t.rdata.size(), t.nread));
      if (t.bad_ext && t.rdata.size() != 0) fail(t, "device answered a command with a wrong extension");
      if (t.has_addr() && t.addr >= XSPI_MEM && t.opcode inside {8'hEE, 8'h12, 8'h21})
        fail(t, "address beyond the array");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("xSPI checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
