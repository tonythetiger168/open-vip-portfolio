// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_monitor.svh -- xSPI monitor: transfers between CS# fall and rise: host bytes on CK edges with dq_m_oe, device bytes on DS edges

class xspi_monitor extends uvm_monitor;
  `uvm_component_utils(xspi_monitor)

  virtual xspi_if vif;
  uvm_analysis_port #(xspi_transaction) ap;
  xspi_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual xspi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "xspi: virtual interface not set")
    if (!uvm_config_db#(xspi_config)::get(this, "", "cfg", cfg))
      cfg = xspi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] hb[$], db[$];
      int unsigned rbeats = 0;
      bit ck_p = 0, ds_p = 0, cs_p = 1;
      forever begin
        @(vif.mon_cb);
        if (!vif.mon_cb.cs_n) begin
          if (cs_p) begin hb.delete(); db.delete(); rbeats = 0; end
          if (vif.mon_cb.ck != ck_p) begin
            if (vif.mon_cb.dq_m_oe) hb.push_back(vif.mon_cb.dq_m);
            else rbeats++;
          end
        end
        if (vif.mon_cb.ds != ds_p) begin
          if (!vif.mon_cb.dq_s_oe) `uvm_error("MON", "xSPI: DS edge without the device driving DQ")
          db.push_back(vif.mon_cb.dq_s);
        end
        if (vif.mon_cb.cs_n && !cs_p) build(hb, db, rbeats);
        ck_p = vif.mon_cb.ck; ds_p = vif.mon_cb.ds; cs_p = vif.mon_cb.cs_n;
      end
    end
  endtask

  function void publish(xspi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  function void build(bit [7:0] hb[$], bit [7:0] db[$], int unsigned rbeats);
    xspi_transaction t = xspi_transaction::type_id::create("t");
    int n = 2;
    if (hb.size() < 2) begin
      `uvm_error("MON", $sformatf("xSPI: transfer with %0d command beats", hb.size()))
      return;
    end
    t.opcode  = hb[0];
    t.bad_ext = (hb[1] != ~hb[0]);
    if (t.has_addr()) begin
      for (int i = 0; i < 4; i++) t.addr = {t.addr[23:0], hb[2 + i]};
      n = 6;
    end
    for (int i = n; i < hb.size(); i++) t.wdata.push_back(hb[i]);
    t.nread = (rbeats > XSPI_DUMMY) ? rbeats - XSPI_DUMMY : 0;
    foreach (db[i]) t.rdata.push_back(db[i]);
    publish(t);
  endfunction
endclass
