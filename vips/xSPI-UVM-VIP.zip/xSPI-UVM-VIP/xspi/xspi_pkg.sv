// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_pkg.sv -- xSPI UVM VIP package

package xspi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import xspi_defs_pkg::*;
  export xspi_defs_pkg::*;

  `include "xspi_transaction.svh"
  `include "xspi_config.svh"
  `include "xspi_sequencer.svh"
  `include "xspi_driver.svh"
  `include "xspi_monitor.svh"
  `include "xspi_agent.svh"
  `include "xspi_sequences.svh"
  `include "xspi_checker.svh"
  `include "xspi_coverage.svh"
endpackage
