// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_compliance_checker.sv -- xSPI concurrent assertion checks (bindable)

module xspi_compliance_checker
  (input logic clk, input logic rst_n, input logic cs_n, input logic ck, input logic [7:0] dq_m, input logic dq_m_oe, input logic [7:0] dq_s, input logic dq_s_oe, input logic ds);

  // device outputs never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({dq_s_oe, ds}))
    else $error("xSPI: X on device outputs");
  // the device drives DQ only while selected, and never while the host drives it
  assert property (@(posedge clk) disable iff (!rst_n) dq_s_oe |-> !$past(cs_n))
    else $error("xSPI: device drives DQ while deselected");
  assert property (@(posedge clk) disable iff (!rst_n) !(dq_s_oe && dq_m_oe))
    else $error("xSPI: DQ driven by host and device at once");
  // a DS edge comes with valid data and only in a selected transfer
  assert property (@(posedge clk) disable iff (!rst_n) $changed(ds) |-> dq_s_oe && !$isunknown(dq_s))
    else $error("xSPI: DS edge without valid read data");
  // CK only toggles while selected
  assert property (@(posedge clk) disable iff (!rst_n) cs_n && $past(cs_n) |-> $stable(ck))
    else $error("xSPI: CK toggles while CS# is high");
  cover property (@(posedge clk) disable iff (!rst_n) $changed(ds));
  cover property (@(posedge clk) disable iff (!rst_n) $rose(cs_n));
endmodule
