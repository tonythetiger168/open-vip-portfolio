// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_if.sv -- xSPI interface

interface xspi_if (input logic clk);
  logic rst_n;

  logic cs_n;
  logic ck;
  logic [7:0] dq_m;
  logic dq_m_oe;
  logic [7:0] dq_s;
  logic dq_s_oe;
  logic ds;

  modport DUT (input clk, rst_n, input cs_n, input ck, input dq_m, input dq_m_oe, output dq_s, output dq_s_oe, output ds);
  modport MON (input clk, rst_n, cs_n, ck, dq_m, dq_m_oe, dq_s, dq_s_oe, ds);

  clocking drv_cb @(posedge clk);
    input rst_n, dq_s, dq_s_oe, ds;
    inout cs_n, ck, dq_m, dq_m_oe;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, cs_n, ck, dq_m, dq_m_oe, dq_s, dq_s_oe, ds;
  endclocking
endinterface
