// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_defs.sv -- xSPI shared type definitions

package xspi_defs_pkg;

  typedef enum bit [1:0] {XSPI_OK, XSPI_ERR} xspi_status_e;

  localparam int XSPI_DUMMY = 16;        // dummy beats before read data (8 clock cycles, DDR)
  localparam int XSPI_MEM   = 8192;      // array size in bytes

endpackage
