// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_driver.svh -- xSPI driver: one 8D-8D-8D transfer per item: command, extension, address, dummy and data beats; device bytes taken on DS edges

class xspi_driver extends uvm_driver #(xspi_transaction);
  `uvm_component_utils(xspi_driver)

  uvm_analysis_port #(xspi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual xspi_if vif;
  xspi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual xspi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "xspi: virtual interface not set")
    if (!uvm_config_db#(xspi_config)::get(this, "", "cfg", cfg))
      cfg = xspi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    xspi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.cs_n    <= 1'b1;
    vif.drv_cb.ck      <= 1'b0;
    vif.drv_cb.dq_m    <= '0;
    vif.drv_cb.dq_m_oe <= 1'b0;
  endtask

  task drive_item(xspi_transaction t);
    bit [7:0] hb[$];
    bit ds_p;
    hb.push_back(t.opcode);
    hb.push_back(~t.opcode ^ {7'h0, t.bad_ext});
    if (t.has_addr()) for (int i = 3; i >= 0; i--) hb.push_back(t.addr[8*i +: 8]);
    foreach (t.wdata[i]) hb.push_back(t.wdata[i]);
    t.rdata.delete();
    @(vif.drv_cb);
    vif.drv_cb.cs_n <= 1'b0;
    @(vif.drv_cb);
    foreach (hb[i]) beat(1'b1, hb[i]);
    if (t.is_read()) begin
      ds_p = vif.drv_cb.ds;
      for (int i = 0; i < XSPI_DUMMY + t.nread; i++) begin
        beat(1'b0, 8'h0);
        if (vif.drv_cb.ds != ds_p) t.rdata.push_back(vif.drv_cb.dq_s);
        ds_p = vif.drv_cb.ds;
      end
      // the device answers a beat on the following clock: collect the last
      // bytes with CS# still low and CK stopped
      repeat (3) begin
        @(vif.drv_cb);
        if (vif.drv_cb.ds != ds_p) t.rdata.push_back(vif.drv_cb.dq_s);
        ds_p = vif.drv_cb.ds;
      end
    end
    vif.drv_cb.dq_m_oe <= 1'b0;
    vif.drv_cb.cs_n <= 1'b1;
    repeat (2) @(vif.drv_cb);
  endtask

  // one beat: toggle CK, drive (oe) or release DQ
  task beat(bit oe, bit [7:0] d);
    vif.drv_cb.ck      <= !vif.drv_cb.ck;
    vif.drv_cb.dq_m_oe <= oe;
    vif.drv_cb.dq_m    <= oe ? d : 8'h0;
    @(vif.drv_cb);
  endtask
endclass
