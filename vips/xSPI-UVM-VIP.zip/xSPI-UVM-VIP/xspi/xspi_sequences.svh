// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_sequences.svh -- xSPI sequences

// Random traffic: cfg.num_items constrained-random items.
class xspi_base_sequence extends uvm_sequence #(xspi_transaction);
  `uvm_object_utils(xspi_base_sequence)
  xspi_config cfg;

  function new(string name = "xspi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = xspi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "xspi_transaction randomize() failed")

      finish_item(req);
      if (!req.bad_ext && req.opcode inside {8'h12, 8'h21}) wait_ready();
    end
  endtask

  // poll RDSR until the program / erase ends (WIP = 0)
  task wait_ready();
    xspi_transaction s;
    int n = 0;
    do begin
      s = xspi_transaction::type_id::create("rdsr");
      s.opcode = 8'h05; s.nread = 2;
      start_item(s); finish_item(s);
      n++;
    end while (s.rdata.size() > 0 && s.rdata[0][0] && n < 50);
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class xspi_directed_sequence extends uvm_sequence #(xspi_transaction);
  `uvm_object_utils(xspi_directed_sequence)
  xspi_config cfg;

  function new(string name = "xspi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function xspi_transaction item();
    item = xspi_transaction::type_id::create("req");
  endfunction

  task send(xspi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    xspi_transaction t;
    // ID, status, erased array
    t = item(); t.opcode = 8'h9F; t.nread = 6; send(t);
    t = item(); t.opcode = 8'h05; t.nread = 2; send(t);
    t = item(); t.opcode = 8'hEE; t.addr = 32'h100; t.nread = 8; send(t);
    // program without WEL is ignored
    t = item(); t.opcode = 8'h12; t.addr = 32'h100; t.wdata = '{8'h00, 8'h11}; send(t);
    t = item(); t.opcode = 8'hEE; t.addr = 32'h100; t.nread = 2; send(t);
    // WREN, program across the page end (wraps to the page start), poll, read
    t = item(); t.opcode = 8'h06; send(t);
    t = item(); t.opcode = 8'h05; t.nread = 2; send(t);
    t = item(); t.opcode = 8'h12; t.addr = 32'h1FC; t.wdata = '{8'hA1, 8'hA2, 8'hA3, 8'hA4, 8'hA5, 8'hA6}; send(t);
    wait_ready();
    t = item(); t.opcode = 8'hEE; t.addr = 32'h1F8; t.nread = 8; send(t);
    t = item(); t.opcode = 8'hEE; t.addr = 32'h100; t.nread = 4; send(t);
    // NOR: a second program only clears bits
    t = item(); t.opcode = 8'h06; send(t);
    t = item(); t.opcode = 8'h12; t.addr = 32'h1FC; t.wdata = '{8'h0F}; send(t);
    wait_ready();
    t = item(); t.opcode = 8'hEE; t.addr = 32'h1FC; t.nread = 1; send(t);
    // wrong extension and unknown opcode are ignored; WRDI blocks a program
    t = item(); t.opcode = 8'h06; t.bad_ext = 1; send(t);
    t = item(); t.opcode = 8'h05; t.nread = 2; send(t);
    t = item(); t.opcode = 8'hAB; send(t);
    t = item(); t.opcode = 8'h06; send(t);
    t = item(); t.opcode = 8'h04; send(t);
    t = item(); t.opcode = 8'h12; t.addr = 32'h0; t.wdata = '{8'h00}; send(t);
    t = item(); t.opcode = 8'hEE; t.addr = 32'h0; t.nread = 1; send(t);
    // sector erase of the upper sector, then read across the sector boundary and the array wrap
    t = item(); t.opcode = 8'h06; send(t);
    t = item(); t.opcode = 8'h12; t.addr = 32'h1FFE; t.wdata = '{8'h12, 8'h34}; send(t);
    wait_ready();
    t = item(); t.opcode = 8'hEE; t.addr = 32'h1FFE; t.nread = 4; send(t);
    t = item(); t.opcode = 8'h06; send(t);
    t = item(); t.opcode = 8'h21; t.addr = 32'h1000; send(t);
    wait_ready();
    t = item(); t.opcode = 8'hEE; t.addr = 32'h0FFC; t.nread = 8; send(t);
    t = item(); t.opcode = 8'hEE; t.addr = 32'h1FFE; t.nread = 4; send(t);
  endtask

  // poll RDSR until the program / erase ends (WIP = 0)
  task wait_ready();
    xspi_transaction s;
    int n = 0;
    do begin
      s = xspi_transaction::type_id::create("rdsr");
      s.opcode = 8'h05; s.nread = 2;
      start_item(s); finish_item(s);
      n++;
    end while (s.rdata.size() > 0 && s.rdata[0][0] && n < 50);
  endtask
endclass
