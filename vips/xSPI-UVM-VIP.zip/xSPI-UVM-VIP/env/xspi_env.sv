// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xspi_env.sv -- xSPI environment: reference-model scoreboard, checker, coverage

package xspi_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import xspi_defs_pkg::*;
  import xspi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class xspi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(xspi_scoreboard)
    uvm_analysis_imp_exp #(xspi_transaction, xspi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(xspi_transaction, xspi_scoreboard) obs_ap;

    xspi_config cfg;
    xspi_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [7:0] mem [XSPI_MEM];
    bit wel = 0, pending = 0, erased = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(xspi_config)::get(this, "", "cfg", cfg))
        cfg = xspi_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(xspi_transaction t);
      // independent NOR flash model (no timing: WIP comes from the observed status)
      bit ok = !t.bad_ext && t.opcode inside {8'h06, 8'h04, 8'h05, 8'h9F, 8'hEE, 8'h12, 8'h21};
      bit [7:0] obs[$] = t.rdata;
      t.rdata.delete();
      if (!erased) begin foreach (mem[i]) mem[i] = 8'hFF; erased = 1; end   // blank part
      if (ok && pending && t.opcode != 8'h05) ok = 0;          // busy: only RDSR
      if (ok) case (t.opcode)
        8'h06: wel = 1;
        8'h04: wel = 0;
        8'h05: begin
          // WIP is timing: accept 1 only while a program / erase is pending
          bit wip = (obs.size() > 0) ? obs[0][0] : 1'b0;
          if (wip && !pending) wip = 0;
          if (!wip && pending) begin pending = 0; wel = 0; end
          repeat (t.nread) t.rdata.push_back({6'h0, wel, wip});
        end
        8'h9F: for (int i = 0; i < t.nread; i++) t.rdata.push_back(i % 3 == 0 ? 8'h5A : i % 3 == 1 ? 8'h81 : 8'h1A);
        8'hEE: for (int i = 0; i < t.nread; i++) t.rdata.push_back(mem[(t.addr + i) % XSPI_MEM]);
        8'h12: if (wel && t.wdata.size() > 0) begin
          foreach (t.wdata[i]) begin
            int a = {t.addr[12:8], 8'(t.addr[7:0] + i)};
            mem[a] &= t.wdata[i];
          end
          pending = 1;
        end
        8'h21: if (wel) begin
          for (int i = 0; i < 4096; i++) mem[{t.addr[12], 12'(i)}] = 8'hFF;
          pending = 1;
        end
      endcase
    endfunction

    function void write_exp(xspi_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(xspi_transaction t);
      xspi_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        xspi_transaction e = exp_q.pop_front();
        xspi_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("xspi scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class xspi_env extends uvm_env;
    `uvm_component_utils(xspi_env)
    xspi_agent      agt;
    xspi_scoreboard sb;
    xspi_checker    chk;
    xspi_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = xspi_agent     ::type_id::create("agt", this);
      sb  = xspi_scoreboard::type_id::create("sb",  this);
      chk = xspi_checker   ::type_id::create("chk", this);
      cov = xspi_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
