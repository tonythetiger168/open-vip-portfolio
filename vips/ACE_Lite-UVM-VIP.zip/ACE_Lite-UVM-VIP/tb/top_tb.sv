// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- ACE-Lite testbench top with a functional ACE-Lite DUT model

`ifndef ACE-Lite_TB_SV
`define ACE-Lite_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ace_lite_defs_pkg::*;
import ace_lite_pkg::*;
import ace_lite_env_pkg::*;
import ace_lite_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ace_lite_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ace_lite_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .awvalid(vif.awvalid),
    .awbar(vif.awbar),
    .awaddr(vif.awaddr),
    .wvalid(vif.wvalid),
    .wdata(vif.wdata),
    .wstrb(vif.wstrb),
    .bready(vif.bready),
    .awready(vif.awready),
    .wready(vif.wready),
    .bvalid(vif.bvalid),
    .bresp(vif.bresp)
  );

  // Concurrent protocol checks
  ace_lite_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .awvalid(vif.awvalid), .awbar(vif.awbar), .awaddr(vif.awaddr), .wvalid(vif.wvalid), .wdata(vif.wdata), .wstrb(vif.wstrb), .bready(vif.bready), .awready(vif.awready), .wready(vif.wready), .bvalid(vif.bvalid), .bresp(vif.bresp)
  );

  initial begin
    uvm_config_db#(virtual ace_lite_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ace_lite_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        awvalid,
  input  logic [1:0]  awbar,
  input  logic [31:0] awaddr,
  input  logic        wvalid,
  input  logic [63:0] wdata,
  input  logic [7:0]  wstrb,
  input  logic        bready,
  output logic        awready,
  output logic        wready,
  output logic        bvalid,
  output logic [1:0]  bresp
);
  logic [63:0] mem [0:15];
  logic        wpend;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      awready <= 1'b0;
      wready  <= 1'b0;
      bvalid  <= 1'b0;
      bresp   <= 2'b00;
      wpend   <= 1'b0;
    end else begin
      awready <= awvalid && !awready;
      wready  <= wvalid  && !wready;
      if (wvalid && wready) begin
        for (int i = 0; i < 8; i++)
          if (wstrb[i]) mem[awaddr[6:3]][i*8 +: 8] <= wdata[i*8 +: 8];
        wpend <= 1'b1;
      end
      if (bvalid && bready)
        bvalid <= 1'b0;
      else if (wpend && !(awvalid && !awready)) begin
        bvalid <= 1'b1;
        bresp  <= 2'b00; // OKAY
        wpend  <= 1'b0;
      end
    end
  end
endmodule
`endif
