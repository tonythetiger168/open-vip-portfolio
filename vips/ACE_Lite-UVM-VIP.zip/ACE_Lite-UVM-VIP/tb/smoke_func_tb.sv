// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (ACE-Lite write with barrier)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened ace_lite_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic awvalid = 1'b0;
  logic [1:0]  awbar = '0;
  logic [31:0] awaddr = '0;
  logic wvalid = 1'b0;
  logic [63:0] wdata = '0;
  logic [7:0]  wstrb = '0;
  logic bready = 1'b1;
  wire  awready;
  wire  wready;
  wire  bvalid;
  wire  [1:0]  bresp;

  always #5 clk = ~clk;

  ace_lite_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .awvalid(awvalid), .awbar(awbar),
    .awaddr(awaddr), .wvalid(wvalid),
    .wdata(wdata), .wstrb(wstrb), .bready(bready),
    .awready(awready), .wready(wready),
    .bvalid(bvalid), .bresp(bresp)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(awready === 1'b0 && wready === 1'b0 && bvalid === 1'b0,
        "channels reset quiet");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) begin
      step();
      chk(awready === 1'b0 && wready === 1'b0 && bvalid === 1'b0, "no ready / BVALID out of reset while idle");
    end

    // single write transaction, all byte lanes
    @(negedge clk);
    awvalid = 1; awaddr = 32'h0000_0020; awbar = 2'b00;
    wvalid = 1; wdata = 64'h1122_3344_5566_7788; wstrb = 8'hFF;
    step();
    chk(awready === 1'b1, "AW accepted");
    chk(wready === 1'b1, "W accepted");
    @(negedge clk); awvalid = 0;      // keep WVALID through the accept cycle
    step();
    @(negedge clk); wvalid = 0; wstrb = '0;

    // B response must follow with OKAY
    begin : bch
      int to = 0;
      while (bvalid !== 1'b1 && to < 12) begin step(); to++; end
      chk(bvalid === 1'b1, "BVALID after write");
      chk(bresp === 2'b00, "BRESP OKAY");
    end
    step();
    chk(bvalid === 1'b0, "BVALID completes");

    // idle: no spurious responses
    repeat (6) begin step(); chk(bvalid === 1'b0, "no spurious BVALID"); end
    chk(u_dut.mem[4] === 64'h1122_3344_5566_7788, "full-strobe write stored at awaddr[6:3]");

    // partial strobes: only the enabled byte lanes change (lane 0 included)
    @(negedge clk);
    awvalid = 1; awaddr = 32'h0000_0020; wvalid = 1; wdata = 64'hAAAA_BBBB_CCCC_DDDD; wstrb = 8'h0F;
    step(); @(negedge clk); awvalid = 0; step(); @(negedge clk); wvalid = 0; wstrb = '0;
    begin : bch2
      int to = 0;
      while (bvalid !== 1'b1 && to < 12) begin step(); to++; end
      chk(bvalid === 1'b1, "BVALID after the partial write");
    end
    step();
    chk(u_dut.mem[4] === 64'h1122_3344_CCCC_DDDD, "WSTRB 0x0F writes byte lanes 0-3 only");
    @(negedge clk); wvalid = 1; wdata = 64'h0; wstrb = 8'h01; awaddr = 32'h0000_0020;
    step(); step(); @(negedge clk); wvalid = 0; wstrb = '0;
    begin : bch3
      int to = 0;
      while (bvalid !== 1'b1 && to < 12) begin step(); to++; end
    end
    step();
    chk(u_dut.mem[4] === 64'h1122_3344_CCCC_DD00, "WSTRB 0x01 writes byte lane 0 only");

    // held WVALID: WREADY pulses on alternate cycles, never two in a row
    begin : alt
      int n = 0; bit q = 0;
      @(negedge clk); wvalid = 1; wstrb = 8'h00;
      repeat (8) begin
        step();
        if (wready === 1'b1) begin n++; chk(!q, "WREADY never high two cycles in a row"); end
        q = wready;
      end
      chk(n == 4, $sformatf("WREADY on every other cycle while WVALID is held (%0d of 8)", n));
      @(negedge clk); wvalid = 0;
      repeat (12) step();
    end

    // B waits while an AW is still waiting for AWREADY
    @(negedge clk); wvalid = 1; wstrb = 8'h00;
    step();                                    // WREADY rises
    step();                                    // W accepted, write pending
    @(negedge clk); wvalid = 0; awvalid = 1; awaddr = 32'h0000_0040;
    step();                                    // AW waiting: no B yet
    chk(bvalid === 1'b0, "B held while AWVALID waits for AWREADY");
    @(negedge clk); awvalid = 0;
    begin : bch4
      int to = 0;
      while (bvalid !== 1'b1 && to < 12) begin step(); to++; end
      chk(bvalid === 1'b1, "B issued once the AW is accepted");
    end
    repeat (4) step();

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
