// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (ACE-Lite write with barrier)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened ace_lite_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic awvalid = 1'b0;
  logic [1:0]  awbar = '0;
  logic [31:0] awaddr = '0;
  logic wvalid = 1'b0;
  logic [63:0] wdata = '0;
  logic [7:0]  wstrb = '0;
  logic bready = 1'b1;
  wire  awready;
  wire  wready;
  wire  bvalid;
  wire  [1:0]  bresp;

  always #5 clk = ~clk;

  ace_lite_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .awvalid(awvalid), .awbar(awbar),
    .awaddr(awaddr), .wvalid(wvalid),
    .wdata(wdata), .wstrb(wstrb), .bready(bready),
    .awready(awready), .wready(wready),
    .bvalid(bvalid), .bresp(bresp)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(awready === 1'b0 && wready === 1'b0 && bvalid === 1'b0,
        "channels reset quiet");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // single write transaction, all byte lanes
    @(negedge clk);
    awvalid = 1; awaddr = 32'h0000_0020; awbar = 2'b00;
    wvalid = 1; wdata = 64'h1122_3344_5566_7788; wstrb = 8'hFF;
    step();
    chk(awready === 1'b1, "AW accepted");
    chk(wready === 1'b1, "W accepted");
    @(negedge clk); awvalid = 0;      // keep WVALID through the accept cycle
    step();
    @(negedge clk); wvalid = 0; wstrb = '0;

    // B response must follow with OKAY
    begin : bch
      int to = 0;
      while (bvalid !== 1'b1 && to < 12) begin step(); to++; end
      chk(bvalid === 1'b1, "BVALID after write");
      chk(bresp === 2'b00, "BRESP OKAY");
    end
    step();
    chk(bvalid === 1'b0, "BVALID completes");

    // idle: no spurious responses
    repeat (6) begin step(); chk(bvalid === 1'b0, "no spurious BVALID"); end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
