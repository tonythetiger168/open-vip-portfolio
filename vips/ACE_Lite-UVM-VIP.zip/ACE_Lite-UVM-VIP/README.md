# ACE-Lite UVM VIP (ACE_Lite-UVM-VIP)

ACE-Lite (non-snooping AXI4+barriers) slave UVM VIP with write/read channels and barrier tracking model. Complements the ACE-Lite RTL IP from the open-ip-portfolio sister project.

## Structure

- `ace_lite/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `ace_lite_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `ace_lite_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural ACE-Lite DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/ACE_Lite-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh ACE_Lite-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
