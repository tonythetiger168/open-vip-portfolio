// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_defs.sv -- ACE-Lite shared type definitions

package ace_lite_defs_pkg;

  typedef enum bit [1:0] {ACE_LITE_OK, ACE_LITE_ERR} ace_lite_status_e;

  // AWBAR: 2'b00 normal access, 2'b01 memory barrier, 2'b11 synchronisation barrier
  localparam bit [1:0] ACE_BAR_NORMAL = 2'b00, ACE_BAR_MEMORY = 2'b01, ACE_BAR_SYNC = 2'b11;

endpackage
