// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_if.sv -- ACE-Lite interface

interface ace_lite_if (input logic clk);
  logic rst_n;

  logic awvalid;
  logic [1:0] awbar;
  logic [31:0] awaddr;
  logic wvalid;
  logic [63:0] wdata;
  logic [7:0] wstrb;
  logic bready;
  logic awready;
  logic wready;
  logic bvalid;
  logic [1:0] bresp;

  modport DUT (input clk, rst_n, awvalid, awbar, awaddr, wvalid, wdata, wstrb, bready, output awready, wready, bvalid, bresp);
  modport DRV (input clk, rst_n, awready, wready, bvalid, bresp, output awvalid, awbar, awaddr, wvalid, wdata, wstrb, bready);
  modport MON (input clk, rst_n, awvalid, awbar, awaddr, wvalid, wdata, wstrb, bready, awready, wready, bvalid, bresp);

  clocking drv_cb @(posedge clk);
    input rst_n, awvalid, awbar, awaddr, wvalid, wdata, wstrb, bready, awready, wready, bvalid, bresp;
    output awvalid, awbar, awaddr, wvalid, wdata, wstrb, bready;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, awvalid, awbar, awaddr, wvalid, wdata, wstrb, bready, awready, wready, bvalid, bresp;
  endclocking
endinterface
