// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_compliance_checker.sv -- ACE-Lite concurrent assertion checks (bindable)

module ace_lite_compliance_checker
  (input logic clk, input logic rst_n, input awvalid, input [1:0] awbar, input [31:0] awaddr, input wvalid, input [63:0] wdata, input [7:0] wstrb, input bready, input awready, input wready, input bvalid, input [1:0] bresp);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({awready, wready, bvalid, bresp}))
    else $error("ACE-Lite: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> awready == '0)
    else $error("ACE-Lite: output not in reset value");
  // BRESP always OKAY
  assert property (@(posedge clk) disable iff (!rst_n) bvalid |-> bresp == 2'b00)
    else $error("ACEL: non-OKAY response");
  cover property (@(posedge clk) disable iff (!rst_n) (awready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (awvalid == 1'b1 && awready == 1'b1));
endmodule
