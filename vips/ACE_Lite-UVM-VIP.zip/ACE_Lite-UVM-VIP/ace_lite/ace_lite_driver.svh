// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_driver.svh -- ACE-Lite driver: AW and W issued together, held until each READY, then B with BREADY

class ace_lite_driver extends uvm_driver #(ace_lite_transaction);
  `uvm_component_utils(ace_lite_driver)

  uvm_analysis_port #(ace_lite_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ace_lite_if vif;
  ace_lite_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ace_lite_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ace_lite: virtual interface not set")
    if (!uvm_config_db#(ace_lite_config)::get(this, "", "cfg", cfg))
      cfg = ace_lite_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ace_lite_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.awvalid <= 1'b0; vif.drv_cb.awbar <= '0; vif.drv_cb.awaddr <= '0;
    vif.drv_cb.wvalid  <= 1'b0; vif.drv_cb.wdata <= '0;  vif.drv_cb.wstrb  <= '0;
    vif.drv_cb.bready  <= 1'b0;
  endtask

  task drive_item(ace_lite_transaction t);
    bit aw_done = 0, w_done = 0;
    int unsigned to = 0;
    @(vif.drv_cb);
    vif.drv_cb.awvalid <= 1'b1; vif.drv_cb.awaddr <= t.awaddr; vif.drv_cb.awbar <= t.awbar;
    vif.drv_cb.wvalid  <= 1'b1; vif.drv_cb.wdata  <= t.wdata;  vif.drv_cb.wstrb <= t.wstrb;
    vif.drv_cb.bready  <= 1'b1;
    while (!(aw_done && w_done) && to < cfg.timeout_cycles) begin
      @(vif.drv_cb); to++;
      if (!aw_done && vif.drv_cb.awready === 1'b1) begin aw_done = 1; vif.drv_cb.awvalid <= 1'b0; end
      if (!w_done  && vif.drv_cb.wready  === 1'b1) begin w_done  = 1; vif.drv_cb.wvalid  <= 1'b0; end
    end
    if (!(aw_done && w_done)) `uvm_error("TIMEOUT", "ACE-Lite AWREADY/WREADY not seen")
    begin
      int unsigned to = 0;
      do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.bvalid === 1'b1) && to < cfg.timeout_cycles);
      if (!(vif.drv_cb.bvalid === 1'b1)) `uvm_error("TIMEOUT", $sformatf("ACE-Lite BVALID: no response within %0d cycles", cfg.timeout_cycles))
    end
    t.bresp = vif.drv_cb.bresp;
    vif.drv_cb.bready <= 1'b0;
  endtask

endclass
