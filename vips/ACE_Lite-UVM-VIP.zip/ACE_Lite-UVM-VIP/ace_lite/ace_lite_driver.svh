// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_driver.svh -- ACE-Lite driver: reset, then per-item protocol stimulus

class ace_lite_driver extends uvm_driver #(ace_lite_transaction);
  `uvm_component_utils(ace_lite_driver)

  virtual ace_lite_if vif;
  ace_lite_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ace_lite_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ace_lite: virtual interface not set")
    void'(uvm_config_db#(ace_lite_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    vif.drv_cb.rst_n <= 1'b0;
    repeat (8) @(vif.drv_cb);
    vif.drv_cb.rst_n <= 1'b1;
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_item(ace_lite_transaction item);
    item.tag = item_cnt++;
    vif.awvalid <= item.awvalid;
    vif.awbar <= item.awbar;
    vif.awaddr <= item.awaddr;
    vif.wvalid <= item.wvalid;
    vif.wdata <= item.wdata;
    vif.wstrb <= item.wstrb;
    vif.bready <= item.bready;
    @(vif.drv_cb);
    ap.write(item);
  endtask
endclass
