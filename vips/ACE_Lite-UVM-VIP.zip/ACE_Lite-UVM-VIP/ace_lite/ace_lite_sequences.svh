// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_sequences.svh -- ACE-Lite sequences

// Random traffic: cfg.num_items constrained-random items.
class ace_lite_base_sequence extends uvm_sequence #(ace_lite_transaction);
  `uvm_object_utils(ace_lite_base_sequence)
  ace_lite_config cfg;

  function new(string name = "ace_lite_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ace_lite_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ace_lite_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ace_lite_directed_sequence extends uvm_sequence #(ace_lite_transaction);
  `uvm_object_utils(ace_lite_directed_sequence)
  ace_lite_config cfg;

  function new(string name = "ace_lite_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ace_lite_transaction item();
    item = ace_lite_transaction::type_id::create("req");
  endfunction

  task send(ace_lite_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ace_lite_transaction t;
    // full-word writes to every entry, byte-lane writes, both barrier types
    for (int i = 0; i < 16; i++) begin
      t = item(); t.awaddr = i * 8; t.wdata = {2{32'hC0DE_0000 | i}}; t.wstrb = 8'hFF; send(t);
    end
    for (int b = 0; b < 8; b++) begin
      t = item(); t.awaddr = 32'h40; t.wdata = 64'h1122_3344_5566_7788; t.wstrb = 8'h1 << b; send(t);
    end
    t = item(); t.awbar = ACE_BAR_MEMORY; send(t);
    t = item(); t.awbar = ACE_BAR_SYNC; send(t);
    t = item(); t.awaddr = 32'h78; t.wdata = '1; t.wstrb = 8'hF0; send(t);
  endtask
endclass
