// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_monitor.svh -- ACE-Lite monitor: AW and W handshakes, completed by the B handshake

class ace_lite_monitor extends uvm_monitor;
  `uvm_component_utils(ace_lite_monitor)

  virtual ace_lite_if vif;
  uvm_analysis_port #(ace_lite_transaction) ap;
  ace_lite_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ace_lite_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ace_lite: virtual interface not set")
    if (!uvm_config_db#(ace_lite_config)::get(this, "", "cfg", cfg))
      cfg = ace_lite_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      ace_lite_transaction t;
      bit have_aw = 0, have_w = 0;
      forever begin
        @(vif.mon_cb);
        if (!have_aw && vif.mon_cb.awvalid && vif.mon_cb.awready) begin
          if (t == null) t = ace_lite_transaction::type_id::create("t");
          t.awaddr = vif.mon_cb.awaddr; t.awbar = vif.mon_cb.awbar; have_aw = 1;
        end
        if (!have_w && vif.mon_cb.wvalid && vif.mon_cb.wready) begin
          if (t == null) t = ace_lite_transaction::type_id::create("t");
          t.wdata = vif.mon_cb.wdata; t.wstrb = vif.mon_cb.wstrb; have_w = 1;
        end
        if (vif.mon_cb.bvalid && vif.mon_cb.bready) begin
          if (!(have_aw && have_w))
            `uvm_error("MON", "ACE-Lite B response before both AW and W handshakes")
          else begin
            t.bresp = vif.mon_cb.bresp;
            publish(t);
          end
          t = null; have_aw = 0; have_w = 0;
        end
      end
    end
  endtask

  function void publish(ace_lite_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
