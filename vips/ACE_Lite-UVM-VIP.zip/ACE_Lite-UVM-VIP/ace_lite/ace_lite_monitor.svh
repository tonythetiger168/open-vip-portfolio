// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_monitor.svh -- ACE-Lite monitor: decodes observed bus activity

class ace_lite_monitor extends uvm_monitor;
  `uvm_component_utils(ace_lite_monitor)

  virtual ace_lite_if vif;
  uvm_analysis_port #(ace_lite_transaction) ap;
  ace_lite_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ace_lite_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ace_lite: virtual interface not set")
    void'(uvm_config_db#(ace_lite_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    ace_lite_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = ace_lite_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.awvalid = vif.awvalid;
        t.awbar = vif.awbar;
        t.awaddr = vif.awaddr;
        t.wvalid = vif.wvalid;
        t.wdata = vif.wdata;
        t.wstrb = vif.wstrb;
        t.bready = vif.bready;
        t.awready_o = vif.awready;
        t.wready_o = vif.wready;
        t.bvalid_o = vif.bvalid;
        t.bresp_o = vif.bresp;
        ap.write(t);
      end
    end
  endtask
endclass
