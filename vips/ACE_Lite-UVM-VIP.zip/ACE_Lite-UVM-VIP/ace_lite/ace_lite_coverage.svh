// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_coverage.svh -- ACE-Lite functional coverage

class ace_lite_coverage extends uvm_subscriber #(ace_lite_transaction);
  `uvm_component_utils(ace_lite_coverage)
  ace_lite_config cfg;
  ace_lite_transaction tr;

  covergroup ace_lite_cg;
    cp_bar  : coverpoint tr.awbar { bins normal = {ACE_BAR_NORMAL}; bins mem = {ACE_BAR_MEMORY}; bins sync = {ACE_BAR_SYNC}; }
    cp_strb : coverpoint tr.wstrb { bins none = {8'h00}; bins full = {8'hFF}; bins partial = default; }
    cp_idx  : coverpoint tr.awaddr[6:3];
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ace_lite_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ace_lite_config)::get(this, "", "cfg", cfg))
      cfg = ace_lite_config::type_id::create("cfg");
  endfunction

  function void write(ace_lite_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ace_lite_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("ACE-Lite coverage: %0.1f%%", ace_lite_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
