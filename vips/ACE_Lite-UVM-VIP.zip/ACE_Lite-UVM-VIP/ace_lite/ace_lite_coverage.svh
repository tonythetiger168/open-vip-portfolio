// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_coverage.svh -- ACE-Lite functional coverage

class ace_lite_coverage extends uvm_subscriber #(ace_lite_transaction);
  `uvm_component_utils(ace_lite_coverage)
  ace_lite_config cfg;
  ace_lite_transaction tr;

  covergroup ace_lite_cg;
    coverpoint tr.awvalid;
    coverpoint tr.awbar;
    coverpoint tr.awaddr;
    coverpoint tr.wvalid;
    coverpoint tr.wdata;
    coverpoint tr.wstrb;
    coverpoint tr.bready;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(ace_lite_config)::get(this, "*", "cfg", cfg));
    ace_lite_cg = new();
  endfunction

  function void write(ace_lite_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    ace_lite_cg.sample();
  endfunction
endclass
