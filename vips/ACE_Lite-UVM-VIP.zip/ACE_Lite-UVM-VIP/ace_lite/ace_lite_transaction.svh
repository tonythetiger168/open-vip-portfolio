// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_transaction.svh -- ACE-Lite transaction

class ace_lite_transaction extends uvm_sequence_item;
  `uvm_object_utils(ace_lite_transaction)

  // request (driven by the agent)
  rand bit [31:0] awaddr;
  rand bit [1:0] awbar;
  rand bit [63:0] wdata;
  rand bit [7:0] wstrb;
  // response (returned by the DUT)
  bit [1:0] bresp;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_addr { awaddr[2:0] == 3'b000; awaddr < 32'h80; }
  constraint c_bar  { awbar dist { ACE_BAR_NORMAL := 8, ACE_BAR_MEMORY := 1, ACE_BAR_SYNC := 1 }; }
  // barrier transactions carry no data (all strobes low, address 0)
  constraint c_barrier { awbar != ACE_BAR_NORMAL -> (wstrb == 8'h00 && wdata == 0 && awaddr == 0);
                         awbar == ACE_BAR_NORMAL -> wstrb != 8'h00; }

  function new(string name = "ace_lite_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    ace_lite_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    awaddr = rhs_.awaddr;
    awbar = rhs_.awbar;
    wdata = rhs_.wdata;
    wstrb = rhs_.wstrb;
    bresp = rhs_.bresp;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ace_lite_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (awaddr != rhs_.awaddr) return 0;
    if (awbar != rhs_.awbar) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (wstrb != rhs_.wstrb) return 0;
    if (bresp != rhs_.bresp) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ace_lite_transaction rhs_);
    if (awaddr != rhs_.awaddr) return 0;
    if (awbar != rhs_.awbar) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (wstrb != rhs_.wstrb) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("ACE-Lite{tag=%0d awaddr=0x%0h awbar=0x%0h wdata=0x%0h wstrb=0x%0h bresp=0x%0h}", tag, awaddr, awbar, wdata, wstrb, bresp);
  endfunction
endclass
