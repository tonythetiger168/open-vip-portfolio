// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_lite_transaction.svh -- ACE-Lite transaction

class ace_lite_transaction extends uvm_sequence_item;
  `uvm_object_utils(ace_lite_transaction)

  rand bit awvalid;
  rand bit [1:0] awbar;
  rand bit [31:0] awaddr;
  rand bit wvalid;
  rand bit [63:0] wdata;
  rand bit [7:0] wstrb;
  rand bit bready;
  bit awready_o;
  bit wready_o;
  bit bvalid_o;
  bit [1:0] bresp_o;
  bit [31:0] tag;

  function new(string name = "ace_lite_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    ace_lite_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    awvalid = rhs_.awvalid;
    awbar = rhs_.awbar;
    awaddr = rhs_.awaddr;
    wvalid = rhs_.wvalid;
    wdata = rhs_.wdata;
    wstrb = rhs_.wstrb;
    bready = rhs_.bready;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ace_lite_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           awvalid == rhs_.awvalid &&
           awbar == rhs_.awbar &&
           awaddr == rhs_.awaddr &&
           wvalid == rhs_.wvalid &&
           wdata == rhs_.wdata &&
           wstrb == rhs_.wstrb &&
           bready == rhs_.bready;
  endfunction

  function string convert2string();
    return $sformatf("ACE-Lite{tag=%0h awvalid=0x%0h awbar=0x%0h awaddr=0x%0h wvalid=0x%0h wdata=0x%0h wstrb=0x%0h bready=0x%0h}", tag, awvalid, awbar, awaddr, wvalid, wdata, wstrb, bready);
  endfunction
endclass
