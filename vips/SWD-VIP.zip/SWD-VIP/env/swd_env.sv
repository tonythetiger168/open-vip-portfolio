// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// swd_env.sv -- SWD verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import swd_defs_pkg::*;
  import swd_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: predicts the SW-DP response from the request and
  // compares it against the monitor-decoded transaction. Prediction rules:
  //   header parity error            -> no response (ACK_NONE)
  //   AP addr=2 (busy AP)            -> WAIT
  //   AP addr=3 (unimplemented)      -> FAULT
  //   DP addr=3 write (RDBUFF is RO) -> FAULT
  //   otherwise                      -> OK (+ read data for reads)
  class swd_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(swd_scoreboard)
    uvm_analysis_imp_exp #(swd_transaction, swd_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(swd_transaction, swd_scoreboard) obs_ap;

    swd_transaction exp_q[$], obs_q[$];
    int unsigned matched = 0, mismatched = 0;

    // Shadow model of the SW-DP register file (mirrors the DUT model)
    localparam bit [31:0] DPIDR = 32'h2BA0_1477;
    localparam bit [31:0] APIDR = 32'h0477_0031;
    bit [31:0] sh_ctrlstat = 0, sh_select = 0, sh_tar = 0, sh_rdbuff = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function bit [2:0] predict_ack(swd_transaction t);
      if (t.parity_err)                          return swd_transaction::ACK_NONE;
      if (t.ap_ndp && t.addr == 2'h2)            return swd_transaction::ACK_WAIT;
      if (t.ap_ndp && t.addr == 2'h3)            return swd_transaction::ACK_FAULT;
      if (!t.ap_ndp && t.addr == 2'h3 && !t.rnw) return swd_transaction::ACK_FAULT;
      return swd_transaction::ACK_OK;
    endfunction

    function bit [31:0] predict_rdata(swd_transaction t);
      if (!t.ap_ndp) begin
        case (t.addr)
          2'h0: return DPIDR;
          2'h1: return sh_ctrlstat;
          2'h2: return sh_select;
          default: return sh_rdbuff;
        endcase
      end else begin
        case (t.addr)
          2'h0: return APIDR;
          default: return sh_tar;
        endcase
      end
    endfunction

    function void update_shadow(swd_transaction t);
      if (t.rnw) begin
        if (t.ap_ndp && t.addr == 2'h1) sh_rdbuff = sh_tar; // AP read -> RDBUFF
      end else begin
        if (!t.ap_ndp && t.addr == 2'h1) sh_ctrlstat = t.data;
        if (!t.ap_ndp && t.addr == 2'h2) sh_select   = t.data;
        if ( t.ap_ndp && t.addr == 2'h1) sh_tar      = t.data;
      end
    endfunction

    function void write_exp(swd_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(swd_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        swd_transaction e = exp_q.pop_front();
        swd_transaction o = obs_q.pop_front();
        bit [2:0] exp_ack = predict_ack(e);
        bit ok = (e.ap_ndp == o.ap_ndp) && (e.rnw == o.rnw) && (e.addr == o.addr) &&
                 (exp_ack == o.ack_resp) && (e.parity_err == o.hdr_parity_err);
        if (ok && exp_ack == swd_transaction::ACK_OK) begin
          if (e.rnw) ok = (o.rdata == predict_rdata(e)) && !o.data_parity_err;
          else       ok = (e.data == o.data) && !o.data_parity_err;
        end
        if (exp_ack == swd_transaction::ACK_OK) update_shadow(e);
        if (ok) matched++;
        else begin
          mismatched++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s} (predicted ack=%0b)",
                     e.convert2string(), o.convert2string(), exp_ack))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("swd scoreboard: matched=%0d mismatched=%0d",
                matched, mismatched), UVM_LOW)
      if (mismatched) `uvm_error("SB", "end-to-end mismatched detected")
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("unmatched transactions: exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
    endfunction
  endclass

  class swd_env extends uvm_env;
    `uvm_component_utils(swd_env)
    swd_agent      agt;
    swd_scoreboard sb;
    swd_checker    chk;
    swd_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = swd_agent::type_id::create("agt", this);
      sb  = swd_scoreboard::type_id::create("sb", this);
      chk = swd_checker::type_id::create("chk", this);
      cov = swd_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
