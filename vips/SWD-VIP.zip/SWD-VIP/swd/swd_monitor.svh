// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// swd_monitor.svh -- SWD monitor: decodes request header, turnaround, ACK and
// data phase from the swdio waveform and publishes reconstructed transactions.
// Frame start is detected as a host-driven rising edge (start bit) after a
// host-driven low (idle) level.

`ifndef SWD_MONITOR_SVH
`define SWD_MONITOR_SVH

class swd_monitor extends uvm_monitor;
  `uvm_component_utils(swd_monitor)
  virtual swd_if vif;
  uvm_analysis_port #(swd_transaction) ap;
  int unsigned txn_count = 0;

  typedef enum bit [2:0] {M_IDLE, M_HDR, M_TRN, M_ACK, M_TRN2, M_DATA, M_PAR} mstate_e;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual swd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "swd virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    mstate_e st = M_IDLE;
    bit        armed = 0;
    bit [7:0]  hdr;
    bit [2:0]  ack;
    bit [31:0] dat;
    bit        par;
    int        cnt = 0;
    swd_transaction tr;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.nreset !== 1'b1) begin
        st = M_IDLE; armed = 0; cnt = 0;
        continue;
      end
      case (st)
        // ---- idle: arm on host-driven 0, start on host-driven 1 ----
        M_IDLE: begin
          if (vif.mon_cb.swdio_oe && vif.mon_cb.swdio_i === 1'b0) armed = 1;
          else if (armed && vif.mon_cb.swdio_oe && vif.mon_cb.swdio_i === 1'b1) begin
            tr     = swd_transaction::type_id::create("tr");
            hdr    = 8'h01;             // start bit
            cnt    = 1;
            armed  = 0;
            st     = M_HDR;
          end
        end
        // ---- request header (bits 1..7) ----
        M_HDR: begin
          hdr[cnt] = vif.mon_cb.swdio_i;
          cnt++;
          if (cnt == 8) begin
            tr.ap_ndp = hdr[1];
            tr.rnw    = hdr[2];
            tr.addr   = hdr[4:3];
            tr.hdr_parity_err = (^{hdr[4:1]} != hdr[5]);
            tr.parity_err     = tr.hdr_parity_err;
            if (hdr[6] !== 1'b0 || hdr[7] !== 1'b1)
              `uvm_warning("MON", "bad stop/park bits in request header")
            st = M_TRN;
          end
        end
        // ---- turnaround (neither side drives) ----
        M_TRN: begin
          if (vif.mon_cb.swdio_oe || vif.mon_cb.slv_swdio_oe)
            `uvm_warning("MON", "line driven during turnaround")
          cnt = 0;
          st  = M_ACK;
        end
        // ---- 3-bit ACK (target driven) ----
        M_ACK: begin
          ack[cnt] = vif.mon_cb.swdio_i;
          cnt++;
          if (cnt == 3) begin
            tr.ack_resp = ack;
            cnt = 0;
            if (ack == swd_transaction::ACK_OK) begin
              st = tr.rnw ? M_DATA : M_TRN2;
            end else begin
              txn_count++;
              `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
              ap.write(tr);
              st = M_IDLE;
            end
          end
        end
        // ---- write: second turnaround before host data ----
        M_TRN2: st = M_DATA;
        // ---- 32-bit data phase ----
        M_DATA: begin
          dat[cnt] = vif.mon_cb.swdio_i;
          cnt++;
          if (cnt == 32) st = M_PAR;
        end
        // ---- data parity ----
        M_PAR: begin
          par = vif.mon_cb.swdio_i;
          tr.data_parity_err = (par != ^dat);
          if (tr.rnw) tr.rdata = dat;
          else        tr.data  = dat;
          txn_count++;
          `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
          ap.write(tr);
          st = M_IDLE;
        end
        default: st = M_IDLE;
      endcase
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("swd monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
