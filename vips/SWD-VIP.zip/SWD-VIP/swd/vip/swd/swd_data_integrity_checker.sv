// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// swd_data_integrity_checker.sv -- ARM Serial Wire Debug data integrity (CRC/E2E) checker

`ifndef SWD_DATA_INTEGRITY_CHECKER_SV
`define SWD_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import swd_defs_pkg::swd_state_e;

module swd_data_integrity_checker
(
  input logic swclk,
  input logic nreset,
  input swd_state_e state
);
  a_swd_data_integrity_state_known : assert property (@(posedge swclk)
    disable iff (!nreset) !$isunknown(state))
    else `uvm_error("DATA_INTEGRITY", "swd data_integrity: state unknown")
endmodule
`endif
