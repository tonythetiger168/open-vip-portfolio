// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// swd_error_checker.sv -- ARM Serial Wire Debug error injection / detection checker

`ifndef SWD_ERROR_CHECKER_SV
`define SWD_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import swd_defs_pkg::swd_state_e;

module swd_error_checker
(
  input logic swclk,
  input logic nreset,
  input swd_state_e state
);
  a_swd_error_state_known : assert property (@(posedge swclk)
    disable iff (!nreset) !$isunknown(state))
    else `uvm_error("ERROR", "swd error: state unknown")
endmodule
`endif
