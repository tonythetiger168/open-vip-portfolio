// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// swd_transaction.svh -- SWD transaction (request header + ACK + data phase)
//
// On the wire (LSB-first):
//   header : start(1) APnDP RnW A2 A3 parity stop(0) park(1)
//   trn    : one turnaround cycle (neither side drives)
//   ack    : 3-bit target response (OK=001 / WAIT=010 / FAULT=100, LSB-first)
//   data   : 32-bit data + even parity (reads: target-driven, writes: host-driven)

`ifndef SWD_TRANSACTION_SVH
`define SWD_TRANSACTION_SVH

class swd_transaction extends uvm_sequence_item;

  // ACK encodings as sampled LSB-first (bit0 first on the wire)
  typedef enum bit [2:0] {ACK_OK    = 3'b001,
                          ACK_WAIT  = 3'b010,
                          ACK_FAULT = 3'b100,
                          ACK_NONE  = 3'b111}  // no target response (line parked high)
                          ack_e;

  rand bit        ap_ndp;    // 1 = AP access, 0 = DP access
  rand bit        rnw;       // 1 = read, 0 = write
  rand bit [1:0]  addr;      // A[3:2] register selector
  rand bit [31:0] data;      // write data (host -> target)
  rand bit        parity_err;// inject inverted header parity (target must ignore)
  rand int unsigned idle_cycles; // idle (driven-0) cycles appended after the frame

  // Observed / sampled from the bus (driver + monitor)
  bit [2:0]  ack_resp;        // ACK bits as seen on the line
  bit [31:0] rdata;           // read data (target -> host)
  bit        hdr_parity_err;  // monitor: computed header parity mismatch
  bit        data_parity_err; // monitor: computed data parity mismatch

  constraint c_parity { parity_err dist {0 := 8, 1 := 2}; }
  constraint c_idle   { idle_cycles inside {[0:4]}; }

  `uvm_object_utils_begin(swd_transaction)
    `uvm_field_int(ap_ndp, UVM_ALL_ON)
    `uvm_field_int(rnw, UVM_ALL_ON)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(parity_err, UVM_ALL_ON)
    `uvm_field_int(ack_resp, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "swd_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    swd_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= (comparer.compare_field("ap_ndp", ap_ndp, t.ap_ndp, 1) == 1);
    do_compare &= (comparer.compare_field("rnw", rnw, t.rnw, 1) == 1);
    do_compare &= (comparer.compare_field("addr", addr, t.addr, 2) == 1);
    do_compare &= (comparer.compare_field("ack_resp", ack_resp, t.ack_resp, 3) == 1);
    if (ack_resp == ACK_OK) begin
      if (rnw) do_compare &= (comparer.compare_field("rdata", rdata, t.rdata, 32) == 1);
      else     do_compare &= (comparer.compare_field("data", data, t.data, 32) == 1);
    end
  endfunction

  function string ack2string();
    case (ack_resp)
      ACK_OK:    return "OK";
      ACK_WAIT:  return "WAIT";
      ACK_FAULT: return "FAULT";
      default:   return "NONE";
    endcase
  endfunction

  function string convert2string();
    return $sformatf("SWD %s %s a=%0d data=0x%08h ack=%s%s rdata=0x%08h",
                     ap_ndp ? "AP" : "DP", rnw ? "RD" : "WR", addr, data,
                     ack2string(), parity_err ? " [HDR_PARITY_ERR]" : "", rdata);
  endfunction
endclass
`endif
