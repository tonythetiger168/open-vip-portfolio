// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// swd_pkg.sv -- ARM Serial Wire Debug UVM VIP package

package swd_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import swd_defs_pkg::*;
  export swd_defs_pkg::*;

  `include "swd_transaction.svh"
  `include "swd_config.svh"
  `include "swd_sequencer.svh"
  `include "swd_driver.svh"
  `include "swd_monitor.svh"
  `include "swd_agent.svh"
  `include "swd_sequences.svh"
  `include "swd_checker.svh"
  `include "swd_coverage.svh"
endpackage
