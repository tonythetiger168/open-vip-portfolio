// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// swd_sequences.svh -- SWD sequence library

`ifndef SWD_SEQUENCES_SVH
`define SWD_SEQUENCES_SVH

class swd_base_sequence extends uvm_sequence #(swd_transaction);
  `uvm_object_utils(swd_base_sequence)
  int num_txns = 20;
  function new(string name = "swd_base_sequence"); super.new(name); endfunction
  task body();
    swd_transaction tr;
    repeat (num_txns) begin
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: IDR register reads (DP DPIDR and AP APIDR)
class swd_read_idr_seq extends swd_base_sequence;
  function new(string name = "swd_read_idr_seq"); super.new(name); endfunction
  `uvm_object_utils(swd_read_idr_seq)
  task body();
    swd_transaction tr;
    repeat (num_txns) begin
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { rnw == 1; addr == 2'h0; parity_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: write-then-read on RW registers (DP CTRL/STAT, SELECT, AP TAR)
class swd_write_read_seq extends swd_base_sequence;
  function new(string name = "swd_write_read_seq"); super.new(name); endfunction
  `uvm_object_utils(swd_write_read_seq)
  rand bit        ap = 0;
  rand bit [1:0]  reg_addr = 2'h1;
  constraint c_reg { reg_addr inside {2'h1, 2'h2}; }
  task body();
    swd_transaction tr;
    repeat (num_txns) begin
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);                       // write
      void'(tr.randomize() with { ap_ndp == ap; rnw == 0; addr == reg_addr;
                                  parity_err == 0; });
      finish_item(tr);
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);                       // read back
      void'(tr.randomize() with { ap_ndp == ap; rnw == 1; addr == reg_addr;
                                  parity_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: AP TAR read followed by DP RDBUFF read (read result buffering)
class swd_rdbuff_seq extends swd_base_sequence;
  function new(string name = "swd_rdbuff_seq"); super.new(name); endfunction
  `uvm_object_utils(swd_rdbuff_seq)
  task body();
    swd_transaction tr;
    repeat (num_txns) begin
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);                       // AP read of TAR -> updates RDBUFF
      void'(tr.randomize() with { ap_ndp == 1; rnw == 1; addr == 2'h1;
                                  parity_err == 0; });
      finish_item(tr);
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);                       // DP RDBUFF read
      void'(tr.randomize() with { ap_ndp == 0; rnw == 1; addr == 2'h3;
                                  parity_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: WAIT response probing (busy AP register, AP addr=2)
class swd_wait_resp_seq extends swd_base_sequence;
  function new(string name = "swd_wait_resp_seq"); super.new(name); endfunction
  `uvm_object_utils(swd_wait_resp_seq)
  task body();
    swd_transaction tr;
    repeat (num_txns) begin
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { ap_ndp == 1; addr == 2'h2; parity_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: FAULT response probing (unimplemented AP addr=3, DP addr=3 write)
class swd_fault_resp_seq extends swd_base_sequence;
  function new(string name = "swd_fault_resp_seq"); super.new(name); endfunction
  `uvm_object_utils(swd_fault_resp_seq)
  task body();
    swd_transaction tr;
    repeat (num_txns) begin
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { (ap_ndp == 1 && addr == 2'h3) ||
                                  (ap_ndp == 0 && addr == 2'h3 && rnw == 0);
                                  parity_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: inverted header parity (target must not respond)
class swd_parity_err_seq extends swd_base_sequence;
  function new(string name = "swd_parity_err_seq"); super.new(name); endfunction
  `uvm_object_utils(swd_parity_err_seq)
  task body();
    swd_transaction tr;
    repeat (num_txns) begin
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { parity_err == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back transfers with no extra idle clocks
class swd_back_to_back_seq extends swd_base_sequence;
  function new(string name = "swd_back_to_back_seq"); super.new(name); endfunction
  `uvm_object_utils(swd_back_to_back_seq)
  task body();
    swd_transaction tr;
    repeat (num_txns) begin
      tr = swd_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { idle_cycles == 0; parity_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

class swd_random_sequence extends swd_base_sequence;
  `uvm_object_utils(swd_random_sequence)
  function new(string name = "swd_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class swd_regression_sequence extends swd_base_sequence;
  `uvm_object_utils(swd_regression_sequence)
  function new(string name = "swd_regression_sequence"); super.new(name); endfunction
  task body();
    swd_read_idr_seq    idr   = swd_read_idr_seq::type_id::create("idr");
    swd_write_read_seq  wr    = swd_write_read_seq::type_id::create("wr");
    swd_rdbuff_seq      rdb   = swd_rdbuff_seq::type_id::create("rdb");
    swd_wait_resp_seq   wait_ = swd_wait_resp_seq::type_id::create("wait_");
    swd_fault_resp_seq  fault = swd_fault_resp_seq::type_id::create("fault");
    swd_parity_err_seq  perr  = swd_parity_err_seq::type_id::create("perr");
    swd_back_to_back_seq b2b  = swd_back_to_back_seq::type_id::create("b2b");
    swd_random_sequence rnd   = swd_random_sequence::type_id::create("rnd");
    idr.num_txns = 6; wr.num_txns = 5; rdb.num_txns = 4; wait_.num_txns = 4;
    fault.num_txns = 4; perr.num_txns = 6; b2b.num_txns = 8; rnd.num_txns = 20;
    idr.start(m_sequencer);  wr.start(m_sequencer);    rdb.start(m_sequencer);
    wait_.start(m_sequencer); fault.start(m_sequencer);
    perr.start(m_sequencer); b2b.start(m_sequencer);   rnd.start(m_sequencer);
  endtask
endclass
`endif
