// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// swd_driver.svh -- SWD host (debug probe) driver, bit-banged half-duplex.
//
// Transfer flow: line reset (>=50 high clocks, once after reset) -> 8-bit
// request header (LSB-first) -> turnaround -> 3-bit ACK -> optional data
// phase (32 bits + even parity) -> idle. On WAIT/FAULT/no-response the data
// phase is omitted, per the SWD specification.

`ifndef SWD_DRIVER_SVH
`define SWD_DRIVER_SVH

class swd_driver extends uvm_driver #(swd_transaction);
  `uvm_component_utils(swd_driver)
  virtual swd_if vif;
  swd_config cfg;
  uvm_analysis_port #(swd_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual swd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "swd virtual interface not set")
  endfunction

  // ---- low-level line control (bits change on swclk falling edge) ----
  task automatic swd_drive_bit(bit b);
    vif.drv_cb.swdio_oe <= 1'b1;
    vif.drv_cb.swdio    <= b;
    @(vif.drv_cb);
  endtask

  task automatic swd_release_cycle();
    vif.drv_cb.swdio_oe <= 1'b0;
    @(vif.drv_cb);
  endtask

  // Line reset: >= 50 swclk with swdio high, then idle low clocks
  task automatic swd_line_reset();
    vif.state = swd_defs_pkg::IDLE;
    repeat (56) swd_drive_bit(1'b1);
    repeat (2)  swd_drive_bit(1'b0);
  endtask

  task automatic swd_send_header(swd_transaction tr);
    bit [7:0] hdr;
    bit       par;
    hdr[0] = 1'b1;              // start
    hdr[1] = tr.ap_ndp;
    hdr[2] = tr.rnw;
    hdr[3] = tr.addr[0];
    hdr[4] = tr.addr[1];
    par    = ^{tr.ap_ndp, tr.rnw, tr.addr};   // even parity over 4 header bits
    hdr[5] = tr.parity_err ? ~par : par;
    hdr[6] = 1'b0;              // stop
    hdr[7] = 1'b1;              // park
    swd_drive_bit(hdr[0]);
    vif.state = swd_defs_pkg::HEADER;
    for (int i = 1; i < 8; i++) swd_drive_bit(hdr[i]);
  endtask

  task run_phase(uvm_phase phase);
    swd_transaction tr;
    bit [2:0]  ack;
    bit [31:0] rd;
    bit        par;
    vif.drv_cb.swdio_oe <= 1'b0;
    vif.drv_cb.swdio    <= 1'b1;
    vif.state = swd_defs_pkg::IDLE;
    wait (vif.nreset === 1'b1);
    swd_line_reset();
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)

      // ---- request header ----
      swd_send_header(tr);

      // ---- turnaround + ACK ----
      swd_release_cycle();
      vif.state = swd_defs_pkg::ACK_TURN;
      @(posedge vif.swclk);                     // turnaround cycle (undriven)
      for (int k = 0; k < 3; k++) begin
        @(posedge vif.swclk);
        ack[k] = vif.swdio_i;                   // target-driven ACK, LSB first
      end
      tr.ack_resp = ack;

      if (ack == swd_transaction::ACK_OK) begin
        if (tr.rnw) begin
          // ---- read data phase (target drives) ----
          vif.state = swd_defs_pkg::DATA;
          for (int i = 0; i < 32; i++) begin
            @(posedge vif.swclk);
            rd[i] = vif.swdio_i;
          end
          vif.state = swd_defs_pkg::PARITY;
          @(posedge vif.swclk);
          par = vif.swdio_i;
          tr.rdata = rd;
          tr.data_parity_err = (par != ^rd);
          if (tr.data_parity_err)
            `uvm_warning("DRV", "read data parity mismatch")
        end else begin
          // ---- write data phase (host drives after one turnaround) ----
          @(posedge vif.swclk);                 // turnaround cycle
          swd_drive_bit(tr.data[0]);
          vif.state = swd_defs_pkg::DATA;
          for (int i = 1; i < 32; i++) swd_drive_bit(tr.data[i]);
          swd_drive_bit(^{tr.data});            // even parity
          vif.state = swd_defs_pkg::PARITY;
          @(vif.drv_cb);                        // parity bit on the wire
        end
      end else begin
        `uvm_info("DRV", $sformatf("ack=%s, data phase skipped", tr.ack2string()),
                  UVM_HIGH)
      end

      // ---- idle: drive swdio low (frame delimiter) ----
      vif.state = swd_defs_pkg::IDLE;
      repeat (1 + tr.idle_cycles) swd_drive_bit(1'b0);

      drv_ap.write(tr);                         // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
