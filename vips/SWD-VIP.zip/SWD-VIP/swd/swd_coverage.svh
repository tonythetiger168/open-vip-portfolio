// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// swd_coverage.svh -- SWD functional coverage

`ifndef SWD_COVERAGE_SVH
`define SWD_COVERAGE_SVH

class swd_coverage extends uvm_subscriber #(swd_transaction);
  `uvm_component_utils(swd_coverage)

  swd_transaction tr;
  swd_defs_pkg::swd_state_e cur_state;
  virtual swd_if vif;

  covergroup cg_protocol;
    cp_apndp : coverpoint tr.ap_ndp { bins dp = {0}; bins ap = {1}; }
    cp_rnw   : coverpoint tr.rnw    { bins wr = {0}; bins rd = {1}; }
    cp_addr  : coverpoint tr.addr   { bins a[] = {[0:3]}; }
    cp_ack   : coverpoint tr.ack_resp {
      bins ok    = {swd_transaction::ACK_OK};
      bins wait_ = {swd_transaction::ACK_WAIT};
      bins fault = {swd_transaction::ACK_FAULT};
      bins none  = {swd_transaction::ACK_NONE};
    }
    cx_ap_rw_addr : cross cp_apndp, cp_rnw, cp_addr;
    cx_ap_addr_ack : cross cp_apndp, cp_addr, cp_ack;
  endgroup

  covergroup cg_fsm with function sample(swd_defs_pkg::swd_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {swd_defs_pkg::IDLE, swd_defs_pkg::HEADER,
                           swd_defs_pkg::ACK_TURN, swd_defs_pkg::DATA,
                           swd_defs_pkg::PARITY};
    }
    cp_trans : coverpoint s {
      bins req_seq  = (swd_defs_pkg::IDLE => swd_defs_pkg::HEADER =>
                       swd_defs_pkg::ACK_TURN);
      bins data_seq = (swd_defs_pkg::ACK_TURN => swd_defs_pkg::DATA =>
                       swd_defs_pkg::PARITY => swd_defs_pkg::IDLE);
      bins abort_seq = (swd_defs_pkg::ACK_TURN => swd_defs_pkg::IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_hdr_par : coverpoint tr.hdr_parity_err { bins ok = {0}; bins bad = {1}; }
    cp_dat_par : coverpoint tr.data_parity_err { bins ok = {0}; bins bad = {1}; }
    cp_nack : coverpoint tr.ack_resp {
      bins wait_ = {swd_transaction::ACK_WAIT};
      bins fault = {swd_transaction::ACK_FAULT};
      bins none  = {swd_transaction::ACK_NONE};
    }
    cx_par_ack : cross cp_hdr_par, cp_nack;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual swd_if)::get(this, "", "vif", vif));
  endfunction

  function void write(swd_transaction t);
    tr = t;
    if (vif != null) cur_state = vif.state;
    cg_protocol.sample();
    cg_fsm.sample(cur_state);
    cg_error.sample();
  endfunction
endclass
`endif
