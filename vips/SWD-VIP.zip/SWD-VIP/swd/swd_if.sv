// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// swd_if.sv -- ARM Serial Wire Debug interface (swclk / swdio, half-duplex)
//
// The bidirectional swdio line is modelled with an output-enable pair per
// side plus a resolved sense line:
//   swdio / swdio_oe         : host (debug probe, VIP driver) drive value/enable
//   slv_swdio_o / slv_swdio_oe : target (SW-DP, DUT) drive value/enable
//   swdio_i                  : resolved line (pull-up when undriven, x on contention)
//
// Bits are changed on the falling edge of swclk and sampled on the rising edge.

interface swd_if (input logic swclk);
  import swd_defs_pkg::swd_state_e;

  logic nreset;
  logic swdio        = 1'b1;
  logic swdio_oe     = 1'b0;
  logic swdio_i;
  logic slv_swdio_o  = 1'b1;
  logic slv_swdio_oe = 1'b0;

  swd_state_e state;   // protocol bookkeeping (driven by the VIP driver)

  // Line resolution with pull-up and contention detection
  always_comb begin
    case ({swdio_oe, slv_swdio_oe})
      2'b00:   swdio_i = 1'b1;                                  // pull-up
      2'b01:   swdio_i = slv_swdio_o;
      2'b10:   swdio_i = swdio;
      default: swdio_i = (swdio === slv_swdio_o) ? swdio : 1'bx; // contention
    endcase
  end

  modport HOST (input  swclk, nreset, swdio_i,
                output swdio, swdio_oe, state);
  modport DUT  (input  swclk, nreset, swdio_i,
                output slv_swdio_o, slv_swdio_oe);
  modport MON  (input  swclk, nreset, swdio_i, swdio_oe, slv_swdio_o, slv_swdio_oe,
                        state);

  // Host drives on the falling edge of swclk.
  clocking drv_cb @(negedge swclk);
    input  nreset, swdio_i;
    output swdio, swdio_oe;
  endclocking

  // Monitor samples on the rising edge of swclk.
  clocking mon_cb @(posedge swclk);
    input nreset, swdio_i, swdio_oe, slv_swdio_o, slv_swdio_oe, state;
  endclocking
endinterface
