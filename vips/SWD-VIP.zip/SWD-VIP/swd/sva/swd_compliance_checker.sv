// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// swd_compliance_checker.sv -- ARM Serial Wire Debug SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = SWD protocol-specific rules

`ifndef SWD_COMPLIANCE_CHECKER_SV
`define SWD_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import swd_defs_pkg::*;

module swd_compliance_checker
(
  input logic swclk,
  input logic nreset,
  input swd_state_e state,
  input logic swdio_i,
  input logic swdio_oe,
  input logic slv_swdio_o,
  input logic slv_swdio_oe
);

  // ---- helper logic: header/data/ack shift capture for L4 checks ----
  bit [7:0]  hdr_q;
  bit [31:0] dat_q;
  bit [2:0]  ack_q;
  int unsigned ack_cnt;
  int unsigned hi_cnt;
  bit        lr_done, seen_req;

  always @(posedge swclk or negedge nreset) begin
    if (!nreset) begin
      hdr_q  <= '0;
      dat_q  <= '0;
      ack_q  <= '0;
      ack_cnt <= 0;
      hi_cnt <= 0;
      lr_done <= 0;
      seen_req <= 0;
    end else begin
      if (state == HEADER) hdr_q <= {swdio_i, hdr_q[7:1]};
      if (state == DATA)   dat_q <= {swdio_i, dat_q[30:0]};
      if (state == ACK_TURN && slv_swdio_oe) begin
        ack_q   <= {swdio_i, ack_q[2:1]};
        ack_cnt <= ack_cnt + 1;
      end else if (state != ACK_TURN) begin
        ack_cnt <= 0;
      end
      hi_cnt <= swdio_i ? hi_cnt + 1 : 0;
      if (hi_cnt >= 50)    lr_done  <= 1'b1;
      if (state == HEADER) seen_req <= 1'b1;
    end
  end

  // ---------------- L1: signal sanity (4) ----------------
  a_swd_l1_clk   : assert property (@(posedge swclk) disable iff (!nreset) !$isunknown(swclk))
    else `uvm_error("SVA_L1", "swd: clock unknown")
  a_swd_l1_rst   : assert property (@(posedge swclk) !$isunknown(nreset))
    else `uvm_error("SVA_L1", "swd: reset unknown")
  a_swd_l1_state : assert property (@(posedge swclk) disable iff (!nreset) !$isunknown(state))
    else `uvm_error("SVA_L1", "swd: state unknown")
  a_swd_l1_valid : assert property (@(posedge swclk) disable iff (!nreset)
    state inside {IDLE, HEADER, ACK_TURN, DATA, PARITY})
    else `uvm_error("SVA_L1", "swd: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_swd_trans_idle : assert property (@(posedge swclk) disable iff (!nreset)
    state == IDLE |=> state inside {IDLE, HEADER})
    else `uvm_error("SVA_L2", "swd: illegal transition from IDLE")

  // L2-2: legal FSM transition from HEADER
  a_swd_trans_header : assert property (@(posedge swclk) disable iff (!nreset)
    state == HEADER |=> state inside {HEADER, ACK_TURN})
    else `uvm_error("SVA_L2", "swd: illegal transition from HEADER")

  // L2-3: legal FSM transition from ACK_TURN (data phase, or abort on non-OK ACK)
  a_swd_trans_ack_turn : assert property (@(posedge swclk) disable iff (!nreset)
    state == ACK_TURN |=> state inside {ACK_TURN, DATA, IDLE})
    else `uvm_error("SVA_L2", "swd: illegal transition from ACK_TURN")

  // L2-4: legal FSM transition from DATA
  a_swd_trans_data : assert property (@(posedge swclk) disable iff (!nreset)
    state == DATA |=> state inside {DATA, PARITY})
    else `uvm_error("SVA_L2", "swd: illegal transition from DATA")

  // L2-5: legal FSM transition from PARITY
  a_swd_trans_parity : assert property (@(posedge swclk) disable iff (!nreset)
    state == PARITY |=> state inside {PARITY, IDLE})
    else `uvm_error("SVA_L2", "swd: illegal transition from PARITY")

  // ---------------- L3: protocol rules (4) ----------------
  a_swd_l3_reset_idle : assert property (@(posedge swclk)
    $fell(nreset) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "swd: state not IDLE during reset")
  a_swd_l3_no_stuck   : assert property (@(posedge swclk) disable iff (!nreset)
    state == PARITY |-> ##[1:8] (state != PARITY))
    else `uvm_error("SVA_L3", "swd: stuck in PARITY")
  a_swd_l3_full_cycle : cover property (@(posedge swclk) disable iff (!nreset)
    state == IDLE ##1 state == HEADER);
  a_swd_l3_back_idle  : cover property (@(posedge swclk) disable iff (!nreset)
    state == PARITY ##1 state == IDLE);

  // ---------------- L4: SWD protocol-specific rules (5) ----------------
  // L4-1: a request with bad header parity/stop/park must get no target response
  a_swd_l4_hdr_parity : assert property (@(posedge swclk) disable iff (!nreset)
    (state == ACK_TURN && $past(state) == HEADER &&
     (^{hdr_q[4:1]} != hdr_q[5] || hdr_q[6] != 1'b0 || hdr_q[7] != 1'b1))
    |-> (!slv_swdio_oe) [*4])
    else `uvm_error("SVA_L4", "swd: target responded to a bad request header")

  // L4-2: neither side may drive swdio during the turnaround cycle
  a_swd_l4_turnaround : assert property (@(posedge swclk) disable iff (!nreset)
    $rose(state == ACK_TURN) |-> (swdio_oe == 1'b0 && slv_swdio_oe == 1'b0))
    else `uvm_error("SVA_L4", "swd: swdio driven during turnaround")

  // L4-3: data parity bit must be the even parity of the 32 data bits
  a_swd_l4_data_parity : assert property (@(posedge swclk) disable iff (!nreset)
    state == PARITY |-> (swdio_i == ^dat_q))
    else `uvm_error("SVA_L4", "swd: data parity mismatch")

  // L4-4: the first request after reset is preceded by a line reset
  //       (>= 50 consecutive swclk cycles with swdio high)
  a_swd_l4_line_reset : assert property (@(posedge swclk) disable iff (!nreset)
    (state == HEADER && !seen_req) |-> lr_done)
    else `uvm_error("SVA_L4", "swd: first request without 50-clock line reset")

  // L4-5: a target ACK response must use a legal encoding (OK/WAIT/FAULT)
  a_swd_l4_ack_legal : assert property (@(posedge swclk) disable iff (!nreset)
    ($fell(state == ACK_TURN) && ack_cnt == 3)
    |-> (ack_q inside {3'b001, 3'b010, 3'b100}))
    else `uvm_error("SVA_L4", "swd: illegal ACK encoding on the line")

endmodule
`endif
