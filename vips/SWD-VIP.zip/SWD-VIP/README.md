# SWD — ARM Serial Wire Debug UVM VIP

Open-source UVM verification IP template for **ARM Serial Wire Debug** (Debug).

## Contents

| Path | Description |
|------|-------------|
| `swd/swd_if.sv` | Protocol interface + FSM state enum |
| `swd/swd_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `swd/sva/swd_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=5) |
| `swd/vip/swd/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/swd_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional SW-DP (debug port) DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged host driver**: >=50-clock line reset, 8-bit request header (start/APnDP/RnW/A[3:2]/parity/stop/park, LSB-first), turnaround, ACK sampling, read/write data phase with even parity, data phase omitted on WAIT/FAULT/no-response
- **Resolved half-duplex swdio**: host/target output-enable pairs with pull-up and contention detection (`swdio_i`)
- **Protocol-decoding monitor**: start-bit detection, header/ACK/data/parity reconstruction from the waveform, turnaround drive-off check
- **End-to-end scoreboard with SW-DP shadow model**: predicts ACK (WAIT/FAULT/NONE) per request, shadows CTRL/STAT/SELECT/TAR/RDBUFF, checks read data against DPIDR/APIDR constants and shadow registers
- **Functional DUT model**: SW-DP with IDR/RDBUFF/CTRL-STAT/SELECT/TAR registers, header-parity ignore, WAIT on busy AP, FAULT on unimplemented/illegal access
- **Directed sequence library**: IDR read / write-read / RDBUFF / WAIT / FAULT / parity-error / back-to-back + regression mix
- **Functional coverage**: APnDP x RnW x addr cross, addr x ACK cross, FSM states + request/data/abort sequences, header & data parity error bins
- **SVA L4**: bad header gets no response, turnaround drive-off, data parity, first request requires 50-high-clock line reset, legal ACK encoding
