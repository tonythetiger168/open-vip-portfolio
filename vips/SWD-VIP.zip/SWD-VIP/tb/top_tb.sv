// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- ARM Serial Wire Debug testbench top with a functional
//              SW-DP (debug port) DUT model

`ifndef SWD_TB_SV
`define SWD_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import swd_defs_pkg::*;
import swd_pkg::*;
import swd_test_pkg::*;

module top_tb;
  logic swclk = 0;
  always #5ns swclk = ~swclk;

  swd_if vif(swclk);

  initial begin
    vif.nreset = 0;
    #100ns;
    vif.nreset = 1;
  end

  swd_dp_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual swd_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional SW-DP: decodes the 8-bit request header (LSB-first), verifies
// header parity / stop / park, drives ACK and read data, and implements a
// small register file:
//   DP a=0: DPIDR (RO) / ABORT (WO, ignored)   DP a=1: CTRL/STAT (RW)
//   DP a=2: SELECT (RW)                        DP a=3: RDBUFF (RO; write=FAULT)
//   AP a=0: APIDR (RO; write ignored)          AP a=1: TAR (RW; read updates RDBUFF)
//   AP a=2: busy     -> WAIT                   AP a=3: unimplemented -> FAULT
// A header parity error is ignored silently (no target response).
module swd_dp_model (swd_if vif);
  localparam bit [31:0] DPIDR = 32'h2BA0_1477;
  localparam bit [31:0] APIDR = 32'h0477_0031;
  localparam bit [2:0]  ACK_OK = 3'b001, ACK_WAIT = 3'b010, ACK_FAULT = 3'b100;

  bit [31:0] ctrlstat = 0, select_reg = 0, tar = 0, rdbuff = 0;

  initial begin
    vif.slv_swdio_o  = 1'b1;
    vif.slv_swdio_oe = 1'b0;
  end

  task automatic sample_hdr_bits(inout bit [7:0] hdr);
    for (int i = 1; i < 8; i++) begin
      @(posedge vif.swclk);
      hdr[i] = vif.swdio_i;
    end
  endtask

  task automatic drive_ack(bit [2:0] ack);
    @(negedge vif.swclk);                       // turnaround cycle: stay released
    for (int i = 0; i < 3; i++) begin
      @(negedge vif.swclk);
      vif.slv_swdio_oe = 1'b1;
      vif.slv_swdio_o  = ack[i];
    end
  endtask

  task automatic drive_read_data(bit [31:0] d);
    for (int i = 0; i < 32; i++) begin
      @(negedge vif.swclk);
      vif.slv_swdio_o = d[i];
    end
    @(negedge vif.swclk);
    vif.slv_swdio_o = ^d;                       // even parity
    @(negedge vif.swclk);
    vif.slv_swdio_oe = 1'b0;                    // release after parity
  endtask

  task automatic sample_write_data(output bit [31:0] d, output bit par_ok);
    bit par;
    @(negedge vif.swclk);
    vif.slv_swdio_oe = 1'b0;                    // release for the write turnaround
    @(posedge vif.swclk);                       // turnaround cycle
    for (int i = 0; i < 32; i++) begin
      @(posedge vif.swclk);
      d[i] = vif.swdio_i;
    end
    @(posedge vif.swclk);
    par    = vif.swdio_i;
    par_ok = (par == ^d);
  endtask

  initial forever begin
    bit [7:0]  hdr;
    bit        ap, rnw, par_ok;
    bit [1:0]  a;
    bit [2:0]  ack;
    bit [31:0] rd, wd;

    wait (vif.nreset === 1'b1);
    // arm on host-driven low, then detect the start bit (host-driven high)
    do @(posedge vif.swclk); while (!(vif.swdio_oe && vif.swdio_i === 1'b0));
    do @(posedge vif.swclk); while (!(vif.swdio_oe && vif.swdio_i === 1'b1));
    hdr = 8'h01;
    sample_hdr_bits(hdr);

    ap = hdr[1]; rnw = hdr[2]; a = hdr[4:3];
    if (^{hdr[4:1]} != hdr[5] || hdr[6] !== 1'b0 || hdr[7] !== 1'b1) begin
      continue;                                 // bad header: no target response
    end

    // response selection
    if (!ap) begin
      case (a)
        2'h0:    begin ack = ACK_OK; rd = DPIDR;      end
        2'h1:    begin ack = ACK_OK; rd = ctrlstat;   end
        2'h2:    begin ack = ACK_OK; rd = select_reg; end
        default: begin
          if (rnw) begin ack = ACK_OK;    rd = rdbuff; end
          else     begin ack = ACK_FAULT; rd = '0;     end
        end
      endcase
    end else begin
      case (a)
        2'h0:    begin ack = ACK_OK;    rd = APIDR; end
        2'h1:    begin ack = ACK_OK;    rd = tar;   end
        2'h2:    begin ack = ACK_WAIT;  rd = '0;    end
        default: begin ack = ACK_FAULT; rd = '0;    end
      endcase
    end

    drive_ack(ack);
    if (ack != ACK_OK) begin
      @(negedge vif.swclk);
      vif.slv_swdio_oe = 1'b0;                  // release after ACK
      continue;
    end

    if (rnw) begin
      drive_read_data(rd);
      if (ap && a == 2'h1) rdbuff = tar;        // AP read result -> RDBUFF
    end else begin
      sample_write_data(wd, par_ok);
      if (par_ok) begin
        if (!ap && a == 2'h1) ctrlstat   = wd;
        if (!ap && a == 2'h2) select_reg = wd;
        if ( ap && a == 2'h1) tar        = wd;
      end
    end
  end
endmodule
`endif
