// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_swd_tb.sv -- self-checking functional test for the Arm SWD debug port
// model (swd_dp_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py SWD-VIP
//
// Model contract (from tb/top_tb.sv), ADIv5 SWD wire protocol:
//   the host drives SWDIO on the falling edge, the target samples on the
//   rising edge. Packet header (LSB first): Start=1, APnDP, RnW, A[3:2],
//   parity(APnDP,RnW,A), Stop=0, Park=1; one turnaround cell; 3-bit ACK
//   (OK=001, WAIT=010, FAULT=100) driven by the target; then 32 data bits LSB
//   first + parity (read: target drives, then turnaround; write: turnaround,
//   then the host drives). DP: 0x0 DPIDR (RO, 0x2BA01477), 0x4 CTRL/STAT,
//   0x8 SELECT, 0xC RDBUFF (RO, write FAULTs). AP: 0x0 IDR (0x04770031),
//   0x4 TAR (an AP read also latches TAR into RDBUFF), 0x8 WAIT, 0xC FAULT.
//   A header with bad parity/stop/park is ignored (no ACK). Write data with
//   bad parity is ACKed but not applied.

module func_swd_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [2:0] OK = 3'b001, WAIT = 3'b010, FAULT = 3'b100;
  int checks = 0, fails = 0;

  logic swclk = 1'b0, nreset = 1'b0, h_oe = 1'b1, h_d = 1'b1;
  wire  t_d, t_oe;

  always #10 swclk = ~swclk;

  swd_dp_model u_dut (
    .vif_swclk(swclk), .vif_nreset(nreset), .vif_swdio_oe(h_oe), .vif_swdio_i(h_d),
    .vif_slv_swdio_o(t_d), .vif_slv_swdio_oe(t_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one bit cell: host drive on the falling edge, sample target on the rising
  bit s_d, s_oe;
  task automatic swd_cell(input bit oe, input bit d);
    @(negedge swclk); h_oe = oe; h_d = d;
    @(posedge swclk); s_d = t_d; s_oe = t_oe;
  endtask

  logic [2:0]  ack;
  logic [31:0] rdata;
  bit          rpar, ack_driven, wr_released;
  task automatic xfer(input bit ap, input bit rnw, input [1:0] a, input [31:0] wd = '0,
                      input bit bad_hdr = 0, input bit bad_wpar = 0);
    logic [7:0] h;
    h[0] = 1'b1; h[1] = ap; h[2] = rnw; h[4:3] = a; h[5] = ^{a, rnw, ap} ^ bad_hdr;
    h[6] = 1'b0; h[7] = 1'b1;
    swd_cell(1'b1, 1'b0);                           // idle
    for (int i = 0; i < 8; i++) swd_cell(1'b1, h[i]);
    swd_cell(1'b0, 1'b1);                           // turnaround: host releases
    ack_driven = 1;
    for (int i = 0; i < 3; i++) begin swd_cell(1'b0, 1'b1); ack[i] = s_d; ack_driven &= s_oe; end
    if (ack_driven && ack == OK) begin
      if (rnw) begin
        for (int i = 0; i < 32; i++) begin swd_cell(1'b0, 1'b1); rdata[i] = s_d; end
        swd_cell(1'b0, 1'b1); rpar = s_d;
        swd_cell(1'b0, 1'b1);                       // turnaround back to host
      end else begin
        swd_cell(1'b0, 1'b1);                       // turnaround to host
        wr_released = 1;
        for (int i = 0; i < 32; i++) begin swd_cell(1'b1, wd[i]); if (t_oe !== 1'b0) wr_released = 0; end
        swd_cell(1'b1, ^wd ^ bad_wpar);
      end
    end else begin
      swd_cell(1'b0, 1'b1);
    end
    repeat (2) swd_cell(1'b1, 1'b0);                // idle cycles
  endtask

  initial begin
    repeat (2) swd_cell(1'b1, 1'b1);
    nreset = 1'b1;
    repeat (52) swd_cell(1'b1, 1'b1);               // line reset (>= 50 cycles high)
    repeat (2) swd_cell(1'b1, 1'b0);

    xfer(0, 1, 2'h0);
    chk(ack_driven && ack == OK, "DP DPIDR read ACKed OK");
    chk(rdata == 32'h2BA0_1477, "DPIDR value read LSB first");
    chk(rpar == ^rdata, "read data parity correct");
    chk(t_oe === 1'b0, "target releases SWDIO after the read turnaround");

    xfer(0, 1, 2'h1);
    chk(ack == OK && rdata == 32'h0, "CTRL/STAT reads 0 after power-up");
    xfer(0, 1, 2'h2);
    chk(ack == OK && rdata == 32'h0, "SELECT reads 0 after power-up");
    xfer(1, 1, 2'h1);
    xfer(0, 1, 2'h3);
    chk(ack == OK && rdata == 32'h0, "TAR and RDBUFF read 0 after power-up");

    xfer(0, 0, 2'h1, 32'h5000_0000);
    chk(ack == OK, "DP CTRL/STAT write ACKed OK");
    chk(wr_released, "target does not drive SWDIO during the write data phase");
    xfer(0, 1, 2'h1);
    chk(rdata == 32'h5000_0000, "CTRL/STAT reads back the written value (power-up request)");
    xfer(0, 0, 2'h2, 32'h0000_00F0);
    xfer(0, 1, 2'h2);
    chk(rdata == 32'h0000_00F0, "SELECT write / read-back");
    xfer(0, 0, 2'h1, 32'h5000_0001);
    xfer(1, 0, 2'h1, 32'h0000_0010);
    xfer(0, 1, 2'h2);
    chk(rdata == 32'h0000_00F0, "CTRL/STAT and TAR writes leave SELECT unchanged");

    xfer(0, 0, 2'h3, 32'h1);
    chk(ack == FAULT, "write to read-only RDBUFF FAULTs");

    xfer(1, 1, 2'h0);
    chk(ack == OK && rdata == 32'h0477_0031, "AP IDR read");
    xfer(1, 0, 2'h1, 32'h2000_0040);
    chk(ack == OK, "AP TAR write ACKed OK");
    xfer(1, 1, 2'h1);
    chk(ack == OK && rdata == 32'h2000_0040, "AP TAR read returns the written address");
    xfer(0, 1, 2'h3);
    chk(ack == OK && rdata == 32'h2000_0040, "RDBUFF returns the result of the last AP read");

    xfer(1, 1, 2'h2);
    chk(ack_driven && ack == WAIT, "AP register 0x8 answers WAIT");
    xfer(1, 1, 2'h3);
    chk(ack_driven && ack == FAULT, "AP register 0xC answers FAULT");

    // protocol errors
    xfer(0, 1, 2'h0, '0, 1);
    chk(!ack_driven, "header with bad parity is ignored (no ACK)");
    repeat (4) swd_cell(1'b1, 1'b0);
    xfer(0, 1, 2'h0);
    chk(ack == OK && rdata == 32'h2BA0_1477, "target resynchronises on the next good header");
    xfer(0, 0, 2'h2, 32'hDEAD_0000, 0, 1);
    chk(ack == OK, "write with bad data parity is still ACKed");
    xfer(0, 1, 2'h2);
    chk(rdata == 32'h0000_00F0, "write with bad data parity is not applied");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #400000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
