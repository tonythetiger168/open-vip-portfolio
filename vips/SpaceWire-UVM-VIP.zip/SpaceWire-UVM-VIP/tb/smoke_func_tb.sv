// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SpaceWire DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened spacewire_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;
  // the DUT is silent 40 clocks (first bit on the 41st); silent(11) after a
  // bit gives the receiver exactly the 12 quiet clocks it needs
  localparam int SILENT_CLKS = 41, QUIET_MIN = 11;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic din = 0, sin = 0;
  wire dout, sout, rep_valid, rep_kind, rep_eop, rep_tick;
  wire [15:0] rep_len;
  wire [31:0] rep_crc;
  wire [2:0] rep_err;
  wire [7:0] rep_tc;

  always #5 clk = ~clk;

  spacewire_model u_dut (.clk(clk), .rst_n(rst_n), .din(din), .sin(sin), .dout(dout), .sout(sout),
                         .rep_valid(rep_valid), .rep_kind(rep_kind), .rep_len(rep_len), .rep_crc(rep_crc),
                         .rep_eop(rep_eop), .rep_err(rep_err), .rep_tc(rep_tc), .rep_tick(rep_tick));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // reports
  int nrep = 0;
  logic r_kind, r_eop, r_tick;
  logic [15:0] r_len;
  logic [31:0] r_crc;
  logic [2:0] r_err;
  logic [7:0] r_tc;
  always @(posedge clk) if (rep_valid) begin
    nrep++; r_kind = rep_kind; r_len = rep_len; r_crc = rep_crc; r_eop = rep_eop; r_err = rep_err;
    r_tc = rep_tc; r_tick = rep_tick;
  end

  // the DUT's transmitter, decoded: NULLs, FCTs, parity, D / S rule, quiet time
  int n_null = 0, n_fct = 0, n_other = 0, tx_par_err = 0, ds_both = 0, quiet_max = 0;
  int quiet = 0, rnb = 0;
  logic rd_p = 0, rs_p = 0, r_on = 0, r_f = 0, r_p = 0, r_par = 0, r_esc = 0, par_pend = 0;
  logic [7:0] r_sh = 0;
  always @(posedge clk) if (rst_n) begin
    if (dout !== rd_p && sout !== rs_p) begin
      if (dout !== 1'b0 || sout !== 1'b0) ds_both++;   // only dropping both lines is allowed
      quiet = 0;
    end else if (dout !== rd_p || sout !== rs_p) begin
      if (!r_on && quiet >= 12) begin r_on = 1; rnb = 0; r_par = 0; r_esc = 0; end
      quiet = 0;
      if (r_on) begin
        if (rnb == 0) r_p = dout;
        else if (rnb == 1) begin
          r_f = dout;
          // counted once the character goes on: a lone bit before the DUT went
          // quiet is its lines dropping, not a character
          par_pend = ((r_p ^ dout ^ r_par) !== 1'b1);
        end else begin
          if (rnb == 2 && par_pend) tx_par_err++;
          r_sh = {dout, r_sh[7:1]};
        end
        rnb++;
        if (rnb >= 4 && rnb == (r_f ? 4 : 10)) begin
          rnb = 0;
          if (r_f) begin
            r_par = r_sh[7] ^ r_sh[6];
            if (r_sh[7:6] == 2'b11) r_esc = 1;
            else begin
              if (r_sh[7:6] == 2'b00) begin if (r_esc) n_null++; else n_fct++; end
              else n_other++;
              r_esc = 0;
            end
          end else begin r_par = ^r_sh; n_other++; r_esc = 0; end
        end
      end
    end else begin
      quiet++;
      if (quiet > quiet_max) quiet_max = quiet;
      if (quiet == 12) begin r_on = 0; par_pend = 0; end
    end
    rd_p = dout; rs_p = sout;
  end

  // DUT bit period, silence after reset, lines during an error
  int cyc = 0, last_ev = -1, per_min = 99, per_max = 0, first_ev = -1, err_glitch = 0;
  logic measure = 1'b1;              // bit periods until the first link error
  logic rd_q = 0, rs_q = 0;   // previous dout / sout
  always @(posedge clk) if (rst_n) begin
    cyc++;
    if (rep_valid && rep_err != 0) measure = 0;
    if (measure && ((dout !== rd_q) ^ (sout !== rs_q))) begin
      if (first_ev < 0) first_ev = cyc;
      if (last_ev >= 0) begin
        if (cyc - last_ev < per_min) per_min = cyc - last_ev;
        if (cyc - last_ev > per_max) per_max = cyc - last_ev;
      end
      last_ev = cyc;
    end else if (dout === 1'b0 && sout === 1'b0) last_ev = -1;
    if (rep_valid && rep_err != 0 && (dout || sout)) err_glitch++;
    rd_q = dout; rs_q = sout;
  end

  // the agent side: bits of 2 clocks
  logic tx_par = 0;
  int sent = 0;                      // N-chars sent since the link started
  task automatic w(input int n); repeat (n) @(posedge clk); #1; endtask
  task automatic bitx(input logic b);
    if (b == din) sin = !sin;
    din = b;
    w(2);
  endtask
  task automatic ctrl(input logic [1:0] c, input logic flip = 0);   // c = {second, first}
    bitx(tx_par ^ flip); bitx(1); bitx(c[0]); bitx(c[1]);
    tx_par = c[1] ^ c[0];
  endtask
  task automatic dat(input logic [7:0] v, input logic flip = 0);
    bitx(!tx_par ^ flip); bitx(0);
    for (int i = 0; i < 8; i++) bitx(v[i]);
    tx_par = ^v;
  endtask
  task automatic null_c; ctrl(2'b11); ctrl(2'b00); endtask
  task automatic silent(input int n); din = 0; sin = 0; tx_par = 0; w(n); endtask
  // an N-char, waiting with NULLs for credit
  task automatic nchar(input bit is_ctrl, input logic [7:0] v);
    int k;
    k = 0;
    while (n_fct * 8 - sent <= 0 && k < 200) begin null_c(); k++; end
    if (is_ctrl) ctrl(v[1:0]); else dat(v);
    sent++;
  endtask
  // start the link: quiet, then NULLs until the first FCT
  task automatic link_up;
    int k;
    n_fct = 0;
    silent(40);
    chk(n_fct == 0, "no FCT after a link reset before a NULL arrives");
    sent = 0; k = 0;
    while (n_fct == 0 && k < 50) begin null_c(); k++; end
    null_c(); null_c();
  endtask
  task automatic wait_rep(input int prev);
    int k;
    k = 0;
    while (nrep == prev && k < 100) begin @(posedge clk); k++; end
    #1;
  endtask

  initial begin
    int b, f0, q0;
    string s9 = "123456789";
    logic [31:0] c;
    repeat (3) @(posedge clk);
    chk(dout === 1'b0 && sout === 1'b0 && rep_valid === 1'b0, "lines low and no report during reset");
    rst_n = 1;
    w(30);
    chk(dout === 1'b0 && sout === 1'b0 && n_null == 0, "transmitter silent after reset");
    w(400);
    chk(n_null > 5 && n_fct == 0 && n_other == 0, $sformatf("NULLs only until a NULL is received (%0d NULLs, %0d FCTs)", n_null, n_fct));
    chk(nrep == 0, "no report while the line in is quiet");
    chk(first_ev == SILENT_CLKS, $sformatf("first bit out %0d clocks after reset", first_ev));

    // link start: one NULL brings two FCTs (16 N-chars of credit)
    silent(2);
    null_c(); null_c();
    w(120);
    chk(n_fct == 2, $sformatf("two FCTs after the first NULL (%0d)", n_fct));
    sent = 0;

    // a packet of 9 data bytes and EOP
    b = nrep;
    for (int i = 0; i < 9; i++) nchar(0, s9[i]);
    nchar(1, 2'b10);
    wait_rep(b);
    chk(nrep == b + 1 && r_kind == 0 && r_err == 0 && r_eop === 1'b1 && r_len == 9 && r_crc == 32'hCBF4_3926,
        $sformatf("packet: 9 bytes, CRC-32 0xCBF43926, EOP (%0d %h %0d)", r_len, r_crc, r_err));
    null_c(); null_c(); null_c(); w(60);
    chk(n_fct == 3, $sformatf("one more FCT once 8 N-chars were used (%0d)", n_fct));
    chk(n_fct * 8 - sent == 14, "credit back up: 24 given, 10 used");

    // EEP, an empty packet, a packet longer than the credit
    b = nrep; nchar(0, 8'hDE); nchar(0, 8'hAD); nchar(1, 2'b01); wait_rep(b);
    chk(r_len == 2 && r_eop === 1'b0 && r_err == 0, "packet ended by EEP");
    b = nrep; nchar(1, 2'b10); wait_rep(b);
    chk(nrep == b + 1 && r_len == 0 && r_crc == 32'h0 && r_eop === 1'b1, "empty packet");
    b = nrep; c = 32'hFFFF_FFFF;
    for (int i = 0; i < 30; i++) begin
      nchar(0, 8'(i * 7));
      c ^= {24'h0, 8'(i * 7)};
      for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    nchar(1, 2'b10); wait_rep(b);
    chk(nrep == b + 1 && r_len == 30 && r_crc == ~c && r_err == 0, "30-byte packet across several FCTs");
    // an FCT from this side is accepted and ignored
    ctrl(2'b00);
    b = nrep; nchar(0, 8'h42); nchar(1, 2'b10); wait_rep(b);
    chk(r_len == 1 && r_err == 0, "FCT received from the agent ignored");

    // time-codes
    b = nrep; ctrl(2'b11); dat(8'h01); wait_rep(b);
    chk(nrep == b + 1 && r_kind === 1'b1 && r_tc == 8'h01 && r_tick === 1'b1, "time-code 1 after 0: tick");
    b = nrep; ctrl(2'b11); dat(8'h05); wait_rep(b);
    chk(r_kind === 1'b1 && r_tc == 8'h05 && r_tick === 1'b0 && r_eop === 1'b0 && r_err == 0,
        "time-code 5 after 1: no tick, no packet fields");
    b = nrep; ctrl(2'b11); dat(8'hC6); wait_rep(b);
    chk(r_tc == 8'hC6 && r_tick === 1'b1 && r_len == 0, "time-code 6 with flags: tick, flags kept");
    ctrl(2'b11); dat(8'h3F); b = nrep; ctrl(2'b11); dat(8'h00); wait_rep(b);
    chk(r_tc == 8'h00 && r_tick === 1'b1, "time-code 63 -> 0 wraps: tick");
    chk(n_fct * 8 - sent >= 8, "time-codes and NULLs use no credit");

    // parity error in a packet: reported with the bytes before it, link reset
    b = nrep; nchar(0, 8'h41); nchar(0, 8'h42);
    dat(8'h43, 1);
    dat(8'h44); dat(8'h45);
    wait_rep(b);
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < 2; i++) begin
      c ^= {24'h0, 8'(8'h41 + i)};
      for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    chk(nrep == b + 1 && r_err == 3'd1 && r_len == 2 && r_crc == ~c && r_eop === 1'b0,
        $sformatf("parity error: code 1, the 2 bytes before it (%0d %0d)", r_err, r_len));
    q0 = quiet_max;
    silent(60);
    chk(quiet_max >= 36, $sformatf("transmitter silent after the error (%0d quiet clocks)", quiet_max));
    chk(nrep == b + 1, "the characters after the error were ignored");
    f0 = n_null;
    link_up();
    chk(n_fct == 2, $sformatf("link restarts: two FCTs after NULLs (%0d)", n_fct));
    b = nrep; nchar(0, 8'h55); nchar(1, 2'b10); wait_rep(b);
    chk(r_err == 0 && r_len == 1, "packet after the restart");

    // escape errors: ESC EOP, ESC ESC, ESC EEP
    b = nrep; nchar(0, 8'h77); ctrl(2'b11); ctrl(2'b10); wait_rep(b);
    chk(nrep == b + 1 && r_err == 3'd2 && r_len == 1, "ESC + EOP: escape error");
    // keep sending through the DUT's silence: it must not start on a running
    // stream, only after quiet
    b = nrep;
    repeat (8) null_c();
    chk(nrep == b, "no restart on a stream that never went quiet");
    silent(QUIET_MIN);
    n_fct = 0; null_c(); null_c(); null_c(); null_c(); w(40);
    chk(n_fct >= 1, "receiver starts after the minimum quiet time");
    sent = 0; w(40);
    b = nrep; ctrl(2'b11); ctrl(2'b11); wait_rep(b);
    chk(nrep == b + 1 && r_err == 3'd2 && r_len == 0, "ESC + ESC: escape error");
    link_up();
    b = nrep; ctrl(2'b11); ctrl(2'b01); wait_rep(b);
    chk(nrep == b + 1 && r_err == 3'd2, "ESC + EEP: escape error");
    // both lines dropping at once is activity, not quiet: no start right after it
    din = 1; sin = 1; w(50);
    n_fct = 0; din = 0; sin = 0; tx_par = 0; w(2);
    null_c(); null_c(); null_c(); w(30);
    chk(n_fct == 0, "no start on a bit right after both lines dropped");

    // credit error: a data character before any FCT
    silent(40);
    b = nrep; dat(8'h99); wait_rep(b);
    chk(nrep == b + 1 && r_err == 3'd4, "N-char without credit: credit error");
    link_up();
    b = nrep; nchar(0, 8'h01); nchar(1, 2'b10); wait_rep(b);
    chk(r_err == 0, "clean packet at the end");

    chk(tx_par_err == 0, "the DUT's characters have odd parity");
    chk(per_min == 3 && per_max == 3, $sformatf("DUT bits last 3 clocks (%0d..%0d)", per_min, per_max));
    chk(err_glitch == 0, "lines low from the clock of an error report");
    chk(ds_both == 0, "D and S out never change together");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #4000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
