// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SpaceWire testbench top with a functional SpaceWire DUT model

`ifndef SPACEWIRE_UVM_VIP_TB_SV
`define SPACEWIRE_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import spacewire_defs_pkg::*;
import spacewire_pkg::*;
import spacewire_env_pkg::*;
import spacewire_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  spacewire_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  spacewire_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .din(vif.din),
    .sin(vif.sin),
    .dout(vif.dout),
    .sout(vif.sout),
    .rep_valid(vif.rep_valid),
    .rep_kind(vif.rep_kind),
    .rep_len(vif.rep_len),
    .rep_crc(vif.rep_crc),
    .rep_eop(vif.rep_eop),
    .rep_err(vif.rep_err),
    .rep_tc(vif.rep_tc),
    .rep_tick(vif.rep_tick)
  );

  // Concurrent protocol checks
  spacewire_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .din(vif.din),
    .sin(vif.sin),
    .dout(vif.dout),
    .sout(vif.sout),
    .rep_valid(vif.rep_valid),
    .rep_kind(vif.rep_kind),
    .rep_len(vif.rep_len),
    .rep_crc(vif.rep_crc),
    .rep_eop(vif.rep_eop),
    .rep_err(vif.rep_err),
    .rep_tc(vif.rep_tc),
    .rep_tick(vif.rep_tick)
  );

  initial begin
    uvm_config_db#(virtual spacewire_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module spacewire_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        din,
  input  logic        sin,
  output logic        dout,
  output logic        sout,
  output logic        rep_valid,
  output logic        rep_kind,
  output logic [15:0] rep_len,
  output logic [31:0] rep_crc,
  output logic        rep_eop,
  output logic [2:0]  rep_err,
  output logic [7:0]  rep_tc,
  output logic        rep_tick
);
  localparam int TXB = 3, QUIET = 12, SILENT = 40;

  function automatic logic [31:0] crc32_byte(input logic [31:0] c, input logic [7:0] b);
    logic [31:0] x;
    x = c ^ {24'h0, b};
    for (int k = 0; k < 8; k++) x = x[0] ? (x >> 1) ^ 32'hEDB8_8320 : (x >> 1);
    crc32_byte = x;
  endfunction

  // receiver
  logic        d_p, s_p, rx_on, p, f, par, esc, got_null;
  logic [5:0]  quiet;
  logic [3:0]  nb;
  logic [7:0]  sh;
  logic [4:0]  outst;          // credit given and not yet used
  logic [15:0] len;
  logic [31:0] crc;
  logic [5:0]  last_tc;
  // transmitter
  logic [5:0]  err_t;          // silent clocks left
  logic [1:0]  tb;
  logic [9:0]  tx_sh;
  logic [3:0]  tx_n;
  logic        tx_par, tx_fct_next;

  // a bit: exactly one of D and S changes (both at once is a link end
  // dropping its lines, not a bit)
  wire ev = (din != d_p) ^ (sin != s_p);
  wire drop = (din != d_p) && (sin != s_p);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      d_p <= 1'b0; s_p <= 1'b0; rx_on <= 1'b0; p <= 1'b0; f <= 1'b0; par <= 1'b0; esc <= 1'b0; got_null <= 1'b0;
      quiet <= '0; nb <= '0; sh <= '0; outst <= '0; len <= '0; crc <= '1; last_tc <= '0;
      err_t <= 6'(SILENT); tb <= '0; tx_sh <= '0; tx_n <= '0; tx_par <= 1'b0; tx_fct_next <= 1'b0;
      dout <= 1'b0; sout <= 1'b0;
      rep_valid <= 1'b0; rep_kind <= 1'b0; rep_len <= '0; rep_crc <= '0; rep_eop <= 1'b0;
      rep_err <= '0; rep_tc <= '0; rep_tick <= 1'b0;
    end else begin : run
      logic [2:0] e;
      logic       use_credit, give_credit;
      e = 3'd0; use_credit = 1'b0; give_credit = 1'b0;
      d_p <= din; s_p <= sin;
      quiet <= (ev || drop) ? 6'd0 : (quiet == 6'd63 ? quiet : quiet + 6'd1);
      rep_valid <= 1'b0;

      // ---- receiver
      if (err_t != 0) rx_on <= 1'b0;
      else if (ev && !rx_on) begin
        if (quiet >= 6'(QUIET)) begin            // first bit after quiet: a parity bit
          rx_on <= 1'b1; p <= din; nb <= 4'd1; par <= 1'b0; esc <= 1'b0;
        end
      end else if (ev && rx_on) begin
        if (nb == 4'd0) begin p <= din; nb <= 4'd1; end
        else if (nb == 4'd1) begin
          f <= din; nb <= 4'd2;
          if ((p ^ din ^ par) != 1'b1) e = 3'd1;  // odd parity
        end else if (nb == (f ? 4'd3 : 4'd9)) begin : char_done
          logic [7:0] v;
          logic [1:0] c;
          v = {din, sh[7:1]};
          c = {din, sh[7]};
          nb <= 4'd0;
          if (f) begin
            par <= c[1] ^ c[0];
            if (esc) begin
              esc <= 1'b0;
              if (c == 2'b00) got_null <= 1'b1;     // NULL
              else e = 3'd2;                         // ESC + ESC / EOP / EEP
            end else if (c == 2'b11) esc <= 1'b1;
            else if (c != 2'b00) begin               // EOP / EEP
              if (outst == 0) e = 3'd4;
              else begin
                use_credit = 1'b1;
                rep_valid <= 1'b1; rep_kind <= 1'b0; rep_len <= len; rep_crc <= ~crc;
                rep_eop <= (c == 2'b10); rep_err <= 3'd0; rep_tc <= '0; rep_tick <= 1'b0;
                len <= '0; crc <= '1;
              end
            end
          end else begin
            par <= ^v;
            if (esc) begin                           // time-code
              esc <= 1'b0;
              rep_valid <= 1'b1; rep_kind <= 1'b1; rep_len <= '0; rep_crc <= '0; rep_eop <= 1'b0;
              rep_err <= 3'd0; rep_tc <= v; rep_tick <= (v[5:0] == last_tc + 6'd1);
              last_tc <= v[5:0];
            end else if (outst == 0) e = 3'd4;
            else begin
              use_credit = 1'b1;
              len <= len + 16'd1; crc <= crc32_byte(crc, v);
            end
          end
        end else begin
          sh <= {din, sh[7:1]};
          nb <= nb + 4'd1;
        end
      end

      // ---- transmitter: NULLs, FCTs while credit given <= 8
      if (err_t != 0) begin
        err_t <= err_t - 6'd1;
        dout <= 1'b0; sout <= 1'b0; tb <= '0; tx_n <= '0; tx_par <= 1'b0; tx_fct_next <= 1'b0;
      end else begin
        tb <= (tb == 2'(TXB - 1)) ? 2'd0 : tb + 2'd1;
        if (tb == 2'd0) begin : tx_bit
          logic [9:0] v;
          logic [3:0] n;
          v = tx_sh; n = tx_n;
          if (n == 4'd0) begin
            if (tx_fct_next || (got_null && outst <= 5'd8)) begin
              v = {6'b0, 2'b00, 1'b1, tx_par};       // FCT
              if (!tx_fct_next) give_credit = 1'b1;
              tx_fct_next <= 1'b0;
            end else begin
              v = {6'b0, 2'b11, 1'b1, tx_par};       // ESC (of a NULL)
              tx_fct_next <= 1'b1;
            end
            tx_par <= 1'b0;
            n = 4'd4;
          end
          if (v[0] == dout) sout <= !sout;
          dout <= v[0];
          tx_sh <= v >> 1;
          tx_n <= n - 4'd1;
        end
      end

      // credit: +8 for an FCT sent (not the FCT of a NULL), -1 per N-char
      outst <= outst + (give_credit ? 5'd8 : 5'd0) - (use_credit ? 5'd1 : 5'd0);

      // ---- an error resets the link
      if (e != 3'd0) begin
        rep_valid <= 1'b1; rep_kind <= 1'b0; rep_len <= len; rep_crc <= ~crc; rep_eop <= 1'b0;
        rep_err <= e; rep_tc <= '0; rep_tick <= 1'b0;
        len <= '0; crc <= '1; rx_on <= 1'b0; esc <= 1'b0; got_null <= 1'b0; outst <= '0;
        err_t <= 6'(SILENT); dout <= 1'b0; sout <= 1'b0; tx_n <= '0; tx_par <= 1'b0; tx_fct_next <= 1'b0;
      end
    end
  end
endmodule
`endif
