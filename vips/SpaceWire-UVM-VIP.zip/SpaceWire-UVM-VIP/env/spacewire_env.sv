// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_env.sv -- SpaceWire environment: reference-model scoreboard, checker, coverage

package spacewire_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import spacewire_defs_pkg::*;
  import spacewire_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class spacewire_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(spacewire_scoreboard)
    uvm_analysis_imp_exp #(spacewire_transaction, spacewire_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(spacewire_transaction, spacewire_scoreboard) obs_ap;

    spacewire_config cfg;
    spacewire_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [5:0] last_tc = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(spacewire_config)::get(this, "", "cfg", cfg))
        cfg = spacewire_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(spacewire_transaction t);
      bit [31:0] c = 32'hFFFF_FFFF;
      t.rlen = 0; t.rcrc = 0; t.reop = 0; t.err = 0; t.rtc = 0; t.tick = 0;
      if (t.kind) begin
        t.rtc = t.tc;
        t.tick = (t.tc[5:0] == 6'(last_tc + 1));
        last_tc = t.tc[5:0];
      end else begin
        foreach (t.data[i]) c = spw_crc32(c, t.data[i]);
        t.rlen = t.data.size(); t.rcrc = ~c;
        if (t.fault != 0) t.err = (t.fault == 1) ? 3'd1 : 3'd2;
        else t.reop = !t.eep;
      end
    endfunction

    function void write_exp(spacewire_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(spacewire_transaction t);
      spacewire_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        spacewire_transaction e = exp_q.pop_front();
        spacewire_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("spacewire scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class spacewire_env extends uvm_env;
    `uvm_component_utils(spacewire_env)
    spacewire_agent      agt;
    spacewire_scoreboard sb;
    spacewire_checker    chk;
    spacewire_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = spacewire_agent     ::type_id::create("agt", this);
      sb  = spacewire_scoreboard::type_id::create("sb",  this);
      chk = spacewire_checker   ::type_id::create("chk", this);
      cov = spacewire_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
