// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_sequences.svh -- SpaceWire sequences

// Random traffic: cfg.num_items constrained-random items.
class spacewire_base_sequence extends uvm_sequence #(spacewire_transaction);
  `uvm_object_utils(spacewire_base_sequence)
  spacewire_config cfg;

  function new(string name = "spacewire_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = spacewire_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "spacewire_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class spacewire_directed_sequence extends uvm_sequence #(spacewire_transaction);
  `uvm_object_utils(spacewire_directed_sequence)
  spacewire_config cfg;

  function new(string name = "spacewire_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function spacewire_transaction item();
    item = spacewire_transaction::type_id::create("req");
  endfunction

  task send(spacewire_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    spacewire_transaction t;
    // the CRC-32 check string, an empty packet, EEP, then packets longer than
    // one and two FCTs of credit
    begin
      string cv = "123456789";
      t = item(); foreach (cv[i]) t.data.push_back(cv[i]); send(t);
    end
    t = item(); send(t);
    t = item(); t.eep = 1; t.data = '{8'hDE, 8'hAD}; send(t);
    t = item(); for (int i = 0; i < 12; i++) t.data.push_back(8'(i)); send(t);
    t = item(); for (int i = 0; i < 40; i++) t.data.push_back(8'(255 - i)); send(t);
    // time-codes: in sequence (tick), a jump (no tick), the wrap 63 -> 0, flags
    t = item(); t.kind = 1; t.tc = 8'h01; send(t);
    t = item(); t.kind = 1; t.tc = 8'h02; send(t);
    t = item(); t.kind = 1; t.tc = 8'h09; send(t);
    t = item(); t.kind = 1; t.tc = 8'h3F; send(t);
    t = item(); t.kind = 1; t.tc = 8'h00; send(t);
    t = item(); t.kind = 1; t.tc = 8'hC1; send(t);
    // planted faults: the link resets, the packet is cut, the next one is fine
    t = item(); t.data = '{8'h11, 8'h22, 8'h33, 8'h44}; t.fault = 1; t.fpos = 2; send(t);
    t = item(); t.data = '{8'h55, 8'h66}; send(t);
    t = item(); t.data = '{8'h77, 8'h88, 8'h99}; t.fault = 2; t.fpos = 1; send(t);
    t = item(); t.kind = 1; t.tc = 8'h01; send(t);
    t = item(); t.data = '{8'hAB}; t.fault = 1; t.fpos = 0; send(t);
    t = item(); for (int i = 0; i < 20; i++) t.data.push_back(8'(i * 3)); t.eep = 1; send(t);
    t = item(); for (int i = 0; i < 20; i++) t.data.push_back(8'(i * 5)); t.fault = 2; t.fpos = 17; send(t);
    t = item(); t.data = '{8'h01}; send(t);
  endtask
endclass
