// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_compliance_checker.sv -- SpaceWire concurrent assertion checks (bindable)

module spacewire_compliance_checker
  (input logic clk, input logic rst_n, input logic din, input logic sin, input logic dout, input logic sout, input logic rep_valid, input logic rep_kind, input logic [15:0] rep_len, input logic [31:0] rep_crc, input logic rep_eop, input logic [2:0] rep_err, input logic [7:0] rep_tc, input logic rep_tick);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({dout, sout, rep_valid}))
    else $error("SpaceWire: X on D / S out or report");
  // Data-Strobe: one of D and S changes per bit, never both
  assert property (@(posedge clk) disable iff (!rst_n) !($changed(dout) && $changed(sout) && (dout || sout)))
    else $error("SpaceWire: D and S changed together");
  // a report never comes while the line in is quiet for long
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_kind);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_err == 3'd1);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_err == 3'd2);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && !rep_kind && rep_err == 0 && !rep_eop);
endmodule
