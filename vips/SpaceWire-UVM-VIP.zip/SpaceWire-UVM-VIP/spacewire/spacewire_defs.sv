// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_defs.sv -- SpaceWire shared type definitions

package spacewire_defs_pkg;

  typedef enum bit [1:0] {SPACEWIRE_OK, SPACEWIRE_ERR} spacewire_status_e;

  // IEEE CRC-32 step (reflected), for the packet fingerprint
  function automatic bit [31:0] spw_crc32(bit [31:0] c, bit [7:0] b);
    c ^= {24'h0, b};
    for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    return c;
  endfunction
  // control codes as {second bit, first bit}
  localparam bit [1:0] SPW_FCT = 2'b00, SPW_EOP = 2'b10, SPW_EEP = 2'b01, SPW_ESC = 2'b11;
  localparam int SPW_QUIET = 12;     // quiet clocks: a receiver restarts / the link is down
  localparam int SPW_SILENT = 40;    // clocks a link end stays silent after a link error

endpackage
