// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_driver.svh -- SpaceWire driver: link transmitter: Data-Strobe bits, characters with parity, NULLs when idle, N-chars only against the credit from received FCTs, time-codes; drops its queue and restarts the link when the DUT goes silent

class spacewire_driver extends uvm_driver #(spacewire_transaction);
  `uvm_component_utils(spacewire_driver)

  uvm_analysis_port #(spacewire_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual spacewire_if vif;
  spacewire_config cfg;

  // link state, kept by the background process
  int unsigned credit = 0;          // N-chars granted by FCTs and not yet sent
  bit [10:0] txq[$];                // {no credit needed, parity flip, control, value}
  bit [7:0]  tcq[$];                // time-codes to send
  bit [9:0]  pend[$];               // characters to send next: {parity flip, control, value}
  int unsigned cur_n = 0;           // bits of the current character still to send
  int unsigned sil = SPW_SILENT;    // clocks of silence left (link start / restart)
  int unsigned resets = 0;          // link restarts seen

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual spacewire_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spacewire: virtual interface not set")
    if (!uvm_config_db#(spacewire_config)::get(this, "", "cfg", cfg))
      cfg = spacewire_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    spacewire_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      bit d_p = 0, s_p = 0, rx_on = 0, rxf = 0, rx_esc = 0;
      bit d_o = 0, s_o = 0, tx_par = 0;
      int unsigned quiet = 0, rnb = 0, tb = 0;
      bit [7:0] rsh = 0;
      bit [9:0] cur = 0;
      forever begin
        bit d, s, ev;
        @(vif.drv_cb);
        // receiver: FCTs grant credit; the DUT going quiet is a link reset
        d = vif.drv_cb.dout; s = vif.drv_cb.sout;
        ev = (d != d_p) ^ (s != s_p);
        if (d != d_p && s != s_p) quiet = 0;
        d_p = d; s_p = s;
        if (ev) begin
          if (!rx_on && quiet >= SPW_QUIET) begin rx_on = 1; rnb = 0; rx_esc = 0; end
          quiet = 0;
          if (rx_on) begin
            if (rnb == 1) rxf = d;
            if (rnb >= 2) rsh = {d, rsh[7:1]};
            rnb++;
            if (rnb >= 4 && rnb == (rxf ? 4 : 10)) begin
              if (rxf) begin
                if (rsh[7:6] == SPW_FCT && !rx_esc) credit += 8;
                rx_esc = (rsh[7:6] == SPW_ESC);
              end else rx_esc = 0;
              rnb = 0;
            end
          end
        end else if (quiet < 1000) quiet++;
        if (rx_on && quiet == SPW_QUIET) begin
          rx_on = 0; credit = 0; txq.delete(); pend.delete(); cur_n = 0; sil = SPW_SILENT; resets++;
        end
        // transmitter
        if (sil != 0) begin
          sil--; d_o = 0; s_o = 0; tx_par = 0; tb = 0;
        end else begin
          if (tb == 0) begin
            bit b;
            if (cur_n == 0) begin
              bit [9:0] c;
              if (pend.size() == 0) begin
                if (tcq.size() != 0) begin
                  pend.push_back({1'b0, 1'b1, 8'(SPW_ESC)});
                  pend.push_back({1'b0, 1'b0, tcq.pop_front()});
                end else if (txq.size() != 0 && (txq[0][10] || credit != 0)) begin
                  bit [10:0] q = txq.pop_front();
                  if (!q[10]) credit--;
                  pend.push_back(q[9:0]);
                end else begin
                  pend.push_back({1'b0, 1'b1, 8'(SPW_ESC)});
                  pend.push_back({1'b0, 1'b1, 8'(SPW_FCT)});
                end
              end
              c = pend.pop_front();
              if (c[8]) begin                     // control: P, 1, first bit, second bit
                cur = {6'b0, c[1], c[0], 1'b1, tx_par ^ c[9]};
                cur_n = 4;
                tx_par = c[1] ^ c[0];
              end else begin                      // data: P, 0, 8 bits LSB first
                cur = {c[7:0], 1'b0, !tx_par ^ c[9]};
                cur_n = 10;
                tx_par = ^c[7:0];
              end
            end
            b = cur[0];
            cur = cur >> 1;
            cur_n--;
            if (b == d_o) s_o = !s_o;
            d_o = b;
          end
          tb = (tb + 1 == cfg.bitclk) ? 0 : tb + 1;
        end
        vif.drv_cb.din <= d_o;
        vif.drv_cb.sin <= s_o;
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.din <= 1'b0;
    vif.drv_cb.sin <= 1'b0;
  endtask

  task drive_item(spacewire_transaction t);
    int unsigned r0 = resets, n = 0;
    if (t.kind) tcq.push_back(t.tc);
    else begin
      foreach (t.data[i]) begin
        if (t.fault == 2 && i == t.fpos) begin
          txq.push_back({1'b1, 1'b0, 1'b1, 8'(SPW_ESC)});
          txq.push_back({1'b1, 1'b0, 1'b1, 8'(SPW_EOP)});
        end
        txq.push_back({1'b0, t.fault == 1 && i == t.fpos, 1'b0, t.data[i]});
      end
      txq.push_back({1'b0, 1'b0, 1'b1, 8'(t.eep ? SPW_EEP : SPW_EOP)});
    end
    if (t.fault != 0) begin
      // the link goes down at the fault: the DUT only saw the data before it
      while (resets == r0 && n < 40 * cfg.timeout_cycles) begin @(vif.drv_cb); n++; end
      if (resets == r0) `uvm_error("DRV", "SpaceWire: no link reset after a planted fault")
      while (t.data.size() > t.fpos) void'(t.data.pop_back());
      t.eep = 0;
    end else begin
      while ((txq.size() != 0 || tcq.size() != 0 || pend.size() != 0 || cur_n != 0) && n < 40 * cfg.timeout_cycles) begin
        @(vif.drv_cb); n++;
      end
      if (n >= 40 * cfg.timeout_cycles) `uvm_error("TIMEOUT", "SpaceWire: characters not sent (no credit?)")
      if (resets != r0) `uvm_error("DRV", "SpaceWire: link reset without a fault")
    end
  endtask

endclass
