// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_if.sv -- SpaceWire interface

interface spacewire_if (input logic clk);
  logic rst_n;

  logic din;
  logic sin;
  logic dout;
  logic sout;
  logic rep_valid;
  logic rep_kind;
  logic [15:0] rep_len;
  logic [31:0] rep_crc;
  logic rep_eop;
  logic [2:0] rep_err;
  logic [7:0] rep_tc;
  logic rep_tick;

  modport DUT (input clk, rst_n, input din, input sin, output dout, output sout, output rep_valid, output rep_kind, output rep_len, output rep_crc, output rep_eop, output rep_err, output rep_tc, output rep_tick);
  modport MON (input clk, rst_n, din, sin, dout, sout, rep_valid, rep_kind, rep_len, rep_crc, rep_eop, rep_err, rep_tc, rep_tick);

  clocking drv_cb @(posedge clk);
    input rst_n, dout, sout, rep_valid, rep_kind, rep_len, rep_crc, rep_eop, rep_err, rep_tc, rep_tick;
    inout din, sin;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, din, sin, dout, sout, rep_valid, rep_kind, rep_len, rep_crc, rep_eop, rep_err, rep_tc, rep_tick;
  endclocking
endinterface
