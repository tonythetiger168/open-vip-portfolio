// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_transaction.svh -- SpaceWire transaction

class spacewire_transaction extends uvm_sequence_item;
  `uvm_object_utils(spacewire_transaction)

  // request (driven by the agent)
  rand bit kind;
  bit [7:0] data[$];
  rand bit eep;
  rand bit [7:0] tc;
  rand bit [1:0] fault;
  rand bit [5:0] fpos;
  // response (returned by the DUT)
  bit [15:0] rlen;
  bit [31:0] rcrc;
  bit reop;
  bit [2:0] err;
  bit [7:0] rtc;
  bit tick;
  // bookkeeping (not compared)
  rand bit [5:0] nbytes;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind  { kind dist { 0 := 8, 1 := 2 }; }
  constraint c_len   { nbytes dist { 0 := 1, [1:8] :/ 6, [9:40] :/ 4 }; }
  constraint c_fault { fault dist { 0 := 14, 1 := 1, 2 := 1 }; eep dist { 0 := 6, 1 := 1 }; }

  function new(string name = "spacewire_transaction"); super.new(name); endfunction

  // packet data from the seed; a time-code carries no packet fields and a
  // packet no time-code, and a fault falls inside the data
  function void post_randomize();
    bit [31:0] x = seed | 1;
    data.delete();
    for (int i = 0; i < nbytes; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      data.push_back(x[7:0]);
    end
    if (kind) begin data.delete(); eep = 0; fault = 0; end
    else tc = 0;
    if (data.size() == 0 || fault == 3) fault = 0;
    fpos = (fault != 0) ? x[15:8] % data.size() : 0;
  endfunction

  function void do_copy(uvm_object rhs);
    spacewire_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    kind = rhs_.kind;
    data = rhs_.data;
    eep = rhs_.eep;
    tc = rhs_.tc;
    fault = rhs_.fault;
    fpos = rhs_.fpos;
    rlen = rhs_.rlen;
    rcrc = rhs_.rcrc;
    reop = rhs_.reop;
    err = rhs_.err;
    rtc = rhs_.rtc;
    tick = rhs_.tick;
    nbytes = rhs_.nbytes;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    spacewire_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (kind != rhs_.kind) return 0;
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (eep != rhs_.eep) return 0;
    if (tc != rhs_.tc) return 0;
    if (fault != rhs_.fault) return 0;
    if (fpos != rhs_.fpos) return 0;
    if (rlen != rhs_.rlen) return 0;
    if (rcrc != rhs_.rcrc) return 0;
    if (reop != rhs_.reop) return 0;
    if (err != rhs_.err) return 0;
    if (rtc != rhs_.rtc) return 0;
    if (tick != rhs_.tick) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(spacewire_transaction rhs_);
    if (kind != rhs_.kind) return 0;
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (eep != rhs_.eep) return 0;
    if (tc != rhs_.tc) return 0;
    if (fault != rhs_.fault) return 0;
    if (fpos != rhs_.fpos) return 0;
    return 1;
  endfunction

  function string qstr_data();
    string s = $sformatf("[%0d]{", data.size());
    foreach (data[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", data[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SpaceWire{tag=%0d kind=0x%0h data=%s eep=0x%0h tc=0x%0h fault=0x%0h fpos=0x%0h rlen=0x%0h rcrc=0x%0h reop=0x%0h err=0x%0h rtc=0x%0h tick=0x%0h}", tag, kind, qstr_data(), eep, tc, fault, fpos, rlen, rcrc, reop, err, rtc, tick);
  endfunction
endclass
