// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_coverage.svh -- SpaceWire functional coverage

class spacewire_coverage extends uvm_subscriber #(spacewire_transaction);
  `uvm_component_utils(spacewire_coverage)
  spacewire_config cfg;
  spacewire_transaction tr;

  covergroup spacewire_cg;
    cp_kind  : coverpoint tr.kind;
    cp_len   : coverpoint tr.data.size() { bins empty = {0}; bins short_ = {[1:8]}; bins credit1 = {[9:16]}; bins long_ = {[17:$]}; }
    cp_end   : coverpoint {tr.fault != 0, tr.eep} iff (!tr.kind) { bins eop = {2'b00}; bins eep = {2'b01}; bins cut = {2'b10}; }
    cp_fault : coverpoint tr.fault { bins none = {0}; bins parity = {1}; bins escape = {2}; }
    cp_tick  : coverpoint tr.tick iff (tr.kind);
    cp_flags : coverpoint tr.tc[7:6] iff (tr.kind);
    x_len_fault : cross cp_len, cp_fault { ignore_bins empty_fault = binsof(cp_len.empty) && !binsof(cp_fault.none); }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    spacewire_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(spacewire_config)::get(this, "", "cfg", cfg))
      cfg = spacewire_config::type_id::create("cfg");
  endfunction

  function void write(spacewire_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    spacewire_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SpaceWire coverage: %0.1f%%", spacewire_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
