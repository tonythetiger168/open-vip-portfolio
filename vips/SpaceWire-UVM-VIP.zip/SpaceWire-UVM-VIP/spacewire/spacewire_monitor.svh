// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spacewire_monitor.svh -- SpaceWire monitor: characters decoded from the D / S wires: packets up to EOP / EEP, time-codes, parity and escape faults; completed by the DUT's report

class spacewire_monitor extends uvm_monitor;
  `uvm_component_utils(spacewire_monitor)

  virtual spacewire_if vif;
  uvm_analysis_port #(spacewire_transaction) ap;
  spacewire_config cfg;
  int unsigned n_obs = 0;

  spacewire_transaction done_q[$], rep_q[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual spacewire_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spacewire: virtual interface not set")
    if (!uvm_config_db#(spacewire_config)::get(this, "", "cfg", cfg))
      cfg = spacewire_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit d_p = 0, s_p = 0, on = 0, f = 0, p = 0, par = 0, esc = 0;
      int unsigned quiet = 0, nb = 0;
      bit [7:0] sh = 0;
      bit [7:0] data[$];
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rep_valid) begin
          spacewire_transaction r = spacewire_transaction::type_id::create("r");
          r.rlen = vif.mon_cb.rep_len; r.rcrc = vif.mon_cb.rep_crc; r.reop = vif.mon_cb.rep_eop;
          r.err = vif.mon_cb.rep_err; r.rtc = vif.mon_cb.rep_tc; r.tick = vif.mon_cb.rep_tick;
          rep_q.push_back(r);
        end
        if ((vif.mon_cb.din != d_p) && (vif.mon_cb.sin != s_p)) quiet = 0;   // lines dropped
        else if ((vif.mon_cb.din != d_p) || (vif.mon_cb.sin != s_p)) begin
          bit d = vif.mon_cb.din;
          if (!on && quiet >= SPW_QUIET) begin on = 1; nb = 0; par = 0; esc = 0; data.delete(); end
          quiet = 0;
          if (on) begin
            if (nb == 0) p = d;
            else if (nb == 1) begin
              f = d;
              if ((p ^ d ^ par) != 1'b1) begin item(data, 0, 1); on = 0; end
            end else sh = {d, sh[7:1]};
            if (on) nb++;
            if (on && nb >= 4 && nb == (f ? 4 : 10)) begin
              nb = 0;
              if (f) begin
                bit [1:0] c = sh[7:6];
                par = c[1] ^ c[0];
                if (esc) begin
                  esc = 0;
                  if (c != SPW_FCT) begin item(data, 0, 2); on = 0; end
                end else if (c == SPW_ESC) esc = 1;
                else if (c != SPW_FCT) begin item(data, c == SPW_EEP, 0); data.delete(); end
              end else begin
                par = ^sh;
                if (esc) begin esc = 0; tc_item(sh); end
                else data.push_back(sh);
              end
            end
          end
        end else if (quiet < 1000) quiet++;
        d_p = vif.mon_cb.din; s_p = vif.mon_cb.sin;
        while (done_q.size() != 0 && rep_q.size() != 0) begin
          spacewire_transaction t = done_q.pop_front(), r = rep_q.pop_front();
          t.rlen = r.rlen; t.rcrc = r.rcrc; t.reop = r.reop; t.err = r.err; t.rtc = r.rtc; t.tick = r.tick;
          publish(t);
        end
      end
    end
  endtask

  function void publish(spacewire_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  function void item(bit [7:0] data[$], bit eep, bit [1:0] fault);
    spacewire_transaction t = spacewire_transaction::type_id::create("t");
    t.kind = 0; t.eep = eep; t.fault = fault;
    foreach (data[i]) t.data.push_back(data[i]);
    t.fpos = (fault != 0) ? data.size() : 0;
    done_q.push_back(t);
  endfunction
  function void tc_item(bit [7:0] v);
    spacewire_transaction t = spacewire_transaction::type_id::create("t");
    t.kind = 1; t.tc = v;
    done_q.push_back(t);
  endfunction
endclass
