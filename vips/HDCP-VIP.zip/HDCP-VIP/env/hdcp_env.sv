// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdcp_env.sv -- HDCP 2.3 verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import hdcp_defs_pkg::*;
  import hdcp_pkg::*;

  // End-to-end scoreboard: compares driver-issued (expected) authentication
  // rounds against monitor-decoded (observed) ones. Rounds aborted by error
  // injection are checked by error class; clean rounds compare the exchanged
  // aksv / bksv / riv / enc_en.
    `uvm_analysis_imp_decl(_exp)
    `uvm_analysis_imp_decl(_obs)

  class hdcp_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(hdcp_scoreboard)
    uvm_analysis_imp_exp #(hdcp_transaction, hdcp_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(hdcp_transaction, hdcp_scoreboard) obs_ap;

    hdcp_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, mismatches = 0, error_hits = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(hdcp_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(hdcp_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        hdcp_transaction e = exp_q.pop_front();
        hdcp_transaction o = obs_q.pop_front();
        if (e.err_inject != HDCP_ERR_NONE || o.err_inject != HDCP_ERR_NONE) begin
          if (e.err_inject == o.err_inject) error_hits++;
          else begin
            mismatches++;
            `uvm_error("SB", $sformatf("error-class mismatch exp{%s} obs{%s}",
                       e.convert2string(), o.convert2string()))
          end
        end
        else if (e.aksv == o.aksv && e.bksv == o.bksv && e.riv == o.riv &&
                 e.enc_en == o.enc_en)
          n_matches++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("hdcp scoreboard: n_matches=%0d error_hits=%0d mismatches=%0d",
                n_matches, error_hits, mismatches), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class hdcp_env extends uvm_env;
    `uvm_component_utils(hdcp_env)
    hdcp_agent      agt;
    hdcp_scoreboard sb;
    hdcp_checker    chk;
    hdcp_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = hdcp_agent::type_id::create("agt", this);
      sb  = hdcp_scoreboard::type_id::create("sb", this);
      chk = hdcp_checker::type_id::create("chk", this);
      cov = hdcp_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
