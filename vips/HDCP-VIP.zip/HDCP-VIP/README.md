# HDCP — HDCP 2.3 Content Protection UVM VIP

Open-source UVM verification IP template for **HDCP 2.3** (Security).

## Contents

| Path | Description |
|------|-------------|
| `hdcp/hdcp_if.sv` | DDC (I2C-like) + Ri link-integrity interface + modports/clocking |
| `hdcp/hdcp_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `hdcp/sva/hdcp_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=5) |
| `hdcp/vip/hdcp/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/hdcp_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional HDCP receiver DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged DDC master driver** (I2C-like, open-drain SDA): full
  authentication exchange AKE_INIT (aksv) -> AKE_SEND_CERT (bksv read) ->
  LC_INIT (rN) -> SKE_SEND_EKS, then the ENCRYPTED phase driving a per-frame
  transmitter Ri and checking `ri_valid` every frame
- **KSV validity model**: `$countones(aksv)==20` constraint, receiver bksv
  read back over DDC, revocation-list check aborting to IDLE on a revoked bksv
- **Dual-process monitor**: DDC byte-stream decode (START/STOP, register
  offset, aksv/riv capture, bksv read) + link-integrity watch (ENCRYPTED
  entry, per-frame `ri_valid`) reconstructing one transaction per
  authentication round
- **End-to-end scoreboard**: driver expected vs monitor observed; clean
  rounds compare aksv/bksv/riv/enc_en, error rounds compare error class
- **Functional DUT model**: HDCP receiver answering certificate reads with
  its bksv (revoked on request), capturing aksv/rN, recomputing the abstract
  Ri `ri_compute(aksv, bksv, frame)` once per frame while ENCRYPTED
- **Directed sequence library**: full auth / auth-only / short / long frames /
  re-authentication / revoked-bksv / ri-mismatch / reset + random + regression
- **Functional coverage**: enc_en x frame-count cross, aksv/riv corners,
  authentication FSM chains (full chain, abort, auth-only, link down),
  error-class bins
- **SVA L4**: ENCRYPTED only after SKE_SEND_EKS, Ri refreshed within 64
  cycles, auth failure returns to IDLE, DDC address fixed at 0x74,
  hdcp_enable only in ENCRYPTED
