// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator  (vvp 12 segfaults in the model's DDC slave)
//
// func_hdcp_tb.sv -- self-checking functional test for the HDCP receiver
// model (hdcp_receiver_model in tb/top_tb.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py HDCP-VIP
//
// Model contract (from tb/top_tb.sv and hdcp_defs_pkg):
//   * DDC slave at 7-bit address 0x74 on an open-drain SDA. A write sets a
//     register offset and appends the following bytes: AKE_INIT (0x01)
//     shifts them into Aksv, LC_INIT (0x03) into rN; other offsets are
//     ACKed and ignored. A read returns Bksv, 5 bytes MSB first, until the
//     master NACKs; Bksv is A5C3F01234, or DEADBEEF01 when rcv_revoked.
//   * Ri: on entering ENCRYPTED, ri = ri_compute(Aksv, Bksv, 0) and then
//     ri_compute(..., k) every 16 clocks, with ri_compute = aksv[15:0] ^
//     bksv[15:0] ^ {k[7:0], ~k[7:0]} ^ 0x9E37.
// Known defect (XFAIL): the DDC read path takes Bksv from a static variable
// initialised once at time 0, so rcv_revoked has no effect on reads (the Ri
// path does follow it).
// Known deviation (XFAIL): HDCP places the receiver at DDC address 0x74
// (write) / 0x75 (read), i.e. 7-bit 0x3A; the model decodes 7-bit 0x74.

module func_hdcp_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [2:0] ST_IDLE = 0, ST_AKE = 1, ST_ENC = 5;
  localparam bit [39:0] BKSV = 40'hA5_C3_F0_12_34, BKSV_REV = 40'hDE_AD_BE_EF_01;
  localparam time T = 20;
  int checks = 0, fails = 0, xfails = 0;

  logic clk = 1'b0, rst_n = 1'b0, scl = 1'b1, m_sda = 1'b1, revoked = 1'b0;
  logic [2:0] state = ST_IDLE;
  wire  s_o, s_oe;
  wire  [15:0] ri;
  wire  sda = m_sda & (s_oe ? s_o : 1'b1);

  always #5 clk = ~clk;

  hdcp_receiver_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_ddc_scl(scl), .vif_ddc_sda(sda),
    .vif_rcv_revoked(revoked), .vif_rcv_sda_o(s_o), .vif_rcv_sda_oe(s_oe), .vif_ri(ri),
    .vif_state(state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // ---- DDC (I2C) master ----
  task automatic start_c(); m_sda = 1; scl = 1; #T; m_sda = 0; #T; scl = 0; #T; endtask
  task automatic stop_c();  m_sda = 0; #T; scl = 1; #T; m_sda = 1; #T; endtask
  task automatic wbit(input bit b); m_sda = b; #T; scl = 1; #(2*T); scl = 0; #T; endtask
  task automatic rbit(output bit b); m_sda = 1; #T; scl = 1; #T; b = sda; #T; scl = 0; #T; endtask
  task automatic wbyte(input [7:0] d, output bit ack);
    bit a;
    for (int i = 7; i >= 0; i--) wbit(d[i]);
    rbit(a); ack = !a;
  endtask
  task automatic rbyte(output [7:0] d, input bit nack);
    for (int i = 7; i >= 0; i--) rbit(d[i]);
    wbit(nack);
  endtask

  bit acks;
  task automatic ddc_write(input [7:0] addr8, input [7:0] off, input logic [7:0] b[$]);
    bit k;
    start_c();
    wbyte(addr8, acks);
    if (acks) begin
      wbyte(off, k); acks &= k;
      foreach (b[i]) begin wbyte(b[i], k); acks &= k; end
    end
    stop_c();
    #(4*T);
  endtask

  logic [7:0] rd[$];
  task automatic ddc_read(input [7:0] addr8, input int n);
    logic [7:0] d;
    rd.delete();
    start_c();
    wbyte(addr8, acks);
    if (acks) for (int i = 0; i < n; i++) begin rbyte(d, i == n - 1); rd.push_back(d); end
    stop_c();
    #(4*T);
  endtask

  function automatic logic [15:0] ri_ref(input [39:0] a, input [39:0] b, input int k);
    return a[15:0] ^ b[15:0] ^ {k[7:0], ~k[7:0]} ^ 16'h9E37;
  endfunction

  localparam logic [7:0] W = {7'h74, 1'b0}, R = {7'h74, 1'b1};
  logic [39:0] aksv = 40'h51_1E_F2_1A_CD;

  initial begin
    #(3*T); rst_n = 1; #(3*T);

    // DDC address
    ddc_read(8'h75, 1);
    chk_xfail(acks, "receiver answers at the HDCP DDC read address 0x75");
    ddc_read(8'h44, 1);
    chk(!acks, "other DDC addresses are not ACKed");

    // Bksv read
    ddc_read(R, 5);
    chk(acks && rd.size() == 5 && {rd[0], rd[1], rd[2], rd[3], rd[4]} == BKSV,
        "Bksv read back, 5 bytes MSB first");
    ddc_read(R, 2);
    chk(rd.size() == 2 && rd[0] == BKSV[39:32] && rd[1] == BKSV[31:24], "master NACK ends the Bksv read early");
    revoked = 1;
    ddc_read(R, 5);
    chk_xfail({rd[0], rd[1], rd[2], rd[3], rd[4]} == BKSV_REV, "revoked receiver presents the revoked Bksv");
    revoked = 0;

    // Aksv and rN writes
    ddc_write(W, 8'h01, '{aksv[39:32], aksv[31:24], aksv[23:16], aksv[15:8], aksv[7:0]});
    chk(acks && u_dut.aksv_reg == aksv, "AKE_INIT write: all bytes ACKed, Aksv stored");
    ddc_write(W, 8'h03, '{8'h01, 8'h23, 8'h45, 8'h67, 8'h89, 8'hAB, 8'hCD, 8'hEF});
    chk(acks && u_dut.riv_reg == 64'h0123_4567_89AB_CDEF, "LC_INIT write: rN stored");
    chk(u_dut.aksv_reg == aksv, "LC_INIT does not touch Aksv");
    ddc_write(W, 8'h04, '{8'hFF, 8'hFF, 8'hFF, 8'hFF});
    chk(acks && u_dut.aksv_reg == aksv && u_dut.riv_reg == 64'h0123_4567_89AB_CDEF,
        "SKE write ACKed without changing Aksv or rN");
    ddc_write(8'h44, 8'h01, '{8'h00});
    chk(!acks && u_dut.aksv_reg == aksv, "write to another address ignored");

    // link integrity Ri
    @(negedge clk); state = ST_AKE;
    repeat (3) @(negedge clk);
    chk(ri == 0, "no Ri before encryption");
    state = ST_ENC;
    @(negedge clk);
    chk(ri == ri_ref(aksv, BKSV, 0), "Ri(0) on entering ENCRYPTED");
    repeat (15) @(negedge clk);
    chk(ri == ri_ref(aksv, BKSV, 0), "Ri held for 16 clocks");
    @(negedge clk);
    chk(ri == ri_ref(aksv, BKSV, 1), "Ri(1) after 16 clocks");
    repeat (16 * 3) @(negedge clk);
    chk(ri == ri_ref(aksv, BKSV, 4), "Ri(4) after 64 clocks");
    revoked = 1;
    repeat (16) @(negedge clk);
    chk(ri == ri_ref(aksv, BKSV_REV, 5), "Ri follows the presented Bksv");
    revoked = 0;

    // re-authentication restarts the frame index
    state = ST_IDLE; repeat (2) @(negedge clk);
    chk(ri == ri_ref(aksv, BKSV_REV, 5), "Ri held outside ENCRYPTED");
    aksv = 40'h0F_0F_0F_33_CC;
    ddc_write(W, 8'h01, '{aksv[39:32], aksv[31:24], aksv[23:16], aksv[15:8], aksv[7:0]});
    @(negedge clk); state = ST_ENC;
    @(negedge clk);
    chk(ri == ri_ref(aksv, BKSV, 0), "new Aksv: Ri restarts at frame 0");

    // reset
    @(negedge clk); rst_n = 0;
    @(negedge clk);
    chk(ri == 0, "reset clears Ri");
    rst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
