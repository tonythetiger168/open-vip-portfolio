// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- HDCP 2.3 testbench top with a functional HDCP receiver DUT

`ifndef HDCP_TB_SV
`define HDCP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import hdcp_defs_pkg::*;
import hdcp_pkg::*;
import hdcp_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  hdcp_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  hdcp_receiver_model dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual hdcp_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional HDCP receiver: answers DDC reads with its bksv (revoked on
// request), captures aksv / rN from DDC writes, and recomputes the Ri
// integrity value once per frame while the link is ENCRYPTED.
module hdcp_receiver_model (hdcp_if vif);

  bit [39:0] aksv_reg;
  bit [63:0] riv_reg;
  int unsigned frame_cnt = 0;
  int fcnt = 0;
  hdcp_state_e prev_st = IDLE;

  initial begin
    vif.rcv_sda_o  = 0;
    vif.rcv_sda_oe = 0;
    vif.ri         = 16'h0000;
  end

  function automatic bit [39:0] bksv_sel();
    return vif.rcv_revoked ? BKSV_REVOKED : BKSV_VALID;
  endfunction

  // ---- per-frame Ri update while ENCRYPTED ----
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      vif.ri <= 16'h0000;
      frame_cnt <= 0;
      fcnt <= 0;
      prev_st <= IDLE;
    end else begin
      prev_st <= vif.state;
      if (vif.state == ENCRYPTED) begin
        if (prev_st != ENCRYPTED) begin
          frame_cnt <= 0;
          fcnt <= 0;
          vif.ri <= ri_compute(aksv_reg, bksv_sel(), 0);
        end else if (fcnt == 15) begin
          fcnt <= 0;
          frame_cnt <= frame_cnt + 1;
          vif.ri <= ri_compute(aksv_reg, bksv_sel(), frame_cnt + 1);
        end else begin
          fcnt <= fcnt + 1;
        end
      end
    end
  end

  // ---- DDC slave (open-drain sda) ----
  task automatic drive_ack();
    // called right after the 8th falling edge of scl
    vif.rcv_sda_oe = 1; vif.rcv_sda_o = 0;      // ACK
    @(negedge vif.ddc_scl);                     // end of the ack clock
    vif.rcv_sda_oe = 0;
  endtask

  task automatic sample8(output bit [7:0] d);
    for (int i = 7; i >= 0; i--) begin
      @(posedge vif.ddc_scl);
      d[i] = vif.ddc_sda;
      @(negedge vif.ddc_scl);
    end
  endtask

  // sample8 with concurrent STOP detection (sda rising while scl high),
  // single-threaded: no fork/disable fork, no @(sda iff scl)
  task automatic sample8_stop(output bit [7:0] d, output bit stop);
    bit ps, pd, got;
    d = '0; stop = 0;
    ps = vif.ddc_scl; pd = vif.ddc_sda;
    for (int i = 7; i >= 0 && !stop; i--) begin
      got = 0;
      while (!got && !stop) begin
        @(vif.ddc_scl or vif.ddc_sda);
        if (vif.ddc_scl === 1'b1 && ps === 1'b0)                              got = 1;
        else if (vif.ddc_sda === 1'b1 && pd === 1'b0 && vif.ddc_scl === 1'b1) stop = 1;
        ps = vif.ddc_scl; pd = vif.ddc_sda;
      end
      if (!stop) begin
        d[i] = vif.ddc_sda;
        got = 0;
        while (!got && !stop) begin
          @(vif.ddc_scl or vif.ddc_sda);
          if (vif.ddc_scl === 1'b0 && ps === 1'b1)                              got = 1;
          else if (vif.ddc_sda === 1'b1 && pd === 1'b0 && vif.ddc_scl === 1'b1) stop = 1;
          ps = vif.ddc_scl; pd = vif.ddc_sda;
        end
      end
    end
  endtask

  task automatic send_byte(input bit [7:0] d, output bit master_nack);
    for (int i = 7; i >= 0; i--) begin
      vif.rcv_sda_oe = 1; vif.rcv_sda_o = d[i];
      @(negedge vif.ddc_scl);
    end
    vif.rcv_sda_oe = 0;
    @(posedge vif.ddc_scl);
    master_nack = vif.ddc_sda;
    @(negedge vif.ddc_scl);
  endtask

  initial forever begin : ddc_slave
    bit [7:0] d, reg_addr;
    bit rw, stop, nack;
    int unsigned cnt;
    // wait for START (sda falls while scl high) -- @(negedge sda iff scl)
    // rewritten as a polling loop (iff event control is not portable)
    stop = 0;
    while (!stop) begin
      @(negedge vif.ddc_sda);
      if (vif.ddc_scl === 1'b1) stop = 1;
    end
    sample8(d);
    rw = d[0];
    if (d[7:1] == HDCP_DDC_ADDR) begin
      drive_ack();
      if (!rw) begin
        // register offset + payload bytes until STOP
        sample8(reg_addr);
        drive_ack();
        cnt = 0;
        stop = 0;
        while (!stop) begin
          sample8_stop(d, stop);
          if (!stop) begin
            case (reg_addr)
              REG_AKE_INIT: aksv_reg = {aksv_reg[31:0], d};
              REG_LC_INIT : riv_reg  = {riv_reg[55:0], d};
              default     : ;
            endcase
            cnt++;
            drive_ack();
          end
        end
      end else begin
        // certificate read: return the 40-bit bksv, MSB first
        bit [39:0] bksv = bksv_sel();
        nack = 0;
        for (int i = 4; i >= 0 && !nack; i--) begin
          send_byte(bksv[i*8 +: 8], nack);
        end
      end
    end
  end
endmodule
`endif
