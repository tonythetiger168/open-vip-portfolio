// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdcp_sequences.svh -- HDCP 2.3 sequence library

`ifndef HDCP_SEQUENCES_SVH
`define HDCP_SEQUENCES_SVH

class hdcp_base_sequence extends uvm_sequence #(hdcp_transaction);
  `uvm_object_utils(hdcp_base_sequence)
  int num_txns = 10;
  function new(string name = "hdcp_base_sequence"); super.new(name); endfunction
  task body();
    hdcp_transaction tr;
    repeat (num_txns) begin
      tr = hdcp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: full authentication + encrypted link integrity (clean)
class hdcp_auth_seq extends hdcp_base_sequence;
  function new(string name = "hdcp_auth_seq"); super.new(name); endfunction
  `uvm_object_utils(hdcp_auth_seq)
  task body();
    hdcp_transaction tr;
    repeat (num_txns) begin
      tr = hdcp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { enc_en == 1; err_inject == HDCP_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: authenticate only, never enter the ENCRYPTED phase
class hdcp_auth_only_seq extends hdcp_base_sequence;
  function new(string name = "hdcp_auth_only_seq"); super.new(name); endfunction
  `uvm_object_utils(hdcp_auth_only_seq)
  task body();
    hdcp_transaction tr;
    repeat (num_txns) begin
      tr = hdcp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { enc_en == 0; err_inject == HDCP_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: receiver presents a revoked bksv, transmitter aborts
class hdcp_revoked_bksv_seq extends hdcp_base_sequence;
  function new(string name = "hdcp_revoked_bksv_seq"); super.new(name); endfunction
  `uvm_object_utils(hdcp_revoked_bksv_seq)
  task body();
    hdcp_transaction tr;
    repeat (num_txns) begin
      tr = hdcp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { err_inject == HDCP_ERR_BKSV_REVOKED; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: transmitter ri corrupted on the last frame
class hdcp_ri_mismatch_seq extends hdcp_base_sequence;
  function new(string name = "hdcp_ri_mismatch_seq"); super.new(name); endfunction
  `uvm_object_utils(hdcp_ri_mismatch_seq)
  task body();
    hdcp_transaction tr;
    repeat (num_txns) begin
      tr = hdcp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { enc_en == 1;
                                  err_inject == HDCP_ERR_RI_MISMATCH; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: minimum-length link integrity phase
class hdcp_short_frame_seq extends hdcp_base_sequence;
  function new(string name = "hdcp_short_frame_seq"); super.new(name); endfunction
  `uvm_object_utils(hdcp_short_frame_seq)
  task body();
    hdcp_transaction tr;
    repeat (num_txns) begin
      tr = hdcp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { enc_en == 1; num_frames == 2;
                                  err_inject == HDCP_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: maximum-length link integrity phase (ri refresh stress)
class hdcp_long_frame_seq extends hdcp_base_sequence;
  function new(string name = "hdcp_long_frame_seq"); super.new(name); endfunction
  `uvm_object_utils(hdcp_long_frame_seq)
  task body();
    hdcp_transaction tr;
    repeat (num_txns) begin
      tr = hdcp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { enc_en == 1; num_frames == 6;
                                  err_inject == HDCP_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: re-authentication stress (back-to-back rounds, same aksv)
class hdcp_reauth_seq extends hdcp_base_sequence;
  function new(string name = "hdcp_reauth_seq"); super.new(name); endfunction
  `uvm_object_utils(hdcp_reauth_seq)
  rand bit [39:0] fixed_aksv;
  constraint c_fixed { $countones(fixed_aksv) == 20; }
  task body();
    hdcp_transaction tr;
    void'(this.randomize());
    repeat (num_txns) begin
      tr = hdcp_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { aksv == fixed_aksv;
                                  err_inject == HDCP_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single clean round right after reset release
class hdcp_reset_seq extends hdcp_base_sequence;
  function new(string name = "hdcp_reset_seq"); super.new(name); endfunction
  `uvm_object_utils(hdcp_reset_seq)
  task body();
    hdcp_transaction tr = hdcp_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { enc_en == 1; num_frames == 2;
                                err_inject == HDCP_ERR_NONE; });
    finish_item(tr);
  endtask
endclass

class hdcp_random_sequence extends hdcp_base_sequence;
  `uvm_object_utils(hdcp_random_sequence)
  function new(string name = "hdcp_random_sequence"); super.new(name); num_txns = 25; endfunction
endclass

// Regression: weighted mix of all directed sequences
class hdcp_regression_sequence extends hdcp_base_sequence;
  `uvm_object_utils(hdcp_regression_sequence)
  function new(string name = "hdcp_regression_sequence"); super.new(name); endfunction
  task body();
    hdcp_auth_seq         auth = hdcp_auth_seq::type_id::create("auth");
    hdcp_auth_only_seq    aonly = hdcp_auth_only_seq::type_id::create("aonly");
    hdcp_short_frame_seq  shrt = hdcp_short_frame_seq::type_id::create("shrt");
    hdcp_long_frame_seq   lng  = hdcp_long_frame_seq::type_id::create("lng");
    hdcp_reauth_seq       re   = hdcp_reauth_seq::type_id::create("re");
    hdcp_revoked_bksv_seq rev  = hdcp_revoked_bksv_seq::type_id::create("rev");
    hdcp_ri_mismatch_seq  rim  = hdcp_ri_mismatch_seq::type_id::create("rim");
    auth.num_txns = 8; aonly.num_txns = 4; shrt.num_txns = 4; lng.num_txns = 4;
    re.num_txns = 4; rev.num_txns = 2; rim.num_txns = 2;
    auth.start(m_sequencer); aonly.start(m_sequencer); shrt.start(m_sequencer);
    lng.start(m_sequencer); re.start(m_sequencer);
    rev.start(m_sequencer); rim.start(m_sequencer);
  endtask
endclass
`endif
