// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdcp_driver.svh -- HDCP 2.3 transmitter driver: bit-banged DDC (I2C-like)
// authentication exchange (AKE_INIT / AKE_SEND_CERT / LC_INIT /
// SKE_SEND_EKS) followed by the ENCRYPTED phase with per-frame Ri checks.

`ifndef HDCP_DRIVER_SVH
`define HDCP_DRIVER_SVH

class hdcp_driver extends uvm_driver #(hdcp_transaction);
  `uvm_component_utils(hdcp_driver)
  virtual hdcp_if vif;
  hdcp_config cfg;
  uvm_analysis_port #(hdcp_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hdcp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hdcp virtual interface not set")
  endfunction

  // ---- low-level DDC line control (open-drain sda: oe=0 releases) ----
  task set_sda(bit v); vif.drv_cb.mst_sda_o  <= v; vif.drv_cb.mst_sda_oe <= 1; endtask
  task rel_sda();      vif.drv_cb.mst_sda_oe <= 0; endtask
  task set_scl(bit v); vif.drv_cb.mst_scl_o  <= v; endtask

  task ddc_start();
    rel_sda(); set_scl(1); repeat (4) @(vif.drv_cb);
    set_sda(0);            repeat (4) @(vif.drv_cb);   // sda falls while scl high
    set_scl(0);            repeat (4) @(vif.drv_cb);
  endtask

  task ddc_stop();
    set_sda(0); set_scl(1); repeat (4) @(vif.drv_cb);
    rel_sda();              repeat (4) @(vif.drv_cb);   // sda rises while scl high
  endtask

  task ddc_write_bit(bit b);
    if (b) rel_sda(); else set_sda(0);
    set_scl(1); repeat (4) @(vif.drv_cb);               // data valid during high
    set_scl(0); repeat (4) @(vif.drv_cb);
  endtask

  task ddc_read_bit(output bit b);
    rel_sda();
    set_scl(1); repeat (2) @(vif.drv_cb);
    b = vif.drv_cb.ddc_sda;
    repeat (2) @(vif.drv_cb);
    set_scl(0); repeat (4) @(vif.drv_cb);
  endtask

  task ddc_write_byte(bit [7:0] d, output bit nack);
    for (int i = 7; i >= 0; i--) ddc_write_bit(d[i]);
    ddc_read_bit(nack);                                  // ACK slot from receiver
  endtask

  task ddc_read_byte(output bit [7:0] d, input bit master_nack);
    for (int i = 7; i >= 0; i--) ddc_read_bit(d[i]);
    ddc_write_bit(master_nack);                          // ACK=0 / NACK=1
  endtask

  // Write register offset + payload to the receiver
  task ddc_write_reg(bit [7:0] reg_addr, bit [7:0] payload[$]);
    bit nack;
    ddc_start();
    ddc_write_byte({hdcp_defs_pkg::HDCP_DDC_ADDR, 1'b0}, nack);
    if (nack) `uvm_warning("DRV", "receiver NACKed DDC address")
    ddc_write_byte(reg_addr, nack);
    foreach (payload[i]) begin
      ddc_write_byte(payload[i], nack);
      if (nack) begin `uvm_warning("DRV", "receiver NACKed payload"); break; end
    end
    ddc_stop();
  endtask

  // Read the 40-bit receiver KSV (MSB first)
  task ddc_read_bksv(output bit [39:0] ksv);
    bit nack;
    bit [7:0] d;
    ddc_start();
    ddc_write_byte({hdcp_defs_pkg::HDCP_DDC_ADDR, 1'b1}, nack);
    for (int i = 4; i >= 0; i--) begin
      ddc_read_byte(d, i == 0);                          // NACK last byte
      ksv[i*8 +: 8] = d;
    end
    ddc_stop();
  endtask

  task run_phase(uvm_phase phase);
    hdcp_transaction tr;
    vif.drv_cb.mst_sda_oe  <= 0;
    vif.drv_cb.mst_scl_o   <= 1;
    vif.drv_cb.ddc_addr    <= hdcp_defs_pkg::HDCP_DDC_ADDR;
    vif.drv_cb.tx_ri       <= 16'h0000;
    vif.drv_cb.rcv_revoked <= 0;
    vif.drv_cb.auth_fail   <= 0;
    vif.drv_cb.hdcp_enable <= 0;
    vif.drv_cb.state       <= hdcp_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    forever begin
      bit [7:0] payload[$];
      bit [39:0] bksv;
      bit failed = 0;
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)

      // ---- AKE_INIT: send aksv ----
      vif.drv_cb.state <= hdcp_defs_pkg::AKE_INIT;
      payload.delete();
      for (int i = 4; i >= 0; i--) payload.push_back(tr.aksv[i*8 +: 8]);
      ddc_write_reg(hdcp_defs_pkg::REG_AKE_INIT, payload);
      repeat (4) @(vif.drv_cb);

      // ---- AKE_SEND_CERT: read bksv ----
      vif.drv_cb.state <= hdcp_defs_pkg::AKE_SEND_CERT;
      vif.drv_cb.rcv_revoked <= (tr.err_inject == HDCP_ERR_BKSV_REVOKED);
      ddc_read_bksv(bksv);
      vif.drv_cb.rcv_revoked <= 0;
      tr.bksv = bksv;
      if (bksv == hdcp_defs_pkg::BKSV_REVOKED) begin
        `uvm_warning("DRV", "bksv on revocation list, aborting authentication")
        vif.drv_cb.auth_fail <= 1;
        vif.drv_cb.state     <= hdcp_defs_pkg::IDLE;
        @(vif.drv_cb);
        vif.drv_cb.auth_fail <= 0;
        repeat (8) @(vif.drv_cb);
        drv_ap.write(tr);
        seq_item_port.item_done();
        continue;
      end

      // ---- LC_INIT: send rN (riv) ----
      vif.drv_cb.state <= hdcp_defs_pkg::LC_INIT;
      payload.delete();
      for (int i = 7; i >= 0; i--) payload.push_back(tr.riv[i*8 +: 8]);
      ddc_write_reg(hdcp_defs_pkg::REG_LC_INIT, payload);
      repeat (4) @(vif.drv_cb);

      // ---- SKE_SEND_EKS: send abstract encrypted session key ----
      vif.drv_cb.state <= hdcp_defs_pkg::SKE_SEND_EKS;
      payload.delete();
      begin
        bit [31:0] eks = tr.aksv[31:0] ^ tr.riv[31:0];
        for (int i = 3; i >= 0; i--) payload.push_back(eks[i*8 +: 8]);
      end
      ddc_write_reg(hdcp_defs_pkg::REG_SKE_SEND_EKS, payload);
      repeat (4) @(vif.drv_cb);

      if (!tr.enc_en) begin
        vif.drv_cb.state <= hdcp_defs_pkg::IDLE;
        repeat (8) @(vif.drv_cb);
        drv_ap.write(tr);
        seq_item_port.item_done();
        continue;
      end

      // ---- ENCRYPTED: per-frame Ri verification ----
      vif.drv_cb.state       <= hdcp_defs_pkg::ENCRYPTED;
      vif.drv_cb.hdcp_enable <= 1;
      for (int f = 0; f < tr.num_frames; f++) begin
        bit [15:0] exp_ri = hdcp_defs_pkg::ri_compute(tr.aksv, tr.bksv, f);
        vif.drv_cb.tx_ri <= (tr.err_inject == HDCP_ERR_RI_MISMATCH &&
                             f == tr.num_frames - 1) ? ~exp_ri : exp_ri;
        // sample ri_valid mid-frame: the receiver updates its ri two cycles
        // after each 16-cycle frame boundary, so the settled window is
        // [frame+2 .. frame+15]
        repeat (8) @(vif.drv_cb);
        if (vif.drv_cb.ri_valid !== 1'b1) begin
          `uvm_warning("DRV", $sformatf("ri mismatch on frame %0d", f))
          failed = 1;
          break;
        end
        repeat (8) @(vif.drv_cb);
      end
      vif.drv_cb.hdcp_enable <= 0;
      vif.drv_cb.state       <= hdcp_defs_pkg::IDLE;
      if (failed) begin
        vif.drv_cb.auth_fail <= 1;
        @(vif.drv_cb);
        vif.drv_cb.auth_fail <= 0;
      end
      repeat (8) @(vif.drv_cb);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
