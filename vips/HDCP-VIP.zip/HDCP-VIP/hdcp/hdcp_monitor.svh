// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdcp_monitor.svh -- HDCP monitor: decodes the DDC byte stream
// (aksv / bksv / riv exchange) and watches the link-integrity phase
// (ENCRYPTED entry, per-frame ri_valid) to reconstruct one transaction
// per authentication round.

`ifndef HDCP_MONITOR_SVH
`define HDCP_MONITOR_SVH

class hdcp_monitor extends uvm_monitor;
  `uvm_component_utils(hdcp_monitor)
  virtual hdcp_if vif;
  uvm_analysis_port #(hdcp_transaction) ap;
  int unsigned txn_count = 0;

  // transaction-in-progress fields (filled by the DDC decode process)
  protected bit [39:0] cur_aksv, cur_bksv;
  protected bit [63:0] cur_riv;
  // link watch state
  protected bit        enc_seen, ri_bad, fail_seen;
  protected int unsigned enc_cyc, enc_total;
  protected bit        sda_d, scl_d;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hdcp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hdcp virtual interface not set")
  endfunction

  function void clear_round();
    cur_aksv = '0; cur_bksv = '0; cur_riv = '0;
    enc_seen = 0; ri_bad = 0; fail_seen = 0;
    enc_cyc = 0; enc_total = 0;
  endfunction

  task sample_byte(output bit [7:0] d, output bit ack_bit);
    for (int i = 7; i >= 0; i--) begin
      @(posedge vif.ddc_scl);           // data valid while SCL high
      d[i] = vif.ddc_sda;
      @(negedge vif.ddc_scl);
    end
    @(posedge vif.ddc_scl);             // ACK slot
    ack_bit = vif.ddc_sda;
    @(negedge vif.ddc_scl);
  endtask

  // ---- process 1: DDC transfer decode ----
  task ddc_decode();
    bit [7:0] d, reg_addr;
    bit ack_bit, rw;
    bit [7:0] payload[$];
    bit stop;
    sda_d = 1; scl_d = 1;
    forever begin
      @(vif.mon_cb);
      if (!vif.mon_cb.rst_n) begin sda_d = 1; scl_d = 1; continue; end
      // START: sda falls while scl high
      if (scl_d && sda_d && !vif.mon_cb.ddc_sda && vif.mon_cb.ddc_scl) begin
        sample_byte(d, ack_bit);
        rw = d[0];
        if (d[7:1] != hdcp_defs_pkg::HDCP_DDC_ADDR) begin
          `uvm_warning("MON", $sformatf("DDC transfer to foreign addr 0x%02h", d[7:1]))
        end else if (!rw) begin
          // write: register offset + payload bytes until STOP
          sample_byte(reg_addr, ack_bit);
          payload.delete();
          forever begin
            stop = 0;
            fork
              begin : p_byte
                sample_byte(d, ack_bit);
                payload.push_back(d);
              end
              begin : stop_w
                do @(posedge vif.ddc_sda); while (!vif.ddc_scl);
                stop = 1;
              end
            join_any
            disable fork;
            if (stop) break;
          end
          case (reg_addr)
            hdcp_defs_pkg::REG_AKE_INIT:
              if (payload.size() >= 5)
                cur_aksv = {payload[0], payload[1], payload[2], payload[3], payload[4]};
            hdcp_defs_pkg::REG_LC_INIT:
              if (payload.size() >= 8)
                cur_riv = {payload[0], payload[1], payload[2], payload[3],
                           payload[4], payload[5], payload[6], payload[7]};
            default: ;
          endcase
        end else begin
          // read: 5-byte bksv from the receiver
          payload.delete();
          repeat (5) begin
            sample_byte(d, ack_bit);
            payload.push_back(d);
          end
          cur_bksv = {payload[0], payload[1], payload[2], payload[3], payload[4]};
        end
      end
      sda_d = vif.mon_cb.ddc_sda;
      scl_d = vif.mon_cb.ddc_scl;
    end
  endtask

  // ---- process 2: link integrity watch + transaction publish ----
  task link_watch();
    hdcp_transaction tr;
    hdcp_state_e prev = hdcp_defs_pkg::IDLE;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        prev = hdcp_defs_pkg::IDLE;
        clear_round();
        continue;
      end
      if (vif.mon_cb.state == hdcp_defs_pkg::ENCRYPTED) begin
        enc_seen = 1;
        enc_total++;
        enc_cyc++;
        // check ri_valid only inside the settled window of each 16-cycle
        // frame (receiver ri lags the frame boundary by two cycles)
        if ((enc_cyc % 16) inside {[3:15]} && vif.mon_cb.ri_valid !== 1'b1)
          ri_bad = 1;
      end else begin
        enc_cyc = 0;
      end
      if (vif.mon_cb.auth_fail) fail_seen = 1;

      // authentication round ends when the FSM falls back to IDLE
      if (vif.mon_cb.state == hdcp_defs_pkg::IDLE &&
          prev inside {hdcp_defs_pkg::AKE_SEND_CERT,
                       hdcp_defs_pkg::SKE_SEND_EKS,
                       hdcp_defs_pkg::ENCRYPTED}) begin
        tr = hdcp_transaction::type_id::create("tr");
        tr.aksv       = cur_aksv;
        tr.bksv       = cur_bksv;
        tr.riv        = cur_riv;
        tr.enc_en     = enc_seen;
        tr.num_frames = enc_total / 16;
        tr.auth_fail  = fail_seen;
        tr.ri_bad     = ri_bad;
        tr.err_inject = (cur_bksv == hdcp_defs_pkg::BKSV_REVOKED) ? HDCP_ERR_BKSV_REVOKED :
                        ri_bad ? HDCP_ERR_RI_MISMATCH : HDCP_ERR_NONE;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
        clear_round();
      end
      prev = vif.mon_cb.state;
    end
  endtask

  task run_phase(uvm_phase phase);
    clear_round();
    fork
      ddc_decode();
      link_watch();
    join
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("hdcp monitor observed %0d authentication rounds",
              txn_count), UVM_LOW)
  endfunction
endclass
`endif
