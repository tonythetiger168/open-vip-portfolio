// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdcp_if.sv -- HDCP 2.3 Content Protection interface
// DDC channel (open-drain SDA, master-driven SCL) plus link-integrity
// signals (ri / tx_ri / ri_valid) and the authentication FSM state.

interface hdcp_if (input logic clk);
  import hdcp_defs_pkg::hdcp_state_e;

  logic rst_n;

  // Resolved DDC lines
  logic ddc_scl;
  logic ddc_sda;

  // Transmitter (VIP driver) drives
  logic mst_scl_o;
  logic mst_sda_o, mst_sda_oe;
  logic [6:0]  ddc_addr;      // address of the in-flight DDC transfer
  logic [15:0] tx_ri;         // transmitter-computed Ri for the current frame
  logic        rcv_revoked;   // testbench knob: receiver answers with revoked bksv
  logic        auth_fail;     // transmitter aborts authentication

  // Receiver (DUT) drives
  logic rcv_sda_o, rcv_sda_oe;
  logic [15:0] ri;            // receiver-computed Ri for the current frame

  logic hdcp_enable;          // link encryption active
  logic ri_valid;             // Ri comparison result for the current frame

  hdcp_state_e state;

  // Wired-AND with pull-ups; SCL is master push-pull
  assign ddc_scl  = mst_scl_o;
  assign ddc_sda  = (mst_sda_oe ? mst_sda_o : 1'b1) &
                    (rcv_sda_oe ? rcv_sda_o : 1'b1);
  assign ri_valid = (tx_ri === ri);

  modport TX (input  clk, rst_n, ddc_sda, ri, ri_valid,
              output mst_scl_o, mst_sda_o, mst_sda_oe, ddc_addr, tx_ri,
                     rcv_revoked, auth_fail, hdcp_enable, state);
  modport RX (input  clk, rst_n, ddc_scl, ddc_sda, rcv_revoked, state,
              output rcv_sda_o, rcv_sda_oe, ri);
  modport MON (input clk, rst_n, ddc_scl, ddc_sda, ddc_addr, tx_ri, ri,
                      ri_valid, hdcp_enable, auth_fail, state);

  clocking drv_cb @(posedge clk);
    input  rst_n, ddc_sda, ri, ri_valid;
    output mst_scl_o, mst_sda_o, mst_sda_oe, ddc_addr, tx_ri,
           rcv_revoked, auth_fail, hdcp_enable, state;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, ddc_scl, ddc_sda, ddc_addr, tx_ri, ri, ri_valid,
          hdcp_enable, auth_fail, state;
  endclocking
endinterface
