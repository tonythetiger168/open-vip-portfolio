// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdcp_coverage.svh -- HDCP functional coverage: authentication protocol
// (with crosses), link FSM (sampled from the interface) and error injection.

`ifndef HDCP_COVERAGE_SVH
`define HDCP_COVERAGE_SVH

class hdcp_coverage extends uvm_subscriber #(hdcp_transaction);
  `uvm_component_utils(hdcp_coverage)

  hdcp_transaction tr;
  virtual hdcp_if vif;

  covergroup cg_protocol;
    cp_enc    : coverpoint tr.enc_en { bins auth_only = {0}; bins encrypted = {1}; }
    cp_frames : coverpoint tr.num_frames iff (tr.enc_en) {
      bins min_f  = {[0:2]};
      bins mid_f  = {[3:4]};
      bins max_f  = {[5:6]};
    }
    cp_aksv   : coverpoint tr.aksv[7:0] {
      bins low  = {[8'h00 : 8'h7F]};
      bins high = {[8'h80 : 8'hFF]};
    }
    cp_riv    : coverpoint tr.riv[7:0] {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins mid  = {[8'h01 : 8'hFE]};
    }
    cx_enc_frames : cross cp_enc, cp_frames;
  endgroup

  covergroup cg_fsm with function sample(hdcp_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, AKE_INIT, AKE_SEND_CERT, LC_INIT,
                           SKE_SEND_EKS, ENCRYPTED};
    }
    cp_trans : coverpoint s {
      bins auth_chain = (IDLE => AKE_INIT => AKE_SEND_CERT => LC_INIT
                         => SKE_SEND_EKS => ENCRYPTED);
      bins auth_abort = (AKE_SEND_CERT => IDLE);
      bins auth_only  = (SKE_SEND_EKS => IDLE);
      bins link_down  = (ENCRYPTED => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_err  : coverpoint tr.err_inject {
      bins clean   = {HDCP_ERR_NONE};
      bins revoked = {HDCP_ERR_BKSV_REVOKED};
      bins ri_mis  = {HDCP_ERR_RI_MISMATCH};
    }
    cp_fail : coverpoint tr.auth_fail { bins pass = {0}; bins fail = {1}; }
    cp_ri   : coverpoint tr.ri_bad    { bins ok = {0}; bins bad = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual hdcp_if)::get(this, "", "vif", vif));
  endfunction

  // Link FSM coverage straight from the interface; sampled only on state
  // changes so multi-cycle holds do not break transition chains
  task run_phase(uvm_phase phase);
    hdcp_state_e prev = hdcp_defs_pkg::IDLE;
    if (vif == null) return;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n === 1'b1 && vif.mon_cb.state != prev)
        cg_fsm.sample(vif.mon_cb.state);
      prev = vif.mon_cb.state;
    end
  endtask

  function void write(hdcp_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction
endclass
`endif
