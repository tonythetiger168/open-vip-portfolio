// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hdcp_transaction.svh -- HDCP 2.3 transaction: one authentication round
// (AKE_INIT -> AKE_SEND_CERT -> LC_INIT -> SKE_SEND_EKS) plus the
// ENCRYPTED link-integrity phase with per-frame Ri verification.

`ifndef HDCP_TRANSACTION_SVH
`define HDCP_TRANSACTION_SVH

class hdcp_transaction extends uvm_sequence_item;

  rand bit [39:0]    aksv;          // transmitter KSV
  bit [39:0]         bksv;          // receiver KSV (read back over DDC)
  rand bit [63:0]    riv;           // rN exchanged during LC_INIT
  rand bit           enc_en;        // enter ENCRYPTED after SKE
  rand int unsigned  num_frames;    // frames verified in ENCRYPTED
  rand hdcp_err_e    err_inject;    // error class for this round

  bit                auth_fail;     // monitor: authentication aborted
  bit                ri_bad;        // monitor: ri_valid fell in ENCRYPTED

  constraint c_aksv  { $countones(aksv) == 20; }   // KSV validity rule
  constraint c_frames{ num_frames inside {[2:6]}; }
  constraint c_enc   { enc_en dist {1 := 9, 0 := 1}; }
  constraint c_err   { err_inject dist {HDCP_ERR_NONE := 7,
                                        HDCP_ERR_BKSV_REVOKED := 2,
                                        HDCP_ERR_RI_MISMATCH := 1};
                       err_inject == HDCP_ERR_RI_MISMATCH -> enc_en == 1; }

  `uvm_object_utils_begin(hdcp_transaction)
    `uvm_field_int(aksv, UVM_ALL_ON)
    `uvm_field_int(bksv, UVM_ALL_ON)
    `uvm_field_int(riv, UVM_ALL_ON)
    `uvm_field_int(enc_en, UVM_ALL_ON)
    `uvm_field_int(num_frames, UVM_ALL_ON)
    `uvm_field_enum(hdcp_err_e, err_inject, UVM_ALL_ON)
    `uvm_field_int(auth_fail, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(ri_bad, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "hdcp_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    hdcp_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    // Authentication rounds aborted by error injection carry no payload
    // guarantee: compare the error class instead of the exchanged values.
    if (err_inject != HDCP_ERR_NONE || t.err_inject != HDCP_ERR_NONE)
      do_compare &= (comparer.compare_field("err_inject", err_inject, t.err_inject, 2) == 1);
  endfunction

  function string convert2string();
    return $sformatf("HDCP aksv=%010h bksv=%010h riv=%016h enc=%0b frames=%0d err=%s",
                     aksv, bksv, riv, enc_en, num_frames, err_inject.name());
  endfunction
endclass
`endif
