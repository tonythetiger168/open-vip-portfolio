// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdcp_defs.sv -- HDCP 2.3 Content Protection shared type definitions
// DDC message map, KSV constants and the abstract Ri function shared by
// the VIP (transmitter), the receiver DUT model and the SVA checker.

package hdcp_defs_pkg;
  typedef enum bit [2:0] {
    IDLE,
    AKE_INIT,
    AKE_SEND_CERT,
    LC_INIT,
    SKE_SEND_EKS,
    ENCRYPTED
  } hdcp_state_e;

  // Error-injection classes
  typedef enum bit [1:0] {
    HDCP_ERR_NONE,          // clean authentication + link integrity
    HDCP_ERR_BKSV_REVOKED,  // receiver presents a revoked bksv
    HDCP_ERR_RI_MISMATCH    // transmitter Ri does not match receiver Ri
  } hdcp_err_e;

  // DDC (I2C-like) addresses and register offsets
  localparam bit [6:0] HDCP_DDC_ADDR   = 7'h74;   // HDCP receiver on DDC
  localparam bit [7:0] REG_AKE_INIT    = 8'h01;   // + 5B aksv
  localparam bit [7:0] REG_LC_INIT     = 8'h03;   // + 8B rN (riv)
  localparam bit [7:0] REG_SKE_SEND_EKS= 8'h04;   // + 4B encrypted session key

  // Receiver KSVs (abstract: validity encoded by membership in the SRM)
  localparam bit [39:0] BKSV_VALID   = 40'hA5_C3_F0_12_34;
  localparam bit [39:0] BKSV_REVOKED = 40'hDE_AD_BE_EF_01;

  // Abstract Ri integrity value: both sides derive the same 16-bit value
  // per frame from aksv/bksv and the frame index.
  function automatic bit [15:0] ri_compute(bit [39:0] aksv, bit [39:0] bksv,
                                           int unsigned frame);
    return aksv[15:0] ^ bksv[15:0] ^ {frame[7:0], ~frame[7:0]} ^ 16'h9E37;
  endfunction
endpackage
