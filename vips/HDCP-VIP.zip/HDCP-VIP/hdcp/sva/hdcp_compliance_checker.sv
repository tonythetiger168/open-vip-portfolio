// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdcp_compliance_checker.sv -- HDCP 2.3 SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = HDCP authentication/link-integrity rules

`ifndef HDCP_COMPLIANCE_CHECKER_SV
`define HDCP_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import hdcp_defs_pkg::*;

module hdcp_compliance_checker
(
  input logic clk,
  input logic rst_n,
  input hdcp_state_e state,
  input logic [6:0] ddc_addr,
  input logic [15:0] ri,
  input logic ri_valid,
  input logic auth_fail,
  input logic hdcp_enable
);

  // ---------------- L1: signal sanity (4) ----------------
  a_hdcp_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "hdcp: clock unknown")
  a_hdcp_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "hdcp: reset unknown")
  a_hdcp_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "hdcp: state unknown")
  a_hdcp_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, AKE_INIT, AKE_SEND_CERT, LC_INIT, SKE_SEND_EKS, ENCRYPTED})
    else `uvm_error("SVA_L1", "hdcp: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from IDLE
  a_hdcp_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, AKE_INIT})
    else `uvm_error("SVA_L2", "hdcp: illegal transition from IDLE")

  // L2-2: legal FSM transition from AKE_INIT
  a_hdcp_trans_ake_init : assert property (@(posedge clk) disable iff (!rst_n)
    state == AKE_INIT |=> state inside {AKE_INIT, AKE_SEND_CERT})
    else `uvm_error("SVA_L2", "hdcp: illegal transition from AKE_INIT")

  // L2-3: legal FSM transition from AKE_SEND_CERT (LC_INIT or abort to IDLE)
  a_hdcp_trans_ake_send_cert : assert property (@(posedge clk) disable iff (!rst_n)
    state == AKE_SEND_CERT |=> state inside {AKE_SEND_CERT, LC_INIT, IDLE})
    else `uvm_error("SVA_L2", "hdcp: illegal transition from AKE_SEND_CERT")

  // L2-4: legal FSM transition from LC_INIT
  a_hdcp_trans_lc_init : assert property (@(posedge clk) disable iff (!rst_n)
    state == LC_INIT |=> state inside {LC_INIT, SKE_SEND_EKS})
    else `uvm_error("SVA_L2", "hdcp: illegal transition from LC_INIT")

  // L2-5: legal FSM transition from SKE_SEND_EKS (ENCRYPTED or auth-only end)
  a_hdcp_trans_ske_send_eks : assert property (@(posedge clk) disable iff (!rst_n)
    state == SKE_SEND_EKS |=> state inside {SKE_SEND_EKS, ENCRYPTED, IDLE})
    else `uvm_error("SVA_L2", "hdcp: illegal transition from SKE_SEND_EKS")

  // L2-6: legal FSM transition from ENCRYPTED
  a_hdcp_trans_encrypted : assert property (@(posedge clk) disable iff (!rst_n)
    state == ENCRYPTED |=> state inside {ENCRYPTED, IDLE})
    else `uvm_error("SVA_L2", "hdcp: illegal transition from ENCRYPTED")

  // ---------------- L3: protocol rules (4) ----------------
  a_hdcp_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "hdcp: state not IDLE during reset")
  a_hdcp_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == ENCRYPTED |-> ##[1:128] (state != ENCRYPTED))
    else `uvm_error("SVA_L3", "hdcp: stuck in ENCRYPTED")
  a_hdcp_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == AKE_INIT);
  a_hdcp_l3_back_idle  : cover property (@(posedge clk) disable iff (!rst_n)
    state == ENCRYPTED ##1 state == IDLE);

  // ---------------- L4: HDCP-specific rules (5) ----------------
  // L4-1: ENCRYPTED is only entered right after SKE_SEND_EKS completed
  a_hdcp_l4_enc_after_ske : assert property (@(posedge clk) disable iff (!rst_n)
    state == ENCRYPTED |-> $past(state == SKE_SEND_EKS) || $past(state == ENCRYPTED))
    else `uvm_error("SVA_L4", "hdcp: ENCRYPTED entered without completing SKE")

  // L4-2: Ri is refreshed regularly while the link is encrypted
  a_hdcp_l4_ri_refresh : assert property (@(posedge clk) disable iff (!rst_n)
    state == ENCRYPTED |-> ##[1:64] ($changed(ri) || state != ENCRYPTED))
    else `uvm_error("SVA_L4", "hdcp: Ri not refreshed within 64 cycles")

  // L4-3: an authentication failure returns the FSM to IDLE
  a_hdcp_l4_fail_idle : assert property (@(posedge clk) disable iff (!rst_n)
    $rose(auth_fail) |=> state == IDLE)
    else `uvm_error("SVA_L4", "hdcp: authentication failure did not return to IDLE")

  // L4-4: DDC traffic always targets the fixed HDCP receiver address 0x74
  a_hdcp_l4_ddc_addr : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {AKE_INIT, AKE_SEND_CERT, LC_INIT, SKE_SEND_EKS}
      |-> ddc_addr == 7'h74)
    else `uvm_error("SVA_L4", "hdcp: DDC address is not the HDCP receiver address")

  // L4-5: encryption enable only in the ENCRYPTED phase
  a_hdcp_l4_enable_phase : assert property (@(posedge clk) disable iff (!rst_n)
    hdcp_enable |-> state == ENCRYPTED)
    else `uvm_error("SVA_L4", "hdcp: hdcp_enable outside ENCRYPTED")

endmodule
`endif
