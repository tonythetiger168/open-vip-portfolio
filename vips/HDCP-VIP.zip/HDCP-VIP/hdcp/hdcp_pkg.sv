// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// hdcp_pkg.sv -- HDCP 2.3 Content Protection UVM VIP package

package hdcp_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import hdcp_defs_pkg::*;
  export hdcp_defs_pkg::*;

  `include "hdcp_transaction.svh"
  `include "hdcp_config.svh"
  `include "hdcp_sequencer.svh"
  `include "hdcp_driver.svh"
  `include "hdcp_monitor.svh"
  `include "hdcp_agent.svh"
  `include "hdcp_sequences.svh"
  `include "hdcp_checker.svh"
  `include "hdcp_coverage.svh"
endpackage
