# USB 2.0 Protocol VIP — Unified Multi-Protocol Verification IP

## 前言概述 (Protocol Overview)

USB 2.0 高速 (High Speed, 480 Mbps) 驗證重點：
token (OUT/IN/SOF/SETUP/PING/SPLIT) / data (DATA0/1/2/MDATA) / handshake
(ACK/NAK/STALL/NYET) 三類 packet 序列、CRC5/CRC16 校驗、
NRZI 編碼 + bit-stuffing 概念、HS chirp 支援、
UTMI/ULPI PHY 介面、裝置狀態機
(POWERED→DEFAULT→ADDRESS→CONFIGURED)推進。

本 VIP 為 USB 系列統一架構：單一環境涵蓋 7 種協議
(USB 2.0 / 3.0 / 3.1 / 3.2 / USB4 / eUSB2 / USB-PD)，本專案聚焦於 **USB 2.0 Protocol VIP**。

## 架構 (Architecture)

```
top_tb.sv
 ├─ usb_vip_if × 7 (MAC + PHY 雙層, clocking blocks, modports, IF assertions)
 └─ usb_dut (functional DUT model)
     ├─ usb2_dev_ep ×2     USB2/eUSB2 device endpoint: chirp response,
     │                      CRC16 檢查, ACK/STALL/timeout, babble detect
     ├─ usb3_phy_model ×3  PIPE PHY: LTSSM walk→U0, CRC32 check, loopback ACK
     ├─ usb4_phy_model     PIPE4 PHY: link ready, router sideband, loopback
     └─ pd_controller_model PD controller: header decode, Vbus transition
usb_env
 ├─ usb_agent × 7 (usb_sequencer / usb_driver / usb_monitor)
 ├─ usb_scoreboard  expected(drv_ap→exp_imp) vs observed(mon→analysis_imp)
 │                   pairwise compare, n_matches/n_mismatches, UVM_ERROR on mismatch
 ├─ usb_coverage_model × 4 (8 covergroups, 見下)
 └─ *_protocol_checker × 5 (procedural protocol checks + covergroups)
```

Closed loop：driver 依 transaction descriptor 送出 token/data packet
（含 CRC16/CRC32 trailer，data packet 以 `mac_frame_num` 作 sideband byte count），
DUT 依位址/endpoint/CRC 決定 ACK/STALL/timeout/babble，monitor 從 MAC/PHY
波形解碼 PID→packet type、重組 payload（剝除 CRC trailer）、觀察 handshake，
scoreboard 端到端比對。

## Sequence 清單

| Sequence | 類型 | 說明 |
|----------|------|------|
| `usb_base_sequence` | base | 共用參數/constraint |
| `usb_random_sequence` | random | protocol-weighted 隨機流量 (90% 打到 DUT 位址) |
| `usb_normal_seq` | directed | 正常 SETUP/IN/OUT/DATA, ACK 路徑 |
| `usb_error_inject_seq` | directed | CRC 腐敗 / timeout(未實作位址) / STALL(EP15) / babble(超長) |
| `usb_reset_seq` | directed | bus reset (SE0) 後重新列舉 |
| `usb_back_to_back_seq` | directed | 最小 inter-packet gap (=2) 背靠背 |
| `usb_stress_seq` | directed | 大 payload (256–512B) 高速率壓力 |
| `usb_corner_seq` | directed | ZLP / 1-byte / max-packet / DATA0-DATA1 toggle / 邊界 EP |
| `usb_sof_seq` | directed | SOF frame stream (11-bit frame number) |
| `usb_regression_sequence` | regression | 加權混合 regression |
| `usb_directed_regression_sequence` | regression | directed library 全掃 |

Tests：`usb_random_regression_test` (預設), `usb_directed_test`,
`usb_hs_test`, `usb_ss_test`, `usb_ssp_test`, `usb_ss20_test`,
`usb4_test`, `usb_eusb2_test`, `usb_pd_test`。

## SVA 清單 (rtl/sva/usb2_compliance_checker.sv, module on usb2_link_if)

每個違規都是 `UVM_ERROR`：
- **L1 signal sanity (4)**：合法 link / device state 編碼、state 與 answer valid 無 X、送出的 answer 無 X
- **L2 packets (6)**：answer PID check nibble、只送 ACK / NAK / STALL / NYET / DATA0 / DATA1、handshake 不帶資料、資料長度不超過該速度的 MPS、NYET 只在 HS、資料只回應 IN token
- **L3 link (7)**：每個 answer 都在一個合法封包之後一個 clock、且在 FS / HS；hs 只在 HS state；chirp K 只在 chirp 期間；合法 link 轉移；HS 只從 chirp 或 resume 進入；bus reset 回到 DEFAULT / address 0；reset 計數對應真的 reset
- **L4 chapter 9 (4)**：DEFAULT ↔ address 0、cfg_val ↔ CONFIGURED、EP0 永不 halt、halt 只在 CONFIGURED
- **L5 counters (4)**：counter 每 clock 最多加一、NAK / STALL / NYET counter 與 answer 一一對應、完成的 split 一定回 ACK 或 DATA0、microframe 只在 HS
- 12 個 cover：HS chirp 成功、chirp 失敗回 FS、HS suspend、resume 回 HS、NYET、STALL、512-byte DATA1、split 完成、第 8 個 microframe、SOF miss、babble、HS CONFIGURED

## Functional Coverage 清單

`usb_coverage_model` (8 covergroups，含 cross)：
`cg_txn_type` (protocol×type cross)、`cg_endpoint` (ep×type cross)、
`cg_packet_size` (size×protocol cross)、`cg_device_state` (FSM transition bins,
state×protocol cross)、`cg_phy_layer` (phy_if×term cross)、
`cg_pd_contract` (contract×voltage cross)、`cg_error_injection` (err×recovery cross)、
`cg_data_pattern` (first-byte pattern×length cross)。
Interface covergroup：`cg_usb_interface` (MAC handshake × device state cross)。
各 protocol checker 另有專屬 covergroup + cross。

## 快速上手 (Quick Start)

```sh
cd scripts
make compile           # VCS: pkg → checkers → if → sequences → env → tests → tb
make simulate TEST=usb_random_regression_test
make simulate TEST=usb_directed_test
make coverage          # 見 scripts/coverage.mk
```

環境變數 `TEST` 選擇測試；`UVM_VERBOSITY` 控制訊息等級。
regression 結束時 scoreboard 回報 `n_matches/n_mismatches`，
compliance checker 回報 L1/L2/L3/L4 tiered coverage。

## Deepened Features (v1.8.0)

- **Device model** (`tb/usb2_smoke_model.sv`): USB 2.0 device at the packet layer with the bus line state: reset detection, device chirp K and the host K-J handshake (HS) or FS fallback, suspend after idle J, resume on K, HS -> FS reversion on idle (SE0 = reset, J = suspend); real PID encoding with check nibble, CRC5 / CRC16 results, babble; chapter 9 DEFAULT / ADDRESS / CONFIGURED with SET_ADDRESS (applied after the status stage), SET_CONFIGURATION, GET_STATUS (device / endpoint), SET / CLEAR_FEATURE(ENDPOINT_HALT) and protocol stall; EP1 bulk OUT with 2 buffers, PING and NYET; EP2 bulk IN FIFO and EP3 interrupt IN with DATA0 / DATA1 toggles, retries and host-ACK timeout; split transactions through a Transaction Translator (SSPLIT / CSPLIT, NYET while busy); SOF frame and microframe tracking with missed-SOF detection; 13 counters
- **Functional test** (`tb/smoke_func_tb.sv`): 230 self-checks
- **UVM agent** (`vip/usb2/usb2_link_pkg.sv` on `usb2_link_if`): host driver / monitor, a scoreboard that predicts the device clock by clock (link state, chapter 9 state, every answer packet, frame / microframe, all counters), link / answer / request / event covergroups, a 1500-iteration random regression (`usb2_link_test`, runs on Verilator)
- **SVA**: `rtl/sva/usb2_compliance_checker.sv` rewritten on the link interface (25 assertions, 12 covers)
