# USB 2.0 Protocol VIP \u2014 Unified Multi-Protocol Verification IP

## \u524d\u8a00\u6982\u8ff0 (Protocol Overview)

USB 2.0 \u9ad8\u901f (High Speed, 480 Mbps) \u9a57\u8b49\u91cd\u9ede\uff1a
token (OUT/IN/SOF/SETUP/PING/SPLIT) / data (DATA0/1/2/MDATA) / handshake
(ACK/NAK/STALL/NYET) \u4e09\u985e packet \u5e8f\u5217\u3001CRC5/CRC16 \u6821\u9a57\u3001
NRZI \u7de8\u78bc + bit-stuffing \u6982\u5ff5\u3001HS chirp \u652f\u63f4\u3001
UTMI/ULPI PHY \u4ecb\u9762\u3001\u88dd\u7f6e\u72c0\u614b\u6a5f
(POWERED\u2192DEFAULT\u2192ADDRESS\u2192CONFIGURED)\u63a8\u9032\u3002

\u672c VIP \u70ba USB \u7cfb\u5217\u7d71\u4e00\u67b6\u69cb\uff1a\u55ae\u4e00\u74b0\u5883\u6db5\u84cb 7 \u7a2e\u5354\u8b70
(USB 2.0 / 3.0 / 3.1 / 3.2 / USB4 / eUSB2 / USB-PD)\uff0c\u672c\u5c08\u6848\u805a\u7126\u65bc **USB 2.0 Protocol VIP**\u3002

## 架構 (Architecture)

```
top_tb.sv
 \u251c\u2500 usb_vip_if \u00d7 7 (MAC + PHY \u96d9\u5c64, clocking blocks, modports, IF assertions)
 \u2514\u2500 usb_dut (functional DUT model)
     \u251c\u2500 usb2_dev_ep \u00d72     USB2/eUSB2 device endpoint: chirp response,
     \u2502                      CRC16 \u6aa2\u67e5, ACK/STALL/timeout, babble detect
     \u251c\u2500 usb3_phy_model \u00d73  PIPE PHY: LTSSM walk\u2192U0, CRC32 check, loopback ACK
     \u251c\u2500 usb4_phy_model     PIPE4 PHY: link ready, router sideband, loopback
     \u2514\u2500 pd_controller_model PD controller: header decode, Vbus transition
usb_env
 \u251c\u2500 usb_agent \u00d7 7 (usb_sequencer / usb_driver / usb_monitor)
 \u251c\u2500 usb_scoreboard  expected(drv_ap\u2192exp_imp) vs observed(mon\u2192analysis_imp)
 \u2502                   pairwise compare, n_matches/n_mismatches, UVM_ERROR on mismatch
 \u251c\u2500 usb_coverage_model \u00d7 4 (8 covergroups, \u898b\u4e0b)
 \u2514\u2500 *_protocol_checker \u00d7 5 (procedural protocol checks + covergroups)
```

Closed loop\uff1adriver \u4f9d transaction descriptor \u9001\u51fa token/data packet
\uff08\u542b CRC16/CRC32 trailer\uff0cdata packet \u4ee5 `mac_frame_num` \u4f5c sideband byte count\uff09\uff0c
DUT \u4f9d\u4f4d\u5740/endpoint/CRC \u6c7a\u5b9a ACK/STALL/timeout/babble\uff0cmonitor \u5f9e MAC/PHY
\u6ce2\u5f62\u89e3\u78bc PID\u2192packet type\u3001\u91cd\u7d44 payload\uff08\u525d\u9664 CRC trailer\uff09\u3001\u89c0\u5bdf handshake\uff0c
scoreboard \u7aef\u5230\u7aef\u6bd4\u5c0d\u3002

## Sequence \u6e05\u55ae

| Sequence | \u985e\u578b | \u8aaa\u660e |
|----------|------|------|
| `usb_base_sequence` | base | \u5171\u7528\u53c3\u6578/constraint |
| `usb_random_sequence` | random | protocol-weighted \u96a8\u6a5f\u6d41\u91cf (90% \u6253\u5230 DUT \u4f4d\u5740) |
| `usb_normal_seq` | directed | \u6b63\u5e38 SETUP/IN/OUT/DATA, ACK \u8def\u5f91 |
| `usb_error_inject_seq` | directed | CRC \u8150\u6557 / timeout(\u672a\u5be6\u4f5c\u4f4d\u5740) / STALL(EP15) / babble(\u8d85\u9577) |
| `usb_reset_seq` | directed | bus reset (SE0) \u5f8c\u91cd\u65b0\u5217\u8209 |
| `usb_back_to_back_seq` | directed | \u6700\u5c0f inter-packet gap (=2) \u80cc\u9760\u80cc |
| `usb_stress_seq` | directed | \u5927 payload (256\u2013512B) \u9ad8\u901f\u7387\u58d3\u529b |
| `usb_corner_seq` | directed | ZLP / 1-byte / max-packet / DATA0-DATA1 toggle / \u908a\u754c EP |
| `usb_sof_seq` | directed | SOF frame stream (11-bit frame number) |
| `usb_regression_sequence` | regression | \u52a0\u6b0a\u6df7\u5408 regression |
| `usb_directed_regression_sequence` | regression | directed library \u5168\u6383 |

Tests\uff1a`usb_random_regression_test` (\u9810\u8a2d), `usb_directed_test`,
`usb_hs_test`, `usb_ss_test`, `usb_ssp_test`, `usb_ss20_test`,
`usb4_test`, `usb_eusb2_test`, `usb_pd_test`\u3002

## SVA \u6e05\u55ae (rtl/sva/usb2_compliance_checker.sv, module)

- **L1 Basic (4)**\uff1autmi_linestate \u5408\u6cd5\u3001rxvalid\u2192rxactive\u3001op_mode \u5408\u6cd5\u3001xcvr_select \u5408\u6cd5
- **L2 Full Protocol (6)**\uff1atxvalid stable/handshake\u3001SE0 reset\u3001suspend\u2192J\u3001
  term_select\u3001HS chirp\u3001resume signaling
- **L3 Advanced (0)**\uff1a\u4fdd\u7559\u5c64\u7d1a (placeholder)
- **L4 USB 2.0 \u5c08\u5c6c (5)**\uff1atoken turnaround bound\u3001inter-packet gap\u3001
  DATA payload anti-babble\u3001bus reset\u2192SE0\u3001HS chirp K/J \u56de\u61c9

vip/usb2/usb2_protocol_checker (class, procedural checks)\uff1a
PID complement\u3001token CRC5\u3001data CRC16\u3001response timeout\u3001bit-stuff\u3001
handshake \u5408\u6cd5\u6027\u3001UTMI linestate (SE1 illegal)\u3002

## Functional Coverage \u6e05\u55ae

`usb_coverage_model` (8 covergroups\uff0c\u542b cross)\uff1a
`cg_txn_type` (protocol\u00d7type cross)\u3001`cg_endpoint` (ep\u00d7type cross)\u3001
`cg_packet_size` (size\u00d7protocol cross)\u3001`cg_device_state` (FSM transition bins,
state\u00d7protocol cross)\u3001`cg_phy_layer` (phy_if\u00d7term cross)\u3001
`cg_pd_contract` (contract\u00d7voltage cross)\u3001`cg_error_injection` (err\u00d7recovery cross)\u3001
`cg_data_pattern` (first-byte pattern\u00d7length cross)\u3002
Interface covergroup\uff1a`cg_usb_interface` (MAC handshake \u00d7 device state cross)\u3002
\u5404 protocol checker \u53e6\u6709\u5c08\u5c6c covergroup + cross\u3002

## \u5feb\u901f\u4e0a\u624b (Quick Start)

```sh
cd scripts
make compile           # VCS: pkg \u2192 checkers \u2192 if \u2192 sequences \u2192 env \u2192 tests \u2192 tb
make simulate TEST=usb_random_regression_test
make simulate TEST=usb_directed_test
make coverage          # \u898b scripts/coverage.mk
```

\u74b0\u5883\u8b8a\u6578 `TEST` \u9078\u64c7\u6e2c\u8a66\uff1b`UVM_VERBOSITY` \u63a7\u5236\u8a0a\u606f\u7b49\u7d1a\u3002
regression \u7d50\u675f\u6642 scoreboard \u56de\u5831 `n_matches/n_mismatches`\uff0c
compliance checker \u56de\u5831 L1/L2/L3/L4 tiered coverage\u3002
