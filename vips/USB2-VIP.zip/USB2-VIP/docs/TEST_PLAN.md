# USB2 Test Plan（USB2-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | USB 2.0 (FS / HS device, chapter 7 / 8 / 9 / 11 split) |
| 家族 | USB |
| 類型 | UVM VIP |
| 交付目錄 | `USB2-VIP/` |
| 目前 L1b 狀態 | PASS |

## 2. DUT / 待測對象

- `usb2_smoke_model`（USB 2.0 device：reset / HS chirp / suspend-resume、chapter 9 control、bulk OUT with PING / NYET、bulk / interrupt IN、split transaction TT、SOF / microframe）
- `usb3_phy_model`、`usb4_phy_model`、`pd_controller_model`（umbrella top 的 PIPE loopback model，沿用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | after rst_n: FS, DEFAULT, address 0, counters 0 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | bus reset after 16 clocks of SE0, no second reset while SE0 is held, re-armed by J | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | FS SOF frame numbers, repeated / skipped frame -> sof_miss | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | FS enumeration and bulk: no NYET, PING ignored, 64-byte MPS (babble, IN clamp) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | FS suspend after 24 idle J clocks, packets ignored, short K ignored, resume on K >= 4 clocks | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | HS chirp: device K for 8 clocks, 3 host K-J pairs -> HS; no host chirp / 1-clock levels / 1.5 pairs -> FS | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | HS idle with SE0 -> reset and new chirp; packets during the chirp ignored | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | SET_ADDRESS applied only after the status stage ACK; status ZLP retry after a missing ACK | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | SET_CONFIGURATION (valid / invalid), SET_ADDRESS in CONFIGURED, GET_STATUS device / endpoint, status OUT duplicate | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | protocol stall for unsupported requests, cleared by the next SETUP; malformed SETUP data ignored | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | HS bulk OUT: ACK, NYET on the last buffer, NAK when full, PING ACK / NAK, duplicate ACK, 512-byte MPS | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | CRC16 / CRC5 / PID check / DATA2 errors: no handshake, toggle kept, counters | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | OUT data timeout, token abort, stray handshake during the data wait | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | bulk IN: clamp to MPS, DATA0 / DATA1, retry after timeout / host NAK / new token, FIFO full, NAK when empty | 檢查成立，`FUNC_PASS` 輸出 |
| FS-15 | interrupt IN reports with toggles; non-existent endpoints, wrong direction and other addresses not answered | 檢查成立，`FUNC_PASS` 輸出 |
| FS-16 | ENDPOINT_HALT set / clear, STALL on halted IN / OUT / PING, toggle reset, SET_CONFIGURATION clears halts | 檢查成立，`FUNC_PASS` 輸出 |
| FS-17 | HS microframes 0..7 within a frame, ninth microframe and frame jumps -> sof_miss, 2047 -> 0 wrap | 檢查成立，`FUNC_PASS` 輸出 |
| FS-18 | split: SSPLIT OUT / SETUP / IN, CSPLIT NYET while the TT works, ACK / DATA0 when done, STALL on mismatch, NAK when busy, errors, SPLIT timeout, SPLIT at FS ignored | 檢查成立，`FUNC_PASS` 輸出 |
| FS-19 | HS suspend / resume back to HS, reset from suspend | 檢查成立，`FUNC_PASS` 輸出 |
| FS-20 | rst_n clears everything | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Isochronous endpoints (DATA2 / MDATA high-bandwidth sequencing) |
| PT-02 | Remote wakeup and LPM (L1) |
| PT-03 | Bit-level NRZI / bit stuffing / EOP on a UTMI model |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/usb2_compliance_checker.sv`（L1 signal sanity 4、L2 packets 6、L3 link 7、L4 chapter 9 4、L5 counters 4，加 12 個 cover）
- Functional coverage：`vip/usb2/usb2_link_pkg.sv` 的 `usb2_coverage`（cg_link 轉移、cg_ans 每種交易的回應含 split、cg_req control request、cg_ev 錯誤 / 事件）
- Scoreboard：`usb2_scoreboard` 逐 clock 預測 device（link state、chirp、suspend / resume、chapter 9 state、每個 answer 的 PID / 長度 / 資料、toggle、TT、frame / microframe、13 個 counter）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/USB2-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py USB2-VIP && python3 smoke/smoke_run.py USB2-VIP   # L1b
python3 tools/run_uvm_tests.py USB2-VIP       # UVM（Verilator），期望 SB_PASS
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 行為級 model 以每 clock 一個封包建模，計時器縮短為 clock 數；不含 NRZI / bit stuffing / CRC 計算本身（CRC 結果以 `rx_crc_ok` 輸入）。

---
*文件版本：v1.8.0*
