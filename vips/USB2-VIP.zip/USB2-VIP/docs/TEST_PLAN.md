# USB2 Test Plan（USB2-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | USB2 |
| 家族 | USB |
| 類型 | UVM VIP |
| 交付目錄 | `USB2-VIP/` |
| 目前 L1b 狀態 | PASS(functional) |

## 2. DUT / 待測對象

- `pd_controller_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）
- `usb2_smoke_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）
- `usb3_phy_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）
- `usb4_phy_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | reset: DEFAULT state, addr 0, DATA0 expected | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | SOF produces no handshake | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | SETUP resets data toggle to DATA0 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | SETUP data stage ACKed | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | SET_ADDRESS accepted: addr=5, state=ADDRESS | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | OUT DATA0 ACKed | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | toggle flipped to DATA1 after accept | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | duplicate DATA0 ACKed without toggle flip | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | DATA1 accepted, toggle back to DATA0 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | bad CRC: NAK, toggle held, nak_count=1 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | endpoint 0xF STALLs | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | IN token: tx_valid=1, first payload byte | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | host ACK consumed data: tx_valid cleared, toggle flipped | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | foreign address ignored (state untouched) | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Agent reset and first-transaction bring-up |
| PT-02 | Constrained-random sequence sweep (base sequence extended) |
| PT-03 | Error injection and protocol-violation response |
| PT-04 | Backpressure / wait-state interaction |
| PT-05 | End-to-end scoreboard matching (exp vs obs streams) |
| PT-06 | Coverage closure toward the self-served COV_GOAL=100 checklist |

## 5. 覆蓋與檢查

- （本 VIP 無獨立 SVA/coverage 檔案，覆蓋由 directed tb 之通過/失敗判定承擔。）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/USB2-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py USB2-VIP && python3 smoke/smoke_run.py USB2-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 無特別備註。

---
*文件版本：v1.7.5 自動產生*
