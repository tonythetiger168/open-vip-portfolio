// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened usb2_smoke_model (USB 2.0
// device: reset / HS chirp / suspend-resume, chapter 9 control requests,
// bulk OUT with PING/NYET, bulk and interrupt IN with data toggles and
// retries, SOF / microframes, split transactions through the TT, and the
// error paths). See the model header for the behaviour checked here.
// Packets are driven on a negedge for one clock; the answer is sampled on
// the following negedge.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;
  int i, n, m;

  logic        clk = 1'b0;
  logic        rst_n = 1'b0;
  logic        hs_cap = 1'b0;
  logic [1:0]  line = 2'd1;
  logic        rx_valid = 1'b0;
  logic [7:0]  rx_pid = 8'h00;
  logic        rx_crc_ok = 1'b1;
  logic [6:0]  rx_addr = 7'h00;
  logic [3:0]  rx_endp = 4'h0;
  logic [9:0]  rx_len = 10'd0;
  logic [31:0] rx_data = 32'h0;
  logic        app_rd = 1'b0;
  logic        app_wr = 1'b0;
  logic [9:0]  app_len = 10'd0;
  logic        app_irq = 1'b0;
  wire [2:0]   ls;
  wire         hs;
  wire         chirp_k;
  wire [1:0]   dev_state;
  wire [6:0]   dev_addr;
  wire         cfg_val;
  wire [10:0]  frame_num;
  wire [2:0]   uframe;
  wire [3:0]   ep_halt;
  wire         tx_valid;
  wire [7:0]   tx_pid;
  wire [9:0]   tx_len;
  wire [15:0]  tx_data;
  wire [7:0]   pid_err, crc5_err, crc16_err, babble_cnt, dup_cnt, nak_cnt, stall_cnt, nyet_cnt;
  wire [7:0]   sof_cnt, sof_miss, resets, tmo_cnt, split_cnt;
  logic [7:0]  s0, s1, s2;
  logic [10:0] fr;

  always #5 clk = ~clk;

  usb2_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .hs_cap(hs_cap), .line(line), .rx_valid(rx_valid), .rx_pid(rx_pid),
    .rx_crc_ok(rx_crc_ok), .rx_addr(rx_addr), .rx_endp(rx_endp), .rx_len(rx_len), .rx_data(rx_data),
    .app_rd(app_rd), .app_wr(app_wr), .app_len(app_len), .app_irq(app_irq),
    .ls(ls), .hs(hs), .chirp_k(chirp_k), .dev_state(dev_state), .dev_addr(dev_addr), .cfg_val(cfg_val),
    .frame_num(frame_num), .uframe(uframe), .ep_halt(ep_halt),
    .tx_valid(tx_valid), .tx_pid(tx_pid), .tx_len(tx_len), .tx_data(tx_data),
    .pid_err(pid_err), .crc5_err(crc5_err), .crc16_err(crc16_err), .babble_cnt(babble_cnt),
    .dup_cnt(dup_cnt), .nak_cnt(nak_cnt), .stall_cnt(stall_cnt), .nyet_cnt(nyet_cnt),
    .sof_cnt(sof_cnt), .sof_miss(sof_miss), .resets(resets), .tmo_cnt(tmo_cnt), .split_cnt(split_cnt)
  );

  localparam logic [3:0] P_OUT = 4'h1, P_IN = 4'h9, P_SOF = 4'h5, P_SETUP = 4'hD,
                         P_DATA0 = 4'h3, P_DATA1 = 4'hB, P_DATA2 = 4'h7,
                         P_ACK = 4'h2, P_NAK = 4'hA, P_STALL = 4'hE, P_NYET = 4'h6,
                         P_SPLIT = 4'h8, P_PING = 4'h4;
  localparam logic [1:0] SE0 = 2'd0, J = 2'd1, K = 2'd2;
  localparam logic [2:0] L_FS = 3'd0, L_CHIRP = 3'd1, L_CHWAIT = 3'd2, L_HS = 3'd3, L_SUSP = 3'd4;

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s (t=%0t tx=%0b pid=%h len=%0d d=%h ls=%0d)", msg, $time,
                                     tx_valid, tx_pid, tx_len, tx_data, ls); end
  endtask

  task automatic idle(input int c);
    repeat (c) @(negedge clk);
  endtask

  task automatic pkt(input logic [3:0] p, input logic [6:0] a, input logic [3:0] e,
                     input logic [9:0] len, input logic [31:0] d, input bit ok);
    rx_valid = 1'b1; rx_pid = {~p, p}; rx_addr = a; rx_endp = e; rx_len = len; rx_data = d; rx_crc_ok = ok;
    @(negedge clk);
    rx_valid = 1'b0; rx_crc_ok = 1'b1; rx_len = 10'd0; rx_data = 32'h0;
  endtask

  task automatic tok(input logic [3:0] p, input logic [6:0] a, input logic [3:0] e);
    pkt(p, a, e, 10'd0, 32'h0, 1'b1);
  endtask

  task automatic dat(input logic [3:0] p, input logic [9:0] len, input logic [31:0] d);
    pkt(p, 7'h00, 4'h0, len, d, 1'b1);
  endtask

  task automatic exp(input logic [3:0] p, input string msg);
    chk(tx_valid === 1'b1 && tx_pid === {~p, p}, msg);
  endtask

  task automatic exp_none(input string msg);
    chk(tx_valid === 1'b0, msg);
  endtask

  task automatic sof(input logic [10:0] f);
    pkt(P_SOF, f[6:0], f[10:7], 10'd0, 32'h0, 1'b1);
  endtask

  task automatic pulse_rd();
    app_rd = 1'b1; @(negedge clk); app_rd = 1'b0;
  endtask
  task automatic pulse_wr(input logic [9:0] len);
    app_wr = 1'b1; app_len = len; @(negedge clk); app_wr = 1'b0;
  endtask
  task automatic pulse_irq();
    app_irq = 1'b1; @(negedge clk); app_irq = 1'b0;
  endtask

  // bus reset; with hs_cap the host answers the device chirp with 3 K-J pairs
  task automatic reset_bus(input bit go_hs);
    line = SE0;
    idle(16);
    chk(ls === (hs_cap ? L_CHIRP : L_FS), "reset detected after 16 clocks of SE0");
    if (hs_cap) begin
      n = 0;
      for (i = 0; i < 8; i++) begin idle(1); if (chirp_k === 1'b1) n++; end
      idle(1);
      chk(n == 8 && chirp_k === 1'b0 && ls === L_CHWAIT, "device chirp K for 8 clocks");
      if (go_hs) begin
        for (i = 0; i < 3; i++) begin
          line = K; idle(2); line = J; idle(2);
        end
        chk(ls === L_HS && hs === 1'b1, "3 host K-J pairs -> HS");
        line = SE0;
      end
    end else begin
      line = J; idle(1);
    end
  endtask

  // control transfer helpers (EP0); addr is the current device address
  task automatic setup(input logic [6:0] a, input logic [7:0] t, input logic [7:0] r,
                       input logic [7:0] v, input logic [7:0] x, input string msg);
    tok(P_SETUP, a, 4'h0);
    exp_none({msg, ": SETUP token alone has no answer"});
    dat(P_DATA0, 10'd8, {x, v, r, t});
    exp(P_ACK, {msg, ": SETUP data ACKed"});
  endtask

  task automatic status_in(input logic [6:0] a, input string msg);
    tok(P_IN, a, 4'h0);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA1, P_DATA1} && tx_len === 10'd0, {msg, ": status ZLP DATA1"});
    tok(P_ACK, 7'h00, 4'h0);
  endtask

  task automatic enumerate(input logic [6:0] a);
    setup(7'h00, 8'h00, 8'h05, {1'b0, a}, 8'h00, "SET_ADDRESS");
    status_in(7'h00, "SET_ADDRESS");
    setup(a, 8'h00, 8'h09, 8'h01, 8'h00, "SET_CONFIGURATION");
    status_in(a, "SET_CONFIGURATION");
    chk(dev_state === 2'd2 && cfg_val === 1'b1 && dev_addr === a, "enumerated: CONFIGURED");
  endtask

  task automatic halt_ep(input logic [6:0] a, input logic [7:0] ep, input bit set);
    setup(a, 8'h02, set ? 8'h03 : 8'h01, 8'h00, ep, set ? "SET_FEATURE(HALT)" : "CLEAR_FEATURE(HALT)");
    status_in(a, "HALT feature");
  endtask

  initial begin
    // ------------------------------------------------------------ 1. power-on
    idle(3);
    chk(tx_valid === 1'b0 && ls === L_FS, "in reset: no answer, FS");
    rst_n = 1'b1;
    idle(1);
    chk(ls === L_FS && hs === 1'b0 && dev_state === 2'd0 && dev_addr === 7'h00 && resets === 8'd0,
        "after rst_n: FS, DEFAULT, address 0");
    chk(tx_valid === 1'b0 && pid_err === 8'd0 && sof_cnt === 8'd0, "after rst_n: idle, counters 0");

    // ------------------------------------------------------------ 2. FS reset, no chirp
    hs_cap = 1'b0;
    line = SE0;
    idle(15);
    chk(resets === 8'd0, "15 clocks of SE0: no reset yet");
    idle(1);
    chk(resets === 8'd1 && ls === L_FS && chirp_k === 1'b0, "16th clock: bus reset, FS (no hs_cap)");
    idle(30);
    chk(resets === 8'd1, "SE0 held on after the reset: no second reset");
    line = J; idle(2);
    line = SE0; idle(16);
    chk(resets === 8'd2, "J then SE0 16 clocks: second reset");
    line = J; idle(1);

    // ------------------------------------------------------------ 3. FS enumeration and bulk
    sof(11'd5);
    chk(frame_num === 11'd5 && sof_cnt === 8'd1 && uframe === 3'd0, "FS SOF: frame 5");
    sof(11'd6);
    chk(frame_num === 11'd6 && sof_miss === 8'd0, "FS SOF: next frame, no miss");
    sof(11'd6);
    chk(sof_miss === 8'd1 && uframe === 3'd0, "FS: repeated frame number -> sof_miss");
    sof(11'd9);
    chk(sof_miss === 8'd2 && frame_num === 11'd9, "FS: skipped frames -> sof_miss");
    enumerate(7'h11);
    // FS bulk OUT: no NYET, PING ignored
    tok(P_OUT, 7'h11, 4'h1); dat(P_DATA0, 10'd64, 32'h1);
    exp(P_ACK, "FS bulk OUT DATA0: ACK");
    tok(P_OUT, 7'h11, 4'h1); dat(P_DATA1, 10'd64, 32'h2);
    exp(P_ACK, "FS bulk OUT fills both buffers: ACK (no NYET at FS)");
    tok(P_PING, 7'h11, 4'h1);
    exp_none("FS: PING is not answered");
    tok(P_OUT, 7'h11, 4'h1); dat(P_DATA0, 10'd65, 32'h3);
    exp_none("FS bulk OUT 65 bytes: babble, no handshake");
    chk(babble_cnt === 8'd1, "babble counted");
    pulse_rd(); pulse_rd();
    pulse_wr(10'd200);
    tok(P_IN, 7'h11, 4'h2);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA0, P_DATA0} && tx_len === 10'd64 && tx_data === 16'hB200,
        "FS bulk IN: app length clamped to 64");
    tok(P_ACK, 7'h00, 4'h0);
    sof(11'd10);

    // FS idle J -> suspend; resume
    idle(23);
    chk(ls === L_FS, "23 idle clocks: still FS");
    idle(1);
    chk(ls === L_SUSP, "24 idle J clocks: suspend");
    tok(P_IN, 7'h11, 4'h3);
    exp_none("suspended: packets ignored");
    line = K; idle(2); line = J; idle(1);
    chk(ls === L_SUSP, "2-clock K: no resume");
    line = K; idle(5); line = J; idle(1);
    chk(ls === L_FS && hs === 1'b0 && dev_state === 2'd2, "K >= 4 clocks then J: resume at FS, still CONFIGURED");

    // ------------------------------------------------------------ 4. HS chirp
    hs_cap = 1'b1;
    reset_bus(1'b1);
    chk(resets === 8'd3 && dev_state === 2'd0 && dev_addr === 7'h00 && cfg_val === 1'b0,
        "reset returns the device to DEFAULT / address 0");
    tok(P_OUT, 7'h11, 4'h1);
    exp_none("old address no longer answers");

    // chirp failure: host never chirps
    line = SE0;
    idle(24);
    chk(ls === L_CHIRP && resets === 8'd4, "HS idle with SE0 -> reset, new chirp");
    idle(8);
    tok(P_SETUP, 7'h00, 4'h0);
    exp_none("packets during the chirp are ignored");
    idle(48);
    chk(ls === L_FS && hs === 1'b0, "no host chirp within 48 clocks: FS");
    // 1-clock chirp levels do not count
    line = J; idle(2);
    reset_bus(1'b0);
    for (i = 0; i < 12; i++) begin line = (i % 2) ? J : K; idle(1); end
    line = SE0;
    idle(40);
    chk(ls === L_FS && hs === 1'b0, "1-clock K/J levels: FS fallback");
    // K-K-J order wrong: K then K (one level) then J J counts only 2
    line = J; idle(2);
    reset_bus(1'b0);
    line = K; idle(2); line = J; idle(2); line = K; idle(2);
    line = SE0; idle(48);
    chk(ls === L_FS, "only 1.5 K-J pairs: FS fallback");
    line = J; idle(2);
    reset_bus(1'b1);

    // ------------------------------------------------------------ 5. HS control
    // address applies only after the status stage
    setup(7'h00, 8'h00, 8'h05, 8'h2A, 8'h00, "SET_ADDRESS 0x2A");
    chk(dev_addr === 7'h00, "address not applied before the status stage");
    tok(P_IN, 7'h2A, 4'h0);
    exp_none("new address not answered before the status stage");
    tok(P_IN, 7'h00, 4'h0);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA1, P_DATA1} && tx_len === 10'd0, "status IN: ZLP DATA1");
    chk(dev_addr === 7'h00, "address still 0 before the host ACK");
    idle(16);
    chk(tmo_cnt === 8'd1 && dev_addr === 7'h00, "status ZLP without ACK: timeout, address held");
    status_in(7'h00, "status retry");
    chk(dev_addr === 7'h2A && dev_state === 2'd1, "status ACK: ADDRESS 0x2A");
    // SET_CONFIGURATION 2 is not a valid configuration
    setup(7'h2A, 8'h00, 8'h09, 8'h02, 8'h00, "SET_CONFIGURATION(2)");
    tok(P_IN, 7'h2A, 4'h0);
    exp(P_STALL, "invalid configuration: status STALL");
    tok(P_IN, 7'h2A, 4'h0);
    exp(P_STALL, "protocol stall persists");
    tok(P_OUT, 7'h2A, 4'h0); dat(P_DATA1, 10'd0, 32'h0);
    exp(P_STALL, "protocol stall: OUT also STALLed");
    // a bulk endpoint before CONFIGURED does not answer
    tok(P_IN, 7'h2A, 4'h2);
    exp_none("EP2 before CONFIGURED: no answer");
    setup(7'h2A, 8'h00, 8'h09, 8'h01, 8'h00, "SET_CONFIGURATION(1)");
    status_in(7'h2A, "SET_CONFIGURATION(1)");
    chk(dev_state === 2'd2 && cfg_val === 1'b1, "CONFIGURED");
    // SET_ADDRESS in CONFIGURED -> stall
    setup(7'h2A, 8'h00, 8'h05, 8'h33, 8'h00, "SET_ADDRESS in CONFIGURED");
    tok(P_IN, 7'h2A, 4'h0);
    exp(P_STALL, "SET_ADDRESS in CONFIGURED: STALL");
    chk(dev_addr === 7'h2A, "address unchanged");
    // GET_STATUS(device)
    setup(7'h2A, 8'h80, 8'h00, 8'h00, 8'h00, "GET_STATUS(device)");
    tok(P_IN, 7'h2A, 4'h0);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA1, P_DATA1} && tx_len === 10'd2 && tx_data === 16'h0001,
        "GET_STATUS(device): DATA1, 2 bytes, self-powered");
    tok(P_ACK, 7'h00, 4'h0);
    tok(P_IN, 7'h2A, 4'h0);
    exp(P_STALL, "IN after the data stage (status must be OUT): STALL");
    setup(7'h2A, 8'h80, 8'h00, 8'h00, 8'h00, "GET_STATUS(device) again");
    tok(P_IN, 7'h2A, 4'h0); tok(P_ACK, 7'h00, 4'h0);
    tok(P_OUT, 7'h2A, 4'h0); dat(P_DATA0, 10'd0, 32'h0);
    exp(P_ACK, "status OUT with DATA0: ACK as duplicate");
    chk(dup_cnt === 8'd1, "duplicate counted");
    tok(P_OUT, 7'h2A, 4'h0); dat(P_DATA1, 10'd0, 32'h0);
    exp(P_ACK, "status OUT ZLP DATA1: ACK");
    tok(P_OUT, 7'h2A, 4'h0); dat(P_DATA1, 10'd0, 32'h0);
    exp(P_STALL, "OUT with no transfer in progress: STALL");
    // unsupported request
    setup(7'h2A, 8'h80, 8'h06, 8'h00, 8'h00, "GET_DESCRIPTOR (unsupported)");
    tok(P_IN, 7'h2A, 4'h0);
    exp(P_STALL, "unsupported request: STALL");
    setup(7'h2A, 8'h80, 8'h00, 8'h00, 8'h00, "SETUP clears the protocol stall");
    tok(P_IN, 7'h2A, 4'h0);
    chk(tx_valid === 1'b1 && tx_len === 10'd2, "after a new SETUP: data stage served");
    tok(P_ACK, 7'h00, 4'h0);
    tok(P_OUT, 7'h2A, 4'h0); dat(P_DATA1, 10'd0, 32'h0);
    // malformed SETUP data
    tok(P_SETUP, 7'h2A, 4'h0); dat(P_DATA1, 10'd8, 32'h0000_0080);
    exp_none("SETUP with DATA1: no handshake");
    tok(P_SETUP, 7'h2A, 4'h0); dat(P_DATA0, 10'd7, 32'h0000_0080);
    exp_none("SETUP with 7 bytes: no handshake");
    tok(P_SETUP, 7'h2A, 4'h1); dat(P_DATA0, 10'd8, 32'h0000_0080);
    exp_none("SETUP to EP1: ignored");
    tok(P_OUT, 7'h2A, 4'h0); dat(P_DATA1, 10'd65, 32'h0);
    exp_none("EP0 OUT 65 bytes: babble");

    // ------------------------------------------------------------ 6. HS bulk OUT, PING / NYET
    s0 = nyet_cnt; s1 = nak_cnt;
    tok(P_PING, 7'h2A, 4'h1);
    exp(P_ACK, "PING with free buffers: ACK");
    tok(P_PING, 7'h2A, 4'h0);
    exp(P_ACK, "PING on EP0: ACK");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA0, 10'd512, 32'h10);
    exp(P_ACK, "HS bulk OUT 512 bytes DATA0: ACK");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA1, 10'd512, 32'h11);
    exp(P_NYET, "packet filling the last buffer: NYET");
    chk(nyet_cnt === s0 + 8'd1, "NYET counted");
    tok(P_PING, 7'h2A, 4'h1);
    exp(P_NAK, "PING with no free buffer: NAK");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA0, 10'd10, 32'h12);
    exp(P_NAK, "OUT with no free buffer: NAK");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA1, 10'd10, 32'h12);
    exp(P_ACK, "repeat of the last packet (DATA1) while full: ACK, dropped");
    chk(dup_cnt === 8'd2 && nak_cnt === s1 + 8'd2, "dup and NAK counted");
    pulse_rd();
    tok(P_PING, 7'h2A, 4'h1);
    exp(P_ACK, "after app_rd: PING ACK");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA0, 10'd513, 32'h13);
    exp_none("HS bulk OUT 513 bytes: babble");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA0, 10'd100, 32'h13);
    exp(P_NYET, "refill the last buffer: NYET");
    pulse_rd(); pulse_rd(); pulse_rd();
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA1, 10'd100, 32'h14);
    exp(P_ACK, "after draining: ACK");
    // CRC / PID errors keep the toggle
    pulse_rd();
    s0 = crc16_err;
    tok(P_OUT, 7'h2A, 4'h1); pkt(P_DATA0, 7'h00, 4'h0, 10'd8, 32'h15, 1'b0);
    exp_none("bad CRC16: no handshake");
    chk(crc16_err === s0 + 8'd1, "CRC16 error counted");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA0, 10'd8, 32'h15);
    exp(P_ACK, "retry after the bad CRC: ACK with the same toggle");
    s0 = pid_err;
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA2, 10'd8, 32'h16);
    exp_none("DATA2 on a bulk endpoint: ignored");
    chk(pid_err === s0 + 8'd1, "DATA2 counted as PID error");
    rx_valid = 1'b1; rx_pid = 8'h11; rx_addr = 7'h2A; rx_endp = 4'h2; @(negedge clk); rx_valid = 1'b0;
    exp_none("PID check nibble wrong: dropped");
    chk(pid_err === s0 + 8'd2, "PID check error counted");
    s0 = crc5_err;
    pkt(P_IN, 7'h2A, 4'h3, 10'd0, 32'h0, 1'b0);
    exp_none("bad CRC5 token: no answer");
    chk(crc5_err === s0 + 8'd1, "CRC5 error counted");
    // data timeout and token abort
    tok(P_OUT, 7'h2A, 4'h1);
    idle(16);
    dat(P_DATA1, 10'd8, 32'h17);
    exp_none("data 16 clocks after the OUT token: ignored");
    tok(P_OUT, 7'h2A, 4'h1);
    tok(P_IN, 7'h2A, 4'h2);
    exp(P_NAK, "IN token aborts the OUT data wait (EP2 empty: NAK)");
    pulse_rd();
    tok(P_OUT, 7'h2A, 4'h1); tok(P_ACK, 7'h00, 4'h0); dat(P_DATA1, 10'd8, 32'h17);
    exp(P_ACK, "stray handshake during the data wait is ignored");
    pulse_rd();

    // ------------------------------------------------------------ 7. HS bulk / interrupt IN
    pulse_wr(10'd600); pulse_wr(10'd20); pulse_wr(10'd30);
    tok(P_IN, 7'h2A, 4'h2);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA0, P_DATA0} && tx_len === 10'd512 && tx_data === 16'hB201,
        "HS bulk IN: 600 clamped to 512, DATA0");
    idle(16);
    chk(tmo_cnt === 8'd2, "no host ACK: timeout");
    tok(P_IN, 7'h2A, 4'h2);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA0, P_DATA0} && tx_data === 16'hB201, "retry repeats DATA0 and the data");
    tok(P_NAK, 7'h00, 4'h0);
    chk(tmo_cnt === 8'd3, "host NAK instead of ACK: not retired");
    tok(P_IN, 7'h2A, 4'h2);
    tok(P_IN, 7'h2A, 4'h2);
    chk(tmo_cnt === 8'd4 && tx_pid === {~P_DATA0, P_DATA0}, "a token instead of the ACK: not retired, served again");
    tok(P_ACK, 7'h00, 4'h0);
    tok(P_IN, 7'h2A, 4'h2);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA1, P_DATA1} && tx_len === 10'd20 && tx_data === 16'hB202,
        "second packet: DATA1, 20 bytes (third app_wr dropped: FIFO full)");
    tok(P_ACK, 7'h00, 4'h0);
    tok(P_IN, 7'h2A, 4'h2);
    exp(P_NAK, "FIFO empty: NAK");
    tok(P_IN, 7'h2A, 4'h3);
    exp(P_NAK, "interrupt EP3 without a report: NAK");
    pulse_irq();
    tok(P_IN, 7'h2A, 4'h3);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA0, P_DATA0} && tx_len === 10'd4 && tx_data === 16'hE300,
        "interrupt IN: DATA0, 4 bytes");
    tok(P_ACK, 7'h00, 4'h0);
    tok(P_IN, 7'h2A, 4'h3);
    exp(P_NAK, "report consumed: NAK");
    pulse_irq();
    tok(P_IN, 7'h2A, 4'h3);
    chk(tx_pid === {~P_DATA1, P_DATA1} && tx_data === 16'hE301, "next report: DATA1");
    tok(P_ACK, 7'h00, 4'h0);
    tok(P_IN, 7'h2A, 4'h5);
    exp_none("EP5 does not exist: no answer");
    tok(P_OUT, 7'h2A, 4'h2); dat(P_DATA0, 10'd4, 32'h0);
    exp_none("OUT to the IN endpoint: no answer");
    tok(P_IN, 7'h2B, 4'h2);
    exp_none("other device address: no answer");

    // ------------------------------------------------------------ 8. halt feature, toggles
    halt_ep(7'h2A, 8'h82, 1'b1);
    chk(ep_halt === 4'b0100, "EP2 halted");
    pulse_wr(10'd8);
    tok(P_IN, 7'h2A, 4'h2);
    exp(P_STALL, "halted EP2: STALL");
    setup(7'h2A, 8'h82, 8'h00, 8'h00, 8'h82, "GET_STATUS(EP2)");
    tok(P_IN, 7'h2A, 4'h0);
    chk(tx_len === 10'd2 && tx_data === 16'h0001, "GET_STATUS(EP2): halted");
    tok(P_ACK, 7'h00, 4'h0);
    tok(P_OUT, 7'h2A, 4'h0); dat(P_DATA1, 10'd0, 32'h0);
    halt_ep(7'h2A, 8'h82, 1'b0);
    chk(ep_halt === 4'b0000, "EP2 halt cleared");
    tok(P_IN, 7'h2A, 4'h2);
    chk(tx_pid === {~P_DATA0, P_DATA0} && tx_data === 16'hB203, "CLEAR_FEATURE resets the toggle to DATA0");
    tok(P_ACK, 7'h00, 4'h0);
    halt_ep(7'h2A, 8'h01, 1'b1);
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA0, 10'd8, 32'h0);
    exp(P_STALL, "halted EP1: OUT STALL");
    tok(P_PING, 7'h2A, 4'h1);
    exp(P_STALL, "halted EP1: PING STALL");
    setup(7'h2A, 8'h02, 8'h03, 8'h00, 8'h00, "SET_FEATURE(HALT) on EP0");
    tok(P_IN, 7'h2A, 4'h0);
    exp(P_STALL, "halt of EP0 is not supported: STALL");
    setup(7'h2A, 8'h02, 8'h03, 8'h01, 8'h01, "SET_FEATURE(feature 1)");
    tok(P_IN, 7'h2A, 4'h0);
    exp(P_STALL, "unknown feature selector: STALL");
    // EP1 toggle is now 1 (after the last accepted DATA0 ... ); SET_CONFIGURATION resets toggles and halts
    setup(7'h2A, 8'h00, 8'h09, 8'h01, 8'h00, "SET_CONFIGURATION(1) again");
    status_in(7'h2A, "re-configure");
    chk(ep_halt === 4'b0000, "SET_CONFIGURATION clears halts");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA0, 10'd8, 32'h0);
    exp(P_ACK, "after SET_CONFIGURATION: EP1 expects DATA0");
    tok(P_OUT, 7'h2A, 4'h1); dat(P_DATA0, 10'd8, 32'h0);
    exp(P_ACK, "DATA0 again: duplicate");
    pulse_rd();
    setup(7'h2A, 8'h00, 8'h09, 8'h00, 8'h00, "SET_CONFIGURATION(0)");
    status_in(7'h2A, "de-configure");
    chk(dev_state === 2'd1 && cfg_val === 1'b0, "configuration 0: back to ADDRESS");
    tok(P_IN, 7'h2A, 4'h3);
    exp_none("EP3 in ADDRESS state: no answer");
    setup(7'h2A, 8'h00, 8'h09, 8'h01, 8'h00, "SET_CONFIGURATION(1) third");
    status_in(7'h2A, "configure");

    // ------------------------------------------------------------ 9. HS SOF / microframes
    s0 = sof_miss;
    sof(11'd100);
    for (i = 1; i < 8; i++) begin
      sof(11'd100);
      chk(uframe === i[2:0] && frame_num === 11'd100, "HS: microframe advances within frame 100");
    end
    sof(11'd100);
    chk(sof_miss === s0 + 8'd1 && uframe === 3'd7, "ninth microframe: sof_miss");
    sof(11'd101);
    chk(uframe === 3'd0 && frame_num === 11'd101 && sof_miss === s0 + 8'd1, "next frame: microframe 0");
    sof(11'd2047);
    chk(sof_miss === s0 + 8'd2, "frame jump: sof_miss");
    sof(11'd0);
    chk(frame_num === 11'd0 && sof_miss === s0 + 8'd2, "frame number wraps 2047 -> 0");
    s0 = crc5_err;
    pkt(P_SOF, 7'h01, 4'h0, 10'd0, 32'h0, 1'b0);
    chk(frame_num === 11'd0 && crc5_err === s0 + 8'd1, "SOF with bad CRC5: ignored");

    // ------------------------------------------------------------ 10. split transactions
    s0 = split_cnt;
    tok(P_SPLIT, 7'h2A, 4'h1);                  // SSPLIT port 1
    exp_none("SPLIT token alone: no answer");
    tok(P_OUT, 7'h05, 4'h2);
    exp_none("SSPLIT OUT token: waits for data");
    dat(P_DATA0, 10'd64, 32'h0);
    exp(P_ACK, "SSPLIT OUT data: TT accepts");
    tok(P_SPLIT, 7'h2A, 4'h9); tok(P_OUT, 7'h05, 4'h2);
    exp(P_NYET, "CSPLIT while the TT works: NYET");
    tok(P_SPLIT, 7'h2A, 4'h1); tok(P_IN, 7'h06, 4'h1);
    exp(P_NAK, "SSPLIT while the TT is busy: NAK");
    tok(P_SPLIT, 7'h2A, 4'h9); tok(P_OUT, 7'h05, 4'h3);
    exp(P_STALL, "CSPLIT for another endpoint: STALL");
    idle(4);
    tok(P_SPLIT, 7'h2A, 4'h9); tok(P_OUT, 7'h05, 4'h2);
    exp(P_ACK, "CSPLIT after the TT finished: ACK");
    chk(split_cnt === s0 + 8'd1, "split completed");
    tok(P_SPLIT, 7'h2A, 4'h9); tok(P_OUT, 7'h05, 4'h2);
    exp(P_STALL, "second CSPLIT: nothing pending, STALL");
    tok(P_SPLIT, 7'h2A, 4'h1); tok(P_IN, 7'h06, 4'h1);
    exp(P_ACK, "SSPLIT IN: ACK");
    tok(P_SPLIT, 7'h2A, 4'h9); tok(P_OUT, 7'h06, 4'h1);
    exp(P_STALL, "CSPLIT with the wrong direction: STALL");
    tok(P_SPLIT, 7'h2A, 4'h9); tok(P_IN, 7'h06, 4'h1);
    exp(P_NYET, "CSPLIT IN early: NYET");
    idle(6);
    tok(P_SPLIT, 7'h2A, 4'h9); tok(P_IN, 7'h06, 4'h1);
    chk(tx_valid === 1'b1 && tx_pid === {~P_DATA0, P_DATA0} && tx_len === 10'd8 && tx_data === {5'd0, 7'h06, 4'h1},
        "CSPLIT IN done: DATA0, 8 bytes");
    chk(split_cnt === s0 + 8'd2, "second split completed");
    tok(P_SPLIT, 7'h2A, 4'h1); tok(P_SETUP, 7'h07, 4'h0); pkt(P_DATA0, 7'h0, 4'h0, 10'd8, 32'h0, 1'b0);
    exp_none("SSPLIT SETUP with bad CRC16: no answer, TT stays free");
    tok(P_SPLIT, 7'h2A, 4'h1); tok(P_SETUP, 7'h07, 4'h0); dat(P_DATA0, 10'd65, 32'h0);
    exp_none("SSPLIT data over 64 bytes: babble");
    tok(P_SPLIT, 7'h2A, 4'h1); tok(P_SETUP, 7'h07, 4'h0); dat(P_DATA0, 10'd8, 32'h0);
    exp(P_ACK, "SSPLIT SETUP: ACK (TT was free)");
    idle(9);
    tok(P_SPLIT, 7'h2A, 4'h9); tok(P_SETUP, 7'h07, 4'h0);
    exp(P_ACK, "CSPLIT SETUP: ACK");
    tok(P_SPLIT, 7'h2B, 4'h1); tok(P_IN, 7'h06, 4'h1);
    exp_none("SPLIT to another hub: ignored");
    tok(P_SPLIT, 7'h2A, 4'h1); idle(4); tok(P_IN, 7'h2A, 4'h2);
    exp(P_NAK, "SPLIT not followed within 4 clocks: next token is a normal IN");
    s0 = crc5_err;
    tok(P_SPLIT, 7'h2A, 4'h1); pkt(P_IN, 7'h06, 4'h1, 10'd0, 32'h0, 1'b0);
    exp_none("split token with a bad CRC5: dropped");
    chk(crc5_err === s0 + 8'd1, "split token CRC5 error counted once");
    s0 = crc5_err; s1 = crc16_err;
    pkt(P_DATA1, 7'h2A, 4'h0, 10'd8, 32'h0, 1'b0);
    exp_none("stray data packet while idle: ignored");
    chk(crc5_err === s0 && crc16_err === s1, "stray data packet with a bad CRC: not counted");
    tok(P_SPLIT, 7'h2A, 4'h1); sof(11'd1);
    chk(frame_num === 11'd1, "SOF after a SPLIT is still a SOF");

    // ------------------------------------------------------------ 11. HS suspend / resume, reset
    line = J;
    idle(23);
    chk(ls === L_HS, "HS: 23 clocks without packets");
    idle(1);
    chk(ls === L_SUSP && hs === 1'b0, "HS: 24 clocks idle with J -> suspend (FS termination)");
    line = K; idle(4); line = SE0; idle(1);
    chk(ls === L_HS && hs === 1'b1 && dev_state === 2'd2, "resume K, then back to HS");
    tok(P_IN, 7'h2A, 4'h2);
    exp(P_NAK, "after resume: device answers");
    line = J; idle(24);
    chk(ls === L_SUSP, "suspend again");
    line = SE0; idle(15);
    chk(ls === L_SUSP, "SE0 for 15 clocks in suspend: no reset yet");
    idle(1);
    chk(ls === L_CHIRP && dev_state === 2'd0, "SE0 16 clocks in suspend: reset, chirp");
    idle(9);
    for (i = 0; i < 3; i++) begin line = K; idle(2); line = J; idle(2); end
    chk(ls === L_HS, "HS again after the reset");
    line = SE0;
    enumerate(7'h3C);
    // split in FS is ignored: drop to FS by a failed chirp
    idle(24);
    idle(8 + 48);
    chk(ls === L_FS && hs === 1'b0, "reset without host chirp: FS");
    line = J; idle(1);
    enumerate(7'h3D);
    tok(P_SPLIT, 7'h3D, 4'h1); tok(P_IN, 7'h06, 4'h1);
    exp_none("SPLIT at FS: not a hub transaction, IN to 0x06 ignored");
    tok(P_OUT, 7'h3D, 4'h1); dat(P_DATA0, 10'd8, 32'h0);
    tok(P_OUT, 7'h3D, 4'h1); dat(P_DATA1, 10'd8, 32'h0);
    exp(P_ACK, "FS: buffer full without NYET");
    pulse_wr(10'd100);
    tok(P_IN, 7'h3D, 4'h2);
    chk(tx_len === 10'd64, "FS bulk IN clamp 64");
    tok(P_ACK, 7'h00, 4'h0);

    // ------------------------------------------------------------ 12. rst_n
    rst_n = 1'b0; idle(1); rst_n = 1'b1; idle(1);
    chk(ls === L_FS && resets === 8'd0 && dev_addr === 7'h00 && nak_cnt === 8'd0 && split_cnt === 8'd0,
        "rst_n clears everything");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #400000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
