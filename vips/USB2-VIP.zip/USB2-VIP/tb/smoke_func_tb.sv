// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2025 Functional smoke testbench (USB 2.0 device endpoint FSM)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened usb2_smoke_model.
// DUT behaviour (from dut_usb2_smoke_model.sv):
//   - token decode by PID class/subtype bits; SOF updates frame_num
//   - SETUP resets the DATA0/DATA1 toggle; accepted data flips it
//   - simplified SET_ADDRESS: accepted SETUP data byte becomes dev_addr,
//     dev_state DEFAULT -> ADDRESS -> CONFIGURED
//   - bad CRC -> NAK without toggle flip; endpoint 0xF -> STALL;
//     duplicate (toggle-mismatched) data -> ACK without flip
//   - IN token raises tx_valid with an incrementing payload byte until the
//     host handshake arrives; ACK flips the toggle
//   - tokens to other device addresses are ignored (promiscuous=0)
// PID byte is composed as {~ln, ln} with ln = {subtype, class}, matching
// the USB PID check-bit convention (e.g. SETUP = 8'h2D).

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        clk = 1'b0;
  logic        rst_n = 1'b0;
  logic        pid_valid = 1'b0;
  logic [7:0]  rx_pid = 8'h00;
  logic [6:0]  rx_addr = 7'h00;
  logic [3:0]  rx_endp = 4'h0;
  logic [7:0]  rx_data = 8'h00;
  logic        rx_crc_ok = 1'b1;
  logic        promiscuous = 1'b0;
  wire [1:0]  hs_resp;
  wire        data_toggle;
  wire [3:0]  dev_state;
  wire [6:0]  dev_addr;
  wire [10:0] frame_num;
  wire [7:0]  tx_data;
  wire        tx_valid;
  wire [7:0]  nak_count;

  always #5 clk = ~clk;

  usb2_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .pid_valid(pid_valid), .rx_pid(rx_pid),
    .rx_addr(rx_addr), .rx_endp(rx_endp), .rx_data(rx_data),
    .rx_crc_ok(rx_crc_ok), .promiscuous(promiscuous), .hs_resp(hs_resp),
    .data_toggle(data_toggle), .dev_state(dev_state), .dev_addr(dev_addr),
    .frame_num(frame_num), .tx_data(tx_data), .tx_valid(tx_valid),
    .nak_count(nak_count)
  );

  localparam logic [1:0] CLS_TOKEN = 2'b01;
  localparam logic [1:0] CLS_HS    = 2'b10;
  localparam logic [1:0] CLS_DATA  = 2'b11;
  localparam logic [1:0] TOK_OUT   = 2'b00;
  localparam logic [1:0] TOK_SOF   = 2'b01;
  localparam logic [1:0] TOK_IN    = 2'b10;
  localparam logic [1:0] TOK_SETUP = 2'b11;

  localparam logic [1:0] RESP_NONE  = 2'b00;
  localparam logic [1:0] RESP_ACK   = 2'b01;
  localparam logic [1:0] RESP_NAK   = 2'b10;
  localparam logic [1:0] RESP_STALL = 2'b11;

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // drive one packet-PID cycle, then idle; sample happens after the posedge
  task automatic send_pid(input logic [1:0] cls, input logic [1:0] sub,
                          input logic [6:0] addr, input logic [3:0] endp,
                          input logic [7:0] data, input bit crc_ok);
    logic [3:0] ln;
    ln = {sub, cls};
    @(negedge clk);
    rx_pid = {~ln, ln};              // USB PID = {~pid[3:0], pid[3:0]}
    rx_addr = addr; rx_endp = endp; rx_data = data; rx_crc_ok = crc_ok;
    pid_valid = 1'b1;
    @(negedge clk);
    pid_valid = 1'b0;
  endtask

  task automatic idle(input int n);
    repeat (n) @(negedge clk);
  endtask

  initial begin
    idle(4);
    rst_n = 1'b1;
    idle(2);

    chk(dev_state === 4'd0 && dev_addr === 7'h00 && data_toggle === 1'b0,
        "reset: DEFAULT state, addr 0, DATA0 expected");

    // 1. SOF: frame number tracked, no handshake
    send_pid(CLS_TOKEN, TOK_SOF, 7'h00, 4'h3, 8'hAB, 1'b1);
    idle(2);
    chk(frame_num === {8'hAB, 3'b011}, "SOF updates frame_num");
    chk(hs_resp === RESP_NONE, "SOF produces no handshake");

    // 2. SETUP to default address 0 carrying SET_ADDRESS(5) payload
    send_pid(CLS_TOKEN, TOK_SETUP, 7'h00, 4'h0, 8'h00, 1'b1);
    idle(2);
    chk(data_toggle === 1'b0, "SETUP resets data toggle to DATA0");
    send_pid(CLS_DATA, 2'b00, 7'h00, 4'h0, 8'h05, 1'b1);  // DATA0, payload 5
    idle(2);
    chk(hs_resp === RESP_ACK, "SETUP data stage ACKed");
    chk(dev_addr === 7'h05 && dev_state === 4'd1,
        "SET_ADDRESS accepted: addr=5, state=ADDRESS");

    // 3. OUT/DATA0 to assigned address: ACK, toggle flips to 1
    send_pid(CLS_TOKEN, TOK_OUT, 7'h05, 4'h0, 8'h00, 1'b1);
    idle(1);
    send_pid(CLS_DATA, 2'b00, 7'h05, 4'h0, 8'hC3, 1'b1);
    idle(2);
    chk(hs_resp === RESP_ACK, "OUT DATA0 ACKed");
    chk(data_toggle === 1'b1, "toggle flipped to DATA1 after accept");

    // 4. duplicate DATA0 (toggle mismatch): ACK but no flip
    send_pid(CLS_TOKEN, TOK_OUT, 7'h05, 4'h0, 8'h00, 1'b1);
    idle(1);
    send_pid(CLS_DATA, 2'b00, 7'h05, 4'h0, 8'hC3, 1'b1);
    idle(2);
    chk(hs_resp === RESP_ACK && data_toggle === 1'b1,
        "duplicate DATA0 ACKed without toggle flip");

    // 5. DATA1 with matching toggle: ACK, flips back to 0
    send_pid(CLS_TOKEN, TOK_OUT, 7'h05, 4'h0, 8'h00, 1'b1);
    idle(1);
    send_pid(CLS_DATA, 2'b10, 7'h05, 4'h0, 8'h96, 1'b1);
    idle(2);
    chk(hs_resp === RESP_ACK && data_toggle === 1'b0,
        "DATA1 accepted, toggle back to DATA0");

    // 6. bad CRC: NAK, no toggle flip, nak_count increments
    send_pid(CLS_TOKEN, TOK_OUT, 7'h05, 4'h0, 8'h00, 1'b1);
    idle(1);
    send_pid(CLS_DATA, 2'b00, 7'h05, 4'h0, 8'h00, 1'b0);
    idle(2);
    chk(hs_resp === RESP_NAK && data_toggle === 1'b0 && nak_count === 8'd1,
        "bad CRC: NAK, toggle held, nak_count=1");

    // 7. unimplemented endpoint 0xF: STALL
    send_pid(CLS_TOKEN, TOK_OUT, 7'h05, 4'hF, 8'h00, 1'b1);
    idle(1);
    send_pid(CLS_DATA, 2'b00, 7'h05, 4'hF, 8'h00, 1'b1);
    idle(2);
    chk(hs_resp === RESP_STALL, "endpoint 0xF STALLs");

    // 8. IN transaction: tx_valid rises with payload, host ACK flips toggle
    send_pid(CLS_TOKEN, TOK_IN, 7'h05, 4'h0, 8'h00, 1'b1);
    idle(2);
    chk(tx_valid === 1'b1 && tx_data === 8'd1,
        "IN token: tx_valid=1, first payload byte");
    send_pid(CLS_HS, 2'b00, 7'h05, 4'h0, 8'h00, 1'b1);   // host ACK
    idle(2);
    chk(tx_valid === 1'b0 && data_toggle === 1'b1,
        "host ACK consumed data: tx_valid cleared, toggle flipped");

    // 9. token to a foreign address is ignored
    send_pid(CLS_TOKEN, TOK_OUT, 7'h20, 4'h0, 8'h00, 1'b1);
    idle(1);
    send_pid(CLS_DATA, 2'b01, 7'h20, 4'h0, 8'hFF, 1'b1);
    idle(2);
    chk(dev_addr === 7'h05 && hs_resp === RESP_NONE && nak_count === 8'd1,
        "foreign address ignored (state untouched)");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  // safety timeout
  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
