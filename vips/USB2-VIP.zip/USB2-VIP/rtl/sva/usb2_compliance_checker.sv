// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// USB 2.0 Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 19
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
// L4=Protocol-specific rules
`ifndef USB2_COMPLIANCE_CHECKER_SV
`define USB2_COMPLIANCE_CHECKER_SV

module usb2_compliance_checker (usb_vip_if vif);
  import uvm_pkg::*;
  import usb_vip_pkg::*;
  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_usb2_linestate_j; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_linestate inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_usb2_linestate_j: assert property(p_usb2_linestate_j) l1_pass[0]++; else begin `uvm_warning("USB2_L1", "J state valid failed"); l1_fail[0]++; end
  cover_p_usb2_linestate_j: cover property(p_usb2_linestate_j);

  property p_usb2_rxactive; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_rxvalid |-> vif.utmi_rxactive; endproperty
  assert_p_usb2_rxactive: assert property(p_usb2_rxactive) l1_pass[1]++; else begin `uvm_warning("USB2_L1", "RX active with valid failed"); l1_fail[1]++; end
  cover_p_usb2_rxactive: cover property(p_usb2_rxactive);

  property p_usb2_op_mode; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_op_mode inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_usb2_op_mode: assert property(p_usb2_op_mode) l1_pass[2]++; else begin `uvm_warning("USB2_L1", "Op mode valid failed"); l1_fail[2]++; end
  cover_p_usb2_op_mode: cover property(p_usb2_op_mode);

  property p_usb2_xcvr_select; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_xcvr_select inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_usb2_xcvr_select: assert property(p_usb2_xcvr_select) l1_pass[3]++; else begin `uvm_warning("USB2_L1", "XCVR select valid failed"); l1_fail[3]++; end
  cover_p_usb2_xcvr_select: cover property(p_usb2_xcvr_select);


  // ===== L2: Full Protocol (6 SVAs) =====
  property p_usb2_utmi_txvalid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_txvalid |-> $stable(vif.utmi_txvalid) ##[1:8] vif.utmi_txready; endproperty
  assert_p_usb2_utmi_txvalid: assert property(p_usb2_utmi_txvalid) l2_pass[0]++; else begin `uvm_warning("USB2_L2", "TX valid stable failed"); l2_fail[0]++; end
  cover_p_usb2_utmi_txvalid: cover property(p_usb2_utmi_txvalid);

  property p_usb2_linestate_se0; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_linestate == 2'b00 |-> ##[1:100] vif.rst_n; endproperty
  assert_p_usb2_linestate_se0: assert property(p_usb2_linestate_se0) l2_pass[1]++; else begin `uvm_warning("USB2_L2", "SE0 for reset failed"); l2_fail[1]++; end
  cover_p_usb2_linestate_se0: cover property(p_usb2_linestate_se0);

  property p_usb2_suspend; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_suspend |-> vif.utmi_linestate == 2'b01; endproperty
  assert_p_usb2_suspend: assert property(p_usb2_suspend) l2_pass[2]++; else begin `uvm_warning("USB2_L2", "Suspend entry failed"); l2_fail[2]++; end
  cover_p_usb2_suspend: cover property(p_usb2_suspend);

  property p_usb2_term_select; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_txvalid |-> vif.utmi_term_select; endproperty
  assert_p_usb2_term_select: assert property(p_usb2_term_select) l2_pass[3]++; else begin `uvm_warning("USB2_L2", "Term select failed"); l2_fail[3]++; end
  cover_p_usb2_term_select: cover property(p_usb2_term_select);

  property p_usb2_hs_chirp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_chirp |-> vif.utmi_xcvr_select == 2'b00; endproperty
  assert_p_usb2_hs_chirp: assert property(p_usb2_hs_chirp) l2_pass[4]++; else begin `uvm_warning("USB2_L2", "HS chirp failed"); l2_fail[4]++; end
  cover_p_usb2_hs_chirp: cover property(p_usb2_hs_chirp);

  property p_usb2_resume; @(posedge vif.clk) disable iff (!vif.rst_n) vif.resume |-> vif.utmi_linestate == 2'b10; endproperty
  assert_p_usb2_resume: assert property(p_usb2_resume) l2_pass[5]++; else begin `uvm_warning("USB2_L2", "Resume signaling failed"); l2_fail[5]++; end
  cover_p_usb2_resume: cover property(p_usb2_resume);


  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: an OUT/SETUP/IN token must be answered by a DATA or handshake packet inside 16 cycles
  property p_usb2_l3_token_rsp; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b0001,4'b1101,4'b1001})
    |-> ##[1:16] (vif.mac_valid && vif.mac_pid[3:0] inside {4'b0011,4'b1011,4'b0111,4'b1111,4'b0010,4'b1010,4'b1110,4'b0110}); endproperty
  assert_p_usb2_l3_token_rsp: assert property(p_usb2_l3_token_rsp) l3_pass[0]++; else begin `uvm_warning("USB2_L3", "Token not answered by data/handshake failed"); l3_fail[0]++; end
  cover_p_usb2_l3_token_rsp: cover property(p_usb2_l3_token_rsp);
  // L3-2: RXERROR may only be flagged while RXACTIVE
  property p_usb2_l3_rxerr_window; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_rxerror |-> vif.utmi_rxactive; endproperty
  assert_p_usb2_l3_rxerr_window: assert property(p_usb2_l3_rxerr_window) l3_pass[1]++; else begin `uvm_warning("USB2_L3", "RXERROR outside RXACTIVE failed"); l3_fail[1]++; end
  cover_p_usb2_l3_rxerr_window: cover property(p_usb2_l3_rxerr_window);
  // L3-3: no transmit activity while the link is suspended
  property p_usb2_l3_suspend_no_tx; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_suspend |-> !vif.utmi_txvalid; endproperty
  assert_p_usb2_l3_suspend_no_tx: assert property(p_usb2_l3_suspend_no_tx) l3_pass[2]++; else begin `uvm_warning("USB2_L3", "TXVALID during suspend failed"); l3_fail[2]++; end
  cover_p_usb2_l3_suspend_no_tx: cover property(p_usb2_l3_suspend_no_tx);
  // L3-4: MAC valid must hold until accepted by ready
  property p_usb2_l3_mac_hold; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.mac_valid && !vif.mac_ready) |=> vif.mac_valid; endproperty
  assert_p_usb2_l3_mac_hold: assert property(p_usb2_l3_mac_hold) l3_pass[3]++; else begin `uvm_warning("USB2_L3", "MAC valid dropped before ready failed"); l3_fail[3]++; end
  cover_p_usb2_l3_mac_hold: cover property(p_usb2_l3_mac_hold);

  // ---------------- L4: USB 2.0 protocol-specific rules (5) ----------------
  // L4-1: addressed IN/OUT token completes with handshake or timeout within 32 cycles
  property p_usb2_l4_turnaround; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b1001,4'b0001} && vif.mac_addr inside {7'h20,7'h00} |-> ##[1:32] (vif.utmi_rxvalid || !vif.mac_valid); endproperty
  assert_p_usb2_l4_turnaround: assert property(p_usb2_l4_turnaround) l4_pass[0]++; else begin `uvm_warning("USB2_L4", "Token turnaround failed"); l4_fail[0]++; end
  cover_p_usb2_l4_turnaround: cover property(p_usb2_l4_turnaround);

  // L4-2: inter-packet gap: at least 2 idle cycles after EOP
  property p_usb2_l4_ipg; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_eop |=> !vif.mac_valid ##1 !vif.mac_valid; endproperty
  assert_p_usb2_l4_ipg: assert property(p_usb2_l4_ipg) l4_pass[1]++; else begin `uvm_warning("USB2_L4", "Inter-packet gap violated"); l4_fail[1]++; end
  cover_p_usb2_l4_ipg: cover property(p_usb2_l4_ipg);

  // L4-3: DATA payload ends with EOP within 80 beats (anti-babble)
  property p_usb2_l4_babble; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b0011,4'b1011} |-> ##[1:80] vif.mac_eop; endproperty
  assert_p_usb2_l4_babble: assert property(p_usb2_l4_babble) l4_pass[2]++; else begin `uvm_warning("USB2_L4", "DATA packet babble"); l4_fail[2]++; end
  cover_p_usb2_l4_babble: cover property(p_usb2_l4_babble);

  // L4-4: bus reset forces SE0 on the line
  property p_usb2_l4_reset_se0; @(posedge vif.clk) disable iff (!vif.rst_n) vif.dev_reset |-> vif.utmi_linestate == 2'b00; endproperty
  assert_p_usb2_l4_reset_se0: assert property(p_usb2_l4_reset_se0) l4_pass[3]++; else begin `uvm_warning("USB2_L4", "Reset without SE0"); l4_fail[3]++; end
  cover_p_usb2_l4_reset_se0: cover property(p_usb2_l4_reset_se0);

  // L4-5: device chirp response toggles K/J while host chirps
  property p_usb2_l4_chirp_resp; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.utmi_xcvr_select == 2'b01 && vif.utmi_op_mode == 2'b10 && vif.utmi_term_select) |-> vif.utmi_linestate inside {2'b01,2'b10}; endproperty
  assert_p_usb2_l4_chirp_resp: assert property(p_usb2_l4_chirp_resp) l4_pass[4]++; else begin `uvm_warning("USB2_L4", "Chirp response invalid"); l4_fail[4]++; end
  cover_p_usb2_l4_chirp_resp: cover property(p_usb2_l4_chirp_resp);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l1_hit=0, l2_hit=0, l3_hit=0;
    int l4_total=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("USB2_RPT", $sformatf("=== USB2 Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("USB2_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("USB2_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("USB2_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("USB2_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("USB2_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
