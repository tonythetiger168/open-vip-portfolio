// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB 2.0 UVM agent (host side) for a device on usb2_link_if:
//   usb2_item / usb2_driver  one packet (token, data or handshake, with CRC /
//                            PID-check / length errors), a bus line level,
//                            idle clocks, a device application event
//                            (buffer read, IN data, interrupt report) or the
//                            device's HS capability
//   usb2_monitor             both directions every clock, link state before
//                            and after the edge
//   usb2_scoreboard          predicts the device clock by clock: reset
//                            detection, the chirp handshake, suspend /
//                            resume and HS -> FS reversion; chapter 9
//                            state, address and configuration; every answer
//                            packet (PID, length, data) for control, bulk
//                            OUT with PING / NYET, bulk and interrupt IN with
//                            toggles and retries, split transactions through
//                            the TT; SOF frame / microframe tracking and all
//                            13 counters
//   usb2_coverage            link transitions, answers per transaction kind,
//                            control requests, error / event counters
//   sequences + usb2_env + usb2_link_test
`ifndef USB2_LINK_PKG_SV
`define USB2_LINK_PKG_SV

package usb2_link_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [3:0] P_OUT = 4'h1, P_IN = 4'h9, P_SOF = 4'h5, P_SETUP = 4'hD,
                         P_DATA0 = 4'h3, P_DATA1 = 4'hB, P_DATA2 = 4'h7, P_MDATA = 4'hF,
                         P_ACK = 4'h2, P_NAK = 4'hA, P_STALL = 4'hE, P_NYET = 4'h6,
                         P_SPLIT = 4'h8, P_PING = 4'h4;
  localparam logic [1:0] LN_SE0 = 2'd0, LN_J = 2'd1, LN_K = 2'd2;
  localparam logic [2:0] L_FS = 3'd0, L_CHIRP = 3'd1, L_CHWAIT = 3'd2, L_HS = 3'd3, L_SUSP = 3'd4;
  localparam logic [2:0] X_IDLE = 3'd0, X_ODATA = 3'd1, X_INHS = 3'd2, X_SPLIT = 3'd3, X_SPDATA = 3'd4;
  localparam logic [2:0] C_IDLE = 3'd0, C_DIN = 3'd1, C_SOUT = 3'd2, C_SIN = 3'd3, C_STALL = 3'd4;
  localparam logic [1:0] D_DEFAULT = 2'd0, D_ADDRESS = 2'd1, D_CONFIGURED = 2'd2;
  localparam int T_RST = 16, T_CHIRP = 8, T_CHWAIT = 48, T_IDLE = 24, T_RESUME = 4,
                 T_TMO = 16, T_TT = 8, T_SPLIT = 4;

  typedef enum int { K_PKT, K_LINE, K_IDLE, K_APP_RD, K_APP_WR, K_APP_IRQ, K_CAP } u2_kind_e;

  // ------------------------------------------------------------ item
  class usb2_item extends uvm_sequence_item;
    `uvm_object_utils(usb2_item)
    u2_kind_e    kind = K_IDLE;
    logic [3:0]  pid;
    bit          bad_pid;
    bit          crc_ok = 1;
    logic [6:0]  addr;
    logic [3:0]  endp;
    logic [9:0]  len;
    logic [31:0] data;
    logic [1:0]  lvl;
    int          n = 1;
    function new(string name = "usb2_item"); super.new(name); endfunction
    virtual function string convert2string();
      if (kind == K_PKT) return $sformatf("PKT pid %h addr %h ep %0d len %0d crc %0d", pid, addr, endp, len, crc_ok);
      return kind.name();
    endfunction
  endclass

  class usb2_obs extends uvm_object;
    `uvm_object_utils(usb2_obs)
    bit          hs_cap, rx_valid, rx_crc_ok, app_rd, app_wr, app_irq;
    logic [1:0]  line;
    logic [7:0]  rx_pid;
    logic [6:0]  rx_addr;
    logic [3:0]  rx_endp;
    logic [9:0]  rx_len, app_len;
    logic [31:0] rx_data;
    logic [2:0]  ls, ls_next, uframe;
    bit          hs, chirp_k, cfg_val, tx_valid;
    logic [1:0]  dev_state;
    logic [6:0]  dev_addr;
    logic [10:0] frame_num;
    logic [3:0]  ep_halt;
    logic [7:0]  tx_pid;
    logic [9:0]  tx_len;
    logic [15:0] tx_data;
    logic [7:0]  cnt [13];
    function new(string name = "usb2_obs"); super.new(name); endfunction
  endclass

  typedef uvm_sequencer #(usb2_item) usb2_sequencer;

  // ------------------------------------------------------------ driver
  class usb2_driver extends uvm_driver #(usb2_item);
    `uvm_component_utils(usb2_driver)
    virtual usb2_link_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual usb2_link_if)::get(this, "", "usb2l_vif", vif))
        `uvm_fatal("NOVIF", "usb2l_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      usb2_item t;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(t);
        drive(t);
        seq_item_port.item_done();
      end
    endtask
    task drive(usb2_item t);
      case (t.kind)
        K_LINE: begin vif.line = t.lvl; return; end
        K_CAP:  begin vif.hs_cap = t.lvl[0]; return; end
        default: ;
      endcase
      @(negedge vif.clk);
      case (t.kind)
        K_IDLE: repeat (t.n - 1) @(negedge vif.clk);
        K_APP_RD:  begin vif.app_rd = 1'b1; @(posedge vif.clk); #1 vif.app_rd = 1'b0; end
        K_APP_WR:  begin vif.app_wr = 1'b1; vif.app_len = t.len; @(posedge vif.clk); #1 vif.app_wr = 1'b0; end
        K_APP_IRQ: begin vif.app_irq = 1'b1; @(posedge vif.clk); #1 vif.app_irq = 1'b0; end
        default: begin
          vif.rx_valid = 1'b1;
          vif.rx_pid = t.bad_pid ? {t.pid, t.pid} : {~t.pid, t.pid};
          vif.rx_crc_ok = t.crc_ok; vif.rx_addr = t.addr; vif.rx_endp = t.endp; vif.rx_len = t.len;
          vif.rx_data = t.data;
          @(posedge vif.clk); #1;
          vif.rx_valid = 1'b0; vif.rx_crc_ok = 1'b1; vif.rx_len = 10'd0; vif.rx_data = 32'h0;
        end
      endcase
    endtask
  endclass

  // ------------------------------------------------------------ monitor
  class usb2_monitor extends uvm_monitor;
    `uvm_component_utils(usb2_monitor)
    virtual usb2_link_if vif;
    uvm_analysis_port #(usb2_obs) ap;
    function new(string name, uvm_component parent); super.new(name, parent); ap = new("ap", this); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual usb2_link_if)::get(this, "", "usb2l_vif", vif))
        `uvm_fatal("NOVIF", "usb2l_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      usb2_obs o;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n !== 1'b1) continue;
        o = usb2_obs::type_id::create("o");
        o.hs_cap = vif.hs_cap; o.line = vif.line; o.rx_valid = vif.rx_valid; o.rx_pid = vif.rx_pid;
        o.rx_crc_ok = vif.rx_crc_ok; o.rx_addr = vif.rx_addr; o.rx_endp = vif.rx_endp; o.rx_len = vif.rx_len;
        o.rx_data = vif.rx_data; o.app_rd = vif.app_rd; o.app_wr = vif.app_wr; o.app_irq = vif.app_irq;
        o.app_len = vif.app_len;
        o.ls = vif.ls; o.hs = vif.hs; o.chirp_k = vif.chirp_k; o.dev_state = vif.dev_state; o.dev_addr = vif.dev_addr;
        o.cfg_val = vif.cfg_val; o.frame_num = vif.frame_num; o.uframe = vif.uframe; o.ep_halt = vif.ep_halt;
        o.tx_valid = vif.tx_valid; o.tx_pid = vif.tx_pid; o.tx_len = vif.tx_len; o.tx_data = vif.tx_data;
        o.cnt = '{vif.pid_err, vif.crc5_err, vif.crc16_err, vif.babble_cnt, vif.dup_cnt, vif.nak_cnt,
                  vif.stall_cnt, vif.nyet_cnt, vif.sof_cnt, vif.sof_miss, vif.resets, vif.tmo_cnt, vif.split_cnt};
        #1 o.ls_next = vif.ls;
        ap.write(o);
      end
    endtask
  endclass

  // ------------------------------------------------------------ scoreboard
  class usb2_scoreboard extends uvm_subscriber #(usb2_obs);
    `uvm_component_utils(usb2_scoreboard)
    int unsigned cyc, errors, n_checks, n_pkts, n_ans, n_data, n_ctl, n_split, n_chirp, n_susp;
    // predicted outputs
    logic [2:0]  ls;
    bit          hs, ck, cfg, tv;
    logic [1:0]  st;
    logic [6:0]  addr;
    logic [10:0] fr;
    logic [2:0]  uf;
    logic [3:0]  halt;
    logic [7:0]  tpid;
    logic [9:0]  tlen;
    logic [15:0] tdat;
    logic [7:0]  c [13];   // pid c5 c16 babble dup nak stall nyet sof miss resets tmo split
    // predicted internal state
    logic [4:0]  se0_cnt;
    bit          se0_armed, hs_pre;
    logic [5:0]  idle_cnt, lsc, ch_len;
    logic [2:0]  k_cnt, ch_n;
    logic [1:0]  ch_lvl;
    logic [3:0]  tog_out, tog_in;
    logic [1:0]  ob_n, ib_n;
    logic [9:0]  ib_len [2];
    logic [7:0]  ib_seq [2];
    bit          ib_rd, ib_wr, irq_pend;
    logic [7:0]  wr_seq, irq_seq;
    logic [2:0]  xs, cph;
    logic [4:0]  xt;
    logic [3:0]  x_ep, sp_ep, tt_ep, tt_tmr;
    bit          x_setup, sp_sc, tt_in, sof_seen;
    logic [1:0]  x_src, tt_st;
    logic [6:0]  sp_addr, tt_addr;
    logic [7:0]  c_req, c_val, c_idx;
    logic [15:0] c_status;
    string       cnt_name [13] = '{"pid_err", "crc5_err", "crc16_err", "babble_cnt", "dup_cnt", "nak_cnt",
                                   "stall_cnt", "nyet_cnt", "sof_cnt", "sof_miss", "resets", "tmo_cnt", "split_cnt"};

    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      ls = L_FS; hs = 0; ck = 0; cfg = 0; tv = 0; st = D_DEFAULT; addr = 0; fr = 0; uf = 0; halt = 0;
      tpid = 0; tlen = 0; tdat = 0;
      foreach (c[i]) c[i] = 8'd0;
      se0_cnt = 0; se0_armed = 1; hs_pre = 0; idle_cnt = 0; lsc = 0; ch_len = 0; k_cnt = 0; ch_n = 0; ch_lvl = LN_SE0;
      tog_out = 0; tog_in = 0; ob_n = 0; ib_n = 0; ib_len = '{10'd0, 10'd0}; ib_seq = '{8'd0, 8'd0};
      ib_rd = 0; ib_wr = 0; irq_pend = 0; wr_seq = 0; irq_seq = 0;
      xs = X_IDLE; cph = C_IDLE; xt = 0; x_ep = 0; sp_ep = 0; tt_ep = 0; tt_tmr = 0;
      x_setup = 0; sp_sc = 0; tt_in = 0; sof_seen = 0; x_src = 0; tt_st = 0; sp_addr = 0; tt_addr = 0;
      c_req = 0; c_val = 0; c_idx = 0; c_status = 0;
    endfunction
    function void chk(bit ok, string m);
      n_checks++;
      if (!ok) begin errors++; `uvm_error("USB2_SB", m) end
    endfunction

    function void answer(logic [3:0] p, logic [9:0] len, logic [15:0] d);
      tv = 1; tpid = {~p, p}; tlen = len; tdat = d;
      if (p == P_NAK)   c[5]++;
      if (p == P_STALL) c[6]++;
      if (p == P_NYET)  c[7]++;
      n_ans++;
    endfunction
    function void send_in(logic [1:0] src, bit t, logic [9:0] len, logic [15:0] d);
      answer(t ? P_DATA1 : P_DATA0, len, d);
      xs = X_INHS; xt = 0; x_src = src; n_data++;
    endfunction
    function void bus_reset(bit cap);
      st = D_DEFAULT; addr = 0; cfg = 0; halt = 0; tog_out = 0; tog_in = 0; ob_n = 0;
      ib_rd = 0; ib_wr = 0; ib_n = 0; irq_pend = 0; xs = X_IDLE; xt = 0; cph = C_IDLE; tt_st = 0; tt_tmr = 0;
      fr = 0; uf = 0; sof_seen = 0; c[10]++;
      se0_cnt = 0; se0_armed = 0; idle_cnt = 0; k_cnt = 0; hs = 0; lsc = 0;
      ls = cap ? L_CHIRP : L_FS;
    endfunction
    function void ctl_done();
      if (cph == C_DIN) cph = C_SOUT;
      else if (cph == C_SIN) begin
        cph = C_IDLE; n_ctl++;
        case (c_req)
          8'h05: begin addr = c_val[6:0]; st = (c_val[6:0] == 0) ? D_DEFAULT : D_ADDRESS; end
          8'h09: begin cfg = c_val[0]; st = c_val[0] ? D_CONFIGURED : D_ADDRESS; tog_out = 0; tog_in = 0; halt = 0; end
          8'h01: begin halt[c_idx[1:0]] = 0; tog_out[c_idx[1:0]] = 0; tog_in[c_idx[1:0]] = 0; end
          8'h03: halt[c_idx[1:0]] = 1;
          default: ;
        endcase
      end
    endfunction
    function void setup_decode(logic [31:0] d);
      logic [7:0] t;
      t = d[7:0]; c_req = d[15:8]; c_val = d[23:16]; c_idx = d[31:24];
      if (c_req == 8'h05 && t == 8'h00 && st != D_CONFIGURED && !c_val[7]) cph = C_SIN;
      else if (c_req == 8'h09 && t == 8'h00 && st != D_DEFAULT && c_val <= 1) cph = C_SIN;
      else if (c_req == 8'h00 && t == 8'h80) begin c_status = 16'h0001; cph = C_DIN; end
      else if (c_req == 8'h00 && t == 8'h82 && c_idx[6:2] == 0 && (c_idx[1:0] == 0 || st == D_CONFIGURED)) begin
        c_status = {15'd0, halt[c_idx[1:0]]}; cph = C_DIN;
      end else if ((c_req == 8'h01 || c_req == 8'h03) && t == 8'h02 && c_val == 0 && c_idx[6:2] == 0 &&
                   c_idx[1:0] != 0 && st == D_CONFIGURED) cph = C_SIN;
      else cph = C_STALL;
    endfunction

    // one device clock, inputs of o
    function void step(usb2_obs o);
      bit pv, consumed, is_tok, is_data, tg;
      logic [3:0] pt, ce;
      logic [10:0] f;
      logic [9:0] mps;
      tv = 0; tpid = 0; tlen = 0; tdat = 0; ck = 0;
      mps = hs ? 10'd512 : 10'd64;
      pv = o.rx_valid && (ls == L_FS || ls == L_HS);
      pt = o.rx_pid[3:0];
      if (pv && (o.rx_pid[7:4] != ~o.rx_pid[3:0])) begin c[0]++; pv = 0; end
      if (pv) n_pkts++;
      is_tok  = pt inside {P_OUT, P_IN, P_SETUP, P_SOF, P_PING, P_SPLIT};
      is_data = pt[1:0] == 2'b11;
      consumed = 0;
      if (!pv) begin
        if (xs == X_ODATA || xs == X_SPDATA) begin xt++; if (xt == T_TMO) xs = X_IDLE; end
        else if (xs == X_INHS) begin xt++; if (xt == T_TMO) begin xs = X_IDLE; c[11]++; end end
        else if (xs == X_SPLIT) begin xt++; if (xt == T_SPLIT) xs = X_IDLE; end
      end else begin
        if (xs == X_INHS) begin
          xs = X_IDLE;
          if (pt == P_ACK) begin
            consumed = 1;
            case (x_src)
              2'd0: ctl_done();
              2'd2: begin tog_in[2] = ~tog_in[2]; ib_rd = ~ib_rd; ib_n--; end
              default: begin tog_in[3] = ~tog_in[3]; irq_pend = 0; irq_seq++; end
            endcase
          end else begin
            c[11]++;
            if (!is_tok) consumed = 1;
          end
        end else if (xs == X_ODATA) begin
          if (is_data) begin
            consumed = 1; xs = X_IDLE; tg = pt == P_DATA1;
            if (!o.rx_crc_ok) c[2]++;
            else if (pt == P_DATA2 || pt == P_MDATA) c[0]++;
            else if (x_setup) begin
              if (pt == P_DATA0 && o.rx_len == 8) begin answer(P_ACK, 0, 0); setup_decode(o.rx_data); end
            end else if (x_ep == 0) begin
              if (o.rx_len > 64) c[3]++;
              else if (cph == C_SOUT && tg && o.rx_len == 0) begin answer(P_ACK, 0, 0); cph = C_IDLE; n_ctl++; end
              else if (cph == C_SOUT && !tg) begin answer(P_ACK, 0, 0); c[4]++; end
              else begin answer(P_STALL, 0, 0); cph = C_STALL; end
            end else begin
              if (o.rx_len > mps) c[3]++;
              else if (halt[1]) answer(P_STALL, 0, 0);
              else if (tg != tog_out[1]) begin answer(P_ACK, 0, 0); c[4]++; end
              else if (ob_n == 2) answer(P_NAK, 0, 0);
              else begin
                ob_n++; tog_out[1] = ~tog_out[1];
                if (hs && ob_n == 2) answer(P_NYET, 0, 0);
                else answer(P_ACK, 0, 0);
              end
            end
          end else if (is_tok) xs = X_IDLE;
          else consumed = 1;
        end else if (xs == X_SPDATA) begin
          if (is_data) begin
            consumed = 1; xs = X_IDLE;
            if (!o.rx_crc_ok) c[2]++;
            else if (o.rx_len > 64) c[3]++;
            else if (tt_st != 0) answer(P_NAK, 0, 0);
            else begin answer(P_ACK, 0, 0); tt_st = 1; tt_tmr = 0; tt_in = 0; tt_addr = sp_addr; tt_ep = sp_ep; end
          end else if (is_tok) xs = X_IDLE;
          else consumed = 1;
        end else if (xs == X_SPLIT) begin
          xs = X_IDLE;
          if (pt == P_OUT || pt == P_SETUP || pt == P_IN) begin
            consumed = 1;
            if (!o.rx_crc_ok) c[1]++;
            else if (!sp_sc) begin
              if (pt == P_IN) begin
                if (tt_st == 0) begin
                  answer(P_ACK, 0, 0); tt_st = 1; tt_tmr = 0; tt_in = 1; tt_addr = o.rx_addr; tt_ep = o.rx_endp;
                end else answer(P_NAK, 0, 0);
              end else begin xs = X_SPDATA; xt = 0; sp_addr = o.rx_addr; sp_ep = o.rx_endp; end
            end else begin
              if (tt_st == 0 || tt_addr != o.rx_addr || tt_ep != o.rx_endp || tt_in != (pt == P_IN))
                answer(P_STALL, 0, 0);
              else if (tt_st == 1) answer(P_NYET, 0, 0);
              else begin
                if (tt_in) answer(P_DATA0, 8, {5'd0, tt_addr, tt_ep});
                else answer(P_ACK, 0, 0);
                tt_st = 0; c[12]++; n_split++;
              end
            end
          end else if (!is_tok) consumed = 1;
        end

        if (!consumed && xs == X_IDLE && is_tok) begin
          if (!o.rx_crc_ok) c[1]++;
          else if (pt == P_SOF) begin
            c[8]++;
            f = {o.rx_endp, o.rx_addr};
            if (sof_seen && hs && f == fr) begin
              if (uf == 7) c[9]++; else uf++;
            end else begin
              if (sof_seen && f != fr + 11'd1) c[9]++;
              uf = 0;
            end
            fr = f; sof_seen = 1;
          end else if (pt == P_SPLIT) begin
            if (hs && o.rx_addr == addr) begin xs = X_SPLIT; xt = 0; sp_sc = o.rx_endp[3]; end
          end else if (o.rx_addr == addr) begin
            ce = o.rx_endp;
            case (pt)
              P_SETUP: if (ce == 0) begin xs = X_ODATA; xt = 0; x_ep = 0; x_setup = 1; end
              P_OUT: if (ce == 0 || (ce == 1 && st == D_CONFIGURED)) begin xs = X_ODATA; xt = 0; x_ep = ce; x_setup = 0; end
              P_PING: if (hs) begin
                if (ce == 0) answer(P_ACK, 0, 0);
                else if (ce == 1 && st == D_CONFIGURED) begin
                  if (halt[1]) answer(P_STALL, 0, 0);
                  else if (ob_n == 2) answer(P_NAK, 0, 0);
                  else answer(P_ACK, 0, 0);
                end
              end
              P_IN: begin
                if (ce == 0) begin
                  if (cph == C_DIN) send_in(0, 1, 2, c_status);
                  else if (cph == C_SIN) send_in(0, 1, 0, 0);
                  else begin answer(P_STALL, 0, 0); cph = C_STALL; end
                end else if (ce == 2 && st == D_CONFIGURED) begin
                  if (halt[2]) answer(P_STALL, 0, 0);
                  else if (ib_n == 0) answer(P_NAK, 0, 0);
                  else send_in(2, tog_in[2], ib_len[ib_rd], {8'hB2, ib_seq[ib_rd]});
                end else if (ce == 3 && st == D_CONFIGURED) begin
                  if (halt[3]) answer(P_STALL, 0, 0);
                  else if (!irq_pend) answer(P_NAK, 0, 0);
                  else send_in(3, tog_in[3], 4, {8'hE3, irq_seq});
                end
              end
              default: ;
            endcase
          end
        end
      end

      // application side
      if (o.app_rd && ob_n != 0) ob_n--;
      if (o.app_wr && ib_n != 2) begin
        ib_len[ib_wr] = (o.app_len > mps) ? mps : o.app_len;
        ib_seq[ib_wr] = wr_seq; wr_seq++; ib_wr = ~ib_wr; ib_n++;
      end
      if (o.app_irq) irq_pend = 1;
      if (tt_st == 1) begin tt_tmr++; if (tt_tmr == T_TT) tt_st = 2; end

      // line / speed
      case (ls)
        L_FS: begin
          if (o.line == LN_SE0 && !o.rx_valid) begin if (se0_cnt != 31) se0_cnt++; end
          else se0_cnt = 0;
          if (o.line != LN_SE0) se0_armed = 1;
          if (o.line == LN_J && !o.rx_valid) idle_cnt++; else idle_cnt = 0;
          if (se0_cnt == T_RST && se0_armed) bus_reset(o.hs_cap);
          else if (idle_cnt == T_IDLE) begin ls = L_SUSP; hs_pre = 0; idle_cnt = 0; k_cnt = 0; se0_cnt = 0; n_susp++; end
        end
        L_HS: begin
          if (o.rx_valid) idle_cnt = 0; else idle_cnt++;
          if (idle_cnt == T_IDLE) begin
            if (o.line == LN_SE0) bus_reset(o.hs_cap);
            else begin
              ls = L_SUSP; hs_pre = 1; hs = 0; idle_cnt = 0; k_cnt = 0; se0_cnt = 0; se0_armed = 1; n_susp++;
            end
          end
        end
        L_SUSP: begin
          if (o.line == LN_K) begin if (k_cnt != 7) k_cnt++; end
          else begin
            if (k_cnt >= T_RESUME) begin ls = hs_pre ? L_HS : L_FS; hs = hs_pre; idle_cnt = 0; end
            k_cnt = 0;
          end
          if (ls == L_SUSP) begin
            if (o.line == LN_SE0) begin if (se0_cnt != 31) se0_cnt++; end
            else begin se0_cnt = 0; se0_armed = 1; end
            if (se0_cnt == T_RST && se0_armed) bus_reset(o.hs_cap);
          end
        end
        L_CHIRP: begin
          ck = 1; lsc++;
          if (lsc == T_CHIRP) begin ls = L_CHWAIT; lsc = 0; ch_lvl = LN_SE0; ch_len = 0; ch_n = 0; end
        end
        L_CHWAIT: begin
          lsc++;
          if (o.line == ch_lvl) begin if (ch_len != 63) ch_len++; end
          else begin ch_lvl = o.line; ch_len = 1; end
          if (ch_len == 2 && o.line == (ch_n[0] ? LN_J : LN_K)) ch_n++;
          if (ch_n == 6) begin ls = L_HS; hs = 1; idle_cnt = 0; n_chirp++; end
          else if (lsc == T_CHWAIT) begin ls = L_FS; idle_cnt = 0; se0_cnt = 0; end
        end
        default: ls = L_FS;
      endcase
    endfunction

    function void write(usb2_obs o);
      cyc++;
      // outputs registered at the previous edge
      chk(o.tx_valid == tv && (!tv || (o.tx_pid == tpid && o.tx_len == tlen && o.tx_data == tdat)),
          $sformatf("@%0d answer: valid %0d pid %h len %0d data %h, predicted %0d %h %0d %h", cyc, o.tx_valid,
                    o.tx_pid, o.tx_len, o.tx_data, tv, tpid, tlen, tdat));
      chk(o.ls == ls && o.hs == hs && o.chirp_k == ck,
          $sformatf("@%0d link ls %0d hs %0d chirp %0d, predicted %0d %0d %0d", cyc, o.ls, o.hs, o.chirp_k, ls, hs, ck));
      chk(o.dev_state == st && o.dev_addr == addr && o.cfg_val == cfg && o.ep_halt == halt,
          $sformatf("@%0d device state %0d addr %h cfg %0d halt %b, predicted %0d %h %0d %b", cyc, o.dev_state,
                    o.dev_addr, o.cfg_val, o.ep_halt, st, addr, cfg, halt));
      chk(o.frame_num == fr && o.uframe == uf,
          $sformatf("@%0d frame %0d.%0d, predicted %0d.%0d", cyc, o.frame_num, o.uframe, fr, uf));
      foreach (c[i]) chk(o.cnt[i] == c[i], $sformatf("@%0d %s %0d, predicted %0d", cyc, cnt_name[i], o.cnt[i], c[i]));
      step(o);
      chk(o.ls_next == ls, $sformatf("@%0d link state %0d -> %0d, predicted %0d (line %0d rx %0d)", cyc, o.ls,
                                     o.ls_next, ls, o.line, o.rx_valid));
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("USB2_SB", $sformatf("checks=%0d packets=%0d answers=%0d data=%0d control=%0d splits=%0d chirps=%0d suspends=%0d errors=%0d",
                n_checks, n_pkts, n_ans, n_data, n_ctl, n_split, n_chirp, n_susp, errors), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ coverage
  class usb2_coverage extends uvm_subscriber #(usb2_obs);
    `uvm_component_utils(usb2_coverage)
    logic [2:0] from_s, to_s;
    logic [3:0] tok, ans;
    logic [3:0] ep;
    bit         sp;
    logic [7:0] req;
    int         ev;
    logic [7:0] prev [13];
    bit         first = 1;
    logic [3:0] last_tok, last_ep;
    bit         last_split, after_split;
    covergroup cg_link;
      cp_tr: coverpoint {from_s, to_s} {
        bins fs_susp   = {6'o04};
        bins susp_fs   = {6'o40};
        bins hs_susp   = {6'o34};
        bins susp_hs   = {6'o43};
        bins fs_chirp  = {6'o01};
        bins chirp_w   = {6'o12};
        bins w_hs      = {6'o23};
        bins w_fs      = {6'o20};
        bins hs_chirp  = {6'o31};
        bins susp_chirp = {6'o41};
      }
    endgroup
    covergroup cg_ans;
      cp_ans: coverpoint {sp, tok, ans} {
        bins out_ack   = {9'h012};
        bins out_nak   = {9'h01A};
        bins out_stall = {9'h01E};
        bins out_nyet  = {9'h016};
        bins in_d0     = {9'h093};
        bins in_d1     = {9'h09B};
        bins in_nak    = {9'h09A};
        bins in_stall  = {9'h09E};
        bins setup_ack = {9'h0D2};
        bins ping_ack  = {9'h042};
        bins ping_nak  = {9'h04A};
        bins ping_stall = {9'h04E};
        bins sp_out_ack  = {9'h112};
        bins sp_out_nak  = {9'h11A};
        bins sp_nyet     = {9'h116, 9'h196};
        bins sp_in_ack   = {9'h192};
        bins sp_in_data  = {9'h193};
        bins sp_stall    = {9'h11E, 9'h19E, 9'h1DE};
      }
      cp_ep: coverpoint ep { bins ep0 = {0}; bins ep1 = {1}; bins ep2 = {2}; bins ep3 = {3}; }
    endgroup
    covergroup cg_req;
      cp_req: coverpoint req { bins get_status = {8'h00}; bins clear_feature = {8'h01}; bins set_feature = {8'h03};
                               bins set_address = {8'h05}; bins set_config = {8'h09}; bins other = {8'h06}; }
    endgroup
    covergroup cg_ev;
      cp_ev: coverpoint ev { bins pid = {0}; bins crc5 = {1}; bins crc16 = {2}; bins babble = {3}; bins dup = {4};
                             bins nak = {5}; bins stall = {6}; bins nyet = {7}; bins sof = {8}; bins miss = {9};
                             bins reset = {10}; bins tmo = {11}; bins split = {12}; bins uframe7 = {20};
                             bins configured = {21}; bins halted = {22}; bins fs_configured = {23}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      cg_link = new(); cg_ans = new(); cg_req = new(); cg_ev = new();
    endfunction
    function void write(usb2_obs o);
      if (o.ls != o.ls_next) begin from_s = o.ls; to_s = o.ls_next; cg_link.sample(); end
      if (o.tx_valid) begin
        sp = after_split; tok = last_tok; ans = o.tx_pid[3:0]; ep = last_ep; cg_ans.sample();
      end
      if (o.rx_valid && o.rx_pid[7:4] == ~o.rx_pid[3:0]) begin
        if (o.rx_pid[3:0] inside {P_OUT, P_IN, P_SETUP, P_PING}) begin
          last_tok = o.rx_pid[3:0]; last_ep = o.rx_endp; after_split = last_split;
        end
        last_split = o.rx_pid[3:0] == P_SPLIT;
        if (o.rx_pid[3:0] == P_DATA0 && o.rx_len == 8 && last_tok == P_SETUP && !after_split) begin
          req = o.rx_data[15:8]; cg_req.sample();
        end
      end
      if (!first) foreach (o.cnt[i]) if (o.cnt[i] != prev[i]) begin ev = i; cg_ev.sample(); end
      if (o.uframe == 7) begin ev = 20; cg_ev.sample(); end
      if (o.dev_state == D_CONFIGURED) begin ev = o.hs ? 21 : 23; cg_ev.sample(); end
      if (o.ep_halt != 0) begin ev = 22; cg_ev.sample(); end
      first = 0;
      prev = o.cnt;
    endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("USB2_COV", $sformatf("link %0.1f%%  answers %0.1f%%  requests %0.1f%%  events %0.1f%%",
                cg_link.get_coverage(), cg_ans.get_coverage(), cg_req.get_coverage(), cg_ev.get_coverage()), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ sequences
  class usb2_base_seq extends uvm_sequence #(usb2_item);
    `uvm_object_utils(usb2_base_seq)
    virtual usb2_link_if vif;
    bit          h_tog;          // host view of the EP1 OUT toggle
    logic [10:0] h_fr;
    logic [2:0]  h_uf;
    function new(string name = "usb2_base_seq"); super.new(name); endfunction
    task pre_body();
      if (vif == null) void'(uvm_config_db#(virtual usb2_link_if)::get(null, "*", "usb2l_vif", vif));
    endtask
    task send(usb2_item t); start_item(t); finish_item(t); endtask
    task idle(int n);
      usb2_item t = usb2_item::type_id::create("t");
      t.kind = K_IDLE; t.n = n; send(t);
    endtask
    task line(logic [1:0] l);
      usb2_item t = usb2_item::type_id::create("t");
      t.kind = K_LINE; t.lvl = l; send(t);
    endtask
    task cap(bit v);
      usb2_item t = usb2_item::type_id::create("t");
      t.kind = K_CAP; t.lvl = {1'b0, v}; send(t);
    endtask
    task app(u2_kind_e k, logic [9:0] len = 0);
      usb2_item t = usb2_item::type_id::create("t");
      t.kind = k; t.len = len; send(t);
    endtask
    task pkt(logic [3:0] p, logic [6:0] a = 0, logic [3:0] e = 0, logic [9:0] len = 0, logic [31:0] d = 0,
             bit ok = 1, bit bad_pid = 0);
      usb2_item t = usb2_item::type_id::create("t");
      t.kind = K_PKT; t.pid = p; t.addr = a; t.endp = e; t.len = len; t.data = d; t.crc_ok = ok; t.bad_pid = bad_pid;
      send(t);
    endtask
    function bit got(logic [3:0] p);
      return vif.tx_valid === 1'b1 && vif.tx_pid[3:0] === p;
    endfunction
    function logic [6:0] me();
      return vif.dev_addr;
    endfunction
    task sof_next(bit skip = 0);
      if (vif.hs && h_uf != 7 && !skip) h_uf++;
      else begin h_fr = h_fr + (skip ? 11'd3 : 11'd1); h_uf = 0; end
      pkt(P_SOF, h_fr[6:0], h_fr[10:7]);
    endtask

    // bus reset; go_hs answers the device chirp with 3 K-J pairs (bad: 1-clock levels)
    task reset_bus(bit go_hs, bit bad = 0);
      bit was_hs;
      was_hs = vif.ls == L_HS;
      line(LN_SE0);
      idle(was_hs ? T_IDLE + 1 : T_RST + 1);
      if (vif.ls == L_CHIRP || vif.ls == L_CHWAIT) begin
        while (vif.ls != L_CHWAIT) idle(1);
        if (go_hs) begin
          for (int i = 0; i < 3; i++) begin
            line(LN_K); idle(bad ? 1 : 2); line(LN_J); idle(bad ? 1 : 2);
          end
          line(LN_SE0);
        end
        while (vif.ls == L_CHWAIT) idle(1);
      end
      if (vif.ls == L_FS) line(LN_J);
      idle(1);
      h_tog = 0;
    endtask

    // control transfer; drop_ack skips the first host ACK of the status / data stage
    task ctl(logic [7:0] t, logic [7:0] r, logic [7:0] v, logic [7:0] x, bit drop_ack = 0);
      logic [6:0] a;
      a = me();
      pkt(P_SETUP, a, 0);
      pkt(P_DATA0, 0, 0, 8, {x, v, r, t});
      if (!got(P_ACK)) return;
      pkt(P_IN, a, 0);
      if (got(P_DATA1)) begin
        if (drop_ack) begin
          idle($urandom_range(1, 18));
          pkt(P_IN, a, 0);
        end
        if (got(P_DATA1)) begin
          if (vif.tx_len == 0) begin pkt(P_ACK); return; end
          pkt(P_ACK);
          if ($urandom_range(0, 7) == 0) pkt(P_OUT, a, 0, 0, 0, 1) ;
          if ($urandom_range(0, 7) == 0) pkt(P_DATA0, 0, 0, 0, 0);
          pkt(P_OUT, a, 0);
          pkt(P_DATA1, 0, 0, 0, 0);
        end
      end
    endtask
    task enumerate(logic [6:0] a);
      ctl(8'h00, 8'h05, {1'b0, a}, 8'h00);
      ctl(8'h00, 8'h09, 8'h01, 8'h00);
      h_tog = 0;
    endtask
    task ensure_active();
      if (vif.ls == L_SUSP) begin
        line(LN_K); idle($urandom_range(4, 6)); line(LN_J); idle(1);
        if (vif.ls == L_HS) line(LN_SE0);
      end
      if (vif.ls == L_CHIRP || vif.ls == L_CHWAIT) begin
        while (vif.ls != L_CHWAIT) idle(1);
        for (int i = 0; i < 3; i++) begin line(LN_K); idle(2); line(LN_J); idle(2); end
        line(LN_SE0); idle(1);
      end
      if (vif.ls == L_FS) line(LN_J);
      if (vif.dev_state != D_CONFIGURED) enumerate(7'($urandom_range(1, 127)));
    endtask

    task bulk_out(int n);
      bit dflt;
      for (int i = 0; i < n; i++) begin
        if (vif.hs && $urandom_range(0, 2) == 0) pkt(P_PING, me(), 1);
        if (got(P_NAK)) begin app(K_APP_RD); continue; end
        pkt(P_OUT, me(), 1);
        dflt = 0;
        case ($urandom_range(0, 19))
          0: pkt(P_DATA0 ^ {~h_tog, 3'b000}, 0, 0, 10'($urandom_range(0, 64)), $urandom(), 0);        // bad CRC16
          1: pkt(P_DATA0 ^ {h_tog, 3'b000}, 0, 0, vif.hs ? 10'd513 : 10'd65, $urandom());              // babble
          2: pkt(P_DATA0 ^ {~h_tog, 3'b000}, 0, 0, 10'($urandom_range(0, 64)), $urandom());           // duplicate
          3: pkt(P_DATA2, 0, 0, 10'd8, $urandom());
          4: idle(17);                                                                                   // no data
          default: begin
            pkt(h_tog ? P_DATA1 : P_DATA0, 0, 0, 10'($urandom_range(0, vif.hs ? 512 : 64)), $urandom());
            dflt = 1;
          end
        endcase
        // the host flips its toggle on every ACK / NYET of a normal packet; a duplicate ACK
        // (device already had it) resynchronises a host that lost track
        if (dflt && (got(P_ACK) || got(P_NYET))) h_tog = ~h_tog;
        if ($urandom_range(0, 2) == 0) app(K_APP_RD);
      end
    endtask
    task bulk_in(int n, logic [3:0] e = 2);
      for (int i = 0; i < n; i++) begin
        if ($urandom_range(0, 2) == 0) begin
          if (e == 2) app(K_APP_WR, 10'($urandom_range(0, 700))); else app(K_APP_IRQ);
        end
        pkt(P_IN, me(), e);
        if (got(P_DATA0) || got(P_DATA1)) begin
          case ($urandom_range(0, 9))
            0: idle($urandom_range(1, 18));
            1: pkt(P_NAK);
            2: pkt(P_IN, me(), e);
            default: pkt(P_ACK);
          endcase
        end
      end
    endtask
    task split(int n);
      logic [6:0] da;
      logic [3:0] de;
      bit in;
      for (int i = 0; i < n; i++) begin
        da = 7'($urandom_range(1, 4)); de = 4'($urandom_range(0, 2)); in = $urandom_range(0, 1);
        // start
        pkt(P_SPLIT, ($urandom_range(0, 9) == 0) ? 7'(me() + 1) : me(), {1'b0, 3'($urandom_range(1, 7))});
        if ($urandom_range(0, 9) == 0) idle(4);
        if (in) pkt(P_IN, da, de, 0, 0, $urandom_range(0, 9) != 0);
        else begin
          pkt(($urandom_range(0, 3) == 0) ? P_SETUP : P_OUT, da, de);
          pkt(P_DATA0, 0, 0, ($urandom_range(0, 9) == 0) ? 10'd65 : 10'($urandom_range(0, 64)), $urandom(),
              $urandom_range(0, 9) != 0);
        end
        // complete, possibly early, possibly for the wrong endpoint
        for (int k = 0; k < 4; k++) begin
          idle($urandom_range(1, 5));
          pkt(P_SPLIT, me(), {1'b1, 3'd1});
          pkt(in ? P_IN : P_OUT, da, ($urandom_range(0, 7) == 0) ? 4'(de + 1) : de);
          if (!got(P_NYET)) break;
        end
      end
    endtask
    task suspend_resume();
      line(LN_J);
      idle(T_IDLE + $urandom_range(0, 6));
      if ($urandom_range(0, 3) == 0) begin line(LN_K); idle($urandom_range(1, 3)); line(LN_J); idle(2); end
      line(LN_K); idle($urandom_range(4, 8)); line(LN_J); idle(1);
      if (vif.ls == L_HS) line(LN_SE0);
    endtask
    task errors();
      case ($urandom_range(0, 5))
        0: pkt(4'($urandom()), me(), 4'($urandom()), 0, 0, 1, 1);                     // PID check error
        1: pkt(P_IN, me(), 4'($urandom_range(0, 3)), 0, 0, 0);                       // CRC5
        2: pkt(P_IN, 7'(me() + 1), 4'($urandom_range(0, 3)));                        // other device
        3: pkt(P_IN, me(), 4'($urandom_range(4, 15)));                               // no such endpoint
        4: begin pkt(P_OUT, me(), 2); pkt(P_DATA0, 0, 0, 4, 0); end                  // OUT to an IN endpoint
        default: begin pkt(P_OUT, me(), 1); pkt(P_SETUP, me(), 0); pkt(P_DATA0, 0, 0, 8, 32'h0000_0080); end
      endcase
    endtask
    task requests();
      case ($urandom_range(0, 9))
        0: ctl(8'h80, 8'h00, 8'h00, 8'h00, $urandom_range(0, 1));
        1: ctl(8'h82, 8'h00, 8'h00, 8'($urandom_range(0, 3)) | ($urandom_range(0, 1) ? 8'h80 : 8'h00));
        2: ctl(8'h02, 8'h03, 8'h00, 8'($urandom_range(0, 3)) | 8'h80, $urandom_range(0, 1));
        3: ctl(8'h02, 8'h01, 8'h00, 8'($urandom_range(0, 3)));
        4: ctl(8'h80, 8'h06, 8'h01, 8'h00);
        5: ctl(8'h00, 8'h09, 8'($urandom_range(0, 2)), 8'h00, $urandom_range(0, 1));
        6: ctl(8'h00, 8'h05, 8'($urandom_range(0, 127)), 8'h00);
        7: begin pkt(P_IN, me(), 0); pkt(P_OUT, me(), 0); pkt(P_DATA1, 0, 0, 0, 0); end
        8: ctl(8'h02, 8'h03, 8'h01, 8'h01);
        default: begin pkt(P_SETUP, me(), 0); pkt(P_DATA1, 0, 0, 8, 0); pkt(P_SETUP, me(), 0); pkt(P_DATA0, 0, 0, 7, 0); end
      endcase
    endtask
  endclass

  class usb2_regression_seq extends usb2_base_seq;
    `uvm_object_utils(usb2_regression_seq)
    int n_iter = 1500;
    function new(string name = "usb2_regression_seq"); super.new(name); endfunction
    task body();
      idle(3);
      // FS device first
      cap(0);
      reset_bus(0);
      enumerate(7'h11);
      for (int i = 0; i < 6; i++) begin sof_next(i == 3); bulk_out(2); bulk_in(2); end
      pkt(P_SPLIT, me(), 4'h1); pkt(P_IN, 7'h3, 4'h1);      // SPLIT at FS
      pkt(P_PING, me(), 1);                                   // PING at FS
      suspend_resume();
      cap(1);
      reset_bus(1, 1);                                        // bad chirp -> FS
      line(LN_J); idle(2);
      reset_bus(0);                                           // no chirp answer -> FS
      line(LN_J); idle(2);
      reset_bus(1);
      for (int i = 0; i < n_iter; i++) begin
        ensure_active();
        case ($urandom_range(0, 19))
          0, 1, 2: bulk_out($urandom_range(1, 6));
          3, 4, 5: bulk_in($urandom_range(1, 6));
          6, 7: bulk_in($urandom_range(1, 4), 3);
          8, 9: split($urandom_range(1, 3));
          10, 11: requests();
          12: repeat ($urandom_range(1, 10)) sof_next($urandom_range(0, 15) == 0);
          13: begin repeat (9) pkt(P_SOF, h_fr[6:0], h_fr[10:7]); h_uf = 7; end
          14: errors();
          15: if ($urandom_range(0, 2) == 0) suspend_resume();
          16: if ($urandom_range(0, 3) == 0) begin
                if (vif.ls == L_FS) line(LN_J);
                if (vif.ls == L_HS && $urandom_range(0, 1)) begin line(LN_SE0); idle(T_IDLE + 2); end
                else reset_bus($urandom_range(0, 3) != 0, $urandom_range(0, 5) == 0);
              end
          17: if ($urandom_range(0, 3) == 0) begin
                // suspend then reset from suspend
                line(LN_J); idle(T_IDLE + 1); line(LN_SE0); idle(18);
              end
          18: if ($urandom_range(0, 5) == 0) begin cap(0); reset_bus(0); cap(1); end
          default: repeat ($urandom_range(1, 6)) app(K_APP_RD);
        endcase
        idle($urandom_range(1, 6));
        if (vif.ls == L_HS || vif.ls == L_FS) sof_next();
      end
      idle(30);
    endtask
  endclass

  // ------------------------------------------------------------ env / test
  class usb2_env extends uvm_env;
    `uvm_component_utils(usb2_env)
    usb2_sequencer  sqr;
    usb2_driver     drv;
    usb2_monitor    mon;
    usb2_scoreboard sb;
    usb2_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      sqr = usb2_sequencer::type_id::create("sqr", this);
      drv = usb2_driver::type_id::create("drv", this);
      mon = usb2_monitor::type_id::create("mon", this);
      sb  = usb2_scoreboard::type_id::create("sb", this);
      cov = usb2_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(sb.analysis_export);
      mon.ap.connect(cov.analysis_export);
    endfunction
  endclass

  class usb2_link_test extends uvm_test;
    `uvm_component_utils(usb2_link_test)
    usb2_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      env = usb2_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      usb2_regression_seq s = usb2_regression_seq::type_id::create("s");
      phase.raise_objection(this);
      s.start(env.sqr);
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0 &&
          env.sb.n_data > 200 && env.sb.n_ctl > 30 && env.sb.n_split > 20 && env.sb.n_chirp > 5)
        $display("SB_PASS checks=%0d", env.sb.n_checks);
      else `uvm_error("TEST", "USB2_LINK_TEST FAILED")
    endfunction
  endclass
endpackage

`endif
