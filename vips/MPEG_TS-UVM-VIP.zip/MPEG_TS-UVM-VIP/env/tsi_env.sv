// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_env.sv -- TSI environment: reference-model scoreboard, checker, coverage

package tsi_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import tsi_defs_pkg::*;
  import tsi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class tsi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(tsi_scoreboard)
    uvm_analysis_imp_exp #(tsi_transaction, tsi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(tsi_transaction, tsi_scoreboard) obs_ap;

    tsi_config cfg;
    tsi_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [3:0] last [4];
    bit       seen [4] = '{0, 0, 0, 0};

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(tsi_config)::get(this, "", "cfg", cfg))
        cfg = tsi_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(tsi_transaction t);
      int n = t.pkt.size(), s, L = 0, p0;
      bit [12:0] pid;
      bit [1:0] afc;
      bit [3:0] c;
      bit di = 0;
      t.odata.delete();
      t.rpid = 0; t.rcc = 0;
      if (n != 188 || t.pkt[0] != 8'h47) begin t.rstatus = 5; return; end
      pid = {t.pkt[1][4:0], t.pkt[2]};
      c = t.pkt[3][3:0]; afc = t.pkt[3][5:4];
      t.rpid = pid; t.rcc = c;
      if (t.pkt[1][7] || t.terr) begin t.rstatus = 4; return; end
      s = tsi_slot(pid);
      if (s < 0) begin t.rstatus = 1; return; end
      if (afc[1]) begin L = t.pkt[4]; if (L > 0) di = t.pkt[5][7]; end
      if (afc == 2'b00 || (afc == 2'b10 && L != 183) || (afc == 2'b11 && L > 182)) begin t.rstatus = 6; return; end
      if (afc == 2'b10) begin t.rstatus = 0; return; end
      p0 = afc[1] ? 5 + L : 4;
      if (!seen[s] || di || c == last[s] + 4'd1) t.rstatus = 0;
      else if (c == last[s]) begin t.rstatus = 3; return; end
      else t.rstatus = 2;
      seen[s] = 1; last[s] = c;
      for (int i = p0; i < 188; i++) t.odata.push_back(t.pkt[i]);
    endfunction

    function void write_exp(tsi_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(tsi_transaction t);
      tsi_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        tsi_transaction e = exp_q.pop_front();
        tsi_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("tsi scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class tsi_env extends uvm_env;
    `uvm_component_utils(tsi_env)
    tsi_agent      agt;
    tsi_scoreboard sb;
    tsi_checker    chk;
    tsi_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = tsi_agent     ::type_id::create("agt", this);
      sb  = tsi_scoreboard::type_id::create("sb",  this);
      chk = tsi_checker   ::type_id::create("chk", this);
      cov = tsi_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
