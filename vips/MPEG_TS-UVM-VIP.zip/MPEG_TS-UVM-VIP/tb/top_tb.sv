// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- TSI testbench top with a functional TSI DUT model

`ifndef MPEG_TS_UVM_VIP_TB_SV
`define MPEG_TS_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import tsi_defs_pkg::*;
import tsi_pkg::*;
import tsi_env_pkg::*;
import tsi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  tsi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  tsi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .ts_valid(vif.ts_valid),
    .ts_sync(vif.ts_sync),
    .ts_data(vif.ts_data),
    .ts_err(vif.ts_err),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data),
    .out_last(vif.out_last),
    .rep_valid(vif.rep_valid),
    .rep_pid(vif.rep_pid),
    .rep_cc(vif.rep_cc),
    .rep_status(vif.rep_status)
  );

  // Concurrent protocol checks
  tsi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .ts_valid(vif.ts_valid),
    .ts_sync(vif.ts_sync),
    .ts_data(vif.ts_data),
    .ts_err(vif.ts_err),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data),
    .out_last(vif.out_last),
    .rep_valid(vif.rep_valid),
    .rep_pid(vif.rep_pid),
    .rep_cc(vif.rep_cc),
    .rep_status(vif.rep_status)
  );

  initial begin
    uvm_config_db#(virtual tsi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module tsi_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        ts_valid,
  input  logic        ts_sync,
  input  logic [7:0]  ts_data,
  input  logic        ts_err,
  output logic        out_valid,
  output logic [7:0]  out_data,
  output logic        out_last,
  output logic        rep_valid,
  output logic [12:0] rep_pid,
  output logic [3:0]  rep_cc,
  output logic [2:0]  rep_status
);
  function automatic integer slot(input logic [12:0] pid);
    case (pid)
      13'h0000: slot = 0;
      13'h0100: slot = 1;
      13'h0101: slot = 2;
      13'h0111: slot = 3;
      default:  slot = -1;
    endcase
  endfunction

  logic [7:0]  rb [0:187];
  logic [7:0]  cnt, opos;
  logic        go, busy, perr;
  logic [6:0]  idle;
  logic [3:0]  last [0:3];
  logic [3:0]  seen;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cnt <= '0; opos <= '0; go <= 1'b0; busy <= 1'b0; perr <= 1'b0; idle <= '0; seen <= '0;
      for (int i = 0; i < 4; i++) last[i] <= 4'h0;
      out_valid <= 1'b0; out_data <= '0; out_last <= 1'b0;
      rep_valid <= 1'b0; rep_pid <= '0; rep_cc <= '0; rep_status <= '0;
    end else begin
      rep_valid <= 1'b0; out_valid <= 1'b0; out_last <= 1'b0;
      go <= 1'b0;
      if (ts_valid) begin
        idle <= '0;
        if (ts_sync) begin
          if (cnt != 8'd0) begin rep_valid <= 1'b1; rep_status <= 3'd5; rep_pid <= '0; rep_cc <= '0; end
          rb[0] <= ts_data; cnt <= 8'd1; perr <= ts_err;
        end else if (cnt != 8'd0) begin
          rb[cnt] <= ts_data;
          if (ts_err) perr <= 1'b1;
          if (cnt == 8'd187) begin cnt <= '0; go <= 1'b1; end
          else cnt <= cnt + 8'd1;
        end
      end else if (cnt != 8'd0) begin
        idle <= idle + 7'd1;
        if (idle == 7'd63) begin
          cnt <= '0; rep_valid <= 1'b1; rep_status <= 3'd5; rep_pid <= '0; rep_cc <= '0;
        end
      end
      if (go) begin : packet
        logic [12:0] pid;
        logic [1:0]  afc;
        logic [3:0]  c;
        logic [7:0]  L;
        logic        di, pay;
        logic [2:0]  rs;
        integer      s;
        pid = {rb[1][4:0], rb[2]}; afc = rb[3][5:4]; c = rb[3][3:0];
        L = afc[1] ? rb[4] : 8'd0;
        di = afc[1] && L != 8'd0 && rb[5][7];
        s = slot(pid);
        pay = 1'b0;
        rep_pid <= pid; rep_cc <= c;
        if (rb[0] != 8'h47) begin rs = 3'd5; rep_pid <= '0; rep_cc <= '0; end
        else if (rb[1][7] || perr) rs = 3'd4;
        else if (s < 0) rs = 3'd1;
        else if (afc == 2'b00 || (afc == 2'b10 && L != 8'd183) || (afc == 2'b11 && L > 8'd182)) rs = 3'd6;
        else if (afc == 2'b10) rs = 3'd0;
        else if (!seen[s] || di || c == last[s] + 4'd1) begin rs = 3'd0; pay = 1'b1; end
        else if (c == last[s]) rs = 3'd3;
        else begin rs = 3'd2; pay = 1'b1; end
        rep_status <= rs;
        if (pay) begin
          seen[s] <= 1'b1; last[s] <= c;
          opos <= afc[1] ? 8'd5 + L : 8'd4; busy <= 1'b1;
        end else rep_valid <= 1'b1;
      end
      if (busy) begin
        out_valid <= 1'b1;
        out_data <= rb[opos];
        opos <= opos + 8'd1;
        if (opos == 8'd187) begin out_last <= 1'b1; busy <= 1'b0; rep_valid <= 1'b1; end
      end
    end
  end
endmodule
`endif
