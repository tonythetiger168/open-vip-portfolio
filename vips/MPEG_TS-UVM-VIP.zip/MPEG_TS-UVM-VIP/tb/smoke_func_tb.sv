// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (TSI DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened tsi_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic ts_valid = 1'b0, ts_sync = 1'b0, ts_err = 1'b0;
  logic [7:0] ts_data = 8'h00;
  wire out_valid, out_last, rep_valid;
  wire [7:0] out_data;
  wire [12:0] rep_pid;
  wire [3:0] rep_cc;
  wire [2:0] rep_status;

  always #5 clk = ~clk;

  tsi_model u_dut (.clk(clk), .rst_n(rst_n), .ts_valid(ts_valid), .ts_sync(ts_sync), .ts_data(ts_data),
                   .ts_err(ts_err), .out_valid(out_valid), .out_data(out_data), .out_last(out_last),
                   .rep_valid(rep_valid), .rep_pid(rep_pid), .rep_cc(rep_cc), .rep_status(rep_status));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic [7:0] pb [0:187];
  integer p0;
  // packet: pid, cc, afc, adaptation length L (or -1), discontinuity, payload from v0
  task automatic build(input logic [12:0] pid, input logic [3:0] cc, input logic [1:0] afc = 2'b01,
                       input integer L = -1, input logic di = 0, input logic [7:0] v0 = 8'h10);
    integer n;
    pb[0] = 8'h47; pb[1] = {3'b010, pid[12:8]}; pb[2] = pid[7:0]; pb[3] = {2'b00, afc, cc};
    n = 4;
    if (L >= 0) begin
      pb[4] = L; n = 5;
      if (L > 0) begin pb[5] = {di, 7'h00}; n = 6; end
      for (int i = 0; i < 188; i++) if (i >= n && i < 5 + L) pb[i] = 8'hFF;
      n = 5 + L;
    end
    p0 = n;
    for (int i = 0; i < 188; i++) if (i >= n) pb[i] = v0 + 8'd7 * i;
  endtask

  logic [7:0] ob [0:187];
  integer on = 0, nrep = 0;
  logic [12:0] r_pid;
  logic [3:0] r_cc;
  logic [2:0] r_st;
  always @(posedge clk) begin
    if (out_valid) begin ob[on] = out_data; on = on + 1; end
    if (rep_valid) begin nrep = nrep + 1; r_pid = rep_pid; r_cc = rep_cc; r_st = rep_status; end
  end
  task automatic send(input integer len = 188, input integer errb = -1, input integer gap = 0);
    integer r0, k;
    r0 = nrep; on = 0;
    for (int i = 0; i < 188; i++)
      if (i < len) begin
        if (gap != 0 && i % gap == 1) begin @(negedge clk); ts_valid = 0; ts_sync = 0; ts_err = 0; @(negedge clk); end
        @(negedge clk); ts_valid = 1; ts_sync = (i == 0); ts_data = pb[i]; ts_err = (i == errb);
      end
    @(negedge clk); ts_valid = 0; ts_sync = 0; ts_err = 0;
    k = 0;
    while (k < 400 && nrep == r0) begin @(negedge clk); k = k + 1; end
    @(negedge clk);
  endtask
  function automatic logic got(input logic [2:0] st, input logic [12:0] pid, input logic [3:0] cc);
    got = r_st == st && r_pid == pid && r_cc == cc;
  endfunction
  function automatic logic delivered();
    logic ok;
    ok = (on == 188 - p0);
    for (int i = 0; i < 188; i++) if (i < 188 - p0 && ob[i] !== pb[p0 + i]) ok = 0;
    delivered = ok;
  endfunction

  initial begin
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0 && out_valid === 1'b0, "nothing out in reset");
    rst_n = 1;
    repeat (4) @(negedge clk);
    build(13'h0000, 4'd5); send(); chk(got(0, 0, 5) && delivered() && on == 184, "PAT, first packet: any CC, 184 bytes");
    build(13'h0000, 4'd6); send(188, -1, 3); chk(got(0, 0, 6) && delivered(), "CC + 1 with ts_valid gaps");
    build(13'h0100, 4'd0, 2'b11, 0); send(); chk(got(0, 13'h100, 0) && on == 183, "adaptation length 0");
    build(13'h0100, 4'd1, 2'b11, 182); send(); chk(got(0, 13'h100, 1) && on == 1 && delivered(), "adaptation length 182");
    build(13'h0100, 4'd1); send(); chk(got(3, 13'h100, 1) && on == 0, "same CC: duplicate dropped");
    build(13'h0100, 4'd2); send(); chk(got(0, 13'h100, 2) && delivered(), "then CC + 1");
    build(13'h0100, 4'd9); send(); chk(got(2, 13'h100, 9) && delivered(), "CC 9 after 2: discontinuity, delivered");
    build(13'h0100, 4'd10); send(); chk(got(0, 13'h100, 10), "tracking restarted at 9");
    build(13'h0100, 4'd3, 2'b11, 7, 1); send(); chk(got(0, 13'h100, 3) && delivered(), "discontinuity_indicator: any CC");
    build(13'h0100, 4'd3, 2'b10, 183); send(); chk(got(0, 13'h100, 3) && on == 0, "adaptation only: no payload");
    build(13'h0100, 4'd4, 2'b10, 100); send(); chk(got(6, 13'h100, 4), "control 10 with length 100");
    build(13'h0100, 4'd4, 2'b11, 183); send(); chk(got(6, 13'h100, 4), "control 11 with length 183");
    build(13'h0100, 4'd4, 2'b00); send(); chk(got(6, 13'h100, 4), "control 00");
    build(13'h0101, 4'd0); pb[1][7] = 1; send(); chk(got(4, 13'h101, 0) && on == 0, "TEI set: dropped");
    build(13'h0101, 4'd0); send(188, 77); chk(got(4, 13'h101, 0) && on == 0, "ts_err on byte 77: dropped");
    build(13'h0101, 4'd0); pb[0] = 8'h46; send(); chk(got(5, 0, 0), "sync byte 0x46");
    build(13'h0101, 4'd0); send(100); chk(got(5, 0, 0) && on == 0, "cut after 100 bytes: timeout");
    build(13'h1FFF, 4'd0); send(); chk(got(1, 13'h1FFF, 0) && on == 0, "null packet");
    build(13'h0102, 4'd0); send(); chk(got(1, 13'h102, 0), "PID not filtered");
    build(13'h0101, 4'd0); send(); chk(got(0, 13'h101, 0) && delivered(), "PID 0x101 first packet after the faults");
    build(13'h0111, 4'd15); send(); chk(got(0, 13'h111, 15), "PID 0x111 CC 15");
    build(13'h0111, 4'd0); send(); chk(got(0, 13'h111, 0), "CC wraps 15 -> 0");
    // sync in the middle of a packet: the partial one is reported, the new one received
    build(13'h0000, 4'd7); send(50); chk(got(5, 0, 0), "50-byte packet");
    build(13'h0000, 4'd7); send(); chk(got(0, 0, 7) && delivered(), "PAT CC 7");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
