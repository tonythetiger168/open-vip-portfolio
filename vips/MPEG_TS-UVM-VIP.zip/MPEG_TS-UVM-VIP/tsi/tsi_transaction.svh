// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_transaction.svh -- TSI transaction

class tsi_transaction extends uvm_sequence_item;
  `uvm_object_utils(tsi_transaction)

  // request (driven by the agent)
  bit [7:0] pkt[$];
  bit terr;
  // response (returned by the DUT)
  bit [12:0] rpid;
  bit [3:0] rcc;
  bit [2:0] rstatus;
  bit [7:0] odata[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [1:0] sel;
  rand bit [7:0] aflen;
  rand bit pusi;
  rand bit [31:0] seed;
  bit [3:0] cc;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "tsi_transaction"); super.new(name); endfunction

  // kind: 0-11 payload in order (control 01 / 11 from aflen[0]), 12 duplicate CC,
  // 13 CC gap, 14 CC gap with discontinuity_indicator, 15 PID not filtered, 16 null
  // packet, 17 TEI, 18 ts_err, 19 sync byte 0x46, 20 cut after 100 bytes,
  // 21 adaptation field only, 22 control 11 with length 183, 23 control 00, 24-31 in order
  function void set(int k, int s, bit [7:0] af = 8'h01); kind = k; sel = s; aflen = af; endfunction
  function bit [12:0] pid_of();
    if (kind == 15) return 13'h0200 + seed[7:0];
    if (kind == 16) return 13'h1FFF;
    return tsi_pid(sel);
  endfunction
  function void build(bit [3:0] c);
    bit [31:0] x = seed | 1;
    bit [1:0] afc;
    int L = -1;
    bit [12:0] pid = pid_of();
    cc = c;
    afc = aflen[0] ? 2'b01 : 2'b11;
    if (kind == 21) afc = 2'b10;
    if (kind == 22 || kind == 14) afc = 2'b11;
    if (kind == 23) afc = 2'b00;
    if (afc[1]) L = (kind == 21 || kind == 22) ? 183 : (kind == 14) ? 1 + aflen % 182 : aflen % 183;
    pkt.delete();
    terr = (kind == 18);
    pkt.push_back((kind == 19) ? 8'h46 : 8'h47);
    pkt.push_back({kind == 17, pusi, 1'b0, pid[12:8]});
    pkt.push_back(pid[7:0]);
    pkt.push_back({2'b00, afc, c});
    if (L >= 0) begin
      pkt.push_back(L[7:0]);
      if (L > 0) pkt.push_back({kind == 14, 7'h00});
      while (pkt.size() < 5 + L) pkt.push_back(8'hFF);
    end
    while (pkt.size() < 188) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      pkt.push_back(x[7:0]);
    end
    if (kind == 20) while (pkt.size() > 100) void'(pkt.pop_back());
  endfunction

  function void do_copy(uvm_object rhs);
    tsi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    pkt = rhs_.pkt;
    terr = rhs_.terr;
    rpid = rhs_.rpid;
    rcc = rhs_.rcc;
    rstatus = rhs_.rstatus;
    odata = rhs_.odata;
    kind = rhs_.kind;
    sel = rhs_.sel;
    aflen = rhs_.aflen;
    pusi = rhs_.pusi;
    seed = rhs_.seed;
    cc = rhs_.cc;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    tsi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (pkt.size() != rhs_.pkt.size()) return 0;
    foreach (pkt[i]) if (pkt[i] != rhs_.pkt[i]) return 0;
    if (terr != rhs_.terr) return 0;
    if (rpid != rhs_.rpid) return 0;
    if (rcc != rhs_.rcc) return 0;
    if (rstatus != rhs_.rstatus) return 0;
    if (odata.size() != rhs_.odata.size()) return 0;
    foreach (odata[i]) if (odata[i] != rhs_.odata[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(tsi_transaction rhs_);
    if (pkt.size() != rhs_.pkt.size()) return 0;
    foreach (pkt[i]) if (pkt[i] != rhs_.pkt[i]) return 0;
    if (terr != rhs_.terr) return 0;
    return 1;
  endfunction

  function string qstr_pkt();
    string s = $sformatf("[%0d]{", pkt.size());
    foreach (pkt[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", pkt[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_odata();
    string s = $sformatf("[%0d]{", odata.size());
    foreach (odata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", odata[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("TSI{tag=%0d pkt=%s terr=0x%0h rpid=0x%0h rcc=0x%0h rstatus=0x%0h odata=%s}", tag, qstr_pkt(), terr, rpid, rcc, rstatus, qstr_odata());
  endfunction
endclass
