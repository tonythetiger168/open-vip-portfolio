// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_monitor.svh -- TSI monitor: bytes from each ts_sync, the payload and the report that closes the packet

class tsi_monitor extends uvm_monitor;
  `uvm_component_utils(tsi_monitor)

  virtual tsi_if vif;
  uvm_analysis_port #(tsi_transaction) ap;
  tsi_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual tsi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tsi: virtual interface not set")
    if (!uvm_config_db#(tsi_config)::get(this, "", "cfg", cfg))
      cfg = tsi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] b[$], o[$];
      bit e = 0;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.ts_valid) begin
          if (vif.mon_cb.ts_sync) begin b.delete(); e = 0; end
          b.push_back(vif.mon_cb.ts_data);
          if (vif.mon_cb.ts_err) e = 1;
        end
        if (vif.mon_cb.out_valid) o.push_back(vif.mon_cb.out_data);
        if (vif.mon_cb.rep_valid) begin
          tsi_transaction t = tsi_transaction::type_id::create("t");
          t.pkt = b; t.terr = e; t.odata = o;
          t.rpid = vif.mon_cb.rep_pid; t.rcc = vif.mon_cb.rep_cc; t.rstatus = vif.mon_cb.rep_status;
          publish(t);
          b.delete(); o.delete(); e = 0;
        end
      end
    end
  endtask

  function void publish(tsi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
