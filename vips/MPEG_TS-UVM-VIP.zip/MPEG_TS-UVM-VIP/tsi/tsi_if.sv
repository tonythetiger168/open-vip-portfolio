// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_if.sv -- TSI interface

interface tsi_if (input logic clk);
  logic rst_n;

  logic ts_valid;
  logic ts_sync;
  logic [7:0] ts_data;
  logic ts_err;
  logic out_valid;
  logic [7:0] out_data;
  logic out_last;
  logic rep_valid;
  logic [12:0] rep_pid;
  logic [3:0] rep_cc;
  logic [2:0] rep_status;

  modport DUT (input clk, rst_n, input ts_valid, input ts_sync, input ts_data, input ts_err, output out_valid, output out_data, output out_last, output rep_valid, output rep_pid, output rep_cc, output rep_status);
  modport MON (input clk, rst_n, ts_valid, ts_sync, ts_data, ts_err, out_valid, out_data, out_last, rep_valid, rep_pid, rep_cc, rep_status);

  clocking drv_cb @(posedge clk);
    input rst_n, out_valid, out_data, out_last, rep_valid, rep_pid, rep_cc, rep_status;
    inout ts_valid, ts_sync, ts_data, ts_err;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, ts_valid, ts_sync, ts_data, ts_err, out_valid, out_data, out_last, rep_valid, rep_pid, rep_cc, rep_status;
  endclocking
endinterface
