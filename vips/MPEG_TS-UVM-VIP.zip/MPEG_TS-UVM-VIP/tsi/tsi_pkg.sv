// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_pkg.sv -- TSI UVM VIP package

package tsi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import tsi_defs_pkg::*;
  export tsi_defs_pkg::*;

  `include "tsi_transaction.svh"
  `include "tsi_config.svh"
  `include "tsi_sequencer.svh"
  `include "tsi_driver.svh"
  `include "tsi_monitor.svh"
  `include "tsi_agent.svh"
  `include "tsi_sequences.svh"
  `include "tsi_checker.svh"
  `include "tsi_coverage.svh"
endpackage
