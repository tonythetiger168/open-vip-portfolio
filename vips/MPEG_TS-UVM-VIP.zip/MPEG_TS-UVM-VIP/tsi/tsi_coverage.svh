// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_coverage.svh -- TSI functional coverage

class tsi_coverage extends uvm_subscriber #(tsi_transaction);
  `uvm_component_utils(tsi_coverage)
  tsi_config cfg;
  tsi_transaction tr;

  covergroup tsi_cg;
    cp_status : coverpoint tr.rstatus { bins ok = {0}; bins filtered = {1}; bins gap = {2}; bins dup = {3};
                                        bins tei = {4}; bins sync = {5}; bins af = {6}; }
    cp_pid    : coverpoint tr.rpid iff (tr.rstatus inside {0, 2}) { bins pat = {13'h0000}; bins v = {13'h0100};
                                                                   bins a = {13'h0101}; bins s = {13'h0111}; }
    cp_plen   : coverpoint tr.odata.size() iff (tr.rstatus inside {0, 2}) { bins none = {0}; bins one = {1};
                                                                           bins part = {[2:183]}; bins full = {184}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    tsi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(tsi_config)::get(this, "", "cfg", cfg))
      cfg = tsi_config::type_id::create("cfg");
  endfunction

  function void write(tsi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    tsi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("TSI coverage: %0.1f%%", tsi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
