// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_sequences.svh -- TSI sequences

// Random traffic: cfg.num_items constrained-random items.
class tsi_base_sequence extends uvm_sequence #(tsi_transaction);
  `uvm_object_utils(tsi_base_sequence)
  tsi_config cfg;

  function new(string name = "tsi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = tsi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "tsi_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class tsi_directed_sequence extends uvm_sequence #(tsi_transaction);
  `uvm_object_utils(tsi_directed_sequence)
  tsi_config cfg;

  function new(string name = "tsi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function tsi_transaction item();
    item = tsi_transaction::type_id::create("req");
  endfunction

  task send(tsi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    tsi_transaction t;
    // in-order traffic on every PID, both adaptation forms and their limits, each fault
    for (int s = 0; s < 4; s++)
      for (int i = 0; i < 2; i++) begin t = item(); t.set(0, s, 8'h01 + 8'h10 * i); send(t); end
    t = item(); t.set(0, 1, 8'h00); t.aflen = 8'h00; send(t);          // control 11, length 0
    t = item(); t.set(0, 1, 8'd182); send(t);                          // control 11, length 182: 1 payload byte
    t = item(); t.set(12, 1); send(t);
    t = item(); t.set(13, 1); send(t);
    t = item(); t.set(0, 1); send(t);
    t = item(); t.set(14, 2, 8'd9); send(t);
    for (int k = 15; k < 24; k++) begin
      t = item(); t.set(k, 3, 8'd41); t.seed = 32'h1F00 + k; send(t);
      t = item(); t.set(0, 3); send(t);
    end
    for (int i = 0; i < 18; i++) begin t = item(); t.set(0, 0, i); t.seed = i; send(t); end   // CC wraps
  endtask
endclass
