// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_driver.svh -- TSI driver: one 188-byte packet per item with ts_sync on byte 0 and random ts_valid gaps, CC from a per-PID counter (duplicates and gaps planted); then the payload and the report

class tsi_driver extends uvm_driver #(tsi_transaction);
  `uvm_component_utils(tsi_driver)

  uvm_analysis_port #(tsi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual tsi_if vif;
  tsi_config cfg;

  bit [3:0] nxt [4] = '{0, 0, 0, 0};

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual tsi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tsi: virtual interface not set")
    if (!uvm_config_db#(tsi_config)::get(this, "", "cfg", cfg))
      cfg = tsi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    tsi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.ts_valid <= 1'b0;
    vif.drv_cb.ts_sync  <= 1'b0;
    vif.drv_cb.ts_data  <= 8'h00;
    vif.drv_cb.ts_err   <= 1'b0;
  endtask

  task drive_item(tsi_transaction t);
    bit [3:0] c = nxt[t.sel];
    bit [31:0] x = t.seed ^ 32'h9E37_79B9;
    int k = 0, ep = 4 + t.seed[6:0];
    if (t.kind == 12) c = nxt[t.sel] - 1;
    else if (t.kind inside {13, 14}) c = nxt[t.sel] + 1 + t.seed[1:0];
    else if (t.kind == 21) c = nxt[t.sel] - 1;
    t.build(c);
    if (t.kind inside {[0:11], 13, 14, [24:31]}) nxt[t.sel] = c + 1;
    @(vif.drv_cb);
    foreach (t.pkt[i]) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      if (x[2:0] == 0 && i != 0) begin
        vif.drv_cb.ts_valid <= 1'b0; vif.drv_cb.ts_sync <= 1'b0; vif.drv_cb.ts_err <= 1'b0;
        repeat (1 + x[4:3]) @(vif.drv_cb);
      end
      vif.drv_cb.ts_valid <= 1'b1; vif.drv_cb.ts_sync <= (i == 0); vif.drv_cb.ts_data <= t.pkt[i];
      vif.drv_cb.ts_err <= t.terr && (i == ep);
      @(vif.drv_cb);
    end
    vif.drv_cb.ts_valid <= 1'b0; vif.drv_cb.ts_sync <= 1'b0; vif.drv_cb.ts_err <= 1'b0;
    t.odata.delete();
    do begin
      @(vif.drv_cb);
      if (vif.drv_cb.out_valid) t.odata.push_back(vif.drv_cb.out_data);
      k++;
    end while (!vif.drv_cb.rep_valid && k < cfg.timeout_cycles);
    if (!vif.drv_cb.rep_valid) `uvm_error("DRV", "TSI: no report for a packet")
    t.rpid = vif.drv_cb.rep_pid; t.rcc = vif.drv_cb.rep_cc; t.rstatus = vif.drv_cb.rep_status;
    repeat (2) @(vif.drv_cb);
  endtask

endclass
