// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_defs.sv -- TSI shared type definitions

package tsi_defs_pkg;

  typedef enum bit [1:0] {TSI_OK, TSI_ERR} tsi_status_e;

  function automatic bit [12:0] tsi_pid(int i);
    case (i)
      0: return 13'h0000;
      1: return 13'h0100;
      2: return 13'h0101;
      default: return 13'h0111;
    endcase
  endfunction
  function automatic int tsi_slot(bit [12:0] pid);   // filter entry, -1 when not filtered
    for (int i = 0; i < 4; i++) if (tsi_pid(i) == pid) return i;
    return -1;
  endfunction

endpackage
