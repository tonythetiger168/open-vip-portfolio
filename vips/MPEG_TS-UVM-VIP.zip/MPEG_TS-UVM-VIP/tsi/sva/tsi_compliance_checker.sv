// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tsi_compliance_checker.sv -- TSI concurrent assertion checks (bindable)

module tsi_compliance_checker
  (input logic clk, input logic rst_n, input logic ts_valid, input logic ts_sync, input logic [7:0] ts_data, input logic ts_err, input logic out_valid, input logic [7:0] out_data, input logic out_last, input logic rep_valid, input logic [12:0] rep_pid, input logic [3:0] rep_cc, input logic [2:0] rep_status);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({ts_valid, out_valid, rep_valid}))
    else $error("TSI: X on a valid");
  assert property (@(posedge clk) disable iff (!rst_n) ts_sync |-> ts_valid)
    else $error("TSI: ts_sync without ts_valid");
  assert property (@(posedge clk) disable iff (!rst_n) ts_valid |-> !$isunknown({ts_sync, ts_data, ts_err}))
    else $error("TSI: X on a valid byte");
  assert property (@(posedge clk) disable iff (!rst_n) out_last |-> out_valid && rep_valid && rep_status inside {3'd0, 3'd2})
    else $error("TSI: payload end without an accept report");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |-> rep_status != 3'd7)
    else $error("TSI: reserved status");
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_status == 3'd2);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_status == 3'd3);
endmodule
