// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SUE testbench top with a functional SUE DUT model

`ifndef SUE_UVM_VIP_TB_SV
`define SUE_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sue_defs_pkg::*;
import sue_pkg::*;
import sue_env_pkg::*;
import sue_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  sue_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  sue_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .in_valid(vif.in_valid),
    .in_data(vif.in_data),
    .in_last(vif.in_last),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data),
    .out_last(vif.out_last),
    .rep_valid(vif.rep_valid),
    .rep_type(vif.rep_type),
    .rep_vc(vif.rep_vc),
    .rep_psn(vif.rep_psn),
    .rep_reason(vif.rep_reason)
  );

  // Concurrent protocol checks
  sue_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .in_valid(vif.in_valid),
    .in_data(vif.in_data),
    .in_last(vif.in_last),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data),
    .out_last(vif.out_last),
    .rep_valid(vif.rep_valid),
    .rep_type(vif.rep_type),
    .rep_vc(vif.rep_vc),
    .rep_psn(vif.rep_psn),
    .rep_reason(vif.rep_reason)
  );

  initial begin
    uvm_config_db#(virtual sue_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module sue_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        in_valid,
  input  logic [7:0]  in_data,
  input  logic        in_last,
  output logic        out_valid,
  output logic [7:0]  out_data,
  output logic        out_last,
  output logic        rep_valid,
  output logic [1:0]  rep_type,
  output logic [1:0]  rep_vc,
  output logic [15:0] rep_psn,
  output logic [2:0]  rep_reason
);
  function automatic logic [31:0] crc32_byte(input logic [31:0] c, input logic [7:0] b);
    logic [31:0] x;
    x = c ^ {24'h0, b};
    for (int k = 0; k < 8; k++) x = x[0] ? (x >> 1) ^ 32'hEDB8_8320 : (x >> 1);
    crc32_byte = x;
  endfunction

  logic [7:0]  rb [0:127];
  logic [7:0]  nrb, olen, opos;
  logic        go, busy;
  logic [15:0] expp [0:3];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      nrb <= '0; olen <= '0; opos <= '0; go <= 1'b0; busy <= 1'b0;
      for (int i = 0; i < 4; i++) expp[i] <= 16'h0;
      out_valid <= 1'b0; out_data <= '0; out_last <= 1'b0;
      rep_valid <= 1'b0; rep_type <= '0; rep_vc <= '0; rep_psn <= '0; rep_reason <= '0;
    end else begin
      rep_valid <= 1'b0; out_valid <= 1'b0; out_last <= 1'b0;
      go <= in_valid && in_last;
      if (in_valid) begin
        if (nrb < 8'd128) rb[nrb[6:0]] <= in_data;
        nrb <= nrb + 8'd1;
      end
      if (go) begin : receive
        logic [31:0] c;
        logic [15:0] p, d, len, e;
        logic [1:0]  v, ty;
        logic [2:0]  rs;
        logic [15:0] rp;
        integer      n;
        n = nrb;
        nrb <= '0;
        ty = 2'd2; rp = 16'h0; v = rb[15][7:6];
        e = expp[v];
        if (n < 26 || {rb[12], rb[13]} != 16'h88B5 || rb[14] != 8'h10) begin rs = 3'd5; v = 2'd0; end
        else begin
          c = 32'hFFFF_FFFF;
          for (int i = 14; i < 128; i++) if (i < n) c = crc32_byte(c, rb[i]);
          len = {rb[20], rb[21]};
          p = {rb[18], rb[19]};
          if (c != 32'hDEBB_20E3) begin rs = 3'd3; ty = 2'd1; rp = e; end
          else if (len != n - 26 || len == 16'd0 || len > 16'd64) begin rs = 3'd6; v = 2'd0; end
          else if ({rb[16], rb[17]} != 16'h0042) begin rs = 3'd4; v = 2'd0; end
          else begin
            d = e - p;
            if (p == e) begin
              rs = 3'd0; ty = 2'd0; rp = p;
              expp[v] <= e + 16'd1;
              olen <= len[7:0]; opos <= '0; busy <= 1'b1;
            end else if (d >= 16'd1 && d <= 16'h8000) begin rs = 3'd1; ty = 2'd0; rp = e - 16'd1; end
            else begin rs = 3'd2; ty = 2'd1; rp = e; end
          end
        end
        rep_type <= ty; rep_vc <= v; rep_psn <= rp; rep_reason <= rs;
        if (rs != 3'd0) rep_valid <= 1'b1;
      end
      if (busy) begin
        out_valid <= 1'b1;
        out_data <= rb[22 + opos];
        opos <= opos + 8'd1;
        if (opos == olen - 8'd1) begin out_last <= 1'b1; busy <= 1'b0; rep_valid <= 1'b1; end
      end
    end
  end
endmodule
`endif
