// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SUE DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened sue_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic in_valid = 1'b0, in_last = 1'b0;
  logic [7:0] in_data = 8'h00;
  wire out_valid, out_last, rep_valid;
  wire [7:0] out_data;
  wire [1:0] rep_type, rep_vc;
  wire [15:0] rep_psn;
  wire [2:0] rep_reason;

  always #5 clk = ~clk;

  sue_model u_dut (.clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_data(in_data), .in_last(in_last),
                   .out_valid(out_valid), .out_data(out_data), .out_last(out_last), .rep_valid(rep_valid),
                   .rep_type(rep_type), .rep_vc(rep_vc), .rep_psn(rep_psn), .rep_reason(rep_reason));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [31:0] crc32(input logic [31:0] c, input logic [7:0] b);
    logic [31:0] x;
    x = c ^ {24'h0, b};
    for (int k = 0; k < 8; k++) x = x[0] ? (x >> 1) ^ 32'hEDB8_8320 : (x >> 1);
    crc32 = x;
  endfunction

  logic [7:0] fb [0:127];
  integer fn;
  // data frame: vc, psn, n payload bytes from v0; dest; then the CRC
  task automatic build(input integer vc, input logic [15:0] psn, input integer n, input logic [7:0] v0,
                       input logic [15:0] dest = 16'h0042);
    logic [31:0] c;
    for (int i = 0; i < 128; i++) fb[i] = 8'h00;
    for (int i = 0; i < 12; i++) fb[i] = 8'hA0 + i;
    fb[12] = 8'h88; fb[13] = 8'hB5; fb[14] = 8'h10; fb[15] = {vc[1:0], 6'h0};
    fb[16] = dest[15:8]; fb[17] = dest[7:0]; fb[18] = psn[15:8]; fb[19] = psn[7:0]; fb[20] = 8'h00; fb[21] = n;
    for (int i = 0; i < n; i++) fb[22 + i] = v0 + 8'd29 * i;
    fn = 22 + n;
    c = 32'hFFFF_FFFF;
    for (int i = 14; i < 128; i++) if (i < fn) c = crc32(c, fb[i]);
    c = ~c;
    fb[fn] = c[7:0]; fb[fn + 1] = c[15:8]; fb[fn + 2] = c[23:16]; fb[fn + 3] = c[31:24];
    fn = fn + 4;
  endtask
  task automatic recrc();
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    for (int i = 14; i < 128; i++) if (i < fn - 4) c = crc32(c, fb[i]);
    c = ~c;
    fb[fn - 4] = c[7:0]; fb[fn - 3] = c[15:8]; fb[fn - 2] = c[23:16]; fb[fn - 1] = c[31:24];
  endtask

  logic [7:0] ob [0:127];
  integer on = 0, nrep = 0, nlast = 0;
  logic [1:0] r_ty, r_vc;
  logic [15:0] r_psn;
  logic [2:0] r_rs;
  always @(posedge clk) begin
    if (out_valid) begin ob[on] = out_data; on = on + 1; if (out_last) nlast = nlast + 1; end
    if (rep_valid) begin nrep = nrep + 1; r_ty = rep_type; r_vc = rep_vc; r_psn = rep_psn; r_rs = rep_reason; end
  end
  task automatic send();
    integer r0, k;
    r0 = nrep; on = 0;
    for (int i = 0; i < 128; i++)
      if (i < fn) begin @(negedge clk); in_valid = 1; in_data = fb[i]; in_last = (i == fn - 1); end
    @(negedge clk); in_valid = 0; in_last = 0;
    k = 0;
    while (k < 200 && nrep == r0) begin @(negedge clk); k = k + 1; end
    @(negedge clk);
  endtask
  function automatic logic got(input logic [1:0] ty, input logic [1:0] vc, input logic [15:0] psn, input logic [2:0] rs);
    got = r_ty == ty && r_vc == vc && r_psn == psn && r_rs == rs;
  endfunction
  function automatic logic delivered(input integer n);
    logic ok;
    ok = (on == n);
    for (int i = 0; i < 128; i++) if (i < n && ob[i] !== fb[22 + i]) ok = 0;
    delivered = ok;
  endfunction

  initial begin
    integer r;
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0 && out_valid === 1'b0 && out_last === 1'b0, "nothing out in reset");
    rst_n = 1;
    repeat (4) @(negedge clk);
    chk(nrep == 0, "no report without a frame");

    build(0, 0, 1, 8'h11); send(); chk(got(0, 0, 0, 0) && delivered(1), "VC 0 PSN 0, 1 byte: ACK 0, delivered");
    build(0, 1, 64, 8'h12); send(); chk(got(0, 0, 1, 0) && delivered(64), "VC 0 PSN 1, 64 bytes");
    build(3, 0, 17, 8'h13); send(); chk(got(0, 3, 0, 0) && delivered(17), "VC 3 has its own PSN");
    build(2, 0, 5, 8'h14); send(); chk(got(0, 2, 0, 0) && delivered(5), "VC 2 PSN 0");
    build(1, 0, 9, 8'h15); send(); chk(got(0, 1, 0, 0) && delivered(9), "VC 1 PSN 0");
    // duplicate, gap, retransmission
    build(0, 1, 8, 8'h16); send(); chk(got(0, 0, 1, 1) && on == 0, "VC 0 PSN 1 again: duplicate, ACK 1, not delivered");
    build(0, 0, 8, 8'h17); send(); chk(got(0, 0, 1, 1), "VC 0 PSN 0: duplicate, ACK of the last (1)");
    build(0, 3, 8, 8'h18); send(); chk(got(1, 0, 2, 2) && on == 0, "VC 0 PSN 3 where 2 is due: NACK 2, dropped");
    build(0, 2, 8, 8'h19); send(); chk(got(0, 0, 2, 0) && delivered(8), "retransmitted PSN 2: delivered");
    build(0, 3, 8, 8'h1A); send(); chk(got(0, 0, 3, 0) && delivered(8), "then PSN 3");
    build(0, 16'h8003, 8, 8'h1B); send(); chk(got(1, 0, 4, 2), "PSN 0x8003 (32767 ahead): gap, NACK 4");
    build(0, 16'h8004, 8, 8'h1C); send(); chk(got(0, 0, 3, 1), "PSN 0x8004 (32768 behind): duplicate, ACK 3");
    // faults
    build(1, 1, 10, 8'h20); fb[25] = fb[25] ^ 8'h04; send(); chk(got(1, 1, 1, 3) && on == 0, "payload bit flipped: CRC NACK of VC 1's 1");
    build(1, 1, 10, 8'h21); fb[fn - 1] = fb[fn - 1] ^ 8'h80; send(); chk(got(1, 1, 1, 3), "CRC bit flipped");
    build(2, 1, 10, 8'h22, 16'h0043); send(); chk(got(2, 0, 0, 4) && on == 0, "XPU 0x0043: dropped");
    build(2, 1, 10, 8'h23); fb[14] = 8'h20; recrc(); send(); chk(got(2, 0, 0, 5), "version 2: dropped");
    build(2, 1, 10, 8'h24); fb[14] = 8'h11; recrc(); send(); chk(got(2, 0, 0, 5), "opcode 1: dropped");
    build(2, 1, 10, 8'h25); fb[12] = 8'h08; fb[13] = 8'h00; send(); chk(got(2, 0, 0, 5), "EtherType 0x0800: dropped");
    build(2, 1, 10, 8'h26); fb[21] = 8'd11; recrc(); send(); chk(got(2, 0, 0, 6), "length field 11 for 10 bytes: dropped");
    build(2, 1, 10, 8'h27); fb[21] = 8'd9; recrc(); send(); chk(got(2, 0, 0, 6), "length field 9 for 10 bytes: dropped");
    build(2, 1, 0, 8'h28); send(); chk(got(2, 0, 0, 6), "empty payload: dropped");
    build(2, 1, 65, 8'h29); send(); chk(got(2, 0, 0, 6), "65-byte payload: dropped");
    build(2, 1, 10, 8'h2A); fn = 25; send(); chk(got(2, 0, 0, 5), "25-byte runt: dropped");
    build(2, 1, 10, 8'h2B); send(); chk(got(0, 2, 1, 0) && delivered(10), "VC 2 PSN 1 after the drops");
    build(1, 1, 10, 8'h2C); send(); chk(got(0, 1, 1, 0) && delivered(10), "VC 1 PSN 1 after its CRC NACKs");
    build(3, 1, 3, 8'h2D); send(); chk(got(0, 3, 1, 0) && delivered(3), "VC 3 untouched");
    // a long in-order run on VC 3
    for (int i = 2; i < 6; i++) begin build(3, i, 2, 8'h30 + i); send(); end
    r = 1;
    for (int i = 6; i < 70; i++) begin build(3, i, 1, i); send(); if (!got(0, 3, i, 0)) r = 0; end
    chk(r == 1, "VC 3 PSN 6..69 in order");
    chk(nlast == 78, $sformatf("one last-byte strobe per delivered frame (%0d)", nlast));

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
