// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sue_pkg.sv -- SUE UVM VIP package

package sue_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import sue_defs_pkg::*;
  export sue_defs_pkg::*;

  `include "sue_transaction.svh"
  `include "sue_config.svh"
  `include "sue_sequencer.svh"
  `include "sue_driver.svh"
  `include "sue_monitor.svh"
  `include "sue_agent.svh"
  `include "sue_sequences.svh"
  `include "sue_checker.svh"
  `include "sue_coverage.svh"
endpackage
