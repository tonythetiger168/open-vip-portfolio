// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sue_coverage.svh -- SUE functional coverage

class sue_coverage extends uvm_subscriber #(sue_transaction);
  `uvm_component_utils(sue_coverage)
  sue_config cfg;
  sue_transaction tr;

  covergroup sue_cg;
    cp_reason : coverpoint tr.reason { bins in_order = {0}; bins duplicate = {1}; bins gap = {2}; bins crc = {3};
                                         bins dest = {4}; bins header = {5}; bins length = {6}; }
    cp_vc : coverpoint tr.rvc iff (tr.reason == 0);
    cp_len : coverpoint tr.odata.size() iff (tr.reason == 0) { bins one = {1}; bins short_p = {[2:16]}; bins long_p = {[17:64]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    sue_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(sue_config)::get(this, "", "cfg", cfg))
      cfg = sue_config::type_id::create("cfg");
  endfunction

  function void write(sue_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    sue_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SUE coverage: %0.1f%%", sue_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
