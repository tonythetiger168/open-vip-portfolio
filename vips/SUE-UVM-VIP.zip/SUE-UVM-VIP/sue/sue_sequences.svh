// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sue_sequences.svh -- SUE sequences

// Random traffic: cfg.num_items constrained-random items.
class sue_base_sequence extends uvm_sequence #(sue_transaction);
  `uvm_object_utils(sue_base_sequence)
  sue_config cfg;

  function new(string name = "sue_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = sue_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "sue_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class sue_directed_sequence extends uvm_sequence #(sue_transaction);
  `uvm_object_utils(sue_directed_sequence)
  sue_config cfg;

  function new(string name = "sue_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function sue_transaction item();
    item = sue_transaction::type_id::create("req");
  endfunction

  task send(sue_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    sue_transaction t;
    // in order on every VC, a duplicate, a gap and its retransmission, each fault
    for (int v = 0; v < 4; v++)
      for (int i = 0; i < 2; i++) begin t = item(); t.set(0, v, 1 + 21 * i + v); send(t); end
    t = item(); t.set(18, 1, 8); send(t);
    t = item(); t.set(20, 1, 8); send(t);
    t = item(); t.set(0, 1, 64); send(t);
    for (int k = 22; k < 29; k++) begin
      t = item(); t.set(k, 2, 10); send(t);
      t = item(); t.set(0, 2, 10); send(t);
    end
  endtask
endclass
