// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sue_transaction.svh -- SUE transaction

class sue_transaction extends uvm_sequence_item;
  `uvm_object_utils(sue_transaction)

  // request (driven by the agent)
  bit [7:0] frame[$];
  // response (returned by the DUT)
  bit [1:0] rtype;
  bit [1:0] rvc;
  bit [15:0] rpsn;
  bit [2:0] reason;
  bit [7:0] odata[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [1:0] vc;
  rand bit [5:0] len_r;
  rand bit [31:0] seed;
  bit [15:0] psn;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "sue_transaction"); super.new(name); endfunction

  // kind: 0-17 in order, 18-19 duplicate, 20-21 gap, 22 CRC, 23 destination, 24 version, 25 opcode,
  // 26 EtherType, 27 length field, 28 runt, 29-31 in order
  function void set(int k, bit [1:0] v, int n); kind = k; vc = v; len_r = n - 1; endfunction
  function void build(bit [15:0] p);
    bit [31:0] x = seed | 1, c = 32'hFFFF_FFFF;
    bit [15:0] n = len_r + 1;
    psn = p;
    frame.delete();
    for (int i = 0; i < 6; i++) frame.push_back(8'h02 + i);
    for (int i = 0; i < 6; i++) frame.push_back(8'h12 + i);
    frame.push_back((kind == 26) ? 8'h08 : SUE_ETYPE[15:8]); frame.push_back((kind == 26) ? 8'h00 : SUE_ETYPE[7:0]);
    frame.push_back({(kind == 24) ? 4'h2 : 4'h1, (kind == 25) ? 4'h1 : 4'h0});
    frame.push_back({vc, 6'h0});
    frame.push_back((kind == 23) ? 8'h00 : SUE_XPU[15:8]); frame.push_back((kind == 23) ? 8'h43 : SUE_XPU[7:0]);
    frame.push_back(p[15:8]); frame.push_back(p[7:0]);
    frame.push_back(8'h00); frame.push_back((kind == 27) ? 8'(n + 1) : n[7:0]);
    for (int i = 0; i < n; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      frame.push_back(x[7:0]);
    end
    for (int i = 14; i < frame.size(); i++) c = sue_crc32(c, frame[i]);
    c = ~c;
    if (kind == 22) c[17] = ~c[17];
    for (int i = 0; i < 4; i++) frame.push_back(c[8*i +: 8]);
    if (kind == 28) while (frame.size() > 20) void'(frame.pop_back());
  endfunction

  function void do_copy(uvm_object rhs);
    sue_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    frame = rhs_.frame;
    rtype = rhs_.rtype;
    rvc = rhs_.rvc;
    rpsn = rhs_.rpsn;
    reason = rhs_.reason;
    odata = rhs_.odata;
    kind = rhs_.kind;
    vc = rhs_.vc;
    len_r = rhs_.len_r;
    seed = rhs_.seed;
    psn = rhs_.psn;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sue_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (frame.size() != rhs_.frame.size()) return 0;
    foreach (frame[i]) if (frame[i] != rhs_.frame[i]) return 0;
    if (rtype != rhs_.rtype) return 0;
    if (rvc != rhs_.rvc) return 0;
    if (rpsn != rhs_.rpsn) return 0;
    if (reason != rhs_.reason) return 0;
    if (odata.size() != rhs_.odata.size()) return 0;
    foreach (odata[i]) if (odata[i] != rhs_.odata[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(sue_transaction rhs_);
    if (frame.size() != rhs_.frame.size()) return 0;
    foreach (frame[i]) if (frame[i] != rhs_.frame[i]) return 0;
    return 1;
  endfunction

  function string qstr_frame();
    string s = $sformatf("[%0d]{", frame.size());
    foreach (frame[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", frame[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_odata();
    string s = $sformatf("[%0d]{", odata.size());
    foreach (odata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", odata[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SUE{tag=%0d frame=%s rtype=0x%0h rvc=0x%0h rpsn=0x%0h reason=0x%0h odata=%s}", tag, qstr_frame(), rtype, rvc, rpsn, reason, qstr_odata());
  endfunction
endclass
