// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sue_if.sv -- SUE interface

interface sue_if (input logic clk);
  logic rst_n;

  logic in_valid;
  logic [7:0] in_data;
  logic in_last;
  logic out_valid;
  logic [7:0] out_data;
  logic out_last;
  logic rep_valid;
  logic [1:0] rep_type;
  logic [1:0] rep_vc;
  logic [15:0] rep_psn;
  logic [2:0] rep_reason;

  modport DUT (input clk, rst_n, input in_valid, input in_data, input in_last, output out_valid, output out_data, output out_last, output rep_valid, output rep_type, output rep_vc, output rep_psn, output rep_reason);
  modport MON (input clk, rst_n, in_valid, in_data, in_last, out_valid, out_data, out_last, rep_valid, rep_type, rep_vc, rep_psn, rep_reason);

  clocking drv_cb @(posedge clk);
    input rst_n, out_valid, out_data, out_last, rep_valid, rep_type, rep_vc, rep_psn, rep_reason;
    inout in_valid, in_data, in_last;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, in_valid, in_data, in_last, out_valid, out_data, out_last, rep_valid, rep_type, rep_vc, rep_psn, rep_reason;
  endclocking
endinterface
