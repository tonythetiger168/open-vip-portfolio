// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sue_monitor.svh -- SUE monitor: frames into the receiver, then the delivered payload and the report that close each one

class sue_monitor extends uvm_monitor;
  `uvm_component_utils(sue_monitor)

  virtual sue_if vif;
  uvm_analysis_port #(sue_transaction) ap;
  sue_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual sue_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sue: virtual interface not set")
    if (!uvm_config_db#(sue_config)::get(this, "", "cfg", cfg))
      cfg = sue_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] b[$], o[$];
      bit [7:0] frames[$][$];
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.in_valid) begin
          b.push_back(vif.mon_cb.in_data);
          if (vif.mon_cb.in_last) begin frames.push_back(b); b.delete(); end
        end
        if (vif.mon_cb.out_valid) o.push_back(vif.mon_cb.out_data);
        if (vif.mon_cb.rep_valid) begin
          if (frames.size() == 0) `uvm_error("MON", "SUE: report without a frame")
          else begin
            sue_transaction t = sue_transaction::type_id::create("t");
            t.frame = frames.pop_front();
            t.odata = o;
            t.rtype = vif.mon_cb.rep_type; t.rvc = vif.mon_cb.rep_vc; t.rpsn = vif.mon_cb.rep_psn; t.reason = vif.mon_cb.rep_reason;
            publish(t);
          end
          o.delete();
        end
      end
    end
  endtask

  function void publish(sue_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
