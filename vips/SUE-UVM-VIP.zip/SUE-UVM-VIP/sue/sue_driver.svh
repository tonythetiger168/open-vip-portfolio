// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sue_driver.svh -- SUE driver: one frame per item with the PSN from the driver's per-VC counter (planted duplicate / gap PSNs leave the counter, so the next frame is the retransmission); then the delivered payload and the report

class sue_driver extends uvm_driver #(sue_transaction);
  `uvm_component_utils(sue_driver)

  uvm_analysis_port #(sue_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual sue_if vif;
  sue_config cfg;

  bit [15:0] nxt [4] = '{0, 0, 0, 0};

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sue_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sue: virtual interface not set")
    if (!uvm_config_db#(sue_config)::get(this, "", "cfg", cfg))
      cfg = sue_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    sue_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.in_valid <= 1'b0;
    vif.drv_cb.in_data  <= 8'h00;
    vif.drv_cb.in_last  <= 1'b0;
  endtask

  task drive_item(sue_transaction t);
    bit [15:0] p = nxt[t.vc];
    int k = 0;
    if (t.kind inside {18, 19}) p = nxt[t.vc] - 1 - t.seed[2:0];
    else if (t.kind inside {20, 21}) p = nxt[t.vc] + 1 + t.seed[2:0];
    else if (!(t.kind inside {[22:28]})) nxt[t.vc]++;
    t.build(p);
    foreach (t.frame[i]) begin
      vif.drv_cb.in_valid <= 1'b1; vif.drv_cb.in_data <= t.frame[i]; vif.drv_cb.in_last <= (i == t.frame.size() - 1);
      @(vif.drv_cb);
    end
    vif.drv_cb.in_valid <= 1'b0; vif.drv_cb.in_last <= 1'b0;
    t.odata.delete();
    do begin
      @(vif.drv_cb);
      if (vif.drv_cb.out_valid) t.odata.push_back(vif.drv_cb.out_data);
      k++;
    end while (!vif.drv_cb.rep_valid && k < cfg.timeout_cycles);
    if (!vif.drv_cb.rep_valid) `uvm_error("DRV", "SUE: no report for a frame")
    t.rtype = vif.drv_cb.rep_type; t.rvc = vif.drv_cb.rep_vc; t.rpsn = vif.drv_cb.rep_psn; t.reason = vif.drv_cb.rep_reason;
    repeat (2) @(vif.drv_cb);
  endtask

endclass
