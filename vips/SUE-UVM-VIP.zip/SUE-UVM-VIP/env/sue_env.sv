// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sue_env.sv -- SUE environment: reference-model scoreboard, checker, coverage

package sue_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sue_defs_pkg::*;
  import sue_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class sue_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(sue_scoreboard)
    uvm_analysis_imp_exp #(sue_transaction, sue_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(sue_transaction, sue_scoreboard) obs_ap;

    sue_config cfg;
    sue_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [15:0] exp_psn [4] = '{0, 0, 0, 0};

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(sue_config)::get(this, "", "cfg", cfg))
        cfg = sue_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(sue_transaction t);
      int n = t.frame.size(), len;
      bit [31:0] c = 32'hFFFF_FFFF;
      bit [15:0] p, d;
      bit [1:0] v;
      t.odata.delete();
      t.rtype = 2; t.rvc = 0; t.rpsn = 0;
      if (n < 26 || {t.frame[12], t.frame[13]} != SUE_ETYPE || t.frame[14] != 8'h10) t.reason = 5;
      else begin
        v = t.frame[15][7:6];
        for (int i = 14; i < n; i++) c = sue_crc32(c, t.frame[i]);
        len = {t.frame[20], t.frame[21]};
        p = {t.frame[18], t.frame[19]};
        if (c != 32'hDEBB_20E3) begin t.reason = 3; t.rtype = 1; t.rvc = v; t.rpsn = exp_psn[v]; end
        else if (len != n - 26 || len == 0 || len > 64) t.reason = 6;
        else if ({t.frame[16], t.frame[17]} != SUE_XPU) t.reason = 4;
        else begin
          t.rvc = v;
          d = exp_psn[v] - p;
          if (p == exp_psn[v]) begin
            t.reason = 0; t.rtype = 0; t.rpsn = p;
            for (int i = 0; i < len; i++) t.odata.push_back(t.frame[22 + i]);
            exp_psn[v]++;
          end else if (d >= 1 && d <= 16'h8000) begin t.reason = 1; t.rtype = 0; t.rpsn = exp_psn[v] - 1; end
          else begin t.reason = 2; t.rtype = 1; t.rpsn = exp_psn[v]; end
        end
      end
    endfunction

    function void write_exp(sue_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(sue_transaction t);
      sue_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        sue_transaction e = exp_q.pop_front();
        sue_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("sue scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class sue_env extends uvm_env;
    `uvm_component_utils(sue_env)
    sue_agent      agt;
    sue_scoreboard sb;
    sue_checker    chk;
    sue_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = sue_agent     ::type_id::create("agt", this);
      sb  = sue_scoreboard::type_id::create("sb",  this);
      chk = sue_checker   ::type_id::create("chk", this);
      cov = sue_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
