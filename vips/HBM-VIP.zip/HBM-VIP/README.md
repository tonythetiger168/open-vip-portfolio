# HBM UVM VIP

**Protocol:** HBM2/2E/3 High Bandwidth Memory
**License:** Apache-2.0

## 1. Protocol Overview

HBM2/2E/3 stacked DRAM VIP with 8 pseudo-channels (cid). Commands are encoded on cs_n/ras_n/cas_n/we_n per channel; the driver issues ACT/RD/WR/PRE/REF/MRS/PDE/PDX with per-channel bank tracking.

Timing parameters (cycles): tRCD=14, tRP=14, tRAS=34,
tCL=14, tCWL=8, tFAW=16, tRFC=34.

## 2. Architecture

```
interfaces/memory_interfaces.sv   9 memory protocol interfaces (hbm_if is the DUT-side bus)
hbm/hbm_pkg.sv                    HBM VIP package:
    hbm_seq_item                  transaction (cmd/addr/bank/data + page_hit/bstate)
    hbm_cfg                       timing + mode configuration
    hbm_sequencer / hbm_driver    command driver (timing-accurate, drv_ap broadcast)
    hbm_monitor                   CA-bus command decoder (analysis port)
    hbm_agent                     sequencer + driver + monitor
    sequences                     directed library (below)
coverage/memory_coverage_pkg.sv   HBM functional coverage (3 covergroups + crosses)
env/memory_env_pkg.sv             memory_env_cfg / memory_scoreboard / memory_env
                                  end-to-end: driver drv_ap (expected) vs
                                  monitor item_collected_port (observed),
                                  n_matches/n_mismatches, UVM_ERROR on mismatch
env/vip/hbm/hbm_*_checker.sv      legacy L1/L2/L3 SVA checkers (module-based)
env/sva/hbm_compliance_checker.sv consolidated L1-L4 compliance checker
test/memory_test_pkg.sv           memory_base_test / memory_directed_test /
                                  memory_coverage_regression_test
tb_top.sv                         testbench top: 9 protocol interfaces, HBM DRAM
                                  memory model (bank/row/col storage + refresh
                                  counter), SVA checker instantiation
```

The `tb_top.sv` DRAM model tracks bank/row state, stores write data in a
sparse `{bank,row,col}` array, returns it on reads after tCL, and counts
refreshes -- closing the end-to-end data loop.

## 3. Sequence Library

| `hbm_base_seq`          | randomized legal ACT->RD/WR->PRE rounds |
| `hbm_rw_seq`            | legacy random R/W mix (kept API) |
| `hbm_write_seq`         | directed write rounds |
| `hbm_read_seq`          | directed read rounds |
| `hbm_refresh_seq`       | refresh traffic |
| `hbm_bank_conflict_seq` | same-bank ACT/PRE turnaround (tRP/tRCD pressure) |
| `hbm_back_to_back_seq`  | inter-bank back-to-back accesses |
| `hbm_page_hit_seq`      | corner: multiple accesses to one open row |
| `hbm_page_miss_seq`     | corner: every access forces PRE+ACT |
| `hbm_stress_seq`        | long randomized legal mix |
| `hbm_regression_seq`    | weighted mix of all directed sequences |

Legacy coverage sequences: `hbm_cov_cmd_seq`, `hbm_cov_bank_seq`, `{p}_cov_ch_seq`.

## 4. SVA Checkers (L1-L4)

Legacy tiered checkers (module-based, `env/vip/hbm/`):
- `hbm_protocol_checker` (L1: basic compliance)
- `hbm_timing_checker` (L2: timing windows)
- `hbm_data_integrity_checker` (L2/L3: data rules)
- `hbm_error_checker` (L3: error conditions)

Consolidated `hbm_compliance_checker` keeps the tiered L1/L2/L3 rule sets with
pass/fail counters and adds:
- **L4 (6):** tRCD (ACT->CAS), tRAS (ACT->PRE), tFAW (<=4 ACT/window),
  RD/WR only to open bank, no ACT to an already-open bank,
  refresh interval (tREFI) -- plus ACT->CAS / full-cycle covers.

## 5. Functional Coverage

- `hbm_cmd_cg`        : command distribution x bank geometry (crosses)
- `hbm_bank_state_cg` : bank state transitions (IDLE/ACTIVE) x command (cross)
- `hbm_addr_cg`       : row regions, page hit/miss x command (cross)

## 6. Quick Start

```bash
# Portable multi-simulator flow (VCS / Xcelium / Questa)
make -C scripts SIMULATOR=vcs TEST=memory_directed_test
# or use the wrapper
./run.sh TESTNAME=memory_directed_test
```

Tests: `memory_base_test` (default), `memory_directed_test`,
`memory_coverage_regression_test`.
