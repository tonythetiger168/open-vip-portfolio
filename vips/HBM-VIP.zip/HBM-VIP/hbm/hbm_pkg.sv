// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// HBM2/2E/3 UVM VIP Package
// Deepened: timing-accurate command driver (tRCD/tRP/tRAS/tFAW), bus-decoding
// monitor with per-channel bank/page tracking, directed sequence library.
//------------------------------------------------------------------------------
package hbm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // Bank state tracked by the monitor, sampled by functional coverage
  typedef enum {B_IDLE, B_ACTIVE} bank_state_e;

  //==========================================================================
  // HBM Sequence Item
  //==========================================================================
  class hbm_seq_item extends uvm_sequence_item;
    `uvm_object_utils(hbm_seq_item)
    typedef enum {ACT, READ, WRITE, PRE, REF, NOP, MRS, PDE, PDX} cmd_type_e;
    rand cmd_type_e cmd_type;
    rand bit [33:0] addr;
    rand bit [2:0]  cid;     // Channel ID (0-7)
    rand bit [1:0]  bank;
    rand bit [127:0] data[];
    rand bit [15:0]  dm;
    rand bit [4:0]   burst_len;
    bit [127:0]      rdata[];
    rand bit         par;
    // filled in by the monitor
    bit              page_hit;
    bank_state_e     bstate;

    constraint c_cid { cid inside {[0:7]}; }
    constraint c_bank { bank inside {[0:3]}; }
    constraint c_burst_len { burst_len inside {2, 4, 8, 16}; }
    constraint c_data_size { data.size() == burst_len; rdata.size() == burst_len; }
    constraint c_addr_align { addr[3:0] == 4'b0000; }
    function new(string name = "hbm_seq_item");
      super.new(name);
    endfunction
    function string convert2string();
      return $sformatf("HBM %s: ch=%0d bank=%0d addr=0x%0h bl=%0d",
                       cmd_type.name(), cid, bank, addr, burst_len);
    endfunction
  endclass : hbm_seq_item

  //==========================================================================
  // HBM Configuration
  //==========================================================================
  class hbm_cfg extends uvm_object;
    `uvm_object_utils(hbm_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1;
    int tRCD = 14;
    int tRP  = 14;
    int tRAS = 34;
    int tCL  = 14;
    int tCWL = 8;
    int tRRD = 4;
    int tFAW = 16;
    int tCCDS = 2;  // CAS-to-CAS delay (same bank group)
    int tCCDL = 4;  // CAS-to-CAS delay (different bank group)
    function new(string name = "hbm_cfg");
      super.new(name);
    endfunction
  endclass : hbm_cfg

  //==========================================================================
  // HBM Sequencer
  //==========================================================================
  class hbm_sequencer extends uvm_sequencer #(hbm_seq_item);
    `uvm_component_utils(hbm_sequencer)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
  endclass : hbm_sequencer

  //==========================================================================
  // HBM Driver -- drives per-channel DRAM command sequences on hbm_if with
  // JEDEC-style timing; publishes expected items for the scoreboard.
  //==========================================================================
  class hbm_driver extends uvm_driver #(hbm_seq_item);
    `uvm_component_utils(hbm_driver)
    virtual hbm_if vif;
    hbm_cfg cfg;
    uvm_analysis_port #(hbm_seq_item) drv_ap;  // expected items for scoreboard

    bit          bank_active [32];  // flattened {cid,bank}
    bit [33:0]   active_row  [32];
    int unsigned act_cycle   [32];
    int unsigned act_hist    [4];
    int          act_hist_idx = 0;
    int unsigned cyc = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      drv_ap = new("drv_ap", this);
      foreach (bank_active[i]) bank_active[i] = 0;
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual hbm_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "HBM virtual interface not found")
      if (!uvm_config_db#(hbm_cfg)::get(this, "", "cfg", cfg))
        cfg = hbm_cfg::type_id::create("cfg");
    endfunction

    function int bank_id(bit [2:0] cid, bit [1:0] b);
      return cid * 4 + b;
    endfunction

    task drive_cmd(bit cs_n, bit ras_n, bit cas_n, bit we_n,
                   bit [33:0] a, bit [2:0] cid, bit [1:0] b);
      vif.drv_cb.cs_n  <= cs_n;
      vif.drv_cb.ras_n <= ras_n;
      vif.drv_cb.cas_n <= cas_n;
      vif.drv_cb.we_n  <= we_n;
      vif.drv_cb.addr  <= a;
      vif.drv_cb.cid   <= cid;
      vif.drv_cb.ba    <= b;
      @(vif.drv_cb);
      cyc++;
    endtask

    task idle(int n);
      vif.drv_cb.cs_n  <= 1'b1;
      vif.drv_cb.ras_n <= 1'b1;
      vif.drv_cb.cas_n <= 1'b1;
      vif.drv_cb.we_n  <= 1'b1;
      repeat (n) begin
        @(vif.drv_cb);
        cyc++;
      end
    endtask

    task drive_activate(hbm_seq_item item);
      int id = bank_id(item.cid, item.bank);
      while (cyc - act_hist[act_hist_idx] <= cfg.tFAW && act_hist[act_hist_idx] != 0)
        idle(1);                        // tFAW window
      drive_cmd(0, 0, 1, 1, item.addr, item.cid, item.bank);
      active_row[id]  = item.addr;
      bank_active[id] = 1;
      act_cycle[id]   = cyc;
      act_hist[act_hist_idx] = cyc;
      act_hist_idx = (act_hist_idx + 1) % 4;
      idle(cfg.tRCD - 1);               // tRCD
    endtask

    task drive_read(hbm_seq_item item);
      int id = bank_id(item.cid, item.bank);
      if (!bank_active[id])
        `uvm_warning(get_type_name(),
          $sformatf("RD to closed bank ch=%0d ba=%0d", item.cid, item.bank))
      drive_cmd(0, 1, 0, 1, item.addr, item.cid, item.bank);
      idle(cfg.tCL);                    // CAS latency
      item.rdata = new[item.burst_len];
      for (int i = 0; i < item.burst_len; i++) begin
        @(vif.drv_cb);
        cyc++;
        item.rdata[i] = vif.drv_cb.dq;  // sample read data burst
      end
    endtask

    task drive_write(hbm_seq_item item);
      int id = bank_id(item.cid, item.bank);
      if (!bank_active[id])
        `uvm_warning(get_type_name(),
          $sformatf("WR to closed bank ch=%0d ba=%0d", item.cid, item.bank))
      drive_cmd(0, 1, 0, 0, item.addr, item.cid, item.bank);
      idle(cfg.tCWL - 1);               // CAS write latency
      for (int i = 0; i < item.burst_len; i++) begin
        vif.drv_cb.dq <= item.data[i];
        vif.drv_cb.dm <= item.dm;
        @(vif.drv_cb);
        cyc++;
      end
    endtask

    task drive_precharge(hbm_seq_item item);
      int id = bank_id(item.cid, item.bank);
      while (cyc - act_cycle[id] < cfg.tRAS)
        idle(1);                        // tRAS
      drive_cmd(0, 0, 1, 0, item.addr, item.cid, item.bank);
      bank_active[id] = 0;
      idle(cfg.tRP - 1);                // tRP
    endtask

    task drive_refresh(hbm_seq_item item);
      foreach (bank_active[i])
        if (bank_active[i])
          `uvm_warning(get_type_name(), "REF issued with open banks")
      drive_cmd(0, 0, 0, 1, item.addr, item.cid, item.bank);
      idle(cfg.tRAS - 1);               // tRFC
    endtask

    task drive_mrs(hbm_seq_item item);
      drive_cmd(0, 0, 0, 0, item.addr, item.cid, item.bank);
      idle(4);                          // tMOD
    endtask

    task drive_pde(hbm_seq_item item);
      @(vif.drv_cb);
      vif.drv_cb.cke <= 1'b0;
      cyc++;
    endtask

    task drive_pdx(hbm_seq_item item);
      @(vif.drv_cb);
      vif.drv_cb.cke <= 1'b1;
      cyc++;
      idle(5);
    endtask

    task run_phase(uvm_phase phase);
      idle(1);
      wait (vif.rst_n === 1'b1);
      idle(5);
      forever begin
        seq_item_port.get_next_item(req);
        `uvm_info(get_type_name(), $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
        case (req.cmd_type)
          hbm_seq_item::ACT:   drive_activate(req);
          hbm_seq_item::READ:  drive_read(req);
          hbm_seq_item::WRITE: drive_write(req);
          hbm_seq_item::PRE:   drive_precharge(req);
          hbm_seq_item::REF:   drive_refresh(req);
          hbm_seq_item::MRS:   drive_mrs(req);
          hbm_seq_item::PDE:   drive_pde(req);
          hbm_seq_item::PDX:   drive_pdx(req);
          hbm_seq_item::NOP:   idle(1);
        endcase
        if (req.cmd_type != hbm_seq_item::NOP && req.cmd_type != hbm_seq_item::PDE && req.cmd_type != hbm_seq_item::PDX)
          drv_ap.write(req);            // broadcast expected transaction
        seq_item_port.item_done();
      end
    endtask
  endclass : hbm_driver

  //==========================================================================
  // HBM Monitor -- decodes commands from the CA bus waveform, tracks
  // per-channel bank state and page hit/miss.
  //==========================================================================
  class hbm_monitor extends uvm_monitor;
    `uvm_component_utils(hbm_monitor)
    virtual hbm_if vif;
    uvm_analysis_port #(hbm_seq_item) item_collected_port;
    int unsigned txn_count = 0;

    protected bit        bank_active [32];
    protected bit [33:0] active_row  [32];

    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual hbm_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "HBM virtual interface not found")
    endfunction

    function int bank_id(bit [2:0] cid, bit [1:0] b);
      return cid * 4 + b;
    endfunction

    task run_phase(uvm_phase phase);
      hbm_seq_item item;
      int id;
      forever begin
        @(vif.mon_cb);
        if (vif.rst_n !== 1'b1) begin
          foreach (bank_active[i]) bank_active[i] = 0;
          continue;
        end
        if (vif.mon_cb.cs_n) continue;  // deselect
        item = hbm_seq_item::type_id::create("item");
        if (!vif.mon_cb.ras_n && vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::ACT;
        else if (vif.mon_cb.ras_n && !vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::READ;
        else if (vif.mon_cb.ras_n && !vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::WRITE;
        else if (!vif.mon_cb.ras_n && vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::PRE;
        else if (!vif.mon_cb.ras_n && !vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::REF;
        else
          item.cmd_type = hbm_seq_item::MRS;
        item.cid      = vif.mon_cb.cid;
        item.bank     = vif.mon_cb.ba;
        item.addr     = vif.mon_cb.addr;
        item.page_hit = 1'b0;
        id = bank_id(vif.mon_cb.cid, vif.mon_cb.ba);
        case (item.cmd_type)
          hbm_seq_item::ACT: begin
            item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
            bank_active[id] = 1;
            active_row[id]  = vif.mon_cb.addr;
          end
          hbm_seq_item::READ, hbm_seq_item::WRITE: begin
            item.bstate   = bank_active[id] ? B_ACTIVE : B_IDLE;
            item.page_hit = bank_active[id];
          end
          hbm_seq_item::PRE: begin
            item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
            bank_active[id] = 0;
          end
          hbm_seq_item::REF: begin
            item.bstate = B_IDLE;
            foreach (bank_active[i]) bank_active[i] = 0;
          end
          default: item.bstate = B_IDLE;
        endcase
        txn_count++;
        item_collected_port.write(item);
        `uvm_info(get_type_name(), $sformatf("Monitored: %s", item.convert2string()), UVM_MEDIUM)
      end
    endtask

    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(),
        $sformatf("HBM monitor observed %0d transactions", txn_count), UVM_LOW)
    endfunction
  endclass : hbm_monitor

  //==========================================================================
  // HBM Agent
  //==========================================================================
  class hbm_agent extends uvm_agent;
    `uvm_component_utils(hbm_agent)
    hbm_sequencer sqr;
    hbm_driver    drv;
    hbm_monitor   mon;
    hbm_cfg       cfg;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(hbm_cfg)::get(this, "", "cfg", cfg))
        cfg = hbm_cfg::type_id::create("cfg");
      mon = hbm_monitor::type_id::create("mon", this);
      if (cfg.is_active == UVM_ACTIVE) begin
        sqr = hbm_sequencer::type_id::create("sqr", this);
        drv = hbm_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.is_active == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass : hbm_agent

  //==========================================================================
  // Directed sequence library (normal R/W, refresh, bank conflict,
  // back-to-back, page hit/miss corner cases, stress, regression)
  //==========================================================================
  class hbm_base_seq extends uvm_sequence #(hbm_seq_item);
    `uvm_object_utils(hbm_base_seq)
    rand int num_trans = 20;
    rand bit [15:0] row;
    rand bit [15:0] col;
    rand bit [2:0]  chan_n;
    rand bit [2:0]  bank_n;
    rand bit        rd_not_wr;
    constraint c_col { col[2:0] == 3'b000; }
    constraint c_bankn { bank_n <= 3; }
    function new(string name = "hbm_base_seq");
      super.new(name);
    endfunction
    // issue one command item with explicit geometry
    task issue(hbm_seq_item::cmd_type_e c, bit [15:0] a, bit [2:0] ch, bit [2:0] b);
      hbm_seq_item item = hbm_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { cmd_type == c; addr == a; cid == ch; bank == b[1:0]; });
      finish_item(item);
    endtask
    // random-but-legal ACT -> RD/WR -> PRE rounds, REF every 8th round
    task body();
      for (int i = 0; i < num_trans; i++) begin
        void'(this.randomize(row, col, chan_n, bank_n, rd_not_wr));
        if (i % 8 == 7) issue(hbm_seq_item::REF, 16'h0, 3'h0, 3'h0);
        issue(hbm_seq_item::ACT, row, chan_n, bank_n);
        issue(rd_not_wr ? hbm_seq_item::READ : hbm_seq_item::WRITE, col, chan_n, bank_n);
        issue(hbm_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // Legacy random read/write mix (kept API): legal rounds
  class hbm_rw_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_rw_seq)
    function new(string name = "hbm_rw_seq");
      super.new(name);
      num_trans = 30;
    endfunction
  endclass

  // 1) Directed: write rounds (normal write traffic)
  class hbm_write_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_write_seq)
    function new(string name = "hbm_write_seq");
      super.new(name);
    endfunction
    constraint c_wr { rd_not_wr == 0; }
  endclass

  // 2) Directed: read rounds (normal read traffic)
  class hbm_read_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_read_seq)
    function new(string name = "hbm_read_seq");
      super.new(name);
    endfunction
    constraint c_rd { rd_not_wr == 1; }
  endclass

  // 3) Directed: refresh traffic
  class hbm_refresh_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_refresh_seq)
    function new(string name = "hbm_refresh_seq");
      super.new(name);
    endfunction
    task body();
      for (int i = 0; i < num_trans; i++)
        issue(hbm_seq_item::REF, 16'h0, 3'h0, 3'h0);
    endtask
  endclass

  // 4) Directed: bank conflict -- repeated ACT to the SAME bank forces
  //    PRE/ACT turnaround (tRP + tRCD pressure)
  class hbm_bank_conflict_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_bank_conflict_seq)
    function new(string name = "hbm_bank_conflict_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h0100;
      void'(hbm_base_seq'(this).randomize(chan_n, bank_n));
      for (int i = 0; i < num_trans; i++) begin
        issue(hbm_seq_item::ACT, crow, chan_n, bank_n);
        issue(hbm_seq_item::WRITE, 16'h0, chan_n, bank_n);
        issue(hbm_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h100;
      end
    endtask
  endclass

  // 5) Directed: back-to-back accesses across 4 banks (no PRE between)
  class hbm_back_to_back_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_back_to_back_seq)
    function new(string name = "hbm_back_to_back_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h2000;
      for (int i = 0; i < num_trans; i++) begin
        for (int b = 0; b < 4; b++)
          issue(hbm_seq_item::ACT, crow, chan_n, b[2:0]);
        for (int b = 0; b < 4; b++) begin
          issue(hbm_seq_item::WRITE, 16'h0, chan_n, b[2:0]);
          issue(hbm_seq_item::READ, 16'h0, chan_n, b[2:0]);
        end
        for (int b = 0; b < 4; b++)
          issue(hbm_seq_item::PRE, 16'h0, chan_n, b[2:0]);
        crow = crow + 16'h400;
      end
    endtask
  endclass

  // 6) Corner case: page hit -- one ACT, many RD/WR to the SAME open row
  class hbm_page_hit_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_page_hit_seq)
    function new(string name = "hbm_page_hit_seq");
      super.new(name);
    endfunction
    task body();
      for (int i = 0; i < num_trans; i++) begin
        void'(hbm_base_seq'(this).randomize(row, chan_n, bank_n));
        issue(hbm_seq_item::ACT, row, chan_n, bank_n);
        for (int k = 0; k < 4; k++) begin
          void'(hbm_base_seq'(this).randomize(col, rd_not_wr));
          issue(rd_not_wr ? hbm_seq_item::READ : hbm_seq_item::WRITE, col, chan_n, bank_n);
        end
        issue(hbm_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // 7) Corner case: page miss -- every access targets a different row
  class hbm_page_miss_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_page_miss_seq)
    function new(string name = "hbm_page_miss_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h0;
      void'(hbm_base_seq'(this).randomize(chan_n, bank_n));
      for (int i = 0; i < num_trans; i++) begin
        void'(hbm_base_seq'(this).randomize(col, rd_not_wr));
        issue(hbm_seq_item::ACT, crow, chan_n, bank_n);
        issue(rd_not_wr ? hbm_seq_item::READ : hbm_seq_item::WRITE, col, chan_n, bank_n);
        issue(hbm_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h311;
      end
    endtask
  endclass

  // 8) Stress: long legal mix of rounds
  class hbm_stress_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_stress_seq)
    function new(string name = "hbm_stress_seq");
      super.new(name);
    endfunction
    function new(string name = "hbm_stress_seq");
      super.new(name);
      num_trans = 200;
    endfunction
  endclass

  // Regression: weighted mix of every directed sequence
  class hbm_regression_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_regression_seq)
    function new(string name = "hbm_regression_seq");
      super.new(name);
    endfunction
    task body();
      hbm_write_seq         wr   = hbm_write_seq::type_id::create("wr");
      hbm_read_seq          rd   = hbm_read_seq::type_id::create("rd");
      hbm_refresh_seq       refs = hbm_refresh_seq::type_id::create("refs");
      hbm_bank_conflict_seq bc   = hbm_bank_conflict_seq::type_id::create("bc");
      hbm_back_to_back_seq  b2b  = hbm_back_to_back_seq::type_id::create("b2b");
      hbm_page_hit_seq      hit  = hbm_page_hit_seq::type_id::create("hit");
      hbm_page_miss_seq     miss = hbm_page_miss_seq::type_id::create("miss");
      wr.num_trans   = 10; rd.num_trans   = 10;
      refs.num_trans = 4;  bc.num_trans   = 5;
      b2b.num_trans  = 4;  hit.num_trans  = 4;
      miss.num_trans = 5;
      wr.start(m_sequencer);
      rd.start(m_sequencer);
      hit.start(m_sequencer);
      miss.start(m_sequencer);
      bc.start(m_sequencer);
      b2b.start(m_sequencer);
      refs.start(m_sequencer);
    endtask
  endclass

  //==========================================================================
  // Legacy directed coverage sequences (kept API)
  //==========================================================================
  class hbm_cov_cmd_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_cov_cmd_seq)
    function new(string name = "hbm_cov_cmd_seq");
      super.new(name);
    endfunction
    task body();
      hbm_seq_item item;
      hbm_seq_item::cmd_type_e cmds[7] = '{hbm_seq_item::ACT, hbm_seq_item::READ, hbm_seq_item::WRITE, hbm_seq_item::PRE, hbm_seq_item::REF, hbm_seq_item::MRS, hbm_seq_item::NOP};
      foreach (cmds[i]) begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == cmds[i]; })
          `uvm_error(get_type_name(), "Rand failed")
        finish_item(item);
      end
    endtask
  endclass : hbm_cov_cmd_seq

  class hbm_cov_ch_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_cov_ch_seq)
    function new(string name = "hbm_cov_ch_seq");
      super.new(name);
    endfunction
    task body();
      for (int c = 0; c < 8; c++) begin
        issue(hbm_seq_item::ACT, 16'h100 * (c + 1), c[2:0], 3'h0);
        issue(hbm_seq_item::WRITE, 16'h0, c[2:0], 3'h0);
        issue(hbm_seq_item::PRE, 16'h0, c[2:0], 3'h0);
      end
    endtask
  endclass : hbm_cov_ch_seq
endpackage : hbm_pkg
