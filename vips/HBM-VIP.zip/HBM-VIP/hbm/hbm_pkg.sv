// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// HBM2/2E/3 UVM VIP Package
// Deepened: timing-accurate command driver (tRCD/tRP/tRAS/tFAW), bus-decoding
// monitor with per-channel bank/page tracking, directed sequence library.
//------------------------------------------------------------------------------
package hbm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // Bank state tracked by the monitor, sampled by functional coverage
  typedef enum {B_IDLE, B_ACTIVE} bank_state_e;

  //==========================================================================
  // HBM Sequence Item
  //==========================================================================
  class hbm_seq_item extends uvm_sequence_item;
    `uvm_object_utils(hbm_seq_item)
    typedef enum {ACT, READ, WRITE, PRE, REF, NOP, MRS, PDE, PDX} cmd_type_e;
    rand cmd_type_e cmd_type;
    rand bit [33:0] addr;
    rand bit [2:0]  cid;     // Channel ID (0-7)
    rand bit [1:0]  bank;
    rand bit [127:0] data[];
    rand bit [15:0]  dm;
    rand bit [4:0]   burst_len;
    bit [127:0]      rdata[];
    rand bit         par;
    // filled in by the monitor
    bit              page_hit;
    bank_state_e     bstate;

    constraint c_cid { cid inside {[0:7]}; }
    constraint c_bank { bank inside {[0:3]}; }
    constraint c_burst_len { burst_len inside {2, 4, 8, 16}; }
    constraint c_data_size { data.size() == burst_len; }
    constraint c_addr_align { cmd_type inside {READ, WRITE} -> addr[3:0] == 4'b0000; }
    function new(string name = "hbm_seq_item");
      super.new(name);
    endfunction
    // rdata is not rand: a size constraint on it would pin burst_len to its
    // current size (0), so it is sized here instead
    function void post_randomize();
      rdata = new[burst_len];
    endfunction
    function string convert2string();
      return $sformatf("HBM %s: ch=%0d bank=%0d addr=0x%0h bl=%0d",
                       cmd_type.name(), cid, bank, addr, burst_len);
    endfunction
  endclass : hbm_seq_item

  //==========================================================================
  // HBM Configuration
  //==========================================================================
  class hbm_cfg extends uvm_object;
    `uvm_object_utils(hbm_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1;
    int tRCD = 14;
    int tRP  = 14;
    int tRAS = 34;
    int tCL  = 14;
    int tCWL = 8;
    int tRRD = 4;
    int tFAW = 16;
    int tCCDS = 2;  // CAS-to-CAS delay (same bank group)
    int tCCDL = 4;  // CAS-to-CAS delay (different bank group)
    int tREFI = 3900;   // average refresh interval, in clocks
    function new(string name = "hbm_cfg");
      super.new(name);
    endfunction
  endclass : hbm_cfg

  //==========================================================================
  // HBM Sequencer
  //==========================================================================
  class hbm_sequencer extends uvm_sequencer #(hbm_seq_item);
    `uvm_component_utils(hbm_sequencer)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
  endclass : hbm_sequencer

  //==========================================================================
  // HBM Driver -- drives per-channel DRAM command sequences on hbm_if with
  // JEDEC-style timing; publishes expected items for the scoreboard.
  //==========================================================================
  class hbm_driver extends uvm_driver #(hbm_seq_item);
    `uvm_component_utils(hbm_driver)
    virtual hbm_if vif;
    hbm_cfg cfg;
    uvm_analysis_port #(hbm_seq_item) drv_ap;  // expected items for scoreboard

    bit          bank_active [32];  // flattened {cid,bank}
    bit [33:0]   active_row  [32];
    int unsigned act_cycle   [32];
    int unsigned act_hist    [4];
    int          act_hist_idx = 0;
    int unsigned cyc = 0;             // clock count, kept by a process of its own
    int unsigned last_act_cyc = 0;   // latest ACT to any bank
    int unsigned last_ref_cyc = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      drv_ap = new("drv_ap", this);
      foreach (bank_active[i]) bank_active[i] = 0;
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual hbm_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "HBM virtual interface not found")
      if (!uvm_config_db#(hbm_cfg)::get(this, "", "cfg", cfg))
        cfg = hbm_cfg::type_id::create("cfg");
    endfunction

    function int bank_id(bit [2:0] cid, bit [1:0] b);
      return cid * 4 + b;
    endfunction

    // With Verilator 5.052 a clocking-block drive issued right after the
    // clock edge lands in the same step, so the command pins were overwritten
    // before any edge sampled them. Drive them directly on the falling edge,
    // hold for one rising edge, then return to deselect.
    task drive_cmd(bit cs_n, bit ras_n, bit cas_n, bit we_n,
                   bit [33:0] a, bit [2:0] cid, bit [1:0] b);
      @(negedge vif.ck);
      vif.cs_n  = cs_n;
      vif.ras_n = ras_n;
      vif.cas_n = cas_n;
      vif.we_n  = we_n;
      vif.addr  = a;
      vif.cid   = cid;
      vif.ba    = b;
      @(posedge vif.ck);
      vif.cs_n  <= 1'b1;
      vif.ras_n <= 1'b1;
      vif.cas_n <= 1'b1;
      vif.we_n  <= 1'b1;
    endtask

    task idle(int n);
      repeat (n) begin
        @(posedge vif.ck);
      end
    endtask

    // A command the driver adds on its own, as a memory controller does
    // (open a closed bank, close an open one, refresh in time): it goes on
    // the expected stream like any sequence item.
    function void expect_cmd(hbm_seq_item::cmd_type_e c, bit [33:0] a, bit [2:0] ch, bit [1:0] b);
      hbm_seq_item e = hbm_seq_item::type_id::create("auto");
      e.cmd_type = c; e.addr = a; e.cid = ch; e.bank = b;
      `uvm_info(get_type_name(), $sformatf("Controller adds: %s", e.convert2string()), UVM_HIGH)
      drv_ap.write(e);
    endfunction

    task activate(bit [33:0] row, bit [2:0] ch, bit [1:0] b);
      int id = bank_id(ch, b);
      if (bank_active[id]) begin        // ACT to an open bank: close it first
        precharge(ch, b, 34'h0);
        expect_cmd(hbm_seq_item::PRE, 34'h0, ch, b);
      end
      while (cyc - act_hist[act_hist_idx] <= cfg.tFAW && act_hist[act_hist_idx] != 0)
        idle(1);                        // tFAW window
      drive_cmd(0, 0, 1, 1, row, ch, b);
      active_row[id]  = row;
      bank_active[id] = 1;
      act_cycle[id]   = cyc;
      last_act_cyc    = cyc;
      act_hist[act_hist_idx] = cyc;
      act_hist_idx = (act_hist_idx + 1) % 4;
      idle(cfg.tRCD - 1);               // tRCD before any CAS
    endtask

    task precharge(bit [2:0] ch, bit [1:0] b, bit [33:0] a);
      while (cyc - last_act_cyc < cfg.tRAS)
        idle(1);                        // tRAS: earliest legal PRE after ACT
      drive_cmd(0, 0, 1, 0, a, ch, b);
      bank_active[bank_id(ch, b)] = 0;
      idle(cfg.tRP - 1);                // tRP before re-activation
    endtask

    // RD/WR to a closed bank: open a row first
    task ensure_open(hbm_seq_item item);
      if (!bank_active[bank_id(item.cid, item.bank)]) begin
        activate(34'h0, item.cid, item.bank);
        expect_cmd(hbm_seq_item::ACT, 34'h0, item.cid, item.bank);
      end
    endtask

    // Close every open bank (before REF), all after tRAS of the latest ACT
    task precharge_all();
      bit any = 0;
      while (cyc - last_act_cyc < cfg.tRAS)
        idle(1);
      foreach (bank_active[i])
        if (bank_active[i]) begin
          drive_cmd(0, 0, 1, 0, 34'h0, i / 4, i % 4);
          bank_active[i] = 0;
          expect_cmd(hbm_seq_item::PRE, 34'h0, i / 4, i % 4);
          any = 1;
        end
      if (any) idle(cfg.tRP - 1);
    endtask

    // Refresh before tREFI runs out, then reopen the rows that were open
    task refresh_if_due();
      bit        was_open[32];
      bit [33:0] rows[32];
      if (cyc - last_ref_cyc + 300 < cfg.tREFI) return;
      foreach (bank_active[i]) begin was_open[i] = bank_active[i]; rows[i] = active_row[i]; end
      precharge_all();
      drive_cmd(0, 0, 0, 1, 34'h0, 3'h0, 2'h0);
      last_ref_cyc = cyc;
      expect_cmd(hbm_seq_item::REF, 34'h0, 3'h0, 2'h0);
      idle(cfg.tRAS - 1);               // tRFC
      foreach (was_open[i])
        if (was_open[i]) begin
          activate(rows[i], i / 4, i % 4);
          expect_cmd(hbm_seq_item::ACT, rows[i], i / 4, i % 4);
        end
    endtask

    task drive_activate(hbm_seq_item item);
      activate(item.addr, item.cid, item.bank);
    endtask

    task drive_read(hbm_seq_item item);
      int id = bank_id(item.cid, item.bank);
      ensure_open(item);
      drive_cmd(0, 1, 0, 1, item.addr, item.cid, item.bank);
      idle(cfg.tCL);                    // CAS latency
      item.rdata = new[item.burst_len];
      for (int i = 0; i < item.burst_len; i++) begin
        @(vif.drv_cb);
        item.rdata[i] = vif.drv_cb.dq;  // sample read data burst
      end
    endtask

    task drive_write(hbm_seq_item item);
      int id = bank_id(item.cid, item.bank);
      ensure_open(item);
      drive_cmd(0, 1, 0, 0, item.addr, item.cid, item.bank);
      idle(cfg.tCWL - 1);               // CAS write latency
      for (int i = 0; i < item.burst_len; i++) begin
        vif.drv_cb.dq <= item.data[i];
        vif.drv_cb.dm <= item.dm;
        @(vif.drv_cb);
      end
      vif.drv_cb.dm <= '0;              // the mask belongs to the write burst only
    endtask

    task drive_precharge(hbm_seq_item item);
      precharge(item.cid, item.bank, item.addr);
    endtask

    task drive_refresh(hbm_seq_item item);
      precharge_all();                  // REF needs every bank idle
      drive_cmd(0, 0, 0, 1, item.addr, item.cid, item.bank);
      last_ref_cyc = cyc;
      idle(cfg.tRAS - 1);               // tRFC
    endtask

    task drive_mrs(hbm_seq_item item);
      drive_cmd(0, 0, 0, 0, item.addr, item.cid, item.bank);
      idle(4);                          // tMOD
    endtask

    task drive_pde(hbm_seq_item item);
      @(vif.drv_cb);
      vif.drv_cb.cke <= 1'b0;
    endtask

    task drive_pdx(hbm_seq_item item);
      @(vif.drv_cb);
      vif.drv_cb.cke <= 1'b1;
      idle(5);
    endtask

    task run_phase(uvm_phase phase);
      vif.cs_n = 1'b1; vif.ras_n = 1'b1; vif.cas_n = 1'b1; vif.we_n = 1'b1;
      fork forever begin @(posedge vif.ck); cyc++; end join_none
      vif.cke = 1'b1;                   // clock enabled (PDE / PDX change it)
      vif.addr = '0; vif.cid = '0; vif.ba = '0; vif.dm = '0;   // known while idle
      idle(1);
      wait (vif.rst_n === 1'b1);
      idle(5);
      forever begin
        seq_item_port.get_next_item(req);
        // re-align to the clock: an item handed over after the clocking
        // event made the command drive land on the same edge as the idle()
        // that follows it, so ACT / RD / WR never reached the pins
        @(vif.drv_cb);
        `uvm_info(get_type_name(), $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
        if (vif.cke === 1'b1) refresh_if_due();
        case (req.cmd_type)
          hbm_seq_item::ACT:   drive_activate(req);
          hbm_seq_item::READ:  drive_read(req);
          hbm_seq_item::WRITE: drive_write(req);
          hbm_seq_item::PRE:   drive_precharge(req);
          hbm_seq_item::REF:   drive_refresh(req);
          hbm_seq_item::MRS:   drive_mrs(req);
          hbm_seq_item::PDE:   drive_pde(req);
          hbm_seq_item::PDX:   drive_pdx(req);
          hbm_seq_item::NOP:   idle(1);
        endcase
        if (req.cmd_type != hbm_seq_item::NOP && req.cmd_type != hbm_seq_item::PDE && req.cmd_type != hbm_seq_item::PDX)
          drv_ap.write(req);            // broadcast expected transaction
        seq_item_port.item_done();
      end
    endtask
  endclass : hbm_driver

  //==========================================================================
  // HBM Monitor -- decodes commands from the CA bus waveform, tracks
  // per-channel bank state and page hit/miss.
  //==========================================================================
  class hbm_monitor extends uvm_monitor;
    `uvm_component_utils(hbm_monitor)
    virtual hbm_if vif;
    uvm_analysis_port #(hbm_seq_item) item_collected_port;
    int unsigned txn_count = 0;

    protected bit        bank_active [32];
    protected bit [33:0] active_row  [32];
    protected bit        accessed    [32];   // row read/written since its ACT

    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual hbm_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "HBM virtual interface not found")
    endfunction

    function int bank_id(bit [2:0] cid, bit [1:0] b);
      return cid * 4 + b;
    endfunction

    task run_phase(uvm_phase phase);
      hbm_seq_item item;
      int id;
      forever begin
        @(vif.mon_cb);
        if (vif.rst_n !== 1'b1) begin
          foreach (bank_active[i]) bank_active[i] = 0;
          continue;
        end
        if (vif.mon_cb.cs_n) continue;  // deselect
        item = hbm_seq_item::type_id::create("item");
        if (!vif.mon_cb.ras_n && vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::ACT;
        else if (vif.mon_cb.ras_n && !vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::READ;
        else if (vif.mon_cb.ras_n && !vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::WRITE;
        else if (!vif.mon_cb.ras_n && vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::PRE;
        else if (!vif.mon_cb.ras_n && !vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = hbm_seq_item::REF;
        else
          item.cmd_type = hbm_seq_item::MRS;
        item.cid      = vif.mon_cb.cid;
        item.bank     = vif.mon_cb.ba;
        item.addr     = vif.mon_cb.addr;
        item.page_hit = 1'b0;
        id = bank_id(vif.mon_cb.cid, vif.mon_cb.ba);
        case (item.cmd_type)
          hbm_seq_item::ACT: begin
            item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
            bank_active[id] = 1;
            active_row[id]  = vif.mon_cb.addr;
            accessed[id]    = 0;
          end
          hbm_seq_item::READ, hbm_seq_item::WRITE: begin
            item.bstate   = bank_active[id] ? B_ACTIVE : B_IDLE;
            // page hit: the open row was accessed before; miss: first access after ACT
            item.page_hit = bank_active[id] && accessed[id];
            accessed[id]  = 1;
          end
          hbm_seq_item::PRE: begin
            item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
            bank_active[id] = 0;
          end
          hbm_seq_item::REF: begin
            item.bstate = B_IDLE;
            foreach (bank_active[i]) bank_active[i] = 0;
          end
          default: item.bstate = B_IDLE;
        endcase
        txn_count++;
        item_collected_port.write(item);
        `uvm_info(get_type_name(), $sformatf("Monitored: %s", item.convert2string()), UVM_MEDIUM)
      end
    endtask

    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(),
        $sformatf("HBM monitor observed %0d transactions", txn_count), UVM_LOW)
    endfunction
  endclass : hbm_monitor

  //==========================================================================
  // HBM Agent
  //==========================================================================
  class hbm_agent extends uvm_agent;
    `uvm_component_utils(hbm_agent)
    hbm_sequencer sqr;
    hbm_driver    drv;
    hbm_monitor   mon;
    hbm_cfg       cfg;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(hbm_cfg)::get(this, "", "cfg", cfg))
        cfg = hbm_cfg::type_id::create("cfg");
      mon = hbm_monitor::type_id::create("mon", this);
      if (cfg.is_active == UVM_ACTIVE) begin
        sqr = hbm_sequencer::type_id::create("sqr", this);
        drv = hbm_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.is_active == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass : hbm_agent

  //==========================================================================
  // Directed sequence library (normal R/W, refresh, bank conflict,
  // back-to-back, page hit/miss corner cases, stress, regression)
  //==========================================================================
  class hbm_base_seq extends uvm_sequence #(hbm_seq_item);
    `uvm_object_utils(hbm_base_seq)
    rand int num_trans = 20;
    rand bit [15:0] row;
    rand bit [15:0] col;
    rand bit [2:0]  chan_n;
    rand bit [2:0]  bank_n;
    rand bit        rd_not_wr;
    // READ / WRITE items need addr[3:0] == 0 (hbm_seq_item c_addr_align);
    // col[3] set made those randomize() calls fail and send a default ACT
    constraint c_col { col[3:0] == 4'b0000; }
    constraint c_bankn { bank_n <= 3; }
    function new(string name = "hbm_base_seq");
      super.new(name);
    endfunction
    // issue one command item with explicit geometry
    task issue(hbm_seq_item::cmd_type_e c, bit [15:0] a, bit [2:0] ch, bit [2:0] b);
      hbm_seq_item item = hbm_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { cmd_type == c; addr == a; cid == ch; bank == b[1:0]; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    endtask
    // random-but-legal ACT -> RD/WR -> PRE rounds, REF every 8th round
    task body();
      for (int i = 0; i < num_trans; i++) begin
        if (!(this.randomize(row, col, chan_n, bank_n, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
        if (i % 8 == 7) issue(hbm_seq_item::REF, 16'h0, 3'h0, 3'h0);
        issue(hbm_seq_item::ACT, row, chan_n, bank_n);
        issue(rd_not_wr ? hbm_seq_item::READ : hbm_seq_item::WRITE, col, chan_n, bank_n);
        issue(hbm_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // Legacy random read/write mix (kept API): legal rounds
  class hbm_rw_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_rw_seq)
    function new(string name = "hbm_rw_seq");
      super.new(name);
      num_trans = 30;
    endfunction
  endclass

  // 1) Directed: write rounds (normal write traffic)
  class hbm_write_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_write_seq)
    function new(string name = "hbm_write_seq");
      super.new(name);
    endfunction
    constraint c_wr { rd_not_wr == 0; }
  endclass

  // 2) Directed: read rounds (normal read traffic)
  class hbm_read_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_read_seq)
    function new(string name = "hbm_read_seq");
      super.new(name);
    endfunction
    constraint c_rd { rd_not_wr == 1; }
  endclass

  // 3) Directed: refresh traffic
  class hbm_refresh_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_refresh_seq)
    function new(string name = "hbm_refresh_seq");
      super.new(name);
    endfunction
    task body();
      for (int i = 0; i < num_trans; i++)
        issue(hbm_seq_item::REF, 16'h0, 3'h0, 3'h0);
    endtask
  endclass

  // 4) Directed: bank conflict -- repeated ACT to the SAME bank forces
  //    PRE/ACT turnaround (tRP + tRCD pressure)
  class hbm_bank_conflict_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_bank_conflict_seq)
    function new(string name = "hbm_bank_conflict_seq");
      super.new(name);
    endfunction
    task body();
      hbm_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a hbm_base_seq handle
      bit [15:0] crow = 16'h0100;
      if (!(rnd_h.randomize(chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
      for (int i = 0; i < num_trans; i++) begin
        issue(hbm_seq_item::ACT, crow, chan_n, bank_n);
        issue(hbm_seq_item::WRITE, 16'h0, chan_n, bank_n);
        issue(hbm_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h100;
      end
    endtask
  endclass

  // 5) Directed: back-to-back accesses across 4 banks (no PRE between)
  class hbm_back_to_back_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_back_to_back_seq)
    function new(string name = "hbm_back_to_back_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h2000;
      for (int i = 0; i < num_trans; i++) begin
        for (int b = 0; b < 4; b++)
          issue(hbm_seq_item::ACT, crow, chan_n, b[2:0]);
        for (int b = 0; b < 4; b++) begin
          issue(hbm_seq_item::WRITE, 16'h0, chan_n, b[2:0]);
          issue(hbm_seq_item::READ, 16'h0, chan_n, b[2:0]);
        end
        for (int b = 0; b < 4; b++)
          issue(hbm_seq_item::PRE, 16'h0, chan_n, b[2:0]);
        crow = crow + 16'h400;
      end
    endtask
  endclass

  // 6) Corner case: page hit -- one ACT, many RD/WR to the SAME open row
  class hbm_page_hit_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_page_hit_seq)
    function new(string name = "hbm_page_hit_seq");
      super.new(name);
    endfunction
    task body();
      hbm_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a hbm_base_seq handle
      for (int i = 0; i < num_trans; i++) begin
        if (!(rnd_h.randomize(row, chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
        issue(hbm_seq_item::ACT, row, chan_n, bank_n);
        for (int k = 0; k < 4; k++) begin
          if (!(rnd_h.randomize(col, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
          issue(rd_not_wr ? hbm_seq_item::READ : hbm_seq_item::WRITE, col, chan_n, bank_n);
        end
        issue(hbm_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // 7) Corner case: page miss -- every access targets a different row
  class hbm_page_miss_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_page_miss_seq)
    function new(string name = "hbm_page_miss_seq");
      super.new(name);
    endfunction
    task body();
      hbm_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a hbm_base_seq handle
      bit [15:0] crow = 16'h0;
      if (!(rnd_h.randomize(chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
      for (int i = 0; i < num_trans; i++) begin
        if (!(rnd_h.randomize(col, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
        issue(hbm_seq_item::ACT, crow, chan_n, bank_n);
        issue(rd_not_wr ? hbm_seq_item::READ : hbm_seq_item::WRITE, col, chan_n, bank_n);
        issue(hbm_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h311;
      end
    endtask
  endclass

  // 8) Stress: long legal mix of rounds
  class hbm_stress_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_stress_seq)
    function new(string name = "hbm_stress_seq");
      super.new(name);
      num_trans = 200;
    endfunction
  endclass

  // Regression: weighted mix of every directed sequence
  class hbm_regression_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_regression_seq)
    function new(string name = "hbm_regression_seq");
      super.new(name);
    endfunction
    task body();
      hbm_write_seq         wr   = hbm_write_seq::type_id::create("wr");
      hbm_read_seq          rd   = hbm_read_seq::type_id::create("rd");
      hbm_refresh_seq       refs = hbm_refresh_seq::type_id::create("refs");
      hbm_bank_conflict_seq bc   = hbm_bank_conflict_seq::type_id::create("bc");
      hbm_back_to_back_seq  b2b  = hbm_back_to_back_seq::type_id::create("b2b");
      hbm_page_hit_seq      hit  = hbm_page_hit_seq::type_id::create("hit");
      hbm_page_miss_seq     miss = hbm_page_miss_seq::type_id::create("miss");
      wr.num_trans   = 10; rd.num_trans   = 10;
      refs.num_trans = 4;  bc.num_trans   = 5;
      b2b.num_trans  = 4;  hit.num_trans  = 4;
      miss.num_trans = 5;
      wr.start(m_sequencer);
      rd.start(m_sequencer);
      hit.start(m_sequencer);
      miss.start(m_sequencer);
      bc.start(m_sequencer);
      b2b.start(m_sequencer);
      refs.start(m_sequencer);
    endtask
  endclass

  //==========================================================================
  // Legacy directed coverage sequences (kept API)
  //==========================================================================
  class hbm_cov_cmd_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_cov_cmd_seq)
    function new(string name = "hbm_cov_cmd_seq");
      super.new(name);
    endfunction
    task body();
      hbm_seq_item item;
      hbm_seq_item::cmd_type_e cmds[7] = '{hbm_seq_item::ACT, hbm_seq_item::READ, hbm_seq_item::WRITE, hbm_seq_item::PRE, hbm_seq_item::REF, hbm_seq_item::MRS, hbm_seq_item::NOP};
      foreach (cmds[i]) begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == cmds[i]; })
          `uvm_error(get_type_name(), "Rand failed")
        finish_item(item);
      end
    endtask
  endclass : hbm_cov_cmd_seq

  class hbm_cov_ch_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_cov_ch_seq)
    function new(string name = "hbm_cov_ch_seq");
      super.new(name);
    endfunction
    task body();
      for (int c = 0; c < 8; c++) begin
        issue(hbm_seq_item::ACT, 16'h100 * (c + 1), c[2:0], 3'h0);
        issue(hbm_seq_item::WRITE, 16'h0, c[2:0], 3'h0);
        issue(hbm_seq_item::PRE, 16'h0, c[2:0], 3'h0);
      end
    endtask
  endclass : hbm_cov_ch_seq
endpackage : hbm_pkg
