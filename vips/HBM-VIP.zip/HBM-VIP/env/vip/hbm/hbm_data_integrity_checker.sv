// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// HBM Data Integrity Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef HBM_DATA_INTEGRITY_CHECKER_SV
`define HBM_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module hbm_data_integrity_checker (hbm_if vif);

  property p_hbm_data_valid; @(posedge vif.ck) disable iff (!vif.rst_n) (|vif.dqs) == 1'b1 |-> !$isunknown(vif.dq); endproperty
  assert_p_hbm_data_valid: assert property(p_hbm_data_valid) else `uvm_warning("HBM_DI", "Data valid on RW failed");
  cover_p_hbm_data_valid: cover property(p_hbm_data_valid);
  property p_hbm_temp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp <= 8'd127; endproperty
  assert_p_hbm_temp: assert property(p_hbm_temp) else `uvm_warning("HBM_DI", "Temperature valid failed");
  cover_p_hbm_temp: cover property(p_hbm_temp);

endmodule : hbm_data_integrity_checker
`endif
