// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// HBM Protocol Compliance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef HBM_PROTOCOL_CHECKER_SV
`define HBM_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module hbm_protocol_checker (hbm_if vif);

  property p_hbm_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_hbm_cmd_valid: assert property(p_hbm_cmd_valid) else `uvm_warning("HBM_CHK", "Command valid failed");
  cover_p_hbm_cmd_valid: cover property(p_hbm_cmd_valid);
  property p_hbm_pseudo_ch; @(posedge vif.ck) disable iff (!vif.rst_n) !$isunknown(vif.pseudo_ch); endproperty
  assert_p_hbm_pseudo_ch: assert property(p_hbm_pseudo_ch) else `uvm_warning("HBM_CHK", "Pseudo channel valid failed");
  cover_p_hbm_pseudo_ch: cover property(p_hbm_pseudo_ch);
  property p_hbm_stack_id; @(posedge vif.ck) disable iff (!vif.rst_n) !$isunknown(vif.stack_id); endproperty
  assert_p_hbm_stack_id: assert property(p_hbm_stack_id) else `uvm_warning("HBM_CHK", "Stack ID valid failed");
  cover_p_hbm_stack_id: cover property(p_hbm_stack_id);
  property p_hbm_dbis; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dbis == 1 |-> !$isunknown(vif.dq); endproperty
  assert_p_hbm_dbis: assert property(p_hbm_dbis) else `uvm_warning("HBM_CHK", "DBI/DM without write data");
  cover_p_hbm_dbis: cover property(p_hbm_dbis);

endmodule : hbm_protocol_checker
`endif
