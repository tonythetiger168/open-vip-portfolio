// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// HBM Error Handling Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef HBM_ERROR_CHECKER_SV
`define HBM_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module hbm_error_checker (hbm_if vif);

  property p_hbm_reset; @(posedge vif.ck) disable iff (!vif.rst_n) vif.rst_n == 0 |-> ##[100:200] vif.rst_n == 1; endproperty
  assert_p_hbm_reset: assert property(p_hbm_reset) else `uvm_warning("HBM_ERR", "Reset stable failed");
  cover_p_hbm_reset: cover property(p_hbm_reset);
  property p_hbm_overtemp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp > 8'd85 |-> vif.cs_n == 1; endproperty
  assert_p_hbm_overtemp: assert property(p_hbm_overtemp) else `uvm_warning("HBM_ERR", "Overtemp protection failed");
  cover_p_hbm_overtemp: cover property(p_hbm_overtemp);

endmodule : hbm_error_checker
`endif
