// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// HBM Timing & Performance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef HBM_TIMING_CHECKER_SV
`define HBM_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module hbm_timing_checker (hbm_if vif);

  property p_hbm_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cs_n) |-> ##[2:6] vif.addr[4] == 0; endproperty
  assert_p_hbm_tRCD: assert property(p_hbm_tRCD) else `uvm_warning("HBM_TIM", "tRCD timing violated");
  cover_p_hbm_tRCD: cover property(p_hbm_tRCD);
  property p_hbm_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.cs_n) |-> ##[2:6] $fell(vif.cs_n); endproperty
  assert_p_hbm_tRP: assert property(p_hbm_tRP) else `uvm_warning("HBM_TIM", "tRP timing violated");
  cover_p_hbm_tRP: cover property(p_hbm_tRP);

endmodule : hbm_timing_checker
`endif
