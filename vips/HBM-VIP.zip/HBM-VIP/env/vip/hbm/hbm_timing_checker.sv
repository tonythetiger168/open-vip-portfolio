// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// HBM Timing & Performance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef HBM_TIMING_CHECKER_SV
`define HBM_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module hbm_timing_checker (hbm_if vif);
  wire is_act = !vif.cs_n && !vif.ras_n &&  vif.cas_n &&  vif.we_n;
  wire is_cas = !vif.cs_n &&  vif.ras_n && !vif.cas_n;
  wire is_pre_c = !vif.cs_n && !vif.ras_n &&  vif.cas_n && !vif.we_n;
  localparam int TRCD = 14, TRP = 14;   // hbm_cfg defaults

  property p_hbm_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) is_act |=> !is_cas [*TRCD-1]; endproperty
  assert_p_hbm_tRCD: assert property(p_hbm_tRCD) else `uvm_warning("HBM_TIM", "tRCD timing violated");
  cover_p_hbm_tRCD: cover property(p_hbm_tRCD);
  property p_hbm_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) is_pre_c |=> !is_act [*TRP-1]; endproperty
  assert_p_hbm_tRP: assert property(p_hbm_tRP) else `uvm_warning("HBM_TIM", "tRP timing violated");
  cover_p_hbm_tRP: cover property(p_hbm_tRP);

endmodule : hbm_timing_checker
`endif
