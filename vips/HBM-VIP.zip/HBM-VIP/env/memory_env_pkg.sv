// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// Memory UVM Environment Package (HBM deepened with end-to-end scoreboard)
//------------------------------------------------------------------------------
package memory_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import ddr_pkg::*;
  import lpddr_pkg::*;
  import hbm_pkg::*;
  import ufs_pkg::*;
  import unipro_pkg::*;
  import emmc_pkg::*;
  import onfi_pkg::*;
  import sd_pkg::*;
  import memory_coverage_pkg::*;

  `uvm_analysis_imp_decl(_hbm_exp)
  `uvm_analysis_imp_decl(_hbm_data)
  `uvm_analysis_imp_decl(_ddr)
  `uvm_analysis_imp_decl(_lpddr)
  `uvm_analysis_imp_decl(_ufs)
  `uvm_analysis_imp_decl(_unipro)
  `uvm_analysis_imp_decl(_emmc)
  `uvm_analysis_imp_decl(_onfi)
  `uvm_analysis_imp_decl(_sd)

  class memory_env_cfg extends uvm_object;
    `uvm_object_utils(memory_env_cfg)
    ddr_cfg ddr_cfg_h;
    lpddr_cfg lpddr_cfg_h;
    hbm_cfg hbm_cfg_h;
    ufs_cfg ufs_cfg_h;
    unipro_cfg unipro_cfg_h;
    emmc_cfg emmc_cfg_h;
    onfi_cfg onfi_cfg_h;
    sd_cfg sd_cfg_h;
    bit scoreboard_enable = 1;
    bit coverage_enable = 1;
    int num_ddr = 30;
    int num_lpddr = 30;
    int num_hbm = 30;
    int num_ufs = 20;
    int num_unipro = 20;
    int num_emmc = 20;
    int num_onfi = 20;
    int num_sd = 20;
    function new(string name = "memory_env_cfg");
      super.new(name);
      ddr_cfg_h = ddr_cfg::type_id::create("ddr_cfg_h");
      lpddr_cfg_h = lpddr_cfg::type_id::create("lpddr_cfg_h");
      hbm_cfg_h = hbm_cfg::type_id::create("hbm_cfg_h");
      ufs_cfg_h = ufs_cfg::type_id::create("ufs_cfg_h");
      unipro_cfg_h = unipro_cfg::type_id::create("unipro_cfg_h");
      emmc_cfg_h = emmc_cfg::type_id::create("emmc_cfg_h");
      onfi_cfg_h = onfi_cfg::type_id::create("onfi_cfg_h");
      sd_cfg_h = sd_cfg::type_id::create("sd_cfg_h");
    endfunction
  endclass

  // End-to-end scoreboard. For HBM the driver-issued (expected) stream is
  // compared against the monitor-decoded (observed) stream; other protocol
  // exports keep their observation counters.
  class memory_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(memory_scoreboard)
    uvm_analysis_imp_ddr #(ddr_seq_item, memory_scoreboard) ddr_export;
    uvm_analysis_imp_lpddr #(lpddr_seq_item, memory_scoreboard) lpddr_export;
    uvm_analysis_imp #(hbm_seq_item, memory_scoreboard) hbm_export;
    uvm_analysis_imp_ufs #(ufs_seq_item, memory_scoreboard) ufs_export;
    uvm_analysis_imp_unipro #(unipro_seq_item, memory_scoreboard) unipro_export;
    uvm_analysis_imp_emmc #(emmc_seq_item, memory_scoreboard) emmc_export;
    uvm_analysis_imp_onfi #(onfi_seq_item, memory_scoreboard) onfi_export;
    uvm_analysis_imp_sd #(sd_seq_item, memory_scoreboard) sd_export;
    // HBM expected (driver) stream
    uvm_analysis_imp_hbm_exp #(hbm_seq_item, memory_scoreboard) hbm_exp_export;
    // HBM read-data check: the monitor's RD / WR bursts (data seen on DQ)
    uvm_analysis_imp_hbm_data #(hbm_seq_item, memory_scoreboard) hbm_data_export;
    // shadow memory of every written beat, {channel, bank, row, column} -> data;
    // beat i of a burst at column c is column c + 8*i (the device model's
    // burst-to-column contract, see tb_top.sv)
    bit [127:0] shadow [bit [36:0]];
    int unsigned n_data_checks = 0, n_data_errs = 0, n_wr_bursts = 0, n_rd_bursts = 0;

    int ddr_count = 0, lpddr_count = 0, hbm_count = 0, ufs_count = 0;
    int unipro_count = 0, emmc_count = 0, onfi_count = 0, sd_count = 0;

    // HBM end-to-end comparison state
    hbm_seq_item exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      ddr_export = new("ddr_export", this);
      lpddr_export = new("lpddr_export", this);
      hbm_export = new("hbm_export", this);
      ufs_export = new("ufs_export", this);
      unipro_export = new("unipro_export", this);
      emmc_export = new("emmc_export", this);
      onfi_export = new("onfi_export", this);
      sd_export = new("sd_export", this);
      hbm_exp_export = new("hbm_exp_export", this);
      hbm_data_export = new("hbm_data_export", this);
    endfunction

    virtual function void write_ddr(ddr_seq_item item);
      ddr_count++;
      
    endfunction
    virtual function void write_lpddr(lpddr_seq_item item);
      lpddr_count++;
      
    endfunction
    virtual function void write(hbm_seq_item item);
      hbm_count++;
      obs_q.push_back(item); check();
    endfunction
    virtual function void write_ufs(ufs_seq_item item);    ufs_count++;    endfunction
    virtual function void write_unipro(unipro_seq_item item); unipro_count++; endfunction
    virtual function void write_emmc(emmc_seq_item item);   emmc_count++;   endfunction
    virtual function void write_onfi(onfi_seq_item item);   onfi_count++;   endfunction
    virtual function void write_sd(sd_seq_item item);     sd_count++;     endfunction

    // HBM expected stream (from hbm_driver.drv_ap)
    function void write_hbm_exp(hbm_seq_item item);
      exp_q.push_back(item);
      check();
    endfunction

    function bit [36:0] dkey(hbm_seq_item t, int i);
      bit [15:0] col = t.addr[15:0] + 16'(8 * i);
      return {t.cid, t.bank, t.row, col};
    endfunction

    function void write_hbm_data(hbm_seq_item t);
      if (t.cmd_type == hbm_seq_item::WRITE) begin
        n_wr_bursts++;
        foreach (t.data[i]) shadow[dkey(t, i)] = t.data[i];
      end else begin
        n_rd_bursts++;
        // a beat never written has no defined value: only written beats are checked
        foreach (t.rdata[i])
          if (shadow.exists(dkey(t, i))) begin
            n_data_checks++;
            if (t.rdata[i] !== shadow[dkey(t, i)]) begin
              n_data_errs++;
              `uvm_error("SB_DATA", $sformatf("HBM read data mismatch ch=%0d bank=%0d row=0x%0h col=0x%0h beat %0d: exp 0x%h got 0x%h",
                         t.cid, t.bank, t.row, t.addr[15:0], i, shadow[dkey(t, i)], t.rdata[i]))
            end
          end
      end
    endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        hbm_seq_item e = exp_q.pop_front();
        hbm_seq_item o = obs_q.pop_front();
        if (compare_hbm(e, o))
          n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("HBM mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function bit compare_hbm(hbm_seq_item e, hbm_seq_item o);
      return (e.cmd_type == o.cmd_type) && (e.addr == o.addr) && (e.bank == o.bank) && (e.cid == o.cid);
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
      `uvm_info(get_type_name(), "  MEMORY SCOREBOARD REPORT", UVM_LOW)
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("DDR:    %0d", ddr_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("LPDDR:  %0d", lpddr_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("HBM:    %0d", hbm_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("UFS:    %0d", ufs_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("UniPro: %0d", unipro_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("eMMC:   %0d", emmc_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("ONFI:   %0d", onfi_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("SD:     %0d", sd_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf(
        "HBM end-to-end: n_matches=%0d n_mismatches=%0d",
        n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches)
        `uvm_error(get_type_name(), "HBM end-to-end n_mismatches detected")
      `uvm_info(get_type_name(), $sformatf(
        "HBM read data: %0d write / %0d read bursts, %0d beats checked, %0d wrong",
        n_wr_bursts, n_rd_bursts, n_data_checks, n_data_errs), UVM_LOW)
      // the data-integrity sequence reads back only what it wrote: each of
      // those beats must have reached the check (a monitor that samples DQ
      // on the wrong clock, or drops bursts, fails here)
      if (n_data_checks < hbm_data_seq::exp_checks)
        `uvm_error("SB_DATA", $sformatf("HBM read data: %0d beats checked, the data sequence needs %0d",
                   n_data_checks, hbm_data_seq::exp_checks))
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
    endfunction
  endclass

  class memory_env extends uvm_env;
    `uvm_component_utils(memory_env)
    ddr_agent ddr_ag;
    lpddr_agent lpddr_ag;
    hbm_agent hbm_ag;
    ufs_agent ufs_ag;
    unipro_agent unipro_ag;
    emmc_agent emmc_ag;
    onfi_agent onfi_ag;
    sd_agent sd_ag;
    ddr_coverage ddr_cov;
    lpddr_coverage lpddr_cov;
    hbm_coverage hbm_cov;
    ufs_coverage ufs_cov;
    unipro_coverage unipro_cov;
    emmc_coverage emmc_cov;
    onfi_coverage onfi_cov;
    sd_coverage sd_cov;
    memory_coverage_report_checker cov_chk;
    memory_scoreboard sb;
    memory_env_cfg cfg;

    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(memory_env_cfg)::get(this, "", "cfg", cfg))
        cfg = memory_env_cfg::type_id::create("cfg");
      hbm_ag = hbm_agent::type_id::create("hbm_ag", this);
      if (cfg.coverage_enable) begin
        hbm_cov = hbm_coverage::type_id::create("hbm_cov", this);
        cov_chk = memory_coverage_report_checker::type_id::create("cov_chk", this);
      end
      if (cfg.scoreboard_enable)
        sb = memory_scoreboard::type_id::create("sb", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.scoreboard_enable) begin
        // HBM end-to-end: driver (expected) + monitor (observed)
        hbm_ag.drv.drv_ap.connect(sb.hbm_exp_export);
        hbm_ag.mon.item_collected_port.connect(sb.hbm_export);
        hbm_ag.mon.data_port.connect(sb.hbm_data_export);
      end
      if (cfg.coverage_enable) begin
        hbm_ag.mon.item_collected_port.connect(hbm_cov.analysis_export);
        cov_chk.hbm_cov_h = hbm_cov;
      end
    endfunction
  endclass
endpackage : memory_env_pkg
