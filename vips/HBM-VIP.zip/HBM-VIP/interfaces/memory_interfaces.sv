// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// Memory/Storage Protocol Interfaces with UVM Clocking Blocks
// 9 Protocols: DDR4/5, LPDDR4/5/6, HBM2/2E/3, UFS, UniPro, eMMC, ONFI, SD/SDIO
//------------------------------------------------------------------------------
interface ddr_if #(
  parameter ADDR_WIDTH = 17,
  parameter DATA_WIDTH = 64,
  parameter DQ_WIDTH   = 64,
  parameter DQS_WIDTH  = 8
)(
  input logic ck,
  input logic ck_n,
  input logic rst_n
);
  // Command/Address
  logic [ADDR_WIDTH-1:0] addr;
  logic [2:0]            ba;      // Bank address
  logic [1:0]            bg;      // Bank group (DDR5)
  logic                  ras_n;   // Row address strobe
  logic                  cas_n;   // Column address strobe
  logic                  we_n;    // Write enable
  logic                  cs_n;    // Chip select
  logic                  cke;     // Clock enable
  logic                  odt;     // On-die termination
  logic                  act_n;   // Activation command (DDR4)
  // Data
  logic [DQ_WIDTH-1:0]   dq;
  logic [DQS_WIDTH-1:0]  dqs;
  logic [DQS_WIDTH-1:0]  dqs_n;
  logic [DATA_WIDTH/8-1:0] dm;    // Data mask
  // Timing parameters (for VIP reference)
  int tRCD = 15;  // RAS to CAS delay
  int tRP  = 15;  // Row precharge time
  int tRAS = 35;  // Row active time
  int tRC  = 50;  // Row cycle time
  int tCL  = 15;  // CAS latency
  int tCWL = 14;  // CAS write latency

  clocking drv_cb @(posedge ck);
    default input #0.5 output #0.5;
    output addr, ba, bg, ras_n, cas_n, we_n, cs_n, cke, odt, act_n;
    inout  dq, dqs, dqs_n, dm;
  endclocking

  clocking mon_cb @(posedge ck);
    default input #0.5 output #0.5;
    input addr, ba, bg, ras_n, cas_n, we_n, cs_n, cke, odt, act_n;
    input dq, dqs, dqs_n, dm;
  endclocking

  modport driver  (clocking drv_cb, input ck, ck_n, rst_n);
  modport monitor (clocking mon_cb, input ck, ck_n, rst_n);
endinterface : ddr_if

interface lpddr_if #(
  parameter ADDR_WIDTH = 16,
  parameter DATA_WIDTH = 32,
  parameter CA_WIDTH   = 6
)(
  input logic ck,
  input logic ck_n,
  input logic cke,
  input logic rst_n
);
  // Command/Address (CA bus is shared)
  logic [CA_WIDTH-1:0] ca;
  logic                cs;   // Chip select
  // Data
  logic [DATA_WIDTH-1:0]   dq;
  logic [DATA_WIDTH/8-1:0] dqs;
  logic [DATA_WIDTH/8-1:0] dqs_n;
  logic [DATA_WIDTH/8-1:0] dm;
  // LPDDR-specific signals
  logic                  dmi;   // Data mask/inversion
  // Timing
  int tRCD = 18;
  int tRP  = 18;
  int tRAS = 42;
  int tCL  = 22;
  int tCWL = 11;

  clocking drv_cb @(posedge ck);
    default input #0.5 output #0.5;
    output ca, cs;
    inout  dq, dqs, dqs_n, dm, dmi;
  endclocking

  clocking mon_cb @(posedge ck);
    default input #0.5 output #0.5;
    input ca, cs;
    input dq, dqs, dqs_n, dm, dmi;
  endclocking

  modport driver  (clocking drv_cb, input ck, ck_n, cke, rst_n);
  modport monitor (clocking mon_cb, input ck, ck_n, cke, rst_n);
endinterface : lpddr_if

interface hbm_if #(
  parameter ADDR_WIDTH = 34,
  parameter DATA_WIDTH = 128,
  parameter CHANNELS   = 8
)(
  input logic ck,
  input logic ck_n,
  input logic rst_n
);
  // HBM uses pseudo-channel architecture
  logic [ADDR_WIDTH-1:0] addr;
  logic [2:0]            cid;     // Channel ID
  logic [1:0]            ba;      // Bank address
  logic                  cs_n;
  logic                  cke;
  logic                  ras_n;
  logic                  cas_n;
  logic                  we_n;
  // Data (wide bus)
  logic [DATA_WIDTH-1:0]   dq;
  logic [DATA_WIDTH/8-1:0] dqs;
  logic [DATA_WIDTH/8-1:0] dqs_n;
  logic [DATA_WIDTH/8-1:0] dm;
  // HBM-specific
  logic                  par;   // Parity
  // ---- SVA checker compatibility aliases ----
  // Pseudo-channel select derived from the channel ID pin.
  logic                  pseudo_ch;
  assign pseudo_ch = cid[0];
  // Stack identifier (single-stack model).
  logic [1:0]            stack_id;
  assign stack_id = 2'b00;
  // Junction temperature in deg C (fixed 25C model; no thermal sensor).
  logic [7:0]            temp;
  assign temp = 8'd25;
  // DBI strobe activity derived from the DM bus.
  logic                  dbis;
  assign dbis = |dm;
  // On-die termination (always engaged in this model).
  logic                  odt;
  assign odt = 1'b1;
  // Timing
  int tRCD = 14;
  int tRP  = 14;
  int tRAS = 34;
  int tCL  = 14;
  int tCWL = 8;

  clocking drv_cb @(posedge ck);
    default input #0.5 output #0.5;
    output addr, cid, ba, cs_n, cke, ras_n, cas_n, we_n, par;
    inout  dq, dqs, dqs_n, dm;
  endclocking

  clocking mon_cb @(posedge ck);
    default input #0.5 output #0.5;
    input addr, cid, ba, cs_n, cke, ras_n, cas_n, we_n, par;
    input dq, dqs, dqs_n, dm;
  endclocking

  modport driver  (clocking drv_cb, input ck, ck_n, rst_n);
  modport monitor (clocking mon_cb, input ck, ck_n, rst_n);
endinterface : hbm_if

interface ufs_if #(
  parameter DATA_WIDTH = 8,
  parameter LANE_COUNT = 2
)(
  input logic ref_clk,
  input logic rst_n
);
  // M-PHY based interface
  logic [LANE_COUNT-1:0] tx_lane;
  logic [LANE_COUNT-1:0] rx_lane;
  logic                  tx_ready;
  logic                  rx_ready;
  logic [7:0]            lun;
  logic [DATA_WIDTH-1:0] data;
endinterface : ufs_if

interface unipro_if #(
  parameter DATA_WIDTH = 8,
  parameter LANE_COUNT = 2
)(
  input logic clk,
  input logic rst_n
);
  // UniPro uses M-PHY physical layer
  logic [LANE_COUNT-1:0] tx;
  logic [LANE_COUNT-1:0] rx;
  logic [7:0]            cportid;
  logic [DATA_WIDTH-1:0] data;
endinterface : unipro_if

interface emmc_if #(
  parameter DATA_WIDTH = 8
)(
  input logic clk,
  input logic rst_n
);
  // eMMC uses MMC interface
  logic                  cmd;
  logic [DATA_WIDTH-1:0] dat;
  logic                  ds;      // Data strobe (HS400)
endinterface : emmc_if

interface onfi_if #(
  parameter DATA_WIDTH = 8,
  parameter ADDR_WIDTH = 16
)(
  input logic clk,
  input logic rst_n
);
  // ONFI (Open NAND Flash Interface)
  logic [DATA_WIDTH-1:0] dq;
  logic [ADDR_WIDTH-1:0] addr;
  logic                  ce_n;
  logic                  we_n;
  logic                  re_n;
  logic                  cle;
  logic                  ale;
  logic                  r_b;     // Ready/Busy
endinterface : onfi_if

interface sd_if #(
  parameter DATA_WIDTH = 4
)(
  input logic clk,
  input logic rst_n
);
  // SD/SDIO interface
  logic                  cmd;
  logic [DATA_WIDTH-1:0] dat;
endinterface : sd_if
