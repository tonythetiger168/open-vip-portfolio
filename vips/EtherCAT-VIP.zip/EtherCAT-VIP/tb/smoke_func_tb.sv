// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (EtherCAT MII forwarding)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened ethercat_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [3:0]  mii_rxd = '0;
  logic mii_rx_dv = 1'b0;
  logic mii_rx_er = 1'b0;
  logic [15:0] pd_status = 16'h0000;
  wire  [3:0]  mii_txd;
  wire  mii_tx_en;
  wire  mii_tx_er;
  wire  [15:0] pd_out;

  always #5 clk = ~clk;

  ethercat_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .mii_rxd(mii_rxd), .mii_rx_dv(mii_rx_dv),
    .mii_rx_er(mii_rx_er), .pd_status(pd_status),
    .mii_txd(mii_txd), .mii_tx_en(mii_tx_en),
    .mii_tx_er(mii_tx_er), .pd_out(pd_out)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [3:0] strm [0:5];
  initial begin
    strm[0]=4'h5; strm[1]=4'hD; strm[2]=4'h5; strm[3]=4'h5;
    strm[4]=4'h1; strm[5]=4'h7;
    repeat (8) step();
    chk(mii_tx_en === 1'b0, "tx_en quiet out of reset");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();
    chk(mii_txd === 4'h5, "txd idle nibble (0x5)");

    // inter-frame: tx_en low, idle nibbles
    repeat (3) begin
      step();
      chk(mii_tx_en === 1'b0, "tx_en low between frames");
      chk(mii_txd === 4'h5, "idle nibble while not forwarding");
    end

    // forward a frame (per-beat check)
    for (int i = 0; i < 6; i++) begin
      @(negedge clk); mii_rxd = strm[i]; mii_rx_dv = 1;
      step();
      chk(mii_tx_en === 1'b1, "tx_en high during frame");
      chk(mii_txd === strm[i], "forwarded nibble integrity");
    end
    @(negedge clk); mii_rx_dv = 0;
    step();
    chk(mii_tx_en === 1'b0, "tx_en drops at frame end");

    // process data passthrough
    @(negedge clk); pd_status = 16'h1234;
    step(); step();
    chk(pd_out === 16'h1234, "process data passthrough");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
