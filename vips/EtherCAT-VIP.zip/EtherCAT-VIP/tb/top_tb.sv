// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- EtherCAT testbench top with a functional EtherCAT DUT model

`ifndef EtherCAT_TB_SV
`define EtherCAT_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ethercat_defs_pkg::*;
import ethercat_pkg::*;
import ethercat_env_pkg::*;
import ethercat_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ethercat_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ethercat_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .mii_rxd(vif.mii_rxd),
    .mii_rx_dv(vif.mii_rx_dv),
    .mii_rx_er(vif.mii_rx_er),
    .pd_status(vif.pd_status),
    .mii_txd(vif.mii_txd),
    .mii_tx_en(vif.mii_tx_en),
    .mii_tx_er(vif.mii_tx_er),
    .pd_out(vif.pd_out)
  );

  // Concurrent protocol checks
  ethercat_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .mii_rxd(vif.mii_rxd), .mii_rx_dv(vif.mii_rx_dv), .mii_rx_er(vif.mii_rx_er), .pd_status(vif.pd_status), .mii_txd(vif.mii_txd), .mii_tx_en(vif.mii_tx_en), .mii_tx_er(vif.mii_tx_er), .pd_out(vif.pd_out)
  );

  initial begin
    uvm_config_db#(virtual ethercat_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ethercat_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [3:0]  mii_rxd,
  input  logic        mii_rx_dv,
  input  logic        mii_rx_er,
  input  logic [15:0] pd_status,
  output logic [3:0]  mii_txd,
  output logic        mii_tx_en,
  output logic        mii_tx_er,
  output logic [15:0] pd_out
);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mii_txd   <= '0;
      mii_tx_en <= 1'b0;
      mii_tx_er <= 1'b0;
      pd_out    <= '0;
    end else begin
      // forwarding only while frame valid, else inter-frame idle nibbles
      mii_txd   <= mii_rx_dv ? mii_rxd : 4'h5;
      mii_tx_en <= mii_rx_dv;
      mii_tx_er <= mii_rx_er;
      pd_out    <= pd_status;
    end
  end
endmodule
`endif
