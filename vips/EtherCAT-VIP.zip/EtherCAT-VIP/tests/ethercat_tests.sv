// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_tests.sv -- EtherCAT test package

package ethercat_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import ethercat_defs_pkg::*;
  import ethercat_pkg::*;
  import ethercat_env_pkg::*;

  class ethercat_base_test extends uvm_test;
    `uvm_component_utils(ethercat_base_test)
    ethercat_env env;
    ethercat_config cfg;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      cfg = ethercat_config::type_id::create("cfg", this);
      uvm_config_db#(ethercat_config)::set(this, "*", "cfg", cfg);
      env = ethercat_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
      ethercat_base_sequence seq = ethercat_base_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass
endpackage
