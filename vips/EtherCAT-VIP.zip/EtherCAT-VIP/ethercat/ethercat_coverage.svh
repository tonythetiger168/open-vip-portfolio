// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_coverage.svh -- EtherCAT functional coverage

class ethercat_coverage extends uvm_subscriber #(ethercat_transaction);
  `uvm_component_utils(ethercat_coverage)
  ethercat_config cfg;
  ethercat_transaction tr;

  covergroup ethercat_cg;
    coverpoint tr.mii_rxd;
    coverpoint tr.mii_rx_dv;
    coverpoint tr.mii_rx_er;
    coverpoint tr.pd_status;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(ethercat_config)::get(this, "*", "cfg", cfg));
    ethercat_cg = new();
  endfunction

  function void write(ethercat_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    ethercat_cg.sample();
  endfunction
endclass
