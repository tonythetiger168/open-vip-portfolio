// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_transaction.svh -- EtherCAT transaction

class ethercat_transaction extends uvm_sequence_item;
  `uvm_object_utils(ethercat_transaction)

  rand bit [3:0] mii_rxd;
  rand bit mii_rx_dv;
  rand bit mii_rx_er;
  rand bit [15:0] pd_status;
  bit [3:0] mii_txd_o;
  bit mii_tx_en_o;
  bit mii_tx_er_o;
  bit [15:0] pd_out_o;
  bit [31:0] tag;

  function new(string name = "ethercat_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    ethercat_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mii_rxd = rhs_.mii_rxd;
    mii_rx_dv = rhs_.mii_rx_dv;
    mii_rx_er = rhs_.mii_rx_er;
    pd_status = rhs_.pd_status;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ethercat_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           mii_rxd == rhs_.mii_rxd &&
           mii_rx_dv == rhs_.mii_rx_dv &&
           mii_rx_er == rhs_.mii_rx_er &&
           pd_status == rhs_.pd_status;
  endfunction

  function string convert2string();
    return $sformatf("EtherCAT{tag=%0h mii_rxd=0x%0h mii_rx_dv=0x%0h mii_rx_er=0x%0h pd_status=0x%0h}", tag, mii_rxd, mii_rx_dv, mii_rx_er, pd_status);
  endfunction
endclass
