// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_transaction.svh -- EtherCAT transaction

class ethercat_transaction extends uvm_sequence_item;
  `uvm_object_utils(ethercat_transaction)

  // request (driven by the agent)
  bit [7:0] bytes[$];
  bit preamble_ok;
  rand bit inject_er;
  rand bit [15:0] pd_status;
  // response (returned by the DUT)
  bit [7:0] out_bytes[$];
  bit out_preamble_ok;
  bit out_er;
  bit [15:0] pd_out;
  // bookkeeping (not compared)
  rand bit [6:0] plen;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len { plen inside {[46:100]}; }
  constraint c_er { inject_er dist { 0 := 5, 1 := 1 }; }

  function new(string name = "ethercat_transaction"); super.new(name); endfunction

  // IEEE 802.3 CRC-32 (reflected 0xEDB88320, init/final xor all ones)
  function bit [31:0] crc32(bit [7:0] b[$], int unsigned n);
    bit [31:0] c = 32'hFFFF_FFFF;
    for (int unsigned i = 0; i < n; i++) begin
      c ^= {24'h0, b[i]};
      for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    return ~c;
  endfunction

  // destination/source address, length/type, payload from seed, FCS
  function void build_frame(int unsigned payload_len, bit [31:0] seed, bit [15:0] etype);
    bit [31:0] x = seed | 32'h1;
    bit [31:0] fcs;
    bytes.delete();
    for (int i = 0; i < 6; i++) bytes.push_back(8'hFF);                 // broadcast
    for (int i = 0; i < 6; i++) bytes.push_back(i == 0 ? 8'h02 : 8'(seed >> (i * 4)));
    bytes.push_back(etype[15:8]);
    bytes.push_back(etype[7:0]);
    for (int unsigned i = 0; i < payload_len; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      bytes.push_back(x[7:0]);
    end
    fcs = crc32(bytes, bytes.size());
    for (int i = 0; i < 4; i++) bytes.push_back(fcs[i*8 +: 8]);       // LSB first
  endfunction

  // FCS of a received frame (last four bytes) is correct
  function bit fcs_ok();
    bit [31:0] fcs;
    if (bytes.size() < 18) return 0;
    fcs = crc32(bytes, bytes.size() - 4);
    for (int i = 0; i < 4; i++) if (bytes[bytes.size() - 4 + i] != fcs[i*8 +: 8]) return 0;
    return 1;
  endfunction

  function void post_randomize();
    build_frame(plen, seed, 16'h88A4);    // EtherCAT EtherType
    preamble_ok = 1;
  endfunction

  function void do_copy(uvm_object rhs);
    ethercat_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    bytes = rhs_.bytes;
    preamble_ok = rhs_.preamble_ok;
    inject_er = rhs_.inject_er;
    out_bytes = rhs_.out_bytes;
    out_preamble_ok = rhs_.out_preamble_ok;
    out_er = rhs_.out_er;
    plen = rhs_.plen;
    seed = rhs_.seed;
    pd_status = rhs_.pd_status;
    pd_out = rhs_.pd_out;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ethercat_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (preamble_ok != rhs_.preamble_ok) return 0;
    if (inject_er != rhs_.inject_er) return 0;
    if (out_bytes.size() != rhs_.out_bytes.size()) return 0;
    foreach (out_bytes[i]) if (out_bytes[i] != rhs_.out_bytes[i]) return 0;
    if (out_preamble_ok != rhs_.out_preamble_ok) return 0;
    if (out_er != rhs_.out_er) return 0;
    if (pd_status != rhs_.pd_status) return 0;
    if (pd_out != rhs_.pd_out) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ethercat_transaction rhs_);
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (preamble_ok != rhs_.preamble_ok) return 0;
    if (inject_er != rhs_.inject_er) return 0;
    if (pd_status != rhs_.pd_status) return 0;
    return 1;
  endfunction

  function string qstr_bytes();
    string s = $sformatf("[%0d]{", bytes.size());
    foreach (bytes[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bytes[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_out_bytes();
    string s = $sformatf("[%0d]{", out_bytes.size());
    foreach (out_bytes[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", out_bytes[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("EtherCAT{tag=%0d bytes=%s preamble_ok=0x%0h inject_er=0x%0h out_bytes=%s out_preamble_ok=0x%0h out_er=0x%0h pd_status=0x%0h pd_out=0x%0h}", tag, qstr_bytes(), preamble_ok, inject_er, qstr_out_bytes(), out_preamble_ok, out_er, pd_status, pd_out);
  endfunction
endclass
