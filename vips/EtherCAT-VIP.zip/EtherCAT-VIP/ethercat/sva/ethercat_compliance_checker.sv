// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_compliance_checker.sv -- EtherCAT concurrent assertion checks (bindable)

module ethercat_compliance_checker
  (input logic clk, input logic rst_n, input [3:0] mii_rxd, input mii_rx_dv, input mii_rx_er, input [15:0] pd_status, input [3:0] mii_txd, input mii_tx_en, input mii_tx_er, input [15:0] pd_out);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({mii_txd, mii_tx_en, mii_tx_er, pd_out}))
    else $error("EtherCAT: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> mii_txd == '0)
    else $error("EtherCAT: output not in reset value");
  // TX enable only mirrors RX DV
  assert property (@(posedge clk) disable iff (!rst_n) mii_tx_en == $past(mii_rx_dv))
    else $error("EtherCAT: tx_en does not mirror rx_dv");
  cover property (@(posedge clk) disable iff (!rst_n) (mii_txd != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (mii_tx_en == 1'b1));
endmodule
