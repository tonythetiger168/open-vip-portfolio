// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_if.sv -- EtherCAT interface

interface ethercat_if (input logic clk);
  logic rst_n;

  logic [3:0] mii_rxd;
  logic mii_rx_dv;
  logic mii_rx_er;
  logic [15:0] pd_status;
  logic [3:0] mii_txd;
  logic mii_tx_en;
  logic mii_tx_er;
  logic [15:0] pd_out;

  modport DUT (input clk, rst_n, mii_rxd, mii_rx_dv, mii_rx_er, pd_status, output mii_txd, mii_tx_en, mii_tx_er, pd_out);
  modport DRV (input clk, rst_n, mii_txd, mii_tx_en, mii_tx_er, pd_out, output mii_rxd, mii_rx_dv, mii_rx_er, pd_status);
  modport MON (input clk, rst_n, mii_rxd, mii_rx_dv, mii_rx_er, pd_status, mii_txd, mii_tx_en, mii_tx_er, pd_out);

  clocking drv_cb @(posedge clk);
    input rst_n, mii_rxd, mii_rx_dv, mii_rx_er, pd_status, mii_txd, mii_tx_en, mii_tx_er, pd_out;
    output mii_rxd, mii_rx_dv, mii_rx_er, pd_status;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, mii_rxd, mii_rx_dv, mii_rx_er, pd_status, mii_txd, mii_tx_en, mii_tx_er, pd_out;
  endclocking
endinterface
