// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_pkg.sv -- EtherCAT UVM VIP package

package ethercat_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ethercat_defs_pkg::*;
  export ethercat_defs_pkg::*;

  `include "ethercat_transaction.svh"
  `include "ethercat_config.svh"
  `include "ethercat_sequencer.svh"
  `include "ethercat_driver.svh"
  `include "ethercat_monitor.svh"
  `include "ethercat_agent.svh"
  `include "ethercat_sequences.svh"
  `include "ethercat_checker.svh"
  `include "ethercat_coverage.svh"
endpackage
