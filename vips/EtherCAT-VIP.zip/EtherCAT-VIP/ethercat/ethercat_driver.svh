// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_driver.svh -- EtherCAT driver: preamble, SFD and one MAC frame, then the inter-frame gap

class ethercat_driver extends uvm_driver #(ethercat_transaction);
  `uvm_component_utils(ethercat_driver)

  uvm_analysis_port #(ethercat_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ethercat_if vif;
  ethercat_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ethercat_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ethercat: virtual interface not set")
    if (!uvm_config_db#(ethercat_config)::get(this, "", "cfg", cfg))
      cfg = ethercat_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ethercat_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.mii_rxd <= '0; vif.drv_cb.mii_rx_dv <= 1'b0; vif.drv_cb.mii_rx_er <= 1'b0; vif.drv_cb.pd_status <= '0;
  endtask

  task drive_item(ethercat_transaction t);
    bit [7:0] line[$];
    @(vif.drv_cb);
    vif.drv_cb.pd_status <= t.pd_status;
    for (int i = 0; i < 7; i++) line.push_back(8'h55);
    line.push_back(8'hD5);
    foreach (t.bytes[i]) line.push_back(t.bytes[i]);
    foreach (line[i]) for (int h = 0; h < 2; h++) begin
      vif.drv_cb.mii_rxd <= h ? line[i][7:4] : line[i][3:0];
      vif.drv_cb.mii_rx_dv <= 1'b1;
      vif.drv_cb.mii_rx_er <= t.inject_er && (i == line.size() / 2);
      @(vif.drv_cb);
    end
    vif.drv_cb.mii_rx_dv <= 1'b0;
    vif.drv_cb.mii_rxd <= '0;
    vif.drv_cb.mii_rx_er <= 1'b0;
    repeat (cfg.ifg_clks) @(vif.drv_cb);
  endtask

endclass
