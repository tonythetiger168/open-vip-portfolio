// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ethercat_monitor.svh -- EtherCAT monitor: decodes observed bus activity

class ethercat_monitor extends uvm_monitor;
  `uvm_component_utils(ethercat_monitor)

  virtual ethercat_if vif;
  uvm_analysis_port #(ethercat_transaction) ap;
  ethercat_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ethercat_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ethercat: virtual interface not set")
    void'(uvm_config_db#(ethercat_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    ethercat_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = ethercat_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.mii_rxd = vif.mii_rxd;
        t.mii_rx_dv = vif.mii_rx_dv;
        t.mii_rx_er = vif.mii_rx_er;
        t.pd_status = vif.pd_status;
        t.mii_txd_o = vif.mii_txd;
        t.mii_tx_en_o = vif.mii_tx_en;
        t.mii_tx_er_o = vif.mii_tx_er;
        t.pd_out_o = vif.pd_out;
        ap.write(t);
      end
    end
  endtask
endclass
