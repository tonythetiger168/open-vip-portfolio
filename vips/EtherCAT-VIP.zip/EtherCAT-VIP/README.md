# EtherCAT UVM VIP (EtherCAT-VIP)

EtherCAT slave controller (ESC) UVM VIP: MII loopback with frame-valid qualification and process-data status.

## Structure

- `ethercat/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `ethercat_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `ethercat_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural EtherCAT DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/EtherCAT-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh EtherCAT-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
