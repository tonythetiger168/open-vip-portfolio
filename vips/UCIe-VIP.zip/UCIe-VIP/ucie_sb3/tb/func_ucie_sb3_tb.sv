// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// FUNC_SIM: iverilog
//
// func_ucie_sb3_tb.sv -- sideband partner for ucie_sb3_model (UCIe 3.0
// sideband additions) with a reference written out independently of the
// model:
//   * register reads / byte-enabled writes, UR outside the register file,
//     completion tag, status, data and parity
//   * priority packets overtake the normal queue, queue-full drops
//   * management transport: in-order reassembly, 1..8 dwords, SOM restart,
//     wrong fragment seq, fragment without SOM, overflow
//   * runtime recalibration: pause length, RecalDone, busy while running,
//     RecalDone held while the normal queue is full
//   * throttle levels, emergency shutdown held until reset, parity errors,
//     unknown opcodes
//   * 3000 random packets with random back-pressure, checked clock by
//     clock against the reference
// Run: python3 tools/run_func_tests.py UCIe-VIP
`timescale 1ns/1ps
module func_ucie_sb3_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int RECAL_T = 8;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic sb_rx_valid = 0, sb_tx_ready = 1;
  logic [63:0] sb_rx = 0;
  wire sb_tx_valid, mb_pause, shutdown, msg_valid;
  wire [63:0] sb_tx;
  wire [1:0] throttle;
  wire [3:0] msg_len;
  wire [255:0] msg_data;
  wire [5:0] err;
  always #5 clk = ~clk;

  ucie_sb3_model #(.RECAL_T(RECAL_T)) u_dut (.clk, .rst_n, .sb_rx_valid, .sb_rx, .sb_tx_valid, .sb_tx, .sb_tx_ready,
    .mb_pause, .throttle, .shutdown, .msg_valid, .msg_len, .msg_data, .err);

  task automatic wait_clk(input int n); repeat (n) @(negedge clk); #1; endtask

  // packet builder; fields by name
  function automatic logic [63:0] pkt(input int op, input int tag = 0, input int addr = 0, input int be = 15,
                                      input logic [31:0] data = 0, input bit prio = 0, input bit som = 0,
                                      input bit eom = 0, input int fseq = 0);
    logic [63:0] p;
    p = 0;
    p[62] = prio; p[61:58] = op; p[57:53] = tag; p[52:45] = addr; p[44:41] = be;
    p[40] = som; p[39] = eom; p[38:35] = fseq; p[31:0] = data;
    p[63] = ^p[62:0];
    return p;
  endfunction

  // ------------------------------------------------------------ reference
  logic [31:0] r_reg [16];
  logic [62:0] r_pq [$], r_nq [$];
  bit r_mon = 0;
  int r_mn = 0, r_mseq = 0, r_rc = 0;
  logic [31:0] r_md [8];
  bit [5:0] r_err = 0;
  bit r_shut = 0;
  int r_thr = 0;
  bit e_msg;
  int e_mlen;
  logic [255:0] e_mdat;
  logic [63:0] e_tx;
  bit e_txv, e_pause;
  int bad_out = 0, n_tx = 0, n_msg = 0, n_done = 0;
  logic [63:0] txlog [$];
  bit check_on = 1;

  always @(posedge clk) if (rst_n && check_on) begin
    bit [5:0] e;
    e = 0; e_msg = 0;
    if (sb_tx_valid && sb_tx_ready) begin
      if (r_pq.size() > 0) void'(r_pq.pop_front()); else void'(r_nq.pop_front());
    end
    if (sb_rx_valid) begin
      logic [62:0] r, c;
      int op;
      r = sb_rx[62:0]; op = r[61:58];
      if (sb_rx[63] != ^r) e[0] = 1;
      else if (op == 0 || op == 1 || op == 3) begin
        int st;
        bit full;
        st = 0;
        c = 0; c[62] = r[62]; c[61:58] = 7; c[57:53] = r[57:53];
        if (op == 3) begin if (r_rc > 0) begin st = 2; e[5] = 1; end end
        else if (r[52:45] > 15) st = 1;
        else if (op == 0) c[31:0] = r_reg[r[48:45]];
        c[34:33] = st;
        full = r[62] ? r_pq.size() == 2 : r_nq.size() == 4;
        if (full) e[2] = 1;
        else begin
          if (op == 1 && st == 0) for (int b = 0; b < 4; b++) if (r[41 + b]) r_reg[r[48:45]][8 * b +: 8] = r[8 * b +: 8];
          if (op == 3 && st == 0) r_rc = RECAL_T + 1;
          if (r[62]) r_pq.push_back(c); else r_nq.push_back(c);
        end
      end else if (op == 2) begin
        if (r[40]) begin
          if (r_mon) e[3] = 1;
          r_mon = 1; r_mn = 0; r_mseq = 0;
        end
        if (!r_mon || r[38:35] != r_mseq) begin e[3] = 1; r_mon = 0; end
        else if (r_mn == 8) begin e[4] = 1; r_mon = 0; end
        else begin
          r_md[r_mn] = r[31:0]; r_mn++; r_mseq = (r_mseq + 1) % 16;
          if (r[39]) begin
            e_msg = 1; e_mlen = r_mn; e_mdat = 0;
            for (int i = 0; i < r_mn; i++) e_mdat[32 * i +: 32] = r_md[i];
            r_mon = 0;
          end
        end
      end else if (op == 5) r_thr = r[1:0];
      else if (op == 6) r_shut = 1;
      else e[1] = 1;
    end
    if (r_rc > 1) r_rc--;
    else if (r_rc == 1 && r_nq.size() < 4) begin
      logic [62:0] d;
      d = 0; d[61:58] = 4; r_nq.push_back(d); r_rc = 0;
    end
    e_pause = r_rc > 0;
    e_txv = r_pq.size() > 0 || r_nq.size() > 0;
    if (r_pq.size() > 0) e_tx = {^r_pq[0], r_pq[0]};
    else if (r_nq.size() > 0) e_tx = {^r_nq[0], r_nq[0]};
    r_err |= e;
  end
  always @(negedge clk) if (rst_n && check_on) begin
    bit ok;
    ok = sb_tx_valid === e_txv && mb_pause === e_pause && msg_valid === e_msg && err === r_err &&
         throttle == r_thr && shutdown === r_shut;
    if (e_txv && sb_tx !== e_tx) ok = 0;
    if (e_msg && (msg_len != e_mlen || msg_data !== e_mdat)) ok = 0;
    if (!ok) begin
      bad_out++;
      if (bad_out < 6) $display("  @%0t tx %b/%b %h/%h pause %b/%b msg %b/%b err %b/%b", $time, sb_tx_valid, e_txv,
                                sb_tx, e_tx, mb_pause, e_pause, msg_valid, e_msg, err, r_err);
    end
    n_msg += msg_valid;
  end
  // packets accepted by the partner (sampled at the handshake edge)
  always @(posedge clk)
    if (rst_n && sb_tx_valid && sb_tx_ready) begin n_tx++; txlog.push_back(sb_tx); if (sb_tx[61:58] == 4) n_done++; end

  function automatic int tag_at(input int i); logic [63:0] x; x = txlog[i]; return x[57:53]; endfunction
  function automatic int op_at(input int i); logic [63:0] x; x = txlog[i]; return x[61:58]; endfunction
  task automatic send(input logic [63:0] p);
    @(negedge clk); sb_rx_valid = 1; sb_rx = p;
    @(negedge clk); sb_rx_valid = 0; #1;
  endtask
  // waits for the next transmitted packet
  task automatic next_tx(output logic [63:0] p);
    int t;
    t = 0;
    while (txlog.size() == 0 && t < 50) begin wait_clk(1); t++; end
    p = (txlog.size() > 0) ? txlog.pop_front() : 64'hX;
  endtask

  logic [63:0] p;
  int t0, d0;
  bit ok;

  initial begin
    for (int i = 0; i < 16; i++) r_reg[i] = 0;
    wait_clk(3); rst_n = 1; wait_clk(2);

    // ---- register access
    send(pkt(1, 3, 5, 15, 32'hDEAD_BEEF));
    next_tx(p);
    chk(p[61:58] == 7 && p[57:53] == 3 && p[34:33] == 0 && ^p == 0, "MemWr32: Cpl, tag 3, status 0, even parity");
    send(pkt(1, 4, 5, 4'b0101, 32'h1122_3344));
    next_tx(p);
    send(pkt(0, 9, 5));
    next_tx(p);
    chk(p[57:53] == 9 && p[34:33] == 0 && p[31:0] == 32'hDE22_BE44, "byte-enabled write, read back");
    send(pkt(0, 10, 16));
    next_tx(p);
    chk(p[34:33] == 1 && p[31:0] == 0, "read outside the register file: UR");
    send(pkt(1, 11, 200, 15, 32'h1));
    next_tx(p);
    send(pkt(0, 12, 200 % 16));
    next_tx(p);
    chk(p[34:33] == 0 && p[31:0] == 0, "UR write did not alias into the register file");
    send(pkt(0, 13, 15));
    next_tx(p);
    chk(p[34:33] == 0, "register 15 is inside the file");

    // ---- priority overtakes, queue full
    wait_clk(4);
    chk(!sb_tx_valid, "queues empty");
    sb_tx_ready = 0;
    for (int i = 0; i < 4; i++) send(pkt(0, i, 0));
    send(pkt(0, 20, 0));
    chk(err[2], "fifth normal request with the normal queue full: dropped (err 2)");
    send(pkt(0, 21, 5, 15, 0, 1));
    chk(sb_tx_valid && sb_tx[62] && sb_tx[57:53] == 21, "priority Cpl replaces the waiting normal one");
    send(pkt(0, 22, 5, 15, 0, 1));
    send(pkt(0, 23, 5, 15, 0, 1));
    txlog.delete();
    sb_tx_ready = 1;
    wait_clk(8);
    chk(txlog.size() == 6 && tag_at(0) == 21 && tag_at(1) == 22 && tag_at(2) == 0 &&
        tag_at(5) == 3, "priority queue (2) drained first, third priority dropped, then normal in order");
    txlog.delete();

    // ---- management transport
    send(pkt(2, 0, 0, 0, 32'hA0, 0, 1, 0, 0));
    send(pkt(2, 0, 0, 0, 32'hA1, 0, 0, 0, 1));
    @(negedge clk); sb_rx_valid = 1; sb_rx = pkt(2, 0, 0, 0, 32'hA2, 0, 0, 1, 2);
    @(negedge clk); sb_rx_valid = 0;
    #1;
    chk(msg_valid && msg_len == 3 && msg_data[95:0] == {32'hA2, 32'hA1, 32'hA0} && msg_data[255:96] == 0,
        "3-fragment message reassembled in order");
    send(pkt(2, 0, 0, 0, 32'hB0, 0, 1, 1, 0));
    chk(msg_valid && msg_len == 1 && msg_data[31:0] == 32'hB0, "single-fragment message (SOM and EOM)");
    send(pkt(2, 0, 0, 0, 32'hD0, 0, 1, 0, 0));
    send(pkt(2, 0, 0, 0, 32'hE0, 0, 1, 0, 0));
    send(pkt(2, 0, 0, 0, 32'hE1, 0, 0, 1, 1));
    chk(err[3] && msg_valid && msg_len == 2 && msg_data[63:0] == {32'hE1, 32'hE0}, "SOM restarts the message (err 3 for the dropped partial one)");
    d0 = n_msg;
    send(pkt(2, 0, 0, 0, 32'hC0, 0, 1, 0, 0));
    send(pkt(2, 0, 0, 0, 32'hC1, 0, 0, 0, 2));
    chk(err[3] && n_msg == d0, "wrong fragment seq: message dropped (err 3)");
    send(pkt(2, 0, 0, 0, 32'hC2, 0, 0, 1, 2));
    chk(n_msg == d0, "fragment without a started message: dropped");
    for (int i = 0; i < 8; i++) send(pkt(2, 0, 0, 0, 32'hF0 + i, 0, i == 0, i == 7, i));
    chk(msg_valid && msg_len == 8 && msg_data[255:224] == 32'hF7, "8-dword message");
    d0 = n_msg;
    for (int i = 0; i < 9; i++) send(pkt(2, 0, 0, 0, i, 0, i == 0, i == 8, i));
    chk(err[4] && n_msg == d0, "9 dwords: message dropped (err 4)");
    chk(txlog.size() == 0, "management fragments get no Cpl");

    // ---- runtime recalibration
    txlog.delete();
    send(pkt(3, 6));
    t0 = 0;
    while (mb_pause && t0 < 40) begin wait_clk(1); t0++; end
    chk(t0 == RECAL_T, $sformatf("RecalReq: mainband paused for RECAL_T clocks (%0d)", t0));
    next_tx(p);
    chk(p[61:58] == 7 && p[57:53] == 6 && p[34:33] == 0, "RecalReq accepted (Cpl status 0)");
    next_tx(p);
    chk(p[61:58] == 4, "RecalDone sent when the pause ends");
    send(pkt(3, 7));
    send(pkt(3, 9));
    next_tx(p);
    chk(p[57:53] == 7 && p[34:33] == 0, "RecalReq accepted");
    next_tx(p);
    chk(p[57:53] == 9 && p[34:33] == 2 && err[5], "second RecalReq while running: busy (status 2)");
    next_tx(p);
    chk(p[61:58] == 4 && !mb_pause, "one RecalDone for the accepted request");
    // RecalDone waits for room in the normal queue
    sb_tx_ready = 0;
    send(pkt(3, 8));
    for (int i = 0; i < 3; i++) send(pkt(0, i, 0));
    wait_clk(RECAL_T + 2);
    chk(mb_pause, "pause continues while RecalDone cannot be queued");
    send(pkt(3, 30, 0, 15, 0, 1));
    chk(sb_tx_valid && sb_tx[57:53] == 30 && sb_tx[34:33] == 2, "priority RecalReq while RecalDone waits: busy");
    txlog.delete(); d0 = n_done;
    sb_tx_ready = 1;
    wait_clk(8);
    chk(!mb_pause && n_done == d0 + 1 && txlog.size() == 6 && op_at(5) == 4, "RecalDone queued after the 4 waiting packets");

    // ---- throttle, shutdown, parity, unknown op
    send(pkt(5, 0, 0, 0, 2, 1));
    chk(throttle == 2, "fast throttle level 2");
    send(pkt(5, 0, 0, 0, 0, 1));
    chk(throttle == 0, "throttle released");
    send(pkt(0, 1, 0) ^ 64'h1);
    chk(err[0], "parity error: dropped (err 0)");
    send(pkt(0, 1, 0) ^ 64'h3);
    chk(bad_out == 0, "two flipped bits keep parity: handled as a read");
    send(pkt(8, 1, 0));
    chk(err[1], "unknown opcode: dropped (err 1)");
    send(pkt(4, 1, 0));
    send(pkt(7, 1, 0));
    send(pkt(6, 0, 0, 0, 0, 1));
    chk(shutdown, "emergency shutdown");
    wait_clk(4);
    chk(shutdown && bad_out == 0, "shutdown held; directed packets as the reference");

    // ---- random
    begin
      int sent;
      sent = 0;
      for (int i = 0; i < 3000; i++) begin
        int op, r;
        r = $urandom_range(0, 99);
        op = (r < 30) ? 0 : (r < 50) ? 1 : (r < 80) ? 2 : (r < 85) ? 3 : (r < 90) ? 5 : (r < 92) ? 6 : $urandom_range(4, 15);
        @(negedge clk);
        sb_tx_ready = $urandom_range(0, 3) != 0;
        sb_rx_valid = $urandom_range(0, 2) != 0;
        if (op == 2)
          sb_rx = pkt(2, 0, 0, 0, $urandom, $urandom_range(0, 1), $urandom_range(0, 5) == 0, $urandom_range(0, 4) == 0,
                      ($urandom_range(0, 9) == 0) ? $urandom_range(0, 15) : r_mseq);
        else
          sb_rx = pkt(op, $urandom_range(0, 31), $urandom_range(0, 19), $urandom_range(0, 15), $urandom,
                      $urandom_range(0, 3) == 0);
        if ($urandom_range(0, 49) == 0) sb_rx[$urandom_range(0, 63)] ^= 1'b1;
        sent += sb_rx_valid;
      end
      @(negedge clk); sb_rx_valid = 0; sb_tx_ready = 1;
      wait_clk(RECAL_T + 10);
      chk(bad_out == 0, $sformatf("%0d random packets: every output as the reference (%0d sent, %0d messages)", sent, n_tx, n_msg));
    end

    // ---- reset
    check_on = 0;
    rst_n = 0; wait_clk(2);
    chk(!shutdown && throttle == 0 && !sb_tx_valid && !mb_pause && err == 0, "reset clears shutdown, throttle and queues");
    rst_n = 1;
    send(pkt(0, 2, 5));
    chk(sb_tx_valid && sb_tx[31:0] == 0, "registers cleared by reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #20ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
