// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ucie_sb3_model.sv -- the sideband features UCIe 3.0 added, at the packet
// level: priority sideband packets that overtake queued traffic, a
// management transport (fragmented messages reassembled in order), runtime
// recalibration that pauses the mainband without retraining, and the fast
// throttle / emergency shutdown signals. The packet layout, opcodes,
// status codes, queue depths and timers are this model's own; the
// specification's encodings are not reproduced.
//
// Packet (sb_rx / sb_tx, 64 bits): [63] even parity over [62:0], [62] prio,
//   [61:58] op, [57:53] tag, [52:45] addr, [44:41] byte enables,
//   [40] SOM, [39] EOM, [38:35] fragment seq, [34:33] status, [31:0] data.
// Received ops (a parity error drops the packet, err[0]):
//   0 MemRd32  -> Cpl with the register (addr < 16) or status 1 (UR)
//   1 MemWr32  -> byte-enabled write (addr < 16), Cpl status 0, else UR
//   2 MgmtFrag -> management transport fragment: SOM starts a message
//                 (a partial one is dropped, err[3]), the fragment seq
//                 counts from 0, a wrong seq or a fragment without a
//                 started message drops it (err[3]), more than 8 dwords
//                 drop it (err[4]); EOM delivers it (msg_valid one clock,
//                 msg_len dwords, msg_data dword i in [32*i +: 32]). No Cpl.
//   3 RecalReq -> Cpl status 0 and runtime recalibration: mb_pause from
//                 the next clock for RECAL_T clocks, then a RecalDone (op 4)
//                 packet; status 2
//                 (busy, err[5]) while a recalibration is running
//   5 Throttle -> throttle <= data[1:0]          (no Cpl)
//   6 Shutdown -> shutdown, held until reset     (no Cpl)
//   other      -> dropped (err[1])
// Cpl: op 7, the request's tag and prio, status in [34:33], data for a
//   MemRd32. Transmit: a priority queue (2 entries) and a normal queue
//   (4 entries); one packet per clock while sb_tx_ready, priority first
//   (a priority packet replaces a normal one still waiting for ready).
//   A response that finds its queue full drops the request (err[2]).
//   RecalDone uses the normal queue and waits (the pause continues) while
//   the queue is full.
module ucie_sb3_model #(parameter int RECAL_T = 8) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         sb_rx_valid,
  input  logic [63:0]  sb_rx,
  output logic         sb_tx_valid,
  output logic [63:0]  sb_tx,
  input  logic         sb_tx_ready,
  output logic         mb_pause,
  output logic [1:0]   throttle,
  output logic         shutdown,
  output logic         msg_valid,
  output logic [3:0]   msg_len,
  output logic [255:0] msg_data,
  output logic [5:0]   err
);
  logic [31:0]  regs [0:15];
  logic [62:0]  pq [0:1], nq [0:3];
  int           pn, nn;
  logic         m_on;
  int           m_n;
  logic [3:0]   m_seq;
  logic [255:0] m_d;
  int           rc;          // recalibration clocks left; 0 = idle

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 16; i++) regs[i] = '0;
      pn = 0; nn = 0; m_on = 1'b0; m_n = 0; m_seq = '0; m_d = '0; rc = 0;
      sb_tx_valid <= 1'b0; sb_tx <= '0; mb_pause <= 1'b0; throttle <= '0; shutdown <= 1'b0;
      msg_valid <= 1'b0; msg_len <= '0; msg_data <= '0; err <= '0;
    end else begin : step
      logic [5:0]  e;
      logic [62:0] r, c;
      logic        hp, sent;
      e = '0; r = sb_rx[62:0]; hp = sb_rx[62]; sent = 1'b0;
      msg_valid <= 1'b0;

      // transmit (frees a slot for this clock's response)
      if (sb_tx_valid && sb_tx_ready) sent = 1'b1;
      if (sent) begin
        if (pn > 0) begin pq[0] = pq[1]; pn = pn - 1; end
        else begin for (int i = 0; i < 3; i++) nq[i] = nq[i + 1]; nn = nn - 1; end
      end

      if (sb_rx_valid) begin
        if (^sb_rx) e[0] = 1'b1;
        else begin
          c = '0; c[62] = hp; c[61:58] = 4'd7; c[57:53] = r[57:53];
          case (r[61:58])
            4'd0, 4'd1, 4'd3: begin
              if (r[61:58] == 4'd3) begin
                if (rc > 0) begin c[34:33] = 2'd2; e[5] = 1'b1; end
              end else if (r[52:45] >= 8'd16) c[34:33] = 2'd1;
              else if (r[61:58] == 4'd0) c[31:0] = regs[r[48:45]];
              if ((hp && pn == 2) || (!hp && nn == 4)) e[2] = 1'b1;
              else begin
                if (r[61:58] == 4'd1 && c[34:33] == 2'd0)
                  for (int b = 0; b < 4; b++) if (r[41 + b]) regs[r[48:45]][8 * b +: 8] = r[8 * b +: 8];
                if (r[61:58] == 4'd3 && c[34:33] == 2'd0) rc = RECAL_T + 1;
                if (hp) begin pq[pn] = c; pn = pn + 1; end
                else begin nq[nn] = c; nn = nn + 1; end
              end
            end
            4'd2: begin
              if (r[40]) begin
                if (m_on) e[3] = 1'b1;
                m_on = 1'b1; m_n = 0; m_seq = '0; m_d = '0;
              end
              if (!m_on || r[38:35] != m_seq) begin e[3] = 1'b1; m_on = 1'b0; end
              else if (m_n == 8) begin e[4] = 1'b1; m_on = 1'b0; end
              else begin
                m_d[32 * m_n +: 32] = r[31:0]; m_n = m_n + 1; m_seq = m_seq + 4'd1;
                if (r[39]) begin
                  msg_valid <= 1'b1; msg_len <= 4'(m_n); msg_data <= m_d; m_on = 1'b0;
                end
              end
            end
            4'd5: throttle <= r[1:0];
            4'd6: shutdown <= 1'b1;
            default: e[1] = 1'b1;
          endcase
        end
      end

      // runtime recalibration
      if (rc > 1) rc = rc - 1;
      else if (rc == 1 && nn < 4) begin
        c = '0; c[61:58] = 4'd4; nq[nn] = c; nn = nn + 1; rc = 0;
      end
      mb_pause <= (rc > 0);

      if (pn > 0) begin sb_tx_valid <= 1'b1; sb_tx <= {^pq[0], pq[0]}; end
      else if (nn > 0) begin sb_tx_valid <= 1'b1; sb_tx <= {^nq[0], nq[0]}; end
      else sb_tx_valid <= 1'b0;
      err <= err | e;
    end
  end
endmodule
