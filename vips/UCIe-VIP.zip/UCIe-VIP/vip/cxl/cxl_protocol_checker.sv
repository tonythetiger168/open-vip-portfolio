// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// CXL Protocol Checker
// Protocol-specific assertions for CXL 2.0/3.0 (.cache/.mem over PCIe PHY)
//============================================================================
`ifndef CXL_PROTOCOL_CHECKER_SV
`define CXL_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

// ============================================================================
// cxl_protocol_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module cxl_protocol_checker_sva (mp_vip_if vif);

    int cache_err_cnt;
  int mem_err_cnt;
  int vc_err_cnt;
  int hsk_err_cnt;

    initial begin
    cache_err_cnt = 0; mem_err_cnt = 0; vc_err_cnt = 0; hsk_err_cnt = 0;
    end


  // CXL transfers use the dedicated CXL VC encoding (4'b0010)
  property p_cxl_vc;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.ucie_vc == 4'b0010;
  endproperty
  assert_cxl_vc: assert property(p_cxl_vc)
  else begin
    `uvm_error("CXL_CHK", "CXL VC encoding violation")
    vc_err_cnt++;
  end

  // CXL.cache line transfers are 64B (16 DW) aligned
  property p_cxl_cache_line;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.length_dw inside {[10'd1:10'd256]};
  endproperty
  assert_cxl_line: assert property(p_cxl_cache_line)
  else begin
    `uvm_error("CXL_CHK", "CXL cache line length violation")
    cache_err_cnt++;
  end

  // Handshake: valid must eventually be accepted
  property p_cxl_handshake;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.valid |-> ##[1:100] vif.ready;
  endproperty
  assert_cxl_hsk: assert property(p_cxl_handshake)
  else begin
    `uvm_error("CXL_CHK", "CXL valid-ready timeout")
    hsk_err_cnt++;
  end

  // LCRC error may only be flagged during a transfer
  property p_cxl_lcrc;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.lcrc_error |-> vif.valid;
  endproperty
  assert_cxl_lcrc: assert property(p_cxl_lcrc)
  else begin
    `uvm_error("CXL_CHK", "CXL LCRC error flagged outside transfer")
    mem_err_cnt++;
  end

  final begin
    `uvm_info("CXL_RPT", $sformatf("CXL Chk | Cache:%0d Mem:%0d VC:%0d Hsk:%0d",
              cache_err_cnt, mem_err_cnt, vc_err_cnt, hsk_err_cnt), UVM_LOW)
    end
endmodule

// ============================================================================
// cxl_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the cxl_protocol_checker_sva module above)
// ============================================================================
class cxl_protocol_checker extends uvm_component;
  `uvm_component_utils(cxl_protocol_checker)
  function new(string name = "cxl_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
