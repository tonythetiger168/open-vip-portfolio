// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// PCIe Protocol Checker
// Protocol-specific assertions for PCIe Gen5/Gen6 TLP framing
//============================================================================
`ifndef PCIE_PROTOCOL_CHECKER_SV
`define PCIE_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

// ============================================================================
// pcie_protocol_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module pcie_protocol_checker_sva (mp_vip_if vif);

    int tlp_err_cnt;
  int tag_err_cnt;
  int len_err_cnt;
  int hsk_err_cnt;

    initial begin
    tlp_err_cnt = 0; tag_err_cnt = 0; len_err_cnt = 0; hsk_err_cnt = 0;
    end


  // TLP length must be non-zero and within max payload
  property p_pcie_tlp_len;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.length_dw inside {[10'd1:10'd1024]};
  endproperty
  assert_pcie_len: assert property(p_pcie_tlp_len)
  else begin
    `uvm_error("PCIE_CHK", "PCIe TLP length out of range")
    len_err_cnt++;
  end

  // Traffic class is 3-bit (always in range) but attr must be legal
  property p_pcie_attr;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid) |-> vif.attr inside {2'b00, 2'b01, 2'b10, 2'b11};
  endproperty
  assert_pcie_attr: assert property(p_pcie_attr)
  else begin
    `uvm_error("PCIE_CHK", "PCIe attr illegal")
    tlp_err_cnt++;
  end

  // Handshake: valid must eventually be accepted
  property p_pcie_handshake;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.valid |-> ##[1:100] vif.ready;
  endproperty
  assert_pcie_hsk: assert property(p_pcie_handshake)
  else begin
    `uvm_error("PCIE_CHK", "PCIe valid-ready timeout")
    hsk_err_cnt++;
  end

  // ECRC error may only be flagged during a transfer
  property p_pcie_ecrc;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.ecrc_error |-> vif.valid;
  endproperty
  assert_pcie_ecrc: assert property(p_pcie_ecrc)
  else begin
    `uvm_error("PCIE_CHK", "PCIe ECRC error flagged outside transfer")
    tlp_err_cnt++;
  end

  final begin
    `uvm_info("PCIE_RPT", $sformatf("PCIe Chk | TLP:%0d Tag:%0d Len:%0d Hsk:%0d",
              tlp_err_cnt, tag_err_cnt, len_err_cnt, hsk_err_cnt), UVM_LOW)
    end
endmodule

// ============================================================================
// pcie_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the pcie_protocol_checker_sva module above)
// ============================================================================
class pcie_protocol_checker extends uvm_component;
  `uvm_component_utils(pcie_protocol_checker)
  function new(string name = "pcie_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
