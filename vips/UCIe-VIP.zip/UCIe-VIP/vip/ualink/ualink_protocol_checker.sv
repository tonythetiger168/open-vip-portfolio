// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// UALink Protocol Checker
// Protocol-specific assertions for UALink (Ultra Accelerator Link)
//============================================================================
`ifndef UALINK_PROTOCOL_CHECKER_SV
`define UALINK_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

// ============================================================================
// ualink_protocol_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module ualink_protocol_checker_sva (mp_vip_if vif);

    int flit_err_cnt;
  int vc_err_cnt;
  int qos_err_cnt;
  int framing_err_cnt;

    initial begin
    flit_err_cnt = 0; vc_err_cnt = 0; qos_err_cnt = 0; framing_err_cnt = 0;
    end


  //==========================================================================
  // Assertion: UALink Flit Mode Consistency
  //==========================================================================
  property p_ualink_flit_mode;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.ualink_flit_mode == 1'b1;
  endproperty
  assert_ualink_flit: assert property(p_ualink_flit_mode)
  else begin
    `uvm_error("UALINK_CHK", "UALink flit mode not asserted")
    flit_err_cnt++;
  end

  //==========================================================================
  // Assertion: UALink VC Range (4-bit, 16 VCs max)
  //==========================================================================
  property p_ualink_vc;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid) |-> vif.ualink_vc inside {[4'h0:4'hF]};
  endproperty
  assert_ualink_vc: assert property(p_ualink_vc)
  else begin
    `uvm_error("UALINK_CHK", "UALink VC out of range")
    vc_err_cnt++;
  end

  //==========================================================================
  // Assertion: UALink QoS Range (2-bit)
  //==========================================================================
  property p_ualink_qos;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid) |-> vif.ualink_qos inside {2'b00, 2'b01, 2'b10, 2'b11};
  endproperty
  assert_ualink_qos: assert property(p_ualink_qos)
  else begin
    `uvm_error("UALINK_CHK", "UALink QoS out of range")
    qos_err_cnt++;
  end

  //==========================================================================
  // Assertion: UALink Flit Boundary (512B flit for 800G)
  //==========================================================================
  property p_ualink_flit_boundary;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> (int'(vif.length_dw) * 4) <= 512;
  endproperty
  assert_ualink_boundary: assert property(p_ualink_flit_boundary)
  else begin
    `uvm_error("UALINK_CHK", "UALink flit exceeds 512B boundary")
    framing_err_cnt++;
  end

  //==========================================================================
  // Assertion: UALink Address Alignment (64B for AI workloads)
  //==========================================================================
  property p_ualink_addr_align;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> (vif.data[vif.DATA_WIDTH-1 -: 64] & 64'h3F) == 64'h0;
  endproperty
  assert_ualink_align: assert property(p_ualink_addr_align)
  else begin
    `uvm_error("UALINK_CHK", "UALink address not 64B aligned")
    framing_err_cnt++;
  end

  final begin
    `uvm_info("UALINK_RPT", $sformatf("UALink Chk | Flit:%0d VC:%0d QoS:%0d Framing:%0d",
              flit_err_cnt, vc_err_cnt, qos_err_cnt, framing_err_cnt), UVM_LOW)
    end
endmodule

// ============================================================================
// ualink_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the ualink_protocol_checker_sva module above)
// ============================================================================
class ualink_protocol_checker extends uvm_component;
  `uvm_component_utils(ualink_protocol_checker)
  function new(string name = "ualink_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
