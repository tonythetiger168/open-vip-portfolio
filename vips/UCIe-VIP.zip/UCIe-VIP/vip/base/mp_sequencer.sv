// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Sequencer
//============================================================================
`ifndef MP_SEQUENCER_SV
`define MP_SEQUENCER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;


class mp_sequencer extends uvm_sequencer #(mp_sequence_item);
  `uvm_component_utils(mp_sequencer)
  protocol_e protocol;

  function new(string name = "mp_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(protocol_e)::get(this, "", "protocol", protocol))
      `uvm_warning("CONFIG", "Protocol not configured, defaulting to PCIe Gen5")
  endfunction
endclass
`endif
