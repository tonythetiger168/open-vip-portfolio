// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Agent
// Encapsulates sequencer, driver, and monitor
//============================================================================
`ifndef MP_AGENT_SV
`define MP_AGENT_SV
`include "uvm_macros.svh"
import uvm_pkg::*;


class mp_agent extends uvm_agent;
  `uvm_component_utils(mp_agent)
  mp_sequencer sqr;
  mp_driver    drv;
  mp_monitor   mon;
  protocol_e     protocol;
  protocol_cfg_t cfg;
  bit is_active = 1;   // UVM_ACTIVE / UVM_PASSIVE
  uvm_analysis_port #(mp_sequence_item) ap;

  function new(string name = "mp_agent", uvm_component parent = null);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    // Get configuration
    if (!uvm_config_db#(protocol_e)::get(this, "", "protocol", protocol))
      protocol = PROTO_PCIE_GEN5;
    if (!uvm_config_db#(bit)::get(this, "", "is_active", is_active))
      is_active = 1;
    void'(uvm_config_db#(protocol_cfg_t)::get(this, "", "cfg", cfg));
    // Create monitor (always present)
    mon = mp_monitor::type_id::create("mon", this);
    // Create sequencer and driver only for active agents
    if (is_active) begin
      sqr = mp_sequencer::type_id::create("sqr", this);
      drv = mp_driver::type_id::create("drv", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (is_active)
      drv.seq_item_port.connect(sqr.seq_item_export);
    mon.ap.connect(ap);
  endfunction

  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    // Pass configuration to sub-components
    if (sqr != null) uvm_config_db#(protocol_e)::set(sqr, "", "protocol", protocol);
    if (drv != null) uvm_config_db#(protocol_e)::set(drv, "", "protocol", protocol);
    if (mon != null) uvm_config_db#(protocol_e)::set(mon, "", "protocol", protocol);
    if (drv != null) uvm_config_db#(protocol_cfg_t)::set(drv, "", "cfg", cfg);
    if (mon != null) uvm_config_db#(protocol_cfg_t)::set(mon, "", "cfg", cfg);
  endfunction
endclass
`endif
