// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Monitor
// Decodes SOP/EOP-framed transfers from the bus into mp_sequence_item
// transactions (header capture, payload unpacking, error flag tracking).
//============================================================================
`ifndef MP_MONITOR_SV
`define MP_MONITOR_SV
`include "uvm_macros.svh"
import uvm_pkg::*;


class mp_monitor extends uvm_monitor;
  `uvm_component_utils(mp_monitor)
  virtual mp_vip_if vif;
  protocol_e     protocol;
  protocol_cfg_t cfg;
  uvm_analysis_port #(mp_sequence_item) ap;

  int unsigned txn_count = 0;
  int unsigned error_count = 0;

  // in-flight burst state
  protected mp_sequence_item item;
  protected int unsigned     data_idx;
  protected bit              err_seen;

  function new(string name = "mp_monitor", uvm_component parent = null);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual mp_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "Virtual interface not found")
    if (!uvm_config_db#(protocol_e)::get(this, "", "protocol", protocol))
      protocol = PROTO_PCIE_GEN5;
    void'(uvm_config_db#(protocol_cfg_t)::get(this, "", "cfg", cfg));
  endfunction

  function automatic void open_item();
    item = mp_sequence_item::type_id::create("item");
    item.txn.protocol    = protocol;
    item.txn.address     = (protocol == PROTO_UCIE) ?
                           {48'h0, vif.monitor_cb.data[vif.DATA_WIDTH-1 -: 16]} :
                           vif.monitor_cb.data[vif.DATA_WIDTH-1 -: 64];
    item.txn.requester_id = vif.monitor_cb.requester_id;
    item.txn.completer_id = vif.monitor_cb.completer_id;
    item.txn.tag         = vif.monitor_cb.tag;
    item.txn.tc          = vif.monitor_cb.tc;
    item.txn.ep          = vif.monitor_cb.ep;
    item.txn.td          = vif.monitor_cb.td;
    item.txn.attr        = vif.monitor_cb.attr;
    item.txn.length_dw   = vif.monitor_cb.length_dw;
    item.txn.length      = int'(vif.monitor_cb.length_dw) * 4;
    item.txn.ualink_vc   = vif.monitor_cb.ualink_vc;
    item.txn.ucie_vc     = vif.monitor_cb.ucie_vc;
    item.txn.ucie_credits = vif.monitor_cb.ucie_credits;
    item.txn.txn_type    = (protocol == PROTO_UALINK) ? UALINK_FLIT :
                           (protocol == PROTO_UCIE)   ? UCIE_DATA_WR :
                           (protocol inside {PROTO_CXL_20, PROTO_CXL_30}) ?
                           CXL_MEM_WR : TLP_MEM_WR;
    item.txn.status      = TXN_ACTIVE;
    item.txn.data        = new[1024];
    data_idx = 0;
    err_seen = 1'b0;
    // UALink/UCIe header flit carries payload word 0
    if (protocol inside {PROTO_UALINK, PROTO_UCIE}) begin
      item.txn.data[0] = vif.monitor_cb.data[31:0];
      data_idx = 1;
    end
  endfunction

  function automatic void close_item();
    if (item == null) return;
    item.txn.data = new[data_idx](item.txn.data);
    item.txn.set_complete(err_seen ? TXN_ERROR : TXN_COMPLETE);
    txn_count++;
    if (err_seen) error_count++;
    `uvm_info("MONITOR", $sformatf("Observed: %s", item.convert2string()), UVM_HIGH)
    ap.write(item);
    item = null;
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.monitor_cb);
      if (vif.monitor_cb.ecrc_error || vif.monitor_cb.lcrc_error ||
          vif.monitor_cb.framing_error || vif.monitor_cb.protocol_error)
        err_seen = 1'b1;

      if (vif.monitor_cb.valid && vif.monitor_cb.ready) begin
        if (vif.monitor_cb.sop) begin
          if (item != null) close_item();   // dangling burst (protocol error)
          open_item();
        end
        else if (item != null) begin
          // payload beat: unpack DATA_WIDTH/32 words
          for (int j = 0; j < (vif.DATA_WIDTH/32) && data_idx < 1024; j++)
            item.txn.data[data_idx++] = vif.monitor_cb.data[j*32 +: 32];
        end
        if (vif.monitor_cb.eop && item != null)
          close_item();
      end
    end
  endtask

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("MONITOR_REPORT", $sformatf("Protocol: %s | Observed: %0d | Errors: %0d",
              protocol.name(), txn_count, error_count), UVM_LOW)
  endfunction
endclass
`endif
