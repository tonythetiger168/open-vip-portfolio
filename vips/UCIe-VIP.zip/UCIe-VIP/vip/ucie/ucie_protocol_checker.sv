// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// UCIe Protocol Checker
// Protocol-specific assertions for UCIe die-to-die link (credits, VCs)
//============================================================================
`ifndef UCIE_PROTOCOL_CHECKER_SV
`define UCIE_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

// ============================================================================
// ucie_protocol_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module ucie_protocol_checker_sva (mp_vip_if vif);

    int credit_err_cnt;
  int vc_err_cnt;
  int framing_err_cnt;
  int hsk_err_cnt;

    initial begin
    credit_err_cnt = 0; vc_err_cnt = 0; framing_err_cnt = 0; hsk_err_cnt = 0;
    end


  // UCIe VC is 4-bit: 16 virtual channels max
  property p_ucie_vc;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid) |-> vif.ucie_vc inside {[4'h0:4'hF]};
  endproperty
  assert_ucie_vc: assert property(p_ucie_vc)
  else begin
    `uvm_error("UCIE_CHK", "UCIe VC out of range")
    vc_err_cnt++;
  end

  // Credits must be non-zero when starting a transfer
  property p_ucie_credits;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.ucie_credits > 8'h00;
  endproperty
  assert_ucie_credits: assert property(p_ucie_credits)
  else begin
    `uvm_error("UCIE_CHK", "UCIe transfer with zero credits")
    credit_err_cnt++;
  end

  // UCIe register/data bursts are short (<= 64 DW)
  property p_ucie_burst;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.length_dw <= 10'd64;
  endproperty
  assert_ucie_burst: assert property(p_ucie_burst)
  else begin
    `uvm_error("UCIE_CHK", "UCIe burst too long")
    framing_err_cnt++;
  end

  // Handshake: valid must eventually be accepted
  property p_ucie_handshake;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.valid |-> ##[1:100] vif.ready;
  endproperty
  assert_ucie_hsk: assert property(p_ucie_handshake)
  else begin
    `uvm_error("UCIE_CHK", "UCIe valid-ready timeout")
    hsk_err_cnt++;
  end

  final begin
    `uvm_info("UCIE_RPT", $sformatf("UCIe Chk | Credit:%0d VC:%0d Framing:%0d Hsk:%0d",
              credit_err_cnt, vc_err_cnt, framing_err_cnt, hsk_err_cnt), UVM_LOW)
    end
endmodule

// ============================================================================
// ucie_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the ucie_protocol_checker_sva module above)
// ============================================================================
class ucie_protocol_checker extends uvm_component;
  `uvm_component_utils(ucie_protocol_checker)
  function new(string name = "ucie_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
