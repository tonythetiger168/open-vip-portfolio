# UCIe — UCIe (Universal Chiplet Interconnect Express) UVM VIP

Coverage-driven UVM verification IP for **UCIe**, built on a multi-protocol
skeleton (PCIe Gen5/Gen6, CXL 2.0/3.0, UALink companion UVCs share the same
`mp_vip_if` / `mp_vip_pkg` base so the fixed regression harness compiles and
runs all protocol agents).

## Protocol overview

UCIe is a die-to-die chiplet interconnect. Traffic is framed as header
flit + payload flits (`SOP`/`EOP` with `VALID`/`READY` handshake), is
credit-based (`ucie_credits`, non-zero before a transfer may start), uses
4-bit virtual channels (`ucie_vc`), short register/data bursts (<= 64 DW),
and reports link state through an LTSSM-style `link_state`. Backpressure
rules require flit data to stay stable while `VALID` is high and `READY`
is low.

## Architecture

| Path | Description |
|------|-------------|
| `rtl/mp_vip_if.sv` | Multi-protocol interface (params `DATA_WIDTH/LANE_COUNT/PROTOCOL`), driver/monitor clocking blocks, modports, inline SVA + 2 covergroups, UALink sideband helpers |
| `vip/base/mp_vip_pkg.sv` | Enums (`protocol_e/link_state_e/tlp_type_e/txn_status_e`), `mp_txn_descriptor`, `mp_sequence_item`, `mp_protocol_config`, `mp_coverage_model` (6 covergroups), end-to-end `mp_scoreboard` |
| `vip/base/mp_driver.sv` | Protocol-aware driver: SOP/EOP framing, per-beat READY handshake, UALink flit mode + header flit packing |
| `vip/base/mp_monitor.sv` | Bus decoder: header capture, payload unpacking, error-flag tracking, publishes transactions |
| `vip/base/mp_agent.sv` / `mp_sequencer.sv` | Active/passive agent with protocol configuration propagation |
| `vip/ucie/ucie_protocol_checker.sv` | UCIe-specific protocol checker (VC range, non-zero credits, burst length, handshake) |
| `vip/{pcie,cxl,ualink}/*_protocol_checker.sv` | Companion protocol checkers |
| `rtl/sva/ucie_compliance_checker.sv` | Tiered SVA compliance checker (L1/L2/L3/L4) |
| `env/mp_env.sv` | 6-agent environment + end-to-end scoreboard wiring + coverage |
| `sequences/` | Sequence library (see below) |
| `tests/` | `mp_base_test` + per-protocol standalone tests + regression/PM/error tests |
| `tb/top_tb.sv` | Testbench top + functional DUT model (per-protocol responder channels, ECRC error region `0xEE??_????`, wait-state stalls) |
| `scripts/` | Makefile + coverage-driven regression (line/fsm/toggle/SVA, 100% goal) |

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `mp_base_sequence` | Random transactions for a target protocol |
| `mp_random_sequence` | Weighted-protocol random traffic |
| `mp_error_inject_sequence` | Directed: ECRC error-region + poisoned/short-frame/timeout variants |
| `mp_power_mgmt_sequence` | Directed: L0s/L1/L2/Recovery transitions |
| `mp_back_to_back_sequence` | Directed: zero-delay back-to-back flits |
| `mp_stress_sequence` | Directed: high-volume large (256–512 B) payloads |
| `mp_reset_sequence` | Directed: transfer right after reset release |
| `mp_corner_sequence` | Directed: min/max payload corners (4/64/256/512 B) |
| `mp_regression_sequence` | Weighted multi-phase mix incl. all directed sequences |

## SVA compliance (rtl/sva/ucie_compliance_checker.sv)

- **L1 Basic (4)**: valid⇒ready, VC 0–15, adapter stable, SOP lane alignment
- **L2 Full protocol (6)**: credit decrement, no-X data, link-up for traffic, EOP follows SOP, flit boundary, retry limit
- **L3 Advanced (6)**: PM states, die-to-die ID, link training, CRC per flit, latency target, bandwidth monitor
- **L4 UCIe-specific (4)**: VC stable within a burst, credits replenished after a burst, flit stable under backpressure, bursts complete within 64 flits

## Functional coverage (vip/base/mp_vip_pkg.sv)

- `cg_txn_type`: protocol × transaction-type cross
- `cg_address_map`: address range + alignment
- `cg_data_patterns`: all-0/all-1/walking/random × cross
- `cg_latency`: latency distribution × protocol cross
- `cg_error_injection`: error type × recovery cross
- `cg_link_state`: link-state FSM + transition bins (link-up flow, L0⇄L0s/L1/L2, recovery)

## Quick start

```bash
cd scripts
make all                          # single run (VCS default)
TEST=mp_ucie_test make all
./coverage_regression.sh          # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

## Deepened Features (v1.6.0)

- **Protocol-aware driver**: UCIe credit-based flit header+payload packing, per-beat READY handshakes with backpressure hold, delay injection, expected-item broadcast
- **Waveform-decoding monitor**: SOP/EOP burst reconstruction with header capture, payload unpacking and error-flag tracking
- **End-to-end scoreboard**: driver-issued (expected) vs monitor-decoded (observed) compare (protocol/address/length/payload) with `n_matches`/`n_mismatches` and `UVM_ERROR` on mismatch
- **Functional DUT model**: per-protocol responder channels with link-state generation, loopback READY, periodic wait-state stalls, ECRC error region
- **Directed sequence library**: 9 sequences (error / power-mgmt / back-to-back / stress / reset / corner / regression)
- **SVA L4**: 4 UCIe-specific rules
- **Functional coverage**: 6 covergroups with cross coverage (incl. link-state FSM transitions)

License: Apache-2.0
