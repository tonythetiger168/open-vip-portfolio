# UCIe UVM VIP (UCIe-VIP)

UCIe UVM VIP: die-to-die streaming flit channel (64-bit data, valid/ready handshake in both directions, last-beat marker) with 8-deep FIFO. Smoke checks cover ordering, tlast propagation and transmit backpressure for chiplet link bring-up.

## Structure

- `ucie/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `ucie_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `ucie_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural UCIe DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/UCIe-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh UCIe-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
