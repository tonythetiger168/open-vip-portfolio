# UCIe UVM VIP (UCIe-VIP)

UCIe UVM VIP: die-to-die streaming flit channel (64-bit data, valid/ready handshake in both directions, last-beat marker) with 8-deep FIFO. Smoke checks cover ordering, tlast propagation and transmit backpressure for chiplet link bring-up.

## Structure

- `ucie/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `ucie_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `ucie_base_test` (constrained-random), `ucie_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural UCIe DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Link training and flit retry reference (`ucie_d2d/`, v1.9.0)

The agent above drives a flit FIFO. `ucie_d2d/` adds a die-to-die model of
the link training state machine and the D2D Adapter retry, and a
link-partner test:

| File | Content |
|---|---|
| `ucie_d2d/tb/ucie_d2d_model.sv` | RESET -> SBINIT (patterns, done handshakes) -> MBINIT (parameter exchange, lane repair: x16, x8 on either half, TRAINERROR when both halves fail) -> MBTRAIN (speed degrade on remote or local failure) -> LINKINIT -> ACTIVE; PHYRETRAIN, L1 (refused with flits outstanding), TRAINERROR on sideband timeout; 68-byte flits (Format 2 layout: 2-byte header, 64 bytes, CRC-16) with go-back-N retry: sequence numbers, ACK / NAK in every flit or a NOP flit, single NAK, duplicates, retry-buffer back-pressure, NAK replay, replay timer, replay limit -> retrain |
| `ucie_d2d/tb/func_ucie_d2d_tb.sv` | sideband responder, flit partner with its own CRC-16 (checked against the CRC-16/CCITT-FALSE check value 29B1) and protocol-layer driver: 64 checks (`python3 tools/run_func_tests.py UCIe-VIP`, Verilator) |

The state sequence and the retry rules follow the UCIe specification's
structure; the sideband message codes, the flit header bit layout and the
CRC polynomial (a parameter, CRC-16/CCITT by default) are this model's own,
not the specification's encodings. 256-byte flit formats, multi-module
links and the real-time sideband packet format are not modelled
(sideband parity and runtime recalibration: see `ucie_sb3/`).

## Sideband additions reference (`ucie_sb3/`, UCIe 3.0, v1.11.0)

| File | Content |
|---|---|
| `ucie_sb3/tb/ucie_sb3_model.sv` | sideband packets with even parity; register reads and byte-enabled writes with completions (UR outside the register file); priority packets that overtake the normal queue; queue-full drops; management transport (fragments reassembled in order, 1 to 8 dwords, SOM restart, wrong sequence, overflow); runtime recalibration (mainband paused for RECAL_T clocks without retraining, busy while running, RecalDone); fast throttle levels and emergency shutdown |
| `ucie_sb3/tb/func_ucie_sb3_tb.sv` | sideband partner with its own reference: every opcode and error, priority ordering, recalibration timing and 3000 random packets with random back-pressure checked clock by clock: 36 checks (`python3 tools/run_func_tests.py UCIe-VIP`, Icarus) |

The packet layout, opcodes, status codes, queue depths and timers are this
model's own; the 48 / 64 GT/s mainband is not modelled.

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/UCIe-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh UCIe-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py UCIe-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
