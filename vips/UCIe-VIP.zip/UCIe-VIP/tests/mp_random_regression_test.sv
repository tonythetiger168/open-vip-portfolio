// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Random Regression Test
//============================================================================
`ifndef MP_RANDOM_REGRESSION_TEST_SV
`define MP_RANDOM_REGRESSION_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

class mp_random_regression_test extends mp_base_test;
  `uvm_component_utils(mp_random_regression_test)
  function new(string name = "mp_random_regression_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    mp_random_sequence seq;
    phase.raise_objection(this);
    // UALink-focused random regression (deepened VIP target)
    seq = mp_random_sequence::type_id::create("seq");
    seq.num_transactions = 500;
    seq.target_protocol = PROTO_UALINK;
    seq.enable_ualink = 1;
    seq.start(env.ualink_agent.sqr);
    // PCIe sanity traffic on the second agent
    seq = mp_random_sequence::type_id::create("seq2");
    seq.num_transactions = 100;
    seq.target_protocol = PROTO_PCIE_GEN5;
    seq.enable_pcie = 1;
    seq.start(env.pcie_gen5_agent.sqr);
    #5000ns;
    phase.drop_objection(this);
  endtask
endclass
`endif
