// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
/// UALink Standalone Test
// Tests UALink flit-based transport, control, and data operations
//===========================================================================
`ifndef MP_UALINK_TEST_SV
`define MP_UALINK_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

class mp_ualink_test extends mp_base_test;
  `uvm_component_utils(mp_ualink_test)
  function new(string name = "mp_ualink_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_pcie_gen5", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_pcie_gen6", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_cxl20", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_cxl30", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_ucie", 0);
  endfunction
  virtual task run_phase(uvm_phase phase);
    mp_random_sequence seq;
    phase.raise_objection(this);
    seq = mp_random_sequence::type_id::create("seq");
    seq.num_transactions = 200;
    seq.target_protocol = PROTO_UALINK;
    seq.start(env.ualink_agent.sqr);
    #2000ns;
    phase.drop_objection(this);
  endtask
endclass
`endif
