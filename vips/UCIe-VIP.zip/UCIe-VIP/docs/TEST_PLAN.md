# UCIe Test Plan（UCIe-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | UCIe |
| 家族 | Interconnect |
| 類型 | UVM VIP |
| 交付目錄 | `UCIe-VIP/` |
| 目前 L1b 狀態 | PASS(verilator) |

## 2. DUT / 待測對象

- 合成參考 RTL（`rtl/`）+ directed testbench（`tb/`）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke

- 狀態：**尚未導入**（目前為 model smoke / directed-tb smoke）
- 導入方式：比照 `gen_func_tb.py` 產出的 self-checking tb，對展平後的 behavioral model 做 directed 檢查

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Agent reset and first-transaction bring-up |
| PT-02 | Constrained-random sequence sweep (base sequence extended) |
| PT-03 | Error injection and protocol-violation response |
| PT-04 | Backpressure / wait-state interaction |
| PT-05 | End-to-end scoreboard matching (exp vs obs streams) |
| PT-06 | Coverage closure toward the self-served COV_GOAL=100 checklist |

## 5. 覆蓋與檢查

- （本 VIP 無獨立 SVA/coverage 檔案，覆蓋由 directed tb 之通過/失敗判定承擔。）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/UCIe-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py UCIe-VIP && python3 smoke/smoke_run.py UCIe-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- functional smoke 為後續補強對象。

---
*文件版本：v1.7.5 自動產生*
