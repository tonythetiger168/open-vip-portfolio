// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Interface
// Supports: PCIe, CXL, UCIe, UALink
//============================================================================
`ifndef MP_VIP_IF_SV
`define MP_VIP_IF_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

interface mp_vip_if #(parameter int DATA_WIDTH = 512,
                      parameter int LANE_COUNT = 16,
                      parameter int PROTOCOL = 0)
                     (input logic clk, input logic rst_n);

  //==========================================================================
  // Common Signals
  //==========================================================================
  logic                    valid;
  logic                    ready;
  logic [DATA_WIDTH-1:0]   data;
  logic [LANE_COUNT-1:0]   lane_valid;
  logic                    sop;       // Start of Packet
  logic                    eop;       // End of Packet
  logic [7:0]              be;        // Byte Enable

  //==========================================================================
  // Protocol-Specific Signals
  //==========================================================================
  // PCIe/CXL Signals
  logic [15:0] requester_id;
  logic [15:0] completer_id;
  logic [7:0]  tag;
  logic [2:0]  tc;          // Traffic Class
  logic        ep;          // Error Poisoned
  logic        td;          // TLP Digest
  logic [1:0]  attr;
  logic [9:0]  length_dw;
  // UCIe Signals
  logic [7:0]  ucie_credits;
  logic [3:0]  ucie_vc;     // Virtual Channel
  logic        ucie_adapt;
  // UALink Signals
  logic [3:0]  ualink_vc;
  logic [1:0]  ualink_qos;
  logic        ualink_flit_mode;
  // Link State
  link_state_e link_state;
  logic        link_up;
  // Error Signals
  logic        ecrc_error;
  logic        lcrc_error;
  logic        framing_error;
  logic        protocol_error;
  // Power Management
  logic        pm_request;
  logic [2:0]  pm_state;

  //==========================================================================
  // UALink sideband/helper signals (observed by the SVA compliance checker)
  //==========================================================================
  logic        retry_req;
  logic        retry_ack;
  logic [7:0]  credit;
  logic [3:0]  host_id;
  logic        shaper_en;
  logic        err_inject;
  // Default sideband behavior (no retry in flight, credits available)
  assign retry_req = 1'b0;
  assign retry_ack = 1'b1;
  assign credit    = 8'hFF;
  assign host_id   = 4'h0;
  assign shaper_en = |ualink_qos;
  assign err_inject = 1'b0;

  //==========================================================================
  // UCIe sideband/helper signals (observed by the SVA compliance checker)
  //==========================================================================
  logic        flit_boundary;
  logic [3:0]  retry_cnt;
  logic [3:0]  die_id;
  logic [2:0]  training_state;
  logic        crc_ok;
  logic [31:0] bandwidth;
  assign flit_boundary = 1'b1;
  assign retry_cnt     = 4'h0;
  assign die_id        = 4'h0;
  assign training_state = 3'h4;   // trained/operational
  assign crc_ok        = ~ecrc_error;
  assign bandwidth     = 32'h0000_4000;

  //==========================================================================
  // Clocking Blocks
  //==========================================================================
  clocking driver_cb @(posedge clk);
    default input #1step output #1ns;
    output valid, data, lane_valid, sop, eop, be;
    output requester_id, completer_id, tag, tc, ep, td, attr, length_dw;
    output ucie_credits, ucie_vc, ucie_adapt;
    output ualink_vc, ualink_qos, ualink_flit_mode;
    output pm_request, pm_state;
    input  ready, link_up, link_state;
    input  ecrc_error, lcrc_error, framing_error, protocol_error;
  endclocking

  clocking monitor_cb @(posedge clk);
    default input #1step;
    input valid, ready, data, lane_valid, sop, eop, be;
    input requester_id, completer_id, tag, tc, ep, td, attr, length_dw;
    input ucie_credits, ucie_vc, ucie_adapt;
    input ualink_vc, ualink_qos, ualink_flit_mode;
    input link_up, link_state;
    input ecrc_error, lcrc_error, framing_error, protocol_error;
    input pm_request, pm_state;
  endclocking

  //==========================================================================
  // Modports
  //==========================================================================
  modport driver_mp  (clocking driver_cb, input clk, rst_n);
  modport monitor_mp (clocking monitor_cb, input clk, rst_n);

  //==========================================================================
  // Assertion: Valid-Ready Handshake
  //==========================================================================
  property p_valid_ready_handshake;
    @(posedge clk) disable iff (!rst_n) valid |-> ##[1:100] ready;
  endproperty
  assert_valid_ready: assert property(p_valid_ready_handshake)
    else `uvm_error("MP_IF", "Valid-Ready handshake timeout");

  //==========================================================================
  // Assertion: SOP-EOP Alignment
  //==========================================================================
  property p_sop_eop_alignment;
    @(posedge clk) disable iff (!rst_n) sop |-> (!eop ##[1:256] eop);
  endproperty
  assert_sop_eop: assert property(p_sop_eop_alignment)
    else `uvm_error("MP_IF", "SOP-EOP alignment violation");

  //==========================================================================
  // Assertion: Link State Validity
  //==========================================================================
  property p_link_state_valid;
    @(posedge clk) disable iff (!rst_n)
      link_state inside {LINK_RESET, LINK_DETECT, LINK_POLLING, LINK_CONFIG,
                         LINK_L0, LINK_L0S, LINK_L1, LINK_L2, LINK_RECOVERY,
                         LINK_DISABLED, LINK_LOOPBACK, LINK_HOT_RESET};
  endproperty
  assert_link_state: assert property(p_link_state_valid)
    else `uvm_error("MP_IF", "Invalid link state detected");

  //==========================================================================
  // Coverage: Interface Activity
  //==========================================================================
  covergroup cg_interface_activity @(posedge clk);
    option.per_instance = 1;
    cp_valid: coverpoint valid { bins inactive = {0}; bins active = {1}; }
    cp_ready: coverpoint ready { bins inactive = {0}; bins active = {1}; }
    cp_handshake: coverpoint {valid, ready} {
      bins idle = {2'b00}; bins wait_ready = {2'b10};
      bins transfer = {2'b11}; bins wait_valid = {2'b01};
    }
    cp_link_state: coverpoint link_state;
    cp_error: coverpoint {ecrc_error, lcrc_error, framing_error, protocol_error} {
      bins no_error = {4'b0000}; bins ecrc_err = {4'b1000};
      bins lcrc_err = {4'b0100}; bins frame_err = {4'b0010}; bins proto_err = {4'b0001};
    }
    cross_hs_state: cross cp_handshake, cp_link_state;
  endgroup

  //==========================================================================
  // PIPE PHY Layer Signals (PCIe/CXL Physical Layer)
  //==========================================================================
  // TX Data Path
  logic [31:0] pipe_tx_data;
  logic [3:0]  pipe_tx_data_k;
  logic        pipe_tx_detect_rx;
  logic        pipe_tx_elecidle;
  logic [2:0]  pipe_tx_deemph;
  logic [1:0]  pipe_tx_margin;
  logic        pipe_tx_swing;
  logic        pipe_tx_sync;
  // RX Data Path
  logic [31:0] pipe_rx_data;
  logic [3:0]  pipe_rx_data_k;
  logic        pipe_rx_valid;
  logic        pipe_rx_elecidle;
  logic [2:0]  pipe_rx_status;

  //==========================================================================
  // Coverage: PHY Layer Activity
  //==========================================================================
  covergroup cg_phy_layer @(posedge clk);
    option.per_instance = 1;
    cp_tx_elecidle: coverpoint pipe_tx_elecidle { bins active = {0}; bins idle = {1}; }
    cp_rx_valid:    coverpoint pipe_rx_valid    { bins invalid = {0}; bins valid = {1}; }
    cp_lane_valid:  coverpoint $countones(lane_valid) {
      bins x1 = {1}; bins x4 = {4}; bins x8 = {8}; bins x16 = {16}; bins other = default;
    }
    cross_idle_rx: cross cp_tx_elecidle, cp_rx_valid;
  endgroup

  cg_interface_activity cg_act = new();
  cg_phy_layer          cg_phy = new();

endinterface
`endif
