// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// UCIe Tiered Compliance SVA Checker
// Level: Complex | Total SVAs: 16
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
`ifndef UCIE_COMPLIANCE_CHECKER_SV
`define UCIE_COMPLIANCE_CHECKER_SV

// ============================================================================
// ucie_compliance_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module ucie_compliance_checker_sva (mp_vip_if vif);

    int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[6], l3_fail[6];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

    initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
    end


  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_ucie_valid_ready; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> ##[1:16] vif.ready; endproperty
  assert_p_ucie_valid_ready: assert property(p_ucie_valid_ready) l1_pass[0]++; else begin `uvm_warning("UCIE_L1", "Valid implies ready failed"); l1_fail[0]++; end
  cover_p_ucie_valid_ready: cover property(p_ucie_valid_ready);
  property p_ucie_vc_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ucie_vc <= 4'd15; endproperty
  assert_p_ucie_vc_valid: assert property(p_ucie_vc_valid) l1_pass[1]++; else begin `uvm_warning("UCIE_L1", "VC 0-15 failed"); l1_fail[1]++; end
  cover_p_ucie_vc_valid: cover property(p_ucie_vc_valid);
  property p_ucie_adapt_stable; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> $stable(vif.ucie_adapt); endproperty
  assert_p_ucie_adapt_stable: assert property(p_ucie_adapt_stable) l1_pass[2]++; else begin `uvm_warning("UCIE_L1", "Adapt stable failed"); l1_fail[2]++; end
  cover_p_ucie_adapt_stable: cover property(p_ucie_adapt_stable);
  property p_ucie_sop_aligned; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sop |-> vif.lane_valid[0]; endproperty
  assert_p_ucie_sop_aligned: assert property(p_ucie_sop_aligned) l1_pass[3]++; else begin `uvm_warning("UCIE_L1", "SOP aligned failed"); l1_fail[3]++; end
  cover_p_ucie_sop_aligned: cover property(p_ucie_sop_aligned);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_ucie_credit_mgmt; @(posedge vif.clk) disable iff (!vif.rst_n) $fell(vif.ucie_credits) |-> $past(vif.valid,1); endproperty
  assert_p_ucie_credit_mgmt: assert property(p_ucie_credit_mgmt) l2_pass[0]++; else begin `uvm_warning("UCIE_L2", "Credits decrement failed"); l2_fail[0]++; end
  cover_p_ucie_credit_mgmt: cover property(p_ucie_credit_mgmt);
  property p_ucie_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_ucie_no_x: assert property(p_ucie_no_x) l2_pass[1]++; else begin `uvm_warning("UCIE_L2", "No X when valid failed"); l2_fail[1]++; end
  cover_p_ucie_no_x: cover property(p_ucie_no_x);
  property p_ucie_link_up; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.link_up; endproperty
  assert_p_ucie_link_up: assert property(p_ucie_link_up) l2_pass[2]++; else begin `uvm_warning("UCIE_L2", "Link up for traffic failed"); l2_fail[2]++; end
  cover_p_ucie_link_up: cover property(p_ucie_link_up);
  property p_ucie_eop_follows_sop; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> $past(vif.sop,1) || vif.sop; endproperty
  assert_p_ucie_eop_follows_sop: assert property(p_ucie_eop_follows_sop) l2_pass[3]++; else begin `uvm_warning("UCIE_L2", "EOP follows SOP failed"); l2_fail[3]++; end
  cover_p_ucie_eop_follows_sop: cover property(p_ucie_eop_follows_sop);
  property p_ucie_flit_boundary; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sop |-> vif.flit_boundary == 1; endproperty
  assert_p_ucie_flit_boundary: assert property(p_ucie_flit_boundary) l2_pass[4]++; else begin `uvm_warning("UCIE_L2", "Flit boundary valid failed"); l2_fail[4]++; end
  cover_p_ucie_flit_boundary: cover property(p_ucie_flit_boundary);
  property p_ucie_retry; @(posedge vif.clk) disable iff (!vif.rst_n) vif.retry_cnt <= 4'd15; endproperty
  assert_p_ucie_retry: assert property(p_ucie_retry) l2_pass[5]++; else begin `uvm_warning("UCIE_L2", "Retry limit failed"); l2_fail[5]++; end
  cover_p_ucie_retry: cover property(p_ucie_retry);

  // ===== L3: Advanced Features (6 SVAs) =====
  property p_ucie_pm_active; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ucie_pm_active: assert property(p_ucie_pm_active) l3_pass[0]++; else begin `uvm_warning("UCIE_L3", "PM active state failed"); l3_fail[0]++; end
  cover_p_ucie_pm_active: cover property(p_ucie_pm_active);
  property p_ucie_die2die; @(posedge vif.clk) disable iff (!vif.rst_n) vif.die_id <= 4'd15; endproperty
  assert_p_ucie_die2die: assert property(p_ucie_die2die) l3_pass[1]++; else begin `uvm_warning("UCIE_L3", "Die-to-die valid failed"); l3_fail[1]++; end
  cover_p_ucie_die2die: cover property(p_ucie_die2die);
  property p_ucie_link_training; @(posedge vif.clk) disable iff (!vif.rst_n) vif.training_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ucie_link_training: assert property(p_ucie_link_training) l3_pass[2]++; else begin `uvm_warning("UCIE_L3", "Link training failed"); l3_fail[2]++; end
  cover_p_ucie_link_training: cover property(p_ucie_link_training);
  property p_ucie_crc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.crc_ok; endproperty
  assert_p_ucie_crc: assert property(p_ucie_crc) l3_pass[3]++; else begin `uvm_warning("UCIE_L3", "CRC per flit failed"); l3_fail[3]++; end
  cover_p_ucie_crc: cover property(p_ucie_crc);
  property p_ucie_latency; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> ##[1:8] vif.ready; endproperty
  assert_p_ucie_latency: assert property(p_ucie_latency) l3_pass[4]++; else begin `uvm_warning("UCIE_L3", "Latency target failed"); l3_fail[4]++; end
  cover_p_ucie_latency: cover property(p_ucie_latency);
  property p_ucie_bandwidth; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bandwidth <= 32'hFFFFFFFF; endproperty
  assert_p_ucie_bandwidth: assert property(p_ucie_bandwidth) l3_pass[5]++; else begin `uvm_warning("UCIE_L3", "Bandwidth monitor failed"); l3_fail[5]++; end
  cover_p_ucie_bandwidth: cover property(p_ucie_bandwidth);

  // ---------------- L4: UCIe protocol-specific rules (4) ----------------
  // L4-1: VC must remain stable within a burst (SOP through EOP)
  property p_ucie_l4_vc_stable;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && !vif.sop && $past(vif.valid)) |-> $stable(vif.ucie_vc);
  endproperty
  assert_p_ucie_l4_vc_stable: assert property(p_ucie_l4_vc_stable) l4_pass[0]++;
    else begin `uvm_warning("UCIE_L4", "VC changed mid-burst"); l4_fail[0]++; end
  cover_p_ucie_l4_vc_stable: cover property(p_ucie_l4_vc_stable);

  // L4-2: credits are replenished back to a non-zero value after a burst
  property p_ucie_l4_credit_replenish;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.eop) |-> s_eventually (vif.ucie_credits > 8'h00);
  endproperty
  assert_p_ucie_l4_credit_replenish: assert property(p_ucie_l4_credit_replenish) l4_pass[1]++;
    else begin `uvm_warning("UCIE_L4", "Credits never replenished"); l4_fail[1]++; end
  cover_p_ucie_l4_credit_replenish: cover property(p_ucie_l4_credit_replenish);

  // L4-3: payload data is stable while VALID is high and READY is low (backpressure)
  property p_ucie_l4_backpressure_stable;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && !vif.ready) |=> $stable({vif.data, vif.sop, vif.eop}) && vif.valid;
  endproperty
  assert_p_ucie_l4_backpressure_stable: assert property(p_ucie_l4_backpressure_stable) l4_pass[2]++;
    else begin `uvm_warning("UCIE_L4", "Flit changed under backpressure"); l4_fail[2]++; end
  cover_p_ucie_l4_backpressure_stable: cover property(p_ucie_l4_backpressure_stable);

  // L4-4: sideband/register traffic (short bursts) completes within 64 flits
  property p_ucie_l4_short_burst;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop && !vif.eop) |-> ##[1:64] (vif.valid && vif.eop);
  endproperty
  assert_p_ucie_l4_short_burst: assert property(p_ucie_l4_short_burst) l4_pass[3]++;
    else begin `uvm_warning("UCIE_L4", "Burst exceeds 64 flits"); l4_fail[3]++; end
  cover_p_ucie_l4_short_burst: cover property(p_ucie_l4_short_burst);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0;
    int l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ?
                ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("UCIE_RPT", $sformatf("=== UCIe Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("UCIE_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("UCIE_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("UCIE_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("UCIE_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("UCIE_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov,
              l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
    end

endmodule

// ============================================================================
// ucie_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the ucie_compliance_checker_sva module above)
// ============================================================================
class ucie_compliance_checker extends uvm_component;
  `uvm_component_utils(ucie_compliance_checker)
  function new(string name = "ucie_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
