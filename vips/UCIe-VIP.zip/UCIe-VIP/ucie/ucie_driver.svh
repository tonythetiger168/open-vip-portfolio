// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_driver.svh -- UCIe driver: flits on tvalid/tready (tlast on the last), random rready on the receive side

class ucie_driver extends uvm_driver #(ucie_transaction);
  `uvm_component_utils(ucie_driver)

  uvm_analysis_port #(ucie_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ucie_if vif;
  ucie_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ucie_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ucie: virtual interface not set")
    if (!uvm_config_db#(ucie_config)::get(this, "", "cfg", cfg))
      cfg = ucie_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ucie_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      forever begin
        @(vif.drv_cb);
        vif.drv_cb.rready <= ($urandom_range(99) < cfg.rready_pct);
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.tvalid <= 1'b0; vif.drv_cb.tdata <= '0; vif.drv_cb.tlast <= 1'b0;
    vif.drv_cb.rready <= 1'b0;
  endtask

  task drive_item(ucie_transaction t);
    @(vif.drv_cb);
    foreach (t.flits[i]) begin
      vif.drv_cb.tvalid <= 1'b1;
      vif.drv_cb.tdata  <= t.flits[i];
      vif.drv_cb.tlast  <= (i == t.flits.size() - 1);
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.tready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.tready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("UCIe tready: no response within %0d cycles", cfg.timeout_cycles))
      end
    end
    vif.drv_cb.tvalid <= 1'b0;
    vif.drv_cb.tlast  <= 1'b0;
  endtask

endclass
