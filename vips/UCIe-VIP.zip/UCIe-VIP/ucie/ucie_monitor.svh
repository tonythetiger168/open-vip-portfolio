// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_monitor.svh -- UCIe monitor: decodes observed bus activity

class ucie_monitor extends uvm_monitor;
  `uvm_component_utils(ucie_monitor)

  virtual ucie_if vif;
  uvm_analysis_port #(ucie_transaction) ap;
  ucie_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ucie_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ucie: virtual interface not set")
    void'(uvm_config_db#(ucie_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    ucie_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = ucie_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.tvalid = vif.tvalid;
        t.tdata = vif.tdata;
        t.tlast = vif.tlast;
        t.rready = vif.rready;
        t.tready_o = vif.tready;
        t.rvalid_o = vif.rvalid;
        t.rdata_o = vif.rdata;
        t.rlast_o = vif.rlast;
        ap.write(t);
      end
    end
  endtask
endclass
