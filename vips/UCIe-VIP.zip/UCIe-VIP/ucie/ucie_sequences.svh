// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_sequences.svh -- UCIe sequences

// Random traffic: cfg.num_items constrained-random items.
class ucie_base_sequence extends uvm_sequence #(ucie_transaction);
  `uvm_object_utils(ucie_base_sequence)
  ucie_config cfg;

  function new(string name = "ucie_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ucie_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ucie_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ucie_directed_sequence extends uvm_sequence #(ucie_transaction);
  `uvm_object_utils(ucie_directed_sequence)
  ucie_config cfg;

  function new(string name = "ucie_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ucie_transaction item();
    item = ucie_transaction::type_id::create("req");
  endfunction

  task send(ucie_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ucie_transaction t;
    t = item(); t.seed = 32'h11; t.fill_flits(1); send(t);
    t = item(); t.seed = 32'h12; t.fill_flits(8); send(t);    // exactly the FIFO depth
    t = item(); t.seed = 32'h13; t.fill_flits(20); send(t);   // longer than the FIFO: tready back-pressure
    t = item(); t.flits = '{64'h0, 64'hFFFF_FFFF_FFFF_FFFF, 64'h8000_0000_0000_0001}; send(t);
  endtask
endclass
