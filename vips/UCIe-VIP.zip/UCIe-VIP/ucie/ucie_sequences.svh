// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_sequences.svh -- UCIe sequences

class ucie_base_sequence extends uvm_sequence #(ucie_transaction);
  `uvm_object_utils(ucie_base_sequence)
  ucie_config cfg;
  function new(string name = "ucie_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin
      `uvm_do_with(req, 1 == 1)
    end
  endtask
endclass
