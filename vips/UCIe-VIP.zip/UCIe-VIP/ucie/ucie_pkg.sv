// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_pkg.sv -- UCIe UVM VIP package

package ucie_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ucie_defs_pkg::*;
  export ucie_defs_pkg::*;

  `include "ucie_transaction.svh"
  `include "ucie_config.svh"
  `include "ucie_sequencer.svh"
  `include "ucie_driver.svh"
  `include "ucie_monitor.svh"
  `include "ucie_agent.svh"
  `include "ucie_sequences.svh"
  `include "ucie_checker.svh"
  `include "ucie_coverage.svh"
endpackage
