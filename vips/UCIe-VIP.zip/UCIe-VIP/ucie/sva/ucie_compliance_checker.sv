// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_compliance_checker.sv -- UCIe concurrent assertion checks (bindable)

module ucie_compliance_checker
  (input logic clk, input logic rst_n, input tvalid, input [63:0] tdata, input tlast, input tready, input rvalid, input [63:0] rdata, input rlast, input rready);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tready, rvalid, rdata, rlast}))
    else $error("UCIe: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> tready == '0)
    else $error("UCIe: output not in reset value");
  // a stalled flit must hold its payload
  assert property (@(posedge clk) disable iff (!rst_n) tvalid && !tready |=> tvalid && $stable(tdata) && $stable(tlast))
    else $error("UCIe: flit not held under backpressure");
  cover property (@(posedge clk) disable iff (!rst_n) (tready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (tvalid && tready && tlast));
endmodule
