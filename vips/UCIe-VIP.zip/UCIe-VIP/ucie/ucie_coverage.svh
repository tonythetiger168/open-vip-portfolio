// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_coverage.svh -- UCIe functional coverage

class ucie_coverage extends uvm_subscriber #(ucie_transaction);
  `uvm_component_utils(ucie_coverage)
  ucie_config cfg;
  ucie_transaction tr;

  covergroup ucie_cg;
    cp_len : coverpoint tr.flits.size() { bins one = {1}; bins fits = {[2:8]}; bins overflows = {[9:20]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ucie_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ucie_config)::get(this, "", "cfg", cfg))
      cfg = ucie_config::type_id::create("cfg");
  endfunction

  function void write(ucie_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ucie_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("UCIe coverage: %0.1f%%", ucie_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
