// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_if.sv -- UCIe interface

interface ucie_if (input logic clk);
  logic rst_n;

  logic tvalid;
  logic [63:0] tdata;
  logic tlast;
  logic tready;
  logic rvalid;
  logic [63:0] rdata;
  logic rlast;
  logic rready;

  modport DUT (input clk, rst_n, tvalid, tdata, tlast, rready, output tready, rvalid, rdata, rlast);
  modport DRV (input clk, rst_n, tready, rvalid, rdata, rlast, output tvalid, tdata, tlast, rready);
  modport MON (input clk, rst_n, tvalid, tdata, tlast, tready, rvalid, rdata, rlast, rready);

  clocking drv_cb @(posedge clk);
    input rst_n, tvalid, tdata, tlast, tready, rvalid, rdata, rlast, rready;
    output tvalid, tdata, tlast, rready;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, tvalid, tdata, tlast, tready, rvalid, rdata, rlast, rready;
  endclocking
endinterface
