// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_transaction.svh -- UCIe transaction

class ucie_transaction extends uvm_sequence_item;
  `uvm_object_utils(ucie_transaction)

  rand bit tvalid;
  rand bit [63:0] tdata;
  rand bit tlast;
  rand bit rready;
  bit tready_o;
  bit rvalid_o;
  bit [63:0] rdata_o;
  bit rlast_o;
  bit [31:0] tag;

  function new(string name = "ucie_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    ucie_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    tvalid = rhs_.tvalid;
    tdata = rhs_.tdata;
    tlast = rhs_.tlast;
    rready = rhs_.rready;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ucie_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           tvalid == rhs_.tvalid &&
           tdata == rhs_.tdata &&
           tlast == rhs_.tlast &&
           rready == rhs_.rready;
  endfunction

  function string convert2string();
    return $sformatf("UCIe{tag=%0h tvalid=0x%0h tdata=0x%0h tlast=0x%0h rready=0x%0h}", tag, tvalid, tdata, tlast, rready);
  endfunction
endclass
