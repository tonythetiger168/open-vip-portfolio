// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ucie_transaction.svh -- UCIe transaction

class ucie_transaction extends uvm_sequence_item;
  `uvm_object_utils(ucie_transaction)

  // request (driven by the agent)
  bit [63:0] flits[$];
  // response (returned by the DUT)
  bit [63:0] out_flits[$];
  // bookkeeping (not compared)
  rand bit [4:0] nflits;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len { nflits inside {[1:20]}; }

  function new(string name = "ucie_transaction"); super.new(name); endfunction

  function void fill_flits(int unsigned nf);
    bit [31:0] x = seed | 32'h1;
    flits.delete();
    for (int unsigned i = 0; i < nf; i++) begin
      bit [63:0] v;
      for (int k = 0; k < 2; k++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        v = (v << 32) | 64'(x);
      end
      flits.push_back(v);
    end
  endfunction

  function void post_randomize();
    fill_flits(nflits);
  endfunction

  function void do_copy(uvm_object rhs);
    ucie_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    flits = rhs_.flits;
    out_flits = rhs_.out_flits;
    nflits = rhs_.nflits;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ucie_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (flits.size() != rhs_.flits.size()) return 0;
    foreach (flits[i]) if (flits[i] != rhs_.flits[i]) return 0;
    if (out_flits.size() != rhs_.out_flits.size()) return 0;
    foreach (out_flits[i]) if (out_flits[i] != rhs_.out_flits[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ucie_transaction rhs_);
    if (flits.size() != rhs_.flits.size()) return 0;
    foreach (flits[i]) if (flits[i] != rhs_.flits[i]) return 0;
    return 1;
  endfunction

  function string qstr_flits();
    string s = $sformatf("[%0d]{", flits.size());
    foreach (flits[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", flits[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_out_flits();
    string s = $sformatf("[%0d]{", out_flits.size());
    foreach (out_flits[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", out_flits[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("UCIe{tag=%0d flits=%s out_flits=%s}", tag, qstr_flits(), qstr_out_flits());
  endfunction
endclass
