// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (UCIe flit loopback ordering + backpressure)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened ucie_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic tvalid = 1'b0;
  logic [63:0] tdata = '0;
  logic tlast = 1'b0;
  logic rready = 1'b0;
  wire  tready;
  wire  rvalid;
  wire  [63:0] rdata;
  wire  rlast;

  always #5 clk = ~clk;

  ucie_model u_dut (
    .clk(clk), .rst_n(rst_n), .tvalid(tvalid), .tdata(tdata),
    .tlast(tlast), .tready(tready), .rvalid(rvalid), .rdata(rdata),
    .rlast(rlast), .rready(rready)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  integer i;
  integer n;
  initial begin
    repeat (8) step();
    chk(tready === 1'b1, "tready high when empty");
    chk(rvalid === 1'b0, "rvalid low when empty");
    @(negedge clk); rst_n = 1'b1;

    // 3 flits with sink stalled, then drain in order
    @(negedge clk); rready = 1'b0;
    @(negedge clk); tvalid = 1'b1; tdata = 64'h1111; tlast = 1'b0;
    step();
    @(negedge clk); tdata = 64'h2222;
    step();
    @(negedge clk); tdata = 64'h3333; tlast = 1'b1;
    step();
    @(negedge clk); tvalid = 1'b0; tlast = 1'b0;
    chk(rvalid === 1'b1 && rdata === 64'h1111 && rlast === 1'b0, "flit0 head of queue");
    @(negedge clk); rready = 1'b1;
    step();
    chk(rvalid === 1'b1 && rdata === 64'h2222 && rlast === 1'b0, "flit1 loopback order");
    step();
    chk(rvalid === 1'b1 && rdata === 64'h3333 && rlast === 1'b1, "flit2 loopback with tlast");
    step();
    chk(rvalid === 1'b0, "drained after 3 flits");

    // backpressure: fill FIFO to full, tready must drop, drain recovers
    @(negedge clk); rready = 1'b0;
    for (i = 0; i < 8; i = i + 1) begin
      @(negedge clk); tvalid = 1'b1; tdata = i; tlast = 1'b0;
      chk(tready === 1'b1, "accept while not full");
      step();
    end
    @(negedge clk); tdata = 64'hBEEF;
    step();
    chk(tready === 1'b0, "tready low when full");
    chk(rvalid === 1'b1 && rdata === 64'h0, "oldest flit at head");
    @(negedge clk); tvalid = 1'b0;
    @(negedge clk); rready = 1'b1;
    repeat (8) step();
    chk(rvalid === 1'b0, "fully drained after backpressure test");
    chk(tready === 1'b1, "tready high when empty");

    // no flit loss on a 6-flit burst delivered while streaming
    n = 0;
    @(negedge clk); rready = 1'b1;
    for (i = 0; i < 6; i = i + 1) begin
      @(negedge clk); tvalid = 1'b1; tdata = 64'h500 + i;
      if (rvalid) n = n + 1;
      step();
    end
    @(negedge clk); tvalid = 1'b0;
    repeat (6) begin
      if (rvalid) n = n + 1;
      step();
    end
    chk(n == 6, "all 6 burst flits delivered");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
