// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- UCIe testbench top with a functional UCIe DUT model

`ifndef UCIe_TB_SV
`define UCIe_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ucie_defs_pkg::*;
import ucie_pkg::*;
import ucie_env_pkg::*;
import ucie_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ucie_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ucie_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tvalid(vif.tvalid),
    .tdata(vif.tdata),
    .tlast(vif.tlast),
    .tready(vif.tready),
    .rvalid(vif.rvalid),
    .rdata(vif.rdata),
    .rlast(vif.rlast),
    .rready(vif.rready)
  );

  // Concurrent protocol checks
  ucie_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .tvalid(vif.tvalid), .tdata(vif.tdata), .tlast(vif.tlast), .tready(vif.tready), .rvalid(vif.rvalid), .rdata(vif.rdata), .rlast(vif.rlast), .rready(vif.rready)
  );

  initial begin
    uvm_config_db#(virtual ucie_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ucie_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        tvalid,
  input  logic [63:0] tdata,
  input  logic        tlast,
  output logic        tready,
  output logic        rvalid,
  output logic [63:0] rdata,
  output logic        rlast,
  input  logic        rready
);
  // 8-deep FIFO, combinational read side, pop on rvalid && rready
  logic [63:0] fifo [0:7];
  logic        fifo_last [0:7];
  logic [3:0]  wptr, rptr;
  logic [3:0]  count;
  assign tready = (count < 8);
  assign rvalid = (count != 0);
  assign rdata  = fifo[rptr[2:0]];
  assign rlast  = fifo_last[rptr[2:0]];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wptr <= 4'd0; rptr <= 4'd0; count <= 4'd0;
    end else begin
      if (tvalid && tready) begin
        fifo[wptr[2:0]] <= tdata;
        fifo_last[wptr[2:0]] <= tlast;
        wptr <= wptr + 1;
      end
      if (rvalid && rready)
        rptr <= rptr + 1;
      case ({tvalid && tready, rvalid && rready})
        2'b10:   count <= count + 1;
        2'b01:   count <= count - 1;
        default: count <= count;
      endcase
    end
  end
endmodule
`endif
