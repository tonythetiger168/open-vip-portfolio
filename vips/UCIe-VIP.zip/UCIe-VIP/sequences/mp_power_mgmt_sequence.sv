// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Power Management Sequence (directed)
// Exercises L0s, L1, L2, and Recovery state transitions for all protocols
//============================================================================
`ifndef MP_POWER_MGMT_SEQUENCE_SV
`define MP_POWER_MGMT_SEQUENCE_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

class mp_power_mgmt_sequence extends uvm_sequence #(mp_sequence_item);
  `uvm_object_utils(mp_power_mgmt_sequence)
  rand int num_cycles;
  rand protocol_e target_protocol;
  rand bit enable_l0s;
  rand bit enable_l1;
  rand bit enable_l2;
  rand bit enable_recovery;

  constraint c_num_cycles { num_cycles inside {[50:500]}; }
  constraint c_protocol {
    target_protocol inside {PROTO_PCIE_GEN5, PROTO_PCIE_GEN6, PROTO_CXL_20, PROTO_CXL_30};
  }

  function new(string name = "mp_power_mgmt_sequence");
    super.new(name);
  endfunction

  // Model the state transition timing of the link power states
  virtual task drive_link_state(link_state_e new_state);
    `uvm_info("PM_SEQ", $sformatf("Driving link state transition to %s",
              new_state.name()), UVM_MEDIUM)
    case (new_state)
      LINK_L0S:      #500ns;    // L0s entry: ~500ns
      LINK_L1:       #2000ns;   // L1 entry: ~2us
      LINK_L2:       #10000ns;  // L2 entry: ~10us
      LINK_RECOVERY: #100ns;    // Recovery: ~100ns
      default:       #100ns;
    endcase
  endtask

  virtual task body();
    `uvm_info("PM_SEQ", $sformatf("Starting Power Management sequence for %s (cycles=%0d)",
              target_protocol.name(), num_cycles), UVM_LOW)
    repeat (num_cycles) begin
      mp_sequence_item item;
      // Phase 1: Normal operation in L0
      item = mp_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.address[63:56] != 8'hEE;
                                   txn.delay_cycles inside {[1:10]}; })
        `uvm_error("PM_SEQ", "Randomization failed")
      finish_item(item);

      // Phase 2: Transition to low power state
      if (enable_l0s) begin
        drive_link_state(LINK_L0S);
        drive_link_state(LINK_L0);
      end
      if (enable_l1) begin
        drive_link_state(LINK_L1);
        if (enable_recovery) drive_link_state(LINK_RECOVERY);
        drive_link_state(LINK_L0);
      end
      if (enable_l2) begin
        drive_link_state(LINK_L2);
        drive_link_state(LINK_L0);
      end
    end
  endtask
endclass
`endif
