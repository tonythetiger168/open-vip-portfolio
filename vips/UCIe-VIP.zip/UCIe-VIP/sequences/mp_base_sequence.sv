// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Base Sequence
//============================================================================
`ifndef MP_BASE_SEQUENCE_SV
`define MP_BASE_SEQUENCE_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

class mp_base_sequence extends uvm_sequence #(mp_sequence_item);
  `uvm_object_utils(mp_base_sequence)
  rand int num_transactions;
  rand protocol_e target_protocol;
  constraint c_num_txn { num_transactions inside {[10:1000]}; }

  function new(string name = "mp_base_sequence");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info("SEQ", $sformatf("Starting %0d transactions for %s",
              num_transactions, target_protocol.name()), UVM_LOW)
    repeat (num_transactions) begin
      mp_sequence_item item = mp_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.address[63:56] != 8'hEE; })
        `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
