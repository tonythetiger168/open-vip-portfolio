// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Error Injection Sequence (directed)
// Systematically targets the ECRC error region (addr[63:56]==8'hEE) with
// poisoned flags and short frames to exercise error handling.
//============================================================================
`ifndef MP_ERROR_INJECT_SEQUENCE_SV
`define MP_ERROR_INJECT_SEQUENCE_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

class mp_error_inject_sequence extends uvm_sequence #(mp_sequence_item);
  `uvm_object_utils(mp_error_inject_sequence)
  rand int num_errors;
  rand protocol_e target_protocol;
  rand int error_type;   // 0=ECRC, 1=LCRC, 2=Framing, 3=Protocol, 4=Timeout

  constraint c_num_errors { num_errors inside {[20:200]}; }
  constraint c_error_type { error_type inside {[0:4]}; }
  constraint c_protocol {
    target_protocol inside {PROTO_PCIE_GEN5, PROTO_PCIE_GEN6, PROTO_CXL_20,
                            PROTO_CXL_30, PROTO_UCIE, PROTO_UALINK};
  }

  function new(string name = "mp_error_inject_sequence");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info("ERR_INJ", $sformatf("Starting Error Injection: %0d errors for %s",
              num_errors, target_protocol.name()), UVM_LOW)
    repeat (num_errors) begin
      mp_sequence_item item = mp_sequence_item::type_id::create("item");
      start_item(item);
      case (error_type)
        0: begin // ECRC error region + poisoned flag
          if (!item.randomize() with { txn.protocol == target_protocol;
                                       txn.address[63:56] == 8'hEE;
                                       txn.inject_error == 1;
                                       txn.ep == 1;
                                       txn.delay_cycles inside {[0:50]}; })
            `uvm_error("ERR_INJ", "ECRC randomization failed")
        end
        1: begin // error region
          if (!item.randomize() with { txn.protocol == target_protocol;
                                       txn.address[63:56] == 8'hEE;
                                       txn.inject_error == 1;
                                       txn.delay_cycles inside {[0:50]}; })
            `uvm_error("ERR_INJ", "LCRC randomization failed")
        end
        2: begin // short frame to the error region (framing stress)
          if (!item.randomize() with { txn.protocol == target_protocol;
                                       txn.address[63:56] == 8'hEE;
                                       txn.inject_error == 1;
                                       txn.length == 4;
                                       txn.delay_cycles inside {[0:20]}; })
            `uvm_error("ERR_INJ", "Framing randomization failed")
        end
        3: begin // unknown TLP type into the error region
          if (!item.randomize() with { txn.protocol == target_protocol;
                                       txn.address[63:56] == 8'hEE;
                                       txn.inject_error == 1;
                                       txn.txn_type == TLP_UNKNOWN;
                                       txn.delay_cycles inside {[0:30]}; })
            `uvm_error("ERR_INJ", "Protocol randomization failed")
        end
        default: begin // timeout stress: max delay into error region
          if (!item.randomize() with { txn.protocol == target_protocol;
                                       txn.address[63:56] == 8'hEE;
                                       txn.inject_error == 1;
                                       txn.delay_cycles inside {[40:50]}; })
            `uvm_error("ERR_INJ", "Timeout randomization failed")
        end
      endcase
      finish_item(item);
    end
  endtask
endclass
`endif
