// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Regression Sequence
// Coverage-driven random regression with weighted protocol distribution,
// plus a directed-sequence phase (back-to-back/stress/reset/corner).
//============================================================================
`ifndef MP_REGRESSION_SEQUENCE_SV
`define MP_REGRESSION_SEQUENCE_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

`include "mp_extra_sequences.svh"

class mp_regression_sequence extends uvm_sequence #(mp_sequence_item);
  `uvm_object_utils(mp_regression_sequence)
  // Regression knobs
  rand int pcie_weight;
  rand int cxl_weight;
  rand int ucie_weight;
  rand int ualink_weight;
  constraint c_weights {
    pcie_weight inside {[1:10]}; cxl_weight inside {[1:10]};
    ucie_weight inside {[1:10]}; ualink_weight inside {[1:10]};
  }

  function new(string name = "mp_regression_sequence");
    super.new(name);
  endfunction

  virtual task body();
    mp_random_sequence seq;
    int total = 5000;   // Total regression transactions
    `uvm_info("REGRESSION", "Starting Coverage-Driven Random Regression", UVM_LOW)

    // Phase 1: PCIe heavy
    seq = mp_random_sequence::type_id::create("pcie_seq");
    seq.num_transactions = total * pcie_weight / (pcie_weight+cxl_weight+ucie_weight+ualink_weight);
    seq.enable_pcie = 1; seq.enable_cxl = 0; seq.enable_ucie = 0; seq.enable_ualink = 0;
    seq.target_protocol = PROTO_PCIE_GEN5;
    seq.start(m_sequencer);

    // Phase 2: CXL heavy
    seq = mp_random_sequence::type_id::create("cxl_seq");
    seq.num_transactions = total * cxl_weight / (pcie_weight+cxl_weight+ucie_weight+ualink_weight);
    seq.enable_pcie = 0; seq.enable_cxl = 1; seq.enable_ucie = 0; seq.enable_ualink = 0;
    seq.target_protocol = PROTO_CXL_20;
    seq.start(m_sequencer);

    // Phase 3: UCIe
    seq = mp_random_sequence::type_id::create("ucie_seq");
    seq.num_transactions = total * ucie_weight / (pcie_weight+cxl_weight+ucie_weight+ualink_weight);
    seq.enable_pcie = 0; seq.enable_cxl = 0; seq.enable_ucie = 1; seq.enable_ualink = 0;
    seq.target_protocol = PROTO_UCIE;
    seq.start(m_sequencer);

    // Phase 4: UALink
    seq = mp_random_sequence::type_id::create("ualink_seq");
    seq.num_transactions = total * ualink_weight / (pcie_weight+cxl_weight+ucie_weight+ualink_weight);
    seq.enable_pcie = 0; seq.enable_cxl = 0; seq.enable_ucie = 0; seq.enable_ualink = 1;
    seq.target_protocol = PROTO_UALINK;
    seq.start(m_sequencer);

    // Phase 5: Directed sequences (back-to-back / stress / reset / corner)
    begin
      mp_back_to_back_sequence b2b = mp_back_to_back_sequence::type_id::create("b2b");
      mp_stress_sequence       str = mp_stress_sequence::type_id::create("str");
      mp_reset_sequence        rst = mp_reset_sequence::type_id::create("rst");
      mp_corner_sequence       cor = mp_corner_sequence::type_id::create("cor");
      b2b.num_transactions = 100; b2b.target_protocol = PROTO_UALINK;
      str.num_transactions = 100; str.target_protocol = PROTO_UALINK;
      rst.target_protocol = PROTO_UALINK;
      cor.num_transactions = 50;  cor.target_protocol = PROTO_UALINK;
      b2b.start(m_sequencer);
      str.start(m_sequencer);
      rst.start(m_sequencer);
      cor.start(m_sequencer);
    end

    // Phase 6: Cross-protocol stress
    seq = mp_random_sequence::type_id::create("stress_seq");
    seq.num_transactions = total / 5;
    seq.enable_pcie = 1; seq.enable_cxl = 1; seq.enable_ucie = 1; seq.enable_ualink = 1;
    seq.target_protocol = PROTO_UALINK;
    seq.start(m_sequencer);
    `uvm_info("REGRESSION", "Regression Sequence Complete", UVM_LOW)
  endtask
endclass
`endif
