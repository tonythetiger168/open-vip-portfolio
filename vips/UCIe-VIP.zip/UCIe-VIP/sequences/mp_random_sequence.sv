// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Random Sequence
// Generates random transactions for a target protocol
//============================================================================
`ifndef MP_RANDOM_SEQUENCE_SV
`define MP_RANDOM_SEQUENCE_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

class mp_random_sequence extends mp_base_sequence;
  `uvm_object_utils(mp_random_sequence)
  rand bit enable_pcie;
  rand bit enable_cxl;
  rand bit enable_ucie;
  rand bit enable_ualink;

  constraint c_protocol_dist {
    if (enable_pcie)   target_protocol inside {PROTO_PCIE_GEN5, PROTO_PCIE_GEN6};
    if (enable_cxl)    target_protocol inside {PROTO_CXL_20, PROTO_CXL_30};
    if (enable_ucie)   target_protocol == PROTO_UCIE;
    if (enable_ualink) target_protocol == PROTO_UALINK;
  }

  function new(string name = "mp_random_sequence");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info("SEQ", $sformatf("Random sequence: %0d txns for %s",
              num_transactions, target_protocol.name()), UVM_LOW)
    repeat (num_transactions) begin
      mp_sequence_item item = mp_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.address[63:56] != 8'hEE; })
        `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
