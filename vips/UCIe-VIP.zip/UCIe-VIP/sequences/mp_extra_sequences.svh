// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// mp_extra_sequences.svh -- additional directed sequences
// (back-to-back / stress / reset / corner), included from
// mp_regression_sequence.sv so the fixed Makefile file list covers them.

`ifndef MP_EXTRA_SEQUENCES_SVH
`define MP_EXTRA_SEQUENCES_SVH

// Directed: back-to-back flits with zero inter-transaction delay
class mp_back_to_back_sequence extends mp_base_sequence;
  `uvm_object_utils(mp_back_to_back_sequence)
  function new(string name = "mp_back_to_back_sequence");
    super.new(name);
  endfunction
  virtual task body();
    repeat (num_transactions) begin
      mp_sequence_item item = mp_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.address[63:56] != 8'hEE;
                                   txn.delay_cycles == 0;
                                   txn.length inside {[4:64]}; })
        `uvm_error("SEQ", "B2B randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Stress: high-volume large payloads
class mp_stress_sequence extends mp_base_sequence;
  `uvm_object_utils(mp_stress_sequence)
  function new(string name = "mp_stress_sequence");
    super.new(name);
  endfunction
  virtual task body();
    repeat (num_transactions) begin
      mp_sequence_item item = mp_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.address[63:56] != 8'hEE;
                                   txn.length inside {[256:512]}; })
        `uvm_error("SEQ", "Stress randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Reset behavior: single transaction issued right after reset release
class mp_reset_sequence extends mp_base_sequence;
  `uvm_object_utils(mp_reset_sequence)
  function new(string name = "mp_reset_sequence");
    super.new(name);
  endfunction
  virtual task body();
    mp_sequence_item item = mp_sequence_item::type_id::create("item");
    start_item(item);
    if (!item.randomize() with { txn.protocol == target_protocol;
                                 txn.address[63:56] != 8'hEE;
                                 txn.length == 4; txn.delay_cycles == 0; })
      `uvm_error("SEQ", "Reset randomization failed")
    finish_item(item);
  endtask
endclass

// Corner case: minimum (4B) and maximum (4KB) payloads, misaligned lengths
class mp_corner_sequence extends mp_base_sequence;
  `uvm_object_utils(mp_corner_sequence)
  function new(string name = "mp_corner_sequence");
    super.new(name);
  endfunction
  virtual task body();
    repeat (num_transactions) begin
      mp_sequence_item item = mp_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.address[63:56] != 8'hEE;
                                   txn.length inside {4, 64, 256, 512}; })
        `uvm_error("SEQ", "Corner randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
