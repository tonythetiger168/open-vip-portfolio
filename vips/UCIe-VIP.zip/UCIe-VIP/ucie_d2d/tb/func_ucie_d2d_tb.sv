// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator
//
// func_ucie_d2d_tb.sv -- link partner for ucie_d2d_model: a sideband
// responder, a flit transmitter / receiver with its own CRC-16 (checked
// first against the CRC-16/CCITT-FALSE check value) and a protocol-layer
// driver. Covers:
//   * training: SBINIT pattern and done handshakes, MBINIT parameter and
//     lane-repair exchange (x16, x8 on either half, both halves failed),
//     MBTRAIN speed degrade on remote and local failures, LINKINIT, ACTIVE
//   * TRAINERROR on sideband timeout, unrepairable lanes and no trainable
//     speed; RESET on lt_start low; unexpected sideband messages
//   * retry: sequence numbers, ACK purge, retry-buffer back-pressure,
//     receiver CRC / sequence errors with a single NAK, duplicates, NAK
//     replay, replay timeout, replay limit -> retrain, data kept across
//     the retrain
//   * PHY retrain by the partner, L1 entry refused with flits outstanding,
//     accepted when empty, L1 exit
// Run: python3 tools/run_func_tests.py UCIe-VIP
module func_ucie_d2d_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int SB_TIMEOUT = 400, REPLAY_TO = 120, RB_DEPTH = 8;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0, lt_start = 0, retrain_req = 0;
  logic [15:0] lane_fail = 0;
  logic [7:0] local_fail = 0;
  logic sb_rx_valid = 0;
  logic [7:0] sb_rx_msg = 0;
  logic [15:0] sb_rx_data = 0;
  wire sb_tx_valid;
  wire [7:0] sb_tx_msg;
  wire [15:0] sb_tx_data;
  logic fdi_tx_valid = 0;
  logic [511:0] fdi_tx_data = 0;
  wire fdi_tx_ready, fdi_rx_valid;
  wire [511:0] fdi_rx_data;
  logic mb_rx_valid = 0;
  logic [543:0] mb_rx_flit = 0;
  wire mb_tx_valid;
  wire [543:0] mb_tx_flit;
  wire [3:0] state;
  wire link_up;
  wire [2:0] speed;
  wire [4:0] width;
  wire [7:0] err;
  always #5 clk = ~clk;

  ucie_d2d_model #(.SB_TIMEOUT(SB_TIMEOUT), .REPLAY_TO(REPLAY_TO), .RB_DEPTH(RB_DEPTH), .MAX_SPEED(3'd5))
    u_dut (.clk, .rst_n, .lt_start, .lane_fail, .local_fail, .retrain_req, .sb_rx_valid, .sb_rx_msg,
           .sb_rx_data, .sb_tx_valid, .sb_tx_msg, .sb_tx_data, .fdi_tx_valid, .fdi_tx_data, .fdi_tx_ready,
           .fdi_rx_valid, .fdi_rx_data, .mb_rx_valid, .mb_rx_flit, .mb_tx_valid, .mb_tx_flit,
           .state, .link_up, .speed, .width, .err);

  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  logic [7:0] err_acc = 0;
  always @(posedge clk) err_acc <= err_acc | err;
  task automatic wait_clk(input int n); repeat (n) @(negedge clk); endtask
  task automatic wait_state(input logic [3:0] s, input int maxc = 2000);
    int c;
    c = 0;
    while (state != s && c < maxc) begin @(negedge clk); c++; end
  endtask

  // ------------------------------------------------------------ CRC-16 (MSB first, init FFFF)
  function automatic logic [15:0] crc_byte(input logic [15:0] c, input logic [7:0] d);
    for (int b = 7; b >= 0; b--) c = (c[15] ^ d[b]) ? ((c << 1) ^ 16'h1021) : (c << 1);
    return c;
  endfunction
  function automatic logic [543:0] seal(input logic [543:0] f);
    logic [15:0] c;
    c = 16'hFFFF;
    for (int i = 0; i < 66; i++) c = crc_byte(c, f[8 * i +: 8]);
    f[8 * 66 +: 8] = c[15:8]; f[8 * 67 +: 8] = c[7:0];
    return f;
  endfunction
  function automatic bit crc_ok(input logic [543:0] f);
    return seal(f) == f;
  endfunction

  // ------------------------------------------------------------ sideband
  logic [23:0] sbq [$];
  always @(negedge clk) begin
    sb_rx_valid <= 1'b0;
    if (sbq.size() > 0) begin
      logic [23:0] m;
      m = sbq.pop_front();
      sb_rx_valid <= 1'b1; sb_rx_msg <= m[23:16]; sb_rx_data <= m[15:0];
    end
  end
  task automatic sb(input logic [7:0] m, input logic [15:0] d = 0); sbq.push_back({m, d}); endtask
  // messages from the model
  logic [7:0] sm [0:4095];
  logic [15:0] sd [0:4095];
  int st_ [0:4095];
  int ns_ = 0;
  bit no_li_rsp = 0;
  int t30 = -1, t7 = -1;
  always @(posedge clk) begin
    if (sb_rx_valid && sb_rx_msg == 8'h30) t30 = cyc;
    if (state == 4'd7 && t7 < 0) t7 = cyc;
  end
  // auto responder
  bit auto_sb = 1;
  logic [2:0] p_speed = 3'd5;
  logic [4:0] p_width = 5'd16;
  logic [7:0] p_fail = 8'h00;
  always @(posedge clk) if (sb_tx_valid) begin
    sm[ns_ % 4096] = sb_tx_msg; sd[ns_ % 4096] = sb_tx_data; st_[ns_ % 4096] = cyc; ns_++;
    if (auto_sb)
      case (sb_tx_msg)
        8'h02: sb(8'h03);
        8'h10: sb(8'h11, {13'h0, p_speed});
        8'h12: sb(8'h13, {11'h0, p_width});
        8'h20: sb(8'h21, {15'h0, !p_fail[sb_tx_data[2:0]]});
        8'h30: if (!no_li_rsp) sb(8'h31);
        8'h40: sb(8'h41);
        default: ;
      endcase
  end
  function automatic int count_sb(input logic [7:0] m, input int from);
    int n;
    n = 0;
    for (int i = from; i < ns_; i++) if (sm[i % 4096] == m) n++;
    return n;
  endfunction
  function automatic int last_sb(input logic [7:0] m, input int from);
    for (int i = ns_ - 1; i >= from; i--) if (sm[i % 4096] == m) return i;
    return -1;
  endfunction

  // full training with a cooperative partner
  task automatic train(input int p_spd = 5, input int p_wid = 16);
    p_speed = p_spd; p_width = p_wid;
    lt_start = 1;
    wait_state(4'd1, 50);
    sb(8'h01); wait_clk(3); sb(8'h01); wait_clk(3); sb(8'h02);
    wait_state(4'd2, 200);
    sb(8'h10, {13'h0, p_speed}); sb(8'h12, {11'h0, p_width});
    wait_state(4'd4, 600);
    sb(8'h30);
    wait_state(4'd5, 200);
  endtask
  // retrain path back to ACTIVE (MBTRAIN is driven by the model)
  task automatic finish_retrain();
    wait_state(4'd4, 600);
    sb(8'h30);
    wait_state(4'd5, 200);
  endtask

  // ------------------------------------------------------------ mainband
  logic [543:0] mbq [$];
  always @(negedge clk) begin
    mb_rx_valid <= 1'b0;
    if (mbq.size() > 0) begin mb_rx_flit <= mbq.pop_front(); mb_rx_valid <= 1'b1; end
  end
  function automatic logic [543:0] flit(input logic [1:0] ty, input logic [5:0] sq, input logic [5:0] as,
                                        input bit ack, input bit nak, input logic [511:0] d);
    logic [543:0] f;
    f = '0;
    f[7:0] = {ty, sq}; f[15:8] = {as, ack, nak}; f[16 +: 512] = d;
    return seal(f);
  endfunction
  // flits from the model
  logic [543:0] mf [0:4095];
  int nf = 0, bad_crc = 0;
  bit auto_ack = 1;
  always @(posedge clk) if (mb_tx_valid) begin
    if (!crc_ok(mb_tx_flit)) bad_crc++;
    mf[nf % 4096] = mb_tx_flit; nf++;
    if (auto_ack && mb_tx_flit[7:6] == 2'd0) mbq.push_back(flit(2'd1, 6'd0, mb_tx_flit[5:0], 1, 0, '0));
  end
  function automatic int count_data(input int from);
    int n;
    n = 0;
    for (int i = from; i < nf; i++) if (mf[i % 4096][7:6] == 2'd0) n++;
    return n;
  endfunction
  function automatic int last_ctl(input int from);              // last flit carrying ACK or NAK
    for (int i = nf - 1; i >= from; i--) if (mf[i % 4096][9] || mf[i % 4096][8]) return i;
    return -1;
  endfunction
  function automatic int count_nak(input int from);
    int n;
    n = 0;
    for (int i = from; i < nf; i++) if (mf[i % 4096][8]) n++;
    return n;
  endfunction

  // protocol layer: payloads to send (in order) and those delivered
  logic [511:0] txq [$];
  logic [511:0] sent [0:1023];
  int nsent = 0;
  // a handshake happens at the edge after a negedge where valid and ready were both high
  logic rdy_q = 0;
  always @(negedge clk) begin
    if (fdi_tx_valid && rdy_q) begin
      sent[nsent % 1024] = fdi_tx_data; nsent++;
      void'(txq.pop_front());
    end
    rdy_q = fdi_tx_ready;
    fdi_tx_valid <= txq.size() > 0;
    if (txq.size() > 0) fdi_tx_data <= txq[0];
  end
  logic [511:0] rcvd [0:1023];
  int nrcv = 0;
  always @(posedge clk) if (fdi_rx_valid) begin rcvd[nrcv % 1024] = fdi_rx_data; nrcv++; end
  function automatic logic [511:0] pay(input int i);
    logic [511:0] v;
    for (int k = 0; k < 16; k++) v[32 * k +: 32] = 32'(i * 32'h0101_0101 + k * 32'h1357_9BDF);
    return v;
  endfunction

  // ------------------------------------------------------------ test
  initial begin
    int s0, f0, n0, i0, c;
    logic [15:0] cc;
    // CRC-16/CCITT-FALSE check value
    cc = 16'hFFFF;
    for (int i = 0; i < 9; i++) cc = crc_byte(cc, 8'h31 + 8'(i));
    chk(cc == 16'h29B1, "bench CRC-16 matches the CRC-16/CCITT-FALSE check value 29B1");

    wait_clk(3); rst_n = 1; wait_clk(2);
    chk(state == 4'd0 && !link_up, "RESET after reset");
    chk(nf == 0 && nrcv == 0 && ns_ == 0, "no flit, delivery or sideband message during and after reset");

    // ---- SBINIT
    lane_fail = 16'h0100;                                  // a fault in the upper half
    local_fail = 8'b0000_0100;                             // local training fails at speed 2
    p_fail = 8'b0000_1000;                                 // partner fails at speed 3
    p_speed = 3; p_width = 16;
    lt_start = 1;
    wait_clk(20);
    chk(state == 4'd1 && count_sb(8'h01, 0) >= 3 && count_sb(8'h02, 0) == 0, "SBINIT: patterns, no done before two partner patterns");
    chk(st_[1] - st_[0] == 4 && st_[2] - st_[1] == 4, "SBINIT patterns every 4 clocks");
    sb(8'h02);
    wait_clk(4);
    chk(err_acc[7] && state == 4'd1, "done request before the patterns is unexpected");
    err_acc = 0;
    s0 = ns_;
    sb(8'h01); wait_clk(3);
    sb(8'h01); wait_clk(10);
    chk(count_sb(8'h02, s0) == 1, "done request after two partner patterns");
    chk(state == 4'd1, "SBINIT holds until the partner's done request is answered");
    s0 = ns_;
    sb(8'h02);
    wait_clk(4);
    chk(count_sb(8'h03, s0) == 1 && state == 4'd2, "partner's done answered: MBINIT");

    // ---- MBINIT
    s0 = ns_;
    sb(8'h10, 16'd3); sb(8'h12, 16'd16);
    wait_state(4'd3, 100);
    i0 = last_sb(8'h11, s0);
    chk(i0 >= 0 && sd[i0 % 4096] == 16'd5, "parameter response carries the local max speed 5");
    i0 = last_sb(8'h13, s0);
    chk(i0 >= 0 && sd[i0 % 4096] == 16'd8, "lane fault in lanes 8..15: repair response offers x8");
    i0 = last_sb(8'h12, s0);
    chk(i0 >= 0 && sd[i0 % 4096] == 16'd8, "repair request x8");
    chk(state == 4'd3 && speed == 3'd3 && width == 5'd8, "MBTRAIN at min(5, 3) = speed 3, width min(16, 8) = 8");

    // ---- MBTRAIN with degrade
    s0 = ns_;
    wait_state(4'd4, 300);
    begin
      int sp [0:7], k;
      k = 0;
      for (int i = s0; i < ns_ && k < 8; i++) if (sm[i % 4096] == 8'h20) begin sp[k] = sd[i % 4096]; k++; end
      chk(k == 3 && sp[0] == 3 && sp[1] == 2 && sp[2] == 1,
          $sformatf("speed 3 fails at the partner, 2 locally: trained at 1 (%0d tries)", k));
    end
    chk(speed == 3'd1, "speed 1 after degrade");
    // ---- LINKINIT
    chk(state == 4'd4 && !link_up, "LINKINIT: link not up yet");
    wait_clk(20);
    chk(state == 4'd4 && !link_up, "LINKINIT holds until the partner's LINKINIT request");
    sb(8'h30);
    wait_state(4'd5, 50);
    chk(state == 4'd5 && link_up && fdi_tx_ready, "ACTIVE: link up, protocol layer may send");

    // ---- unexpected / out-of-state messages
    err_acc = 0;
    s0 = ns_;
    sb(8'h21, 16'h1); sb(8'h77);
    wait_clk(6);
    chk(err_acc == 8'h80 && state == 4'd5, "MBTRAIN response and unknown message in ACTIVE flagged, state kept");
    s0 = ns_;
    sb(8'h20, 16'd2); sb(8'h20, 16'd1);
    wait_clk(6);
    chk(err_acc == 8'h80, "MBTRAIN request outside training flagged");

    // ---- model -> partner data, ACK purge
    chk(nf == 0, "no flit before the protocol layer offers data");
    err_acc = 0;
    f0 = nf;
    for (int i = 0; i < 20; i++) txq.push_back(pay(i));
    wait_clk(80);
    begin
      int bad, k;
      bad = 0; k = 0;
      for (int i = f0; i < nf; i++) if (mf[i % 4096][7:6] == 2'd0) begin
        if (mf[i % 4096][5:0] != 6'(k) || mf[i % 4096][16 +: 512] != pay(k)) bad++;
        k++;
      end
      chk(k == 20 && bad == 0 && nsent == 20, $sformatf("20 flits, sequence 0..19, data intact (%0d sent, %0d bad)", k, bad));
    end
    chk(bad_crc == 0 && err_acc == 0, "flit CRCs good, no error");

    // ---- retry-buffer back-pressure
    auto_ack = 0;
    f0 = nf; n0 = nsent;
    for (int i = 20; i < 32; i++) txq.push_back(pay(i));
    wait_clk(40);
    chk(nsent - n0 == RB_DEPTH && !fdi_tx_ready, $sformatf("retry buffer full after %0d unacknowledged flits: ready low", nsent - n0));
    mbq.push_back(flit(2'd1, 0, 6'd22, 1, 0, '0));            // ACK 20..22
    wait_clk(20);
    chk(nsent - n0 == RB_DEPTH + 3, $sformatf("ACK of 3 flits frees 3 entries (%0d sent)", nsent - n0));

    // ---- NAK replay from the oldest unacknowledged
    f0 = nf;
    mbq.push_back(flit(2'd1, 0, 6'd24, 0, 1, '0));            // NAK, 23 and 24 good
    wait_clk(20);
    begin
      int k, bad;
      k = 0; bad = 0;
      for (int i = f0; i < nf; i++) if (mf[i % 4096][7:6] == 2'd0) begin
        if (mf[i % 4096][5:0] != 6'(25 + k) || mf[i % 4096][16 +: 512] != pay(25 + k)) bad++;
        k++;
      end
      chk(k == 7 && bad == 0, $sformatf("NAK: flits 25..30 replayed, then the waiting flit 31 (%0d, %0d bad)", k, bad));
    end
    mbq.push_back(flit(2'd1, 0, 6'd30, 1, 0, '0));
    wait_clk(20);
    chk(nsent == 32 && count_data(f0) == 7, "flit 31 sent after the replay");

    // ---- replay timeout
    err_acc = 0;
    f0 = nf;
    c = 0;
    while (count_data(f0) == 0 && c < 400) begin @(negedge clk); c++; end
    chk(err_acc[2] && c >= REPLAY_TO - 30 && c <= REPLAY_TO && mf[(nf - 1) % 4096][5:0] == 6'd31,
        $sformatf("no ACK for %0d clocks: flit 31 replayed on timeout", c));
    // three more timeouts: replay limit -> retrain
    s0 = ns_;
    c = 0;
    while (!err_acc[3] && c < 800) begin @(negedge clk); c++; end
    chk(err_acc[3] && count_data(f0) == 4, "fourth replay: replay limit flagged");
    wait_clk(4);
    chk(count_sb(8'h40, s0) == 1 && state != 4'd5 && !link_up, "replay limit requests a retrain");
    finish_retrain();
    chk(state == 4'd5 && speed == 3'd1, "back to ACTIVE at the trained speed");
    f0 = nf;
    auto_ack = 1;
    wait_clk(REPLAY_TO + 10);
    chk(count_data(f0) >= 1 && mf[(nf - 1) % 4096][5:0] == 6'd31 && mf[(nf - 1) % 4096][16 +: 512] == pay(31),
        "unacknowledged flit kept across the retrain and replayed");
    f0 = nf;
    wait_clk(REPLAY_TO + 10);
    chk(count_data(f0) == 0, "ACKed: no more replays");
    err_acc = 0; s0 = ns_;
    wait_clk(5 * REPLAY_TO);
    chk(err_acc == 0 && state == 4'd5 && count_sb(8'h40, s0) == 0, "idle with nothing outstanding: no replay timeout, no retrain");

    // ---- partner -> model: delivery, ACK, CRC error, sequence errors, duplicate
    err_acc = 0;
    f0 = nf; n0 = nrcv;
    for (int i = 0; i < 3; i++) mbq.push_back(flit(2'd0, 6'(i), 6'h3F, 0, 0, pay(100 + i)));
    wait_clk(10);
    chk(nrcv - n0 == 3 && rcvd[n0 % 1024] == pay(100) && rcvd[(n0 + 2) % 1024] == pay(102), "three flits delivered in order");
    i0 = last_ctl(f0);
    chk(i0 >= 0 && mf[i0 % 4096][9] && !mf[i0 % 4096][8] && mf[i0 % 4096][15:10] == 6'd2 && mf[i0 % 4096][7:6] == 2'd1,
        "ACK 2 sent in a NOP flit");
    f0 = nf;
    begin
      logic [543:0] bf;
      bf = flit(2'd0, 6'd3, 6'h3F, 0, 0, pay(103));
      bf[100] = !bf[100];
      mbq.push_back(bf); mbq.push_back(bf);
    end
    wait_clk(8);
    chk(err_acc[0] && nrcv - n0 == 3, "corrupted flit dropped");
    chk(count_nak(f0) == 1 && mf[last_ctl(f0) % 4096][15:10] == 6'd2, "one NAK with the last good sequence 2");
    mbq.push_back(flit(2'd0, 6'd5, 6'h3F, 0, 0, pay(105)));
    wait_clk(8);
    chk(err_acc[1] && count_nak(f0) == 1, "sequence ahead dropped, no second NAK while one is scheduled");
    f0 = nf;
    mbq.push_back(flit(2'd0, 6'd3, 6'h3F, 0, 0, pay(103)));
    mbq.push_back(flit(2'd0, 6'd1, 6'h3F, 0, 0, pay(999)));   // duplicate
    wait_clk(8);
    chk(nrcv - n0 == 4 && rcvd[(n0 + 3) % 1024] == pay(103), "replayed flit 3 delivered, duplicate 1 not delivered");
    i0 = last_ctl(f0);
    chk(i0 >= 0 && mf[i0 % 4096][9] && mf[i0 % 4096][15:10] == 6'd3, "duplicate answered with ACK 3");
    err_acc = 0;
    f0 = nf;
    mbq.push_back(flit(2'd0, 6'd5, 6'h3F, 0, 0, pay(105)));
    wait_clk(8);
    chk(err_acc[1] && count_nak(f0) == 1, "a new sequence error after recovery NAKs again");
    mbq.push_back(flit(2'd0, 6'd4, 6'h3F, 0, 0, pay(104)));
    mbq.push_back(flit(2'd0, 6'd5, 6'h3F, 0, 0, pay(105)));
    wait_clk(8);
    chk(nrcv - n0 == 6, "flits 4 and 5 delivered");
    // ACK piggybacked on a data flit
    f0 = nf;
    auto_ack = 0;
    @(posedge clk); #1;
    mbq.push_back(flit(2'd0, 6'd6, 6'h3F, 0, 0, pay(106)));
    txq.push_back(pay(32));
    wait_clk(8);
    i0 = -1;
    for (int i = f0; i < nf; i++) if (mf[i % 4096][7:6] == 2'd0) i0 = i;
    chk(i0 >= 0 && mf[i0 % 4096][9] && mf[i0 % 4096][15:10] == 6'd6 && mf[i0 % 4096][5:0] == 6'd32,
        "ACK 6 carried by data flit 32");

    // ---- L1: refused with flits outstanding, accepted when empty
    s0 = ns_;
    sb(8'h50);
    wait_clk(6);
    i0 = last_sb(8'h51, s0);
    chk(i0 >= 0 && sd[i0 % 4096] == 16'd0 && state == 4'd5, "L1 refused with flit 32 unacknowledged");
    mbq.push_back(flit(2'd1, 0, 6'd32, 1, 0, '0));
    wait_clk(4);
    s0 = ns_;
    sb(8'h50);
    wait_clk(6);
    i0 = last_sb(8'h51, s0);
    chk(i0 >= 0 && sd[i0 % 4096] == 16'd1 && state == 4'd8 && !link_up && !fdi_tx_ready, "L1 accepted with the retry buffer empty");
    n0 = nrcv;
    mbq.push_back(flit(2'd0, 6'd7, 6'h3F, 0, 0, pay(107)));
    wait_clk(6);
    chk(nrcv == n0, "no mainband reception in L1");
    sb(8'h52);
    wait_state(4'd3, 10);
    chk(state == 4'd3, "L1 exit: MBTRAIN");
    finish_retrain();
    chk(state == 4'd5 && link_up, "L1 exit retrains to ACTIVE");
    mbq.push_back(flit(2'd0, 6'd7, 6'h3F, 0, 0, pay(107)));
    wait_clk(6);
    chk(nrcv == n0 + 1 && rcvd[n0 % 1024] == pay(107), "sequence numbers continue after L1");

    // ---- retrain by the partner and by the local request
    s0 = ns_;
    sb(8'h40);
    wait_state(4'd3, 10);
    chk(count_sb(8'h41, s0) == 1 && state == 4'd3, "partner retrain request answered: MBTRAIN");
    finish_retrain();
    chk(state == 4'd5, "partner retrain back to ACTIVE");
    s0 = ns_;
    auto_sb = 0;
    retrain_req = 1; wait_clk(1); retrain_req = 0;
    wait_clk(10);
    chk(count_sb(8'h40, s0) == 1 && state == 4'd6, "local retrain request waits in PHYRETRAIN for the response");
    sb(8'h41);
    auto_sb = 1;
    wait_state(4'd3, 10);
    chk(state == 4'd3, "retrain response: MBTRAIN");
    finish_retrain();

    // ---- lt_start low: RESET, everything restarts
    lt_start = 0;
    wait_clk(3);
    chk(state == 4'd0 && !link_up && speed == 0 && width == 0, "lt_start low: RESET");
    lane_fail = 16'h00F0; local_fail = 0; p_fail = 0;
    auto_ack = 1;
    train(4, 16);
    chk(state == 4'd5 && speed == 3'd4 && width == 5'd8, "retrained: speed min(5, 4), x8 on the upper half");
    f0 = nf;
    txq.push_back(pay(200));
    wait_clk(6);
    chk(count_data(f0) == 1 && mf[(nf - 1) % 4096][5:0] == 6'd0, "sequence numbers restart at 0 after RESET");
    n0 = nrcv;
    mbq.push_back(flit(2'd0, 6'd0, 6'h3F, 0, 0, pay(300)));
    wait_clk(6);
    chk(nrcv == n0 + 1, "receiver expects sequence 0 after RESET");

    // ---- TRAINERROR: unrepairable lanes
    lt_start = 0; wait_clk(3);
    err_acc = 0;
    lane_fail = 16'h0101;
    lt_start = 1;
    wait_state(4'd1, 50);
    sb(8'h01); wait_clk(3); sb(8'h01); wait_clk(3); sb(8'h02);
    wait_state(4'd7, 200);
    wait_clk(2);
    chk(state == 4'd7 && err_acc[5], $sformatf("faults in both halves: TRAINERROR (state %0d err %h)", state, err_acc));
    // ---- TRAINERROR: no trainable speed
    lt_start = 0; wait_clk(3);
    err_acc = 0;
    lane_fail = 0; p_fail = 8'hFF;
    lt_start = 1;
    wait_state(4'd1, 50);
    sb(8'h01); wait_clk(3); sb(8'h01); wait_clk(3); sb(8'h02);
    wait_state(4'd2, 200);
    s0 = ns_;
    sb(8'h10, 16'd2); sb(8'h12, 16'd16);
    wait_state(4'd7, 400);
    wait_clk(2);
    chk(state == 4'd7 && err_acc[6] && count_sb(8'h20, s0) == 3, $sformatf("speeds 2, 1, 0 all fail: TRAINERROR (state %0d err %h n %0d)", state, err_acc, count_sb(8'h20, s0)));
    // ---- TRAINERROR: sideband timeout (partner silent in MBINIT)
    lt_start = 0; wait_clk(3);
    err_acc = 0;
    p_fail = 0;
    lt_start = 1;
    wait_state(4'd1, 50);
    sb(8'h01); wait_clk(3); sb(8'h01); wait_clk(3); sb(8'h02);
    wait_state(4'd2, 200);
    auto_sb = 0;
    c = 0;
    while (state == 4'd2 && c < 1000) begin @(negedge clk); c++; end
    wait_clk(2);
    chk(state == 4'd7 && err_acc[4] && c >= SB_TIMEOUT - 5 && c <= SB_TIMEOUT + 5,
        $sformatf("silent partner: TRAINERROR after %0d clocks (state %0d err %h)", c, state, err_acc));
    lt_start = 0; wait_clk(3);
    chk(state == 4'd0, "TRAINERROR to RESET when lt_start drops");
    // ---- LINKINIT timeout measured from the partner's last message
    err_acc = 0; auto_sb = 1; no_li_rsp = 1; t7 = -1;
    lt_start = 1;
    wait_state(4'd1, 50);
    sb(8'h01); wait_clk(3); sb(8'h01); wait_clk(3); sb(8'h02);
    wait_state(4'd2, 200);
    sb(8'h10, 16'd5); sb(8'h12, 16'd16);
    wait_state(4'd4, 600);
    sb(8'h30);
    wait_state(4'd7, 600);
    wait_clk(2);
    chk(err_acc[4] && t7 - t30 == SB_TIMEOUT + 1, $sformatf("no LINKINIT response: TRAINERROR %0d clocks after the partner's request", t7 - t30 - 1));
    lt_start = 0; wait_clk(3);
    chk(bad_crc == 0, "every flit from the model has a good CRC");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #5ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
