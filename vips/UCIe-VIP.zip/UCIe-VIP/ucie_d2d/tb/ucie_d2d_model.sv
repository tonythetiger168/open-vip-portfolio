// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ucie_d2d_model.sv -- UCIe die-to-die reference model: the link training
// state machine of the Logical PHY (driven by sideband messages) and the
// D2D Adapter's 68-byte flit retry (Format 2: 2-byte header, 64 bytes of
// protocol data, 2-byte CRC).
//
// The state sequence and the rules follow the UCIe specification's
// structure: RESET -> SBINIT -> MBINIT (parameter exchange, lane repair)
// -> MBTRAIN (speed degrade on failure) -> LINKINIT -> ACTIVE, with
// PHYRETRAIN, L1 and TRAINERROR. The sideband message codes, the header
// bit layout and the CRC polynomial (CRC_POLY, CRC-16/CCITT by default) are
// this model's own; the specification's encodings are not reproduced.
//
// Sideband (sb_*_msg / sb_*_data), one message per clock:
//   01 SBINIT pattern      02 SBINIT done req   03 SBINIT done rsp
//   10 MBINIT param req    11 MBINIT param rsp  data[2:0] max speed
//   12 MBINIT repair req   13 MBINIT repair rsp data[4:0] usable width
//   20 MBTRAIN req (data[2:0] speed)  21 MBTRAIN rsp (data[0] 1 = pass)
//   30 LINKINIT req        31 LINKINIT rsp
//   40 retrain req         41 retrain rsp
//   50 L1 req  51 L1 rsp (data[0] 1 = accept)  52 L1 exit
// Training: SBINIT ends when two partner patterns were seen and both done
// handshakes completed; speed = min of both max speeds; width from the
// local lane_fail mask (16 lanes; faults only in one half -> x8 on the
// other half; faults in both halves -> TRAINERROR) and the partner's width
// (minimum); MBTRAIN passes when the partner reports pass and
// local_fail[speed] is 0, otherwise the speed drops by one (TRAINERROR
// below speed 0). A state waiting on the partner for SB_TIMEOUT clocks
// goes to TRAINERROR. TRAINERROR and every state return to RESET when
// lt_start is low. A retrain request (either side) in ACTIVE goes through
// PHYRETRAIN -> MBTRAIN -> LINKINIT -> ACTIVE at the current speed; an L1
// request is accepted only with the retry buffer empty, L1 exit retrains.
//
// Flits (mb_*_flit[543:0], byte i in [8i +: 8]):
//   byte 0: {type[1:0], seq[5:0]}  type 0 data, 1 NOP (ACK carrier only)
//   byte 1: {ack_seq[5:0], ack, nak}
//   bytes 2..65: protocol data, bytes 66..67: CRC-16 over bytes 0..65
//   (MSB-first register, init FFFF, byte 66 = CRC[15:8])
// Retry (go-back-N, 64 sequence numbers, RB_DEPTH flits outstanding):
//   receiver: bad CRC -> drop, NAK once; expected seq -> deliver on fdi_rx,
//   ACK; older seq -> drop, ACK; newer seq -> drop, NAK once
//   transmitter: ACK / NAK purge up to ack_seq; NAK replays the rest;
//   no ACK progress for REPLAY_TO clocks replays everything; the fourth
//   replay of the same flit asks for a retrain.
//   Every flit carries the latest ACK / NAK; with no data to send a NOP
//   flit carries a pending one.
// err (pulses): [0] flit CRC  [1] flit sequence  [2] replay timeout
//   [3] replay limit -> retrain  [4] sideband timeout  [5] lane repair
//   impossible  [6] no trainable speed  [7] unexpected sideband message
module ucie_d2d_model #(
  parameter logic [15:0] CRC_POLY = 16'h1021,
  parameter int SB_TIMEOUT = 400, REPLAY_TO = 120, RB_DEPTH = 8,
  parameter logic [2:0] MAX_SPEED = 3'd5
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         lt_start,
  input  logic [15:0]  lane_fail,
  input  logic [7:0]   local_fail,      // training fails at speed i
  input  logic         retrain_req,
  // sideband
  input  logic         sb_rx_valid,
  input  logic [7:0]   sb_rx_msg,
  input  logic [15:0]  sb_rx_data,
  output logic         sb_tx_valid,
  output logic [7:0]   sb_tx_msg,
  output logic [15:0]  sb_tx_data,
  // protocol layer (FDI)
  input  logic         fdi_tx_valid,
  input  logic [511:0] fdi_tx_data,
  output logic         fdi_tx_ready,
  output logic         fdi_rx_valid,
  output logic [511:0] fdi_rx_data,
  // mainband flits
  input  logic         mb_rx_valid,
  input  logic [543:0] mb_rx_flit,
  output logic         mb_tx_valid,
  output logic [543:0] mb_tx_flit,
  // status
  output logic [3:0]   state,
  output logic         link_up,
  output logic [2:0]   speed,
  output logic [4:0]   width,
  output logic [7:0]   err
);
  localparam logic [3:0] S_RESET = 0, S_SBINIT = 1, S_MBINIT = 2, S_MBTRAIN = 3, S_LINKINIT = 4,
                         S_ACTIVE = 5, S_RETRAIN = 6, S_TRAINERR = 7, S_L1 = 8;

  function automatic logic [15:0] crc16(input logic [543:0] f);
    logic [15:0] c;
    c = 16'hFFFF;
    for (int i = 0; i < 66; i++)
      for (int b = 7; b >= 0; b--) begin
        logic fb;
        fb = c[15] ^ f[8 * i + b];
        c = {c[14:0], 1'b0};
        if (fb) c = c ^ CRC_POLY;
      end
    return c;
  endfunction
  function automatic logic seq_le(input logic [5:0] a, input logic [5:0] b);   // a <= b (mod 64)
    return 6'(b - a) < 6'd32;
  endfunction

  // training
  int          t_wait, sb_div;
  logic [1:0]  pat_seen;
  logic        done_tx, done_rx, par_tx, par_rx, rep_tx, rep_rx, tr_tx, tr_rx, li_tx, li_rx;
  logic [2:0]  p_speed;
  logic [4:0]  p_width, l_width;
  logic        tr_pass;
  // retry
  logic [5:0]  tx_seq, rx_exp;
  logic        rt_wait;
  logic [511:0] rb [0:63];
  logic [5:0]  rb_first;
  int          rb_cnt, rp_left, rp_tmr, rp_num;
  logic [5:0]  rp_idx, rp_seq;
  logic        nak_sched, ack_pend, nak_pend;

  task automatic sb_send(input logic [7:0] m, input logic [15:0] d);
    sb_tx_valid <= 1'b1; sb_tx_msg <= m; sb_tx_data <= d;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_RESET; link_up <= 1'b0; speed <= '0; width <= '0; err <= '0;
      sb_tx_valid <= 1'b0; sb_tx_msg <= '0; sb_tx_data <= '0;
      fdi_rx_valid <= 1'b0; fdi_rx_data <= '0; mb_tx_valid <= 1'b0; mb_tx_flit <= '0;
      t_wait = 0; sb_div = 0; pat_seen = '0;
      {done_tx, done_rx, par_tx, par_rx, rep_tx, rep_rx, tr_tx, tr_rx, li_tx, li_rx} = '0;
      p_speed = '0; p_width = '0; l_width = '0; tr_pass = 1'b0;
      tx_seq = '0; rx_exp = '0; rb_first = '0; rb_cnt = 0; rt_wait = 1'b0;
      rp_left = 0; rp_tmr = 0; rp_num = 0; rp_idx = '0; rp_seq = '0;
      nak_sched = 1'b0; ack_pend = 1'b0; nak_pend = 1'b0;
    end else begin : step
      logic [7:0] e;
      logic [3:0] ns;
      logic go_retrain;
      e = '0; ns = state; go_retrain = 1'b0;
      sb_tx_valid <= 1'b0; mb_tx_valid <= 1'b0; fdi_rx_valid <= 1'b0;
      t_wait = t_wait + 1;

      // ======================= mainband receive (ACTIVE only)
      if (mb_rx_valid && state == S_ACTIVE) begin
        if (crc16(mb_rx_flit) != {mb_rx_flit[8 * 66 +: 8], mb_rx_flit[8 * 67 +: 8]}) begin
          e[0] = 1'b1;
          if (!nak_sched) begin nak_sched = 1'b1; nak_pend = 1'b1; ack_pend = 1'b0; end
        end else begin
          logic [1:0] ty;
          logic [5:0] sq, as;
          ty = mb_rx_flit[7:6]; sq = mb_rx_flit[5:0];
          as = mb_rx_flit[15:10];
          // ACK / NAK carried by the partner
          if (mb_rx_flit[9] || mb_rx_flit[8]) begin
            while (rb_cnt != 0 && seq_le(6'(tx_seq - 6'(rb_cnt)), as)) begin
              rb_first = rb_first + 6'd1; rb_cnt = rb_cnt - 1; rp_tmr = 0; rp_num = 0;
            end
            if (rp_left > rb_cnt) rp_left = rb_cnt;
            if (mb_rx_flit[8] && rb_cnt != 0) begin
              rp_left = rb_cnt; rp_idx = rb_first; rp_seq = 6'(tx_seq - 6'(rb_cnt)); rp_tmr = 0;
              rp_num = rp_num + 1;
              if (rp_num == 4) begin e[3] = 1'b1; go_retrain = 1'b1; end
            end
          end
          if (ty == 2'd0) begin
            if (sq == rx_exp) begin
              rx_exp = rx_exp + 6'd1;
              fdi_rx_valid <= 1'b1; fdi_rx_data <= mb_rx_flit[16 +: 512];
              nak_sched = 1'b0; ack_pend = 1'b1;
            end else if (seq_le(sq, 6'(rx_exp - 6'd1))) ack_pend = 1'b1;      // duplicate
            else begin
              e[1] = 1'b1;
              if (!nak_sched) begin nak_sched = 1'b1; nak_pend = 1'b1; ack_pend = 1'b0; end
            end
          end
        end
      end

      // ======================= replay timer
      if (state == S_ACTIVE && rb_cnt != 0 && rp_left == 0) begin
        rp_tmr = rp_tmr + 1;
        if (rp_tmr >= REPLAY_TO) begin
          e[2] = 1'b1; rp_tmr = 0;
          rp_left = rb_cnt; rp_idx = rb_first; rp_seq = 6'(tx_seq - 6'(rb_cnt));
          rp_num = rp_num + 1;
          if (rp_num == 4) begin e[3] = 1'b1; go_retrain = 1'b1; end
        end
      end else if (rb_cnt == 0) rp_tmr = 0;

      // ======================= mainband transmit: replay, new data, NOP
      if (state == S_ACTIVE) begin : tx
        logic [543:0] f;
        logic [1:0] ty;
        logic [5:0] sq;
        logic [511:0] d;
        logic have;
        have = 1'b0; ty = 2'd0; sq = '0; d = '0;
        // data offered while ready is always taken; during a replay it
        // joins the end of the replay
        if (fdi_tx_valid && fdi_tx_ready) begin
          rb[6'(rb_first + 6'(rb_cnt))] = fdi_tx_data;
          rb_cnt = rb_cnt + 1; tx_seq = tx_seq + 6'd1;
          if (rp_left != 0) rp_left = rp_left + 1;
          else begin have = 1'b1; sq = 6'(tx_seq - 6'd1); d = fdi_tx_data; end
        end
        if (!have && rp_left != 0) begin
          have = 1'b1; sq = rp_seq; d = rb[rp_idx];
          rp_left = rp_left - 1; rp_idx = rp_idx + 6'd1; rp_seq = rp_seq + 6'd1;
        end else if (!have && (ack_pend || nak_pend)) begin
          have = 1'b1; ty = 2'd1; sq = '0;
        end
        if (have) begin
          f = '0;
          f[7:0] = {ty, sq};
          f[15:10] = 6'(rx_exp - 6'd1);
          f[9] = ack_pend && !nak_pend;
          f[8] = nak_pend;
          f[16 +: 512] = d;
          {f[8 * 66 +: 8], f[8 * 67 +: 8]} = crc16(f);
          mb_tx_valid <= 1'b1; mb_tx_flit <= f;
          ack_pend = 1'b0; nak_pend = 1'b0;
        end
      end

      // ======================= sideband receive
      if (sb_rx_valid) begin
        case (sb_rx_msg)
          8'h01: if (state == S_SBINIT) begin if (pat_seen != 2'd2) pat_seen = pat_seen + 2'd1; end
          8'h02: if (state == S_SBINIT && pat_seen == 2'd2) begin sb_send(8'h03, 16'h0); done_rx = 1'b1; t_wait = 0; end
                 else e[7] = 1'b1;
          8'h03: if (state == S_SBINIT && done_tx) begin done_tx = 1'b0; par_tx = 1'b1; t_wait = 0; end   // own done answered
                 else e[7] = 1'b1;
          8'h10: if (state == S_MBINIT) begin p_speed = sb_rx_data[2:0]; par_rx = 1'b1;
                   sb_send(8'h11, {13'h0, MAX_SPEED}); t_wait = 0; end
                 else e[7] = 1'b1;
          8'h11: if (state == S_MBINIT && par_tx) begin par_tx = 1'b0; rep_tx = 1'b1; t_wait = 0; end
                 else e[7] = 1'b1;
          8'h12: if (state == S_MBINIT) begin p_width = sb_rx_data[4:0]; rep_rx = 1'b1;
                   sb_send(8'h13, {11'h0, l_width}); t_wait = 0; end
                 else e[7] = 1'b1;
          8'h13: if (state == S_MBINIT && rep_tx) begin rep_tx = 1'b0; li_tx = 1'b1; t_wait = 0; end
                 else e[7] = 1'b1;
          8'h20: if (state == S_MBTRAIN || state == S_RETRAIN) begin
                   sb_send(8'h21, {15'h0, !local_fail[sb_rx_data[2:0]]}); t_wait = 0; end
                 else e[7] = 1'b1;
          8'h21: if (state == S_MBTRAIN && tr_tx) begin tr_tx = 1'b0; tr_rx = 1'b1; tr_pass = sb_rx_data[0]; t_wait = 0; end
                 else e[7] = 1'b1;
          8'h30: if (state == S_LINKINIT) begin sb_send(8'h31, 16'h0); li_rx = 1'b1; t_wait = 0; end
                 else e[7] = 1'b1;
          8'h31: if (state == S_LINKINIT && li_tx) begin li_tx = 1'b0; done_tx = 1'b1; t_wait = 0; end
                 else e[7] = 1'b1;
          8'h40: if (state == S_ACTIVE) begin sb_send(8'h41, 16'h0); ns = S_RETRAIN; end
                 else e[7] = 1'b1;
          8'h41: if (state == S_RETRAIN && rt_wait) rt_wait = 1'b0;
                 else e[7] = 1'b1;
          8'h50: if (state == S_ACTIVE) begin
                   sb_send(8'h51, {15'h0, rb_cnt == 0});
                   if (rb_cnt == 0) ns = S_L1;
                 end else e[7] = 1'b1;
          8'h52: if (state == S_L1) ns = S_RETRAIN;
                 else e[7] = 1'b1;
          default: e[7] = 1'b1;
        endcase
      end

      // ======================= training state machine
      case (state)
        S_RESET: if (lt_start) begin
          ns = S_SBINIT; t_wait = 0; sb_div = 0; pat_seen = '0;
          {done_tx, done_rx, par_tx, par_rx, rep_tx, rep_rx, tr_tx, tr_rx, li_tx, li_rx} = '0;
        end
        S_SBINIT: begin
          sb_div = sb_div + 1;
          if (pat_seen != 2'd2 && sb_div % 4 == 0 && !sb_rx_valid) sb_send(8'h01, 16'h0);
          else if (pat_seen == 2'd2 && !done_tx && !par_tx && sb_div % 4 == 0 && !sb_rx_valid) begin
            sb_send(8'h02, 16'h0); done_tx = 1'b1;
          end
          // par_tx here marks "own done answered"
          if (par_tx && done_rx) begin
            ns = S_MBINIT; t_wait = 0; par_tx = 1'b0; done_rx = 1'b0;
            l_width = (lane_fail == 0) ? 5'd16 : (lane_fail[15:8] == 0 || lane_fail[7:0] == 0) ? 5'd8 : 5'd0;
          end
        end
        S_MBINIT: begin
          if (l_width == 0) begin e[5] = 1'b1; ns = S_TRAINERR; end
          else if (!par_tx && !rep_tx && !li_tx && !sb_rx_valid) begin sb_send(8'h10, {13'h0, MAX_SPEED}); par_tx = 1'b1; end
          else if (rep_tx && par_rx && !done_tx && !sb_rx_valid) begin sb_send(8'h12, {11'h0, l_width}); done_tx = 1'b1; end
          if (li_tx && rep_rx) begin
            ns = S_MBTRAIN; t_wait = 0; li_tx = 1'b0; done_tx = 1'b0;
            speed <= (p_speed < MAX_SPEED) ? p_speed : MAX_SPEED;
            width <= (p_width < l_width) ? p_width : l_width;
          end
        end
        S_MBTRAIN, S_RETRAIN: begin
          if (state == S_RETRAIN) begin if (!rt_wait) ns = S_MBTRAIN; end
          else if (!tr_tx && !tr_rx && !sb_rx_valid) begin sb_send(8'h20, {13'h0, speed}); tr_tx = 1'b1; end
          else if (tr_rx) begin
            tr_rx = 1'b0;
            if (tr_pass && !local_fail[speed]) begin ns = S_LINKINIT; t_wait = 0; li_tx = 1'b0; done_tx = 1'b0; li_rx = 1'b0; end
            else if (speed == 0) begin e[6] = 1'b1; ns = S_TRAINERR; end
            else begin speed <= speed - 3'd1; t_wait = 0; end
          end
        end
        S_LINKINIT: begin
          if (!li_tx && !done_tx && !sb_rx_valid) begin sb_send(8'h30, 16'h0); li_tx = 1'b1; end
          if (done_tx && li_rx) begin ns = S_ACTIVE; done_tx = 1'b0; li_rx = 1'b0; rp_num = 0; end
        end
        S_ACTIVE: begin
          if ((retrain_req || go_retrain) && !sb_rx_valid && ns == S_ACTIVE) begin sb_send(8'h40, 16'h0); ns = S_RETRAIN; rt_wait = 1'b1; end
        end
        default: ;
      endcase
      // sideband timeout while waiting on the partner
      if ((state == S_SBINIT || state == S_MBINIT || state == S_MBTRAIN || state == S_LINKINIT) &&
          t_wait >= SB_TIMEOUT && ns == state) begin
        e[4] = 1'b1; ns = S_TRAINERR;
      end
      if (!lt_start) ns = S_RESET;
      if (ns != state) begin
        t_wait = 0;
        if (ns == S_RETRAIN || ns == S_MBTRAIN) begin tr_tx = 1'b0; tr_rx = 1'b0; end
        if (ns == S_RESET || ns == S_TRAINERR) begin
          tx_seq = '0; rx_exp = '0; rb_first = '0; rb_cnt = 0; rp_left = 0;
          rp_tmr = 0; rp_num = 0; nak_sched = 1'b0; ack_pend = 1'b0; nak_pend = 1'b0;
          speed <= '0; width <= '0;
        end
      end
      state <= ns;
      link_up <= (ns == S_ACTIVE);
      fdi_tx_ready <= (ns == S_ACTIVE) && rb_cnt < RB_DEPTH;
      err <= e;
    end
  end
endmodule
