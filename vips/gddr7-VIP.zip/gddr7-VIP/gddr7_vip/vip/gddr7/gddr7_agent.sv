// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// gddr7_agent.sv -- GDDR7 UVM agent (sequencer + driver + monitor)

`ifndef GDDR7_AGENT_SV
`define GDDR7_AGENT_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
typedef class gddr7_driver;
typedef class gddr7_monitor;

class gddr7_agent extends uvm_agent;
  `uvm_component_utils(gddr7_agent)
  uvm_sequencer #(gddr7_transaction) sqr;
  gddr7_driver  drv;
  gddr7_monitor mon;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    sqr = uvm_sequencer #(gddr7_transaction)::type_id::create("sqr", this);
    drv = gddr7_driver::type_id::create("drv", this);
    mon = gddr7_monitor::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
