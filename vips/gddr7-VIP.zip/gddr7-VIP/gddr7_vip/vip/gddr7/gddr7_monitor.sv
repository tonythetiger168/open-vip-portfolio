// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// gddr7_monitor.sv -- GDDR7 bus monitor
//
// Decodes GDDR7 commands (ACT/RD/WR/PRE/REF) from the command/address bus
// on every posedge of ck, samples the DQ data bus at the CAS latency /
// CAS write latency point, reconstructs transactions and publishes them on
// the analysis port for the scoreboard, coverage and checkers.

`ifndef GDDR7_MONITOR_SV
`define GDDR7_MONITOR_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class gddr7_monitor extends uvm_monitor;
  `uvm_component_utils(gddr7_monitor)
  virtual gddr7_if vif;
  uvm_analysis_port #(gddr7_transaction) ap;
  int unsigned txn_count = 0;

  // Must match the driver / memory-model latencies
  localparam int TCL  = 8;
  localparam int TCWL = 2;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual gddr7_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "GDDR7 virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    gddr7_transaction tr;
    forever begin
      @(posedge vif.ck);
      if (vif.rst_n !== 1'b1) continue;
      if (vif.cs_n !== 1'b0) continue;               // deselect cycle
      if (vif.act_n === 1'b0) begin                  // ACT: row on addr
        tr = gddr7_transaction::type_id::create("tr");
        tr.cmd = GDDR7_CMD_ACT;
        tr.row = vif.addr; tr.addr = vif.addr;
        tr.bg = vif.bg; tr.ba = vif.ba; tr.stack_id = vif.stack_id;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
      else if (vif.ras_n === 1'b1 && vif.cas_n === 1'b0) begin  // RD or WR
        tr = gddr7_transaction::type_id::create("tr");
        tr.cmd = vif.we_n ? GDDR7_CMD_RD : GDDR7_CMD_WR;
        tr.col = vif.addr[9:0]; tr.addr = vif.addr;
        tr.bg = vif.bg; tr.ba = vif.ba; tr.stack_id = vif.stack_id;
        if (vif.we_n) begin                          // RD: sample at CAS latency
          repeat (TCL-1) @(posedge vif.ck);
          #1 tr.rdata = vif.dq;
        end
        else begin                                   // WR: sample at CAS write latency
          repeat (TCWL-1) @(posedge vif.ck);
          #1 tr.data = vif.dq;
        end
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
      else if (vif.ras_n === 1'b0 && vif.cas_n === 1'b1 && vif.we_n === 1'b0) begin  // PRE
        tr = gddr7_transaction::type_id::create("tr");
        tr.cmd = GDDR7_CMD_PRE;
        tr.bg = vif.bg; tr.ba = vif.ba; tr.stack_id = vif.stack_id;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
      else if (vif.ras_n === 1'b0 && vif.cas_n === 1'b0 && vif.we_n === 1'b1) begin  // REF
        tr = gddr7_transaction::type_id::create("tr");
        tr.cmd = GDDR7_CMD_REF;
        tr.bg = vif.bg; tr.ba = vif.ba; tr.stack_id = vif.stack_id;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
      // NOP (cs_n=0, act_n=ras_n=cas_n=we_n=1) is a wait state: not published
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("gddr7 monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
