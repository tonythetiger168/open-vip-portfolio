// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// gddr7_test.sv -- GDDR7 UVM tests

`ifndef GDDR7_TEST_SV
`define GDDR7_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class gddr7_base_test extends uvm_test;
  `uvm_component_utils(gddr7_base_test)
  gddr7_env env;
  function new(string name="gddr7_base_test", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = gddr7_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    gddr7_regression_sequence seq;
    phase.raise_objection(this);
    seq = gddr7_regression_sequence::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: write flow only
class gddr7_write_test extends gddr7_base_test;
  `uvm_component_utils(gddr7_write_test)
  function new(string name="gddr7_write_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr7_write_seq seq;
    phase.raise_objection(this);
    seq = gddr7_write_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: read flow + refresh flow
class gddr7_read_test extends gddr7_base_test;
  `uvm_component_utils(gddr7_read_test)
  function new(string name="gddr7_read_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr7_read_seq    rd;
    gddr7_refresh_seq rf;
    phase.raise_objection(this);
    rd = gddr7_read_seq::type_id::create("rd");
    rf = gddr7_refresh_seq::type_id::create("rf");
    rd.start(env.agt.sqr);
    rf.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress test: long protocol-legal random stream
class gddr7_stress_test extends gddr7_base_test;
  `uvm_component_utils(gddr7_stress_test)
  function new(string name="gddr7_stress_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr7_stress_seq seq;
    phase.raise_objection(this);
    seq = gddr7_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
