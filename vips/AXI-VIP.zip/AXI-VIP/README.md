# AXI — AXI4 UVM VIP

Open-source UVM verification IP for **AMBA AXI4**, sharing the common
`amba_vip_if` / `amba_vip_pkg` skeleton with the AHB and APB VIPs.

## Protocol overview

AXI4 uses five independent handshake channels: AW/W/B for writes and AR/R
for reads. Bursts (`AWLEN/ARLEN` + 1 beats) support INCR / WRAP / FIXED
addressing with `AxSIZE` beat size; `WLAST`/`RLAST` mark the final beat.
Responses (`BRESP`/`RRESP`) report OKAY / EXOKAY / SLVERR / DECERR.

## Architecture

| Path | Description |
|------|-------------|
| `rtl/amba_vip_if.sv` | AXI4+AHB5+APB4 interface, `drv_cb`/`mon_cb` clocking blocks, modports, inline SVA + covergroup |
| `vip/base/amba_vip_pkg.sv` | `amba_txn`/`amba_seq_item`, `amba_cov`, end-to-end `amba_sb` scoreboard; includes AXI UVC + SVA checker |
| `vip/axi/axi_driver.svh` | AXI4 master driver: one thread per channel, up to 4 bursts outstanding per direction on any AWID/ARID, narrow and unaligned WSTRB per beat, B/R matched to the oldest burst of their ID, random BREADY/RREADY and WVALID gaps |
| `vip/axi/axi_monitor.svh` | AXI4 monitor: rebuilds every outstanding burst per ID (W in AW order, B / R by ID), marks out-of-order completion and interleaved reads |
| `vip/axi/axi_agent.svh` / `axi_sequencer.svh` | Active agent (sequencer + driver + monitor) |
| `vip/axi/axi_sequences.svh` | Directed sequence library (see below) |
| `vip/axi/axi_coverage.svh` | Functional coverage: burst / size / length, narrow / unaligned / strobes / 4 KB page end, IDs / outstanding / out-of-order / interleaving |
| `vip/axi/axi_protocol_checker.sv` | Class-based protocol checker (properties + `cg_axi`) |
| `rtl/sva/axi_compliance_checker.sv` | Tiered SVA compliance checker (L1/L2/L3/L4) |
| `env/amba_env.sv` | Environment: agent, scoreboard, coverage, checkers, analysis connections |
| `tests/amba_tests.sv` | `amba_base_test` / `amba_axi_test` / `amba_ahb_test` / `amba_apb_test` |
| `tb/top_tb.sv` | Testbench top + functional AXI4 slave DUT: 4 KB memory, 4 write + 4 read bursts outstanding, B / R out of order across IDs, interleaved R beats, narrow / unaligned lanes, SLVERR for the `0xEE00_0000` region, 4 KB crossings, illegal WRAP / size |
| `scripts/` | Makefile + coverage-driven regression (line/fsm/toggle/SVA, 100% goal) |

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `axi_base_sequence` | Random AXI4 transactions (8-byte beats, aligned) |
| `axi_single_seq` | Single-beat directed transfers |
| `axi_incr_burst_seq` | INCR 4/8/16-beat bursts (aligned) |
| `axi_wrap_burst_seq` | WRAP 2/4/8/16 cache-line corner case |
| `axi_back_to_back_seq` | Zero-delay back-to-back transfers |
| `axi_error_inject_seq` | SLVERR region accesses (`0xEE??_????`) |
| `axi_reset_seq` | Transfer right after reset release |
| `axi_stress_seq` | 100 long random bursts |
| `axi_regression_sequence` | Weighted mix of all directed sequences |
| `axi_cov_sweep_seq` | Every burst / size / length class, narrow and unaligned bursts from every byte offset, bursts ending on a 4 KB page, then 160 outstanding bursts on 16 IDs (nb) |

## SVA compliance (rtl/sva/axi_compliance_checker.sv)

- **L1 Basic (4)**: AWVALID/WVALID/ARVALID/RVALID stability until ready
- **L2 Full protocol (4)**: burst legality, WLAST, B/R response rules
- **L3 Advanced (4)**: ID ordering, WSTRB contiguity, exclusive access, AWCACHE
- **L4 AXI4-specific**: AW payload stable until AWREADY, WSTRB only on the beat's byte lanes, BVALID only with the BID of a write past WLAST, RVALID only with the RID of an outstanding read, INCR bursts inside one 4 KB page, WRAP length 2/4/8/16, B / R payload stable until READY
- WLAST is checked against an AWLEN FIFO (W beats follow the AW order with several writes outstanding)

## Functional coverage (vip/axi/axi_coverage.svh)

- `cg_protocol`: write × burst × size × len, response bins + crosses
- `cg_xfer`: aligned / unaligned × size, narrow, sparse strobes, INCR ending on the last byte of a 4 KB page
- `cg_order`: ID, bursts outstanding at issue, out-of-order completion, interleaved reads
- `cg_data`: data pattern corners (all-0/all-1/0xAA…/0x55…) × write cross

## UVM RAL (register model)

- `env/amba_reg_model.sv` -- `amba_reg_block` modelling the `amba_dut` slave in
  `tb/top_tb.sv`: REG0..REG7 (0x00-0x38) + MEM 504x64 (0x40-0xFF8), all RW with reset 0, plus `ERR_PROBE` at
  0xEE000000 (error region, excluded from the built-in sequences). Map: axi_map (8 bytes).
- `vip/base/amba_reg_adapter.svh` -- `amba_reg_adapter` (single-beat AXI4
  `amba_seq_item`; `protocol` / `bus_bytes` set by the env).
- `amba_env` builds the model, sets the adapter on the agent sequencer and
  keeps the mirror with a `uvm_reg_predictor` fed by the monitor
  (explicit prediction).
- `amba_ral_test` -- `uvm_reg_hw_reset_seq`, `uvm_reg_bit_bash_seq`, `uvm_mem_walk_seq`,
  random write + `mirror(UVM_CHECK)`, and the error response returning `UVM_NOT_OK`.
  Runs on Verilator: `python3 tools/run_uvm_tests.py AXI-VIP` from the
  portfolio repo (see docs/RAL.md there).

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
TEST=amba_ahb_test make all
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

## Deepened Features (v1.8.0)

- **Outstanding bursts and IDs**: the driver issues up to 4 bursts per direction on AWID/ARID; the slave answers B out of order across IDs (in order within one) and interleaves R beats of different IDs; driver and monitor match responses by ID
- **Narrow and unaligned transfers**: per-beat byte lanes from the beat address and AxSIZE; the driver limits WSTRB to them, the slave ignores strobes outside them, the scoreboard checks only the active lanes
- **4 KB boundary**: an INCR burst crossing a page is a checker error and gets SLVERR from the slave
- **Reference memory in the scoreboard**: every read beat is checked against a byte model of the slave, every response against its SLVERR rules
- **Smoke test**: 37 self-checking groups on the flattened slave, including 150 random outstanding batches with back-pressure

## Deepened Features (v1.6.0)

- **AXI4 master driver**: full 5-channel handshake, burst address generation (INCR/WRAP/FIXED), WLAST/RLAST handling, BRESP/RRESP capture
- **Channel-tracking monitor**: reconstructs write/read bursts from handshakes, closes on B / RLAST, publishes transactions
- **End-to-end scoreboard**: driver-issued (expected) vs monitor-decoded (observed) compare with `n_matches`/`n_mismatches` and `UVM_ERROR` on mismatch
- **Functional DUT model**: AXI4 slave memory with SLVERR region closing the driver→DUT→monitor loop
- **Directed sequence library**: 9 sequences (single / incr / wrap / back-to-back / error / reset / stress / regression)
- **SVA L4**: 4 AXI4-specific rules
- **Functional coverage**: 3 covergroups with cross coverage

License: Apache-2.0
