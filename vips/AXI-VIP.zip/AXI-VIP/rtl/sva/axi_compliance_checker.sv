// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// AXI Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 16
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=Protocol-Specific Rules
`ifndef AXI_COMPLIANCE_CHECKER_SV
`define AXI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================================
// axi_compliance_checker_sva -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module axi_compliance_checker_sva (amba_vip_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  // AWVALID, once asserted, stays high until AWREADY (AXI A3.2.1)
  property p_axi_awvalid_stable; @(posedge vif.aclk) disable iff (!vif.aresetn) (vif.awvalid && !vif.awready) |=> vif.awvalid; endproperty
  assert_p_axi_awvalid_stable: assert property(p_axi_awvalid_stable) l1_pass[0]++; else begin `uvm_warning("AXI_L1", "AWVALID stable failed"); l1_fail[0]++; end
  cover_p_axi_awvalid_stable: cover property(p_axi_awvalid_stable);
  property p_axi_awburst_valid; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.awvalid |-> vif.awburst inside {2'b00,2'b01,2'b10}; endproperty
  assert_p_axi_awburst_valid: assert property(p_axi_awburst_valid) l1_pass[1]++; else begin `uvm_warning("AXI_L1", "AWBURST valid failed"); l1_fail[1]++; end
  cover_p_axi_awburst_valid: cover property(p_axi_awburst_valid);
  // AWSIZE must not exceed the data bus width (AXI A3.4.1): 2**AWSIZE <= WSTRB bits
  property p_axi_awsize_valid; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.awvalid |-> (1 << vif.awsize) <= $bits(vif.wstrb); endproperty
  assert_p_axi_awsize_valid: assert property(p_axi_awsize_valid) l1_pass[2]++; else begin `uvm_warning("AXI_L1", "AWSIZE wider than the data bus"); l1_fail[2]++; end
  cover_p_axi_awsize_valid: cover property(p_axi_awsize_valid);
  // EXOKAY is only a legal response to an exclusive write (AXI A7.2.4)
  logic excl_wr;
  always @(posedge vif.aclk or negedge vif.aresetn)
    if (!vif.aresetn) excl_wr <= 1'b0;
    else if (vif.awvalid && vif.awready) excl_wr <= vif.awlock;
  property p_axi_bresp_valid; @(posedge vif.aclk) disable iff (!vif.aresetn) (vif.bvalid && vif.bresp == 2'b01) |-> excl_wr; endproperty
  assert_p_axi_bresp_valid: assert property(p_axi_bresp_valid) l1_pass[3]++; else begin `uvm_warning("AXI_L1", "EXOKAY to a non-exclusive write"); l1_fail[3]++; end
  cover_p_axi_bresp_valid: cover property(p_axi_bresp_valid);

  // ===== L2: Full Protocol (4 SVAs) =====
  // AW FIFO: several write bursts may be outstanding and their W beats
  // follow the AW order, so each W beat belongs to the head entry. The head
  // also tracks the beat address for the WSTRB lane check (L4-2).
  logic [31:0] aw_addr [0:15];
  logic [7:0]  aw_len  [0:15], aw_id [0:15];
  logic [2:0]  aw_size [0:15];
  logic [1:0]  aw_burst[0:15];
  logic [3:0]  aw_rp, aw_wp;
  logic [4:0]  aw_cnt;
  logic [7:0]  wl_beat;
  logic [31:0] wl_addr;                 // address of the head burst's current beat
  wire         wl_known = (aw_cnt != 5'd0) || (vif.awvalid && vif.awready);
  wire  [7:0]  wl_awlen = (aw_cnt != 5'd0) ? aw_len[aw_rp]   : vif.awlen;
  wire  [2:0]  wl_size  = (aw_cnt != 5'd0) ? aw_size[aw_rp]  : vif.awsize;
  wire  [1:0]  wl_burst = (aw_cnt != 5'd0) ? aw_burst[aw_rp] : vif.awburst;
  wire  [7:0]  wl_id    = (aw_cnt != 5'd0) ? aw_id[aw_rp]    : vif.awid;
  wire  [31:0] wl_cur   = (wl_beat != 8'h0) ? wl_addr : ((aw_cnt != 5'd0) ? aw_addr[aw_rp] : vif.awaddr);
  wire         w_hs     = vif.wvalid && vif.wready && wl_known;
  wire         wl_pop   = w_hs && vif.wlast;
  function automatic logic [31:0] beat_next(logic [31:0] a, logic [2:0] sz, logic [1:0] bt, logic [7:0] len);
    logic [31:0] nb, wsz;
    nb = 32'd1 << sz;
    if (bt == 2'b00) return a;
    if (bt == 2'b10) begin
      wsz = nb * (32'(len) + 32'd1);
      return (a & ~(wsz - 32'd1)) | ((a + nb) & (wsz - 32'd1));
    end
    return (a & ~(nb - 32'd1)) + nb;
  endfunction
  function automatic logic [7:0] beat_lanes(logic [31:0] a, logic [2:0] sz);
    logic [3:0] nb;
    nb = 4'd1 << sz;
    return (8'((9'd1 << nb) - 9'd1) << (a[2:0] & ~(3'(nb) - 3'd1))) & ~((8'd1 << a[2:0]) - 8'd1);
  endfunction
  always @(posedge vif.aclk or negedge vif.aresetn)
    if (!vif.aresetn) begin
      aw_rp <= 4'h0; aw_wp <= 4'h0; aw_cnt <= 5'd0; wl_beat <= 8'h0; wl_addr <= 32'h0;
    end
    else begin
      if (vif.awvalid && vif.awready) begin
        aw_addr[aw_wp] <= vif.awaddr; aw_len[aw_wp] <= vif.awlen; aw_size[aw_wp] <= vif.awsize;
        aw_burst[aw_wp] <= vif.awburst; aw_id[aw_wp] <= vif.awid; aw_wp <= aw_wp + 4'h1;
      end
      if (wl_pop) aw_rp <= aw_rp + 4'h1;
      aw_cnt <= aw_cnt + 5'(vif.awvalid && vif.awready) - 5'(wl_pop);
      if (w_hs) begin
        wl_beat <= vif.wlast ? 8'h0 : wl_beat + 8'h1;
        wl_addr <= beat_next(wl_cur, wl_size, wl_burst, wl_awlen);
      end
    end
  property p_axi_wlast_align; @(posedge vif.aclk) disable iff (!vif.aresetn) w_hs |-> (vif.wlast == (wl_beat == wl_awlen)); endproperty
  assert_p_axi_wlast_align: assert property(p_axi_wlast_align) l2_pass[0]++; else begin `uvm_warning("AXI_L2", "WLAST aligns AWLEN failed"); l2_fail[0]++; end
  cover_p_axi_wlast_align: cover property(p_axi_wlast_align);
  property p_axi_arburst_valid; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.arvalid |-> vif.arburst inside {2'b00,2'b01,2'b10}; endproperty
  assert_p_axi_arburst_valid: assert property(p_axi_arburst_valid) l2_pass[1]++; else begin `uvm_warning("AXI_L2", "ARBURST valid failed"); l2_fail[1]++; end
  cover_p_axi_arburst_valid: cover property(p_axi_arburst_valid);
  // RDATA, RRESP and RLAST stay stable while RVALID waits for RREADY (AXI A3.2.1)
  property p_axi_rlast_resp; @(posedge vif.aclk) disable iff (!vif.aresetn) (vif.rvalid && !vif.rready) |=> (vif.rvalid && $stable(vif.rresp) && $stable(vif.rlast) && $stable(vif.rdata)); endproperty
  assert_p_axi_rlast_resp: assert property(p_axi_rlast_resp) l2_pass[2]++; else begin `uvm_warning("AXI_L2", "R channel changed while RVALID waited for RREADY"); l2_fail[2]++; end
  cover_p_axi_rlast_resp: cover property(p_axi_rlast_resp);
  // a WRAP burst starts aligned to its size (A3.4.1); INCR / FIXED may be unaligned
  property p_axi_addr_aligned; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.awvalid && vif.awburst == 2'b10 |-> (vif.awaddr & ((32'd1 << vif.awsize) - 32'd1)) == 0; endproperty
  assert_p_axi_addr_aligned: assert property(p_axi_addr_aligned) l2_pass[3]++; else begin `uvm_error("AXI_L2", "WRAP burst address not aligned to AWSIZE"); l2_fail[3]++; end
  cover_p_axi_addr_aligned: cover property(p_axi_addr_aligned);

  // ===== L3: Advanced Features (4 SVAs) =====
  // Write address channel payload is stable while AWVALID waits for AWREADY (AXI A3.2.1)
  property p_axi_awid_order; @(posedge vif.aclk) disable iff (!vif.aresetn) (vif.awvalid && !vif.awready) |=> ($stable(vif.awid) && $stable(vif.awaddr) && $stable(vif.awlen) && $stable(vif.awsize) && $stable(vif.awburst)); endproperty
  assert_p_axi_awid_order: assert property(p_axi_awid_order) l3_pass[0]++; else begin `uvm_warning("AXI_L3", "AW channel changed while AWVALID waited for AWREADY"); l3_fail[0]++; end
  cover_p_axi_awid_order: cover property(p_axi_awid_order);
  // WDATA / WSTRB / WLAST stay stable while WVALID waits for WREADY (AXI A3.2.1); sparse
  // strobes are legal, so the former "contiguous" form (true for any non-zero WSTRB) is gone
  property p_axi_wstrb_contig; @(posedge vif.aclk) disable iff (!vif.aresetn) (vif.wvalid && !vif.wready) |=> (vif.wvalid && $stable(vif.wstrb) && $stable(vif.wdata) && $stable(vif.wlast)); endproperty
  assert_p_axi_wstrb_contig: assert property(p_axi_wstrb_contig) l3_pass[1]++; else begin `uvm_warning("AXI_L3", "W channel changed while WVALID waited for WREADY"); l3_fail[1]++; end
  cover_p_axi_wstrb_contig: cover property(p_axi_wstrb_contig);
  property p_axi_rresp_excl; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.rvalid && vif.rresp == 2'b01 |-> vif.arlock == 1; endproperty
  assert_p_axi_rresp_excl: assert property(p_axi_rresp_excl) l3_pass[2]++; else begin `uvm_warning("AXI_L3", "Exclusive access OK failed"); l3_fail[2]++; end
  cover_p_axi_rresp_excl: cover property(p_axi_rresp_excl);
  // Non-modifiable transactions (AWCACHE[1]=0) must have AWCACHE[3:2]=0 (AXI4 A4.4)
  property p_axi_awcache_buffer; @(posedge vif.aclk) disable iff (!vif.aresetn) (vif.awvalid && !vif.awcache[1]) |-> vif.awcache[3:2] == 2'b00; endproperty
  assert_p_axi_awcache_buffer: assert property(p_axi_awcache_buffer) l3_pass[3]++; else begin `uvm_warning("AXI_L3", "AWCACHE[3:2] set on a non-modifiable write"); l3_fail[3]++; end
  cover_p_axi_awcache_buffer: cover property(p_axi_awcache_buffer);

  // ---------------- L4: AXI protocol-specific rules (4) ----------------
  // L4-1: AWADDR/AWLEN held stable while AWVALID waits for AWREADY
  property p_axi_l4_aw_payload_stable; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.awvalid && !vif.awready |=> vif.awvalid && $stable({vif.awaddr, vif.awlen}); endproperty
  assert_p_axi_l4_aw_payload_stable: assert property(p_axi_l4_aw_payload_stable) l4_pass[0]++; else begin `uvm_warning("AXI_L4", "AW payload not stable during AWVALID wait"); l4_fail[0]++; end
  cover_p_axi_l4_aw_payload_stable: cover property(p_axi_l4_aw_payload_stable);
  // L4-2: WSTRB is set only on the byte lanes of the beat's address window
  // (narrow and unaligned transfers, A3.4.3)
  property p_axi_l4_wstrb_lanes; @(posedge vif.aclk) disable iff (!vif.aresetn) w_hs |-> (vif.wstrb & ~beat_lanes(wl_cur, wl_size)) == 8'h0; endproperty
  assert_p_axi_l4_wstrb_lanes: assert property(p_axi_l4_wstrb_lanes) l4_pass[1]++; else begin `uvm_error("AXI_L4", "WSTRB set outside the beat's byte lanes"); l4_fail[1]++; end
  cover_p_axi_l4_wstrb_lanes: cover property(@(posedge vif.aclk) disable iff (!vif.aresetn) w_hs && vif.wstrb != 8'hFF && vif.wstrb != 8'h00);
  // L4-3: a B response only for a write whose WLAST has passed, with that
  // write's ID; R beats only with the ID of an outstanding read (A5.3)
  int unsigned wdone [0:255];   // writes per ID with all W beats in, waiting for B
  int unsigned rout  [0:255];   // reads per ID accepted, RLAST not yet seen
  initial for (int i = 0; i < 256; i++) begin wdone[i] = 0; rout[i] = 0; end
  always @(posedge vif.aclk or negedge vif.aresetn)
    if (!vif.aresetn) for (int i = 0; i < 256; i++) begin wdone[i] <= 0; rout[i] <= 0; end
    else begin
      if (wl_pop) wdone[wl_id] <= wdone[wl_id] + 1 - int'(vif.bvalid && vif.bready && vif.bid == wl_id);
      if (vif.bvalid && vif.bready && !(wl_pop && vif.bid == wl_id)) wdone[vif.bid] <= wdone[vif.bid] - 1;
      if (vif.arvalid && vif.arready)
        rout[vif.arid] <= rout[vif.arid] + 1 - int'(vif.rvalid && vif.rready && vif.rlast && vif.rid == vif.arid);
      if (vif.rvalid && vif.rready && vif.rlast && !(vif.arvalid && vif.arready && vif.rid == vif.arid))
        rout[vif.rid] <= rout[vif.rid] - 1;
    end
  property p_axi_l4_bvalid_after_wlast; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.bvalid |-> wdone[vif.bid] != 0; endproperty
  assert_p_axi_l4_bvalid_after_wlast: assert property(p_axi_l4_bvalid_after_wlast) l4_pass[2]++; else begin `uvm_error("AXI_L4", "BVALID with a BID that has no write past WLAST"); l4_fail[2]++; end
  cover_p_axi_l4_bvalid_after_wlast: cover property(p_axi_l4_bvalid_after_wlast);
  property p_axi_rid_outstanding; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.rvalid |-> rout[vif.rid] != 0; endproperty
  assert_p_axi_rid_outstanding: assert property(p_axi_rid_outstanding) else `uvm_error("AXI_L4", "RVALID with an RID that has no outstanding read")
  // an INCR burst stays inside one 4 KB page (A3.4.1)
  function automatic logic crosses_4k(logic [31:0] a, logic [7:0] len, logic [2:0] sz);
    return ({2'b00, a[11:0] & ~((12'd1 << sz) - 12'd1)} + ((14'(len) + 14'd1) << sz)) > 14'h1000;
  endfunction
  property p_axi_aw_4k; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.awvalid && vif.awburst == 2'b01 |-> !crosses_4k(vif.awaddr, vif.awlen, vif.awsize); endproperty
  assert_p_axi_aw_4k: assert property(p_axi_aw_4k) else `uvm_error("AXI_L4", "INCR write burst crosses a 4 KB boundary")
  property p_axi_ar_4k; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.arvalid && vif.arburst == 2'b01 |-> !crosses_4k(vif.araddr, vif.arlen, vif.arsize); endproperty
  assert_p_axi_ar_4k: assert property(p_axi_ar_4k) else `uvm_error("AXI_L4", "INCR read burst crosses a 4 KB boundary")
  // a WRAP burst has 2, 4, 8 or 16 beats
  property p_axi_wrap_len; @(posedge vif.aclk) disable iff (!vif.aresetn) (vif.awvalid && vif.awburst == 2'b10 |-> vif.awlen inside {8'd1, 8'd3, 8'd7, 8'd15}) and (vif.arvalid && vif.arburst == 2'b10 |-> vif.arlen inside {8'd1, 8'd3, 8'd7, 8'd15}); endproperty
  assert_p_axi_wrap_len: assert property(p_axi_wrap_len) else `uvm_error("AXI_L4", "WRAP burst length is not 2, 4, 8 or 16")
  // response channel payload stable while waiting
  property p_axi_b_stable; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.bvalid && !vif.bready |=> vif.bvalid && $stable({vif.bid, vif.bresp}); endproperty
  assert_p_axi_b_stable: assert property(p_axi_b_stable) else `uvm_error("AXI_L4", "B channel changed while BVALID waited for BREADY")
  property p_axi_r_id_stable; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.rvalid && !vif.rready |=> $stable(vif.rid); endproperty
  assert_p_axi_r_id_stable: assert property(p_axi_r_id_stable) else `uvm_error("AXI_L4", "RID changed while RVALID waited for RREADY")
  cover_p_axi_r_interleave: cover property(@(posedge vif.aclk) disable iff (!vif.aresetn) vif.rvalid && vif.rready && !vif.rlast ##[1:8] vif.rvalid && vif.rready && $changed(vif.rid));
  // L4-4: RDATA/RRESP held stable while RVALID waits for RREADY
  property p_axi_l4_r_payload_stable; @(posedge vif.aclk) disable iff (!vif.aresetn) vif.rvalid && !vif.rready |=> vif.rvalid && $stable({vif.rdata, vif.rresp}); endproperty
  assert_p_axi_l4_r_payload_stable: assert property(p_axi_l4_r_payload_stable) l4_pass[3]++; else begin `uvm_warning("AXI_L4", "R payload not stable during RVALID wait"); l4_fail[3]++; end
  cover_p_axi_l4_r_payload_stable: cover property(p_axi_l4_r_payload_stable);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("AXI_RPT", $sformatf("=== AXI Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("AXI_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("AXI_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("AXI_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("AXI_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("AXI_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end

endmodule

// ============================================================================
// axi_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the axi_compliance_checker_sva module above)
// ============================================================================
class axi_compliance_checker extends uvm_component;
  `uvm_component_utils(axi_compliance_checker)
  function new(string name="axi_compliance_checker", uvm_component parent=null);
    super.new(name, parent);
  endfunction
endclass

`endif