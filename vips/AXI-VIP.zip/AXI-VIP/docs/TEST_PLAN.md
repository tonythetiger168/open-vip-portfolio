# AXI Test Plan（AXI-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | AXI |
| 家族 | AMBA |
| 類型 | UVM VIP |
| 交付目錄 | `AXI-VIP/` |
| 目前 L1b 狀態 | PASS(functional) |

## 2. DUT / 待測對象

- `tb/top_tb.sv` 的 `amba_dut`：AXI4 slave（4 KB memory；寫、讀各 4 筆 outstanding；不同 ID 的 B / R 亂序、R beat 交錯；窄 / 非對齊 byte lane；error region、跨 4 KB、非法 WRAP / size 回 SLVERR）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | reset: no B / R, WREADY low | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | unwritten words (first and last of the 4 KB) read 0 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | 16-beat INCR write / read, OKAY, RLAST on the last beat | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | 256-beat INCR burst | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | WRAP bursts of 2, 4, 8, 16 beats wrap at the burst boundary | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | FIXED burst: every beat to the same address, the last one stays | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | 8 single-byte beats fill one word lane by lane | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | 2- and 4-byte narrow bursts, read back narrow and full width | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | unaligned 8-byte INCR: lanes 3-7 of the first beat, then aligned; byte 2 and word 2 untouched | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | unaligned 4-byte INCR: lanes 2-3, then 4-7, then 0-3 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | unaligned narrow FIXED burst: lane 5 only, every beat | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | WSTRB outside a narrow beat's lanes writes nothing | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | sparse random strobes | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | error-region write: SLVERR, aliased memory unchanged | 檢查成立，`FUNC_PASS` 輸出 |
| FS-15 | error-region read: SLVERR and zero data on every beat, RLAST | 檢查成立，`FUNC_PASS` 輸出 |
| FS-16 | INCR ending on the last byte of a 4 KB page: OKAY | 檢查成立，`FUNC_PASS` 輸出 |
| FS-17 | INCR crossing a 4 KB page: SLVERR, nothing written either side | 檢查成立，`FUNC_PASS` 輸出 |
| FS-18 | narrow INCR up to the page end: OKAY | 檢查成立，`FUNC_PASS` 輸出 |
| FS-19 | unaligned narrow INCR across the page: SLVERR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-20 | unaligned WRAP burst: SLVERR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-21 | 3-beat WRAP burst: SLVERR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-22 | 16-byte AxSIZE on a 64-bit bus: SLVERR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-23 | reserved burst type: SLVERR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-24 | illegal write burst answered SLVERR | 檢查成立，`FUNC_PASS` 輸出 |
| FS-25 | four writes outstanding; a fifth AW waits | 檢查成立，`FUNC_PASS` 輸出 |
| FS-26 | four reads outstanding; a fifth AR waits | 檢查成立，`FUNC_PASS` 輸出 |
| FS-27 | W waits while four B responses are not taken | 檢查成立，`FUNC_PASS` 輸出 |
| FS-28 | outstanding writes and reads on several IDs complete with the right data | 檢查成立，`FUNC_PASS` 輸出 |
| FS-29 | B responses overtake older writes of other IDs (N) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-30 | R beats of different IDs interleave (N) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-31 | four reads of one ID: beats returned in issue order | 檢查成立，`FUNC_PASS` 輸出 |
| FS-32 | four writes of one ID: B responses in issue order | 檢查成立，`FUNC_PASS` 輸出 |
| FS-33 | 150 random batches (narrow, unaligned, FIXED / INCR / WRAP, SLVERR) match the reference memory | 檢查成立，`FUNC_PASS` 輸出 |
| FS-34 | BVALID / RVALID and their payload held until READY | 檢查成立，`FUNC_PASS` 輸出 |
| FS-35 | AWREADY / ARREADY back-pressure seen | 檢查成立，`FUNC_PASS` 輸出 |
| FS-36 | reset drops B, R and WREADY | 檢查成立，`FUNC_PASS` 輸出 |
| FS-37 | after reset: memory contents kept, new bursts complete | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Agent reset and first-transaction bring-up |
| PT-02 | Exclusive access (AxLOCK, EXOKAY) and an exclusive monitor in the slave |
| PT-03 | AXI4 QoS / REGION / USER signals |
| PT-04 | Wider data buses (128 / 256 bits) |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/axi_compliance_checker.sv`（L1–L4，含 WSTRB lane、BID/RID、4 KB、WRAP 長度）、`vip/axi/axi_protocol_checker.sv`、`rtl/amba_vip_if.sv`
- Functional coverage：`vip/axi/axi_coverage.svh`（cg_protocol / cg_xfer / cg_order / cg_data）、`amba_cov`、`axi_protocol_checker_sva.cg_axi`

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/AXI-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py AXI-VIP && python3 smoke/smoke_run.py AXI-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 無特別備註。

---
*文件版本：v1.8.0*
