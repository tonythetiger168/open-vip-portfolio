// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AMBA VIP Package
// Protocols: AXI4/AXI4-Lite/AXI4-Stream, AHB5/APB4
//============================================================================
`ifndef AMBA_VIP_PKG_SV
`define AMBA_VIP_PKG_SV

// Tiered SVA compliance checker (L1/L2/L3/L4) and protocol checkers: the SVA
// content lives in modules (class-scope concurrent assertions are illegal per
// IEEE 1800); thin class shells remain. Included at compilation-unit scope,
// outside and before the package, so amba_env / top_tb can see them.
`include "sva/axi_compliance_checker.sv"
`include "ahb_protocol_checker.sv"
`include "apb_protocol_checker.sv"
`include "axi_protocol_checker.sv"

package amba_vip_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef enum int { AXI4=0, AXI4_LITE=1, AXI4_STREAM=2, AHB5=3, APB4=4, AMBA_MAX=5 } amba_protocol_e;
  typedef enum logic [1:0] { BURST_FIXED=2'b00, BURST_INCR=2'b01, BURST_WRAP=2'b10, BURST_RSVD=2'b11 } axburst_e;
  typedef enum logic [2:0] { SIZE_1B=3'b000, SIZE_2B=3'b001, SIZE_4B=3'b010, SIZE_8B=3'b011,
                             SIZE_16B=3'b100, SIZE_32B=3'b101, SIZE_64B=3'b110, SIZE_128B=3'b111 } axsize_e;
  typedef enum logic [1:0] { RESP_OKAY=2'b00, RESP_EXOKAY=2'b01, RESP_SLVERR=2'b10, RESP_DECERR=2'b11 } resp_e;
  typedef enum logic [2:0] { AHB_IDLE=3'b000, AHB_BUSY=3'b001, AHB_NONSEQ=3'b010, AHB_SEQ=3'b011 } htrans_e;

  class amba_txn extends uvm_object;
    `uvm_object_utils(amba_txn)
    rand amba_protocol_e protocol;
    rand logic [31:0]   addr;
    rand logic [63:0]   data[];
    rand int            len;
    rand axburst_e      burst;
    rand axsize_e       size;
    rand logic [3:0]    cache;
    rand logic [2:0]    prot;
    rand resp_e         resp;
    rand bit            excl;
    rand int            delay;
    rand bit            write;   // 1 = write, 0 = read
    rand logic [7:0]    id;      // AXI4 AWID / ARID: same-ID responses return in order
    logic [7:0]         strb[];  // AXI4 write strobes per beat (driver fills the beat's lanes when empty)
    rand bit            nb;      // AXI4: the driver may start the next item before this one completes
    bit                 done;    // AXI4 driver: response received
    // monitor annotations (AXI4)
    int unsigned        outst;   // bursts outstanding (both directions) when the address was accepted
    bit                 ooo;     // completed before an older outstanding burst
    bit                 ilv;     // read beats interleaved with another ID's beats
    int unsigned        nbeat;   // beats seen so far (driver / monitor bookkeeping)

    constraint c_len  { len inside {[1:16]}; }
    constraint c_data { data.size() == len; }
    constraint c_resp { resp dist { RESP_OKAY := 90, RESP_SLVERR := 10 }; }
    // Inter-transfer idle cycles. Unconstrained, a random int delay is up to
    // 2^31 clock cycles in "repeat (t.delay)" in the driver, so a randomized
    // sequence effectively never finishes.
    constraint c_delay { delay inside {[0:3]}; }
    // A legal AXI4 transfer on this VIP's 64-bit data bus (AMBA AXI IHI0022
    // A3.4): no reserved burst type, a size no wider than the bus, an address
    // aligned to the size, a WRAP burst of 2, 4, 8 or 16 beats, an INCR burst
    // that stays inside one 4 KB page, and AxCACHE[3:2] only on a modifiable
    // (AxCACHE[1]) transfer. Without it, randomized sequences tripped the
    // VIP's own protocol checkers.
    // INCR and FIXED bursts may start unaligned (the first beat then uses
    // only the lanes from the address up); a WRAP burst starts aligned.
    constraint c_axi_legal {
      protocol == AXI4 -> {
        burst != BURST_RSVD;
        size inside {SIZE_1B, SIZE_2B, SIZE_4B, SIZE_8B};
        id inside {[0:15]};
        (burst == BURST_WRAP && size == SIZE_2B) -> addr[0]   == 1'b0;
        (burst == BURST_WRAP && size == SIZE_4B) -> addr[1:0] == 2'b00;
        (burst == BURST_WRAP && size == SIZE_8B) -> addr[2:0] == 3'b000;
        (burst == BURST_WRAP) -> len inside {2, 4, 8, 16};
        (burst == BURST_FIXED) -> len <= 16;
        (burst == BURST_INCR) -> ({20'h0, addr[11:0]} + (len << size)) <= 32'h1000;
        !cache[1] -> cache[3:2] == 2'b00;
        excl == 1'b0;
      }
    }

    function new(string name = "amba_txn");
      super.new(name);
    endfunction

    virtual function string convert2string();
      return $sformatf("%s %s id=%0d addr=0x%08X len=%0d size=%0d burst=%s resp=%s",
                       protocol.name(), write ? "WR" : "RD", id, addr, len, 1 << size,
                       burst.name(), resp.name());
    endfunction

    // ---- AXI4 beat helpers (A3.4.1) ----
    // address of beat i
    function logic [31:0] beat_addr(int i);
      logic [31:0] nb, wsz, a;
      nb = 32'd1 << size;
      if (i == 0 || burst == BURST_FIXED) return addr;
      if (burst == BURST_WRAP) begin
        wsz = nb * len;
        a = addr;
        repeat (i) a = (a & ~(wsz - 1)) | ((a + nb) & (wsz - 1));
        return a;
      end
      return (addr & ~(nb - 1)) + i * nb;
    endfunction
    // byte lanes of beat i on the 64-bit bus
    function logic [7:0] beat_lanes(int i);
      logic [31:0] a;
      logic [7:0]  m;
      int nb;
      a = beat_addr(i);
      nb = 1 << size;
      m = 8'((9'd1 << nb) - 1) << (a[2:0] & ~3'(nb - 1));
      return m & ~((8'd1 << a[2:0]) - 8'd1);
    endfunction
    // the slave answers SLVERR (and ignores the burst): error region, an INCR
    // burst across a 4 KB page, an illegal WRAP, a size wider than the bus
    function bit slverr();
      logic [31:0] al;
      al = addr & ~((32'd1 << size) - 1);
      if (addr[31:24] == 8'hEE || size > SIZE_8B || burst == BURST_RSVD) return 1;
      if (burst == BURST_INCR && al[11:0] + (len << size) > 4096) return 1;
      if (burst == BURST_WRAP && (!(len inside {2, 4, 8, 16}) || al != addr)) return 1;
      return 0;
    endfunction
    // 4 KB memory words (addr[11:3]) a burst touches
    function void words(ref bit [511:0] m);
      for (int i = 0; i < len; i++) m[beat_addr(i) >> 3 & 9'h1FF] = 1'b1;
    endfunction
  endclass

  class amba_seq_item extends uvm_sequence_item;
    `uvm_object_utils(amba_seq_item)
    rand amba_txn txn;
    function new(string name = "amba_seq_item");
      super.new(name);
      txn = amba_txn::type_id::create("txn");
    endfunction
    virtual function string convert2string();
      return txn.convert2string();
    endfunction
  endclass

  class amba_cov extends uvm_subscriber #(amba_seq_item);
    `uvm_component_utils(amba_cov)
    amba_protocol_e protocol;
    axburst_e burst;
    axsize_e size;
    int len;
    resp_e resp;
    logic clk;
    covergroup cg_axi;
      option.per_instance = 1;
      // REACHABILITY: this environment's agent drives AXI4 only
      cp_prot: coverpoint protocol { bins axi4 = {AXI4};
                                     ignore_bins other = {AXI4_LITE, AXI4_STREAM, AHB5, APB4}; }
      cp_burst: coverpoint burst { bins fixed = {BURST_FIXED}; bins incr = {BURST_INCR}; bins wrap = {BURST_WRAP}; }
      // REACHABILITY: 64-bit data bus, so at most 8 bytes per transfer
      cp_size: coverpoint size { bins b1 = {SIZE_1B}; bins b2 = {SIZE_2B}; bins b4 = {SIZE_4B}; bins b8 = {SIZE_8B};
                                 ignore_bins wider_than_bus = {SIZE_16B, SIZE_32B, SIZE_64B, SIZE_128B}; }
      cp_len: coverpoint len { bins single = {1}; bins burst4 = {[2:4]}; bins burst8 = {[5:8]}; bins burst16 = {[9:16]}; }
      cp_resp: coverpoint resp { bins ok = {RESP_OKAY}; bins slv = {RESP_SLVERR};
                                 // REACHABILITY: RESP_EXOKAY / RESP_DECERR can never be observed in
                                 // this TB: AHB hresp and APB pslverr are 1-bit (OKAY/ERROR only) and
                                 // the AXI DUT model drives only OKAY/SLVERR on bresp/rresp.
                                 ignore_bins ex  = {RESP_EXOKAY};
                                 ignore_bins dec = {RESP_DECERR}; }
      cross_burst_len: cross cp_burst, cp_len {
        ignore_bins wrap_single = binsof(cp_burst.wrap) && binsof(cp_len.single); }
      cross_prot_size: cross cp_prot, cp_size;
    endgroup
    function new(string name = "amba_cov", uvm_component parent = null);
      super.new(name, parent);
      cg_axi = new();
    endfunction
    // uvm_subscriber write: sample observed (monitor-decoded) transactions
    function void write(amba_seq_item t);   // argument name must match uvm_subscriber::write
      sample(t.txn);
    endfunction
    function void sample(amba_txn t);
      protocol = t.protocol;
      burst    = t.burst;
      size     = t.size;
      len      = t.len;
      resp     = t.resp;
      cg_axi.sample();
    endfunction
    function real get_cov();
      return cg_axi.get_coverage();
    endfunction
  endclass

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard.
  //  * driver/monitor agreement: each completed burst the driver reports is
  //    matched with the monitor's burst of the same direction, ID, address
  //    and length (bursts complete out of order across IDs), comparing write
  //    data, strobes, read data and response;
  //  * reference memory: the monitor's bursts are replayed on a 4 KB byte
  //    model of the slave; every read beat is checked on its active byte
  //    lanes, every response against the slave's SLVERR rules.
  class amba_sb extends uvm_scoreboard;
    `uvm_component_utils(amba_sb)
    uvm_analysis_imp     #(amba_seq_item, amba_sb) analysis_imp;  // legacy counting port
    uvm_analysis_imp_exp #(amba_seq_item, amba_sb) exp_ap;
    uvm_analysis_imp_obs #(amba_seq_item, amba_sb) obs_ap;

    int txn_cnt, err_cnt;
    int unsigned n_matches = 0, n_mismatches = 0, n_ref_checks = 0;
    amba_seq_item exp_q[$], obs_q[$];
    logic [7:0] ref_mem [4096];

    function new(string name = "amba_sb", uvm_component parent = null);
      super.new(name, parent);
      analysis_imp = new("analysis_imp", this);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
      foreach (ref_mem[i]) ref_mem[i] = 8'h0;
    endfunction

    virtual function void write(amba_seq_item item);
      txn_cnt++;
      if (item.txn.resp inside {RESP_SLVERR, RESP_DECERR}) err_cnt++;
    endfunction

    virtual function void write_exp(amba_seq_item item);
      exp_q.push_back(item);
      check();
    endfunction

    virtual function void write_obs(amba_seq_item item);
      ref_check(item.txn);
      obs_q.push_back(item);
      check();
    endfunction

    function void bad(string what, amba_txn t);
      n_mismatches++;
      `uvm_error("SB", $sformatf("%s: %s", what, t.convert2string()))
    endfunction

    // the monitor's burst against the reference memory
    function void ref_check(amba_txn t);
      bit err;
      if (t.protocol != AXI4) return;
      err = t.slverr();
      n_ref_checks++;
      if (t.resp != (err ? RESP_SLVERR : RESP_OKAY)) bad($sformatf("response %s, expected %s", t.resp.name(), err ? "SLVERR" : "OKAY"), t);
      for (int i = 0; i < t.len && i < t.data.size(); i++) begin
        logic [7:0]  ln = t.beat_lanes(i);
        logic [11:0] w  = {t.beat_addr(i) >> 3, 3'b000};
        for (int b = 0; b < 8; b++) begin
          if (t.write) begin
            if (!err && ln[b] && t.strb.size() > i && t.strb[i][b]) ref_mem[w + b] = t.data[i][b*8 +: 8];
          end
          else if (err ? (t.data[i][b*8 +: 8] !== 8'h0) : (ln[b] && t.data[i][b*8 +: 8] !== ref_mem[w + b]))
            bad($sformatf("read beat %0d lane %0d = %02h, reference %02h", i, b, t.data[i][b*8 +: 8],
                          err ? 8'h0 : ref_mem[w + b]), t);
        end
      end
    endfunction

    // driver and monitor views of the same bursts
    virtual function void check();
      int k;
      do begin
        k = -1;
        foreach (obs_q[o]) begin
          foreach (exp_q[e])
            if (exp_q[e].txn.write == obs_q[o].txn.write && exp_q[e].txn.id == obs_q[o].txn.id &&
                exp_q[e].txn.addr == obs_q[o].txn.addr && exp_q[e].txn.len == obs_q[o].txn.len) begin
              k = e;
              break;
            end
          if (k >= 0) begin
            amba_txn e = exp_q[k].txn, ob = obs_q[o].txn;
            bit ok = (e.resp == ob.resp) && (e.data.size() == ob.data.size());
            if (ok) foreach (e.data[i])
              if (e.write ? (e.data[i] !== ob.data[i] || e.strb[i] !== ob.strb[i]) : (e.data[i] !== ob.data[i])) ok = 0;
            if (ok) n_matches++;
            else begin
              n_mismatches++;
              `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}", e.convert2string(), ob.convert2string()))
            end
            exp_q.delete(k);
            obs_q.delete(o);
            break;
          end
        end
      end while (k >= 0);
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed bursts left unmatched", exp_q.size(), obs_q.size()))
    endfunction

    virtual function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("TXN:%0d ERR:%0d", txn_cnt, err_cnt), UVM_LOW)
      `uvm_info("SB", $sformatf("amba scoreboard: n_matches=%0d n_ref_checks=%0d n_mismatches=%0d",
                n_matches, n_ref_checks, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  // Deepened AHB5 master UVC (sequencer/driver/monitor/agent/coverage/sequences)
  `include "axi_sequencer.svh"
  `include "axi_driver.svh"
  `include "axi_monitor.svh"
  `include "axi_agent.svh"
  `include "axi_coverage.svh"
  `include "axi_sequences.svh"

  // Tiered SVA compliance checker (L1/L2/L3/L4)
  `include "sva/axi_compliance_checker.sv"

  // UVM RAL adapter (register model frontdoor over this agent)
  `include "amba_reg_adapter.svh"
endpackage
`endif
