// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// amba_reg_adapter.svh -- UVM RAL adapter for the AMBA agents (APB4 / AHB5 /
// AXI4) that share amba_seq_item.
//   reg2bus: one uvm_reg_bus_op -> one single-beat amba_seq_item of `protocol`
//   bus2reg: amba_seq_item (driver-completed or monitor-observed) -> uvm_reg_bus_op
// The drivers complete the request item in place (read data and response are
// written back into item.txn) and send no separate response, so
// provides_responses = 0. The drivers always enable every byte lane, so byte
// enables are not supported. Set `protocol` and `bus_bytes` (4 for APB4, 8
// for the 64-bit AHB5 / AXI4 data bus) before the map is used.

`ifndef AMBA_REG_ADAPTER_SVH
`define AMBA_REG_ADAPTER_SVH

class amba_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(amba_reg_adapter)
  amba_protocol_e protocol  = APB4;
  int unsigned    bus_bytes = 4;

  function new(string name = "amba_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 0;
  endfunction

  function uvm_reg_data_t bus_mask();
    return (bus_bytes >= 8) ? 64'hFFFF_FFFF_FFFF_FFFF : ((64'h1 << (bus_bytes * 8)) - 1);
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    amba_seq_item item = amba_seq_item::type_id::create("ral_item");
    item.txn.protocol = protocol;
    item.txn.addr     = rw.addr[31:0];
    item.txn.write    = (rw.kind == UVM_WRITE);
    item.txn.len      = 1;
    item.txn.data     = new[1];
    item.txn.data[0]  = (rw.kind == UVM_WRITE) ? 64'(rw.data & bus_mask()) : 64'h0;
    item.txn.size     = (bus_bytes >= 8) ? SIZE_8B : SIZE_4B;
    item.txn.burst    = BURST_INCR;
    item.txn.cache    = 4'h0;
    item.txn.prot     = 3'b000;
    item.txn.resp     = RESP_OKAY;
    item.txn.excl     = 1'b0;
    item.txn.delay    = 0;
    return item;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    amba_seq_item item;
    if (!$cast(item, bus_item)) begin
      `uvm_fatal("AMBA_RAL", "bus2reg: item is not an amba_seq_item")
      return;
    end
    rw.kind    = item.txn.write ? UVM_WRITE : UVM_READ;
    rw.addr    = item.txn.addr;
    rw.data    = (item.txn.data.size() > 0) ? (uvm_reg_data_t'(item.txn.data[0]) & bus_mask()) : '0;
    rw.n_bits  = bus_bytes * 8;
    rw.byte_en = '1;
    rw.status  = (item.txn.resp inside {RESP_OKAY, RESP_EXOKAY}) ? UVM_IS_OK : UVM_NOT_OK;
  endfunction
endclass
`endif
