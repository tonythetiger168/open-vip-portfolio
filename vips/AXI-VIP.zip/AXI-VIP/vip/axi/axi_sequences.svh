// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// axi_sequences.svh -- AXI4 sequence library:
//   base / single / incr burst / wrap burst / back-to-back /
//   error-inject (SLVERR region) / reset / stress / regression mix

`ifndef AXI_SEQUENCES_SVH
`define AXI_SEQUENCES_SVH

class axi_base_sequence extends uvm_sequence #(amba_seq_item);
  `uvm_object_utils(axi_base_sequence)
  int num_txns = 20;
  function new(string name = "axi_base_sequence");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AXI4;
                                    txn.addr[2:0] == 3'b000;
                                    txn.addr[31:24] != 8'hEE;
                                    txn.size == SIZE_8B; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: single-beat transfers
class axi_single_seq extends axi_base_sequence;
  `uvm_object_utils(axi_single_seq)
  function new(string name = "axi_single_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AXI4; txn.len == 1;
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: INCR bursts (4/8/16 beats)
class axi_incr_burst_seq extends axi_base_sequence;
  `uvm_object_utils(axi_incr_burst_seq)
  function new(string name = "axi_incr_burst_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AXI4;
                                    txn.burst == BURST_INCR;
                                    txn.len inside {4, 8, 16};
                                    txn.addr[3:0] == 4'h0;
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: WRAP bursts (cache-line corner case)
class axi_wrap_burst_seq extends axi_base_sequence;
  `uvm_object_utils(axi_wrap_burst_seq)
  function new(string name = "axi_wrap_burst_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AXI4;
                                    txn.burst == BURST_WRAP;
                                    txn.len inside {2, 4, 8, 16};
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Directed: back-to-back transfers with zero gap
class axi_back_to_back_seq extends axi_base_sequence;
  `uvm_object_utils(axi_back_to_back_seq)
  function new(string name = "axi_back_to_back_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AXI4;
                                    txn.len inside {[1:2]};
                                    txn.delay == 0;
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Error injection: SLVERR region (0xEE00_0000)
class axi_error_inject_seq extends axi_base_sequence;
  `uvm_object_utils(axi_error_inject_seq)
  function new(string name = "axi_error_inject_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AXI4;
                                    txn.addr[31:24] == 8'hEE;
                                    txn.len == 1; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Reset behavior: transfer right after reset release
class axi_reset_seq extends axi_base_sequence;
  `uvm_object_utils(axi_reset_seq)
  function new(string name = "axi_reset_seq");
    super.new(name);
  endfunction
  task body();
    amba_seq_item item = amba_seq_item::type_id::create("item");
    start_item(item);
    if (!(item.randomize() with { txn.protocol == AXI4; txn.len == 1;
                                  txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
    finish_item(item);
  endtask
endclass

// Stress: high-volume random bursts
class axi_stress_seq extends axi_base_sequence;
  `uvm_object_utils(axi_stress_seq)
  function new(string name = "axi_stress_seq");
    super.new(name);
    num_txns = 100;
  endfunction
  task body();
    amba_seq_item item;
    repeat (num_txns) begin
      item = amba_seq_item::type_id::create("item");
      start_item(item);
      if (!(item.randomize() with { txn.protocol == AXI4;
                                    txn.len inside {[4:16]};
                                    txn.addr[31:24] != 8'hEE; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    end
  endtask
endclass

// Coverage sweep: every legal (direction, burst, size, length) of this
// 64-bit bus once, AxCACHE cycling through device / normal, data cycling
// through the corner patterns, each write read back at once; then num_txns
// random legal transfers. A write and its read-back go back to back.
class axi_cov_sweep_seq extends axi_base_sequence;
  `uvm_object_utils(axi_cov_sweep_seq)
  // No randomize(): every field is set directly ($urandom for the random
  // part), so the sequence runs on simulators that cannot solve the nested
  // amba_txn constraints (Verilator).
  function new(string name = "axi_cov_sweep_seq");
    super.new(name);
    num_txns = 100;
  endfunction
  function logic [63:0] pattern(int n);
    case (n % 5)
      0: return 64'h0;
      1: return 64'hFFFF_FFFF_FFFF_FFFF;
      2: return 64'hAAAA_AAAA_AAAA_AAAA;
      3: return 64'h5555_5555_5555_5555;
      default: return {$urandom, $urandom};
    endcase
  endfunction
  task send(axburst_e b, axsize_e s, int l, bit wr, logic [3:0] c, int n, logic [31:0] a,
            logic [2:0] p = 3'b000, int dly = 0);
    amba_seq_item item = amba_seq_item::type_id::create("item");
    start_item(item);
    item.txn.protocol = AXI4;  item.txn.burst = b;  item.txn.size = s;
    item.txn.len      = l;     item.txn.write = wr; item.txn.cache = c;
    item.txn.addr     = a;     item.txn.prot  = p;  item.txn.resp  = RESP_OKAY;
    item.txn.excl     = 1'b0;  item.txn.delay = dly;
    item.txn.data     = new[l];
    foreach (item.txn.data[i]) item.txn.data[i] = pattern(n + i);
    finish_item(item);
  endtask
  task body();
    axburst_e bursts[3] = '{BURST_FIXED, BURST_INCR, BURST_WRAP};
    axsize_e  sizes[4]  = '{SIZE_1B, SIZE_2B, SIZE_4B, SIZE_8B};
    int       lens[7]   = '{1, 2, 3, 4, 8, 12, 16};
    int       wlens[4]  = '{2, 4, 8, 16};
    logic [3:0] caches[4] = '{4'b0000, 4'b0001, 4'b0010, 4'b1111};
    int n = 0;
    foreach (bursts[b]) foreach (sizes[s]) foreach (lens[l]) begin
      logic [31:0] a;
      if (bursts[b] == BURST_WRAP && !(lens[l] inside {2, 4, 8, 16})) continue;
      // aligned to the whole burst, so INCR stays in its 4 KB page
      a = (n * 256) % 4096;
      send(bursts[b], sizes[s], lens[l], 1, caches[n % 4], n, a);
      send(bursts[b], sizes[s], lens[l], 0, caches[n % 4], n, a);
      n++;
    end
    // random legal traffic (AXI4: aligned, WRAP 2/4/8/16, INCR inside 4 KB)
    repeat (num_txns) begin
      axburst_e    rb = bursts[$urandom_range(2)];
      int unsigned rs = $urandom_range(3);
      int          rl = (rb == BURST_WRAP) ? wlens[$urandom_range(3)] : $urandom_range(16, 1);
      int unsigned span = (rb == BURST_INCR) ? (rl << rs) : (1 << rs);
      logic [31:0] ra = ($urandom & 32'h00FF_F000) |
                        (($urandom_range(4096 - span) >> rs) << rs);
      send(rb, sizes[rs], rl, $urandom_range(1), caches[$urandom_range(3)], n++, ra,
           $urandom_range(7), $urandom_range(3));
    end
  endtask
endclass

// Random sequence (compatibility name)
class axi_random_sequence extends axi_base_sequence;
  `uvm_object_utils(axi_random_sequence)
  function new(string name = "axi_random_sequence");
    super.new(name);
    num_txns = 50;
  endfunction
endclass

// Regression: weighted mix of all directed sequences
class axi_regression_sequence extends axi_base_sequence;
  `uvm_object_utils(axi_regression_sequence)
  function new(string name = "axi_regression_sequence");
    super.new(name);
  endfunction
  task body();
    axi_single_seq       sgl = axi_single_seq::type_id::create("sgl");
    axi_incr_burst_seq   inc = axi_incr_burst_seq::type_id::create("inc");
    axi_wrap_burst_seq   wrp = axi_wrap_burst_seq::type_id::create("wrp");
    axi_back_to_back_seq b2b = axi_back_to_back_seq::type_id::create("b2b");
    axi_error_inject_seq err = axi_error_inject_seq::type_id::create("err");
    axi_stress_seq       str = axi_stress_seq::type_id::create("str");
    sgl.num_txns = 20; inc.num_txns = 15; wrp.num_txns = 10;
    b2b.num_txns = 20; err.num_txns = 5;  str.num_txns = 40;
    sgl.start(m_sequencer); inc.start(m_sequencer);
    wrp.start(m_sequencer); b2b.start(m_sequencer);
    err.start(m_sequencer); str.start(m_sequencer);
  endtask
endclass
`endif
