// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// axi_coverage.svh -- AXI4 functional coverage:
//   cg_protocol : burst config (dir x burst x size x len, resp) + crosses
//   cg_fsm      : channel handshake state transitions
//   cg_data     : data pattern corners x direction

`ifndef AXI_COVERAGE_SVH
`define AXI_COVERAGE_SVH

class axi_coverage extends uvm_subscriber #(amba_seq_item);
  `uvm_component_utils(axi_coverage)

  amba_seq_item tr;
  bit unal, narrow, page_end, sparse;

  covergroup cg_protocol;
    option.per_instance = 1;
    cp_write: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cp_burst: coverpoint tr.txn.burst { bins fixed = {BURST_FIXED};
                                        bins incr  = {BURST_INCR};
                                        bins wrap  = {BURST_WRAP}; }
    cp_size: coverpoint tr.txn.size { bins b1 = {SIZE_1B}; bins b2 = {SIZE_2B};
                                      bins b4 = {SIZE_4B}; bins b8 = {SIZE_8B}; }
    cp_len: coverpoint tr.txn.len { bins single = {1}; bins b2 = {2}; bins b4 = {4};
                                    bins b8 = {8}; bins b16 = {16}; bins other = {[3:3], [5:7], [9:15]};
                                    bins long_ = {[17:256]}; }
    cp_resp: coverpoint tr.txn.resp { bins ok = {RESP_OKAY}; bins slv = {RESP_SLVERR}; }
    cx_wr_burst: cross cp_write, cp_burst;
    // a WRAP burst has 2, 4, 8 or 16 beats; a FIXED burst at most 16
    cx_burst_len: cross cp_burst, cp_len {
      ignore_bins wrap_other = binsof(cp_burst.wrap) && (binsof(cp_len.single) || binsof(cp_len.other) || binsof(cp_len.long_));
      ignore_bins fixed_long = binsof(cp_burst.fixed) && binsof(cp_len.long_); }
    cx_wr_size_len: cross cp_write, cp_size, cp_len;
  endgroup

  // narrow / unaligned transfers, strobes, the 4 KB page
  covergroup cg_xfer;
    option.per_instance = 1;
    cp_write: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cp_unal: coverpoint unal { bins aligned = {0}; bins unaligned = {1}; }
    cp_narrow: coverpoint narrow { bins full = {0}; bins narrow = {1}; }
    cp_size: coverpoint tr.txn.size { bins b1 = {SIZE_1B}; bins b2 = {SIZE_2B}; bins b4 = {SIZE_4B}; bins b8 = {SIZE_8B}; }
    cp_page_end: coverpoint page_end { bins inside_ = {0}; bins last_byte = {1}; }
    cp_sparse: coverpoint sparse iff (tr.txn.write) { bins full = {0}; bins partial = {1}; }
    // REACHABILITY: a 1-byte transfer is always aligned
    cx_unal_size: cross cp_unal, cp_size { ignore_bins b1_unal = binsof(cp_unal.unaligned) && binsof(cp_size.b1); }
    cx_wr_unal_burst: cross cp_write, cp_unal, cp_narrow;
  endgroup

  // IDs, outstanding bursts, out-of-order completion, read interleaving
  covergroup cg_order;
    option.per_instance = 1;
    cp_write: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cp_id: coverpoint tr.txn.id { bins id[4] = {[0:15]}; }
    cp_outst: coverpoint tr.txn.outst { bins none = {0}; bins one = {1}; bins two_three = {[2:3]}; bins four_plus = {[4:$]}; }
    cp_ooo: coverpoint tr.txn.ooo { bins in_order = {0}; bins out_of_order = {1}; }
    cp_ilv: coverpoint tr.txn.ilv iff (!tr.txn.write) { bins alone = {0}; bins interleaved = {1}; }
    cx_wr_outst: cross cp_write, cp_outst;
    cx_wr_ooo: cross cp_write, cp_ooo;
  endgroup

  covergroup cg_data;
    option.per_instance = 1;
    cp_data: coverpoint tr.txn.data[0] iff (tr.txn.data.size() > 0) {
      bins zero = {64'h0};
      bins ones = {64'hFFFF_FFFF_FFFF_FFFF};
      bins aa55 = {64'hAAAA_AAAA_AAAA_AAAA, 64'h5555_5555_5555_5555};
      bins other = default;
    }
    cp_w: coverpoint tr.txn.write { bins rd = {0}; bins wr = {1}; }
    cx_wr_data: cross cp_data, cp_w;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_xfer     = new();
    cg_order    = new();
    cg_data     = new();
  endfunction

  function void write(amba_seq_item t);
    logic [31:0] last;
    tr = t;
    unal   = (t.txn.addr & ((32'd1 << t.txn.size) - 1)) != 0;
    narrow = t.txn.size < SIZE_8B;
    last   = t.txn.beat_addr(t.txn.len - 1) | ((32'd1 << t.txn.size) - 1);
    page_end = t.txn.burst == BURST_INCR && last[11:0] == 12'hFFF;
    sparse = 0;
    foreach (t.txn.strb[i]) if (t.txn.strb[i] != t.txn.beat_lanes(i)) sparse = 1;
    cg_protocol.sample();
    if (t.txn.resp == RESP_OKAY) cg_xfer.sample();
    cg_order.sample();
    cg_data.sample();
  endfunction
endclass
`endif
