// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AXI4 master driver: the five channels run as separate threads, so several
// bursts can be outstanding, responses can come back in any order across
// IDs, and read beats of different IDs can interleave.
//   * an item with txn.nb = 0 (the default, e.g. register accesses) is
//     completed before item_done; nb = 1 lets the next item start at once
//   * up to max_outstanding bursts per direction are in flight
//   * a burst waits while an outstanding burst touches the same memory words
//     and one of the two is a write: AXI4 gives no ordering between the read
//     and write channels, or between write IDs, so a master must not depend
//     on it (A5.3)
//   * W beats follow the AW order; each beat's WSTRB is limited to the byte
//     lanes of its address (narrow and unaligned transfers, A3.4.3)
//   * B and R are matched to the oldest outstanding burst of their ID; the
//     completed item goes to drv_ap in completion order
//   * BREADY / RREADY and WVALID gaps are randomised (bp_pct)
//============================================================================
`ifndef AXI_DRIVER_SVH
`define AXI_DRIVER_SVH

class axi_driver extends uvm_driver #(amba_seq_item);
  `uvm_component_utils(axi_driver)
  virtual amba_vip_if vif;
  uvm_analysis_port #(amba_seq_item) drv_ap;  // expected items for scoreboard

  int unsigned max_outstanding = 4;   // per direction
  int unsigned bp_pct          = 25;  // percent of clocks with BREADY / RREADY low, WVALID gaps
  int unsigned timeout_cycles  = 2000;

  protected amba_seq_item aw_q[$], w_q[$], b_q[$], ar_q[$], r_q[$];   // per channel, oldest first
  protected amba_seq_item outst[$];                                  // all bursts in flight

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "AXI virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    amba_seq_item item;
    idle();
    wait (vif.aresetn === 1'b1);
    fork
      aw_thread();
      w_thread();
      b_thread();
      ar_thread();
      r_thread();
    join_none
    forever begin
      seq_item_port.get_next_item(item);
      `uvm_info("DRV", {"drive: ", item.convert2string()}, UVM_HIGH)
      prepare(item.txn);
      while (n_dir(item.txn.write) >= max_outstanding || hazard(item.txn)) @(vif.drv_cb);
      item.txn.done = 0;
      outst.push_back(item);
      if (item.txn.write) aw_q.push_back(item);
      else                ar_q.push_back(item);
      if (!item.txn.nb) wait (item.txn.done);
      seq_item_port.item_done();
    end
  endtask

  task idle();
    vif.drv_cb.awvalid <= 1'b0;
    vif.drv_cb.wvalid  <= 1'b0;
    vif.drv_cb.wlast   <= 1'b0;
    vif.drv_cb.bready  <= 1'b0;
    vif.drv_cb.arvalid <= 1'b0;
    vif.drv_cb.rready  <= 1'b0;
    vif.drv_cb.awlock  <= 1'b0;
    vif.drv_cb.arlock  <= 1'b0;
    vif.drv_cb.awid    <= 8'h0;
    vif.drv_cb.arid    <= 8'h0;
  endtask

  // write strobes: the requested ones (all when none given) on the beat's lanes
  function void prepare(amba_txn t);
    logic [7:0] s[];
    s = new[t.len];
    foreach (s[i]) s[i] = ((t.strb.size() > i) ? t.strb[i] : 8'hFF) & t.beat_lanes(i);
    t.strb = s;
    if (t.data.size() != t.len) t.data = new[t.len](t.data);
  endfunction

  function int unsigned n_dir(bit wr);
    n_dir = 0;
    foreach (outst[i]) if (outst[i].txn.write == wr) n_dir++;
  endfunction

  function bit hazard(amba_txn t);
    bit [511:0] m, o;
    m = '0;
    t.words(m);
    foreach (outst[i]) if (t.write || outst[i].txn.write) begin
      o = '0;
      outst[i].txn.words(o);
      if ((m & o) != '0) return 1;
    end
    return 0;
  endfunction

  function void complete(amba_seq_item item);
    foreach (outst[i]) if (outst[i] == item) begin outst.delete(i); break; end
    item.txn.done = 1;
    drv_ap.write(item);
  endfunction

  // oldest burst in q with this ID (responses of one ID come back in order)
  function int oldest(ref amba_seq_item q[$], input logic [7:0] id);
    foreach (q[i]) if (q[i].txn.id == id) return i;
    return -1;
  endfunction

  task aw_thread();
    forever begin
      amba_seq_item item;
      amba_txn t;
      while (aw_q.size() == 0) @(vif.drv_cb);
      item = aw_q.pop_front();
      t = item.txn;
      repeat (t.delay) @(vif.drv_cb);
      vif.drv_cb.awid    <= t.id;
      vif.drv_cb.awaddr  <= t.addr;
      vif.drv_cb.awlen   <= t.len - 1;
      vif.drv_cb.awsize  <= t.size;
      vif.drv_cb.awburst <= t.burst;
      vif.drv_cb.awcache <= t.cache;
      vif.drv_cb.awprot  <= t.prot;
      vif.drv_cb.awvalid <= 1'b1;
      do @(vif.drv_cb); while (vif.drv_cb.awready !== 1'b1);
      vif.drv_cb.awvalid <= 1'b0;
      w_q.push_back(item);
      b_q.push_back(item);
    end
  endtask

  task w_thread();
    forever begin
      amba_txn t;
      while (w_q.size() == 0) @(vif.drv_cb);
      t = w_q[0].txn;
      for (int i = 0; i < t.len; i++) begin
        while ($urandom_range(99) < bp_pct) begin vif.drv_cb.wvalid <= 1'b0; @(vif.drv_cb); end
        vif.drv_cb.wdata  <= t.data[i];
        vif.drv_cb.wstrb  <= t.strb[i];
        vif.drv_cb.wlast  <= (i == t.len - 1);
        vif.drv_cb.wvalid <= 1'b1;
        do @(vif.drv_cb); while (vif.drv_cb.wready !== 1'b1);
      end
      vif.drv_cb.wvalid <= 1'b0;
      vif.drv_cb.wlast  <= 1'b0;
      void'(w_q.pop_front());
    end
  endtask

  task b_thread();
    forever begin
      bit rdy = ($urandom_range(99) >= bp_pct);
      vif.drv_cb.bready <= rdy;
      @(vif.drv_cb);
      if (vif.drv_cb.bvalid === 1'b1 && rdy) begin
        int k = oldest(b_q, vif.drv_cb.bid);
        if (k < 0) `uvm_error("DRV", $sformatf("B response with BID %0d and no write outstanding", vif.drv_cb.bid))
        else begin
          amba_seq_item item = b_q[k];
          b_q.delete(k);
          item.txn.resp = resp_e'(vif.drv_cb.bresp);
          complete(item);
        end
      end
    end
  endtask

  task ar_thread();
    forever begin
      amba_seq_item item;
      amba_txn t;
      while (ar_q.size() == 0) @(vif.drv_cb);
      item = ar_q.pop_front();
      t = item.txn;
      repeat (t.delay) @(vif.drv_cb);
      vif.drv_cb.arid    <= t.id;
      vif.drv_cb.araddr  <= t.addr;
      vif.drv_cb.arlen   <= t.len - 1;
      vif.drv_cb.arsize  <= t.size;
      vif.drv_cb.arburst <= t.burst;
      vif.drv_cb.arvalid <= 1'b1;
      do @(vif.drv_cb); while (vif.drv_cb.arready !== 1'b1);
      vif.drv_cb.arvalid <= 1'b0;
      t.resp = RESP_OKAY;
      t.nbeat = 0;
      r_q.push_back(item);
    end
  endtask

  task r_thread();
    forever begin
      bit rdy = ($urandom_range(99) >= bp_pct);
      vif.drv_cb.rready <= rdy;
      @(vif.drv_cb);
      if (vif.drv_cb.rvalid === 1'b1 && rdy) begin
        int k = oldest(r_q, vif.drv_cb.rid);
        if (k < 0) `uvm_error("DRV", $sformatf("R beat with RID %0d and no read outstanding", vif.drv_cb.rid))
        else begin
          amba_seq_item item = r_q[k];
          amba_txn t = item.txn;
          int unsigned n = t.nbeat;
          if (n < t.len) t.data[n] = vif.drv_cb.rdata;
          if (vif.drv_cb.rresp != 2'b00 && t.resp == RESP_OKAY) t.resp = resp_e'(vif.drv_cb.rresp);
          t.nbeat = n + 1;
          if ((vif.drv_cb.rlast === 1'b1) != (n + 1 == t.len))
            `uvm_error("DRV", $sformatf("RLAST on beat %0d of a %0d-beat read", n + 1, t.len))
          if (vif.drv_cb.rlast === 1'b1) begin
            r_q.delete(k);
            complete(item);
          end
        end
      end
    end
  endtask
endclass
`endif
