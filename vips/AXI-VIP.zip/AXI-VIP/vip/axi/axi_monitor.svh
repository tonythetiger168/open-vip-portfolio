// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// axi_monitor.svh -- AXI4 monitor: tracks the 5 handshake channels and
// reconstructs write/read burst transactions, published via analysis port.

`ifndef AXI_MONITOR_SVH
`define AXI_MONITOR_SVH

class axi_monitor extends uvm_monitor;
  `uvm_component_utils(axi_monitor)
  virtual amba_vip_if vif;
  uvm_analysis_port #(amba_seq_item) ap;
  int unsigned txn_count = 0;
  int unsigned n_ooo = 0, n_ilv = 0;

  // bursts in flight, oldest first
  protected amba_seq_item w_q[$];    // AW accepted, W beats still coming (W follows the AW order)
  protected amba_seq_item b_q[$];    // AW accepted, waiting for B
  protected amba_seq_item r_q[$];    // AR accepted, waiting for RLAST
  protected amba_seq_item all_q[$];  // every burst in flight, in address-acceptance order
  protected logic [7:0]   last_rid;
  protected bit           last_r_open;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual amba_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "AXI virtual interface not set")
  endfunction

  function int oldest(ref amba_seq_item q[$], input logic [7:0] id);
    foreach (q[i]) if (q[i].txn.id == id) return i;
    return -1;
  endfunction

  function void finish(amba_seq_item item);
    // out of order: an older burst is still in flight
    if (all_q.size() && all_q[0] != item) begin item.txn.ooo = 1; n_ooo++; end
    foreach (all_q[i]) if (all_q[i] == item) begin all_q.delete(i); break; end
    txn_count++;
    `uvm_info("MON", {"mon: ", item.convert2string()}, UVM_HIGH)
    ap.write(item);
  endfunction

  function amba_seq_item open_burst(bit wr, logic [7:0] id, logic [31:0] a, logic [7:0] len,
                                    logic [2:0] size, logic [1:0] burst);
    amba_seq_item item = amba_seq_item::type_id::create(wr ? "wr_item" : "rd_item");
    item.txn.protocol = AXI4;
    item.txn.write = wr;
    item.txn.id    = id;
    item.txn.addr  = a;
    item.txn.len   = int'(len) + 1;
    item.txn.size  = axsize_e'(size);
    item.txn.burst = axburst_e'(burst);
    item.txn.resp  = RESP_OKAY;
    item.txn.data  = new[item.txn.len];
    item.txn.strb  = new[wr ? item.txn.len : 0];
    item.txn.nbeat = 0;
    item.txn.outst = all_q.size();
    all_q.push_back(item);
    return item;
  endfunction

  task run_phase(uvm_phase phase);
    forever begin
      @(vif.mon_cb);
      if (vif.aresetn !== 1'b1) begin
        w_q.delete(); b_q.delete(); r_q.delete(); all_q.delete(); last_r_open = 0;
        continue;
      end

      // ---- AW: open a write burst ----
      if (vif.mon_cb.awvalid && vif.mon_cb.awready) begin
        amba_seq_item item = open_burst(1, vif.mon_cb.awid, vif.mon_cb.awaddr, vif.mon_cb.awlen,
                                        vif.mon_cb.awsize, vif.mon_cb.awburst);
        item.txn.cache = vif.mon_cb.awcache;
        item.txn.prot  = vif.mon_cb.awprot;
        w_q.push_back(item);
        b_q.push_back(item);
      end

      // ---- W: beats of the oldest write still taking data ----
      if (vif.mon_cb.wvalid && vif.mon_cb.wready) begin
        if (w_q.size() == 0) `uvm_error("MON", "W beat accepted with no write address outstanding")
        else begin
          amba_txn t = w_q[0].txn;
          if (t.nbeat < t.len) begin
            t.data[t.nbeat] = vif.mon_cb.wdata;
            t.strb[t.nbeat] = vif.mon_cb.wstrb;
          end
          t.nbeat++;
          if (vif.mon_cb.wlast) begin
            if (t.nbeat != t.len) `uvm_error("MON", $sformatf("WLAST on beat %0d of a %0d-beat write", t.nbeat, t.len))
            void'(w_q.pop_front());
          end
        end
      end

      // ---- B: oldest write of that ID ----
      if (vif.mon_cb.bvalid && vif.mon_cb.bready) begin
        int k = oldest(b_q, vif.mon_cb.bid);
        if (k < 0) `uvm_error("MON", $sformatf("B with BID %0d and no write outstanding", vif.mon_cb.bid))
        else begin
          amba_seq_item item = b_q[k];
          b_q.delete(k);
          item.txn.resp = resp_e'(vif.mon_cb.bresp);
          finish(item);
        end
      end

      // ---- AR: open a read burst ----
      if (vif.mon_cb.arvalid && vif.mon_cb.arready)
        r_q.push_back(open_burst(0, vif.mon_cb.arid, vif.mon_cb.araddr, vif.mon_cb.arlen,
                                 vif.mon_cb.arsize, vif.mon_cb.arburst));

      // ---- R: beat of the oldest read of that ID ----
      if (vif.mon_cb.rvalid && vif.mon_cb.rready) begin
        int k = oldest(r_q, vif.mon_cb.rid);
        if (k < 0) `uvm_error("MON", $sformatf("R beat with RID %0d and no read outstanding", vif.mon_cb.rid))
        else begin
          amba_seq_item item = r_q[k];
          amba_txn t = item.txn;
          // interleaving: this beat follows an unfinished burst of another ID
          if (last_r_open && last_rid != vif.mon_cb.rid) begin
            foreach (r_q[i]) if (r_q[i].txn.id == last_rid && r_q[i].txn.nbeat != 0) r_q[i].txn.ilv = 1;
            t.ilv = 1;
            n_ilv++;
          end
          if (t.nbeat < t.len) t.data[t.nbeat] = vif.mon_cb.rdata;
          if (vif.mon_cb.rresp != 2'b00 && t.resp == RESP_OKAY) t.resp = resp_e'(vif.mon_cb.rresp);
          t.nbeat++;
          last_rid = vif.mon_cb.rid;
          last_r_open = !vif.mon_cb.rlast;
          if (vif.mon_cb.rlast) begin
            if (t.nbeat != t.len) `uvm_error("MON", $sformatf("RLAST on beat %0d of a %0d-beat read", t.nbeat, t.len))
            r_q.delete(k);
            finish(item);
          end
        end
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("AXI monitor observed %0d transactions (%0d out of order, %0d interleaved read beats)",
              txn_count, n_ooo, n_ilv), UVM_LOW)
  endfunction
endclass
`endif
