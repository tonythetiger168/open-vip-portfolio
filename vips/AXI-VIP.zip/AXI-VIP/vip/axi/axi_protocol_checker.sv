// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AXI Protocol Checker
//============================================================================
`ifndef AXI_PROTOCOL_CHECKER_SV
`define AXI_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================================
// axi_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module axi_protocol_checker_sva (amba_vip_if vif);

  int aw_err, w_err, b_err, ar_err, r_err;

  initial begin
    aw_err = 0; w_err = 0; b_err = 0; ar_err = 0; r_err = 0;
  end

  // AW channel: burst must be valid
  property p_axi_awburst;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.awvalid) |-> vif.awburst inside {2'b00, 2'b01, 2'b10};
  endproperty
  assert_axi_awburst: assert property (p_axi_awburst)
  else begin
    `uvm_error("AXI_CHK", "Invalid AWBURST");
    aw_err++;
  end

  // W channel: WLAST marks beat AWLEN+1. Write bursts may be outstanding;
  // their W beats follow the AW order, so AWLEN is kept in a FIFO.
  logic [7:0] wl_len [0:15];
  logic [3:0] wl_rp, wl_wp;
  logic [4:0] wl_cnt;
  logic [7:0] wl_beat;
  wire        wl_known = (wl_cnt != 5'd0) || (vif.awvalid && vif.awready);
  wire  [7:0] wl_awlen = (wl_cnt != 5'd0) ? wl_len[wl_rp] : vif.awlen;
  wire        wl_pop   = vif.wvalid && vif.wready && wl_known && vif.wlast;
  always @(posedge vif.aclk or negedge vif.aresetn)
    if (!vif.aresetn) begin
      wl_rp <= 4'h0; wl_wp <= 4'h0; wl_cnt <= 5'd0; wl_beat <= 8'h0;
    end
    else begin
      if (vif.awvalid && vif.awready) begin wl_len[wl_wp] <= vif.awlen; wl_wp <= wl_wp + 4'h1; end
      if (wl_pop) wl_rp <= wl_rp + 4'h1;
      wl_cnt <= wl_cnt + 5'(vif.awvalid && vif.awready) - 5'(wl_pop);
      if (vif.wvalid && vif.wready && wl_known) wl_beat <= vif.wlast ? 8'h0 : wl_beat + 8'h1;
    end
  property p_axi_wlast;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.wvalid && vif.wready && wl_known) |-> (vif.wlast == (wl_beat == wl_awlen));
  endproperty
  assert_axi_wlast: assert property (p_axi_wlast)
  else begin
    `uvm_error("AXI_CHK", "WLAST misaligned");
    w_err++;
  end

  // B channel: the response is accepted within 16 clocks
  property p_axi_bvalid;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.bvalid) |-> ##[0:16] vif.bready;
  endproperty
  assert_axi_bvalid: assert property (p_axi_bvalid)
  else begin
    `uvm_error("AXI_CHK", "BVALID timeout");
    b_err++;
  end

  // AR channel: a WRAP burst address is aligned to its size (INCR and
  // FIXED bursts may start unaligned)
  property p_axi_aralign;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.arvalid && vif.arburst == 2'b10) |-> (vif.araddr & ((32'h1 << vif.arsize) - 32'h1)) == 32'h0;
  endproperty
  assert_axi_aralign: assert property (p_axi_aralign)
  else begin
    `uvm_error("AXI_CHK", "ARADDR of a WRAP burst misaligned");
    ar_err++;
  end

  // R channel: RRESP valid on last beat
  property p_axi_rlast;
    @(posedge vif.aclk) disable iff (!vif.aresetn)
      (vif.rvalid && vif.rlast) |-> !$isunknown(vif.rresp);
  endproperty
  assert_axi_rlast: assert property (p_axi_rlast)
  else begin
    `uvm_error("AXI_CHK", "RRESP invalid");
    r_err++;
  end

  // Coverage
  covergroup cg_axi @(posedge vif.aclk);
    option.per_instance = 1;
    // sampled on the handshake of each channel
    cp_awburst: coverpoint vif.awburst iff (vif.awvalid && vif.awready) { bins fixed = {2'b00}; bins incr = {2'b01}; bins wrap = {2'b10}; }
    // REACHABILITY: the data bus is 64 bits, so a transfer is at most 8 bytes
    // (AxSIZE <= 3'b011); wider sizes are protocol errors the checkers report.
    cp_awsize: coverpoint vif.awsize iff (vif.awvalid && vif.awready) { bins b1 = {3'b000}; bins b2 = {3'b001}; bins b4 = {3'b010}; bins b8 = {3'b011};
                                       ignore_bins wider_than_bus = {[3'b100:3'b111]}; }
    cp_awlen: coverpoint vif.awlen iff (vif.awvalid && vif.awready) { bins single = {8'h00}; bins burst4 = {[8'h01:8'h03]};
                                     bins burst8 = {[8'h04:8'h07]}; bins burst16 = {[8'h08:8'h0F]}; bins long_ = {[8'h10:8'hFF]}; }
    cp_awcache: coverpoint vif.awcache iff (vif.awvalid && vif.awready) { bins dev_nc = {4'b0000}; bins dev_buf = {4'b0001};
                                         bins normal_nc = {4'b0010}; bins normal_wb = {4'b1111}; }
    cp_awunal: coverpoint (vif.awaddr[2:0] & ((3'd1 << vif.awsize) - 3'd1)) != 3'd0 iff (vif.awvalid && vif.awready) { bins aligned = {0}; bins unaligned = {1}; }
    // REACHABILITY: no exclusive accesses (EXOKAY) and the TB slave answers
    // only OKAY / SLVERR (no decoder, so no DECERR).
    cp_bresp: coverpoint vif.bresp iff (vif.bvalid && vif.bready) { bins ok = {2'b00}; bins slv = {2'b10};
                                     ignore_bins ex = {2'b01}; ignore_bins dec = {2'b11}; }
    cp_arburst: coverpoint vif.arburst iff (vif.arvalid && vif.arready) { bins fixed = {2'b00}; bins incr = {2'b01}; bins wrap = {2'b10}; }
    cp_arsize: coverpoint vif.arsize iff (vif.arvalid && vif.arready) { bins b1 = {3'b000}; bins b2 = {3'b001}; bins b4 = {3'b010}; bins b8 = {3'b011};
                                       ignore_bins wider_than_bus = {[3'b100:3'b111]}; }
    cp_rresp: coverpoint vif.rresp iff (vif.rvalid && vif.rready) { bins ok = {2'b00}; bins slv = {2'b10};
                                     ignore_bins ex = {2'b01}; ignore_bins dec = {2'b11}; }
    cp_wstrb: coverpoint vif.wstrb iff (vif.wvalid && vif.wready) { bins full = {8'hFF}; bins none = {8'h00}; bins one = {8'h01, 8'h02, 8'h04, 8'h08, 8'h10, 8'h20, 8'h40, 8'h80};
                                     bins other = default; }
    // a WRAP burst has 2, 4, 8 or 16 beats, never one or more than 16
    cross_aw: cross cp_awburst, cp_awsize, cp_awlen {
      ignore_bins wrap_single = binsof(cp_awburst.wrap) && binsof(cp_awlen.single);
      ignore_bins wrap_long   = binsof(cp_awburst.wrap) && binsof(cp_awlen.long_);
      // a FIXED burst has at most 16 beats (A3.4.1)
      ignore_bins fixed_long  = binsof(cp_awburst.fixed) && binsof(cp_awlen.long_); }
    cross_ar: cross cp_arburst, cp_arsize;
  endgroup

  cg_axi cg;

  initial begin
    cg = new();
  end

  final begin
    `uvm_info("AXI_RPT", $sformatf("AXI Chk | AW:%0d W:%0d B:%0d AR:%0d R:%0d",
              aw_err, w_err, b_err, ar_err, r_err), UVM_LOW)
  end
endmodule

// ============================================================================
// axi_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the axi_protocol_checker_sva module above)
// ============================================================================
class axi_protocol_checker extends uvm_component;
  `uvm_component_utils(axi_protocol_checker)
  function new(string name = "axi_chk", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
