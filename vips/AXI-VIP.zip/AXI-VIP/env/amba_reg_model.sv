// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//============================================================================
// UVM RAL model of the top_tb AXI4 slave (amba_dut, tb/top_tb.sv): a
// 512 x 64-bit word memory on the 64-bit data bus.
//   0x0000..0x0038  REG[0..7]  64-bit RW, reset 0 (low words modelled as
//                              registers so hw_reset / bit_bash cover them)
//   0x0040..0x0FF8  MEM        504 x 64-bit RW memory (uvm_mem_walk_seq)
//   0xEE000000      ERR_PROBE  error region (BRESP/RRESP=SLVERR); excluded from the
//                              built-in sequences, used to check that an
//                              error response reaches the RAL as UVM_NOT_OK
// The DUT decodes only addr[11:3] (plus the error region), so higher
// addresses alias; the model maps only one copy.
//============================================================================
`ifndef AMBA_REG_MODEL_SV
`define AMBA_REG_MODEL_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class amba_data_reg extends uvm_reg;
  `uvm_object_utils(amba_data_reg)
  rand uvm_reg_field DATA;

  function new(string name = "amba_data_reg");
    super.new(name, 64, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    DATA = uvm_reg_field::type_id::create("DATA");
    //            parent size lsb access volatile reset has_reset rand individually_accessible
    DATA.configure(this, 64,  0,  "RW",  0,       64'h0, 1,        1,   1);
  endfunction
endclass

class amba_reg_block extends uvm_reg_block;
  `uvm_object_utils(amba_reg_block)
  localparam int N_REGS = 8;
  localparam int N_WORDS = 512;
  rand amba_data_reg REG[N_REGS];
  uvm_mem            MEM;
  amba_data_reg      ERR_PROBE;
  uvm_reg_map        axi_map;

  function new(string name = "amba_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    axi_map = create_map("axi_map", 'h0, 8, UVM_LITTLE_ENDIAN, 1);
    default_map = axi_map;
    foreach (REG[i]) begin
      REG[i] = amba_data_reg::type_id::create($sformatf("REG%0d", i));
      REG[i].configure(this, null, "");
      REG[i].build();
      axi_map.add_reg(REG[i], i * 8, "RW");
    end
    MEM = new("MEM", N_WORDS - N_REGS, 64, "RW", UVM_NO_COVERAGE);
    MEM.configure(this, "");
    axi_map.add_mem(MEM, N_REGS * 8, "RW");
    ERR_PROBE = amba_data_reg::type_id::create("ERR_PROBE");
    ERR_PROBE.configure(this, null, "");
    ERR_PROBE.build();
    axi_map.add_reg(ERR_PROBE, 'hEE00_0000, "RW");
    uvm_resource_db#(bit)::set({"REG::", ERR_PROBE.get_full_name()}, "NO_REG_TESTS", 1, this);
  endfunction
endclass
`endif
