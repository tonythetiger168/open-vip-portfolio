// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2025 Functional smoke testbench (AXI 5-channel write/read)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened AXI slave amba_dut.
// DUT behaviour (from dut_amba_dut.sv):
//   - 512-entry x 64-bit memory, indexed by addr[11:3]
//   - AW always ready; W accepted while a write burst is active;
//     B asserted after WLAST (SLVERR if awaddr[31:24]==0xEE, write dropped)
//   - AR ready when no read burst active; R valid during burst,
//     RLAST on final beat (SLVERR + zero data if araddr[31:24]==0xEE)
//   - INCR bursts advance address by 8 per beat; WSTRB per-byte enables

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        vif_aclk    = 1'b0;
  logic        vif_aresetn = 1'b0;
  logic [31:0] vif_awaddr  = 32'h0;
  logic [7:0]  vif_awlen   = 8'h0;
  logic [1:0]  vif_awburst = 2'b01;
  logic        vif_awvalid = 1'b0;
  wire         vif_awready;
  logic [63:0] vif_wdata   = 64'h0;
  logic [7:0]  vif_wstrb   = 8'h0;
  logic        vif_wlast   = 1'b0;
  logic        vif_wvalid  = 1'b0;
  wire         vif_wready;
  wire [1:0]   vif_bresp;
  wire         vif_bvalid;
  logic        vif_bready  = 1'b0;
  logic [31:0] vif_araddr  = 32'h0;
  logic [7:0]  vif_arlen   = 8'h0;
  logic [1:0]  vif_arburst = 2'b01;
  logic        vif_arvalid = 1'b0;
  wire         vif_arready;
  wire [63:0]  vif_rdata;
  wire [1:0]   vif_rresp;
  wire         vif_rlast;
  wire         vif_rvalid;
  logic        vif_rready  = 1'b0;
  // unused sibling-protocol outputs of the shared amba_dut shell
  wire         vif_tready, vif_hreadyout, vif_hresp, vif_pready, vif_pslverr;
  wire [63:0]  vif_hrdata;
  wire [31:0]  vif_prdata;

  always #5 vif_aclk = ~vif_aclk;

  amba_dut u_dut (
    .vif_aclk(vif_aclk), .vif_aresetn(vif_aresetn),
    .vif_awaddr(vif_awaddr), .vif_awlen(vif_awlen),
    .vif_awburst(vif_awburst), .vif_awvalid(vif_awvalid),
    .vif_awready(vif_awready),
    .vif_wdata(vif_wdata), .vif_wstrb(vif_wstrb),
    .vif_wlast(vif_wlast), .vif_wvalid(vif_wvalid),
    .vif_wready(vif_wready),
    .vif_bresp(vif_bresp), .vif_bvalid(vif_bvalid),
    .vif_bready(vif_bready),
    .vif_araddr(vif_araddr), .vif_arlen(vif_arlen),
    .vif_arburst(vif_arburst), .vif_arvalid(vif_arvalid),
    .vif_arready(vif_arready),
    .vif_rdata(vif_rdata), .vif_rresp(vif_rresp),
    .vif_rlast(vif_rlast), .vif_rvalid(vif_rvalid),
    .vif_rready(vif_rready),
    .vif_tready(vif_tready), .vif_hrdata(vif_hrdata),
    .vif_hreadyout(vif_hreadyout), .vif_hresp(vif_hresp),
    .vif_prdata(vif_prdata), .vif_pready(vif_pready),
    .vif_pslverr(vif_pslverr)
  );

  task automatic chk(input bit cond, input string name);
    begin
      checks++;
      if (!cond) begin
        fails++;
        $display("  [FAIL] %s", name);
      end
    end
  endtask

  // full AXI write burst (INCR), returns bresp
  task automatic axi_write(input [31:0] addr, input [63:0] d0,
                           input [63:0] d1, input [7:0] strb,
                           output [1:0] bresp_o);
    begin
      @(negedge vif_aclk);
      vif_awaddr = addr; vif_awlen = 8'd1; vif_awburst = 2'b01;
      vif_awvalid = 1'b1;
      @(negedge vif_aclk);                 // AW accepted (awready=1)
      vif_awvalid = 1'b0;
      chk(vif_wready === 1'b1, "wready high once write burst active");
      vif_wdata = d0; vif_wstrb = strb; vif_wlast = 1'b0; vif_wvalid = 1'b1;
      @(negedge vif_aclk);                 // beat 0 accepted
      vif_wdata = d1; vif_wlast = 1'b1;
      @(negedge vif_aclk);                 // beat 1 (wlast) accepted
      vif_wvalid = 1'b0; vif_wlast = 1'b0; vif_wstrb = 8'h0;
      chk(vif_bvalid === 1'b1, "bvalid asserted after WLAST");
      bresp_o = vif_bresp;
      vif_bready = 1'b1;
      @(negedge vif_aclk);                 // B handshake
      vif_bready = 1'b0;
      chk(vif_bvalid === 1'b0, "bvalid cleared after B handshake");
    end
  endtask

  // full AXI read burst of 2 beats (INCR)
  task automatic axi_read2(input [31:0] addr, output [63:0] d0,
                           output [63:0] d1);
    begin
      @(negedge vif_aclk);
      vif_araddr = addr; vif_arlen = 8'd1; vif_arburst = 2'b01;
      vif_arvalid = 1'b1; vif_rready = 1'b1;
      @(negedge vif_aclk);                 // AR accepted
      vif_arvalid = 1'b0;
      chk(vif_rvalid === 1'b1, "rvalid high during read burst");
      chk(vif_rresp === 2'b00, "rresp OKAY on good region");
      chk(vif_rlast === 1'b0, "rlast low on first beat");
      d0 = vif_rdata;
      @(negedge vif_aclk);                 // beat 0 consumed
      chk(vif_rlast === 1'b1, "rlast high on final beat");
      d1 = vif_rdata;
      @(negedge vif_aclk);                 // beat 1 consumed, burst done
      vif_rready = 1'b0;
      chk(vif_rvalid === 1'b0, "rvalid low after burst completes");
    end
  endtask

  localparam [63:0] D0 = 64'h1122_3344_5566_7788;
  localparam [63:0] D1 = 64'h99AA_BBCC_DDEE_FF00;
  localparam [63:0] D2 = 64'hA5A5_A5A5_5A5A_5A5A;
  reg [63:0] r0, r1;
  reg [1:0] br;

  initial begin
    repeat (4) @(posedge vif_aclk);
    @(negedge vif_aclk);
    vif_aresetn = 1'b1;
    @(negedge vif_aclk);
    chk(vif_awready === 1'b1, "awready high (always-ready AW)");
    chk(vif_arready === 1'b1, "arready high when no read burst");

    // 2-beat INCR write at 0x40 then read-back data compare
    axi_write(32'h0000_0040, D0, D1, 8'hFF, br);
    chk(br === 2'b00, "bresp OKAY on good write");
    axi_read2(32'h0000_0040, r0, r1);
    chk(r0 === D0, "read beat 0 equals written data");
    chk(r1 === D1, "read beat 1 equals written data");

    // partial strobes: only upper 4 bytes of first beat written
    axi_write(32'h0000_0080, D2, 64'h0, 8'hF0, br);
    axi_read2(32'h0000_0080, r0, r1);
    chk(r0 === 64'hA5A5_A5A5_0000_0000, "wstrb masks unenabled byte lanes");

    // error region write -> SLVERR, memory untouched
    axi_write(32'hEE00_0100, 64'hFFFF_FFFF_FFFF_FFFF, 64'h0, 8'hFF, br);
    chk(br === 2'b10, "bresp SLVERR on error region write");

    // error region read -> SLVERR + zero data
    @(negedge vif_aclk);
    vif_araddr = 32'hEE00_0100; vif_arlen = 8'd0; vif_arburst = 2'b01;
    vif_arvalid = 1'b1; vif_rready = 1'b1;
    @(negedge vif_aclk);
    vif_arvalid = 1'b0;
    chk(vif_rresp === 2'b10, "rresp SLVERR on error region read");
    chk(vif_rdata === 64'h0, "error region read returns zero data");
    chk(vif_rlast === 1'b1, "single-beat error read has rlast");
    @(negedge vif_aclk);
    vif_rready = 1'b0;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  // safety timeout (well below 100us budget)
  initial begin
    #80000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
