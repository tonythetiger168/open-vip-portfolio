// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened AXI4 slave amba_dut
// (tb/top_tb.sv): up to 4 write and 4 read bursts outstanding, B / R out of
// order across IDs and in order within an ID, read interleaving, narrow and
// unaligned transfers, SLVERR for the error region, 4 KB crossings, illegal
// WRAP bursts and sizes wider than the bus.
//
// The master here runs batches of bursts: every channel is its own process
// (AW, W, B, AR, R), all addresses of a batch are issued as fast as the
// slave accepts them, and the bursts of a batch never touch the same memory
// word when one of them is a write, so the reference memory below predicts
// every read beat whatever order the slave picks.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic        vif_aclk    = 1'b0;
  logic        vif_aresetn = 1'b0;
  logic [7:0]  vif_awid    = 8'h0;
  logic [31:0] vif_awaddr  = 32'h0;
  logic [7:0]  vif_awlen   = 8'h0;
  logic [2:0]  vif_awsize  = 3'd3;
  logic [1:0]  vif_awburst = 2'b01;
  logic        vif_awvalid = 1'b0;
  wire         vif_awready;
  logic [63:0] vif_wdata   = 64'h0;
  logic [7:0]  vif_wstrb   = 8'h0;
  logic        vif_wvalid  = 1'b0;
  wire         vif_wready;
  wire [7:0]   vif_bid;
  wire [1:0]   vif_bresp;
  wire         vif_bvalid;
  logic        vif_bready  = 1'b0;
  logic [7:0]  vif_arid    = 8'h0;
  logic [31:0] vif_araddr  = 32'h0;
  logic [7:0]  vif_arlen   = 8'h0;
  logic [2:0]  vif_arsize  = 3'd3;
  logic [1:0]  vif_arburst = 2'b01;
  logic        vif_arvalid = 1'b0;
  wire         vif_arready;
  wire [7:0]   vif_rid;
  wire [63:0]  vif_rdata;
  wire [1:0]   vif_rresp;
  wire         vif_rlast;
  wire         vif_rvalid;
  logic        vif_rready  = 1'b0;
  // unused sibling-protocol outputs of the shared amba_dut shell
  wire         vif_tready, vif_hreadyout, vif_hresp, vif_pready, vif_pslverr;
  wire [63:0]  vif_hrdata;
  wire [31:0]  vif_prdata;

  always #5 vif_aclk = ~vif_aclk;

  amba_dut u_dut (
    .vif_aclk(vif_aclk), .vif_aresetn(vif_aresetn),
    .vif_awid(vif_awid), .vif_awaddr(vif_awaddr), .vif_awlen(vif_awlen), .vif_awsize(vif_awsize),
    .vif_awburst(vif_awburst), .vif_awvalid(vif_awvalid), .vif_awready(vif_awready),
    .vif_wdata(vif_wdata), .vif_wstrb(vif_wstrb), .vif_wvalid(vif_wvalid), .vif_wready(vif_wready),
    .vif_bid(vif_bid), .vif_bresp(vif_bresp), .vif_bvalid(vif_bvalid), .vif_bready(vif_bready),
    .vif_arid(vif_arid), .vif_araddr(vif_araddr), .vif_arlen(vif_arlen), .vif_arsize(vif_arsize),
    .vif_arburst(vif_arburst), .vif_arvalid(vif_arvalid), .vif_arready(vif_arready),
    .vif_rid(vif_rid), .vif_rdata(vif_rdata), .vif_rresp(vif_rresp), .vif_rlast(vif_rlast),
    .vif_rvalid(vif_rvalid), .vif_rready(vif_rready),
    .vif_tready(vif_tready), .vif_hrdata(vif_hrdata), .vif_hreadyout(vif_hreadyout), .vif_hresp(vif_hresp),
    .vif_prdata(vif_prdata), .vif_pready(vif_pready), .vif_pslverr(vif_pslverr)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // ------------------------------------------------------------------ model
  logic [7:0] ref_mem [0:4095];
  initial for (int i = 0; i < 4096; i++) ref_mem[i] = 8'h0;

  function automatic logic [31:0] baddr(input logic [31:0] a, input logic [2:0] sz, input logic [1:0] bt,
                                        input int len, input int i);
    logic [31:0] nb, wsz, x;
    nb = 32'd1 << sz;
    if (i == 0 || bt == 2'b00) return a;
    if (bt == 2'b10) begin
      wsz = nb * len;
      x = a;
      for (int k = 0; k < i; k++) x = (x & ~(wsz - 1)) | ((x + nb) & (wsz - 1));
      return x;
    end
    return (a & ~(nb - 1)) + i * nb;
  endfunction
  function automatic logic [7:0] blanes(input logic [31:0] a, input logic [2:0] sz);
    logic [7:0] m;
    int nb;
    nb = 1 << sz;
    m = 8'((9'd1 << nb) - 1) << (a[2:0] & ~3'(nb - 1));
    return m & ~((8'd1 << a[2:0]) - 8'd1);
  endfunction
  function automatic bit berr(input logic [31:0] a, input logic [2:0] sz, input logic [1:0] bt, input int len);
    logic [31:0] al;
    al = a & ~((32'd1 << sz) - 1);
    if (a[31:24] == 8'hEE || sz > 3 || bt == 2'b11) return 1;
    if (bt == 2'b01 && al[11:0] + (len << sz) > 4096) return 1;
    if (bt == 2'b10 && (!(len == 2 || len == 4 || len == 8 || len == 16) || al != a)) return 1;
    return 0;
  endfunction

  // ------------------------------------------------------------------ batch
  localparam int MB = 8;      // bursts per direction in a batch
  localparam int ML = 256;    // beats per burst
  int          nw, nr;
  logic [31:0] w_a [MB];  logic [2:0] w_s [MB]; logic [1:0] w_b [MB]; int w_l [MB]; logic [7:0] w_id [MB];
  logic [63:0] w_d [MB][ML]; logic [7:0] w_st [MB][ML];
  logic [1:0]  w_resp [MB]; bit w_done [MB]; int w_aw_order [MB];
  logic [31:0] r_a [MB];  logic [2:0] r_s [MB]; logic [1:0] r_b [MB]; int r_l [MB]; logic [7:0] r_id [MB];
  logic [63:0] r_d [MB][ML]; logic [1:0] r_rs [MB][ML]; int r_n [MB]; bit r_lastok [MB];
  int          b_order [MB];     // write index of each B, in arrival order
  int          nb_got, rl_got, w_gap_pct = 0, ready_pct = 100;
  int          n_ooo = 0, n_ilv = 0, n_unexp = 0;
  int          aw_wait = 0, ar_wait = 0;

  task automatic clear_batch();
    nw = 0; nr = 0;
  endtask
  task automatic add_w(input logic [7:0] id, input logic [31:0] a, input int len, input logic [2:0] sz,
                       input logic [1:0] bt, input int seed, input bit rstrb = 0);
    w_id[nw] = id; w_a[nw] = a; w_l[nw] = len; w_s[nw] = sz; w_b[nw] = bt;
    for (int i = 0; i < len; i++) begin
      w_d[nw][i]  = {$random(seed), $random(seed)};
      w_st[nw][i] = rstrb ? 8'($random(seed)) : blanes(baddr(a, sz, bt, len, i), sz);
    end
    nw++;
  endtask
  task automatic add_r(input logic [7:0] id, input logic [31:0] a, input int len, input logic [2:0] sz,
                       input logic [1:0] bt);
    r_id[nr] = id; r_a[nr] = a; r_l[nr] = len; r_s[nr] = sz; r_b[nr] = bt;
    nr++;
  endtask

  task automatic run_batch();
    for (int i = 0; i < MB; i++) begin w_done[i] = 0; r_n[i] = 0; r_lastok[i] = 1; end
    nb_got = 0; rl_got = 0;
    fork
      begin : aw_ch
        for (int i = 0; i < nw; i++) begin
          @(negedge vif_aclk);
          vif_awid = w_id[i]; vif_awaddr = w_a[i]; vif_awlen = 8'(w_l[i] - 1); vif_awsize = w_s[i];
          vif_awburst = w_b[i]; vif_awvalid = 1'b1;
          @(posedge vif_aclk);
          while (!vif_awready) begin aw_wait++; @(posedge vif_aclk); end
        end
        @(negedge vif_aclk); vif_awvalid = 1'b0;
      end
      begin : w_ch
        for (int i = 0; i < nw; i++)
          for (int k = 0; k < w_l[i]; k++) begin
            @(negedge vif_aclk);
            vif_wvalid = 1'b0;
            while ($urandom_range(99) < w_gap_pct) @(negedge vif_aclk);
            vif_wdata = w_d[i][k]; vif_wstrb = w_st[i][k]; vif_wvalid = 1'b1;
            @(posedge vif_aclk);
            while (!vif_wready) @(posedge vif_aclk);
          end
        @(negedge vif_aclk); vif_wvalid = 1'b0;
      end
      begin : b_ch
        while (nb_got < nw) begin
          @(negedge vif_aclk);
          vif_bready = ($urandom_range(99) < ready_pct);
          @(posedge vif_aclk);
          if (vif_bvalid && vif_bready) begin
            int k;
            k = -1;
            for (int i = nw - 1; i >= 0; i--) if (!w_done[i] && w_id[i] == vif_bid) k = i;
            if (k < 0) n_unexp++;
            else begin
              for (int i = 0; i < k; i++) if (!w_done[i]) begin n_ooo++; break; end
              w_done[k] = 1; w_resp[k] = vif_bresp; b_order[nb_got] = k;
            end
            nb_got++;
          end
        end
        @(negedge vif_aclk); vif_bready = 1'b0;
      end
      begin : ar_ch
        for (int i = 0; i < nr; i++) begin
          @(negedge vif_aclk);
          vif_arid = r_id[i]; vif_araddr = r_a[i]; vif_arlen = 8'(r_l[i] - 1); vif_arsize = r_s[i];
          vif_arburst = r_b[i]; vif_arvalid = 1'b1;
          @(posedge vif_aclk);
          while (!vif_arready) begin ar_wait++; @(posedge vif_aclk); end
        end
        @(negedge vif_aclk); vif_arvalid = 1'b0;
      end
      begin : r_ch
        int last_k;
        last_k = -1;
        while (rl_got < nr) begin
          @(negedge vif_aclk);
          vif_rready = ($urandom_range(99) < ready_pct);
          @(posedge vif_aclk);
          if (vif_rvalid && vif_rready) begin
            int k;
            k = -1;
            for (int i = nr - 1; i >= 0; i--) if (r_n[i] < r_l[i] && r_id[i] == vif_rid) k = i;
            if (k < 0) begin n_unexp++; rl_got++; end
            else begin
              if (last_k >= 0 && last_k != k && r_n[last_k] != 0 && r_n[last_k] < r_l[last_k]) n_ilv++;
              r_d[k][r_n[k]] = vif_rdata; r_rs[k][r_n[k]] = vif_rresp;
              r_n[k]++;
              if (vif_rlast != (r_n[k] == r_l[k])) r_lastok[k] = 0;
              if (vif_rlast) rl_got++;
              last_k = k;
            end
          end
        end
        @(negedge vif_aclk); vif_rready = 1'b0;
      end
    join
  endtask

  // check the batch against the reference memory, then apply its writes
  int bad_w, bad_r, bad_last;
  task automatic check_batch();
    bad_w = 0; bad_r = 0; bad_last = 0;
    for (int i = 0; i < nr; i++) begin
      bit e;
      e = berr(r_a[i], r_s[i], r_b[i], r_l[i]);
      if (!r_lastok[i] || r_n[i] != r_l[i]) bad_last++;
      for (int k = 0; k < r_l[i]; k++) begin
        logic [31:0] a;
        logic [7:0] ln;
        a = baddr(r_a[i], r_s[i], r_b[i], r_l[i], k);
        ln = blanes(a, r_s[i]);
        if (r_rs[i][k] != (e ? 2'b10 : 2'b00)) bad_r++;
        for (int b = 0; b < 8; b++)
          if (e ? (r_d[i][k][b*8 +: 8] !== 8'h0) : (ln[b] && r_d[i][k][b*8 +: 8] !== ref_mem[{a[11:3], 3'b000} + b])) bad_r++;
      end
    end
    for (int i = 0; i < nw; i++) begin
      bit e;
      e = berr(w_a[i], w_s[i], w_b[i], w_l[i]);
      if (!w_done[i] || w_resp[i] != (e ? 2'b10 : 2'b00)) bad_w++;
      if (!e)
        for (int k = 0; k < w_l[i]; k++) begin
          logic [31:0] a;
          logic [7:0] ln;
          a = baddr(w_a[i], w_s[i], w_b[i], w_l[i], k);
          ln = blanes(a, w_s[i]) & w_st[i][k];
          for (int b = 0; b < 8; b++)
            if (ln[b]) ref_mem[{a[11:3], 3'b000} + b] = w_d[i][k][b*8 +: 8];
        end
    end
  endtask

  // one burst on its own
  task automatic wr1(input logic [7:0] id, input logic [31:0] a, input int len, input logic [2:0] sz,
                     input logic [1:0] bt, input int seed, input bit rstrb = 0);
    clear_batch(); add_w(id, a, len, sz, bt, seed, rstrb); run_batch(); check_batch();
  endtask
  task automatic rd1(input logic [7:0] id, input logic [31:0] a, input int len, input logic [2:0] sz,
                     input logic [1:0] bt);
    clear_batch(); add_r(id, a, len, sz, bt); run_batch(); check_batch();
  endtask

  // does a candidate burst share a memory word with a write of the batch
  // (or, for a write, with any burst of the batch)
  function automatic bit clash(input logic [31:0] a, input int len, input logic [2:0] sz, input logic [1:0] bt,
                               input bit wr);
    bit [511:0] m, o;
    m = '0; o = '0;
    for (int k = 0; k < len; k++) m[baddr(a, sz, bt, len, k) >> 3 & 32'h1FF] = 1'b1;
    for (int i = 0; i < nw; i++)
      for (int j = 0; j < w_l[i]; j++) o[baddr(w_a[i], w_s[i], w_b[i], w_l[i], j) >> 3 & 32'h1FF] = 1'b1;
    if (wr)
      for (int i = 0; i < nr; i++)
        for (int j = 0; j < r_l[i]; j++) o[baddr(r_a[i], r_s[i], r_b[i], r_l[i], j) >> 3 & 32'h1FF] = 1'b1;
    clash = (m & o) != '0;
  endfunction

  // response channels hold their payload until READY
  int b_unstable = 0, r_unstable = 0;
  logic       pb_wait, pr_wait;
  logic [9:0] pb;
  logic [74:0] pr;
  always @(posedge vif_aclk) begin
    if (pb_wait && !(vif_bvalid && {vif_bid, vif_bresp} == pb)) b_unstable++;
    if (pr_wait && !(vif_rvalid && {vif_rid, vif_rdata, vif_rresp, vif_rlast} == pr)) r_unstable++;
    pb_wait = vif_aresetn && vif_bvalid && !vif_bready; pb = {vif_bid, vif_bresp};
    pr_wait = vif_aresetn && vif_rvalid && !vif_rready; pr = {vif_rid, vif_rdata, vif_rresp, vif_rlast};
  end

  // ------------------------------------------------------------------ tests
  initial begin
    int seed, cnt, ok, aw_full, rlen, tries;
    logic [31:0] ra; logic [2:0] rsz; logic [1:0] rbt; bit rwr;
    seed = 7;
    repeat (3) @(posedge vif_aclk);
    chk(vif_bvalid === 1'b0 && vif_rvalid === 1'b0 && vif_wready === 1'b0, "reset: no B / R, WREADY low");
    @(negedge vif_aclk); vif_aresetn = 1'b1;
    repeat (2) @(negedge vif_aclk);

    // ---- single bursts ----
    rd1(1, 32'h0000_0000, 1, 3, 2'b01);
    rd1(1, 32'h0000_0FF8, 1, 3, 2'b01);
    chk(bad_r == 0 && bad_last == 0, "unwritten words (first and last of the 4 KB) read 0");
    wr1(2, 32'h0000_0100, 16, 3, 2'b01, 1); rd1(2, 32'h0000_0100, 16, 3, 2'b01);
    chk(bad_w == 0 && bad_r == 0 && bad_last == 0, "16-beat INCR write / read, OKAY, RLAST on the last beat");
    wr1(3, 32'h0000_0200, 256, 3, 2'b01, 2); rd1(3, 32'h0000_0200, 256, 3, 2'b01);
    chk(bad_w == 0 && bad_r == 0 && bad_last == 0, "256-beat INCR burst");
    ok = 1;
    for (int l = 2; l <= 16; l *= 2) begin
      wr1(4, 32'h0000_0A00 + 8 * (l / 2), l, 3, 2'b10, l); rd1(4, 32'h0000_0A00, 32, 3, 2'b01);
      if (bad_w || bad_r) ok = 0;
      rd1(4, 32'h0000_0A00 + 8 * (l / 2) + 8, l, 3, 2'b10);
      if (bad_r || bad_last) ok = 0;
    end
    chk(ok == 1, "WRAP bursts of 2, 4, 8, 16 beats wrap at the burst boundary");
    wr1(5, 32'h0000_0C08, 4, 3, 2'b00, 3); rd1(5, 32'h0000_0C00, 4, 3, 2'b01);
    chk(bad_w == 0 && bad_r == 0 && ref_mem[12'hC08] == w_d[0][3][7:0], "FIXED burst: every beat to the same address, the last one stays");

    // ---- narrow and unaligned ----
    wr1(6, 32'h0000_0D00, 8, 0, 2'b01, 4); rd1(6, 32'h0000_0D00, 1, 3, 2'b01);
    chk(bad_w == 0 && bad_r == 0, "8 single-byte beats fill one word lane by lane");
    wr1(6, 32'h0000_0D08, 4, 1, 2'b01, 5); wr1(6, 32'h0000_0D10, 2, 2, 2'b01, 6);
    rd1(6, 32'h0000_0D08, 2, 3, 2'b01); rd1(6, 32'h0000_0D08, 8, 1, 2'b01);
    chk(bad_w == 0 && bad_r == 0, "2- and 4-byte narrow bursts, read back narrow and full width");
    wr1(7, 32'h0000_0E00, 2, 3, 2'b01, 30); wr1(7, 32'h0000_0E10, 2, 3, 2'b01, 31);
    wr1(7, 32'h0000_0E03, 2, 3, 2'b01, 8);
    rd1(7, 32'h0000_0E00, 3, 3, 2'b01);
    chk(bad_r == 0, "unaligned 8-byte INCR: lanes 3-7 of the first beat, then aligned; byte 2 and word 2 untouched");
    wr1(7, 32'h0000_0E22, 3, 2, 2'b01, 9); rd1(7, 32'h0000_0E20, 2, 3, 2'b01); rd1(7, 32'h0000_0E21, 3, 2, 2'b01);
    chk(bad_w == 0 && bad_r == 0, "unaligned 4-byte INCR: lanes 2-3, then 4-7, then 0-3");
    wr1(7, 32'h0000_0E35, 3, 1, 2'b00, 10); rd1(7, 32'h0000_0E30, 1, 3, 2'b01);
    chk(bad_w == 0 && bad_r == 0, "unaligned narrow FIXED burst: lane 5 only, every beat");
    // strobes outside the beat's lanes are ignored
    wr1(8, 32'h0000_0E40, 1, 3, 2'b01, 11); wr1(8, 32'h0000_0E40, 1, 3, 2'b01, 11);
    clear_batch(); add_w(8, 32'h0000_0E42, 1, 1, 2'b01, 12); w_st[0][0] = 8'hFF; run_batch();
    w_st[0][0] = 8'h0C; check_batch(); rd1(8, 32'h0000_0E40, 1, 3, 2'b01);
    chk(bad_r == 0, "WSTRB outside a narrow beat's lanes writes nothing");
    wr1(8, 32'h0000_0E48, 4, 3, 2'b01, 13, 1); rd1(8, 32'h0000_0E48, 4, 3, 2'b01);
    chk(bad_w == 0 && bad_r == 0, "sparse random strobes");

    // ---- SLVERR ----
    wr1(9, 32'h0000_0F00, 2, 3, 2'b01, 14);
    wr1(9, 32'hEE00_0F00, 2, 3, 2'b01, 15); rd1(9, 32'h0000_0F00, 2, 3, 2'b01);
    chk(bad_r == 0, "error-region write: SLVERR, aliased memory unchanged");
    rd1(9, 32'hEE00_0F00, 4, 3, 2'b01);
    chk(bad_r == 0 && bad_last == 0 && r_rs[0][3] == 2'b10 && r_d[0][2] == 64'h0, "error-region read: SLVERR and zero data on every beat, RLAST");
    wr1(10, 32'h0000_1FF0, 2, 3, 2'b01, 16); rd1(10, 32'h0000_0FF0, 2, 3, 2'b01);
    chk(bad_w == 0 && bad_r == 0 && w_resp[0] == 2'b00, "INCR ending on the last byte of a 4 KB page: OKAY");
    wr1(10, 32'h0000_1FF8, 2, 3, 2'b01, 17); rd1(10, 32'h0000_0FF0, 2, 3, 2'b01); rd1(10, 32'h0000_0000, 1, 3, 2'b01);
    chk(bad_r == 0, "INCR crossing a 4 KB page: SLVERR, nothing written either side");
    rd1(10, 32'h0000_0FF8, 2, 2, 2'b01);
    chk(bad_r == 0 && r_rs[0][0] == 2'b00, "narrow INCR up to the page end: OKAY");
    rd1(10, 32'h0000_0FFD, 2, 2, 2'b01);
    chk(bad_r == 0 && r_rs[0][0] == 2'b10, "unaligned narrow INCR across the page: SLVERR");
    wr1(11, 32'h0000_0A04, 4, 3, 2'b10, 18); rd1(11, 32'h0000_0A04, 4, 3, 2'b10);
    chk(bad_r == 0 && r_rs[0][0] == 2'b10, "unaligned WRAP burst: SLVERR");
    rd1(11, 32'h0000_0A00, 3, 3, 2'b10);
    chk(bad_r == 0 && r_rs[0][0] == 2'b10, "3-beat WRAP burst: SLVERR");
    rd1(11, 32'h0000_0A00, 1, 3'd4, 2'b01);
    chk(bad_r == 0 && r_rs[0][0] == 2'b10, "16-byte AxSIZE on a 64-bit bus: SLVERR");
    rd1(11, 32'h0000_0A00, 2, 3, 2'b11);
    chk(bad_r == 0 && r_rs[0][0] == 2'b10, "reserved burst type: SLVERR");
    wr1(11, 32'h0000_0A00, 1, 3'd5, 2'b11, 19);
    chk(bad_w == 0, "illegal write burst answered SLVERR");

    // ---- outstanding bursts, IDs ----
    // four writes accepted before any W beat; the fifth AW waits
    clear_batch();
    for (int i = 0; i < 5; i++) add_w(8'(i % 3), 32'h0000_0400 + 64 * i, 2, 3, 2'b01, 40 + i);
    w_gap_pct = 100;
    fork
      run_batch();
      begin
        repeat (60) @(posedge vif_aclk);
        aw_full = vif_awvalid && !vif_awready;
        w_gap_pct = 0;
      end
    join
    check_batch();
    chk(aw_full == 1 && bad_w == 0, "four writes outstanding; a fifth AW waits");
    clear_batch();
    for (int i = 0; i < 5; i++) add_r(8'(i % 3), 32'h0000_0400 + 64 * i, 2, 3, 2'b01);
    ready_pct = 0;
    fork
      run_batch();
      begin
        repeat (60) @(posedge vif_aclk);
        aw_full = vif_arvalid && !vif_arready;
        ready_pct = 100;
      end
    join
    check_batch();
    chk(aw_full == 1 && bad_r == 0 && bad_last == 0, "four reads outstanding; a fifth AR waits");
    // B queue full: no last W beat while four B responses wait
    clear_batch();
    for (int i = 0; i < 6; i++) add_w(8'(i), 32'h0000_0500 + 8 * i, 1, 3, 2'b01, 50 + i);
    ready_pct = 0;
    fork
      run_batch();
      begin
        repeat (80) @(posedge vif_aclk);
        aw_full = vif_wvalid && !vif_wready;
        ready_pct = 100;
      end
    join
    check_batch();
    chk(aw_full == 1 && bad_w == 0, "W waits while four B responses are not taken");

    // responses out of order across IDs, in order within an ID, interleaved reads
    n_ooo = 0; n_ilv = 0; n_unexp = 0;
    ok = 1;
    ready_pct = 25;   // let B responses pile up so the slave can pick among them
    for (int t = 0; t < 12; t++) begin
      clear_batch();
      for (int i = 0; i < 4; i++) add_w(8'(i), 32'h0000_0600 + 128 * i + 16 * t[1:0], 3, 3, 2'b01, 100 + 8 * t + i);
      for (int i = 0; i < 4; i++) add_r(8'(4 + i % 2), 32'h0000_0000 + 128 * i, 4, 3, 2'b01);
      run_batch(); check_batch();
      if (bad_w || bad_r || bad_last) ok = 0;
    end
    ready_pct = 100;
    chk(ok == 1 && n_unexp == 0, "outstanding writes and reads on several IDs complete with the right data");
    chk(n_ooo > 0, $sformatf("B responses overtake older writes of other IDs (%0d)", n_ooo));
    chk(n_ilv > 0, $sformatf("R beats of different IDs interleave (%0d)", n_ilv));
    // same ID: in order (a younger burst never answers first)
    clear_batch();
    for (int i = 0; i < 4; i++) add_r(8'h7, 32'h0000_0400 + 64 * i, 1 + i, 3, 2'b01);
    run_batch(); check_batch();
    chk(bad_r == 0 && bad_last == 0, "four reads of one ID: beats returned in issue order");
    clear_batch();
    for (int i = 0; i < 4; i++) add_w(8'h9, 32'h0000_0700 + 64 * i, 4 - i, 3, 2'b01, 200 + i);
    run_batch(); check_batch();
    ok = 1;
    for (int i = 0; i < 4; i++) if (b_order[i] != i) ok = 0;
    chk(bad_w == 0 && ok == 1, "four writes of one ID: B responses in issue order");

    // ---- random batches with back-pressure ----
    n_unexp = 0;
    ok = 1;
    w_gap_pct = 20; ready_pct = 70;
    for (int t = 0; t < 150; t++) begin
      clear_batch();
      cnt = $urandom_range(6);
      for (int i = 0; i < cnt; i++) begin
        tries = 0;
        do begin
          rwr = $urandom_range(1);
          rsz = $urandom_range(3);
          rbt = $urandom_range(2);
          rlen = (rbt == 2'b10) ? (2 << $urandom_range(3)) : $urandom_range(rbt == 2'b00 ? 4 : 12, 1);
          ra = {($urandom_range(15) == 0) ? 8'hEE : 8'h00, 12'($urandom), 12'($urandom)};
          if (rbt == 2'b10 || $urandom_range(1)) ra = ra & ~((32'd1 << rsz) - 1);
          tries++;
        end while (clash(ra, rlen, rsz, rbt, rwr) && tries < 20);
        if (tries < 20) begin
          if (rwr && nw < MB) add_w(8'($urandom_range(5)), ra, rlen, rsz, rbt, 1000 + 16 * t + i, $urandom_range(3) == 0);
          if (!rwr && nr < MB) add_r(8'($urandom_range(5)), ra, rlen, rsz, rbt);
        end
      end
      run_batch(); check_batch();
      if (bad_w || bad_r || bad_last) begin
        ok = 0;
        $display("  batch %0d: bad_w=%0d bad_r=%0d bad_last=%0d", t, bad_w, bad_r, bad_last);
      end
    end
    w_gap_pct = 0; ready_pct = 100;
    chk(ok == 1 && n_unexp == 0, "150 random batches (narrow, unaligned, FIXED / INCR / WRAP, SLVERR) match the reference memory");
    chk(b_unstable == 0 && r_unstable == 0, "BVALID / RVALID and their payload held until READY");
    chk(aw_wait > 0 && ar_wait > 0, "AWREADY / ARREADY back-pressure seen");

    // ---- reset aborts everything, memory survives ----
    clear_batch(); add_w(12, 32'h0000_0800, 8, 3, 2'b01, 300); add_r(13, 32'h0000_0100, 16, 3, 2'b01);
    fork
      run_batch();
      begin
        repeat (12) @(posedge vif_aclk);
        #1 vif_aresetn = 1'b0;
        #1 chk(vif_bvalid === 1'b0 && vif_rvalid === 1'b0 && vif_wready === 1'b0, "reset drops B, R and WREADY");
        #20 vif_aresetn = 1'b1;
      end
    join_any
    disable fork;
    vif_awvalid = 0; vif_wvalid = 0; vif_arvalid = 0; vif_bready = 0; vif_rready = 0;
    repeat (3) @(negedge vif_aclk);
    // the aborted write may have landed some beats: forget word 0x800..0x83F
    for (int i = 12'h800; i < 12'h840; i++) ref_mem[i] = 8'hxx;
    wr1(12, 32'h0000_0800, 8, 3, 2'b01, 301);
    rd1(13, 32'h0000_0100, 16, 3, 2'b01); rd1(12, 32'h0000_0800, 8, 3, 2'b01);
    chk(bad_r == 0 && bad_last == 0, "after reset: memory contents kept, new bursts complete");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
