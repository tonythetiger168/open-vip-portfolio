// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// AMBA Testbench -- top with a functional AXI4 slave DUT model (memory)
//============================================================================
`ifndef AMBA_TB_SV
`define AMBA_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import amba_vip_pkg::*;

module top_tb;
  logic aclk = 0, aresetn;
  always #5ns aclk = ~aclk;

  initial begin
    aresetn = 0;
    #100ns;
    aresetn = 1;
  end

  amba_vip_if vif(aclk, aresetn);
  amba_dut dut(.vif(vif));

  // Tiered SVA compliance checker (module form)
  axi_compliance_checker_sva u_axi_sva_chk (.vif(vif));

  // Protocol checkers (module form)
  ahb_protocol_checker_sva u_ahb_proto_sva (.vif(vif));
  apb_protocol_checker_sva u_apb_proto_sva (.vif(vif));
  axi_protocol_checker_sva u_axi_proto_sva (.vif(vif));

  initial begin
    uvm_config_db#(virtual amba_vip_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

//----------------------------------------------------------------------------
// Functional AXI4 slave: memory model with multiple outstanding bursts.
//   - 4 KiB memory, 64-bit words indexed by addr[11:3] (aliases every 4 KiB)
//   - up to 4 write bursts and 4 read bursts outstanding; W beats follow the
//     AW order (AXI4 has no WID)
//   - B responses and R beats are returned out of order across IDs and in
//     order within an ID (A5.3); R beats of bursts with different IDs are
//     interleaved, one beat at a time
//   - narrow (AxSIZE < 3) and unaligned transfers: a beat writes only the
//     byte lanes of its address window that also have WSTRB set (A3.4.3)
//   - SLVERR, no memory effect and zero read data for: the error region
//     addr[31:24] == 8'hEE, an INCR burst that crosses a 4 KB page (A3.4.1),
//     a WRAP burst that is unaligned or not 2, 4, 8 or 16 beats, AxSIZE wider
//     than the bus, and the reserved burst type
//   - AWREADY / WREADY / ARREADY, the BVALID / RVALID start and the gaps
//     between beats come from an LFSR; RVALID / BVALID with their payload
//     stay stable until READY
//----------------------------------------------------------------------------
module amba_dut(amba_vip_if vif);
  localparam int QD = 4;

  logic [63:0] mem [0:511];
  initial for (int i = 0; i < 512; i++) mem[i] = 64'h0;

  // queues kept oldest first: index 0 is the oldest entry
  //   wq: accepted AW (W beats go to entry 0), bq: finished writes waiting
  //   for B, rq: accepted AR. *_a is the address of the burst's next beat.
  logic [31:0] wq_a [0:QD-1], rq_a [0:QD-1];
  logic [7:0]  wq_l [0:QD-1], rq_l [0:QD-1];     // AxLEN
  logic [7:0]  wq_k [0:QD-1], rq_k [0:QD-1];     // beats done
  logic [2:0]  wq_s [0:QD-1], rq_s [0:QD-1];
  logic [1:0]  wq_b [0:QD-1], rq_b [0:QD-1];
  logic [7:0]  wq_i [0:QD-1], rq_i [0:QD-1], bq_i [0:QD-1];
  logic        wq_e [0:QD-1], rq_e [0:QD-1];
  logic [1:0]  bq_r [0:QD-1];
  logic [2:0]  wq_n, bq_n, rq_n;
  logic        bv, rv;
  logic [1:0]  bsel, rsel;
  logic [15:0] lfsr;
  logic [1:0]  b_pick, r_pick;
  logic [7:0]  w_lanes;

  wire aw_hs = vif.awvalid && vif.awready;
  wire w_hs  = vif.wvalid  && vif.wready;
  wire b_hs  = vif.bvalid  && vif.bready;
  wire ar_hs = vif.arvalid && vif.arready;
  wire r_hs  = vif.rvalid  && vif.rready;
  wire w_end = (wq_k[0] == wq_l[0]);             // the W beat is the burst's last
  wire r_end = (rq_k[rsel] == rq_l[rsel]);

  // SLVERR bursts (decided when the address is accepted)
  function automatic logic burst_err(input logic [31:0] a, input logic [7:0] len, input logic [2:0] size,
                                     input logic [1:0] burst);
    logic [13:0] last;
    logic [4:0]  nb;
    nb = 5'd1 << size;
    burst_err = (a[31:24] == 8'hEE) || (size > 3'd3) || (burst == 2'b11);
    // INCR: the aligned start plus the burst's bytes must stay in the 4 KB page
    last = {2'b00, a[11:0] & ~(12'(nb) - 12'd1)} + ((14'(len) + 14'd1) << size);
    if (burst == 2'b01 && last > 14'h1000) burst_err = 1'b1;
    if (burst == 2'b10 && ((len != 8'd1 && len != 8'd3 && len != 8'd7 && len != 8'd15) ||
                           (a[2:0] & (nb[2:0] - 3'd1)) != 3'd0)) burst_err = 1'b1;
  endfunction

  // byte lanes of a beat at address a: from a up to the end of its size window
  function automatic logic [7:0] lanes(input logic [31:0] a, input logic [2:0] size);
    logic [3:0] nb;
    logic [7:0] m;
    nb = 4'd1 << size;
    m = 8'((9'd1 << nb) - 9'd1) << (a[2:0] & ~(3'(nb) - 3'd1));
    lanes = m & ~((8'd1 << a[2:0]) - 8'd1);
  endfunction

  // address of the beat after a (A3.4.1)
  function automatic logic [31:0] next_addr(input logic [31:0] a, input logic [2:0] size,
                                            input logic [1:0] burst, input logic [7:0] len);
    logic [31:0] nb, wsz;
    nb = 32'd1 << size;
    if (burst == 2'b00) next_addr = a;
    else if (burst == 2'b10) begin
      wsz = nb * (32'(len) + 32'd1);
      next_addr = (a & ~(wsz - 32'd1)) | ((a + nb) & (wsz - 32'd1));
    end
    else next_addr = (a & ~(nb - 32'd1)) + nb;
  endfunction

  assign vif.awready = (wq_n < QD) && (lfsr[2] | lfsr[9]);
  // the last beat of a burst needs room for its B response
  assign vif.wready  = (wq_n != 3'd0) && (bq_n < QD) && (lfsr[5] | lfsr[12]);
  assign vif.arready = (rq_n < QD) && (lfsr[7] | lfsr[14]);
  assign vif.bvalid  = bv;
  assign vif.bid     = bq_i[bsel];
  assign vif.bresp   = bq_r[bsel];
  assign vif.rvalid  = rv;
  assign vif.rid     = rq_i[rsel];
  assign vif.rdata   = rq_e[rsel] ? 64'h0 : mem[rq_a[rsel][11:3]];
  assign vif.rresp   = rq_e[rsel] ? 2'b10 : 2'b00;
  assign vif.rlast   = r_end;
  assign w_lanes     = lanes(wq_a[0], wq_s[0]);

  // next response to return: an entry with no older entry of the same ID,
  // searched from an LFSR-chosen start so IDs overtake each other
  always_comb begin
    logic found, elig;
    int   i;
    found = 1'b0; b_pick = 2'd0;
    for (int k = 0; k < QD; k++) begin
      i = (k + int'(lfsr[1:0])) % QD;
      if (!found && i < int'(bq_n)) begin
        elig = 1'b1;
        for (int j = 0; j < QD; j++) if (j < i && bq_i[j] == bq_i[i]) elig = 1'b0;
        if (elig) begin found = 1'b1; b_pick = 2'(i); end
      end
    end
  end
  always_comb begin
    logic found, elig;
    int   i;
    found = 1'b0; r_pick = 2'd0;
    for (int k = 0; k < QD; k++) begin
      i = (k + int'(lfsr[4:3])) % QD;
      if (!found && i < int'(rq_n)) begin
        elig = 1'b1;
        for (int j = 0; j < QD; j++) if (j < i && rq_i[j] == rq_i[i]) elig = 1'b0;
        if (elig) begin found = 1'b1; r_pick = 2'(i); end
      end
    end
  end

  always_ff @(posedge vif.aclk or negedge vif.aresetn) begin
    if (!vif.aresetn) begin
      for (int i = 0; i < QD; i++) begin
        wq_a[i] <= '0; wq_l[i] <= '0; wq_k[i] <= '0; wq_s[i] <= '0; wq_b[i] <= '0; wq_i[i] <= '0; wq_e[i] <= 1'b0;
        rq_a[i] <= '0; rq_l[i] <= '0; rq_k[i] <= '0; rq_s[i] <= '0; rq_b[i] <= '0; rq_i[i] <= '0; rq_e[i] <= 1'b0;
        bq_i[i] <= '0; bq_r[i] <= '0;
      end
      wq_n <= 3'd0; bq_n <= 3'd0; rq_n <= 3'd0;
      bv <= 1'b0; rv <= 1'b0; bsel <= 2'd0; rsel <= 2'd0;
      lfsr <= 16'hACE1;
    end
    else begin
      lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};

      // ---- write side: AW queue -> W beats on the head -> B queue ----
      if (w_hs && !wq_e[0])
        for (int b = 0; b < 8; b++)
          if (vif.wstrb[b] && w_lanes[b]) mem[wq_a[0][11:3]][b*8 +: 8] <= vif.wdata[b*8 +: 8];
      if (w_hs && w_end) begin
        // head done: shift the AW queue, append its B response
        for (int i = 0; i < QD - 1; i++) begin
          wq_a[i] <= wq_a[i + 1]; wq_l[i] <= wq_l[i + 1]; wq_k[i] <= wq_k[i + 1];
          wq_s[i] <= wq_s[i + 1]; wq_b[i] <= wq_b[i + 1]; wq_i[i] <= wq_i[i + 1]; wq_e[i] <= wq_e[i + 1];
        end
      end
      else if (w_hs) begin
        wq_a[0] <= next_addr(wq_a[0], wq_s[0], wq_b[0], wq_l[0]);
        wq_k[0] <= wq_k[0] + 8'd1;
      end
      if (aw_hs) begin
        // the new entry lands after the shift, if any
        wq_a[wq_n - 3'(w_hs && w_end)] <= vif.awaddr;
        wq_l[wq_n - 3'(w_hs && w_end)] <= vif.awlen;
        wq_k[wq_n - 3'(w_hs && w_end)] <= 8'd0;
        wq_s[wq_n - 3'(w_hs && w_end)] <= vif.awsize;
        wq_b[wq_n - 3'(w_hs && w_end)] <= vif.awburst;
        wq_i[wq_n - 3'(w_hs && w_end)] <= vif.awid;
        wq_e[wq_n - 3'(w_hs && w_end)] <= burst_err(vif.awaddr, vif.awlen, vif.awsize, vif.awburst);
      end
      wq_n <= wq_n + 3'(aw_hs) - 3'(w_hs && w_end);

      if (b_hs)
        for (int i = 0; i < QD - 1; i++)
          if (i >= int'(bsel)) begin bq_i[i] <= bq_i[i + 1]; bq_r[i] <= bq_r[i + 1]; end
      if (w_hs && w_end) begin
        bq_i[bq_n - 3'(b_hs)] <= wq_i[0];
        bq_r[bq_n - 3'(b_hs)] <= wq_e[0] ? 2'b10 : 2'b00;
      end
      bq_n <= bq_n + 3'(w_hs && w_end) - 3'(b_hs);

      // ---- read side: AR queue, one beat of the selected burst at a time ----
      if (r_hs && r_end) begin
        for (int i = 0; i < QD - 1; i++)
          if (i >= int'(rsel)) begin
            rq_a[i] <= rq_a[i + 1]; rq_l[i] <= rq_l[i + 1]; rq_k[i] <= rq_k[i + 1];
            rq_s[i] <= rq_s[i + 1]; rq_b[i] <= rq_b[i + 1]; rq_i[i] <= rq_i[i + 1]; rq_e[i] <= rq_e[i + 1];
          end
      end
      else if (r_hs) begin
        rq_a[rsel] <= next_addr(rq_a[rsel], rq_s[rsel], rq_b[rsel], rq_l[rsel]);
        rq_k[rsel] <= rq_k[rsel] + 8'd1;
      end
      if (ar_hs) begin
        rq_a[rq_n - 3'(r_hs && r_end)] <= vif.araddr;
        rq_l[rq_n - 3'(r_hs && r_end)] <= vif.arlen;
        rq_k[rq_n - 3'(r_hs && r_end)] <= 8'd0;
        rq_s[rq_n - 3'(r_hs && r_end)] <= vif.arsize;
        rq_b[rq_n - 3'(r_hs && r_end)] <= vif.arburst;
        rq_i[rq_n - 3'(r_hs && r_end)] <= vif.arid;
        rq_e[rq_n - 3'(r_hs && r_end)] <= burst_err(vif.araddr, vif.arlen, vif.arsize, vif.arburst);
      end
      rq_n <= rq_n + 3'(ar_hs) - 3'(r_hs && r_end);

      // BVALID / RVALID: one response at a time, held until READY, then a
      // clock (or more) before the next
      if (b_hs) bv <= 1'b0;
      else if (!bv && bq_n != 3'd0 && (lfsr[3] | lfsr[11])) begin bv <= 1'b1; bsel <= b_pick; end
      if (r_hs) rv <= 1'b0;
      else if (!rv && rq_n != 3'd0 && (lfsr[6] | lfsr[13])) begin rv <= 1'b1; rsel <= r_pick; end
    end
  end

  // Tie off unused protocol outputs (AHB/APB/stream) so no X propagates
  initial begin
    vif.tready = 1'b0;
    vif.hreadyout = 1'b0; vif.hrdata = 64'h0; vif.hresp = 1'b0;
    vif.pready = 1'b0; vif.prdata = 32'h0; vif.pslverr = 1'b0;
  end
endmodule
`endif
