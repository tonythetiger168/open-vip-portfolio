// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_axi_tb.sv -- AXI4 burst / handshake functional test for the AXI slave
// model (amba_dut, flattened by smoke/flatten.py); complements
// smoke_func_tb.sv (single bursts, WSTRB, SLVERR).
// Run: python3 tools/run_func_tests.py AXI-VIP
//
// Model contract (from tb/top_tb.sv): 64-bit data, 4 KB memory (addr[11:3]),
// AWREADY always high, WREADY while a write burst is active, BVALID after
// WLAST until BREADY, ARREADY while no read burst is active, RVALID during
// the read burst; FIXED / INCR / WRAP bursts of 8-byte beats; addresses
// with [31:24] = EEh answer SLVERR (writes dropped, reads return 0).
// Checked here against an AXI4 reference memory: 300 random bursts of every
// type and legal length with random WVALID gaps and BREADY / RREADY
// back-pressure, plus reset in the middle of bursts.
//
// Model defect (XFAIL): AWREADY stays high during a write burst, and a new
// AW overwrites the burst address, so the remaining beats of the first
// burst land at the second address.

`timescale 1ns/1ps
module func_axi_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [1:0] FIXED = 2'b00, INCR = 2'b01, WRAP = 2'b10;
  int checks = 0, fails = 0, xfails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [31:0] awaddr = '0, araddr = '0;
  logic [7:0]  awlen = '0, arlen = '0;
  logic [1:0]  awburst = INCR, arburst = INCR;
  logic        awvalid = 0, wvalid = 0, wlast = 0, bready = 0, arvalid = 0, rready = 0;
  logic [63:0] wdata = '0;
  logic [7:0]  wstrb = '0;
  wire         awready, wready, bvalid, arready, rvalid, rlast;
  wire  [1:0]  bresp, rresp;
  wire  [63:0] rdata;
  wire         tready, hreadyout, hresp, pready, pslverr;
  wire  [63:0] hrdata;
  wire  [31:0] prdata;

  always #5 clk = ~clk;

  amba_dut u_dut (
    .vif_aclk(clk), .vif_aresetn(rst_n),
    .vif_awaddr(awaddr), .vif_awlen(awlen), .vif_awburst(awburst), .vif_awvalid(awvalid),
    .vif_awready(awready), .vif_wdata(wdata), .vif_wstrb(wstrb), .vif_wlast(wlast),
    .vif_wvalid(wvalid), .vif_wready(wready), .vif_bresp(bresp), .vif_bvalid(bvalid),
    .vif_bready(bready), .vif_araddr(araddr), .vif_arlen(arlen), .vif_arburst(arburst),
    .vif_arvalid(arvalid), .vif_arready(arready), .vif_rdata(rdata), .vif_rresp(rresp),
    .vif_rlast(rlast), .vif_rvalid(rvalid), .vif_rready(rready),
    .vif_tready(tready), .vif_hrdata(hrdata), .vif_hreadyout(hreadyout), .vif_hresp(hresp),
    .vif_prdata(prdata), .vif_pready(pready), .vif_pslverr(pslverr)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // ---- AXI4 reference: beat addresses of a burst (8-byte beats) ----
  logic [63:0] ref_mem [0:511];
  function automatic logic [31:0] beat_addr(input [31:0] start, input [1:0] burst,
                                           input [7:0] len, input int n);
    int bytes;
    logic [31:0] lower;
    case (burst)
      FIXED: return start;
      INCR:  return start + 8 * n;
      default: begin
        bytes = (len + 1) * 8;
        lower = start - (start % bytes);
        return lower + ((start - lower + 8 * n) % bytes);
      end
    endcase
  endfunction

  // ---- channel monitors: VALID must hold until READY, payload stable ----
  int b_drop = 0, r_drop = 0, r_unstable = 0;
  logic [63:0] r_hold;
  logic        r_hold_last;
  always @(posedge clk) if (rst_n) begin
    if (bvalid && !bready) #1 if (!bvalid && rst_n) b_drop++;
  end
  always @(posedge clk) if (rst_n) begin
    if (rvalid && !rready) begin
      r_hold = rdata; r_hold_last = rlast;
      #1 if (rst_n && (!rvalid || rdata !== r_hold || rlast !== r_hold_last)) r_unstable++;
    end
  end

  // ---- master tasks ----
  logic [1:0] last_b;
  int         gap_pct = 0, bp_pct = 0;
  function automatic bit roll(input int pct); return $urandom_range(99) < pct; endfunction

  task automatic write(input [31:0] a, input [7:0] len, input [1:0] burst, input bit upd = 1);
    logic [31:0] ba;
    logic [63:0] d;
    logic [7:0]  s;
    @(negedge clk);
    awaddr = a; awlen = len; awburst = burst; awvalid = 1;
    @(negedge clk);                           // AWREADY is always high
    awvalid = 0;
    for (int n = 0; n <= len; n++) begin
      while (roll(gap_pct)) begin wvalid = 0; @(negedge clk); end
      d = {$urandom, $urandom}; s = $urandom;
      wdata = d; wstrb = s; wlast = (n == len); wvalid = 1;
      do @(negedge clk); while (!(wready === 1'b1) && 0);
      ba = beat_addr(a, burst, len, n);
      if (upd && a[31:24] != 8'hEE)
        for (int b = 0; b < 8; b++) if (s[b]) ref_mem[ba[11:3]][b*8 +: 8] = d[b*8 +: 8];
    end
    wvalid = 0; wlast = 0;
    while (roll(bp_pct)) @(negedge clk);
    bready = 1;
    while (bvalid !== 1'b1) @(negedge clk);
    last_b = bresp;
    @(negedge clk);
    bready = 0;
  endtask

  int rd_bad, rlast_bad;
  logic [1:0] last_r;
  task automatic read(input [31:0] a, input [7:0] len, input [1:0] burst);
    logic [31:0] ba;
    @(negedge clk);
    while (arready !== 1'b1) @(negedge clk);
    araddr = a; arlen = len; arburst = burst; arvalid = 1;
    @(negedge clk);
    arvalid = 0;
    for (int n = 0; n <= len; n++) begin
      rready = 0;
      while (roll(bp_pct)) @(negedge clk);
      rready = 1;
      while (rvalid !== 1'b1) @(negedge clk);
      ba = beat_addr(a, burst, len, n);
      last_r = rresp;
      if (a[31:24] == 8'hEE) begin
        if (rdata !== 64'h0 || rresp !== 2'b10) rd_bad++;
      end else if (rdata !== ref_mem[ba[11:3]] || rresp !== 2'b00) rd_bad++;
      if (rlast !== (n == len)) rlast_bad++;
      @(negedge clk);
    end
    rready = 0;
  endtask

  int bad_b;
  initial begin
    for (int i = 0; i < 512; i++) ref_mem[i] = 64'h0;
    repeat (2) @(negedge clk);
    chk(!bvalid && !rvalid && !wready && arready && awready, "reset: no B / R, WREADY low, AWREADY / ARREADY high");
    rst_n = 1'b1;
    @(negedge clk);

    rd_bad = 0; rlast_bad = 0;
    read(32'h0, 0, INCR);
    read(32'hFF8, 0, INCR);
    chk(rd_bad == 0, "unwritten words (first and last of the 4 KB) read 0");

    // ---- directed burst types ----
    write(32'h100, 15, INCR);
    read(32'h100, 15, INCR);
    chk(rd_bad == 0 && rlast_bad == 0, "16-beat INCR write / read");
    for (int l = 1; l <= 15; l = l * 2 + 1) begin
      write(32'h208 + 8 * l, 8'(l), WRAP);           // start in the middle of the window
      read(32'h200 + 8 * (l / 2), 8'(l), WRAP);
      read(32'h200 - (32'h200 % ((l + 1) * 8)), 8'(l), INCR);
    end
    chk(rd_bad == 0 && rlast_bad == 0, "WRAP bursts of 2, 4, 8, 16 beats wrap at the burst boundary");
    write(32'h300, 7, FIXED);
    read(32'h300, 3, FIXED);
    read(32'h300, 0, INCR);
    read(32'h308, 0, INCR);
    chk(rd_bad == 0, "FIXED burst: every beat to the same address, neighbours untouched");
    write(32'h400, 255, INCR);
    read(32'h400, 255, INCR);
    chk(rd_bad == 0 && rlast_bad == 0, "256-beat INCR burst");

    // ---- error region ----
    write(32'hEE00_0500, 3, INCR, 0);
    chk(last_b == 2'b10, "4-beat write to the error region: SLVERR");
    read(32'h500, 3, INCR);
    chk(rd_bad == 0, "error-region write leaves the aliased memory unchanged");
    read(32'hEE00_0500, 3, INCR);
    chk(rd_bad == 0 && last_r == 2'b10 && rlast_bad == 0, "4-beat read from the error region: SLVERR, zero data, RLAST on the last beat");

    // ---- random traffic with gaps and back-pressure ----
    gap_pct = 30; bp_pct = 40; bad_b = 0;
    for (int t = 0; t < 300; t++) begin
      logic [1:0]  bt;
      logic [7:0]  l;
      logic [31:0] a;
      bt = $urandom_range(2);
      case (bt)
        FIXED: l = $urandom_range(7);
        INCR:  l = $urandom_range(31);
        default: l = (8'd2 << $urandom_range(3)) - 1;
      endcase
      a = {$urandom_range(511 - ((bt == INCR) ? l : 0)), 3'b000};
      if ($urandom_range(1)) begin
        write(a, l, bt);
        if (last_b != 2'b00) bad_b++;
      end else read(a, l, bt);
    end
    chk(rd_bad == 0, "300 random FIXED / INCR / WRAP bursts match the AXI4 reference memory");
    chk(rlast_bad == 0 && bad_b == 0, "RLAST only on the last beat, BRESP OKAY");
    chk(b_drop == 0, "BVALID held until BREADY");
    chk(r_unstable == 0, "RVALID, RDATA and RLAST held stable while RREADY is low");
    gap_pct = 0; bp_pct = 0;

    // ---- WVALID before AW ----
    @(negedge clk);
    wdata = 64'hFEED_0000_0000_0001; wstrb = 8'hFF; wlast = 1; wvalid = 1;
    repeat (3) @(negedge clk);
    chk(!wready, "W beat ahead of AW waits (WREADY low)");
    awaddr = 32'h600; awlen = 0; awburst = INCR; awvalid = 1;
    @(negedge clk); awvalid = 0;
    while (!wready) @(negedge clk);
    @(negedge clk); wvalid = 0; wlast = 0;
    ref_mem[32'h600 >> 3] = 64'hFEED_0000_0000_0001;
    bready = 1; while (!bvalid) @(negedge clk); @(negedge clk); bready = 0;
    read(32'h600, 0, INCR);
    chk(rd_bad == 0, "W beat presented before AW is written once AW arrives");

    // ---- second AW during a write burst ----
    @(negedge clk);
    awaddr = 32'h700; awlen = 3; awburst = INCR; awvalid = 1;
    @(negedge clk); awvalid = 0;
    wdata = 64'h1111; wstrb = 8'hFF; wvalid = 1;
    @(negedge clk);
    awaddr = 32'h780; awlen = 0; awvalid = 1;            // next AW while W of the first is pending
    wvalid = 0;                                          // (in a clock without a W beat)
    @(negedge clk); awvalid = 0;
    wdata = 64'h2222; wvalid = 1;
    @(negedge clk);
    wdata = 64'h3333;
    @(negedge clk);
    wdata = 64'h4444; wlast = 1;
    @(negedge clk); wvalid = 0; wlast = 0;
    bready = 1; repeat (3) @(negedge clk); bready = 0;
    rd_bad = 0;
    ref_mem[32'h700 >> 3] = 64'h1111; ref_mem[32'h708 >> 3] = 64'h2222;
    ref_mem[32'h710 >> 3] = 64'h3333; ref_mem[32'h718 >> 3] = 64'h4444;
    read(32'h700, 3, INCR);
    chk_xfail(rd_bad == 0, "AW accepted during a write burst does not redirect that burst's beats");

    // ---- reset in the middle of bursts ----
    @(negedge clk);
    awaddr = 32'h800; awlen = 7; awburst = INCR; awvalid = 1;
    araddr = 32'h100; arlen = 7; arburst = INCR; arvalid = 1;
    @(negedge clk); awvalid = 0; arvalid = 0;
    chk(wready && rvalid, "write and read bursts active");
    rst_n = 1'b0;
    @(negedge clk);
    chk(!wready && !rvalid && !bvalid && arready, "reset aborts both bursts (WREADY, RVALID low, ARREADY high)");
    rst_n = 1'b1;
    @(negedge clk);
    rd_bad = 0;
    read(32'h100, 1, INCR);
    chk(rd_bad == 0, "memory contents survive the reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #5000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
