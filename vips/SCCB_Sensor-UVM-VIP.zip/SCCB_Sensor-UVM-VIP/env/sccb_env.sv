// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_env.sv -- SCCB environment: reference-model scoreboard, checker, coverage

package sccb_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sccb_defs_pkg::*;
  import sccb_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class sccb_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(sccb_scoreboard)
    uvm_analysis_imp_exp #(sccb_transaction, sccb_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(sccb_transaction, sccb_scoreboard) obs_ap;

    sccb_config cfg;
    sccb_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [7:0]  regs [512];
    bit        rinit = 0;
    bit [15:0] ptr = 0;
    bit [7:0]  hi = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(sccb_config)::get(this, "", "cfg", cfg))
        cfg = sccb_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(sccb_transaction t);
      // target state per event: the falling edge before each rise sets its SDA drive
      int st = 0;                  // 0 idle 1 address 2 write 3 read 4 ignore
      int p = 0, wb = 0;
      bit [7:0] sh = 0, txb = 0;
      bit ack = 0, rw = 0, slo = 0;
      if (!rinit) begin foreach (regs[i]) regs[i] = 8'h00; rinit = 1; end
      t.so.delete();
      foreach (t.ev[i]) begin
        if (t.ev[i] == 2'b10) begin st = 1; p = 0; slo = 0; t.so.push_back(1'b0); end
        else if (t.ev[i] == 2'b11) begin st = 0; slo = 0; t.so.push_back(1'b0); end
        else begin
          bit line;
          case (st)
            3: slo = (p < 8) ? !txb[7 - p] : 1'b0;
            1, 2: slo = (p == 8) && ack;
            default: slo = 0;
          endcase
          t.so.push_back(slo);
          line = !(t.ev[i][0] || slo);
          if (p == 8) begin
            p = 0;
            if (st == 1) begin
              if (!ack) st = 4;
              else if (rw) begin st = 3; txb = sccb_rd(regs, ptr); end
              else begin st = 2; wb = 0; end
            end else if (st == 3) begin
              ptr++;
              if (!line) txb = sccb_rd(regs, ptr); else st = 4;
            end
          end else begin
            bit [7:0] shn = {sh[6:0], line};
            p++;
            if (st == 1 || st == 2) begin
              sh = shn;
              if (p == 8) begin
                if (st == 1) begin ack = shn[7:1] == cfg.dev; rw = shn[0]; end
                else begin
                  ack = 1;
                  if (wb == 0) hi = shn;
                  else if (wb == 1) ptr = {hi, shn};
                  else begin if (ptr >= 2 && ptr < 512) regs[ptr[8:0]] = shn; ptr++; end
                  if (wb != 2) wb++;
                end
              end
            end
          end
        end
      end
      t.decode();
    endfunction

    function void write_exp(sccb_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(sccb_transaction t);
      sccb_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        sccb_transaction e = exp_q.pop_front();
        sccb_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("sccb scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class sccb_env extends uvm_env;
    `uvm_component_utils(sccb_env)
    sccb_agent      agt;
    sccb_scoreboard sb;
    sccb_checker    chk;
    sccb_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = sccb_agent     ::type_id::create("agt", this);
      sb  = sccb_scoreboard::type_id::create("sb",  this);
      chk = sccb_checker   ::type_id::create("chk", this);
      cov = sccb_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
