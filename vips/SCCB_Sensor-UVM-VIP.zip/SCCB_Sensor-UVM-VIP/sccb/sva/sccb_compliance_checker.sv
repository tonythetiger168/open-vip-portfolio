// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_compliance_checker.sv -- SCCB concurrent assertion checks (bindable)

module sccb_compliance_checker
  (input logic clk, input logic rst_n, input logic scl, input logic sda_m_lo, input logic sda_s_lo);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({scl, sda_m_lo, sda_s_lo}))
    else $error("SCCB: X on the bus");
  assert property (@(posedge clk) disable iff (!rst_n) $changed(sda_s_lo) |-> !scl)
    else $error("SCCB: target changed SDA while SCL is high");
  assert property (@(posedge clk) disable iff (!rst_n) scl && $past(scl) && $changed(sda_m_lo) |-> !sda_s_lo)
    else $error("SCCB: START / STOP while the target holds SDA low");
  cover property (@(posedge clk) disable iff (!rst_n) $rose(scl) && sda_s_lo);
endmodule
