// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_driver.svh -- SCCB driver: one START .. STOP transaction per item: START from an idle bus (SDA low, then SCL low), each bit set a quarter after SCL falls and clocked for two quarters, repeated START and STOP as I2C conditions; the bus then idles for four quarters

class sccb_driver extends uvm_driver #(sccb_transaction);
  `uvm_component_utils(sccb_driver)

  uvm_analysis_port #(sccb_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual sccb_if vif;
  sccb_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sccb_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sccb: virtual interface not set")
    if (!uvm_config_db#(sccb_config)::get(this, "", "cfg", cfg))
      cfg = sccb_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    sccb_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.scl      <= 1'b1;
    vif.drv_cb.sda_m_lo <= 1'b0;
  endtask

  task drive_item(sccb_transaction t);
    t.build(cfg.dev);
    @(vif.drv_cb);
    foreach (t.ev[i]) begin
      if (t.ev[i] == 2'b10) begin                  // START: SCL is high
        vif.drv_cb.sda_m_lo <= 1'b1;
        repeat (cfg.q) @(vif.drv_cb);
        vif.drv_cb.scl <= 1'b0;
        repeat (cfg.q) @(vif.drv_cb);
      end else if (t.ev[i] == 2'b11) begin         // STOP: SCL is high
        vif.drv_cb.sda_m_lo <= 1'b0;
        repeat (4 * cfg.q) @(vif.drv_cb);
      end else begin                               // a bit; a rise right before START / STOP stays high
        vif.drv_cb.sda_m_lo <= t.ev[i][0];
        repeat (cfg.q) @(vif.drv_cb);
        vif.drv_cb.scl <= 1'b1;
        repeat (cfg.q) @(vif.drv_cb);
        if (i + 1 < t.ev.size() && !t.ev[i + 1][1]) begin
          repeat (cfg.q) @(vif.drv_cb);
          vif.drv_cb.scl <= 1'b0;
          repeat (cfg.q) @(vif.drv_cb);
        end
      end
    end
  endtask

endclass
