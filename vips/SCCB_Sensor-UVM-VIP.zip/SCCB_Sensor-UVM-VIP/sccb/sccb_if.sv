// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_if.sv -- SCCB interface

interface sccb_if (input logic clk);
  logic rst_n;

  logic scl;
  logic sda_m_lo;
  logic sda_s_lo;

  modport DUT (input clk, rst_n, input scl, input sda_m_lo, output sda_s_lo);
  modport MON (input clk, rst_n, scl, sda_m_lo, sda_s_lo);

  clocking drv_cb @(posedge clk);
    input rst_n, sda_s_lo;
    inout scl, sda_m_lo;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, scl, sda_m_lo, sda_s_lo;
  endclocking
endinterface
