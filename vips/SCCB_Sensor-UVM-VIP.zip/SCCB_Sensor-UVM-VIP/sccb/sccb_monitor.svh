// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_monitor.svh -- SCCB monitor: from START to STOP: {sda_m_lo} and sda_s_lo at every SCL rising edge, START (SDA falling with SCL high) and STOP (SDA rising with SCL high) markers; decoded into the bytes the target sent

class sccb_monitor extends uvm_monitor;
  `uvm_component_utils(sccb_monitor)

  virtual sccb_if vif;
  uvm_analysis_port #(sccb_transaction) ap;
  sccb_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual sccb_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sccb: virtual interface not set")
    if (!uvm_config_db#(sccb_config)::get(this, "", "cfg", cfg))
      cfg = sccb_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      sccb_transaction t;
      bit pscl = 1, psda = 1;
      forever begin
        bit sda;
        @(vif.mon_cb);
        sda = !(vif.mon_cb.sda_m_lo === 1'b1 || vif.mon_cb.sda_s_lo === 1'b1);
        if (pscl && vif.mon_cb.scl === 1'b1 && psda && !sda) begin
          if (t == null) t = sccb_transaction::type_id::create("t");
          t.ev.push_back(2'b10); t.so.push_back(1'b0);
        end else if (pscl && vif.mon_cb.scl === 1'b1 && !psda && sda && t != null) begin
          t.ev.push_back(2'b11); t.so.push_back(1'b0);
          t.decode();
          publish(t);
          t = null;
        end else if (!pscl && vif.mon_cb.scl === 1'b1 && t != null) begin
          t.ev.push_back({1'b0, vif.mon_cb.sda_m_lo === 1'b1});
          t.so.push_back(vif.mon_cb.sda_s_lo === 1'b1);
        end
        pscl = (vif.mon_cb.scl === 1'b1); psda = sda;
      end
    end
  endtask

  function void publish(sccb_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
