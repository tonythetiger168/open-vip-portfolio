// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_sequences.svh -- SCCB sequences

// Random traffic: cfg.num_items constrained-random items.
class sccb_base_sequence extends uvm_sequence #(sccb_transaction);
  `uvm_object_utils(sccb_base_sequence)
  sccb_config cfg;

  function new(string name = "sccb_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = sccb_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "sccb_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class sccb_directed_sequence extends uvm_sequence #(sccb_transaction);
  `uvm_object_utils(sccb_directed_sequence)
  sccb_config cfg;

  function new(string name = "sccb_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function sccb_transaction item();
    item = sccb_transaction::type_id::create("req");
  endfunction

  task send(sccb_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    sccb_transaction t;
    // ID, register blocks with both read styles, read-only and unmapped registers, NACKs, wraps
    t = item(); t.set(19, 0, 2); send(t);
    t = item(); t.set(0, 16'h0010, 8, 32'h11); send(t);
    t = item(); t.set(8, 16'h0010, 8); send(t);
    t = item(); t.set(14, 16'h0012); send(t);
    t = item(); t.set(15, 0, 3); send(t);
    t = item(); t.set(15, 0, 1); send(t);
    t = item(); t.set(18, 0, 2, 32'h7); send(t);
    t = item(); t.set(19, 0, 3); send(t);
    t = item(); t.set(20, 16'h0033, 2, 32'h9); send(t);
    t = item(); t.set(21, 0, 4); send(t);
    t = item(); t.set(16, 16'h0010, 2); send(t);
    t = item(); t.set(17); send(t);
    t = item(); t.set(22); send(t);
    t = item(); t.set(23, 16'h0100); send(t);
    t = item(); t.set(15, 0, 2); send(t);
    t = item(); t.set(24, 16'h01FF, 1, 32'h5); send(t);
    t = item(); t.set(8, 16'h01FF, 1); send(t);
    t = item(); t.set(8, 16'h0040, 2); send(t);
    t = item(); t.set(0, 16'h01FE, 4, 32'h99); send(t);
    t = item(); t.set(8, 16'h01FE, 3); send(t);
  endtask
endclass
