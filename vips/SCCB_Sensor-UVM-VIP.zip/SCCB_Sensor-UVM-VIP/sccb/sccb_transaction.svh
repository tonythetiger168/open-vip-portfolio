// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_transaction.svh -- SCCB transaction

class sccb_transaction extends uvm_sequence_item;
  `uvm_object_utils(sccb_transaction)

  // request (driven by the agent)
  bit [1:0] ev[$];
  // response (returned by the DUT)
  bit so[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [15:0] reg_a;
  rand bit [2:0] n;
  rand bit [31:0] seed;
  bit [7:0] rd[$];
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "sccb_transaction"); super.new(name); endfunction

  // kind: 0-7 write 1-8 registers, 8-13 read with a repeated START, 14 write
  // the pointer only (SCCB phase 1), 15 current-address read (SCCB phase 2),
  // 16 write to another address, 17 read from another address, 18 write the
  // chip ID, 19 read the chip ID, 20 write past 0x01FF, 21 read across 0x0200,
  // 22 START + STOP, 23 one address byte only, 24 write, repeated START, write,
  // 25-31 write (seed bit 0 = 0) or read
  function void set(int k, bit [15:0] a = 16'h0010, int cnt = 2, bit [31:0] s = 32'h1); kind = k; reg_a = a; n = cnt - 1; seed = s; endfunction
  function void wbyte(bit [7:0] b);
    for (int i = 7; i >= 0; i--) ev.push_back({1'b0, !b[i]});
    ev.push_back(2'b00);                         // release for the target's ACK
  endfunction
  function void rbytes(int cnt);
    for (int j = 0; j < cnt; j++) begin
      repeat (8) ev.push_back(2'b00);
      ev.push_back({1'b0, j != cnt - 1});        // ACK all but the last, NACK it
    end
  endfunction
  function void rstart(); ev.push_back(2'b00); ev.push_back(2'b10); endfunction
  function void stop(); ev.push_back(2'b01); ev.push_back(2'b11); endfunction
  function void build(bit [6:0] dev);
    bit [31:0] x = seed | 1;
    bit [15:0] a = (kind inside {[0:13], 24, [25:31]}) ? {7'h00, reg_a[8:0]} : reg_a;
    bit [6:0] d = (kind inside {16, 17}) ? dev ^ 7'h01 : dev;
    int cnt = n + 1;
    bit rd_k = kind inside {[8:13], 15, 17, 19, 21} || (kind >= 25 && seed[0]);
    if (kind == 18 || kind == 19) a = 16'h0000;
    if (kind == 20) a = 16'h0200 + reg_a[7:0];
    if (kind == 21) a = 16'h01FE;
    ev.delete();
    ev.push_back(2'b10);
    if (kind == 22) begin stop(); return; end
    if (kind == 15) begin wbyte({d, 1'b1}); rbytes(cnt); stop(); return; end
    wbyte({d, 1'b0});
    if (kind == 16) begin stop(); return; end
    if (kind == 17) begin rstart(); wbyte({d, 1'b1}); stop(); return; end
    wbyte(a[15:8]);
    if (kind == 23) begin stop(); return; end
    wbyte(a[7:0]);
    if (kind == 14) begin stop(); return; end
    if (rd_k) begin
      rstart(); wbyte({d, 1'b1}); rbytes((kind == 21) ? 4 : cnt);
    end else begin
      for (int j = 0; j < cnt; j++) begin x ^= x << 13; x ^= x >> 17; x ^= x << 5; wbyte(x[7:0]); end
      if (kind == 24) begin
        rstart(); wbyte({d, 1'b0}); wbyte(8'h00); wbyte(8'h40);
        x ^= x << 13; x ^= x >> 17; x ^= x << 5; wbyte(x[7:0]);
      end
    end
    stop();
  endfunction
  // monitor side: data bytes of the read frames (after an ACKed address byte with R = 1)
  function void decode();
    int k = 0, fr = 0;
    bit rmode = 0;
    bit [7:0] b = 0;
    rd.delete();
    foreach (ev[i]) begin
      if (ev[i][1]) begin k = 0; fr = 0; rmode = 0; continue; end
      if (k < 8) b = {b[6:0], !(ev[i][0] || so[i])};
      k++;
      if (k == 9) begin
        if (fr == 0) rmode = b[0] && so[i];
        else if (rmode) rd.push_back(b);
        fr++; k = 0;
      end
    end
  endfunction

  function void do_copy(uvm_object rhs);
    sccb_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    ev = rhs_.ev;
    so = rhs_.so;
    kind = rhs_.kind;
    reg_a = rhs_.reg_a;
    n = rhs_.n;
    seed = rhs_.seed;
    rd = rhs_.rd;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sccb_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (ev.size() != rhs_.ev.size()) return 0;
    foreach (ev[i]) if (ev[i] != rhs_.ev[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(sccb_transaction rhs_);
    if (ev.size() != rhs_.ev.size()) return 0;
    foreach (ev[i]) if (ev[i] != rhs_.ev[i]) return 0;
    return 1;
  endfunction

  function string qstr_ev();
    string s = $sformatf("[%0d]{", ev.size());
    foreach (ev[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", ev[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rd();
    string s = $sformatf("[%0d]{", rd.size());
    foreach (rd[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rd[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SCCB{tag=%0d ev=%s so=%s}", tag, qstr_ev(), qstr_so());
  endfunction
endclass
