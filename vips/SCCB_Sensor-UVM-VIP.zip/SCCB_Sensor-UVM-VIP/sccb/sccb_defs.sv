// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_defs.sv -- SCCB shared type definitions

package sccb_defs_pkg;

  typedef enum bit [1:0] {SCCB_OK, SCCB_ERR} sccb_status_e;

  function automatic bit [7:0] sccb_rd(const ref bit [7:0] r [512], input bit [15:0] a);
    if (a == 16'h0000) return 8'h5A;
    if (a == 16'h0001) return 8'h31;
    if (a < 16'h0200) return r[a[8:0]];
    return 8'h00;
  endfunction

endpackage
