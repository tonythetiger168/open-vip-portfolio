// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_pkg.sv -- SCCB UVM VIP package

package sccb_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import sccb_defs_pkg::*;
  export sccb_defs_pkg::*;

  `include "sccb_transaction.svh"
  `include "sccb_config.svh"
  `include "sccb_sequencer.svh"
  `include "sccb_driver.svh"
  `include "sccb_monitor.svh"
  `include "sccb_agent.svh"
  `include "sccb_sequences.svh"
  `include "sccb_checker.svh"
  `include "sccb_coverage.svh"
endpackage
