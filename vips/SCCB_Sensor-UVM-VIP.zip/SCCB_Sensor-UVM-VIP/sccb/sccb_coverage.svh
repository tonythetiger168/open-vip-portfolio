// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sccb_coverage.svh -- SCCB functional coverage

class sccb_coverage extends uvm_subscriber #(sccb_transaction);
  `uvm_component_utils(sccb_coverage)
  sccb_config cfg;
  sccb_transaction tr;

  covergroup sccb_cg;
    cp_kind : coverpoint tr.ev.size() { bins empty = {[1:4]}; bins addr = {[5:14]}; bins short_t = {[15:40]}; bins long_t = {[41:200]}; }
    cp_rd   : coverpoint tr.rd.size() { bins none = {0}; bins one = {1}; bins some = {[2:8]}; }
    cp_ack  : coverpoint (tr.so.size() > 9 ? tr.so[9] : 1'b0) { bins nack = {0}; bins ack = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    sccb_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(sccb_config)::get(this, "", "cfg", cfg))
      cfg = sccb_config::type_id::create("cfg");
  endfunction

  function void write(sccb_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    sccb_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SCCB coverage: %0.1f%%", sccb_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
