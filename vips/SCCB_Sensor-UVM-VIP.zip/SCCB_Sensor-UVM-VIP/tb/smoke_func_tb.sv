// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SCCB DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened sccb_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic scl = 1'b1, sda_m_lo = 1'b0;
  wire sda_s_lo;
  integer q = 4;

  always #5 clk = ~clk;

  sccb_model u_dut (.clk(clk), .rst_n(rst_n), .scl(scl), .sda_m_lo(sda_m_lo), .sda_s_lo(sda_s_lo));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic s_at_rise;
  integer slo_hi = 0;
  logic pscl = 1'b1, pm = 1'b0;
  always @(posedge clk) begin
    if (scl && pscl && pm != sda_m_lo && sda_s_lo) slo_hi = slo_hi + 1;
    pscl <= scl; pm <= sda_m_lo;
  end
  task automatic start();
    @(negedge clk); sda_m_lo = 1; repeat (q) @(negedge clk);
    scl = 0; repeat (q) @(negedge clk);
  endtask
  task automatic bitc(input logic m, input logic last = 0);
    sda_m_lo = m; repeat (q) @(negedge clk);
    scl = 1; s_at_rise = sda_s_lo; repeat (q) @(negedge clk);
    if (!last) begin repeat (q) @(negedge clk); scl = 0; repeat (q) @(negedge clk); end
  endtask
  integer idle_lo = 0;
  task automatic stop();
    bitc(1, 1);
    sda_m_lo = 0;
    repeat (4 * q) begin @(negedge clk); if (sda_s_lo !== 1'b0) idle_lo = idle_lo + 1; end
  endtask
  task automatic rstart();
    bitc(0, 1);
    sda_m_lo = 1; repeat (q) @(negedge clk);
    scl = 0; repeat (q) @(negedge clk);
  endtask
  logic ack;
  task automatic wbyte(input logic [7:0] b);
    for (int i = 7; i >= 0; i--) bitc(!b[i]);
    bitc(0); ack = s_at_rise;
  endtask
  logic [7:0] rb [0:15];
  task automatic rbytes(input integer n);
    for (int j = 0; j < n; j++) begin
      for (int i = 7; i >= 0; i--) begin bitc(0); rb[j][i] = !s_at_rise; end
      bitc(j != n - 1);
    end
  endtask
  logic a0, a1, a2;
  task automatic wr(input logic [6:0] d, input logic [15:0] a, input integer n, input logic [7:0] v0);
    start(); wbyte({d, 1'b0}); a0 = ack; wbyte(a[15:8]); a1 = ack; wbyte(a[7:0]); a2 = ack;
    for (int i = 0; i < n; i++) wbyte(v0 + 8'h11 * i);
    stop();
  endtask
  task automatic rd(input logic [15:0] a, input integer n);
    start(); wbyte({7'h3C, 1'b0}); wbyte(a[15:8]); wbyte(a[7:0]);
    rstart(); wbyte({7'h3C, 1'b1}); a0 = ack; rbytes(n); stop();
  endtask

  initial begin
    repeat (3) @(posedge clk);
    chk(sda_s_lo === 1'b0, "SDA released in reset");
    rst_n = 1;
    repeat (8) @(negedge clk);
    rd(16'h0000, 2);
    chk(a0 && rb[0] == 8'h5A && rb[1] == 8'h31, "chip ID 5A 31");
    wr(7'h3C, 16'h0010, 4, 8'h21);
    chk(a0 && a1 && a2 && ack, "device address, register address and data bytes ACKed");
    rd(16'h0010, 4);
    chk(rb[0] == 8'h21 && rb[1] == 8'h32 && rb[2] == 8'h43 && rb[3] == 8'h54, "auto-increment write, repeated-START read");
    start(); wbyte(8'h78); wbyte(8'h00); wbyte(8'h12); stop();
    start(); wbyte(8'h79); a0 = ack; rbytes(2); stop();
    chk(a0 && rb[0] == 8'h43 && rb[1] == 8'h54, "SCCB two-phase read: pointer kept across STOP");
    start(); wbyte(8'h79); rbytes(1); stop();
    chk(rb[0] == 8'h00, "pointer advanced past the read bytes");
    wr(7'h3C, 16'h0000, 2, 8'h00);
    rd(16'h0000, 2);
    chk(rb[0] == 8'h5A && rb[1] == 8'h31, "chip ID is read only");
    wr(7'h3C, 16'h0233, 1, 8'h77);
    rd(16'h0233, 1);
    chk(ack && rb[0] == 8'h00, "unmapped register: write ACKed and ignored, reads 0");
    wr(7'h3C, 16'h01FE, 2, 8'hA0);
    rd(16'h01FE, 3);
    chk(rb[0] == 8'hA0 && rb[1] == 8'hB1 && rb[2] == 8'h00, "last registers, then 0 past 0x01FF");
    wr(7'h3D, 16'h0010, 1, 8'hEE);
    chk(!a0 && !a1 && !a2, "another device address: no ACK, bus ignored");
    rd(16'h0010, 1);
    chk(rb[0] == 8'h21, "and nothing written");
    start(); wbyte(8'h79 ^ 8'h02); a0 = ack; stop();
    chk(!a0, "read from another address: no ACK");
    start(); stop();
    rd(16'h0011, 1);
    chk(rb[0] == 8'h32, "an empty START / STOP changes nothing");
    start(); wbyte(8'h78); wbyte(8'h00); wbyte(8'h13); stop();
    start(); wbyte(8'h78); wbyte(8'h01); stop();
    start(); wbyte(8'h79); rbytes(1); stop();
    chk(rb[0] == 8'h54, "one address byte leaves the pointer unchanged");
    start(); wbyte(8'h78); wbyte(8'h00); wbyte(8'h20); wbyte(8'h99);
    rstart(); wbyte(8'h78); wbyte(8'h00); wbyte(8'h30); wbyte(8'h66); stop();
    rd(16'h0020, 1); a1 = (rb[0] == 8'h99);
    rd(16'h0030, 1);
    chk(a1 && rb[0] == 8'h66, "write, repeated START, write");
    start(); wbyte(8'h79); rbytes(3); stop();
    chk(rb[0] == 8'h00 && rb[1] == 8'h00 && rb[2] == 8'h00, "read with ACKs continues, NACK ends it");
    chk(slo_hi == 0, "the target never holds SDA low at a START or STOP");
    chk(idle_lo == 0, "the target leaves SDA alone on an idle bus");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
