# LPDDR5 UVM VIP

**Protocol Level:** Complex
**Checkers:** 4 UVM components (Protocol L1, Data Integrity L2, Timing L2, Error L3) + module-based SVA compliance checker (L1-L4)
**License:** Apache-2.0

## Protocol Overview
LPDDR5 low-power DRAM: WCK clocking, 8B/4B/4R bank modes, link ECC and DBI support.

The VIP drives and monitors a DDR-style command/address bus
(`cs_n/act_n/ras_n/cas_n/we_n` + `{bg,ba}` bank + `addr` row/column):

| Command | cs_n | act_n | ras_n | cas_n | we_n | Address |
|---------|------|-------|-------|-------|------|---------|
| ACT     | 0    | 0     | -     | -     | -    | row     |
| RD      | 0    | 1     | 1     | 0     | 1    | column  |
| WR      | 0    | 1     | 1     | 0     | 0    | column  |
| PRE     | 0    | 1     | 0     | 1     | 0    | -       |
| REF     | 0    | 1     | 0     | 0     | 1    | -       |
| NOP     | 0    | 1     | 1     | 1     | 1    | -       |

Core timing parameters (cycles): tRCD=12, tRP=12, tRAS=16, tCL=12, tCWL=2, tRFC=40, tREFI=3900.

## Architecture
```
lpddr5_vip/
|-- rtl/lpddr5_if.sv                    # signal interface (+ clocking block)
|-- sequences/lpddr5_sequence.sv        # transaction + directed sequence library
|-- vip/lpddr5/
|   |-- lpddr5_driver.sv                # protocol driver (cmd encoding, timing, DQ)
|   |-- lpddr5_monitor.sv               # bus monitor (command/DQ decode -> analysis port)
|   |-- lpddr5_agent.sv                 # sequencer + driver + monitor
|   |-- lpddr5_coverage.sv              # 3 covergroups with crosses
|   |-- lpddr5_compliance_checker.sv    # SVA module, L1-L4 (instanced in tb_top)
|   |-- lpddr5_protocol_checker.sv      # L1 component (procedural sampling)
|   |-- lpddr5_timing_checker.sv        # L2 component (tRCD/tRP/tRAS measurement)
|   |-- lpddr5_data_integrity_checker.sv# L2 component (DQ/DBI/BL sampling)
|   |-- lpddr5_error_checker.sv         # L3 component (temp/refresh/DFE monitoring)
|-- env/lpddr5_env.sv                   # env + end-to-end scoreboard
|-- tests/lpddr5_test.sv                # base/write/read/stress tests
|-- tb/tb_top.sv                     # TB top + DRAM memory-array functional model
|-- Makefile
```

Closed loop: sequences -> driver -> `lpddr5_if` -> `lpddr5_mem_model` (bank/row/col
storage in tb_top) drives read data back -> monitor decodes -> scoreboard
compares expected (driver) vs observed (monitor) end-to-end.

## Sequence Library
| Sequence | Purpose |
|----------|---------|
| `lpddr5_base_sequence` | legacy fully-random items (API compatibility) |
| `lpddr5_write_seq` | normal write flow: ACT, WR burst, PRE |
| `lpddr5_read_seq` | normal read flow: ACT, RD burst, PRE |
| `lpddr5_refresh_seq` | traffic punctuated by REF (tRFC apart) |
| `lpddr5_bank_conflict_seq` | same bank, alternating rows (page misses) |
| `lpddr5_back_to_back_seq` | one ACT, long alternating RD/WR stream (page hits) |
| `lpddr5_stress_seq` | long protocol-legal random stream (bank-state model) |
| `lpddr5_corner_seq` | all-zero/all-one row/col, boundary banks/stacks |
| `lpddr5_random_sequence` | 50 random items |
| `lpddr5_regression_sequence` | weighted mix of all directed sequences |

Tests: `lpddr5_base_test` (regression seq), `lpddr5_write_test`, `lpddr5_read_test`, `lpddr5_stress_test`.

## SVA Compliance Checker (vip/lpddr5/lpddr5_compliance_checker.sv)
- **L1 signal sanity (4):** command/address known when selected, bank group/address encoding bounds.
- **L2 timing & data integrity (8):** tRCD/tRP windows, burst length, data valid with DQS, DBI/WCK settings.
- **L3 error handling (6):** power-management state, refresh interval, over-temperature, DFE/bandwidth/latency bounds.
- **L4 LPDDR5-specific (10):** ACT/RD-WR/PRE bank-state legality (3), tRCD/tRP/tRAS timing rules (3), refresh pulse width, CKE gating, family rules (WCK2CK training bound + bank encoding), refresh-interval + ACT->col->PRE covers.

## Functional Coverage (vip/lpddr5/lpddr5_coverage.sv)
- `cg_command`    : command distribution x bank cross (`cx_cmd_bank`)
- `cg_bank_state` : bank state transitions (ACT=>RD/WR, RD/WR=>PRE, PRE/REF=>ACT, RD<=>WR)
- `cg_addr`       : row/col/stack address patterns with `cx_row_col` cross

## Quick Start
```bash
make comp                                   # compile (VCS + UVM 1.2)
make sim                                    # run default test
make regress                                # run regression test
./simv +UVM_TESTNAME=lpddr5_stress_test        # run a directed test
```
