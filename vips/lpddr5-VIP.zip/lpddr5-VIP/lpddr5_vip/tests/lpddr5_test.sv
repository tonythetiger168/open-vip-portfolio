// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpddr5_test.sv -- LPDDR5 UVM tests

`ifndef LPDDR5_TEST_SV
`define LPDDR5_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class lpddr5_base_test extends uvm_test;
  `uvm_component_utils(lpddr5_base_test)
  lpddr5_env env;
  function new(string name="lpddr5_base_test", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = lpddr5_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    lpddr5_regression_sequence seq;
    phase.raise_objection(this);
    seq = lpddr5_regression_sequence::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: write flow only
class lpddr5_write_test extends lpddr5_base_test;
  `uvm_component_utils(lpddr5_write_test)
  function new(string name="lpddr5_write_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    lpddr5_write_seq seq;
    phase.raise_objection(this);
    seq = lpddr5_write_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: read flow + refresh flow
class lpddr5_read_test extends lpddr5_base_test;
  `uvm_component_utils(lpddr5_read_test)
  function new(string name="lpddr5_read_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    lpddr5_read_seq    rd;
    lpddr5_refresh_seq rf;
    phase.raise_objection(this);
    rd = lpddr5_read_seq::type_id::create("rd");
    rf = lpddr5_refresh_seq::type_id::create("rf");
    rd.start(env.agt.sqr);
    rf.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress test: long protocol-legal random stream
class lpddr5_stress_test extends lpddr5_base_test;
  `uvm_component_utils(lpddr5_stress_test)
  function new(string name="lpddr5_stress_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    lpddr5_stress_seq seq;
    phase.raise_objection(this);
    seq = lpddr5_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
