// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpddr5_compliance_checker.sv -- LPDDR5 SVA compliance checker
// L1 = signal sanity, L2 = timing & data integrity, L3 = error handling,
// L4 = LPDDR5 protocol-specific rules (timing parameters, bank-state
// legality, refresh servicing). Instantiated in tb_top.
// LPDDR5 low-power DRAM: WCK clocking, 8B/4B/4R bank modes, link ECC and DBI support.

`ifndef LPDDR5_COMPLIANCE_CHECKER_SV
`define LPDDR5_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module lpddr5_compliance_checker (lpddr5_if vif);

  // ---------------- L1: signal sanity (4) ----------------
  property p_lpddr5_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_lpddr5_cmd_valid: assert property(p_lpddr5_cmd_valid) else `uvm_warning("LPDDR5_L1", "Command valid failed");
  cover_p_lpddr5_cmd_valid: cover property(p_lpddr5_cmd_valid);
  property p_lpddr5_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_lpddr5_addr_valid: assert property(p_lpddr5_addr_valid) else `uvm_warning("LPDDR5_L1", "Address valid failed");
  cover_p_lpddr5_addr_valid: cover property(p_lpddr5_addr_valid);
  property p_lpddr5_bg; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bg <= 2'd3; endproperty
  assert_p_lpddr5_bg: assert property(p_lpddr5_bg) else `uvm_warning("LPDDR5_L1", "Bank group 0-3 failed");
  cover_p_lpddr5_bg: cover property(p_lpddr5_bg);
  property p_lpddr5_ba; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ba <= 2'd3; endproperty
  assert_p_lpddr5_ba: assert property(p_lpddr5_ba) else `uvm_warning("LPDDR5_L1", "Bank address 0-3 failed");
  cover_p_lpddr5_ba: cover property(p_lpddr5_ba);

  // ---------------- L2: timing & data integrity (8) ----------------
  property p_lpddr5_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cs_n) |-> ##[10:14] vif.ca[4] == 0; endproperty
  assert_p_lpddr5_tRCD: assert property(p_lpddr5_tRCD) else `uvm_warning("LPDDR5_TIM", "tRCD 10-14 cycles violated");
  cover_p_lpddr5_tRCD: cover property(p_lpddr5_tRCD);
  property p_lpddr5_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.cs_n) |-> ##[10:14] $fell(vif.cs_n); endproperty
  assert_p_lpddr5_tRP: assert property(p_lpddr5_tRP) else `uvm_warning("LPDDR5_TIM", "tRP 10-14 cycles violated");
  cover_p_lpddr5_tRP: cover property(p_lpddr5_tRP);
  property p_lpddr5_bl; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {4'b1000,4'b1001}; endproperty
  assert_p_lpddr5_bl: assert property(p_lpddr5_bl) else `uvm_warning("LPDDR5_L2", "Burst length 8/16 failed");
  cover_p_lpddr5_bl: cover property(p_lpddr5_bl);
  property p_lpddr5_wck_ratio; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_lpddr5_wck_ratio: assert property(p_lpddr5_wck_ratio) else `uvm_warning("LPDDR5_L2", "WCK ratio failed");
  cover_p_lpddr5_wck_ratio: cover property(p_lpddr5_wck_ratio);
  property p_lpddr5_dmi; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dqs_t == 1 && vif.ca[4] == 0 |-> vif.dmi_t == 1; endproperty
  assert_p_lpddr5_dmi: assert property(p_lpddr5_dmi) else `uvm_warning("LPDDR5_L2", "DMI on write failed");
  cover_p_lpddr5_dmi: cover property(p_lpddr5_dmi);
  property p_lpddr5_dbim; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dbim inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_lpddr5_dbim: assert property(p_lpddr5_dbim) else `uvm_warning("LPDDR5_L2", "DBI mode failed");
  cover_p_lpddr5_dbim: cover property(p_lpddr5_dbim);
  property p_lpddr5_crc; @(posedge vif.ck) disable iff (!vif.rst_n) vif.crc_en == 1 && vif.we_n == 0 |-> vif.crc != 8'h00; endproperty
  assert_p_lpddr5_crc: assert property(p_lpddr5_crc) else `uvm_warning("LPDDR5_L2", "CRC on write failed");
  cover_p_lpddr5_crc: cover property(p_lpddr5_crc);
  property p_lpddr5_odt; @(posedge vif.ck) disable iff (!vif.rst_n) vif.odt_ca == 1 |-> vif.cs_n == 0; endproperty
  assert_p_lpddr5_odt: assert property(p_lpddr5_odt) else `uvm_warning("LPDDR5_L2", "ODT-CA active failed");
  cover_p_lpddr5_odt: cover property(p_lpddr5_odt);

  // ---------------- L3: error handling (6) ----------------
  property p_lpddr5_pm; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_lpddr5_pm: assert property(p_lpddr5_pm) else `uvm_warning("LPDDR5_L3", "Power management failed");
  cover_p_lpddr5_pm: cover property(p_lpddr5_pm);
  property p_lpddr5_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.refresh |-> ##[1:3900] vif.cs_n == 0; endproperty
  assert_p_lpddr5_refresh: assert property(p_lpddr5_refresh) else `uvm_warning("LPDDR5_L3", "Refresh interval failed");
  cover_p_lpddr5_refresh: cover property(p_lpddr5_refresh);
  property p_lpddr5_vrefca; @(posedge vif.ck) disable iff (!vif.rst_n) vif.vrefca_train |-> vif.cs_n == 0; endproperty
  assert_p_lpddr5_vrefca: assert property(p_lpddr5_vrefca) else `uvm_warning("LPDDR5_L3", "VrefCA training failed");
  cover_p_lpddr5_vrefca: cover property(p_lpddr5_vrefca);
  property p_lpddr5_temp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp_sensor <= 8'd127; endproperty
  assert_p_lpddr5_temp: assert property(p_lpddr5_temp) else `uvm_warning("LPDDR5_L3", "Temperature sensor failed");
  cover_p_lpddr5_temp: cover property(p_lpddr5_temp);
  property p_lpddr5_wck2ck; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck2ck_train |-> vif.wck_ratio > 0; endproperty
  assert_p_lpddr5_wck2ck: assert property(p_lpddr5_wck2ck) else `uvm_warning("LPDDR5_L3", "WCK2CK training failed");
  cover_p_lpddr5_wck2ck: cover property(p_lpddr5_wck2ck);
  property p_lpddr5_rdqs; @(posedge vif.ck) disable iff (!vif.rst_n) vif.rdqs == 1 |-> vif.cs_n == 0; endproperty
  assert_p_lpddr5_rdqs: assert property(p_lpddr5_rdqs) else `uvm_warning("LPDDR5_L3", "RDQS valid failed");
  cover_p_lpddr5_rdqs: cover property(p_lpddr5_rdqs);

  // ---------------- L4: LPDDR5 protocol-specific rules (10) ----------------
  localparam int L4_TRCD  = 12;
  localparam int L4_TRP   = 12;
  localparam int L4_TRAS  = 16;
  localparam int L4_TRFC  = 40;
  localparam int L4_TREFI = 3900;

  // Command decode (mirrors the driver/monitor truth table)
  wire l4_act = (!vif.cs_n) && (!vif.act_n);
  wire l4_rd  = (!vif.cs_n) && vif.act_n && vif.ras_n && (!vif.cas_n) && vif.we_n;
  wire l4_wr  = (!vif.cs_n) && vif.act_n && vif.ras_n && (!vif.cas_n) && (!vif.we_n);
  wire l4_col = l4_rd || l4_wr;
  wire l4_pre = (!vif.cs_n) && vif.act_n && (!vif.ras_n) && vif.cas_n && (!vif.we_n);
  wire l4_ref = (!vif.cs_n) && vif.act_n && (!vif.ras_n) && (!vif.cas_n) && vif.we_n;
  wire [4:0] l4_bidx = {vif.bg, vif.ba};

  // Bank open/close state used by the legality rules below
  bit [31:0] l4_open;
  always @(posedge vif.ck or negedge vif.rst_n) begin
    if (!vif.rst_n) l4_open <= '0;
    else begin
      if (l4_act) l4_open[l4_bidx] <= 1'b1;
      if (l4_pre) l4_open[l4_bidx] <= 1'b0;
      if (l4_ref) l4_open <= '0;
    end
  end

  // L4-1: ACT may only target a closed (precharged) bank
  a_lpddr5_l4_act_closed : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> !l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "lpddr5: ACT issued to an already-active bank")
  // L4-2: RD/WR may only target an activated bank
  a_lpddr5_l4_col_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_col |-> l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "lpddr5: RD/WR to a non-activated bank")
  // L4-3: PRE may only target an activated bank
  a_lpddr5_l4_pre_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_pre |-> l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "lpddr5: PRE to a non-activated bank")
  // L4-4: tRCD -- no column command within tRCD cycles after ACT
  a_lpddr5_l4_trcd : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> ##1 (!l4_col)[*(L4_TRCD-1)])
    else `uvm_error("SVA_L4", "lpddr5: tRCD violation (column command too soon after ACT)")
  // L4-5: tRP -- no ACT within tRP cycles after PRE
  a_lpddr5_l4_trp : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_pre |-> ##1 (!l4_act)[*(L4_TRP-1)])
    else `uvm_error("SVA_L4", "lpddr5: tRP violation (ACT too soon after PRE)")
  // L4-6: tRAS -- no PRE within tRAS cycles after ACT
  a_lpddr5_l4_tras : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> ##1 (!l4_pre)[*(L4_TRAS-1)])
    else `uvm_error("SVA_L4", "lpddr5: tRAS violation (PRE too soon after ACT)")
  // L4-7: refresh pulse must complete within tRFC (+2) cycles
  a_lpddr5_l4_ref_pulse : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    $rose(vif.refresh) |-> ##[1:(L4_TRFC+2)] $fell(vif.refresh))
    else `uvm_error("SVA_L4", "lpddr5: refresh pulse wider than tRFC")
  // L4-8: commands require CKE high
  a_lpddr5_l4_cke : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    (!vif.cs_n && !vif.act_n) |-> vif.cke)
    else `uvm_error("SVA_L4", "lpddr5: command issued while CKE low")

  // L4-9 (LPDDR5): WCK2CK training is a bounded handshake
  a_lpddr5_l4_wck_train : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    $rose(vif.wck2ck_train) |-> ##[1:16] $fell(vif.wck2ck_train))
    else `uvm_error("SVA_L4", "lpddr5: WCK2CK training not completed")
  // L4-10 (LPDDR5): bank-group architecture limits bg/ba encodings
  a_lpddr5_l4_bank_enc : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> (vif.bg <= 3'd3 && vif.ba <= 2'd3))
    else `uvm_error("SVA_L4", "lpddr5: illegal bank encoding on ACT")

  // Refresh must be serviced again within tREFI after each REF command
  c_lpddr5_l4_ref_interval : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_ref ##[1:(L4_TREFI)] l4_ref);
  // Full ACT -> column -> PRE bank cycle observed
  c_lpddr5_l4_rw_cycle : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act ##[1:64] l4_col ##[1:64] l4_pre);

endmodule
`endif
