// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpddr5_agent.sv -- LPDDR5 UVM agent (sequencer + driver + monitor)

`ifndef LPDDR5_AGENT_SV
`define LPDDR5_AGENT_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
typedef class lpddr5_driver;
typedef class lpddr5_monitor;

class lpddr5_agent extends uvm_agent;
  `uvm_component_utils(lpddr5_agent)
  uvm_sequencer #(lpddr5_transaction) sqr;
  lpddr5_driver  drv;
  lpddr5_monitor mon;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    sqr = uvm_sequencer #(lpddr5_transaction)::type_id::create("sqr", this);
    drv = lpddr5_driver::type_id::create("drv", this);
    mon = lpddr5_monitor::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
