// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_env.sv -- Multi-speed Ethernet environment
// Instantiates agents for all supported protocols/speeds

`ifndef NET_ENV_SV
`define NET_ENV_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

class net_env extends uvm_env;
  `uvm_component_utils(net_env)
  // Protocol agents
  net_agent eth_1g_agent;
  net_agent eth_100g_agent;
  net_agent eth_400g_agent;
  net_agent eth_800g_agent;
  net_agent eth_1p6t_agent;
  net_agent uec_agent;
  net_agent fc_agent;
  // Scoreboard
  net_scoreboard sb;
  // Protocol checkers
  eth_protocol_checker eth_chk;
  uec_protocol_checker uec_chk;
  fc_protocol_checker  fc_chk;
  // Coverage
  net_coverage_model eth_cov;
  net_coverage_model uec_cov;
  net_coverage_model fc_cov;

  // Configuration
  bit enable_eth_1g = 1;
  bit enable_eth_100g = 1;
  bit enable_eth_400g = 1;
  bit enable_eth_800g = 1;
  bit enable_eth_1p6t = 1;
  bit enable_uec = 1;
  bit enable_fc = 1;

  function new(string name = "net_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function automatic net_agent make_agent(string name, net_protocol_e p, string vif_name);
    net_agent a = net_agent::type_id::create(name, this);
    net_protocol_config pc = new($sformatf("%s_cfg", name), p);
    virtual net_vip_if v;
    uvm_config_db#(net_protocol_e)::set(a, "", "protocol", p);
    uvm_config_db#(net_protocol_cfg_t)::set(a, "", "cfg", pc.cfg);
    if (uvm_config_db#(virtual net_vip_if)::get(this, "", vif_name, v))
      uvm_config_db#(virtual net_vip_if)::set(a, "*", "vif", v);
    else
      `uvm_fatal("CONFIG", $sformatf("env: %s not found", vif_name))
    return a;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(bit)::get(this, "", "enable_eth_1g", enable_eth_1g));
    void'(uvm_config_db#(bit)::get(this, "", "enable_eth_100g", enable_eth_100g));
    void'(uvm_config_db#(bit)::get(this, "", "enable_eth_400g", enable_eth_400g));
    void'(uvm_config_db#(bit)::get(this, "", "enable_eth_800g", enable_eth_800g));
    void'(uvm_config_db#(bit)::get(this, "", "enable_eth_1p6t", enable_eth_1p6t));
    void'(uvm_config_db#(bit)::get(this, "", "enable_uec", enable_uec));
    void'(uvm_config_db#(bit)::get(this, "", "enable_fc", enable_fc));

    if (enable_eth_1g)   eth_1g_agent   = make_agent("eth_1g_agent", NET_ETH_1G, "eth_1g_vif");
    if (enable_eth_100g) eth_100g_agent = make_agent("eth_100g_agent", NET_ETH_100G, "eth_100g_vif");
    if (enable_eth_400g) eth_400g_agent = make_agent("eth_400g_agent", NET_ETH_400G, "eth_400g_vif");
    if (enable_eth_800g) eth_800g_agent = make_agent("eth_800g_agent", NET_ETH_800G, "eth_800g_vif");
    if (enable_eth_1p6t) eth_1p6t_agent = make_agent("eth_1p6t_agent", NET_ETH_1P6T, "eth_1p6t_vif");
    if (enable_uec)      uec_agent      = make_agent("uec_agent", NET_UEC, "uec_vif");
    if (enable_fc)       fc_agent       = make_agent("fc_agent", NET_FC, "fc_vif");

    sb = net_scoreboard::type_id::create("sb", this);

    eth_chk = eth_protocol_checker::type_id::create("eth_chk", this);
    uec_chk = uec_protocol_checker::type_id::create("uec_chk", this);
    fc_chk  = fc_protocol_checker::type_id::create("fc_chk", this);

    eth_cov = net_coverage_model::type_id::create("eth_cov", this);
    uec_cov = net_coverage_model::type_id::create("uec_cov", this);
    fc_cov  = net_coverage_model::type_id::create("fc_cov", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (eth_1g_agent != null) begin
      eth_1g_agent.mon.analysis_port.connect(eth_cov.analysis_imp);
      eth_1g_agent.mon.analysis_port.connect(sb.obs_ap);
      if (eth_1g_agent.drv != null) eth_1g_agent.drv.drv_ap.connect(sb.exp_ap);
    end
    if (eth_100g_agent != null)
      eth_100g_agent.mon.analysis_port.connect(eth_cov.analysis_imp);
    if (eth_400g_agent != null)
      eth_400g_agent.mon.analysis_port.connect(eth_cov.analysis_imp);
    if (eth_800g_agent != null)
      eth_800g_agent.mon.analysis_port.connect(eth_cov.analysis_imp);
    if (eth_1p6t_agent != null)
      eth_1p6t_agent.mon.analysis_port.connect(eth_cov.analysis_imp);
    if (uec_agent != null) begin
      uec_agent.mon.analysis_port.connect(uec_cov.analysis_imp);
      // UEC end-to-end: driver-issued (expected) vs monitor-decoded (observed)
      uec_agent.mon.analysis_port.connect(sb.obs_ap);
      if (uec_agent.drv != null) uec_agent.drv.drv_ap.connect(sb.exp_ap);
    end
    if (fc_agent != null)
      fc_agent.mon.analysis_port.connect(fc_cov.analysis_imp);
  endfunction

  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("ENV", "Net Environment Done", UVM_LOW)
    if (uec_cov != null)
      `uvm_info("COV", $sformatf("UEC coverage = %0.2f%%", uec_cov.get_coverage()), UVM_LOW)
  endfunction
endclass
`endif
