// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_random_sequence.sv -- Random frame sequence for a target protocol

`ifndef NET_RANDOM_SEQUENCE_SV
`define NET_RANDOM_SEQUENCE_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

class net_random_sequence extends net_base_sequence;
  `uvm_object_utils(net_random_sequence)
  rand bit enable_eth;
  rand bit enable_uec;
  rand bit enable_fc;

  function new(string name = "net_random_sequence");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info("SEQ", $sformatf("Random sequence: %0d frames for %s",
              num_frames, target_protocol.name()), UVM_LOW)
    repeat (num_frames) begin
      net_sequence_item item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.ethertype != 16'hEEEE; })
        `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
