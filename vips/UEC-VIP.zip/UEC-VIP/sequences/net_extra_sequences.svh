// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_extra_sequences.svh -- additional directed sequences
// (back-to-back / stress / reset / corner / error-inject), included from
// net_regression_sequence.sv so the fixed Makefile file list covers them.

`ifndef NET_EXTRA_SEQUENCES_SVH
`define NET_EXTRA_SEQUENCES_SVH

// Directed: back-to-back frames with minimum IFG
class net_back_to_back_sequence extends net_base_sequence;
  `uvm_object_utils(net_back_to_back_sequence)
  function new(string name = "net_back_to_back_sequence");
    super.new(name);
  endfunction
  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.ethertype != 16'hEEEE;
                                   txn.ifg_cycles == 12;
                                   txn.delay_cycles == 0;
                                   txn.payload_len inside {[46:128]}; })
        `uvm_error("SEQ", "B2B randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Stress: high-volume jumbo frames
class net_stress_sequence extends net_base_sequence;
  `uvm_object_utils(net_stress_sequence)
  function new(string name = "net_stress_sequence");
    super.new(name);
  endfunction
  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.ethertype != 16'hEEEE;
                                   txn.payload_len inside {[1500:4500]}; })
        `uvm_error("SEQ", "Stress randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Reset behavior: single frame right after reset release
class net_reset_sequence extends net_base_sequence;
  `uvm_object_utils(net_reset_sequence)
  function new(string name = "net_reset_sequence");
    super.new(name);
  endfunction
  virtual task body();
    net_sequence_item item = net_sequence_item::type_id::create("item");
    start_item(item);
    if (!item.randomize() with { txn.protocol == target_protocol;
                                 txn.ethertype != 16'hEEEE;
                                 txn.payload_len == 64;
                                 txn.delay_cycles == 0; })
      `uvm_error("SEQ", "Reset randomization failed")
    finish_item(item);
  endtask
endclass

// Corner case: min (46B) / MTU-boundary / jumbo frames
class net_corner_sequence extends net_base_sequence;
  `uvm_object_utils(net_corner_sequence)
  function new(string name = "net_corner_sequence");
    super.new(name);
  endfunction
  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.ethertype != 16'hEEEE;
                                   txn.payload_len inside {46, 64, 1500, 1518, 2048}; })
        `uvm_error("SEQ", "Corner randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Error injection: frames with the FCS error ethertype (0xEEEE) and bad CRC
class net_error_inject_sequence extends net_base_sequence;
  `uvm_object_utils(net_error_inject_sequence)
  function new(string name = "net_error_inject_sequence");
    super.new(name);
  endfunction
  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.ethertype == 16'hEEEE;
                                   txn.inject_crc_error == 1;
                                   txn.payload_len inside {[46:256]}; })
        `uvm_error("SEQ", "Error-inject randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
