// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_base_sequence.sv -- Multi-speed Ethernet base sequence

`ifndef NET_BASE_SEQUENCE_SV
`define NET_BASE_SEQUENCE_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

class net_base_sequence extends uvm_sequence #(net_sequence_item);
  `uvm_object_utils(net_base_sequence)
  rand int num_frames;
  rand net_protocol_e target_protocol;
  constraint c_num_frames { num_frames inside {[10:1000]}; }

  function new(string name = "net_base_sequence");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info("SEQ", $sformatf("Starting %0d frames for %s",
              num_frames, target_protocol.name()), UVM_LOW)
    repeat (num_frames) begin
      net_sequence_item item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol;
                                   txn.ethertype != 16'hEEEE; })
        `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
