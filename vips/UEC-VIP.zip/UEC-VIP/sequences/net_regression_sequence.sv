// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_regression_sequence.sv -- Coverage-driven regression sequence
// (random phases + directed-sequence phase)

`ifndef NET_REGRESSION_SEQUENCE_SV
`define NET_REGRESSION_SEQUENCE_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

`include "net_extra_sequences.svh"

class net_regression_sequence extends uvm_sequence #(net_sequence_item);
  `uvm_object_utils(net_regression_sequence)
  rand int eth_weight;
  rand int uec_weight;
  rand int fc_weight;
  constraint c_weights {
    eth_weight inside {[1:10]}; uec_weight inside {[1:10]}; fc_weight inside {[1:10]};
  }

  function new(string name = "net_regression_sequence");
    super.new(name);
  endfunction

  virtual task body();
    net_random_sequence seq;
    int total = 3000;
    `uvm_info("REGRESSION", "Starting Coverage-Driven Random Regression", UVM_LOW)

    // Phase 1: Ethernet (1G baseline)
    seq = net_random_sequence::type_id::create("eth_seq");
    seq.num_frames = total * eth_weight / (eth_weight+uec_weight+fc_weight);
    seq.target_protocol = NET_ETH_1G;
    seq.start(m_sequencer);

    // Phase 2: UEC (deepened VIP target)
    seq = net_random_sequence::type_id::create("uec_seq");
    seq.num_frames = total * uec_weight / (eth_weight+uec_weight+fc_weight);
    seq.target_protocol = NET_UEC;
    seq.start(m_sequencer);

    // Phase 3: Directed sequences on the target protocol
    begin
      net_back_to_back_sequence b2b = net_back_to_back_sequence::type_id::create("b2b");
      net_stress_sequence       str = net_stress_sequence::type_id::create("str");
      net_reset_sequence        rst = net_reset_sequence::type_id::create("rst");
      net_corner_sequence       cor = net_corner_sequence::type_id::create("cor");
      net_error_inject_sequence err = net_error_inject_sequence::type_id::create("err");
      b2b.num_frames = 100; b2b.target_protocol = NET_UEC;
      str.num_frames = 100; str.target_protocol = NET_UEC;
      rst.target_protocol = NET_UEC;
      cor.num_frames = 50;  cor.target_protocol = NET_UEC;
      err.num_frames = 20;  err.target_protocol = NET_UEC;
      b2b.start(m_sequencer);
      str.start(m_sequencer);
      rst.start(m_sequencer);
      cor.start(m_sequencer);
      err.start(m_sequencer);
    end
    `uvm_info("REGRESSION", "Regression Sequence Complete", UVM_LOW)
  endtask
endclass
`endif
