// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_coverage.svh -- UEC functional coverage

class uec_coverage extends uvm_subscriber #(uec_transaction);
  `uvm_component_utils(uec_coverage)
  uec_config cfg;
  uec_transaction tr;

  covergroup uec_cg;
    coverpoint tr.tx_valid;
    coverpoint tr.tx_data;
    coverpoint tr.tx_len;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(uec_config)::get(this, "*", "cfg", cfg));
    uec_cg = new();
  endfunction

  function void write(uec_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    uec_cg.sample();
  endfunction
endclass
