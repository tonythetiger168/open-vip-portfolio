// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_if.sv -- UEC interface

interface uec_if (input logic clk);
  logic rst_n;

  logic tx_valid;
  logic [511:0] tx_data;
  logic [10:0] tx_len;
  logic tx_ready;
  logic rx_valid;
  logic [511:0] rx_data;
  logic [10:0] rx_len;
  logic rx_err;

  modport DUT (input clk, rst_n, tx_valid, tx_data, tx_len, output tx_ready, rx_valid, rx_data, rx_len, rx_err);
  modport DRV (input clk, rst_n, tx_ready, rx_valid, rx_data, rx_len, rx_err, output tx_valid, tx_data, tx_len);
  modport MON (input clk, rst_n, tx_valid, tx_data, tx_len, tx_ready, rx_valid, rx_data, rx_len, rx_err);

  clocking drv_cb @(posedge clk);
    input rst_n, tx_valid, tx_data, tx_len, tx_ready, rx_valid, rx_data, rx_len, rx_err;
    output tx_valid, tx_data, tx_len;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, tx_valid, tx_data, tx_len, tx_ready, rx_valid, rx_data, rx_len, rx_err;
  endclocking
endinterface
