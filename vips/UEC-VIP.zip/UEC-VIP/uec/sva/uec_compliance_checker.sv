// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_compliance_checker.sv -- UEC concurrent assertion checks (bindable)

module uec_compliance_checker
  (input logic clk, input logic rst_n, input tx_valid, input [511:0] tx_data, input [10:0] tx_len, input tx_ready, input rx_valid, input [511:0] rx_data, input [10:0] rx_len, input rx_err);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tx_ready, rx_valid, rx_data, rx_len, rx_err}))
    else $error("UEC: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> tx_ready == '0)
    else $error("UEC: output not in reset value");
  assert property (@(posedge clk) disable iff (!rst_n) rx_err |=> !rx_err)
    else $error("UEC: rx_err not a pulse");
  assert property (@(posedge clk) disable iff (!rst_n) rx_valid |-> $past(v2, 2) || $past(bad2, 2) == 1'b0)
    else $error("UEC: rx_valid without staged flit");
  cover property (@(posedge clk) disable iff (!rst_n) (tx_ready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (tx_valid && (tx_len < 11'd64 || tx_len > 11'd1518)));
endmodule
