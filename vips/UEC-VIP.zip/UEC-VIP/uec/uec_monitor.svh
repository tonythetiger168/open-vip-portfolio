// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_monitor.svh -- UEC monitor: decodes observed bus activity

class uec_monitor extends uvm_monitor;
  `uvm_component_utils(uec_monitor)

  virtual uec_if vif;
  uvm_analysis_port #(uec_transaction) ap;
  uec_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual uec_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "uec: virtual interface not set")
    void'(uvm_config_db#(uec_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    uec_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = uec_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.tx_valid = vif.tx_valid;
        t.tx_data = vif.tx_data;
        t.tx_len = vif.tx_len;
        t.tx_ready_o = vif.tx_ready;
        t.rx_valid_o = vif.rx_valid;
        t.rx_data_o = vif.rx_data;
        t.rx_len_o = vif.rx_len;
        t.rx_err_o = vif.rx_err;
        ap.write(t);
      end
    end
  endtask
endclass
