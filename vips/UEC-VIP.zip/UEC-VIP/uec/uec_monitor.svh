// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_monitor.svh -- UEC monitor: transmitted packets paired in order with rx_valid / rx_err

class uec_monitor extends uvm_monitor;
  `uvm_component_utils(uec_monitor)

  virtual uec_if vif;
  uvm_analysis_port #(uec_transaction) ap;
  uec_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual uec_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "uec: virtual interface not set")
    if (!uvm_config_db#(uec_config)::get(this, "", "cfg", cfg))
      cfg = uec_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      uec_transaction in_q[$];
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rx_valid || vif.mon_cb.rx_err) begin
          if (in_q.size() == 0) `uvm_error("MON", "UEC rx_valid/rx_err with no packet in flight")
          else begin
            uec_transaction t = in_q.pop_front();
            if (vif.mon_cb.rx_valid && vif.mon_cb.rx_err) `uvm_error("MON", "UEC rx_valid and rx_err together")
            t.err     = vif.mon_cb.rx_err;
            t.rx_data = t.err ? '0 : vif.mon_cb.rx_data;
            t.rx_len  = t.err ? '0 : vif.mon_cb.rx_len;
            publish(t);
          end
        end
        if (vif.mon_cb.tx_valid && vif.mon_cb.tx_ready) begin
          uec_transaction t = uec_transaction::type_id::create("t");
          t.data = vif.mon_cb.tx_data;
          t.len  = vif.mon_cb.tx_len;
          in_q.push_back(t);
        end
      end
    end
  endtask

  function void publish(uec_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
