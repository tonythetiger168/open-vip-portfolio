// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_transaction.svh -- UEC transaction

class uec_transaction extends uvm_sequence_item;
  `uvm_object_utils(uec_transaction)

  rand bit tx_valid;
  rand bit [511:0] tx_data;
  rand bit [10:0] tx_len;
  bit tx_ready_o;
  bit rx_valid_o;
  bit [511:0] rx_data_o;
  bit [10:0] rx_len_o;
  bit rx_err_o;
  bit [31:0] tag;

  function new(string name = "uec_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    uec_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    tx_valid = rhs_.tx_valid;
    tx_data = rhs_.tx_data;
    tx_len = rhs_.tx_len;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    uec_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           tx_valid == rhs_.tx_valid &&
           tx_data == rhs_.tx_data &&
           tx_len == rhs_.tx_len;
  endfunction

  function string convert2string();
    return $sformatf("UEC{tag=%0h tx_valid=0x%0h tx_data=0x%0h tx_len=0x%0h}", tag, tx_valid, tx_data, tx_len);
  endfunction
endclass
