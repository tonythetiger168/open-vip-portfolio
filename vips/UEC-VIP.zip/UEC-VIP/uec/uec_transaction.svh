// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_transaction.svh -- UEC transaction

class uec_transaction extends uvm_sequence_item;
  `uvm_object_utils(uec_transaction)

  // request (driven by the agent)
  rand bit [10:0] len;
  bit [511:0] data;
  // response (returned by the DUT)
  bit err;
  bit [511:0] rx_data;
  bit [10:0] rx_len;
  // bookkeeping (not compared)
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)

  bit [511:0] dq[$];


  constraint c_len { len dist { [64:1518] :/ 8, [0:63] :/ 1, [1519:2047] :/ 1, 64 := 1, 1518 := 1 }; }

  function new(string name = "uec_transaction"); super.new(name); endfunction

  function void fill_dq(int unsigned n);
    bit [31:0] x = seed | 32'h1;
    dq.delete();
    for (int unsigned i = 0; i < n; i++) begin
      bit [511:0] v;
      for (int k = 0; k < 16; k++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        v = (v << 32) | 512'(x);
      end
      dq.push_back(v);
    end
  endfunction

  function void post_randomize();
    fill_dq(1);
    data = dq[0];
  endfunction

  function void do_copy(uvm_object rhs);
    uec_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    len = rhs_.len;
    data = rhs_.data;
    err = rhs_.err;
    rx_data = rhs_.rx_data;
    rx_len = rhs_.rx_len;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    uec_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (len != rhs_.len) return 0;
    if (data != rhs_.data) return 0;
    if (err != rhs_.err) return 0;
    if (rx_data != rhs_.rx_data) return 0;
    if (rx_len != rhs_.rx_len) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(uec_transaction rhs_);
    if (len != rhs_.len) return 0;
    if (data != rhs_.data) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("UEC{tag=%0d len=0x%0h data=0x%0h err=0x%0h rx_data=0x%0h rx_len=0x%0h}", tag, len, data, err, rx_data, rx_len);
  endfunction
endclass
