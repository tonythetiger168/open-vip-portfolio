// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_sequences.svh -- UEC sequences

// Random traffic: cfg.num_items constrained-random items.
class uec_base_sequence extends uvm_sequence #(uec_transaction);
  `uvm_object_utils(uec_base_sequence)
  uec_config cfg;

  function new(string name = "uec_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = uec_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "uec_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class uec_directed_sequence extends uvm_sequence #(uec_transaction);
  `uvm_object_utils(uec_directed_sequence)
  uec_config cfg;

  function new(string name = "uec_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function uec_transaction item();
    item = uec_transaction::type_id::create("req");
  endfunction

  task send(uec_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    uec_transaction t;
    int unsigned lens [8] = '{64, 1518, 63, 1519, 0, 2047, 65, 1000};
    foreach (lens[i]) begin
      t = item(); t.len = lens[i]; t.seed = 32'h5EED + i; t.fill_dq(1); t.data = t.dq[0]; send(t);
    end
  endtask
endclass
