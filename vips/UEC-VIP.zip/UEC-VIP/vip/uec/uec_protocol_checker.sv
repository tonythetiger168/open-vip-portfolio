// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// uec_protocol_checker.sv -- UEC Protocol Checker (Ultra Ethernet Consortium)

`ifndef UEC_PROTOCOL_CHECKER_SV
`define UEC_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

// ============================================================================
// uec_protocol_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module uec_protocol_checker_sva (net_vip_if vif);

    int vc_err_cnt = 0;
  int cong_err_cnt = 0;
  int hsk_err_cnt = 0;
  int pfc_err_cnt = 0;

    initial begin
    end


  property p_uec_vc_range;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid) |-> vif.uec_vc inside {[4'h0:4'hF]};
  endproperty
  assert_uec_vc_range: assert property(p_uec_vc_range)
  else begin
    `uvm_error("UEC_CHK", "UEC VC out of range")
    vc_err_cnt++;
  end

  property p_uec_congestion;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.uec_congestion <= 8'hFF;
  endproperty
  assert_uec_congestion: assert property(p_uec_congestion)
  else begin
    `uvm_error("UEC_CHK", "UEC congestion field illegal")
    cong_err_cnt++;
  end

  property p_uec_handshake;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.valid |-> ##[1:100] vif.ready;
  endproperty
  assert_uec_handshake: assert property(p_uec_handshake)
  else begin
    `uvm_error("UEC_CHK", "UEC valid-ready timeout")
    hsk_err_cnt++;
  end

  property p_uec_pfc;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.pfc_frame |-> vif.link_up;
  endproperty
  assert_uec_pfc: assert property(p_uec_pfc)
  else begin
    `uvm_error("UEC_CHK", "PFC frame while link down")
    pfc_err_cnt++;
  end

  final begin
    `uvm_info("UEC_RPT", $sformatf("UEC Chk report"), UVM_LOW)
    end
endmodule

// ============================================================================
// uec_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the uec_protocol_checker_sva module above)
// ============================================================================
class uec_protocol_checker extends uvm_component;
  `uvm_component_utils(uec_protocol_checker)
  function new(string name = "uec_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
