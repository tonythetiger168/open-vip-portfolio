// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_monitor.sv -- Multi-speed Ethernet monitor: decodes SOP/EOP-framed
// MAC frames from the bus (header capture, payload unpacking, error-flag
// tracking) and publishes them via analysis_port.

`ifndef NET_MONITOR_SV
`define NET_MONITOR_SV
`include "uvm_macros.svh"
import uvm_pkg::*;


class net_monitor extends uvm_monitor;
  `uvm_component_utils(net_monitor)
  virtual net_vip_if vif;
  net_protocol_e     protocol;
  net_protocol_cfg_t cfg;
  uvm_analysis_port #(net_sequence_item) analysis_port;
  net_coverage_model cov_model;

  int unsigned txn_count = 0;
  int unsigned error_count = 0;

  // in-flight frame state
  protected net_sequence_item item;
  protected int unsigned      data_idx;
  protected bit               err_seen;

  function new(string name = "net_monitor", uvm_component parent = null);
    super.new(name, parent);
    analysis_port = new("analysis_port", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual net_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "Virtual interface not found")
    if (!uvm_config_db#(net_protocol_e)::get(this, "", "protocol", protocol))
      protocol = NET_ETH_1G;
    void'(uvm_config_db#(net_protocol_cfg_t)::get(this, "", "cfg", cfg));
    cov_model = net_coverage_model::type_id::create("cov_model", this);
  endfunction

  function automatic void open_item();
    item = net_sequence_item::type_id::create("item");
    item.txn.protocol  = protocol;
    item.txn.dst_mac   = vif.monitor_cb.dst_mac;
    item.txn.src_mac   = vif.monitor_cb.src_mac;
    item.txn.ethertype = vif.monitor_cb.ethertype;
    item.txn.vlan_id   = vif.monitor_cb.vlan_id;
    item.txn.vlan_pcp  = vif.monitor_cb.vlan_pcp;
    item.txn.vlan_cfi  = vif.monitor_cb.vlan_cfi;
    item.txn.uec_vc    = vif.monitor_cb.uec_vc;
    item.txn.uec_ai_tag = vif.monitor_cb.uec_ai_tag;
    item.txn.uec_congestion = vif.monitor_cb.uec_congestion;
    item.txn.fc_port_id = vif.monitor_cb.fc_port_id;
    item.txn.fc_exchange = vif.monitor_cb.fc_exchange;
    item.txn.frame_type = (item.txn.dst_mac == 48'hFFFF_FFFF_FFFF) ? FRAME_BROADCAST :
                          (item.txn.dst_mac[40]) ? FRAME_MULTICAST :
                          (item.txn.ethertype == 16'h8100) ? FRAME_VLAN_TAGGED :
                          FRAME_UNICAST;
    item.txn.status    = NET_TXN_ACTIVE;
    item.txn.payload_data = new[2048];
    data_idx = 0;
    err_seen = 1'b0;
    // header beat carries payload word 0 at [31:0]
    item.txn.payload_data[0] = vif.monitor_cb.data[31:0];
    data_idx = 1;
  endfunction

  function automatic void close_item();
    if (item == null) return;
    item.txn.payload_data = new[data_idx](item.txn.payload_data);
    item.txn.payload_len  = data_idx * 4;
    item.txn.set_complete(err_seen ? NET_TXN_ERROR : NET_TXN_COMPLETE);
    txn_count++;
    if (err_seen) error_count++;
    `uvm_info("MONITOR", $sformatf("Observed: %s", item.convert2string()), UVM_HIGH)
    analysis_port.write(item);
    cov_model.sample_transaction(item.txn);
    item = null;
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.monitor_cb);
      if (vif.monitor_cb.fcs_error || vif.monitor_cb.symbol_error ||
          vif.monitor_cb.link_error || vif.monitor_cb.protocol_error)
        err_seen = 1'b1;

      if (vif.monitor_cb.valid && vif.monitor_cb.ready) begin
        if (vif.monitor_cb.sop) begin
          if (item != null) close_item();   // dangling frame (protocol error)
          open_item();
        end
        else if (item != null) begin
          // payload beat: unpack DATA_WIDTH/32 words
          for (int j = 0; j < (vif.DATA_WIDTH/32) && data_idx < 2048; j++)
            item.txn.payload_data[data_idx++] = vif.monitor_cb.data[j*32 +: 32];
        end
        if (vif.monitor_cb.eop && item != null) begin
          if (vif.monitor_cb.fcs_valid) item.txn.fcs = vif.monitor_cb.fcs;
          close_item();
        end
      end
    end
  endtask

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("MONITOR_REPORT", $sformatf("Protocol: %s | Observed: %0d | Errors: %0d",
              protocol.name(), txn_count, error_count), UVM_LOW)
  endfunction
endclass
`endif
