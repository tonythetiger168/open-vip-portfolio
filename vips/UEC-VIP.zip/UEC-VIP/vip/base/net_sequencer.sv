// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_sequencer.sv -- Multi-speed Ethernet sequencer

`ifndef NET_SEQUENCER_SV
`define NET_SEQUENCER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;


class net_sequencer extends uvm_sequencer #(net_sequence_item);
  `uvm_component_utils(net_sequencer)
  net_protocol_e protocol;

  function new(string name = "net_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(net_protocol_e)::get(this, "", "protocol", protocol))
      `uvm_warning("CONFIG", "Protocol not configured, defaulting to Ethernet 1G")
  endfunction
endclass
`endif
