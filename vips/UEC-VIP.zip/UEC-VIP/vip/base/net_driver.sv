// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_driver.sv -- Multi-speed Ethernet driver: MAC frame driving with
// SOP/EOP framing, per-beat READY handshake, VLAN tags, FCS, UEC VC/tags,
// FC port fields, and IFG insertion.

`ifndef NET_DRIVER_SV
`define NET_DRIVER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;


class net_driver extends uvm_driver #(net_sequence_item);
  `uvm_component_utils(net_driver)
  virtual net_vip_if vif;
  net_protocol_e     protocol;
  net_protocol_cfg_t cfg;
  uvm_analysis_port #(net_sequence_item) drv_ap;  // expected frames for scoreboard

  int txn_count;
  int error_count;

  function new(string name = "net_driver", uvm_component parent = null);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
    txn_count = 0;
    error_count = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual net_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "Virtual interface not found")
    if (!uvm_config_db#(net_protocol_e)::get(this, "", "protocol", protocol))
      protocol = NET_ETH_1G;
    void'(uvm_config_db#(net_protocol_cfg_t)::get(this, "", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    // Idle the bus
    vif.driver_cb.valid      <= 1'b0;
    vif.driver_cb.sop        <= 1'b0;
    vif.driver_cb.eop        <= 1'b0;
    vif.driver_cb.data       <= '0;
    vif.driver_cb.lane_valid <= '1;
    vif.driver_cb.be         <= 8'hFF;
    vif.driver_cb.fcs_valid  <= 1'b0;
    vif.driver_cb.pause_frame <= 1'b0;
    vif.driver_cb.pfc_frame  <= 1'b0;
    wait (vif.rst_n === 1'b1);
    forever begin
      net_sequence_item req_item;
      seq_item_port.get_next_item(req_item);
      drive_item(req_item);
      drv_ap.write(req_item);        // broadcast expected frame
      seq_item_port.item_done();
    end
  endtask

  virtual task drive_item(net_sequence_item item);
    net_txn_descriptor txn = item.txn;
    `uvm_info("DRIVER", $sformatf("Driving: %s", txn.convert2string()), UVM_HIGH)
    repeat (txn.delay_cycles > 50 ? 0 : txn.delay_cycles) @(vif.driver_cb);
    case (txn.protocol)
      NET_ETH_1G, NET_ETH_100G, NET_ETH_400G,
      NET_ETH_800G, NET_ETH_1P6T: drive_ethernet(txn);
      NET_UEC:                    drive_uec(txn);
      NET_FC:                     drive_fc(txn);
      default:                    drive_ethernet(txn);
    endcase
    // Inter-frame gap
    repeat (txn.ifg_cycles / 10) @(vif.driver_cb);
    txn_count++;
    if (txn.status == NET_TXN_ERROR) error_count++;
  endtask

  // Drive the header beat: {dst_mac, src_mac, ethertype, vlan} at top of the
  // flit, payload word 0 at [31:0]; then payload beats.
  virtual task drive_header_and_payload(net_txn_descriptor txn);
    int beats;
    int data_idx = 0;
    logic [511:0] beat_data;
    beats = 1 + (txn.payload_len + (vif.DATA_WIDTH/8) - 1) / (vif.DATA_WIDTH/8);

    // ---- header beat ----
    @(vif.driver_cb);
    vif.driver_cb.sop       <= 1'b1;
    vif.driver_cb.eop       <= (beats == 1);
    vif.driver_cb.valid     <= 1'b1;
    vif.driver_cb.dst_mac   <= txn.dst_mac;
    vif.driver_cb.src_mac   <= txn.src_mac;
    vif.driver_cb.ethertype <= txn.ethertype;
    vif.driver_cb.vlan_id   <= txn.vlan_id;
    vif.driver_cb.vlan_pcp  <= txn.vlan_pcp;
    vif.driver_cb.vlan_cfi  <= txn.vlan_cfi;
    vif.driver_cb.fcs       <= txn.fcs;
    vif.driver_cb.fcs_valid <= (beats == 1);
    vif.driver_cb.data      <= '0;
    vif.driver_cb.data[vif.DATA_WIDTH-1   -: 48] <= txn.dst_mac;
    vif.driver_cb.data[vif.DATA_WIDTH-49  -: 48] <= txn.src_mac;
    vif.driver_cb.data[vif.DATA_WIDTH-97  -: 16] <= txn.ethertype;
    vif.driver_cb.data[vif.DATA_WIDTH-113 -: 16] <= {txn.vlan_pcp, txn.vlan_cfi, txn.vlan_id};
    if (txn.payload_data.size() > 0)
      vif.driver_cb.data[31:0] <= txn.payload_data[data_idx++];

    // ---- payload beats ----
    for (int i = 1; i < beats; i++) begin
      @(vif.driver_cb);
      while (vif.driver_cb.ready !== 1'b1) @(vif.driver_cb);
      beat_data = '0;
      for (int j = 0; j < (vif.DATA_WIDTH/32) && data_idx < txn.payload_data.size(); j++)
        beat_data[j*32 +: 32] = txn.payload_data[data_idx++];
      vif.driver_cb.sop       <= 1'b0;
      vif.driver_cb.valid     <= 1'b1;
      vif.driver_cb.eop       <= (i == beats - 1);
      vif.driver_cb.fcs_valid <= (i == beats - 1);
      vif.driver_cb.data      <= beat_data;
    end

    // ---- end of frame ----
    @(vif.driver_cb);
    vif.driver_cb.valid     <= 1'b0;
    vif.driver_cb.sop       <= 1'b0;
    vif.driver_cb.eop       <= 1'b0;
    vif.driver_cb.fcs_valid <= 1'b0;
    wait (vif.driver_cb.ready === 1'b1);
    txn.set_complete(NET_TXN_COMPLETE);
  endtask

  //==========================================================================
  // Ethernet Driving (1G/100G/400G/800G/1.6T)
  //==========================================================================
  virtual task drive_ethernet(net_txn_descriptor txn);
    vif.driver_cb.uec_vc    <= 4'h0;
    vif.driver_cb.uec_ai_tag <= 4'h0;
    drive_header_and_payload(txn);
  endtask

  //==========================================================================
  // UEC Driving (Ultra Ethernet Consortium: VC + AI tags + congestion)
  //==========================================================================
  virtual task drive_uec(net_txn_descriptor txn);
    vif.driver_cb.uec_vc         <= txn.uec_vc;
    vif.driver_cb.uec_ai_tag     <= txn.uec_ai_tag;
    vif.driver_cb.uec_congestion <= txn.uec_congestion;
    drive_header_and_payload(txn);
    vif.driver_cb.uec_vc         <= 4'h0;
    vif.driver_cb.uec_ai_tag     <= 4'h0;
    vif.driver_cb.uec_congestion <= 8'h0;
  endtask

  //==========================================================================
  // FC Driving (Fibre Channel: port ID + exchange)
  //==========================================================================
  virtual task drive_fc(net_txn_descriptor txn);
    vif.driver_cb.fc_port_id  <= txn.fc_port_id;
    vif.driver_cb.fc_exchange <= txn.fc_exchange;
    drive_header_and_payload(txn);
  endtask

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("DRIVER_REPORT", $sformatf("Protocol: %s | Total Driven: %0d | Errors: %0d",
              protocol.name(), txn_count, error_count), UVM_LOW)
  endfunction
endclass
`endif
