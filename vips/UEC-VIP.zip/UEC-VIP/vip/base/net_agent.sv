// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_agent.sv -- Multi-speed Ethernet agent (sequencer + driver + monitor)

`ifndef NET_AGENT_SV
`define NET_AGENT_SV
`include "uvm_macros.svh"
import uvm_pkg::*;


class net_agent extends uvm_agent;
  `uvm_component_utils(net_agent)
  net_sequencer sqr;
  net_driver    drv;
  net_monitor   mon;
  net_protocol_e     protocol;
  net_protocol_cfg_t cfg;
  bit is_active = 1;
  uvm_analysis_port #(net_sequence_item) ap;

  function new(string name = "net_agent", uvm_component parent = null);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(net_protocol_e)::get(this, "", "protocol", protocol))
      protocol = NET_ETH_1G;
    if (!uvm_config_db#(bit)::get(this, "", "is_active", is_active))
      is_active = 1;
    void'(uvm_config_db#(net_protocol_cfg_t)::get(this, "", "cfg", cfg));
    mon = net_monitor::type_id::create("mon", this);
    if (is_active) begin
      sqr = net_sequencer::type_id::create("sqr", this);
      drv = net_driver::type_id::create("drv", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (is_active)
      drv.seq_item_port.connect(sqr.seq_item_export);
    mon.analysis_port.connect(ap);
  endfunction

  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    if (sqr != null) uvm_config_db#(net_protocol_e)::set(sqr, "", "protocol", protocol);
    if (drv != null) uvm_config_db#(net_protocol_e)::set(drv, "", "protocol", protocol);
    if (mon != null) uvm_config_db#(net_protocol_e)::set(mon, "", "protocol", protocol);
    if (drv != null) uvm_config_db#(net_protocol_cfg_t)::set(drv, "", "cfg", cfg);
    if (mon != null) uvm_config_db#(net_protocol_cfg_t)::set(mon, "", "cfg", cfg);
  endfunction
endclass
`endif
