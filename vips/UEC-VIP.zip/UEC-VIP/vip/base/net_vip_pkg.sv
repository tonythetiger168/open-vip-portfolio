// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Speed Ethernet VIP Package
// Protocols: 1G/100G/400G/800G/1.6T Ethernet, UEC, FC
//============================================================================
`ifndef NET_VIP_PKG_SV
`define NET_VIP_PKG_SV

// Tiered SVA compliance checker and protocol checkers: the SVA content lives
// in modules (class-scope concurrent assertions are illegal per IEEE 1800);
// thin class shells remain. Included at compilation-unit scope, outside and
// before the package, so net_env / top_tb can see them.
`include "sva/uec_compliance_checker.sv"
`include "eth_protocol_checker.sv"
`include "fc_protocol_checker.sv"
`include "uec_protocol_checker.sv"

package net_vip_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef enum int { NET_ETH_1G=0, NET_ETH_100G=1, NET_ETH_400G=2, NET_ETH_800G=3,
                     NET_ETH_1P6T=4, NET_UEC=5, NET_FC=6, NET_MAX=7 } net_protocol_e;
  typedef enum logic [3:0] {
    LINK_DOWN = 4'b0000,
    LINK_ANEG = 4'b0001,      // Auto-negotiation
    LINK_TRAINING = 4'b0010,  // Link training
    LINK_UP = 4'b0011,
    LINK_LOCAL_FAULT = 4'b0100,
    LINK_REMOTE_FAULT = 4'b0101,
    LINK_TEST = 4'b0110,
    LINK_RECOVERY = 4'b0111
  } net_link_state_e;
  typedef enum logic [1:0] { MOD_NRZ = 2'b00, MOD_PAM4 = 2'b01,
                             MOD_PAM6 = 2'b10, MOD_PAM8 = 2'b11 } modulation_e;
  typedef enum int { FRAME_UNICAST=0, FRAME_MULTICAST=1, FRAME_BROADCAST=2,
                     FRAME_VLAN_TAGGED=3, FRAME_QINQ=4, FRAME_JUMBO=5,
                     FRAME_PAUSE=6, FRAME_PFC=7, FRAME_ECN=8,
                     FRAME_PCS_BLOCK=9, FRAME_FEC_CW=10, FRAME_PAM4_SYMBOL=11,
                     FRAME_UNKNOWN=12 } frame_type_e;
  typedef enum int { NET_TXN_IDLE=0, NET_TXN_PENDING=1, NET_TXN_ACTIVE=2,
                     NET_TXN_COMPLETE=3, NET_TXN_ERROR=4, NET_TXN_TIMEOUT=5 } net_txn_status_e;

  typedef struct packed {
    net_protocol_e protocol;
    int            num_lanes;
    int            mtu_size;
    bit            fec_enabled;
    modulation_e   modulation;
    bit            pfc_enabled;
    bit            ecn_enabled;
    int            credit_timeout;
    int            replay_timeout;
  } net_protocol_cfg_t;

  typedef struct packed {
    bit cov_frame_types;
    bit cov_addresses;
    bit cov_payload_patterns;
    bit cov_link_states;
    bit cov_error_injection;
    bit cov_flow_control;
    bit cov_bandwidth;
    bit cov_latency;
    bit cov_cross_protocol;
  } net_coverage_cfg_t;

  //==========================================================================
  // Ethernet Frame Descriptor
  //==========================================================================
  class net_txn_descriptor extends uvm_object;
    `uvm_object_utils(net_txn_descriptor)
    rand net_protocol_e protocol;
    rand frame_type_e   frame_type;
    rand logic [47:0]   dst_mac;
    rand logic [47:0]   src_mac;
    rand logic [15:0]   ethertype;
    rand int            payload_len;   // bytes (46-1500 std, up to 9000 jumbo)
    rand logic [31:0]   payload_data[];
    rand logic [11:0]   vlan_id;
    rand logic [2:0]    vlan_pcp;
    rand logic          vlan_cfi;
    rand logic [31:0]   fcs;
    rand bit            inject_crc_error;
    rand bit            trigger_pause;
    rand net_txn_status_e status;
    rand int            ifg_cycles;    // Inter-frame gap
    rand int            delay_cycles;
    // Protocol-specific fields
    rand logic [3:0]    uec_vc;
    rand logic [3:0]    uec_ai_tag;
    rand logic [7:0]    uec_congestion;
    rand logic [23:0]   fc_port_id;
    rand logic [15:0]   fc_exchange;
    // Timestamp
    time start_time;
    time end_time;

    constraint c_payload_len { payload_len inside {[46:9000]}; payload_len % 4 == 0; }
    constraint c_payload_words { payload_data.size() == (payload_len / 4); }
    constraint c_ethertype {
      ethertype inside {16'h0800, 16'h86DD, 16'h8100, 16'h8808, 16'h88A8, 16'h9100};
    }
    constraint c_mac { dst_mac != 48'h0; src_mac != 48'h0; }
    constraint c_broadcast {
      if (frame_type == FRAME_BROADCAST) dst_mac == 48'hFFFF_FFFF_FFFF;
      if (frame_type == FRAME_UNICAST)   dst_mac[40] == 1'b0;
      if (frame_type == FRAME_MULTICAST) dst_mac[40] == 1'b1 && dst_mac != 48'hFFFF_FFFF_FFFF;
    }
    // REACHABILITY: VLAN id 0 is the legal 802.1Q priority-tagged value, so
    // allow it (cg_addresses cp_vlan_id.zero); 12'hFFF stays excluded because
    // it is reserved by the specification.
    constraint c_vlan { vlan_id inside {[12'h000:12'hFFE]}; }
    constraint c_ifg { ifg_cycles inside {[12:100]}; }  // Min 12-byte IFG
    constraint c_delay { delay_cycles inside {[0:1000]}; }
    constraint c_error_rate { inject_crc_error dist { 0 := 95, 1 := 5 }; }
    constraint c_status { status == NET_TXN_PENDING; }

    function new(string name = "net_txn_descriptor");
      super.new(name);
    endfunction

    function void post_randomize();
      start_time = $time;
      // Simple CRC32 placeholder for FCS
      fcs = 32'hDEAD_BEEF;
    endfunction

    function void set_complete(net_txn_status_e s);
      status = s;
      end_time = $time;
    endfunction

    function int get_latency_ns();
      if (end_time > start_time) return int'((end_time - start_time) / 1ns);
      else return 0;
    endfunction

    function string convert2string();
      return $sformatf("protocol=%s type=%s dst=%012X src=%012X len=%0d status=%s",
                       protocol.name(), frame_type.name(), dst_mac, src_mac,
                       payload_len, status.name());
    endfunction
  endclass

  //==========================================================================
  // Base Sequence Item
  //==========================================================================
  class net_sequence_item extends uvm_sequence_item;
    `uvm_object_utils(net_sequence_item)
    rand net_txn_descriptor txn;
    constraint c_default { txn.protocol != NET_MAX; }
    function new(string name = "net_sequence_item");
      super.new(name);
      txn = net_txn_descriptor::type_id::create("txn");
    endfunction
    function string convert2string();
      return txn.convert2string();
    endfunction
  endclass

  //==========================================================================
  // Protocol Configuration Object
  //==========================================================================
  class net_protocol_config extends uvm_object;
    `uvm_object_utils(net_protocol_config)
    net_protocol_e     protocol;
    net_protocol_cfg_t cfg;
    net_coverage_cfg_t cov_cfg;

    function new(string name = "net_protocol_config", net_protocol_e p = NET_ETH_1G);
      super.new(name);
      protocol = p;
      set_default_cfg();
    endfunction

    function void set_default_cfg();
      case (protocol)
        NET_ETH_1G: begin
          cfg.num_lanes = 1; cfg.mtu_size = 1500; cfg.modulation = MOD_NRZ;
          cfg.fec_enabled = 0; cfg.pfc_enabled = 0;
        end
        NET_ETH_100G: begin
          cfg.num_lanes = 4; cfg.mtu_size = 9000; cfg.modulation = MOD_NRZ;
          cfg.fec_enabled = 1; cfg.pfc_enabled = 1;
        end
        NET_ETH_400G: begin
          cfg.num_lanes = 8; cfg.mtu_size = 9000; cfg.modulation = MOD_PAM4;
          cfg.fec_enabled = 1; cfg.pfc_enabled = 1;
        end
        NET_ETH_800G: begin
          cfg.num_lanes = 8; cfg.mtu_size = 9000; cfg.modulation = MOD_PAM4;
          cfg.fec_enabled = 1; cfg.pfc_enabled = 1;
        end
        NET_ETH_1P6T: begin
          cfg.num_lanes = 16; cfg.mtu_size = 9000; cfg.modulation = MOD_PAM4;
          cfg.fec_enabled = 1; cfg.pfc_enabled = 1; cfg.ecn_enabled = 1;
        end
        NET_UEC: begin
          cfg.num_lanes = 8; cfg.mtu_size = 4500; cfg.modulation = MOD_PAM4;
          cfg.fec_enabled = 1; cfg.pfc_enabled = 1; cfg.ecn_enabled = 1;
        end
        NET_FC: begin
          cfg.num_lanes = 1; cfg.mtu_size = 2148; cfg.modulation = MOD_NRZ;
          cfg.fec_enabled = 0; cfg.pfc_enabled = 0;
        end
        default: begin
          cfg.num_lanes = 1; cfg.mtu_size = 1500; cfg.modulation = MOD_NRZ;
        end
      endcase
      cfg.protocol = protocol;
      cfg.credit_timeout = 10000;
      cfg.replay_timeout = 50000;
      // Default coverage enable
      cov_cfg.cov_frame_types = 1;
      cov_cfg.cov_addresses = 1;
      cov_cfg.cov_payload_patterns = 1;
      cov_cfg.cov_link_states = 1;
      cov_cfg.cov_error_injection = 1;
      cov_cfg.cov_flow_control = 1;
      cov_cfg.cov_bandwidth = 1;
      cov_cfg.cov_latency = 1;
      cov_cfg.cov_cross_protocol = 1;
    endfunction
  endclass

  //==========================================================================
  // Coverage Model Base Class (frame/address/payload/latency/error/link-state)
  //==========================================================================
  class net_coverage_model extends uvm_component;
    `uvm_component_utils(net_coverage_model)
    uvm_analysis_imp #(net_sequence_item, net_coverage_model) analysis_imp;

    // Coverage variables
    net_protocol_e txn_protocol;
    frame_type_e   frame_type;
    logic [47:0]   dst_mac;
    logic [15:0]   ethertype;
    logic [11:0]   vlan_id;
    int            payload_len;
    bit all_zeros, all_ones, walking_ones, walking_zeros, is_random;
    int            latency_ns;
    int            error_type;
    bit            recovery_triggered;
    net_link_state_e cur_link_state;

    covergroup cg_frame_types;
      option.per_instance = 1;
      cp_protocol: coverpoint txn_protocol {
        bins eth_1g = {NET_ETH_1G}; bins eth_100g = {NET_ETH_100G};
        bins eth_400g = {NET_ETH_400G}; bins eth_800g = {NET_ETH_800G};
        bins eth_1p6t = {NET_ETH_1P6T}; bins uec = {NET_UEC}; bins fc = {NET_FC};
      }
      cp_frame_type: coverpoint frame_type {
        bins unicast = {FRAME_UNICAST}; bins multicast = {FRAME_MULTICAST};
        bins broadcast = {FRAME_BROADCAST}; bins vlan = {FRAME_VLAN_TAGGED};
        bins qinq = {FRAME_QINQ}; bins jumbo = {FRAME_JUMBO};
        bins pause = {FRAME_PAUSE}; bins pfc = {FRAME_PFC}; bins ecn = {FRAME_ECN};
      }
      cp_payload_len: coverpoint payload_len {
        bins min = {[46:64]}; bins std = {[65:1500]};
        bins jumbo = {[1501:9000]};
        // REACHABILITY: 9000 bytes is the jumbo-frame ceiling (c_payload_len
        // caps payload_len at 9000); larger frames are not a legal Ethernet/UEC
        // frame size, so values above 9000 can never be sampled.
        ignore_bins max = {[9001:$]};
      }
      cross_prot_frame: cross cp_protocol, cp_frame_type;
    endgroup

    covergroup cg_addresses;
      option.per_instance = 1;
      cp_dst_oui: coverpoint dst_mac[47:24] {
        bins unicast = {[24'h000000:24'h7FFFFF]};
        bins multicast = {[24'h800000:24'hFFFFFF]};
      }
      cp_ethertype: coverpoint ethertype {
        bins ipv4 = {16'h0800}; bins ipv6 = {16'h86DD};
        bins vlan = {16'h8100}; bins pause = {16'h8808};
        bins qinq = {16'h88A8}; bins other = default;
      }
      cp_vlan_id: coverpoint vlan_id {
        bins zero = {12'h000}; bins low = {[12'h001:12'h0FF]};
        bins mid = {[12'h100:12'h7FF]}; bins high = {[12'h800:12'hFFE]};
      }
      cross_type_vlan: cross cp_ethertype, cp_vlan_id;
    endgroup

    covergroup cg_payload_patterns;
      option.per_instance = 1;
      cp_all_zeros:     coverpoint all_zeros     { bins yes = {1}; bins no = {0}; }
      cp_all_ones:      coverpoint all_ones      { bins yes = {1}; bins no = {0}; }
      cp_walking_ones:  coverpoint walking_ones  { bins yes = {1}; bins no = {0}; }
      cp_walking_zeros: coverpoint walking_zeros { bins yes = {1}; bins no = {0}; }
      cp_random:        coverpoint is_random     { bins yes = {1}; bins no = {0}; }
      cross_pat: cross cp_all_zeros, cp_all_ones, cp_walking_ones;
    endgroup

    covergroup cg_latency;
      option.per_instance = 1;
      cp_latency_ns: coverpoint latency_ns {
        bins low = {[0:100]}; bins med = {[101:500]};
        bins high = {[501:1000]}; bins extreme = {[1001:$]};
      }
      cp_protocol: coverpoint txn_protocol {
        bins low_speed = {NET_ETH_1G}; bins medium_speed = {NET_ETH_100G};
        bins high_speed = {NET_ETH_400G, NET_ETH_800G, NET_ETH_1P6T, NET_UEC};
        bins fc = {NET_FC};
      }
      cross_lat_prot: cross cp_latency_ns, cp_protocol;
    endgroup

    covergroup cg_error_injection;
      option.per_instance = 1;
      cp_error_type: coverpoint error_type {
        bins fcs_error = {0}; bins symbol_error = {1}; bins link_error = {2};
        bins timeout_error = {3}; bins protocol_error = {4};
      }
      cp_recovery: coverpoint recovery_triggered { bins yes = {1}; bins no = {0}; }
      cross_err_rec: cross cp_error_type, cp_recovery;
    endgroup

    // Link-state FSM transition coverage
    covergroup cg_link_state;
      option.per_instance = 1;
      cp_state: coverpoint cur_link_state {
        bins down = {LINK_DOWN}; bins aneg = {LINK_ANEG};
        bins training = {LINK_TRAINING}; bins up = {LINK_UP};
        bins local_fault = {LINK_LOCAL_FAULT}; bins remote_fault = {LINK_REMOTE_FAULT};
        bins test = {LINK_TEST}; bins recovery = {LINK_RECOVERY};
      }
      cp_trans: coverpoint cur_link_state {
        bins link_up_flow = (LINK_DOWN => LINK_ANEG => LINK_TRAINING => LINK_UP);
        bins up_fault     = (LINK_UP => LINK_LOCAL_FAULT);
        bins fault_rec    = (LINK_LOCAL_FAULT => LINK_RECOVERY);
        bins rec_up       = (LINK_RECOVERY => LINK_UP);
        bins up_rfault    = (LINK_UP => LINK_REMOTE_FAULT);
        bins rfault_rec   = (LINK_REMOTE_FAULT => LINK_RECOVERY);
      }
    endgroup

    function new(string name = "net_coverage_model", uvm_component parent = null);
      super.new(name, parent);
      analysis_imp = new("analysis_imp", this);
      cg_frame_types = new();
      cg_addresses = new();
      cg_payload_patterns = new();
      cg_latency = new();
      cg_error_injection = new();
      cg_link_state = new();
    endfunction

    virtual function void write(net_sequence_item item);
      sample_transaction(item.txn);
    endfunction

    virtual function void sample_transaction(net_txn_descriptor txn);
      txn_protocol = txn.protocol;
      frame_type   = txn.frame_type;
      dst_mac      = txn.dst_mac;
      ethertype    = txn.ethertype;
      vlan_id      = txn.vlan_id;
      payload_len  = txn.payload_len;
      latency_ns   = txn.get_latency_ns();
      // Payload pattern analysis
      if (txn.payload_data.size() > 0) begin
        all_zeros = 1; all_ones = 1;
        walking_ones = 0; walking_zeros = 0; is_random = 1;
        foreach (txn.payload_data[i]) begin
          if (txn.payload_data[i] != 32'h0000_0000) all_zeros = 0;
          if (txn.payload_data[i] != 32'hFFFF_FFFF) all_ones = 0;
        end
        begin
          logic [31:0] d = txn.payload_data[0];
          if ($countones(d) == 1)  walking_ones = 1;
          if ($countones(~d) == 1) walking_zeros = 1;
        end
        if (all_zeros || all_ones || walking_ones || walking_zeros) is_random = 0;
      end
      cg_frame_types.sample();
      cg_addresses.sample();
      cg_payload_patterns.sample();
      cg_latency.sample();
    endfunction

    virtual function void sample_error(int err_type, bit recovery);
      error_type = err_type;
      recovery_triggered = recovery;
      cg_error_injection.sample();
    endfunction

    virtual function void sample_link_state(net_link_state_e s);
      cur_link_state = s;
      cg_link_state.sample();
    endfunction

    virtual function real get_coverage();
      real cov = 0;
      cov += cg_frame_types.get_coverage();
      cov += cg_addresses.get_coverage();
      cov += cg_payload_patterns.get_coverage();
      cov += cg_latency.get_coverage();
      cov += cg_error_injection.get_coverage();
      cov += cg_link_state.get_coverage();
      return cov / 6.0;
    endfunction
  endclass

  //==========================================================================
  // End-to-end Scoreboard: compares driver-issued (expected) frames against
  // monitor-decoded (observed) frames.
  //==========================================================================
  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  class net_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(net_scoreboard)
    uvm_analysis_imp     #(net_sequence_item, net_scoreboard) analysis_imp;  // legacy
    uvm_analysis_imp_exp #(net_sequence_item, net_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(net_sequence_item, net_scoreboard) obs_ap;

    net_sequence_item expected_queue[$];
    net_sequence_item received_queue[$];

    int txn_count;
    int error_count;
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name = "net_scoreboard", uvm_component parent = null);
      super.new(name, parent);
      analysis_imp = new("analysis_imp", this);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
      txn_count = 0; error_count = 0;
    endfunction

    virtual function void write(net_sequence_item item);
      txn_count++;
      if (item.txn.status == NET_TXN_ERROR) error_count++;
    endfunction

    virtual function void write_exp(net_sequence_item item);
      expected_queue.push_back(item);
      compare();
    endfunction

    virtual function void write_obs(net_sequence_item item);
      received_queue.push_back(item);
      compare();
    endfunction

    virtual function void compare();
      while (expected_queue.size() && received_queue.size()) begin
        net_sequence_item e = expected_queue.pop_front();
        net_sequence_item o = received_queue.pop_front();
        bit ok = (e.txn.protocol == o.txn.protocol) &&
                 (e.txn.dst_mac   == o.txn.dst_mac) &&
                 (e.txn.src_mac   == o.txn.src_mac) &&
                 (e.txn.ethertype == o.txn.ethertype) &&
                 (e.txn.payload_len == o.txn.payload_len);
        if (ok) begin
          int n = (e.txn.payload_data.size() < o.txn.payload_data.size()) ?
                  e.txn.payload_data.size() : o.txn.payload_data.size();
          for (int i = 0; i < n; i++)
            if (e.txn.payload_data[i] !== o.txn.payload_data[i]) ok = 0;
        end
        if (ok) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    virtual function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("net scoreboard: txn=%0d err=%0d n_matches=%0d n_mismatches=%0d",
                txn_count, error_count, n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  // UVC components (sequencer/driver/monitor/agent)
  `include "net_sequencer.sv"
  `include "net_driver.sv"
  `include "net_monitor.sv"
  `include "net_agent.sv"

endpackage
`endif
