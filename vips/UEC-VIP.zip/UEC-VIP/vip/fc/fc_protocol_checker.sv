// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// fc_protocol_checker.sv -- Fibre Channel Protocol Checker

`ifndef FC_PROTOCOL_CHECKER_SV
`define FC_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

// ============================================================================
// fc_protocol_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module fc_protocol_checker_sva (net_vip_if vif);

    int pid_err_cnt = 0;
  int xch_err_cnt = 0;
  int hsk_err_cnt = 0;
  int link_err_cnt = 0;

    initial begin
    end


  property p_fc_port_id;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.fc_port_id != 24'h0;
  endproperty
  assert_fc_port_id: assert property(p_fc_port_id)
  else begin
    `uvm_error("FC_CHK", "FC port ID zero")
    pid_err_cnt++;
  end

  property p_fc_exchange;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid) |-> vif.fc_exchange <= 16'hFFFF;
  endproperty
  assert_fc_exchange: assert property(p_fc_exchange)
  else begin
    `uvm_error("FC_CHK", "FC exchange illegal")
    xch_err_cnt++;
  end

  property p_fc_handshake;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.valid |-> ##[1:100] vif.ready;
  endproperty
  assert_fc_handshake: assert property(p_fc_handshake)
  else begin
    `uvm_error("FC_CHK", "FC valid-ready timeout")
    hsk_err_cnt++;
  end

  property p_fc_link;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.link_up;
  endproperty
  assert_fc_link: assert property(p_fc_link)
  else begin
    `uvm_error("FC_CHK", "FC frame while link down")
    link_err_cnt++;
  end

  final begin
    `uvm_info("FC_RPT", $sformatf("FC Chk report"), UVM_LOW)
    end
endmodule

// ============================================================================
// fc_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the fc_protocol_checker_sva module above)
// ============================================================================
class fc_protocol_checker extends uvm_component;
  `uvm_component_utils(fc_protocol_checker)
  function new(string name = "fc_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
