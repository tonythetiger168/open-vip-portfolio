// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eth_protocol_checker.sv -- Ethernet Protocol Checker (MAC framing)

`ifndef ETH_PROTOCOL_CHECKER_SV
`define ETH_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

// ============================================================================
// eth_protocol_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module eth_protocol_checker_sva (net_vip_if vif);

    int runt_err_cnt = 0;
  int type_err_cnt = 0;
  int hsk_err_cnt = 0;
  int fcs_err_cnt = 0;

    initial begin
    end


  property p_eth_min_frame;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop && vif.eop) |-> vif.be != 8'h00;
  endproperty
  assert_eth_min_frame: assert property(p_eth_min_frame)
  else begin
    `uvm_error("ETH_CHK", "Ethernet runt frame")
    runt_err_cnt++;
  end

  property p_eth_ethertype;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.valid && vif.sop) |-> vif.ethertype inside {16'h0800, 16'h86DD, 16'h8100, 16'h8808, 16'h88A8, 16'h9100, 16'hEEEE};
  endproperty
  assert_eth_ethertype: assert property(p_eth_ethertype)
  else begin
    `uvm_error("ETH_CHK", "Unknown EtherType")
    type_err_cnt++;
  end

  property p_eth_handshake;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.valid |-> ##[1:100] vif.ready;
  endproperty
  assert_eth_handshake: assert property(p_eth_handshake)
  else begin
    `uvm_error("ETH_CHK", "Ethernet valid-ready timeout")
    hsk_err_cnt++;
  end

  property p_eth_fcs_window;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.fcs_valid |-> (vif.valid && vif.eop);
  endproperty
  assert_eth_fcs_window: assert property(p_eth_fcs_window)
  else begin
    `uvm_error("ETH_CHK", "FCS flagged outside EOP")
    fcs_err_cnt++;
  end

  final begin
    `uvm_info("ETH_RPT", $sformatf("ETH Chk report"), UVM_LOW)
    end
endmodule

// ============================================================================
// eth_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the eth_protocol_checker_sva module above)
// ============================================================================
class eth_protocol_checker extends uvm_component;
  `uvm_component_utils(eth_protocol_checker)
  function new(string name = "eth_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
