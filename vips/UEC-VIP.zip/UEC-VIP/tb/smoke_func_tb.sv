// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (UEC min/max size policing)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened uec_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic tx_valid = 1'b0;
  logic [511:0] tx_data = '0;
  logic [10:0] tx_len = '0;
  wire  tx_ready;
  wire  rx_valid;
  wire  [511:0] rx_data;
  wire  [10:0] rx_len;
  wire  rx_err;

  always #5 clk = ~clk;

  uec_model u_dut (
    .clk(clk), .rst_n(rst_n), .tx_valid(tx_valid),
    .tx_data(tx_data), .tx_len(tx_len),
    .tx_ready(tx_ready), .rx_valid(rx_valid),
    .rx_data(rx_data), .rx_len(rx_len),
    .rx_err(rx_err)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(rx_valid === 1'b0 && rx_err === 1'b0, "rx quiet in reset");
    chk(tx_ready === 1'b1, "tx_ready high");
    @(negedge clk); rst_n = 1'b1;

    // good packet len=128 passes through with 2-cycle latency
    @(negedge clk); tx_valid = 1'b1; tx_len = 11'd128;
    tx_data = 512'h5A5A;
    step();
    @(negedge clk); tx_valid = 1'b0;
    step();
    chk(rx_valid === 1'b0, "latency not visible yet");
    step();
    chk(rx_valid === 1'b1, "good packet delivered");
    chk(rx_len === 11'd128 && rx_data === 512'h5A5A, "payload intact");
    chk(rx_err === 1'b0, "no err on good packet");
    step();
    chk(rx_valid === 1'b0, "single-cycle delivery");

    // undersize len=32 dropped with err pulse
    @(negedge clk); tx_valid = 1'b1; tx_len = 11'd32;
    step();
    @(negedge clk); tx_valid = 1'b0;
    step();
    step();
    chk(rx_valid === 1'b0, "undersize dropped");
    chk(rx_err === 1'b1, "undersize err pulse");
    step();
    chk(rx_err === 1'b0, "err is a pulse");

    // oversize len=2000 dropped
    @(negedge clk); tx_valid = 1'b1; tx_len = 11'd2000;
    step();
    @(negedge clk); tx_valid = 1'b0;
    step();
    step();
    chk(rx_valid === 1'b0 && rx_err === 1'b1, "oversize dropped with err");
    step();
    chk(rx_err === 1'b0, "err clears");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
