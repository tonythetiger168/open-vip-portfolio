// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- UEC testbench top with a functional UEC DUT model

`ifndef UEC_TB_SV
`define UEC_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import uec_defs_pkg::*;
import uec_pkg::*;
import uec_env_pkg::*;
import uec_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  uec_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  uec_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tx_valid(vif.tx_valid),
    .tx_data(vif.tx_data),
    .tx_len(vif.tx_len),
    .tx_ready(vif.tx_ready),
    .rx_valid(vif.rx_valid),
    .rx_data(vif.rx_data),
    .rx_len(vif.rx_len),
    .rx_err(vif.rx_err)
  );

  // Concurrent protocol checks
  uec_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .tx_valid(vif.tx_valid), .tx_data(vif.tx_data), .tx_len(vif.tx_len), .tx_ready(vif.tx_ready), .rx_valid(vif.rx_valid), .rx_data(vif.rx_data), .rx_len(vif.rx_len), .rx_err(vif.rx_err)
  );

  initial begin
    uvm_config_db#(virtual uec_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module uec_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        tx_valid,
  input  logic [511:0] tx_data,
  input  logic [10:0] tx_len,
  output logic        tx_ready,
  output logic        rx_valid,
  output logic [511:0] rx_data,
  output logic [10:0] rx_len,
  output logic        rx_err
);
  // min 64B / max 1518B policing, fixed 2-cycle latency pass-through
  logic        v1, v2;
  logic [511:0] d1, d2;
  logic [10:0] l1, l2;
  logic        bad1, bad2;
  assign tx_ready = 1'b1;
  initial begin rx_valid = 1'b0; rx_err = 1'b0; end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      v1 <= 1'b0; v2 <= 1'b0; rx_valid <= 1'b0; rx_err <= 1'b0;
    end else begin
      // stage 1: accept
      v1 <= tx_valid;
      d1 <= tx_data;
      l1 <= tx_len;
      bad1 <= tx_valid && (tx_len < 11'd64 || tx_len > 11'd1518);
      // stage 2: deliver
      v2 <= v1;
      d2 <= d1;
      l2 <= l1;
      bad2 <= bad1;
      rx_valid <= v2 && !bad2;
      rx_data <= d2;
      rx_len <= l2;
      rx_err <= v2 && bad2;
    end
  end
endmodule
`endif
