// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- Multi-speed Ethernet testbench top with a functional DUT
// model (per-protocol responder channels with FCS error injection).

`ifndef TOP_TB_SV
`define TOP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

module top_tb;
  logic clk = 0;
  logic rst_n;
  always #1ns clk = ~clk;   // 500MHz

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  // Interfaces (one per protocol/speed)
  net_vip_if #(.DATA_WIDTH(64),  .LANE_COUNT(1),  .PROTOCOL(0)) eth_1g_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(256), .LANE_COUNT(4),  .PROTOCOL(1)) eth_100g_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(2)) eth_400g_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(3)) eth_800g_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(4)) eth_1p6t_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(5)) uec_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(64),  .LANE_COUNT(1),  .PROTOCOL(6)) fc_if(clk, rst_n);

  // Functional DUT model (responder)
  net_dut dut (
    .clk(clk), .rst_n(rst_n),
    .eth_1g_if(eth_1g_if),     .eth_100g_if(eth_100g_if),
    .eth_400g_if(eth_400g_if), .eth_800g_if(eth_800g_if),
    .eth_1p6t_if(eth_1p6t_if), .uec_if(uec_if), .fc_if(fc_if)
  );

  // Tiered SVA compliance checker + protocol checkers (module form)
  uec_compliance_checker     u_uec_sva_chk   (.vif(uec_if));
  eth_protocol_checker_sva   u_eth_proto_sva (.vif(eth_1g_if));
  uec_protocol_checker_sva   u_uec_proto_sva (.vif(uec_if));
  fc_protocol_checker_sva    u_fc_proto_sva  (.vif(fc_if));

  initial begin
    // config-db type must match each interface's parameterization exactly
    uvm_config_db#(virtual net_vip_if #(.DATA_WIDTH(64),  .LANE_COUNT(1),  .PROTOCOL(0)))::set(null, "*", "eth_1g_vif", eth_1g_if);
    uvm_config_db#(virtual net_vip_if #(.DATA_WIDTH(256), .LANE_COUNT(4),  .PROTOCOL(1)))::set(null, "*", "eth_100g_vif", eth_100g_if);
    uvm_config_db#(virtual net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(2)))::set(null, "*", "eth_400g_vif", eth_400g_if);
    uvm_config_db#(virtual net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(3)))::set(null, "*", "eth_800g_vif", eth_800g_if);
    uvm_config_db#(virtual net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(4)))::set(null, "*", "eth_1p6t_vif", eth_1p6t_if);
    uvm_config_db#(virtual net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(5)))::set(null, "*", "uec_vif", uec_if);
    uvm_config_db#(virtual net_vip_if #(.DATA_WIDTH(64),  .LANE_COUNT(1),  .PROTOCOL(6)))::set(null, "*", "fc_vif", fc_if);
    run_test();
  end
endmodule

//----------------------------------------------------------------------------
// Functional DUT model: one responder channel per interface. Each channel:
// link up after reset, READY loopback with periodic wait-state stalls, and
// an FCS error pulse for frames with the error EtherType 0xEEEE.
//----------------------------------------------------------------------------
module net_dut (
  input logic clk,
  input logic rst_n,
  net_vip_if eth_1g_if,
  net_vip_if eth_100g_if,
  net_vip_if eth_400g_if,
  net_vip_if eth_800g_if,
  net_vip_if eth_1p6t_if,
  net_vip_if uec_if,
  net_vip_if fc_if
);
  net_dut_channel #(.HDR_WIDTH(64)) ch_eth_1g (.clk(clk), .rst_n(rst_n),
    .valid(eth_1g_if.valid), .sop(eth_1g_if.sop), .eop(eth_1g_if.eop),
    .ethertype(eth_1g_if.ethertype), .ready(eth_1g_if.ready),
    .link_up(eth_1g_if.link_up), .link_state(eth_1g_if.link_state),
    .fcs_error(eth_1g_if.fcs_error), .symbol_error(eth_1g_if.symbol_error),
    .link_error(eth_1g_if.link_error), .protocol_error(eth_1g_if.protocol_error),
    .crc_ok(eth_1g_if.crc_ok));

  net_dut_channel #(.HDR_WIDTH(256)) ch_eth_100g (.clk(clk), .rst_n(rst_n),
    .valid(eth_100g_if.valid), .sop(eth_100g_if.sop), .eop(eth_100g_if.eop),
    .ethertype(eth_100g_if.ethertype), .ready(eth_100g_if.ready),
    .link_up(eth_100g_if.link_up), .link_state(eth_100g_if.link_state),
    .fcs_error(eth_100g_if.fcs_error), .symbol_error(eth_100g_if.symbol_error),
    .link_error(eth_100g_if.link_error), .protocol_error(eth_100g_if.protocol_error),
    .crc_ok(eth_100g_if.crc_ok));

  net_dut_channel ch_eth_400g (.clk(clk), .rst_n(rst_n),
    .valid(eth_400g_if.valid), .sop(eth_400g_if.sop), .eop(eth_400g_if.eop),
    .ethertype(eth_400g_if.ethertype), .ready(eth_400g_if.ready),
    .link_up(eth_400g_if.link_up), .link_state(eth_400g_if.link_state),
    .fcs_error(eth_400g_if.fcs_error), .symbol_error(eth_400g_if.symbol_error),
    .link_error(eth_400g_if.link_error), .protocol_error(eth_400g_if.protocol_error),
    .crc_ok(eth_400g_if.crc_ok));

  net_dut_channel ch_eth_800g (.clk(clk), .rst_n(rst_n),
    .valid(eth_800g_if.valid), .sop(eth_800g_if.sop), .eop(eth_800g_if.eop),
    .ethertype(eth_800g_if.ethertype), .ready(eth_800g_if.ready),
    .link_up(eth_800g_if.link_up), .link_state(eth_800g_if.link_state),
    .fcs_error(eth_800g_if.fcs_error), .symbol_error(eth_800g_if.symbol_error),
    .link_error(eth_800g_if.link_error), .protocol_error(eth_800g_if.protocol_error),
    .crc_ok(eth_800g_if.crc_ok));

  net_dut_channel ch_eth_1p6t (.clk(clk), .rst_n(rst_n),
    .valid(eth_1p6t_if.valid), .sop(eth_1p6t_if.sop), .eop(eth_1p6t_if.eop),
    .ethertype(eth_1p6t_if.ethertype), .ready(eth_1p6t_if.ready),
    .link_up(eth_1p6t_if.link_up), .link_state(eth_1p6t_if.link_state),
    .fcs_error(eth_1p6t_if.fcs_error), .symbol_error(eth_1p6t_if.symbol_error),
    .link_error(eth_1p6t_if.link_error), .protocol_error(eth_1p6t_if.protocol_error),
    .crc_ok(eth_1p6t_if.crc_ok));

  net_dut_channel ch_uec (.clk(clk), .rst_n(rst_n),
    .valid(uec_if.valid), .sop(uec_if.sop), .eop(uec_if.eop),
    .ethertype(uec_if.ethertype), .ready(uec_if.ready),
    .link_up(uec_if.link_up), .link_state(uec_if.link_state),
    .fcs_error(uec_if.fcs_error), .symbol_error(uec_if.symbol_error),
    .link_error(uec_if.link_error), .protocol_error(uec_if.protocol_error),
    .crc_ok(uec_if.crc_ok));

  net_dut_channel #(.HDR_WIDTH(64)) ch_fc (.clk(clk), .rst_n(rst_n),
    .valid(fc_if.valid), .sop(fc_if.sop), .eop(fc_if.eop),
    .ethertype(fc_if.ethertype), .ready(fc_if.ready),
    .link_up(fc_if.link_up), .link_state(fc_if.link_state),
    .fcs_error(fc_if.fcs_error), .symbol_error(fc_if.symbol_error),
    .link_error(fc_if.link_error), .protocol_error(fc_if.protocol_error),
    .crc_ok(fc_if.crc_ok));
endmodule

//----------------------------------------------------------------------------
// Single responder channel (iverilog-checkable, no interface ports)
//----------------------------------------------------------------------------
module net_dut_channel #(parameter int HDR_WIDTH = 512) (
  input  logic clk,
  input  logic rst_n,
  input  logic valid,
  input  logic sop,
  input  logic eop,
  input  logic [15:0] ethertype,
  output logic ready,
  output logic link_up,
  output net_vip_pkg::net_link_state_e link_state,
  output logic fcs_error,
  output logic symbol_error,
  output logic link_error,
  output logic protocol_error,
  output logic crc_ok
);
  import net_vip_pkg::*;

  logic [3:0] beat_cnt;
  logic [1:0] stall_cnt;
  logic       err_frame;

  wire error_ethertype = (ethertype == 16'hEEEE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ready          <= 1'b0;
      link_up        <= 1'b0;
      link_state     <= LINK_DOWN;
      fcs_error      <= 1'b0;
      symbol_error   <= 1'b0;
      link_error     <= 1'b0;
      protocol_error <= 1'b0;
      crc_ok         <= 1'b1;
      beat_cnt       <= 4'h0;
      stall_cnt      <= 2'h0;
      err_frame      <= 1'b0;
    end
    else begin
      link_up    <= 1'b1;
      link_state <= LINK_UP;
      // error pulses are single-cycle
      fcs_error      <= 1'b0;
      symbol_error   <= 1'b0;
      link_error     <= 1'b0;
      protocol_error <= 1'b0;
      crc_ok         <= 1'b1;

      // track frames; inject FCS error for error-EtherType frames
      if (valid && sop) begin
        beat_cnt  <= 4'h0;
        err_frame <= error_ethertype;
      end
      else if (valid && ready) begin
        beat_cnt <= beat_cnt + 4'h1;
        if (err_frame && eop) begin
          fcs_error <= 1'b1;
          crc_ok    <= 1'b0;
          err_frame <= 1'b0;
        end
      end

      // periodic 2-cycle wait-state stall every 8 beats
      if (stall_cnt != 2'h0) begin
        stall_cnt <= stall_cnt - 2'h1;
        ready     <= 1'b0;
      end
      else begin
        ready <= valid;
        if (valid && ready && (beat_cnt == 4'h7)) begin
          stall_cnt <= 2'h2;
          ready     <= 1'b0;
        end
      end
    end
  end
endmodule
`endif
