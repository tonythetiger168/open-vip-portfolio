// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Speed Ethernet Interface
// Supports: 1G/100G/400G/800G/1.6T Ethernet, UEC, FC
//============================================================================
`ifndef NET_VIP_IF_SV
`define NET_VIP_IF_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

interface net_vip_if #(parameter int DATA_WIDTH = 512,
                       parameter int LANE_COUNT = 8,
                       parameter int PROTOCOL = 0)
                      (input logic clk, input logic rst_n);

  //==========================================================================
  // Common Signals
  //==========================================================================
  logic                    valid;
  logic                    ready;
  logic [DATA_WIDTH-1:0]   data;
  logic [LANE_COUNT-1:0]   lane_valid;
  logic                    sop;
  logic                    eop;
  logic [7:0]              be;

  //==========================================================================
  // Ethernet MAC/PCS Signals
  //==========================================================================
  logic [47:0] dst_mac;
  logic [47:0] src_mac;
  logic [15:0] ethertype;
  logic [11:0] vlan_id;
  logic [2:0]  vlan_pcp;
  logic        vlan_cfi;
  logic [31:0] fcs;
  logic        fcs_valid;
  logic        crc_ok;
  // FEC (800G/1.6T)
  logic        fec_enable;
  logic [7:0]  fec_symbol_errors;
  // PCS
  logic [1:0]  pcs_modulation;   // 0=NRZ, 1=PAM4
  logic [7:0]  pcs_lane_errors;

  //==========================================================================
  // Protocol-Specific Signals
  //==========================================================================
  // UEC Signals (Ultra Ethernet Consortium)
  logic [3:0]  uec_vc;
  logic [3:0]  uec_ai_tag;
  logic [7:0]  uec_congestion;
  // FC Signals (Fibre Channel)
  logic [23:0] fc_port_id;
  logic [7:0]  fc_speed;
  logic [15:0] fc_exchange;
  // Link State
  net_link_state_e link_state;
  logic        link_up;
  // Error Signals
  logic        fcs_error;
  logic        symbol_error;
  logic        link_error;
  logic        protocol_error;
  // Flow Control
  logic        pause_frame;
  logic        pfc_frame;
  logic [15:0] pause_time;
  // Bandwidth Utilization
  logic [31:0] bw_utilization;

  //==========================================================================
  // UEC sideband/helper signals (observed by the SVA compliance checker)
  //==========================================================================
  logic        fec_en;
  logic        pfc_en;
  logic [3:0]  port_num;
  logic [7:0]  llr_credit;
  logic [3:0]  retry_cnt;
  assign fec_en     = fec_enable;
  assign pfc_en     = pfc_frame;
  assign port_num   = 4'h0;
  assign llr_credit = 8'hFF;
  assign retry_cnt  = 4'h0;

  //==========================================================================
  // Clocking Blocks
  //==========================================================================
  clocking driver_cb @(posedge clk);
    default input #1step output #1ns;
    output valid, data, lane_valid, sop, eop, be;
    output dst_mac, src_mac, ethertype, vlan_id, vlan_pcp, vlan_cfi;
    output fcs, fcs_valid;
    output uec_vc, uec_ai_tag, uec_congestion;
    output fc_port_id, fc_speed, fc_exchange;
    output pause_frame, pfc_frame, pause_time;
    input  ready, link_up, link_state;
    input  crc_ok, fcs_error, symbol_error, link_error, protocol_error;
  endclocking

  clocking monitor_cb @(posedge clk);
    default input #1step;
    input valid, ready, data, lane_valid, sop, eop, be;
    input dst_mac, src_mac, ethertype, vlan_id, vlan_pcp, vlan_cfi;
    input fcs, fcs_valid, crc_ok;
    input fec_enable, fec_symbol_errors, pcs_modulation, pcs_lane_errors;
    input uec_vc, uec_ai_tag, uec_congestion;
    input fc_port_id, fc_speed, fc_exchange;
    input link_up, link_state;
    input fcs_error, symbol_error, link_error, protocol_error;
    input pause_frame, pfc_frame, pause_time, bw_utilization;
  endclocking

  //==========================================================================
  // Modports
  //==========================================================================
  modport driver_mp  (clocking driver_cb, input clk, rst_n);
  modport monitor_mp (clocking monitor_cb, input clk, rst_n);

  //==========================================================================
  // Assertion: Valid-Ready Handshake
  //==========================================================================
  property p_valid_ready_handshake;
    @(posedge clk) disable iff (!rst_n) valid |-> ##[1:100] ready;
  endproperty
  assert_valid_ready: assert property(p_valid_ready_handshake)
    else `uvm_error("NET_IF", "Valid-Ready handshake timeout");

  //==========================================================================
  // Assertion: SOP-EOP Alignment
  //==========================================================================
  property p_sop_eop_alignment;
    @(posedge clk) disable iff (!rst_n) sop |-> (!eop ##[1:256] eop);
  endproperty
  assert_sop_eop: assert property(p_sop_eop_alignment)
    else `uvm_error("NET_IF", "SOP-EOP alignment violation");

  //==========================================================================
  // Assertion: Link State Validity
  //==========================================================================
  property p_link_state_valid;
    @(posedge clk) disable iff (!rst_n)
      link_state inside {LINK_DOWN, LINK_ANEG, LINK_TRAINING, LINK_UP,
                         LINK_LOCAL_FAULT, LINK_REMOTE_FAULT, LINK_TEST, LINK_RECOVERY};
  endproperty
  assert_link_state: assert property(p_link_state_valid)
    else `uvm_error("NET_IF", "Invalid link state detected");

  //==========================================================================
  // Coverage: Interface Activity
  //==========================================================================
  covergroup cg_interface_activity @(posedge clk);
    option.per_instance = 1;
    cp_valid: coverpoint valid { bins inactive = {0}; bins active = {1}; }
    cp_ready: coverpoint ready { bins inactive = {0}; bins active = {1}; }
    cp_handshake: coverpoint {valid, ready} {
      bins idle = {2'b00}; bins wait_ready = {2'b10};
      bins transfer = {2'b11}; bins wait_valid = {2'b01};
    }
    cp_link_state: coverpoint link_state;
    cp_error: coverpoint {fcs_error, symbol_error, link_error, protocol_error} {
      bins no_error = {4'b0000}; bins fcs_err = {4'b1000};
      bins sym_err = {4'b0100}; bins link_err = {4'b0010}; bins proto_err = {4'b0001};
    }
    cross_hs_state: cross cp_handshake, cp_link_state;
  endgroup

  //==========================================================================
  // PHY Layer Signals (PAM4/NRZ modulation)
  //==========================================================================
  logic [31:0] phy_tx_data;
  logic        phy_tx_valid;
  logic [31:0] phy_rx_data;
  logic        phy_rx_valid;

  //==========================================================================
  // Coverage: PHY Layer
  //==========================================================================
  covergroup cg_phy_layer @(posedge clk);
    option.per_instance = 1;
    cp_modulation: coverpoint pcs_modulation { bins nrz = {2'b00}; bins pam4 = {2'b01}; }
    cp_lane_valid: coverpoint $countones(lane_valid) {
      bins x1 = {1}; bins x4 = {4}; bins x8 = {8}; bins other = default;
    }
    cp_fec_errors: coverpoint fec_symbol_errors iff (fec_enable) {
      bins zero = {8'h00}; bins low = {[8'h01:8'h0F]};
      bins med = {[8'h10:8'h7F]}; bins high = {[8'h80:8'hFF]};
    }
    cross_mod_lane: cross cp_modulation, cp_lane_valid;
  endgroup

  cg_interface_activity cg_act = new();
  cg_phy_layer          cg_phy = new();

endinterface
`endif
