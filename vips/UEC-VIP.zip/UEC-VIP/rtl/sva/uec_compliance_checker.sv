// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// UEC Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 18
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=Protocol-Specific Rules
`ifndef UEC_COMPLIANCE_CHECKER_SV
`define UEC_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

// ============================================================================
// uec_compliance_checker -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module uec_compliance_checker (net_vip_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; l4_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_uec_flit_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> ##[1:8] vif.ready; endproperty
  assert_p_uec_flit_valid: assert property(p_uec_flit_valid) l1_pass[0]++; else begin `uvm_warning("UEC_L1", "Flit valid implies ready failed"); l1_fail[0]++; end
  cover_p_uec_flit_valid: cover property(p_uec_flit_valid);
  property p_uec_crc_per_flit; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.crc_ok; endproperty
  assert_p_uec_crc_per_flit: assert property(p_uec_crc_per_flit) l1_pass[1]++; else begin `uvm_warning("UEC_L1", "CRC per flit failed"); l1_fail[1]++; end
  cover_p_uec_crc_per_flit: cover property(p_uec_crc_per_flit);
  property p_uec_port_num; @(posedge vif.clk) disable iff (!vif.rst_n) vif.port_num <= 8'd255; endproperty
  assert_p_uec_port_num: assert property(p_uec_port_num) l1_pass[2]++; else begin `uvm_warning("UEC_L1", "Port 0-255 failed"); l1_fail[2]++; end
  cover_p_uec_port_num: cover property(p_uec_port_num);
  property p_uec_sop_eop; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> $past(vif.sop,1) || vif.sop; endproperty
  assert_p_uec_sop_eop: assert property(p_uec_sop_eop) l1_pass[3]++; else begin `uvm_warning("UEC_L1", "SOP before EOP failed"); l1_fail[3]++; end
  cover_p_uec_sop_eop: cover property(p_uec_sop_eop);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_uec_llr_credit; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.llr_credit > 0; endproperty
  assert_p_uec_llr_credit: assert property(p_uec_llr_credit) l2_pass[0]++; else begin `uvm_warning("UEC_L2", "LLR credit > 0 failed"); l2_fail[0]++; end
  cover_p_uec_llr_credit: cover property(p_uec_llr_credit);
  property p_uec_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_uec_no_x: assert property(p_uec_no_x) l2_pass[1]++; else begin `uvm_warning("UEC_L2", "No X when valid failed"); l2_fail[1]++; end
  cover_p_uec_no_x: cover property(p_uec_no_x);
  property p_uec_link_up; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.link_up; endproperty
  assert_p_uec_link_up: assert property(p_uec_link_up) l2_pass[2]++; else begin `uvm_warning("UEC_L2", "Link up for traffic failed"); l2_fail[2]++; end
  cover_p_uec_link_up: cover property(p_uec_link_up);
  property p_uec_retry_limit; @(posedge vif.clk) disable iff (!vif.rst_n) vif.retry_cnt <= 4'd15; endproperty
  assert_p_uec_retry_limit: assert property(p_uec_retry_limit) l2_pass[3]++; else begin `uvm_warning("UEC_L2", "Retry <= 15 failed"); l2_fail[3]++; end
  cover_p_uec_retry_limit: cover property(p_uec_retry_limit);
  property p_uec_fec; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fec_en |-> vif.crc_ok; endproperty
  assert_p_uec_fec: assert property(p_uec_fec) l2_pass[4]++; else begin `uvm_warning("UEC_L2", "FEC valid failed"); l2_fail[4]++; end
  cover_p_uec_fec: cover property(p_uec_fec);
  property p_uec_pfc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pfc_en |-> vif.pause_time > 0; endproperty
  assert_p_uec_pfc: assert property(p_uec_pfc) l2_pass[5]++; else begin `uvm_warning("UEC_L2", "PFC valid failed"); l2_fail[5]++; end
  cover_p_uec_pfc: cover property(p_uec_pfc);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: stalled flit must hold valid until accepted
  property p_uec_l3_valid_hold; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && !vif.ready) |=> vif.valid; endproperty
  assert_p_uec_l3_valid_hold: assert property(p_uec_l3_valid_hold) l3_pass[0]++; else begin `uvm_warning("UEC_L3", "Valid dropped before ready failed"); l3_fail[0]++; end
  cover_p_uec_l3_valid_hold: cover property(p_uec_l3_valid_hold);
  // L3-2: while a PFC pause is active no new traffic may be transmitted
  property p_uec_l3_pfc_block; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.pfc_en && vif.pause_time > 0) |-> !vif.valid; endproperty
  assert_p_uec_l3_pfc_block: assert property(p_uec_l3_pfc_block) l3_pass[1]++; else begin `uvm_warning("UEC_L3", "Traffic during PFC pause failed"); l3_fail[1]++; end
  cover_p_uec_l3_pfc_block: cover property(p_uec_l3_pfc_block);
  // L3-3: FEC symbol errors may only be reported when FEC is enabled
  property p_uec_l3_fec_err_en; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.fec_symbol_errors > 8'h0) |-> vif.fec_en; endproperty
  assert_p_uec_l3_fec_err_en: assert property(p_uec_l3_fec_err_en) l3_pass[2]++; else begin `uvm_warning("UEC_L3", "FEC errors while FEC disabled failed"); l3_fail[2]++; end
  cover_p_uec_l3_fec_err_en: cover property(p_uec_l3_fec_err_en);
  // L3-4: congestion marking requires an operational link
  property p_uec_l3_cong_link; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.uec_congestion != 8'h0) |-> vif.link_up; endproperty
  assert_p_uec_l3_cong_link: assert property(p_uec_l3_cong_link) l3_pass[3]++; else begin `uvm_warning("UEC_L3", "Congestion marked while link down failed"); l3_fail[3]++; end
  cover_p_uec_l3_cong_link: cover property(p_uec_l3_cong_link);

  // ---------------- L4: UEC protocol-specific rules (4) ----------------
  // L4-1: every frame SOP is paired with an EOP within 256 cycles
  property p_uec_l4_sop_eop_pairing; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid && vif.sop && !vif.eop |-> ##[1:256] (vif.valid && vif.eop); endproperty
  assert_p_uec_l4_sop_eop_pairing: assert property(p_uec_l4_sop_eop_pairing) l4_pass[0]++; else begin `uvm_warning("UEC_L4", "Frame SOP without matching EOP"); l4_fail[0]++; end
  cover_p_uec_l4_sop_eop_pairing: cover property(p_uec_l4_sop_eop_pairing);
  // L4-2: UEC virtual channel stays constant within a frame
  property p_uec_l4_vc_stable_frame;
    logic [3:0] v;
    @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && vif.sop, v = vif.uec_vc) |-> (vif.uec_vc == v) until_with (vif.valid && vif.eop);
  endproperty
  assert_p_uec_l4_vc_stable_frame: assert property(p_uec_l4_vc_stable_frame) l4_pass[1]++; else begin `uvm_warning("UEC_L4", "VC changed inside a frame"); l4_fail[1]++; end
  cover_p_uec_l4_vc_stable_frame: cover property(p_uec_l4_vc_stable_frame);
  // L4-3: no new frame starts while the link is down
  property p_uec_l4_no_traffic_link_down; @(posedge vif.clk) disable iff (!vif.rst_n) !vif.link_up |-> !vif.sop; endproperty
  assert_p_uec_l4_no_traffic_link_down: assert property(p_uec_l4_no_traffic_link_down) l4_pass[2]++; else begin `uvm_warning("UEC_L4", "Traffic started before link up"); l4_fail[2]++; end
  cover_p_uec_l4_no_traffic_link_down: cover property(p_uec_l4_no_traffic_link_down);
  // L4-4: FCS error flag is only raised inside a frame
  property p_uec_l4_fcs_err_in_frame; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fcs_error |-> vif.valid; endproperty
  assert_p_uec_l4_fcs_err_in_frame: assert property(p_uec_l4_fcs_err_in_frame) l4_pass[3]++; else begin `uvm_warning("UEC_L4", "FCS error flagged outside a frame"); l4_fail[3]++; end
  cover_p_uec_l4_fcs_err_in_frame: cover property(p_uec_l4_fcs_err_in_frame);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("UEC_RPT", $sformatf("=== UEC Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("UEC_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("UEC_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("UEC_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("UEC_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("UEC_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule

`endif
