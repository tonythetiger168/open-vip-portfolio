# UEC — UEC (Ultra Ethernet Consortium) UVM VIP

Coverage-driven UVM verification IP for **UEC / multi-speed Ethernet**
(1G/100G/400G/800G/1.6T + FC companion UVCs share the same `net_vip_if` /
`net_vip_pkg` base so the fixed regression harness compiles and runs all
protocol agents).

## Protocol overview

UEC (Ultra Ethernet) extends Ethernet for AI/HPC fabrics: MAC frames
(dst/src MAC + EtherType + optional VLAN) are transported as header beat +
payload beats (`SOP`/`EOP` with `VALID`/`READY` handshake), carry a 4-bit
virtual channel (`uec_vc`), AI tags and congestion fields, with PFC/ECN
flow control and FEC on PAM4 lanes. Link state is reported through an
Ethernet-style `link_state` (DOWN/ANEG/TRAINING/UP/faults).

## Architecture

| Path | Description |
|------|-------------|
| `rtl/net_vip_if.sv` | Multi-protocol interface (params `DATA_WIDTH/LANE_COUNT/PROTOCOL`), driver/monitor clocking blocks, modports, inline SVA + 2 covergroups, UEC sideband helpers |
| `vip/base/net_vip_pkg.sv` | Enums (`net_protocol_e/net_link_state_e/frame_type_e/net_txn_status_e`), `net_txn_descriptor`, `net_sequence_item`, `net_protocol_config`, `net_coverage_model` (6 covergroups), end-to-end `net_scoreboard` |
| `vip/base/net_driver.sv` | Protocol-aware driver: SOP/EOP framing, per-beat READY handshake, UEC frame mode + header flit packing |
| `vip/base/net_monitor.sv` | Bus decoder: header capture, payload unpacking, error-flag tracking, publishes transactions |
| `vip/base/net_agent.sv` / `net_sequencer.sv` | Active/passive agent with protocol configuration propagation |
| `vip/uec/uec_protocol_checker.sv` | UEC-specific protocol checker (flit mode, VC/QoS range, flit boundary, 64B alignment) |
| `vip/{eth,fc}/*_protocol_checker.sv` | Companion protocol checkers |
| `rtl/sva/uec_compliance_checker.sv` | Tiered SVA compliance checker (L1/L2/L3/L4) |
| `env/net_env.sv` | 6-agent environment + end-to-end scoreboard wiring + coverage |
| `sequences/` | Sequence library (see below) |
| `tests/` | `mp_base_test` + per-protocol standalone tests + regression/PM/error tests |
| `tb/top_tb.sv` | Testbench top + functional DUT model (per-protocol responder channels, FCS error EtherType `0xEEEE`, wait-state stalls) |
| `scripts/` | Makefile + coverage-driven regression (line/fsm/toggle/SVA, 100% goal) |

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `net_base_sequence` | Random transactions for a target protocol |
| `net_random_sequence` | Weighted-protocol random traffic |
| `net_error_inject_sequence` | Directed: FCS error-EtherType + poisoned/short-frame/timeout variants |
| `net_pfc_pause_sequence` | Directed: L0s/L1/L2/Recovery transitions |
| `net_back_to_back_sequence` | Directed: zero-delay back-to-back flits |
| `net_stress_sequence` | Directed: high-volume large (256–512 B) payloads |
| `net_reset_sequence` | Directed: transfer right after reset release |
| `net_corner_sequence` | Directed: min/max payload corners (4/64/256/512 B) |
| `net_regression_sequence` | Weighted multi-phase mix incl. all directed sequences |

## SVA compliance (rtl/sva/uec_compliance_checker.sv)

- **L1 Basic (4)**: valid⇒ready, EtherType legality, min frame, FCS window
- **L2 Full protocol (6)**: SOP-EOP alignment, VLAN consistency, pause/PFC handling, no-X data, link-up for traffic, handshake
- **L3 Advanced (0)**: reserved
- **L4 UEC-specific (4)**: VC stable within a frame, flow-control only with link up, FCS error only during a frame, payload stable under backpressure

## Functional coverage (vip/base/net_vip_pkg.sv)

- `cg_txn_type`: protocol × transaction-type cross
- `cg_address_map`: address range + alignment
- `cg_data_patterns`: all-0/all-1/walking/random × cross
- `cg_latency`: latency distribution × protocol cross
- `cg_error_injection`: error type × recovery cross
- `cg_link_state`: link-state FSM + transition bins (link-up flow, L0⇄L0s/L1/L2, recovery)

## Quick start

```bash
cd scripts
make all                          # single run (VCS default)
TEST=net_uec_test make all
./coverage_regression.sh          # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

## Deepened Features (v1.6.0)

- **Protocol-aware driver**: UEC frame-based header+payload packing, per-beat READY handshakes, delay injection, expected-item broadcast
- **Waveform-decoding monitor**: SOP/EOP burst reconstruction with header capture, payload unpacking and error-flag tracking
- **End-to-end scoreboard**: driver-issued (expected) vs monitor-decoded (observed) compare (protocol/address/length/payload) with `n_matches`/`n_mismatches` and `UVM_ERROR` on mismatch
- **Functional DUT model**: per-protocol responder channels with link-state generation, loopback READY, periodic wait-state stalls, FCS error EtherType region
- **Directed sequence library**: 9 sequences (error / power-mgmt / back-to-back / stress / reset / corner / regression)
- **SVA L4**: 4 UEC-specific rules
- **Functional coverage**: 6 covergroups with cross coverage (incl. link-state FSM transitions)

License: Apache-2.0
