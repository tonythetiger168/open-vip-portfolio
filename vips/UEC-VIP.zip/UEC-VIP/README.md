# UEC UVM VIP (UEC-VIP)

UEC (Ultra Ethernet Consortium) UVM VIP: 512-bit packet pipe with min/max size policing (64..1518B) and 2-cycle pass-through latency. Smoke checks cover MTU drop and undersize drop for AI fabric transport.

## Structure

- `uec/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `uec_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `uec_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural UEC DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/UEC-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh UEC-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
