// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// uec_tests.sv -- UEC tests

package uec_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import uec_defs_pkg::*;
  import uec_pkg::*;
  import uec_env_pkg::*;

  // constrained-random traffic (cfg.num_items items)
  class uec_base_test extends uvm_test;
    `uvm_component_utils(uec_base_test)
    uec_env env;
    uec_config cfg;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      cfg = uec_config::type_id::create("cfg");
      uvm_config_db#(uec_config)::set(this, "*", "cfg", cfg);
      env = uec_env::type_id::create("env", this);
    endfunction

    virtual task stimulus();
      uec_base_sequence seq = uec_base_sequence::type_id::create("seq");
      seq.cfg = cfg;
      seq.start(env.agt.sqr);
    endtask

    task run_phase(uvm_phase phase);
      phase.raise_objection(this);
      stimulus();
      #(2000ns);   // let the monitor see the last DUT response
      phase.drop_objection(this);
    endtask

    // pass criteria: scoreboard checked traffic and nothing was reported
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      super.report_phase(phase);
      if (env.sb.n_checks == 0)
        `uvm_error("TEST", "scoreboard checked no traffic")
      else if (rs.get_severity_count(UVM_ERROR) == 0 && rs.get_severity_count(UVM_FATAL) == 0)
        $display("SB_PASS checks=%0d", env.sb.n_checks);
    endfunction
  endclass

  // directed corner cases, then random traffic; the test run on Verilator
  // by tools/run_uvm_tests.py
  class uec_func_test extends uec_base_test;
    `uvm_component_utils(uec_func_test)

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task stimulus();
      uec_directed_sequence dseq = uec_directed_sequence::type_id::create("dseq");
      dseq.cfg = cfg;
      dseq.start(env.agt.sqr);
      super.stimulus();
    endtask
  endclass
endpackage
