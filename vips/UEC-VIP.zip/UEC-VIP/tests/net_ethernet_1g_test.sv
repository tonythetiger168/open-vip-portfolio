// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_ethernet_1g_test.sv -- standalone test for NET_ETH_1G

`ifndef NET_ETHERNET_1G_TEST_SV
`define NET_ETHERNET_1G_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

class net_ethernet_1g_test extends net_base_test;
  `uvm_component_utils(net_ethernet_1g_test)
  function new(string name = "net_ethernet_1g_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_100g", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_400g", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_800g", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_1p6t", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_uec", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_fc", 0);
  endfunction
  virtual task run_phase(uvm_phase phase);
    net_random_sequence seq;
    phase.raise_objection(this);
    seq = net_random_sequence::type_id::create("seq");
    seq.num_frames = 200;
    seq.target_protocol = NET_ETH_1G;
    seq.start(env.eth_1g_agent.sqr);
    #2000ns;
    phase.drop_objection(this);
  endtask
endclass
`endif
