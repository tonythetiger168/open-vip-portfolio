// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_random_regression_test.sv -- random regression test (UEC-focused)

`ifndef NET_RANDOM_REGRESSION_TEST_SV
`define NET_RANDOM_REGRESSION_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

class net_random_regression_test extends net_base_test;
  `uvm_component_utils(net_random_regression_test)
  function new(string name = "net_random_regression_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual task run_phase(uvm_phase phase);
    net_random_sequence seq;
    phase.raise_objection(this);
    // UEC-focused random regression (deepened VIP target)
    seq = net_random_sequence::type_id::create("seq");
    seq.num_frames = 500;
    seq.target_protocol = NET_UEC;
    seq.enable_uec = 1;
    seq.start(env.uec_agent.sqr);
    // Ethernet sanity traffic on the 1G agent
    seq = net_random_sequence::type_id::create("seq2");
    seq.num_frames = 100;
    seq.target_protocol = NET_ETH_1G;
    seq.enable_eth = 1;
    seq.start(env.eth_1g_agent.sqr);
    #5000ns;
    phase.drop_objection(this);
  endtask
endclass
`endif
