// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_base_test.sv -- Multi-speed Ethernet base test

`ifndef NET_BASE_TEST_SV
`define NET_BASE_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

class net_base_test extends uvm_test;
  `uvm_component_utils(net_base_test)
  net_env env;
  function new(string name = "net_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = net_env::type_id::create("env", this);
  endfunction
  function void start_of_simulation_phase(uvm_phase phase);
    super.start_of_simulation_phase(phase);
    uvm_top.print_topology();
  endfunction
  virtual task run_phase(uvm_phase phase);
    phase.raise_objection(this);
    `uvm_info("TEST", "Base test running", UVM_LOW)
    #1000ns;
    phase.drop_objection(this);
  endtask
endclass
`endif
