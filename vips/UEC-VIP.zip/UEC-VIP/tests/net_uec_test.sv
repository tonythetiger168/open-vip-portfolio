// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_uec_test.sv -- standalone test for NET_UEC

`ifndef NET_UEC_TEST_SV
`define NET_UEC_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

class net_uec_test extends net_base_test;
  `uvm_component_utils(net_uec_test)
  function new(string name = "net_uec_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_1g", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_100g", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_400g", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_800g", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_eth_1p6t", 0);
    uvm_config_db#(bit)::set(this, "env", "enable_fc", 0);
  endfunction
  virtual task run_phase(uvm_phase phase);
    net_random_sequence seq;
    phase.raise_objection(this);
    seq = net_random_sequence::type_id::create("seq");
    seq.num_frames = 200;
    seq.target_protocol = NET_UEC;
    seq.start(env.uec_agent.sqr);
    #2000ns;
    phase.drop_objection(this);
  endtask
endclass
`endif
