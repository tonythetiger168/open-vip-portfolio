# I3C — MIPI I3C UVM VIP

Open-source UVM verification IP template for **MIPI I3C** (MIPI).

## Contents

| Path | Description |
|------|-------------|
| `i3c/i3c_if.sv` | Protocol interface (open-drain SDA + master-driven SCL) + FSM state enum |
| `i3c/i3c_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `i3c/sva/i3c_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=4) |
| `i3c/vip/i3c/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/i3c_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with two functional I3C target DUTs |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged SDR master driver**: START/STOP/repeated-START, open-drain SDA with
  master-driven SCL (push-pull semantics), byte-level ACK/NACK handling
- **ENTDAA dynamic addressing**: broadcast `7'h7E/W + 0x07`, repeated START, `0xFD`
  arbitration round with 8-byte provisioned ID (48-bit PID + BCR + DCR), dynamic
  address assignment byte; open-drain bit-level arbitration between two targets
- **CCC command support**: broadcast (ENEC/DISEC/RSTDAA/ENTHDR0) and direct
  (ENEC/DISEC) CCCs with defining bytes; unsupported CCCs are NACKed by the target
- **SDR read/write**: private transfers to the assigned dynamic address with an
  offset+payload register-file model (offsets >= 0x80 alias the direct-CCC space)
- **IBI modeling**: ENEC arms the target, which then pulses SDA low while the bus
  is idle; the monitor decodes the request and the scoreboard counts it separately
- **Protocol-decoding monitor**: reconstructs ENTDAA / CCC / SDR / IBI transactions
  from SDA/SCL waveforms (direct CCC vs SDR write split by the 0x80 code boundary)
- **End-to-end scoreboard**: expected (driver) vs observed (monitor) compare of
  address/CCC/NACK status and full write/read data contents
- **Functional DUT pair**: two I3C targets with different provisioned IDs;
  arbitration loser drops out, winner accepts the assigned address
- **Directed sequence library**: entdaa / ccc-bcast / ccc-direct / sdr-write /
  sdr-read / ibi / error-inject (unsupported CCC, unassigned-address conflict)
  + random + regression mix (ENTDAA always re-run after RSTDAA)
- **Functional coverage**: transfer-kind x length cross, CCC code bins, dynamic
  address bins, data corners, FSM state + chain transitions, NACK/IBI error bins
- **SVA L4 (bus-snooper based)**: SDR only after ENTDAA, broadcast CCC code range,
  dynamic address uniqueness, IBI only after ENEC enable
