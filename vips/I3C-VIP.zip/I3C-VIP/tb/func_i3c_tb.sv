// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator  (vvp 12 segfaults in the target model's ENTDAA ID transmit)
//
// func_i3c_tb.sv -- self-checking functional test for the I3C target model
// (i3c_target_model, flattened by smoke/flatten.py), with two targets on an
// open-drain SDA bus as in tb/top_tb.sv. Run: python3 tools/run_func_tests.py I3C-VIP
//
// Model contract (from tb/top_tb.sv), I3C SDR subset:
//   * broadcast 0x7E/W is ACKed; supported broadcast CCCs: ENEC 0x00,
//     DISEC 0x01, RSTDAA 0x06, ENTDAA 0x07, 0x20; others are NACKed.
//   * ENTDAA: Sr, 0x7E/R, each unassigned target sends PID[47:0], BCR, DCR
//     (8 bytes, a 9th clock after each), losing arbitration on a 0 it did not
//     send; the winner ACKs the dynamic address byte {addr, parity}.
//   * private write to the dynamic address: first byte < 0x80 sets the
//     register pointer, following bytes are stored with auto-increment;
//     a first byte >= 0x80 is a direct CCC (ENEC 0x80 / DISEC 0x81).
//   * private read returns bytes from the pointer until the master NACKs.
//   * known model defect (XFAIL): the target's bit receiver does not
//     recognise a repeated START, so the SCL rise of the Sr is taken as data
//     bit 7 and the 0x7E/R header of ENTDAA is never matched. ENTDAA is
//     therefore also run without the Sr to exercise the rest of the flow,
//     and a register read sets the pointer in its own write transfer.
//   * ENEC with ENINT (bit 3) arms an In-Band Interrupt: after 30 idle clocks
//     the target pulls SDA low for 3 clocks.

module func_i3c_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [2:0] ST_IDLE = 3'd0, ST_SDR = 3'd4;
  localparam bit [47:0] PID0 = 48'h0111_2222_3333, PID1 = 48'h0222_3333_4444;
  localparam time T = 20;
  int checks = 0, fails = 0, xfails = 0;

  logic clk = 1'b0, rst_n = 1'b0, scl = 1'b1, m_sda = 1'b1;
  logic [2:0] state = ST_SDR;
  wire  t0_o, t0_oe, t1_o, t1_oe;
  wire  sda = m_sda & (t0_oe ? t0_o : 1'b1) & (t1_oe ? t1_o : 1'b1);   // open drain

  always #5 clk = ~clk;

  i3c_target_model #(.PROV_ID(PID0), .BCR(8'h5A), .DCR(8'h3C)) tgt0 (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_sda_i(sda), .vif_scl_i(scl),
    .vif_slv_sda_o(t0_o), .vif_slv_sda_oe(t0_oe), .vif_state(state));
  i3c_target_model #(.PROV_ID(PID1), .BCR(8'h4B), .DCR(8'h2D)) tgt1 (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_sda_i(sda), .vif_scl_i(scl),
    .vif_slv_sda_o(t1_o), .vif_slv_sda_oe(t1_oe), .vif_state(state));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // ---- controller bit-level BFM (SCL push-pull, SDA open drain) ----
  task automatic start_c(); m_sda = 1; scl = 1; #T; m_sda = 0; #T; scl = 0; #T; endtask
  task automatic rstart(); m_sda = 1; #T; scl = 1; #T; m_sda = 0; #T; scl = 0; #T; endtask
  task automatic stop_c(); m_sda = 0; #T; scl = 1; #T; m_sda = 1; #T; endtask
  task automatic wbit(input bit b); m_sda = b; #T; scl = 1; #(2*T); scl = 0; #T; endtask
  task automatic rbit(output bit b); m_sda = 1; #T; scl = 1; #T; b = sda; #T; scl = 0; #T; endtask
  task automatic wbyte(input [7:0] d, output bit ack);
    bit a;
    for (int i = 7; i >= 0; i--) wbit(d[i]);
    rbit(a); ack = !a;
  endtask
  task automatic rbyte(output [7:0] d, input bit nack);
    for (int i = 7; i >= 0; i--) rbit(d[i]);
    wbit(nack);
  endtask

  bit a1, a2, a3;
  logic [7:0] id [8];

  // ENTDAA round assigning 'addr'; a1 = 7E/W ack, a2 = CCC ack, a3 = 7E/R ack
  bit da_ack;
  task automatic entdaa(input [6:0] addr, input bit use_sr);
    start_c();
    wbyte(8'hFC, a1);
    wbyte(8'h07, a2);
    if (use_sr) rstart();
    wbyte(8'hFD, a3);
    da_ack = 0;
    if (a3) begin
      for (int i = 0; i < 8; i++) rbyte(id[i], 1'b1);
      wbyte({addr, ~^addr}, da_ack);
    end
    stop_c();
    #(4*T);
  endtask

  task automatic bcast_ccc(input [7:0] ccc, input bit with_data = 0, input [7:0] d = '0);
    bit k;
    start_c();
    wbyte(8'hFC, a1);
    wbyte(ccc, a2);
    if (with_data && a2) wbyte(d, a3);
    stop_c();
    #(4*T);
  endtask

  task automatic priv_write(input [6:0] addr, input [7:0] ptr, input [7:0] d0, input [7:0] d1,
                            input [7:0] d2, output bit all_ack);
    bit k;
    start_c();
    wbyte({addr, 1'b0}, a1);
    all_ack = a1;
    if (a1) begin
      wbyte(ptr, k); all_ack &= k;
      wbyte(d0, k);  all_ack &= k;
      wbyte(d1, k);  all_ack &= k;
      wbyte(d2, k);  all_ack &= k;
    end
    stop_c();
    #(4*T);
  endtask

  logic [7:0] rd [3];
  task automatic priv_read(input [6:0] addr, input [7:0] ptr);
    bit k;
    start_c();
    wbyte({addr, 1'b0}, a1);
    if (a1) wbyte(ptr, k);
    stop_c();               // P + S rather than Sr: see the XFAIL note above
    #(4*T);
    start_c();
    wbyte({addr, 1'b1}, a2);
    if (a2) begin
      rbyte(rd[0], 1'b0);
      rbyte(rd[1], 1'b0);
      rbyte(rd[2], 1'b1);
    end
    stop_c();
    #(4*T);
  endtask

  function automatic bit id_is(input [47:0] pid, input [7:0] bcr, input [7:0] dcr);
    for (int i = 0; i < 6; i++) if (id[i] !== pid[47 - i*8 -: 8]) return 0;
    return id[6] === bcr && id[7] === dcr;
  endfunction

  // watch for an IBI: SDA pulled low by a target while the bus is idle
  bit ibi_seen;
  always @(negedge sda) if (state == ST_IDLE && scl === 1'b1 && m_sda === 1'b1) ibi_seen = 1;

  bit ok;

  initial begin
    #(3*T); rst_n = 1'b1; #(3*T);

    // ---- dynamic address assignment ----
    entdaa(7'h0A, 1);
    chk_xfail(a3 && da_ack && tgt0.assigned, "ENTDAA with a repeated START before 0x7E/R");
    chk(!tgt0.assigned && !tgt1.assigned, "aborted ENTDAA leaves both targets unassigned");
    entdaa(7'h0A, 0);
    chk(a1 && a2, "broadcast 7E/W and ENTDAA CCC are ACKed");
    chk(a3, "7E/R is ACKed by an unassigned target");
    chk(id_is(PID0, 8'h5A, 8'h3C), "ENTDAA arbitration: lowest PID wins and its PID/BCR/DCR is read");
    chk(da_ack && tgt0.assigned && tgt0.dyn_addr == 7'h0A && !tgt1.assigned,
        "winner ACKs and takes dynamic address 0x0A; loser stays unassigned");
    entdaa(7'h0B, 0);
    chk(id_is(PID1, 8'h4B, 8'h2D) && tgt1.assigned && tgt1.dyn_addr == 7'h0B,
        "second ENTDAA assigns 0x0B to the remaining target");
    entdaa(7'h0C, 0);
    chk(!a3, "ENTDAA with every target assigned: 7E/R is NACKed");

    // ---- private transfers ----
    priv_write(7'h0A, 8'h10, 8'hA0, 8'hA1, 8'hA2, ok);
    chk(ok, "private write to 0x0A: address, pointer and data bytes ACKed");
    chk(tgt0.mem[16] === 8'hA0 && tgt0.mem[17] === 8'hA1 && tgt0.mem[18] === 8'hA2,
        "private write stores bytes with pointer auto-increment");
    chk(tgt1.mem[16] === 8'h00, "the other target is not written");
    priv_read(7'h0A, 8'h10);
    chk(a2 && rd[0] === 8'hA0 && rd[1] === 8'hA1 && rd[2] === 8'hA2,
        "private read returns bytes from the pointer until NACK");
    priv_write(7'h0C, 8'h00, 8'h1, 8'h2, 8'h3, ok);
    chk(!a1, "unassigned address 0x0C is NACKed");

    // ---- CCCs ----
    bcast_ccc(8'h29);
    chk(a1 && !a2, "unsupported broadcast CCC is NACKed");

    // ENEC(ENINT) arms an IBI that is raised once the bus is idle
    state = ST_SDR;
    bcast_ccc(8'h00, 1, 8'h08);
    chk(a2 && a3 && tgt0.ibi_en && tgt1.ibi_en, "ENEC with ENINT is ACKed and enables IBIs");
    ibi_seen = 0;
    state = ST_IDLE;
    repeat (25) @(posedge clk);
    chk(!ibi_seen, "no IBI before 30 idle clocks");
    repeat (20) @(posedge clk);
    chk(ibi_seen, "IBI request (SDA pulled low) after the bus is idle");
    repeat (10) @(posedge clk);
    chk(sda === 1'b1 && !tgt0.ibi_pending, "IBI pulse released, request cleared");
    state = ST_SDR;
    bcast_ccc(8'h01, 1, 8'h08);
    chk(!tgt0.ibi_en && !tgt1.ibi_en, "DISEC with ENINT disables IBIs");

    // RSTDAA drops every dynamic address
    bcast_ccc(8'h06);
    chk(a2 && !tgt0.assigned && !tgt1.assigned, "RSTDAA clears the dynamic addresses");
    priv_write(7'h0A, 8'h00, 8'h1, 8'h2, 8'h3, ok);
    chk(!a1, "old dynamic address is NACKed after RSTDAA");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
