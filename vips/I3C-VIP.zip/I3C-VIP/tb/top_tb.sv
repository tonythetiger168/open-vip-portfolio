// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- MIPI I3C testbench top with two functional I3C target DUTs
// Two targets with different provisioned IDs participate in ENTDAA
// arbitration (open-drain wired-AND), accept dynamic addresses 0x20/0x21,
// handle broadcast/direct CCCs and serve SDR read/write from a register
// file. Target 0 also raises IBI requests once enabled via ENEC.

`ifndef I3C_TB_SV
`define I3C_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import i3c_defs_pkg::*;
import i3c_pkg::*;
import i3c_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  i3c_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // Lower provisioned ID wins ENTDAA arbitration (assigned 0x20 first)
  i3c_target_model #(.PROV_ID(48'h0111_2222_3333), .BCR(8'h5A), .DCR(8'h3C)) tgt0 (.vif(vif));
  i3c_target_model #(.PROV_ID(48'h0222_3333_4444), .BCR(8'h4B), .DCR(8'h2D)) tgt1 (.vif(vif));

  initial begin
    uvm_config_db#(virtual i3c_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional I3C target: ENTDAA arbitration + CCC handling + SDR regfile
module i3c_target_model #(parameter bit [47:0] PROV_ID = 48'h0,
                          parameter bit [7:0]  BCR = 8'h00,
                          parameter bit [7:0]  DCR = 8'h00)
  (i3c_if vif);

  bit       assigned;
  bit [6:0] dyn_addr;
  bit       ibi_en;
  bit       ibi_pending;
  bit [7:0] mem [0:127];       // 128-byte register file (2-state, reads 0)
  bit [6:0] rd_ptr;

  initial begin
    vif.slv_sda_o  = 0;
    vif.slv_sda_oe = 0;
  end

  function bit [7:0] id_byte(int idx);
    if (idx < 6)  return PROV_ID[47 - idx*8 -: 8];  // 48-bit PID, MSB first
    if (idx == 6) return BCR;
    return DCR;
  endfunction

  function bit ccc_supported_bcast(bit [7:0] c);
    return (c == 8'h00 || c == 8'h01 || c == 8'h06 || c == 8'h07 || c == 8'h20);
  endfunction
  function bit ccc_supported_direct(bit [7:0] c);
    return (c == 8'h80 || c == 8'h81);
  endfunction

  // Receive 8 bits; `stopped` set if a STOP condition terminates the byte
  // Single-threaded (no fork/disable fork): each half-bit wait also
  // watches for STOP (sda rising while scl high), like @(posedge sda iff scl).
  task automatic slv_recv_bits(output bit [7:0] d, output bit stopped);
    bit ps, pd, got;
    d = '0; stopped = 0;
    ps = vif.scl_i; pd = vif.sda_i;
    for (int i = 7; i >= 0 && !stopped; i--) begin
      // wait for scl rising edge or STOP
      got = 0;
      while (!got && !stopped) begin
        @(vif.scl_i or vif.sda_i);
        if (vif.scl_i === 1'b1 && ps === 1'b0)                            got = 1;
        else if (vif.sda_i === 1'b1 && pd === 1'b0 && vif.scl_i === 1'b1) stopped = 1;
        ps = vif.scl_i; pd = vif.sda_i;
      end
      if (!stopped) begin
        d[i] = vif.sda_i;
        // wait for scl falling edge or STOP
        got = 0;
        while (!got && !stopped) begin
          @(vif.scl_i or vif.sda_i);
          if (vif.scl_i === 1'b0 && ps === 1'b1)                            got = 1;
          else if (vif.sda_i === 1'b1 && pd === 1'b0 && vif.scl_i === 1'b1) stopped = 1;
          ps = vif.scl_i; pd = vif.sda_i;
        end
      end
    end
  endtask

  // Drive (ack=1: pull SDA low) or release the 9th-bit ACK slot
  task automatic slv_ack_slot(input bit ack);
    if (ack) begin vif.slv_sda_oe = 1; vif.slv_sda_o = 0; end
    @(posedge vif.scl_i);
    @(negedge vif.scl_i);
    vif.slv_sda_oe = 0;
  endtask

  // Send one byte, MSB first, with open-drain arbitration loss detect;
  // then release and sample the master ACK/NACK slot.
  task automatic slv_send_byte(input bit [7:0] d, output bit mst_nack, output bit lost);
    mst_nack = 0; lost = 0;
    vif.slv_sda_oe = 1; vif.slv_sda_o = d[7];       // MSB during current low phase
    for (int i = 7; i >= 0 && !lost; i--) begin
      @(posedge vif.scl_i);
      if (vif.sda_i !== d[i]) begin                 // another target drove lower
        vif.slv_sda_oe = 0; lost = 1;
      end else begin
        @(negedge vif.scl_i);
        if (i > 0) begin vif.slv_sda_oe = 1; vif.slv_sda_o = d[i-1]; end
      end
    end
    if (!lost) begin
      vif.slv_sda_oe = 0;
      @(posedge vif.scl_i);
      mst_nack = vif.sda_i;
      @(negedge vif.scl_i);
    end
  endtask

  // ENTDAA participation: Sr + 0xFD, drive provisioned ID with arbitration,
  // receive the dynamic address assignment. Non-participating if assigned.
  task automatic do_entdaa();
    bit [7:0] b;
    bit stopped, nack, lost;
    bit abort;
    abort = 0;
    if (!assigned) begin
      slv_recv_bits(b, stopped);                    // repeated START + 0xFD
      if (stopped || b != 8'hFD) abort = 1;
      if (!abort) begin
        slv_ack_slot(1'b1);                         // join the arbitration round
        lost = 0;
        for (int i = 0; i < 8 && !lost; i++) begin
          slv_send_byte(id_byte(i), nack, lost);    // lost arbitration: drop out
        end
        if (lost) abort = 1;
      end
      if (!abort) begin
        slv_recv_bits(b, stopped);                  // assigned dynamic address
        if (stopped) abort = 1;
      end
      if (!abort) begin
        slv_ack_slot(1'b1);
        dyn_addr = b[7:1];
        assigned = 1;
      end
    end
  endtask

  task automatic do_event_ccc(input bit [7:0] ccc);
    bit [7:0] d;
    bit stopped;
    slv_recv_bits(d, stopped);                      // defining byte
    if (!stopped) begin
      slv_ack_slot(1'b1);
      if (ccc == 8'h00 || ccc == 8'h80) begin       // ENEC
        if (d[3]) begin ibi_en = 1; ibi_pending = 1; end
      end else begin                                // DISEC
        if (d[3]) ibi_en = 0;
      end
    end
  endtask

  // Main address-decode loop
  initial forever begin
    bit [7:0] b, d;
    bit stopped, nack, lost;
    bit started;
    // START / repeated START -- @(negedge sda iff scl) as a polling loop
    started = 0;
    while (!started) begin
      @(negedge vif.sda_i);
      if (vif.scl_i === 1'b1) started = 1;
    end
    if (vif.rst_n) begin
      slv_recv_bits(b, stopped);
      if (!stopped) begin

      if (b[7:1] == 7'h7E && b[0] == 1'b0) begin
        // -------- broadcast CCC --------
        slv_ack_slot(1'b1);                         // all targets ACK 7'h7E/W
        slv_recv_bits(b, stopped);
        if (!stopped) begin
          slv_ack_slot(ccc_supported_bcast(b));     // NACK unsupported CCCs
          if (ccc_supported_bcast(b)) begin
            case (b)
              8'h07:       do_entdaa();
              8'h00, 8'h01: do_event_ccc(b);        // ENEC / DISEC
              8'h06:       assigned = 0;            // RSTDAA
              default:     ;                        // ENTHDR0: no payload
            endcase
          end
        end
      end else if (assigned && b[7:1] == dyn_addr) begin
        // -------- addressed transfer --------
        slv_ack_slot(1'b1);
        if (b[0]) begin
          nack = 0; lost = 0;
          while (!nack && !lost) begin              // SDR read
            slv_send_byte(mem[rd_ptr], nack, lost);
            rd_ptr++;
          end
        end else begin
          slv_recv_bits(d, stopped);
          if (!stopped) begin
            if (d >= 8'h80) begin                   // direct CCC code space
              slv_ack_slot(ccc_supported_direct(d));
              if (ccc_supported_direct(d))
                do_event_ccc(d);                    // ENEC_D / DISEC_D
            end else begin                          // SDR write: offset+payload
              slv_ack_slot(1'b1);
              rd_ptr = d[6:0];
              stopped = 0;
              while (!stopped) begin
                slv_recv_bits(d, stopped);
                if (!stopped) begin
                  mem[rd_ptr] = d;
                  slv_ack_slot(1'b1);
                  rd_ptr++;
                end
              end
            end
          end
        end
      end
      end
    end
    // not addressed: stay silent, resync on the next START
  end

  // IBI request: pulse SDA low while the bus is idle (after ENEC armed it)
  initial forever begin
    int idle_cnt;
    wait (ibi_pending && ibi_en);
    idle_cnt = 0;
    while (idle_cnt < 30) begin                     // require sustained bus idle
      @(posedge vif.clk);
      if (vif.state == i3c_defs_pkg::IDLE && vif.scl_i && vif.sda_i) idle_cnt++;
      else idle_cnt = 0;
    end
    vif.slv_sda_oe = 1; vif.slv_sda_o = 0;          // IBI request pulse
    begin
      int k;
      bit abort;
      k = 0; abort = 0;
      while (k < 3 && !abort) begin
        @(posedge vif.clk);
        if (vif.state != i3c_defs_pkg::IDLE) abort = 1;  // abort if master starts
        k++;
      end
    end
    vif.slv_sda_oe = 0;
    ibi_pending = 0;
  end
endmodule
`endif
