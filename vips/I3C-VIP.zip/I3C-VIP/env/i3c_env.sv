// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// env_pkg.sv -- MIPI I3C verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import i3c_defs_pkg::*;
  import i3c_pkg::*;

  // End-to-end scoreboard: compares driver-issued (expected) transactions
  // against monitor-decoded (observed) transactions. Target-initiated IBI
  // requests have no expected counterpart and are counted separately.
    `uvm_analysis_imp_decl(_exp)
    `uvm_analysis_imp_decl(_obs)

  class i3c_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(i3c_scoreboard)
    uvm_analysis_imp_exp #(i3c_transaction, i3c_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(i3c_transaction, i3c_scoreboard) obs_ap;

    i3c_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, mismatches = 0, ibi_count = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(i3c_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(i3c_transaction t);
      if (t.is_ibi) begin ibi_count++; return; end   // target initiated
      obs_q.push_back(t); check();
    endfunction

    function bit bytes_match(bit [7:0] a[$], bit [7:0] b[$]);
      if (a.size() != b.size()) return 0;
      foreach (a[i]) if (a[i] !== b[i]) return 0;
      return 1;
    endfunction

    function bit txn_match(i3c_transaction e, i3c_transaction o);
      if (e.is_ccc != o.is_ccc) return 0;
      if (e.addr_nack != o.addr_nack) return 0;
      if (e.is_ccc) begin
        if (e.ccc != o.ccc || e.ccc_type != o.ccc_type) return 0;
        if (e.ccc_nack != o.ccc_nack) return 0;
        if (e.ccc == i3c_transaction::CCC_ENTDAA) begin
          if (e.assigned_ok != o.assigned_ok) return 0;
          return !e.assigned_ok || (e.dyn_addr == o.dyn_addr);
        end
        if (e.ccc_nack || e.addr_nack) return 1;   // aborted before data
        return bytes_match(e.data, o.data);
      end
      if (e.dyn_addr != o.dyn_addr || e.rnw != o.rnw) return 0;
      if (e.addr_nack) return 1;                    // no target responded
      if (!e.rnw) return bytes_match(e.data, o.data);
      return bytes_match(e.rdata, o.rdata);
    endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        i3c_transaction e = exp_q.pop_front();
        i3c_transaction o = obs_q.pop_front();
        if (txn_match(e, o)) n_matches++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("i3c scoreboard: n_matches=%0d mismatches=%0d ibi=%0d",
                n_matches, mismatches, ibi_count), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class i3c_env extends uvm_env;
    `uvm_component_utils(i3c_env)
    i3c_agent      agt;
    i3c_scoreboard sb;
    i3c_checker    chk;
    i3c_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = i3c_agent::type_id::create("agt", this);
      sb  = i3c_scoreboard::type_id::create("sb", this);
      chk = i3c_checker::type_id::create("chk", this);
      cov = i3c_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
