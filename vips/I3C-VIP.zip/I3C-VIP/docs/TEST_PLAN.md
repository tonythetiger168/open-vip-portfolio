# MIPI I3C Test Plan（I3C-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | MIPI I3C |
| 家族 | MIPI |
| 類型 | UVM VIP |
| 交付目錄 | `I3C-VIP/` |
| 目前 L1b 狀態 | PASS |

## 2. DUT / 待測對象

- `i3c_target_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke

- 狀態：**尚未導入**（目前為 model smoke / directed-tb smoke）
- 導入方式：比照 `gen_func_tb.py` 產出的 self-checking tb，對展平後的 behavioral model 做 directed 檢查

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Agent reset and first-transaction bring-up |
| PT-02 | Constrained-random sequence sweep (base sequence extended) |
| PT-03 | Error injection and protocol-violation response |
| PT-04 | Backpressure / wait-state interaction |
| PT-05 | End-to-end scoreboard matching (exp vs obs streams) |
| PT-06 | Coverage closure toward the self-served COV_GOAL=100 checklist |

## 5. 覆蓋與檢查

**Coverpoints（功能覆蓋取樣點）：**

- `tr.addr_nack`
- `tr.assigned_ok`
- `tr.ccc`
- `tr.ccc_nack`
- `tr.dyn_addr`

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/I3C-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py I3C-VIP && python3 smoke/smoke_run.py I3C-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- functional smoke 未導入：model 為 I3C target，需 controller 側 ENTDAA bit-bang，列入後續輪次。

---
*文件版本：v1.7.5 自動產生*
