// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i3c_transaction.svh -- MIPI I3C transaction
// One item models exactly one bus transfer:
//   * ENTDAA dynamic address assignment  (is_ccc=1, ccc=8'h07, broadcast)
//   * Broadcast / direct CCC command     (is_ccc=1)
//   * Private SDR write / read           (is_ccc=0, rnw selects direction)

`ifndef I3C_TRANSACTION_SVH
`define I3C_TRANSACTION_SVH

class i3c_transaction extends uvm_sequence_item;

  // CCC framing: broadcast (to 7'h7E) or direct (to a dynamic address)
  typedef enum bit {CCC_BROADCAST = 1'b0, CCC_DIRECT = 1'b1} i3c_ccc_type_e;

  localparam bit [7:0] CCC_ENEC_B   = 8'h00;  // enable events (broadcast)
  localparam bit [7:0] CCC_DISEC_B  = 8'h01;  // disable events (broadcast)
  localparam bit [7:0] CCC_RSTDAA_B = 8'h06;  // reset dynamic address
  localparam bit [7:0] CCC_ENTDAA   = 8'h07;  // enter dynamic address assignment
  localparam bit [7:0] CCC_ENTHDR0  = 8'h20;  // enter HDR-DDR mode 0
  localparam bit [7:0] CCC_ENEC_D   = 8'h80;  // enable events (direct)
  localparam bit [7:0] CCC_DISEC_D  = 8'h81;  // disable events (direct)

  rand bit              is_ccc;          // 1 = CCC transfer, 0 = private SDR
  rand i3c_ccc_type_e   ccc_type;        // broadcast / direct (CCC only)
  rand bit [7:0]        ccc;             // CCC command code
  rand bit [6:0]        dyn_addr;        // target dynamic address
  rand bit              rnw;             // SDR: 1 = read, 0 = write
  rand bit [7:0]        data[$];         // SDR write: {reg offset, payload...}
                                         // CCC: defining/data byte(s)

  // Status / observed fields (filled by driver and monitor)
  bit [7:0]       rdata[$];              // SDR read data / ENTDAA provisioned ID
  bit             addr_nack;             // address phase NACKed
  bit             ccc_nack;              // CCC code NACKed (unsupported CCC)
  bit             assigned_ok;           // ENTDAA: target ACKed assigned address
  bit             is_ibi;                // monitor: target-initiated IBI request
  i3c_state_e     state;                 // dominant protocol phase (coverage)

  constraint c_ccc_range {
    (is_ccc && ccc_type == CCC_BROADCAST) -> ccc inside {[8'h00 : 8'h7F]};
    (is_ccc && ccc_type == CCC_DIRECT)    -> ccc inside {[8'h80 : 8'hFE]};
  }
  constraint c_entdaa_bcast {
    (is_ccc && ccc == CCC_ENTDAA) -> ccc_type == CCC_BROADCAST;
  }
  constraint c_addr {
    dyn_addr inside {[7'h08 : 7'h77]};    // 7'h7E reserved (broadcast)
  }
  constraint c_len {
    data.size() inside {[0:8]};
    (!is_ccc && !rnw) -> data.size() inside {[2:8]};   // offset + >=1 payload
    (!is_ccc &&  rnw) -> data.size() inside {[1:8]};   // read byte count
    (is_ccc && ccc_type == CCC_DIRECT) -> data.size() == 1;
    (is_ccc && ccc == CCC_ENTDAA) -> data.size() == 0;
  }
  constraint c_sdr_offset {
    // offsets >= 0x80 would alias the direct-CCC code space (model rule)
    (!is_ccc && !rnw && data.size() > 0) -> data[0] < 8'h80;
  }

  `uvm_object_utils_begin(i3c_transaction)
    `uvm_field_int(is_ccc, UVM_ALL_ON)
    `uvm_field_enum(i3c_ccc_type_e, ccc_type, UVM_ALL_ON)
    `uvm_field_int(ccc, UVM_ALL_ON)
    `uvm_field_int(dyn_addr, UVM_ALL_ON)
    `uvm_field_int(rnw, UVM_ALL_ON)
    `uvm_field_queue_int(data, UVM_ALL_ON)
    `uvm_field_queue_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(addr_nack, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(ccc_nack, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(assigned_ok, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(is_ibi, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "i3c_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    i3c_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= (comparer.compare_field("dyn_addr", dyn_addr, t.dyn_addr, 7) == 1);
    do_compare &= (comparer.compare_field("is_ccc",   is_ccc,   t.is_ccc,   1) == 1);
    if (is_ccc)
      do_compare &= (comparer.compare_field("ccc", ccc, t.ccc, 8) == 1);
    else begin
      do_compare &= (comparer.compare_field("rnw", rnw, t.rnw, 1) == 1);
      do_compare &= (comparer.compare_field("data_size", data.size(), t.data.size(), 32) == 1);
    end
  endfunction

  function string convert2string();
    string s;
    if (is_ibi) return "I3C IBI request (target initiated)";
    if (is_ccc && ccc == CCC_ENTDAA && ccc_type == CCC_BROADCAST)
      s = $sformatf("I3C ENTDAA assign dyn=0x%02h ok=%0d", dyn_addr, assigned_ok);
    else if (is_ccc)
      s = $sformatf("I3C CCC %s code=0x%02h addr=0x%02h len=%0d nack=%0d",
                    ccc_type == CCC_DIRECT ? "DIRECT" : "BCAST",
                    ccc, dyn_addr, data.size(), ccc_nack);
    else begin
      s = $sformatf("I3C SDR %s addr=0x%02h len=%0d nack=%0d",
                    rnw ? "RD" : "WR", dyn_addr,
                    rnw ? rdata.size() : data.size(), addr_nack);
      if (!rnw) foreach (data[i])  s = {s, $sformatf(" %02h", data[i])};
      if ( rnw) foreach (rdata[i]) s = {s, $sformatf(" %02h", rdata[i])};
    end
    return s;
  endfunction
endclass
`endif
