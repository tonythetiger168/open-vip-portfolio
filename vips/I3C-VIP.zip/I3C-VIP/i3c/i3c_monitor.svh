// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i3c_monitor.svh -- MIPI I3C monitor
// Decodes SDR-mode waveforms (SDA open-drain / SCL master clock) into
// transactions: ENTDAA address assignment, broadcast/direct CCC, private
// SDR read/write, and target-initiated IBI request pulses.
// Decode rule (model simplification, shared with the DUT): on an
// addressed write, a first byte >= 0x80 is a direct CCC code, otherwise
// it is an SDR register offset.

`ifndef I3C_MONITOR_SVH
`define I3C_MONITOR_SVH

class i3c_monitor extends uvm_monitor;
  `uvm_component_utils(i3c_monitor)
  virtual i3c_if vif;
  uvm_analysis_port #(i3c_transaction) ap;
  int unsigned txn_count = 0;

  protected bit sda_d, scl_d;   // delayed samples for START edge detect

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual i3c_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "i3c virtual interface not set")
  endfunction

  // Sample one byte + ACK slot; `stopped` is set instead if a STOP
  // condition (SDA rises while SCL high) terminates the transfer.
  task automatic read_byte_or_stop(output bit [7:0] d, output bit ack,
                                   output bit stopped);
    d = '0; ack = 1'b1; stopped = 0;
    fork
      begin : b_byte
        for (int i = 7; i >= 0; i--) begin
          @(posedge vif.scl_i);            // data valid while SCL high
          d[i] = vif.sda_i;
          @(negedge vif.scl_i);
        end
        @(posedge vif.scl_i);              // ACK slot
        ack = vif.sda_i;
        @(negedge vif.scl_i);
      end
      begin : b_stop
        forever begin
          @(posedge vif.sda_i);
          if (vif.scl_i) begin             // STOP (repeated START never
            stopped = 1;                   // raises SDA while SCL high)
            disable b_byte;
          end
        end
      end
    join_any
    disable fork;
  endtask

  // Decode one full transfer starting after the START condition.
  task automatic decode_transfer();
    i3c_transaction tr;
    bit [7:0] b;
    bit       ack, stopped;
    tr = i3c_transaction::type_id::create("tr");
    tr.state = vif.state;

    read_byte_or_stop(b, ack, stopped);
    if (stopped) return;                   // degenerate START/STOP, discard

    if (b[7:1] == 7'h7E && b[0] == 1'b0) begin
      // ---- broadcast CCC ----
      tr.is_ccc   = 1;
      tr.ccc_type = i3c_transaction::CCC_BROADCAST;
      read_byte_or_stop(b, ack, stopped);
      tr.ccc      = b;
      tr.ccc_nack = ack;
      if (!stopped && !ack && b == i3c_transaction::CCC_ENTDAA) begin
        read_byte_or_stop(b, ack, stopped);           // Sr + 0xFD
        if (!stopped && !ack && b == 8'hFD) begin
          for (int i = 0; i < 8; i++) begin           // provisioned ID
            read_byte_or_stop(b, ack, stopped);
            if (stopped) break;
            tr.rdata.push_back(b);
          end
          if (!stopped) begin
            read_byte_or_stop(b, ack, stopped);       // assigned address
            if (!stopped) begin
              tr.dyn_addr    = b[7:1];
              tr.assigned_ok = !ack;
            end
          end
        end
      end else if (!stopped && !ack) begin
        forever begin                                  // CCC data bytes
          read_byte_or_stop(b, ack, stopped);
          if (stopped) break;
          tr.data.push_back(b);
        end
      end
    end else begin
      // ---- addressed transfer: SDR or direct CCC ----
      tr.dyn_addr  = b[7:1];
      tr.rnw       = b[0];
      tr.addr_nack = ack;
      if (!ack) begin
        if (b[0]) begin
          forever begin                                // SDR read
            read_byte_or_stop(b, ack, stopped);
            if (stopped) break;
            tr.rdata.push_back(b);
          end
        end else begin
          read_byte_or_stop(b, ack, stopped);
          if (!stopped) begin
            if (b >= 8'h80) begin                      // direct CCC code
              tr.is_ccc   = 1;
              tr.ccc_type = i3c_transaction::CCC_DIRECT;
              tr.ccc      = b;
              tr.ccc_nack = ack;
              if (!ack) begin
                forever begin
                  read_byte_or_stop(b, ack, stopped);
                  if (stopped) break;
                  tr.data.push_back(b);
                end
              end
            end else begin                             // SDR write
              tr.data.push_back(b);
              forever begin
                read_byte_or_stop(b, ack, stopped);
                if (stopped) break;
                tr.data.push_back(b);
              end
            end
          end
        end
      end
    end
    txn_count++;
    `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
    ap.write(tr);
  endtask

  task run_phase(uvm_phase phase);
    i3c_transaction tr;
    sda_d = 1; scl_d = 1;
    forever begin
      @(vif.mon_cb);
      if (!vif.mon_cb.rst_n) begin sda_d = 1; scl_d = 1; continue; end

      // START condition: SDA falls while SCL high
      if (scl_d && sda_d && !vif.mon_cb.sda_i && vif.mon_cb.scl_i) begin
        if (vif.mon_cb.state == i3c_defs_pkg::IDLE) begin
          // Bus idle, master not transferring: target IBI request pulse
          tr = i3c_transaction::type_id::create("tr");
          tr.is_ibi = 1;
          tr.state  = i3c_defs_pkg::IBI;
          txn_count++;
          `uvm_info("MON", "mon: IBI request pulse decoded", UVM_HIGH)
          ap.write(tr);
        end else begin
          decode_transfer();
        end
      end
      sda_d = vif.mon_cb.sda_i;
      scl_d = vif.mon_cb.scl_i;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("i3c monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
