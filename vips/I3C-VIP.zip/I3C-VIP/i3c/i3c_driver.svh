// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i3c_driver.svh -- MIPI I3C master driver (bit-banged SDR mode)
// Drives I2C-like SDR transfers: SDA open-drain, SCL master-driven.
// Supports ENTDAA dynamic address assignment, broadcast/direct CCCs and
// private SDR read/write. The `vif.state` sideband walks the legal FSM
// chain (IDLE->ENTDAA->CCC->HDR_DDR->SDR->IBI->IDLE), dwelling on the
// dominant phase of each transfer, so FSM coverage and L2 FSM checks
// stay consistent.

`ifndef I3C_DRIVER_SVH
`define I3C_DRIVER_SVH

class i3c_driver extends uvm_driver #(i3c_transaction);
  `uvm_component_utils(i3c_driver)
  virtual i3c_if vif;
  i3c_config cfg;
  uvm_analysis_port #(i3c_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual i3c_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "i3c virtual interface not set")
  endfunction

  // ---- low-level line control (open-drain SDA: oe=0 releases the line) ----
  task set_sda(bit v); vif.drv_cb.sda_o  <= v; vif.drv_cb.sda_oe <= 1; endtask
  task rel_sda();    vif.drv_cb.sda_oe <= 0; endtask
  task set_scl(bit v); vif.drv_cb.scl_o  <= v; vif.drv_cb.scl_oe <= 1; endtask
  task rel_scl();    vif.drv_cb.scl_oe <= 0; endtask   // pull-up: SCL high

  task i3c_start();
    rel_sda(); rel_scl(); repeat (4) @(vif.drv_cb);
    set_sda(0);            repeat (4) @(vif.drv_cb);   // SDA falls while SCL high
    set_scl(0);            repeat (4) @(vif.drv_cb);
  endtask

  task i3c_stop();
    set_sda(0); rel_scl(); repeat (4) @(vif.drv_cb);
    rel_sda();             repeat (4) @(vif.drv_cb);   // SDA rises while SCL high
  endtask

  task i3c_write_bit(bit b);
    if (b) rel_sda(); else set_sda(0);
    rel_scl(); repeat (4) @(vif.drv_cb);               // data valid during high
    set_scl(0); repeat (4) @(vif.drv_cb);
  endtask

  task i3c_read_bit(output bit b);
    rel_sda();
    rel_scl(); repeat (2) @(vif.drv_cb);
    b = vif.drv_cb.sda_i;
    repeat (2) @(vif.drv_cb);
    set_scl(0); repeat (4) @(vif.drv_cb);
  endtask

  task i3c_write_byte(bit [7:0] d, output bit nack);
    for (int i = 7; i >= 0; i--) i3c_write_bit(d[i]);
    i3c_read_bit(nack);                                 // ACK slot driven by target
  endtask

  task i3c_read_byte(output bit [7:0] d, input bit master_nack);
    for (int i = 7; i >= 0; i--) i3c_read_bit(d[i]);
    i3c_write_bit(master_nack);                         // ACK=0 / NACK=1
  endtask

  // ---- FSM sideband walk: step through the legal chain to `dwell` ----
  task walk_to(i3c_state_e dwell);
    int dst = int'(dwell);
    for (int k = int'(vif.state) + 1; k <= dst; k++) begin
      vif.state = i3c_state_e'(k);
      @(vif.drv_cb);
    end
  endtask

  task walk_home(i3c_state_e dwell);
    for (int k = int'(dwell) + 1; k <= int'(i3c_defs_pkg::IBI); k++) begin
      vif.state = i3c_state_e'(k);
      @(vif.drv_cb);
    end
    vif.state = i3c_defs_pkg::IDLE;
    @(vif.drv_cb);
  endtask

  // ---- ENTDAA: broadcast 0x7E/W + 0x07, Sr, 0x7E/R, 8-byte provisioned ID,
  //      then the dynamic-address assignment byte (T-bit parity not modeled) ----
  task do_entdaa(i3c_transaction tr);
    bit nack;
    i3c_start();
    i3c_write_byte({7'h7E, 1'b0}, nack);
    tr.addr_nack = nack;
    if (nack) begin i3c_stop(); return; end
    i3c_write_byte(i3c_transaction::CCC_ENTDAA, nack);
    tr.ccc_nack = nack;
    if (nack) begin i3c_stop(); return; end
    i3c_start();                                        // repeated START
    i3c_write_byte({7'h7E, 1'b1}, nack);                // 0xFD: arbitration round
    if (nack) begin i3c_stop(); return; end             // no target participates
    for (int i = 0; i < 8; i++) begin                   // 48b PID + BCR + DCR
      bit [7:0] idb;
      i3c_read_byte(idb, 1'b0);
      tr.rdata.push_back(idb);
    end
    i3c_write_byte({tr.dyn_addr, 1'b0}, nack);          // assign dynamic address
    tr.assigned_ok = !nack;
    i3c_stop();
  endtask

  // ---- CCC command (broadcast to 7'h7E or direct to dyn_addr) ----
  task do_ccc(i3c_transaction tr);
    bit nack;
    i3c_start();
    if (tr.ccc_type == i3c_transaction::CCC_BROADCAST)
      i3c_write_byte({7'h7E, 1'b0}, nack);
    else
      i3c_write_byte({tr.dyn_addr, 1'b0}, nack);
    tr.addr_nack = nack;
    if (nack) begin i3c_stop(); return; end
    i3c_write_byte(tr.ccc, nack);
    tr.ccc_nack = nack;
    if (nack) begin                                     // unsupported CCC
      `uvm_warning("DRV", $sformatf("CCC 0x%02h NACKed (unsupported)", tr.ccc))
      i3c_stop(); return;
    end
    foreach (tr.data[i]) begin
      i3c_write_byte(tr.data[i], nack);
      if (nack) begin `uvm_warning("DRV", "CCC data NACKed"); break; end
    end
    i3c_stop();
  endtask

  // ---- Private SDR write / read ----
  task do_sdr(i3c_transaction tr);
    bit nack;
    i3c_start();
    i3c_write_byte({tr.dyn_addr, tr.rnw}, nack);
    tr.addr_nack = nack;
    if (nack) begin
      `uvm_warning("DRV", $sformatf("SDR addr 0x%02h NACKed", tr.dyn_addr))
      i3c_stop(); return;
    end
    if (!tr.rnw) begin
      foreach (tr.data[i]) begin
        i3c_write_byte(tr.data[i], nack);
        if (nack) begin `uvm_warning("DRV", "SDR data NACKed"); break; end
      end
    end else begin
      for (int i = 0; i < tr.data.size(); i++) begin
        bit [7:0] d;
        i3c_read_byte(d, (i == tr.data.size() - 1));    // NACK terminates read
        tr.rdata.push_back(d);
      end
    end
    i3c_stop();
  endtask

  task run_phase(uvm_phase phase);
    i3c_transaction tr;
    vif.drv_cb.sda_oe <= 0; vif.drv_cb.scl_oe <= 0;
    vif.state = i3c_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    forever begin
      i3c_state_e dwell;
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)

      dwell = (tr.is_ccc && tr.ccc == i3c_transaction::CCC_ENTDAA &&
               tr.ccc_type == i3c_transaction::CCC_BROADCAST) ? i3c_defs_pkg::ENTDAA :
              tr.is_ccc ? i3c_defs_pkg::CCC : i3c_defs_pkg::SDR;
      tr.state = dwell;

      walk_to(dwell);
      if (dwell == i3c_defs_pkg::ENTDAA)   do_entdaa(tr);
      else if (dwell == i3c_defs_pkg::CCC) do_ccc(tr);
      else                                 do_sdr(tr);
      walk_home(dwell);

      repeat (4) @(vif.drv_cb);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
