// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i3c_compliance_checker.sv -- MIPI I3C SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = I3C protocol-specific rules (ENTDAA ordering, CCC format,
//      dynamic address uniqueness, IBI enable). L4 uses a small bus
//      snooper that reconstructs the byte stream from SDA/SCL.

`ifndef I3C_COMPLIANCE_CHECKER_SV
`define I3C_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import i3c_defs_pkg::i3c_state_e;
import i3c_defs_pkg::*;   // enum literals (IDLE, ENTDAA, ...)

module i3c_compliance_checker
(
  input logic clk,
  input logic rst_n,
  input i3c_state_e state,
  input logic sda_i,
  input logic scl_i
);

  // ---------------- L1: signal sanity (4) ----------------
  a_i3c_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "i3c: clock unknown")
  a_i3c_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "i3c: reset unknown")
  a_i3c_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "i3c: state unknown")
  a_i3c_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, ENTDAA, CCC, HDR_DDR, SDR, IBI})
    else `uvm_error("SVA_L1", "i3c: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from IDLE
  a_i3c_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, ENTDAA})
    else `uvm_error("SVA_L2", "i3c: illegal transition from IDLE")

  // L2-2: legal FSM transition from ENTDAA
  a_i3c_trans_entdaa : assert property (@(posedge clk) disable iff (!rst_n)
    state == ENTDAA |=> state inside {ENTDAA, CCC})
    else `uvm_error("SVA_L2", "i3c: illegal transition from ENTDAA")

  // L2-3: legal FSM transition from CCC
  a_i3c_trans_ccc : assert property (@(posedge clk) disable iff (!rst_n)
    state == CCC |=> state inside {CCC, HDR_DDR})
    else `uvm_error("SVA_L2", "i3c: illegal transition from CCC")

  // L2-4: legal FSM transition from HDR_DDR
  a_i3c_trans_hdr_ddr : assert property (@(posedge clk) disable iff (!rst_n)
    state == HDR_DDR |=> state inside {HDR_DDR, SDR})
    else `uvm_error("SVA_L2", "i3c: illegal transition from HDR_DDR")

  // L2-5: legal FSM transition from SDR
  a_i3c_trans_sdr : assert property (@(posedge clk) disable iff (!rst_n)
    state == SDR |=> state inside {SDR, IBI})
    else `uvm_error("SVA_L2", "i3c: illegal transition from SDR")

  // L2-6: legal FSM transition from IBI
  a_i3c_trans_ibi : assert property (@(posedge clk) disable iff (!rst_n)
    state == IBI |=> state inside {IBI, IDLE})
    else `uvm_error("SVA_L2", "i3c: illegal transition from IBI")

  // ---------------- L3: protocol rules (4) ----------------
  a_i3c_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "i3c: state not IDLE during reset")
  a_i3c_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == IBI |-> ##[1:8] (state != IBI))
    else `uvm_error("SVA_L3", "i3c: stuck in IBI")
  a_i3c_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == ENTDAA);
  a_i3c_l3_back_idle  : cover property (@(posedge clk) disable iff (!rst_n)
    state == IBI ##1 state == IDLE);

  // ---------------- L4: I3C protocol-specific rules (4) ----------------
  // Bus snooper: reconstructs the byte stream between START and STOP.
  bit        in_frame;
  bit [7:0]  sh;
  int        nbits;
  int        byte_idx;
  bit        is_bcast, entdaa_active;
  bit        entdaa_done;        // an ENTDAA assignment completed
  bit        ibi_enabled;        // ENEC seen (DISEC clears)
  bit        ccc_fmt_err;        // broadcast CCC code outside 0x00-0x7F
  bit        addr_conflict;      // duplicate dynamic address assigned
  bit        ibi_pulse;          // SDA pulled low while bus idle (IBI request)
  bit [127:0] assigned_map;      // dynamic addresses assigned so far

  initial begin
    in_frame = 0; nbits = 0; byte_idx = 0;
    is_bcast = 0; entdaa_active = 0;
    entdaa_done = 0; ibi_enabled = 0;
    ccc_fmt_err = 0; addr_conflict = 0; ibi_pulse = 0;
    assigned_map = '0;
  end

  // START / repeated START: SDA falls while SCL high
  always @(negedge sda_i) begin
    if (scl_i) begin
      if (in_frame == 0 && state == IDLE) ibi_pulse = 1;  // target pulls SDA: IBI
      in_frame = 1; nbits = 0; byte_idx = 0;
    end
  end
  // STOP: SDA rises while SCL high
  always @(posedge sda_i) begin
    if (scl_i) in_frame = 0;
  end
  // IBI pulse clear (one ref-clock wide flag)
  always @(posedge clk) if (ibi_pulse) ibi_pulse <= 0;

  // Shift in data bits; every 9th SCL edge is the ACK slot
  always @(posedge scl_i) begin
    if (in_frame && rst_n) begin
      nbits <= nbits + 1;
      if (nbits < 8) sh <= {sh[6:0], sda_i};
      if (nbits == 7) handle_byte({sh[6:0], sda_i}, byte_idx);
      if (nbits == 8) begin nbits <= 0; byte_idx <= byte_idx + 1; end
    end
  end

  // Byte-stream interpretation for CCC/ENTDAA tracking
  function void handle_byte(bit [7:0] b, int idx);
    if (idx == 0) begin
      is_bcast      = (b == 8'hFC);   // 7'h7E + W
      entdaa_active = 0;
    end
    if (idx == 1) begin
      if (is_bcast) begin
        if (b[7]) ccc_fmt_err = 1;                 // bcast CCC must be 0x00-0x7F
        if (b == 8'h07) entdaa_active = 1;         // ENTDAA
        if (b == 8'h00) ibi_enabled   = 1;         // ENEC  (broadcast)
        if (b == 8'h01) ibi_enabled   = 0;         // DISEC (broadcast)
        if (b == 8'h06) begin                      // RSTDAA
          assigned_map = '0;
          entdaa_done  = 0;
        end
      end else begin
        if (b == 8'h80) ibi_enabled = 1;           // ENEC  (direct)
        if (b == 8'h81) ibi_enabled = 0;           // DISEC (direct)
      end
    end
    if (entdaa_active) begin
      if (idx == 2 && b != 8'hFD) entdaa_active = 0;   // expected Sr + 7'h7E/R
      if (idx == 11) begin                             // address assignment byte
        if (assigned_map[b[7:1]]) addr_conflict = 1;
        assigned_map[b[7:1]] = 1'b1;
        entdaa_done = 1;
      end
    end
  endfunction

  // L4-1: SDR transfers require a completed ENTDAA first (checked only on
  //       a dwelling SDR phase, not on chain pass-through cycles)
  a_i3c_l4_entdaa_before_sdr : assert property (@(posedge clk) disable iff (!rst_n)
    (state == SDR && $past(state == SDR) && $past(state == SDR, 2)) |-> entdaa_done)
    else `uvm_error("SVA_L4", "i3c: SDR transfer before ENTDAA completed")

  // L4-2: broadcast CCC frames must carry a legal 7-bit CCC code
  a_i3c_l4_ccc_format : assert property (@(posedge clk) disable iff (!rst_n) !ccc_fmt_err)
    else `uvm_error("SVA_L4", "i3c: broadcast CCC code outside 0x00-0x7F")

  // L4-3: every assigned dynamic address must be unique on the bus
  a_i3c_l4_dyn_addr_unique : assert property (@(posedge clk) disable iff (!rst_n) !addr_conflict)
    else `uvm_error("SVA_L4", "i3c: dynamic address conflict (duplicate assignment)")

  // L4-4: an IBI request is only legal after ENEC enabled in-band interrupts
  a_i3c_l4_ibi_enabled : assert property (@(posedge clk) disable iff (!rst_n)
    ibi_pulse |-> ibi_enabled)
    else `uvm_error("SVA_L4", "i3c: IBI requested before ENEC enabled it")

endmodule
`endif
