// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i3c_if.sv -- MIPI I3C interface
// SDR mode electrical model:
//   SDA : open-drain, wired-AND with pull-up (master + target drives)
//   SCL : driven by the master (push-pull emulated with oe + pull-up,
//         idle high like I2C legacy mode)
// `state` is a VIP-driven sideband reflecting the dominant protocol phase
// (used for FSM coverage and the SVA compliance checker).

interface i3c_if (input logic clk);
  import i3c_defs_pkg::i3c_state_e;

  logic rst_n;

  // Open-drain SDA: _o = output value, _oe = output enable (pull low), _i = sensed line
  logic sda_o, sda_oe, sda_i;
  // SCL: master driven (push-pull in real I3C SDR; oe model keeps it simple)
  logic scl_o, scl_oe, scl_i;

  // Target-side drives (DUT model)
  logic slv_sda_o, slv_sda_oe;

  i3c_state_e state;

  // Line resolution (wired-AND with pull-ups)
  assign sda_i = (sda_oe ? sda_o : 1'b1) & (slv_sda_oe ? slv_sda_o : 1'b1);
  assign scl_i = scl_oe ? scl_o : 1'b1;

  modport MASTER (input  clk, rst_n, sda_i, scl_i,
                  output sda_o, sda_oe, scl_o, scl_oe, state);
  modport SLAVE  (input  clk, rst_n, sda_i, scl_i,
                  output slv_sda_o, slv_sda_oe);
  modport MON    (input  clk, rst_n, sda_i, scl_i, state);

  clocking drv_cb @(posedge clk);
    input  sda_i, scl_i;
    output sda_o, sda_oe, scl_o, scl_oe;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, sda_i, scl_i, state;
  endclocking
endinterface
