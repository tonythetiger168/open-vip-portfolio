// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i3c_coverage.svh -- MIPI I3C functional coverage
// cg_protocol : transfer kind / CCC codes / addresses / lengths (+ cross)
// cg_fsm      : protocol FSM states and legal chain transitions, sampled
//               from the interface sideband on every state change
// cg_error    : NACK / IBI / address-conflict related bins

`ifndef I3C_COVERAGE_SVH
`define I3C_COVERAGE_SVH

class i3c_coverage extends uvm_subscriber #(i3c_transaction);
  `uvm_component_utils(i3c_coverage)

  virtual i3c_if vif;
  i3c_transaction tr;
  i3c_state_e cur_state;

  covergroup cg_protocol;
    cp_kind : coverpoint {tr.is_ibi, tr.is_ccc, tr.ccc_type, tr.rnw} {
      bins sdr_write  = {4'b0000};
      bins sdr_read   = {4'b0001};
      bins ccc_bcast  = {4'b0100};
      bins ccc_direct = {4'b0110};
      bins ibi        = {4'b1000};
    }
    cp_ccc : coverpoint tr.ccc iff (tr.is_ccc) {
      bins enec_b   = {8'h00};
      bins disec_b  = {8'h01};
      bins rstdaa   = {8'h06};
      bins entdaa   = {8'h07};
      bins enthdr0  = {8'h20};
      bins enec_d   = {8'h80};
      bins disec_d  = {8'h81};
      bins other    = default;
    }
    cp_addr : coverpoint tr.dyn_addr iff (!tr.is_ibi) {
      bins tgt0     = {7'h20};
      bins tgt1     = {7'h21};
      bins assigned = {[7'h08 : 7'h77]};
    }
    cp_len : coverpoint tr.data.size() iff (!tr.is_ibi) {
      bins none   = {0};
      bins single = {1};
      bins short  = {[2:4]};
      bins burst  = {[5:8]};
    }
    cp_data0 : coverpoint tr.data[0] iff (!tr.is_ccc && !tr.rnw && tr.data.size() > 0) {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins walk = {[8'h01 : 8'hFE]};
    }
    cx_kind_len : cross cp_kind, cp_len;
  endgroup

  covergroup cg_fsm with function sample(i3c_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {i3c_defs_pkg::IDLE, i3c_defs_pkg::ENTDAA, i3c_defs_pkg::CCC,
                           i3c_defs_pkg::HDR_DDR, i3c_defs_pkg::SDR, i3c_defs_pkg::IBI};
    }
    cp_trans : coverpoint s {
      bins entdaa_seq = (i3c_defs_pkg::IDLE    => i3c_defs_pkg::ENTDAA => i3c_defs_pkg::CCC);
      bins hdr_seq    = (i3c_defs_pkg::CCC     => i3c_defs_pkg::HDR_DDR => i3c_defs_pkg::SDR);
      bins ibi_seq    = (i3c_defs_pkg::SDR     => i3c_defs_pkg::IBI    => i3c_defs_pkg::IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_addr_nack : coverpoint tr.addr_nack iff (!tr.is_ibi) { bins ack = {0}; bins nack = {1}; }
    cp_ccc_nack  : coverpoint tr.ccc_nack  iff (tr.is_ccc)  { bins ack = {0}; bins nack = {1}; }
    cp_assign    : coverpoint tr.assigned_ok iff (tr.is_ccc && tr.ccc == 8'h07) {
      bins ok = {1}; bins fail = {0};
    }
    cp_ibi       : coverpoint tr.is_ibi { bins req = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual i3c_if)::get(this, "", "vif", vif));
  endfunction

  // Sample the FSM covergroup on every interface state change
  task run_phase(uvm_phase phase);
    i3c_state_e prev = i3c_defs_pkg::IDLE;
    if (vif == null) return;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n === 1'b1 && vif.mon_cb.state !== prev) begin
        cur_state = vif.mon_cb.state;
        cg_fsm.sample(cur_state);
        prev = cur_state;
      end
    end
  endtask

  function void write(i3c_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction
endclass
`endif
