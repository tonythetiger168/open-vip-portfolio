// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i3c_sequences.svh -- MIPI I3C sequence library
// Directed sequences: ENTDAA / broadcast CCC / direct CCC / SDR write /
// SDR read / IBI enable / error injection, plus random and regression mix.
// The DUT targets are assigned dynamic addresses 0x20 / 0x21 (see top_tb).

`ifndef I3C_SEQUENCES_SVH
`define I3C_SEQUENCES_SVH

class i3c_base_sequence extends uvm_sequence #(i3c_transaction);
  `uvm_object_utils(i3c_base_sequence)
  int num_txns = 20;
  bit [6:0] assigned_addr = 7'h20;      // primary target dynamic address
  function new(string name = "i3c_base_sequence"); super.new(name); endfunction
  task body();
    i3c_transaction tr;
    repeat (num_txns) begin
      tr = i3c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: ENTDAA dynamic address assignment (one address per item)
class i3c_entdaa_seq extends i3c_base_sequence;
  `uvm_object_utils(i3c_entdaa_seq)
  bit [6:0] addrs[$] = '{7'h20, 7'h21};  // one per on-bus target
  function new(string name = "i3c_entdaa_seq"); super.new(name); num_txns = 2; endfunction
  task body();
    i3c_transaction tr;
    foreach (addrs[i]) begin
      tr = i3c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { is_ccc == 1;
                                  ccc_type == i3c_transaction::CCC_BROADCAST;
                                  ccc == CCC_ENTDAA;
                                  dyn_addr == addrs[i]; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: broadcast CCCs (ENEC / DISEC / RSTDAA / ENTHDR0)
class i3c_ccc_bcast_seq extends i3c_base_sequence;
  function new(string name = "i3c_ccc_bcast_seq"); super.new(name); endfunction
  `uvm_object_utils(i3c_ccc_bcast_seq)
  task body();
    i3c_transaction tr;
    bit [7:0] codes[$] = '{8'h00, 8'h01, 8'h06, 8'h20};
    foreach (codes[i]) begin
      tr = i3c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { is_ccc == 1;
                                  ccc_type == i3c_transaction::CCC_BROADCAST;
                                  ccc == codes[i];
                                  // ENEC/DISEC carry one defining byte
                                  (ccc inside {8'h00, 8'h01}) -> data.size() == 1;
                                  (ccc inside {8'h06, 8'h20}) -> data.size() == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: direct CCCs (ENEC / DISEC) to the assigned dynamic address
class i3c_ccc_direct_seq extends i3c_base_sequence;
  function new(string name = "i3c_ccc_direct_seq"); super.new(name); endfunction
  `uvm_object_utils(i3c_ccc_direct_seq)
  task body();
    i3c_transaction tr;
    bit [7:0] codes[$] = '{8'h80, 8'h81};
    foreach (codes[i]) begin
      tr = i3c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { is_ccc == 1;
                                  ccc_type == i3c_transaction::CCC_DIRECT;
                                  ccc == codes[i];
                                  dyn_addr == assigned_addr;
                                  data.size() == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: SDR register writes (offset + payload, walking offsets)
class i3c_sdr_write_seq extends i3c_base_sequence;
  function new(string name = "i3c_sdr_write_seq"); super.new(name); endfunction
  `uvm_object_utils(i3c_sdr_write_seq)
  rand bit [6:0] offset = 7'h00;
  task body();
    i3c_transaction tr;
    repeat (num_txns) begin
      tr = i3c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { is_ccc == 0; rnw == 0;
                                  dyn_addr == assigned_addr;
                                  data.size() inside {[2:8]};
                                  data[0] == offset; });
      finish_item(tr);
      offset = (offset + 7'h08) % 7'h80;
    end
  endtask
endclass

// Directed: SDR reads of varying length
class i3c_sdr_read_seq extends i3c_base_sequence;
  function new(string name = "i3c_sdr_read_seq"); super.new(name); endfunction
  `uvm_object_utils(i3c_sdr_read_seq)
  task body();
    i3c_transaction tr;
    repeat (num_txns) begin
      tr = i3c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { is_ccc == 0; rnw == 1;
                                  dyn_addr == assigned_addr;
                                  data.size() inside {[1:8]}; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: enable IBI via ENEC (target raises an IBI request afterwards)
class i3c_ibi_seq extends i3c_base_sequence;
  function new(string name = "i3c_ibi_seq"); super.new(name); endfunction
  `uvm_object_utils(i3c_ibi_seq)
  task body();
    i3c_transaction tr;
    // ENEC broadcast with IBI event bit (bit 3) set
    tr = i3c_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { is_ccc == 1;
                                ccc_type == i3c_transaction::CCC_BROADCAST;
                                ccc == CCC_ENEC_B;
                                data.size() == 1;
                                data[0] == 8'h08; });
    finish_item(tr);
    // leave the bus idle afterwards so the target can issue the IBI pulse
  endtask
endclass

// Error injection: unsupported CCC codes + dynamic-address conflict
class i3c_error_inject_seq extends i3c_base_sequence;
  function new(string name = "i3c_error_inject_seq"); super.new(name); endfunction
  `uvm_object_utils(i3c_error_inject_seq)
  task body();
    i3c_transaction tr;
    // 1) unsupported broadcast CCC -> target NACKs the CCC byte
    tr = i3c_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { is_ccc == 1;
                                ccc_type == i3c_transaction::CCC_BROADCAST;
                                ccc == 8'h5A; data.size() == 0; });
    finish_item(tr);
    // 2) unsupported direct CCC -> target NACKs the CCC byte
    tr = i3c_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { is_ccc == 1;
                                ccc_type == i3c_transaction::CCC_DIRECT;
                                ccc == 8'h9A;
                                dyn_addr == assigned_addr;
                                data.size() == 0; });
    finish_item(tr);
    // 3) address conflict: SDR to a dynamic address never assigned by
    //    ENTDAA on this bus -> no target responds, address phase NACKed
    tr = i3c_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { is_ccc == 0; rnw == 0;
                                dyn_addr == 7'h31;
                                data.size() == 2; });
    finish_item(tr);
  endtask
endclass

class i3c_random_sequence extends i3c_base_sequence;
  `uvm_object_utils(i3c_random_sequence)
  function new(string name = "i3c_random_sequence"); super.new(name); num_txns = 50; endfunction
  task body();
    i3c_transaction tr;
    // randomize mostly legal traffic aimed at the assigned address
    repeat (num_txns) begin
      tr = i3c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with {
        is_ccc dist {0 := 3, 1 := 1};
        dyn_addr == assigned_addr;
        (is_ccc && ccc_type == i3c_transaction::CCC_BROADCAST) ->
          ccc inside {8'h00, 8'h01, 8'h06, 8'h20, 8'h07};
        (is_ccc && ccc_type == i3c_transaction::CCC_DIRECT) ->
          ccc inside {8'h80, 8'h81};
        (is_ccc && ccc == 8'h07) -> data.size() == 0;
      });
      finish_item(tr);
    end
  endtask
endclass

// Regression: ENTDAA first (SDR needs an assigned address), then a
// weighted mix of all directed sequences
class i3c_regression_sequence extends i3c_base_sequence;
  `uvm_object_utils(i3c_regression_sequence)
  function new(string name = "i3c_regression_sequence"); super.new(name); endfunction
  task body();
    i3c_entdaa_seq      daa = i3c_entdaa_seq::type_id::create("daa");
    i3c_ccc_bcast_seq   cb  = i3c_ccc_bcast_seq::type_id::create("cb");
    i3c_ccc_direct_seq  cd  = i3c_ccc_direct_seq::type_id::create("cd");
    i3c_sdr_write_seq   wr  = i3c_sdr_write_seq::type_id::create("wr");
    i3c_sdr_read_seq    rd  = i3c_sdr_read_seq::type_id::create("rd");
    i3c_ibi_seq         ibi = i3c_ibi_seq::type_id::create("ibi");
    i3c_error_inject_seq err = i3c_error_inject_seq::type_id::create("err");
    wr.num_txns = 16; rd.num_txns = 16;
    daa.start(m_sequencer);           // assigns 0x20 / 0x21
    cb.start(m_sequencer);            // includes RSTDAA (clears assignment)
    daa.start(m_sequencer);           // re-assign after RSTDAA
    cd.start(m_sequencer);
    wr.start(m_sequencer);
    rd.start(m_sequencer);
    ibi.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
