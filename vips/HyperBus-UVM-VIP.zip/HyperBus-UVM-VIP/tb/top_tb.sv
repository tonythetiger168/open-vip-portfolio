// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- HyperBus testbench top with a functional HyperBus DUT model

`ifndef HYPERBUS_UVM_VIP_TB_SV
`define HYPERBUS_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import hyperbus_defs_pkg::*;
import hyperbus_pkg::*;
import hyperbus_env_pkg::*;
import hyperbus_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  hyperbus_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  hyperbus_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cs_n(vif.cs_n),
    .ck(vif.ck),
    .dq_m(vif.dq_m),
    .dq_m_oe(vif.dq_m_oe),
    .rwds_m(vif.rwds_m),
    .rwds_m_oe(vif.rwds_m_oe),
    .dq_s(vif.dq_s),
    .dq_s_oe(vif.dq_s_oe),
    .rwds_s(vif.rwds_s),
    .rwds_s_oe(vif.rwds_s_oe)
  );

  // Concurrent protocol checks
  hyperbus_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cs_n(vif.cs_n),
    .ck(vif.ck),
    .dq_m(vif.dq_m),
    .dq_m_oe(vif.dq_m_oe),
    .rwds_m(vif.rwds_m),
    .rwds_m_oe(vif.rwds_m_oe),
    .dq_s(vif.dq_s),
    .dq_s_oe(vif.dq_s_oe),
    .rwds_s(vif.rwds_s),
    .rwds_s_oe(vif.rwds_s_oe)
  );

  initial begin
    uvm_config_db#(virtual hyperbus_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module hyperbus_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       cs_n,
  input  logic       ck,
  input  logic [7:0] dq_m,
  input  logic       dq_m_oe,
  input  logic       rwds_m,
  input  logic       rwds_m_oe,
  output logic [7:0] dq_s,
  output logic       dq_s_oe,
  output logic       rwds_s,
  output logic       rwds_s_oe
);
  logic [15:0] mem [0:255];
  logic [15:0] cr0;
  logic [47:0] ca;
  logic [5:0]  fr;            // free-running: refresh due when bit 5 is set
  logic        cs_p, ck_p, lat2x, hi;
  logic [2:0]  nca;
  logic [1:0]  ph;            // 0 command-address, 1 latency, 2 data, 3 idle
  logic [7:0]  lcnt, latn, widx, ub;

  function automatic logic [3:0] lat_clk(input logic [3:0] code);
    case (code)
      4'h0: lat_clk = 4'd5;
      4'h1: lat_clk = 4'd6;
      4'h2: lat_clk = 4'd7;
      4'hE: lat_clk = 4'd3;
      4'hF: lat_clk = 4'd4;
      default: lat_clk = 4'd6;
    endcase
  endfunction
  function automatic logic [7:0] wrap_mask(input logic [1:0] bl);   // burst words - 1
    case (bl)
      2'd0: wrap_mask = 8'd63;
      2'd1: wrap_mask = 8'd31;
      2'd2: wrap_mask = 8'd7;
      default: wrap_mask = 8'd15;
    endcase
  endfunction

  wire        edge_ = !cs_n && (ck != ck_p);
  wire [31:0] wa    = {ca[44:16], ca[2:0]};
  wire [31:0] wm    = {24'h0, wrap_mask(cr0[1:0])};
  wire [31:0] ai    = ca[45] ? wa + {24'h0, widx} : ((wa & ~wm) | ((wa + {24'h0, widx}) & wm));
  wire [15:0] rword = !ca[46] ? mem[ai[7:0]] :
                      (wa == 32'h0) ? 16'h0C81 : (wa == 32'h1) ? 16'h0001 : (wa == 32'h800) ? cr0 : 16'h0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 256; i++) mem[i] <= '0;
      cr0 <= 16'h8F1F; ca <= '0; fr <= '0; cs_p <= 1'b1; ck_p <= 1'b0; lat2x <= 1'b0; hi <= 1'b1;
      nca <= '0; ph <= 2'd3; lcnt <= '0; latn <= '0; widx <= '0; ub <= '0;
      dq_s <= '0; dq_s_oe <= 1'b0; rwds_s <= 1'b0; rwds_s_oe <= 1'b0;
    end else begin
      fr <= fr + 6'd1;
      cs_p <= cs_n; ck_p <= ck;
      if (cs_n) begin
        ph <= 2'd3; dq_s_oe <= 1'b0; rwds_s_oe <= 1'b0; rwds_s <= 1'b0;
      end else if (cs_p) begin                     // CS# fall: RWDS gives the latency
        ph <= 2'd0; nca <= '0; hi <= 1'b1; widx <= '0; lcnt <= '0;
        lat2x <= cr0[3] | fr[5];
        rwds_s <= cr0[3] | fr[5]; rwds_s_oe <= 1'b1;
      end else if (edge_) begin
        case (ph)
          2'd0: if (dq_m_oe) begin
            ca <= {ca[39:0], dq_m};
            nca <= nca + 3'd1;
            if (nca == 3'd5) begin : ca_done
              logic [47:0] c;
              logic [7:0]  l;
              c = {ca[39:0], dq_m};
              l = {3'b000, lat_clk(cr0[7:4]), 1'b0};
              if (lat2x) l = l << 1;
              if (!c[47] && c[46]) begin             // register write: data right away
                ph <= 2'd2; rwds_s_oe <= 1'b0;
              end else begin
                ph <= 2'd1; latn <= l;
                rwds_s_oe <= c[47]; rwds_s <= 1'b0;  // a read keeps RWDS (low until data)
              end
            end
          end
          2'd1: begin
            lcnt <= lcnt + 8'd1;
            if (lcnt + 8'd1 == latn) ph <= 2'd2;
          end
          2'd2: if (ca[47]) begin
            dq_s <= hi ? rword[15:8] : rword[7:0];
            dq_s_oe <= 1'b1;
            rwds_s <= !rwds_s;
            hi <= !hi;
            if (!hi) widx <= widx + 8'd1;
          end else if (dq_m_oe) begin
            if (ca[46]) begin
              if (hi) ub <= dq_m;
              else if (wa == 32'h800 && widx == 8'd0) cr0 <= (cr0 & ~16'h00FB) | ({ub, dq_m} & 16'h00FB);
            end else if (!(rwds_m_oe && rwds_m)) begin
              if (hi) mem[ai[7:0]][15:8] <= dq_m;
              else    mem[ai[7:0]][7:0]  <= dq_m;
            end
            hi <= !hi;
            if (!hi) widx <= widx + 8'd1;
          end
          default: ;
        endcase
      end
    end
  end
endmodule
`endif
