// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (HyperBus DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened hyperbus_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic cs_n = 1, ck = 0, dq_m_oe = 0, rwds_m = 0, rwds_m_oe = 0;
  logic [7:0] dq_m = 0;
  wire [7:0] dq_s;
  wire dq_s_oe, rwds_s, rwds_s_oe;

  always #5 clk = ~clk;

  hyperbus_model u_dut (.clk(clk), .rst_n(rst_n), .cs_n(cs_n), .ck(ck), .dq_m(dq_m), .dq_m_oe(dq_m_oe),
                        .rwds_m(rwds_m), .rwds_m_oe(rwds_m_oe), .dq_s(dq_s), .dq_s_oe(dq_s_oe),
                        .rwds_s(rwds_s), .rwds_s_oe(rwds_s_oe));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // bus rules watched all the time
  int clash = 0, idle_drv = 0;
  logic cs_q = 1'b1;
  always @(posedge clk) begin
    if (rst_n && ((dq_s_oe && dq_m_oe) || (rwds_s_oe && rwds_m_oe))) clash++;
    if (rst_n && cs_n && cs_q && (dq_s_oe || rwds_s_oe)) idle_drv++;
    cs_q <= cs_n;
  end

  task automatic bt(input logic oe, input logic [7:0] d, input logic moe, input logic m);
    @(negedge clk); ck = !ck; dq_m_oe = oe; dq_m = d; rwds_m_oe = moe; rwds_m = m;
  endtask

  logic [15:0] rbuf [0:63];
  int nrd, first, l2x;
  logic l2x_oe, wr_rwds_oe;
  logic [1:0] lat_rwds;
  task automatic ca(input logic rw, input logic as_, input logic lin, input logic [31:0] a);
    logic [47:0] c;
    logic [7:0] b;
    c = {rw, as_, lin, a[31:3], 13'h0, a[2:0]};
    @(negedge clk); cs_n = 0;
    for (int i = 5; i >= 0; i--) begin
      b = c[8*i +: 8];
      bt(1, b, 0, 0);
      if (i == 4) begin l2x = rwds_s; l2x_oe = rwds_s_oe; end
    end
  endtask
  task automatic finish_xfer;
    @(negedge clk); dq_m_oe = 0; rwds_m_oe = 0;
    @(negedge clk); cs_n = 1;
    repeat (3) @(negedge clk);
  endtask
  // read n words, the host waiting lat clocks (2 x lat CK edges)
  task automatic rd(input logic as_, input logic lin, input logic [31:0] a, input int n, input int lat);
    logic rp;
    logic [7:0] hb;
    int k, ne;
    ca(1, as_, lin, a);
    k = 0; ne = 0; first = -1; rp = rwds_s; hb = 0;
    for (int i = 0; i < 2 * lat + 2 * n + 3; i++) begin
      if (i < 2 * lat + 2 * n) begin bt(0, 0, 0, 0); ne++; end
      else @(negedge clk);
      if (ne == 3) lat_rwds = {rwds_s_oe, rwds_s};
      if (rwds_s !== rp && dq_s_oe) begin
        if (first < 0) first = ne - 2;   // CK edges before the one the first byte answers
        if (k % 2 == 0) hb = dq_s; else rbuf[k / 2] = {hb, dq_s};
        k++;
      end
      rp = rwds_s;
    end
    nrd = k / 2;
    finish_xfer();
  endtask
  // write n words d0 + 0x0101 * i after lat clocks (lat < 0: -lat clocks,
  // doubled when RWDS says so); m0 masks word 0
  task automatic wr(input logic as_, input logic lin, input logic [31:0] a, input int n, input logic [15:0] d0,
                    input int lat, input logic [1:0] m0 = 2'b00);
    logic [15:0] d;
    ca(0, as_, lin, a);
    if (lat < 0) lat = l2x ? -2 * lat : -lat;
    repeat (2 * lat) bt(0, 0, 0, 0);
    wr_rwds_oe = 0;
    for (int i = 0; i < n; i++) begin
      d = d0 + 16'h0101 * i;
      bt(1, d[15:8], !as_, (i == 0) && m0[1]);
      bt(1, d[7:0],  !as_, (i == 0) && m0[0]);
      wr_rwds_oe = wr_rwds_oe | rwds_s_oe;
    end
    finish_xfer();
  endtask
  // a register read in variable latency mode: the latency follows RWDS
  int lat_now;
  task automatic rd_var(input logic as_, input logic lin, input logic [31:0] a, input int n, input int lc);
    // RWDS is known only after the command-address: read with the longer
    // wait, the data starts where the level says
    rd(as_, lin, a, n, 2 * lc);
    lat_now = l2x ? 2 * lc : lc;
  endtask

  initial begin
    int seen0, seen1, bad_lat;
    repeat (3) @(posedge clk);
    chk(dq_s_oe === 1'b0 && rwds_s_oe === 1'b0, "bus released during reset");
    rst_n = 1;
    repeat (3) @(posedge clk);

    // registers after reset: fixed latency, 6 clocks doubled
    rd(1, 1, 32'h800, 1, 12);
    chk(nrd == 1 && rbuf[0] === 16'h8F1F, $sformatf("CR0 reads 0x8F1F after reset (%h)", rbuf[0]));
    chk(l2x === 1'b1 && l2x_oe === 1'b1, "fixed latency: device drives RWDS high during the command-address");
    chk(lat_rwds === 2'b10, "and drives it low through the latency of a read");
    chk(first == 24, $sformatf("read data after 2 x 6 clocks (24 CK edges, saw %0d)", first));
    rd(1, 1, 32'h0, 1, 12); chk(rbuf[0] === 16'h0C81, "ID0");
    rd(1, 1, 32'h1, 1, 12); chk(rbuf[0] === 16'h0001, "ID1");
    rd(1, 1, 32'h2, 1, 12); chk(rbuf[0] === 16'h0000, "unmapped register reads 0");
    rd(1, 1, 32'h800, 2, 12); chk(nrd == 2 && rbuf[1] === 16'h8F1F, "a register read repeats the register");

    // memory: linear write / read, masks
    rd(0, 1, 32'h0, 2, 12); chk(nrd == 2 && rbuf[0] === 16'h0 && rbuf[1] === 16'h0, "memory 0 after reset");
    rd(0, 1, 32'hFF, 1, 12); chk(rbuf[0] === 16'h0, "last word 0 after reset");
    wr(0, 1, 32'h10, 4, 16'h1122, 12);
    chk(wr_rwds_oe === 1'b0, "device releases RWDS for the write mask");
    rd(0, 1, 32'h10, 4, 12);
    chk(nrd == 4 && rbuf[0] === 16'h1122 && rbuf[1] === 16'h1223 && rbuf[2] === 16'h1324 && rbuf[3] === 16'h1425,
        "linear write and read of 4 words, bits 15:8 first");
    wr(0, 1, 32'h10, 1, 16'hAAAA, 12, 2'b10);
    wr(0, 1, 32'h11, 1, 16'hBBBB, 12, 2'b01);
    rd(0, 1, 32'h10, 2, 12);
    chk(rbuf[0] === 16'h11AA && rbuf[1] === 16'hBB23, $sformatf("RWDS byte masks (%h %h)", rbuf[0], rbuf[1]));
    rd(0, 1, 32'h12, 1, 12); chk(rbuf[0] === 16'h1324, "masked burst left the next word");

    // wrapped bursts, 16 words after reset
    wr(0, 1, 32'h1E, 2, 16'hE1E1, 12);
    rd(0, 0, 32'h1E, 4, 12);
    chk(rbuf[0] === 16'hE1E1 && rbuf[1] === 16'hE2E2 && rbuf[2] === 16'h11AA && rbuf[3] === 16'hBB23,
        "wrapped read wraps at the 16-word boundary");
    rd(0, 1, 32'h1F, 2, 12); chk(rbuf[1] === 16'h0000, "linear read runs on past it");
    wr(0, 0, 32'h2F, 2, 16'h2F2F, 12);
    rd(0, 1, 32'h20, 1, 12); chk(rbuf[0] === 16'h3030, "wrapped write wraps too");
    rd(0, 1, 32'h30, 1, 12); chk(rbuf[0] === 16'h0000, "and does not reach the next group");

    // CR0: latency 3 clocks, variable latency, 16-byte (8-word) wrap; only bits 7:3, 1:0 written
    wr(1, 1, 32'h800, 1, 16'h00E2, 0);
    chk(wr_rwds_oe === 1'b0, "device releases RWDS for a register write");
    rd(1, 1, 32'h800, 1, 6);
    chk(rbuf[0] === 16'h8FE6, $sformatf("CR0 written (%h)", rbuf[0]));
    seen0 = 0; seen1 = 0; bad_lat = 0;
    for (int i = 0; i < 12; i++) begin
      rd_var(0, 1, 32'h10, 1, 3);
      if (l2x) seen1++; else seen0++;
      if (first != 2 * lat_now || rbuf[0] !== 16'h11AA) bad_lat++;
      repeat (i * 3) @(negedge clk);
    end
    chk(seen0 > 0 && seen1 > 0, $sformatf("variable latency: RWDS low (%0d) and high (%0d)", seen0, seen1));
    chk(bad_lat == 0, "variable latency: data after 3 or 6 clocks as RWDS says");
    rd_var(0, 0, 32'h0E, 3, 3);
    chk(rbuf[0] === 16'h0 && rbuf[1] === 16'h0 && rbuf[2] === 16'h0, "8-word wrap read");
    wr(0, 1, 32'h0E, 1, 16'h0E0E, -3);
    wr(0, 1, 32'h08, 1, 16'h0808, -3);
    rd_var(0, 0, 32'h0F, 2, 3);
    chk(rbuf[0] === 16'h0 && rbuf[1] === 16'h0808, "8-word wrap: 0x0F then 0x08");

    // back to fixed latency, each code
    wr(1, 1, 32'h800, 1, 16'h000B, 0); rd(0, 1, 32'h10, 1, 10); chk(first == 20, "code 0: 5 clocks doubled");
    wr(1, 1, 32'h800, 1, 16'h001B, 0); rd(0, 1, 32'h10, 1, 12); chk(first == 24, "code 1: 6 clocks doubled");
    wr(1, 1, 32'h800, 1, 16'h002B, 0); rd(0, 1, 32'h10, 1, 14); chk(first == 28, "code 2: 7 clocks doubled");
    wr(1, 1, 32'h800, 1, 16'h00FB, 0); rd(0, 1, 32'h10, 1, 8);  chk(first == 16, "code F: 4 clocks doubled");
    wr(1, 1, 32'h800, 1, 16'h00EB, 0); rd(0, 1, 32'h10, 1, 6);  chk(first == 12, "code E: 3 clocks doubled");
    wr(1, 1, 32'h800, 1, 16'h005B, 0); rd(0, 1, 32'h10, 1, 12); chk(first == 24, "reserved code: 6 clocks");
    // write beats inside the latency are ignored
    wr(1, 1, 32'h800, 1, 16'h001B, 0);
    wr(0, 1, 32'h40, 2, 16'h4040, 11);
    rd(0, 1, 32'h40, 2, 12);
    chk(rbuf[0] === 16'h4141 && rbuf[1] === 16'h0000, "write data inside the latency ignored");
    // 128-byte and 64-byte wraps
    wr(1, 1, 32'h800, 1, 16'h0018, 0);
    wr(0, 1, 32'h80, 1, 16'h8080, 12);
    rd(0, 0, 32'hBF, 2, 12); chk(rbuf[1] === 16'h8080, "64-word wrap");
    wr(1, 1, 32'h800, 1, 16'h0019, 0);
    wr(0, 1, 32'hA0, 1, 16'hA0A0, 12);
    rd(0, 0, 32'hBF, 2, 12); chk(rbuf[1] === 16'hA0A0, "32-word wrap");
    // ID registers are read-only, CR0 keeps its fixed bits
    wr(1, 1, 32'h0, 1, 16'hFFFF, 0);
    rd(1, 1, 32'h0, 1, 12); chk(rbuf[0] === 16'h0C81, "ID0 is read-only");
    rd(1, 1, 32'h800, 1, 12); chk(rbuf[0] === 16'h8F1D, $sformatf("a write to ID0 does not reach CR0 (%h)", rbuf[0]));
    wr(1, 1, 32'h800, 1, 16'h0000, 0);
    rd(1, 1, 32'h800, 1, 10); chk(rbuf[0] === 16'h8F04, $sformatf("CR0 bits 15:8 and 2 are fixed (%h)", rbuf[0]));
    // CS# cut in the middle of the command-address: the next transaction is clean
    @(negedge clk); cs_n = 0; bt(1, 8'hA0, 0, 0); bt(1, 8'h00, 0, 0); finish_xfer();
    wr(1, 1, 32'h800, 1, 16'h001F, 0);
    rd(1, 1, 32'h800, 1, 12); chk(rbuf[0] === 16'h8F1F && first == 24, "transaction after a cut command-address");

    chk(clash == 0, "DQ / RWDS never driven by both sides");
    chk(idle_drv == 0, "device releases the bus while CS# is high");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #4000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
