// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_defs.sv -- HyperBus shared type definitions

package hyperbus_defs_pkg;

  typedef enum bit [1:0] {HYPERBUS_OK, HYPERBUS_ERR} hyperbus_status_e;

  // initial latency in clocks from CR0[7:4]
  function automatic int hb_lat(bit [3:0] code);
    case (code)
      4'h0: return 5;
      4'h1: return 6;
      4'h2: return 7;
      4'hE: return 3;
      4'hF: return 4;
      default: return 6;
    endcase
  endfunction
  // wrapped burst length in words from CR0[1:0]
  function automatic int hb_wrap(bit [1:0] bl);
    case (bl)
      2'd0: return 64;
      2'd1: return 32;
      2'd2: return 8;
      default: return 16;
    endcase
  endfunction
  localparam bit [15:0] HB_CR0_RESET = 16'h8F1F;
  localparam bit [15:0] HB_CR0_WMASK = 16'h00FB;

endpackage
