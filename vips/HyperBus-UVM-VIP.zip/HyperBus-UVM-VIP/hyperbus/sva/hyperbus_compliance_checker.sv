// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_compliance_checker.sv -- HyperBus concurrent assertion checks (bindable)

module hyperbus_compliance_checker
  (input logic clk, input logic rst_n, input logic cs_n, input logic ck, input logic [7:0] dq_m, input logic dq_m_oe, input logic rwds_m, input logic rwds_m_oe, input logic [7:0] dq_s, input logic dq_s_oe, input logic rwds_s, input logic rwds_s_oe);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({dq_s_oe, rwds_s_oe, rwds_s}))
    else $error("HyperBus: X on device outputs");
  // one driver at a time on DQ and on RWDS
  assert property (@(posedge clk) disable iff (!rst_n) !(dq_s_oe && dq_m_oe))
    else $error("HyperBus: DQ driven by host and device at once");
  assert property (@(posedge clk) disable iff (!rst_n) !(rwds_s_oe && rwds_m_oe))
    else $error("HyperBus: RWDS driven by host and device at once");
  // the device lets go of the bus while deselected and drives RWDS from CS# fall
  assert property (@(posedge clk) disable iff (!rst_n) cs_n && $past(cs_n) |-> !dq_s_oe && !rwds_s_oe)
    else $error("HyperBus: device drives the bus while CS# is high");
  assert property (@(posedge clk) disable iff (!rst_n) $fell(cs_n) |=> rwds_s_oe)
    else $error("HyperBus: RWDS latency level not driven during the command-address");
  // a read strobe edge comes with valid data
  assert property (@(posedge clk) disable iff (!rst_n) $changed(rwds_s) && dq_s_oe |-> !$isunknown(dq_s))
    else $error("HyperBus: RWDS edge without valid read data");
  // CK only toggles while selected
  assert property (@(posedge clk) disable iff (!rst_n) cs_n && $past(cs_n) |-> $stable(ck))
    else $error("HyperBus: CK toggles while CS# is high");
  cover property (@(posedge clk) disable iff (!rst_n) $fell(cs_n) ##1 !rwds_s);
  cover property (@(posedge clk) disable iff (!rst_n) rwds_m_oe && rwds_m);
endmodule
