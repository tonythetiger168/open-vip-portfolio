// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_coverage.svh -- HyperBus functional coverage

class hyperbus_coverage extends uvm_subscriber #(hyperbus_transaction);
  `uvm_component_utils(hyperbus_coverage)
  hyperbus_config cfg;
  hyperbus_transaction tr;

  covergroup hyperbus_cg;
    cp_op    : coverpoint {tr.rw, tr.regsp} { bins mem_wr = {2'b00}; bins reg_wr = {2'b01}; bins mem_rd = {2'b10}; bins reg_rd = {2'b11}; }
    cp_burst : coverpoint tr.burst;
    cp_n     : coverpoint tr.nwords { bins one = {1}; bins few = {[2:7]}; bins many = {[8:$]}; }
    cp_lat   : coverpoint tr.lat_clk { bins zero = {0}; bins l[] = {3, 4, 5, 6, 7, 8, 10, 12, 14}; }
    cp_2x    : coverpoint tr.lat2x;
    cp_wrap8 : coverpoint (!tr.burst && tr.nwords > 1 && (tr.addr % 8) + tr.nwords > 8) { bins crosses = {1}; }
    cp_mask  : coverpoint (!tr.rw && !tr.regsp && tr.wmask.size() != 0 && tr.wmask[0] != 0) { bins masked = {1}; }
    x_op_burst : cross cp_op, cp_burst { ignore_bins regs = binsof(cp_op.reg_wr) || binsof(cp_op.reg_rd); }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    hyperbus_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(hyperbus_config)::get(this, "", "cfg", cfg))
      cfg = hyperbus_config::type_id::create("cfg");
  endfunction

  function void write(hyperbus_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    hyperbus_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("HyperBus coverage: %0.1f%%", hyperbus_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
