// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_sequences.svh -- HyperBus sequences

// Random traffic: cfg.num_items constrained-random items.
class hyperbus_base_sequence extends uvm_sequence #(hyperbus_transaction);
  `uvm_object_utils(hyperbus_base_sequence)
  hyperbus_config cfg;

  function new(string name = "hyperbus_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = hyperbus_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "hyperbus_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class hyperbus_directed_sequence extends uvm_sequence #(hyperbus_transaction);
  `uvm_object_utils(hyperbus_directed_sequence)
  hyperbus_config cfg;

  function new(string name = "hyperbus_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function hyperbus_transaction item();
    item = hyperbus_transaction::type_id::create("req");
  endfunction

  task send(hyperbus_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    hyperbus_transaction t;
    // registers after reset (fixed, doubled latency of 6 clocks)
    t = item(); t.rw = 1; t.regsp = 1; t.addr = 32'h800; t.nwords = 1; send(t);
    t = item(); t.rw = 1; t.regsp = 1; t.addr = 32'h0; t.nwords = 1; send(t);
    t = item(); t.rw = 1; t.regsp = 1; t.addr = 32'h1; t.nwords = 1; send(t);
    t = item(); t.rw = 1; t.regsp = 1; t.addr = 32'h2; t.nwords = 1; send(t);
    // linear write and read, byte masks
    t = item(); t.burst = 1; t.addr = 32'h10; t.nwords = 4; t.wdata = '{16'h1122, 16'h3344, 16'h5566, 16'h7788}; t.wmask = '{0, 0, 0, 0}; send(t);
    t = item(); t.rw = 1; t.burst = 1; t.addr = 32'h10; t.nwords = 4; send(t);
    t = item(); t.burst = 1; t.addr = 32'h10; t.nwords = 2; t.wdata = '{16'hAAAA, 16'hBBBB}; t.wmask = '{2'b10, 2'b01}; send(t);
    t = item(); t.rw = 1; t.burst = 1; t.addr = 32'h10; t.nwords = 2; send(t);
    // wrapped bursts at the 16-word boundary, linear across it
    t = item(); t.burst = 1; t.addr = 32'h1E; t.nwords = 2; t.wdata = '{16'hE1E1, 16'hF1F1}; t.wmask = '{0, 0}; send(t);
    t = item(); t.rw = 1; t.burst = 0; t.addr = 32'h1E; t.nwords = 4; send(t);
    t = item(); t.rw = 1; t.burst = 1; t.addr = 32'h1F; t.nwords = 3; send(t);
    t = item(); t.burst = 0; t.addr = 32'h2F; t.nwords = 2; t.wdata = '{16'h2F2F, 16'h2020}; t.wmask = '{0, 0}; send(t);
    t = item(); t.rw = 1; t.burst = 1; t.addr = 32'h20; t.nwords = 16; send(t);
    // variable latency of 3 clocks, 16-byte wrap
    t = item(); t.regsp = 1; t.addr = 32'h800; t.nwords = 1; t.wdata = '{16'h00E2}; t.wmask = '{0}; send(t);
    for (int i = 0; i < 6; i++) begin
      t = item(); t.rw = 1; t.regsp = 1; t.addr = 32'h800; t.nwords = 1; send(t);
    end
    t = item(); t.rw = 1; t.burst = 0; t.addr = 32'h0E; t.nwords = 3; send(t);
    t = item(); t.burst = 0; t.addr = 32'h17; t.nwords = 3; t.wdata = '{16'h1717, 16'h1010, 16'h1111}; t.wmask = '{0, 0, 0}; send(t);
    t = item(); t.rw = 1; t.burst = 1; t.addr = 32'h10; t.nwords = 8; send(t);
    // every latency code, fixed
    t = item(); t.regsp = 1; t.addr = 32'h800; t.nwords = 1; t.wdata = '{16'h000B}; t.wmask = '{0}; send(t);
    t = item(); t.rw = 1; t.regsp = 1; t.addr = 32'h800; t.nwords = 1; send(t);
    t = item(); t.regsp = 1; t.addr = 32'h800; t.nwords = 1; t.wdata = '{16'h001B}; t.wmask = '{0}; send(t);
    t = item(); t.rw = 1; t.burst = 1; t.addr = 32'h40; t.nwords = 1; send(t);
    t = item(); t.regsp = 1; t.addr = 32'h800; t.nwords = 1; t.wdata = '{16'h002B}; t.wmask = '{0}; send(t);
    t = item(); t.rw = 1; t.burst = 1; t.addr = 32'h40; t.nwords = 1; send(t);
    t = item(); t.regsp = 1; t.addr = 32'h800; t.nwords = 1; t.wdata = '{16'h00EB}; t.wmask = '{0}; send(t);
    t = item(); t.burst = 1; t.addr = 32'h40; t.nwords = 1; t.wdata = '{16'h4040}; t.wmask = '{0}; send(t);
    t = item(); t.regsp = 1; t.addr = 32'h800; t.nwords = 1; t.wdata = '{16'h00FA}; t.wmask = '{0}; send(t);
    t = item(); t.rw = 1; t.burst = 0; t.addr = 32'h7F; t.nwords = 33; send(t);
    t = item(); t.regsp = 1; t.addr = 32'h800; t.nwords = 1; t.wdata = '{16'hFFFF}; t.wmask = '{0}; send(t);
    t = item(); t.rw = 1; t.regsp = 1; t.addr = 32'h800; t.nwords = 1; send(t);
    t = item(); t.regsp = 1; t.addr = 32'h800; t.nwords = 1; t.wdata = '{16'h001F}; t.wmask = '{0}; send(t);
  endtask
endclass
