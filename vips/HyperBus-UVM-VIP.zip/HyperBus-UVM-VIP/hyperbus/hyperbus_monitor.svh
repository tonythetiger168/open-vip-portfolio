// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_monitor.svh -- HyperBus monitor: transactions between CS# fall and rise: command-address and write beats from DQ on CK edges, read bytes on RWDS edges, latency from the released CK edges

class hyperbus_monitor extends uvm_monitor;
  `uvm_component_utils(hyperbus_monitor)

  virtual hyperbus_if vif;
  uvm_analysis_port #(hyperbus_transaction) ap;
  hyperbus_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual hyperbus_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hyperbus: virtual interface not set")
    if (!uvm_config_db#(hyperbus_config)::get(this, "", "cfg", cfg))
      cfg = hyperbus_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] hb[$], db[$];
      bit [1:0] mb[$];
      bit mk[$];
      int ne = 0, nrel = 0, first = -1, firstw = -1;
      bit ck_p = 0, rw_p = 0, cs_p = 1, l2x = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.mon_cb.cs_n) begin
          if (cs_p) begin hb.delete(); db.delete(); mk.delete(); ne = 0; nrel = 0; first = -1; firstw = -1; end
          if (vif.mon_cb.rwds_s != rw_p && vif.mon_cb.dq_s_oe) begin
            if (first < 0) first = nrel;
            db.push_back(vif.mon_cb.dq_s);
          end
          if (vif.mon_cb.ck != ck_p) begin
            ne++;
            if (vif.mon_cb.dq_m_oe) begin
              hb.push_back(vif.mon_cb.dq_m);
              mk.push_back(vif.mon_cb.rwds_m_oe && vif.mon_cb.rwds_m);
              if (ne > 6 && firstw < 0) firstw = nrel;
            end else nrel++;
            if (ne == 2) l2x = vif.mon_cb.rwds_s;
          end
        end else if (!cs_p) assemble(hb, mk, db, l2x, nrel, first, firstw);
        ck_p = vif.mon_cb.ck; rw_p = vif.mon_cb.rwds_s; cs_p = vif.mon_cb.cs_n;
      end
    end
  endtask

  function void publish(hyperbus_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  function void assemble(bit [7:0] hb[$], bit mk[$], bit [7:0] db[$], bit l2x, int nrel, int first, int firstw);
    hyperbus_transaction t = hyperbus_transaction::type_id::create("t");
    bit [47:0] ca = 0;
    if (hb.size() < 6) begin
      `uvm_error("MON", $sformatf("HyperBus: transaction with %0d command-address beats", hb.size()))
      return;
    end
    for (int i = 0; i < 6; i++) ca = {ca[39:0], hb[i]};
    t.rw = ca[47]; t.regsp = ca[46]; t.burst = ca[45]; t.addr = {ca[44:16], ca[2:0]};
    t.lat2x = l2x;
    if (t.rw) begin
      // the first byte answers the first CK edge after the latency
      t.lat_clk = (first > 0) ? (first - 1) / 2 : 0;
      t.nwords = (first > 0) ? (nrel - (first - 1)) / 2 : 0;
      for (int i = 0; i + 1 < db.size(); i += 2) t.rdata.push_back({db[i], db[i + 1]});
    end else begin
      t.lat_clk = (firstw > 0) ? firstw / 2 : 0;
      t.nwords = (hb.size() - 6) / 2;
      for (int i = 6; i + 1 < hb.size(); i += 2) begin
        t.wdata.push_back({hb[i], hb[i + 1]});
        t.wmask.push_back({mk[i], mk[i + 1]});
      end
    end
    publish(t);
  endfunction
endclass
