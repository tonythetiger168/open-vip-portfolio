// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_transaction.svh -- HyperBus transaction

class hyperbus_transaction extends uvm_sequence_item;
  `uvm_object_utils(hyperbus_transaction)

  // request (driven by the agent)
  rand bit rw;
  rand bit regsp;
  rand bit burst;
  rand bit [31:0] addr;
  rand bit [5:0] nwords;
  bit [15:0] wdata[$];
  bit [1:0] wmask[$];
  // response (returned by the DUT)
  bit [15:0] rdata[$];
  bit lat2x;
  bit [4:0] lat_clk;
  // bookkeeping (not compared)
  rand bit [31:0] seed;
  rand bit [1:0] rsel;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { regsp dist { 0 := 10, 1 := 2 }; }
  constraint c_mem  { !regsp -> addr < 256 && nwords >= 1 && nwords <= 20; }
  constraint c_reg  { regsp -> nwords == 1 && addr == (rsel == 0 ? 32'h0 : rsel == 1 ? 32'h1 : rsel == 2 ? 32'h2 : 32'h800);
                      (regsp && !rw) -> rsel == 3; }

  function new(string name = "hyperbus_transaction"); super.new(name); endfunction

  // write data and masks from the seed; a CR0 write picks a valid latency code
  function void post_randomize();
    bit [31:0] x = seed | 1;
    wdata.delete(); wmask.delete();
    if (!rw)
      for (int i = 0; i < nwords; i++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        wdata.push_back(x[15:0]);
        wmask.push_back((!regsp && x[20:18] == 0) ? x[17:16] : 2'b00);
      end
    if (regsp && !rw) begin
      bit [3:0] code;
      case (x[26:24] % 5) 0: code = 4'h0; 1: code = 4'h1; 2: code = 4'h2; 3: code = 4'hE; default: code = 4'hF; endcase
      wdata[0] = {8'h8F, code, x[27], 1'b1, x[29:28]};
    end
  endfunction

  function void do_copy(uvm_object rhs);
    hyperbus_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    rw = rhs_.rw;
    regsp = rhs_.regsp;
    burst = rhs_.burst;
    addr = rhs_.addr;
    nwords = rhs_.nwords;
    wdata = rhs_.wdata;
    wmask = rhs_.wmask;
    rdata = rhs_.rdata;
    lat2x = rhs_.lat2x;
    lat_clk = rhs_.lat_clk;
    seed = rhs_.seed;
    rsel = rhs_.rsel;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    hyperbus_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (rw != rhs_.rw) return 0;
    if (regsp != rhs_.regsp) return 0;
    if (burst != rhs_.burst) return 0;
    if (addr != rhs_.addr) return 0;
    if (nwords != rhs_.nwords) return 0;
    if (wdata.size() != rhs_.wdata.size()) return 0;
    foreach (wdata[i]) if (wdata[i] != rhs_.wdata[i]) return 0;
    if (wmask.size() != rhs_.wmask.size()) return 0;
    foreach (wmask[i]) if (wmask[i] != rhs_.wmask[i]) return 0;
    if (rdata.size() != rhs_.rdata.size()) return 0;
    foreach (rdata[i]) if (rdata[i] != rhs_.rdata[i]) return 0;
    if (lat2x != rhs_.lat2x) return 0;
    if (lat_clk != rhs_.lat_clk) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(hyperbus_transaction rhs_);
    if (rw != rhs_.rw) return 0;
    if (regsp != rhs_.regsp) return 0;
    if (burst != rhs_.burst) return 0;
    if (addr != rhs_.addr) return 0;
    if (nwords != rhs_.nwords) return 0;
    if (wdata.size() != rhs_.wdata.size()) return 0;
    foreach (wdata[i]) if (wdata[i] != rhs_.wdata[i]) return 0;
    if (wmask.size() != rhs_.wmask.size()) return 0;
    foreach (wmask[i]) if (wmask[i] != rhs_.wmask[i]) return 0;
    return 1;
  endfunction

  function string qstr_wdata();
    string s = $sformatf("[%0d]{", wdata.size());
    foreach (wdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", wdata[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_wmask();
    string s = $sformatf("[%0d]{", wmask.size());
    foreach (wmask[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", wmask[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rdata();
    string s = $sformatf("[%0d]{", rdata.size());
    foreach (rdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rdata[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("HyperBus{tag=%0d rw=0x%0h regsp=0x%0h burst=0x%0h addr=0x%0h nwords=0x%0h wdata=%s wmask=%s rdata=%s lat2x=0x%0h lat_clk=0x%0h}", tag, rw, regsp, burst, addr, nwords, qstr_wdata(), qstr_wmask(), qstr_rdata(), lat2x, lat_clk);
  endfunction
endclass
