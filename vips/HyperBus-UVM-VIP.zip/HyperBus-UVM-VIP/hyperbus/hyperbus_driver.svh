// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_driver.svh -- HyperBus driver: one transaction per item: command-address, RWDS latency level, latency clocks, data words (read bytes on RWDS edges, write bytes with the RWDS mask)

class hyperbus_driver extends uvm_driver #(hyperbus_transaction);
  `uvm_component_utils(hyperbus_driver)

  uvm_analysis_port #(hyperbus_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual hyperbus_if vif;
  hyperbus_config cfg;

  bit [15:0] cr0 = HB_CR0_RESET;   // the host's copy of CR0 (it programs the latency)

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hyperbus_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hyperbus: virtual interface not set")
    if (!uvm_config_db#(hyperbus_config)::get(this, "", "cfg", cfg))
      cfg = hyperbus_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    hyperbus_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.cs_n      <= 1'b1;
    vif.drv_cb.ck        <= 1'b0;
    vif.drv_cb.dq_m      <= '0;
    vif.drv_cb.dq_m_oe   <= 1'b0;
    vif.drv_cb.rwds_m    <= 1'b0;
    vif.drv_cb.rwds_m_oe <= 1'b0;
  endtask

  task drive_item(hyperbus_transaction t);
    bit [47:0] ca = {t.rw, t.regsp, t.burst, t.addr[31:3], 13'h0, t.addr[2:0]};
    bit [7:0] rb[$];
    bit rp;
    int lat = 0;
    t.rdata.delete();
    @(vif.drv_cb);
    vif.drv_cb.cs_n <= 1'b0;
    @(vif.drv_cb);
    for (int i = 5; i >= 0; i--) begin
      beat(1'b1, ca[8*i +: 8], 1'b0, 1'b0);
      if (i == 4) t.lat2x = vif.drv_cb.rwds_s;
    end
    if (!(!t.rw && t.regsp)) lat = hb_lat(cr0[7:4]) * (t.lat2x ? 2 : 1);
    t.lat_clk = lat;
    if (t.rw) begin
      rp = vif.drv_cb.rwds_s;
      for (int i = 0; i < 2 * lat + 2 * t.nwords + 3; i++) begin
        if (i < 2 * lat + 2 * t.nwords) beat(1'b0, 8'h0, 1'b0, 1'b0);
        else @(vif.drv_cb);
        if (vif.drv_cb.rwds_s != rp && vif.drv_cb.dq_s_oe) rb.push_back(vif.drv_cb.dq_s);
        rp = vif.drv_cb.rwds_s;
      end
      for (int i = 0; i + 1 < rb.size(); i += 2) t.rdata.push_back({rb[i], rb[i + 1]});
    end else begin
      repeat (2 * lat) beat(1'b0, 8'h0, 1'b0, 1'b0);
      foreach (t.wdata[i]) begin
        beat(1'b1, t.wdata[i][15:8], !t.regsp, t.wmask[i][1]);
        beat(1'b1, t.wdata[i][7:0],  !t.regsp, t.wmask[i][0]);
      end
      if (t.regsp && t.addr == 32'h800 && t.wdata.size() != 0)
        cr0 = (cr0 & ~HB_CR0_WMASK) | (t.wdata[0] & HB_CR0_WMASK);
    end
    vif.drv_cb.dq_m_oe <= 1'b0; vif.drv_cb.rwds_m_oe <= 1'b0;
    @(vif.drv_cb);
    vif.drv_cb.cs_n <= 1'b1;
    repeat (3) @(vif.drv_cb);
  endtask

  // one beat: toggle CK, drive (oe) or release DQ and RWDS
  task beat(bit oe, bit [7:0] d, bit moe, bit m);
    vif.drv_cb.ck        <= !vif.drv_cb.ck;
    vif.drv_cb.dq_m_oe   <= oe;
    vif.drv_cb.dq_m      <= oe ? d : 8'h0;
    vif.drv_cb.rwds_m_oe <= moe;
    vif.drv_cb.rwds_m    <= moe ? m : 1'b0;
    @(vif.drv_cb);
  endtask
endclass
