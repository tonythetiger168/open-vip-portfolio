// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_pkg.sv -- HyperBus UVM VIP package

package hyperbus_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import hyperbus_defs_pkg::*;
  export hyperbus_defs_pkg::*;

  `include "hyperbus_transaction.svh"
  `include "hyperbus_config.svh"
  `include "hyperbus_sequencer.svh"
  `include "hyperbus_driver.svh"
  `include "hyperbus_monitor.svh"
  `include "hyperbus_agent.svh"
  `include "hyperbus_sequences.svh"
  `include "hyperbus_checker.svh"
  `include "hyperbus_coverage.svh"
endpackage
