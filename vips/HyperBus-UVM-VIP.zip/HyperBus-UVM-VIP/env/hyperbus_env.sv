// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hyperbus_env.sv -- HyperBus environment: reference-model scoreboard, checker, coverage

package hyperbus_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import hyperbus_defs_pkg::*;
  import hyperbus_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class hyperbus_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(hyperbus_scoreboard)
    uvm_analysis_imp_exp #(hyperbus_transaction, hyperbus_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(hyperbus_transaction, hyperbus_scoreboard) obs_ap;

    hyperbus_config cfg;
    hyperbus_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [15:0] mem [256];
    bit [15:0] cr0 = HB_CR0_RESET;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(hyperbus_config)::get(this, "", "cfg", cfg))
        cfg = hyperbus_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(hyperbus_transaction t);
      // independent HyperRAM model: latency from CR0, wrapped bursts, byte masks
      int L = hb_lat(cr0[7:4]), W = hb_wrap(cr0[1:0]);
      bit [31:0] a;
      if (cr0[3]) t.lat2x = 1;                 // fixed latency: always doubled
      t.lat_clk = (!t.rw && t.regsp) ? 0 : L * (t.lat2x ? 2 : 1);
      t.rdata.delete();
      for (int i = 0; i < t.nwords; i++) begin
        a = t.burst ? t.addr + i : ((t.addr & ~(W - 1)) | ((t.addr + i) & (W - 1)));
        if (t.rw) begin
          if (!t.regsp) t.rdata.push_back(mem[a[7:0]]);
          else t.rdata.push_back(t.addr == 0 ? 16'h0C81 : t.addr == 1 ? 16'h0001 : t.addr == 32'h800 ? cr0 : 16'h0);
        end else if (!t.regsp && i < t.wdata.size()) begin
          if (!t.wmask[i][1]) mem[a[7:0]][15:8] = t.wdata[i][15:8];
          if (!t.wmask[i][0]) mem[a[7:0]][7:0]  = t.wdata[i][7:0];
        end
      end
      if (!t.rw && t.regsp && t.addr == 32'h800 && t.wdata.size() != 0)
        cr0 = (cr0 & ~HB_CR0_WMASK) | (t.wdata[0] & HB_CR0_WMASK);
    endfunction

    function void write_exp(hyperbus_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(hyperbus_transaction t);
      hyperbus_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        hyperbus_transaction e = exp_q.pop_front();
        hyperbus_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("hyperbus scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class hyperbus_env extends uvm_env;
    `uvm_component_utils(hyperbus_env)
    hyperbus_agent      agt;
    hyperbus_scoreboard sb;
    hyperbus_checker    chk;
    hyperbus_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = hyperbus_agent     ::type_id::create("agt", this);
      sb  = hyperbus_scoreboard::type_id::create("sb",  this);
      chk = hyperbus_checker   ::type_id::create("chk", this);
      cov = hyperbus_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
