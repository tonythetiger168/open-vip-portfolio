# eUSB2 Protocol VIP — Unified Multi-Protocol Verification IP

## 前言概述 (Protocol Overview)

eUSB2 (embedded USB2, 1.2V single-ended) 驗證重點：
ULPI PHY 介面 (command/register access)、USB2 packet 序列
(token/data/handshake)、CRC5/CRC16、SE1 非法狀態檢測、
repeater mode、suspend/resume。

本 VIP 為 USB 系列統一架構：單一環境涵蓋 7 種協議
(USB 2.0 / 3.0 / 3.1 / 3.2 / USB4 / eUSB2 / USB-PD)，本專案聚焦於 **eUSB2 Protocol VIP**。

## 架構 (Architecture)

```
top_tb.sv
 ├─ usb_vip_if × 7 (MAC + PHY 雙層, clocking blocks, modports, IF assertions)
 └─ usb_dut (functional DUT model)
     ├─ usb2_dev_ep ×2     USB2/eUSB2 device endpoint: chirp response,
     │                      CRC16 檢查, ACK/STALL/timeout, babble detect
     ├─ usb3_phy_model ×3  PIPE PHY: LTSSM walk→U0, CRC32 check, loopback ACK
     ├─ usb4_phy_model     PIPE4 PHY: link ready, router sideband, loopback
     └─ pd_controller_model PD controller: header decode, Vbus transition
usb_env
 ├─ usb_agent × 7 (usb_sequencer / usb_driver / usb_monitor)
 ├─ usb_scoreboard  expected(drv_ap→exp_imp) vs observed(mon→analysis_imp)
 │                   pairwise compare, n_matches/n_mismatches, UVM_ERROR on mismatch
 ├─ usb_coverage_model × 4 (8 covergroups, 見下)
 └─ *_protocol_checker × 5 (procedural protocol checks + covergroups)
```

Closed loop：driver 依 transaction descriptor 送出 token/data packet
（含 CRC16/CRC32 trailer，data packet 以 `mac_frame_num` 作 sideband byte count），
DUT 依位址/endpoint/CRC 決定 ACK/STALL/timeout/babble，monitor 從 MAC/PHY
波形解碼 PID→packet type、重組 payload（剝除 CRC trailer）、觀察 handshake，
scoreboard 端到端比對。

## Sequence 清單

| Sequence | 類型 | 說明 |
|----------|------|------|
| `usb_base_sequence` | base | 共用參數/constraint |
| `usb_random_sequence` | random | protocol-weighted 隨機流量 (90% 打到 DUT 位址) |
| `usb_normal_seq` | directed | 正常 SETUP/IN/OUT/DATA, ACK 路徑 |
| `usb_error_inject_seq` | directed | CRC 腐敗 / timeout(未實作位址) / STALL(EP15) / babble(超長) |
| `usb_reset_seq` | directed | bus reset (SE0) 後重新列舉 |
| `usb_back_to_back_seq` | directed | 最小 inter-packet gap (=2) 背靠背 |
| `usb_stress_seq` | directed | 大 payload (256–512B) 高速率壓力 |
| `usb_corner_seq` | directed | ZLP / 1-byte / max-packet / DATA0-DATA1 toggle / 邊界 EP |
| `usb_sof_seq` | directed | SOF frame stream (11-bit frame number) |
| `usb_regression_sequence` | regression | 加權混合 regression |
| `usb_directed_regression_sequence` | regression | directed library 全掃 |

Tests：`usb_random_regression_test` (預設), `usb_directed_test`,
`usb_hs_test`, `usb_ss_test`, `usb_ssp_test`, `usb_ss20_test`,
`usb4_test`, `usb_eusb2_test`, `usb_pd_test`。

## SVA 清單 (rtl/sva/eusb2_compliance_checker.sv, module on eusb2_link_if)

每個違規都是 `UVM_ERROR`：
- **L1 signal sanity (4)**：合法 link state 編碼、state / strobe 無 X、LPM answer 帶回應碼、register answer 無 X
- **L2 link (5)**：合法轉移、attach 拉低即 DISC、hs 只在 powered-up state、chirp K 只在 chirp 期間、wake K 只在 RWAKE
- **L3 LPM (5)**：LPM answer 一定在 L0 的 LPM token 之後一個 clock；ACK 進 L1、NYET / STALL 留在 L0；STALL 只在 LPM 關閉時；L1 只能由 ACK 進入
- **L4 power (3)**：HS 只經 host chirp 進入、L2 remote wake 只在啟用時、reset 計數只對應進入 RESET
- **L5 registers (4)**：register answer 一定在 repeater mode 的 access 之後一個 clock、被拒絕的 access 一定計數、CTRL 只有 3 bits、counter 每 clock 最多加一
- 12 個 cover：HS、FS fallback、L1、L2、L1 remote wake、L2 remote wake、LPM NYET、LPM STALL、register access 成功 / 被拒絕、bad control message、disconnect

## Functional Coverage 清單

`usb_coverage_model` (8 covergroups，含 cross)：
`cg_txn_type` (protocol×type cross)、`cg_endpoint` (ep×type cross)、
`cg_packet_size` (size×protocol cross)、`cg_device_state` (FSM transition bins,
state×protocol cross)、`cg_phy_layer` (phy_if×term cross)、
`cg_pd_contract` (contract×voltage cross)、`cg_error_injection` (err×recovery cross)、
`cg_data_pattern` (first-byte pattern×length cross)。
Interface covergroup：`cg_usb_interface` (MAC handshake × device state cross)。
各 protocol checker 另有專屬 covergroup + cross。

## 快速上手 (Quick Start)

```sh
cd scripts
make compile           # VCS: pkg → checkers → if → sequences → env → tests → tb
make simulate TEST=usb_random_regression_test
make simulate TEST=usb_directed_test
make coverage          # 見 scripts/coverage.mk
```

環境變數 `TEST` 選擇測試；`UVM_VERBOSITY` 控制訊息等級。
regression 結束時 scoreboard 回報 `n_matches/n_mismatches`，
compliance checker 回報 L1/L2/L3/L4 tiered coverage。

## Deepened Features (v1.8.0)

- **Port link controller model** (`tb/eusb2_smoke_model.sv`): eUSB2 peripheral port in native mode or behind a repeater: attach / disconnect, native SE0 reset and repeater control messages (SE1 pulse trains: CM.RESET / CM.SUSPEND / CM.RESUME / CM.RAP, bad messages counted), HS chirp or FS fallback, L0 idle -> L2, LPM (ACK / NYET / STALL) -> L1 with the token's BESL and remote-wake bit, host resume (K in native mode, CM.RESUME behind a repeater) with BESL-timed L1 exit, device remote wake from L1 / L2, repeater register access (ID, CTRL with lpm_en / rwake_en / hs_dis, STATUS, scratch, tuning; read-only and out-of-range accesses rejected, access window timeout), 10 counters
- **Functional test** (`tb/smoke_func_tb.sv`): 88 self-checks (replaces `func_eusb2_tb.sv`)
- **UVM agent** (`vip/eusb2/eusb2_link_pkg.sv` on `eusb2_link_if`): host-port driver / monitor, a scoreboard that predicts the port clock by clock (link state, chirp / wake K, LPM and register answers, CTRL, all counters), link / LPM / register / event covergroups, a 1500-iteration random regression over both modes (`eusb2_link_test`, runs on Verilator)
- **SVA**: `rtl/sva/eusb2_compliance_checker.sv` rewritten on the link interface (21 assertions, 12 covers)
