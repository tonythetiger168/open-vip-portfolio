# eUSB2 Test Plan（eUSB2-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | eUSB2 1.1 peripheral port (native / repeater mode) |
| 家族 | USB |
| 類型 | UVM VIP |
| 交付目錄 | `eUSB2-VIP/` |
| 目前 L1b 狀態 | PASS |

## 2. DUT / 待測對象

- `eusb2_smoke_model`（eUSB2 peripheral port link controller：attach、reset、HS chirp、L0 / L1 / L2、LPM、resume、remote wake、repeater control message 與 register access）
- `usb3_phy_model`、`usb4_phy_model`、`pd_controller_model`（umbrella top 的 PIPE loopback model，沿用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | in reset: DISC, nothing sent; after rst_n CTRL = lpm_en | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | attach: J for 4 clocks, nothing taken before reset, disconnect counted, re-attach | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | native SE0 reset after 16 clocks, RESET 8 clocks, device chirp K, 3 host K-J pairs -> HS | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | L0 idle -> L2 after 24 clocks (HS kept), SE1 ignored in native mode, K resume (>= 4 clocks), 8-clock L2 resume | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | LPM: NYET while busy, ACK -> L1, remote wake allowed by the token (6 clocks of K) | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | L1 without remote wake, host resume timed 4 + 2 * BESL | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | L2 remote wake only with DEVICE_REMOTE_WAKEUP | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | reset from L1, no HS capability -> FS without a chirp, chirp timeout and 1-clock levels -> FS, reset not re-triggered by held SE0 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | disconnect in L0 clears HS | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | repeater mode: SE0 is not a reset, CM.RESET after its end gap, CM.SUSPEND, K does not resume, CM.RESUME, bad / unknown control messages, long SE1 pulses | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | register access: ID, STATUS, read-only and out-of-range writes rejected, scratch, 6-bit tuning, window timeout, access without CM.RAP | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | CTRL: LPM disabled -> STALL, rwake_en -> L2 remote wake, hs_dis -> FS after CM.RESET; CM.SUSPEND during RESET rejected; registers survive a bus reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | rst_n clears everything | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | LS / FS keep-alive and the eUSB2 ping protocol in L1 / L2 |
| PT-02 | Repeater-side disconnect detection during L2 |
| PT-03 | Packet-level traffic (tokens / data / handshakes) through the port |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/eusb2_compliance_checker.sv`（L1 signal sanity 4、L2 link 5、L3 LPM 5、L4 power 3、L5 registers 4，加 12 個 cover）
- Functional coverage：`vip/eusb2/eusb2_link_pkg.sv` 的 `eusb2_coverage`（cg_link 轉移、cg_lpm 回應、cg_rap 位址 × 讀寫、cg_ev 事件含兩種 mode 的 reset / resume）
- Scoreboard：`eusb2_scoreboard` 逐 clock 預測 port（link state、chirp / wake K、LPM 回應、register answer、CTRL、10 個 counter）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/eUSB2-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py eUSB2-VIP && python3 smoke/smoke_run.py eUSB2-VIP   # L1b
python3 tools/run_uvm_tests.py eUSB2-VIP       # UVM（Verilator），期望 SB_PASS
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 行為級 model 以每 clock 一個 bus level 建模，計時器縮短；control message 的 pulse-count 編碼為簡化版本，不含 1.2 V 類比層與 repeater 的 USB 2.0 側。

---
*文件版本：v1.8.0*
