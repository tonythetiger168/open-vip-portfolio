// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// eUSB2 Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 17
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
// L4=Protocol-specific rules
`ifndef EUSB2_COMPLIANCE_CHECKER_SV
`define EUSB2_COMPLIANCE_CHECKER_SV

module eusb2_compliance_checker (usb_vip_if vif);
  import uvm_pkg::*;
  import usb_vip_pkg::*;
  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_eusb2_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> ##[1:8] vif.ready; endproperty
  assert_p_eusb2_valid: assert property(p_eusb2_valid) l1_pass[0]++; else begin `uvm_warning("EUSB2_L1", "Valid implies ready failed"); l1_fail[0]++; end
  cover_p_eusb2_valid: cover property(p_eusb2_valid);

  property p_eusb2_power_state; @(posedge vif.clk) disable iff (!vif.rst_n) vif.power_state inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_eusb2_power_state: assert property(p_eusb2_power_state) l1_pass[1]++; else begin `uvm_warning("EUSB2_L1", "Power state valid failed"); l1_fail[1]++; end
  cover_p_eusb2_power_state: cover property(p_eusb2_power_state);

  property p_eusb2_role; @(posedge vif.clk) disable iff (!vif.rst_n) vif.role inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_eusb2_role: assert property(p_eusb2_role) l1_pass[2]++; else begin `uvm_warning("EUSB2_L1", "Role valid failed"); l1_fail[2]++; end
  cover_p_eusb2_role: cover property(p_eusb2_role);

  property p_eusb2_sop_eop; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> $past(vif.sop,1) || vif.sop; endproperty
  assert_p_eusb2_sop_eop: assert property(p_eusb2_sop_eop) l1_pass[3]++; else begin `uvm_warning("EUSB2_L1", "SOP before EOP failed"); l1_fail[3]++; end
  cover_p_eusb2_sop_eop: cover property(p_eusb2_sop_eop);


  // ===== L2: Full Protocol (4 SVAs) =====
  property p_eusb2_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_eusb2_no_x: assert property(p_eusb2_no_x) l2_pass[0]++; else begin `uvm_warning("EUSB2_L2", "No X when valid failed"); l2_fail[0]++; end
  cover_p_eusb2_no_x: cover property(p_eusb2_no_x);

  property p_eusb2_link_up; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.link_up; endproperty
  assert_p_eusb2_link_up: assert property(p_eusb2_link_up) l2_pass[1]++; else begin `uvm_warning("EUSB2_L2", "Link up for traffic failed"); l2_fail[1]++; end
  cover_p_eusb2_link_up: cover property(p_eusb2_link_up);

  property p_eusb2_hs_mode; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_mode |-> vif.power_state == 2'b00; endproperty
  assert_p_eusb2_hs_mode: assert property(p_eusb2_hs_mode) l2_pass[2]++; else begin `uvm_warning("EUSB2_L2", "HS mode valid failed"); l2_fail[2]++; end
  cover_p_eusb2_hs_mode: cover property(p_eusb2_hs_mode);

  property p_eusb2_repeater; @(posedge vif.clk) disable iff (!vif.rst_n) vif.repeater_mode |-> vif.power_state inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_eusb2_repeater: assert property(p_eusb2_repeater) l2_pass[3]++; else begin `uvm_warning("EUSB2_L2", "Repeater mode failed"); l2_fail[3]++; end
  cover_p_eusb2_repeater: cover property(p_eusb2_repeater);


  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: stalled transfer must hold valid until accepted
  property p_eusb2_l3_valid_hold; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && !vif.ready) |=> vif.valid; endproperty
  assert_p_eusb2_l3_valid_hold: assert property(p_eusb2_l3_valid_hold) l3_pass[0]++; else begin `uvm_warning("EUSB2_L3", "Valid dropped before ready failed"); l3_fail[0]++; end
  cover_p_eusb2_l3_valid_hold: cover property(p_eusb2_l3_valid_hold);
  // L3-2: an OUT/SETUP/IN token must be answered by a DATA or handshake packet inside 16 cycles
  property p_eusb2_l3_token_rsp; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b0001,4'b1101,4'b1001})
    |-> ##[1:16] (vif.mac_valid && vif.mac_pid[3:0] inside {4'b0011,4'b1011,4'b0111,4'b1111,4'b0010,4'b1010,4'b1110,4'b0110}); endproperty
  assert_p_eusb2_l3_token_rsp: assert property(p_eusb2_l3_token_rsp) l3_pass[1]++; else begin `uvm_warning("EUSB2_L3", "Token not answered by data/handshake failed"); l3_fail[1]++; end
  cover_p_eusb2_l3_token_rsp: cover property(p_eusb2_l3_token_rsp);
  // L3-3: repeater mode requires an operational link
  property p_eusb2_l3_repeater_link; @(posedge vif.clk) disable iff (!vif.rst_n) vif.repeater_mode |-> vif.link_up; endproperty
  assert_p_eusb2_l3_repeater_link: assert property(p_eusb2_l3_repeater_link) l3_pass[2]++; else begin `uvm_warning("EUSB2_L3", "Repeater mode without link failed"); l3_fail[2]++; end
  cover_p_eusb2_l3_repeater_link: cover property(p_eusb2_l3_repeater_link);
  // L3-4: no traffic may be sent while the link is suspended
  property p_eusb2_l3_suspend_quiet; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_suspend |-> !vif.valid; endproperty
  assert_p_eusb2_l3_suspend_quiet: assert property(p_eusb2_l3_suspend_quiet) l3_pass[3]++; else begin `uvm_warning("EUSB2_L3", "Traffic during suspend failed"); l3_fail[3]++; end
  cover_p_eusb2_l3_suspend_quiet: cover property(p_eusb2_l3_suspend_quiet);

  // ---------------- L4: eUSB2 protocol-specific rules (5) ----------------
  // L4-1: single-ended SE1 (2'b11) is illegal on eUSB2 lines
  property p_eusb2_l4_se1; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_linestate != 2'b11; endproperty
  assert_p_eusb2_l4_se1: assert property(p_eusb2_l4_se1) l4_pass[0]++; else begin `uvm_warning("EUSB2_L4", "SE1 illegal state"); l4_fail[0]++; end
  cover_p_eusb2_l4_se1: cover property(p_eusb2_l4_se1);

  // L4-2: UTMI RX error only valid during RX active
  property p_eusb2_l4_rxerr; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_rxerror |-> vif.utmi_rxactive; endproperty
  assert_p_eusb2_l4_rxerr: assert property(p_eusb2_l4_rxerr) l4_pass[1]++; else begin `uvm_warning("EUSB2_L4", "RX error outside RX active"); l4_fail[1]++; end
  cover_p_eusb2_l4_rxerr: cover property(p_eusb2_l4_rxerr);

  // L4-3: DATA payload ends with EOP within 80 beats (anti-babble)
  property p_eusb2_l4_babble; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b0011,4'b1011} |-> ##[1:80] vif.mac_eop; endproperty
  assert_p_eusb2_l4_babble: assert property(p_eusb2_l4_babble) l4_pass[2]++; else begin `uvm_warning("EUSB2_L4", "DATA packet babble"); l4_fail[2]++; end
  cover_p_eusb2_l4_babble: cover property(p_eusb2_l4_babble);

  // L4-4: suspend entry parks the line in J state
  property p_eusb2_l4_suspend_j; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_suspend |-> vif.utmi_linestate == 2'b01; endproperty
  assert_p_eusb2_l4_suspend_j: assert property(p_eusb2_l4_suspend_j) l4_pass[3]++; else begin `uvm_warning("EUSB2_L4", "Suspend without J state"); l4_fail[3]++; end
  cover_p_eusb2_l4_suspend_j: cover property(p_eusb2_l4_suspend_j);

  // L4-5: bus reset forces SE0 on the line
  property p_eusb2_l4_reset_se0; @(posedge vif.clk) disable iff (!vif.rst_n) vif.dev_reset |-> vif.utmi_linestate == 2'b00; endproperty
  assert_p_eusb2_l4_reset_se0: assert property(p_eusb2_l4_reset_se0) l4_pass[4]++; else begin `uvm_warning("EUSB2_L4", "Reset without SE0"); l4_fail[4]++; end
  cover_p_eusb2_l4_reset_se0: cover property(p_eusb2_l4_reset_se0);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l1_hit=0, l2_hit=0, l3_hit=0;
    int l4_total=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("EUSB2_RPT", $sformatf("=== EUSB2 Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("EUSB2_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("EUSB2_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("EUSB2_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("EUSB2_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("EUSB2_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end

endmodule
`endif
