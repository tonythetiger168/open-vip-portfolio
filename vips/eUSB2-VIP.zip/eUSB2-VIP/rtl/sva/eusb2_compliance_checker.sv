// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eUSB2 peripheral port compliance checker on eusb2_link_if. Every
// violation is a UVM_ERROR.
//   L1 signal sanity   (4)  legal link state code, no X on state / strobes,
//                           LPM answer code, register answer known
//   L2 link            (5)  legal transitions, disconnect without attach,
//                           hs only in a powered-up state, chirp K only while
//                           chirping, wake K only in RWAKE
//   L3 LPM             (5)  an LPM answer follows an LPM token in L0 one clock
//                           earlier; ACK enters L1, NYET / STALL stay in L0;
//                           STALL only with LPM disabled; L1 only by an ACK
//   L4 power           (3)  HS only through the host chirp, L2 remote wake
//                           only when enabled, a reset counted only on entering
//                           RESET
//   L5 registers       (4)  a register answer follows an access one clock
//                           earlier in repeater mode, rejected answers counted,
//                           CTRL keeps 3 bits, counters step by at most one
`ifndef EUSB2_COMPLIANCE_CHECKER_SV
`define EUSB2_COMPLIANCE_CHECKER_SV

module eusb2_compliance_checker (eusb2_link_if vif);
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [3:0] DISC = 4'd0, ATT = 4'd1, RST = 4'd2, CHIRP = 4'd3, HSW = 4'd4, L0 = 4'd5, L1 = 4'd6,
                         L2 = 4'd7, RSM = 4'd8, WAKE = 4'd9;

  function automatic bit legal(input logic [3:0] a, input logic [3:0] b);
    if (a == b || b == DISC) return 1'b1;
    if (b == RST) return a == ATT || a == L0 || a == L1 || a == L2;
    case (a)
      DISC:  return b == ATT;
      RST:   return b == CHIRP || b == L0;
      CHIRP: return b == HSW;
      HSW:   return b == L0;
      L0:    return b == L1 || b == L2;
      L1:    return b == RSM || b == WAKE;
      L2:    return b == RSM || b == WAKE;
      RSM:   return b == L0;
      WAKE:  return b == L0;
      default: return 1'b0;
    endcase
  endfunction
  function automatic bit step1(input logic [7:0] now, input logic [7:0] was);
    return now == was || now == was + 8'd1;
  endfunction
  wire [79:0] cnts = {vif.resets, vif.l1_cnt, vif.l2_cnt, vif.wake_cnt, vif.lpm_nyet, vif.lpm_stall, vif.cm_bad,
                      vif.rap_err, vif.disc_cnt, vif.chirp_fail};
  function automatic bit all_step1(input logic [79:0] now, input logic [79:0] was);
    for (int i = 0; i < 10; i++) if (!step1(now[8*i +: 8], was[8*i +: 8])) return 1'b0;
    return 1'b1;
  endfunction

  `define E2_CHK(LBL, NAME, PROP, MSG) \
    LBL: assert property (@(posedge vif.clk) disable iff (!vif.rst_n) PROP) \
      else `uvm_error(NAME, MSG)

  // ---------------------------------------------------- L1
  `E2_CHK(a_l1_state, "EUSB2_L1", vif.lstate <= WAKE, "illegal link state code")
  `E2_CHK(a_l1_known, "EUSB2_L1",
          !$isunknown({vif.lstate, vif.hs, vif.chirp_k, vif.rwake_k, vif.lpm_valid, vif.rap_done}),
          "X/Z on the link state or a strobe")
  `E2_CHK(a_l1_lpm, "EUSB2_L1", vif.lpm_valid |-> vif.lpm_resp != 2'd0, "LPM answer without a code")
  `E2_CHK(a_l1_rap, "EUSB2_L1", vif.rap_done |-> !$isunknown({vif.rap_ok, vif.rap_rdata}), "X/Z in a register answer")

  // ---------------------------------------------------- L2
  `E2_CHK(a_l2_trans, "EUSB2_L2", legal($past(vif.lstate), vif.lstate), "illegal link state transition")
  `E2_CHK(a_l2_disc, "EUSB2_L2", !$past(vif.attach) |-> vif.lstate == DISC && !vif.hs, "attached state without attach")
  `E2_CHK(a_l2_hs, "EUSB2_L2", vif.hs |-> vif.lstate inside {L0, L1, L2, RSM, WAKE}, "hs outside a powered-up state")
  `E2_CHK(a_l2_chirp, "EUSB2_L2", vif.chirp_k |-> vif.lstate inside {CHIRP, HSW}, "chirp K outside the chirp")
  `E2_CHK(a_l2_wake, "EUSB2_L2", vif.rwake_k |-> vif.lstate inside {WAKE, L0}, "wake K outside RWAKE")

  // ---------------------------------------------------- L3
  `E2_CHK(a_l3_lpm_src, "EUSB2_L3", vif.lpm_valid |-> $past(vif.lpm_req) && $past(vif.lstate) == L0,
          "LPM answer without an LPM token in L0")
  `E2_CHK(a_l3_ack, "EUSB2_L3", vif.lpm_valid && vif.lpm_resp == 2'd1 |-> vif.lstate == L1, "LPM ACK without L1")
  `E2_CHK(a_l3_nak, "EUSB2_L3", vif.lpm_valid && vif.lpm_resp != 2'd1 |-> vif.lstate == L0,
          "LPM NYET / STALL left L0")
  `E2_CHK(a_l3_stall, "EUSB2_L3", vif.lpm_valid && vif.lpm_resp == 2'd3 |-> !$past(vif.ctrl[0]),
          "LPM STALL with LPM enabled")
  `E2_CHK(a_l3_l1_entry, "EUSB2_L3", vif.lstate == L1 && $past(vif.lstate) != L1 |-> vif.lpm_valid && vif.lpm_resp == 2'd1,
          "L1 entered without an LPM ACK")

  // ---------------------------------------------------- L4
  `E2_CHK(a_l4_hs_entry, "EUSB2_L4", vif.hs && !$past(vif.hs) |-> $past(vif.lstate) == HSW, "HS without the host chirp")
  `E2_CHK(a_l4_l2_wake, "EUSB2_L4", vif.lstate == WAKE && $past(vif.lstate) == L2 |->
                                     $past(vif.rwake_feat) || $past(vif.ctrl[1]),
          "remote wake from L2 while not enabled")
  `E2_CHK(a_l4_reset, "EUSB2_L4", vif.resets != $past(vif.resets) |-> vif.lstate == RST && !vif.hs,
          "reset counted without entering RESET")

  // ---------------------------------------------------- L5
  `E2_CHK(a_l5_rap_src, "EUSB2_L5", vif.rap_done |-> $past(vif.rap_valid) && $past(vif.rep_mode),
          "register answer without an access in repeater mode")
  `E2_CHK(a_l5_rap_err, "EUSB2_L5", (vif.rap_err != $past(vif.rap_err)) == (vif.rap_done && !vif.rap_ok),
          "rejected register access not counted (or counted without one)")
  `E2_CHK(a_l5_ctrl, "EUSB2_L5", vif.ctrl[7:3] == 5'd0, "CTRL has more than 3 bits")
  `E2_CHK(a_l5_step, "EUSB2_L5", all_step1(cnts, $past(cnts)), "a counter moved by more than one")

  // ---------------------------------------------------- covers
  c_hs:      cover property (@(posedge vif.clk) vif.lstate == L0 && vif.hs && $past(vif.lstate) == HSW);
  c_fs:      cover property (@(posedge vif.clk) vif.chirp_fail != $past(vif.chirp_fail));
  c_l1:      cover property (@(posedge vif.clk) vif.lstate == L1);
  c_l2:      cover property (@(posedge vif.clk) vif.lstate == L2);
  c_l1_wake: cover property (@(posedge vif.clk) vif.lstate == WAKE && $past(vif.lstate) == L1);
  c_l2_wake: cover property (@(posedge vif.clk) vif.lstate == WAKE && $past(vif.lstate) == L2);
  c_nyet:    cover property (@(posedge vif.clk) vif.lpm_valid && vif.lpm_resp == 2'd2);
  c_stall:   cover property (@(posedge vif.clk) vif.lpm_valid && vif.lpm_resp == 2'd3);
  c_rap_ok:  cover property (@(posedge vif.clk) vif.rap_done && vif.rap_ok);
  c_rap_bad: cover property (@(posedge vif.clk) vif.rap_done && !vif.rap_ok);
  c_cm_bad:  cover property (@(posedge vif.clk) vif.cm_bad != $past(vif.cm_bad));
  c_disc:    cover property (@(posedge vif.clk) vif.disc_cnt != $past(vif.disc_cnt));

  `undef E2_CHK
endmodule

`endif
