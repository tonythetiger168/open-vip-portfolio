// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened eusb2_smoke_model (eUSB2
// peripheral port link controller): attach / disconnect, native SE0 reset
// and repeater CM.RESET, HS chirp and FS fallback, L0 idle -> L2, LPM ->
// L1 with BESL-timed resume, host resume (K / CM.RESUME), remote wake from
// L1 and L2, control-message decoding and the repeater register access
// protocol. Levels are driven on a negedge; outputs are sampled on the next
// negedge.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;
  int i, n;

  logic        clk = 1'b0;
  logic        rst_n = 1'b0;
  logic        rep_mode = 1'b0;
  logic        attach = 1'b0;
  logic        hs_cap = 1'b1;
  logic [1:0]  eline = 2'd0;
  logic        pkt = 1'b0;
  logic        lpm_req = 1'b0;
  logic [3:0]  lpm_besl = 4'd0;
  logic        lpm_rw = 1'b0;
  logic        busy = 1'b0;
  logic        dev_rwake = 1'b0;
  logic        rwake_feat = 1'b0;
  logic        rap_valid = 1'b0;
  logic        rap_wr = 1'b0;
  logic [3:0]  rap_addr = 4'd0;
  logic [7:0]  rap_wdata = 8'h00;
  wire [3:0]   lstate;
  wire         hs, chirp_k, rwake_k, lpm_valid, rap_done, rap_ok;
  wire [1:0]   lpm_resp;
  wire [7:0]   rap_rdata, ctrl;
  wire [7:0]   resets, l1_cnt, l2_cnt, wake_cnt, lpm_nyet, lpm_stall, cm_bad, rap_err, disc_cnt, chirp_fail;
  logic [7:0]  s0, s1;

  always #5 clk = ~clk;

  eusb2_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .rep_mode(rep_mode), .attach(attach), .hs_cap(hs_cap), .eline(eline), .pkt(pkt),
    .lpm_req(lpm_req), .lpm_besl(lpm_besl), .lpm_rw(lpm_rw), .busy(busy), .dev_rwake(dev_rwake),
    .rwake_feat(rwake_feat), .rap_valid(rap_valid), .rap_wr(rap_wr), .rap_addr(rap_addr), .rap_wdata(rap_wdata),
    .lstate(lstate), .hs(hs), .chirp_k(chirp_k), .rwake_k(rwake_k), .lpm_valid(lpm_valid), .lpm_resp(lpm_resp),
    .rap_done(rap_done), .rap_ok(rap_ok), .rap_rdata(rap_rdata), .ctrl(ctrl), .resets(resets), .l1_cnt(l1_cnt),
    .l2_cnt(l2_cnt), .wake_cnt(wake_cnt), .lpm_nyet(lpm_nyet), .lpm_stall(lpm_stall), .cm_bad(cm_bad),
    .rap_err(rap_err), .disc_cnt(disc_cnt), .chirp_fail(chirp_fail)
  );

  localparam logic [1:0] SE0 = 2'd0, J = 2'd1, K = 2'd2, SE1 = 2'd3;
  localparam logic [3:0] DISC = 4'd0, ATT = 4'd1, RST = 4'd2, CHIRP = 4'd3, HSW = 4'd4, L0 = 4'd5, L1 = 4'd6,
                         L2 = 4'd7, RSM = 4'd8, WAKE = 4'd9;

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s (t=%0t lstate=%0d hs=%0b)", msg, $time, lstate, hs); end
  endtask

  task automatic idle(input int c);
    repeat (c) @(negedge clk);
  endtask

  task automatic packet();
    pkt = 1'b1; @(negedge clk); pkt = 1'b0;
  endtask

  // control message: n SE1 pulses (1 clock SE1, 1 clock SE0), then the 4-clock end gap
  task automatic cmsg(input int np, input logic [1:0] rest);
    for (i = 0; i < np; i++) begin eline = SE1; idle(1); eline = SE0; idle(1); end
    eline = rest;
    idle(3);
  endtask

  task automatic lpm(input logic [3:0] b, input bit rw);
    lpm_req = 1'b1; lpm_besl = b; lpm_rw = rw; @(negedge clk); lpm_req = 1'b0;
  endtask

  task automatic rap(input bit wr, input logic [3:0] a, input logic [7:0] d);
    rap_valid = 1'b1; rap_wr = wr; rap_addr = a; rap_wdata = d; @(negedge clk); rap_valid = 1'b0;
  endtask

  // host side of the chirp: 3 K-J pairs, each level 2 clocks
  task automatic host_chirp();
    for (i = 0; i < 3; i++) begin eline = K; idle(2); eline = J; idle(2); end
  endtask

  // native reset then the full HS chirp
  task automatic native_reset_hs();
    eline = SE0; idle(16);
    chk(lstate === RST, "native: SE0 for 16 clocks -> RESET");
    eline = J;
    idle(8);
    chk(lstate === CHIRP, "RESET lasts 8 clocks, then CHIRP");
    n = 0;
    repeat (8) begin idle(1); if (chirp_k === 1'b1) n++; end
    chk(n == 8 && lstate === HSW, "device chirp K, then HS_WAIT");
    idle(1);
    chk(chirp_k === 1'b0, "chirp K ends");
    host_chirp();
    chk(lstate === L0 && hs === 1'b1, "3 host K-J pairs: L0 at HS");
    eline = J;
  endtask

  initial begin
    // ------------------------------------------------ 1. reset
    idle(3);
    chk(lstate === DISC && rap_done === 1'b0 && lpm_valid === 1'b0, "in reset: DISC, nothing sent");
    rst_n = 1'b1;
    idle(1);
    chk(lstate === DISC && hs === 1'b0 && ctrl === 8'h01 && resets === 8'd0 && disc_cnt === 8'd0,
        "after rst_n: DISC, CTRL = lpm_en");

    // ------------------------------------------------ 2. attach (native)
    eline = J; idle(5);
    chk(lstate === DISC, "J without attach: DISC");
    attach = 1'b1;
    eline = K; idle(3); eline = J; idle(3);
    chk(lstate === DISC, "3 clocks of J: not yet attached");
    idle(1);
    chk(lstate === ATT, "J for 4 clocks with attach: ATTACHED");
    packet(); lpm(4'd1, 1'b0);
    chk(lstate === ATT && lpm_valid === 1'b0, "ATTACHED: packets and LPM ignored before reset");
    attach = 1'b0; idle(1);
    chk(lstate === DISC && disc_cnt === 8'd1, "attach low: DISC, counted");
    attach = 1'b1; idle(4);
    chk(lstate === ATT, "re-attach");

    // ------------------------------------------------ 3. native reset, HS chirp
    eline = SE0; idle(15);
    chk(lstate === ATT, "15 clocks of SE0: no reset yet");
    eline = J; idle(1);
    native_reset_hs();
    chk(resets === 8'd1, "one reset");

    // ------------------------------------------------ 4. L0 idle -> L2, native resume
    for (n = 0; n < 5; n++) begin idle(20); packet(); end
    chk(lstate === L0, "packets every 21 clocks keep L0");
    idle(23);
    chk(lstate === L0, "23 idle clocks: L0");
    idle(1);
    chk(lstate === L2 && l2_cnt === 8'd1 && hs === 1'b1, "24 idle clocks: L2 (HS kept)");
    eline = SE1; idle(3); eline = J; idle(5);
    chk(lstate === L2 && cm_bad === 8'd0, "native mode: SE1 is not a control message");
    eline = K; idle(3); eline = J; idle(1);
    chk(lstate === L2, "3 clocks of K: no resume");
    eline = K; idle(4); eline = J; idle(1);
    chk(lstate === RSM, "K for 4 clocks: RESUME");
    idle(7);
    chk(lstate === RSM, "L2 resume lasts 8 clocks");
    idle(1);
    chk(lstate === L0 && hs === 1'b1, "back to L0 at HS");

    // ------------------------------------------------ 5. LPM -> L1, remote wake
    busy = 1'b1; lpm(4'd3, 1'b1); busy = 1'b0;
    chk(lpm_valid === 1'b1 && lpm_resp === 2'd2 && lpm_nyet === 8'd1 && lstate === L0, "LPM while busy: NYET, stay L0");
    idle(1);
    chk(lpm_valid === 1'b0, "LPM answer is one clock");
    lpm(4'd3, 1'b1);
    chk(lpm_valid === 1'b1 && lpm_resp === 2'd1 && lstate === L1 && l1_cnt === 8'd1, "LPM: ACK, L1");
    idle(30);
    chk(lstate === L1, "L1 does not time out to L2");
    dev_rwake = 1'b1; idle(1); dev_rwake = 1'b0;
    chk(lstate === WAKE, "remote wake allowed by the LPM token: RWAKE");
    n = 0;
    repeat (6) begin idle(1); if (rwake_k === 1'b1) n++; end
    chk(n == 6 && lstate === L0 && wake_cnt === 8'd1, "device K for 6 clocks, then L0");
    idle(1);
    chk(rwake_k === 1'b0, "wake K ends");

    // ------------------------------------------------ 6. L1 without remote wake, BESL resume
    lpm(4'd5, 1'b0);
    chk(lstate === L1 && l1_cnt === 8'd2, "second LPM: L1");
    dev_rwake = 1'b1; idle(2); dev_rwake = 1'b0;
    chk(lstate === L1, "remote wake not allowed by this LPM: stays L1");
    eline = K; idle(4); eline = J; idle(1);
    chk(lstate === RSM, "host K: RESUME");
    idle(13);
    chk(lstate === RSM, "L1 resume with BESL 5: 14 clocks");
    idle(1);
    chk(lstate === L0, "L0 after 4 + 2 * BESL clocks");

    // ------------------------------------------------ 7. L2 remote wake needs the feature
    idle(24);
    chk(lstate === L2 && l2_cnt === 8'd2, "idle: L2 again");
    dev_rwake = 1'b1; idle(2); dev_rwake = 1'b0;
    chk(lstate === L2, "remote wake not enabled: stays L2");
    rwake_feat = 1'b1;
    dev_rwake = 1'b1; idle(1); dev_rwake = 1'b0;
    chk(lstate === WAKE, "DEVICE_REMOTE_WAKEUP set: RWAKE from L2");
    idle(6);
    chk(lstate === L0 && wake_cnt === 8'd2, "L0 after the wake");
    rwake_feat = 1'b0;

    // ------------------------------------------------ 8. reset from L1, FS, chirp failure
    lpm(4'd0, 1'b0);
    eline = SE0; idle(16);
    chk(lstate === RST && resets === 8'd2 && hs === 1'b0, "SE0 in L1: reset, HS cleared");
    hs_cap = 1'b0; eline = J;
    idle(8);
    chk(lstate === L0 && hs === 1'b0 && chirp_k === 1'b0, "no HS capability: L0 at FS without a chirp");
    hs_cap = 1'b1;
    eline = SE0; idle(16); eline = J;
    idle(8 + 8 + 47);
    chk(lstate === HSW, "no host chirp: still waiting after 47 clocks");
    idle(1);
    chk(lstate === L0 && hs === 1'b0 && chirp_fail === 8'd1, "48 clocks without a host chirp: L0 at FS");
    // 1-clock chirp levels do not count
    eline = SE0; idle(16); eline = J; idle(17);
    for (n = 0; n < 12; n++) begin eline = (n % 2) ? J : K; idle(1); end
    eline = J; idle(40);
    chk(lstate === L0 && hs === 1'b0 && chirp_fail === 8'd2, "1-clock K/J levels: FS");
    // reset not re-triggered while SE0 continues into RESET (re-armed by J)
    eline = SE0; idle(16);
    chk(resets === 8'd5, "reset counted");
    idle(40);
    chk(resets === 8'd5, "SE0 held: no second reset");
    eline = J; idle(70);

    // ------------------------------------------------ 9. disconnect in L0
    native_reset_hs();
    attach = 1'b0; idle(1);
    chk(lstate === DISC && hs === 1'b0 && disc_cnt === 8'd2, "disconnect in L0: DISC");
    attach = 1'b1;

    // ------------------------------------------------ 10. repeater mode
    rep_mode = 1'b1;
    eline = J; idle(4);
    chk(lstate === ATT, "repeater mode: attach");
    eline = SE0; idle(20); eline = J; idle(1);
    chk(lstate === ATT, "repeater mode: SE0 is not a reset");
    s0 = resets;
    eline = SE1; idle(1); eline = SE0; idle(1); eline = J; idle(2);
    chk(lstate === ATT, "CM.RESET not decoded before its 4-clock end gap");
    idle(1);
    chk(lstate === RST && resets === s0 + 8'd1, "CM.RESET: RESET");
    idle(16);
    host_chirp();
    chk(lstate === L0 && hs === 1'b1, "repeater: HS after the chirp");
    eline = J;
    packet();
    s0 = l2_cnt;
    cmsg(2, J); idle(1);
    chk(lstate === L2 && l2_cnt === s0 + 8'd1, "CM.SUSPEND: L2");
    eline = K; idle(6); eline = J; idle(2);
    chk(lstate === L2, "repeater mode: K does not resume");
    cmsg(3, J); idle(1);
    chk(lstate === RSM, "CM.RESUME: RESUME");
    idle(8);
    chk(lstate === L0, "L0");
    s0 = cm_bad;
    cmsg(3, J); idle(1);
    chk(lstate === L0 && cm_bad === s0 + 8'd1, "CM.RESUME in L0: bad control message");
    cmsg(6, J); idle(1);
    chk(cm_bad === s0 + 8'd2, "6 pulses: unknown control message");
    s1 = l2_cnt;
    eline = SE1; idle(3); eline = SE0; idle(1); eline = SE1; idle(2); eline = J; idle(4);
    chk(lstate === L2 && l2_cnt === s1 + 8'd1, "long SE1 pulses count once each: CM.SUSPEND");
    cmsg(3, J); idle(9);
    chk(lstate === L0, "resumed");

    // ------------------------------------------------ 11. register access
    cmsg(4, J); idle(1);
    rap(1'b0, 4'd0, 8'h00);
    chk(rap_done === 1'b1 && rap_ok === 1'b1 && rap_rdata === 8'hE2, "RAP read ID: 0xE2");
    idle(1);
    chk(rap_done === 1'b0, "RAP answer is one clock");
    cmsg(4, J); rap(1'b0, 4'd2, 8'h00);
    chk(rap_ok === 1'b1 && rap_rdata === {3'd0, 1'b1, L0}, "RAP read STATUS: {hs, L0}");
    s0 = rap_err;
    cmsg(4, J); rap(1'b1, 4'd0, 8'h55);
    chk(rap_done === 1'b1 && rap_ok === 1'b0 && rap_err === s0 + 8'd1, "write to the read-only ID: rejected");
    cmsg(4, J); rap(1'b1, 4'd2, 8'h55);
    chk(rap_ok === 1'b0 && rap_err === s0 + 8'd2, "write to STATUS: rejected");
    cmsg(4, J); rap(1'b0, 4'd9, 8'h00);
    chk(rap_ok === 1'b0 && rap_err === s0 + 8'd3, "address 9: rejected");
    cmsg(4, J); rap(1'b1, 4'd3, 8'hA5);
    cmsg(4, J); rap(1'b0, 4'd3, 8'h00);
    chk(rap_ok === 1'b1 && rap_rdata === 8'hA5, "scratch register write / read");
    cmsg(4, J); rap(1'b1, 4'd6, 8'hFF);
    cmsg(4, J); rap(1'b0, 4'd6, 8'h00);
    chk(rap_rdata === 8'h3F, "tuning register keeps 6 bits");
    cmsg(4, J); idle(8); rap(1'b0, 4'd0, 8'h00);
    chk(rap_done === 1'b0, "access 8 clocks after CM.RAP: dropped");
    rap(1'b0, 4'd0, 8'h00);
    chk(rap_done === 1'b0, "access without CM.RAP: ignored");
    // CTRL: LPM disabled -> STALL
    cmsg(4, J); rap(1'b1, 4'd1, 8'hF8);
    chk(ctrl === 8'h00, "CTRL write keeps 3 bits");
    s0 = lpm_stall;
    lpm(4'd2, 1'b0);
    chk(lpm_valid === 1'b1 && lpm_resp === 2'd3 && lpm_stall === s0 + 8'd1 && lstate === L0, "LPM disabled: STALL");
    // CTRL.rwake_en enables L2 remote wake
    cmsg(4, J); rap(1'b1, 4'd1, 8'h03);
    chk(ctrl === 8'h03, "CTRL = lpm_en | rwake_en");
    cmsg(2, J); idle(1);
    dev_rwake = 1'b1; idle(1); dev_rwake = 1'b0;
    chk(lstate === WAKE, "CTRL.rwake_en: remote wake from L2");
    idle(6);
    // L1 then CM.RESUME with BESL 0
    lpm(4'd0, 1'b0);
    chk(lstate === L1, "LPM ACK: L1");
    cmsg(3, J); idle(1);
    chk(lstate === RSM, "CM.RESUME from L1");
    idle(4);
    chk(lstate === L0, "BESL 0: 4 clocks");
    // CTRL.hs_dis -> FS after CM.RESET
    cmsg(4, J); rap(1'b1, 4'd1, 8'h05);
    cmsg(1, J);
    chk(lstate === RST, "CM.RESET");
    s0 = cm_bad;
    cmsg(2, J);
    chk(lstate === RST && cm_bad === s0 + 8'd1, "CM.SUSPEND during RESET: bad control message");
    idle(4);
    chk(lstate === L0 && hs === 1'b0, "CTRL.hs_dis: L0 at FS without a chirp");
    // reset from L1 by CM.RESET
    lpm(4'd1, 1'b0);
    cmsg(1, J); idle(1);
    chk(lstate === RST, "CM.RESET from L1");
    idle(8);
    cmsg(4, J); rap(1'b0, 4'd1, 8'h00);
    chk(rap_rdata === 8'h05, "registers survive a bus reset");

    // ------------------------------------------------ 12. rst_n
    rst_n = 1'b0; idle(1); rst_n = 1'b1; idle(1);
    chk(lstate === DISC && ctrl === 8'h01 && resets === 8'd0 && rap_err === 8'd0 && cm_bad === 8'd0,
        "rst_n clears everything");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
