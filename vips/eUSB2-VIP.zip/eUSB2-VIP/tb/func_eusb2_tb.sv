// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_eusb2_tb.sv -- self-checking functional test for the eUSB2 link
// mode-control model (tb/eusb2_smoke_model.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py eUSB2-VIP
//
// Model contract (from tb/eusb2_smoke_model.sv); linestate 00 SE0, 01 J, 10 K:
//   * out of reset: non-driving, FS transceiver and termination. IDLE drives
//     normal op_mode with the LS or FS transceiver per speed_req.
//   * bus reset (bus_reset_req with SE0) from IDLE, HS or SUSPEND; on release
//     LS/FS go back to IDLE, HS starts the chirp: device chirp K
//     (chirp_active), then host K/J chirps; six K/J changes after the first
//     host chirp select HS (HS transceiver, HS termination, hs_mode). No host
//     chirp, or no lock, within 256 clocks falls back to FS.
//   * suspend_req from IDLE or HS suspends (non-driving); resume_req or K
//     resumes to the state it left.
//   * link_state follows the internal state one clock later.
// Known deviation (XFAIL): USB 2.0 7.1.7.5 lets the device enter HS after
// detecting K-J-K-J-K-J from the host; the model counts changes after the
// first host K and needs a seventh chirp.

module func_eusb2_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam logic [1:0] SE0 = 2'b00, J = 2'b01, K = 2'b10;
  localparam logic [1:0] LS = 0, FS = 1, HS = 2;
  localparam logic [2:0] S_IDLE = 0, S_RESET = 1, S_CHK = 2, S_CHKJ = 3, S_HS = 4, S_SUSP = 5;
  int checks = 0, fails = 0, xfails = 0;

  logic       clk = 1'b0, rst_n = 1'b0, breset = 1'b0, susp = 1'b0, resume = 1'b0;
  logic [1:0] ls = J, spd = FS;
  wire  [2:0] lstate;
  wire  [1:0] op_mode, xcvr;
  wire        term, hs_mode, chirp, suspended;
  wire  [7:0] ccount;

  always #5 clk = ~clk;

  eusb2_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .linestate(ls), .speed_req(spd), .bus_reset_req(breset),
    .suspend_req(susp), .resume_req(resume), .link_state(lstate), .op_mode(op_mode),
    .xcvr_sel(xcvr), .term_select(term), .hs_mode(hs_mode), .chirp_active(chirp),
    .suspended(suspended), .chirp_count(ccount)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  task automatic idle(input int n); repeat (n) @(negedge clk); endtask

  task automatic bus_reset(input int len = 5);
    @(negedge clk); ls = SE0; breset = 1;
    idle(len);
    breset = 0;
    idle(3);
  endtask

  // host chirps: n alternating K/J, each held 'w' clocks, then SE0
  task automatic host_chirps(input int n, input int w = 3);
    for (int i = 0; i < n; i++) begin
      ls = (i % 2 == 0) ? K : J;
      idle(w);
    end
    ls = SE0;
    idle(3);
  endtask

  initial begin
    idle(2);
    chk(op_mode == 2'b01 && xcvr == 2'b01 && term && !hs_mode, "reset: non-driving, FS transceiver and termination");
    rst_n = 1;
    idle(3);
    chk(lstate == S_IDLE && op_mode == 2'b00 && xcvr == 2'b01, "attached FS idle: normal mode, FS transceiver");
    spd = LS; idle(2);
    chk(xcvr == 2'b10, "LS requested: LS transceiver");
    spd = FS; idle(2);

    // bus reset at FS
    @(negedge clk); breset = 1; ls = J; idle(3);
    chk(lstate == S_IDLE, "reset request without SE0 is ignored");
    bus_reset();
    chk(lstate == S_IDLE && !chirp && !hs_mode, "FS bus reset returns to idle without chirp");
    ls = J;

    // HS chirp handshake with the minimum K-J-K-J-K-J
    spd = HS;
    @(negedge clk); ls = SE0; breset = 1; idle(3);
    chk(lstate == S_RESET, "SE0 bus reset");
    breset = 0; idle(3);
    chk(lstate == S_CHK && chirp, "HS device answers the reset with chirp K");
    host_chirps(6);
    chk_xfail(hs_mode, "HS selected after host K-J-K-J-K-J");
    chk(lstate == S_CHKJ && ccount == 5, "model counted five changes after the first host chirp");
    ls = K; idle(3); ls = SE0; idle(3);
    chk(hs_mode && lstate == S_HS && !chirp, "HS selected after a seventh host chirp");
    chk(xcvr == 2'b00 && !term && op_mode == 2'b00, "HS transceiver and HS termination");

    // a K/J level held for several clocks counts once
    bus_reset();
    chk(lstate == S_CHK && !hs_mode, "bus reset from HS restarts the chirp");
    host_chirps(4, 8);
    chk(ccount == 3, "each host chirp counts once regardless of its length");
    idle(260);
    chk(lstate == S_IDLE && !hs_mode && !chirp && term, "incomplete chirp times out to FS");

    // no host chirp at all
    bus_reset();
    chk(lstate == S_CHK, "chirp K after reset");
    idle(250);
    chk(lstate == S_CHK, "device still chirping after 250 clocks");
    idle(10);
    chk(lstate == S_IDLE && !hs_mode, "no host chirp: FS fallback");

    // suspend / resume in HS
    bus_reset();
    host_chirps(7);
    chk(hs_mode, "HS again");
    @(negedge clk); susp = 1; @(negedge clk); susp = 0; ls = J;
    idle(2);
    chk(suspended && op_mode == 2'b01 && lstate == S_SUSP, "suspend in HS: non-driving");
    idle(20);
    chk(suspended, "stays suspended on idle J");
    @(negedge clk); ls = K; @(negedge clk); ls = SE0;
    idle(2);
    chk(!suspended && lstate == S_HS && hs_mode && op_mode == 2'b00, "K resume returns to HS");

    // suspend / resume at FS via resume_req
    spd = FS;
    bus_reset();
    ls = J;
    @(negedge clk); susp = 1; @(negedge clk); susp = 0;
    idle(2);
    chk(suspended && lstate == S_SUSP, "suspend at FS");
    @(negedge clk); resume = 1; @(negedge clk); resume = 0;
    idle(2);
    chk(!suspended && lstate == S_IDLE && !hs_mode, "resume_req returns to FS idle");

    // reset during suspend
    @(negedge clk); susp = 1; @(negedge clk); susp = 0;
    idle(2);
    bus_reset();
    chk(!suspended && lstate == S_IDLE, "bus reset wakes a suspended link");

    // power-on reset
    spd = HS; bus_reset(); host_chirps(7);
    @(negedge clk); rst_n = 0;
    @(negedge clk); rst_n = 1;
    chk(!hs_mode && !chirp && !suspended && ccount == 0 && op_mode == 2'b01 && term,
        "reset returns to non-driving FS");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
