// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Smoke-target minimal behavioral model: eUSB2 link mode control FSM.
// Handles bus reset (SE0), LS/FS/HS speed selection, the HS chirp
// handshake (device chirp K then host K/J alternation), suspend/resume,
// and drives UTMI-style op_mode/xcvr_select/term_select outputs. Plain
// ANSI ports only (no interfaces) so the L1b smoke harness can build it
// directly with iverilog.

module eusb2_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [1:0]  linestate,      // 00=SE0 01=J 10=K 11=SE1
  input  logic [1:0]  speed_req,      // 0=LS 1=FS 2=HS requested speed
  input  logic        bus_reset_req,  // host driving SE0 bus reset
  input  logic        suspend_req,    // host requests suspend (idle)
  input  logic        resume_req,     // resume signaling detected
  output logic [2:0]  link_state,     // FSM state (observability)
  output logic [1:0]  op_mode,        // 00=normal 01=non-driving 10=bitstuff
  output logic [1:0]  xcvr_sel,       // 00=HS 01=FS 10=LS
  output logic        term_select,    // 1=FS termination, 0=HS termination
  output logic        hs_mode,        // link operating at High Speed
  output logic        chirp_active,   // HS chirp handshake in progress
  output logic        suspended,      // link suspended
  output logic [7:0]  chirp_count     // host chirp K/J alternations seen
);

  localparam logic [1:0] LS_SE0 = 2'b00;
  localparam logic [1:0] LS_J   = 2'b01;
  localparam logic [1:0] LS_K   = 2'b10;

  localparam logic [1:0] SPD_LS = 2'd0;
  localparam logic [1:0] SPD_FS = 2'd1;
  localparam logic [1:0] SPD_HS = 2'd2;

  localparam logic [2:0] ST_IDLE     = 3'd0;   // FS/LS idle (J)
  localparam logic [2:0] ST_RESET    = 3'd1;   // SE0 bus reset
  localparam logic [2:0] ST_CHIRP_K  = 3'd2;   // device chirp K
  localparam logic [2:0] ST_CHIRP_KJ = 3'd3;   // host chirp K/J sequence
  localparam logic [2:0] ST_HS       = 3'd4;   // High-Speed operation
  localparam logic [2:0] ST_SUSPEND  = 3'd5;

  logic [2:0] state;
  logic [7:0] tmo;
  logic [1:0] prev_ls;
  logic [2:0] resume_state;   // state to return to after resume

  always @(posedge clk) begin
    if (!rst_n) begin
      state        <= ST_IDLE;
      tmo          <= 8'd0;
      prev_ls      <= LS_SE0;
      resume_state <= ST_IDLE;
      link_state   <= ST_IDLE;
      op_mode      <= 2'b01;    // non-driving until attached
      xcvr_sel     <= 2'b01;    // FS transceiver
      term_select  <= 1'b1;     // FS termination
      hs_mode      <= 1'b0;
      chirp_active <= 1'b0;
      suspended    <= 1'b0;
      chirp_count  <= 8'd0;
    end else begin
      link_state <= state;
      prev_ls    <= linestate;
      tmo        <= tmo + 8'd1;
      case (state)
        // ---- IDLE: attached, FS/LS J state, wait for bus reset ----
        ST_IDLE: begin
          op_mode      <= 2'b00;
          xcvr_sel     <= (speed_req == SPD_LS) ? 2'b10 : 2'b01;
          term_select  <= 1'b1;
          hs_mode      <= 1'b0;
          chirp_active <= 1'b0;
          if (bus_reset_req && (linestate == LS_SE0)) begin
            state <= ST_RESET;
            tmo   <= 8'd0;
          end else if (suspend_req) begin
            resume_state <= ST_IDLE;
            state        <= ST_SUSPEND;
            tmo          <= 8'd0;
          end
        end

        // ---- RESET: SE0 held; on release branch by requested speed ----
        ST_RESET: begin
          op_mode     <= 2'b00;
          xcvr_sel    <= 2'b01;          // FS during chirp negotiation
          term_select <= 1'b1;
          if (!bus_reset_req) begin
            if (speed_req == SPD_HS) begin
              state        <= ST_CHIRP_K;  // device answers with chirp K
              chirp_active <= 1'b1;
              chirp_count  <= 8'd0;
            end else begin
              state <= ST_IDLE;            // LS/FS: straight to idle J
            end
            tmo <= 8'd0;
          end
        end

        // ---- CHIRP_K: device drives K while host is silent (SE0) ----
        ST_CHIRP_K: begin
          chirp_active <= 1'b1;
          if (linestate == LS_K || linestate == LS_J) begin
            state <= ST_CHIRP_KJ;         // host chirp burst started
            tmo   <= 8'd0;
          end else if (tmo == 8'hFF) begin
            state <= ST_IDLE;             // no host chirp: stay FS
            tmo   <= 8'd0;
          end
        end

        // ---- CHIRP_KJ: count host K/J alternations, >=6 locks HS ----
        ST_CHIRP_KJ: begin
          chirp_active <= 1'b1;
          if ((linestate == LS_K || linestate == LS_J) &&
              (linestate != prev_ls) &&
              (chirp_count != 8'hFF))
            chirp_count <= chirp_count + 8'd1;
          if (chirp_count >= 8'd6) begin
            state        <= ST_HS;        // chirp handshake complete
            hs_mode      <= 1'b1;
            chirp_active <= 1'b0;
            xcvr_sel     <= 2'b00;        // HS transceiver
            term_select  <= 1'b0;         // HS termination
            op_mode      <= 2'b00;
            tmo          <= 8'd0;
          end else if (tmo == 8'hFF) begin
            state        <= ST_IDLE;      // chirp failed: FS fallback
            chirp_active <= 1'b0;
            tmo          <= 8'd0;
          end
        end

        // ---- HS: High-Speed operation, suspend / reset exit ----
        ST_HS: begin
          hs_mode     <= 1'b1;
          xcvr_sel    <= 2'b00;
          term_select <= 1'b0;
          if (bus_reset_req && (linestate == LS_SE0)) begin
            state   <= ST_RESET;
            hs_mode <= 1'b0;
            tmo     <= 8'd0;
          end else if (suspend_req) begin
            resume_state <= ST_HS;
            state        <= ST_SUSPEND;
            tmo          <= 8'd0;
          end
        end

        // ---- SUSPEND: non-driving, wake on resume or reset ----
        ST_SUSPEND: begin
          suspended <= 1'b1;
          op_mode   <= 2'b01;             // non-driving
          if (resume_req || (linestate == LS_K)) begin
            state     <= resume_state;    // resume to FS idle or HS
            suspended <= 1'b0;
            op_mode   <= 2'b00;
            tmo       <= 8'd0;
          end else if (bus_reset_req && (linestate == LS_SE0)) begin
            state     <= ST_RESET;
            suspended <= 1'b0;
            hs_mode   <= 1'b0;
            tmo       <= 8'd0;
          end
        end

        default: state <= ST_IDLE;
      endcase
    end
  end

endmodule
