// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eUSB2 peripheral port link controller (eUSB2 1.1, timers scaled to
// clocks), native mode or behind an eUSB2 repeater. One bus level per clock
// on eD+/eD- plus packet-level events from the USB 2.0 protocol layer.
// Plain ANSI ports so the L1b smoke harness and tb/smoke_func_tb.sv build it
// directly.
//
// Bus levels: 0 SE0, 1 J, 2 K, 3 SE1.
// Control messages (repeater mode only): the host port sends SE1 pulses; a
//   message ends 4 clocks after the last pulse and is decoded by its pulse
//   count (simplified encoding): 1 CM.RESET, 2 CM.SUSPEND (L2), 3 CM.RESUME,
//   4 CM.RAP (register access). Any other count, or a message that does not
//   apply in the current state, is counted in cm_bad. In native mode SE1 is
//   not a control message and is ignored.
// Link states (lstate): 0 DISC, 1 ATTACHED, 2 RESET, 3 CHIRP, 4 HS_WAIT,
//   5 L0, 6 L1, 7 L2, 8 RESUME, 9 RWAKE.
//   DISC -> ATTACHED: attach high and J for 4 clocks. attach low in any
//   state -> DISC (disc_cnt when it was connected).
//   Native mode idles at J. Reset: native mode SE0 for 16 clocks (re-armed by a non-SE0 level),
//   repeater mode CM.RESET; from ATTACHED / L0 / L1 / L2. RESET lasts 8
//   clocks; then, with hs_cap and HS not disabled (CTRL.hs_dis), the device
//   chirps K for 8 clocks (CHIRP) and waits up to 48 clocks (HS_WAIT) for 3
//   host K-J pairs, each level >= 2 clocks -> L0 at HS; else L0 at FS
//   (chirp_fail when the chirp went unanswered).
//   L0: 24 clocks without a packet (or, in repeater mode, an SE1 pulse) -> L2;
//   repeater mode CM.SUSPEND -> L2.
//   LPM (lpm_req, from an EXT + LPM token in L0): CTRL.lpm_en clear ->
//   STALL (lpm_stall); busy -> NYET (lpm_nyet); else ACK and L1 with the
//   token's BESL and remote-wake bit (l1_cnt).
//   L1 / L2 exit by the host: native mode K for >= 4 clocks, repeater mode
//   CM.RESUME -> RESUME, which lasts 4 + 2 * BESL clocks after L1 and 8
//   clocks after L2 -> L0. Remote wake: dev_rwake in L1 with the LPM
//   remote-wake bit, or in L2 with remote wake enabled (rwake_feat or
//   CTRL.rwake_en) -> RWAKE: the device drives K (rwake_k) for 6 clocks,
//   then L0 (wake_cnt). A reset from L1 / L2 is taken as above.
// Register access (repeater mode, CM.RAP): one rap_valid within 8 clocks;
//   answered the next clock by rap_done with rap_ok and rap_rdata.
//   0 ID 0xE2 (RO), 1 CTRL {hs_dis[2], rwake_en[1], lpm_en[0]} (reset 0x01),
//   2 STATUS {hs, lstate} (RO), 3 scratch, 4..7 tuning (6 bits). A write to
//   a read-only register or an address >= 8 -> rap_ok = 0 (rap_err). No
//   access within the window: the RAP is dropped.

module eusb2_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rep_mode,
  input  logic        attach,
  input  logic        hs_cap,
  input  logic [1:0]  eline,         // 0 SE0 1 J 2 K 3 SE1
  input  logic        pkt,           // a packet on the bus this clock
  input  logic        lpm_req,
  input  logic [3:0]  lpm_besl,
  input  logic        lpm_rw,
  input  logic        busy,
  input  logic        dev_rwake,
  input  logic        rwake_feat,
  input  logic        rap_valid,
  input  logic        rap_wr,
  input  logic [3:0]  rap_addr,
  input  logic [7:0]  rap_wdata,
  output logic [3:0]  lstate,
  output logic        hs,
  output logic        chirp_k,
  output logic        rwake_k,
  output logic        lpm_valid,
  output logic [1:0]  lpm_resp,      // 1 ACK 2 NYET 3 STALL
  output logic        rap_done,
  output logic        rap_ok,
  output logic [7:0]  rap_rdata,
  output logic [7:0]  ctrl,
  output logic [7:0]  resets,
  output logic [7:0]  l1_cnt,
  output logic [7:0]  l2_cnt,
  output logic [7:0]  wake_cnt,
  output logic [7:0]  lpm_nyet,
  output logic [7:0]  lpm_stall,
  output logic [7:0]  cm_bad,
  output logic [7:0]  rap_err,
  output logic [7:0]  disc_cnt,
  output logic [7:0]  chirp_fail
);
  localparam logic [1:0] B_SE0 = 2'd0, B_J = 2'd1, B_K = 2'd2, B_SE1 = 2'd3;
  localparam logic [3:0] S_DISC = 4'd0, S_ATT = 4'd1, S_RESET = 4'd2, S_CHIRP = 4'd3, S_HSW = 4'd4,
                         S_L0 = 4'd5, S_L1 = 4'd6, S_L2 = 4'd7, S_RSM = 4'd8, S_WAKE = 4'd9;
  localparam int T_CONN = 4, T_RST = 16, T_RSTLEN = 8, T_CHIRP = 8, T_HSW = 48, T_IDLE = 24,
                 T_RESUME = 4, T_L2RSM = 8, T_WAKE = 6, T_CMEND = 4, T_RAP = 8;

  // working copies of the outputs (blocking inside the clock), registered below
  logic [3:0]  w_ls;
  logic        w_hs, w_ck, w_rk, w_lv, w_rd, w_rok;
  logic [1:0]  w_lr;
  logic [7:0]  w_rdat;
  logic [7:0]  n_rst, n_l1, n_l2, n_wake, n_nyet, n_stall, n_cmb, n_rerr, n_disc, n_cf;
  // state
  logic [7:0]  regs [8];
  logic [6:0]  tmr;
  logic [4:0]  se0_cnt;
  logic        se0_armed;
  logic [2:0]  j_cnt;
  logic [2:0]  k_cnt;
  logic [1:0]  ch_lvl;
  logic [5:0]  ch_len;
  logic [2:0]  ch_n;
  logic [2:0]  cm_n;
  logic [2:0]  cm_gap;
  logic [1:0]  prev_b;
  logic [3:0]  besl;
  logic        l1_rw;
  logic        from_l1;
  logic        rap_win;
  logic [3:0]  rap_t;
  logic [2:0]  cm;
  logic        rst_now, rsm_now;
  logic [7:0]  rv;

  task automatic go_reset();
    w_ls = S_RESET; tmr = 7'd0; w_hs = 1'b0; n_rst = n_rst + 8'd1; se0_cnt = 5'd0; se0_armed = 1'b0;
    rap_win = 1'b0; cm_n = 3'd0; cm_gap = 3'd0;
  endtask

  task automatic go_resume(input logic l1);
    from_l1 = l1; w_ls = S_RSM; tmr = 7'd0; k_cnt = 3'd0;
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      w_ls = S_DISC; w_hs = 1'b0; w_ck = 1'b0; w_rk = 1'b0; w_lv = 1'b0; w_lr = 2'd0; w_rd = 1'b0;
      w_rok = 1'b0; w_rdat = 8'h00;
      n_rst = 8'd0; n_l1 = 8'd0; n_l2 = 8'd0; n_wake = 8'd0; n_nyet = 8'd0; n_stall = 8'd0; n_cmb = 8'd0;
      n_rerr = 8'd0; n_disc = 8'd0; n_cf = 8'd0;
      regs[0] = 8'hE2; regs[1] = 8'h01; regs[3] = 8'h00;
      for (int i = 4; i < 8; i++) regs[i] = 8'h00;
      tmr = 7'd0; se0_cnt = 5'd0; se0_armed = 1'b1; j_cnt = 3'd0; k_cnt = 3'd0;
      ch_lvl = B_SE0; ch_len = 6'd0; ch_n = 3'd0; cm_n = 3'd0; cm_gap = 3'd0; prev_b = B_SE0;
      besl = 4'd0; l1_rw = 1'b0; from_l1 = 1'b0; rap_win = 1'b0; rap_t = 4'd0;
    end else begin
      w_ck = 1'b0; w_rk = 1'b0; w_lv = 1'b0; w_lr = 2'd0; w_rd = 1'b0; w_rok = 1'b0; w_rdat = 8'h00;
      cm = 3'd0;

      // ---------------------------------------- control messages (repeater mode)
      if (rep_mode && w_ls != S_DISC) begin
        if (eline == B_SE1) begin
          if (prev_b != B_SE1 && cm_n != 3'd7) cm_n = cm_n + 3'd1;
          cm_gap = 3'd0;
        end else if (cm_n != 3'd0) begin
          cm_gap = cm_gap + 3'd1;
          if (cm_gap == 3'(T_CMEND)) begin cm = cm_n; cm_n = 3'd0; cm_gap = 3'd0; end
        end
      end else begin
        cm_n = 3'd0; cm_gap = 3'd0;
      end
      prev_b = eline;

      // ---------------------------------------- register access window
      if (rap_win) begin
        if (rap_valid) begin
          rap_win = 1'b0; w_rd = 1'b1;
          if (rap_addr > 4'd7 || (rap_wr && (rap_addr == 4'd0 || rap_addr == 4'd2))) begin
            w_rok = 1'b0; n_rerr = n_rerr + 8'd1;
          end else if (rap_wr) begin
            w_rok = 1'b1;
            case (rap_addr)
              4'd1: regs[1] = {5'd0, rap_wdata[2:0]};
              4'd3: regs[3] = rap_wdata;
              default: regs[rap_addr[2:0]] = {2'b00, rap_wdata[5:0]};
            endcase
          end else begin
            w_rok = 1'b1;
            rv = regs[rap_addr[2:0]];
            if (rap_addr == 4'd2) rv = {3'd0, w_hs, w_ls};
            w_rdat = rv;
          end
        end else begin
          rap_t = rap_t + 4'd1;
          if (rap_t == 4'(T_RAP)) rap_win = 1'b0;
        end
      end

      // ---------------------------------------- native-mode SE0 reset / K resume
      rst_now = 1'b0; rsm_now = 1'b0;
      if (!rep_mode && (w_ls == S_ATT || w_ls == S_L0 || w_ls == S_L1 || w_ls == S_L2)) begin
        if (eline == B_SE0 && !pkt) begin
          if (se0_cnt != 5'd31) se0_cnt = se0_cnt + 5'd1;
        end else se0_cnt = 5'd0;
        if (se0_cnt == 5'(T_RST) && se0_armed) rst_now = 1'b1;
        if (w_ls == S_L1 || w_ls == S_L2) begin
          if (eline == B_K) begin
            if (k_cnt != 3'd7) k_cnt = k_cnt + 3'd1;
          end else begin
            if (k_cnt >= 3'(T_RESUME)) rsm_now = 1'b1;
            k_cnt = 3'd0;
          end
        end else k_cnt = 3'd0;
      end else begin
        se0_cnt = 5'd0; k_cnt = 3'd0;
      end

      if (eline != B_SE0) se0_armed = 1'b1;

      // ---------------------------------------- link state
      if (!attach) begin
        if (w_ls != S_DISC) n_disc = n_disc + 8'd1;
        w_ls = S_DISC; w_hs = 1'b0; j_cnt = 3'd0; rap_win = 1'b0; cm_n = 3'd0; cm_gap = 3'd0;
        se0_armed = 1'b1;
      end else begin
        // control message dispatch
        if (cm != 3'd0) begin
          if (cm == 3'd1 && (w_ls == S_ATT || w_ls == S_L0 || w_ls == S_L1 || w_ls == S_L2)) rst_now = 1'b1;
          else if (cm == 3'd2 && w_ls == S_L0) begin w_ls = S_L2; n_l2 = n_l2 + 8'd1; tmr = 7'd0; end
          else if (cm == 3'd3 && (w_ls == S_L1 || w_ls == S_L2)) rsm_now = 1'b1;
          else if (cm == 3'd4 && w_ls != S_RESET && w_ls != S_CHIRP && w_ls != S_HSW) begin
            rap_win = 1'b1; rap_t = 4'd0;
          end else n_cmb = n_cmb + 8'd1;
        end

        if (rst_now) go_reset();
        else case (w_ls)
          S_DISC: begin
            if (eline == B_J) begin
              j_cnt = j_cnt + 3'd1;
              if (j_cnt == 3'(T_CONN)) begin w_ls = S_ATT; j_cnt = 3'd0; end
            end else j_cnt = 3'd0;
          end
          S_RESET: begin
            tmr = tmr + 7'd1;
            if (tmr == 7'(T_RSTLEN)) begin
              tmr = 7'd0;
              if (hs_cap && !regs[1][2]) w_ls = S_CHIRP;
              else w_ls = S_L0;
            end
          end
          S_CHIRP: begin
            w_ck = 1'b1; tmr = tmr + 7'd1;
            if (tmr == 7'(T_CHIRP)) begin
              w_ls = S_HSW; tmr = 7'd0; ch_lvl = B_SE0; ch_len = 6'd0; ch_n = 3'd0;
            end
          end
          S_HSW: begin
            tmr = tmr + 7'd1;
            if (eline == ch_lvl) begin
              if (ch_len != 6'd63) ch_len = ch_len + 6'd1;
            end else begin ch_lvl = eline; ch_len = 6'd1; end
            if (ch_len == 6'd2 && eline == (ch_n[0] ? B_J : B_K)) ch_n = ch_n + 3'd1;
            if (ch_n == 3'd6) begin w_ls = S_L0; w_hs = 1'b1; tmr = 7'd0; end
            else if (tmr == 7'(T_HSW)) begin w_ls = S_L0; tmr = 7'd0; n_cf = n_cf + 8'd1; end
          end
          S_L0: begin
            if (lpm_req) begin
              w_lv = 1'b1;
              if (!regs[1][0]) begin w_lr = 2'd3; n_stall = n_stall + 8'd1; end
              else if (busy) begin w_lr = 2'd2; n_nyet = n_nyet + 8'd1; end
              else begin
                w_lr = 2'd1; w_ls = S_L1; besl = lpm_besl; l1_rw = lpm_rw; n_l1 = n_l1 + 8'd1; tmr = 7'd0;
              end
            end
            if (w_ls == S_L0) begin
              if (pkt || lpm_req || (rep_mode && eline == B_SE1)) tmr = 7'd0;
              else begin
                tmr = tmr + 7'd1;
                if (tmr == 7'(T_IDLE)) begin w_ls = S_L2; n_l2 = n_l2 + 8'd1; tmr = 7'd0; end
              end
            end
          end
          S_L1: begin
            if (rsm_now) go_resume(1'b1);
            else if (dev_rwake && l1_rw) begin w_ls = S_WAKE; tmr = 7'd0; end
          end
          S_L2: begin
            if (rsm_now) go_resume(1'b0);
            else if (dev_rwake && (rwake_feat || regs[1][1])) begin w_ls = S_WAKE; tmr = 7'd0; end
          end
          S_RSM: begin
            tmr = tmr + 7'd1;
            if (tmr == (from_l1 ? 7'(T_RESUME) + {2'b00, besl, 1'b0} : 7'(T_L2RSM))) begin
              w_ls = S_L0; tmr = 7'd0;
            end
          end
          S_WAKE: begin
            w_rk = 1'b1; tmr = tmr + 7'd1;
            if (tmr == 7'(T_WAKE)) begin w_ls = S_L0; tmr = 7'd0; n_wake = n_wake + 8'd1; end
          end
          default: ;
        endcase
      end
    end

    lstate <= w_ls; hs <= w_hs; chirp_k <= w_ck; rwake_k <= w_rk; lpm_valid <= w_lv; lpm_resp <= w_lr;
    rap_done <= w_rd; rap_ok <= w_rok; rap_rdata <= w_rdat; ctrl <= regs[1];
    resets <= n_rst; l1_cnt <= n_l1; l2_cnt <= n_l2; wake_cnt <= n_wake; lpm_nyet <= n_nyet;
    lpm_stall <= n_stall; cm_bad <= n_cmb; rap_err <= n_rerr; disc_cnt <= n_disc; chirp_fail <= n_cf;
  end

endmodule
