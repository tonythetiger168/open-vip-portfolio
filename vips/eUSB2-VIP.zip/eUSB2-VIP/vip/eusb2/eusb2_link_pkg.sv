// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eUSB2 UVM agent (host port side) for a peripheral port on eusb2_link_if:
//   eusb2_item / eusb2_driver  a bus level held for n clocks, a packet, an
//                              LPM token, a register access, idle clocks, a
//                              device remote-wake request or a static input
//                              (mode, attach, HS capability, busy, remote
//                              wake feature)
//   eusb2_monitor              both directions every clock, link state
//                              before and after the edge
//   eusb2_scoreboard           predicts the port clock by clock: attach /
//                              disconnect, native SE0 reset, control-message
//                              decoding (CM.RESET / SUSPEND / RESUME / RAP),
//                              HS chirp or FS fallback, L0 idle -> L2, LPM
//                              ACK / NYET / STALL -> L1, BESL-timed resume,
//                              remote wake from L1 / L2, every register access
//                              answer and all 10 counters
//   eusb2_coverage             link transitions per mode, LPM answers,
//                              register accesses, events
//   sequences + eusb2_env + eusb2_link_test
`ifndef EUSB2_LINK_PKG_SV
`define EUSB2_LINK_PKG_SV

package eusb2_link_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [1:0] B_SE0 = 2'd0, B_J = 2'd1, B_K = 2'd2, B_SE1 = 2'd3;
  localparam logic [3:0] S_DISC = 4'd0, S_ATT = 4'd1, S_RESET = 4'd2, S_CHIRP = 4'd3, S_HSW = 4'd4,
                         S_L0 = 4'd5, S_L1 = 4'd6, S_L2 = 4'd7, S_RSM = 4'd8, S_WAKE = 4'd9;
  localparam int T_CONN = 4, T_RST = 16, T_RSTLEN = 8, T_CHIRP = 8, T_HSW = 48, T_IDLE = 24,
                 T_RESUME = 4, T_L2RSM = 8, T_WAKE = 6, T_CMEND = 4, T_RAP = 8;

  typedef enum int { K_LVL, K_PKT, K_LPM, K_RAP, K_IDLE, K_WAKE, K_MODE, K_ATTACH, K_CAP, K_BUSY, K_FEAT } e2_kind_e;

  // ------------------------------------------------------------ item
  class eusb2_item extends uvm_sequence_item;
    `uvm_object_utils(eusb2_item)
    e2_kind_e    kind = K_IDLE;
    logic [1:0]  lvl;
    int          n = 1;
    logic [3:0]  besl;
    bit          rw, wr, v;
    logic [3:0]  addr;
    logic [7:0]  data;
    function new(string name = "eusb2_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("%s lvl %0d n %0d", kind.name(), lvl, n);
    endfunction
  endclass

  class eusb2_obs extends uvm_object;
    `uvm_object_utils(eusb2_obs)
    bit          rep_mode, attach, hs_cap, pkt, lpm_req, lpm_rw, busy, dev_rwake, rwake_feat, rap_valid, rap_wr;
    logic [1:0]  eline;
    logic [3:0]  lpm_besl, rap_addr;
    logic [7:0]  rap_wdata;
    logic [3:0]  lstate, lstate_next;
    bit          hs, chirp_k, rwake_k, lpm_valid, rap_done, rap_ok;
    logic [1:0]  lpm_resp;
    logic [7:0]  rap_rdata, ctrl;
    logic [7:0]  cnt [10];
    function new(string name = "eusb2_obs"); super.new(name); endfunction
  endclass

  typedef uvm_sequencer #(eusb2_item) eusb2_sequencer;

  // ------------------------------------------------------------ driver
  class eusb2_driver extends uvm_driver #(eusb2_item);
    `uvm_component_utils(eusb2_driver)
    virtual eusb2_link_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual eusb2_link_if)::get(this, "", "eusb2l_vif", vif))
        `uvm_fatal("NOVIF", "eusb2l_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      eusb2_item t;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(t);
        drive(t);
        seq_item_port.item_done();
      end
    endtask
    task drive(eusb2_item t);
      case (t.kind)
        K_MODE:   begin vif.rep_mode = t.v; return; end
        K_ATTACH: begin vif.attach = t.v; return; end
        K_CAP:    begin vif.hs_cap = t.v; return; end
        K_BUSY:   begin vif.busy = t.v; return; end
        K_FEAT:   begin vif.rwake_feat = t.v; return; end
        default: ;
      endcase
      @(negedge vif.clk);
      case (t.kind)
        K_LVL: begin vif.eline = t.lvl; repeat (t.n - 1) @(negedge vif.clk); end
        K_IDLE: repeat (t.n - 1) @(negedge vif.clk);
        K_PKT:  begin vif.pkt = 1'b1; @(posedge vif.clk); #1 vif.pkt = 1'b0; end
        K_WAKE: begin vif.dev_rwake = 1'b1; @(posedge vif.clk); #1 vif.dev_rwake = 1'b0; end
        K_LPM: begin
          vif.lpm_req = 1'b1; vif.lpm_besl = t.besl; vif.lpm_rw = t.rw;
          @(posedge vif.clk); #1 vif.lpm_req = 1'b0;
        end
        default: begin
          vif.rap_valid = 1'b1; vif.rap_wr = t.wr; vif.rap_addr = t.addr; vif.rap_wdata = t.data;
          @(posedge vif.clk); #1 vif.rap_valid = 1'b0;
        end
      endcase
    endtask
  endclass

  // ------------------------------------------------------------ monitor
  class eusb2_monitor extends uvm_monitor;
    `uvm_component_utils(eusb2_monitor)
    virtual eusb2_link_if vif;
    uvm_analysis_port #(eusb2_obs) ap;
    function new(string name, uvm_component parent); super.new(name, parent); ap = new("ap", this); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual eusb2_link_if)::get(this, "", "eusb2l_vif", vif))
        `uvm_fatal("NOVIF", "eusb2l_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      eusb2_obs o;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n !== 1'b1) continue;
        o = eusb2_obs::type_id::create("o");
        o.rep_mode = vif.rep_mode; o.attach = vif.attach; o.hs_cap = vif.hs_cap; o.eline = vif.eline; o.pkt = vif.pkt;
        o.lpm_req = vif.lpm_req; o.lpm_besl = vif.lpm_besl; o.lpm_rw = vif.lpm_rw; o.busy = vif.busy;
        o.dev_rwake = vif.dev_rwake; o.rwake_feat = vif.rwake_feat; o.rap_valid = vif.rap_valid; o.rap_wr = vif.rap_wr;
        o.rap_addr = vif.rap_addr; o.rap_wdata = vif.rap_wdata;
        o.lstate = vif.lstate; o.hs = vif.hs; o.chirp_k = vif.chirp_k; o.rwake_k = vif.rwake_k;
        o.lpm_valid = vif.lpm_valid; o.lpm_resp = vif.lpm_resp; o.rap_done = vif.rap_done; o.rap_ok = vif.rap_ok;
        o.rap_rdata = vif.rap_rdata; o.ctrl = vif.ctrl;
        o.cnt = '{vif.resets, vif.l1_cnt, vif.l2_cnt, vif.wake_cnt, vif.lpm_nyet, vif.lpm_stall, vif.cm_bad,
                  vif.rap_err, vif.disc_cnt, vif.chirp_fail};
        #1 o.lstate_next = vif.lstate;
        ap.write(o);
      end
    endtask
  endclass

  // ------------------------------------------------------------ scoreboard
  class eusb2_scoreboard extends uvm_subscriber #(eusb2_obs);
    `uvm_component_utils(eusb2_scoreboard)
    int unsigned cyc, errors, n_checks, n_cm, n_rap, n_lpm, n_l1, n_l2, n_hs, n_wake, n_rsm;
    // predicted outputs
    logic [3:0]  ls;
    bit          hs, ck, rk, lv, rd, rok;
    logic [1:0]  lr;
    logic [7:0]  rdat;
    logic [7:0]  c [10];   // resets l1 l2 wake nyet stall cm_bad rap_err disc chirp_fail
    // predicted state
    logic [7:0]  regs [8];
    logic [6:0]  tmr;
    logic [4:0]  se0_cnt;
    bit          se0_armed, l1_rw, from_l1, rap_win;
    logic [2:0]  j_cnt, k_cnt, ch_n, cm_n, cm_gap;
    logic [1:0]  ch_lvl, prev_b;
    logic [5:0]  ch_len;
    logic [3:0]  besl, rap_t;
    string       cnt_name [10] = '{"resets", "l1_cnt", "l2_cnt", "wake_cnt", "lpm_nyet", "lpm_stall", "cm_bad",
                                   "rap_err", "disc_cnt", "chirp_fail"};

    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      ls = S_DISC; hs = 0; ck = 0; rk = 0; lv = 0; rd = 0; rok = 0; lr = 0; rdat = 0;
      foreach (c[i]) c[i] = 0;
      regs = '{8'hE2, 8'h01, 8'h00, 8'h00, 8'h00, 8'h00, 8'h00, 8'h00};
      tmr = 0; se0_cnt = 0; se0_armed = 1; l1_rw = 0; from_l1 = 0; rap_win = 0;
      j_cnt = 0; k_cnt = 0; ch_n = 0; cm_n = 0; cm_gap = 0; ch_lvl = B_SE0; prev_b = B_SE0; ch_len = 0;
      besl = 0; rap_t = 0;
    endfunction
    function void chk(bit ok, string m);
      n_checks++;
      if (!ok) begin errors++; `uvm_error("EUSB2_SB", m) end
    endfunction
    function void go_reset();
      ls = S_RESET; tmr = 0; hs = 0; c[0]++; se0_cnt = 0; se0_armed = 0; rap_win = 0; cm_n = 0; cm_gap = 0;
    endfunction
    function void go_resume(bit l1);
      from_l1 = l1; ls = S_RSM; tmr = 0; k_cnt = 0; n_rsm++;
    endfunction

    function void step(eusb2_obs o);
      logic [2:0] cm;
      bit rst_now, rsm_now;
      logic [7:0] rv;
      ck = 0; rk = 0; lv = 0; lr = 0; rd = 0; rok = 0; rdat = 0; cm = 0;
      // control messages
      if (o.rep_mode && ls != S_DISC) begin
        if (o.eline == B_SE1) begin
          if (prev_b != B_SE1 && cm_n != 7) cm_n++;
          cm_gap = 0;
        end else if (cm_n != 0) begin
          cm_gap++;
          if (cm_gap == T_CMEND) begin cm = cm_n; cm_n = 0; cm_gap = 0; n_cm++; end
        end
      end else begin cm_n = 0; cm_gap = 0; end
      prev_b = o.eline;
      // register access window
      if (rap_win) begin
        if (o.rap_valid) begin
          rap_win = 0; rd = 1; n_rap++;
          if (o.rap_addr > 7 || (o.rap_wr && (o.rap_addr == 0 || o.rap_addr == 2))) begin rok = 0; c[7]++; end
          else if (o.rap_wr) begin
            rok = 1;
            case (o.rap_addr)
              4'd1: regs[1] = {5'd0, o.rap_wdata[2:0]};
              4'd3: regs[3] = o.rap_wdata;
              default: regs[o.rap_addr[2:0]] = {2'b00, o.rap_wdata[5:0]};
            endcase
          end else begin
            rok = 1;
            rv = regs[o.rap_addr[2:0]];
            if (o.rap_addr == 2) rv = {3'd0, hs, ls};
            rdat = rv;
          end
        end else begin
          rap_t++;
          if (rap_t == T_RAP) rap_win = 0;
        end
      end
      // native-mode SE0 reset / K resume
      rst_now = 0; rsm_now = 0;
      if (!o.rep_mode && ls inside {S_ATT, S_L0, S_L1, S_L2}) begin
        if (o.eline == B_SE0 && !o.pkt) begin if (se0_cnt != 31) se0_cnt++; end
        else se0_cnt = 0;
        if (se0_cnt == T_RST && se0_armed) rst_now = 1;
        if (ls == S_L1 || ls == S_L2) begin
          if (o.eline == B_K) begin if (k_cnt != 7) k_cnt++; end
          else begin if (k_cnt >= T_RESUME) rsm_now = 1; k_cnt = 0; end
        end else k_cnt = 0;
      end else begin se0_cnt = 0; k_cnt = 0; end
      if (o.eline != B_SE0) se0_armed = 1;
      // link state
      if (!o.attach) begin
        if (ls != S_DISC) c[8]++;
        ls = S_DISC; hs = 0; j_cnt = 0; rap_win = 0; cm_n = 0; cm_gap = 0; se0_armed = 1;
      end else begin
        if (cm != 0) begin
          if (cm == 1 && ls inside {S_ATT, S_L0, S_L1, S_L2}) rst_now = 1;
          else if (cm == 2 && ls == S_L0) begin ls = S_L2; c[2]++; tmr = 0; n_l2++; end
          else if (cm == 3 && (ls == S_L1 || ls == S_L2)) rsm_now = 1;
          else if (cm == 4 && !(ls inside {S_RESET, S_CHIRP, S_HSW})) begin rap_win = 1; rap_t = 0; end
          else c[6]++;
        end
        if (rst_now) go_reset();
        else case (ls)
          S_DISC: begin
            if (o.eline == B_J) begin j_cnt++; if (j_cnt == T_CONN) begin ls = S_ATT; j_cnt = 0; end end
            else j_cnt = 0;
          end
          S_RESET: begin
            tmr++;
            if (tmr == T_RSTLEN) begin tmr = 0; ls = (o.hs_cap && !regs[1][2]) ? S_CHIRP : S_L0; end
          end
          S_CHIRP: begin
            ck = 1; tmr++;
            if (tmr == T_CHIRP) begin ls = S_HSW; tmr = 0; ch_lvl = B_SE0; ch_len = 0; ch_n = 0; end
          end
          S_HSW: begin
            tmr++;
            if (o.eline == ch_lvl) begin if (ch_len != 63) ch_len++; end
            else begin ch_lvl = o.eline; ch_len = 1; end
            if (ch_len == 2 && o.eline == (ch_n[0] ? B_J : B_K)) ch_n++;
            if (ch_n == 6) begin ls = S_L0; hs = 1; tmr = 0; n_hs++; end
            else if (tmr == T_HSW) begin ls = S_L0; tmr = 0; c[9]++; end
          end
          S_L0: begin
            if (o.lpm_req) begin
              lv = 1; n_lpm++;
              if (!regs[1][0]) begin lr = 3; c[5]++; end
              else if (o.busy) begin lr = 2; c[4]++; end
              else begin lr = 1; ls = S_L1; besl = o.lpm_besl; l1_rw = o.lpm_rw; c[1]++; tmr = 0; n_l1++; end
            end
            if (ls == S_L0) begin
              if (o.pkt || o.lpm_req || (o.rep_mode && o.eline == B_SE1)) tmr = 0;
              else begin tmr++; if (tmr == T_IDLE) begin ls = S_L2; c[2]++; tmr = 0; n_l2++; end end
            end
          end
          S_L1: begin
            if (rsm_now) go_resume(1);
            else if (o.dev_rwake && l1_rw) begin ls = S_WAKE; tmr = 0; end
          end
          S_L2: begin
            if (rsm_now) go_resume(0);
            else if (o.dev_rwake && (o.rwake_feat || regs[1][1])) begin ls = S_WAKE; tmr = 0; end
          end
          S_RSM: begin
            tmr++;
            if (tmr == (from_l1 ? 7'(T_RESUME) + {2'b00, besl, 1'b0} : 7'(T_L2RSM))) begin ls = S_L0; tmr = 0; end
          end
          S_WAKE: begin
            rk = 1; tmr++;
            if (tmr == T_WAKE) begin ls = S_L0; tmr = 0; c[3]++; n_wake++; end
          end
          default: ;
        endcase
      end
    endfunction

    function void write(eusb2_obs t);
      eusb2_obs o = t;
      cyc++;
      chk(o.lstate == ls && o.hs == hs && o.chirp_k == ck && o.rwake_k == rk,
          $sformatf("@%0d link %0d hs %0d chirp %0d wake %0d, predicted %0d %0d %0d %0d", cyc, o.lstate, o.hs,
                    o.chirp_k, o.rwake_k, ls, hs, ck, rk));
      chk(o.lpm_valid == lv && (!lv || o.lpm_resp == lr),
          $sformatf("@%0d LPM answer %0d/%0d, predicted %0d/%0d", cyc, o.lpm_valid, o.lpm_resp, lv, lr));
      chk(o.rap_done == rd && (!rd || (o.rap_ok == rok && o.rap_rdata == rdat)),
          $sformatf("@%0d RAP answer %0d ok %0d data %h, predicted %0d %0d %h", cyc, o.rap_done, o.rap_ok,
                    o.rap_rdata, rd, rok, rdat));
      chk(o.ctrl == regs[1], $sformatf("@%0d CTRL %h, predicted %h", cyc, o.ctrl, regs[1]));
      foreach (c[i]) chk(o.cnt[i] == c[i], $sformatf("@%0d %s %0d, predicted %0d", cyc, cnt_name[i], o.cnt[i], c[i]));
      step(o);
      chk(o.lstate_next == ls, $sformatf("@%0d link %0d -> %0d, predicted %0d (eline %0d rep %0d)", cyc, o.lstate,
                                         o.lstate_next, ls, o.eline, o.rep_mode));
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("EUSB2_SB", $sformatf("checks=%0d control_msgs=%0d rap=%0d lpm=%0d l1=%0d l2=%0d hs=%0d wakes=%0d resumes=%0d errors=%0d",
                n_checks, n_cm, n_rap, n_lpm, n_l1, n_l2, n_hs, n_wake, n_rsm, errors), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ coverage
  class eusb2_coverage extends uvm_subscriber #(eusb2_obs);
    `uvm_component_utils(eusb2_coverage)
    logic [3:0] from_s, to_s;
    logic [1:0] lr;
    logic [3:0] ra;
    bit         rwr, rok;
    int         ev;
    logic [7:0] prev [10];
    bit         first = 1;
    covergroup cg_link;
      cp_tr: coverpoint {from_s, to_s} {
        bins attach   = {8'h01};
        bins reset    = {8'h12, 8'h52, 8'h62, 8'h72};
        bins chirp    = {8'h23};
        bins no_chirp = {8'h25};
        bins hs_wait  = {8'h34};
        bins hs_ok    = {8'h45};
        bins idle_l2  = {8'h57};
        bins lpm_l1   = {8'h56};
        bins l1_rsm   = {8'h68};
        bins l2_rsm   = {8'h78};
        bins l1_wake  = {8'h69};
        bins l2_wake  = {8'h79};
        bins rsm_l0   = {8'h85};
        bins wake_l0  = {8'h95};
        bins disc     = {8'h10, 8'h50, 8'h60, 8'h70};
      }
    endgroup
    covergroup cg_lpm;
      cp_resp: coverpoint lr { bins ack = {1}; bins nyet = {2}; bins stall = {3}; }
    endgroup
    covergroup cg_rap;
      cp_addr: coverpoint ra { bins id = {0}; bins ctrl = {1}; bins status = {2}; bins scratch = {3};
                               bins tune = {[4:7]}; bins bad = {[8:15]}; }
      cp_wr: coverpoint rwr;
      cp_ok: coverpoint rok;
      x_addr_wr: cross cp_addr, cp_wr;
    endgroup
    covergroup cg_ev;
      cp_ev: coverpoint ev { bins reset = {0}; bins l1 = {1}; bins l2 = {2}; bins wake = {3}; bins nyet = {4};
                             bins stall = {5}; bins cm_bad = {6}; bins rap_err = {7}; bins disc = {8};
                             bins chirp_fail = {9}; bins hs_dis = {20}; bins rwake_en = {21};
                             bins cm_reset = {22}; bins se0_reset = {23}; bins cm_resume = {24}; bins k_resume = {25}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      cg_link = new(); cg_lpm = new(); cg_rap = new(); cg_ev = new();
    endfunction
    function void write(eusb2_obs t);
      eusb2_obs o = t;
      if (o.lstate != o.lstate_next) begin
        from_s = o.lstate; to_s = o.lstate_next; cg_link.sample();
        if (to_s == S_RESET) begin ev = o.rep_mode ? 22 : 23; cg_ev.sample(); end
        if (to_s == S_RSM) begin ev = o.rep_mode ? 24 : 25; cg_ev.sample(); end
      end
      if (o.lpm_valid) begin lr = o.lpm_resp; cg_lpm.sample(); end
      if (!first) foreach (o.cnt[i]) if (o.cnt[i] != prev[i]) begin ev = i; cg_ev.sample(); end
      if (o.ctrl[2]) begin ev = 20; cg_ev.sample(); end
      if (o.ctrl[1]) begin ev = 21; cg_ev.sample(); end
      first = 0;
      prev = o.cnt;
    endfunction
    // register accesses are sampled from the answer (one clock after the access)
    function void sample_rap(logic [3:0] a, bit w, bit ok);
      ra = a; rwr = w; rok = ok; cg_rap.sample();
    endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("EUSB2_COV", $sformatf("link %0.1f%%  lpm %0.1f%%  rap %0.1f%%  events %0.1f%%", cg_link.get_coverage(),
                cg_lpm.get_coverage(), cg_rap.get_coverage(), cg_ev.get_coverage()), UVM_LOW)
    endfunction
  endclass

  // pairs a register access with its answer for coverage
  class eusb2_rap_tracker extends uvm_subscriber #(eusb2_obs);
    `uvm_component_utils(eusb2_rap_tracker)
    eusb2_coverage cov;
    bit            pend;
    logic [3:0]    a;
    bit            w;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void write(eusb2_obs t);
      eusb2_obs o = t;
      if (pend && o.rap_done) cov.sample_rap(a, w, o.rap_ok);
      pend = o.rap_valid; a = o.rap_addr; w = o.rap_wr;
    endfunction
  endclass

  // ------------------------------------------------------------ sequences
  class eusb2_base_seq extends uvm_sequence #(eusb2_item);
    `uvm_object_utils(eusb2_base_seq)
    virtual eusb2_link_if vif;
    function new(string name = "eusb2_base_seq"); super.new(name); endfunction
    task pre_body();
      if (vif == null) void'(uvm_config_db#(virtual eusb2_link_if)::get(null, "*", "eusb2l_vif", vif));
    endtask
    task send(eusb2_item t); start_item(t); finish_item(t); endtask
    task idle(int n);
      eusb2_item t = eusb2_item::type_id::create("t");
      t.kind = K_IDLE; t.n = n; send(t);
    endtask
    task lvl(logic [1:0] l, int n = 1);
      eusb2_item t = eusb2_item::type_id::create("t");
      t.kind = K_LVL; t.lvl = l; t.n = n; send(t);
    endtask
    task set(e2_kind_e k, bit v);
      eusb2_item t = eusb2_item::type_id::create("t");
      t.kind = k; t.v = v; send(t);
    endtask
    task ev(e2_kind_e k);
      eusb2_item t = eusb2_item::type_id::create("t");
      t.kind = k; send(t);
    endtask
    task lpm(logic [3:0] b, bit rw);
      eusb2_item t = eusb2_item::type_id::create("t");
      t.kind = K_LPM; t.besl = b; t.rw = rw; send(t);
    endtask
    task rap(bit wr, logic [3:0] a, logic [7:0] d);
      eusb2_item t = eusb2_item::type_id::create("t");
      t.kind = K_RAP; t.wr = wr; t.addr = a; t.data = d; send(t);
    endtask
    // control message: n SE1 pulses of 1..2 clocks, then the end gap
    task cmsg(int np);
      for (int i = 0; i < np; i++) begin lvl(B_SE1, $urandom_range(1, 2)); lvl(B_SE0, $urandom_range(1, 2)); end
      lvl(B_J, T_CMEND);
    endtask
    task host_chirp(bit bad = 0);
      for (int i = 0; i < 3; i++) begin lvl(B_K, bad ? 1 : 2); lvl(B_J, bad ? 1 : 2); end
    endtask
    // reset by the mode's mechanism, then answer the chirp (or not)
    task reset_port(bit go_hs = 1, bit bad = 0);
      if (vif.rep_mode) cmsg(1);
      else lvl(B_SE0, T_RST + 1);
      lvl(B_J, 1);
      if (vif.lstate == S_RESET) while (vif.lstate == S_RESET) idle(1);
      if (vif.lstate == S_CHIRP) begin
        while (vif.lstate != S_HSW) idle(1);
        if (go_hs) host_chirp(bad);
        while (vif.lstate == S_HSW) idle(1);
      end
      lvl(B_J, 1);
    endtask
    task host_resume();
      if (vif.rep_mode) cmsg(3);
      else begin lvl(B_K, $urandom_range(4, 6)); lvl(B_J, 1); end
      while (vif.lstate == S_RSM) idle(1);
    endtask
    task ensure_l0();
      for (int k = 0; k < 4 && vif.lstate != S_L0; k++) begin
        if (!vif.attach) set(K_ATTACH, 1);
        if (vif.lstate == S_DISC) lvl(B_J, T_CONN + 1);
        if (vif.lstate == S_ATT) reset_port($urandom_range(0, 4) != 0);
        if (vif.lstate == S_L1 || vif.lstate == S_L2) host_resume();
        while (vif.lstate inside {S_RESET, S_CHIRP, S_HSW, S_RSM, S_WAKE}) idle(1);
      end
    endtask
    task traffic(int n);
      for (int i = 0; i < n; i++) begin ev(K_PKT); idle($urandom_range(1, 20)); end
    endtask
    task do_lpm();
      bit b;
      b = $urandom_range(0, 4) == 0;
      if (b) set(K_BUSY, 1);
      lpm(4'($urandom_range(0, 15)), $urandom_range(0, 1));
      if (b) set(K_BUSY, 0);
      if (vif.lstate == S_L1) begin
        idle($urandom_range(1, 30));
        if ($urandom_range(0, 1)) ev(K_WAKE);
        idle(2);
        if (vif.lstate == S_L1) begin
          if ($urandom_range(0, 7) == 0) reset_port(1);
          else host_resume();
        end
        while (vif.lstate == S_WAKE) idle(1);
      end
    endtask
    task do_l2();
      if (vif.rep_mode && $urandom_range(0, 1)) cmsg(2);
      else idle(T_IDLE + 1);
      if (vif.lstate != S_L2) return;
      idle($urandom_range(1, 20));
      if ($urandom_range(0, 2) == 0) begin
        if ($urandom_range(0, 1)) set(K_FEAT, 1);
        ev(K_WAKE); idle(1); set(K_FEAT, 0);
        while (vif.lstate == S_WAKE) idle(1);
      end
      if (vif.lstate == S_L2) begin
        if (!vif.rep_mode && $urandom_range(0, 3) == 0) begin lvl(B_K, $urandom_range(1, 3)); lvl(B_J, 2); end
        if ($urandom_range(0, 7) == 0) reset_port(1);
        else host_resume();
      end
    endtask
    task do_rap();
      if (!vif.rep_mode) return;
      cmsg(4);
      case ($urandom_range(0, 9))
        0: idle(T_RAP + 1);
        1: begin rap(1, 4'd1, 8'($urandom_range(0, 7))); end
        2: rap(1, 4'($urandom_range(0, 1)) * 4'd2, $urandom());
        3: rap($urandom_range(0, 1), 4'($urandom_range(8, 15)), $urandom());
        4: rap($urandom_range(0, 1), 4'd3, $urandom());
        5: rap($urandom_range(0, 1), 4'($urandom_range(4, 7)), $urandom());
        6: rap(0, 4'd2, 0);
        default: rap(0, 4'($urandom_range(0, 7)), 0);
      endcase
      idle(1);
      ev(K_PKT);
    endtask
  endclass

  class eusb2_regression_seq extends eusb2_base_seq;
    `uvm_object_utils(eusb2_regression_seq)
    int n_iter = 1500;
    function new(string name = "eusb2_regression_seq"); super.new(name); endfunction
    task body();
      idle(3);
      set(K_ATTACH, 1);
      lvl(B_J, 6);
      for (int i = 0; i < n_iter; i++) begin
        if (i % 150 == 75) begin set(K_ATTACH, 0); idle(3); set(K_MODE, !vif.rep_mode); set(K_ATTACH, 1); end
        ensure_l0();
        case ($urandom_range(0, 15))
          0, 1, 2: traffic($urandom_range(1, 6));
          3, 4, 5: do_lpm();
          6, 7: do_l2();
          8, 9, 10: do_rap();
          11: begin cmsg($urandom_range(1, 7)); idle(2); end                       // any control message
          12: begin lvl(B_SE1, 2); lvl(B_J, 2); end                               // stray SE1
          13: if ($urandom_range(0, 3) == 0) begin set(K_CAP, $urandom_range(0, 3) != 0);
                reset_port($urandom_range(0, 3) != 0, $urandom_range(0, 4) == 0); set(K_CAP, 1); end
          14: if ($urandom_range(0, 5) == 0) begin set(K_ATTACH, 0); idle($urandom_range(1, 5)); set(K_ATTACH, 1); end
          default: begin lvl(B_SE0, $urandom_range(2, 12)); lvl(B_J, 1); end      // short SE0
        endcase
        if (vif.lstate == S_L0) ev(K_PKT);
      end
      idle(30);
    endtask
  endclass

  // ------------------------------------------------------------ env / test
  class eusb2_env extends uvm_env;
    `uvm_component_utils(eusb2_env)
    eusb2_sequencer   sqr;
    eusb2_driver      drv;
    eusb2_monitor     mon;
    eusb2_scoreboard  sb;
    eusb2_coverage    cov;
    eusb2_rap_tracker rt;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      sqr = eusb2_sequencer::type_id::create("sqr", this);
      drv = eusb2_driver::type_id::create("drv", this);
      mon = eusb2_monitor::type_id::create("mon", this);
      sb  = eusb2_scoreboard::type_id::create("sb", this);
      cov = eusb2_coverage::type_id::create("cov", this);
      rt  = eusb2_rap_tracker::type_id::create("rt", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(sb.analysis_export);
      mon.ap.connect(cov.analysis_export);
      mon.ap.connect(rt.analysis_export);
      rt.cov = cov;
    endfunction
  endclass

  class eusb2_link_test extends uvm_test;
    `uvm_component_utils(eusb2_link_test)
    eusb2_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      env = eusb2_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      eusb2_regression_seq s = eusb2_regression_seq::type_id::create("s");
      phase.raise_objection(this);
      s.start(env.sqr);
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0 &&
          env.sb.n_rap > 50 && env.sb.n_l1 > 50 && env.sb.n_l2 > 30 && env.sb.n_hs > 20)
        $display("SB_PASS checks=%0d", env.sb.n_checks);
      else `uvm_error("TEST", "EUSB2_LINK_TEST FAILED")
    endfunction
  endclass
endpackage

`endif
