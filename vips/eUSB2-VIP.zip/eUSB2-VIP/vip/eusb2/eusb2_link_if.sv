// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eUSB2 port interface between the host-port BFM and a peripheral port
// link controller: mode, attach, the eD+/eD- bus level, packet-level LPM
// and activity, device remote-wake and repeater register access in; link
// state, chirp / wake K, LPM and register-access answers and counters out.
// See tb/eusb2_smoke_model.sv.
`ifndef EUSB2_LINK_IF_SV
`define EUSB2_LINK_IF_SV

interface eusb2_link_if (input logic clk, input logic rst_n);
  logic        rep_mode, attach, hs_cap;
  logic [1:0]  eline;          // 0 SE0 1 J 2 K 3 SE1
  logic        pkt;
  logic        lpm_req;
  logic [3:0]  lpm_besl;
  logic        lpm_rw, busy, dev_rwake, rwake_feat;
  logic        rap_valid, rap_wr;
  logic [3:0]  rap_addr;
  logic [7:0]  rap_wdata;
  logic [3:0]  lstate;         // 0 DISC 1 ATT 2 RESET 3 CHIRP 4 HS_WAIT 5 L0 6 L1 7 L2 8 RESUME 9 RWAKE
  logic        hs, chirp_k, rwake_k, lpm_valid, rap_done, rap_ok;
  logic [1:0]  lpm_resp;       // 1 ACK 2 NYET 3 STALL
  logic [7:0]  rap_rdata, ctrl;
  logic [7:0]  resets, l1_cnt, l2_cnt, wake_cnt, lpm_nyet, lpm_stall, cm_bad, rap_err, disc_cnt, chirp_fail;

  initial begin
    rep_mode = 1'b0; attach = 1'b0; hs_cap = 1'b1; eline = 2'd1; pkt = 1'b0; lpm_req = 1'b0; lpm_besl = 4'd0;
    lpm_rw = 1'b0; busy = 1'b0; dev_rwake = 1'b0; rwake_feat = 1'b0; rap_valid = 1'b0; rap_wr = 1'b0;
    rap_addr = 4'd0; rap_wdata = 8'h00;
  end
endinterface

`endif
