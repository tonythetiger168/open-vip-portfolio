// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (BoW DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened bow_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic phy_reset_b = 1'b1, ck = 1'b0, aux = 1'b0, fec = 1'b0, rep_en = 1'b0, prbs_en = 1'b0;
  logic [15:0] d = 16'h0;
  logic [4:0]  bad_a = 5'd31, bad_b = 5'd31;
  wire  phy_ready, pv;
  wire  [63:0] pd;
  wire  [3:0]  paux, pfec;
  wire  [4:0]  err;

  always #5 clk = ~clk;

  bow_model u_dut (.clk(clk), .rst_n(rst_n), .phy_reset_b(phy_reset_b), .ck(ck), .d(d), .aux(aux), .fec(fec),
                   .rep_en(rep_en), .bad_a(bad_a), .bad_b(bad_b), .prbs_en(prbs_en), .phy_ready(phy_ready),
                   .pv(pv), .pd(pd), .paux(paux), .pfec(pfec), .err(err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // what the slice reported: the last word, every error bit seen, the clock of each
  logic [63:0] w_pd;  logic [3:0] w_aux, w_fec;
  integer nw = 0, e_seen [0:4], e_at [0:4], nclk = 0;
  always @(posedge clk) begin
    nclk = nclk + 1;
    if (pv) begin nw = nw + 1; w_pd = pd; w_aux = paux; w_fec = pfec; end
    for (int i = 0; i < 5; i++) if (err[i]) begin e_seen[i] = e_seen[i] + 1; e_at[i] = nclk; end
  end
  task automatic settle(); repeat (2) @(posedge clk); #1; endtask
  task automatic clr(); for (int i = 0; i < 5; i++) e_seen[i] = 0; endtask
  function automatic bit no_err(); no_err = (e_seen[0] + e_seen[1] + e_seen[2] + e_seen[3] + e_seen[4]) == 0; endfunction

  // one bench clock with the 18 physical lines {FEC, D, AUX}; tog toggles the forwarded clock
  task automatic phy(input bit tog, input logic [17:0] x);
    @(negedge clk);
    if (tog) ck = !ck;
    aux = x[0]; d = x[16:1]; fec = x[17];
  endtask
  task automatic still(input integer n); repeat (n) phy(0, 18'h0); endtask
  task automatic ui(input logic [15:0] v, input bit a = 0, input bit f = 0); phy(1, {f, v, a}); endtask
  task automatic word(input logic [63:0] w, input logic [3:0] a = 0, input logic [3:0] f = 0);
    for (int k = 0; k < 4; k++) ui(w[16*k +: 16], a[k], f[k]);
  endtask
  task automatic train(input integer n, input logic [15:0] tp);
    for (int u = 0; u < n; u++) phy(1, {18{tp[15 - u % 16]}});
  endtask
  task automatic preset();
    @(negedge clk); phy_reset_b = 0; still(3); @(negedge clk); phy_reset_b = 1;
  endtask
  // physical lines for logical lanes l with redundancy around physical lines p, q (p < q, 31 = none)
  function automatic logic [17:0] rmap(input logic [15:0] l, input integer p, input integer q);
    logic [17:0] x;
    integer pj;
    x = 18'h0;
    for (int j = 0; j < 16; j++) begin
      pj = (j + 1 <= p) ? j : (j + 1 >= q) ? j + 2 : j + 1;
      x[pj] = l[j];
    end
    rmap = x;
  endfunction
  integer t0, k;
  logic [8:0] s [0:15];
  logic [15:0] pl;
  logic [15:0] tpat = 16'hF0CA;

  initial begin
    clr();
    repeat (3) @(posedge clk);
    chk(phy_ready === 1'b0 && pv === 1'b0 && err === 5'h0, "reset: not ready, nothing out");
    rst_n = 1;
    // no training yet: random wire activity gives no PHYReady
    for (int u = 0; u < 40; u++) phy(1, {18{u[1] ^ u[3]}});
    chk(phy_ready === 1'b0, "no PHYReady without the training pattern");
    // wrong pattern
    preset(); train(64, 16'hF1CA);
    chk(phy_ready === 1'b0, "wrong training pattern: not ready");
    // the right one: ready after 32 edges, word boundary at the pattern start
    preset(); train(31, 16'hF0CA); settle();
    chk(phy_ready === 1'b0, "31 UI of pattern: not yet ready");
    phy(1, {18{1'b0}}); settle();    // UI 31: the pattern's last bit (TP[0] = 0)
    chk(phy_ready === 1'b1, "ready after 32 UI with the last 16 equal to the pattern");
    nw = 0;
    phy(1, {18{1'b1}}); phy(1, {18{1'b1}}); phy(1, {18{1'b1}}); phy(1, {18{1'b1}});  // pattern bits 15..12 = 1111
    settle();
    chk(nw == 1 && w_pd == {64{1'b1}} && w_aux == 4'hF && w_fec == 4'hF, "first word = first 4 UI of the pattern");
    train(12, 16'h0CA0);       // finish the pattern (bits 11..0) without a gate
    // bit ordering: UI k -> P_D[16k +: 16]
    word(64'h4444_3333_2222_1111, 4'b0101, 4'b1010); settle();
    chk(w_pd == 64'h4444_3333_2222_1111 && w_aux == 4'b0101 && w_fec == 4'b1010, "UI k lands in P_D[16k+15:16k], AUX / FEC bit k");
    // a proper gate: IDLE postamble, gate, IDLE preamble
    word(64'h0); still(3); clr(); still(20); word(64'h0); word(64'hDEAD_BEEF_0123_4567); word(64'h0); still(5);
    settle();
    chk(no_err(), "IDLE postamble / preamble around a gate: no error");
    chk(w_pd == 64'h0, "the IDLE postamble is delivered as a word");
    // non-IDLE postamble
    clr(); word(64'h0); word(64'h1); still(5); @(posedge clk);
    chk(e_seen[1] == 1 && e_seen[2] == 0, "gate after a non-IDLE word: postamble error");
    // non-IDLE preamble
    clr(); word(64'h0, 4'b0001); word(64'h0); still(4);
    chk(e_seen[1] == 1, "first word after a gate not IDLE (AUX set): preamble error");
    // partial word
    clr(); word(64'h0); ui(16'h0); ui(16'h0); still(4); @(posedge clk);
    chk(e_seen[2] == 1 && e_seen[1] == 0, "clock stopped after 2 UI of a word: error 2");
    k = nw; word(64'h0); word(64'hAB); word(64'h0); still(3); settle();
    chk(nw == k + 3 && w_pd == 64'h0, "the next words start at a word boundary again");
    // gated high: odd UI count
    clr(); word(64'h0); ui(16'h0); still(4); @(posedge clk);
    chk(e_seen[3] == 1 && e_seen[2] == 1, "clock gated high (mid-word): errors 3 and 2");
    ui(16'h0); ui(16'h0); ui(16'h0); still(3);   // back to low
    // gate length: 512 UI fine, 513 not
    clr(); word(64'h0); still(512); word(64'h0); still(3); @(posedge clk);
    chk(e_seen[0] == 0, "512 UI gated: no error");
    clr(); word(64'h0); t0 = nclk; still(513); settle();
    chk(e_seen[0] == 1 && e_at[0] - t0 == 515, "513th gated UI: error 0, one clock later");
    still(600); @(posedge clk);
    chk(e_seen[0] == 1, "error 0 once per gate");
    word(64'h0); still(3);
    // redundancy: D4 and D6 defective (physical 5 and 7)
    rep_en = 1; bad_a = 5'd7; bad_b = 5'd5;
    preset(); for (int u = 0; u < 48; u++) begin
      logic [17:0] x; x = {18{u % 16 == 0 || u % 16 == 1 || u % 16 == 2 || u % 16 == 3 ||
                          u % 16 == 8 || u % 16 == 9 || u % 16 == 12 || u % 16 == 14}};
      x[5] = u[0]; x[7] = !u[0];    // noise on the defective lines
      phy(1, x);
    end
    chk(phy_ready === 1'b1, "training ignores the defective lines");
    clr();
    for (int kk = 0; kk < 4; kk++) begin logic [17:0] x; x = rmap(16'h8001 << kk | 16'h0010, 5, 7); x[5] = 1; x[7] = 1; phy(1, x); end
    settle();
    chk(w_pd == {16'h0010 | 16'h8001 << 3, 16'h0010 | 16'h8001 << 2, 16'h0010 | 16'h8001 << 1, 16'h8011},
        "D4, D6 defective: logical D[4:0] on {D[3:0], AUX}, D[15:6] on {FEC, D[15:7]}");
    chk(w_aux == 4'h0 && w_fec == 4'h0, "redundancy on: PAUX / PFEC are 0");
    // logical D0 really travels on AUX, D15 on FEC
    phy(1, 18'h00001); phy(1, 18'h20000); phy(1, 18'h00040); phy(1, 18'h00010); settle();
    chk(w_pd == {16'h0010, 16'h0020, 16'h8000, 16'h0001}, "AUX carries logical D0, FEC D15, physical D5 / D3 carry D5 / D4");
    // one defective data line: D10 (physical 11)
    bad_a = 5'd11; bad_b = 5'd31; preset(); train(48, 16'hF0CA);
    phy(1, rmap(16'h0400, 11, 31)); phy(1, rmap(16'h0800, 11, 31)); phy(1, rmap(16'h0001, 11, 31)); phy(1, rmap(16'hFFFF, 11, 31));
    settle();
    chk(w_pd == {16'hFFFF, 16'h0001, 16'h0800, 16'h0400} && rmap(16'h0400, 11, 31) == 18'h00400, "D10 defective: D10 on physical D9, D11 stays");
    // only AUX and FEC defective: nothing moves
    bad_a = 5'd0; bad_b = 5'd17; preset(); train(48, 16'hF0CA);
    word(64'h8000_0001_1234_00FF); settle();
    chk(w_pd == 64'h8000_0001_1234_00FF, "AUX and FEC defective: no shift");
    // AUX and D3 defective: D3 and up shift up
    bad_a = 5'd4; bad_b = 5'd0; preset(); train(48, 16'hF0CA);
    phy(1, rmap(16'h0008, 0, 4)); phy(1, rmap(16'h8000, 0, 4)); phy(1, rmap(16'h0004, 0, 4)); phy(1, rmap(16'h0001, 0, 4));
    settle();
    chk(w_pd == {16'h0001, 16'h0004, 16'h8000, 16'h0008} && rmap(16'h8000, 0, 4) == 18'h20000,
        "AUX and D3 defective: D3 on D4 ... D15 on FEC");
    // FEC alone: no shift
    bad_a = 5'd17; bad_b = 5'd31; preset(); train(48, 16'hF0CA);
    word(64'h0001_8000_0010_0100); settle();
    chk(w_pd == 64'h0001_8000_0010_0100, "FEC alone defective: no shift");
    // AUX alone, named by bad_b: no shift
    bad_a = 5'd31; bad_b = 5'd0; preset(); train(48, 16'hF0CA);
    word(64'h8001_0002_4000_0100); settle();
    chk(w_pd == 64'h8001_0002_4000_0100, "AUX alone defective (second defect field): no shift");
    // a line named in bad_a with noise: trains with redundancy on, not with it off
    for (int r = 1; r >= 0; r--) begin
      rep_en = r[0]; bad_a = 5'd6; bad_b = 5'd31; preset();
      for (int u = 0; u < 48; u++) begin
        logic [17:0] x; x = {18{tpat[15 - u % 16]}}; x[6] = u[1]; phy(1, x);
      end
      settle();
      if (r == 1) chk(phy_ready === 1'b1, "redundancy on: noise on the line in bad_a is ignored in training");
      else        chk(phy_ready === 1'b0, "redundancy off: bad_a is ignored, the noisy line keeps PHYReady low");
    end
    // PRBS-9 checker
    rep_en = 0; bad_a = 5'd31; bad_b = 5'd31; prbs_en = 1; preset(); train(48, 16'hF0CA);
    word(64'h0); still(5); clr();
    for (int j = 0; j < 16; j++) s[j] = 9'(j * 29 + 3);
    word(64'h0);
    for (int u = 0; u < 40; u++) begin
      for (int j = 0; j < 16; j++) begin pl[j] = s[j][8] ^ s[j][4]; s[j] = {s[j][7:0], pl[j]}; end
      ui(pl);
    end
    word(64'h0); still(5);
    chk(e_seen[4] == 0 && e_seen[1] == 0, "PRBS-9 (x^9 + x^5 + 1) on 16 lanes: no error");
    clr(); word(64'h0);
    for (int u = 0; u < 40; u++) begin
      for (int j = 0; j < 16; j++) begin pl[j] = s[j][8] ^ s[j][4]; s[j] = {s[j][7:0], pl[j]}; end
      if (u == 20) pl[7] = !pl[7];
      ui(pl);
    end
    word(64'h0); still(5);
    chk(e_seen[4] >= 1, "one flipped bit: PRBS error");
    clr(); word(64'h0);
    for (int u = 0; u < 8; u++) ui(16'hFFFF);  // 8 UI: still locking, then IDLE
    word(64'h0); still(5);
    chk(e_seen[4] == 0, "no PRBS check before 9 UI of data");
    prbs_en = 0; clr(); word(64'h0); word(64'h1234); word(64'h0); still(5);
    chk(e_seen[4] == 0, "checker off: no PRBS error");
    // PHYResetB drops PHYReady
    @(negedge clk); phy_reset_b = 0; settle();
    chk(phy_ready === 1'b0, "PHYResetB low: PHYReady low on the next clock");
    @(negedge clk); phy_reset_b = 1; k = nw; word(64'h1); word(64'h0); still(3);
    chk(phy_ready === 1'b0 && nw == k, "after reset no words until retrained");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #4000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
