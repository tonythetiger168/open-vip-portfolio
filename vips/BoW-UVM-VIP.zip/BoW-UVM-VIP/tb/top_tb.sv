// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- BoW testbench top with a functional BoW DUT model

`ifndef BOW_UVM_VIP_TB_SV
`define BOW_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import bow_defs_pkg::*;
import bow_pkg::*;
import bow_env_pkg::*;
import bow_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  bow_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  bow_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .phy_reset_b(vif.phy_reset_b),
    .ck(vif.ck),
    .d(vif.d),
    .aux(vif.aux),
    .fec(vif.fec),
    .rep_en(vif.rep_en),
    .bad_a(vif.bad_a),
    .bad_b(vif.bad_b),
    .prbs_en(vif.prbs_en),
    .phy_ready(vif.phy_ready),
    .pv(vif.pv),
    .pd(vif.pd),
    .paux(vif.paux),
    .pfec(vif.pfec),
    .err(vif.err)
  );

  // Concurrent protocol checks
  bow_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .phy_reset_b(vif.phy_reset_b),
    .ck(vif.ck),
    .d(vif.d),
    .aux(vif.aux),
    .fec(vif.fec),
    .rep_en(vif.rep_en),
    .bad_a(vif.bad_a),
    .bad_b(vif.bad_b),
    .prbs_en(vif.prbs_en),
    .phy_ready(vif.phy_ready),
    .pv(vif.pv),
    .pd(vif.pd),
    .paux(vif.paux),
    .pfec(vif.pfec),
    .err(vif.err)
  );

  initial begin
    uvm_config_db#(virtual bow_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module bow_model #(
  parameter logic [15:0] TP    = 16'hF0CA,
  parameter int          ALIGN = 32,
  parameter int          GMAX  = 512
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        phy_reset_b,
  input  logic        ck,
  input  logic [15:0] d,
  input  logic        aux,
  input  logic        fec,
  input  logic        rep_en,
  input  logic [4:0]  bad_a,
  input  logic [4:0]  bad_b,
  input  logic        prbs_en,
  output logic        phy_ready,
  output logic        pv,
  output logic [63:0] pd,
  output logic [3:0]  paux,
  output logic [3:0]  pfec,
  output logic [4:0]  err
);
  // physical line of logical lane j (0 = AUX, 1..16 = D0..D15, 17 = FEC)
  function automatic integer phys_of(input integer j);
    integer lo, hi;
    logic va, vb;
    lo = -1; hi = 99;
    va = (bad_a <= 5'd17);
    vb = (bad_b <= 5'd17) && (bad_b != bad_a);
    if (rep_en) begin
      if (va && vb) begin
        lo = (bad_a < bad_b) ? bad_a : bad_b;
        hi = (bad_a < bad_b) ? bad_b : bad_a;
      end else if (va && bad_a >= 5'd1 && bad_a <= 5'd16) lo = bad_a;
      else if (vb && bad_b >= 5'd1 && bad_b <= 5'd16) lo = bad_b;
    end
    if (j + 1 <= lo) phys_of = j;
    else if (j + 1 >= hi) phys_of = j + 2;
    else phys_of = j + 1;
  endfunction
  function automatic logic bad_line(input integer i);
    bad_line = rep_en && ((bad_a <= 5'd17 && i == bad_a) || (bad_b <= 5'd17 && i == bad_b));
  endfunction

  wire  [17:0] line = {fec, d, aux};
  logic [15:0] lg;
  logic        la, lf, ui_idle, match, perr, wi;
  logic [15:0] win [0:17];
  logic [8:0]  hist [0:15];
  logic        ck_q, gated, need_pre, last_idle, widle;
  logic [5:0]  edges;
  logic [1:0]  ph;
  logic [47:0] wd;
  logic [3:0]  wa, wf;
  logic [9:0]  g;
  logic [3:0]  pn;

  always_comb begin
    for (int j = 0; j < 16; j++) lg[j] = line[phys_of(j)];
    la = rep_en ? 1'b0 : aux;
    lf = rep_en ? 1'b0 : fec;
    ui_idle = (lg == 16'h0) && !la && !lf;
    match = 1'b1;
    for (int i = 0; i < 18; i++)
      if (!bad_line(i) && {win[i][14:0], line[i]} != TP) match = 1'b0;
    perr = 1'b0;
    for (int j = 0; j < 16; j++)
      if (!ui_idle && pn >= 4'd9 && lg[j] != (hist[j][8] ^ hist[j][4])) perr = 1'b1;
    wi = (ph == 2'd0) ? ui_idle : (widle && ui_idle);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ck_q <= 1'b0; phy_ready <= 1'b0; pv <= 1'b0; pd <= '0; paux <= '0; pfec <= '0; err <= '0;
      edges <= '0; ph <= '0; wd <= '0; wa <= '0; wf <= '0; gated <= 1'b0; g <= '0;
      need_pre <= 1'b0; last_idle <= 1'b1; widle <= 1'b1; pn <= '0;
      for (int i = 0; i < 18; i++) win[i] <= '0;
      for (int j = 0; j < 16; j++) hist[j] <= '0;
    end else begin
      ck_q <= ck;
      pv   <= 1'b0;
      err  <= '0;
      if (!phy_reset_b) begin
        phy_ready <= 1'b0; edges <= '0; ph <= '0; gated <= 1'b0; g <= '0;
        need_pre <= 1'b0; last_idle <= 1'b1; widle <= 1'b1; pn <= '0;
        for (int i = 0; i < 18; i++) win[i] <= '0;
      end else if (!phy_ready) begin
        if (ck != ck_q) begin
          for (int i = 0; i < 18; i++) win[i] <= {win[i][14:0], line[i]};
          if (edges != 6'd63) edges <= edges + 6'd1;
          if (32'(edges) + 1 >= ALIGN && match) begin
            phy_ready <= 1'b1; ph <= '0; pn <= '0; last_idle <= 1'b1; gated <= 1'b0;
          end
        end
      end else if (ck != ck_q) begin
        widle <= wi;
        if (gated) need_pre <= 1'b1;
        gated <= 1'b0; g <= '0;
        if (ph == 2'd3) begin
          pv <= 1'b1; pd <= {lg, wd}; paux <= {la, wa[2:0]}; pfec <= {lf, wf[2:0]};
          last_idle <= wi;
          if (need_pre) begin
            need_pre <= 1'b0;
            if (!wi) err[1] <= 1'b1;
          end
        end else begin
          case (ph)
            2'd0: wd[15:0]  <= lg;
            2'd1: wd[31:16] <= lg;
            default: wd[47:32] <= lg;
          endcase
          wa[ph] <= la; wf[ph] <= lf;
        end
        ph <= ph + 2'd1;
        if (prbs_en) begin
          if (perr) err[4] <= 1'b1;
          for (int j = 0; j < 16; j++) hist[j] <= {hist[j][7:0], lg[j]};
          if (ui_idle) pn <= '0;
          else if (pn != 4'd9) pn <= pn + 4'd1;
        end else pn <= '0;
      end else begin
        if (!gated) begin
          gated <= 1'b1; g <= 10'd1;
          if (ph != 2'd0) begin err[2] <= 1'b1; ph <= '0; end
          else if (!last_idle) err[1] <= 1'b1;
          if (ck) err[3] <= 1'b1;
        end else if (32'(g) != GMAX + 1) begin
          if (32'(g) == GMAX) err[0] <= 1'b1;
          g <= g + 10'd1;
        end
      end
    end
  end
endmodule
`endif
