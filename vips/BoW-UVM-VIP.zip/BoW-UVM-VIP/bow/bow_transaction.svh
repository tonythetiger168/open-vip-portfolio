// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_transaction.svh -- BoW transaction

class bow_transaction extends uvm_sequence_item;
  `uvm_object_utils(bow_transaction)

  // request (driven by the agent)
  bit [31:0] mo[$];
  // response (returned by the DUT)
  bit [78:0] so[$];
  bit [4:0] errs;
  // bookkeeping (not compared)
  rand bit [3:0] kind;
  rand bit [3:0] nw;
  rand bit [4:0] ba;
  rand bit [4:0] bb;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { kind dist { 1 := 8, 0 := 2, [2:5] :/ 4, 6 := 4, 7 := 2, 8 := 1, 9 := 3, 10 := 1, [11:15] :/ 2 }; }
  constraint c_nw   { nw inside {[1:8]}; }
  constraint c_bad  { ba inside {[0:17], 31}; bb inside {[0:17], 31}; }

  function new(string name = "bow_transaction"); super.new(name); endfunction

  // kind: 0 reset + training + words, 1 burst with IDLE pre/postamble, 2 no
  // preamble, 3 two extra UI (partial word), 4 a gate of 520 UI first, 5 CLK
  // gated high (odd UI count), 6 PRBS-9 burst, 7 PRBS-9 with a flipped bit,
  // 8 reset + wrong training pattern, 9 reset with redundancy (ba, bb),
  // 10 reset with the PRBS checker on, 11-15 bursts as 1
  function void set(int k, int n = 4, bit [31:0] s = 32'h1, int a = 31, int b = 31);
    kind = k; nw = n; seed = s; ba = a; bb = b;
  endfunction
  function int kk(); return (kind >= 11) ? 1 : kind; endfunction
  // derived from the monitored wires (for coverage)
  function int nwords();
    int n = 0;
    foreach (so[i]) if (so[i][77]) n++;
    return n;
  endfunction
  function bit rep_seen();
    foreach (mo[i]) if (mo[i][20]) return 1;
    return 0;
  endfunction
  function bit prbs_seen();
    foreach (mo[i]) if (mo[i][31]) return 1;
    return 0;
  endfunction
  function bit ready_seen();
    foreach (so[i]) if (so[i][78]) return 1;
    return 0;
  endfunction
  // redundancy configuration seen: 1 one defective data line, 2 two defective
  // lines with at least one data line, 3 only AUX / FEC defective, 0 none
  function int rep_kind();
    bit [4:0] a = 31, b = 31;
    int n;
    bit dl;
    foreach (mo[i]) if (mo[i][20]) begin a = mo[i][25:21]; b = mo[i][30:26]; end
    n = (a <= 17) + (b <= 17 && b != a);
    dl = (a >= 1 && a <= 16) || (b >= 1 && b <= 16);
    if (n == 0) return 0;
    if (!dl) return 3;
    return n;
  endfunction

  function void do_copy(uvm_object rhs);
    bow_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mo = rhs_.mo;
    so = rhs_.so;
    errs = rhs_.errs;
    kind = rhs_.kind;
    nw = rhs_.nw;
    ba = rhs_.ba;
    bb = rhs_.bb;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    bow_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    if (errs != rhs_.errs) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(bow_transaction rhs_);
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    return 1;
  endfunction

  function string qstr_mo();
    string s = $sformatf("[%0d]{", mo.size());
    foreach (mo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", mo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("BoW{tag=%0d mo=%s so=%s errs=0x%0h}", tag, qstr_mo(), qstr_so(), errs);
  endfunction
endclass
