// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_driver.svh -- BoW driver: one item per burst on the slice wires: optional PHYResetB pulse with configuration and training pattern, payload words with or without the IDLE preamble / postamble, partial words, CLK gated low or high, a long gate, PRBS-9 data; every item ends with cfg.gap static clocks (the clock gated low)

class bow_driver extends uvm_driver #(bow_transaction);
  `uvm_component_utils(bow_driver)

  uvm_analysis_port #(bow_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual bow_if vif;
  bow_config cfg;

  bit         ckl = 0;          // forwarded clock level
  bit         rb = 1;           // PHYResetB
  bit         rep = 0, prb = 0;
  bit [4:0]   a = 31, b = 31;
  bit [31:0]  nz = 32'h1234_5678;   // noise on defective lines
  bit [8:0]   lfsr [16];        // PRBS-9 generator per logical lane
  bit         first = 1;
  bow_transaction cur;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual bow_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "bow: virtual interface not set")
    if (!uvm_config_db#(bow_config)::get(this, "", "cfg", cfg))
      cfg = bow_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    bow_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.phy_reset_b <= 1'b1;
    vif.drv_cb.ck <= 1'b0; vif.drv_cb.d <= '0; vif.drv_cb.aux <= 1'b0; vif.drv_cb.fec <= 1'b0;
    vif.drv_cb.rep_en <= 1'b0; vif.drv_cb.bad_a <= 5'd31; vif.drv_cb.bad_b <= 5'd31; vif.drv_cb.prbs_en <= 1'b0;
    foreach (lfsr[j]) lfsr[j] = 9'(j * 37 + 1);
  endtask

  task drive_item(bow_transaction t);
    int n = (t.nw == 0) ? 1 : t.nw;
    cur = t;
    t.mo.delete();
    if (t.kk() == 4 && !first) still(520);
    first = 0;
    case (t.kk())
      0, 8, 9, 10: begin
        do_reset(t.kk() == 9, t.kk() == 10, (t.kk() == 9) ? t.ba : 5'd31, (t.kk() == 9) ? t.bb : 5'd31);
        train(48, (t.kk() == 8) ? (BOW_TP ^ 16'h0100) : BOW_TP);
        if (t.kk() != 8) begin
          for (int i = 0; i < n; i++) word(rword(t.seed, i), t.seed[3:0] ^ 4'(i), t.seed[7:4] ^ 4'(i));
          idle_word();
        end
      end
      6, 7: begin
        idle_word();
        for (int u = 0; u < 4 * n + 12; u++) prbs_ui((t.kk() == 7 && u == 10 + t.seed % 8) ? int'(t.seed[7:4]) : -1);
        idle_word();
      end
      default: begin
        if (t.kk() != 2) idle_word();
        for (int i = 0; i < n; i++) word(rword(t.seed, i), t.seed[3:0], t.seed[11:8]);
        if (t.kk() == 5) begin
          ui(16'h0);           // odd UI count: gated high, mid-word
          still(3);
          repeat (3) ui(16'h0); // back to low (and mid-word again)
        end else begin
          idle_word();
          if (t.kk() == 3) begin ui(16'h0); ui(16'h0); end
        end
      end
    endcase
    still(cfg.gap);
  endtask

  function bit noise();
    nz ^= nz << 13; nz ^= nz >> 17; nz ^= nz << 5;
    return nz[0];
  endfunction
  // one bench clock: toggle the forwarded clock or not, 18 physical lines
  task automatic clk1(bit tog, bit [17:0] ln);
    if (tog) ckl = !ckl;
    vif.drv_cb.phy_reset_b <= rb;
    vif.drv_cb.ck      <= ckl;
    vif.drv_cb.aux     <= ln[0];
    vif.drv_cb.d       <= ln[16:1];
    vif.drv_cb.fec     <= ln[17];
    vif.drv_cb.rep_en  <= rep;
    vif.drv_cb.bad_a   <= a;
    vif.drv_cb.bad_b   <= b;
    vif.drv_cb.prbs_en <= prb;
    cur.mo.push_back({prb, b, a, rep, rb, ckl, ln[17], ln[0], ln[16:1]});
    @(vif.drv_cb);
  endtask
  task automatic still(int n); repeat (n) clk1(1'b0, 18'h0); endtask
  // one UI of logical data through the TX redundancy mux
  task automatic ui(bit [15:0] l, bit la = 0, bit lf = 0);
    bit [17:0] x = 0;
    if (!rep) x = {lf, l, la};
    else begin
      for (int j = 0; j < 16; j++) x[bow_phys(j, rep, a, b)] = l[j];
      for (int i = 0; i < 18; i++) if (bow_bad(i, rep, a, b)) x[i] = noise();
    end
    clk1(1'b1, x);
  endtask
  task automatic word(bit [63:0] w, bit [3:0] wa = 0, bit [3:0] wf = 0);
    for (int k = 0; k < 4; k++) ui(w[16*k +: 16], (rep ? 1'b0 : wa[k]), (rep ? 1'b0 : wf[k]));
  endtask
  task automatic idle_word(); word(64'h0); endtask
  function bit [63:0] rword(bit [31:0] s, int i);
    bit [63:0] x = {s, s ^ 32'h9E37_79B9} + 64'(i) * 64'hD1B5_4A32_D192_ED03;
    x ^= x >> 29; x *= 64'hBF58_476D_1CE4_E5B9; x ^= x >> 32;
    return (x == 0) ? 64'h1 : x;          // never an IDLE word
  endfunction
  // training: TP on every line (noise on defective ones), n UI
  task automatic train(int n, bit [15:0] tp);
    for (int u = 0; u < n; u++) begin
      bit [17:0] x = {18{tp[15 - u % 16]}};
      for (int i = 0; i < 18; i++) if (bow_bad(i, rep, a, b)) x[i] = noise();
      clk1(1'b1, x);
    end
  endtask
  task automatic do_reset(bit r, bit p, bit [4:0] na, bit [4:0] nb);
    rb = 0; rep = r; prb = p; a = na; b = nb;
    still(4);
    rb = 1;
  endtask
  task automatic prbs_ui(int flip);
    bit [15:0] l;
    for (int j = 0; j < 16; j++) begin
      bit nb = lfsr[j][8] ^ lfsr[j][4];
      l[j] = nb;
      lfsr[j] = {lfsr[j][7:0], nb};
    end
    if (flip >= 0) l[flip] = !l[flip];
    ui(l);
  endtask
endclass
