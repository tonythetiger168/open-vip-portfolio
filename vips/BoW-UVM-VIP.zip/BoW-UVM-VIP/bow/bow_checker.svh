// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_checker.svh -- BoW protocol checker on monitored items

class bow_checker extends uvm_component;
  `uvm_component_utils(bow_checker)
  uvm_analysis_imp #(bow_transaction, bow_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  bow_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(bow_config)::get(this, "", "cfg", cfg))
      cfg = bow_config::type_id::create("cfg");
  endfunction

  function void fail(bow_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("BoW: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(bow_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.mo.size() == 0) fail(t, "empty item");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("BoW checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
