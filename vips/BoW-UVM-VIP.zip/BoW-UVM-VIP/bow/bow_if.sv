// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_if.sv -- BoW interface

interface bow_if (input logic clk);
  logic rst_n;

  logic phy_reset_b;
  logic ck;
  logic [15:0] d;
  logic aux;
  logic fec;
  logic rep_en;
  logic [4:0] bad_a;
  logic [4:0] bad_b;
  logic prbs_en;
  logic phy_ready;
  logic pv;
  logic [63:0] pd;
  logic [3:0] paux;
  logic [3:0] pfec;
  logic [4:0] err;

  modport DUT (input clk, rst_n, input phy_reset_b, input ck, input d, input aux, input fec, input rep_en, input bad_a, input bad_b, input prbs_en, output phy_ready, output pv, output pd, output paux, output pfec, output err);
  modport MON (input clk, rst_n, phy_reset_b, ck, d, aux, fec, rep_en, bad_a, bad_b, prbs_en, phy_ready, pv, pd, paux, pfec, err);

  clocking drv_cb @(posedge clk);
    input rst_n, phy_ready, pv, pd, paux, pfec, err;
    inout phy_reset_b, ck, d, aux, fec, rep_en, bad_a, bad_b, prbs_en;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, phy_reset_b, ck, d, aux, fec, rep_en, bad_a, bad_b, prbs_en, phy_ready, pv, pd, paux, pfec, err;
  endclocking
endinterface
