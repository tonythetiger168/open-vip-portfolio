// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_sequences.svh -- BoW sequences

// Random traffic: cfg.num_items constrained-random items.
class bow_base_sequence extends uvm_sequence #(bow_transaction);
  `uvm_object_utils(bow_base_sequence)
  bow_config cfg;

  function new(string name = "bow_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = bow_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "bow_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class bow_directed_sequence extends uvm_sequence #(bow_transaction);
  `uvm_object_utils(bow_directed_sequence)
  bow_config cfg;

  function new(string name = "bow_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function bow_transaction item();
    item = bow_transaction::type_id::create("req");
  endfunction

  task send(bow_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    bow_transaction t;
    // bring-up, words, every clock-gating rule, redundancy cases, PRBS-9, retraining
    t = item(); t.set(1, 2); send(t);                     // before any training: no words
    t = item(); t.set(0, 3, 32'hA5); send(t);
    t = item(); t.set(1, 4, 32'h11); send(t);
    t = item(); t.set(1, 8, 32'h22); send(t);
    t = item(); t.set(2, 2, 32'h33); send(t);             // no preamble
    t = item(); t.set(1, 1, 32'h44); send(t);
    t = item(); t.set(3, 2, 32'h55); send(t);             // partial word
    t = item(); t.set(1, 2, 32'h66); send(t);
    t = item(); t.set(4, 2, 32'h77); send(t);             // 520 UI gate
    t = item(); t.set(5, 1, 32'h88); send(t);             // gated high
    t = item(); t.set(1, 3, 32'h99); send(t);
    t = item(); t.set(9, 2, 32'h1, 5, 7); send(t);        // D4 and D6 defective (sec. 13 example)
    t = item(); t.set(1, 3, 32'h2); send(t);
    t = item(); t.set(9, 2, 32'h3, 11, 31); send(t);      // D10 alone
    t = item(); t.set(1, 2, 32'h4); send(t);
    t = item(); t.set(9, 2, 32'h5, 0, 17); send(t);       // AUX and FEC: nothing moves
    t = item(); t.set(1, 2, 32'h6); send(t);
    t = item(); t.set(9, 2, 32'h7, 0, 4); send(t);        // AUX and D3: D3 and up shift up
    t = item(); t.set(1, 2, 32'h8); send(t);
    t = item(); t.set(9, 2, 32'h9, 17, 31); send(t);      // FEC alone
    t = item(); t.set(1, 2, 32'hA); send(t);
    t = item(); t.set(10, 1, 32'hB); send(t);             // PRBS checker on
    t = item(); t.set(6, 6, 32'hC); send(t);
    t = item(); t.set(7, 6, 32'h1D); send(t);
    t = item(); t.set(6, 4, 32'hE); send(t);
    t = item(); t.set(8, 1, 32'hF); send(t);              // wrong pattern: not ready
    t = item(); t.set(1, 2, 32'h10); send(t);
    t = item(); t.set(0, 2, 32'h11); send(t);
    t = item(); t.set(1, 5, 32'h12); send(t);
  endtask
endclass
