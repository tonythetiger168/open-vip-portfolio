// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_coverage.svh -- BoW functional coverage

class bow_coverage extends uvm_subscriber #(bow_transaction);
  `uvm_component_utils(bow_coverage)
  bow_config cfg;
  bow_transaction tr;

  covergroup bow_cg;
    cp_e0    : coverpoint tr.errs[0] { bins seen = {1}; bins none = {0}; }
    cp_e1    : coverpoint tr.errs[1] { bins seen = {1}; bins none = {0}; }
    cp_e2    : coverpoint tr.errs[2] { bins seen = {1}; bins none = {0}; }
    cp_e3    : coverpoint tr.errs[3] { bins seen = {1}; bins none = {0}; }
    cp_e4    : coverpoint tr.errs[4] { bins seen = {1}; bins none = {0}; }
    cp_words : coverpoint tr.nwords() { bins none = {0}; bins few = {[1:4]}; bins many = {[5:$]}; }
    cp_rep   : coverpoint tr.rep_kind() iff (tr.rep_seen()) { bins one = {1}; bins two = {2}; bins spare_only = {3}; }
    cp_prbs  : coverpoint tr.prbs_seen();
    cp_ready : coverpoint tr.ready_seen();
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    bow_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(bow_config)::get(this, "", "cfg", cfg))
      cfg = bow_config::type_id::create("cfg");
  endfunction

  function void write(bow_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    bow_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("BoW coverage: %0.1f%%", bow_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
