// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_defs.sv -- BoW shared type definitions

package bow_defs_pkg;

  typedef enum bit [1:0] {BOW_OK, BOW_ERR} bow_status_e;

  localparam bit [15:0] BOW_TP    = 16'hF0CA;   // RX training pattern (this model's datasheet)
  localparam int        BOW_ALIGN = 32;         // clock edges before PHYReady
  localparam int        BOW_GMAX  = 512;        // max UI in the clock gated state
  // physical line (0 = AUX, 1..16 = D0..D15, 17 = FEC) of logical data lane j
  function automatic int bow_phys(int j, bit rep, bit [4:0] a, bit [4:0] b);
    int lo = -1, hi = 99;
    bit va = (a <= 5'd17), vb = (b <= 5'd17) && (b != a);
    if (rep) begin
      if (va && vb) begin lo = (a < b) ? a : b; hi = (a < b) ? b : a; end
      else if (va && a >= 5'd1 && a <= 5'd16) lo = a;
      else if (vb && b >= 5'd1 && b <= 5'd16) lo = b;
    end
    if (j + 1 <= lo) return j;
    if (j + 1 >= hi) return j + 2;
    return j + 1;
  endfunction
  function automatic bit bow_bad(int i, bit rep, bit [4:0] a, bit [4:0] b);
    return rep && ((a <= 5'd17 && i == a) || (b <= 5'd17 && i == b));
  endfunction

endpackage
