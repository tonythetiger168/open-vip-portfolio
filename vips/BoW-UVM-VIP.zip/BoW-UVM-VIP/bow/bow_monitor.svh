// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_monitor.svh -- BoW monitor: every bench clock's wires and outputs; an item starts at a forwarded-clock edge or a PHYResetB change (with the static clocks before it) and ends after cfg.gap static clocks

class bow_monitor extends uvm_monitor;
  `uvm_component_utils(bow_monitor)

  virtual bow_if vif;
  uvm_analysis_port #(bow_transaction) ap;
  bow_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual bow_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "bow: virtual interface not set")
    if (!uvm_config_db#(bow_config)::get(this, "", "cfg", cfg))
      cfg = bow_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit started = 0;
      bit pck = 0, prb = 1;
      bit [31:0] pend_mo [$];
      bit [78:0] pend_so [$];
      wait (vif.rst_n === 1'b1);
      forever begin
        bow_transaction t = null;
        int st = 0;
        // static clocks up to the next activity
        forever begin
          bit [31:0] m;
          bit [78:0] o;
          @(vif.mon_cb);
          m = {vif.mon_cb.prbs_en, vif.mon_cb.bad_b, vif.mon_cb.bad_a, vif.mon_cb.rep_en, vif.mon_cb.phy_reset_b,
               vif.mon_cb.ck, vif.mon_cb.fec, vif.mon_cb.aux, vif.mon_cb.d};
          o = {vif.mon_cb.phy_ready, vif.mon_cb.pv, vif.mon_cb.err, vif.mon_cb.paux, vif.mon_cb.pfec, vif.mon_cb.pd};
          if (t == null && (m[18] != pck || m[19] != prb)) begin
            t = bow_transaction::type_id::create("t");
            if (started) begin t.mo = pend_mo; t.so = pend_so; end
            pend_mo.delete(); pend_so.delete();
            started = 1;
          end
          if (t == null) begin
            if (started) begin pend_mo.push_back(m); pend_so.push_back(o); end
          end else begin
            t.mo.push_back(m); t.so.push_back(o);
            if (m[18] != pck || m[19] != prb) st = 0; else st++;
          end
          pck = m[18]; prb = m[19];
          if (t != null && st == cfg.gap) break;
        end
        t.errs = 0;
        foreach (t.so[i]) t.errs |= t.so[i][76:72];
        publish(t);
      end
    end
  endtask

  function void publish(bow_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
