// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_compliance_checker.sv -- BoW concurrent assertion checks (bindable)

module bow_compliance_checker
  (input logic clk, input logic rst_n, input logic phy_reset_b, input logic ck, input logic [15:0] d, input logic aux, input logic fec, input logic rep_en, input logic [4:0] bad_a, input logic [4:0] bad_b, input logic prbs_en, input logic phy_ready, input logic pv, input logic [63:0] pd, input logic [3:0] paux, input logic [3:0] pfec, input logic [4:0] err);

  // outputs are never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({phy_ready, pv, err}))
    else $error("BoW: X on PHYReady / pv / err");
  // a parallel word only comes from a ready slice
  assert property (@(posedge clk) disable iff (!rst_n) pv |-> phy_ready)
    else $error("BoW: word without PHYReady");
  // PHYResetB low takes PHYReady down on the next clock (sec. 6.5.1.1)
  assert property (@(posedge clk) disable iff (!rst_n) !phy_reset_b |=> !phy_ready)
    else $error("BoW: PHYReady while PHYResetB is asserted");
  // PHYReady rises only after a forwarded clock edge (self-alignment, sec. 6.5.1.3)
  assert property (@(posedge clk) disable iff (!rst_n) $rose(phy_ready) |-> $past(phy_reset_b) && $past(ck) != $past(ck, 2))
    else $error("BoW: PHYReady without a clock edge");
  // a gated clock produces no word
  assert property (@(posedge clk) disable iff (!rst_n) phy_ready && $stable(ck) && phy_reset_b |=> !pv)
    else $error("BoW: word while the clock is gated");
  // with redundancy on, AUX / FEC are spares
  assert property (@(posedge clk) disable iff (!rst_n) pv && $past(rep_en) |-> paux == 4'h0 && pfec == 4'h0)
    else $error("BoW: AUX / FEC data with redundancy on");
  // the rule checks the tests break on purpose: covers, not assertions
  cover property (@(posedge clk) disable iff (!rst_n) err[0]);
  cover property (@(posedge clk) disable iff (!rst_n) err[1]);
  cover property (@(posedge clk) disable iff (!rst_n) err[2]);
  cover property (@(posedge clk) disable iff (!rst_n) err[3]);
  cover property (@(posedge clk) disable iff (!rst_n) err[4]);
  cover property (@(posedge clk) disable iff (!rst_n) $rose(phy_ready));
  cover property (@(posedge clk) disable iff (!rst_n) pv && rep_en);
endmodule
