// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// bow_env.sv -- BoW environment: reference-model scoreboard, checker, coverage

package bow_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import bow_defs_pkg::*;
  import bow_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class bow_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(bow_scoreboard)
    uvm_analysis_imp_exp #(bow_transaction, bow_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(bow_transaction, bow_scoreboard) obs_ap;

    bow_config cfg;
    bow_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // the RX slice (scoreboard copy), kept across items
    bit        ckq = 0, rdy = 0, gated = 0, need_pre = 0, last_idle = 1, widle = 1;
    int        edges = 0, ph = 0, g = 0, pn = 0;
    bit [15:0] win [18];
    bit [8:0]  hist [16];
    bit [47:0] wd = 0;
    bit [3:0]  wa = 0, wf = 0;
    bit        o_pv = 0;
    bit [63:0] o_pd = 0;
    bit [3:0]  o_paux = 0, o_pfec = 0;
    bit [4:0]  o_err = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(bow_config)::get(this, "", "cfg", cfg))
        cfg = bow_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(bow_transaction t);
      t.so.delete();
      t.errs = 0;
      foreach (t.mo[k]) begin
        bit [31:0] m = t.mo[k];
        bit        prb = m[31], rep = m[20], rb = m[19], c = m[18];
        bit [4:0]  bb = m[30:26], ba = m[25:21];
        bit [17:0] ln = {m[17], m[15:0], m[16]};
        bit [15:0] lg;
        bit        la, lf, ui_idle, match, perr, wi;
        bit        n_pv = 0;
        bit [4:0]  n_err = 0;
        t.so.push_back({rdy, o_pv, o_err, o_paux, o_pfec, o_pd});
        t.errs |= o_err;
        for (int j = 0; j < 16; j++) lg[j] = ln[bow_phys(j, rep, ba, bb)];
        la = rep ? 1'b0 : ln[0];
        lf = rep ? 1'b0 : ln[17];
        ui_idle = (lg == 0) && !la && !lf;
        match = 1;
        for (int i = 0; i < 18; i++) if (!bow_bad(i, rep, ba, bb) && {win[i][14:0], ln[i]} != BOW_TP) match = 0;
        perr = 0;
        for (int j = 0; j < 16; j++) if (!ui_idle && pn >= 9 && lg[j] != (hist[j][8] ^ hist[j][4])) perr = 1;
        if (!rb) begin
          rdy = 0; edges = 0; ph = 0; gated = 0; g = 0; need_pre = 0; last_idle = 1; widle = 1; pn = 0;
          foreach (win[i]) win[i] = 0;
        end else if (!rdy) begin
          if (c != ckq) begin
            foreach (win[i]) win[i] = {win[i][14:0], ln[i]};
            if (edges < 63) edges++;
            if (edges >= BOW_ALIGN && match) begin rdy = 1; ph = 0; pn = 0; last_idle = 1; gated = 0; end
          end
        end else if (c != ckq) begin
          wi = (ph == 0) ? ui_idle : (widle && ui_idle);
          widle = wi;
          if (gated) need_pre = 1;
          gated = 0; g = 0;
          if (ph == 3) begin
            n_pv = 1; o_pd = {lg, wd}; o_paux = {la, wa[2:0]}; o_pfec = {lf, wf[2:0]};
            last_idle = wi;
            if (need_pre) begin need_pre = 0; if (!wi) n_err[1] = 1; end
          end else begin
            wd[16 * ph +: 16] = lg; wa[ph] = la; wf[ph] = lf;
          end
          ph = (ph + 1) % 4;
          if (prb) begin
            if (perr) n_err[4] = 1;
            for (int j = 0; j < 16; j++) hist[j] = {hist[j][7:0], lg[j]};
            if (ui_idle) pn = 0; else if (pn != 9) pn++;
          end else pn = 0;
        end else begin
          if (!gated) begin
            gated = 1; g = 1;
            if (ph != 0) begin n_err[2] = 1; ph = 0; end
            else if (!last_idle) n_err[1] = 1;
            if (c) n_err[3] = 1;
          end else if (g != BOW_GMAX + 1) begin
            if (g == BOW_GMAX) n_err[0] = 1;
            g++;
          end
        end
        ckq = c;
        o_pv = n_pv;
        o_err = n_err;
      end
    endfunction

    function void write_exp(bow_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(bow_transaction t);
      bow_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        bow_transaction e = exp_q.pop_front();
        bow_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("bow scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class bow_env extends uvm_env;
    `uvm_component_utils(bow_env)
    bow_agent      agt;
    bow_scoreboard sb;
    bow_checker    chk;
    bow_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = bow_agent     ::type_id::create("agt", this);
      sb  = bow_scoreboard::type_id::create("sb",  this);
      chk = bow_checker   ::type_id::create("chk", this);
      cov = bow_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
