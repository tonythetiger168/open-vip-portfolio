// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// lpddr6_env.sv -- LPDDR6 environment: reference-model scoreboard, checker, coverage

package lpddr6_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import lpddr6_defs_pkg::*;
  import lpddr6_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class lpddr6_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(lpddr6_scoreboard)
    uvm_analysis_imp_exp #(lpddr6_transaction, lpddr6_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(lpddr6_transaction, lpddr6_scoreboard) obs_ap;

    lpddr6_config cfg;
    lpddr6_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [63:0] mem [bit [14:0]];   // written locations

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(lpddr6_config)::get(this, "", "cfg", cfg))
        cfg = lpddr6_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(lpddr6_transaction t);
      if (t.sref) t.rdata = 0;   // self-refresh keeps the array contents
      else if (!t.sref && t.write) begin
        mem[{t.bank, t.col}] = t.wdata;
        t.rdata = 0;
      end else
        t.rdata = mem.exists({t.bank, t.col}) ? mem[{t.bank, t.col}] : '0;   // the model's array starts at 0
    endfunction

    function void write_exp(lpddr6_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(lpddr6_transaction t);
      lpddr6_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        lpddr6_transaction e = exp_q.pop_front();
        lpddr6_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("lpddr6 scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class lpddr6_env extends uvm_env;
    `uvm_component_utils(lpddr6_env)
    lpddr6_agent      agt;
    lpddr6_scoreboard sb;
    lpddr6_checker    chk;
    lpddr6_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = lpddr6_agent     ::type_id::create("agt", this);
      sb  = lpddr6_scoreboard::type_id::create("sb",  this);
      chk = lpddr6_checker   ::type_id::create("chk", this);
      cov = lpddr6_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
