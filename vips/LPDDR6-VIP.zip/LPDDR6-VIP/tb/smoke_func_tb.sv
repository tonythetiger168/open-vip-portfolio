// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (LPDDR6 write/read + self-refresh)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened lpddr6_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic cs_n = 1'b1;
  logic act_n = 1'b1;
  logic [1:0] bank = '0;
  logic [13:0] addr = '0;
  logic [63:0] wr_data = '0;
  logic self_ref = 1'b0;
  wire  [63:0] rd_data;
  wire  rd_valid;

  always #5 clk = ~clk;

  lpddr6_model u_dut (
    .clk(clk), .rst_n(rst_n), .cs_n(cs_n),
    .act_n(act_n), .bank(bank), .addr(addr),
    .wr_data(wr_data), .rd_data(rd_data),
    .rd_valid(rd_valid), .self_ref(self_ref)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(rd_valid === 1'b0, "rd_valid quiet in reset");
    @(negedge clk); rst_n = 1'b1;

    // write col0 = DEADBEEF
    @(negedge clk); cs_n = 1'b0; addr = 14'd0;
    wr_data = 64'hDEADBEEF;
    step();
    @(negedge clk); cs_n = 1'b1;
    step();

    // read back: RL=7 total latency
    @(negedge clk); cs_n = 1'b0; addr = 14'd1;
    step();
    @(negedge clk); cs_n = 1'b1;
    repeat (5) begin step(); chk(rd_valid === 1'b0, "read latency respected"); end
    step();
    chk(rd_valid === 1'b1, "rd_valid after RL");
    chk(rd_data === 64'hDEADBEEF, "read data matches write");
    step();
    chk(rd_valid === 1'b0, "rd_valid is a pulse");

    // self-refresh: commands masked, no read data
    @(negedge clk); self_ref = 1'b1;
    @(negedge clk); cs_n = 1'b0; addr = 14'd1;
    step();
    @(negedge clk); cs_n = 1'b1;
    repeat (10) begin step(); chk(rd_valid === 1'b0, "no rd_valid in self-refresh"); end
    @(negedge clk); self_ref = 1'b0;
    step();

    // read returns after self-refresh exit
    @(negedge clk); cs_n = 1'b0; addr = 14'd1;
    step();
    @(negedge clk); cs_n = 1'b1;
    repeat (5) step();
    step();
    chk(rd_valid === 1'b1 && rd_data === 64'hDEADBEEF, "data survives self-refresh");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
