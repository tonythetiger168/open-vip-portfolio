// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- LPDDR6 testbench top with a functional LPDDR6 DUT model

`ifndef LPDDR6_TB_SV
`define LPDDR6_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import lpddr6_defs_pkg::*;
import lpddr6_pkg::*;
import lpddr6_env_pkg::*;
import lpddr6_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  lpddr6_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  lpddr6_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cs_n(vif.cs_n),
    .act_n(vif.act_n),
    .bank(vif.bank),
    .addr(vif.addr),
    .wr_data(vif.wr_data),
    .rd_data(vif.rd_data),
    .rd_valid(vif.rd_valid),
    .self_ref(vif.self_ref)
  );

  // Concurrent protocol checks
  lpddr6_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .cs_n(vif.cs_n), .act_n(vif.act_n), .bank(vif.bank), .addr(vif.addr), .wr_data(vif.wr_data), .rd_data(vif.rd_data), .rd_valid(vif.rd_valid), .self_ref(vif.self_ref)
  );

  initial begin
    uvm_config_db#(virtual lpddr6_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module lpddr6_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        cs_n,
  input  logic        act_n,
  input  logic [1:0]  bank,
  input  logic [13:0] addr,
  input  logic [63:0] wr_data,
  output logic [63:0] rd_data,
  output logic        rd_valid,
  input  logic        self_ref
);
  // simplified LPDDR6: 4 banks x 16k x 64b, RL=6, self-refresh masks commands
  logic [63:0] mem [0:3][0:16383];
  logic [63:0] pipe [0:5];
  logic        rd_pending [0:5];
  integer i, j;
  initial for (i = 0; i < 4; i = i + 1)
            for (j = 0; j < 16384; j = j + 1) mem[i][j] = '0;
  initial rd_valid = 1'b0;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_data <= '0;
      rd_valid <= 1'b0;
      for (i = 0; i < 6; i = i + 1) rd_pending[i] <= 1'b0;
    end else if (!self_ref) begin
      if (!cs_n && act_n && !addr[0])
        mem[bank][addr[13:1]] <= wr_data;
      rd_valid <= rd_pending[5];
      if (rd_pending[5]) rd_data <= pipe[5];
      rd_pending[5] <= rd_pending[4];
      rd_pending[4] <= rd_pending[3];
      rd_pending[3] <= rd_pending[2];
      rd_pending[2] <= rd_pending[1];
      rd_pending[1] <= rd_pending[0];
      rd_pending[0] <= (!cs_n && act_n && addr[0]);
      pipe[0] <= mem[bank][addr[13:1]];
      pipe[1] <= pipe[0];
      pipe[2] <= pipe[1];
      pipe[3] <= pipe[2];
      pipe[4] <= pipe[3];
      pipe[5] <= pipe[4];
    end else begin
      rd_valid <= 1'b0;
      for (i = 0; i < 6; i = i + 1) rd_pending[i] <= 1'b0;
    end
  end
endmodule
`endif
