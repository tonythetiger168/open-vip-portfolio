// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// lpddr6_transaction.svh -- LPDDR6 transaction

class lpddr6_transaction extends uvm_sequence_item;
  `uvm_object_utils(lpddr6_transaction)

  // request (driven by the agent)
  rand bit sref;
  rand bit [4:0] sref_cycles;
  rand bit write;
  rand bit [1:0] bank;
  rand bit [12:0] col;
  rand bit [63:0] wdata;
  // response (returned by the DUT)
  bit [63:0] rdata;
  // bookkeeping (not compared)
  rand bit [13:0] row;
  int unsigned rl;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_sref { sref dist { 0 := 12, 1 := 1 }; sref_cycles inside {[2:20]}; }
  constraint c_data { !write -> wdata == 0; }
  constraint c_col  { col dist { [0:15] := 2, [16:8190] := 1, 8191 := 1 }; }

  function new(string name = "lpddr6_transaction"); super.new(name); endfunction

  function void post_randomize();
    if (!sref) sref_cycles = 0;   // the monitor reports 0 outside self-refresh
    else begin
      write = 0; wdata = 0; col = 0; bank = 0;
    end
  endfunction

  function void do_copy(uvm_object rhs);
    lpddr6_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    sref = rhs_.sref;
    sref_cycles = rhs_.sref_cycles;
    write = rhs_.write;
    bank = rhs_.bank;
    col = rhs_.col;
    wdata = rhs_.wdata;
    rdata = rhs_.rdata;
    row = rhs_.row;
    rl = rhs_.rl;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    lpddr6_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (sref != rhs_.sref) return 0;
    if (sref_cycles != rhs_.sref_cycles) return 0;
    if (write != rhs_.write) return 0;
    if (bank != rhs_.bank) return 0;
    if (col != rhs_.col) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (rdata != rhs_.rdata) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(lpddr6_transaction rhs_);
    if (sref != rhs_.sref) return 0;
    if (sref_cycles != rhs_.sref_cycles) return 0;
    if (write != rhs_.write) return 0;
    if (bank != rhs_.bank) return 0;
    if (col != rhs_.col) return 0;
    if (wdata != rhs_.wdata) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("LPDDR6{tag=%0d sref=0x%0h sref_cycles=0x%0h write=0x%0h bank=0x%0h col=0x%0h wdata=0x%0h rdata=0x%0h}", tag, sref, sref_cycles, write, bank, col, wdata, rdata);
  endfunction
endclass
