// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// lpddr6_compliance_checker.sv -- LPDDR6 concurrent assertion checks (bindable)

module lpddr6_compliance_checker
  (input logic clk, input logic rst_n, input cs_n, input act_n, input [1:0] bank, input [13:0] addr, input [63:0] wr_data, input [63:0] rd_data, input rd_valid, input self_ref);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({rd_data, rd_valid}))
    else $error("LPDDR6: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> rd_data == '0)
    else $error("LPDDR6: output not in reset value");
  // no read data while in self-refresh
  assert property (@(posedge clk) disable iff (!rst_n) self_ref |-> !rd_valid)
    else $error("LPDDR6: rd_valid during self-refresh");
  assert property (@(posedge clk) disable iff (!rst_n) rd_valid |=> !rd_valid || (!cs_n && act_n && addr[0]))
    else $error("LPDDR6: rd_valid stuck high");
  cover property (@(posedge clk) disable iff (!rst_n) (rd_data != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (self_ref == 1'b1 && rd_valid == 1'b0));
endmodule
