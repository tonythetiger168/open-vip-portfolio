// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// lpddr6_pkg.sv -- LPDDR6 UVM VIP package

package lpddr6_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import lpddr6_defs_pkg::*;
  export lpddr6_defs_pkg::*;

  `include "lpddr6_transaction.svh"
  `include "lpddr6_config.svh"
  `include "lpddr6_sequencer.svh"
  `include "lpddr6_driver.svh"
  `include "lpddr6_monitor.svh"
  `include "lpddr6_agent.svh"
  `include "lpddr6_sequences.svh"
  `include "lpddr6_checker.svh"
  `include "lpddr6_coverage.svh"
endpackage
