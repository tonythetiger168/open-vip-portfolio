// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// lpddr6_monitor.svh -- LPDDR6 monitor: decodes observed bus activity

class lpddr6_monitor extends uvm_monitor;
  `uvm_component_utils(lpddr6_monitor)

  virtual lpddr6_if vif;
  uvm_analysis_port #(lpddr6_transaction) ap;
  lpddr6_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual lpddr6_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "lpddr6: virtual interface not set")
    void'(uvm_config_db#(lpddr6_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    lpddr6_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = lpddr6_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.cs_n = vif.cs_n;
        t.act_n = vif.act_n;
        t.bank = vif.bank;
        t.addr = vif.addr;
        t.wr_data = vif.wr_data;
        t.self_ref = vif.self_ref;
        t.rd_data_o = vif.rd_data;
        t.rd_valid_o = vif.rd_valid;
        ap.write(t);
      end
    end
  endtask
endclass
