// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// lpddr6_driver.svh -- LPDDR6 driver: ACT then one RD/WR command; reads wait for rd_valid

class lpddr6_driver extends uvm_driver #(lpddr6_transaction);
  `uvm_component_utils(lpddr6_driver)

  uvm_analysis_port #(lpddr6_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual lpddr6_if vif;
  lpddr6_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual lpddr6_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "lpddr6: virtual interface not set")
    if (!uvm_config_db#(lpddr6_config)::get(this, "", "cfg", cfg))
      cfg = lpddr6_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    lpddr6_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.cs_n <= 1'b1; vif.drv_cb.act_n <= 1'b1; vif.drv_cb.addr <= '0; vif.drv_cb.wr_data <= '0; vif.drv_cb.bank <= '0; vif.drv_cb.self_ref <= 1'b0;
  endtask

  task drive_item(lpddr6_transaction t);
    if (t.sref) begin
      @(vif.drv_cb);
      vif.drv_cb.self_ref <= 1'b1;
      repeat (t.sref_cycles) @(vif.drv_cb);
      vif.drv_cb.self_ref <= 1'b0;
      @(vif.drv_cb);
    end else begin
      // ACTIVATE (ignored by the model; keeps the command stream realistic)
      @(vif.drv_cb);
      vif.drv_cb.cs_n <= 1'b0; vif.drv_cb.act_n <= 1'b0; vif.drv_cb.bank <= t.bank; vif.drv_cb.addr <= t.row;
      // READ (addr[0] = 1) / WRITE (addr[0] = 0) to column addr[13:1]
      @(vif.drv_cb);
      vif.drv_cb.act_n <= 1'b1;
      vif.drv_cb.addr  <= {t.col, !t.write};
      vif.drv_cb.wr_data <= t.write ? t.wdata : '0;
      @(vif.drv_cb);
      vif.drv_cb.cs_n <= 1'b1;
      vif.drv_cb.wr_data <= '0;
      if (!t.write) begin
        int unsigned n = 0;
        do begin @(vif.drv_cb); n++; end while (vif.drv_cb.rd_valid !== 1'b1 && n < cfg.timeout_cycles);
        if (vif.drv_cb.rd_valid !== 1'b1) `uvm_error("TIMEOUT", "LPDDR6: no rd_valid for read")
        t.rdata = vif.drv_cb.rd_data;
        t.rl = n;
      end
    end
  endtask

endclass
