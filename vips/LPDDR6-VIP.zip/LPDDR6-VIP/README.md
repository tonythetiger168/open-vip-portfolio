# LPDDR6 UVM VIP (LPDDR6-VIP)

LPDDR6 UVM VIP: 64-bit low-power DRAM command decode with self-refresh isolation. Write/read data integrity plus power-state quiescence checks.

## Structure

- `lpddr6/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `lpddr6_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `lpddr6_base_test` (constrained-random), `lpddr6_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural LPDDR6 DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/LPDDR6-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh LPDDR6-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py LPDDR6-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
