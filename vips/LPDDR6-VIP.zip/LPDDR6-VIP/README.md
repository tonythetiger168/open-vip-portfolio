# LPDDR6 UVM VIP (LPDDR6-VIP)

LPDDR6 UVM VIP: 64-bit low-power DRAM command decode with self-refresh isolation. Write/read data integrity plus power-state quiescence checks.

## Structure

- `lpddr6/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `lpddr6_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `lpddr6_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural LPDDR6 DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/LPDDR6-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh LPDDR6-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
