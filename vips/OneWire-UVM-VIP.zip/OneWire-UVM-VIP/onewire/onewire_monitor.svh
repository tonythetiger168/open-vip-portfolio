// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_monitor.svh -- 1-Wire monitor: decodes observed bus activity

class onewire_monitor extends uvm_monitor;
  `uvm_component_utils(onewire_monitor)

  virtual onewire_if vif;
  uvm_analysis_port #(onewire_transaction) ap;
  onewire_config cfg;
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual onewire_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "onewire: virtual interface not set")
    void'(uvm_config_db#(onewire_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    onewire_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = onewire_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.dq_o = vif.dq_o;
        t.dq_oe = vif.dq_oe;
        t.presence_o = vif.presence;
        t.dq_o = vif.dq;
        ap.write(t);
      end
    end
  endtask
endclass
