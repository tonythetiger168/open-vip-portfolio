// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_monitor.svh -- 1-Wire monitor: master low pulses on dq: resets (with presence) and byte-wise time slots

class onewire_monitor extends uvm_monitor;
  `uvm_component_utils(onewire_monitor)

  virtual onewire_if vif;
  uvm_analysis_port #(onewire_transaction) ap;
  onewire_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual onewire_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "onewire: virtual interface not set")
    if (!uvm_config_db#(onewire_config)::get(this, "", "cfg", cfg))
      cfg = onewire_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      int unsigned nbit = 0;
      bit [7:0] wb = 0, rb = 0;
      forever begin
        @(vif.mon_cb);
        if (master_low()) begin                  // first clock of a master low pulse
          int unsigned low = 1, c = 0;
          bit rv = 1, released = 0;
          // measure the low time; the line is sampled sample_clk clocks in
          while (!released || c < cfg.sample_clk) begin
            @(vif.mon_cb); c++;
            if (c == cfg.sample_clk) rv = (vif.mon_cb.dq !== 1'b0);
            if (!released) begin
              if (master_low()) low++; else released = 1;
            end
            if (released && low >= 8) break;
            if (c > 10 * cfg.slot_clks) break;
          end
          if (low >= 8) begin                    // reset: look for the presence pulse
            onewire_transaction t = onewire_transaction::type_id::create("t");
            if (nbit != 0) `uvm_error("MON", "1-Wire reset inside a byte")
            nbit = 0;
            t.is_reset = 1;
            for (int i = 0; i < cfg.presence_win; i++) begin
              if (i != 0) @(vif.mon_cb);
              if (vif.mon_cb.dq === 1'b0 && !master_low()) t.presence = 1;
            end
            publish(t);
          end else begin                         // time slot: short low writes 1 (or reads)
            wb[nbit] = (low < cfg.low0_clks);
            rb[nbit] = rv;
            nbit++;
            if (nbit == 8) begin
              onewire_transaction t = onewire_transaction::type_id::create("t");
              t.wdata = wb; t.rdata = rb;
              publish(t);
              nbit = 0;
            end
          end
        end
      end
    end
  endtask

  function void publish(onewire_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  function bit master_low();
    return vif.mon_cb.dq_oe === 1'b1 && vif.mon_cb.dq_o === 1'b0;
  endfunction
endclass
