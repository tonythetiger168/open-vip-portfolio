// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_transaction.svh -- 1-Wire transaction

class onewire_transaction extends uvm_sequence_item;
  `uvm_object_utils(onewire_transaction)

  rand bit dq_o;
  rand bit dq_oe;
  bit presence_o;
  bit dq_o;
  bit [31:0] tag;

  function new(string name = "onewire_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    onewire_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    dq_o = rhs_.dq_o;
    dq_oe = rhs_.dq_oe;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    onewire_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           dq_o == rhs_.dq_o &&
           dq_oe == rhs_.dq_oe;
  endfunction

  function string convert2string();
    return $sformatf("1-Wire{tag=%0h dq_o=0x%0h dq_oe=0x%0h}", tag, dq_o, dq_oe);
  endfunction
endclass
