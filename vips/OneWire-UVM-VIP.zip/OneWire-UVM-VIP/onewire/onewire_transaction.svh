// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_transaction.svh -- 1-Wire transaction

class onewire_transaction extends uvm_sequence_item;
  `uvm_object_utils(onewire_transaction)

  // request (driven by the agent)
  rand bit is_reset;
  rand bit [7:0] wdata;
  // response (returned by the DUT)
  bit presence;
  bit [7:0] rdata;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { is_reset dist { 0 := 4, 1 := 1 }; is_reset -> wdata == 0; }

  function new(string name = "onewire_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    onewire_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    is_reset = rhs_.is_reset;
    wdata = rhs_.wdata;
    presence = rhs_.presence;
    rdata = rhs_.rdata;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    onewire_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (is_reset != rhs_.is_reset) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (presence != rhs_.presence) return 0;
    if (rdata != rhs_.rdata) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(onewire_transaction rhs_);
    if (is_reset != rhs_.is_reset) return 0;
    if (wdata != rhs_.wdata) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("1-Wire{tag=%0d is_reset=0x%0h wdata=0x%0h presence=0x%0h rdata=0x%0h}", tag, is_reset, wdata, presence, rdata);
  endfunction
endclass
