// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_pkg.sv -- 1-Wire UVM VIP package

package onewire_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import onewire_defs_pkg::*;
  export onewire_defs_pkg::*;

  `include "onewire_transaction.svh"
  `include "onewire_config.svh"
  `include "onewire_sequencer.svh"
  `include "onewire_driver.svh"
  `include "onewire_monitor.svh"
  `include "onewire_agent.svh"
  `include "onewire_sequences.svh"
  `include "onewire_checker.svh"
  `include "onewire_coverage.svh"
endpackage
