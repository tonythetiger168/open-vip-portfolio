// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_compliance_checker.sv -- 1-Wire concurrent assertion checks (bindable)

module onewire_compliance_checker
  (input logic clk, input logic rst_n, input dq_o, input dq_oe, input dq, input presence);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(presence))
    else $error("1-Wire: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> presence == '0)
    else $error("1-Wire: output not in reset value");
  // presence pulse is a bounded response
  assert property (@(posedge clk) disable iff (!rst_n) $rose(presence) |-> strong(##[1:16] !presence))
    else $error("1W: presence pulse too long");
  cover property (@(posedge clk) disable iff (!rst_n) (presence != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (presence == 1'b1));
endmodule
