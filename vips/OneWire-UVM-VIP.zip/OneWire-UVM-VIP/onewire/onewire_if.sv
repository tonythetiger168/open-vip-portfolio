// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_if.sv -- 1-Wire interface

interface onewire_if (input logic clk);
  logic rst_n;

  logic dq_o;
  logic dq_oe;
  tri1 dq;
  logic presence;
  assign dq = (dq_oe && !dq_o) ? 1'b0 : 1'bz;

  modport DUT (input clk, rst_n, dq_o, dq_oe, output presence, inout dq);
  modport DRV (input clk, rst_n, presence, dq, output dq_o, dq_oe);
  modport MON (input clk, rst_n, dq_o, dq_oe, dq, presence);

  clocking drv_cb @(posedge clk);
    input rst_n, dq_o, dq_oe, dq, presence;
    output dq_o, dq_oe;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, dq_o, dq_oe, dq, presence;
  endclocking
endinterface
