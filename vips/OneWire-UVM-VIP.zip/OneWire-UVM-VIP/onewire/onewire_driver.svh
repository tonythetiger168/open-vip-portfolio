// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_driver.svh -- 1-Wire driver: reset/presence detect, or eight write/read time slots (LSB first)

class onewire_driver extends uvm_driver #(onewire_transaction);
  `uvm_component_utils(onewire_driver)

  uvm_analysis_port #(onewire_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual onewire_if vif;
  onewire_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual onewire_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "onewire: virtual interface not set")
    if (!uvm_config_db#(onewire_config)::get(this, "", "cfg", cfg))
      cfg = onewire_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    onewire_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.dq_oe <= 1'b0; vif.drv_cb.dq_o <= 1'b1;
  endtask

  task drive_item(onewire_transaction t);
    @(vif.drv_cb);
    if (t.is_reset) begin
      vif.drv_cb.dq_oe <= 1'b1; vif.drv_cb.dq_o <= 1'b0;
      repeat (cfg.reset_low) @(vif.drv_cb);
      vif.drv_cb.dq_oe <= 1'b0;
      t.presence = 0;
      repeat (cfg.presence_win) begin
        @(vif.drv_cb);
        if (vif.drv_cb.dq === 1'b0) t.presence = 1;
      end
      repeat (4) @(vif.drv_cb);
    end else begin
      for (int i = 0; i < 8; i++) begin
        int unsigned low = t.wdata[i] ? cfg.low1_clks : cfg.low0_clks;
        vif.drv_cb.dq_oe <= 1'b1; vif.drv_cb.dq_o <= 1'b0;
        for (int c = 0; c < cfg.slot_clks; c++) begin
          @(vif.drv_cb);
          if (c + 1 == low) vif.drv_cb.dq_oe <= 1'b0;
          if (c == cfg.sample_clk) t.rdata[i] = (vif.drv_cb.dq !== 1'b0);
        end
      end
    end
  endtask

endclass
