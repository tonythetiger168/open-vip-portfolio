// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_coverage.svh -- 1-Wire functional coverage

class onewire_coverage extends uvm_subscriber #(onewire_transaction);
  `uvm_component_utils(onewire_coverage)
  onewire_config cfg;
  onewire_transaction tr;

  covergroup onewire_cg;
    coverpoint tr.dq_o;
    coverpoint tr.dq_oe;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(onewire_config)::get(this, "*", "cfg", cfg));
    onewire_cg = new();
  endfunction

  function void write(onewire_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    onewire_cg.sample();
  endfunction
endclass
