// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_coverage.svh -- 1-Wire functional coverage

class onewire_coverage extends uvm_subscriber #(onewire_transaction);
  `uvm_component_utils(onewire_coverage)
  onewire_config cfg;
  onewire_transaction tr;

  covergroup onewire_cg;
    cp_kind : coverpoint tr.is_reset { bins reset = {1}; bins data = {0}; }
    cp_data : coverpoint tr.wdata iff (!tr.is_reset) { bins zero = {8'h00}; bins ones = {8'hFF}; bins other = default; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    onewire_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(onewire_config)::get(this, "", "cfg", cfg))
      cfg = onewire_config::type_id::create("cfg");
  endfunction

  function void write(onewire_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    onewire_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("1-Wire coverage: %0.1f%%", onewire_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
