// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_config.svh -- 1-Wire agent configuration

class onewire_config extends uvm_object;
  `uvm_object_utils(onewire_config)
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  bit coverage_enable = 1;
  bit checks_enable   = 1;
  int unsigned num_items      = 32;     // random items per base sequence
  int unsigned timeout_cycles = 1000;   // handshake / response watchdog
  int unsigned reset_low  = 10;  // reset pulse (model detects >= 8; >= 17 re-triggers it)
  int unsigned presence_win = 16; // clocks after the reset pulse to look for presence
  int unsigned slot_clks  = 10;  // time slot
  int unsigned low0_clks  = 4;   // write-0 low time (< 8: not a reset)
  int unsigned low1_clks  = 1;   // write-1 / read low time
  int unsigned sample_clk = 3;   // master samples the line this many clocks into the slot
  function new(string name = "onewire_config"); super.new(name); endfunction
endclass
