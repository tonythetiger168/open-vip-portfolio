// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// onewire_sequences.svh -- 1-Wire sequences

// Random traffic: cfg.num_items constrained-random items.
class onewire_base_sequence extends uvm_sequence #(onewire_transaction);
  `uvm_object_utils(onewire_base_sequence)
  onewire_config cfg;

  function new(string name = "onewire_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = onewire_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "onewire_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class onewire_directed_sequence extends uvm_sequence #(onewire_transaction);
  `uvm_object_utils(onewire_directed_sequence)
  onewire_config cfg;

  function new(string name = "onewire_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function onewire_transaction item();
    item = onewire_transaction::type_id::create("req");
  endfunction

  task send(onewire_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    onewire_transaction t;
    t = item(); t.is_reset = 1; send(t);
    t = item(); t.wdata = 8'hCC; send(t);   // Skip ROM
    t = item(); t.wdata = 8'h44; send(t);   // Convert T
    t = item(); t.is_reset = 1; send(t);
    t = item(); t.wdata = 8'h33; send(t);   // Read ROM
    t = item(); t.wdata = 8'hFF; send(t);   // read slots
    t = item(); t.wdata = 8'h00; send(t);
    t = item(); t.is_reset = 1; send(t);
  endtask
endclass
