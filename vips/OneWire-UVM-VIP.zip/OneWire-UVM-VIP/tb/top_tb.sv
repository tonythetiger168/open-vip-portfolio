// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- 1-Wire testbench top with a functional 1-Wire DUT model

`ifndef 1-Wire_TB_SV
`define 1-Wire_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import onewire_defs_pkg::*;
import onewire_pkg::*;
import onewire_env_pkg::*;
import onewire_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  onewire_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  onewire_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .dq(vif.dq), .presence(vif.presence)
  );

  // Concurrent protocol checks
  onewire_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .dq_o(vif.dq_o), .dq_oe(vif.dq_oe), .dq(vif.dq), .presence(vif.presence)
  );

  initial begin
    uvm_config_db#(virtual onewire_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module onewire_model (
  input  logic clk,
  input  logic rst_n,
  inout  logic dq,
  output logic presence
);
  // master drives the line through the interface resolution
  logic [3:0] low_cnt;
  logic [3:0] pres_cnt;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      low_cnt  <= '0;
      pres_cnt <= '0;
      presence <= 1'b0;
    end else begin
      if (dq == 1'b0 && low_cnt != 4'hF)
        low_cnt <= low_cnt + 1'b1;
      else if (dq == 1'b1)
        low_cnt <= '0;
      // reset pulse detected: respond with a presence pulse
      if (low_cnt >= 4'd8) begin
        pres_cnt <= 4'd6;
        low_cnt  <= '0;
      end else if (pres_cnt != 0)
        pres_cnt <= pres_cnt - 1'b1;
      presence <= (pres_cnt != 0);
    end
  end
  assign dq = presence ? 1'b0 : 1'bz;
endmodule
`endif
