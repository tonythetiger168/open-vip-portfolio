// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (1-Wire reset/presence sequence)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened onewire_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic dq_o = 1'b0;
  logic dq_oe = 1'b0;
  tri1  dq;
  assign dq = (dq_oe && !dq_o) ? 1'b0 : 1'bz;
  wire  presence;

  always #5 clk = ~clk;

  onewire_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .dq(dq), .presence(presence)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(presence === 1'b0, "presence reset low");
    chk(dq === 1'b1, "dq pulled high (tri1) when idle");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // no reset pulse -> no presence
    repeat (12) begin
      step();
      chk(presence === 1'b0, "no presence without reset pulse");
    end

    // master reset pulse: pull dq low >= 8 cycles, then release
    @(negedge clk); dq_oe = 1'b1; dq_o = 1'b0;
    repeat (10) step();
    @(negedge clk); dq_oe = 1'b0;
    step(); step();

    // presence must appear within a few cycles and be bounded (4..16 cycles)
    begin : pres
      int to = 0;
      while (presence !== 1'b1 && to < 20) begin step(); to++; end
      chk(presence === 1'b1, "presence pulse after reset pulse");
      chk(dq === 1'b0, "dq driven low during presence");
      while (presence === 1'b1 && to < 60) begin step(); to++; end
      chk(presence === 1'b0, "presence pulse terminated (bounded)");
      chk(to < 60, "presence pulse bounded in time");
    end

    // idle again
    repeat (6) begin step(); chk(presence === 1'b0, "back to idle"); end
    chk(dq === 1'b1, "dq released high after presence");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
