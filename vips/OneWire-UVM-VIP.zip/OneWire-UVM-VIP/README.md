# 1-Wire UVM VIP (OneWire-UVM-VIP)

Dallas/Maxim 1-Wire UVM VIP: open-drain master/slave signalling with reset/presence detection model. Complements the 1-Wire RTL IP from the open-ip-portfolio sister project.

## Structure

- `onewire/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `onewire_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `onewire_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural 1-Wire DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/OneWire-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh OneWire-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
