// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ddr_pkg.sv -- DDR protocol VIP package (companion model)
`ifndef DDR_PKG_SV
`define DDR_PKG_SV
package ddr_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class ddr_seq_item extends uvm_sequence_item;
    `uvm_object_utils(ddr_seq_item)
    rand bit [2:0] cmd_type;   // 0=NOP 1=ACT 2=RD 3=WR 4=PRE 5=REF
    rand bit [2:0] bank;
    rand bit [1:0] bank_group;
    rand bit [7:0] burst_len;
    rand bit [16:0] addr;
    constraint c_bl { burst_len inside {8, 16, 32, 64}; }
    rand int unsigned delay;
    constraint c_delay { delay inside {[0:20]}; }
    function new(string name = "ddr_seq_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("DDR item");
    endfunction
  endclass

  class ddr_cfg extends uvm_object;
    `uvm_object_utils(ddr_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    function new(string name = "ddr_cfg"); super.new(name); endfunction
  endclass

  class ddr_sequencer extends uvm_sequencer #(ddr_seq_item);
    `uvm_component_utils(ddr_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  class ddr_driver extends uvm_driver #(ddr_seq_item);
    `uvm_component_utils(ddr_driver)
    virtual ddr_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "DDR virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      ddr_seq_item req;
      vif.drv_cb.cs_n <= 1; vif.drv_cb.act_n <= 1;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        repeat (req.delay) @(vif.drv_cb);
        vif.drv_cb.ba   <= req.bank;
        vif.drv_cb.bg   <= req.bank_group;
        vif.drv_cb.addr <= req.addr;
        vif.drv_cb.cs_n <= 0;
        vif.drv_cb.act_n <= (req.cmd_type != 3'd1);
        vif.drv_cb.ras_n <= (req.cmd_type != 3'd4 && req.cmd_type != 3'd5);
        vif.drv_cb.cas_n <= (req.cmd_type != 3'd2 && req.cmd_type != 3'd3 && req.cmd_type != 3'd5);
        vif.drv_cb.we_n  <= (req.cmd_type != 3'd3);
        @(vif.drv_cb);
        vif.drv_cb.cs_n <= 1;
        seq_item_port.item_done();
      end
    endtask
  endclass

  class ddr_monitor extends uvm_monitor;
    `uvm_component_utils(ddr_monitor)
    virtual ddr_if vif;
    uvm_analysis_port #(ddr_seq_item) item_collected_port;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "DDR virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      ddr_seq_item item;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) continue;
        if (!vif.mon_cb.cs_n) begin
          item = ddr_seq_item::type_id::create("item");
          item.bank = vif.mon_cb.ba;
          item.bank_group = vif.mon_cb.bg;
          item.addr = vif.mon_cb.addr;
          item.cmd_type = !vif.mon_cb.act_n ? 3'd1 :
                          (!vif.mon_cb.we_n ? 3'd3 :
                          (!vif.mon_cb.cas_n ? 3'd2 :
                          (!vif.mon_cb.ras_n ? 3'd4 : 3'd0)));
          item_collected_port.write(item);
        end
      end
    endtask
  endclass

  class ddr_agent extends uvm_agent;
    `uvm_component_utils(ddr_agent)
    ddr_sequencer sqr;
    ddr_driver    drv;
    ddr_monitor   mon;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = ddr_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = ddr_sequencer::type_id::create("sqr", this);
        drv = ddr_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  class ddr_base_seq extends uvm_sequence #(ddr_seq_item);
    `uvm_object_utils(ddr_base_seq)
    function new(string name = "ddr_base_seq"); super.new(name); endfunction
  endclass

  class ddr_rw_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_rw_seq)
    rand int num_trans = 30;
    function new(string name = "ddr_rw_seq"); super.new(name); endfunction
    task body();
      ddr_seq_item item;
      repeat (num_trans) begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize()) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass

  class ddr_cov_cmd_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_cmd_seq)
    function new(string name = "ddr_cov_cmd_seq"); super.new(name); endfunction
    task body();
      ddr_seq_item item;
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd4; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd5; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
  class ddr_cov_bank_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_bank_seq)
    function new(string name = "ddr_cov_bank_seq"); super.new(name); endfunction
    task body();
      ddr_seq_item item;
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd4; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd5; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd6; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd7; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
  class ddr_cov_bl_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_bl_seq)
    function new(string name = "ddr_cov_bl_seq"); super.new(name); endfunction
    task body();
      ddr_seq_item item;
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { burst_len == 8'd8; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { burst_len == 8'd16; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { burst_len == 8'd32; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { burst_len == 8'd64; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
endpackage
`endif
