// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// UniPro-Mem Timing & Performance Checker
// Validates tRCD, tRP, tRAS, tCL, bandwidth, and latency
// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
`ifndef UNIPRO_MEM_TIMING_CHECKER_SV
`define UNIPRO_MEM_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module unipro_mem_timing_checker (unipro_if vif);
  property p_unipro_power; @(posedge vif.clk) disable iff (!vif.rst_n) vif.power_mode inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_unipro_power: assert property(p_unipro_power) else `uvm_warning("UNIPRO-MEM_TIM", "Power mode valid violated");
  cover_p_unipro_power: cover property(p_unipro_power);
  property p_unipro_transfer; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sof == 1 |-> ##[1:32] vif.eof == 1; endproperty
  assert_p_unipro_transfer: assert property(p_unipro_transfer) else `uvm_warning("UNIPRO-MEM_TIM", "Transfer complete violated");
  cover_p_unipro_transfer: cover property(p_unipro_transfer);
endmodule
`endif
