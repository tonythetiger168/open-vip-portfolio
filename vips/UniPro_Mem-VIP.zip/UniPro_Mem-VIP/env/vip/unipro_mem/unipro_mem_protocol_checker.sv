// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// UniPro-Mem Protocol Compliance Checker
// Validates protocol state machine, field ranges, and command sequences
// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
`ifndef UNIPRO_MEM_PROTOCOL_CHECKER_SV
`define UNIPRO_MEM_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module unipro_mem_protocol_checker (unipro_if vif);
  property p_unipro_cp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cp_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_unipro_cp: assert property(p_unipro_cp) else `uvm_warning("UNIPRO-MEM_CHK", "Connection phase valid failed");
  cover_p_unipro_cp: cover property(p_unipro_cp);
  property p_unipro_tc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tc <= 3'd7; endproperty
  assert_p_unipro_tc: assert property(p_unipro_tc) else `uvm_warning("UNIPRO-MEM_CHK", "Traffic class valid failed");
  cover_p_unipro_tc: cover property(p_unipro_tc);
  property p_unipro_vc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vc <= 4'd15; endproperty
  assert_p_unipro_vc: assert property(p_unipro_vc) else `uvm_warning("UNIPRO-MEM_CHK", "Virtual channel valid failed");
  cover_p_unipro_vc: cover property(p_unipro_vc);
  property p_unipro_nack; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err == 1 |-> vif.valid == 1; endproperty
  assert_p_unipro_nack: assert property(p_unipro_nack) else `uvm_warning("UNIPRO-MEM_CHK", "NACK valid failed");
  cover_p_unipro_nack: cover property(p_unipro_nack);
endmodule
`endif
