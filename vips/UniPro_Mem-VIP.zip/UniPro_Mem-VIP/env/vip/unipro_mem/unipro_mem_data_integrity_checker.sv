// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// UniPro-Mem Data Integrity Checker
// Validates CRC, ECC, data consistency, and mask operations
// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
`ifndef UNIPRO_MEM_DATA_INTEGRITY_CHECKER_SV
`define UNIPRO_MEM_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module unipro_mem_data_integrity_checker (unipro_if vif);
  property p_unipro_eof; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eof == 1 |-> $past(vif.sof,1) || vif.sof == 1; endproperty
  assert_p_unipro_eof: assert property(p_unipro_eof) else `uvm_warning("UNIPRO-MEM_DI", "EOF follows SOF failed");
  cover_p_unipro_eof: cover property(p_unipro_eof);
  property p_unipro_credit; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tx_cred <= 8'd255; endproperty
  assert_p_unipro_credit: assert property(p_unipro_credit) else `uvm_warning("UNIPRO-MEM_DI", "Credit valid failed");
  cover_p_unipro_credit: cover property(p_unipro_credit);
endmodule
`endif
