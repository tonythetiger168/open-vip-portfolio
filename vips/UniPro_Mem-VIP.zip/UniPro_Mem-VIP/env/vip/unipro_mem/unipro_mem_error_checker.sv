// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// UniPro-Mem Error Handling Checker
// Validates error injection, recovery, reset behavior, and abort sequences
// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
`ifndef UNIPRO_MEM_ERROR_CHECKER_SV
`define UNIPRO_MEM_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module unipro_mem_error_checker (unipro_if vif);
  property p_unipro_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid == 1 |-> !$isunknown(vif.data); endproperty
  assert_p_unipro_no_x: assert property(p_unipro_no_x) else `uvm_warning("UNIPRO-MEM_ERR", "No X when valid failed");
  cover_p_unipro_no_x: cover property(p_unipro_no_x);
  property p_unipro_nack_retry; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err == 1 |-> ##[1:16] vif.sof == 1; endproperty
  assert_p_unipro_nack_retry: assert property(p_unipro_nack_retry) else `uvm_warning("UNIPRO-MEM_ERR", "NACK retry failed");
  cover_p_unipro_nack_retry: cover property(p_unipro_nack_retry);
endmodule
`endif
