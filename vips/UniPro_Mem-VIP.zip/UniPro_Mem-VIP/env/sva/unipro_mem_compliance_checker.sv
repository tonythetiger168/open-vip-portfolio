// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// unipro_mem_compliance_checker.sv -- UniPro_Mem tiered compliance SVA checker
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced | L4=Protocol-Specific
`ifndef UNIPRO_MEM_COMPLIANCE_CHECKER_SV
`define UNIPRO_MEM_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module unipro_mem_compliance_checker (unipro_if vif);
  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_unipro_mem_cmd_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_unipro_mem_cmd_valid: assert property(p_unipro_mem_cmd_valid) l1_pass[0]++; else begin `uvm_warning("UNIPRO_MEM_L1", "cmd valid failed"); l1_fail[0]++; end
  cover_p_unipro_mem_cmd_valid: cover property(p_unipro_mem_cmd_valid);
  property p_unipro_mem_reset; @(posedge vif.clk) !vif.rst_n |-> !vif.valid; endproperty
  assert_p_unipro_mem_reset: assert property(p_unipro_mem_reset) l1_pass[1]++; else begin `uvm_warning("UNIPRO_MEM_L1", "reset failed"); l1_fail[1]++; end
  cover_p_unipro_mem_reset: cover property(p_unipro_mem_reset);
  property p_unipro_mem_sof_eof; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sof |-> s_eventually vif.eof; endproperty
  assert_p_unipro_mem_sof_eof: assert property(p_unipro_mem_sof_eof) l1_pass[2]++; else begin `uvm_warning("UNIPRO_MEM_L1", "sof/eof failed"); l1_fail[2]++; end
  cover_p_unipro_mem_sof_eof: cover property(p_unipro_mem_sof_eof);
  property p_unipro_mem_power; @(posedge vif.clk) disable iff (!vif.rst_n) vif.power_mode inside {3'b000, 3'b001, 3'b010, 3'b100}; endproperty
  assert_p_unipro_mem_power: assert property(p_unipro_mem_power) l1_pass[3]++; else begin `uvm_warning("UNIPRO_MEM_L1", "power failed"); l1_fail[3]++; end
  cover_p_unipro_mem_power: cover property(p_unipro_mem_power);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_unipro_mem_cp_state; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cp_state <= 3'd7; endproperty
  assert_p_unipro_mem_cp_state: assert property(p_unipro_mem_cp_state) l2_pass[0]++; else begin `uvm_warning("UNIPRO_MEM_L2", "cp state failed"); l2_fail[0]++; end
  cover_p_unipro_mem_cp_state: cover property(p_unipro_mem_cp_state);
  property p_unipro_mem_tc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.tc <= 3'd7; endproperty
  assert_p_unipro_mem_tc: assert property(p_unipro_mem_tc) l2_pass[1]++; else begin `uvm_warning("UNIPRO_MEM_L2", "tc failed"); l2_fail[1]++; end
  cover_p_unipro_mem_tc: cover property(p_unipro_mem_tc);
  property p_unipro_mem_err; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err |-> vif.valid; endproperty
  assert_p_unipro_mem_err: assert property(p_unipro_mem_err) l2_pass[2]++; else begin `uvm_warning("UNIPRO_MEM_L2", "err failed"); l2_fail[2]++; end
  cover_p_unipro_mem_err: cover property(p_unipro_mem_err);
  property p_unipro_mem_ready; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> ##[0:10] vif.ready; endproperty
  assert_p_unipro_mem_ready: assert property(p_unipro_mem_ready) l2_pass[3]++; else begin `uvm_warning("UNIPRO_MEM_L2", "ready failed"); l2_fail[3]++; end
  cover_p_unipro_mem_ready: cover property(p_unipro_mem_ready);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_unipro_mem_status; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ready |-> vif.status != 2'b11; endproperty
  assert_p_unipro_mem_status: assert property(p_unipro_mem_status) l3_pass[0]++; else begin `uvm_warning("UNIPRO_MEM_L3", "status failed"); l3_fail[0]++; end
  cover_p_unipro_mem_status: cover property(p_unipro_mem_status);
  property p_unipro_mem_pwr_state; @(posedge vif.clk) disable iff (!vif.rst_n) vif.power_state inside {3'b000, 3'b010, 3'b011, 3'b101}; endproperty
  assert_p_unipro_mem_pwr_state: assert property(p_unipro_mem_pwr_state) l3_pass[1]++; else begin `uvm_warning("UNIPRO_MEM_L3", "power state failed"); l3_fail[1]++; end
  cover_p_unipro_mem_pwr_state: cover property(p_unipro_mem_pwr_state);
  property p_unipro_mem_eop_next; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eof |=> !vif.sof; endproperty
  assert_p_unipro_mem_eop_next: assert property(p_unipro_mem_eop_next) l3_pass[2]++; else begin `uvm_warning("UNIPRO_MEM_L3", "eop/next failed"); l3_fail[2]++; end
  cover_p_unipro_mem_eop_next: cover property(p_unipro_mem_eop_next);
  property p_unipro_mem_valid_stable; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && !vif.ready) |=> vif.valid; endproperty
  assert_p_unipro_mem_valid_stable: assert property(p_unipro_mem_valid_stable) l3_pass[3]++; else begin `uvm_warning("UNIPRO_MEM_L3", "valid stable failed"); l3_fail[3]++; end
  cover_p_unipro_mem_valid_stable: cover property(p_unipro_mem_valid_stable);

  // ---------------- L4: UniPro protocol-specific rules (4) ----------------
  property p_unipro_mem_l4_sof_eof_pair; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.sof) |-> (!vif.sof throughout (vif.eof [->1])); endproperty
  assert_p_unipro_mem_l4_sof_eof_pair: assert property(p_unipro_mem_l4_sof_eof_pair) l4_pass[0]++; else begin `uvm_warning("UNIPRO_MEM_L4", "SOF overlap failed"); l4_fail[0]++; end
  cover_p_unipro_mem_l4_sof_eof_pair: cover property(p_unipro_mem_l4_sof_eof_pair);
  property p_unipro_mem_l4_credit_frame; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && vif.sof) |-> vif.cp_state == 3'b010; endproperty
  assert_p_unipro_mem_l4_credit_frame: assert property(p_unipro_mem_l4_credit_frame) l4_pass[1]++; else begin `uvm_warning("UNIPRO_MEM_L4", "frame while not connected failed"); l4_fail[1]++; end
  cover_p_unipro_mem_l4_credit_frame: cover property(p_unipro_mem_l4_credit_frame);
  property p_unipro_mem_l4_err_recover; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err |-> s_eventually !vif.err; endproperty
  assert_p_unipro_mem_l4_err_recover: assert property(p_unipro_mem_l4_err_recover) l4_pass[2]++; else begin `uvm_warning("UNIPRO_MEM_L4", "error not recovered failed"); l4_fail[2]++; end
  cover_p_unipro_mem_l4_err_recover: cover property(p_unipro_mem_l4_err_recover);
  property p_unipro_mem_l4_pwr_idle; @(posedge vif.clk) disable iff (!vif.rst_n) $changed(vif.power_mode) |-> !vif.valid; endproperty
  assert_p_unipro_mem_l4_pwr_idle: assert property(p_unipro_mem_l4_pwr_idle) l4_pass[3]++; else begin `uvm_warning("UNIPRO_MEM_L4", "power change during traffic failed"); l4_fail[3]++; end
  cover_p_unipro_mem_l4_pwr_idle: cover property(p_unipro_mem_l4_pwr_idle);

  final begin : sva_report
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("UNIPRO_MEM_RPT", $sformatf("=== UniPro_Mem Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("UNIPRO_MEM_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("UNIPRO_MEM_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("UNIPRO_MEM_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("UNIPRO_MEM_RPT", $sformatf("  L4 Protocol Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("UNIPRO_MEM_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
