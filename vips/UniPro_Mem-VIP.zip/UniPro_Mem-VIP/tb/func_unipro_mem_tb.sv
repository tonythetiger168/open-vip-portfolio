// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_unipro_mem_tb.sv -- self-checking functional test for the UniPro
// endpoint model and the UFS/eMMC loopback stubs of tb_top.sv (flattened by
// smoke/flatten.py). Run: python3 tools/run_func_tests.py UniPro_Mem-VIP
//
// Model contract (from tb_top.sv); every output is registered one clock
// later (with a #1ns delay):
//   * unipro_endpoint_dut: tx_data/tx_data_valid loop back to rx_data/
//     rx_data_valid; rx_cred = tx_cred + 1, with rx_cred_valid on any data
//     or credit transfer; data 0xFF is an error frame (err for one clock,
//     err_frames++), status is 2'b10 the clock after an error and 2'b01
//     otherwise; ready follows valid; rx_frames counts data transfers.
//   * ufs_device_dut / emmc_device_dut: data_out (cmd) loops back to data_in
//     (resp) with its valid; eMMC busy stays low.

`timescale 1ns/1ps

module func_unipro_mem_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic       clk = 1'b0, rst_n = 1'b0;
  logic [7:0] tx_cred = '0, tx_data = '0, ufs_out = '0;
  logic       tx_cred_valid = 0, tx_data_valid = 0, valid = 0, ufs_valid = 0, cmd = 0, cmd_valid = 0;
  wire  [7:0] rx_cred, rx_data, ufs_in;
  wire        rx_cred_valid, rx_data_valid, ready, err, ufs_in_valid, resp, resp_valid, busy;
  wire  [2:0] pwr;
  wire  [1:0] status;

  always #5 clk = ~clk;

  unipro_endpoint_dut u_ep (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_tx_cred(tx_cred), .vif_rx_cred(rx_cred),
    .vif_tx_cred_valid(tx_cred_valid), .vif_rx_cred_valid(rx_cred_valid),
    .vif_tx_data(tx_data), .vif_rx_data(rx_data), .vif_tx_data_valid(tx_data_valid),
    .vif_rx_data_valid(rx_data_valid), .vif_valid(valid), .vif_ready(ready),
    .vif_power_state(pwr), .vif_status(status), .vif_err(err)
  );
  ufs_device_dut u_ufs (
    .vif_ref_clk(clk), .vif_rst_n(rst_n), .vif_data_out(ufs_out), .vif_data_in(ufs_in),
    .vif_data_out_valid(ufs_valid), .vif_data_in_valid(ufs_in_valid)
  );
  emmc_device_dut u_emmc (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_cmd(cmd), .vif_cmd_valid(cmd_valid), .vif_resp(resp),
    .vif_resp_valid(resp_valid), .vif_busy(busy)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // loop-back scoreboards (sampled at negedge, after the #1ns output delay)
  logic [7:0] exp_q[$], got_q[$];
  always @(negedge clk) if (rst_n && rx_data_valid) got_q.push_back(rx_data);

  function automatic bit same_q();
    if (got_q.size() != exp_q.size()) return 0;
    foreach (got_q[i]) if (got_q[i] !== exp_q[i]) return 0;
    return 1;
  endfunction

  int errs_seen;
  always @(negedge clk) if (err) errs_seen++;

  initial begin
    repeat (2) @(negedge clk);
    chk(!rx_data_valid && !ready && status == 2'b00 && !err && pwr == 0, "outputs cleared in reset");
    chk(rx_data === 8'h00 && rx_cred === 8'h00 && rx_cred_valid === 1'b0, "data and credit outputs cleared in reset");
    chk(resp === 1'b0 && resp_valid === 1'b0 && busy === 1'b0 && ufs_in === 8'h00 && ufs_in_valid === 1'b0,
        "eMMC / UFS stub outputs cleared in reset");
    rst_n = 1;
    @(negedge clk);
    chk(status == 2'b01, "status OK after reset");

    // data loopback stream
    for (int i = 0; i < 32; i++) begin
      @(negedge clk);
      tx_data_valid = (i % 5 != 4);             // with gaps
      tx_data = 8'h10 + i;
      if (tx_data_valid) exp_q.push_back(tx_data);
    end
    @(negedge clk); tx_data_valid = 0;
    repeat (2) @(negedge clk);
    chk(same_q(), $sformatf("data looped back in order with gaps (%0d of %0d)", got_q.size(), exp_q.size()));
    chk(u_ep.rx_frames == exp_q.size(), "rx_frames counts data transfers");
    chk(errs_seen == 0 && status == 2'b01, "no error for ordinary data");

    // one-clock latency
    @(negedge clk); tx_data_valid = 1; tx_data = 8'h5A;
    @(negedge clk); tx_data_valid = 0;
    chk(rx_data_valid === 1'b1 && rx_data == 8'h5A, "output registered one clock later");

    // credits
    @(negedge clk); tx_cred_valid = 1; tx_cred = 8'h07;
    @(negedge clk); tx_cred_valid = 0;
    chk(rx_cred_valid && rx_cred == 8'h08, "credit returned as tx_cred + 1");
    tx_cred = 8'hFF; tx_cred_valid = 1;
    @(negedge clk); tx_cred_valid = 0;
    chk(rx_cred == 8'h00, "credit counter wraps at 8 bits");
    @(negedge clk);
    chk(!rx_cred_valid, "rx_cred_valid only with a transfer");
    tx_data_valid = 1; tx_data = 8'h01;
    @(negedge clk); tx_data_valid = 0;
    chk(rx_cred_valid, "data transfer also returns a credit");

    // error frame
    errs_seen = 0;
    @(negedge clk); tx_data_valid = 1; tx_data = 8'hFF;
    @(negedge clk); tx_data_valid = 0;
    chk(err === 1'b1, "data 0xFF flags an error");
    @(negedge clk);
    chk(!err && status == 2'b10, "status reports the error the next clock");
    @(negedge clk);
    chk(status == 2'b01 && errs_seen == 1 && u_ep.err_frames == 1, "error is a single-clock event, counted once");
    @(negedge clk); tx_data_valid = 0; tx_data = 8'hFF;
    @(negedge clk);
    chk(!err, "0xFF without data valid is not an error");

    // ready handshake
    valid = 1; @(negedge clk);
    chk(ready, "ready follows valid");
    valid = 0; @(negedge clk);
    chk(!ready, "ready drops with valid");

    // UFS and eMMC loopback stubs
    ufs_valid = 1; ufs_out = 8'hC3; cmd_valid = 1; cmd = 1;
    @(negedge clk);
    chk(ufs_in_valid && ufs_in == 8'hC3, "UFS stub loops data_out back to data_in");
    chk(resp_valid && resp && !busy, "eMMC stub echoes cmd as resp, never busy");
    ufs_valid = 0; cmd_valid = 0;
    @(negedge clk);
    chk(!ufs_in_valid && !resp_valid, "stub valids drop");

    // reset
    tx_data_valid = 1; tx_data = 8'hFF;
    @(negedge clk); rst_n = 0;
    #2;     // the reset branch of this delayed-NBA process lands 1ns late on Verilator
    chk(!rx_data_valid && !err && status == 2'b00, "asynchronous reset clears the endpoint");
    rst_n = 1; tx_data_valid = 0;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
