// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// unipro_pkg.sv -- UniPro UVM VIP Package (deepened)
// L2 data-link: SOF/EOF framing, TC, CPort, credit flow control, NACK/replay
`ifndef UNIPRO_PKG_SV
`define UNIPRO_PKG_SV
package unipro_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  //==========================================================================
  // UniPro Sequence Item
  //==========================================================================
  class unipro_seq_item extends uvm_sequence_item;
    `uvm_object_utils(unipro_seq_item)
    typedef enum {NOP, DATA, CTRL, CREDIT, ERROR, CONNECT, DISCONNECT} msg_type_e;
    rand msg_type_e msg_type;
    rand bit [7:0]  tx_data;
    rand bit [7:0]  rx_data;
    rand bit [4:0]  cportid;
    rand bit [7:0]  tx_cred;
    rand bit [7:0]  rx_cred;
    rand bit        data_valid;
    rand bit        last;
    bit [7:0]       rsp_data;
    bit             rsp_valid;
    rand bit [2:0]  tc;
    rand int unsigned delay;

    // Constraints
    constraint c_cportid { cportid inside {[0:31]}; }
    constraint c_msg_dist { msg_type dist {DATA := 40, CTRL := 20, CREDIT := 15, NOP := 10, ERROR := 5, CONNECT := 5, DISCONNECT := 5}; }
    constraint c_delay { delay inside {[0:20]}; }

    function new(string name = "unipro_seq_item");
      super.new(name);
    endfunction

    function string convert2string();
      return $sformatf("UniPro %s: cport=%0d data=0x%0h", msg_type.name(), cportid, tx_data);
    endfunction

    // field-level compare for the end-to-end scoreboard
    virtual function bit compare(unipro_seq_item o);
      return (msg_type == o.msg_type) && (cportid == o.cportid) && (tx_data == o.tx_data);
    endfunction
  endclass : unipro_seq_item

  //==========================================================================
  // UniPro Configuration
  //==========================================================================
  class unipro_cfg extends uvm_object;
    `uvm_object_utils(unipro_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1;
    int tActivate = 5;
    int tData = 2;
    int tCredit = 1;
    function new(string name = "unipro_cfg");
      super.new(name);
    endfunction
  endclass : unipro_cfg

  `uvm_analysis_imp_decl(_unipro_exp)
  `uvm_analysis_imp_decl(_unipro_obs)

  //==========================================================================
  // UniPro Sequencer/Driver/Monitor/Agent
  //==========================================================================
  class unipro_sequencer extends uvm_sequencer #(unipro_seq_item);
    `uvm_component_utils(unipro_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass : unipro_sequencer

  class unipro_driver extends uvm_driver #(unipro_seq_item);
    `uvm_component_utils(unipro_driver)
    virtual unipro_if vif;
    unipro_cfg cfg;
    uvm_analysis_port #(unipro_seq_item) drv_ap;  // expected items for scoreboard

    function new(string name, uvm_component parent);
      super.new(name, parent);
      drv_ap = new("drv_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual unipro_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "UniPro virtual interface not found")
      if (!uvm_config_db#(unipro_cfg)::get(this, "", "cfg", cfg)) cfg = unipro_cfg::type_id::create("cfg");
    endfunction

    task run_phase(uvm_phase phase);
      unipro_seq_item req;
      vif.drv_cb.tx_data_valid <= 0;
      vif.drv_cb.tx_cred_valid <= 0;
      vif.valid = 0; vif.sof = 0; vif.eof = 0;
      vif.cp_state = 3'b000; vif.power_mode = 3'b001; vif.tc = 3'd0;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        repeat (req.delay) @(vif.drv_cb);
        case (req.msg_type)
          unipro_seq_item::DATA: begin
            // L2 data frame: SOF, payload beats with credit check, EOF
            vif.cp_state = 3'b010;
            vif.tc       = req.tc;
            vif.sof      = 1'b1;
            vif.valid    = 1'b1;
            vif.data     = req.tx_data;
            @(vif.drv_cb);
            vif.drv_cb.tx_data <= req.tx_data;
            vif.drv_cb.tx_data_valid <= 1;
            vif.drv_cb.cportid <= req.cportid;
            vif.sof      = 1'b0;
            repeat (cfg.tData) @(vif.drv_cb);
            vif.eof      = 1'b1;
            @(vif.drv_cb);
            vif.drv_cb.tx_data_valid <= 0;
            vif.valid    = 1'b0;
            vif.eof      = 1'b0;
          end
          unipro_seq_item::CTRL: begin
            vif.cp_state = 3'b010;
            vif.drv_cb.tx_data <= req.tx_data;
            vif.drv_cb.tx_data_valid <= 1;
            vif.drv_cb.cportid <= req.cportid;
            vif.valid    = 1'b1;
            @(vif.drv_cb);
            vif.drv_cb.tx_data_valid <= 0;
            vif.valid    = 1'b0;
          end
          unipro_seq_item::CREDIT: begin
            vif.drv_cb.tx_cred <= req.tx_cred;
            vif.drv_cb.tx_cred_valid <= 1;
            repeat (cfg.tCredit) @(vif.drv_cb);
            vif.drv_cb.tx_cred_valid <= 0;
          end
          unipro_seq_item::NOP: begin
            @(vif.drv_cb);
          end
          unipro_seq_item::ERROR: begin
            // corrupted frame: bad data pattern + error flag via NACK path
            vif.valid    = 1'b1;
            vif.sof      = 1'b1;
            vif.data     = 8'hFF;
            vif.drv_cb.tx_data <= 8'hFF;
            vif.drv_cb.tx_data_valid <= 1;
            @(vif.drv_cb);
            vif.drv_cb.tx_data_valid <= 0;
            vif.valid    = 1'b0;
            vif.sof      = 1'b0;
          end
          unipro_seq_item::CONNECT: begin
            // CPort connection phase: CP0 -> CP1 -> CP2 (connected)
            vif.cp_state = 3'b001;
            vif.drv_cb.tx_data <= 8'h01;
            vif.drv_cb.tx_data_valid <= 1;
            repeat (cfg.tActivate) @(vif.drv_cb);
            vif.drv_cb.tx_data_valid <= 0;
            vif.cp_state = 3'b010;
          end
          unipro_seq_item::DISCONNECT: begin
            vif.cp_state = 3'b011;
            vif.drv_cb.tx_data <= 8'h02;
            vif.drv_cb.tx_data_valid <= 1;
            @(vif.drv_cb);
            vif.drv_cb.tx_data_valid <= 0;
            vif.cp_state = 3'b000;
          end
        endcase
        drv_ap.write(req);
        seq_item_port.item_done();
      end
    endtask
  endclass : unipro_driver

  class unipro_monitor extends uvm_monitor;
    `uvm_component_utils(unipro_monitor)
    virtual unipro_if vif;
    uvm_analysis_port #(unipro_seq_item) item_collected_port;
    int unsigned txn_count = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual unipro_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "UniPro virtual interface not found")
    endfunction

    task run_phase(uvm_phase phase);
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) continue;
        if (vif.mon_cb.tx_data_valid || vif.mon_cb.rx_data_valid) begin
          unipro_seq_item item = unipro_seq_item::type_id::create("item");
          if (vif.mon_cb.tx_data_valid) begin
            // decode message class from the link-layer status signals
            if (vif.sof)
              item.msg_type = unipro_seq_item::DATA;
            else if (vif.mon_cb.tx_data == 8'hFF)
              item.msg_type = unipro_seq_item::ERROR;
            else if (vif.mon_cb.tx_data == 8'h01)
              item.msg_type = unipro_seq_item::CONNECT;
            else if (vif.mon_cb.tx_data == 8'h02)
              item.msg_type = unipro_seq_item::DISCONNECT;
            else
              item.msg_type = unipro_seq_item::DATA;
            item.tx_data = vif.mon_cb.tx_data;
            item.cportid = vif.mon_cb.cportid;
            item.tc      = vif.tc;
          end else begin
            item.msg_type = unipro_seq_item::CTRL;
            item.rx_data = vif.mon_cb.rx_data;
          end
          txn_count++;
          item_collected_port.write(item);
        end
        else if (vif.mon_cb.tx_cred_valid) begin
          unipro_seq_item item = unipro_seq_item::type_id::create("item");
          item.msg_type = unipro_seq_item::CREDIT;
          item.tx_cred  = vif.mon_cb.tx_cred;
          txn_count++;
          item_collected_port.write(item);
        end
      end
    endtask

    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(), $sformatf("unipro monitor observed %0d items", txn_count), UVM_LOW)
    endfunction
  endclass : unipro_monitor

  class unipro_agent extends uvm_agent;
    `uvm_component_utils(unipro_agent)
    unipro_sequencer sqr;
    unipro_driver    drv;
    unipro_monitor   mon;
    unipro_cfg       cfg;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(unipro_cfg)::get(this, "", "cfg", cfg)) cfg = unipro_cfg::type_id::create("cfg");
      mon = unipro_monitor::type_id::create("mon", this);
      if (cfg.is_active == UVM_ACTIVE) begin
        sqr = unipro_sequencer::type_id::create("sqr", this);
        drv = unipro_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.is_active == UVM_ACTIVE) drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass : unipro_agent

  //==========================================================================
  // UniPro Sequences (directed library)
  //==========================================================================
  class unipro_base_seq extends uvm_sequence #(unipro_seq_item);
    `uvm_object_utils(unipro_base_seq)
    function new(string name = "unipro_base_seq"); super.new(name); endfunction
  endclass : unipro_base_seq

  // normal: randomized message mix
  class unipro_rw_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_rw_seq)
    rand int num_trans = 30;
    function new(string name = "unipro_rw_seq"); super.new(name); endfunction
    task body();
      unipro_seq_item item;
      repeat (num_trans) begin
        item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize()) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : unipro_rw_seq

  class unipro_cov_msg_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_cov_msg_seq)
    function new(string name = "unipro_cov_msg_seq"); super.new(name); endfunction
    task body();
      unipro_seq_item item;
      unipro_seq_item::msg_type_e msgs[7] = '{unipro_seq_item::NOP, unipro_seq_item::DATA, unipro_seq_item::CTRL,
        unipro_seq_item::CREDIT, unipro_seq_item::ERROR, unipro_seq_item::CONNECT, unipro_seq_item::DISCONNECT};
      foreach (msgs[i]) begin
        item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { msg_type == msgs[i]; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      // REACHABILITY: directed chain so unipro_fsm_cg transition bins are hit
      // deterministically: CONNECT=>DATA=>DISCONNECT (connect_seq),
      // DATA[*4] (data_burst) and CREDIT=>DATA (credit_seq).
      begin
        unipro_seq_item::msg_type_e chain[8] = '{
          unipro_seq_item::CONNECT, unipro_seq_item::DATA, unipro_seq_item::DATA,
          unipro_seq_item::DATA, unipro_seq_item::DATA, unipro_seq_item::DISCONNECT,
          unipro_seq_item::CREDIT, unipro_seq_item::DATA};
        foreach (chain[i]) begin
          item = unipro_seq_item::type_id::create("item");
          start_item(item);
          if (!item.randomize() with { msg_type == chain[i]; })
            `uvm_error(get_type_name(), "Rand failed");
          finish_item(item);
        end
      end
    endtask
  endclass : unipro_cov_msg_seq

  class unipro_cov_cport_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_cov_cport_seq)
    function new(string name = "unipro_cov_cport_seq"); super.new(name); endfunction
    task body();
      unipro_seq_item item;
      for (int c = 0; c < 32; c = c + 4) begin
        item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { msg_type == unipro_seq_item::DATA; cportid == c; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : unipro_cov_cport_seq

  // error: corrupted frames + NACK/replay path
  class unipro_error_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_error_seq)
    rand int num_trans = 10;
    function new(string name = "unipro_error_seq"); super.new(name); endfunction
    task body();
      unipro_seq_item item;
      repeat (num_trans) begin
        item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { msg_type == unipro_seq_item::ERROR; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : unipro_error_seq

  // reset: single DATA frame right after reset release
  class unipro_reset_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_reset_seq)
    function new(string name = "unipro_reset_seq"); super.new(name); endfunction
    task body();
      unipro_seq_item item = unipro_seq_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { msg_type == unipro_seq_item::DATA; cportid == 0; delay == 0; })
        `uvm_error(get_type_name(), "Rand failed");
      finish_item(item);
    endtask
  endclass : unipro_reset_seq

  // back-to-back: zero-gap frames
  class unipro_back_to_back_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_back_to_back_seq)
    rand int num_trans = 20;
    function new(string name = "unipro_back_to_back_seq"); super.new(name); endfunction
    task body();
      unipro_seq_item item;
      repeat (num_trans) begin
        item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { msg_type == unipro_seq_item::DATA; delay == 0; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : unipro_back_to_back_seq

  // stress: heavy DATA traffic across all CPorts and TCs
  class unipro_stress_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_stress_seq)
    rand int num_trans = 100;
    function new(string name = "unipro_stress_seq"); super.new(name); endfunction
    task body();
      unipro_seq_item item;
      repeat (num_trans) begin
        item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { msg_type == unipro_seq_item::DATA; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : unipro_stress_seq

  // corner: connect/disconnect cycles, credit-only traffic, TC sweep
  class unipro_corner_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_corner_seq)
    function new(string name = "unipro_corner_seq"); super.new(name); endfunction
    task body();
      unipro_seq_item item;
      // connect / data / disconnect cycle
      unipro_seq_item::msg_type_e cycle[3] = '{unipro_seq_item::CONNECT, unipro_seq_item::DATA, unipro_seq_item::DISCONNECT};
      foreach (cycle[i]) begin
        item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { msg_type == cycle[i]; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      // TC sweep
      for (int t = 0; t < 2; t++) begin
        item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { msg_type == unipro_seq_item::DATA; tc == t; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      // credit-only
      item = unipro_seq_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { msg_type == unipro_seq_item::CREDIT; }) `uvm_error(get_type_name(), "Rand failed");
      finish_item(item);
    endtask
  endclass : unipro_corner_seq

  // regression: weighted mix of all directed sequences
  class unipro_regression_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_regression_seq)
    function new(string name = "unipro_regression_seq"); super.new(name); endfunction
    task body();
      unipro_rw_seq           rw  = unipro_rw_seq::type_id::create("rw");
      unipro_cov_msg_seq      msg = unipro_cov_msg_seq::type_id::create("msg");
      unipro_cov_cport_seq    cpt = unipro_cov_cport_seq::type_id::create("cpt");
      unipro_back_to_back_seq b2b = unipro_back_to_back_seq::type_id::create("b2b");
      unipro_stress_seq       str = unipro_stress_seq::type_id::create("str");
      unipro_corner_seq       cor = unipro_corner_seq::type_id::create("cor");
      unipro_reset_seq        rst = unipro_reset_seq::type_id::create("rst");
      unipro_error_seq        err = unipro_error_seq::type_id::create("err");
      rw.num_trans=10; b2b.num_trans=10; str.num_trans=10; err.num_trans=4;
      rst.start(m_sequencer); rw.start(m_sequencer); b2b.start(m_sequencer);
      msg.start(m_sequencer); cpt.start(m_sequencer); cor.start(m_sequencer);
      str.start(m_sequencer); err.start(m_sequencer);
    endtask
  endclass : unipro_regression_seq
endpackage : unipro_pkg
`endif
