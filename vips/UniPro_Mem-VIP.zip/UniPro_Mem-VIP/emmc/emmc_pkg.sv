// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// emmc_pkg.sv -- EMMC protocol VIP package (companion model)
`ifndef EMMC_PKG_SV
`define EMMC_PKG_SV
package emmc_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class emmc_seq_item extends uvm_sequence_item;
    `uvm_object_utils(emmc_seq_item)
    rand bit [5:0] cmd_type;
    rand bit [1:0] bus_width;
    rand bit [31:0] arg;
    constraint c_bw { bus_width inside {0, 1, 2}; }
    rand int unsigned delay;
    constraint c_delay { delay inside {[0:20]}; }
    function new(string name = "emmc_seq_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("EMMC item");
    endfunction
  endclass

  class emmc_cfg extends uvm_object;
    `uvm_object_utils(emmc_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    function new(string name = "emmc_cfg"); super.new(name); endfunction
  endclass

  class emmc_sequencer extends uvm_sequencer #(emmc_seq_item);
    `uvm_component_utils(emmc_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  class emmc_driver extends uvm_driver #(emmc_seq_item);
    `uvm_component_utils(emmc_driver)
    virtual emmc_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual emmc_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "EMMC virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      emmc_seq_item req;
      vif.drv_cb.cmd_valid <= 0;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        repeat (req.delay) @(vif.drv_cb);
        vif.drv_cb.cmd_index <= req.cmd_type;
        vif.drv_cb.cmd_arg   <= req.arg;
        vif.drv_cb.cmd_valid <= 1;
        do @(vif.drv_cb); while (vif.drv_cb.busy);
        vif.drv_cb.cmd_valid <= 0;
        seq_item_port.item_done();
      end
    endtask
  endclass

  class emmc_monitor extends uvm_monitor;
    `uvm_component_utils(emmc_monitor)
    virtual emmc_if vif;
    uvm_analysis_port #(emmc_seq_item) item_collected_port;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual emmc_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "EMMC virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      emmc_seq_item item;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) continue;
        if (vif.mon_cb.cmd_valid) begin
          item = emmc_seq_item::type_id::create("item");
          item.cmd_type = vif.mon_cb.cmd_index;
          item.arg = vif.mon_cb.cmd_arg;
          item.bus_width = 2'd2;
          item_collected_port.write(item);
        end
      end
    endtask
  endclass

  class emmc_agent extends uvm_agent;
    `uvm_component_utils(emmc_agent)
    emmc_sequencer sqr;
    emmc_driver    drv;
    emmc_monitor   mon;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = emmc_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = emmc_sequencer::type_id::create("sqr", this);
        drv = emmc_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  class emmc_base_seq extends uvm_sequence #(emmc_seq_item);
    `uvm_object_utils(emmc_base_seq)
    function new(string name = "emmc_base_seq"); super.new(name); endfunction
  endclass

  class emmc_rw_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_rw_seq)
    rand int num_trans = 30;
    function new(string name = "emmc_rw_seq"); super.new(name); endfunction
    task body();
      emmc_seq_item item;
      repeat (num_trans) begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize()) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass

  class emmc_cov_cmd_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_cov_cmd_seq)
    function new(string name = "emmc_cov_cmd_seq"); super.new(name); endfunction
    task body();
      emmc_seq_item item;
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd6; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd7; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd8; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd12; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd17; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd18; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd24; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd25; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
  class emmc_cov_bw_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_cov_bw_seq)
    function new(string name = "emmc_cov_bw_seq"); super.new(name); endfunction
    task body();
      emmc_seq_item item;
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bus_width == 2'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bus_width == 2'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bus_width == 2'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
endpackage
`endif
