// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tb_top.sv -- 8-protocol top-level testbench
// Closed loop: UniPro VIP driver -> unipro_if -> functional UniPro endpoint DUT
`timescale 1ns/1ps
`ifndef TB_TOP_SV
`define TB_TOP_SV
import uvm_pkg::*;
`include "uvm_macros.svh"
import memory_test_pkg::*;

module tb_top;
  logic ddr_ck = 0, ddr_rst_n = 0;
  logic lpddr_ck = 0, lpddr_rst_n = 0;
  logic hbm_ck = 0, hbm_rst_n = 0;
  logic ufs_clk = 0, ufs_rst_n = 0;
  logic unipro_clk = 0, unipro_rst_n = 0;
  logic emmc_clk = 0, emmc_rst_n = 0;
  logic onfi_clk = 0, onfi_rst_n = 0;
  logic sd_clk = 0, sd_rst_n = 0;
  always #5 ddr_ck = ~ddr_ck;
  always #5 lpddr_ck = ~lpddr_ck;
  always #5 hbm_ck = ~hbm_ck;
  always #10 ufs_clk = ~ufs_clk;
  always #10 unipro_clk = ~unipro_clk;
  always #20 emmc_clk = ~emmc_clk;
  always #50 onfi_clk = ~onfi_clk;
  always #20 sd_clk = ~sd_clk;
  initial begin
    #100;
    ddr_rst_n = 1; lpddr_rst_n = 1; hbm_rst_n = 1; ufs_rst_n = 1;
    unipro_rst_n = 1; emmc_rst_n = 1; onfi_rst_n = 1; sd_rst_n = 1;
  end

  ddr_if    ddr_if_inst    (.ck(ddr_ck), .ck_n(~ddr_ck), .rst_n(ddr_rst_n));
  lpddr_if  lpddr_if_inst  (.ck(lpddr_ck), .ck_n(~lpddr_ck), .cke(1'b1), .rst_n(lpddr_rst_n));
  hbm_if    hbm_if_inst    (.ck(hbm_ck), .ck_n(~hbm_ck), .rst_n(hbm_rst_n));
  ufs_if    ufs_if_inst    (.ref_clk(ufs_clk), .rst_n(ufs_rst_n));
  unipro_if unipro_if_inst (.clk(unipro_clk), .rst_n(unipro_rst_n));
  emmc_if   emmc_if_inst   (.clk(emmc_clk), .rst_n(emmc_rst_n));
  onfi_if   onfi_if_inst   (.clk(onfi_clk), .rst_n(onfi_rst_n));
  sd_if     sd_if_inst     (.clk(sd_clk), .rst_n(sd_rst_n));

  // functional DUT models (closed loop)
  unipro_endpoint_dut unipro_ep (.vif(unipro_if_inst));
  emmc_device_dut     emmc_dev  (.vif(emmc_if_inst));
  onfi_flash_dut      onfi_dev  (.vif(onfi_if_inst));
  ufs_device_dut      ufs_dev   (.vif(ufs_if_inst));

  // UniPro protocol/timing/integrity SVA checkers
  unipro_mem_compliance_checker      u_unipro_mem_compliance      (.vif(unipro_if_inst));
  unipro_mem_protocol_checker        u_unipro_mem_protocol        (.vif(unipro_if_inst));
  unipro_mem_timing_checker          u_unipro_mem_timing          (.vif(unipro_if_inst));
  unipro_mem_error_checker           u_unipro_mem_error           (.vif(unipro_if_inst));
  unipro_mem_data_integrity_checker  u_unipro_mem_data_integrity  (.vif(unipro_if_inst));

  initial begin
    uvm_config_db#(virtual ddr_if)::set(null, "*.ddr_*", "vif", ddr_if_inst);
    uvm_config_db#(virtual lpddr_if)::set(null, "*.lpddr_*", "vif", lpddr_if_inst);
    uvm_config_db#(virtual hbm_if)::set(null, "*.hbm_*", "vif", hbm_if_inst);
    uvm_config_db#(virtual ufs_if)::set(null, "*.ufs_*", "vif", ufs_if_inst);
    uvm_config_db#(virtual unipro_if)::set(null, "*.unipro_*", "vif", unipro_if_inst);
    uvm_config_db#(virtual emmc_if)::set(null, "*.emmc_*", "vif", emmc_if_inst);
    uvm_config_db#(virtual onfi_if)::set(null, "*.onfi_*", "vif", onfi_if_inst);
    uvm_config_db#(virtual sd_if)::set(null, "*.sd_*", "vif", sd_if_inst);
    run_test();
  end
endmodule

//--------------------------------------------------------------------------
// Functional UniPro endpoint DUT model:
//  - returns L2 credits on reception (credit-based flow control)
//  - echoes received data back on the RX path (loopback)
//  - flags 0xFF frames as errors (error-injection detection)
//--------------------------------------------------------------------------
module unipro_endpoint_dut (unipro_if vif);
  int unsigned rx_frames = 0;
  int unsigned err_frames = 0;
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin : ep
    if (!vif.rst_n) begin : rst
      vif.rx_data <= 0; vif.rx_data_valid <= 0;
      vif.rx_cred <= 0; vif.rx_cred_valid <= 0;
      vif.ready <= 1'b0; vif.status <= 2'b00;
      vif.power_state <= 3'b000; vif.err <= 1'b0;
    end else begin : run
      // accept L2 frames, loop data back on RX path
      vif.ready <= #1ns vif.valid;
      vif.rx_data_valid <= #1ns vif.tx_data_valid;
      vif.rx_data <= #1ns vif.tx_data;
      // credit return after a credit request/data frame
      vif.rx_cred_valid <= #1ns (vif.tx_data_valid || vif.tx_cred_valid);
      vif.rx_cred <= #1ns vif.tx_cred + 8'd1;
      // error flag on corrupted frames
      vif.err <= #1ns (vif.tx_data_valid && (vif.tx_data == 8'hFF));
      vif.status <= #1ns vif.err ? 2'b10 : 2'b01;
      if (vif.tx_data_valid) rx_frames <= rx_frames + 1;
      if (vif.err) err_frames <= err_frames + 1;
    end
  end
  final begin : rpt
    `uvm_info("UNIPRO_EP", $sformatf("endpoint: rx_frames=%0d err_frames=%0d", rx_frames, err_frames), UVM_LOW)
  end
endmodule

// eMMC device model: response + busy handshake
module emmc_device_dut (emmc_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) begin
      vif.resp <= 0; vif.resp_valid <= 0; vif.busy <= 0;
    end else begin
      vif.resp_valid <= #1ns vif.cmd_valid;
      vif.resp <= #1ns vif.cmd;
      vif.busy <= #1ns 1'b0;
    end
endmodule

// ONFI flash model: ready/busy handshake
module onfi_flash_dut (onfi_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) vif.rb_n <= 1'b1;
    else            vif.rb_n <= #1ns 1'b1;
endmodule

// UFS device model: data-in loopback
module ufs_device_dut (ufs_if vif);
  always_ff @(posedge vif.ref_clk or negedge vif.rst_n)
    if (!vif.rst_n) begin
      vif.data_in <= 0; vif.data_in_valid <= 0;
    end else begin
      vif.data_in_valid <= #1ns vif.data_out_valid;
      vif.data_in <= #1ns vif.data_out;
    end
endmodule
`endif
