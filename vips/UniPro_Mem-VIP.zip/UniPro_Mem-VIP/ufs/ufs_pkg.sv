// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ufs_pkg.sv -- UFS protocol VIP package (companion model)
`ifndef UFS_PKG_SV
`define UFS_PKG_SV
package ufs_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class ufs_seq_item extends uvm_sequence_item;
    `uvm_object_utils(ufs_seq_item)
    rand bit [3:0] upiu_type;
    rand bit [7:0] lun;
    rand bit [7:0] data;
    constraint c_upiu { upiu_type inside {4'h00, 4'h01, 4'h02, 4'h16, 4'h21, 4'h22, 4'h31}; }
    rand int unsigned delay;
    constraint c_delay { delay inside {[0:20]}; }
    function new(string name = "ufs_seq_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("UFS item");
    endfunction
  endclass

  class ufs_cfg extends uvm_object;
    `uvm_object_utils(ufs_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    function new(string name = "ufs_cfg"); super.new(name); endfunction
  endclass

  class ufs_sequencer extends uvm_sequencer #(ufs_seq_item);
    `uvm_component_utils(ufs_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  class ufs_driver extends uvm_driver #(ufs_seq_item);
    `uvm_component_utils(ufs_driver)
    virtual ufs_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ufs_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "UFS virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      ufs_seq_item req;
      vif.drv_cb.data_out_valid <= 0;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        repeat (req.delay) @(vif.drv_cb);
        vif.drv_cb.data_out <= req.data;
        vif.drv_cb.task_tag <= req.lun;
        vif.drv_cb.data_out_valid <= 1;
        @(vif.drv_cb);
        vif.drv_cb.data_out_valid <= 0;
        seq_item_port.item_done();
      end
    endtask
  endclass

  class ufs_monitor extends uvm_monitor;
    `uvm_component_utils(ufs_monitor)
    virtual ufs_if vif;
    uvm_analysis_port #(ufs_seq_item) item_collected_port;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ufs_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "UFS virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      ufs_seq_item item;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) continue;
        if (vif.mon_cb.data_out_valid) begin
          item = ufs_seq_item::type_id::create("item");
          item.data = vif.mon_cb.data_out;
          item.lun  = vif.mon_cb.task_tag;
          item.upiu_type = 4'h02;
          item_collected_port.write(item);
        end
      end
    endtask
  endclass

  class ufs_agent extends uvm_agent;
    `uvm_component_utils(ufs_agent)
    ufs_sequencer sqr;
    ufs_driver    drv;
    ufs_monitor   mon;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = ufs_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = ufs_sequencer::type_id::create("sqr", this);
        drv = ufs_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  class ufs_base_seq extends uvm_sequence #(ufs_seq_item);
    `uvm_object_utils(ufs_base_seq)
    function new(string name = "ufs_base_seq"); super.new(name); endfunction
  endclass

  class ufs_rw_seq extends ufs_base_seq;
    `uvm_object_utils(ufs_rw_seq)
    rand int num_trans = 30;
    function new(string name = "ufs_rw_seq"); super.new(name); endfunction
    task body();
      ufs_seq_item item;
      repeat (num_trans) begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize()) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass

  class ufs_cov_upiu_seq extends ufs_base_seq;
    `uvm_object_utils(ufs_cov_upiu_seq)
    function new(string name = "ufs_cov_upiu_seq"); super.new(name); endfunction
    task body();
      ufs_seq_item item;
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { upiu_type == 4'h00; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { upiu_type == 4'h01; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { upiu_type == 4'h02; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { upiu_type == 4'h16; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { upiu_type == 4'h21; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { upiu_type == 4'h22; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { upiu_type == 4'h31; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
  class ufs_cov_lun_seq extends ufs_base_seq;
    `uvm_object_utils(ufs_cov_lun_seq)
    function new(string name = "ufs_cov_lun_seq"); super.new(name); endfunction
    task body();
      ufs_seq_item item;
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { lun == 8'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { lun == 8'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { lun == 8'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { lun == 8'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { lun == 8'd4; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { lun == 8'd5; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { lun == 8'd6; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = ufs_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { lun == 8'd7; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
endpackage
`endif
