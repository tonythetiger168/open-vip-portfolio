// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm_pkg.sv -- HBM protocol VIP package (companion model)
`ifndef HBM_PKG_SV
`define HBM_PKG_SV
package hbm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class hbm_seq_item extends uvm_sequence_item;
    `uvm_object_utils(hbm_seq_item)
    rand bit [2:0] cmd_type;
    rand bit [2:0] cid;
    rand bit [1:0] bank;
    rand bit [33:0] addr;
    rand int unsigned delay;
    constraint c_delay { delay inside {[0:20]}; }
    function new(string name = "hbm_seq_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("HBM item");
    endfunction
  endclass

  class hbm_cfg extends uvm_object;
    `uvm_object_utils(hbm_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    function new(string name = "hbm_cfg"); super.new(name); endfunction
  endclass

  class hbm_sequencer extends uvm_sequencer #(hbm_seq_item);
    `uvm_component_utils(hbm_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  class hbm_driver extends uvm_driver #(hbm_seq_item);
    `uvm_component_utils(hbm_driver)
    virtual hbm_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual hbm_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "HBM virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      hbm_seq_item req;
      vif.drv_cb.cs_n <= 1;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        repeat (req.delay) @(vif.drv_cb);
        vif.drv_cb.addr <= req.addr;
        vif.drv_cb.cid  <= req.cid;
        vif.drv_cb.ba   <= {2'b0, req.bank};
        vif.drv_cb.cs_n <= 0;
        vif.drv_cb.we_n <= (req.cmd_type != 3'd3);
        @(vif.drv_cb);
        vif.drv_cb.cs_n <= 1;
        seq_item_port.item_done();
      end
    endtask
  endclass

  class hbm_monitor extends uvm_monitor;
    `uvm_component_utils(hbm_monitor)
    virtual hbm_if vif;
    uvm_analysis_port #(hbm_seq_item) item_collected_port;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual hbm_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "HBM virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      hbm_seq_item item;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) continue;
        if (!vif.mon_cb.cs_n) begin
          item = hbm_seq_item::type_id::create("item");
          item.addr = vif.mon_cb.addr;
          item.cid  = vif.mon_cb.cid;
          item.bank = vif.mon_cb.ba[1:0];
          item.cmd_type = !vif.mon_cb.we_n ? 3'd3 : 3'd2;
          item_collected_port.write(item);
        end
      end
    endtask
  endclass

  class hbm_agent extends uvm_agent;
    `uvm_component_utils(hbm_agent)
    hbm_sequencer sqr;
    hbm_driver    drv;
    hbm_monitor   mon;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = hbm_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = hbm_sequencer::type_id::create("sqr", this);
        drv = hbm_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  class hbm_base_seq extends uvm_sequence #(hbm_seq_item);
    `uvm_object_utils(hbm_base_seq)
    function new(string name = "hbm_base_seq"); super.new(name); endfunction
  endclass

  class hbm_rw_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_rw_seq)
    rand int num_trans = 30;
    function new(string name = "hbm_rw_seq"); super.new(name); endfunction
    task body();
      hbm_seq_item item;
      repeat (num_trans) begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize()) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass

  class hbm_cov_cmd_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_cov_cmd_seq)
    function new(string name = "hbm_cov_cmd_seq"); super.new(name); endfunction
    task body();
      hbm_seq_item item;
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd4; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd5; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
  class hbm_cov_ch_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_cov_ch_seq)
    function new(string name = "hbm_cov_ch_seq"); super.new(name); endfunction
    task body();
      hbm_seq_item item;
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cid == 3'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cid == 3'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cid == 3'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cid == 3'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cid == 3'd4; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cid == 3'd5; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cid == 3'd6; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = hbm_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cid == 3'd7; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
endpackage
`endif
