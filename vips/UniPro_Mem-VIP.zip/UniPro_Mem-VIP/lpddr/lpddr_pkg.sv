// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lpddr_pkg.sv -- LPDDR protocol VIP package (companion model)
`ifndef LPDDR_PKG_SV
`define LPDDR_PKG_SV
package lpddr_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class lpddr_seq_item extends uvm_sequence_item;
    `uvm_object_utils(lpddr_seq_item)
    rand bit [2:0] cmd_type;
    rand bit [2:0] bank;
    rand bit [5:0] ca;
    rand int unsigned delay;
    constraint c_delay { delay inside {[0:20]}; }
    function new(string name = "lpddr_seq_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("LPDDR item");
    endfunction
  endclass

  class lpddr_cfg extends uvm_object;
    `uvm_object_utils(lpddr_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    function new(string name = "lpddr_cfg"); super.new(name); endfunction
  endclass

  class lpddr_sequencer extends uvm_sequencer #(lpddr_seq_item);
    `uvm_component_utils(lpddr_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  class lpddr_driver extends uvm_driver #(lpddr_seq_item);
    `uvm_component_utils(lpddr_driver)
    virtual lpddr_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual lpddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "LPDDR virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      lpddr_seq_item req;
      vif.drv_cb.cs <= 0;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        repeat (req.delay) @(vif.drv_cb);
        vif.drv_cb.ca <= req.ca;
        vif.drv_cb.cs <= 1;
        @(vif.drv_cb);
        vif.drv_cb.cs <= 0;
        seq_item_port.item_done();
      end
    endtask
  endclass

  class lpddr_monitor extends uvm_monitor;
    `uvm_component_utils(lpddr_monitor)
    virtual lpddr_if vif;
    uvm_analysis_port #(lpddr_seq_item) item_collected_port;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual lpddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "LPDDR virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      lpddr_seq_item item;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) continue;
        if (vif.mon_cb.cs) begin
          item = lpddr_seq_item::type_id::create("item");
          item.ca = vif.mon_cb.ca;
          item.cmd_type = {2'b0, vif.mon_cb.ca[0]};
          item.bank = 3'(vif.mon_cb.ca[4:2]);
          item_collected_port.write(item);
        end
      end
    endtask
  endclass

  class lpddr_agent extends uvm_agent;
    `uvm_component_utils(lpddr_agent)
    lpddr_sequencer sqr;
    lpddr_driver    drv;
    lpddr_monitor   mon;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = lpddr_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = lpddr_sequencer::type_id::create("sqr", this);
        drv = lpddr_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  class lpddr_base_seq extends uvm_sequence #(lpddr_seq_item);
    `uvm_object_utils(lpddr_base_seq)
    function new(string name = "lpddr_base_seq"); super.new(name); endfunction
  endclass

  class lpddr_rw_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_rw_seq)
    rand int num_trans = 30;
    function new(string name = "lpddr_rw_seq"); super.new(name); endfunction
    task body();
      lpddr_seq_item item;
      repeat (num_trans) begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize()) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass

  class lpddr_cov_cmd_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_cov_cmd_seq)
    function new(string name = "lpddr_cov_cmd_seq"); super.new(name); endfunction
    task body();
      lpddr_seq_item item;
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd4; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 3'd5; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
  class lpddr_cov_bank_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_cov_bank_seq)
    function new(string name = "lpddr_cov_bank_seq"); super.new(name); endfunction
    task body();
      lpddr_seq_item item;
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd1; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd4; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd5; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd6; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bank == 3'd7; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
endpackage
`endif
