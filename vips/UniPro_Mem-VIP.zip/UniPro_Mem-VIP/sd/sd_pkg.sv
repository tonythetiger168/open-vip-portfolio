// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sd_pkg.sv -- SD protocol VIP package (companion model)
`ifndef SD_PKG_SV
`define SD_PKG_SV
package sd_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class sd_seq_item extends uvm_sequence_item;
    `uvm_object_utils(sd_seq_item)
    rand bit [5:0] cmd_type;
    rand bit [1:0] bus_width;
    rand bit [3:0] data;
    constraint c_bw { bus_width inside {0, 1, 2}; }
    rand int unsigned delay;
    constraint c_delay { delay inside {[0:20]}; }
    function new(string name = "sd_seq_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("SD item");
    endfunction
  endclass

  class sd_cfg extends uvm_object;
    `uvm_object_utils(sd_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    function new(string name = "sd_cfg"); super.new(name); endfunction
  endclass

  class sd_sequencer extends uvm_sequencer #(sd_seq_item);
    `uvm_component_utils(sd_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  class sd_driver extends uvm_driver #(sd_seq_item);
    `uvm_component_utils(sd_driver)
    virtual sd_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual sd_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "SD virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      sd_seq_item req;
      vif.drv_cb.cmd_dir <= 0;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        repeat (req.delay) @(vif.drv_cb);
        vif.drv_cb.cmd_dir <= 1;
        vif.drv_cb.cmd     <= 1;
        vif.drv_cb.dat     <= req.data;
        @(vif.drv_cb);
        vif.drv_cb.cmd_dir <= 0;
        seq_item_port.item_done();
      end
    endtask
  endclass

  class sd_monitor extends uvm_monitor;
    `uvm_component_utils(sd_monitor)
    virtual sd_if vif;
    uvm_analysis_port #(sd_seq_item) item_collected_port;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual sd_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "SD virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      sd_seq_item item;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) continue;
        if (vif.mon_cb.cmd_dir) begin
          item = sd_seq_item::type_id::create("item");
          item.data = vif.mon_cb.dat;
          item.cmd_type = 6'd8;
          item.bus_width = 2'd1;
          item_collected_port.write(item);
        end
      end
    endtask
  endclass

  class sd_agent extends uvm_agent;
    `uvm_component_utils(sd_agent)
    sd_sequencer sqr;
    sd_driver    drv;
    sd_monitor   mon;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = sd_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = sd_sequencer::type_id::create("sqr", this);
        drv = sd_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  class sd_base_seq extends uvm_sequence #(sd_seq_item);
    `uvm_object_utils(sd_base_seq)
    function new(string name = "sd_base_seq"); super.new(name); endfunction
  endclass

  class sd_rw_seq extends sd_base_seq;
    `uvm_object_utils(sd_rw_seq)
    rand int num_trans = 30;
    function new(string name = "sd_rw_seq"); super.new(name); endfunction
    task body();
      sd_seq_item item;
      repeat (num_trans) begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize()) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass

  class sd_cov_cmd_seq extends sd_base_seq;
    `uvm_object_utils(sd_cov_cmd_seq)
    function new(string name = "sd_cov_cmd_seq"); super.new(name); endfunction
    task body();
      sd_seq_item item;
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd2; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd3; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd6; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd7; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd8; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd9; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd12; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd17; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd18; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd24; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd25; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 6'd55; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
endpackage
`endif
