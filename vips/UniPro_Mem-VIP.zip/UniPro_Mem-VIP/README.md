# UniPro_Mem - UniPro + Memory Protocols UVM VIP

Open-source UVM verification IP for **MIPI UniPro** with companion memory
protocol VIPs (DDR4 / LPDDR5 / HBM3 / UFS / eMMC / ONFI / SD) sharing one
environment, scoreboard and coverage framework.

## Protocol overview

MIPI UniPro: L2 data link layer with SOF/EOF framing, traffic classes (TC),
CPort addressing, credit-based flow control (CAP), NACK/replay error
recovery, CPort connection phases and L1.5 power modes over M-PHY. The
companion memory VIPs model command/address-level traffic for DRAM and
flash/storage protocols.

## Architecture

| Path | Description |
|------|-------------|
| `interfaces/memory_interfaces.sv` | 9 interfaces (ddr/lpddr/hbm/ufs/unipro/emmc/onfi/sd); `unipro_if` includes L2 link status signals for the SVA checker |
| `unipro/unipro_pkg.sv` | UniPro VIP: seq item (msg/cport/tc/credit + compare), driver (SOF/EOF framing, CP phases, credit, error frames), monitor (waveform decode), agent, **8 directed sequences** |
| `ddr/ lpddr/ hbm/ ufs/ emmc/ onfi/ sd/` | Companion protocol VIP packages (seq item/driver/monitor/agent/coverage sequences) |
| `env/memory_env_pkg.sv` | `memory_env` (8 agents + coverage + scoreboard) with **UniPro end-to-end compare** (exp/obs, n_matches/n_mismatches) |
| `coverage/memory_coverage_pkg.sv` | 8 coverage collectors + report checker; UniPro has 3 covergroups |
| `env/sva/unipro_mem_compliance_checker.sv` | Tiered SVA checker: L1 / L2 / L3 / **L4** |
| `test/memory_test_pkg.sv` | `memory_coverage_regression_test`, `memory_random_test`, UniPro directed tests |
| `tb_top.sv` | TB top + functional DUT models: **UniPro endpoint** (credit return + data loopback + error flag), eMMC/ONFI/UFS device responders |
| `scripts/` | Makefile + coverage regression (100% goal) |

## Closed loop

The UniPro driver frames traffic (SOF/data/EOF, credit messages, CP phases)
onto `unipro_if`; the endpoint DUT returns credits, loops data back on the RX
path and flags corrupted frames; the monitor decodes items from the waveform
and the scoreboard compares expected vs observed end-to-end.

## UniPro directed sequence library

| Sequence | Purpose |
|----------|---------|
| `unipro_rw_seq` | randomized message mix |
| `unipro_cov_msg_seq` | all 7 message types |
| `unipro_cov_cport_seq` | CPort sweep 0..31 |
| `unipro_error_seq` | corrupted frames (NACK/replay path) |
| `unipro_reset_seq` | frame right after reset release |
| `unipro_back_to_back_seq` | zero-gap frames |
| `unipro_stress_seq` | 100-frame DATA stress |
| `unipro_corner_seq` | connect/data/disconnect cycles, TC sweep, credit-only |
| `unipro_regression_seq` | weighted mix of all of the above |

Companion sequences: `<p>_rw_seq` + coverage sweeps (`ddr_cov_cmd/bank/bl_seq`,
`lpddr_cov_cmd/bank_seq`, `hbm_cov_cmd/ch_seq`, `ufs_cov_upiu/lun_seq`,
`emmc_cov_cmd/bw_seq`, `onfi_cov_cmd_seq`, `sd_cov_cmd_seq`).

## SVA compliance levels

- **L1 Basic Compliance (4)**: no-X on valid, reset idle, SOF eventually EOF, legal power mode
- **L2 Full Protocol (4)**: CP state legal, TC 0-7, error implies valid, ready latency
- **L3 Advanced Features (4)**: status legal, M-PHY power states, no SOF right after EOF, valid stability under backpressure
- **L4 Protocol-Specific (4)**: no SOF overlap before EOF, frames only when connected, error recovery, power-mode change only when idle

## Functional coverage

- `unipro_coverage::unipro_cg` - message type x CPort cross
- `unipro_coverage::unipro_fsm_cg` - message FSM transitions (connect/data/disconnect, bursts, credit) x TC cross
- `unipro_coverage::unipro_credit_cg` - credit value bins x message type cross
- `ddr/lpddr/hbm/ufs/emmc/onfi/sd_coverage` - command/bank/burst/UPIU/LUN/bus-width bins with crosses

## Quick start

```bash
./run.sh                                    # default memory_coverage_regression_test
cd scripts && make all TEST=unipro_regression_test
./scripts/coverage_regression.sh            # regression + 100% coverage gate
```

License: Apache-2.0
