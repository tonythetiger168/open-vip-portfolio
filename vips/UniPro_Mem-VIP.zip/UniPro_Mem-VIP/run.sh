#!/bin/bash
# UniPro_Mem quick-run script
TESTNAME=${TESTNAME:-memory_coverage_regression_test}
SEED=${SEED:-1}
SIMULATOR=${SIMULATOR:-xrun}
SRCS="interfaces/memory_interfaces.sv \
      ddr/ddr_pkg.sv lpddr/lpddr_pkg.sv hbm/hbm_pkg.sv ufs/ufs_pkg.sv \
      unipro/unipro_pkg.sv emmc/emmc_pkg.sv onfi/onfi_pkg.sv sd/sd_pkg.sv \
      coverage/memory_coverage_pkg.sv env/memory_env_pkg.sv \
      test/memory_test_pkg.sv tb_top.sv"
$SIMULATOR -sv -uvm -access +rwc $SRCS \
  +UVM_TESTNAME=$TESTNAME +SEED=$SEED +UVM_VERBOSITY=UVM_MEDIUM -l run_${TESTNAME}_${SEED}.log
