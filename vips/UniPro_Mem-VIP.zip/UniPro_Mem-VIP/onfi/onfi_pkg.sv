// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// onfi_pkg.sv -- ONFI protocol VIP package (companion model)
`ifndef ONFI_PKG_SV
`define ONFI_PKG_SV
package onfi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class onfi_seq_item extends uvm_sequence_item;
    `uvm_object_utils(onfi_seq_item)
    rand bit [7:0] cmd_type;   // 0x00 PAGE_READ 0x80/0x10 PAGE_PROGRAM 0x60/0xD0 BLOCK_ERASE 0x90 READ_ID 0xFF RESET
    rand bit [7:0] data;
    constraint c_cmd { cmd_type inside {8'h00, 8'h80, 8'h10, 8'h60, 8'hD0, 8'h90, 8'hFF}; }
    rand int unsigned delay;
    constraint c_delay { delay inside {[0:20]}; }
    function new(string name = "onfi_seq_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("ONFI item");
    endfunction
  endclass

  class onfi_cfg extends uvm_object;
    `uvm_object_utils(onfi_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    function new(string name = "onfi_cfg"); super.new(name); endfunction
  endclass

  class onfi_sequencer extends uvm_sequencer #(onfi_seq_item);
    `uvm_component_utils(onfi_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass

  class onfi_driver extends uvm_driver #(onfi_seq_item);
    `uvm_component_utils(onfi_driver)
    virtual onfi_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual onfi_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "ONFI virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      onfi_seq_item req;
      vif.drv_cb.ce_n <= 1; vif.drv_cb.cle <= 0; vif.drv_cb.ale <= 0; vif.drv_cb.we_n <= 1;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        repeat (req.delay) @(vif.drv_cb);
        vif.drv_cb.ce_n <= 0;
        vif.drv_cb.io   <= req.cmd_type;
        vif.drv_cb.cle  <= 1;
        vif.drv_cb.we_n <= 0;
        @(vif.drv_cb);
        vif.drv_cb.we_n <= 1;
        vif.drv_cb.cle  <= 0;
        do @(vif.drv_cb); while (!vif.drv_cb.rb_n);
        vif.drv_cb.ce_n <= 1;
        seq_item_port.item_done();
      end
    endtask
  endclass

  class onfi_monitor extends uvm_monitor;
    `uvm_component_utils(onfi_monitor)
    virtual onfi_if vif;
    uvm_analysis_port #(onfi_seq_item) item_collected_port;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual onfi_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "ONFI virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      onfi_seq_item item;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) continue;
        if (!vif.mon_cb.ce_n && vif.mon_cb.cle && !vif.mon_cb.we_n) begin
          item = onfi_seq_item::type_id::create("item");
          item.cmd_type = vif.mon_cb.io;
          item_collected_port.write(item);
        end
      end
    endtask
  endclass

  class onfi_agent extends uvm_agent;
    `uvm_component_utils(onfi_agent)
    onfi_sequencer sqr;
    onfi_driver    drv;
    onfi_monitor   mon;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = onfi_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = onfi_sequencer::type_id::create("sqr", this);
        drv = onfi_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  class onfi_base_seq extends uvm_sequence #(onfi_seq_item);
    `uvm_object_utils(onfi_base_seq)
    function new(string name = "onfi_base_seq"); super.new(name); endfunction
  endclass

  class onfi_rw_seq extends onfi_base_seq;
    `uvm_object_utils(onfi_rw_seq)
    rand int num_trans = 30;
    function new(string name = "onfi_rw_seq"); super.new(name); endfunction
    task body();
      onfi_seq_item item;
      repeat (num_trans) begin
        item = onfi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize()) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass

  class onfi_cov_cmd_seq extends onfi_base_seq;
    `uvm_object_utils(onfi_cov_cmd_seq)
    function new(string name = "onfi_cov_cmd_seq"); super.new(name); endfunction
    task body();
      onfi_seq_item item;
      begin
        item = onfi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 8'h00; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = onfi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 8'h80; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = onfi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 8'h10; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = onfi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 8'h60; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = onfi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 8'hD0; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = onfi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 8'h90; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      begin
        item = onfi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == 8'hFF; }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
endpackage
`endif
