// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_env.sv -- CHIH environment: reference-model scoreboard, checker, coverage

package chih_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import chih_defs_pkg::*;
  import chih_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class chih_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(chih_scoreboard)
    uvm_analysis_imp_exp #(chih_transaction, chih_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(chih_transaction, chih_scoreboard) obs_ap;

    chih_config cfg;
    chih_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // the SN-F (scoreboard copy), kept across items
    bit [7:0]   mem [1024];
    int         rq_out = 0, rq_give = 4, dt_out = 0, dt_give = 4, rs_cr = 0, dd_cr = 0;
    bit [136:0] fifo [$];
    int         st = 0, k = 0, n = 0, d0 = 0;      // 0 idle, 1 ReadReceipt, 2 CompData, 3 CompDBIDResp, 4 write data
    bit [136:0] c;
    bit [11:0]  dbid = 12'hFF0;
    bit [3:0]   got = 0, need = 0;
    bit         o_rq = 0, o_dt = 0, o_rv = 0, o_dv = 0;
    bit [70:0]  o_rf = 0;
    bit [239:0] o_df = 0;
    bit [6:0]   o_err = 0;
    function void step(bit [380:0] m);
      bit [136:0] rf = m[136:0];
      bit [239:0] df = m[377:138];
      bit rv = m[137], dv = m[378], rc = m[379], dc = m[380];
      bit n_rq = 0, n_dt = 0, n_rv = 0, n_dv = 0;
      bit [70:0] n_rf = 0;
      bit [239:0] n_df = 0;
      bit [6:0] e = 0;
      bit oob = c[107:74] != 0;
      if (rc) begin if (rs_cr == 15) e[6] = 1; else rs_cr++; end
      if (dc) begin if (dd_cr == 15) e[6] = 1; else dd_cr++; end
      if (rv) begin if (rq_out == 0) e[0] = 1; else begin rq_out--; fifo.push_back(rf); end end
      if (dv) begin
        if (dt_out == 0) e[0] = 1;
        else begin
          int d = df[77:76];
          bit [2:0] sz = c[60:58];
          dt_out--; dt_give++;
          if (st != 4 || df[10:4] != CHIH_SN || df[29:18] != dbid || !(df[40:37] inside {CHIH_DAT_NCBWR, CHIH_DAT_CANCEL})
              || !need[d] || got[d]) e[5] = 1;
          else begin
            bit bad = 0;
            bit [15:0] be = df[111:96];
            for (int b = 0; b < 16; b++) begin
              bit w = chih_in_win(c[69:64], sz, d, b);
              if (be[b] && !w) bad = 1;
              if (!be[b] && df[112 + 8 * b +: 8] != 0) bad = 1;
              if (c[56:50] == CHIH_WRITE_FULL && df[40:37] == CHIH_DAT_NCBWR && w && !be[b]) bad = 1;
              if (df[40:37] == CHIH_DAT_CANCEL && be[b]) bad = 1;
              if (c[56:50] == CHIH_WRITE_PTL && c[120] && be[b] && d * 16 + b < c[69:64]) bad = 1;
            end
            if (bad) e[4] = 1;
            else if (!oob && df[40:37] == CHIH_DAT_NCBWR)
              for (int b = 0; b < 16; b++) if (be[b]) mem[{c[73:70], 6'(d * 16 + b)}] = df[112 + 8 * b +: 8];
            got[d] = 1;
            if (got == need) begin st = 0; dbid++; end
          end
        end
      end
      case (st)
        0: if (fifo.size()) begin
          c = fifo.pop_front();
          rq_give++;
          oob = c[107:74] != 0;
          if (c[10:4] != CHIH_SN) e[1] = 1;
          else if (!(c[56:50] inside {CHIH_READ_NOSNP, CHIH_WRITE_PTL, CHIH_WRITE_FULL})) e[3] = 1;
          else if (c[57] || c[63:61] != 0 || c[60:58] == 7 || c[114] || (c[56:50] == CHIH_WRITE_FULL && c[60:58] != 6)) e[2] = 1;
          else begin
            n = chih_npk(c[60:58]); d0 = chih_did0(c[69:64], c[60:58]); k = 0;
            need = 0; got = 0;
            for (int i = 0; i < n; i++) need[d0 + i] = 1;
            if (c[56:50] == CHIH_READ_NOSNP) st = (c[114:113] == 2'b01) ? 1 : 2;
            else st = 3;
          end
        end
        1: if (rs_cr > 0) begin
          rs_cr--; n_rv = 1; n_rf = chih_rsp(c[17:11], c[29:18], CHIH_RSP_RRECEIPT, 2'b00, 12'h0); st = 2;
        end
        2: if (dd_cr > 0) begin
          bit [15:0] be = 0;
          bit [127:0] d = 0;
          int di = d0 + k;
          for (int b = 0; b < 16; b++) begin
            be[b] = chih_in_win(c[69:64], c[60:58], di, b);
            if (!oob) d[8 * b +: 8] = mem[{c[73:70], 6'(di * 16 + b)}];
          end
          dd_cr--; n_dv = 1;
          n_df = chih_dat(c[36:30], CHIH_SN, c[49:38], c[17:11], CHIH_DAT_COMPDATA, oob ? 2'b11 : 2'b00, 3'b010,
                          c[29:18], c[69:68], 2'(di), be, d);
          k++;
          if (k == n) st = 0;
        end
        3: if (rs_cr > 0) begin
          rs_cr--; n_rv = 1; n_rf = chih_rsp(c[17:11], c[29:18], CHIH_RSP_COMPDBID, oob ? 2'b11 : 2'b00, dbid); st = 4;
        end
        default: ;
      endcase
      if (rq_give > 0) begin n_rq = 1; rq_give--; rq_out++; end
      if (dt_give > 0) begin n_dt = 1; dt_give--; dt_out++; end
      o_rq = n_rq; o_dt = n_dt; o_rv = n_rv; o_rf = n_rf; o_dv = n_dv; o_df = n_df; o_err = e;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(chih_config)::get(this, "", "cfg", cfg))
        cfg = chih_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(chih_transaction t);
      t.so.delete();
      foreach (t.mo[i]) begin
        t.so.push_back({o_err, o_dt, o_rq, o_dv, o_df, o_rv, o_rf});
        step(t.mo[i]);
      end
    endfunction

    function void write_exp(chih_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(chih_transaction t);
      chih_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        chih_transaction e = exp_q.pop_front();
        chih_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("chih scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class chih_env extends uvm_env;
    `uvm_component_utils(chih_env)
    chih_agent      agt;
    chih_scoreboard sb;
    chih_checker    chk;
    chih_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = chih_agent     ::type_id::create("agt", this);
      sb  = chih_scoreboard::type_id::create("sb",  this);
      chk = chih_checker   ::type_id::create("chk", this);
      cov = chih_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
