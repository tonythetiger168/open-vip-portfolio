// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CHIH testbench top with a functional CHIH DUT model

`ifndef CHI_H_UVM_VIP_TB_SV
`define CHI_H_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import chih_defs_pkg::*;
import chih_pkg::*;
import chih_env_pkg::*;
import chih_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  chih_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  chih_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rxreqflitv(vif.rxreqflitv),
    .rxreqflit(vif.rxreqflit),
    .rxreqlcrdv(vif.rxreqlcrdv),
    .rxdatflitv(vif.rxdatflitv),
    .rxdatflit(vif.rxdatflit),
    .rxdatlcrdv(vif.rxdatlcrdv),
    .txrspflitv(vif.txrspflitv),
    .txrspflit(vif.txrspflit),
    .txrsplcrdv(vif.txrsplcrdv),
    .txdatflitv(vif.txdatflitv),
    .txdatflit(vif.txdatflit),
    .txdatlcrdv(vif.txdatlcrdv),
    .err(vif.err)
  );

  // Concurrent protocol checks
  chih_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rxreqflitv(vif.rxreqflitv),
    .rxreqflit(vif.rxreqflit),
    .rxreqlcrdv(vif.rxreqlcrdv),
    .rxdatflitv(vif.rxdatflitv),
    .rxdatflit(vif.rxdatflit),
    .rxdatlcrdv(vif.rxdatlcrdv),
    .txrspflitv(vif.txrspflitv),
    .txrspflit(vif.txrspflit),
    .txrsplcrdv(vif.txrsplcrdv),
    .txdatflitv(vif.txdatflitv),
    .txdatflit(vif.txdatflit),
    .txdatlcrdv(vif.txdatlcrdv),
    .err(vif.err)
  );

  initial begin
    uvm_config_db#(virtual chih_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module chih_model #(
  parameter logic [6:0] NID = 7'h20
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         rxreqflitv,
  input  logic [136:0] rxreqflit,
  output logic         rxreqlcrdv,
  input  logic         rxdatflitv,
  input  logic [239:0] rxdatflit,
  output logic         rxdatlcrdv,
  output logic         txrspflitv,
  output logic [70:0]  txrspflit,
  input  logic         txrsplcrdv,
  output logic         txdatflitv,
  output logic [239:0] txdatflit,
  input  logic         txdatlcrdv,
  output logic [6:0]   err
);
  // REQ fields used (Table B13.6, NodeID_Width 7, Req_Addr_Width 44)
  `define RQ_TGT(f)   f[10:4]
  `define RQ_SRC(f)   f[17:11]
  `define RQ_TXN(f)   f[29:18]
  `define RQ_RNID(f)  f[36:30]
  `define RQ_RTXN(f)  f[49:38]
  `define RQ_OP(f)    f[56:50]
  `define RQ_MREQ(f)  f[57]
  `define RQ_SIZE(f)  f[60:58]
  `define RQ_NRQHI(f) f[63:61]
  `define RQ_ADDR(f)  f[107:64]
  `define RQ_ORDER(f) f[114:113]
  `define RQ_DEV(f)   f[120]

  logic [7:0]   mem [0:1023];
  logic [136:0] fq [0:3];
  integer       fr, fc;                      // FIFO read index, count
  integer       rq_out, rq_give, dt_out, dt_give, rs_cr, dd_cr;
  integer       st, k, n, d0, di, o, b, bs;
  logic [136:0] c;
  logic [11:0]  dbid;
  logic [3:0]   got, need;
  logic         oob, bad, w;
  logic [6:0]   e;
  logic [15:0]  be;
  logic [127:0] dd;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 1024; i++) mem[i] = 8'h00;
      fr = 0; fc = 0; rq_out = 0; rq_give = 4; dt_out = 0; dt_give = 4; rs_cr = 0; dd_cr = 0;
      st = 0; k = 0; n = 0; d0 = 0; c = '0; dbid = 12'hFF0; got = '0; need = '0;
      rxreqlcrdv <= 1'b0; rxdatlcrdv <= 1'b0; txrspflitv <= 1'b0; txrspflit <= '0;
      txdatflitv <= 1'b0; txdatflit <= '0; err <= '0;
    end else begin
      e = '0;
      txrspflitv <= 1'b0; txrspflit <= '0; txdatflitv <= 1'b0; txdatflit <= '0;
      // L-credits from the HN
      if (txrsplcrdv) begin if (rs_cr == 15) e[6] = 1'b1; else rs_cr = rs_cr + 1; end
      if (txdatlcrdv) begin if (dd_cr == 15) e[6] = 1'b1; else dd_cr = dd_cr + 1; end
      // REQ flit in
      if (rxreqflitv) begin
        if (rq_out == 0) e[0] = 1'b1;
        else begin rq_out = rq_out - 1; fq[(fr + fc) % 4] = rxreqflit; fc = fc + 1; end
      end
      // DAT flit in
      oob = (`RQ_ADDR(c) >= 44'd1024);
      if (rxdatflitv) begin
        if (dt_out == 0) e[0] = 1'b1;
        else begin
          dt_out = dt_out - 1; dt_give = dt_give + 1;
          di = rxdatflit[77:76];
          if (st != 4 || rxdatflit[10:4] != NID || rxdatflit[29:18] != dbid ||
              (rxdatflit[40:37] != 4'h3 && rxdatflit[40:37] != 4'h7) || !need[di] || got[di]) e[5] = 1'b1;
          else begin
            bad = 1'b0;
            be = rxdatflit[111:96];
            bs = `RQ_ADDR(c) & ~((1 << `RQ_SIZE(c)) - 1);
            bs = bs % 64;
            for (b = 0; b < 16; b = b + 1) begin
              o = di * 16 + b;
              w = (o >= bs) && (o < bs + (1 << `RQ_SIZE(c)));
              if (be[b] && !w) bad = 1'b1;
              if (!be[b] && rxdatflit[112 + 8 * b +: 8] != 8'h00) bad = 1'b1;
              if (`RQ_OP(c) == 7'h1D && rxdatflit[40:37] == 4'h3 && w && !be[b]) bad = 1'b1;
              if (rxdatflit[40:37] == 4'h7 && be[b]) bad = 1'b1;
              if (`RQ_OP(c) == 7'h1C && `RQ_DEV(c) && be[b] && o < `RQ_ADDR(c) % 64) bad = 1'b1;
            end
            if (bad) e[4] = 1'b1;
            else if (!oob && rxdatflit[40:37] == 4'h3)
              for (b = 0; b < 16; b = b + 1)
                if (be[b]) mem[`RQ_ADDR(c) / 64 % 16 * 64 + di * 16 + b] = rxdatflit[112 + 8 * b +: 8];
            got[di] = 1'b1;
            if (got == need) begin st = 0; dbid = dbid + 12'd1; end
          end
        end
      end
      // the request engine
      case (st)
        0: if (fc > 0) begin
          c = fq[fr]; fr = (fr + 1) % 4; fc = fc - 1;
          rq_give = rq_give + 1;
          if (`RQ_TGT(c) != NID) e[1] = 1'b1;
          else if (`RQ_OP(c) != 7'h04 && `RQ_OP(c) != 7'h1C && `RQ_OP(c) != 7'h1D) e[3] = 1'b1;
          else if (`RQ_MREQ(c) || `RQ_NRQHI(c) != 3'd0 || `RQ_SIZE(c) == 3'd7 || `RQ_ORDER(c) >= 2'b10 ||
                   (`RQ_OP(c) == 7'h1D && `RQ_SIZE(c) != 3'd6)) e[2] = 1'b1;
          else begin
            n = (`RQ_SIZE(c) <= 4) ? 1 : (1 << (`RQ_SIZE(c) - 4));
            d0 = (`RQ_SIZE(c) == 6) ? 0 : ((`RQ_ADDR(c) % 64) & ~((1 << `RQ_SIZE(c)) - 1)) / 16;
            k = 0; got = '0; need = '0;
            for (int i = 0; i < 4; i++) if (i >= d0 && i < d0 + n) need[i] = 1'b1;
            if (`RQ_OP(c) == 7'h04) st = (`RQ_ORDER(c) == 2'b01) ? 1 : 2;
            else st = 3;
          end
        end
        1: if (rs_cr > 0) begin       // ReadReceipt
          rs_cr = rs_cr - 1;
          txrspflitv <= 1'b1;
          txrspflit <= {7'h0, 4'h0, 2'b00, 12'h000, 3'b000, 3'b000, 3'b000, 2'b00, 5'h08, `RQ_TXN(c), NID, `RQ_SRC(c), 4'h0};
          st = 2;
        end
        2: if (dd_cr > 0) begin       // CompData_UC to ReturnNID / ReturnTxnID
          oob = (`RQ_ADDR(c) >= 44'd1024);
          di = d0 + k;
          bs = (`RQ_ADDR(c) % 64) & ~((1 << `RQ_SIZE(c)) - 1);
          for (b = 0; b < 16; b = b + 1) begin
            o = di * 16 + b;
            be[b] = (o >= bs) && (o < bs + (1 << `RQ_SIZE(c)));
            dd[8 * b +: 8] = oob ? 8'h00 : mem[`RQ_ADDR(c) / 64 % 16 * 64 + o];
          end
          dd_cr = dd_cr - 1;
          txdatflitv <= 1'b1;
          txdatflit <= {dd, be, 1'b0, 2'b00, 1'b0, 1'b0, 1'b0, 4'h0, 2'b00, 6'h00, di[1:0], c[69:68],
                        4'h0, `RQ_TXN(c), 3'b000, 1'b0, 8'h00, 3'b010, (oob ? 2'b11 : 2'b00), 4'h4,
                        `RQ_SRC(c), `RQ_RTXN(c), NID, `RQ_RNID(c), 4'h0};
          k = k + 1;
          if (k == n) st = 0;
        end
        3: if (rs_cr > 0) begin       // CompDBIDResp
          oob = (`RQ_ADDR(c) >= 44'd1024);
          rs_cr = rs_cr - 1;
          txrspflitv <= 1'b1;
          txrspflit <= {7'h0, 4'h0, 2'b00, dbid, 3'b000, 3'b000, 3'b000, (oob ? 2'b11 : 2'b00), 5'h05, `RQ_TXN(c),
                        NID, `RQ_SRC(c), 4'h0};
          st = 4;
        end
        default: ;
      endcase
      // L-credits back to the HN
      rxreqlcrdv <= 1'b0; rxdatlcrdv <= 1'b0;
      if (rq_give > 0) begin rxreqlcrdv <= 1'b1; rq_give = rq_give - 1; rq_out = rq_out + 1; end
      if (dt_give > 0) begin rxdatlcrdv <= 1'b1; dt_give = dt_give - 1; dt_out = dt_out + 1; end
      err <= e;
    end
  end
  `undef RQ_TGT
  `undef RQ_SRC
  `undef RQ_TXN
  `undef RQ_RNID
  `undef RQ_RTXN
  `undef RQ_OP
  `undef RQ_MREQ
  `undef RQ_SIZE
  `undef RQ_NRQHI
  `undef RQ_ADDR
  `undef RQ_ORDER
  `undef RQ_DEV
endmodule
`endif
