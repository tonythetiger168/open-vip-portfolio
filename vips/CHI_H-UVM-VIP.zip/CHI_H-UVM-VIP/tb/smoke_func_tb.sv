// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (CHIH DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened chih_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic         rxreqflitv = 1'b0, rxdatflitv = 1'b0, rsp_cr = 1'b0, dat_cr = 1'b0, rsp_extra = 1'b0, dat_extra = 1'b0;
  logic [136:0] rxreqflit = '0;
  logic [239:0] rxdatflit = '0;
  wire          rxreqlcrdv, rxdatlcrdv, txrspflitv, txdatflitv;
  wire  [70:0]  txrspflit;
  wire  [239:0] txdatflit;
  wire  [6:0]   err;
  wire          txrsplcrdv = rsp_cr | rsp_extra;
  wire          txdatlcrdv = dat_cr | dat_extra;

  always #5 clk = ~clk;

  chih_model u_dut (.clk(clk), .rst_n(rst_n), .rxreqflitv(rxreqflitv), .rxreqflit(rxreqflit), .rxreqlcrdv(rxreqlcrdv),
                    .rxdatflitv(rxdatflitv), .rxdatflit(rxdatflit), .rxdatlcrdv(rxdatlcrdv), .txrspflitv(txrspflitv),
                    .txrspflit(txrspflit), .txrsplcrdv(txrsplcrdv), .txdatflitv(txdatflitv), .txdatflit(txdatflit),
                    .txdatlcrdv(txdatlcrdv), .err(err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // the HN side of the link: credits it holds, credits it gives back, what it received
  // the SN gets one RSP and one DAT credit and one back per flit: it never holds more than 1
  integer req_cr = 0, dat_cr_n = 0, give_rsp = 1, give_dat = 1;
  logic [70:0]  rsp_log [0:63];
  logic [239:0] dat_log [0:63];
  integer nrsp = 0, ndat = 0;
  integer e_seen [0:6];
  always @(posedge clk) begin
    if (rxreqlcrdv) req_cr = req_cr + 1;
    if (rxdatlcrdv) dat_cr_n = dat_cr_n + 1;
    if (txrspflitv) begin rsp_log[nrsp % 64] = txrspflit; nrsp = nrsp + 1; give_rsp = give_rsp + 1; end
    if (txdatflitv) begin dat_log[ndat % 64] = txdatflit; ndat = ndat + 1; give_dat = give_dat + 1; end
    for (int i = 0; i < 7; i++) if (err[i]) e_seen[i] = e_seen[i] + 1;
  end
  // return the SN's TX credits one per clock
  always @(negedge clk) begin
    rsp_cr = 1'b0; dat_cr = 1'b0;
    if (rst_n && give_rsp > 0) begin rsp_cr = 1'b1; give_rsp = give_rsp - 1; end
    if (rst_n && give_dat > 0) begin dat_cr = 1'b1; give_dat = give_dat - 1; end
  end
  task automatic clr(); for (int i = 0; i < 7; i++) e_seen[i] = 0; nrsp = 0; ndat = 0; endtask
  function automatic bit no_err(); no_err = (e_seen[0] + e_seen[1] + e_seen[2] + e_seen[3] + e_seen[4] + e_seen[5] + e_seen[6]) == 0; endfunction
  task automatic idle(input integer n); repeat (n) @(posedge clk); #1; endtask

  // a REQ flit, bit positions from Table B13.6
  function automatic logic [136:0] mkreq(input logic [6:0] op, input logic [43:0] a, input logic [2:0] size,
                                         input logic [11:0] txn, input logic [6:0] rnid = 7'h05, input logic [11:0] rtxn = 12'hFFF,
                                         input logic [1:0] order = 2'b00, input logic [6:0] tgt = 7'h20,
                                         input logic [3:0] memattr = 4'b0101);
    logic [136:0] f;
    f = '0;
    f[3:0] = 4'hA;            // QoS: not interpreted
    f[10:4] = tgt; f[17:11] = 7'h05; f[29:18] = txn; f[36:30] = rnid; f[49:38] = (rtxn == 12'hFFF) ? txn : rtxn;
    f[56:50] = op; f[63:58] = {3'b000, size}; f[107:64] = a; f[110:108] = 3'b001; f[114:113] = order;
    f[122:119] = memattr; f[136] = 1'b1;   // TraceTag: not interpreted
    mkreq = f;
  endfunction
  task automatic send_req(input logic [136:0] f, input bit nocredit = 0);
    @(negedge clk);
    while (!nocredit && req_cr == 0) @(negedge clk);
    if (req_cr > 0) req_cr = req_cr - 1;
    rxreqflitv = 1'b1; rxreqflit = f;
    @(negedge clk);
    rxreqflitv = 1'b0;
  endtask
  // a write data flit (Table B13.9)
  task automatic send_dat(input logic [3:0] op, input logic [11:0] txn, input logic [1:0] did, input logic [15:0] be,
                          input logic [127:0] d, input logic [6:0] tgt = 7'h20, input bit nocredit = 0);
    logic [239:0] f;
    f = '0;
    f[10:4] = tgt; f[17:11] = 7'h05; f[29:18] = txn; f[40:37] = op; f[77:76] = did; f[111:96] = be; f[239:112] = d;
    @(negedge clk);
    while (!nocredit && dat_cr_n == 0) @(negedge clk);
    if (dat_cr_n > 0) dat_cr_n = dat_cr_n - 1;
    rxdatflitv = 1'b1; rxdatflit = f;
    @(negedge clk);
    rxdatflitv = 1'b0;
  endtask
  function automatic logic [127:0] pat(input integer s);
    pat = {32'(s * 32'h0101_0101 + 32'h1357_9BDF), 32'(s ^ 32'hDEAD_BEEF), 32'(s * 7 + 32'h0BAD_F00D), 32'(~s)};
  endfunction
  logic [11:0] dbid;
  logic [127:0] d;
  integer i, n;

  initial begin
    clr();
    repeat (3) @(posedge clk);
    #1 chk(rxreqlcrdv === 1'b0 && txrspflitv === 1'b0 && err === 7'h0, "reset: no credits, no flits");
    // a flit in the first clock after reset, before any L-credit: dropped
    @(negedge clk); rst_n = 1;
    rxreqflitv = 1'b1; rxreqflit = mkreq(7'h04, 44'h0, 3'd6, 12'h001);
    rxdatflitv = 1'b1; rxdatflit = '0;
    @(negedge clk); rxreqflitv = 1'b0; rxdatflitv = 1'b0;
    idle(8);
    chk(e_seen[0] == 1 && ndat == 0, "REQ and DAT flits before the first L-credit: dropped (err 0)");
    chk(req_cr == 4 && dat_cr_n == 4, "4 REQ and 4 DAT L-credits granted after reset");

    // WriteNoSnpFull with a 12-bit TxnID: CompDBIDResp, then 4 packets
    clr();
    send_req(mkreq(7'h1D, 44'h040, 3'd6, 12'hABC));
    idle(4);
    chk(nrsp == 1 && rsp_log[0][34:30] == 5'h05 && rsp_log[0][29:18] == 12'hABC && rsp_log[0][10:4] == 7'h05 &&
        rsp_log[0][17:11] == 7'h20 && rsp_log[0][36:35] == 2'b00, "WriteNoSnpFull: CompDBIDResp to SrcID with the 12-bit TxnID");
    dbid = rsp_log[0][57:46];
    chk(dbid == 12'hFF0, "first DBID is the model's start value 0xFF0 (12 bits)");
    for (i = 0; i < 4; i++) send_dat(4'h3, dbid, i, 16'hFFFF, pat(i));
    idle(4);
    chk(no_err(), "full write data accepted");
    chk(dat_cr_n == 4, "one DAT L-credit back per write data flit");
    // read it back: CompData_UC, DataID 0..3, DMT fields
    clr();
    send_req(mkreq(7'h04, 44'h040, 3'd6, 12'h7E1));
    idle(10);
    chk(ndat == 4 && nrsp == 0, "ReadNoSnp of 64 bytes: 4 CompData packets, no RSP");
    for (i = 0; i < 4; i++)
      chk(dat_log[i][40:37] == 4'h4 && dat_log[i][45:43] == 3'b010 && dat_log[i][77:76] == i && dat_log[i][239:112] == pat(i),
          $sformatf("CompData_UC packet %0d: DataID %0d and the written data", i, i));
    chk(dat_log[0][10:4] == 7'h05 && dat_log[0][29:18] == 12'h7E1 && dat_log[0][36:30] == 7'h05 && dat_log[0][73:58] == 16'h07E1,
        "no DMT: TgtID = ReturnNID = SrcID, TxnID = ReturnTxnID, HomeNID = SrcID, DBID = TxnID");
    chk(dat_log[1][3:0] == 4'h0 && dat_log[1][57:46] == 12'h0 && dat_log[1][73:70] == 4'h0 && dat_log[1][95:78] == 18'h0,
        "CompData: QoS, DataSource, DataPull, CBusy, DBID MBZ, CacheLineID, TagOp, Tag, TU, TraceTag, CAH, NumDat, Replicate all 0");
    // DMT with Order = 0b01: ReadReceipt to the HN, data to the requester
    clr();
    send_req(mkreq(7'h04, 44'h050, 3'd4, 12'h123, 7'h11, 12'h9A9, 2'b01));
    idle(6);
    chk(nrsp == 1 && rsp_log[0][34:30] == 5'h08 && rsp_log[0][10:4] == 7'h05 && rsp_log[0][29:18] == 12'h123,
        "Order 0b01: ReadReceipt to SrcID with TxnID");
    chk(ndat == 1 && dat_log[0][10:4] == 7'h11 && dat_log[0][29:18] == 12'h9A9 && dat_log[0][36:30] == 7'h05 &&
        dat_log[0][73:58] == 16'h0123, "DMT: CompData to ReturnNID with ReturnTxnID, HomeNID = SrcID, DBID = TxnID");
    chk(dat_log[0][77:76] == 2'd1 && dat_log[0][75:74] == 2'd1 && dat_log[0][239:112] == pat(1),
        "16-byte read at 0x50: one packet, DataID = CCID = Addr[5:4] = 1");
    chk(dat_log[0][111:96] == 16'hFFFF, "read BE marks the 16-byte data window");
    // packet counts per Size (B2.9.4)
    for (i = 0; i <= 6; i++) begin
      clr();
      send_req(mkreq(7'h04, 44'h06C, i, 12'h200 + i));
      idle(10);
      n = (i <= 4) ? 1 : (1 << (i - 4));
      chk(ndat == n && dat_log[0][77:76] == ((i == 6) ? 0 : (i == 5) ? 2 : 2'd2),
          $sformatf("Size %0d at 0x6C: %0d packet(s) from DataID %0d", i, n, (i == 6) ? 0 : 2));
    end
    clr();
    send_req(mkreq(7'h04, 44'h06C, 3'd2, 12'h210)); idle(8);
    chk(dat_log[0][111:96] == 16'hF000, "Size 2 at 0x6C: BE bytes 12..15 of the packet");
    // WriteNoSnpPtl, 32 bytes at 0x0A0, some BE
    clr();
    send_req(mkreq(7'h1C, 44'h0A0, 3'd5, 12'h301));
    idle(4); dbid = rsp_log[0][57:46];
    chk(dbid == 12'hFF1, "next DBID");
    send_dat(4'h3, dbid, 2, 16'h00FF, {64'h0, 64'h1122_3344_5566_7788});
    send_dat(4'h3, dbid, 3, 16'h8001, {8'hEE, 112'h0, 8'h99});
    idle(3);
    chk(no_err(), "partial write: random BE accepted");
    clr(); send_req(mkreq(7'h04, 44'h080, 3'd6, 12'h302)); idle(10);
    chk(dat_log[2][239:112] == {64'h0, 64'h1122_3344_5566_7788} && dat_log[3][239:112] == {8'hEE, 112'h0, 8'h99},
        "only bytes with BE are written");
    // WriteDataCancel: nothing written, BE must be 0
    clr();
    send_req(mkreq(7'h1C, 44'h080, 3'd4, 12'h303)); idle(4); dbid = rsp_log[0][57:46];
    send_dat(4'h7, dbid, 0, 16'h0000, 128'h0); idle(3);
    chk(no_err(), "WriteDataCancel accepted");
    clr(); send_req(mkreq(7'h04, 44'h080, 3'd4, 12'h304)); idle(8);
    chk(dat_log[0][239:112] == 128'h0 && ndat == 1, "cancelled write left memory alone");
    // Device memory WriteNoSnpPtl: BE below Addr is an error
    clr();
    send_req(mkreq(7'h1C, 44'h0C4, 3'd4, 12'h305, 7'h05, 12'hFFF, 2'b00, 7'h20, 4'b0010)); idle(4); dbid = rsp_log[0][57:46];
    send_dat(4'h3, dbid, 0, 16'h0008, {96'h0, 8'h77, 24'h0}); idle(3);
    chk(e_seen[4] == 1, "Device WriteNoSnpPtl: BE below Addr breaks B2.9.3");
    clr();
    send_req(mkreq(7'h1C, 44'h0C4, 3'd4, 12'h306, 7'h05, 12'hFFF, 2'b00, 7'h20, 4'b0010)); idle(4); dbid = rsp_log[0][57:46];
    send_dat(4'h3, dbid, 0, 16'h0030, {80'h0, 16'hABCD, 32'h0}); idle(3);
    chk(no_err(), "Device WriteNoSnpPtl: BE at and above Addr is fine");
    // write data rule breaks
    clr();
    send_req(mkreq(7'h1D, 44'h100, 3'd6, 12'h307)); idle(4); dbid = rsp_log[0][57:46];
    send_dat(4'h3, dbid, 0, 16'hFFFE, pat(9) & ~128'hFF); for (i = 1; i < 4; i++) send_dat(4'h3, dbid, i, 16'hFFFF, pat(i));
    idle(3);
    chk(e_seen[4] == 1, "WriteNoSnpFull with a byte not enabled: error");
    clr(); send_req(mkreq(7'h04, 44'h100, 3'd4, 12'h308)); idle(8);
    chk(dat_log[0][239:112] == 128'h0, "the broken packet was not written");
    clr();
    send_req(mkreq(7'h1C, 44'h140, 3'd4, 12'h309)); idle(4); dbid = rsp_log[0][57:46];
    send_dat(4'h3, dbid, 0, 16'h0001, {120'h0, 8'h00} | {8'h01, 120'h0}); idle(3);
    chk(e_seen[4] == 1, "data under BE = 0 must be zero");
    clr();
    send_req(mkreq(7'h1C, 44'h140, 3'd2, 12'h30A)); idle(4); dbid = rsp_log[0][57:46];
    send_dat(4'h3, dbid, 0, 16'h0010, 128'h0); idle(3);
    chk(e_seen[4] == 1, "BE outside the 4-byte data window");
    clr();
    send_req(mkreq(7'h1C, 44'h140, 3'd4, 12'h30B)); idle(4); dbid = rsp_log[0][57:46];
    send_dat(4'h7, dbid, 0, 16'h0001, 128'h0); idle(3);
    chk(e_seen[4] == 1, "WriteDataCancel with a BE set");
    // unexpected write data
    clr();
    send_dat(4'h3, 12'h123, 0, 16'hFFFF, 128'h0); idle(3);
    chk(e_seen[5] == 1, "write data with no write waiting");
    clr();
    send_req(mkreq(7'h1C, 44'h180, 3'd4, 12'h30C)); idle(4); dbid = rsp_log[0][57:46];
    send_dat(4'h3, dbid ^ 12'h100, 0, 16'h0001, 128'h1); idle(2);
    chk(e_seen[5] == 1, "write data with a TxnID that is not the DBID");
    clr();
    send_dat(4'h3, dbid, 1, 16'h0000, 128'h0); idle(2);
    chk(e_seen[5] == 1, "write data with a DataID outside the transfer");
    clr();
    send_dat(4'h1, dbid, 0, 16'h0000, 128'h0); idle(2);
    chk(e_seen[5] == 1, "SnpRespData is not write data");
    clr();
    send_dat(4'h3, dbid, 0, 16'h0001, 128'h2, 7'h21); idle(2);
    chk(e_seen[5] == 1, "write data to another node");
    clr();
    send_dat(4'h3, dbid, 0, 16'h0001, 128'h3); idle(2);
    send_dat(4'h3, dbid, 0, 16'h0001, 128'h4); idle(2);
    chk(e_seen[5] == 1, "a repeated DataID");
    // out of range: NDERR
    clr();
    send_req(mkreq(7'h04, 44'h400, 3'd6, 12'h401)); idle(10);
    chk(ndat == 4 && dat_log[0][42:41] == 2'b11 && dat_log[3][239:112] == 128'h0, "read at 1 KB: CompData with NDERR, data 0");
    clr();
    send_req(mkreq(7'h1D, 44'h800_0000_0040, 3'd6, 12'h402)); idle(4); dbid = rsp_log[0][57:46];
    chk(rsp_log[0][36:35] == 2'b11, "write above 1 KB: CompDBIDResp with NDERR");
    for (i = 0; i < 4; i++) send_dat(4'h3, dbid, i, 16'hFFFF, 128'h5);
    idle(3);
    clr(); send_req(mkreq(7'h04, 44'h040, 3'd4, 12'h403)); idle(8);
    chk(no_err() && dat_log[0][239:112] == pat(0), "the NDERR write did not touch line 1");
    // request errors
    clr(); send_req(mkreq(7'h04, 44'h0, 3'd6, 12'h404, 7'h05, 12'hFFF, 2'b00, 7'h21)); idle(6);
    chk(e_seen[1] == 1 && ndat == 0, "REQ to another node: dropped");
    clr(); send_req(mkreq(7'h19, 44'h0, 3'd6, 12'h405)); idle(6);
    chk(e_seen[3] == 1 && nrsp == 0, "WriteUniqueFull is not an SN-F request");
    clr(); send_req(mkreq(7'h44, 44'h0, 3'd6, 12'h406)); idle(6);
    chk(e_seen[3] == 1 && ndat == 0, "WriteNoSnpZero (7-bit opcode 0x44) not supported here");
    clr(); begin logic [136:0] f; f = mkreq(7'h04, 44'h0, 3'd6, 12'h407); f[57] = 1'b1; send_req(f); end idle(6);
    chk(e_seen[2] == 1 && ndat == 0, "MultiReq request: not supported");
    clr(); begin logic [136:0] f; f = mkreq(7'h04, 44'h0, 3'd6, 12'h408); f[63] = 1'b1; send_req(f); end idle(6);
    chk(e_seen[2] == 1, "NumReq / {3'b0, Size}: MBZ bit set");
    clr(); send_req(mkreq(7'h04, 44'h0, 3'd7, 12'h409)); idle(6);
    chk(e_seen[2] == 1, "Size 128 bytes is reserved");
    clr(); send_req(mkreq(7'h04, 44'h0, 3'd6, 12'h40A, 7'h05, 12'hFFF, 2'b10)); idle(6);
    chk(e_seen[2] == 1, "Order 0b10 is reserved from HN-F to SN-F");
    clr(); send_req(mkreq(7'h04, 44'h0, 3'd6, 12'h40B, 7'h05, 12'hFFF, 2'b11)); idle(6);
    chk(e_seen[2] == 1, "Order 0b11 is reserved from HN-F to SN-F");
    clr(); send_req(mkreq(7'h1D, 44'h0, 3'd5, 12'h40C)); idle(6);
    chk(e_seen[2] == 1 && nrsp == 0, "WriteNoSnpFull of 32 bytes");
    idle(4);
    chk(req_cr == 4, "dropped requests still return their L-credit");
    // L-credit violations
    clr();
    for (i = 0; i < 4; i++) send_req(mkreq(7'h04, 44'h0, 3'd6, 12'h500 + i));
    send_req(mkreq(7'h04, 44'h0, 3'd6, 12'h504), 1);
    idle(60);
    chk(e_seen[0] == 0 && ndat == 20, "5th REQ after a credit came back: accepted, 20 packets");
    // six 64-byte reads on consecutive clocks: the first is taken at once and its
    // credit comes back, four more fill the credits, the sixth has none
    clr();
    @(negedge clk); req_cr = 0;
    for (i = 0; i < 6; i++) begin rxreqflitv = 1'b1; rxreqflit = mkreq(7'h04, 44'h0, 3'd6, 12'h510 + i); @(negedge clk); end
    rxreqflitv = 1'b0;
    idle(70);
    chk(e_seen[0] == 1 && ndat == 20, "6 back-to-back REQ flits on 4 L-credits: one dropped (err 0), 5 served");
    idle(10); req_cr = 4;
    clr(); give_rsp = 14; give_dat = 14; idle(20);
    chk(no_err(), "15 RSP and 15 DAT L-credits held: fine");
    @(negedge clk); rsp_extra = 1'b1; @(negedge clk); rsp_extra = 1'b0; idle(2);
    chk(e_seen[6] == 1, "a 16th RSP L-credit: overflow");
    clr();
    @(negedge clk); dat_extra = 1'b1; @(negedge clk); dat_extra = 1'b0; idle(2);
    chk(e_seen[6] == 1, "a 16th DAT L-credit: overflow");
    // the SN keeps 15: a burst of reads still flows
    clr(); give_rsp = 0;
    send_req(mkreq(7'h04, 44'h040, 3'd6, 12'hFFF)); idle(10);
    chk(ndat == 4 && no_err() && dat_log[1][239:112] == pat(1), "after the overflow the link still works");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
