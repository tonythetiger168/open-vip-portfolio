// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_pkg.sv -- CHIH UVM VIP package

package chih_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import chih_defs_pkg::*;
  export chih_defs_pkg::*;

  `include "chih_transaction.svh"
  `include "chih_config.svh"
  `include "chih_sequencer.svh"
  `include "chih_driver.svh"
  `include "chih_monitor.svh"
  `include "chih_agent.svh"
  `include "chih_sequences.svh"
  `include "chih_checker.svh"
  `include "chih_coverage.svh"
endpackage
