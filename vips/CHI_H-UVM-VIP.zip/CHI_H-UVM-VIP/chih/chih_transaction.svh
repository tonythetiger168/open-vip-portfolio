// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_transaction.svh -- CHIH transaction

class chih_transaction extends uvm_sequence_item;
  `uvm_object_utils(chih_transaction)

  // request (driven by the agent)
  bit [380:0] mo[$];
  // response (returned by the DUT)
  bit [321:0] so[$];
  // bookkeeping (not compared)
  rand bit [3:0] kind;
  rand bit [2:0] size;
  rand bit [9:0] addr;
  rand bit [11:0] txn;
  rand bit dmt;
  rand bit ord;
  rand bit [2:0] sub;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { kind dist { 0 := 6, 1 := 4, 2 := 5, 3 := 1, 4 := 1, 5 := 1, 6 := 2, 7 := 1, 8 := 1,
                                  9 := 1, 10 := 1, 11 := 2, 12 := 1, [13:15] :/ 6 }; }

  function new(string name = "chih_transaction"); super.new(name); endfunction

  // kind: 0 ReadNoSnp, 1 WriteNoSnpFull, 2 WriteNoSnpPtl (sub[0]: Device memory),
  // 3 WriteNoSnpPtl cancelled, 4 read at or above 1 KB, 5 write at or above 1 KB,
  // 6 four reads back to back, 7 six 64-byte reads ignoring L-credits,
  // 8 REQ to another node, 9 unsupported opcode (sub), 10 reserved field value
  // (sub), 11 write data breaking a rule (sub), 12 L-credit overflow,
  // 13 full write, partial write, read back, 14 / 15 as 0 / 2
  function void set(int k, int sz = 6, int a = 0, int tx = 1, bit d = 0, bit o = 0, int sb = 0, bit [31:0] s = 1);
    kind = k; size = sz; addr = a; txn = tx; dmt = d; ord = o; sub = sb; seed = s;
  endfunction
  function int kk(); return (kind == 14) ? 0 : (kind == 15) ? 2 : kind; endfunction
  // derived from the monitored flits (for coverage)
  function int n_rsp(bit [4:0] op);
    int n = 0;
    foreach (so[i]) if (so[i][71] && so[i][34:30] == op) n++;
    return n;
  endfunction
  function int n_dat(bit [3:0] op);
    int n = 0;
    foreach (so[i]) if (so[i][312] && so[i][112:109] == op) n++;
    return n;
  endfunction
  function bit nderr_seen();
    foreach (so[i]) if ((so[i][71] && so[i][36:35] == 2'b11) || (so[i][312] && so[i][114:113] == 2'b11)) return 1;
    return 0;
  endfunction
  function bit [6:0] errs();
    bit [6:0] e = 0;
    foreach (so[i]) e |= so[i][321:315];
    return e;
  endfunction
  function bit cancel_seen();
    foreach (mo[i]) if (mo[i][378] && mo[i][178:175] == 4'h7) return 1;
    return 0;
  endfunction
  function bit dmt_seen();
    foreach (so[i]) if (so[i][312] && so[i][112:109] == 4'h4 && so[i][82:76] != 7'h05) return 1;
    return 0;
  endfunction
  // request sizes seen: bit s set for a ReadNoSnp / WriteNoSnp* of Size s
  function bit [7:0] sizes();
    bit [7:0] m = 0;
    foreach (mo[i]) if (mo[i][137] && !mo[i][57] && mo[i][63:61] == 0) m[mo[i][60:58]] = 1;
    return m;
  endfunction

  function void do_copy(uvm_object rhs);
    chih_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mo = rhs_.mo;
    so = rhs_.so;
    kind = rhs_.kind;
    size = rhs_.size;
    addr = rhs_.addr;
    txn = rhs_.txn;
    dmt = rhs_.dmt;
    ord = rhs_.ord;
    sub = rhs_.sub;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    chih_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(chih_transaction rhs_);
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    return 1;
  endfunction

  function string qstr_mo();
    string s = $sformatf("[%0d]{", mo.size());
    foreach (mo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", mo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("CHIH{tag=%0d mo=%s so=%s}", tag, qstr_mo(), qstr_so());
  endfunction
endclass
