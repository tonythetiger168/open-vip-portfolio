// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_compliance_checker.sv -- CHIH concurrent assertion checks (bindable)

module chih_compliance_checker
  (input logic clk, input logic rst_n, input logic rxreqflitv, input logic [136:0] rxreqflit, input logic rxreqlcrdv, input logic rxdatflitv, input logic [239:0] rxdatflit, input logic rxdatlcrdv, input logic txrspflitv, input logic [70:0] txrspflit, input logic txrsplcrdv, input logic txdatflitv, input logic [239:0] txdatflit, input logic txdatlcrdv, input logic [6:0] err);

  // outputs are never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({rxreqlcrdv, rxdatlcrdv, txrspflitv, txdatflitv, err}))
    else $error("CHI-H: X on a valid / credit / err output");
  // a protocol flit has a non-zero opcode (B13.10)
  assert property (@(posedge clk) disable iff (!rst_n) txrspflitv |-> txrspflit[34:30] != 5'h00)
    else $error("CHI-H: RSP flit with opcode 0");
  assert property (@(posedge clk) disable iff (!rst_n) txdatflitv |-> txdatflit[40:37] != 4'h0)
    else $error("CHI-H: DAT flit with opcode 0");
  // the SN's flits come from the SN, and DBID's upper 4 bits in DAT are MBZ (Table B13.9)
  assert property (@(posedge clk) disable iff (!rst_n) txrspflitv |-> txrspflit[17:11] == 7'h20)
    else $error("CHI-H: RSP SrcID is not the SN");
  assert property (@(posedge clk) disable iff (!rst_n) txdatflitv |-> txdatflit[17:11] == 7'h20 && txdatflit[73:70] == 4'h0)
    else $error("CHI-H: DAT SrcID / DBID MBZ bits");
  // CompData is UC (Table B4.38) and its CCID names the critical chunk (B2.9.7)
  assert property (@(posedge clk) disable iff (!rst_n) txdatflitv |-> txdatflit[40:37] == 4'h4 && txdatflit[45:43] == 3'b010)
    else $error("CHI-H: SN data that is not CompData_UC");
  // the errors the tests cause on purpose: covers
  cover property (@(posedge clk) disable iff (!rst_n) err[0]);
  cover property (@(posedge clk) disable iff (!rst_n) err[1]);
  cover property (@(posedge clk) disable iff (!rst_n) err[2]);
  cover property (@(posedge clk) disable iff (!rst_n) err[3]);
  cover property (@(posedge clk) disable iff (!rst_n) err[4]);
  cover property (@(posedge clk) disable iff (!rst_n) err[5]);
  cover property (@(posedge clk) disable iff (!rst_n) err[6]);
  cover property (@(posedge clk) disable iff (!rst_n) txrspflitv && txrspflit[34:30] == 5'h08);
  cover property (@(posedge clk) disable iff (!rst_n) txdatflitv && txdatflit[42:41] == 2'b11);
endmodule
