// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_if.sv -- CHIH interface

interface chih_if (input logic clk);
  logic rst_n;

  logic rxreqflitv;
  logic [136:0] rxreqflit;
  logic rxreqlcrdv;
  logic rxdatflitv;
  logic [239:0] rxdatflit;
  logic rxdatlcrdv;
  logic txrspflitv;
  logic [70:0] txrspflit;
  logic txrsplcrdv;
  logic txdatflitv;
  logic [239:0] txdatflit;
  logic txdatlcrdv;
  logic [6:0] err;

  modport DUT (input clk, rst_n, input rxreqflitv, input rxreqflit, input rxdatflitv, input rxdatflit, input txrsplcrdv, input txdatlcrdv, output rxreqlcrdv, output rxdatlcrdv, output txrspflitv, output txrspflit, output txdatflitv, output txdatflit, output err);
  modport MON (input clk, rst_n, rxreqflitv, rxreqflit, rxreqlcrdv, rxdatflitv, rxdatflit, rxdatlcrdv, txrspflitv, txrspflit, txrsplcrdv, txdatflitv, txdatflit, txdatlcrdv, err);

  clocking drv_cb @(posedge clk);
    input rst_n, rxreqlcrdv, rxdatlcrdv, txrspflitv, txrspflit, txdatflitv, txdatflit, err;
    inout rxreqflitv, rxreqflit, rxdatflitv, rxdatflit, txrsplcrdv, txdatlcrdv;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, rxreqflitv, rxreqflit, rxreqlcrdv, rxdatflitv, rxdatflit, rxdatlcrdv, txrspflitv, txrspflit, txrsplcrdv, txdatflitv, txdatflit, txdatlcrdv, err;
  endclocking
endinterface
