// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_coverage.svh -- CHIH functional coverage

class chih_coverage extends uvm_subscriber #(chih_transaction);
  `uvm_component_utils(chih_coverage)
  chih_config cfg;
  chih_transaction tr;

  covergroup chih_cg;
    cp_e0    : coverpoint tr.errs()[0];
    cp_e1    : coverpoint tr.errs()[1];
    cp_e2    : coverpoint tr.errs()[2];
    cp_e3    : coverpoint tr.errs()[3];
    cp_e4    : coverpoint tr.errs()[4];
    cp_e5    : coverpoint tr.errs()[5];
    cp_e6    : coverpoint tr.errs()[6];
    cp_rr    : coverpoint tr.n_rsp(5'h08) { bins none = {0}; bins some = {[1:$]}; }
    cp_dbid  : coverpoint tr.n_rsp(5'h05) { bins none = {0}; bins one = {1}; bins more = {[2:$]}; }
    cp_cdata : coverpoint tr.n_dat(4'h4) { bins none = {0}; bins one = {1}; bins two = {2}; bins four = {[4:$]}; }
    cp_nderr : coverpoint tr.nderr_seen();
    cp_cncl  : coverpoint tr.cancel_seen();
    cp_dmt   : coverpoint tr.dmt_seen();
    cp_s0    : coverpoint tr.sizes()[0] { bins seen = {1}; }
    cp_s3    : coverpoint tr.sizes()[3] { bins seen = {1}; }
    cp_s4    : coverpoint tr.sizes()[4] { bins seen = {1}; }
    cp_s5    : coverpoint tr.sizes()[5] { bins seen = {1}; }
    cp_s6    : coverpoint tr.sizes()[6] { bins seen = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    chih_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(chih_config)::get(this, "", "cfg", cfg))
      cfg = chih_config::type_id::create("cfg");
  endfunction

  function void write(chih_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    chih_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CHIH coverage: %0.1f%%", chih_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
