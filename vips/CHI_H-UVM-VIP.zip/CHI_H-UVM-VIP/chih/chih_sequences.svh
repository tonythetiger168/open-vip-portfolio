// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_sequences.svh -- CHIH sequences

// Random traffic: cfg.num_items constrained-random items.
class chih_base_sequence extends uvm_sequence #(chih_transaction);
  `uvm_object_utils(chih_base_sequence)
  chih_config cfg;

  function new(string name = "chih_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = chih_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "chih_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class chih_directed_sequence extends uvm_sequence #(chih_transaction);
  `uvm_object_utils(chih_directed_sequence)
  chih_config cfg;

  function new(string name = "chih_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function chih_transaction item();
    item = chih_transaction::type_id::create("req");
  endfunction

  task send(chih_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    chih_transaction t;
    // every request type and size, DMT, ReadReceipt, write data rules, every error
    t = item(); t.set(1, 6, 10'h040, 12'hABC, 0, 0, 0, 32'h11); send(t);       // WriteNoSnpFull, 12-bit TxnID
    t = item(); t.set(0, 6, 10'h040, 12'hF01, 0, 0); send(t);                   // read it back
    t = item(); t.set(0, 6, 10'h040, 12'h123, 1, 1); send(t);                   // DMT + ReadReceipt
    for (int s = 0; s <= 6; s++) begin
      t = item(); t.set(2, s, 10'h080 + 10'(s * 9), 12'h200 + s, 0, 0, 0, 32'h20 + s); send(t);   // Ptl, every size
      t = item(); t.set(0, s, 10'h080 + 10'(s * 9), 12'h300 + s, s % 2, (s % 3) == 0); send(t);
    end
    t = item(); t.set(2, 6, 10'h0D3, 12'h400, 0, 0, 1, 32'h31); send(t);       // Device: BE at or above Addr
    t = item(); t.set(3, 5, 10'h120, 12'h401, 0, 0, 0, 32'h32); send(t);       // cancelled
    t = item(); t.set(0, 5, 10'h120, 12'h402); send(t);
    t = item(); t.set(4, 6, 10'h000, 12'h403, 1, 0, 2); send(t);               // NDERR read
    t = item(); t.set(5, 6, 10'h1C0, 12'h404, 0, 0, 3, 32'h33); send(t);       // NDERR write
    t = item(); t.set(6, 6, 10'h200, 12'h410); send(t);                         // four reads
    t = item(); t.set(7, 6, 10'h240, 12'h420); send(t);                         // without L-credits
    t = item(); t.set(0, 6, 10'h240, 12'h430); send(t);
    for (int s = 0; s < 4; s++) begin t = item(); t.set(8, 4, 10'h010, 12'h440 + s, 0, 0, s); send(t); end
    for (int s = 0; s < 4; s++) begin t = item(); t.set(9, 4, 10'h010, 12'h450 + s, 0, 0, s); send(t); end
    for (int s = 0; s < 6; s++) begin t = item(); t.set(10, 6, 10'h010, 12'h460 + s, 0, 0, s); send(t); end
    for (int s = 0; s < 5; s++) begin
      t = item(); t.set(11, (s == 1) ? 4 : 5, (s == 0) ? 10'h305 : 10'h300, 12'h470 + s, 0, 0, s, 32'h40 + s); send(t);
    end
    t = item(); t.set(12); send(t);                                            // credit overflow
    t = item(); t.set(13, 6, 10'h3C0, 12'hFFE, 0, 0, 0, 32'h55); send(t);      // write + read, DBID wraps
    t = item(); t.set(0, 3, 10'h3C8, 12'h7FF); send(t);
  endtask
endclass
