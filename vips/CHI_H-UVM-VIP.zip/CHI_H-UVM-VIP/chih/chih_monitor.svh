// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_monitor.svh -- CHIH monitor: every clock's flits and L-credits; an item starts at the first flit or credit and ends after cfg.gap quiet clocks

class chih_monitor extends uvm_monitor;
  `uvm_component_utils(chih_monitor)

  virtual chih_if vif;
  uvm_analysis_port #(chih_transaction) ap;
  chih_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual chih_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "chih: virtual interface not set")
    if (!uvm_config_db#(chih_config)::get(this, "", "cfg", cfg))
      cfg = chih_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      // the SN acts on its own from the first clock after reset (it grants L-credits),
      // so every clock from there on belongs to some item
      bit started = 1;
      bit [380:0] pend_mo [$];
      bit [321:0] pend_so [$];
      wait (vif.rst_n === 1'b1);
      forever begin
        chih_transaction t = null;
        int q = 0;
        forever begin
          bit [380:0] m;
          bit [321:0] o;
          bit act;
          @(vif.mon_cb);
          m = {vif.mon_cb.txdatlcrdv, vif.mon_cb.txrsplcrdv, vif.mon_cb.rxdatflitv, vif.mon_cb.rxdatflit,
               vif.mon_cb.rxreqflitv, vif.mon_cb.rxreqflit};
          o = {vif.mon_cb.err, vif.mon_cb.rxdatlcrdv, vif.mon_cb.rxreqlcrdv, vif.mon_cb.txdatflitv, vif.mon_cb.txdatflit,
               vif.mon_cb.txrspflitv, vif.mon_cb.txrspflit};
          act = m[380] | m[379] | m[378] | m[137] | o[314] | o[313] | o[312] | o[71];
          if (t == null && act) begin
            t = chih_transaction::type_id::create("t");
            if (started) begin t.mo = pend_mo; t.so = pend_so; end
            pend_mo.delete(); pend_so.delete();
            started = 1;
          end
          if (t == null) begin
            if (started) begin pend_mo.push_back(m); pend_so.push_back(o); end
          end else begin
            t.mo.push_back(m); t.so.push_back(o);
            q = act ? 0 : q + 1;
          end
          if (t != null && q == cfg.gap) break;
        end
        publish(t);
      end
    end
  endtask

  function void publish(chih_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
