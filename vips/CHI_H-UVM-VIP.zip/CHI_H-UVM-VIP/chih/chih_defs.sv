// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_defs.sv -- CHIH shared type definitions

package chih_defs_pkg;

  typedef enum bit [1:0] {CHIH_OK, CHIH_ERR} chih_status_e;

  localparam bit [6:0] CHIH_SN  = 7'h20;   // the SN-F model's NodeID
  localparam bit [6:0] CHIH_HN  = 7'h05;   // the agent's NodeID
  localparam bit [6:0] CHIH_RN  = 7'h11;   // a requester for DMT (ReturnNID)
  localparam bit [6:0] CHIH_READ_NOSNP  = 7'h04;
  localparam bit [6:0] CHIH_WRITE_PTL   = 7'h1C;
  localparam bit [6:0] CHIH_WRITE_FULL  = 7'h1D;
  localparam bit [4:0] CHIH_RSP_COMPDBID = 5'h05;
  localparam bit [4:0] CHIH_RSP_RRECEIPT = 5'h08;
  localparam bit [3:0] CHIH_DAT_NCBWR    = 4'h3;
  localparam bit [3:0] CHIH_DAT_COMPDATA = 4'h4;
  localparam bit [3:0] CHIH_DAT_CANCEL   = 4'h7;
  typedef struct packed {
    bit [6:0] tgt; bit [6:0] src; bit [11:0] txn; bit [6:0] rnid; bit [11:0] rtxn; bit [6:0] op;
    bit mreq; bit [5:0] nreq; bit [43:0] addr; bit [1:0] order; bit [3:0] memattr;
  } chih_req_t;
  function automatic bit [136:0] chih_req(chih_req_t r);
    bit [136:0] f = '0;
    f[10:4] = r.tgt; f[17:11] = r.src; f[29:18] = r.txn; f[36:30] = r.rnid; f[49:38] = r.rtxn;
    f[56:50] = r.op; f[57] = r.mreq; f[63:58] = r.nreq; f[107:64] = r.addr; f[114:113] = r.order;
    f[122:119] = r.memattr;
    return f;
  endfunction
  // RSP / DAT flits as the SN builds them
  function automatic bit [70:0] chih_rsp(bit [6:0] tgt, bit [11:0] txn, bit [4:0] op, bit [1:0] re, bit [11:0] dbid);
    bit [70:0] f = '0;
    f[10:4] = tgt; f[17:11] = CHIH_SN; f[29:18] = txn; f[34:30] = op; f[36:35] = re; f[57:46] = dbid;
    return f;
  endfunction
  function automatic bit [239:0] chih_dat(bit [6:0] tgt, bit [6:0] src, bit [11:0] txn, bit [6:0] home, bit [3:0] op,
                                          bit [1:0] re, bit [2:0] resp, bit [11:0] dbid, bit [1:0] ccid, bit [1:0] did,
                                          bit [15:0] be, bit [127:0] d);
    bit [239:0] f = '0;
    f[10:4] = tgt; f[17:11] = src; f[29:18] = txn; f[36:30] = home; f[40:37] = op; f[42:41] = re; f[45:43] = resp;
    f[73:58] = {4'b0, dbid}; f[75:74] = ccid; f[77:76] = did; f[111:96] = be; f[239:112] = d;
    return f;
  endfunction
  // data window of a request (B2.9.3): byte offset b of packet DataID d is inside
  function automatic bit chih_in_win(bit [5:0] a, bit [2:0] size, int d, int b);
    int base = a & ~((1 << size) - 1);
    int o = d * 16 + b;
    return o >= base && o < base + (1 << size);
  endfunction
  function automatic int chih_npk(bit [2:0] size); return (size <= 4) ? 1 : (1 << (size - 4)); endfunction
  function automatic int chih_did0(bit [5:0] a, bit [2:0] size); return (size >= 6) ? 0 : ((a & ~((1 << size) - 1)) >> 4); endfunction

endpackage
