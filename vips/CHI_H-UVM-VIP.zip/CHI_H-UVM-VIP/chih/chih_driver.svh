// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chih_driver.svh -- CHIH driver: one item per scenario: REQ flits (ReadNoSnp / WriteNoSnp* or a broken request) under L-credits, the write data after each CompDBIDResp, L-credits granted back to the SN for its RSP / DAT flits, then cfg.gap quiet clocks

class chih_driver extends uvm_driver #(chih_transaction);
  `uvm_component_utils(chih_driver)

  uvm_analysis_port #(chih_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual chih_if vif;
  chih_config cfg;

  int        rq_cr = 4, dt_cr = 4;       // L-credits the SN granted us (all 4 by the first item)
  int        sn_rs = 0, sn_dt = 0;       // L-credits we granted the SN
  int        ovf = 0;                    // extra RSP credits to grant (overflow test)
  bit [136:0] req_q [$];
  bit        req_force [$];              // send even without an L-credit
  bit [239:0] dat_q [$];
  bit [239:0] wq_pk [$];                 // write packets waiting for CompDBIDResp
  bit        wq_bad [$];                 // that packet goes out with a wrong TxnID
  int        wq_n [$];                   // packets per write, in request order
  bit [31:0] rs = 32'h1;
  bit        first = 1;
  chih_transaction cur;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual chih_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "chih: virtual interface not set")
    if (!uvm_config_db#(chih_config)::get(this, "", "cfg", cfg))
      cfg = chih_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    chih_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.rxreqflitv <= 1'b0; vif.drv_cb.rxreqflit <= '0;
    vif.drv_cb.rxdatflitv <= 1'b0; vif.drv_cb.rxdatflit <= '0;
    vif.drv_cb.txrsplcrdv <= 1'b0; vif.drv_cb.txdatlcrdv <= 1'b0;
  endtask

  task drive_item(chih_transaction t);
    bit a;
    bit [43:0] ad = {34'h0, t.addr};
    bit [2:0] sz = (t.size > 6) ? 3'd6 : t.size;
    cur = t;
    t.mo.delete();
    // the 4 idle clocks after reset (run_phase) open the first item, as the monitor sees them
    if (first) begin repeat (4) t.mo.push_back('0); first = 0; end
    rs = t.seed ^ 32'h9E37_79B9;
    if (rs == 0) rs = 1;
    case (t.kk())
      0: mkreq(CHIH_READ_NOSNP, ad, sz, t.txn, t.dmt, t.ord ? 2'b01 : 2'b00);
      1: begin mkreq(CHIH_WRITE_FULL, ad, 3'd6, t.txn); wdata(ad, 3'd6, 1); end
      2: begin
        mkreq(CHIH_WRITE_PTL, ad, sz, t.txn, 0, 0, CHIH_SN, t.sub[0] ? 4'b0010 : 4'b0101);
        wdata(ad, sz, t.sub[0] ? 3 : 0);
      end
      3: begin mkreq(CHIH_WRITE_PTL, ad, sz, t.txn); wdata(ad, sz, 2); end
      4: mkreq(CHIH_READ_NOSNP, ad | 44'h400 << t.sub, sz, t.txn, t.dmt);
      5: begin mkreq(CHIH_WRITE_FULL, ad | 44'h800_0000_0000 >> t.sub, 3'd6, t.txn); wdata(ad, 3'd6, 1); end
      6: for (int i = 0; i < 4; i++) mkreq(CHIH_READ_NOSNP, ad ^ (i << 6), 3'(4 + i % 3), t.txn + i, i[0], i[1] ? 2'b01 : 2'b00);
      7: for (int i = 0; i < 6; i++) mkreq(CHIH_READ_NOSNP, ad ^ (i << 6), 3'd6, t.txn + i, 0, 0, CHIH_SN, 4'b0101, 0, 0, 1);
      8: mkreq(CHIH_READ_NOSNP, ad, sz, t.txn, 0, 0, CHIH_SN ^ 7'(1 + t.sub));
      9: mkreq((t.sub[1:0] == 0) ? 7'h01 : (t.sub[1:0] == 1) ? 7'h19 : (t.sub[1:0] == 2) ? 7'h44 : 7'h3A, ad, sz, t.txn);
      10: case (t.sub % 5)
        0: mkreq(CHIH_READ_NOSNP, ad, sz, t.txn, 0, 0, CHIH_SN, 4'b0101, 1);           // MultiReq
        1: mkreq(CHIH_READ_NOSNP, ad, sz, t.txn, 0, 0, CHIH_SN, 4'b0101, 0, 3'b100);   // NumReq bits of {3'b0, Size}
        2: mkreq(CHIH_READ_NOSNP, ad, 3'd7, t.txn);                                    // Size 128 bytes
        3: mkreq(CHIH_READ_NOSNP, ad, sz, t.txn, 0, t.sub[0] ? 2'b10 : 2'b11);         // reserved Order
        default: mkreq(CHIH_WRITE_FULL, ad, (sz == 6) ? 3'd5 : sz, t.txn);             // Full, Size != 6
      endcase
      11: begin
        int b = t.sub % 5;
        bit full = (b == 2);
        mkreq(full ? CHIH_WRITE_FULL : CHIH_WRITE_PTL, ad, full ? 3'd6 : sz, t.txn);
        wdata(ad, full ? 3'd6 : sz, (b == 2) ? 1 : (b == 3) ? 2 : 0, b);
      end
      12: ovf = 17;
      13: begin
        mkreq(CHIH_WRITE_FULL, ad, 3'd6, t.txn); wdata(ad, 3'd6, 1);
        mkreq(CHIH_WRITE_PTL, ad | 44'h10, 3'd4, t.txn + 1); wdata(ad | 44'h10, 3'd4, 0);
        mkreq(CHIH_READ_NOSNP, ad, 3'd6, t.txn + 2);
      end
      default: ;
    endcase
    while (req_q.size() || dat_q.size() || wq_n.size() || ovf > 0) begin
      int w = 0;
      clk1(a);
      if (++w > 400 && wq_n.size()) begin wq_n.delete(); wq_pk.delete(); wq_bad.delete(); end
    end
    quiet();
    // at a quiet point every L-credit is back where it started
    rq_cr = 4; dt_cr = 4;
  endtask

  function bit [31:0] rnd();
    rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5;
    return rs;
  endfunction
  function bit [127:0] rnd128(); return {rnd(), rnd(), rnd(), rnd()}; endfunction
  // one clock: drive the HN side, then look at what the SN sent
  task automatic clk1(output bit act);
    bit rv = 0, dv = 0, rc = 0, dc = 0;
    bit [136:0] rf = '0;
    bit [239:0] df = '0;
    if (req_q.size() && (rq_cr > 0 || req_force[0])) begin
      rf = req_q.pop_front(); void'(req_force.pop_front()); rv = 1; rq_cr--;
    end
    if (dat_q.size() && dt_cr > 0) begin df = dat_q.pop_front(); dv = 1; dt_cr--; end
    if (ovf > 0) begin rc = 1; ovf--; if (sn_rs < 15) sn_rs++; end
    else if (sn_rs < 2) begin rc = 1; sn_rs++; end
    if (sn_dt < 2) begin dc = 1; sn_dt++; end
    vif.drv_cb.rxreqflitv <= rv; vif.drv_cb.rxreqflit <= rf;
    vif.drv_cb.rxdatflitv <= dv; vif.drv_cb.rxdatflit <= df;
    vif.drv_cb.txrsplcrdv <= rc; vif.drv_cb.txdatlcrdv <= dc;
    cur.mo.push_back({dc, rc, dv, df, rv, rf});
    @(vif.drv_cb);
    act = rv | dv | rc | dc;
    if (vif.drv_cb.rxreqlcrdv === 1'b1) begin rq_cr++; act = 1; end
    if (vif.drv_cb.rxdatlcrdv === 1'b1) begin dt_cr++; act = 1; end
    if (vif.drv_cb.txdatflitv === 1'b1) begin sn_dt--; act = 1; end
    if (vif.drv_cb.txrspflitv === 1'b1) begin
      bit [70:0] f = vif.drv_cb.txrspflit;
      sn_rs--; act = 1;
      if (f[34:30] == CHIH_RSP_COMPDBID && wq_n.size()) begin
        int n = wq_n.pop_front();
        repeat (n) begin
          bit [239:0] p = wq_pk.pop_front();
          bit b = wq_bad.pop_front();
          p[10:4] = f[17:11];
          p[29:18] = b ? (f[57:46] ^ 12'h001) : f[57:46];
          dat_q.push_back(p);
          if (b) begin p[29:18] = f[57:46]; dat_q.push_back(p); end   // then the right one
        end
      end
    end
  endtask
  task automatic quiet();
    int q = 0;
    bit a;
    while (q < cfg.gap) begin clk1(a); q = a ? 0 : q + 1; end
  endtask
  function void mkreq(bit [6:0] op, bit [43:0] a, bit [2:0] sz, bit [11:0] tx, bit d = 0, bit [1:0] o = 0,
                    bit [6:0] tgt = CHIH_SN, bit [3:0] ma = 4'b0101, bit mr = 0, bit [2:0] hi = 0, bit force_ = 0);
    chih_req_t r;
    r.tgt = tgt; r.src = CHIH_HN; r.txn = tx; r.rnid = d ? CHIH_RN : CHIH_HN; r.rtxn = d ? (tx ^ 12'hA5A) : tx;
    r.op = op; r.mreq = mr; r.nreq = {hi, sz}; r.addr = a; r.order = o; r.memattr = ma;
    req_q.push_back(chih_req(r));
    req_force.push_back(force_);
  endfunction
  // write data packets for Addr / Size; mode 0 random BE (Ptl), 1 all BE (Full),
  // 2 cancel, 3 BE only at or above Addr (Device), 4.. broken (see drv_item)
  function void wdata(bit [43:0] a, bit [2:0] sz, int mode, int bad = -1);
    int n = chih_npk(sz), d0 = chih_did0(a[5:0], sz);
    for (int k = 0; k < n; k++) begin
      int d = d0 + k;
      bit [15:0] be = 0;
      bit [127:0] dt = rnd128();
      bit [239:0] p = '0;
      for (int b = 0; b < 16; b++) begin
        bit w = chih_in_win(a[5:0], sz, d, b);
        case (mode)
          0: be[b] = w && rnd()[0];
          1: be[b] = w;
          3: be[b] = w && (d * 16 + b >= a[5:0]) && rnd()[0];
          default: be[b] = 0;
        endcase
        if (!be[b]) dt[8*b +: 8] = 8'h00;
      end
      if (k == 0) case (bad)
        0: be[15 - (a[3:0] == 4'hF)] = 1;                          // probably outside the window
        1: dt[8 * (be[0] ? 1 : 0) +: 8] = 8'h5A;                   // data under BE = 0 (if that BE is 0)
        2: be[d * 16 >= (a[5:0] & ~((1 << sz) - 1)) ? 0 : 15] = 0; // Full without every BE
        3: be[0] = 1;                                              // cancel with a BE
        default: ;
      endcase
      p[17:11] = CHIH_HN;
      p[40:37] = (mode == 2) ? CHIH_DAT_CANCEL : CHIH_DAT_NCBWR;
      p[75:74] = a[5:4]; p[77:76] = d; p[111:96] = be; p[239:112] = dt;
      wq_pk.push_back(p);
      wq_bad.push_back(bad == 4 && k == 0);
    end
    wq_n.push_back(n);
  endfunction
endclass
