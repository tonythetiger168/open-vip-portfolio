# USB Power Delivery Test Plan（USB_PD-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | USB PD 3.x sink (physical / protocol layer + policy engine) |
| 家族 | USB |
| 類型 | UVM VIP |
| 交付目錄 | `USB_PD-VIP/` |
| 目前 L1b 狀態 | PASS |

## 2. DUT / 待測對象

- `usb_pd_smoke_model`（PD 3.x sink port：4b5b framing、ordered set 3-of-4、CRC-32、GoodCRC / MessageID / retry、sink policy engine 與計時器）
- `usb3_phy_model`、`usb4_phy_model`、`pd_controller_model`（umbrella top 的 loopback model，沿用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | in reset: Disabled, outputs cleared; VBUS -> Wait_for_Capabilities at vSafe5V | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | SinkWaitCap timeout: Hard Reset twice (HardResetCounter), then ErrorRecovery | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | first contract: highest fixed PDO within want_v50 / want_ma10, Request contents, Accept -> PS_RDY -> explicit contract | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | GoodCRC with the received MessageID 3 clocks after EOP; duplicate MessageID acknowledged but not passed on | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | Ping ignored, Get_Sink_Cap -> Sink_Capabilities | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | dropped packets: bad CRC, invalid symbol, odd nibble count, wrong length, over 34 bytes; SOP' / SOP'' (also with one wrong K-code) not for this port | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | ordered sets: SOP with one wrong K-code accepted, two wrong ignored; Cable Reset ignored | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | renegotiation: Capability Mismatch, APDO / battery PDOs skipped | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | Reject / Wait keep the old contract; with no contract back to Wait_for_Capabilities | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | Not_Supported for unknown messages; out-of-place Accept / PS_RDY -> Soft_Reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | source Soft_Reset -> Accept with MessageID 0, counters cleared | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | retries: no GoodCRC -> same message 3 times (nRetryCount 2), then Hard Reset; GoodCRC on the 2nd try | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | SenderResponse and PSTransition timeouts -> Hard Reset; a data message with the PS_RDY type code in Transition_Sink -> Hard Reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | Hard Reset from the source (3 of 4 K-codes): contract dropped, vSafe5V, stray RST-2 ignored | 檢查成立，`FUNC_PASS` 輸出 |
| FS-15 | Soft_Reset never acknowledged / never accepted -> Hard Reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-16 | Not_Supported never acknowledged -> Soft_Reset; Accept for the source's Soft_Reset never acknowledged -> Hard Reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-17 | VBUS lost in a contract: Disabled; stored MessageID forgotten on detach | 檢查成立，`FUNC_PASS` 輸出 |
| FS-18 | MessageIDCounter keeps counting over control messages | 檢查成立，`FUNC_PASS` 輸出 |
| FS-19 | reset with VBUS present: Reject with no prior contract | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Source port policy engine and PR_Swap / DR_Swap / VCONN_Swap |
| PT-02 | Extended messages and chunking |
| PT-03 | PPS / AVS programmable supplies, EPR mode |
| PT-04 | BMC line coding and preamble |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/usb_pd_compliance_checker.sv`（L1 signal sanity 4、L2 framing 4、L3 policy engine 5、L4 protocol layer 4、L5 receive counters 3，加 10 個 cover）
- Functional coverage：`vip/usbpd/usb_pd_link_pkg.sv` 的 `usb_pd_coverage`（30 個 policy-engine 轉移 bin、receive good / bad / dup / other SOP / retry）
- Scoreboard：`usb_pd_scoreboard` 逐 clock 預測 sink：每個 policy-engine 轉移（訊息、GoodCRC、送出失敗、SinkWaitCap / SenderResponse / PSTransition / Hard Reset 計時器、VBUS、雙向 Hard Reset）、每個狀態送出的訊息內容、GoodCRC 時序、retry 間隔、MessageIDCounter、contract 與 VBUS 電壓、計數器

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/USB_PD-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py USB_PD-VIP && python3 smoke/smoke_run.py USB_PD-VIP   # L1b
python3 tools/run_uvm_tests.py USB_PD-VIP       # UVM（Verilator），期望 SB_PASS
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 行為級 model 以每 clock 一個 symbol / link item 建模，不含 PHY 類比層（BMC / 8b10b / 128b132b 串列化、LFPS 波形）。

---
*文件版本：v1.8.0*
