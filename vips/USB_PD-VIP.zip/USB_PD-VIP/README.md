# USB-PD Protocol VIP — Unified Multi-Protocol Verification IP

## 前言概述 (Protocol Overview)

USB Power Delivery 驗證重點：SOP* message 序列
(header + data objects)、BMC 雙相編碼 (CC1/CC2 differential)、
GoodCRC 回應 (tReceive)、電源套約談判
(Source Capabilities→Request→Accept→PS_RDY→Vbus 轉換)、
5V–48V EPR 電壓範圍、PPS。

本 VIP 為 USB 系列統一架構：單一環境涵蓋 7 種協議
(USB 2.0 / 3.0 / 3.1 / 3.2 / USB4 / eUSB2 / USB-PD)，本專案聚焦於 **USB-PD Protocol VIP**。

## 架構 (Architecture)

```
top_tb.sv
 ├─ usb_vip_if × 7 (MAC + PHY 雙層, clocking blocks, modports, IF assertions)
 └─ usb_dut (functional DUT model)
     ├─ usb2_dev_ep ×2     USB2/eUSB2 device endpoint: chirp response,
     │                      CRC16 檢查, ACK/STALL/timeout, babble detect
     ├─ usb3_phy_model ×3  PIPE PHY: LTSSM walk→U0, CRC32 check, loopback ACK
     ├─ usb4_phy_model     PIPE4 PHY: link ready, router sideband, loopback
     └─ pd_controller_model PD controller: header decode, Vbus transition
usb_env
 ├─ usb_agent × 7 (usb_sequencer / usb_driver / usb_monitor)
 ├─ usb_scoreboard  expected(drv_ap→exp_imp) vs observed(mon→analysis_imp)
 │                   pairwise compare, n_matches/n_mismatches, UVM_ERROR on mismatch
 ├─ usb_coverage_model × 4 (8 covergroups, 見下)
 └─ *_protocol_checker × 5 (procedural protocol checks + covergroups)
```

Closed loop：driver 依 transaction descriptor 送出 token/data packet
（含 CRC16/CRC32 trailer，data packet 以 `mac_frame_num` 作 sideband byte count），
DUT 依位址/endpoint/CRC 決定 ACK/STALL/timeout/babble，monitor 從 MAC/PHY
波形解碼 PID→packet type、重組 payload（剝除 CRC trailer）、觀察 handshake，
scoreboard 端到端比對。

## Sequence 清單

| Sequence | 類型 | 說明 |
|----------|------|------|
| `usb_base_sequence` | base | 共用參數/constraint |
| `usb_random_sequence` | random | protocol-weighted 隨機流量 (90% 打到 DUT 位址) |
| `usb_normal_seq` | directed | 正常 SETUP/IN/OUT/DATA, ACK 路徑 |
| `usb_error_inject_seq` | directed | CRC 腐敗 / timeout(未實作位址) / STALL(EP15) / babble(超長) |
| `usb_reset_seq` | directed | bus reset (SE0) 後重新列舉 |
| `usb_back_to_back_seq` | directed | 最小 inter-packet gap (=2) 背靠背 |
| `usb_stress_seq` | directed | 大 payload (256–512B) 高速率壓力 |
| `usb_corner_seq` | directed | ZLP / 1-byte / max-packet / DATA0-DATA1 toggle / 邊界 EP |
| `usb_sof_seq` | directed | SOF frame stream (11-bit frame number) |
| `usb_regression_sequence` | regression | 加權混合 regression |
| `usb_directed_regression_sequence` | regression | directed library 全掃 |

Tests：`usb_random_regression_test` (預設), `usb_directed_test`,
`usb_hs_test`, `usb_ss_test`, `usb_ssp_test`, `usb_ss20_test`,
`usb4_test`, `usb_eusb2_test`, `usb_pd_test`。

## SVA 清單 (rtl/sva/usb_pd_compliance_checker.sv, module on usb_pd_link_if)

每個違規都是 `UVM_ERROR`：
- **L1 signal sanity (4)**：合法 policy-engine 編碼、state / tx_valid / contract / MessageIDCounter 無 X、送出的 symbol 無 X、symbol 只能是 4b5b data 或 sink 會送的 K-code
- **L2 framing (4)**：frame 以 Sync-1 / RST-1 開頭、ordered set 只能是 SOP 或 Hard Reset、frame 內沒有空檔、EOP 只在 frame 內
- **L3 policy engine (5)**：VBUS 消失 → Disabled、contract 只在 contract 狀態、Hard Reset 丟掉 contract 並回 vSafe5V、contract 只在 PS_RDY 開始、Disabled 時無 VBUS 電壓
- **L4 protocol layer (4)**：retries / hard_resets / MessageIDCounter 每次只動一步、ErrorRecovery 只在 nHardResetCount 之後
- **L5 receive counters (3)**：每個計數器只因自己的原因變動
- 10 個 cover：contract、送出 Hard Reset、進入 Hard Reset、ErrorRecovery、retry、duplicate、SOP' / SOP''、bad packet、Capability Mismatch、contract 中 VBUS 消失

## Functional Coverage 清單

`usb_coverage_model` (8 covergroups，含 cross)：
`cg_txn_type` (protocol×type cross)、`cg_endpoint` (ep×type cross)、
`cg_packet_size` (size×protocol cross)、`cg_device_state` (FSM transition bins,
state×protocol cross)、`cg_phy_layer` (phy_if×term cross)、
`cg_pd_contract` (contract×voltage cross)、`cg_error_injection` (err×recovery cross)、
`cg_data_pattern` (first-byte pattern×length cross)。
Interface covergroup：`cg_usb_interface` (MAC handshake × device state cross)。
各 protocol checker 另有專屬 covergroup + cross。

## 快速上手 (Quick Start)

```sh
cd scripts
make compile           # VCS: pkg → checkers → if → sequences → env → tests → tb
make simulate TEST=usb_random_regression_test
make simulate TEST=usb_directed_test
make coverage          # 見 scripts/coverage.mk
```

環境變數 `TEST` 選擇測試；`UVM_VERBOSITY` 控制訊息等級。
regression 結束時 scoreboard 回報 `n_matches/n_mismatches`，
compliance checker 回報 L1/L2/L3/L4 tiered coverage。

## Deepened Features (v1.8.0)

- **Sink port model** (`tb/usb_pd_smoke_model.sv`): 4b5b framing with 3-of-4 ordered-set detection (SOP / SOP' / SOP'' / Hard Reset / Cable Reset), CRC-32, GoodCRC, duplicate MessageID filtering, retries (nRetryCount 2), Soft_Reset both ways, and a sink policy engine (Wait_for_Capabilities, Select_Capability, Transition_Sink, Ready, Give_Sink_Cap, Not_Supported, Soft_Reset, Hard Reset, ErrorRecovery) with SinkWaitCap / SenderResponse / PSTransition / Hard Reset timers and HardResetCounter
- **Functional test** (`tb/smoke_func_tb.sv`): 264 self-checks
- **UVM agent** (`vip/usbpd/usb_pd_link_pkg.sv` on `usb_pd_link_if`): source-side driver with CRC / symbol / length / K-code error injection, a scoreboard that predicts every policy-engine transition clock by clock and the content and timing of every sink frame, coverage of all 30 policy-engine transitions (`usb_pd_link_test`, runs on Verilator)
- **SVA**: `rtl/sva/usb_pd_compliance_checker.sv` rewritten on the PD interface (20 assertions, 10 covers)
- **Fixed**: a failed Not_Supported / Sink_Capabilities send now queues the Soft_Reset (the policy engine used to wait in Send_Soft_Reset forever); a detach clears the stored MessageID

