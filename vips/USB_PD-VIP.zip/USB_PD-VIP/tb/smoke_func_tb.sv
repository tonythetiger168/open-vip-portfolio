// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
`timescale 1ns/1ps
//
// Self-checking functional smoke for the USB PD 3.x sink port model
// usb_pd_smoke_model (tb/usb_pd_smoke_model.sv). The bench is the source:
// it sends 4b5b-coded packets (SOP*, header, data objects, CRC-32, EOP),
// decodes every packet the sink sends and checks framing, CRC, GoodCRC
// MessageIDs and timing, retries, duplicate detection, the sink policy
// engine (Request selection, contract, Soft_Reset, Hard Reset, timers).
// Run: python3 tools/run_func_tests.py USB_PD-VIP

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic       clk = 1'b0, rst_n = 1'b0, vbus = 1'b0, rx_valid = 1'b0;
  logic [4:0] rx_sym = 5'h0;
  logic [9:0] want_v = 10'd240, want_ma = 10'd150;
  wire        tx_valid, contract, mismatch;
  wire  [4:0] tx_sym;
  wire  [3:0] pe;
  wire  [9:0] vbus_v;
  wire  [2:0] obj_pos, msg_id;
  wire  [7:0] rx_good, rx_bad, rx_dup, rx_other, retries, hard_resets;
  wire  [1:0] hr_counter;

  always #5 clk = ~clk;

  usb_pd_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .vbus_present(vbus), .rx_valid(rx_valid), .rx_sym(rx_sym),
    .want_v50(want_v), .want_ma10(want_ma), .tx_valid(tx_valid), .tx_sym(tx_sym), .pe_state(pe),
    .contract(contract), .vbus_v50(vbus_v), .obj_pos(obj_pos), .mismatch(mismatch), .msg_id(msg_id),
    .rx_good(rx_good), .rx_bad(rx_bad), .rx_dup(rx_dup), .rx_other_sop(rx_other), .retries(retries),
    .hard_resets(hard_resets), .hr_counter(hr_counter)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  localparam logic [3:0] DIS = 0, WCAP = 1, REQ = 2, WRSP = 3, TRANS = 4, READY = 5, SNKCAP = 6,
                         SRACC = 7, NS = 8, SNDSR = 9, WSRACC = 10, HRST = 11, ERR = 12;
  localparam logic [4:0] S1 = 5'h18, S2 = 5'h11, S3 = 5'h06, R1 = 5'h07, R2 = 5'h19, EOP = 5'h0D;
  localparam logic [4:0] GOODCRC = 1, ACCEPT = 3, REJECT = 4, PING = 5, PS_RDY = 6, GET_SNK = 8,
                         DR_SWAP = 9, WAIT = 12, SOFT_RST = 13, NOT_SUPP = 16;
  localparam logic [4:0] SRC_CAP = 1, REQUEST = 2, BIST = 3, SNK_CAP = 4;

  function automatic logic [4:0] enc(input logic [3:0] n);
    case (n)
      4'h0: return 5'h1E; 4'h1: return 5'h09; 4'h2: return 5'h14; 4'h3: return 5'h15;
      4'h4: return 5'h0A; 4'h5: return 5'h0B; 4'h6: return 5'h0E; 4'h7: return 5'h0F;
      4'h8: return 5'h12; 4'h9: return 5'h13; 4'hA: return 5'h16; 4'hB: return 5'h17;
      4'hC: return 5'h1A; 4'hD: return 5'h1B; 4'hE: return 5'h1C; default: return 5'h1D;
    endcase
  endfunction
  function automatic logic [31:0] crcb(input logic [31:0] c0, input logic [7:0] b);
    logic [31:0] c;
    c = c0;
    for (int i = 0; i < 8; i++) c = (c[0] ^ b[i]) ? ((c >> 1) ^ 32'hEDB8_8320) : (c >> 1);
    return c;
  endfunction
  function automatic logic [31:0] fixed_pdo(input int mv, input int ma);
    return {2'b00, 10'h000, 10'(mv / 50), 10'(ma / 10)};
  endfunction

  // ------------------------------------------------------------ source -> sink
  logic [31:0] objs [0:6];
  logic [7:0]  b [0:33];
  logic [4:0]  sop [0:3];
  int          nb, src_id = 0;
  // knobs for one packet
  int          bad_crc = 0, bad_sym_at = -1, drop_nib = 0, len_off = 0;

  task automatic sym(input logic [4:0] s);
    rx_valid = 1'b1; rx_sym = s; @(negedge clk);
  endtask
  task automatic gap(input int n);
    rx_valid = 1'b0; repeat (n) @(negedge clk);
  endtask
  task automatic set_sop(input int kind);           // 0 SOP 1 SOP' 2 SOP'' 3 Hard Reset 4 Cable Reset
    case (kind)
      0: sop = '{S1, S1, S1, S2};
      1: sop = '{S1, S1, S3, S3};
      2: sop = '{S1, S3, S1, S3};
      3: sop = '{R1, R1, R1, R2};
      default: sop = '{R1, S1, R1, S3};
    endcase
  endtask
  // a packet: sop[] then header / objects / CRC, EOP
  task automatic pkt(input logic [4:0] typ, input int ndo, input int id);
    logic [15:0] h;
    logic [31:0] c;
    h = {1'b0, 3'(ndo + len_off), 3'(id), 1'b1, 2'b10, 1'b0, typ};   // source, DFP, rev 3.0
    b[0] = h[7:0]; b[1] = h[15:8]; nb = 2;
    for (int i = 0; i < ndo; i++) begin
      b[nb] = objs[i][7:0]; b[nb + 1] = objs[i][15:8]; b[nb + 2] = objs[i][23:16]; b[nb + 3] = objs[i][31:24];
      nb += 4;
    end
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < nb; i++) c = crcb(c, b[i]);
    c = ~c ^ 32'(bad_crc);
    b[nb] = c[7:0]; b[nb + 1] = c[15:8]; b[nb + 2] = c[23:16]; b[nb + 3] = c[31:24];
    nb += 4;
    for (int i = 0; i < 4; i++) sym(sop[i]);
    for (int i = 0; i < nb; i++) begin
      if (2 * i == bad_sym_at) sym(5'h00); else sym(enc(b[i][3:0]));
      if (!(drop_nib && i == nb - 1)) sym(enc(b[i][7:4]));
    end
    sym(EOP);
    gap(1);
    bad_crc = 0; bad_sym_at = -1; drop_nib = 0; len_off = 0;
  endtask
  task automatic msg(input logic [4:0] typ, input int ndo = 0);
    set_sop(0); pkt(typ, ndo, src_id); src_id = (src_id + 1) % 8;
  endtask
  task automatic ordered(input int kind);
    set_sop(kind); for (int i = 0; i < 4; i++) sym(sop[i]); gap(1);
  endtask

  // ------------------------------------------------------------ sink -> source decoder
  logic [4:0]  w0 = 0, w1 = 0, w2 = 0;
  logic        in_p = 0, hi = 0;
  logic [3:0]  lo;
  logic [7:0]  db [0:33];
  int          dn;
  // decoded packets
  int          q_kind [$];      // 0 SOP message, 3 Hard Reset
  logic [15:0] q_hdr  [$];
  logic [31:0] q_obj  [$];
  bit          q_crc  [$];
  int          q_t0   [$];      // clock of the first K-code
  int          cyc = 0, t_first = 0, t_eop = 0, bad_sym = 0, t_rx_eop = 0;
  function automatic int dec(input logic [4:0] s);
    for (int i = 0; i < 16; i++) if (enc(4'(i)) == s) return i;
    return -1;
  endfunction
  always @(posedge clk) begin
    cyc++;
    if (rx_valid && rx_sym == EOP) t_rx_eop = cyc;
    if (tx_valid === 1'b1) begin
      if (!in_p) begin
        if (w0 == R1 && w1 == R1 && w2 == R1 && tx_sym == R2) begin
          q_kind.push_back(3); q_hdr.push_back(16'h0); q_obj.push_back(32'h0); q_crc.push_back(1);
          q_t0.push_back(cyc - 3);
        end
        else if (w0 == S1 && w1 == S1 && w2 == S1 && tx_sym == S2) begin
          in_p = 1; hi = 0; dn = 0; t_first = cyc - 3;
        end
        w0 = w1; w1 = w2; w2 = tx_sym;
      end
      else if (tx_sym == EOP) begin
        logic [31:0] c;
        in_p = 0; w0 = 0; w1 = 0; w2 = 0; t_eop = cyc;
        c = 32'hFFFF_FFFF;
        for (int i = 0; i < dn; i++) c = crcb(c, db[i]);
        q_kind.push_back(0); q_hdr.push_back({db[1], db[0]});
        q_obj.push_back({db[5], db[4], db[3], db[2]});
        lo = db[1][7:4];
        q_crc.push_back(c == 32'hDEBB_20E3 && dn == 6 + 4 * int'(lo[2:0]) && !hi);
        q_t0.push_back(t_first);
      end
      else if (dec(tx_sym) < 0) bad_sym++;
      else if (!hi) begin lo = 4'(dec(tx_sym)); hi = 1; end
      else begin db[dn] = {4'(dec(tx_sym)), lo}; dn++; hi = 0; end
    end
  end


  // the next packet from the sink must be this
  task automatic expect_msg(input string tag, input logic [4:0] typ, input int ndo, input int id,
                            input logic [31:0] obj = 32'h0, input bit chk_obj = 0);
    logic [15:0] h;
    if (q_kind.size() == 0) begin chk(0, $sformatf("%s: no packet from the sink", tag)); return; end
    h = q_hdr[0];
    chk(q_kind[0] == 0 && q_crc[0] && h[4:0] == typ && h[14:12] == 3'(ndo) &&
        h[11:9] == 3'(id) && h[7:6] == 2'b10 && h[8] == 1'b0 && h[5] == 1'b0 &&
        (!chk_obj || q_obj[0] == obj),
        $sformatf("%s: type %0d ndo %0d id %0d (got kind %0d crc %0d hdr %04h obj %08h)", tag, typ, ndo, id,
                  q_kind[0], q_crc[0], q_hdr[0], q_obj[0]));
    void'(q_kind.pop_front()); void'(q_hdr.pop_front()); void'(q_obj.pop_front());
    void'(q_crc.pop_front()); void'(q_t0.pop_front());
  endtask
  task automatic expect_hr(input string tag);
    chk(q_kind.size() > 0 && q_kind[0] == 3, $sformatf("%s: Hard Reset ordered set", tag));
    if (q_kind.size() > 0) begin
      void'(q_kind.pop_front()); void'(q_hdr.pop_front()); void'(q_obj.pop_front());
      void'(q_crc.pop_front()); void'(q_t0.pop_front());
    end
  endtask
  task automatic expect_none(input string tag);
    chk(q_kind.size() == 0, $sformatf("%s: nothing sent (%0d packets)", tag, q_kind.size()));
    q_kind.delete(); q_hdr.delete(); q_obj.delete(); q_crc.delete(); q_t0.delete();
  endtask
  // wait until the sink has sent n packets (or give up)
  task automatic wait_pkts(input int n, input int max = 400);
    int t;
    t = 0;
    while (q_kind.size() < n && t < max) begin @(negedge clk); t++; end
    @(negedge clk);
  endtask
  // source acknowledges the sink's message with this ID
  task automatic goodcrc(input int id);
    set_sop(0); pkt(GOODCRC, 0, id);
  endtask
  // source message; the sink must answer GoodCRC with its ID right after EOP
  task automatic msg_gc(input string tag, input logic [4:0] typ, input int ndo = 0);
    int id;
    id = src_id;
    msg(typ, ndo);
    wait_pkts(1);
    chk(q_t0.size() > 0 && q_t0[0] == t_rx_eop + 3, $sformatf("%s: GoodCRC starts 3 clocks after EOP (%0d)", tag,
        q_t0.size() > 0 ? q_t0[0] - t_rx_eop : -99));
    expect_msg({tag, ": GoodCRC"}, GOODCRC, 0, id);
  endtask

  int sink_id = 0;
  // Source_Capabilities -> Request (checked) -> GoodCRC -> Accept -> PS_RDY
  task automatic contract_flow(input string tag, input int pos, input bit mm, input int v50);
    msg_gc({tag, " Source_Capabilities"}, SRC_CAP, 3);
    wait_pkts(1);
    expect_msg({tag, " Request"}, REQUEST, 1, sink_id,
               {1'b0, 3'(pos), 1'b0, mm, 4'b0000, 2'b00, want_ma, want_ma}, 1);
    goodcrc(sink_id); sink_id = (sink_id + 1) % 8;
    idle(2);
    chk(pe == WRSP, {tag, ": waiting for the response"});
    msg_gc({tag, " Accept"}, ACCEPT);
    chk(pe == TRANS, {tag, ": Transition_Sink"});
    msg_gc({tag, " PS_RDY"}, PS_RDY);
    chk(pe == READY && contract && vbus_v == 10'(v50) && obj_pos == 3'(pos) && mismatch == mm,
        $sformatf("%s: explicit contract at %0d mV (pos %0d)", tag, v50 * 50, obj_pos));
  endtask
  task automatic idle(input int n); repeat (n) @(negedge clk); endtask

  int k, n0, t;

  initial begin
    idle(2);
    chk(pe == DIS && !tx_valid && !contract && vbus_v == 10'd0 && msg_id == 3'd0 && rx_good == 8'd0 &&
        hard_resets == 8'd0, "in reset: disabled, outputs cleared");
    rst_n = 1'b1;
    idle(3);
    chk(pe == DIS, "no VBUS: disabled");
    vbus = 1'b1;
    idle(2);
    chk(pe == WCAP && vbus_v == 10'd100, "VBUS: Wait_for_Capabilities at vSafe5V");

    // ---------------- SinkWaitCap timeout: Hard Reset x2, then Error
    idle(396);
    chk(pe == WCAP && q_kind.size() == 0, "SinkWaitCap: 399 clocks, still waiting");
    idle(3);
    chk(pe == HRST && hard_resets == 8'd1 && hr_counter == 2'd1, $sformatf("SinkWaitCap timeout: Hard Reset 1 (pe %0d hr %0d)", pe, hard_resets));
    idle(8);
    expect_hr("SinkWaitCap timeout");
    idle(11);
    chk(pe == HRST, "Hard Reset lasts 20 clocks");
    idle(2);
    chk(pe == WCAP, "then Wait_for_Capabilities");
    idle(400);
    chk(pe == HRST && hard_resets == 8'd2 && hr_counter == 2'd2, "second timeout: Hard Reset 2");
    idle(30); expect_hr("second timeout");
    idle(400);
    chk(pe == ERR && hard_resets == 8'd2, "nHardResetCount reached: Error, no third Hard Reset");
    expect_none("Error state");
    vbus = 1'b0; idle(2);
    chk(pe == DIS && vbus_v == 10'd0 && hr_counter == 2'd0, "VBUS removed: disabled");
    vbus = 1'b1; idle(2);
    chk(pe == WCAP, "VBUS back: Wait_for_Capabilities");

    // ---------------- first contract: 9 V of 5 / 9 / 15 V
    objs[0] = fixed_pdo(5000, 3000); objs[1] = fixed_pdo(9000, 3000); objs[2] = fixed_pdo(15000, 2000);
    contract_flow("12 V / 1.5 A max", 2, 0, 180);
    chk(rx_good == 8'd3 && rx_bad == 8'd0 && msg_id == 3'd1, "3 messages received, none bad, MessageIDCounter 1");

    // ---------------- Ping, Get_Sink_Cap, duplicate
    msg_gc("Ping", PING);
    idle(20);
    expect_none("Ping needs no answer");
    chk(pe == READY, "Ping: still Ready");
    msg_gc("Get_Sink_Cap", GET_SNK);
    wait_pkts(1);
    expect_msg("Sink_Capabilities", SNK_CAP, 1, sink_id, {12'h000, 10'd100, want_ma}, 1);
    goodcrc(sink_id); sink_id++;
    idle(2);
    chk(pe == READY && msg_id == 3'd2, "Sink_Capabilities acknowledged: Ready, MessageIDCounter 2");
    n0 = rx_dup;
    src_id = (src_id + 7) % 8;
    msg_gc("Ping retry (same MessageID)", PING);
    chk(rx_dup == 8'(n0 + 1) && pe == READY, "same MessageID again: duplicate, GoodCRC only");

    // ---------------- packets dropped by the physical / protocol layer
    n0 = rx_bad;
    bad_crc = 1; msg(PING);
    bad_sym_at = 2; msg(PING);
    drop_nib = 1; msg(PING);
    len_off = 1; msg(PING);
    // longer than the largest message (header, 7 objects, CRC = 34 bytes)
    set_sop(0);
    for (int i = 0; i < 4; i++) sym(sop[i]);
    for (int i = 0; i < 35; i++) begin sym(enc(4'(i))); sym(enc(4'(i + 3))); end
    sym(EOP); gap(1);
    idle(40);
    chk(rx_bad == 8'(n0 + 5), $sformatf("bad CRC, invalid symbol, odd nibbles, wrong length, over 34 bytes: dropped (%0d)",
        rx_bad - n0));
    expect_none("dropped packets get no GoodCRC");
    n0 = rx_other;
    set_sop(1); pkt(PING, 0, 0);
    set_sop(2); pkt(PING, 0, 0);
    idle(40);
    chk(rx_other == 8'(n0 + 2), "SOP' and SOP'' are for the cable");
    expect_none("no GoodCRC for SOP' / SOP''");
    set_sop(0); sop[1] = S3; pkt(PING, 0, src_id); src_id = (src_id + 1) % 8;
    wait_pkts(1);
    expect_msg("SOP with one K-code wrong (3 of 4): accepted", GOODCRC, 0, (src_id + 7) % 8);
    set_sop(0); sop[1] = S3; sop[2] = S3; pkt(PING, 0, src_id);
    idle(40);
    expect_none("SOP with two K-codes wrong: ignored");
    ordered(4);
    idle(10);
    chk(pe == READY && contract, "Cable Reset is not for this port");

    // ---------------- renegotiate: capability mismatch
    want_v = 10'd400; want_ma = 10'd400;
    objs[0] = fixed_pdo(5000, 3000); objs[1] = fixed_pdo(20000, 3000);
    contract_flow("20 V / 4 A on 3 A PDOs: mismatch", 1, 1, 100);
    want_ma = 10'd300;
    objs[0] = fixed_pdo(5000, 3000); objs[1] = {2'b11, 30'h0}; objs[2] = fixed_pdo(20000, 3000);
    contract_flow("APDO skipped, 20 V", 3, 0, 400);

    // ---------------- Reject / Wait keep the old contract
    want_v = 10'd240; want_ma = 10'd150;
    objs[0] = fixed_pdo(5000, 3000); objs[1] = fixed_pdo(9000, 3000); objs[2] = fixed_pdo(15000, 2000);
    msg_gc("Source_Capabilities", SRC_CAP, 3);
    wait_pkts(1); expect_msg("Request", REQUEST, 1, sink_id); goodcrc(sink_id); sink_id = (sink_id + 1) % 8;
    msg_gc("Reject", REJECT);
    chk(pe == READY && contract && vbus_v == 10'd400, "Reject: Ready, 20 V contract kept");
    msg_gc("Source_Capabilities", SRC_CAP, 3);
    wait_pkts(1); expect_msg("Request", REQUEST, 1, sink_id); goodcrc(sink_id); sink_id = (sink_id + 1) % 8;
    msg_gc("Wait", WAIT);
    chk(pe == READY && vbus_v == 10'd400, "Wait: Ready");

    // ---------------- Not_Supported, out-of-place messages
    msg_gc("DR_Swap", DR_SWAP);
    wait_pkts(1);
    expect_msg("Not_Supported", NOT_SUPP, 0, sink_id);
    goodcrc(sink_id); sink_id = (sink_id + 1) % 8;
    idle(2);
    chk(pe == READY, "after Not_Supported: Ready");
    objs[0] = 32'h0;
    msg_gc("BIST (data)", BIST, 1);
    wait_pkts(1);
    expect_msg("Not_Supported for BIST", NOT_SUPP, 0, sink_id);
    goodcrc(sink_id); sink_id = (sink_id + 1) % 8;
    idle(2);
    msg_gc("Accept in Ready", ACCEPT);
    wait_pkts(1);
    expect_msg("protocol error: Soft_Reset with MessageID 0", SOFT_RST, 0, 0);
    chk(pe == SNDSR, "waiting for GoodCRC of Soft_Reset");
    goodcrc(0); sink_id = 1;
    idle(2);
    chk(pe == WSRACC && msg_id == 3'd1, "Soft_Reset sent: waiting for Accept, MessageIDCounter 1");
    src_id = 0;
    msg_gc("Accept for Soft_Reset", ACCEPT);
    chk(pe == WCAP && !contract, "Soft_Reset done: Wait_for_Capabilities, contract dropped");

    // ---------------- source Soft_Reset
    contract_flow("after Soft_Reset", 2, 0, 180);
    src_id = 0;
    msg_gc("Soft_Reset from the source", SOFT_RST);
    wait_pkts(1);
    expect_msg("Accept with MessageID 0", ACCEPT, 0, 0);
    goodcrc(0); sink_id = 1;
    idle(2);
    chk(pe == WCAP && msg_id == 3'd1 && !contract, "Soft_Reset accepted: Wait_for_Capabilities");

    // ---------------- retries: no GoodCRC
    n0 = retries;
    msg_gc("Source_Capabilities", SRC_CAP, 3);
    wait_pkts(1);
    t = cyc;
    expect_msg("Request, try 1", REQUEST, 1, sink_id);
    wait_pkts(1);
    expect_msg("Request, try 2 (same MessageID)", REQUEST, 1, sink_id);
    goodcrc((sink_id + 1) % 8);                          // wrong MessageID: ignored
    wait_pkts(1);
    expect_msg("Request, try 3", REQUEST, 1, sink_id);
    chk(retries == 8'(n0 + 2), "nRetryCount = 2");
    idle(40);
    chk(pe == HRST && hard_resets == 8'd3, "Request never acknowledged: Hard Reset");
    expect_hr("failed Request");
    chk(msg_id == 3'd0 && !contract, "Hard Reset clears MessageIDCounter and the contract");
    sink_id = 0; src_id = 0;
    idle(20);

    // ---------------- retry acknowledged on the 2nd try
    msg_gc("Source_Capabilities", SRC_CAP, 3);
    wait_pkts(1); expect_msg("Request try 1", REQUEST, 1, 0);
    wait_pkts(1); expect_msg("Request try 2", REQUEST, 1, 0);
    goodcrc(0); sink_id = 1;
    idle(2);
    chk(pe == WRSP && msg_id == 3'd1, "GoodCRC on the 2nd try: MessageIDCounter 1");

    // ---------------- SenderResponse and PSTransition timeouts
    idle(97);
    chk(pe == WRSP, "SenderResponse: 99 clocks");
    idle(3);
    chk(pe == HRST, "no Accept within SenderResponse: Hard Reset");
    idle(10); expect_hr("SenderResponse timeout");
    idle(20); sink_id = 0; src_id = 0;
    msg_gc("Source_Capabilities", SRC_CAP, 3);
    wait_pkts(1); expect_msg("Request", REQUEST, 1, 0); goodcrc(0); sink_id = 1;
    msg_gc("Accept", ACCEPT);
    idle(150);
    chk(pe == TRANS, "PSTransition: still waiting");
    idle(35);
    chk(pe == HRST, "no PS_RDY within PSTransition: Hard Reset");
    idle(10); expect_hr("PSTransition timeout");
    idle(20); sink_id = 0; src_id = 0;

    // ---------------- unexpected message while waiting for the response
    msg_gc("Source_Capabilities", SRC_CAP, 3);
    wait_pkts(1); expect_msg("Request", REQUEST, 1, 0); goodcrc(0); sink_id = 1;
    msg_gc("Ping while waiting for Accept", PING);
    wait_pkts(1);
    expect_msg("Soft_Reset", SOFT_RST, 0, 0);
    goodcrc(0);
    idle(110);
    chk(pe == HRST, "no Accept for the Soft_Reset: Hard Reset");
    idle(10); expect_hr("Soft_Reset not accepted");
    idle(20); sink_id = 0; src_id = 0;

    // ---------------- Hard Reset from the source (3 of 4 K-codes)
    contract_flow("before Hard Reset", 2, 0, 180);
    n0 = hard_resets;
    set_sop(3); sop[0] = S1; for (int i = 0; i < 4; i++) sym(sop[i]); gap(1);
    idle(1);
    chk(pe == HRST && !contract && vbus_v == 10'd100 && msg_id == 3'd0 && hard_resets == 8'(n0 + 1),
        "Hard Reset received: contract dropped, vSafe5V");
    sym(R2); gap(1);                                   // a stray RST-2: the ordered-set window was cleared
    idle(21);
    chk(pe == WCAP && hard_resets == 8'(n0 + 1), "after Hard Reset: Wait_for_Capabilities, one Hard Reset");
    expect_none("no packet sent for a received Hard Reset");
    sink_id = 0; src_id = 0;

    // ---------------- Soft_Reset that is never acknowledged
    contract_flow("before a lost Soft_Reset", 2, 0, 180);
    msg_gc("PS_RDY in Ready", PS_RDY);
    wait_pkts(3, 200);
    expect_msg("Soft_Reset try 1", SOFT_RST, 0, 0);
    expect_msg("Soft_Reset try 2", SOFT_RST, 0, 0);
    expect_msg("Soft_Reset try 3", SOFT_RST, 0, 0);
    idle(40);
    chk(pe == HRST, "Soft_Reset never acknowledged: Hard Reset");
    idle(5); expect_hr("lost Soft_Reset");
    idle(30); sink_id = 0; src_id = 0;

    // ---------------- VBUS lost in a contract
    contract_flow("before VBUS loss", 2, 0, 180);
    vbus = 1'b0; idle(2);
    chk(pe == DIS && !contract && vbus_v == 10'd0, "VBUS lost: disabled");
    vbus = 1'b1; idle(2);
    chk(pe == WCAP, "VBUS back: Wait_for_Capabilities");
    src_id = (src_id + 7) % 8; sink_id = 0;            // the last MessageID before the detach
    contract_flow("after detach: stored MessageID forgotten", 2, 0, 180);

    // ---------------- reset
    rst_n = 1'b0; idle(2);
    chk(pe == DIS && msg_id == 3'd0 && rx_good == 8'd0 && rx_bad == 8'd0 && hard_resets == 8'd0 &&
        retries == 8'd0 && !tx_valid, "reset clears the port");
    rst_n = 1'b1;
    sink_id = 0; src_id = 0;

    // ---------------- reset with VBUS present: no contract to fall back to
    idle(3);
    chk(pe == WCAP && !contract, "reset with VBUS: Wait_for_Capabilities");
    msg_gc("Source_Capabilities after reset", SRC_CAP, 3);
    wait_pkts(1); expect_msg("Request after reset", REQUEST, 1, 0); goodcrc(0); sink_id = 1;
    msg_gc("Reject without a contract", REJECT);
    chk(pe == WCAP && !contract, "Reject with no prior contract: Wait_for_Capabilities");

    // ---------------- MessageIDCounter keeps counting over control messages
    contract_flow("before Not_Supported x2", 2, 0, 180);
    msg_gc("DR_Swap #1", DR_SWAP);
    wait_pkts(1); expect_msg("Not_Supported #1", NOT_SUPP, 0, sink_id);
    goodcrc(sink_id); sink_id = (sink_id + 1) % 8;
    idle(2);
    msg_gc("DR_Swap #2", DR_SWAP);
    wait_pkts(1); expect_msg("Not_Supported #2 (next MessageID)", NOT_SUPP, 0, sink_id);
    goodcrc(sink_id); sink_id = (sink_id + 1) % 8;
    idle(2);
    chk(pe == READY && msg_id == 3'(sink_id), "MessageIDCounter after two Not_Supported");
    idle(60);
    expect_none("nothing else sent in Ready");

    // ---------------- Not_Supported never acknowledged: Soft_Reset
    msg_gc("DR_Swap, Not_Supported will be lost", DR_SWAP);
    wait_pkts(3, 200);
    expect_msg("Not_Supported try 1", NOT_SUPP, 0, sink_id);
    expect_msg("Not_Supported try 2", NOT_SUPP, 0, sink_id);
    expect_msg("Not_Supported try 3", NOT_SUPP, 0, sink_id);
    wait_pkts(1, 80);
    chk(pe == SNDSR, "Not_Supported failed: Send_Soft_Reset");
    expect_msg("Soft_Reset after the failed Not_Supported", SOFT_RST, 0, 0);
    goodcrc(0); sink_id = 1;
    idle(2);
    chk(pe == WSRACC, "Soft_Reset acknowledged: waiting for Accept");
    src_id = 0;
    msg_gc("Accept for that Soft_Reset", ACCEPT);
    chk(pe == WCAP && !contract, "Soft_Reset done");
    contract_flow("after the Soft_Reset", 2, 0, 180);

    // ---------------- Accept for the source's Soft_Reset never acknowledged
    src_id = 0;
    n0 = hard_resets;
    msg_gc("Soft_Reset from the source", SOFT_RST);
    wait_pkts(3, 200);
    expect_msg("Accept try 1", ACCEPT, 0, 0);
    expect_msg("Accept try 2", ACCEPT, 0, 0);
    expect_msg("Accept try 3", ACCEPT, 0, 0);
    idle(40);
    chk(pe == HRST && hard_resets == 8'(n0 + 1), "Accept never acknowledged: Hard Reset");
    expect_hr("lost Accept for Soft_Reset");
    idle(30); sink_id = 0; src_id = 0;
    contract_flow("after the Hard Reset", 2, 0, 180);

    chk(bad_sym == 0, "every symbol the sink sent was a 4b5b code");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #3000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
