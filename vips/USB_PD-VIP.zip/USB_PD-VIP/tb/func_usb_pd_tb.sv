// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_usb_pd_tb.sv -- self-checking functional test for the USB Power
// Delivery sink policy model (tb/usb_pd_smoke_model.sv, flattened by
// smoke/flatten.py). Run: python3 tools/run_func_tests.py USB_PD-VIP
//
// Model contract (from tb/usb_pd_smoke_model.sv), one message per msg_valid
// clock (GoodCRC 0x15, GotoMin 0x16, Accept 0x17, Reject 0x18, PS_RDY 0x19,
// Source_Capabilities 0x1A, Hard Reset 0x1F):
//   * VBUS present -> wait for Source_Capabilities -> Request (req_valid with
//     req_pdo = pdo_select) -> GoodCRC -> Accept -> PS_RDY -> explicit
//     contract (contract_active, contract_count++, vbus_mv = requested level).
//   * Reject or GotoMin instead of Accept: back to waiting for capabilities,
//     reject_count++. Each wait times out after 256 clocks back to waiting
//     for capabilities.
//   * in contract: GotoMin drops vbus_mv to vSafe5V (200 x 25 mV) and waits
//     for PS_RDY; new Source_Capabilities restart negotiation.
//   * VBUS loss or Hard Reset from any state: no contract, vSafe5V.
//   * pd_state follows the internal state one clock later.
// Known deviations from the PD specification, checked as XFAIL:
//   * vbus_mv takes the requested level when the Request is sent, so a
//     rejected request leaves vbus_mv at a level the source never supplied.
//   * Source_Capabilities received during a contract do not trigger a
//     Request; the sink waits for another Source_Capabilities.

module func_usb_pd_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam logic [4:0] GOODCRC = 5'h15, GOTOMIN = 5'h16, ACCEPT = 5'h17, REJECT = 5'h18,
                         PS_RDY = 5'h19, SRC_CAP = 5'h1A, HRESET = 5'h1F;
  localparam logic [2:0] S_IDLE = 0, S_WCAP = 1, S_REQ = 2, S_WACC = 3, S_WPS = 4, S_CON = 5;
  localparam logic [10:0] V5 = 11'd200, V9 = 11'd360, V15 = 11'd600, V20 = 11'd800;
  int checks = 0, fails = 0, xfails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, vbus = 1'b0, mv = 1'b0;
  logic [4:0]  mtype = '0;
  logic [2:0]  pdo = '0;
  logic [10:0] req_v = '0;
  wire  [2:0]  pd_state, req_pdo;
  wire         req_valid, contract;
  wire  [10:0] vbus_mv;
  wire  [7:0]  ccount, rcount;

  always #5 clk = ~clk;

  usb_pd_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .vbus_present(vbus), .msg_valid(mv), .msg_type(mtype),
    .pdo_select(pdo), .req_voltage_mv(req_v), .pd_state(pd_state), .req_valid(req_valid),
    .req_pdo(req_pdo), .contract_active(contract), .vbus_mv(vbus_mv),
    .contract_count(ccount), .reject_count(rcount)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  task automatic msg(input [4:0] t);
    @(negedge clk);
    mv = 1; mtype = t;
    @(negedge clk);
    mv = 0;
    @(negedge clk);                 // pd_state is one clock behind
  endtask

  task automatic idle(input int n); repeat (n) @(negedge clk); endtask

  task automatic negotiate(input [2:0] p, input [10:0] v);
    pdo = p; req_v = v;
    msg(SRC_CAP);
    msg(GOODCRC);
    msg(ACCEPT);
    msg(PS_RDY);
  endtask

  initial begin
    idle(2);
    rst_n = 1;
    idle(3);
    chk(pd_state == S_IDLE && !contract && vbus_mv == V5, "unattached: idle, vSafe5V");
    msg(SRC_CAP);
    chk(pd_state == S_IDLE && !req_valid, "Source_Capabilities ignored without VBUS");

    // attach and full negotiation
    vbus = 1; idle(3);
    chk(pd_state == S_WCAP, "VBUS present: waiting for Source_Capabilities");
    pdo = 3'd2; req_v = V9;
    msg(SRC_CAP);
    chk(pd_state == S_REQ && req_valid && req_pdo == 3'd2, "Source_Capabilities answered with a Request for PDO 2");
    msg(ACCEPT);
    chk(pd_state == S_REQ, "Accept before GoodCRC is ignored");
    msg(GOODCRC);
    chk(pd_state == S_WACC && !req_valid, "GoodCRC completes the Request");
    msg(PS_RDY);
    chk(pd_state == S_WACC && !contract, "PS_RDY before Accept is ignored");
    msg(ACCEPT);
    chk(pd_state == S_WPS && !contract, "Accept: waiting for PS_RDY, no contract yet");
    msg(PS_RDY);
    chk(pd_state == S_CON && contract && ccount == 1 && vbus_mv == V9,
        "PS_RDY: explicit contract at 9 V");

    // GotoMin in contract
    msg(GOTOMIN);
    chk(pd_state == S_WPS && vbus_mv == V5, "GotoMin drops to vSafe5V and waits for PS_RDY");
    msg(PS_RDY);
    chk(pd_state == S_CON && ccount == 2, "PS_RDY after GotoMin re-establishes the contract");

    // renegotiation from contract
    pdo = 3'd4; req_v = V20;
    msg(SRC_CAP);
    chk(pd_state == S_WCAP && contract, "new capabilities during a contract restart negotiation, contract kept");
    chk_xfail(req_valid, "Source_Capabilities during a contract are answered with a Request");
    msg(SRC_CAP);
    chk(req_valid && req_pdo == 3'd4, "Request for PDO 4 after re-sent capabilities");
    msg(GOODCRC);
    msg(REJECT);
    chk(pd_state == S_WCAP && rcount == 1 && ccount == 2, "Reject: back to waiting, reject_count++");
    chk_xfail(vbus_mv == V5, "rejected request leaves VBUS at the previous level");

    // GotoMin in place of Accept also counts as a reject
    pdo = 3'd1; req_v = V15;
    msg(SRC_CAP); msg(GOODCRC); msg(GOTOMIN);
    chk(pd_state == S_WCAP && rcount == 2, "GotoMin answering a Request counts as a reject");

    // timeouts
    msg(SRC_CAP);
    idle(250);
    chk(pd_state == S_REQ, "Request still waiting for GoodCRC after 250 clocks");
    idle(10);
    chk(pd_state == S_WCAP, "missing GoodCRC times out back to capabilities");
    msg(SRC_CAP); msg(GOODCRC);
    idle(260);
    chk(pd_state == S_WCAP, "missing Accept times out");
    msg(SRC_CAP); msg(GOODCRC); msg(ACCEPT);
    idle(260);
    chk(pd_state == S_WCAP, "missing PS_RDY times out");
    idle(300);
    chk(pd_state == S_WCAP, "waiting for capabilities has no timeout exit");

    // hard reset and detach
    negotiate(3'd3, V15);
    chk(contract && vbus_mv == V15 && pd_state == S_CON, "contract at 15 V");
    msg(HRESET);
    idle(1);
    chk(!contract && vbus_mv == V5 && pd_state == S_WCAP, "Hard Reset drops the contract to vSafe5V");
    negotiate(3'd3, V15);
    chk(contract, "contract again");
    @(negedge clk); vbus = 0;
    idle(2);
    chk(!contract && vbus_mv == V5 && pd_state == S_IDLE, "VBUS loss drops the contract");
    pdo = 3'd2;
    msg(SRC_CAP);
    chk(!req_valid && pd_state == S_IDLE, "no negotiation while detached");
    vbus = 1;
    idle(3);
    msg(SRC_CAP);
    vbus = 0;
    idle(2);
    chk(!req_valid, "detach while a Request is pending withdraws it");

    // reset
    vbus = 1; idle(3);
    negotiate(3'd1, V9);
    @(negedge clk); rst_n = 0;
    @(negedge clk); rst_n = 1;
    chk(!contract && vbus_mv == V5 && ccount == 0 && rcount == 0 && pd_state == S_IDLE,
        "reset clears contract and counters");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
