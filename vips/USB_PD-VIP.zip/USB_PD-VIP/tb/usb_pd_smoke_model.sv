// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Smoke-target minimal behavioral model: USB Power Delivery sink-side
// contract negotiation FSM. Follows the SPR policy flow: VBUS detect ->
// wait Source_Capabilities -> send Request -> wait GoodCRC/Accept ->
// wait PS_RDY -> explicit contract. Plain ANSI ports only (no interfaces)
// so the L1b smoke harness can build it directly with iverilog.

module usb_pd_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        vbus_present,     // VBUS detected on CC-attached port
  input  logic        msg_valid,        // inbound PD message strobe
  input  logic [4:0]  msg_type,         // PD message code (see below)
  input  logic [2:0]  pdo_select,       // PDO index the sink wants
  input  logic [10:0] req_voltage_mv,   // requested VBUS in mV/25 units
  output logic [2:0]  pd_state,         // negotiation FSM state
  output logic        req_valid,        // Request message on the wire
  output logic [2:0]  req_pdo,          // requested PDO index
  output logic        contract_active,  // explicit contract in force
  output logic [10:0] vbus_mv,          // negotiated VBUS level
  output logic [7:0]  contract_count,   // completed contracts
  output logic [7:0]  reject_count      // rejected requests
);

  // PD message codes (aligned with usb_vip_pkg usb_txn_type_e values)
  localparam logic [4:0] PD_GOODCRC = 5'b10101;
  localparam logic [4:0] PD_GOTOMIN = 5'b10110;
  localparam logic [4:0] PD_ACCEPT  = 5'b10111;
  localparam logic [4:0] PD_REJECT  = 5'b11000;
  localparam logic [4:0] PD_PS_RDY  = 5'b11001;
  localparam logic [4:0] PD_SRC_CAP = 5'b11010;
  localparam logic [4:0] PD_REQUEST = 5'b11011;
  localparam logic [4:0] PD_HARD_RESET = 5'b11111;  // model-local code

  localparam logic [2:0] ST_IDLE        = 3'd0;
  localparam logic [2:0] ST_WAIT_CAP    = 3'd1;
  localparam logic [2:0] ST_SEND_REQ    = 3'd2;
  localparam logic [2:0] ST_WAIT_ACCEPT = 3'd3;
  localparam logic [2:0] ST_WAIT_PSRDY  = 3'd4;
  localparam logic [2:0] ST_CONTRACT    = 3'd5;

  localparam logic [10:0] VSAFE5V = 11'd200;        // 5 V in mV/25 units

  logic [2:0] state;
  logic [7:0] tmo;

  wire msg_goodcrc = msg_valid && (msg_type == PD_GOODCRC);
  wire msg_accept  = msg_valid && (msg_type == PD_ACCEPT);
  wire msg_reject  = msg_valid && (msg_type == PD_REJECT);
  wire msg_ps_rdy  = msg_valid && (msg_type == PD_PS_RDY);
  wire msg_src_cap = msg_valid && (msg_type == PD_SRC_CAP);
  wire msg_hreset  = msg_valid && (msg_type == PD_HARD_RESET);

  always @(posedge clk) begin
    if (!rst_n) begin
      state           <= ST_IDLE;
      tmo             <= 8'd0;
      pd_state        <= ST_IDLE;
      req_valid       <= 1'b0;
      req_pdo         <= 3'd0;
      contract_active <= 1'b0;
      vbus_mv         <= VSAFE5V;
      contract_count  <= 8'd0;
      reject_count    <= 8'd0;
    end else begin
      pd_state <= state;
      tmo      <= tmo + 8'd1;
      if (!vbus_present || msg_hreset) begin
        // detach or hard reset: drop any contract, back to safe 5 V
        state           <= ST_IDLE;
        req_valid       <= 1'b0;
        contract_active <= 1'b0;
        vbus_mv         <= VSAFE5V;
        tmo             <= 8'd0;
      end else begin
        case (state)
          // ---- attach: source will send Source_Capabilities ----
          ST_IDLE: begin
            req_valid <= 1'b0;
            state     <= ST_WAIT_CAP;
            tmo       <= 8'd0;
          end

          // ---- wait for Source_Capabilities, then issue Request ----
          ST_WAIT_CAP: begin
            if (msg_src_cap) begin
              state     <= ST_SEND_REQ;
              req_valid <= 1'b1;            // Request message on the wire
              req_pdo   <= pdo_select;
              vbus_mv   <= req_voltage_mv;  // candidate operating point
              tmo       <= 8'd0;
            end else if (tmo == 8'hFF) begin
              tmo <= 8'd0;                  // keep waiting (source poll)
            end
          end

          // ---- Request must be GoodCRC'd by the source ----
          ST_SEND_REQ: begin
            if (msg_goodcrc) begin
              state     <= ST_WAIT_ACCEPT;
              req_valid <= 1'b0;            // message delivered
              tmo       <= 8'd0;
            end else if (tmo == 8'hFF) begin
              state <= ST_WAIT_CAP;         // CRC retry budget exhausted
              tmo   <= 8'd0;
            end
          end

          // ---- source answers Accept or Reject ----
          ST_WAIT_ACCEPT: begin
            if (msg_accept) begin
              state <= ST_WAIT_PSRDY;       // supply transition pending
              tmo   <= 8'd0;
            end else if (msg_reject || (msg_valid && (msg_type == PD_GOTOMIN))) begin
              state        <= ST_WAIT_CAP;  // stay on current contract
              reject_count <= reject_count + 8'd1;
              tmo          <= 8'd0;
            end else if (tmo == 8'hFF) begin
              state <= ST_WAIT_CAP;
              tmo   <= 8'd0;
            end
          end

          // ---- PS_RDY means the new level is on VBUS ----
          ST_WAIT_PSRDY: begin
            if (msg_ps_rdy) begin
              state           <= ST_CONTRACT;
              contract_active <= 1'b1;
              contract_count  <= contract_count + 8'd1;
              tmo             <= 8'd0;
            end else if (tmo == 8'hFF) begin
              state <= ST_WAIT_CAP;         // supply fault: renegotiate
              tmo   <= 8'd0;
            end
          end

          // ---- explicit contract: GotoMin returns to 5 V ----
          ST_CONTRACT: begin
            if (msg_valid && (msg_type == PD_GOTOMIN)) begin
              state   <= ST_WAIT_PSRDY;     // wait for 5 V PS_RDY
              vbus_mv <= VSAFE5V;
              tmo     <= 8'd0;
            end else if (msg_src_cap) begin
              state <= ST_WAIT_CAP;         // capabilities re-sent: redo
              tmo   <= 8'd0;
            end
          end

          default: state <= ST_IDLE;
        endcase
      end
    end
  end

endmodule
