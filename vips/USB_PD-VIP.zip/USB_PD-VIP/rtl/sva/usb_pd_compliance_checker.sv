// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// USB-PD Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 19
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
// L4=Protocol-specific rules
`ifndef USB_PD_COMPLIANCE_CHECKER_SV
`define USB_PD_COMPLIANCE_CHECKER_SV

module usb_pd_compliance_checker (usb_vip_if vif);
  import uvm_pkg::*;
  import usb_vip_pkg::*;
  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_usbpd_sop_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_sop |-> vif.pd_valid; endproperty
  assert_p_usbpd_sop_valid: assert property(p_usbpd_sop_valid) l1_pass[0]++; else begin `uvm_warning("USBPD_L1", "SOP valid failed"); l1_fail[0]++; end
  cover_p_usbpd_sop_valid: cover property(p_usbpd_sop_valid);

  property p_usbpd_message_id; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_valid |-> vif.pd_message_id <= 3'd7; endproperty
  assert_p_usbpd_message_id: assert property(p_usbpd_message_id) l1_pass[1]++; else begin `uvm_warning("USBPD_L1", "Message ID 0-7 failed"); l1_fail[1]++; end
  cover_p_usbpd_message_id: cover property(p_usbpd_message_id);

  property p_usbpd_crc32; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_eop |-> vif.pd_crc_ok; endproperty
  assert_p_usbpd_crc32: assert property(p_usbpd_crc32) l1_pass[2]++; else begin `uvm_warning("USBPD_L1", "CRC32 valid failed"); l1_fail[2]++; end
  cover_p_usbpd_crc32: cover property(p_usbpd_crc32);

  property p_usbpd_role; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_role inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_usbpd_role: assert property(p_usbpd_role) l1_pass[3]++; else begin `uvm_warning("USBPD_L1", "Role valid failed"); l1_fail[3]++; end
  cover_p_usbpd_role: cover property(p_usbpd_role);


  // ===== L2: Full Protocol (6 SVAs) =====
  property p_usbpd_power_contract; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_power_contract |-> vif.pd_voltage <= 8'd240; endproperty
  assert_p_usbpd_power_contract: assert property(p_usbpd_power_contract) l2_pass[0]++; else begin `uvm_warning("USBPD_L2", "Power contract failed"); l2_fail[0]++; end
  cover_p_usbpd_power_contract: cover property(p_usbpd_power_contract);

  property p_usbpd_hard_reset; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_hard_reset |-> vif.pd_role != 2'b00; endproperty
  assert_p_usbpd_hard_reset: assert property(p_usbpd_hard_reset) l2_pass[1]++; else begin `uvm_warning("USBPD_L2", "Hard reset failed"); l2_fail[1]++; end
  cover_p_usbpd_hard_reset: cover property(p_usbpd_hard_reset);

  property p_usbpd_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_valid |-> !$isunknown(vif.pd_data); endproperty
  assert_p_usbpd_no_x: assert property(p_usbpd_no_x) l2_pass[2]++; else begin `uvm_warning("USBPD_L2", "No X when valid failed"); l2_fail[2]++; end
  cover_p_usbpd_no_x: cover property(p_usbpd_no_x);

  property p_usbpd_bist; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_bist |-> vif.pd_role == 2'b11; endproperty
  assert_p_usbpd_bist: assert property(p_usbpd_bist) l2_pass[3]++; else begin `uvm_warning("USBPD_L2", "BIST mode failed"); l2_fail[3]++; end
  cover_p_usbpd_bist: cover property(p_usbpd_bist);

  property p_usbpd_pps; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pps_en |-> vif.pd_voltage >= 8'd3 && vif.pd_voltage <= 8'd21; endproperty
  assert_p_usbpd_pps: assert property(p_usbpd_pps) l2_pass[4]++; else begin `uvm_warning("USBPD_L2", "PPS voltage failed"); l2_fail[4]++; end
  cover_p_usbpd_pps: cover property(p_usbpd_pps);

  property p_usbpd_ams; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ams_start |-> ##[1:100] vif.ams_end; endproperty
  assert_p_usbpd_ams: assert property(p_usbpd_ams) l2_pass[5]++; else begin `uvm_warning("USBPD_L2", "Atomic message sequence failed"); l2_fail[5]++; end
  cover_p_usbpd_ams: cover property(p_usbpd_ams);


  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: no new SOP may start before the current message EOP (no message overlap)
  property p_usbpd_l3_no_sop_overlap; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.pd_sop) |-> (!vif.pd_sop throughout (vif.pd_eop [->1])); endproperty
  assert_p_usbpd_l3_no_sop_overlap: assert property(p_usbpd_l3_no_sop_overlap) l3_pass[0]++; else begin `uvm_warning("USBPD_L3", "Overlapping SOP before EOP failed"); l3_fail[0]++; end
  cover_p_usbpd_l3_no_sop_overlap: cover property(p_usbpd_l3_no_sop_overlap);
  // L3-2: MessageID must stay constant within a message
  property p_usbpd_l3_msgid_stable; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.pd_valid && !vif.pd_sop) |-> $stable(vif.pd_message_id); endproperty
  assert_p_usbpd_l3_msgid_stable: assert property(p_usbpd_l3_msgid_stable) l3_pass[1]++; else begin `uvm_warning("USBPD_L3", "MessageID changed mid-message failed"); l3_fail[1]++; end
  cover_p_usbpd_l3_msgid_stable: cover property(p_usbpd_l3_msgid_stable);
  // L3-3: a Hard Reset tears down the explicit power contract
  property p_usbpd_l3_hr_contract; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_hard_reset |=> !vif.pd_power_contract; endproperty
  assert_p_usbpd_l3_hr_contract: assert property(p_usbpd_l3_hr_contract) l3_pass[2]++; else begin `uvm_warning("USBPD_L3", "Contract survives hard reset failed"); l3_fail[2]++; end
  cover_p_usbpd_l3_hr_contract: cover property(p_usbpd_l3_hr_contract);
  // L3-4: an explicit contract requires Vbus to be present
  property p_usbpd_l3_contract_vbus; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_power_contract |-> vif.pd_vbus_present; endproperty
  assert_p_usbpd_l3_contract_vbus: assert property(p_usbpd_l3_contract_vbus) l3_pass[3]++; else begin `uvm_warning("USBPD_L3", "Contract without Vbus failed"); l3_fail[3]++; end
  cover_p_usbpd_l3_contract_vbus: cover property(p_usbpd_l3_contract_vbus);

  // ---------------- L4: USB-PD protocol-specific rules (5) ----------------
  // L4-1: BMC signaling keeps CC1/CC2 differential during a message
  property p_usbpd_l4_bmc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_msg_valid |-> vif.pd_cc1 != vif.pd_cc2; endproperty
  assert_p_usbpd_l4_bmc: assert property(p_usbpd_l4_bmc) l4_pass[0]++; else begin `uvm_warning("USBPD_L4", "BMC not differential"); l4_fail[0]++; end
  cover_p_usbpd_l4_bmc: cover property(p_usbpd_l4_bmc);

  // L4-2: every SOP* message completes with EOP
  property p_usbpd_l4_sop_eop; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_sop |-> ##[1:200] vif.pd_eop; endproperty
  assert_p_usbpd_l4_sop_eop: assert property(p_usbpd_l4_sop_eop) l4_pass[1]++; else begin `uvm_warning("USBPD_L4", "Message without EOP"); l4_fail[1]++; end
  cover_p_usbpd_l4_sop_eop: cover property(p_usbpd_l4_sop_eop);

  // L4-3: control message ends within tReceive (195 cycles model)
  property p_usbpd_l4_goodcrc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_msg_valid && vif.pd_msg_type == 3'b001 |-> ##[1:195] !vif.pd_msg_valid; endproperty
  assert_p_usbpd_l4_goodcrc: assert property(p_usbpd_l4_goodcrc) l4_pass[2]++; else begin `uvm_warning("USBPD_L4", "GoodCRC/tReceive timeout"); l4_fail[2]++; end
  cover_p_usbpd_l4_goodcrc: cover property(p_usbpd_l4_goodcrc);

  // L4-4: explicit contract implies Vbus at or above vSafe5V
  property p_usbpd_l4_ps_rdy; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_power_contract |-> vif.pd_vbus_voltage >= 10'd200; endproperty
  assert_p_usbpd_l4_ps_rdy: assert property(p_usbpd_l4_ps_rdy) l4_pass[3]++; else begin `uvm_warning("USBPD_L4", "Contract below vSafe5V"); l4_fail[3]++; end
  cover_p_usbpd_l4_ps_rdy: cover property(p_usbpd_l4_ps_rdy);

  // L4-5: source Vbus always inside 0-48V absolute range
  property p_usbpd_l4_vbus_range; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pd_vbus_present |-> vif.pd_vbus_voltage <= 10'd1920; endproperty
  assert_p_usbpd_l4_vbus_range: assert property(p_usbpd_l4_vbus_range) l4_pass[4]++; else begin `uvm_warning("USBPD_L4", "Vbus absolute range exceeded"); l4_fail[4]++; end
  cover_p_usbpd_l4_vbus_range: cover property(p_usbpd_l4_vbus_range);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l1_hit=0, l2_hit=0, l3_hit=0;
    int l4_total=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("USB_PD_RPT", $sformatf("=== USB_PD Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("USB_PD_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("USB_PD_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("USB_PD_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("USB_PD_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("USB_PD_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end

endmodule
`endif
