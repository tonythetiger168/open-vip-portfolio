// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_lpddr4_tb.sv -- PHY-level functional test for LPDDR4_top (two
// channels on rtl/MEMCH_top, channel 0 drives the shared CA bus).
// Run: python3 tools/run_func_tests.py LPDDR4-VIP
//
// Checks the CA bus encoding (CA[5:3] = RAS_n/CAS_n/WE_n, CA[2:0] = low
// address bits, CS_n low for any command), exact tRCD/CL timing seen by the
// host, the trace port, DQ direction and reset values on channel 0
// (haddr[8] = 0). Known defects: the PRE encoding stays on the CA bus after
// the command, and tRP is not enforced.
// FUNC_SIM: verilator

module func_lpddr4_tb;
  localparam int CL = 15, TRCD = 6, TRP = 6, AL = 3;
  logic clk = 1'b0, rst_n = 1'b0, hvalid = 1'b0;
  logic [2:0] hcmd = '0;
  logic [31:0] haddr = '0;
  logic [15:0] hwdata = '0, hrdata;
  logic hready, hdone, ck_t, ck_c, cs_n, cke, trace_valid;
  logic [5:0] ca;
  logic [2:0] trace_cmd;
  logic [31:0] trace_addr;
  tri [31:0] dq;
  tri [1:0] dqs;
  wire ras_n = ca[5], cas_n = ca[4], we_n = ca[3];
  // weak keeper pattern: DQ reads it back only while the controller releases DQ
  // (Verilator resolves an undriven tristate to 0, not Z)
  localparam [15:0] KEEP = 16'hC33C;
  assign (weak0, weak1) dq = {KEEP, KEEP};
  wire [15:0] dq_lo = dq[15:0];
  wire [AL-1:0] addr_lo = ca[2:0];

  LPDDR4_top u_dut (.*);

  // CS_n must be low exactly when a command is on CA
  int cs_bad = 0;
  always @(negedge clk) if (rst_n && cs_n !== (ras_n & cas_n & we_n)) cs_bad++;

  int checks = 0, fails = 0, xfails = 0;

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  // known controller defect: must still fail (XPASS fails the test)
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (ok) begin fails++; $display("  [XPASS] %s", msg); end
    else    begin xfails++; $display("  [XFAIL] %s", msg); end
  endtask

  always #5 clk = ~clk;

  // per-cycle snapshot after posedge k of a command (k = 0 is the edge that
  // accepts it), taken at the following negedge
  localparam int N = 40;
  logic        s_rdy [N], s_done [N], s_ras [N], s_cas [N], s_we [N], s_tv [N];
  logic [2:0]  s_tc [N];
  logic [31:0] s_ta [N];
  logic [AL-1:0] s_ad [N];
  logic [15:0] s_rd [N], s_dq [N];
  bit          s_dqz [N];   // DQ released (all Z)

  task automatic issue(input [2:0] c, input [31:0] a, input [15:0] d = '0);
    @(negedge clk);
    hvalid = 1'b1; hcmd = c; haddr = a; hwdata = d;
    for (int k = 0; k < N; k++) begin
      @(negedge clk);
      // a command code without hvalid must be ignored
      hvalid = 1'b0; hcmd = 3'(1 + k % 4);
      s_rdy[k] = hready; s_done[k] = hdone; s_ras[k] = ras_n; s_cas[k] = cas_n; s_we[k] = we_n;
      s_tv[k] = trace_valid; s_tc[k] = trace_cmd; s_ta[k] = trace_addr; s_ad[k] = addr_lo;
      s_rd[k] = hrdata; s_dq[k] = dq_lo; s_dqz[k] = (dq_lo === KEEP);
    end
  endtask

  function automatic int first_ready();
    for (int k = 0; k < N; k++) if (s_rdy[k]) return k;
    return -1;
  endfunction
  function automatic int done_count();
    int n = 0;
    for (int k = 0; k < N; k++) n += s_done[k];
    return n;
  endfunction
  function automatic int tv_count();
    int n = 0;
    for (int k = 0; k < N; k++) n += s_tv[k];
    return n;
  endfunction

  logic [15:0] got;
  task automatic rd(input [31:0] a);
    issue(3'd2, a);
    got = s_rd[CL + 2];
  endtask

  initial begin
    // pins in reset
    repeat (2) @(negedge clk);
    chk(cke === 1'b0 && ras_n === 1'b1 && cas_n === 1'b1 && we_n === 1'b1,
        "reset: CKE low, command pins idle (NOP)");
    chk(ck_c === ~ck_t && hready === 1'b1 && hdone === 1'b0 && hrdata === '0 && trace_valid === 1'b0,
        "reset: differential clock, host ready, no done/trace, read data 0");
    chk(dq_lo === KEEP, "reset: DQ released");
    rst_n = 1'b1;
    @(negedge clk);
    chk(cke === 1'b1, "CKE follows reset release");

    // ACT: one RAS cycle carrying the row, exact tRCD before the host may continue
    issue(3'd1, {14'h2A5C, 18'h0_0012});
    chk(s_tv[0] && s_tc[0] == 3'd1 && s_ta[0] == {14'h2A5C, 18'h0_0012} && tv_count() == 1,
        "ACT emits one gem5 activate trace with the host address");
    chk(s_ras[1] == 0 && s_cas[1] == 1 && s_we[1] == 1, "ACT encoding RAS_n=0 CAS_n=1 WE_n=1");
    chk(s_ad[1] == AL'(14'h2A5C), "ACT drives the row address haddr[31:18]");
    chk(s_ras[2] == 1, "ACT is a single-cycle command");
    chk(first_ready() == TRCD + 2, $sformatf("host ready again exactly tRCD after ACT (k=%0d)", first_ready()));
    chk(done_count() == 0, "ACT does not pulse hdone");

    // WR: data on DQ for the command cycle, CAS/WE strobe with the column
    issue(3'd3, 32'h0000_00C3, 16'hBEEF);
    chk(s_tv[0] && s_tc[0] == 3'd3 && s_ta[0] == 32'h0000_00C3 && tv_count() == 1, "WR emits one write trace");
    chk(s_dq[0] == 16'hBEEF, "write data driven on DQ in the WR cycle");
    chk(s_dqz[1], "DQ released after the WR cycle");
    chk(s_ras[1] == 1 && s_cas[1] == 0 && s_we[1] == 0, "WR encoding RAS_n=1 CAS_n=0 WE_n=0");
    chk(s_ad[1] == AL'(8'hC3), "WR drives the column address haddr[7:0]");
    chk(s_cas[2] == 1 && s_we[2] == 1, "WR is a single-cycle command");
    chk(first_ready() == CL + 2 && done_count() == 0, "WR busy for CL, no hdone");

    // RD: exact CAS latency, single hdone, data the clock after hdone
    rd(32'h0000_00C3);
    chk(s_tv[0] && s_tc[0] == 3'd2 && s_ta[0] == 32'h0000_00C3 && tv_count() == 1, "RD emits one read trace");
    chk(s_ras[1] == 1 && s_cas[1] == 0 && s_we[1] == 1, "RD encoding RAS_n=1 CAS_n=0 WE_n=1");
    chk(s_ad[1] == AL'(8'hC3), "RD drives the column address");
    chk(s_cas[2] == 1, "RD is a single-cycle command");
    chk(s_done[CL + 1] && done_count() == 1, $sformatf("single hdone exactly CL after RD"));
    chk(got == 16'hBEEF && s_rd[CL] != 16'hBEEF, "read data returned at the end of CL");
    chk(first_ready() == CL + 2, "host ready the clock after hdone");
    chk(s_dqz[0] && s_dqz[1], "controller does not drive DQ on a read");

    // column decode: neighbours and the top column are separate words
    issue(3'd3, 32'h0000_00C2, 16'h1234);
    issue(3'd3, 32'h0000_00FF, 16'h5A5A);
    issue(3'd3, 32'h0000_0000, 16'hA5A5);
    rd(32'h0000_00C3); chk(got == 16'hBEEF, "column C3 unaffected by C2 write");
    rd(32'h0000_00C2); chk(got == 16'h1234, "column C2 holds its word");
    rd(32'h0000_00FF); chk(got == 16'h5A5A, "top column FF holds its word");
    rd(32'h0000_0000); chk(got == 16'hA5A5, "column 0 holds its word");
    rd(32'h0000_0077); chk(got == 16'h0000, "unwritten column reads 0");

    // idle command and PRE
    @(negedge clk); hcmd = '0;
    issue(3'd0, 32'h0000_00C3);
    chk(first_ready() == 0 && tv_count() == 0 && s_ras[1] == 1 && s_cas[1] == 1, "idle host command is a no-op");
    issue(3'd4, 32'h0);
    chk(s_ras[1] == 0 && s_cas[1] == 1 && s_we[1] == 0, "PRE encoding RAS_n=0 CAS_n=1 WE_n=0");
    chk(tv_count() == 0 && done_count() == 0, "PRE emits no trace and no hdone");
    chk_xfail(s_ras[2] == 1 && s_we[2] == 1, "PRE is a single-cycle command (pins return to NOP)");
    chk_xfail(first_ready() >= TRP + 1, "host held off for tRP after PRE");

    // random write/read mix against a reference (reads pick written columns)
    begin
      logic [15:0] m [256];
      bit wrt [256];
      int bad = 0;
      foreach (wrt[i]) wrt[i] = 0;
      wrt[8'hC3] = 1; m[8'hC3] = 16'hBEEF; wrt[8'hC2] = 1; m[8'hC2] = 16'h1234;
      wrt[8'hFF] = 1; m[8'hFF] = 16'h5A5A; wrt[8'h00] = 1; m[8'h00] = 16'hA5A5;
      for (int t = 0; t < 40; t++) begin
        logic [7:0] c;
        logic [15:0] d;
        c = 8'($urandom);
        d = 16'($urandom);
        if ($urandom_range(1)) begin
          issue(3'd3, {$urandom} & 32'hFFFC_FE00 | {24'h0, c}, d);   // upper/row bits ignored
          wrt[c] = 1; m[c] = d;
        end else begin
          rd({24'h0, c});
          if (got != (wrt[c] ? m[c] : 16'h0)) bad++;
        end
      end
      chk(bad == 0, $sformatf("40 random reads/writes match the reference (%0d bad)", bad));
    end

    // reset clears the array, the pins and the read register
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(ras_n === 1'b1 && we_n === 1'b1 && hrdata === '0 && hready === 1'b1, "reset returns pins to NOP, ready, data 0");
    rst_n = 1'b1;
    rd(32'h0000_00C3);
    chk(got == 16'h0000, "reset clears stored data");
    rd(32'h0000_0000);
    chk(got == 16'h0000, "reset clears column 0");

    // channel select haddr[8]: channel 1 has its own array and returns data
    // through the host mux (it does not drive the shared CA bus)
    issue(3'd3, 32'h0000_01C3, 16'h7777);
    chk(s_tv[0] && s_tc[0] == 3'd3 && s_ta[0] == 32'h0000_01C3, "channel-1 WR seen on the trace mux");
    rd(32'h0000_01C3); chk(got == 16'h7777, "channel 1 returns its own data");
    rd(32'h0000_00C3); chk(got == 16'h0000, "channel 0 unaffected by the channel-1 write");

    chk(cs_bad == 0, $sformatf("CS_n low exactly when a command is on CA (%0d bad cycles)", cs_bad));
    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
endmodule
