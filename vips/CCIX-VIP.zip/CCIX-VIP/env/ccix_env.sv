// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ccix_env.sv -- CCIX verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import ccix_defs_pkg::*;
  import ccix_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) flits against
  // monitor-decoded (observed) flits from the link waveform.
  class ccix_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(ccix_scoreboard)
    uvm_analysis_imp_exp #(ccix_transaction, ccix_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(ccix_transaction, ccix_scoreboard) obs_ap;

    ccix_transaction exp_q[$], obs_q[$];
    int unsigned match_cnt = 0, mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(ccix_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(ccix_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        ccix_transaction e = exp_q.pop_front();
        ccix_transaction o = obs_q.pop_front();
        if (e.msg_type == o.msg_type && e.src_id == o.src_id && e.payload == o.payload)
          match_cnt++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("ccix scoreboard: matches=%0d mismatches=%0d",
                match_cnt, mismatches), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class ccix_env extends uvm_env;
    `uvm_component_utils(ccix_env)
    ccix_agent      agt;
    ccix_scoreboard sb;
    ccix_checker    chk;
    ccix_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = ccix_agent::type_id::create("agt", this);
      sb  = ccix_scoreboard::type_id::create("sb", this);
      chk = ccix_checker::type_id::create("chk", this);
      cov = ccix_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
