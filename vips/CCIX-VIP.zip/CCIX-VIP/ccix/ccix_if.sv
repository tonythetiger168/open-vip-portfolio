// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ccix_if.sv -- CCIX Cache Coherent Interconnect interface
// Flit-based link with credit-based flow control.
// Flit layout: [63:62]=msg_type, [61:56]=src_id, [55:4]=payload, [3:0]=credit

interface ccix_if (input logic clk);
  import ccix_defs_pkg::ccix_state_e;

  logic        resetn;
  // Requester (VIP master) -> Agent (DUT) flit channel
  logic        tx_flit_valid;
  logic [63:0] tx_flit;
  // Agent (DUT) -> Requester echo/response channel
  logic        rx_flit_valid;
  logic [63:0] rx_flit;
  // Credit level granted by the receiving agent (flow control)
  logic [3:0]  credit;
  // Error-injection window flag (TB-driven; gates the L4 credit SVA)
  logic        err_inject;

  ccix_state_e state;

  modport MASTER (input  clk, resetn, credit, rx_flit_valid, rx_flit,
                  output tx_flit_valid, tx_flit, err_inject, state);
  modport AGENT  (input  clk, resetn, tx_flit_valid, tx_flit,
                  output rx_flit_valid, rx_flit, credit);
  modport MON    (input  clk, resetn, tx_flit_valid, tx_flit,
                        rx_flit_valid, rx_flit, credit, err_inject, state);

  clocking drv_cb @(posedge clk);
    input  resetn, credit, rx_flit_valid, rx_flit;
    output tx_flit_valid, tx_flit, err_inject;
  endclocking

  clocking mon_cb @(posedge clk);
    input resetn, tx_flit_valid, tx_flit, rx_flit_valid, rx_flit, credit, state;
  endclocking
endinterface
