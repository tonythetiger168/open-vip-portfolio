// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ccix_coverage.svh -- CCIX functional coverage

`ifndef CCIX_COVERAGE_SVH
`define CCIX_COVERAGE_SVH

class ccix_coverage extends uvm_subscriber #(ccix_transaction);
  `uvm_component_utils(ccix_coverage)

  ccix_transaction tr;
  ccix_state_e cur_state;
  virtual ccix_if vif;

  covergroup cg_protocol;
    cp_msg : coverpoint tr.msg_type {
      bins req = {ccix_transaction::CCIX_MSG_REQ};
      bins rsp = {ccix_transaction::CCIX_MSG_RSP};
      bins snp = {ccix_transaction::CCIX_MSG_SNP};
      bins dat = {ccix_transaction::CCIX_MSG_DAT};
    }
    cp_src : coverpoint tr.src_id {
      bins low  = {[6'h00 : 6'h1F]};
      bins high = {[6'h20 : 6'h3E]};
    }
    cp_credit : coverpoint tr.credit {
      bins min  = {1};
      bins mid  = {[2:6]};
      bins high = {[7:8]};
    }
    cp_payload : coverpoint tr.payload[7:0] {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins walk = {[8'h01 : 8'hFE]};
    }
    cx_msg_credit : cross cp_msg, cp_credit;
    cx_msg_src    : cross cp_msg, cp_src;
  endgroup

  covergroup cg_fsm with function sample(ccix_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {RESET, LINK_UP, REQ_RSP, MEM_SNOOP, ERROR};
    }
    cp_trans : coverpoint s {
      bins link_seq  = (RESET => LINK_UP => REQ_RSP);
      bins snoop_seq = (REQ_RSP => MEM_SNOOP => REQ_RSP);
      bins err_seq   = (REQ_RSP => ERROR => REQ_RSP);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.error_inject {
      bins legal   = {0};
      bins ovf     = {1};
    }
    cp_err_msg : coverpoint tr.msg_type iff (tr.error_inject) {
      bins ovf_msg[] = {ccix_transaction::CCIX_MSG_REQ, ccix_transaction::CCIX_MSG_RSP,
                        ccix_transaction::CCIX_MSG_SNP, ccix_transaction::CCIX_MSG_DAT};
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual ccix_if)::get(this, "", "vif", vif));
  endfunction

  function void write(ccix_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction

  // Sample the link FSM every cycle so all states/transitions are observable
  task run_phase(uvm_phase phase);
    if (vif == null) begin
      `uvm_warning("COV", "ccix coverage: no vif, FSM coverage disabled")
      return;
    end
    forever begin
      @(posedge vif.clk);
      cur_state = vif.state;
      cg_fsm.sample(cur_state);
    end
  endtask
endclass
`endif
