// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ccix_transaction.svh -- CCIX flit transaction
// Flit layout: [63:62]=msg_type, [61:56]=src_id, [55:4]=payload, [3:0]=credit

`ifndef CCIX_TRANSACTION_SVH
`define CCIX_TRANSACTION_SVH

class ccix_transaction extends uvm_sequence_item;

  typedef enum bit [1:0] {CCIX_MSG_REQ = 2'b00, CCIX_MSG_RSP = 2'b01,
                          CCIX_MSG_SNP = 2'b10, CCIX_MSG_DAT = 2'b11} ccix_msg_type_e;

  rand ccix_msg_type_e msg_type;
  rand bit [5:0]       src_id;
  rand bit [51:0]      payload;
  rand bit [3:0]       credit;         // credits carried / granted by this flit
  rand bit             error_inject;   // 1 = transmit with no credit (credit overflow)
  rand int unsigned    inter_flit_gap; // idle cycles after this flit

  bit [63:0]           raw_flit;       // monitor: raw flit observed on the link

  constraint c_credit { credit inside {[1:8]}; }
  constraint c_src    { src_id != 6'h3F; }                       // 0x3F = broadcast (reserved)
  constraint c_gap    { inter_flit_gap inside {[0:4]}; }
  constraint c_err    { error_inject dist {0 := 9, 1 := 1}; }

  `uvm_object_utils_begin(ccix_transaction)
    `uvm_field_enum(ccix_msg_type_e, msg_type, UVM_ALL_ON)
    `uvm_field_int(src_id, UVM_ALL_ON)
    `uvm_field_int(payload, UVM_ALL_ON)
    `uvm_field_int(credit, UVM_ALL_ON)
    `uvm_field_int(error_inject, UVM_ALL_ON)
    `uvm_field_int(raw_flit, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "ccix_transaction");
    super.new(name);
  endfunction

  function bit [63:0] pack_flit();
    return {msg_type, src_id, payload, credit};
  endfunction

  function void unpack_flit(bit [63:0] f);
    msg_type = ccix_msg_type_e'(f[63:62]);
    src_id   = f[61:56];
    payload  = f[55:4];
    credit   = f[3:0];
    raw_flit = f;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ccix_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    ok &= comparer.compare_field("src_id",  src_id,  t.src_id,  6);
    ok &= comparer.compare_field("payload", payload, t.payload, 52);
    return ok;
  endfunction

  function string convert2string();
    string mn;
    case (msg_type)
      CCIX_MSG_REQ: mn = "REQ";
      CCIX_MSG_RSP: mn = "RSP";
      CCIX_MSG_SNP: mn = "SNP";
      default:      mn = "DAT";
    endcase
    return $sformatf("CCIX %s src=0x%02h payload=0x%013h credit=%0d err=%0b",
                     mn, src_id, payload, credit, error_inject);
  endfunction
endclass
`endif
