// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ccix_compliance_checker.sv -- CCIX Cache Coherent Interconnect SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules, L4 = CCIX-specific rules

`ifndef CCIX_COMPLIANCE_CHECKER_SV
`define CCIX_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import ccix_defs_pkg::*;

module ccix_compliance_checker
(
  input logic clk,
  input logic resetn,
  input ccix_state_e state,
  input logic tx_flit_valid,
  input logic [63:0] tx_flit,
  input logic rx_flit_valid,
  input logic [3:0] credit,
  input logic err_inject
);

  // ---------------- L1: signal sanity (4) ----------------
  a_ccix_l1_clk   : assert property (@(posedge clk) disable iff (!resetn) !$isunknown(clk))
    else `uvm_error("SVA_L1", "ccix: clock unknown")
  a_ccix_l1_rst   : assert property (@(posedge clk) !$isunknown(resetn))
    else `uvm_error("SVA_L1", "ccix: reset unknown")
  a_ccix_l1_state : assert property (@(posedge clk) disable iff (!resetn) !$isunknown(state))
    else `uvm_error("SVA_L1", "ccix: state unknown")
  a_ccix_l1_valid : assert property (@(posedge clk) disable iff (!resetn)
    state inside {RESET, LINK_UP, REQ_RSP, MEM_SNOOP, ERROR})
    else `uvm_error("SVA_L1", "ccix: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from RESET
  a_ccix_trans_reset : assert property (@(posedge clk) disable iff (!resetn)
    state == RESET |=> state inside {RESET, LINK_UP})
    else `uvm_error("SVA_L2", "ccix: illegal transition from RESET")

  // L2-2: legal FSM transition from LINK_UP
  a_ccix_trans_link_up : assert property (@(posedge clk) disable iff (!resetn)
    state == LINK_UP |=> state inside {LINK_UP, REQ_RSP})
    else `uvm_error("SVA_L2", "ccix: illegal transition from LINK_UP")

  // L2-3: legal FSM transition from REQ_RSP
  a_ccix_trans_req_rsp : assert property (@(posedge clk) disable iff (!resetn)
    state == REQ_RSP |=> state inside {REQ_RSP, MEM_SNOOP})
    else `uvm_error("SVA_L2", "ccix: illegal transition from REQ_RSP")

  // L2-4: legal FSM transition from MEM_SNOOP
  a_ccix_trans_mem_snoop : assert property (@(posedge clk) disable iff (!resetn)
    state == MEM_SNOOP |=> state inside {MEM_SNOOP, ERROR})
    else `uvm_error("SVA_L2", "ccix: illegal transition from MEM_SNOOP")

  // L2-5: legal FSM transition from ERROR
  a_ccix_trans_error : assert property (@(posedge clk) disable iff (!resetn)
    state == ERROR |=> state inside {ERROR, RESET})
    else `uvm_error("SVA_L2", "ccix: illegal transition from ERROR")

  // ---------------- L3: protocol rules (4) ----------------
  a_ccix_l3_reset_idle : assert property (@(posedge clk)
    $fell(resetn) |-> ##[1:4] (state == RESET))
    else `uvm_error("SVA_L3", "ccix: state not RESET during reset")
  a_ccix_l3_no_stuck   : assert property (@(posedge clk) disable iff (!resetn)
    state == ERROR |-> ##[1:8] (state != ERROR))
    else `uvm_error("SVA_L3", "ccix: stuck in ERROR")
  a_ccix_l3_full_cycle : cover property (@(posedge clk) disable iff (!resetn)
    state == RESET ##1 state == LINK_UP);
  a_ccix_l3_back_idle  : cover property (@(posedge clk) disable iff (!resetn)
    state == ERROR ##1 state == RESET);

  // ---------------- L4: CCIX protocol-specific rules (4) ----------------
  // L4-1: credit-based flow control -- no flit may be transmitted while the
  //       agent has granted zero credits (disabled during error injection)
  a_ccix_l4_no_flit_wo_credit : assert property (@(posedge clk)
    disable iff (!resetn || err_inject)
    $rose(tx_flit_valid) |-> (credit != 4'd0))
    else `uvm_error("SVA_L4", "ccix: flit transmitted without credit")

  // L4-2: flit payload must remain stable for the whole valid window
  a_ccix_l4_flit_stable : assert property (@(posedge clk) disable iff (!resetn)
    (tx_flit_valid && $past(tx_flit_valid)) |-> $stable(tx_flit))
    else `uvm_error("SVA_L4", "ccix: flit changed during valid window")

  // L4-3: no traffic before the link-up sequence has completed
  a_ccix_l4_no_traffic_before_link : assert property (@(posedge clk) disable iff (!resetn)
    tx_flit_valid |-> (state != RESET && state != LINK_UP))
    else `uvm_error("SVA_L4", "ccix: traffic transmitted before link up")

  // L4-4: every snoop request must be answered by a response flit
  a_ccix_l4_snoop_needs_rsp : assert property (@(posedge clk) disable iff (!resetn)
    (tx_flit_valid && tx_flit[63:62] == 2'b10) |-> ##[1:8] rx_flit_valid)
    else `uvm_error("SVA_L4", "ccix: snoop request without response flit")

endmodule
`endif
