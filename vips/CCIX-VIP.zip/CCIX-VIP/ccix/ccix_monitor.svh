// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ccix_monitor.svh -- CCIX monitor: decodes flits from the tx_flit waveform
// and publishes reconstructed transactions; also counts agent echo flits.

`ifndef CCIX_MONITOR_SVH
`define CCIX_MONITOR_SVH

class ccix_monitor extends uvm_monitor;
  `uvm_component_utils(ccix_monitor)
  virtual ccix_if vif;
  uvm_analysis_port #(ccix_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned rx_echo_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ccix_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ccix virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    ccix_transaction tr;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.resetn !== 1'b1) continue;
      if (vif.mon_cb.tx_flit_valid) begin
        tr = ccix_transaction::type_id::create("tr");
        tr.unpack_flit(vif.mon_cb.tx_flit);
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
      if (vif.mon_cb.rx_flit_valid) rx_echo_count++;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("ccix monitor observed %0d tx flits, %0d rx echo flits",
              txn_count, rx_echo_count), UVM_LOW)
  endfunction
endclass
`endif
