// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ccix_pkg.sv -- CCIX Cache Coherent Interconnect UVM VIP package

package ccix_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ccix_defs_pkg::*;
  export ccix_defs_pkg::*;

  `include "ccix_transaction.svh"
  `include "ccix_config.svh"
  `include "ccix_sequencer.svh"
  `include "ccix_driver.svh"
  `include "ccix_monitor.svh"
  `include "ccix_agent.svh"
  `include "ccix_sequences.svh"
  `include "ccix_checker.svh"
  `include "ccix_coverage.svh"
endpackage
