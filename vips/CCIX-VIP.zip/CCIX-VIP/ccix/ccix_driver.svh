// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ccix_driver.svh -- CCIX requester driver
// Performs the link-up sequence, then transmits flits under credit-based
// flow control (one 64-bit flit per valid cycle, only while credit > 0).

`ifndef CCIX_DRIVER_SVH
`define CCIX_DRIVER_SVH

class ccix_driver extends uvm_driver #(ccix_transaction);
  `uvm_component_utils(ccix_driver)
  virtual ccix_if vif;
  ccix_config cfg;
  uvm_analysis_port #(ccix_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ccix_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ccix virtual interface not set")
  endfunction

  // Link-up: wait for the agent's initial credit grant before any traffic
  task link_up();
    int unsigned tmo = 0;
    vif.state = ccix_defs_pkg::LINK_UP;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "ccix link-up timeout: no initial credits")
    end while (vif.drv_cb.credit == 0);
    repeat (2) @(vif.drv_cb);
    vif.state = ccix_defs_pkg::REQ_RSP;
    `uvm_info("DRV", $sformatf("ccix link up, initial credit=%0d", vif.drv_cb.credit), UVM_MEDIUM)
  endtask

  // Credit-based flow control: block until the agent has granted a credit
  task wait_credit();
    int unsigned tmo = 0;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "ccix credit starvation timeout")
    end while (vif.drv_cb.credit == 0);
  endtask

  task drive_flit(ccix_transaction tr);
    `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
    if (tr.error_inject) begin
      // Credit overflow injection: wait for the pool to drain, transmit anyway
      int unsigned tmo = 0;
      vif.state = ccix_defs_pkg::ERROR;
      do begin
        @(vif.drv_cb);
        if (++tmo > 256) begin
          `uvm_warning("DRV", "credit pool did not drain; injecting overflow anyway")
          break;
        end
      end while (vif.drv_cb.credit != 0);
      vif.drv_cb.err_inject <= 1'b1;
    end else begin
      wait_credit();
      vif.state = (tr.msg_type == ccix_transaction::CCIX_MSG_SNP)
                  ? ccix_defs_pkg::MEM_SNOOP : ccix_defs_pkg::REQ_RSP;
    end
    vif.drv_cb.tx_flit_valid <= 1'b1;
    vif.drv_cb.tx_flit       <= tr.pack_flit();
    @(vif.drv_cb);
    vif.drv_cb.tx_flit_valid <= 1'b0;
    vif.drv_cb.err_inject    <= 1'b0;
    repeat (tr.inter_flit_gap) @(vif.drv_cb);
    if (tr.error_inject) vif.state = ccix_defs_pkg::REQ_RSP;  // recover after injection
  endtask

  task run_phase(uvm_phase phase);
    ccix_transaction tr;
    vif.drv_cb.tx_flit_valid <= 1'b0;
    vif.drv_cb.tx_flit       <= '0;
    vif.drv_cb.err_inject    <= 1'b0;
    vif.state = ccix_defs_pkg::RESET;
    wait (vif.resetn === 1'b1);
    link_up();
    forever begin
      seq_item_port.get_next_item(tr);
      drive_flit(tr);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
