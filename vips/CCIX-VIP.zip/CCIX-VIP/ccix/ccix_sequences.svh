// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ccix_sequences.svh -- CCIX sequence library

`ifndef CCIX_SEQUENCES_SVH
`define CCIX_SEQUENCES_SVH

class ccix_base_sequence extends uvm_sequence #(ccix_transaction);
  `uvm_object_utils(ccix_base_sequence)
  int num_txns = 20;
  function new(string name = "ccix_base_sequence"); super.new(name); endfunction
  task body();
    ccix_transaction tr;
    repeat (num_txns) begin
      tr = ccix_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: first requests right after the link-up sequence completes
class ccix_link_up_seq extends ccix_base_sequence;
  `uvm_object_utils(ccix_link_up_seq)

  function new(string name = "ccix_link_up_seq"); super.new(name); endfunction

  task body();
    ccix_transaction tr;
    num_txns = 8;
    repeat (num_txns) begin
      tr = ccix_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { msg_type == CCIX_MSG_REQ;
                                  inter_flit_gap == 2; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: alternating request / response message traffic
class ccix_req_rsp_seq extends ccix_base_sequence;
  `uvm_object_utils(ccix_req_rsp_seq)

  function new(string name = "ccix_req_rsp_seq"); super.new(name); endfunction

  task body();
    ccix_transaction tr;
    repeat (num_txns) begin
      tr = ccix_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { msg_type inside {CCIX_MSG_REQ, CCIX_MSG_RSP};
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: snoop message traffic (drives the MEM_SNOOP link state)
class ccix_snoop_seq extends ccix_base_sequence;
  `uvm_object_utils(ccix_snoop_seq)

  function new(string name = "ccix_snoop_seq"); super.new(name); endfunction

  task body();
    ccix_transaction tr;
    repeat (num_txns) begin
      tr = ccix_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { msg_type == CCIX_MSG_SNP; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: data flits with payload corner values (all-0 / all-1 / walking)
class ccix_data_seq extends ccix_base_sequence;
  `uvm_object_utils(ccix_data_seq)

  function new(string name = "ccix_data_seq"); super.new(name); endfunction

  task body();
    ccix_transaction tr;
    bit [51:0] corners[$] = '{52'h0, {52{1'b1}}, 52'h1, 52'hA_AAAA_AAAA_AAAA};
    repeat (num_txns) begin
      tr = ccix_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { msg_type == CCIX_MSG_DAT;
                                  payload inside {corners}; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: credit stress -- back-to-back flits that drain the credit pool
class ccix_credit_stress_seq extends ccix_base_sequence;
  `uvm_object_utils(ccix_credit_stress_seq)

  function new(string name = "ccix_credit_stress_seq"); super.new(name); endfunction

  task body();
    ccix_transaction tr;
    num_txns = 24;
    repeat (num_txns) begin
      tr = ccix_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inter_flit_gap == 0; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: drain the credit pool, then transmit without credit
class ccix_error_inject_seq extends ccix_base_sequence;
  `uvm_object_utils(ccix_error_inject_seq)

  function new(string name = "ccix_error_inject_seq"); super.new(name); endfunction

  task body();
    ccix_transaction tr;
    // drain: rapid legal flits
    repeat (6) begin
      tr = ccix_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inter_flit_gap == 0; error_inject == 0; });
      finish_item(tr);
    end
    // overflow: flit transmitted with zero credits
    repeat (3) begin
      tr = ccix_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single small transfer after link-up
class ccix_reset_seq extends ccix_base_sequence;
  `uvm_object_utils(ccix_reset_seq)

  function new(string name = "ccix_reset_seq"); super.new(name); endfunction

  task body();
    ccix_transaction tr = ccix_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { msg_type == CCIX_MSG_REQ; credit == 1;
                                error_inject == 0; });
    finish_item(tr);
  endtask
endclass

class ccix_random_sequence extends ccix_base_sequence;
  `uvm_object_utils(ccix_random_sequence)
  function new(string name = "ccix_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class ccix_regression_sequence extends ccix_base_sequence;
  `uvm_object_utils(ccix_regression_sequence)
  function new(string name = "ccix_regression_sequence"); super.new(name); endfunction
  task body();
    ccix_link_up_seq        lu  = ccix_link_up_seq::type_id::create("lu");
    ccix_req_rsp_seq        rr  = ccix_req_rsp_seq::type_id::create("rr");
    ccix_snoop_seq          snp = ccix_snoop_seq::type_id::create("snp");
    ccix_data_seq           dat = ccix_data_seq::type_id::create("dat");
    ccix_credit_stress_seq  cs  = ccix_credit_stress_seq::type_id::create("cs");
    ccix_error_inject_seq   err = ccix_error_inject_seq::type_id::create("err");
    rr.num_txns = 20; snp.num_txns = 10; dat.num_txns = 12;
    lu.start(m_sequencer); rr.start(m_sequencer); snp.start(m_sequencer);
    dat.start(m_sequencer); cs.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
`endif
