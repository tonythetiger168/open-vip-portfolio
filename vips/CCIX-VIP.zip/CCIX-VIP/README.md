# CCIX — CCIX Cache Coherent Interconnect UVM VIP

Open-source UVM verification IP template for **CCIX Cache Coherent Interconnect** (Interconnect).

## Contents

| Path | Description |
|------|-------------|
| `ccix/ccix_if.sv` | Protocol interface + FSM state enum |
| `ccix/ccix_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `ccix/sva/ccix_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=4) |
| `ccix/vip/ccix/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/ccix_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional CCIX agent DUT |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Flit-based protocol driver**: 64-bit flits (`msg_type/src_id/payload/credit`), link-up sequence that waits for the agent's initial credit grant before any traffic
- **Credit-based flow control**: driver blocks while `credit == 0`; DUT consumes one credit per flit and returns credits through a 4-deep pipeline
- **Protocol-decoding monitor**: reconstructs CCIX transactions (REQ/RSP/SNP/DAT) from the `tx_flit` waveform and counts agent echo flits
- **End-to-end scoreboard**: compares driver-issued vs monitor-decoded flits (msg_type / src_id / payload)
- **Functional DUT model**: CCIX agent with initial credit grant, credit return pipeline, RSP echo flits, and credit-overflow detection
- **Directed sequence library**: link-up / req-rsp mix / snoop / data-corner / credit-stress / error-inject (credit overflow) / reset + regression mix
- **Functional coverage**: msg_type x credit and msg_type x src_id crosses, payload corners, link FSM state + transition sequences, credit-overflow error bins
- **SVA L4**: no flit without credit, flit stable during valid window, no traffic before link-up, snoop must be answered by a response flit
