// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- CCIX testbench top with a functional CCIX agent DUT model

`ifndef CCIX_TB_SV
`define CCIX_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ccix_defs_pkg::*;
import ccix_pkg::*;
import ccix_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ccix_if vif(clk);

  initial begin
    vif.resetn = 0;
    #100ns;
    vif.resetn = 1;
  end

  ccix_agent_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual ccix_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional CCIX agent: grants 4 initial credits at link-up, consumes one
// credit per accepted flit, returns credits through a 4-deep pipeline, and
// echoes a RSP flit back to the requester for every flit received.
module ccix_agent_model (ccix_if vif);
  int unsigned pool;
  int unsigned p;
  bit [3:0]    rtn_pipe;
  bit          link_done;

  initial begin
    vif.rx_flit_valid = 0;
    vif.rx_flit       = '0;
    vif.credit        = '0;
  end

  always_ff @(posedge vif.clk or negedge vif.resetn) begin
    if (!vif.resetn) begin
      pool              <= 0;
      rtn_pipe          <= '0;
      link_done         <= 0;
      vif.rx_flit_valid <= 0;
      vif.rx_flit       <= '0;
      vif.credit        <= '0;
    end else begin
      p = pool;
      // Link-up: initial credit grant
      if (!link_done) begin
        link_done <= 1;
        p = 4;
      end
      vif.rx_flit_valid <= 1'b0;
      if (vif.tx_flit_valid) begin
        if (p == 0)
          `uvm_warning("DUT", "ccix agent: flit received with zero credits (credit overflow)")
        else
          p = p - 1;
        // Echo a RSP flit back to the requester (msg_type=RSP, 1 credit)
        vif.rx_flit_valid <= 1'b1;
        vif.rx_flit       <= {2'b01, vif.tx_flit[61:56], vif.tx_flit[55:4], 4'd1};
        rtn_pipe          <= {rtn_pipe[2:0], 1'b1};
      end else begin
        rtn_pipe <= {rtn_pipe[2:0], 1'b0};
      end
      // Delayed credit return (4-cycle pipeline)
      if (rtn_pipe[3] && p < 15) p = p + 1;
      pool       <= p;
      vif.credit <= p[3:0];
    end
  end
endmodule
`endif
