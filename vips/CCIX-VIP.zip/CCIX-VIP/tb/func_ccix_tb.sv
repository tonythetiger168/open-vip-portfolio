// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_ccix_tb.sv -- self-checking functional test for the CCIX agent model
// (ccix_agent_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py CCIX-VIP
//
// Model contract (from tb/top_tb.sv):
//   link-up grants 4 credits on the first clock after reset; each received
//   flit (tx_flit_valid) consumes one credit and is echoed one clock later on
//   rx_flit as {2'b01, tx[61:56], tx[55:4], 4'd1}; the credit is returned 4
//   clocks after the flit. vif_credit shows the current pool.

module func_ccix_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic        clk = 1'b0, resetn = 1'b0, tx_valid = 1'b0;
  logic [63:0] tx_flit = '0;
  wire         rx_valid;
  wire  [63:0] rx_flit;
  wire  [3:0]  credit;

  always #5 clk = ~clk;

  ccix_agent_model u_dut (
    .vif_clk(clk), .vif_resetn(resetn), .vif_tx_flit_valid(tx_valid),
    .vif_tx_flit(tx_flit), .vif_rx_flit_valid(rx_valid), .vif_rx_flit(rx_flit),
    .vif_credit(credit)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic [63:0] expect_rx(input [63:0] t);
    return {2'b01, t[61:56], t[55:4], 4'd1};
  endfunction

  // send n back-to-back flits starting with seed; returns at the negedge
  // after the last flit edge
  task automatic send(input int n, input [63:0] seed);
    for (int i = 0; i < n; i++) begin
      @(negedge clk);
      tx_valid = 1'b1; tx_flit = seed + 64'(i) * 64'h0101_0101_0101_0101;
    end
    @(negedge clk);
    tx_valid = 1'b0;
  endtask

  int nrx;
  logic [63:0] rx_log [8];
  always @(posedge clk) if (rx_valid) begin
    if (nrx < 8) rx_log[nrx] = rx_flit;
    nrx++;
  end

  initial begin
    nrx = 0;
    repeat (3) @(negedge clk);
    chk(credit === 4'd0 && rx_valid === 1'b0, "no credits and no rx flit while in reset");
    resetn = 1'b1;
    repeat (2) @(negedge clk);
    chk(credit === 4'd4, "link-up grants 4 credits");

    // single flit: echo, latency, credit consume/return
    @(negedge clk); tx_valid = 1'b1; tx_flit = 64'hFFEE_DDCC_BBAA_9988;
    @(negedge clk); tx_valid = 1'b0;
    chk(rx_valid === 1'b1, "rx flit valid one clock after tx flit");
    chk(rx_flit === expect_rx(64'hFFEE_DDCC_BBAA_9988), "rx flit carries header 01, payload, credit-return 1");
    chk(credit === 4'd3, "flit consumes one credit");
    @(negedge clk);
    chk(rx_valid === 1'b0, "rx valid is a single-clock pulse per flit");
    repeat (3) @(negedge clk);
    chk(credit === 4'd4, "credit returned 4 clocks after the flit");

    // burst of 4 drains the pool, then every credit comes back
    nrx = 0;
    send(4, 64'h1000_0000_0000_0001);
    chk(credit === 4'd0, "4 back-to-back flits drain all credits");
    repeat (5) @(negedge clk);
    chk(credit === 4'd4, "all 4 credits returned after the burst");
    chk(nrx == 4, "every flit of the burst is delivered");
    chk(rx_log[0] === expect_rx(64'h1000_0000_0000_0001) &&
        rx_log[3] === expect_rx(64'h1000_0000_0000_0001 + 64'h0303_0303_0303_0303),
        "burst flits delivered in order");

    // reset clears credits and outputs; link-up regrants
    @(negedge clk); resetn = 1'b0;
    @(negedge clk);
    chk(credit === 4'd0 && rx_valid === 1'b0, "reset clears credits and rx");
    resetn = 1'b1;
    repeat (2) @(negedge clk);
    chk(credit === 4'd4, "credits re-granted after reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
