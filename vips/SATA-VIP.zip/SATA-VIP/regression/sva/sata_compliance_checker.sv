// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
`ifndef SATA_COMPLIANCE_CHECKER_SV
`define SATA_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// Module form of the tiered SATA compliance checker (bindable from any tb).
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=SATA specific
module sata_compliance_checker (sata_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

// ===== L1: Basic Compliance (4 SVAs) =====
  property p_sata_link_speed; @(posedge vif.clk) disable iff (!vif.rst_n) vif.link_speed inside {4'b0001,4'b0010,4'b0011,4'b0100}; endproperty
  assert_p_sata_link_speed: assert property(p_sata_link_speed) l1_pass[0]++; else begin `uvm_warning("SATA_L1", "Link speed failed"); l1_fail[0]++; end
  cover_p_sata_link_speed: cover property(p_sata_link_speed);
  property p_sata_primitive; @(posedge vif.clk) disable iff (!vif.rst_n) vif.prim == 1 |-> vif.primitive_type != 32'h00000000; endproperty
  assert_p_sata_primitive: assert property(p_sata_primitive) l1_pass[1]++; else begin `uvm_warning("SATA_L1", "Primitive valid failed"); l1_fail[1]++; end
  cover_p_sata_primitive: cover property(p_sata_primitive);
  property p_sata_fis_type; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fis_valid == 1 |-> vif.fis_type inside {8'h27,8'h34,8'h39,8'h3F,8'h46,8'h5F,8'hA1}; endproperty
  assert_p_sata_fis_type: assert property(p_sata_fis_type) l1_pass[2]++; else begin `uvm_warning("SATA_L1", "FIS type failed"); l1_fail[2]++; end
  cover_p_sata_fis_type: cover property(p_sata_fis_type);
  property p_sata_data_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_valid == 1 |-> vif.link_up == 1; endproperty
  assert_p_sata_data_valid: assert property(p_sata_data_valid) l1_pass[3]++; else begin `uvm_warning("SATA_L1", "Data valid failed"); l1_fail[3]++; end
  cover_p_sata_data_valid: cover property(p_sata_data_valid);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_sata_fis_start; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fis_end == 1 |-> $past(vif.fis_start,1) || vif.fis_start == 1; endproperty
  assert_p_sata_fis_start: assert property(p_sata_fis_start) l2_pass[0]++; else begin `uvm_warning("SATA_L2", "FIS start before end failed"); l2_fail[0]++; end
  cover_p_sata_fis_start: cover property(p_sata_fis_start);
  property p_sata_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync == 1 |-> vif.ready == 1; endproperty
  assert_p_sata_sync: assert property(p_sata_sync) l2_pass[1]++; else begin `uvm_warning("SATA_L2", "Sync when ready failed"); l2_fail[1]++; end
  cover_p_sata_sync: cover property(p_sata_sync);
  property p_sata_link_up; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_valid == 1 |-> vif.link_up == 1; endproperty
  assert_p_sata_link_up: assert property(p_sata_link_up) l2_pass[2]++; else begin `uvm_warning("SATA_L2", "Link up for traffic failed"); l2_fail[2]++; end
  cover_p_sata_link_up: cover property(p_sata_link_up);
  property p_sata_oob; @(posedge vif.clk) disable iff (!vif.rst_n) vif.link_up == 1 |-> $past(vif.tx_p,1) || $past(vif.tx_n,1); endproperty
  assert_p_sata_oob: assert property(p_sata_oob) l2_pass[3]++; else begin `uvm_warning("SATA_L2", "OOB before link failed"); l2_fail[3]++; end
  cover_p_sata_oob: cover property(p_sata_oob);
  property p_sata_ready; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync == 1 |-> ##[1:10] vif.ready == 1; endproperty
  assert_p_sata_ready: assert property(p_sata_ready) l2_pass[4]++; else begin `uvm_warning("SATA_L2", "Ready after sync failed"); l2_fail[4]++; end
  cover_p_sata_ready: cover property(p_sata_ready);
  property p_sata_crc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fis_end == 1 |-> vif.crc_ok == 1; endproperty
  assert_p_sata_crc: assert property(p_sata_crc) l2_pass[5]++; else begin `uvm_warning("SATA_L2", "CRC valid failed"); l2_fail[5]++; end
  cover_p_sata_crc: cover property(p_sata_crc);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_sata_pm_active; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pm_state == 3'b000 |-> vif.link_up == 1; endproperty
  assert_p_sata_pm_active: assert property(p_sata_pm_active) l3_pass[0]++; else begin `uvm_warning("SATA_L3", "PM active failed"); l3_fail[0]++; end
  cover_p_sata_pm_active: cover property(p_sata_pm_active);
  property p_sata_pm_partial; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pm_state == 3'b001 |-> vif.link_up == 0; endproperty
  assert_p_sata_pm_partial: assert property(p_sata_pm_partial) l3_pass[1]++; else begin `uvm_warning("SATA_L3", "PM partial failed"); l3_fail[1]++; end
  cover_p_sata_pm_partial: cover property(p_sata_pm_partial);
  property p_sata_pm_slumber; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pm_state == 3'b010 |-> vif.link_up == 0; endproperty
  assert_p_sata_pm_slumber: assert property(p_sata_pm_slumber) l3_pass[2]++; else begin `uvm_warning("SATA_L3", "PM slumber failed"); l3_fail[2]++; end
  cover_p_sata_pm_slumber: cover property(p_sata_pm_slumber);
  property p_sata_err_inject; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err_inject |-> vif.link_up == 1; endproperty
  assert_p_sata_err_inject: assert property(p_sata_err_inject) l3_pass[3]++; else begin `uvm_warning("SATA_L3", "Error injection failed"); l3_fail[3]++; end
  cover_p_sata_err_inject: cover property(p_sata_err_inject);

  
  // ---------------- L4: SATA protocol-specific rules (5) ----------------
  // L4-1: FIS start must eventually complete with fis_end within 32 DWORDs
  property p_sata_l4_fis_len;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.fis_valid && vif.fis_start) |-> ##[1:32] vif.fis_end;
  endproperty
  assert_p_sata_l4_fis_len: assert property(p_sata_l4_fis_len) l4_pass[0]++;
    else begin `uvm_warning("SATA_L4", "FIS exceeded 32 DWORDs without fis_end"); l4_fail[0]++; end
  cover_p_sata_l4_fis_len: cover property(p_sata_l4_fis_len);

  // L4-2: fis_start only at a frame boundary (not mid-FIS)
  property p_sata_l4_fis_boundary;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.fis_valid && vif.fis_start) |-> ($past(!vif.fis_valid) || $past(vif.fis_end) || $past(!vif.rst_n));
  endproperty
  assert_p_sata_l4_fis_boundary: assert property(p_sata_l4_fis_boundary) l4_pass[1]++;
    else begin `uvm_warning("SATA_L4", "fis_start asserted mid-frame"); l4_fail[1]++; end
  cover_p_sata_l4_fis_boundary: cover property(p_sata_l4_fis_boundary);

  // L4-3: Register H2D FIS (0x27) command field must be a known ATA opcode
  property p_sata_l4_ata_opcode;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.fis_valid && vif.fis_start && vif.fis_type == 8'h27)
        |-> vif.fis_data[15:8] inside {8'hEC, 8'h25, 8'h35, 8'h30, 8'hCA, 8'hEA, 8'h91, 8'h20, 8'h40, 8'h60, 8'h70, 8'hE7, 8'hEF};
  endproperty
  assert_p_sata_l4_ata_opcode: assert property(p_sata_l4_ata_opcode) l4_pass[2]++;
    else begin `uvm_warning("SATA_L4", "unknown ATA opcode in Register H2D FIS"); l4_fail[2]++; end
  cover_p_sata_l4_ata_opcode: cover property(p_sata_l4_ata_opcode);

  // L4-4: no FIS traffic before link-up completes
  property p_sata_l4_link_before_fis;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.fis_valid |-> vif.link_up;
  endproperty
  assert_p_sata_l4_link_before_fis: assert property(p_sata_l4_link_before_fis) l4_pass[3]++;
    else begin `uvm_warning("SATA_L4", "FIS traffic before link-up"); l4_fail[3]++; end
  cover_p_sata_l4_link_before_fis: cover property(p_sata_l4_link_before_fis);

  // L4-5: SYNC flow control must eventually be released (bounded hold-off)
  property p_sata_l4_sync_release;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      vif.sync |-> ##[1:64] !vif.sync;
  endproperty
  assert_p_sata_l4_sync_release: assert property(p_sata_l4_sync_release) l4_pass[4]++;
    else begin `uvm_warning("SATA_L4", "SYNC held longer than 64 cycles"); l4_fail[4]++; end
  cover_p_sata_l4_sync_release: cover property(p_sata_l4_sync_release);

  function void report_sva();
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0;
    int l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0)/(l1_total+l2_total+l3_total+l4_total);
    `uvm_info("SATA_RPT", "=== SATA Tiered SVA Report ===", UVM_LOW)
    `uvm_info("SATA_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("SATA_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("SATA_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("SATA_RPT", $sformatf("  L4 SATA Specific:     %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("SATA_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%%", total_cov), UVM_LOW)
  endfunction

  final report_sva();

endmodule
`endif
