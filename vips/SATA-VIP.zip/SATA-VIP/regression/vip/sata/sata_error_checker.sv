// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// sata Error Handling Checker (module form, bindable from any tb)
`ifndef SATA_ERROR_CHECKER_SV
`define SATA_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module sata_error_handling_checker (sata_if vif);
  property p_sata_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_valid == 1 |-> !$isunknown(vif.data); endproperty
  assert_p_sata_no_x: assert property(p_sata_no_x) else `uvm_warning("SATA", "No X when valid failed");
  cover_p_sata_no_x: cover property(p_sata_no_x);
  property p_sata_fis_data; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fis_valid == 1 |-> !$isunknown(vif.fis_data); endproperty
  assert_p_sata_fis_data: assert property(p_sata_fis_data) else `uvm_warning("SATA", "FIS data valid failed");
  cover_p_sata_fis_data: cover property(p_sata_fis_data);
  property p_sata_primitive_type; @(posedge vif.clk) disable iff (!vif.rst_n) vif.primitive_type inside {32'h7B4A4ABC,32'h7B5A5ABC,32'h7B8080BC,32'h7B9595BC,32'h7BAAAAbc,32'h7BCCCCBC,32'h7BDDDDbc,32'h7BEEEEbc,32'h7BFBFBbc,32'h7B9999BC}; endproperty
  assert_p_sata_primitive_type: assert property(p_sata_primitive_type) else `uvm_warning("SATA", "Primitive type range failed");
  cover_p_sata_primitive_type: cover property(p_sata_primitive_type);
endmodule
`endif