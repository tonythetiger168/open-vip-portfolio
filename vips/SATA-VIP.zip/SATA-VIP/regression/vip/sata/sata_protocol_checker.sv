// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// sata Protocol Compliance Checker (module form, bindable from any tb)
`ifndef SATA_PROTOCOL_CHECKER_SV
`define SATA_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module sata_protocol_compliance_checker (sata_if vif);
  property p_sata_link_speed; @(posedge vif.clk) disable iff (!vif.rst_n) vif.link_speed inside {4'b0001,4'b0010,4'b0011,4'b0100}; endproperty
  assert_p_sata_link_speed: assert property(p_sata_link_speed) else `uvm_warning("SATA", "Link speed valid failed");
  cover_p_sata_link_speed: cover property(p_sata_link_speed);
  property p_sata_primitive; @(posedge vif.clk) disable iff (!vif.rst_n) vif.prim == 1 |-> vif.primitive_type != 32'h00000000; endproperty
  assert_p_sata_primitive: assert property(p_sata_primitive) else `uvm_warning("SATA", "Primitive valid failed");
  cover_p_sata_primitive: cover property(p_sata_primitive);
  property p_sata_fis_type; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fis_valid == 1 |-> vif.fis_type inside {8'h27,8'h34,8'h39,8'h3F,8'h46,8'h5F,8'hA1}; endproperty
  assert_p_sata_fis_type: assert property(p_sata_fis_type) else `uvm_warning("SATA", "FIS type valid failed");
  cover_p_sata_fis_type: cover property(p_sata_fis_type);
  property p_sata_data_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_valid == 1 |-> vif.link_up == 1; endproperty
  assert_p_sata_data_valid: assert property(p_sata_data_valid) else `uvm_warning("SATA", "Data valid failed");
  cover_p_sata_data_valid: cover property(p_sata_data_valid);
endmodule
`endif