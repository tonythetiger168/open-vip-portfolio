// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// sata Timing Performance Checker (module form, bindable from any tb)
`ifndef SATA_TIMING_CHECKER_SV
`define SATA_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module sata_timing_performance_checker (sata_if vif);
  property p_sata_oob; @(posedge vif.clk) disable iff (!vif.rst_n) vif.link_up == 1 |-> $past(vif.tx_p,1) || $past(vif.tx_n,1); endproperty
  assert_p_sata_oob: assert property(p_sata_oob) else `uvm_warning("SATA", "OOB before link up failed");
  cover_p_sata_oob: cover property(p_sata_oob);
  property p_sata_ready; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync == 1 |-> ##[1:10] vif.ready == 1; endproperty
  assert_p_sata_ready: assert property(p_sata_ready) else `uvm_warning("SATA", "Ready after sync failed");
  cover_p_sata_ready: cover property(p_sata_ready);
endmodule
`endif