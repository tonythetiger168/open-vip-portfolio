// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// sata Data Integrity Checker (module form, bindable from any tb)
`ifndef SATA_DATA_INTEGRITY_CHECKER_SV
`define SATA_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module sata_data_integrity_checker (sata_if vif);
  property p_sata_fis_start; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fis_end == 1 |-> $past(vif.fis_start,1) || vif.fis_start == 1; endproperty
  assert_p_sata_fis_start: assert property(p_sata_fis_start) else `uvm_warning("SATA", "FIS start before end failed");
  cover_p_sata_fis_start: cover property(p_sata_fis_start);
  property p_sata_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync == 1 |-> vif.ready == 1; endproperty
  assert_p_sata_sync: assert property(p_sata_sync) else `uvm_warning("SATA", "Sync when ready failed");
  cover_p_sata_sync: cover property(p_sata_sync);
  property p_sata_link_up; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_valid == 1 |-> vif.link_up == 1; endproperty
  assert_p_sata_link_up: assert property(p_sata_link_up) else `uvm_warning("SATA", "Link up for traffic failed");
  cover_p_sata_link_up: cover property(p_sata_link_up);
endmodule
`endif