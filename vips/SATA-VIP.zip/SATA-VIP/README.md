# SATA — SATA UVM VIP

Open-source UVM verification IP template for **SATA** (Serial ATA storage).

## Protocol overview

The VIP models the SATA device side: OOB link-up handshake (COMRESET/COMINIT/
COMWAKE response bursts), FIS reception with link-layer flow control
(ready/SYNC backpressure), transport-layer FIS framing (Register H2D/D2H,
DMA setup, DATA, PIO setup) and ATA command fields (LBA48, sector count).

## Contents

| Path | Description |
|------|-------------|
| `sata/sata_if.sv` | OOB/link/transport interface with clocking blocks |
| `sata/sata_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / checker / coverage) |
| `regression/sva/sata_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=5, module form) |
| `regression/vip/sata/` | protocol / timing / error / data-integrity checkers |
| `env/env_pkg.sv` | multi-protocol env + **sata_e2e_scoreboard** + **sata_env** |
| `tb/top_tb.sv` | Testbench top with functional SATA host DUT model |
| `regression/` | Makefile + coverage-driven regression scripts |

## Deepened Features (v2.0.0)

- **Device driver**: OOB handshake response, FIS ready/SYNC flow control with
  error-mode throttling, `drv_ap` expected broadcast.
- **Decoding monitor**: reconstructs FIS frames (type/command/LBA/payload)
  from fis_start..fis_end waveforms, publishes via analysis port.
- **End-to-end scoreboard** (`sata_e2e_scoreboard`): expected vs observed
  (fis_type/command/lba) with `n_matches`/`n_mismatches`, UVM_ERROR on
  mismatch.
- **Functional DUT model** (`sata_host_model`): OOB sequence, FIS issue
  engine with flow control, disk sector memory.
- **Directed sequences (9)**: random, reg_h2d, dma, error_inject,
  back_to_back, stress (max sector count, all link speeds), corner (LBA 0 /
  48-bit max), reset (IDENTIFY), regression mix.
- **Functional coverage (4 covergroups)**: sata_fis_cg (fis_type x command,
  fis_type x link_speed crosses), sata_error_cg (error x crc cross),
  sata_fsm_cg (FIS sequencing transitions), sata_data_cg (payload DWORD
  pattern x size cross).
- **SVA L4 (5)**: FIS bounded to 32 DWORDs, fis_start only at frame
  boundary, known ATA opcodes in Register H2D, no FIS before link-up,
  bounded SYNC hold-off.

All modified .sv/.svh files pass a pyslang syntax parse with 0 errors.

## Quick start

```bash
cd regression
make all                       # single run (xrun default)
./coverage_regression.sh       # full regression + coverage gate
```
License: Apache-2.0
