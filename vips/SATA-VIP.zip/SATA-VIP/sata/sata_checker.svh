// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sata_checker.svh
// SATA Protocol Checker

class sata_checker extends protocol_checker_base;
  `uvm_component_utils(sata_checker)

  uvm_analysis_imp #(sata_transaction, sata_checker) analysis_export;
  sata_transaction last_tx;
  bit [31:0] expected_crc;
  int tx_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
  endfunction

  function void write(sata_transaction tx);
    tx_count++;
    check_fis_type(tx);
    check_lba_alignment(tx);
    check_sector_count(tx);
    check_crc(tx);
    check_link_speed(tx);
    if (last_tx != null)
      check_sequence(last_tx, tx);
    last_tx = tx;
  endfunction

  function void check_fis_type(sata_transaction tx);
    case (tx.fis_type)
      sata_transaction::FIS_REG_H2D,
      sata_transaction::FIS_REG_D2H,
      sata_transaction::FIS_DMA_ACT,
      sata_transaction::FIS_DMA_SETUP,
      sata_transaction::FIS_DATA,
      sata_transaction::FIS_BIST_ACT,
      sata_transaction::FIS_PIO_SETUP,
      sata_transaction::FIS_SET_DEV: ; // valid
      default: check_protocol_error($sformatf("Invalid FIS type 0x%0x", tx.fis_type));
    endcase
  endfunction

  function void check_lba_alignment(sata_transaction tx);
    if (tx.lba[2:0] != 3'b000 && tx.sector_count > 1)
      check_protocol_warning($sformatf("LBA 0x%0x not aligned for multi-sector", tx.lba));
  endfunction

  function void check_sector_count(sata_transaction tx);
    if (tx.sector_count == 0 && tx.payload_size > 0)
      check_protocol_error("Non-zero payload with sector_count=0");
  endfunction

  function void check_crc(sata_transaction tx);
    if (tx.with_crc_error)
      check_protocol_error("CRC mismatch detected");
  endfunction

  function void check_link_speed(sata_transaction tx);
    if (tx.link_speed > 3)
      check_protocol_error($sformatf("Invalid link speed %0d", tx.link_speed));
  endfunction

  function void check_sequence(sata_transaction prev, sata_transaction curr);
    // Check for valid FIS sequences
    if (prev.fis_type == sata_transaction::FIS_DMA_SETUP &&
        curr.fis_type != sata_transaction::FIS_DMA_ACT &&
        curr.fis_type != sata_transaction::FIS_DATA)
      check_protocol_warning("Invalid sequence after DMA_SETUP");
  endfunction

  task run_phase(uvm_phase phase);
    // Background checks
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("SATA_CHK", $sformatf("Checked %0d transactions, %0d errors, %0d warnings",
      tx_count, error_count, warning_count), UVM_LOW)
  endfunction
endclass
