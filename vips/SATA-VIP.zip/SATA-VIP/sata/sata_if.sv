// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sata_if.sv
// SATA Physical Layer Interface

interface sata_if (input logic clk, input logic rst_n);
  // OOB signals
  logic tx_p, tx_n;
  logic rx_p, rx_n;
  // Link layer
  logic [31:0] data;
  logic        data_valid;
  logic        prim;
  logic [31:0] primitive_type;
  logic        ready;
  logic        sync;
  // Transport layer
  logic        fis_start;
  logic        fis_end;
  logic [7:0]  fis_type;
  logic [31:0] fis_data;
  logic        fis_valid;
  // Status
  logic        link_up;
  logic [3:0]  link_speed;  // 1=1.5G, 2=3G, 3=6G

  // ---- SVA compliance checker compatibility aliases ----
  logic        crc_ok;      // CRC status (no CRC checker modeled; assumed good)
  assign crc_ok = 1'b1;
  logic [2:0]  pm_state;    // power mode derived from link state
  assign pm_state = link_up ? 3'b000 : 3'b001;
  logic        err_inject;  // error injection (not modeled)
  assign err_inject = 1'b0;

  // Modports
  modport DUT (
    input  clk, rst_n, rx_p, rx_n, ready, sync,
    output tx_p, tx_n, data, data_valid, prim, primitive_type,
    output fis_start, fis_end, fis_type, fis_data, fis_valid, link_up, link_speed
  );

  modport TB (
    input  clk, rst_n, tx_p, tx_n, data, data_valid, prim, primitive_type,
    input  fis_start, fis_end, fis_type, fis_data, fis_valid, link_up, link_speed,
    output rx_p, rx_n, ready, sync
  );

  // Clocking block for monitor
  clocking mon_cb @(posedge clk);
    input data, data_valid, prim, primitive_type;
    input fis_start, fis_end, fis_type, fis_data, fis_valid;
    input link_up, link_speed;
  endclocking

  // Clocking block for driver
  clocking drv_cb @(posedge clk);
    output rx_p, rx_n, ready, sync;
    input  link_up;
  endclocking
endinterface
