// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sata_sequences.svh

class sata_base_sequence extends uvm_sequence #(sata_transaction);
  `uvm_object_utils(sata_base_sequence)
  function new(string name = "sata_base_sequence");
    super.new(name);
  endfunction
endclass

class sata_random_sequence extends sata_base_sequence;
  `uvm_object_utils(sata_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "sata_random_sequence");
    super.new(name);
  endfunction
  task body();
    sata_transaction tx;
    repeat (num_txns) begin
      tx = sata_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "SATA tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class sata_reg_h2d_sequence extends sata_base_sequence;
  `uvm_object_utils(sata_reg_h2d_sequence)
  rand int num_txns = 50;
  rand bit [47:0] base_lba;
  function new(string name = "sata_reg_h2d_sequence");
    super.new(name);
  endfunction
  task body();
    sata_transaction tx;
    repeat (num_txns) begin
      tx = sata_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        fis_type == sata_transaction::FIS_REG_H2D;
        lba >= base_lba;
        lba < base_lba + 48'h10000;
      }) `uvm_error("RANDFAIL", "SATA H2D randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class sata_dma_sequence extends sata_base_sequence;
  `uvm_object_utils(sata_dma_sequence)
  rand int num_txns = 30;
  function new(string name = "sata_dma_sequence");
    super.new(name);
  endfunction
  task body();
    sata_transaction tx;
    repeat (num_txns) begin
      tx = sata_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        fis_type inside {sata_transaction::FIS_DMA_SETUP, sata_transaction::FIS_DMA_ACT};
        payload_size inside {[512:2048]};
      }) `uvm_error("RANDFAIL", "SATA DMA randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class sata_error_inject_sequence extends sata_base_sequence;
  `uvm_object_utils(sata_error_inject_sequence)
  rand int num_txns = 20;
  function new(string name = "sata_error_inject_sequence");
    super.new(name);
  endfunction
  task body();
    sata_transaction tx;
    repeat (num_txns) begin
      tx = sata_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        with_error == 1;
      }) `uvm_error("RANDFAIL", "SATA error inject randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Deepened directed sequences (v2.0.0)
// ---------------------------------------------------------------------------

// Directed: back-to-back FISes (no link idle between frames)
class sata_back_to_back_seq extends sata_base_sequence;
  `uvm_object_utils(sata_back_to_back_seq)
  rand int num_txns = 30;
  function new(string name = "sata_back_to_back_seq"); super.new(name); endfunction
  task body();
    sata_transaction tx;
    repeat (num_txns) begin
      tx = sata_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { fis_type == sata_transaction::FIS_REG_H2D;
                                 sector_count == 1; })
        `uvm_error("RANDFAIL", "SATA b2b randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: stress - max sector count DMA transfers at all link speeds
class sata_stress_seq extends sata_base_sequence;
  `uvm_object_utils(sata_stress_seq)
  rand int num_txns = 40;
  function new(string name = "sata_stress_seq"); super.new(name); endfunction
  task body();
    sata_transaction tx;
    repeat (num_txns) begin
      tx = sata_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { fis_type inside {sata_transaction::FIS_DMA_SETUP,
                                                  sata_transaction::FIS_DATA};
                                 sector_count inside {[128:255]};
                                 link_speed inside {[1:3]}; })
        `uvm_error("RANDFAIL", "SATA stress randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: corner cases - LBA 0 / 48-bit max, sector_count 0/1
class sata_corner_seq extends sata_base_sequence;
  `uvm_object_utils(sata_corner_seq)
  function new(string name = "sata_corner_seq"); super.new(name); endfunction
  task body();
    sata_transaction tx;
    bit [47:0] lbas[3] = '{48'h0, 48'hFFFF_FFFF_FFFF, 48'h1};
    foreach (lbas[i]) begin
      tx = sata_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { fis_type == sata_transaction::FIS_REG_H2D;
                                 lba == lbas[i]; sector_count inside {[0:1]}; })
        `uvm_error("RANDFAIL", "SATA corner randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: single FIS issued immediately after link-up
class sata_reset_seq extends sata_base_sequence;
  `uvm_object_utils(sata_reset_seq)
  function new(string name = "sata_reset_seq"); super.new(name); endfunction
  task body();
    sata_transaction tx = sata_transaction::type_id::create("tx");
    start_item(tx);
    if (!tx.randomize() with { fis_type == sata_transaction::FIS_REG_H2D;
                               command == 8'hEC; })  // IDENTIFY DEVICE
      `uvm_error("RANDFAIL", "SATA reset randomization failed")
    finish_item(tx);
  endtask
endclass

// Regression: weighted mix of all directed sequences
class sata_regression_seq extends sata_base_sequence;
  `uvm_object_utils(sata_regression_seq)
  function new(string name = "sata_regression_seq"); super.new(name); endfunction
  task body();
    sata_random_sequence       rnd = sata_random_sequence::type_id::create("rnd");
    sata_reg_h2d_sequence      rh2d = sata_reg_h2d_sequence::type_id::create("reg");
    sata_dma_sequence          dma = sata_dma_sequence::type_id::create("dma");
    sata_back_to_back_seq      b2b = sata_back_to_back_seq::type_id::create("b2b");
    sata_stress_seq            str = sata_stress_seq::type_id::create("str");
    sata_corner_seq            cor = sata_corner_seq::type_id::create("cor");
    sata_error_inject_sequence err = sata_error_inject_sequence::type_id::create("err");
    rnd.num_txns = 40; rh2d.num_txns = 40; dma.num_txns = 20;
    b2b.num_txns = 20; str.num_txns = 10; err.num_txns = 10;
    rnd.start(m_sequencer); rh2d.start(m_sequencer); dma.start(m_sequencer);
    b2b.start(m_sequencer); str.start(m_sequencer);
    cor.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
