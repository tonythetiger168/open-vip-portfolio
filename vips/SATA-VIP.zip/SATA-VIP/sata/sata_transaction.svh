// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sata_transaction.svh
// SATA Transaction Definition

class sata_transaction extends uvm_sequence_item;
  `uvm_object_utils(sata_transaction)

  // FIS types
  typedef enum bit [7:0] {
    FIS_REG_H2D   = 8'h27,
    FIS_REG_D2H   = 8'h34,
    FIS_DMA_ACT   = 8'h39,
    FIS_DMA_SETUP = 8'h41,
    FIS_DATA      = 8'h46,
    FIS_BIST_ACT  = 8'h58,
    FIS_PIO_SETUP = 8'h5F,
    FIS_SET_DEV   = 8'hA1
  } fis_type_e;

  rand fis_type_e    fis_type;
  rand bit [31:0]    data_payload[];
  rand bit [47:0]    lba;
  rand bit [15:0]    sector_count;
  rand bit [7:0]     command;
  rand bit [3:0]     port_multiplier;
  rand bit           is_write;
  rand bit [2:0]     link_speed;  // 1=1.5G, 2=3G, 3=6G
  rand int           payload_size;
  rand bit           with_error;
  rand bit           with_crc_error;

  constraint c_payload_size {
    payload_size inside {[0:2048]};
    data_payload.size() == payload_size;
  }
  constraint c_link_speed {
    link_speed inside {1, 2, 3};
  }
  constraint c_error_dist {
    with_error dist {0:=95, 1:=5};
    with_crc_error dist {0:=98, 1:=2};
  }
  constraint c_fis_cmd {
    if (fis_type == FIS_REG_H2D || fis_type == FIS_REG_D2H)
      command inside {8'h20, 8'h30, 8'hEC, 8'h90, 8'h00, 8'h70, 8'h90};
  }

  function new(string name = "sata_transaction");
    super.new(name);
  endfunction

  function void do_copy(uvm_object rhs);
    sata_transaction rhs_;
    if (!$cast(rhs_, rhs)) return;
    super.do_copy(rhs);
    fis_type      = rhs_.fis_type;
    data_payload  = rhs_.data_payload;
    lba           = rhs_.lba;
    sector_count  = rhs_.sector_count;
    command       = rhs_.command;
    port_multiplier = rhs_.port_multiplier;
    is_write      = rhs_.is_write;
    link_speed    = rhs_.link_speed;
    payload_size  = rhs_.payload_size;
    with_error    = rhs_.with_error;
    with_crc_error = rhs_.with_crc_error;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sata_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           (fis_type == rhs_.fis_type) &&
           (lba == rhs_.lba) &&
           (sector_count == rhs_.sector_count) &&
           (command == rhs_.command);
  endfunction

  function string convert2string();
    return $sformatf("SATA: fis=%s lba=0x%0x sec=%0d cmd=0x%0x speed=Gen%0d payload=%0d err=%b crc_err=%b",
      fis_type.name(), lba, sector_count, command, link_speed, payload_size, with_error, with_crc_error);
  endfunction
endclass
