// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sata_coverage.svh
// SATA Coverage Collector

class sata_coverage extends coverage_collector_base;
  `uvm_component_utils(sata_coverage)

  uvm_analysis_imp #(sata_transaction, sata_coverage) analysis_export;

  // sampled transaction (declared before the covergroups that reference it)
  sata_transaction tx;

  // Covergroups
  covergroup sata_fis_cg;
    option.per_instance = 1;
    fis_type_cp: coverpoint tx.fis_type {
      bins reg_h2d   = {sata_transaction::FIS_REG_H2D};
      bins reg_d2h   = {sata_transaction::FIS_REG_D2H};
      bins dma_act   = {sata_transaction::FIS_DMA_ACT};
      bins dma_setup = {sata_transaction::FIS_DMA_SETUP};
      bins data_fis  = {sata_transaction::FIS_DATA};
      bins bist      = {sata_transaction::FIS_BIST_ACT};
      bins pio_setup = {sata_transaction::FIS_PIO_SETUP};
      bins set_dev   = {sata_transaction::FIS_SET_DEV};
    }
    command_cp: coverpoint tx.command {
      bins read_sec  = {8'h20};
      bins write_sec = {8'h30};
      bins identify  = {8'hEC};
      bins flush     = {8'hE7};
      bins others    = default;
    }
    link_speed_cp: coverpoint tx.link_speed {
      bins gen1 = {1};
      bins gen2 = {2};
      bins gen3 = {3};
    }
    payload_size_cp: coverpoint tx.payload_size {
      bins empty    = {0};
      bins lo    = {[1:128]};
      bins mid   = {[129:512]};
      bins hi    = {[513:1024]};
      bins max      = {[1025:2048]};
    }
    cross fis_type_cp, command_cp;
    cross fis_type_cp, link_speed_cp;
  endgroup

  covergroup sata_error_cg;
    option.per_instance = 1;
    error_cp: coverpoint tx.with_error;
    crc_error_cp: coverpoint tx.with_crc_error;
    cross error_cp, crc_error_cp;
  endgroup


  // FSM transition coverage: FIS frame sequencing
  covergroup sata_fsm_cg;
    option.per_instance = 1;
    fis_trans_cp: coverpoint tx.fis_type {
      bins h2d_then_d2h = (sata_transaction::FIS_REG_H2D => sata_transaction::FIS_REG_D2H);
      bins setup_data   = (sata_transaction::FIS_DMA_SETUP => sata_transaction::FIS_DATA);
      bins data_data    = (sata_transaction::FIS_DATA => sata_transaction::FIS_DATA);
    }
    speed_cp: coverpoint tx.link_speed {
      bins gen1 = {1}; bins gen2 = {2}; bins gen3 = {3};
    }
  endgroup

  // Data pattern coverage: payload DWORD corners x payload size
  covergroup sata_data_cg;
    option.per_instance = 1;
    dw0_cp: coverpoint (tx.data_payload.size() > 0 ? tx.data_payload[0] : 32'h0) {
      bins zero = {32'h0};
      bins ones = {32'hFFFF_FFFF};
      bins walk = default;
    }
    psize_cp: coverpoint tx.payload_size {
      bins lo = {[0:512]};
      bins mid = {[513:4096]};
      bins hi = default;
    }
    cross dw0_cp, psize_cp;
  endgroup

  int sample_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    sata_fis_cg = new();
    sata_error_cg = new();
    sata_fsm_cg = new();
    sata_data_cg = new();
  endfunction

  function void write(sata_transaction tx_);
    tx = tx_;
    sample_coverage(tx);
  endfunction

  virtual function void sample_coverage(uvm_sequence_item tx_);
    sata_transaction stx;
    if (!$cast(stx, tx_)) return;
    tx = stx;
    sata_fis_cg.sample();
    sata_error_cg.sample();
    sata_fsm_cg.sample();
    sata_data_cg.sample();
    sample_count++;
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("SATA_COV", $sformatf("Sampled %0d transactions", sample_count), UVM_LOW)
    `uvm_info("SATA_COV", $sformatf("FIS coverage = %0.2f%%", sata_fis_cg.get_coverage()), UVM_LOW)
    `uvm_info("SATA_COV", $sformatf("Error coverage = %0.2f%%", sata_error_cg.get_coverage()), UVM_LOW)
  endfunction
endclass
