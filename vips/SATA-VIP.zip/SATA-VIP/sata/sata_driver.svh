// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sata_driver.svh -- SATA device-side driver: OOB link-up handshake, FIS
// flow control (ready/sync backpressure), expected-transaction broadcast.

`ifndef SATA_DRIVER_SVH
`define SATA_DRIVER_SVH

class sata_driver extends uvm_driver #(sata_transaction);
  `uvm_component_utils(sata_driver)
  virtual sata_if vif;
  sata_config cfg;
  uvm_analysis_port #(sata_transaction) drv_ap;  // expected items for scoreboard
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sata_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "SATA virtual interface not found")
    if (!uvm_config_db#(sata_config)::get(this, "", "cfg", cfg))
      cfg = sata_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    vif.drv_cb.ready <= 0;
    vif.drv_cb.sync  <= 0;
    vif.drv_cb.rx_p  <= 0;
    vif.drv_cb.rx_n  <= 0;
    // OOB handshake: answer COMRESET/COMINIT, then COMWAKE -> link up
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    vif.drv_cb.rx_p <= 1;  // COMINIT/COMWAKE response burst
    repeat (2) @(vif.drv_cb);
    vif.drv_cb.rx_p <= 0;
    wait (vif.drv_cb.link_up === 1'b1);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      drv_ap.write(req);  // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask

  // One item = one FIS accepted from the host. with_error: the device holds
  // the host off with SYNC (ready high) for three clocks before accepting.
  // DWORDs of a FIS go back to back, so ready drops only after fis_end.
  task drive_item(sata_transaction tx);
    `uvm_info("SATA_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)
    @(vif.drv_cb);
    vif.drv_cb.ready <= 1;
    if (tx.with_error) begin
      vif.drv_cb.sync <= 1;   // SYNC primitive: hold off the host
      repeat (3) @(vif.drv_cb);
      vif.drv_cb.sync <= 0;
    end
    do @(vif.drv_cb);
    while (!(vif.drv_cb.fis_valid === 1'b1 && vif.drv_cb.fis_end === 1'b1));
    vif.drv_cb.ready <= 0;    // the last DWORD is taken on this edge
    txn_count++;
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("SATA_DRV", $sformatf("sata driver serviced %0d FIS transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
