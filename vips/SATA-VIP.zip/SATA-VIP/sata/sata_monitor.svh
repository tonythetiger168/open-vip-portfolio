// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sata_monitor.svh -- SATA monitor: decodes FIS frames (fis_start..fis_end)
// and data payloads from the interface, publishes transactions.

`ifndef SATA_MONITOR_SVH
`define SATA_MONITOR_SVH

class sata_monitor extends uvm_monitor;
  `uvm_component_utils(sata_monitor)
  virtual sata_if vif;
  uvm_analysis_port #(sata_transaction) ap;
  sata_config cfg;
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sata_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "SATA virtual interface not found")
    if (!uvm_config_db#(sata_config)::get(this, "", "cfg", cfg))
      cfg = sata_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    sata_transaction tx;
    int dw_idx;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.fis_valid && vif.mon_cb.fis_start) begin
        tx = sata_transaction::type_id::create("tx");
        dw_idx = 0;
        tx.fis_type    = sata_transaction::fis_type_e'(vif.mon_cb.fis_type);
        tx.link_speed  = vif.mon_cb.link_speed;
        // first FIS DWORD carries command/features for Register FISes
        if (vif.mon_cb.fis_type == 8'h27 || vif.mon_cb.fis_type == 8'h34) begin
          tx.command      = vif.mon_cb.fis_data[15:8];
          tx.lba          = {16'h0, vif.mon_cb.fis_data};
          tx.sector_count = 16'd1;
          tx.is_write     = (vif.mon_cb.fis_data[15:8] inside {8'h30, 8'h35, 8'h3D});
        end
        // consume payload DWORDs until fis_end
        while (vif.mon_cb.fis_end !== 1'b1) begin
          @(vif.mon_cb);
          if (vif.mon_cb.fis_valid) begin
            tx.data_payload = new[tx.data_payload.size() + 1](tx.data_payload);
            tx.data_payload[dw_idx] = vif.mon_cb.fis_data;
            dw_idx++;
          end
        end
        tx.payload_size = dw_idx * 4;
        txn_count++;
        `uvm_info("SATA_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_HIGH)
        ap.write(tx);
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("SATA_MON", $sformatf("sata monitor observed %0d FIS transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
