// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sata_monitor.svh -- SATA monitor: decodes FIS frames (fis_start..fis_end)
// and data payloads from the interface, publishes transactions.

`ifndef SATA_MONITOR_SVH
`define SATA_MONITOR_SVH

class sata_monitor extends uvm_monitor;
  `uvm_component_utils(sata_monitor)
  virtual sata_if vif;
  uvm_analysis_port #(sata_transaction) ap;
  sata_config cfg;
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sata_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "SATA virtual interface not found")
    if (!uvm_config_db#(sata_config)::get(this, "", "cfg", cfg))
      cfg = sata_config::type_id::create("cfg");
  endfunction

  // A DWORD is taken on a clock edge with fis_valid && ready && !sync. A FIS
  // runs from the DWORD with fis_start to the one with fis_end; with_error
  // records that the device sent SYNC since the previous FIS ended.
  task run_phase(uvm_phase phase);
    sata_transaction tx;
    bit sync_seen = 0;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.sync === 1'b1) sync_seen = 1;
      if (vif.mon_cb.fis_valid === 1'b1 && vif.mon_cb.ready === 1'b1 && vif.mon_cb.sync !== 1'b1) begin
        if (vif.mon_cb.fis_start === 1'b1) begin
          tx = sata_transaction::type_id::create("tx");
          tx.fis_type   = sata_transaction::fis_type_e'(vif.mon_cb.fis_type);
          tx.link_speed = vif.mon_cb.link_speed;
          tx.with_error = sync_seen;
          // Register FIS DWORD 0: {features, command, C bit / PM port, FIS type}
          if (vif.mon_cb.fis_type == 8'h27 || vif.mon_cb.fis_type == 8'h34) begin
            tx.command      = vif.mon_cb.fis_data[23:16];
            tx.sector_count = 16'd1;
            tx.is_write     = (vif.mon_cb.fis_data[23:16] inside {8'h30, 8'h35, 8'h3D, 8'hCA, 8'h61});
          end
        end else if (tx != null) begin
          tx.data_payload = new[tx.data_payload.size() + 1](tx.data_payload);
          tx.data_payload[tx.data_payload.size() - 1] = vif.mon_cb.fis_data;
          // Register FIS DWORD 1: device | LBA[23:0]
          if (tx.data_payload.size() == 1 && (tx.fis_type == 8'h27 || tx.fis_type == 8'h34))
            tx.lba = {24'h0, vif.mon_cb.fis_data[23:0]};
        end
        if (vif.mon_cb.fis_end === 1'b1 && tx != null) begin
          tx.payload_size = tx.data_payload.size() * 4;
          txn_count++;
          sync_seen = 0;
          `uvm_info("SATA_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_HIGH)
          ap.write(tx);
          tx = null;
        end
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("SATA_MON", $sformatf("sata monitor observed %0d FIS transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
