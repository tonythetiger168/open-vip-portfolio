// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// env_pkg.sv -- 5-Protocol Verification Environment

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sata_pkg::*;
  import nvme_pkg::*;
  import jtag_pkg::*;
  import bluetooth5_pkg::*;
  import displayport2_pkg::*;

  `uvm_analysis_imp_decl(_sata)
  `uvm_analysis_imp_decl(_nvme)
  `uvm_analysis_imp_decl(_jtag)
  `uvm_analysis_imp_decl(_bt5)
  `uvm_analysis_imp_decl(_dp2)

  class multi_protocol_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(multi_protocol_scoreboard)
    uvm_analysis_imp_sata #(sata_transaction, multi_protocol_scoreboard) sata_ap;
    uvm_analysis_imp_nvme #(nvme_transaction, multi_protocol_scoreboard) nvme_ap;
    uvm_analysis_imp_jtag #(jtag_transaction, multi_protocol_scoreboard) jtag_ap;
    uvm_analysis_imp_bt5  #(bluetooth5_transaction, multi_protocol_scoreboard) bt5_ap;
    uvm_analysis_imp_dp2  #(displayport2_transaction, multi_protocol_scoreboard) dp2_ap;
    int sata_count=0, nvme_count=0, jtag_count=0, bt5_count=0, dp2_count=0;
    int total_count=0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      sata_ap = new("sata_ap", this); nvme_ap = new("nvme_ap", this);
      jtag_ap = new("jtag_ap", this); bt5_ap  = new("bt5_ap", this);
      dp2_ap  = new("dp2_ap", this);
    endfunction
    function void write_sata(sata_transaction tx);       sata_count++; total_count++; endfunction
    function void write_nvme(nvme_transaction tx);       nvme_count++; total_count++; endfunction
    function void write_jtag(jtag_transaction tx);       jtag_count++; total_count++; endfunction
    function void write_bt5(bluetooth5_transaction tx);  bt5_count++;  total_count++; endfunction
    function void write_dp2(displayport2_transaction tx); dp2_count++; total_count++; endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("SCOREBOARD", "=== 5-PROTOCOL SCOREBOARD ===", UVM_LOW)
      `uvm_info("SCOREBOARD", $sformatf("SATA:%0d NVMe:%0d JTAG:%0d BT5:%0d DP2:%0d TOT:%0d",
        sata_count, nvme_count, jtag_count, bt5_count, dp2_count, total_count), UVM_LOW)
    endfunction
  endclass

  class multi_protocol_env extends uvm_env;
    `uvm_component_utils(multi_protocol_env)
    sata_agent sata_agt; nvme_agent nvme_agt; jtag_agent jtag_agt;
    bluetooth5_agent bt5_agt; displayport2_agent dp2_agt;
    multi_protocol_scoreboard sb;
    vip_config env_cfg;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(vip_config)::get(this, "", "cfg", env_cfg))
        env_cfg = vip_config::type_id::create("env_cfg");
      sata_agt = sata_agent::type_id::create("sata_agt", this);
      nvme_agt = nvme_agent::type_id::create("nvme_agt", this);
      jtag_agt = jtag_agent::type_id::create("jtag_agt", this);
      bt5_agt  = bluetooth5_agent::type_id::create("bt5_agt", this);
      dp2_agt  = displayport2_agent::type_id::create("dp2_agt", this);
      begin
        sata_config c_ = sata_config::type_id::create("c");
        uvm_config_db#(sata_config)::set(this, "sata_agt", "cfg", c_);
      end
      begin
        nvme_config c_ = nvme_config::type_id::create("c");
        uvm_config_db#(nvme_config)::set(this, "nvme_agt", "cfg", c_);
      end
      begin
        jtag_config c_ = jtag_config::type_id::create("c");
        uvm_config_db#(jtag_config)::set(this, "jtag_agt", "cfg", c_);
      end
      begin
        bluetooth5_config c_ = bluetooth5_config::type_id::create("c");
        uvm_config_db#(bluetooth5_config)::set(this, "bt5_agt", "cfg", c_);
      end
      begin
        displayport2_config c_ = displayport2_config::type_id::create("c");
        uvm_config_db#(displayport2_config)::set(this, "dp2_agt", "cfg", c_);
      end
      if (env_cfg.enable_scoreboard) sb = multi_protocol_scoreboard::type_id::create("sb", this);
    endfunction
    function uvm_object create_cfg(uvm_object cfg_); return cfg_; endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (env_cfg.enable_scoreboard) begin
        sata_agt.ap.connect(sb.sata_ap); nvme_agt.ap.connect(sb.nvme_ap);
        jtag_agt.ap.connect(sb.jtag_ap); bt5_agt.ap.connect(sb.bt5_ap);
        dp2_agt.ap.connect(sb.dp2_ap);
      end
    endfunction
  endclass

  `uvm_analysis_imp_decl(_sata_exp)
  `uvm_analysis_imp_decl(_sata_obs)

  // End-to-end SATA scoreboard: expected (driver) vs observed (monitor)
  class sata_e2e_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(sata_e2e_scoreboard)
    uvm_analysis_imp_sata_exp #(sata_transaction, sata_e2e_scoreboard) exp_ap;
    uvm_analysis_imp_sata_obs #(sata_transaction, sata_e2e_scoreboard) obs_ap;
    sata_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction
    function void write_sata_exp(sata_transaction t); exp_q.push_back(t); check_txns(); endfunction
    function void write_sata_obs(sata_transaction t); obs_q.push_back(t); check_txns(); endfunction
    function void check_txns();
      while (exp_q.size() && obs_q.size()) begin
        sata_transaction e = exp_q.pop_front();
        sata_transaction o = obs_q.pop_front();
        if (e.fis_type == o.fis_type && e.command == o.command && e.lba == o.lba)
          n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SATA_SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("SATA_SB", $sformatf("sata e2e scoreboard: n_matches=%0d n_mismatches=%0d",
                n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SATA_SB", "end-to-end mismatches detected")
    endfunction
  endclass

  // Standalone SATA environment (agent + e2e scoreboard closed loop)
  class sata_env extends uvm_env;
    `uvm_component_utils(sata_env)
    sata_agent          agt;
    sata_e2e_scoreboard sb;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = sata_agent::type_id::create("agt", this);
      sb  = sata_e2e_scoreboard::type_id::create("sb", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      if (agt.drv != null) agt.drv.drv_ap.connect(sb.exp_ap);
    endfunction
  endclass
endpackage
