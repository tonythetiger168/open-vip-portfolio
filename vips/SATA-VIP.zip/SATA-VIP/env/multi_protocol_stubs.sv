// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// multi_protocol_stubs.sv
// Minimal stub packages for external protocols referenced by the shared
// multi-protocol env_pkg but whose VIP is not part of this tree.
// Each stub provides the transaction/config/agent API surface that
// env_pkg uses (analysis-port based agent, factory-creatable config).

`ifndef MULTI_PROTOCOL_STUBS_SV
`define MULTI_PROTOCOL_STUBS_SV

`include "uvm_macros.svh"

package nvme_pkg;
  import uvm_pkg::*;
  class nvme_transaction extends uvm_sequence_item;
    `uvm_object_utils(nvme_transaction)
    function new(string name = "nvme_transaction"); super.new(name); endfunction
  endclass
  class nvme_config extends uvm_object;
    `uvm_object_utils(nvme_config)
    function new(string name = "nvme_config"); super.new(name); endfunction
  endclass
  class nvme_agent extends uvm_agent;
    `uvm_component_utils(nvme_agent)
    uvm_analysis_port #(nvme_transaction) ap;
    function new(string name = "nvme_agent", uvm_component parent = null);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
  endclass
endpackage

package jtag_pkg;
  import uvm_pkg::*;
  class jtag_transaction extends uvm_sequence_item;
    `uvm_object_utils(jtag_transaction)
    function new(string name = "jtag_transaction"); super.new(name); endfunction
  endclass
  class jtag_config extends uvm_object;
    `uvm_object_utils(jtag_config)
    function new(string name = "jtag_config"); super.new(name); endfunction
  endclass
  class jtag_agent extends uvm_agent;
    `uvm_component_utils(jtag_agent)
    uvm_analysis_port #(jtag_transaction) ap;
    function new(string name = "jtag_agent", uvm_component parent = null);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
  endclass
endpackage

package bluetooth5_pkg;
  import uvm_pkg::*;
  class bluetooth5_transaction extends uvm_sequence_item;
    `uvm_object_utils(bluetooth5_transaction)
    function new(string name = "bluetooth5_transaction"); super.new(name); endfunction
  endclass
  class bluetooth5_config extends uvm_object;
    `uvm_object_utils(bluetooth5_config)
    function new(string name = "bluetooth5_config"); super.new(name); endfunction
  endclass
  class bluetooth5_agent extends uvm_agent;
    `uvm_component_utils(bluetooth5_agent)
    uvm_analysis_port #(bluetooth5_transaction) ap;
    function new(string name = "bluetooth5_agent", uvm_component parent = null);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
  endclass
endpackage

package displayport2_pkg;
  import uvm_pkg::*;
  class displayport2_transaction extends uvm_sequence_item;
    `uvm_object_utils(displayport2_transaction)
    function new(string name = "displayport2_transaction"); super.new(name); endfunction
  endclass
  class displayport2_config extends uvm_object;
    `uvm_object_utils(displayport2_config)
    function new(string name = "displayport2_config"); super.new(name); endfunction
  endclass
  class displayport2_agent extends uvm_agent;
    `uvm_component_utils(displayport2_agent)
    uvm_analysis_port #(displayport2_transaction) ap;
    function new(string name = "displayport2_agent", uvm_component parent = null);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
  endclass
endpackage

`endif
