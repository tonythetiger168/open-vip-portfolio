// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_sata_tb.sv -- self-checking functional test for the SATA host model
// (sata_host_model in tb/top_tb.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py SATA-VIP
//
// Model contract (from tb/top_tb.sv):
//   * OOB: after reset release the host drives tx_p for 3 clocks (COMRESET),
//     waits for the device's rx_p, and raises link_up 4 clocks later;
//     link_speed reports Gen3 (3).
//   * once the link is up the host sends Register H2D FISes (fis_type 0x27)
//     cycling the commands IDENTIFY 0xEC, READ DMA EXT 0x25, WRITE SECTORS
//     0x30, WRITE DMA 0xCA. Each FIS is three dwords D, D+1, D+2 with
//     D = {8'h00, command, 8'h00, 8'hA0}; fis_start marks the first dword,
//     fis_end the last. A dword advances only when ready is high and sync
//     is low; one idle clock separates FISes.
// Known deviations (XFAIL): FIS dword 0 should carry the FIS type 0x27 in
// bits [7:0] and the C bit (bit 15) set for a command; a reset after the
// link is up should drop link_up and repeat OOB.

module func_sata_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic clk = 1'b0, rst_n = 1'b0, rx_p = 1'b0, ready = 1'b0, sync = 1'b0;
  wire  tx_p, tx_n, data_valid, prim, fis_start, fis_end, fis_valid, link_up;
  wire  [31:0] data, prim_type, fis_data;
  wire  [7:0]  fis_type;
  wire  [3:0]  link_speed;

  always #5 clk = ~clk;

  sata_host_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_tx_p(tx_p), .vif_tx_n(tx_n), .vif_rx_p(rx_p),
    .vif_data(data), .vif_data_valid(data_valid), .vif_prim(prim),
    .vif_primitive_type(prim_type), .vif_ready(ready), .vif_sync(sync),
    .vif_fis_start(fis_start), .vif_fis_end(fis_end), .vif_fis_type(fis_type),
    .vif_fis_data(fis_data), .vif_fis_valid(fis_valid), .vif_link_up(link_up),
    .vif_link_speed(link_speed)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // FIS receiver: a dword is taken at a rising edge with valid && ready && !sync
  // completed FISes: type, first dword index into dws[], dword count
  logic [7:0]  ftyp[$];
  int          fbase[$], flen[$];
  logic [31:0] dws[$];
  bit          in_fis, proto_err;
  int          base, len;
  always @(posedge clk) if (rst_n && fis_valid && ready && !sync) begin
    if (fis_start) begin
      if (in_fis) proto_err = 1;              // start without finishing the last
      in_fis = 1; base = dws.size(); len = 0;
      ftyp.push_back(fis_type);
    end else if (!in_fis) proto_err = 1;      // data with no start
    dws.push_back(fis_data);
    len++;
    if (fis_end) begin
      fbase.push_back(base); flen.push_back(len);
      in_fis = 0;
    end
  end

  function automatic bit fis_is(input int i, input logic [31:0] d0);
    return flen[i] == 3 && dws[fbase[i]] == d0 && dws[fbase[i] + 1] == d0 + 1 &&
           dws[fbase[i] + 2] == d0 + 2;
  endfunction

  task automatic clear_log();
    ftyp.delete(); fbase.delete(); flen.delete(); dws.delete();
  endtask

  int tx_len, t_up;
  logic [7:0] cmds[4];
  initial cmds = '{8'hEC, 8'h25, 8'h30, 8'hCA};

  initial begin
    repeat (3) @(negedge clk);
    chk(!tx_p && !link_up && !fis_valid, "quiet in reset");
    chk(link_speed == 4'd3, "link speed Gen3");
    rst_n = 1;

    // COMRESET burst: raised at reset release, dropped on the third rising
    // clock edge (release is at a falling edge: 2.5 clock periods)
    begin
      time t0;
      #1 t0 = $time;
      chk(tx_p === 1'b1, "COMRESET starts at reset release");
      @(negedge tx_p);
      tx_len = $time - t0 + 1;
      chk(tx_len == 25, $sformatf("COMRESET held until the third clock edge (%0d time units)", tx_len));
      repeat (10) @(negedge clk);
      chk(tx_p === 1'b0, "single COMRESET burst");
    end
    ready = 1;
    repeat (20) @(negedge clk);
    chk(!link_up && !fis_valid, "no link and no FIS before the device answers OOB");

    // device COMINIT
    rx_p = 1;
    t_up = 0;
    while (!link_up && t_up < 20) begin @(negedge clk); t_up++; end
    chk(t_up >= 4 && t_up <= 5, $sformatf("link_up 4 clocks after the device signal (got %0d)", t_up));
    rx_p = 0;

    // four FISes with ready always high
    wait (flen.size() == 5);
    @(negedge clk);
    chk(!proto_err, "every FIS starts with fis_start and ends with fis_end");
    for (int i = 0; i < 5; i++) begin
      chk(ftyp[i] == 8'h27, $sformatf("FIS %0d is Register H2D (0x27)", i));
      chk(fis_is(i, {8'h00, cmds[i % 4], 8'h00, 8'hA0}),
          $sformatf("FIS %0d: command %h in three consecutive dwords", i, cmds[i % 4]));
    end
    chk(u_dut.fis_count >= 5, "fis_count counts completed FISes");
    chk_xfail(dws[0][7:0] == 8'h27 && dws[0][15] == 1'b1,
              "dword 0 carries FIS type 0x27 and the C bit");

    // backpressure: ready low freezes the FIS
    @(negedge clk); ready = 0;
    begin
      logic [31:0] d; logic v, s, e;
      @(negedge clk); d = fis_data; v = fis_valid; s = fis_start; e = fis_end;
      repeat (6) @(negedge clk);
      chk(fis_data == d && fis_valid == v && fis_start == s && fis_end == e, "ready low holds the FIS dword");
    end
    ready = 1;
    wait (!in_fis);
    clear_log();
    wait (flen.size() == 2);
    @(negedge clk);
    chk(!proto_err && flen[0] == 3 && flen[1] == 3, "transfer resumes intact after backpressure");

    // SYNC primitive also holds the transfer
    @(negedge clk); sync = 1;
    begin
      logic [31:0] d;
      @(negedge clk); d = fis_data;
      repeat (5) @(negedge clk);
      chk(fis_data == d, "SYNC holds the FIS dword");
    end
    sync = 0;

    // reset
    @(negedge clk); rst_n = 0;
    @(negedge clk);
    @(negedge clk);
    chk(!fis_valid && !fis_start && !fis_end && u_dut.fis_count == 0, "reset clears the FIS engine");
    chk_xfail(!link_up, "reset drops link_up and restarts OOB");
    rst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
