// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- SATA testbench top with a functional SATA host DUT model

`ifndef SATA_TB_SV
`define SATA_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sata_pkg::*;

module top_tb;
  logic clk = 0;
  logic rst_n;

  always #5ns clk = ~clk;

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  sata_if vif(clk, rst_n);

  // Functional SATA host controller model (closed loop driver->DUT->monitor)
  sata_host_model dut (.vif(vif));

  // Module-form SVA/compliance checkers bound to the SATA interface
  sata_compliance_checker          sata_sva_chk    (.vif(vif));
  sata_data_integrity_checker      sata_data_chk   (.vif(vif));
  sata_protocol_compliance_checker sata_proto_chk  (.vif(vif));
  sata_error_handling_checker      sata_err_chk    (.vif(vif));
  sata_timing_performance_checker  sata_timing_chk (.vif(vif));

  initial begin
    uvm_config_db#(virtual sata_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

//============================================================================
// Functional SATA host controller: runs the OOB sequence, issues Register/
// DMA-setup/DATA FISes with flow control, and tracks a disk sector memory.
//============================================================================
module sata_host_model (sata_if vif);

  bit [31:0] disk_mem [bit [47:0]];   // sector memory (LBA -> DWORD)
  int unsigned fis_count = 0;
  bit [7:0]  cmds[4] = '{8'hEC, 8'h25, 8'h30, 8'hCA}; // IDENTIFY/READ DMA/WRITE DMA/RWQ

  initial begin
    vif.tx_p = 0; vif.tx_n = 0;
    vif.data = '0; vif.data_valid = 0;
    vif.prim = 0; vif.primitive_type = 32'h0;
    vif.fis_start = 0; vif.fis_end = 0;
    vif.fis_type = 8'h0; vif.fis_data = '0; vif.fis_valid = 0;
    vif.link_up = 0; vif.link_speed = 3'd3;
  end

  // OOB: COMRESET -> wait COMINIT/COMWAKE -> link up
  initial begin
    wait (vif.rst_n === 1'b1);
    vif.tx_p = 1;            // COMRESET burst
    repeat (3) @(posedge vif.clk);
    vif.tx_p = 0;
    wait (vif.rx_p === 1'b1);// device COMINIT/COMWAKE response
    repeat (4) @(posedge vif.clk);
    vif.link_up = 1;
  end

  // FIS issue engine
  always @(posedge vif.clk) begin
    if (!vif.rst_n) begin
      vif.fis_valid <= 0; vif.fis_start <= 0; vif.fis_end <= 0;
      fis_count <= 0;
    end else if (vif.link_up) begin
      if (!vif.fis_valid && vif.ready) begin
        // start a new Register H2D FIS
        vif.fis_valid <= 1;
        vif.fis_start <= 1;
        vif.fis_end   <= 0;
        vif.fis_type  <= 8'h27;
        vif.fis_data  <= {8'h0, cmds[fis_count % 4], 8'h0, 8'hA0};
        disk_mem[48'h100 + fis_count] = vif.fis_data;
      end else if (vif.fis_valid && vif.ready && !vif.sync) begin
        // payload beat accepted; end frame after 4 DWORDs
        vif.fis_start <= 0;
        vif.fis_data  <= vif.fis_data + 32'h1;
        if (vif.fis_start == 0) begin
          vif.fis_end <= 1;
        end
        if (vif.fis_end) begin
          vif.fis_valid <= 0;
          vif.fis_end   <= 0;
          fis_count <= fis_count + 1;
        end
      end else if (vif.sync) begin
        vif.fis_start <= 0;   // held by device SYNC
      end
    end
  end

  final $display("SATA_HOST_MODEL: fis_frames=%0d disk_entries=%0d",
                 fis_count, disk_mem.num());
endmodule
`endif
