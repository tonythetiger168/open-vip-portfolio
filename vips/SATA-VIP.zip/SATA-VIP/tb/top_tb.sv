// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- SATA testbench top with a functional SATA host DUT model

`ifndef SATA_TB_SV
`define SATA_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sata_pkg::*;
import sata_test_pkg::*;

module top_tb;
  logic clk = 0;
  logic rst_n;

  always #5ns clk = ~clk;

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  sata_if vif(clk, rst_n);

  // Functional SATA host controller model (closed loop driver->DUT->monitor)
  sata_host_model dut (.vif(vif));

  // Module-form SVA/compliance checkers bound to the SATA interface
  sata_compliance_checker          sata_sva_chk    (.vif(vif));
  sata_data_integrity_checker      sata_data_chk   (.vif(vif));
  sata_protocol_compliance_checker sata_proto_chk  (.vif(vif));
  sata_error_handling_checker      sata_err_chk    (.vif(vif));
  sata_timing_performance_checker  sata_timing_chk (.vif(vif));

  initial begin
    uvm_config_db#(virtual sata_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

//============================================================================
// Functional SATA host controller: runs the OOB sequence (COMRESET, device
// COMINIT, COMWAKE) and then sends Register H2D FISes with flow control.
// A FIS is two back-to-back DWORDs: DWORD 0 {features, command, C bit, 0x27}
// with fis_start, DWORD 1 {device = LBA mode, LBA[23:0]} with fis_end. A new
// FIS starts only while the device is ready and not sending SYNC; a DWORD
// moves on only on ready && !sync. FIS n carries command cmds[n % 13] and
// LBA 8*n (the reference model in tests/sata_tests.sv uses the same rule).
//============================================================================
module sata_host_model (sata_if vif);

  bit [31:0] disk_mem [bit [47:0]];   // LBA -> command DWORD of the FIS
  int unsigned fis_count = 0;
  // ATA opcodes: IDENTIFY, READ DMA EXT, WRITE DMA EXT, WRITE SECTORS,
  // WRITE DMA, EXECUTE DEVICE DIAGNOSTIC, INITIALIZE DEVICE PARAMETERS,
  // READ SECTORS, READ VERIFY, READ FPDMA QUEUED, SEEK, FLUSH CACHE, SET FEATURES
  bit [7:0]  cmds[13] = '{8'hEC, 8'h25, 8'h35, 8'h30, 8'hCA, 8'hEA, 8'h91,
                          8'h20, 8'h40, 8'h60, 8'h70, 8'hE7, 8'hEF};

  initial begin
    vif.tx_p = 0; vif.tx_n = 0;
    vif.data = '0; vif.data_valid = 0;
    vif.prim = 0; vif.primitive_type = 32'h0;
    vif.fis_start = 0; vif.fis_end = 0;
    vif.fis_type = 8'h0; vif.fis_data = '0; vif.fis_valid = 0;
    vif.link_up = 0; vif.link_speed = 3'd3;
  end

  // OOB: COMRESET -> wait COMINIT -> COMWAKE (tx_n, held while the link is
  // up) -> link up; a reset at any point drops the link and restarts the
  // sequence (no fork: flattener-portable)
  initial forever begin : oob
    int unsigned n;
    vif.tx_p = 0; vif.tx_n = 0; vif.link_up = 0; vif.primitive_type = 32'h0;
    wait (vif.rst_n === 1'b1);
    vif.primitive_type = 32'h7B4A4ABC;   // line idle primitive
    vif.tx_p = 1;            // COMRESET burst
    n = 0;
    while (n < 3 && vif.rst_n === 1'b1) begin @(posedge vif.clk); n++; end
    vif.tx_p = 0;
    // device COMINIT response
    while (vif.rst_n === 1'b1 && vif.rx_p !== 1'b1) @(vif.rx_p or vif.rst_n);
    if (vif.rst_n === 1'b1) vif.tx_n = 1;   // COMWAKE
    n = 0;
    while (n < 4 && vif.rst_n === 1'b1) begin @(posedge vif.clk); n++; end
    if (vif.rst_n === 1'b1) vif.link_up = 1;
    wait (vif.rst_n !== 1'b1);
  end

  // FIS issue engine
  always @(posedge vif.clk) begin
    if (!vif.rst_n) begin
      vif.fis_valid <= 0; vif.fis_start <= 0; vif.fis_end <= 0;
      fis_count <= 0;
    end else if (vif.link_up) begin
      if (!vif.fis_valid) begin
        if (vif.ready && !vif.sync) begin
          // start a new Register H2D FIS: DWORD 0
          vif.fis_valid <= 1;
          vif.fis_start <= 1;
          vif.fis_end   <= 0;
          vif.fis_type  <= 8'h27;
          vif.fis_data  <= {8'h0, cmds[fis_count % 13], 8'h80, 8'h27};
        end
      end else if (vif.ready && !vif.sync) begin
        if (vif.fis_start) begin
          // DWORD 0 taken; DWORD 1: device (LBA mode) and LBA[23:0]
          disk_mem[{21'h0, fis_count[23:0], 3'b000}] = vif.fis_data;
          vif.fis_start <= 0;
          vif.fis_end   <= 1;
          vif.fis_data  <= {8'h40, fis_count[20:0], 3'b000};
        end else begin
          // DWORD 1 taken: FIS done
          vif.fis_valid <= 0;
          vif.fis_end   <= 0;
          fis_count <= fis_count + 1;
        end
      end
    end
  end

  final $display("SATA_HOST_MODEL: fis_frames=%0d disk_entries=%0d",
                 fis_count, disk_mem.num());
endmodule
`endif
