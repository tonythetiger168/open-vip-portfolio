// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sata_tests.sv -- SATA UVM tests on the host controller model in
// tb/top_tb.sv. The VIP is the device: each item accepts one Register H2D
// FIS from the host, optionally after holding the host off with SYNC. Items
// are built field by field (no randomize()), so the test runs on simulators
// without a constraint solver.

package sata_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sata_pkg::*;
  import env_pkg::*;

  // Reference model of the host in tb/top_tb.sv: FIS n carries ATA command
  // ref_cmd(n) and LBA 8*n.
  function automatic bit [7:0] ref_cmd(int unsigned n);
    bit [7:0] cmds[13] = '{8'hEC, 8'h25, 8'h35, 8'h30, 8'hCA, 8'hEA, 8'h91,
                           8'h20, 8'h40, 8'h60, 8'h70, 8'hE7, 8'hEF};
    return cmds[n % 13];
  endfunction
  function automatic bit [47:0] ref_lba(int unsigned n);
    return {24'h0, n[20:0], 3'b000};
  endfunction

  // The first 13 FISes cover every command without hold-off, the next 13
  // every command with a SYNC hold-off, then n FISes with a hold-off on
  // about one in four.
  class sata_fis_sequence extends uvm_sequence #(sata_transaction);
    `uvm_object_utils(sata_fis_sequence)
    int unsigned n = 60;
    int unsigned idx = 0;

    function new(string name = "sata_fis_sequence"); super.new(name); endfunction

    task send(bit hold);
      sata_transaction tx = sata_transaction::type_id::create("tx");
      tx.fis_type = sata_transaction::FIS_REG_H2D;
      tx.command = ref_cmd(idx); tx.lba = ref_lba(idx); tx.sector_count = 1;
      tx.is_write = 0; tx.port_multiplier = 0; tx.link_speed = 3; tx.payload_size = 4;
      tx.with_error = hold; tx.with_crc_error = 0;
      idx++;
      start_item(tx);
      finish_item(tx);
    endtask

    task body();
      repeat (13) send(0);
      repeat (13) send(1);
      repeat (n) send($urandom_range(3) == 0);
    endtask
  endclass

  `uvm_analysis_imp_decl(_fis_exp)
  `uvm_analysis_imp_decl(_fis_obs)

  // Checks every observed FIS against the host reference model (command,
  // DWORD 1 = LBA mode | LBA, one payload DWORD) and the SYNC hold-off the
  // device applied for it.
  class sata_fis_checker extends uvm_component;
    `uvm_component_utils(sata_fis_checker)
    uvm_analysis_imp_fis_exp #(sata_transaction, sata_fis_checker) exp_ap;
    uvm_analysis_imp_fis_obs #(sata_transaction, sata_fis_checker) obs_ap;
    bit hold_q[$];
    sata_transaction obs_q[$];
    int unsigned n_checks, n_fis, n_hold;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_fis_exp(sata_transaction t); hold_q.push_back(t.with_error); match(); endfunction
    function void write_fis_obs(sata_transaction t); obs_q.push_back(t); match(); endfunction

    function void match();
      while (hold_q.size() && obs_q.size()) begin
        bit hold = hold_q.pop_front();
        sata_transaction o = obs_q.pop_front();
        bit [31:0] dw1 = {8'h40, ref_lba(n_fis)[23:0]};
        n_checks++;
        if (o.fis_type != sata_transaction::FIS_REG_H2D || o.command != ref_cmd(n_fis))
          `uvm_error("SATA_FIS", $sformatf("FIS %0d: %s, expected Register H2D command %02h",
                                           n_fis, o.convert2string(), ref_cmd(n_fis)))
        else if (o.data_payload.size() != 1 || o.data_payload[0] != dw1)
          `uvm_error("SATA_FIS", $sformatf("FIS %0d: DWORD 1 %s, expected %08h", n_fis,
                                           o.data_payload.size() ? $sformatf("%08h", o.data_payload[0]) : "missing", dw1))
        else if (o.with_error != hold)
          `uvm_error("SATA_FIS", $sformatf("FIS %0d: SYNC hold-off seen=%0b, driven=%0b", n_fis, o.with_error, hold))
        n_fis++;
        if (hold) n_hold++;
      end
    endfunction

    function void report_phase(uvm_phase phase);
      if (hold_q.size() || obs_q.size())
        `uvm_error("SATA_FIS", $sformatf("%0d accepted FISes not observed, %0d observed FISes not accepted",
                                         hold_q.size(), obs_q.size()))
    endfunction
  endclass

  class sata_base_test extends uvm_test;
    `uvm_component_utils(sata_base_test)
    sata_env         env;
    sata_fis_checker fis;
    int unsigned     n = 60;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = sata_env::type_id::create("env", this);
      fis = sata_fis_checker::type_id::create("fis", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      env.agt.drv.drv_ap.connect(fis.exp_ap);
      env.agt.mon.ap.connect(fis.obs_ap);
    endfunction

    virtual task stimulus();
      sata_fis_sequence seq = sata_fis_sequence::type_id::create("seq");
      seq.n = n;
      seq.start(env.agt.sqr);
    endtask

    task run_phase(uvm_phase phase);
      phase.raise_objection(this);
      stimulus();
      #(500ns);
      phase.drop_objection(this);
    endtask

    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      int unsigned checks = fis.n_checks + env.sb.n_matches;
      super.report_phase(phase);
      `uvm_info("TEST", $sformatf("%0d FISes checked (%0d after a SYNC hold-off), %0d matched end to end",
                                  fis.n_checks, fis.n_hold, env.sb.n_matches), UVM_LOW)
      if (fis.n_checks == 0 || fis.n_hold == 0 || env.sb.n_matches != fis.n_checks)
        `uvm_error("TEST", "too few FISes checked, or the end-to-end count differs")
      else if (rs.get_severity_count(UVM_ERROR) == 0 && rs.get_severity_count(UVM_FATAL) == 0)
        $display("SB_PASS checks=%0d", checks);
    endfunction
  endclass

  // every command with and without SYNC hold-off, then random hold-offs;
  // run by tools/run_uvm_tests.py
  class sata_func_test extends sata_base_test;
    `uvm_component_utils(sata_func_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass
endpackage
