// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_mem_tb.sv -- self-checking functional test for the LPDDR6 memory model
// (lpddr6_mem_model). Run: python3 tools/run_func_tests.py lpddr6-VIP
//
// Model contract (from tb_top.sv):
//   16 banks = {bg[1:0], ba}. ACT opens a row; WR/RD are BL2 (columns c, c+1).
//   Write beats are sampled 1 and 2 clocks after the command. Read beat 0 is
//   driven tCL clocks after the command (tCL=0 selects the default CL=6),
//   beat 1 a clock later, then dq is released. A read of a closed bank returns
//   DEAD_* markers, an unwritten column BAD0_* markers. PRE closes one bank,
//   PREA (ras_n=0,cas_n=0,we_n=1) and reset close all banks.
// The model indexes storage with row[5:0]/col[5:0]; the test keeps addresses
// inside that window (aliasing above it is a documented model limitation).

module func_mem_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic        ck = 1'b0, rst_n = 1'b0;
  logic        cs_n = 1'b1, act_n = 1'b1, ras_n = 1'b1, cas_n = 1'b1, we_n = 1'b1;
  logic [15:0] addr = '0;
  logic [2:0]  bg = '0;
  logic [1:0]  ba = '0;
  logic [63:0] dq_drv = '0;
  logic        dq_oe = 1'b0;
  wire  [63:0] dq;
  int          tCL = 6;

  assign dq = dq_oe ? dq_drv : 64'hzzzz_zzzz_zzzz_zzzz;
  always #5 ck = ~ck;

  lpddr6_mem_model u_dut (
    .ck(ck), .rst_n(rst_n), .cs_n(cs_n), .act_n(act_n), .ras_n(ras_n),
    .cas_n(cas_n), .we_n(we_n), .addr(addr), .bg(bg), .ba(ba), .dq(dq),
    .tRCD(4), .tRP(4), .tRAS(8), .tCL(tCL)
  );

  localparam [63:0] CLOSED0 = 64'hDEAD_0000_0000_0000, CLOSED1 = 64'hDEAD_1111_1111_1111,
                    UNW0    = 64'hBAD0_BAD0_0000_0000, UNW1    = 64'hBAD0_BAD0_1111_1111;

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic cmd(input bit a_n, input bit r_n, input bit c_n, input bit w_n,
                     input [2:0] g, input [1:0] b, input [15:0] ad, input bit sel = 1'b1);
    @(negedge ck);
    cs_n = !sel; act_n = a_n; ras_n = r_n; cas_n = c_n; we_n = w_n;
    bg = g; ba = b; addr = ad;
    @(posedge ck);                       // P0
    @(negedge ck);                       // N0
    cs_n = 1'b1; act_n = 1'b1; ras_n = 1'b1; cas_n = 1'b1; we_n = 1'b1;
  endtask

  task automatic act(input [2:0] g, input [1:0] b, input [15:0] row); cmd(0,1,1,1,g,b,row); endtask
  task automatic pre(input [2:0] g, input [1:0] b); cmd(1,0,1,0,g,b,'0); endtask
  task automatic prea(); cmd(1,0,0,1,'0,'0,'0); endtask

  task automatic wr(input [2:0] g, input [1:0] b, input [5:0] col,
                    input [63:0] d0, input [63:0] d1, input bit sel = 1'b1);
    cmd(1, 1, 0, 0, g, b, {10'h0, col}, sel);
    dq_oe = 1'b1; dq_drv = d0;           // sampled at P1
    @(negedge ck); dq_drv = d1;          // sampled at P2
    @(negedge ck); dq_oe = 1'b0;
  endtask

  logic [63:0] r0, r1, early, after;
  task automatic rd(input [2:0] g, input [1:0] b, input [5:0] col, input int cl);
    cmd(1, 1, 0, 1, g, b, {10'h0, col});
    repeat (cl - 1) @(negedge ck);
    early = dq;                          // N(cl-1)
    @(negedge ck); r0 = dq;              // N(cl)
    @(negedge ck); r1 = dq;              // N(cl+1)
    @(negedge ck); after = dq;           // N(cl+2)
  endtask

  localparam [63:0] A0 = 64'h0101_0101_A0A0_0000, A1 = 64'h0101_0101_A0A0_0001,
                    B0 = 64'h0202_0202_B0B0_0000, B1 = 64'h0202_0202_B0B0_0001,
                    C0 = 64'h0303_0303_C0C0_0000, C1 = 64'h0303_0303_C0C0_0001;

  initial begin
    repeat (3) @(posedge ck);
    chk(dq === 64'hz, "dq released during reset");
    rst_n = 1'b1;
    @(negedge ck);
    chk(dq === 64'hz, "dq released after reset");
    repeat (2) @(posedge ck);

    // closed (never activated) bank
    rd(0, 0, 6'd0, 6);
    chk(r0 === CLOSED0 && r1 === CLOSED1, "read of a closed bank returns the closed-bank marker");

    act(0, 0, 16'h0003);
    rd(0, 0, 6'd8, 6);
    chk(r0 === UNW0 && r1 === UNW1, "unwritten columns return the unwritten marker");

    act(0, 0, 16'h0000);
    rd(0, 0, 6'd0, 6);
    chk(r0 === UNW0 && r1 === UNW1, "unwritten bank 0 / row 0 / column 0 returns the unwritten marker");
    act(0, 0, 16'h0003);

    wr(0, 0, 6'd4, A0, A1);
    rd(0, 0, 6'd4, 6);
    chk(r0 === A0 && r1 === A1, "BL2 write then read returns both beats in order");
    chk(early === 64'hz, "dq not driven before CL");
    chk(after === 64'hz, "dq released after the second beat");

    // programmable CL
    tCL = 10;
    rd(0, 0, 6'd4, 10);
    chk(r0 === A0 && r1 === A1 && early === 64'hz, "read latency follows tCL=10");
    tCL = 0;
    rd(0, 0, 6'd4, 6);
    chk(r0 === A0 && r1 === A1 && early === 64'hz, "tCL=0 falls back to default CL=6");
    tCL = 1;
    rd(0, 0, 6'd4, 1);
    chk(r0 === A0 && r1 === A1, "minimum latency tCL=1");
    tCL = 6;

    // overwrite
    wr(0, 0, 6'd4, B0, B1);
    rd(0, 0, 6'd4, 6);
    chk(r0 === B0 && r1 === B1, "second write overwrites the first");

    // bank independence ({bg[1:0], ba})
    act(2, 3, 16'h0003);
    wr(2, 3, 6'd4, C0, C1);
    rd(2, 3, 6'd4, 6);
    chk(r0 === C0 && r1 === C1, "bank {bg=2,ba=3} holds its own data");
    rd(0, 0, 6'd4, 6);
    chk(r0 === B0 && r1 === B1, "bank 0 unaffected by bank 11 write");

    // row isolation inside the model's 6-bit row window
    pre(0, 0);
    act(0, 0, 16'h0005);
    rd(0, 0, 6'd4, 6);
    chk(r0 === UNW0, "another row of the same bank does not alias");

    // PRE closes only its bank
    pre(0, 0);
    rd(0, 0, 6'd4, 6);
    chk(r0 === CLOSED0, "PRE closes the addressed bank");
    rd(2, 3, 6'd4, 6);
    chk(r0 === C0, "PRE leaves other banks open");
    act(0, 0, 16'h0003);
    rd(0, 0, 6'd4, 6);
    chk(r0 === B0 && r1 === B1, "re-ACT of the row restores access to retained data");

    // PREA closes all banks
    prea();
    rd(0, 0, 6'd4, 6);
    chk(r0 === CLOSED0, "PREA closes bank 0");
    rd(2, 3, 6'd4, 6);
    chk(r0 === CLOSED0, "PREA closes bank 11");

    // a selected NOP leaves banks open
    act(2, 3, 16'h0003);
    cmd(1, 1, 1, 1, '0, '0, '0);
    rd(2, 3, 6'd4, 6);
    chk(r0 === C0 && r1 === C1, "selected NOP does not close banks");

    // deselected write ignored
    act(0, 0, 16'h0003);
    wr(0, 0, 6'd4, C0, C1, 1'b0);
    rd(0, 0, 6'd4, 6);
    chk(r0 === B0 && r1 === B1, "write with CS_n high is ignored");

    // reset closes rows but keeps array contents
    act(2, 3, 16'h0003);
    @(negedge ck); rst_n = 1'b0;
    @(negedge ck);
    chk(dq === 64'hz, "dq released in reset");
    rst_n = 1'b1;
    rd(0, 0, 6'd4, 6);
    chk(r0 === CLOSED0, "reset closes open rows");
    rd(2, 3, 6'd4, 6);
    chk(r0 === CLOSED0, "reset closes every bank (bank 11)");
    act(0, 0, 16'h0003);
    rd(0, 0, 6'd4, 6);
    chk(r0 === B0, "array contents survive reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
