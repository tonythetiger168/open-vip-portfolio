// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 UVM tests
`ifndef DDR6_TEST_SV
`define DDR6_TEST_SV

class ddr6_base_test extends uvm_test;
  `uvm_component_utils(ddr6_base_test)
  ddr6_env env;
  function new(string name = "ddr6_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = ddr6_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    ddr6_base_sequence seq;
    phase.raise_objection(this);
    seq = ddr6_base_sequence::type_id::create("seq");
    seq.num_transactions = 100;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed regression: every directed sequence in turn
class ddr6_directed_test extends ddr6_base_test;
  `uvm_component_utils(ddr6_directed_test)
  function new(string name = "ddr6_directed_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_phase(uvm_phase phase);
    ddr6_regression_seq seq;
    phase.raise_objection(this);
    seq = ddr6_regression_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress: long randomized command mix
class ddr6_stress_test extends ddr6_base_test;
  `uvm_component_utils(ddr6_stress_test)
  function new(string name = "ddr6_stress_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_phase(uvm_phase phase);
    ddr6_stress_seq seq;
    phase.raise_objection(this);
    seq = ddr6_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
