// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 UVM environment -- agent + end-to-end scoreboard + functional coverage.
// (SVA checkers are modules bound at the testbench level.)
`ifndef DDR6_ENV_SV
`define DDR6_ENV_SV

class ddr6_env extends uvm_env;
  `uvm_component_utils(ddr6_env)

  ddr6_agent      agt;
  ddr6_scoreboard sb;
  ddr6_coverage   cov;

  function new(string name = "ddr6_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agt = ddr6_agent::type_id::create("agt", this);
    sb  = ddr6_scoreboard::type_id::create("sb", this);
    cov = ddr6_coverage::type_id::create("cov", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    agt.mon.ap.connect(sb.obs_ap);        // observed (bus-decoded)
    agt.drv.drv_ap.connect(sb.exp_ap);    // expected (driver-issued)
    agt.mon.ap.connect(cov.analysis_export);
  endfunction
endclass
`endif
