// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 Data Integrity Checker (L2)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR6_DATA_INTEGRITY_CHECKER_SV
`define DDR6_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr6_data_integrity_checker (ddr6_if vif);

  property p_ddr6_bl; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {4'b1000,4'b1001,4'b1010}; endproperty
  assert_p_ddr6_bl: assert property(p_ddr6_bl) else `uvm_warning("DDR6_L2", "Burst length 8/16/32 failed");
  cover_p_ddr6_bl: cover property(p_ddr6_bl);
  property p_ddr6_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[12:16] $fell(vif.cas_n); endproperty
  assert_p_ddr6_tRCD: assert property(p_ddr6_tRCD) else `uvm_warning("DDR6_L2", "tRCD 12-16 cycles failed");
  cover_p_ddr6_tRCD: cover property(p_ddr6_tRCD);
  property p_ddr6_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.act_n) |-> ##[12:16] $fell(vif.act_n); endproperty
  assert_p_ddr6_tRP: assert property(p_ddr6_tRP) else `uvm_warning("DDR6_L2", "tRP 12-16 cycles failed");
  cover_p_ddr6_tRP: cover property(p_ddr6_tRP);
  property p_ddr6_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[28:36] $rose(vif.act_n); endproperty
  assert_p_ddr6_tRAS: assert property(p_ddr6_tRAS) else `uvm_warning("DDR6_L2", "tRAS 28-36 cycles failed");
  cover_p_ddr6_tRAS: cover property(p_ddr6_tRAS);
  property p_ddr6_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cas_n) && vif.we_n == 1 |-> ##[20:26] vif.dqs_t == 1; endproperty
  assert_p_ddr6_tCL: assert property(p_ddr6_tCL) else `uvm_warning("DDR6_L2", "tCL 20-26 cycles failed");
  cover_p_ddr6_tCL: cover property(p_ddr6_tCL);
  property p_ddr6_odt; @(posedge vif.ck) disable iff (!vif.rst_n) vif.we_n == 0 && vif.cs_n == 0 |-> vif.odt == 1; endproperty
  assert_p_ddr6_odt: assert property(p_ddr6_odt) else `uvm_warning("DDR6_L2", "ODT during write failed");
  cover_p_ddr6_odt: cover property(p_ddr6_odt);
  property p_ddr6_pam4; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pam4_en |-> vif.data_width == 5'b10000; endproperty
  assert_p_ddr6_pam4: assert property(p_ddr6_pam4) else `uvm_warning("DDR6_L2", "PAM4 mode valid failed");
  cover_p_ddr6_pam4: cover property(p_ddr6_pam4);
  property p_ddr6_fgr; @(posedge vif.ck) disable iff (!vif.rst_n) vif.fgr_mode inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ddr6_fgr: assert property(p_ddr6_fgr) else `uvm_warning("DDR6_L2", "Fine granularity refresh failed");
  cover_p_ddr6_fgr: cover property(p_ddr6_fgr);

endmodule : ddr6_data_integrity_checker
`endif
