// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 Timing Performance Checker (L2)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR6_TIMING_CHECKER_SV
`define DDR6_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr6_timing_checker (ddr6_if vif);

  property p_ddr6_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[12:16] $fell(vif.cas_n); endproperty
  assert_p_ddr6_tRCD: assert property(p_ddr6_tRCD) else `uvm_warning("DDR6_TIM", "tRCD 12-16 cycles violated");
  cover_p_ddr6_tRCD: cover property(p_ddr6_tRCD);
  property p_ddr6_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.act_n) |-> ##[12:16] $fell(vif.act_n); endproperty
  assert_p_ddr6_tRP: assert property(p_ddr6_tRP) else `uvm_warning("DDR6_TIM", "tRP 12-16 cycles violated");
  cover_p_ddr6_tRP: cover property(p_ddr6_tRP);
  property p_ddr6_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[28:36] $rose(vif.act_n); endproperty
  assert_p_ddr6_tRAS: assert property(p_ddr6_tRAS) else `uvm_warning("DDR6_TIM", "tRAS 28-36 cycles violated");
  cover_p_ddr6_tRAS: cover property(p_ddr6_tRAS);
  property p_ddr6_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cas_n) && vif.we_n == 1 |-> ##[20:26] vif.dqs_t == 1; endproperty
  assert_p_ddr6_tCL: assert property(p_ddr6_tCL) else `uvm_warning("DDR6_TIM", "tCL 20-26 cycles violated");
  cover_p_ddr6_tCL: cover property(p_ddr6_tCL);

endmodule : ddr6_timing_checker
`endif
