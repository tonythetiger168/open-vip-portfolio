// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 UVM agent -- sequencer + driver + monitor
`ifndef DDR6_AGENT_SV
`define DDR6_AGENT_SV

import uvm_pkg::*;
typedef class ddr6_driver;
typedef class ddr6_monitor;

class ddr6_sequencer extends uvm_sequencer #(ddr6_transaction);
  `uvm_component_utils(ddr6_sequencer)
  function new(string name = "ddr6_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

class ddr6_agent extends uvm_agent;
  `uvm_component_utils(ddr6_agent)
  ddr6_sequencer sqr;
  ddr6_driver    drv;
  ddr6_monitor   mon;

  function new(string name = "ddr6_agent", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    mon = ddr6_monitor::type_id::create("mon", this);
    if (is_active == UVM_ACTIVE) begin
      sqr = ddr6_sequencer::type_id::create("sqr", this);
      drv = ddr6_driver::type_id::create("drv", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (is_active == UVM_ACTIVE)
      drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
