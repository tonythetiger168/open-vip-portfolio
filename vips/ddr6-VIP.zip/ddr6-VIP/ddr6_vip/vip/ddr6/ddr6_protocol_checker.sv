// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 Protocol Compliance Checker (L1)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR6_PROTOCOL_CHECKER_SV
`define DDR6_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr6_protocol_checker (ddr6_if vif);

  property p_ddr6_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_ddr6_cmd_valid: assert property(p_ddr6_cmd_valid) else `uvm_warning("DDR6_L1", "Command valid failed");
  cover_p_ddr6_cmd_valid: cover property(p_ddr6_cmd_valid);
  property p_ddr6_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_ddr6_addr_valid: assert property(p_ddr6_addr_valid) else `uvm_warning("DDR6_L1", "Address valid failed");
  cover_p_ddr6_addr_valid: cover property(p_ddr6_addr_valid);
  property p_ddr6_bg; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bg <= 3'd7; endproperty
  assert_p_ddr6_bg: assert property(p_ddr6_bg) else `uvm_warning("DDR6_L1", "Bank group 0-7 failed");
  cover_p_ddr6_bg: cover property(p_ddr6_bg);
  property p_ddr6_ba; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ba <= 2'd3; endproperty
  assert_p_ddr6_ba: assert property(p_ddr6_ba) else `uvm_warning("DDR6_L1", "Bank address 0-3 failed");
  cover_p_ddr6_ba: cover property(p_ddr6_ba);

endmodule : ddr6_protocol_checker
`endif
