// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 Error Handling Checker (L3)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR6_ERROR_CHECKER_SV
`define DDR6_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr6_error_checker (ddr6_if vif);

  property p_ddr6_pm; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ddr6_pm: assert property(p_ddr6_pm) else `uvm_warning("DDR6_L3", "Power management failed");
  cover_p_ddr6_pm: cover property(p_ddr6_pm);
  property p_ddr6_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.refresh |-> ##[1:3900] vif.cs_n == 0; endproperty
  assert_p_ddr6_refresh: assert property(p_ddr6_refresh) else `uvm_warning("DDR6_L3", "Refresh interval failed");
  cover_p_ddr6_refresh: cover property(p_ddr6_refresh);
  property p_ddr6_3ds; @(posedge vif.ck) disable iff (!vif.rst_n) vif.stack_id <= 3'd7; endproperty
  assert_p_ddr6_3ds: assert property(p_ddr6_3ds) else `uvm_warning("DDR6_L3", "3DS stack valid failed");
  cover_p_ddr6_3ds: cover property(p_ddr6_3ds);
  property p_ddr6_wck; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ddr6_wck: assert property(p_ddr6_wck) else `uvm_warning("DDR6_L3", "WCK ratio failed");
  cover_p_ddr6_wck: cover property(p_ddr6_wck);
  property p_ddr6_dfe; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dfe_tap <= 4'd15; endproperty
  assert_p_ddr6_dfe: assert property(p_ddr6_dfe) else `uvm_warning("DDR6_L3", "DFE tap valid failed");
  cover_p_ddr6_dfe: cover property(p_ddr6_dfe);
  property p_ddr6_temp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp_sensor <= 8'd127; endproperty
  assert_p_ddr6_temp: assert property(p_ddr6_temp) else `uvm_warning("DDR6_L3", "Temperature sensor failed");
  cover_p_ddr6_temp: cover property(p_ddr6_temp);
  property p_ddr6_ecc; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ecc_en |-> vif.data_width >= 5'b01000; endproperty
  assert_p_ddr6_ecc: assert property(p_ddr6_ecc) else `uvm_warning("DDR6_L3", "On-die ECC failed");
  cover_p_ddr6_ecc: cover property(p_ddr6_ecc);
  property p_ddr6_ca_parity; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ca_parity |-> ^vif.ca != 1'bx; endproperty
  assert_p_ddr6_ca_parity: assert property(p_ddr6_ca_parity) else `uvm_warning("DDR6_L3", "CA parity check failed");
  cover_p_ddr6_ca_parity: cover property(p_ddr6_ca_parity);

endmodule : ddr6_error_checker
`endif
