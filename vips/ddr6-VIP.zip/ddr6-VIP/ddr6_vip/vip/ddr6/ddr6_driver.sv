// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 UVM driver -- issues real DRAM command sequences (ACT/RD/WR/PRE/REF)
// on the ddr6_if command/address bus with JEDEC-style bank/row/col timing
// (tRCD/tRP/tRAS/tCL/tCWL/tFAW) and publishes expected items to the scoreboard.
`ifndef DDR6_DRIVER_SV
`define DDR6_DRIVER_SV

class ddr6_driver extends uvm_driver #(ddr6_transaction);
  `uvm_component_utils(ddr6_driver)

  virtual ddr6_if vif;
  uvm_analysis_port #(ddr6_transaction) drv_ap;  // expected items for scoreboard

  // DRAM timing parameters (clock cycles), aligned with the timing checker
  int tRCD = 12;
  int tRP  = 12;
  int tRAS = 28;
  int tCL  = 20;
  int tCWL = 18;
  int tFAW = 16;
  int tRFC = 36;

  int unsigned cyc = 0;                 // driver-local free-running cycle count
  bit          bank_active [32];        // flattened {bg,ba} bank state
  bit [15:0]   active_row  [32];
  int unsigned act_cycle   [32];        // cycle of last ACT per bank (tRAS/tFAW)
  int unsigned act_hist    [4];         // last 4 ACT cycles (tFAW window)
  int          act_hist_idx = 0;

  function new(string name = "ddr6_driver", uvm_component parent = null);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db #(virtual ddr6_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "DDR6: virtual interface not set")
  endfunction

  function int bank_id(bit [2:0] bg, bit [1:0] ba);
    return bg * 4 + ba;
  endfunction

  // Drive one command cycle on the CA bus, then count the cycle
  task drive_cmd(bit cs_n, bit act_n, bit ras_n, bit cas_n, bit we_n,
                 bit [15:0] a, bit [2:0] bg, bit [1:0] ba);
    vif.cb.cs_n  <= cs_n;
    vif.cb.act_n <= act_n;
    vif.cb.ras_n <= ras_n;
    vif.cb.cas_n <= cas_n;
    vif.cb.we_n  <= we_n;
    vif.cb.addr  <= a;
    vif.cb.ca    <= a[6:0];           // CA bus carries the command address
    vif.cb.bg    <= bg;
    vif.cb.ba    <= ba;
    @(vif.cb);
    cyc++;
  endtask

  // Deselect (NOP) for n cycles
  task idle(int n);
    vif.cb.cs_n  <= 1'b1;
    vif.cb.act_n <= 1'b1;
    vif.cb.ras_n <= 1'b1;
    vif.cb.cas_n <= 1'b1;
    vif.cb.we_n  <= 1'b1;
    repeat (n) begin
      @(vif.cb);
      cyc++;
    end
  endtask

  task drive_activate(ddr6_transaction tr);
    int id = bank_id(tr.bg, tr.ba);
    // tFAW: no more than 4 ACTs inside the rolling window
    while (cyc - act_hist[act_hist_idx] <= tFAW && act_hist[act_hist_idx] != 0)
      idle(1);
    // ACT: cs_n=0, act_n=0, row address on addr bus
    drive_cmd(0, 0, 1, 1, 1, tr.addr, tr.bg, tr.ba);
    bank_active[id] = 1;
    active_row[id]  = tr.addr;
    act_cycle[id]   = cyc;
    act_hist[act_hist_idx] = cyc;
    act_hist_idx = (act_hist_idx + 1) % 4;
    idle(tRCD - 1);                     // tRCD before a CAS command may follow
  endtask

  task drive_read(ddr6_transaction tr);
    int id = bank_id(tr.bg, tr.ba);
    if (!bank_active[id])
      `uvm_warning("DRV", $sformatf("RD to closed bank bg=%0d ba=%0d", tr.bg, tr.ba))
    // RD: cs_n=0, act_n=1, ras_n=1, cas_n=0, we_n=1, column on addr bus
    drive_cmd(0, 1, 1, 0, 1, tr.addr, tr.bg, tr.ba);
    idle(tCL);                          // CAS latency
    tr.rdata = new[tr.bl];
    for (int i = 0; i < tr.bl; i++) begin
      @(vif.cb);
      cyc++;
      tr.rdata[i] = vif.cb.dq;          // sample read data burst
    end
  endtask

  task drive_write(ddr6_transaction tr);
    int id = bank_id(tr.bg, tr.ba);
    if (!bank_active[id])
      `uvm_warning("DRV", $sformatf("WR to closed bank bg=%0d ba=%0d", tr.bg, tr.ba))
    vif.cb.odt <= 1'b1;                 // terminate DQ for the write burst
    // WR: cs_n=0, act_n=1, ras_n=1, cas_n=0, we_n=0
    drive_cmd(0, 1, 1, 0, 0, tr.addr, tr.bg, tr.ba);
    idle(tCWL - 1);                     // CAS write latency
    for (int i = 0; i < tr.bl; i++) begin
      vif.cb.dq <= tr.data;
      vif.cb.dm <= '0;
      @(vif.cb);
      cyc++;
    end
    vif.cb.odt <= 1'b0;
  endtask

  task drive_precharge(ddr6_transaction tr);
    int id = bank_id(tr.bg, tr.ba);
    while (cyc - act_cycle[id] < tRAS)  // tRAS: earliest legal PRE after ACT
      idle(1);
    // PRE: cs_n=0, act_n=1, ras_n=0, cas_n=1, we_n=0
    drive_cmd(0, 1, 0, 1, 0, tr.addr, tr.bg, tr.ba);
    bank_active[id] = 0;
    idle(tRP - 1);                      // tRP before the bank may be re-activated
  endtask

  task drive_refresh(ddr6_transaction tr);
    foreach (bank_active[i]) begin
      if (bank_active[i])
        `uvm_warning("DRV", "REF issued with open banks (sequence should PRE first)")
    end
    // REF: cs_n=0, act_n=1, ras_n=0, cas_n=0, we_n=1
    drive_cmd(0, 1, 0, 0, 1, tr.addr, tr.bg, tr.ba);
    idle(tRFC - 1);
  endtask

  // Mode-register / static configuration. Nothing else drives these
  // interface signals, so they stayed X (0 on a 2-state simulator) and the
  // checkers that require a legal setting fired on every clock. Drive one
  // legal configuration: BL16, WCK:CK 2:1, every optional feature off.
  task drive_mode_config();
    vif.cb.bg <= '0; vif.cb.ba <= '0;  // known bank address before the first command
    vif.bl = 4'b1001;
    vif.dfe_tap = '0;
    vif.ecc_en = '0;
    vif.fgr_mode = '0;
    vif.pam4_en = '0;
    vif.pm_state = '0;
    vif.refresh = '0;
    vif.stack_id = '0;
    vif.temp_sensor = 8'd45;
    vif.wck_ratio = 2'd1;
  endtask

  task run_phase(uvm_phase phase);
    ddr6_transaction tr;
    drive_mode_config();
    vif.cb.cke <= 1'b1;                 // clock enabled for the whole test
    vif.cb.odt <= 1'b0;
    idle(1);
    wait (vif.rst_n === 1'b1);
    idle(5);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      case (tr.cmd)
        ddr6_transaction::ACT:   drive_activate(tr);
        ddr6_transaction::READ:  drive_read(tr);
        ddr6_transaction::WRITE: drive_write(tr);
        ddr6_transaction::PRE:   drive_precharge(tr);
        ddr6_transaction::REF:   drive_refresh(tr);
        default:                idle(1);   // NOP
      endcase
      if (tr.cmd != ddr6_transaction::NOP)
        drv_ap.write(tr);               // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
