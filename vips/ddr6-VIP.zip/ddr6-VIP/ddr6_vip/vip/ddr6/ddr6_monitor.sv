// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR6 UVM monitor -- decodes DRAM commands from the ddr6_if command/address
// bus waveform (cs_n/act_n/ras_n/cas_n/we_n), tracks per-bank state and page
// hit/miss, and publishes reconstructed transactions on the analysis port.
`ifndef DDR6_MONITOR_SV
`define DDR6_MONITOR_SV

class ddr6_monitor extends uvm_monitor;
  `uvm_component_utils(ddr6_monitor)

  virtual ddr6_if vif;
  uvm_analysis_port #(ddr6_transaction) ap;
  int unsigned txn_count = 0;

  protected bit        bank_active [32];
  protected bit [15:0] active_row  [32];

  function new(string name = "ddr6_monitor", uvm_component parent = null);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db #(virtual ddr6_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "DDR6: virtual interface not set")
  endfunction

  function int bank_id(bit [2:0] bg, bit [1:0] ba);
    return bg * 4 + ba;
  endfunction

  task run_phase(uvm_phase phase);
    ddr6_transaction tr;
    int id;
    forever begin
      @(posedge vif.ck);
      if (vif.rst_n !== 1'b1) begin
        foreach (bank_active[i]) bank_active[i] = 0;
        continue;
      end
      if (vif.cs_n) continue;           // deselect = NOP, not published

      tr = ddr6_transaction::type_id::create("tr");
      tr.addr = vif.addr;
      tr.bg   = vif.bg;
      tr.ba   = vif.ba;
      id      = bank_id(vif.bg, vif.ba);
      tr.page_hit = 1'b0;

      if (!vif.act_n) begin                     // ACT: row address
        tr.cmd    = ddr6_transaction::ACT;
        tr.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
        bank_active[id] = 1;
        active_row[id]  = vif.addr;
      end
      else if (vif.ras_n && !vif.cas_n && vif.we_n) begin   // RD
        tr.cmd      = ddr6_transaction::READ;
        tr.bstate   = bank_active[id] ? B_ACTIVE : B_IDLE;
        tr.page_hit = bank_active[id];          // read hits the open page
      end
      else if (vif.ras_n && !vif.cas_n && !vif.we_n) begin  // WR
        tr.cmd      = ddr6_transaction::WRITE;
        tr.bstate   = bank_active[id] ? B_ACTIVE : B_IDLE;
        tr.page_hit = bank_active[id];
      end
      else if (!vif.ras_n && vif.cas_n && !vif.we_n) begin  // PRE
        tr.cmd    = ddr6_transaction::PRE;
        tr.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
        bank_active[id] = 0;
      end
      else if (!vif.ras_n && !vif.cas_n && vif.we_n) begin  // REF
        tr.cmd    = ddr6_transaction::REF;
        tr.bstate = B_IDLE;
        foreach (bank_active[i]) bank_active[i] = 0;
      end
      else begin                                // MRS/ZQC/other: record as NOP
        tr.cmd    = ddr6_transaction::NOP;
        tr.bstate = B_IDLE;
      end

      if (tr.cmd != ddr6_transaction::NOP) begin
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("DDR6 monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
