// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// typec_env.sv -- USB Type-C verification environment with end-to-end
// scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import typec_defs_pkg::*;
  import typec_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) attach cycles
  // against monitor-observed ones. Clean cycles check the final attach
  // state, vbus and vconn behavior; error cycles compare the error class.
  class typec_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(typec_scoreboard)
    uvm_analysis_imp_exp #(typec_transaction, typec_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(typec_transaction, typec_scoreboard) obs_ap;

    typec_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, mismatches = 0, error_hits = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    // Expected end state for a clean cycle
    function typec_state_e map_exp(typec_transaction e);
      if (e.acc == ACC_AUDIO) return AUDIO_ACC;
      if (e.acc == ACC_DEBUG) return DEBUG_ACC;
      if (e.role == ROLE_SNK) return ATTACHED_SNK;
      if (e.role == ROLE_SRC) return ATTACHED_SRC;
      return e.pd_capable ? ATTACHED_SRC : ATTACHED_SNK;  // DRP try result
    endfunction

    function void write_exp(typec_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(typec_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        typec_transaction e = exp_q.pop_front();
        typec_transaction o = obs_q.pop_front();
        typec_state_e want = map_exp(e);
        if (e.err_inject != TC_ERR_NONE || o.err_inject != TC_ERR_NONE) begin
          if (e.err_inject == o.err_inject) error_hits++;
          else begin
            mismatches++;
            `uvm_error("SB", $sformatf("error-class mismatch exp{%s} obs{%s}",
                       e.convert2string(), o.convert2string()))
          end
        end
        else if (o.attached_as == want &&
                 o.vbus_seen == (want == ATTACHED_SRC) &&
                 o.vconn_seen == (e.vconn && want == ATTACHED_SRC))
          n_matches++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} want_state=%s obs{%s}",
                     e.convert2string(), want.name(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("typec scoreboard: n_matches=%0d error_hits=%0d mismatches=%0d",
                n_matches, error_hits, mismatches), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class typec_env extends uvm_env;
    `uvm_component_utils(typec_env)
    typec_agent      agt;
    typec_scoreboard sb;
    typec_checker    chk;
    typec_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = typec_agent::type_id::create("agt", this);
      sb  = typec_scoreboard::type_id::create("sb", this);
      chk = typec_checker::type_id::create("chk", this);
      cov = typec_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
