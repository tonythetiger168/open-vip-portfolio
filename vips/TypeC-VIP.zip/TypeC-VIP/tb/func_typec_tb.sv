// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_typec_tb.sv -- self-checking functional test for the USB Type-C
// partner termination model (typec_partner_model, flattened by
// smoke/flatten.py). Run: python3 tools/run_func_tests.py TypeC-VIP
//
// Model contract (from tb/top_tb.sv and typec_defs_pkg):
//   the partner presents CC terminations by mode, one clock after the mode
//   changes: SNK = Rd on CC1 / open on CC2 (plug orientation), SRC = Rp/Rp,
//   AUDIO accessory = Ra/Ra, DEBUG accessory = Rd/Rd. cc_glitch_req forces
//   both lines open (detach / debounce stimulus); reset opens both lines.

module func_typec_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [1:0] OPEN = 2'b00, RD = 2'b01, RA = 2'b10, RP = 2'b11;
  localparam bit [1:0] SNK = 2'd0, SRC = 2'd1, AUDIO = 2'd2, DEBUG = 2'd3;
  int checks = 0, fails = 0;

  logic       clk = 1'b0, rst_n = 1'b0, glitch = 1'b0;
  logic [1:0] mode = SNK;
  wire  [1:0] cc1, cc2;

  always #5 clk = ~clk;

  typec_partner_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_ptn_cc1(cc1), .vif_ptn_cc2(cc2),
    .vif_ptn_mode(mode), .vif_cc_glitch_req(glitch)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic set_mode(input [1:0] m);
    @(negedge clk); mode = m;
    @(negedge clk);
  endtask

  initial begin
    repeat (2) @(negedge clk);
    chk(cc1 === OPEN && cc2 === OPEN, "both CC lines open in reset (unattached)");
    rst_n = 1'b1;
    set_mode(SNK);
    chk(cc1 === RD && cc2 === OPEN, "sink partner: Rd on CC1, CC2 open (orientation)");
    set_mode(SRC);
    chk(cc1 === RP && cc2 === RP, "source partner: Rp on both CC lines");
    set_mode(AUDIO);
    chk(cc1 === RA && cc2 === RA, "audio accessory: Ra on both CC lines");
    set_mode(DEBUG);
    chk(cc1 === RD && cc2 === RD, "debug accessory: Rd on both CC lines");

    // glitch / detach
    @(negedge clk); glitch = 1'b1;
    @(negedge clk);
    chk(cc1 === OPEN && cc2 === OPEN, "glitch request opens both lines");
    glitch = 1'b0;
    @(negedge clk);
    chk(cc1 === RD && cc2 === RD, "terminations restored after the glitch");

    // termination follows a mode change within one clock
    @(negedge clk); mode = SRC;
    @(posedge clk); #1;
    chk(cc1 === RP, "mode change takes effect on the next clock edge");

    @(negedge clk); rst_n = 1'b0;
    #1;
    chk(cc1 === OPEN && cc2 === OPEN, "asynchronous reset opens both lines");

    // out of reset the terminations follow the mode again; a glitch held for
    // several clocks keeps both lines open the whole time
    @(negedge clk); rst_n = 1'b1; mode = AUDIO;
    @(negedge clk);
    chk(cc1 === RA && cc2 === RA, "terminations follow the mode after reset");
    @(negedge clk); glitch = 1'b1;
    begin
      bit open_all = 1;
      repeat (4) begin @(negedge clk); if (cc1 !== OPEN || cc2 !== OPEN) open_all = 0; end
      chk(open_all, "a held glitch request keeps both lines open");
    end
    glitch = 1'b0;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #10000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
