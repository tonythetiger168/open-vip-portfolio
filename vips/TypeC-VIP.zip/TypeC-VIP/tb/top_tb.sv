// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- USB Type-C testbench top with a functional port-partner
// DUT model

`ifndef TYPEC_TB_SV
`define TYPEC_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import typec_defs_pkg::*;
import typec_pkg::*;
import typec_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  typec_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  typec_partner_model dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual typec_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional Type-C port partner: presents Rd/Rp/Ra on the CC lines
// according to its personality (sink / source / audio accessory / debug
// accessory, selected out-of-band by the test). Bounces CC open when a
// glitch is requested (error injection). A source personality advertises
// Rp; a sink personality advertises Rd on cc1 only (single orientation).
module typec_partner_model (typec_if vif);

  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      vif.ptn_cc1 <= CC_OPEN;
      vif.ptn_cc2 <= CC_OPEN;
    end else if (vif.cc_glitch_req) begin
      vif.ptn_cc1 <= CC_OPEN;                 // CC bounce -> detach
      vif.ptn_cc2 <= CC_OPEN;
    end else begin
      unique case (partner_mode_e'(vif.ptn_mode))
        PTN_SNK: begin
          vif.ptn_cc1 <= CC_RD;               // sink: Rd on cc1 only
          vif.ptn_cc2 <= CC_OPEN;
        end
        PTN_SRC: begin
          vif.ptn_cc1 <= CC_RP;               // source: Rp advertised
          vif.ptn_cc2 <= CC_RP;
        end
        PTN_AUDIO: begin
          vif.ptn_cc1 <= CC_RA;               // audio accessory: Ra/Ra
          vif.ptn_cc2 <= CC_RA;
        end
        PTN_DEBUG: begin
          vif.ptn_cc1 <= CC_RD;               // debug accessory: Rd/Rd
          vif.ptn_cc2 <= CC_RD;
        end
        default: begin
          vif.ptn_cc1 <= CC_OPEN;
          vif.ptn_cc2 <= CC_OPEN;
        end
      endcase
    end
  end
endmodule
`endif
