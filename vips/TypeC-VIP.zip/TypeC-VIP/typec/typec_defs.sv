// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// typec_defs.sv -- USB Type-C Port Controller shared type definitions
// CC voltage-level encoding, roles, accessory modes and partner model
// personalities shared by VIP, DUT model and SVA checker.

package typec_defs_pkg;
  typedef enum bit [2:0] {
    UNATTACHED,
    ATTACHWAIT_SNK,
    ATTACHED_SNK,
    ATTACHED_SRC,
    AUDIO_ACC,
    DEBUG_ACC,
    TRY_SRC
  } typec_state_e;

  // CC line voltage-level encoding (2-bit)
  typedef enum bit [1:0] {
    CC_OPEN = 2'b00,    // nothing connected / open
    CC_RD   = 2'b01,    // Rd pull-down level (sink present)
    CC_RA   = 2'b10,    // Ra pull-down level (powered cable / audio acc)
    CC_RP   = 2'b11     // Rp pull-up level (source present)
  } cc_level_e;

  // Local port role intent
  typedef enum bit [1:0] {
    ROLE_SNK = 2'd0,    // port advertises Rd, waits for a source
    ROLE_SRC = 2'd1,    // port advertises Rp, waits for a sink
    ROLE_DRP = 2'd2     // dual-role: TRY_SRC then fall back to sink
  } typec_role_e;

  // Accessory detection target
  typedef enum bit [1:0] {
    ACC_NONE,
    ACC_AUDIO,          // partner presents Ra/Ra
    ACC_DEBUG           // partner presents Rd/Rd
  } typec_acc_e;

  // Error-injection classes
  typedef enum bit [1:0] {
    TC_ERR_NONE,        // clean attach/detach
    TC_ERR_CC_GLITCH,   // CC bounces open mid-attach -> detach
    TC_ERR_BAD_VCONN    // vconn enabled while attached as sink
  } typec_err_e;

  // Partner (DUT) personalities, selected out-of-band by the test
  typedef enum bit [1:0] {
    PTN_SNK,            // presents Rd on cc1, open on cc2
    PTN_SRC,            // presents Rp on both cc lines
    PTN_AUDIO,          // presents Ra on both cc lines
    PTN_DEBUG           // presents Rd on both cc lines
  } partner_mode_e;

  // Wired-CC resolution: combine local and partner pulls into the sensed
  // line level (loaded line reads the stronger pull-down level)
  function automatic cc_level_e cc_resolve(cc_level_e port, cc_level_e ptn);
    if (port == CC_OPEN) return ptn;
    if (ptn  == CC_OPEN) return port;
    if (port == ptn)     return port;
    if ((port == CC_RP && ptn == CC_RD) || (port == CC_RD && ptn == CC_RP))
      return CC_RD;                          // Rp+Rd divider reads Rd level
    if ((port == CC_RP && ptn == CC_RA) || (port == CC_RA && ptn == CC_RP))
      return CC_RA;                          // Rp+Ra divider reads Ra level
    return CC_RP;
  endfunction
endpackage
