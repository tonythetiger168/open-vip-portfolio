// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// typec_driver.svh -- Type-C port controller driver: CC advertisement,
// attach state machine (UNATTACHED -> ATTACHWAIT_SNK -> ATTACHED_SNK /
// ATTACHED_SRC, TRY_SRC, AUDIO_ACC, DEBUG_ACC), vbus/vconn control and
// detach / error-injection handling.

`ifndef TYPEC_DRIVER_SVH
`define TYPEC_DRIVER_SVH

class typec_driver extends uvm_driver #(typec_transaction);
  `uvm_component_utils(typec_driver)
  virtual typec_if vif;
  typec_config cfg;
  uvm_analysis_port #(typec_transaction) drv_ap;  // expected items

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual typec_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "typec virtual interface not set")
  endfunction

  task set_port(cc_level_e c1, cc_level_e c2);
    vif.drv_cb.port_cc1 <= c1;
    vif.drv_cb.port_cc2 <= c2;
  endtask

  // Hold an attached state; bail out early if the CC line is lost
  task hold_attached(int cycles, bit glitch_after);
    bit detached = 0;
    if (glitch_after) begin
      repeat (2) @(vif.drv_cb);
      vif.drv_cb.cc_glitch_req <= 1'b1;
      repeat (3) @(vif.drv_cb);
      vif.drv_cb.cc_glitch_req <= 1'b0;
    end
    for (int i = 0; i < cycles && !detached; i++) begin
      @(vif.drv_cb);
      if (vif.drv_cb.cc1 != typec_defs_pkg::CC_RD) begin
        `uvm_warning("DRV", "CC lost while attached, detaching")
        detached = 1;
      end
    end
  endtask

  // Common detach sequence back to UNATTACHED
  task detach();
    vif.drv_cb.vbus_present <= 1'b0;
    vif.drv_cb.vconn_en     <= 1'b0;
    vif.drv_cb.sbu1         <= 1'b0;
    vif.drv_cb.sbu2         <= 1'b0;
    vif.drv_cb.audio_mode   <= 1'b0;
    vif.drv_cb.debug_mode   <= 1'b0;
    set_port(typec_defs_pkg::CC_OPEN, typec_defs_pkg::CC_OPEN);
    vif.drv_cb.state        <= typec_defs_pkg::UNATTACHED;
    repeat (4) @(vif.drv_cb);
  endtask

  task run_phase(uvm_phase phase);
    typec_transaction tr;
    vif.drv_cb.state        <= typec_defs_pkg::UNATTACHED;
    vif.drv_cb.ptn_mode     <= typec_defs_pkg::PTN_SNK;
    vif.drv_cb.cc_glitch_req<= 1'b0;
    vif.drv_cb.vbus_present <= 1'b0;
    vif.drv_cb.vconn_en     <= 1'b0;
    vif.drv_cb.sbu1         <= 1'b0;
    vif.drv_cb.sbu2         <= 1'b0;
    vif.drv_cb.audio_mode   <= 1'b0;
    vif.drv_cb.debug_mode   <= 1'b0;
    set_port(typec_defs_pkg::CC_OPEN, typec_defs_pkg::CC_OPEN);
    wait (vif.rst_n === 1'b1);
    repeat (2) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)

      case (tr.role)
        // ---------------- sink: advertise Rd, wait for a source ----------
        typec_defs_pkg::ROLE_SNK: begin
          vif.drv_cb.ptn_mode <= typec_defs_pkg::PTN_SRC;
          set_port(typec_defs_pkg::CC_RD, typec_defs_pkg::CC_RD);
          wait (vif.drv_cb.cc1 == typec_defs_pkg::CC_RD);
          vif.drv_cb.state <= typec_defs_pkg::ATTACHWAIT_SNK;
          repeat (4) @(vif.drv_cb);                 // CC debounce
          vif.drv_cb.state <= typec_defs_pkg::ATTACHED_SNK;
          if (tr.err_inject == TC_ERR_BAD_VCONN) begin
            @(vif.drv_cb);
            vif.drv_cb.vconn_en <= 1'b1;            // illegal: sink sourcing vconn
            repeat (2) @(vif.drv_cb);
            vif.drv_cb.vconn_en <= 1'b0;
          end
          hold_attached(tr.pd_capable ? 12 : 6, tr.err_inject == TC_ERR_CC_GLITCH);
          detach();
        end

        // ---------------- source: advertise Rp, wait for a sink ----------
        typec_defs_pkg::ROLE_SRC: begin
          vif.drv_cb.ptn_mode <=
            tr.acc == typec_defs_pkg::ACC_AUDIO ? typec_defs_pkg::PTN_AUDIO :
            tr.acc == typec_defs_pkg::ACC_DEBUG ? typec_defs_pkg::PTN_DEBUG :
                                                  typec_defs_pkg::PTN_SNK;
          set_port(typec_defs_pkg::CC_RP,
                   tr.vconn ? typec_defs_pkg::CC_RA : typec_defs_pkg::CC_RP);
          if (tr.acc == typec_defs_pkg::ACC_AUDIO) begin
            wait (vif.drv_cb.cc1 == typec_defs_pkg::CC_RA &&
                  vif.drv_cb.cc2 == typec_defs_pkg::CC_RA);
            vif.drv_cb.state      <= typec_defs_pkg::AUDIO_ACC;
            vif.drv_cb.audio_mode <= 1'b1;
            vif.drv_cb.sbu1       <= 1'b1;
            vif.drv_cb.sbu2       <= 1'b1;
            repeat (8) @(vif.drv_cb);
            detach();
          end else if (tr.acc == typec_defs_pkg::ACC_DEBUG) begin
            wait (vif.drv_cb.cc1 == typec_defs_pkg::CC_RD &&
                  vif.drv_cb.cc2 == typec_defs_pkg::CC_RD);
            vif.drv_cb.state      <= typec_defs_pkg::DEBUG_ACC;
            vif.drv_cb.debug_mode <= 1'b1;
            repeat (8) @(vif.drv_cb);
            detach();
          end else begin
            wait (vif.drv_cb.cc1 == typec_defs_pkg::CC_RD &&
                  vif.drv_cb.cc2 != typec_defs_pkg::CC_RD);
            vif.drv_cb.state <= typec_defs_pkg::ATTACHWAIT_SNK;
            repeat (4) @(vif.drv_cb);               // CC debounce
            vif.drv_cb.state        <= typec_defs_pkg::ATTACHED_SRC;
            vif.drv_cb.vconn_en     <= tr.vconn;
            vif.drv_cb.vbus_present <= 1'b1;        // source vbus
            hold_attached(tr.pd_capable ? 12 : 6, tr.err_inject == TC_ERR_CC_GLITCH);
            detach();
          end
        end

        // ---------------- dual-role: TRY_SRC then fall back --------------
        default: begin  // ROLE_DRP
          bit src_found = 0;
          vif.drv_cb.ptn_mode <= tr.pd_capable ? typec_defs_pkg::PTN_SNK
                                               : typec_defs_pkg::PTN_SRC;
          set_port(typec_defs_pkg::CC_RP, typec_defs_pkg::CC_RP);
          vif.drv_cb.state <= typec_defs_pkg::TRY_SRC;
          repeat (8) begin
            @(vif.drv_cb);
            if (vif.drv_cb.cc1 == typec_defs_pkg::CC_RD &&
                vif.drv_cb.cc2 != typec_defs_pkg::CC_RD) begin
              src_found = 1;
              break;
            end
          end
          if (src_found) begin                      // try succeeded as source
            vif.drv_cb.state <= typec_defs_pkg::ATTACHWAIT_SNK;
            repeat (4) @(vif.drv_cb);
            vif.drv_cb.state        <= typec_defs_pkg::ATTACHED_SRC;
            vif.drv_cb.vconn_en     <= tr.vconn;
            vif.drv_cb.vbus_present <= 1'b1;
            hold_attached(6, tr.err_inject == TC_ERR_CC_GLITCH);
          end else begin                            // fall back to sink
            set_port(typec_defs_pkg::CC_RD, typec_defs_pkg::CC_RD);
            wait (vif.drv_cb.cc1 == typec_defs_pkg::CC_RD);
            vif.drv_cb.state <= typec_defs_pkg::ATTACHWAIT_SNK;
            repeat (4) @(vif.drv_cb);
            vif.drv_cb.state <= typec_defs_pkg::ATTACHED_SNK;
            hold_attached(6, tr.err_inject == TC_ERR_CC_GLITCH);
          end
          detach();
        end
      endcase

      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
