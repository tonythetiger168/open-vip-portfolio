// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// typec_transaction.svh -- Type-C transaction: one attach/detach (or
// accessory detection) cycle of the local port.

`ifndef TYPEC_TRANSACTION_SVH
`define TYPEC_TRANSACTION_SVH

class typec_transaction extends uvm_sequence_item;

  rand bit [1:0]     role;          // typec_role_e: SNK / SRC / DRP(TRY_SRC)
  rand bit [2:0]     rd_rp;         // Rp current advertisement when source
                                    // (0 = Rd pull-down, 1 = Rp default,
                                    //  2 = Rp 1.5A, 3 = Rp 3.0A)
  rand bit           pd_capable;    // stay attached longer for PD contract
  rand bit           vconn;         // supply vconn when attached as source
  rand typec_acc_e   acc;           // accessory detection target
  rand typec_err_e   err_inject;    // error class for this cycle

  // observed (monitor)
  typec_state_e      attached_as;   // state reached (ATTACHED_SNK/SRC/ACC)
  bit                vbus_seen;     // vbus was sourced while attached
  bit                vconn_seen;    // vconn_en observed while attached
  bit                glitch_seen;   // CC bounced open while attached

  constraint c_role { role inside {ROLE_SNK, ROLE_SRC, ROLE_DRP}; }
  constraint c_acc  { acc dist {ACC_NONE := 6, ACC_AUDIO := 2, ACC_DEBUG := 2};
                      acc != ACC_NONE -> role == ROLE_SRC;
                      acc != ACC_NONE -> vconn == 0; }
  constraint c_rdrp { rd_rp inside {[0:3]}; }
  constraint c_err  { err_inject dist {TC_ERR_NONE := 7,
                                       TC_ERR_CC_GLITCH := 2,
                                       TC_ERR_BAD_VCONN := 1};
                      err_inject == TC_ERR_BAD_VCONN -> role == ROLE_SNK;
                      err_inject == TC_ERR_CC_GLITCH -> acc == ACC_NONE; }

  `uvm_object_utils_begin(typec_transaction)
    `uvm_field_int(role, UVM_ALL_ON)
    `uvm_field_int(rd_rp, UVM_ALL_ON)
    `uvm_field_int(pd_capable, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(vconn, UVM_ALL_ON)
    `uvm_field_enum(typec_acc_e, acc, UVM_ALL_ON)
    `uvm_field_enum(typec_err_e, err_inject, UVM_ALL_ON)
    `uvm_field_enum(typec_state_e, attached_as, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(vbus_seen, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(vconn_seen, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(glitch_seen, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "typec_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    typec_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    // Glitchy cycles end early: compare error class instead of end state
    if (err_inject != TC_ERR_NONE || t.err_inject != TC_ERR_NONE)
      do_compare &= comparer.compare_field("err_inject", err_inject, t.err_inject, 2);
  endfunction

  function string convert2string();
    return $sformatf("TYPEC role=%0d rd_rp=%0d pd=%0b vconn=%0b acc=%s err=%s",
                     role, rd_rp, pd_capable, vconn, acc.name(),
                     err_inject.name());
  endfunction
endclass
`endif
