// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// typec_coverage.svh -- Type-C functional coverage: attach protocol (with
// crosses), port FSM (sampled from the interface) and error injection.

`ifndef TYPEC_COVERAGE_SVH
`define TYPEC_COVERAGE_SVH

class typec_coverage extends uvm_subscriber #(typec_transaction);
  `uvm_component_utils(typec_coverage)

  typec_transaction tr;
  virtual typec_if vif;

  covergroup cg_protocol;
    cp_role : coverpoint tr.role {
      bins snk = {typec_defs_pkg::ROLE_SNK};
      bins src = {typec_defs_pkg::ROLE_SRC};
      bins drp = {typec_defs_pkg::ROLE_DRP};
    }
    cp_rdrp : coverpoint tr.rd_rp {
      bins rd       = {0};
      bins rp_def   = {1};
      bins rp_1p5a  = {2};
      bins rp_3p0a  = {3};
    }
    cp_vconn: coverpoint tr.vconn { bins off = {0}; bins on = {1}; }
    cp_acc  : coverpoint tr.acc {
      bins none  = {typec_defs_pkg::ACC_NONE};
      bins audio = {typec_defs_pkg::ACC_AUDIO};
      bins debug = {typec_defs_pkg::ACC_DEBUG};
    }
    cp_end  : coverpoint tr.attached_as {
      bins snk   = {typec_defs_pkg::ATTACHED_SNK};
      bins src   = {typec_defs_pkg::ATTACHED_SRC};
      bins audio = {typec_defs_pkg::AUDIO_ACC};
      bins debug = {typec_defs_pkg::DEBUG_ACC};
    }
    cx_role_vconn : cross cp_role, cp_vconn;
    cx_role_end   : cross cp_role, cp_end {
      // unreachable pairings (sink role never ends as source/accessory,
      // pure source role never ends as sink)
      ignore_bins snk_not_snk = binsof(cp_role.snk) &&
        binsof(cp_end) intersect {typec_defs_pkg::ATTACHED_SRC,
                                  typec_defs_pkg::AUDIO_ACC,
                                  typec_defs_pkg::DEBUG_ACC};
      ignore_bins src_not_src = binsof(cp_role.src) &&
        binsof(cp_end) intersect {typec_defs_pkg::ATTACHED_SNK};
    }
  endgroup

  covergroup cg_fsm with function sample(typec_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {UNATTACHED, ATTACHWAIT_SNK, ATTACHED_SNK,
                           ATTACHED_SRC, AUDIO_ACC, DEBUG_ACC, TRY_SRC};
    }
    cp_trans : coverpoint s {
      bins snk_attach = (UNATTACHED => ATTACHWAIT_SNK => ATTACHED_SNK => UNATTACHED);
      bins src_attach = (UNATTACHED => ATTACHWAIT_SNK => ATTACHED_SRC => UNATTACHED);
      bins try_src    = (UNATTACHED => TRY_SRC => ATTACHWAIT_SNK);
      bins audio      = (UNATTACHED => AUDIO_ACC => UNATTACHED);
      bins debug      = (UNATTACHED => DEBUG_ACC => UNATTACHED);
      bins glitch_det = (ATTACHED_SNK => UNATTACHED);
      bins glitch_src = (ATTACHED_SRC => UNATTACHED);
    }
  endgroup

  covergroup cg_error;
    cp_err    : coverpoint tr.err_inject {
      bins clean   = {TC_ERR_NONE};
      bins glitch  = {TC_ERR_CC_GLITCH};
      bins vconn   = {TC_ERR_BAD_VCONN};
    }
    cp_glitch : coverpoint tr.glitch_seen { bins stable = {0}; bins bounced = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual typec_if)::get(this, "", "vif", vif));
  endfunction

  // Port FSM coverage straight from the interface; sampled only on state
  // changes so multi-cycle holds do not break transition chains
  task run_phase(uvm_phase phase);
    typec_state_e prev = typec_defs_pkg::UNATTACHED;
    if (vif == null) return;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n === 1'b1 && vif.mon_cb.state != prev)
        cg_fsm.sample(vif.mon_cb.state);
      prev = vif.mon_cb.state;
    end
  endtask

  function void write(typec_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction
endclass
`endif
