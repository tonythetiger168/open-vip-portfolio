// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// typec_pkg.sv -- USB Type-C Port Controller UVM VIP package

package typec_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import typec_defs_pkg::*;
  export typec_defs_pkg::*;

  `include "typec_transaction.svh"
  `include "typec_config.svh"
  `include "typec_sequencer.svh"
  `include "typec_driver.svh"
  `include "typec_monitor.svh"
  `include "typec_agent.svh"
  `include "typec_sequences.svh"
  `include "typec_checker.svh"
  `include "typec_coverage.svh"
endpackage
