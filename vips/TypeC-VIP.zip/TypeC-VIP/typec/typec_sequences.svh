// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// typec_sequences.svh -- USB Type-C sequence library

`ifndef TYPEC_SEQUENCES_SVH
`define TYPEC_SEQUENCES_SVH

class typec_base_sequence extends uvm_sequence #(typec_transaction);
  `uvm_object_utils(typec_base_sequence)
  int num_txns = 20;
  function new(string name = "typec_base_sequence"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: sink attach cycles (partner is a source)
class typec_snk_attach_seq extends typec_base_sequence;
  `uvm_object_utils(typec_snk_attach_seq)
  function new(string name = "typec_snk_attach_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { role == ROLE_SNK; acc == ACC_NONE;
                                  err_inject == TC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: source attach cycles (partner is a sink), full Rp range
class typec_src_attach_seq extends typec_base_sequence;
  `uvm_object_utils(typec_src_attach_seq)
  function new(string name = "typec_src_attach_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { role == ROLE_SRC; acc == ACC_NONE;
                                  err_inject == TC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: dual-role TRY_SRC (both try-succeed and sink fallback)
class typec_drp_try_src_seq extends typec_base_sequence;
  `uvm_object_utils(typec_drp_try_src_seq)
  function new(string name = "typec_drp_try_src_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { role == ROLE_DRP; acc == ACC_NONE;
                                  err_inject == TC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: audio accessory detection (Ra/Ra, SBU enabled)
class typec_audio_acc_seq extends typec_base_sequence;
  `uvm_object_utils(typec_audio_acc_seq)
  function new(string name = "typec_audio_acc_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { role == ROLE_SRC; acc == ACC_AUDIO;
                                  err_inject == TC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: debug accessory detection (Rd/Rd)
class typec_debug_acc_seq extends typec_base_sequence;
  `uvm_object_utils(typec_debug_acc_seq)
  function new(string name = "typec_debug_acc_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { role == ROLE_SRC; acc == ACC_DEBUG;
                                  err_inject == TC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: vconn sourcing while attached as source
class typec_vconn_seq extends typec_base_sequence;
  `uvm_object_utils(typec_vconn_seq)
  function new(string name = "typec_vconn_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { role == ROLE_SRC; acc == ACC_NONE;
                                  vconn == 1; err_inject == TC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: CC bounces open mid-attach (detach detection)
class typec_cc_glitch_seq extends typec_base_sequence;
  `uvm_object_utils(typec_cc_glitch_seq)
  function new(string name = "typec_cc_glitch_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { acc == ACC_NONE;
                                  err_inject == TC_ERR_CC_GLITCH; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: vconn enabled while attached as sink
class typec_bad_vconn_seq extends typec_base_sequence;
  `uvm_object_utils(typec_bad_vconn_seq)
  function new(string name = "typec_bad_vconn_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr;
    repeat (num_txns) begin
      tr = typec_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { role == ROLE_SNK; acc == ACC_NONE;
                                  err_inject == TC_ERR_BAD_VCONN; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single clean sink attach right after reset release
class typec_reset_seq extends typec_base_sequence;
  `uvm_object_utils(typec_reset_seq)
  function new(string name = "typec_reset_seq"); super.new(name); endfunction
  task body();
    typec_transaction tr = typec_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { role == ROLE_SNK; acc == ACC_NONE;
                                err_inject == TC_ERR_NONE; });
    finish_item(tr);
  endtask
endclass

class typec_random_sequence extends typec_base_sequence;
  `uvm_object_utils(typec_random_sequence)
  function new(string name = "typec_random_sequence"); super.new(name); num_txns = 40; endfunction
endclass

// Regression: weighted mix of all directed sequences
class typec_regression_sequence extends typec_base_sequence;
  `uvm_object_utils(typec_regression_sequence)
  function new(string name = "typec_regression_sequence"); super.new(name); endfunction
  task body();
    typec_snk_attach_seq  snk = typec_snk_attach_seq::type_id::create("snk");
    typec_src_attach_seq  src = typec_src_attach_seq::type_id::create("src");
    typec_drp_try_src_seq drp = typec_drp_try_src_seq::type_id::create("drp");
    typec_audio_acc_seq   aud = typec_audio_acc_seq::type_id::create("aud");
    typec_debug_acc_seq   dbg = typec_debug_acc_seq::type_id::create("dbg");
    typec_vconn_seq       vc  = typec_vconn_seq::type_id::create("vc");
    typec_cc_glitch_seq   gl  = typec_cc_glitch_seq::type_id::create("gl");
    typec_bad_vconn_seq   bv  = typec_bad_vconn_seq::type_id::create("bv");
    snk.num_txns = 10; src.num_txns = 10; drp.num_txns = 8; aud.num_txns = 4;
    dbg.num_txns = 4; vc.num_txns = 6; gl.num_txns = 4; bv.num_txns = 2;
    snk.start(m_sequencer); src.start(m_sequencer); drp.start(m_sequencer);
    aud.start(m_sequencer); dbg.start(m_sequencer); vc.start(m_sequencer);
    gl.start(m_sequencer); bv.start(m_sequencer);
  endtask
endclass
`endif
