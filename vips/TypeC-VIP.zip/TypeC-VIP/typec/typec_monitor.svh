// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// typec_monitor.svh -- Type-C monitor: observes the resolved CC levels,
// vbus/vconn/sbu and the attach FSM, and reconstructs one transaction per
// attach/detach (or accessory) cycle.

`ifndef TYPEC_MONITOR_SVH
`define TYPEC_MONITOR_SVH

class typec_monitor extends uvm_monitor;
  `uvm_component_utils(typec_monitor)
  virtual typec_if vif;
  uvm_analysis_port #(typec_transaction) ap;
  int unsigned txn_count = 0;

  protected bit          in_cycle;
  protected typec_state_e attached_as;
  protected bit          vbus_seen, vconn_seen, glitch_seen;
  protected bit          try_src_seen;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual typec_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "typec virtual interface not set")
  endfunction

  function void clear_cycle();
    in_cycle = 0;
    attached_as = typec_defs_pkg::UNATTACHED;
    vbus_seen = 0; vconn_seen = 0; glitch_seen = 0; try_src_seen = 0;
  endfunction

  task run_phase(uvm_phase phase);
    typec_transaction tr;
    typec_state_e prev = typec_defs_pkg::UNATTACHED;
    clear_cycle();
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        prev = typec_defs_pkg::UNATTACHED;
        clear_cycle();
        continue;
      end

      if (vif.mon_cb.state == typec_defs_pkg::TRY_SRC) try_src_seen = 1;

      // attach / accessory entry
      if (vif.mon_cb.state inside {typec_defs_pkg::ATTACHED_SNK,
                                   typec_defs_pkg::ATTACHED_SRC,
                                   typec_defs_pkg::AUDIO_ACC,
                                   typec_defs_pkg::DEBUG_ACC}) begin
        if (!in_cycle) begin
          in_cycle = 1;
          attached_as = vif.mon_cb.state;
        end
        if (vif.mon_cb.vbus_present) vbus_seen = 1;
        if (vif.mon_cb.vconn_en)     vconn_seen = 1;
        // attached on cc1 at Rd level: anything else is a CC loss (glitch)
        if ((vif.mon_cb.state == typec_defs_pkg::ATTACHED_SNK ||
             vif.mon_cb.state == typec_defs_pkg::ATTACHED_SRC) &&
            vif.mon_cb.cc1 != typec_defs_pkg::CC_RD)
          glitch_seen = 1;
      end

      // detach: publish the reconstructed cycle
      if (in_cycle && vif.mon_cb.state == typec_defs_pkg::UNATTACHED &&
          prev != typec_defs_pkg::UNATTACHED) begin
        tr = typec_transaction::type_id::create("tr");
        tr.attached_as = attached_as;
        tr.role        = try_src_seen ? typec_defs_pkg::ROLE_DRP :
                         attached_as == typec_defs_pkg::ATTACHED_SNK ? typec_defs_pkg::ROLE_SNK :
                         typec_defs_pkg::ROLE_SRC;
        tr.acc         = attached_as == typec_defs_pkg::AUDIO_ACC ? typec_defs_pkg::ACC_AUDIO :
                         attached_as == typec_defs_pkg::DEBUG_ACC ? typec_defs_pkg::ACC_DEBUG :
                                                                    typec_defs_pkg::ACC_NONE;
        tr.vconn       = vconn_seen;
        tr.vbus_seen   = vbus_seen;
        tr.vconn_seen  = vconn_seen;
        tr.glitch_seen = glitch_seen;
        tr.err_inject  = glitch_seen ? TC_ERR_CC_GLITCH :
                         (vconn_seen && attached_as == typec_defs_pkg::ATTACHED_SNK)
                           ? TC_ERR_BAD_VCONN : TC_ERR_NONE;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
        clear_cycle();
      end

      prev = vif.mon_cb.state;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("typec monitor observed %0d attach/detach cycles",
              txn_count), UVM_LOW)
  endfunction
endclass
`endif
