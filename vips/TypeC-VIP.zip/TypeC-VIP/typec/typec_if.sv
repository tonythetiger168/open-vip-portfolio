// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// typec_if.sv -- USB Type-C Port Controller interface
// Both CC contributors (local port and partner) are resolved onto the
// sensed cc1/cc2 levels; vbus/sbu/vconn plus the attach FSM state.

interface typec_if (input logic clk);
  import typec_defs_pkg::*;

  logic rst_n;

  // Sensed CC line levels (resolved from both contributors)
  logic [1:0] cc1;
  logic [1:0] cc2;

  // Local port (VIP driver) contribution
  logic [1:0] port_cc1;
  logic [1:0] port_cc2;

  // Partner (DUT) contribution + out-of-band personality/glitch knobs
  logic [1:0] ptn_cc1;
  logic [1:0] ptn_cc2;
  logic [1:0] ptn_mode;      // partner_mode_e
  logic       cc_glitch_req; // ask partner to bounce CC open

  logic vbus_present;        // local port sources vbus (source role only)
  logic sbu1, sbu2;          // sideband use (audio accessory)
  logic vconn_en;            // local port supplies vconn
  logic audio_mode;          // in audio accessory mode
  logic debug_mode;          // in debug accessory mode

  typec_state_e state;

  assign cc1 = cc_resolve(cc_level_e'(port_cc1), cc_level_e'(ptn_cc1));
  assign cc2 = cc_resolve(cc_level_e'(port_cc2), cc_level_e'(ptn_cc2));

  modport PORT (input  clk, rst_n, cc1, cc2,
                output port_cc1, port_cc2, ptn_mode, cc_glitch_req,
                       vbus_present, sbu1, sbu2, vconn_en,
                       audio_mode, debug_mode, state);
  modport PTN  (input  clk, rst_n, port_cc1, port_cc2, ptn_mode, cc_glitch_req,
                output ptn_cc1, ptn_cc2);
  modport MON  (input  clk, rst_n, cc1, cc2, vbus_present, sbu1, sbu2,
                       vconn_en, audio_mode, debug_mode, state);

  clocking drv_cb @(posedge clk);
    input  rst_n, cc1, cc2;
    output port_cc1, port_cc2, ptn_mode, cc_glitch_req,
           vbus_present, sbu1, sbu2, vconn_en, audio_mode, debug_mode, state;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, cc1, cc2, vbus_present, sbu1, sbu2, vconn_en,
          audio_mode, debug_mode, state;
  endclocking
endinterface
