// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// typec_compliance_checker.sv -- USB Type-C Port Controller SVA checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = Type-C attach/CC rules

`ifndef TYPEC_COMPLIANCE_CHECKER_SV
`define TYPEC_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import typec_defs_pkg::*;

module typec_compliance_checker
(
  input logic clk,
  input logic rst_n,
  input typec_state_e state,
  input logic [1:0] cc1,
  input logic [1:0] cc2,
  input logic vbus_present,
  input logic vconn_en,
  input logic audio_mode,
  input logic debug_mode
);

  // ---------------- L1: signal sanity (4) ----------------
  a_typec_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "typec: clock unknown")
  a_typec_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "typec: reset unknown")
  a_typec_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "typec: state unknown")
  a_typec_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {UNATTACHED, ATTACHWAIT_SNK, ATTACHED_SNK, ATTACHED_SRC,
                  AUDIO_ACC, DEBUG_ACC, TRY_SRC})
    else `uvm_error("SVA_L1", "typec: state outside legal encoding")

  // ---------------- L2: FSM legality (7) ----------------
  // L2-1: legal FSM transition from UNATTACHED
  a_typec_trans_unattached : assert property (@(posedge clk) disable iff (!rst_n)
    state == UNATTACHED |=> state inside {UNATTACHED, ATTACHWAIT_SNK, TRY_SRC,
                                          AUDIO_ACC, DEBUG_ACC})
    else `uvm_error("SVA_L2", "typec: illegal transition from UNATTACHED")

  // L2-2: legal FSM transition from ATTACHWAIT_SNK
  a_typec_trans_attachwait : assert property (@(posedge clk) disable iff (!rst_n)
    state == ATTACHWAIT_SNK |=> state inside {ATTACHWAIT_SNK, ATTACHED_SNK,
                                              ATTACHED_SRC, UNATTACHED})
    else `uvm_error("SVA_L2", "typec: illegal transition from ATTACHWAIT_SNK")

  // L2-3: legal FSM transition from ATTACHED_SNK
  a_typec_trans_attached_snk : assert property (@(posedge clk) disable iff (!rst_n)
    state == ATTACHED_SNK |=> state inside {ATTACHED_SNK, UNATTACHED})
    else `uvm_error("SVA_L2", "typec: illegal transition from ATTACHED_SNK")

  // L2-4: legal FSM transition from ATTACHED_SRC
  a_typec_trans_attached_src : assert property (@(posedge clk) disable iff (!rst_n)
    state == ATTACHED_SRC |=> state inside {ATTACHED_SRC, UNATTACHED})
    else `uvm_error("SVA_L2", "typec: illegal transition from ATTACHED_SRC")

  // L2-5: legal FSM transition from AUDIO_ACC
  a_typec_trans_audio : assert property (@(posedge clk) disable iff (!rst_n)
    state == AUDIO_ACC |=> state inside {AUDIO_ACC, UNATTACHED})
    else `uvm_error("SVA_L2", "typec: illegal transition from AUDIO_ACC")

  // L2-6: legal FSM transition from DEBUG_ACC
  a_typec_trans_debug : assert property (@(posedge clk) disable iff (!rst_n)
    state == DEBUG_ACC |=> state inside {DEBUG_ACC, UNATTACHED})
    else `uvm_error("SVA_L2", "typec: illegal transition from DEBUG_ACC")

  // L2-7: legal FSM transition from TRY_SRC
  a_typec_trans_try_src : assert property (@(posedge clk) disable iff (!rst_n)
    state == TRY_SRC |=> state inside {TRY_SRC, ATTACHWAIT_SNK, UNATTACHED})
    else `uvm_error("SVA_L2", "typec: illegal transition from TRY_SRC")

  // ---------------- L3: protocol rules (4) ----------------
  a_typec_l3_reset_unattached : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == UNATTACHED))
    else `uvm_error("SVA_L3", "typec: state not UNATTACHED during reset")
  a_typec_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == ATTACHED_SRC |-> ##[1:32] (state != ATTACHED_SRC))
    else `uvm_error("SVA_L3", "typec: stuck in ATTACHED_SRC")
  a_typec_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == UNATTACHED ##1 state == ATTACHWAIT_SNK);
  a_typec_l3_back_unattached : cover property (@(posedge clk) disable iff (!rst_n)
    state == ATTACHED_SRC ##1 state == UNATTACHED);

  // ---------------- L4: Type-C attach/CC rules (6) ----------------
  // L4-1: sink attach must pass through attachwait (CC debounce)
  a_typec_l4_snk_attachwait : assert property (@(posedge clk) disable iff (!rst_n)
    $rose(state == ATTACHED_SNK) |-> $past(state == ATTACHWAIT_SNK))
    else `uvm_error("SVA_L4", "typec: ATTACHED_SNK without ATTACHWAIT_SNK")

  // L4-2: source attach must pass through attachwait (CC debounce)
  a_typec_l4_src_attachwait : assert property (@(posedge clk) disable iff (!rst_n)
    $rose(state == ATTACHED_SRC) |-> $past(state == ATTACHWAIT_SNK))
    else `uvm_error("SVA_L4", "typec: ATTACHED_SRC without ATTACHWAIT_SNK")

  // L4-3: vbus is sourced only while attached as source
  a_typec_l4_vbus_src : assert property (@(posedge clk) disable iff (!rst_n)
    vbus_present |-> state == ATTACHED_SRC)
    else `uvm_error("SVA_L4", "typec: vbus sourced outside ATTACHED_SRC")

  // L4-4: CC open while attached forces detach to UNATTACHED
  a_typec_l4_detach_open : assert property (@(posedge clk) disable iff (!rst_n)
    (state inside {ATTACHED_SNK, ATTACHED_SRC} && cc1 == CC_OPEN)
      |-> ##[1:8] (state == UNATTACHED))
    else `uvm_error("SVA_L4", "typec: CC open did not detach to UNATTACHED")

  // L4-5: audio and debug accessory modes are mutually exclusive
  a_typec_l4_acc_mutex : assert property (@(posedge clk) disable iff (!rst_n)
    !(audio_mode && debug_mode))
    else `uvm_error("SVA_L4", "typec: audio and debug accessory both active")
  a_typec_l4_acc_no_switch : assert property (@(posedge clk) disable iff (!rst_n)
    state == AUDIO_ACC |=> state != DEBUG_ACC)
    else `uvm_error("SVA_L4", "typec: audio accessory switched straight to debug")

endmodule
`endif
