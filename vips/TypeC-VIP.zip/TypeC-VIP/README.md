# TypeC — USB Type-C Port Controller UVM VIP

Open-source UVM verification IP template for **USB Type-C Port Controller** (Interface).

## Contents

| Path | Description |
|------|-------------|
| `typec/typec_if.sv` | CC/vbus/sbu/vconn interface with wired-CC resolution + modports/clocking |
| `typec/typec_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `typec/sva/typec_compliance_checker.sv` | SVA compliance checker (L1=4, L2=7, L3=4, L4=6) |
| `typec/vip/typec/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/typec_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional port-partner DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **CC attach state-machine driver**: UNATTACHED -> ATTACHWAIT_SNK (debounce)
  -> ATTACHED_SNK / ATTACHED_SRC, TRY_SRC with sink fallback, AUDIO_ACC
  (Ra/Ra + SBU) and DEBUG_ACC (Rd/Rd) detection; vbus sourced only as
  source; vconn control with cable-power modeling
- **Wired-CC resolution model** (`typec_defs_pkg`): 2-bit voltage-level
  encoding (Open/Rd/Ra/Rp) with a resolution function combining local-port
  and partner pulls into the sensed line level
- **Attach-cycle monitor**: observes resolved CC levels, vbus/vconn and the
  port FSM; reconstructs one transaction per attach/detach cycle with CC
  glitch (bounce) and illegal-vconn classification
- **End-to-end scoreboard**: expected end state derived from role/accessory
  intent (incl. DRP try result) vs observed attach state, vbus and vconn
  behavior; error cycles compared by error class
- **Functional DUT model**: port partner presenting Rd/Rp/Ra per personality
  (sink / source / audio accessory / debug accessory) and bouncing CC open
  on request (detach error injection)
- **Directed sequence library**: sink / source / drp try-src / audio / debug /
  vconn / cc-glitch / bad-vconn / reset + random + regression mix
- **Functional coverage**: role x vconn and role x end-state crosses (with
  unreachable-pair ignore bins), port FSM chains (snk/src attach, try-src,
  accessories, glitch detaches), error-class bins
- **SVA L4**: attach requires attachwait (snk + src), vbus only in
  ATTACHED_SRC, CC open forces detach to UNATTACHED, audio/debug accessory
  modes mutually exclusive (level + no direct switch)
