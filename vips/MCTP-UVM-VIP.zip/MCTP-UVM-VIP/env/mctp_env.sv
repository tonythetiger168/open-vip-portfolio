// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_env.sv -- MCTP over SMBus environment: reference-model scoreboard, checker, coverage

package mctp_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import mctp_defs_pkg::*;
  import mctp_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class mctp_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(mctp_scoreboard)
    uvm_analysis_imp_exp #(mctp_transaction, mctp_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(mctp_transaction, mctp_scoreboard) obs_ap;

    mctp_config cfg;
    mctp_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(mctp_config)::get(this, "", "cfg", cfg))
        cfg = mctp_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(mctp_transaction t);
      bit [31:0] c = 32'hFFFF_FFFF;
      int unsigned np = t.npkt();
      t.err = 0;
      if (!(t.deid inside {8'h1D, 8'h00, 8'hFF})) t.err = 8;
      else if (t.bad_pkt < np && (t.skip_pkt >= np || t.bad_pkt <= t.skip_pkt)) t.err = 1;
      else if (t.skip_pkt < np) t.err = 2;
      // the endpoint reports the header fields of the message it saw; the length
      // and CRC only for a complete message
      t.rtype = t.mtype; t.rseid = MCTP_SRC_EID; t.rtag = t.mtag; t.rto = t.to;
      t.rlen = 0; t.rcrc = 0;
      if (t.err == 0) begin
        foreach (t.payload[i]) c = crc32_byte(c, t.payload[i]);
        t.rlen = t.payload.size(); t.rcrc = ~c;
      end
    endfunction

    function void write_exp(mctp_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(mctp_transaction t);
      mctp_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        mctp_transaction e = exp_q.pop_front();
        mctp_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("mctp scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class mctp_env extends uvm_env;
    `uvm_component_utils(mctp_env)
    mctp_agent      agt;
    mctp_scoreboard sb;
    mctp_checker    chk;
    mctp_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = mctp_agent     ::type_id::create("agt", this);
      sb  = mctp_scoreboard::type_id::create("sb",  this);
      chk = mctp_checker   ::type_id::create("chk", this);
      cov = mctp_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
