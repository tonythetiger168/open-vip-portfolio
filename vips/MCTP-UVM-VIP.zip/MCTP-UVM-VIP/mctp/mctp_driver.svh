// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_driver.svh -- MCTP over SMBus driver: splits each message into SMBus block-write packets (SOM / EOM, sequence numbers, PEC) and drives them bit by bit on the open-drain bus

class mctp_driver extends uvm_driver #(mctp_transaction);
  `uvm_component_utils(mctp_driver)

  uvm_analysis_port #(mctp_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual mctp_if vif;
  mctp_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual mctp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "mctp: virtual interface not set")
    if (!uvm_config_db#(mctp_config)::get(this, "", "cfg", cfg))
      cfg = mctp_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    mctp_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.scl_m <= 1'b1;
    vif.drv_cb.sda_m <= 1'b1;
  endtask

  task drive_item(mctp_transaction t);
    bit [7:0] msg[$];
    int unsigned np, off = 0;
    bit [1:0] seq = t.seq0;
    msg.push_back(t.mtype);
    foreach (t.payload[i]) msg.push_back(t.payload[i]);
    np = (msg.size() + cfg.mtu - 1) / cfg.mtu;
    for (int unsigned p = 0; p < np; p++) begin
      bit [7:0] pk[$];
      bit [7:0] crc = 0;
      int unsigned n = (msg.size() - off < cfg.mtu) ? msg.size() - off : cfg.mtu;
      bit ack;
      if (p == t.skip_pkt) seq++;
      pk.push_back({MCTP_DEV_ADDR, 1'b0});
      pk.push_back(8'h0F);                                   // MCTP command code
      pk.push_back(8'(n + 5));                               // byte count
      pk.push_back({MCTP_SRC_ADDR, 1'b1});                   // source slave address
      pk.push_back(8'h01);                                   // header version 1
      pk.push_back(t.deid);
      pk.push_back(MCTP_SRC_EID);
      pk.push_back({p == 0, p == np - 1, seq, t.to, t.mtag});
      for (int unsigned i = 0; i < n; i++) pk.push_back(msg[off + i]);
      foreach (pk[i]) crc = crc8(crc, pk[i]);
      pk.push_back(crc ^ {7'h0, p == t.bad_pkt});
      off += n; seq++;
      // START, bytes, STOP
      @(vif.drv_cb);
      vif.drv_cb.sda_m <= 1'b0; wait_clk(cfg.half);
      vif.drv_cb.scl_m <= 1'b0; wait_clk(cfg.half / 2);
      foreach (pk[i]) begin
        wr_byte(pk[i], ack);
        if (!ack) `uvm_error("DRV", $sformatf("MCTP/SMBus: byte %0d of packet %0d NACKed", i, p))
      end
      vif.drv_cb.sda_m <= 1'b0; wait_clk(cfg.half / 2);
      scl_high(); wait_clk(cfg.half);
      vif.drv_cb.sda_m <= 1'b1; wait_clk(3 * cfg.half);
    end
  endtask

  task wait_clk(int unsigned n); repeat (n) @(vif.drv_cb); endtask
  task scl_high();
    int unsigned to = 0;
    vif.drv_cb.scl_m <= 1'b1;
    @(vif.drv_cb);
    while (vif.drv_cb.scl !== 1'b1 && to < cfg.timeout_cycles) begin @(vif.drv_cb); to++; end
    if (vif.drv_cb.scl !== 1'b1) `uvm_error("TIMEOUT", "MCTP/SMBus: SCL held low")
  endtask
  task bit_xfer(bit out, output bit in);
    vif.drv_cb.sda_m <= out; wait_clk(cfg.half / 2);
    scl_high(); wait_clk(cfg.half / 2);
    in = vif.drv_cb.sda;
    wait_clk(cfg.half / 2);
    vif.drv_cb.scl_m <= 1'b0; wait_clk(cfg.half / 2);
  endtask
  task wr_byte(bit [7:0] b, output bit ack);
    bit in;
    for (int i = 7; i >= 0; i--) bit_xfer(b[i], in);
    bit_xfer(1'b1, in);
    ack = !in;
  endtask
endclass
