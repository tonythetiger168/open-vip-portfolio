// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_defs.sv -- MCTP over SMBus shared type definitions

package mctp_defs_pkg;

  typedef enum bit [1:0] {MCTP_OK, MCTP_ERR} mctp_status_e;

  // SMBus PEC: CRC-8, x^8 + x^2 + x + 1, init 0, MSB first
  function automatic bit [7:0] crc8(bit [7:0] c, bit [7:0] b);
    c ^= b;
    for (int k = 0; k < 8; k++) c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
    return c;
  endfunction
  // IEEE CRC-32 step (reflected), for the payload fingerprint
  function automatic bit [31:0] crc32_byte(bit [31:0] c, bit [7:0] b);
    c ^= {24'h0, b};
    for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    return c;
  endfunction
  localparam bit [6:0] MCTP_DEV_ADDR = 7'h1D;
  localparam bit [7:0] MCTP_DEV_EID  = 8'h1D;
  localparam bit [6:0] MCTP_SRC_ADDR = 7'h10;
  localparam bit [7:0] MCTP_SRC_EID  = 8'h08;

endpackage
