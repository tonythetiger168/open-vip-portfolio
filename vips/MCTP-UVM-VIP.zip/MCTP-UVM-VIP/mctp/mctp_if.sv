// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_if.sv -- MCTP over SMBus interface

// Open-drain bus: each side pulls low (0) or releases (1).
interface mctp_if (input logic clk);
  logic rst_n;

  logic scl_m, sda_m;     // agent side
  logic scl_o, sda_o;     // endpoint (DUT) side
  logic rep_valid;
  logic [7:0] rep_type, rep_len, rep_seid;
  logic [31:0] rep_crc;
  logic [2:0] rep_tag;
  logic rep_to;
  logic [3:0] rep_err;
  wire  scl = scl_m & scl_o;
  wire  sda = sda_m & sda_o;

  clocking drv_cb @(posedge clk);
    input rst_n, scl, sda;
    inout scl_m, sda_m;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, scl, sda, rep_valid, rep_type, rep_len, rep_seid, rep_crc, rep_tag, rep_to, rep_err;
  endclocking
endinterface
