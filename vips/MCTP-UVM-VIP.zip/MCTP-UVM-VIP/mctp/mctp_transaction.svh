// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_transaction.svh -- MCTP over SMBus transaction

class mctp_transaction extends uvm_sequence_item;
  `uvm_object_utils(mctp_transaction)

  // request (driven by the agent)
  rand bit [7:0] deid;
  rand bit [7:0] mtype;
  rand bit [2:0] mtag;
  rand bit to;
  bit [7:0] payload[$];
  rand bit [3:0] bad_pkt;
  rand bit [3:0] skip_pkt;
  rand bit [1:0] seq0;
  // response (returned by the DUT)
  bit [7:0] rlen;
  bit [31:0] rcrc;
  bit [7:0] rtype;
  bit [7:0] rseid;
  bit [2:0] rtag;
  bit rto;
  bit [3:0] err;
  // bookkeeping (not compared)
  rand bit [5:0] nbytes;
  rand bit [31:0] seed;
  rand bit [1:0] fault;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_eid  { deid dist { 8'h1D := 12, 8'hFF := 2, 8'h00 := 2, 8'h42 := 1 }; }
  constraint c_type { mtype dist { 8'h00 := 3, 8'h01 := 2, 8'h02 := 1, 8'h04 := 2, 8'h05 := 2, 8'h7E := 1, 8'h7F := 1 }; }
  constraint c_len  { nbytes inside {[0:47]}; fault dist { 0 := 6, 1 := 1, 2 := 1 }; }

  function new(string name = "mctp_transaction"); super.new(name); endfunction

  function int unsigned npkt(int unsigned mtu = 16);
    return (payload.size() + 1 + mtu - 1) / mtu;     // the type byte is message byte 0
  endfunction

  function void post_randomize();
    bit [31:0] x = seed | 32'h1;
    payload.delete();
    for (int unsigned i = 0; i < nbytes; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      payload.push_back(x[7:0]);
    end
    bad_pkt = 15; skip_pkt = 15;
    if (fault == 1) bad_pkt = x[11:8] % npkt();
    if (fault == 2 && npkt() > 1) skip_pkt = 1 + x[15:12] % (npkt() - 1);
  endfunction

  function void do_copy(uvm_object rhs);
    mctp_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    deid = rhs_.deid;
    mtype = rhs_.mtype;
    mtag = rhs_.mtag;
    to = rhs_.to;
    payload = rhs_.payload;
    bad_pkt = rhs_.bad_pkt;
    skip_pkt = rhs_.skip_pkt;
    seq0 = rhs_.seq0;
    rlen = rhs_.rlen;
    rcrc = rhs_.rcrc;
    rtype = rhs_.rtype;
    rseid = rhs_.rseid;
    rtag = rhs_.rtag;
    rto = rhs_.rto;
    err = rhs_.err;
    nbytes = rhs_.nbytes;
    seed = rhs_.seed;
    fault = rhs_.fault;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    mctp_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (deid != rhs_.deid) return 0;
    if (mtype != rhs_.mtype) return 0;
    if (mtag != rhs_.mtag) return 0;
    if (to != rhs_.to) return 0;
    if (payload.size() != rhs_.payload.size()) return 0;
    foreach (payload[i]) if (payload[i] != rhs_.payload[i]) return 0;
    if (bad_pkt != rhs_.bad_pkt) return 0;
    if (skip_pkt != rhs_.skip_pkt) return 0;
    if (seq0 != rhs_.seq0) return 0;
    if (rlen != rhs_.rlen) return 0;
    if (rcrc != rhs_.rcrc) return 0;
    if (rtype != rhs_.rtype) return 0;
    if (rseid != rhs_.rseid) return 0;
    if (rtag != rhs_.rtag) return 0;
    if (rto != rhs_.rto) return 0;
    if (err != rhs_.err) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(mctp_transaction rhs_);
    if (deid != rhs_.deid) return 0;
    if (mtype != rhs_.mtype) return 0;
    if (mtag != rhs_.mtag) return 0;
    if (to != rhs_.to) return 0;
    if (payload.size() != rhs_.payload.size()) return 0;
    foreach (payload[i]) if (payload[i] != rhs_.payload[i]) return 0;
    if (bad_pkt != rhs_.bad_pkt) return 0;
    if (skip_pkt != rhs_.skip_pkt) return 0;
    if (seq0 != rhs_.seq0) return 0;
    return 1;
  endfunction

  function string qstr_payload();
    string s = $sformatf("[%0d]{", payload.size());
    foreach (payload[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", payload[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("MCTP over SMBus{tag=%0d deid=0x%0h mtype=0x%0h mtag=0x%0h to=0x%0h payload=%s bad_pkt=0x%0h skip_pkt=0x%0h seq0=0x%0h rlen=0x%0h rcrc=0x%0h rtype=0x%0h rseid=0x%0h rtag=0x%0h rto=0x%0h err=0x%0h}", tag, deid, mtype, mtag, to, qstr_payload(), bad_pkt, skip_pkt, seq0, rlen, rcrc, rtype, rseid, rtag, rto, err);
  endfunction
endclass
