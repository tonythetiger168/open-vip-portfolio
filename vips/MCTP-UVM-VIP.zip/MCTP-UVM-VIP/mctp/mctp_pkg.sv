// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_pkg.sv -- MCTP over SMBus UVM VIP package

package mctp_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import mctp_defs_pkg::*;
  export mctp_defs_pkg::*;

  `include "mctp_transaction.svh"
  `include "mctp_config.svh"
  `include "mctp_sequencer.svh"
  `include "mctp_driver.svh"
  `include "mctp_monitor.svh"
  `include "mctp_agent.svh"
  `include "mctp_sequences.svh"
  `include "mctp_checker.svh"
  `include "mctp_coverage.svh"
endpackage
