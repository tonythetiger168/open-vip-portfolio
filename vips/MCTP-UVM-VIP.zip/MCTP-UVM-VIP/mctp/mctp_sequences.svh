// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_sequences.svh -- MCTP over SMBus sequences

// Random traffic: cfg.num_items constrained-random items.
class mctp_base_sequence extends uvm_sequence #(mctp_transaction);
  `uvm_object_utils(mctp_base_sequence)
  mctp_config cfg;

  function new(string name = "mctp_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = mctp_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "mctp_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class mctp_directed_sequence extends uvm_sequence #(mctp_transaction);
  `uvm_object_utils(mctp_directed_sequence)
  mctp_config cfg;

  function new(string name = "mctp_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function mctp_transaction item();
    item = mctp_transaction::type_id::create("req");
  endfunction

  task send(mctp_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    mctp_transaction t;
    // the CRC-32 check string in one packet, every sequence start, a message of
    // exactly one packet payload, then two / three packets, broadcast and null
    // EIDs, a message for another endpoint, and planted PEC / sequence faults
    begin
      string cv = "123456789";
      t = item(); t.deid = 8'h1D; t.mtype = 8'h7E; t.bad_pkt = 15; t.skip_pkt = 15;
      foreach (cv[i]) t.payload.push_back(cv[i]);
      send(t);
    end
    for (int s = 0; s < 4; s++) begin
      t = item(); t.deid = 8'h1D; t.mtype = 8'h01; t.seq0 = s; t.mtag = s; t.to = s[0]; t.bad_pkt = 15; t.skip_pkt = 15;
      repeat (15 + 16 * s[0]) t.payload.push_back(8'(s * 7));
      send(t);
    end
    t = item(); t.deid = 8'hFF; t.mtype = 8'h00; t.payload = '{8'h80, 8'h02}; t.bad_pkt = 15; t.skip_pkt = 15; send(t);
    t = item(); t.deid = 8'h00; t.mtype = 8'h00; t.payload = '{8'h80, 8'h01, 8'h00, 8'h1D}; t.bad_pkt = 15; t.skip_pkt = 15; send(t);
    t = item(); t.deid = 8'h33; t.mtype = 8'h05; repeat (20) t.payload.push_back(8'h5A); t.bad_pkt = 15; t.skip_pkt = 15; send(t);
    t = item(); t.deid = 8'h1D; t.mtype = 8'h05; repeat (40) t.payload.push_back(8'hA5); t.bad_pkt = 0; t.skip_pkt = 15; send(t);
    t = item(); t.deid = 8'h1D; t.mtype = 8'h05; repeat (40) t.payload.push_back(8'hA5); t.bad_pkt = 2; t.skip_pkt = 15; send(t);
    t = item(); t.deid = 8'h1D; t.mtype = 8'h04; repeat (40) t.payload.push_back(8'h3C); t.bad_pkt = 15; t.skip_pkt = 1; send(t);
    t = item(); t.deid = 8'h1D; t.mtype = 8'h04; repeat (40) t.payload.push_back(8'h3C); t.bad_pkt = 15; t.skip_pkt = 2; send(t);
    t = item(); t.deid = 8'h1D; t.mtype = 8'h00; t.bad_pkt = 15; t.skip_pkt = 15; send(t);   // type byte only
  endtask
endclass
