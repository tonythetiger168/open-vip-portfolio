// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_compliance_checker.sv -- MCTP over SMBus concurrent assertion checks (bindable)

module mctp_compliance_checker
  (input logic clk, input logic rst_n, input logic scl, input logic sda, input logic scl_o, input logic sda_o, input logic rep_valid, input logic [7:0] rep_type, input logic [7:0] rep_len, input logic [7:0] rep_seid, input logic [31:0] rep_crc, input logic [2:0] rep_tag, input logic rep_to, input logic [3:0] rep_err);

  logic scl_d, sda_d;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin scl_d <= 1'b1; sda_d <= 1'b1; end else begin scl_d <= scl; sda_d <= sda; end
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({scl, sda, rep_valid}))
    else $error("MCTP/SMBus: X on SCL / SDA / report");
  // the endpoint never pulls SCL low (no stretching) and only drives SDA low while SCL is low or for an ACK
  assert property (@(posedge clk) disable iff (!rst_n) scl_o)
    else $error("MCTP/SMBus: endpoint holds SCL");
  // SDA from the endpoint does not change while SCL is high
  assert property (@(posedge clk) disable iff (!rst_n) scl && scl_d |-> $stable(sda_o))
    else $error("MCTP/SMBus: endpoint changed SDA while SCL high");
  // a report only follows a STOP
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |-> $past(scl && sda && !sda_d))
    else $error("MCTP: report without a STOP");
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_err == 0 && rep_len > 15);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_err == 1);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_err == 2);
endmodule
