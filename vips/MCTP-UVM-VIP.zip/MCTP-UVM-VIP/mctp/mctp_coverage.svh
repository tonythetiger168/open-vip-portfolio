// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_coverage.svh -- MCTP over SMBus functional coverage

class mctp_coverage extends uvm_subscriber #(mctp_transaction);
  `uvm_component_utils(mctp_coverage)
  mctp_config cfg;
  mctp_transaction tr;

  covergroup mctp_cg;
    cp_npkt : coverpoint tr.npkt() { bins one = {1}; bins two = {2}; bins more = {[3:4]}; }
    cp_type : coverpoint tr.mtype { bins control = {0}; bins pldm = {1}; bins ncsi = {2}; bins nvme = {4}; bins spdm = {5}; bins vdm = {[8'h7E:8'h7F]}; bins other = default; }
    cp_eid  : coverpoint tr.deid { bins mine = {8'h1D}; bins null_ = {0}; bins bcast = {8'hFF}; bins other = default; }
    cp_err  : coverpoint tr.err { bins ok = {0}; bins pec = {1}; bins seq = {2}; bins eid = {8}; }
    cp_seq0 : coverpoint tr.seq0;
    x_err_n : cross cp_err, cp_npkt { ignore_bins one_seq = binsof(cp_err.seq) && binsof(cp_npkt.one); ignore_bins eid_n = binsof(cp_err.eid) && !binsof(cp_npkt.one); }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    mctp_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(mctp_config)::get(this, "", "cfg", cfg))
      cfg = mctp_config::type_id::create("cfg");
  endfunction

  function void write(mctp_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    mctp_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("MCTP over SMBus coverage: %0.1f%%", mctp_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
