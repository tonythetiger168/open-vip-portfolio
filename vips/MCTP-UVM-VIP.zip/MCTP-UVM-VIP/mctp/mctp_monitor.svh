// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mctp_monitor.svh -- MCTP over SMBus monitor: SMBus packets decoded from the SCL/SDA wires, joined into MCTP messages by SOM / EOM; completed by the endpoint's report

class mctp_monitor extends uvm_monitor;
  `uvm_component_utils(mctp_monitor)

  virtual mctp_if vif;
  uvm_analysis_port #(mctp_transaction) ap;
  mctp_config cfg;
  int unsigned n_obs = 0;

  mctp_transaction cur, msg_q[$], rep_q[$]; bit [7:0] pk[$]; int unsigned npk; bit [1:0] seq_exp;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual mctp_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "mctp: virtual interface not set")
    if (!uvm_config_db#(mctp_config)::get(this, "", "cfg", cfg))
      cfg = mctp_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit scl_p = 1, sda_p = 1, in_xfer = 0;
      int unsigned nbit = 0;
      bit [7:0] sh = 0;
      forever begin
        bit scl, sda;
        @(vif.mon_cb);
        scl = vif.mon_cb.scl; sda = vif.mon_cb.sda;
        if (vif.mon_cb.rep_valid) begin
          mctp_transaction r = mctp_transaction::type_id::create("r");
          r.rtype = vif.mon_cb.rep_type; r.rlen = vif.mon_cb.rep_len; r.rcrc = vif.mon_cb.rep_crc;
          r.rseid = vif.mon_cb.rep_seid; r.rtag = vif.mon_cb.rep_tag; r.rto = vif.mon_cb.rep_to;
          r.err = vif.mon_cb.rep_err;
          rep_q.push_back(r);
        end
        if (scl && scl_p && sda_p && !sda) begin in_xfer = 1; nbit = 0; pk.delete(); end
        else if (scl && scl_p && !sda_p && sda) begin
          if (in_xfer) packet();
          in_xfer = 0;
        end else if (in_xfer && scl && !scl_p) begin
          if (nbit < 8) sh = {sh[6:0], sda}; else pk.push_back(sh);
          nbit = (nbit == 8) ? 0 : nbit + 1;
        end
        scl_p = scl; sda_p = sda;
        while (msg_q.size() != 0 && rep_q.size() != 0) begin
          mctp_transaction t = msg_q.pop_front(), r = rep_q.pop_front();
          t.rtype = r.rtype; t.rlen = r.rlen; t.rcrc = r.rcrc; t.rseid = r.rseid; t.rtag = r.rtag; t.rto = r.rto;
          t.err = r.err;
          publish(t);
        end
      end
    end
  endtask

  function void publish(mctp_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // one SMBus packet: header fields, the PEC, the sequence number
  function void packet();
    bit [7:0] crc = 0;
    bit som, eom;
    bit [1:0] seq;
    if (pk.size() < 9) begin
      `uvm_error("MON", $sformatf("MCTP: packet of %0d bytes", pk.size()))
      return;
    end
    for (int i = 0; i + 1 < pk.size(); i++) crc = crc8(crc, pk[i]);
    som = pk[7][7]; eom = pk[7][6]; seq = pk[7][5:4];
    if (som) begin
      cur = mctp_transaction::type_id::create("t");
      cur.deid = pk[5]; cur.mtag = pk[7][2:0]; cur.to = pk[7][3]; cur.seq0 = seq;
      cur.mtype = pk[8]; cur.bad_pkt = 15; cur.skip_pkt = 15;
      npk = 0; seq_exp = seq;
    end
    if (cur == null) begin
      `uvm_error("MON", "MCTP: packet without SOM before it")
      return;
    end
    if (seq != seq_exp && cur.skip_pkt == 15) cur.skip_pkt = npk;
    if (pk[pk.size() - 1] != crc && cur.bad_pkt == 15) cur.bad_pkt = npk;
    for (int i = som ? 9 : 8; i + 1 < pk.size(); i++) cur.payload.push_back(pk[i]);
    if (pk[1] != 8'h0F || pk[2] != pk.size() - 4 || pk[4] != 8'h01 || pk[0] != {MCTP_DEV_ADDR, 1'b0})
      `uvm_error("MON", "MCTP: packet format (command code, byte count, version or address)")
    seq_exp = seq + 1; npk++;
    if (eom) begin msg_q.push_back(cur); cur = null; end
  endfunction
endclass
