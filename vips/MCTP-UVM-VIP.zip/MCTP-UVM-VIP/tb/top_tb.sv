// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- MCTP over SMBus testbench top with a functional MCTP over SMBus DUT model

`ifndef MCTP_UVM_VIP_TB_SV
`define MCTP_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import mctp_defs_pkg::*;
import mctp_pkg::*;
import mctp_env_pkg::*;
import mctp_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  mctp_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  mctp_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .scl(vif.scl),
    .sda(vif.sda),
    .scl_o(vif.scl_o),
    .sda_o(vif.sda_o),
    .rep_valid(vif.rep_valid),
    .rep_type(vif.rep_type),
    .rep_len(vif.rep_len),
    .rep_seid(vif.rep_seid),
    .rep_crc(vif.rep_crc),
    .rep_tag(vif.rep_tag),
    .rep_to(vif.rep_to),
    .rep_err(vif.rep_err)
  );

  // Concurrent protocol checks
  mctp_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .scl(vif.scl),
    .sda(vif.sda),
    .scl_o(vif.scl_o),
    .sda_o(vif.sda_o),
    .rep_valid(vif.rep_valid),
    .rep_type(vif.rep_type),
    .rep_len(vif.rep_len),
    .rep_seid(vif.rep_seid),
    .rep_crc(vif.rep_crc),
    .rep_tag(vif.rep_tag),
    .rep_to(vif.rep_to),
    .rep_err(vif.rep_err)
  );

  initial begin
    uvm_config_db#(virtual mctp_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module mctp_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        scl,
  input  logic        sda,
  output logic        scl_o,
  output logic        sda_o,
  output logic        rep_valid,
  output logic [7:0]  rep_type,
  output logic [7:0]  rep_len,
  output logic [7:0]  rep_seid,
  output logic [31:0] rep_crc,
  output logic [2:0]  rep_tag,
  output logic        rep_to,
  output logic [3:0]  rep_err
);
  localparam logic [6:0] ADDR = 7'h1D;
  localparam logic [7:0] EID  = 8'h1D;
  logic scl_d, sda_d, active, mine;
  logic [3:0] nbit;
  logic [7:0] sh, nb, cnt, pec;
  // packet fields
  logic [7:0] f_cmd, f_src, f_ver, f_deid, f_seid, f_flags, f_last, f_type;
  // message assembly
  logic        asm_on, dropping;
  logic [1:0]  seq_exp;
  logic [7:0]  m_len, m_type, m_seid;
  logic [2:0]  m_tag;
  logic        m_to;
  logic [31:0] m_crc, p_crc;
  logic [7:0]  p_len;

  function automatic logic [7:0] crc8(input logic [7:0] c, input logic [7:0] b);
    c = c ^ b;
    for (int k = 0; k < 8; k++) c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
    return c;
  endfunction
  function automatic logic [31:0] crc32_byte(input logic [31:0] c, input logic [7:0] b);
    c = c ^ {24'h0, b};
    for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    return c;
  endfunction

  assign scl_o = 1'b1;

  wire start_c = scl && scl_d && sda_d && !sda;
  wire stop_c  = scl && scl_d && !sda_d && sda;
  wire scl_r   = scl && !scl_d;
  wire scl_f   = !scl && scl_d;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      scl_d <= 1'b1; sda_d <= 1'b1; active <= 1'b0; mine <= 1'b0; nbit <= '0; sh <= '0; nb <= '0;
      cnt <= '0; pec <= '0; sda_o <= 1'b1;
      f_cmd <= '0; f_src <= '0; f_ver <= '0; f_deid <= '0; f_seid <= '0; f_flags <= '0; f_last <= '0; f_type <= '0;
      asm_on <= 1'b0; dropping <= 1'b0; seq_exp <= '0; m_len <= '0; m_type <= '0; m_seid <= '0;
      m_tag <= '0; m_to <= 1'b0; m_crc <= '1; p_crc <= '1; p_len <= '0;
      rep_valid <= 1'b0; rep_type <= '0; rep_len <= '0; rep_seid <= '0; rep_crc <= '0; rep_tag <= '0;
      rep_to <= 1'b0; rep_err <= '0;
    end else begin
      scl_d <= scl; sda_d <= sda;
      rep_valid <= 1'b0;
      if (start_c) begin
        active <= 1'b1; mine <= 1'b0; nbit <= '0; nb <= '0; pec <= '0; p_len <= '0; sda_o <= 1'b1;
      end else if (stop_c) begin
        active <= 1'b0; sda_o <= 1'b1;
        if (mine) begin : pkt_end
          logic som, eom;
          logic [3:0] e;
          som = f_flags[7]; eom = f_flags[6];
          e = 4'd0;
          if (f_cmd != 8'h0F || cnt != nb - 8'd4 || f_ver != 8'h01 || !f_src[0]) e = 4'd4;
          else if (pec != 8'h00) e = 4'd1;                 // PEC folded in: residue 0
          if (som) begin
            if (!(f_deid == EID || f_deid == 8'h00 || f_deid == 8'hFF) && e == 0) e = 4'd8;
            m_type <= f_type; m_seid <= f_seid; m_tag <= f_flags[2:0]; m_to <= f_flags[3];
          end else if (!asm_on) e = 4'd0;                  // the rest of a dropped message
          else if (f_flags[5:4] != seq_exp && e == 0) e = 4'd2;
          if (som || asm_on) begin
            if (e != 0) begin
              asm_on <= 1'b0;
              rep_valid <= 1'b1; rep_err <= e; rep_len <= '0; rep_crc <= '0;
              rep_type <= som ? f_type : m_type; rep_seid <= som ? f_seid : m_seid;
              rep_tag <= som ? f_flags[2:0] : m_tag; rep_to <= som ? f_flags[3] : m_to;
            end else begin
              logic [31:0] c;
              logic [7:0] l;
              c = p_crc;
              l = p_len;
              seq_exp <= f_flags[5:4] + 2'd1;
              if (eom) begin
                asm_on <= 1'b0;
                rep_valid <= 1'b1; rep_err <= 4'd0; rep_len <= l; rep_crc <= ~c;
                rep_type <= som ? f_type : m_type; rep_seid <= som ? f_seid : m_seid;
                rep_tag <= som ? f_flags[2:0] : m_tag; rep_to <= som ? f_flags[3] : m_to;
              end else begin
                asm_on <= 1'b1; m_crc <= c; m_len <= l;
              end
            end
          end
        end
      end else if (active) begin
        if (scl_r) begin
          if (nbit < 4'd8) sh <= {sh[6:0], sda};
          nbit <= nbit + 4'd1;
        end else if (scl_f && nbit == 4'd8) begin : byte_done
          // a whole byte (sh): ACK it if the packet is for this address
          logic ack;
          ack = (nb == 0) ? (sh == {ADDR, 1'b0}) : mine;
          if (nb == 0) mine <= ack;
          sda_o <= !ack;
          pec <= crc8(pec, sh);
          case (nb)
            8'd1: f_cmd <= sh;
            8'd2: cnt <= sh;
            8'd3: f_src <= sh;
            8'd4: f_ver <= sh;
            8'd5: f_deid <= sh;
            8'd6: f_seid <= sh;
            8'd7: begin
                    f_flags <= sh;
                    p_crc <= sh[7] ? 32'hFFFF_FFFF : m_crc;
                    p_len <= sh[7] ? 8'd0 : m_len;
                  end
            default: ;
          endcase
          if (nb == 8'd8 && f_flags[7]) f_type <= sh;
          // bytes from 8 on: the previous one was message payload (the last
          // byte of the packet is the PEC, never folded in), except the
          // type byte of a SOM packet
          if (nb >= 8'd9 && !(nb == 8'd9 && f_flags[7])) begin
            p_crc <= crc32_byte(p_crc, f_last);
            p_len <= p_len + 8'd1;
          end
          if (nb >= 8'd8) f_last <= sh;
          nb <= nb + 8'd1;
        end else if (scl_f && nbit == 4'd9) begin   // ACK clock done: release SDA
          sda_o <= 1'b1; nbit <= '0;
        end
      end
    end
  end
endmodule
`endif
