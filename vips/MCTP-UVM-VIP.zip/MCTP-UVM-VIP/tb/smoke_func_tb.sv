// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (MCTP over SMBus DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened mctp_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic scl_m = 1, sda_m = 1;
  wire scl_o, sda_o, rep_valid, rep_to;
  wire scl = scl_m & scl_o;
  wire sda = sda_m & sda_o;
  wire [7:0] rep_type, rep_len, rep_seid;
  wire [31:0] rep_crc;
  wire [2:0] rep_tag;
  wire [3:0] rep_err;

  always #5 clk = ~clk;

  mctp_model u_dut (.clk(clk), .rst_n(rst_n), .scl(scl), .sda(sda), .scl_o(scl_o), .sda_o(sda_o),
                    .rep_valid(rep_valid), .rep_type(rep_type), .rep_len(rep_len), .rep_seid(rep_seid),
                    .rep_crc(rep_crc), .rep_tag(rep_tag), .rep_to(rep_to), .rep_err(rep_err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  int nrep = 0;
  logic [7:0] r_type, r_len, r_seid; logic [31:0] r_crc; logic [2:0] r_tag; logic r_to; logic [3:0] r_err;
  always @(posedge clk) if (rep_valid) begin
    nrep++; r_type = rep_type; r_len = rep_len; r_seid = rep_seid; r_crc = rep_crc; r_tag = rep_tag;
    r_to = rep_to; r_err = rep_err;
  end

  function automatic bit [7:0] crc8(bit [7:0] c, bit [7:0] b);
    c ^= b;
    for (int k = 0; k < 8; k++) c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
    return c;
  endfunction

  // the endpoint changes SDA only while SCL is low
  logic scl_q = 1'b1, sdao_q = 1'b1;
  int sda_glitch = 0;
  always @(posedge clk) begin
    if (rst_n && scl && scl_q && sda_o !== sdao_q) sda_glitch++;
    scl_q <= scl; sdao_q <= sda_o;
  end

  // SMBus master, 8 clocks per SCL period
  int nack = 0;
  task automatic w(input int n); repeat (n) @(posedge clk); #1; endtask
  task automatic tx_byte(input bit [7:0] b);
    for (int i = 7; i >= 0; i--) begin
      sda_m = b[i]; w(2); scl_m = 1; w(4); scl_m = 0; w(2);
    end
    sda_m = 1; w(2); scl_m = 1; w(2);
    if (sda !== 1'b0) nack++;
    w(2); scl_m = 0; w(2);
  endtask
  bit [7:0] pk[$];
  task automatic packet(input bit [7:0] addr8, input bit [7:0] cmd, input bit [7:0] deid, input bit som,
                        input bit eom, input bit [1:0] seq, input bit [2:0] tag, input bit to, input string data,
                        input bit bad_pec = 0, input int cnt_adj = 0, input bit [7:0] ver = 8'h01,
                        input int ctl = -1);   // ctl >= 0: a type byte (may be 0x00) before data
    bit [7:0] c = 0;
    pk.delete();
    pk.push_back(addr8); pk.push_back(cmd); pk.push_back(8'(data.len() + (ctl >= 0) + 5 + cnt_adj)); pk.push_back(8'h21);
    pk.push_back(ver); pk.push_back(deid); pk.push_back(8'h08); pk.push_back({som, eom, seq, to, tag});
    if (ctl >= 0) pk.push_back(8'(ctl));
    for (int i = 0; i < data.len(); i++) pk.push_back(data[i]);
    foreach (pk[i]) c = crc8(c, pk[i]);
    pk.push_back(c ^ {7'h0, bad_pec});
    sda_m = 0; w(4); scl_m = 0; w(2);
    foreach (pk[i]) tx_byte(pk[i]);
    sda_m = 0; w(2); scl_m = 1; w(4); sda_m = 1; w(10);
  endtask
  task automatic wait_rep(input int prev);
    int n = 0;
    while (nrep == prev && n < 5) begin @(posedge clk); n++; end
    #1;
  endtask

  initial begin
    int b;
    bit [7:0] c = 0;
    string s9 = "123456789";
    for (int i = 0; i < s9.len(); i++) c = crc8(c, s9[i]);
    chk(c == 8'hF4, $sformatf("CRC-8/SMBUS check value of 123456789 = 0xF4 (%h)", c));
    repeat (3) @(posedge clk);
    chk(sda === 1'b1 && scl === 1'b1, "bus released during reset");
    rst_n = 1;
    w(5);
    chk(rep_valid === 1'b0 && nrep == 0 && sda === 1'b1 && scl === 1'b1, "idle bus, no report");
    // no message open after reset: a packet without SOM is dropped
    packet(8'h3A, 8'h0F, 8'h1D, 0, 1, 2'd0, 3'd0, 0, "zz"); w(5);
    chk(nrep == 0, "packet without SOM right after reset: dropped");

    // one-packet message: type 0x7E, payload "123456789"
    b = nrep; nack = 0;
    packet(8'h3A, 8'h0F, 8'h1D, 1, 1, 2'd1, 3'd5, 1, {"~", s9});
    wait_rep(b);
    chk(nack == 0, "every byte ACKed");
    chk(nrep == b + 1 && r_err == 0 && r_type == 8'h7E && r_len == 9 && r_crc == 32'hCBF4_3926,
        $sformatf("single packet: type 7E, 9 bytes, CRC-32 0xCBF43926 (%0d %h %0d %h)", r_err, r_type, r_len, r_crc));
    chk(r_tag == 3'd5 && r_to === 1'b1 && r_seid == 8'h08, "tag, TO and source EID reported");
    // the EOM closed the message: a following packet without SOM is dropped
    b = nrep; packet(8'h3A, 8'h0F, 8'h1D, 0, 1, 2'd2, 3'd5, 1, "zz"); w(5);
    chk(nrep == b, "packet without SOM after an EOM: dropped");

    // three packets: 1234 | 5678 | 9
    b = nrep;
    packet(8'h3A, 8'h0F, 8'h1D, 1, 0, 2'd3, 3'd2, 0, "~1234");
    chk(nrep == b, "no report before EOM");
    packet(8'h3A, 8'h0F, 8'h1D, 0, 0, 2'd0, 3'd2, 0, "5678");
    packet(8'h3A, 8'h0F, 8'h1D, 0, 1, 2'd1, 3'd2, 0, "9");
    wait_rep(b);
    chk(nrep == b + 1 && r_err == 0 && r_len == 9 && r_crc == 32'hCBF4_3926, "three packets reassembled, sequence 3, 0, 1");

    // PEC error in the middle packet: reported there, the EOM packet dropped
    b = nrep;
    packet(8'h3A, 8'h0F, 8'h1D, 1, 0, 2'd0, 3'd1, 0, "~1234");
    packet(8'h3A, 8'h0F, 8'h1D, 0, 0, 2'd1, 3'd1, 0, "5678", 1);
    wait_rep(b);
    chk(nrep == b + 1 && r_err == 1, "PEC error reported");
    packet(8'h3A, 8'h0F, 8'h1D, 0, 1, 2'd2, 3'd1, 0, "9");
    w(5);
    chk(nrep == b + 1, "the rest of the message dropped without a report");

    // sequence skip
    b = nrep;
    packet(8'h3A, 8'h0F, 8'h1D, 1, 0, 2'd2, 3'd0, 0, "~1234");
    packet(8'h3A, 8'h0F, 8'h1D, 0, 1, 2'd0, 3'd0, 0, "5678");
    wait_rep(b);
    chk(r_err == 2, "packet sequence 2 then 0: sequence error");

    // not addressed: other EID; broadcast and null accepted
    b = nrep; packet(8'h3A, 8'h0F, 8'h42, 1, 1, 2'd0, 3'd0, 0, "~x"); wait_rep(b);
    chk(r_err == 8, "destination EID 0x42: not for this endpoint");
    b = nrep; packet(8'h3A, 8'h0F, 8'hFF, 1, 1, 2'd0, 3'd0, 0, {8'h80, 8'h02}, 0, 0, 8'h01, 0); wait_rep(b);
    chk(r_err == 0 && r_type == 8'h00 && r_len == 2, "broadcast EID: control message accepted");
    b = nrep; packet(8'h3A, 8'h0F, 8'h00, 1, 1, 2'd0, 3'd0, 0, "", 0, 0, 8'h01, 0); wait_rep(b);
    chk(r_err == 0 && r_len == 0 && r_crc == 32'h0, "null EID, type byte only: empty payload");

    // format errors: command code, byte count, version
    b = nrep; packet(8'h3A, 8'h0E, 8'h1D, 1, 1, 2'd0, 3'd0, 0, "~x"); wait_rep(b);
    chk(r_err == 4, "command code 0x0E: format error");
    b = nrep; packet(8'h3A, 8'h0F, 8'h1D, 1, 1, 2'd0, 3'd0, 0, "~x", 0, 1); wait_rep(b);
    chk(r_err == 4, "byte count one too large: format error");
    b = nrep; packet(8'h3A, 8'h0F, 8'h1D, 1, 1, 2'd0, 3'd0, 0, "~x", 0, 0, 8'h02); wait_rep(b);
    chk(r_err == 4, "header version 2: format error");

    // another slave address: NACKed, no report
    b = nrep; nack = 0;
    packet(8'h40, 8'h0F, 8'h1D, 1, 1, 2'd0, 3'd0, 0, "~x");
    w(5);
    chk(nack > 0 && nrep == b, "another slave address: NACK, no report");
    // a packet without SOM and no message open: dropped
    b = nrep; packet(8'h3A, 8'h0F, 8'h1D, 0, 1, 2'd0, 3'd0, 0, "zz"); w(5);
    chk(nrep == b, "middle packet without a message: dropped");
    // after all that, a clean message still works
    b = nrep; packet(8'h3A, 8'h0F, 8'h1D, 1, 1, 2'd0, 3'd7, 0, {8'h05, "123456789"}); wait_rep(b);
    chk(r_err == 0 && r_type == 8'h05 && r_crc == 32'hCBF4_3926 && r_tag == 3'd7, "clean SPDM-type message afterwards");

    chk(sda_glitch == 0, $sformatf("endpoint SDA stable while SCL high (%0d changes)", sda_glitch));
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
