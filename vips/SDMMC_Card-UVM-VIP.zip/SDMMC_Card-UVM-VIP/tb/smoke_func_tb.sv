// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SDM DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened sdm_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b1;
  initial #1 rst_n = 1'b0;      // a falling edge: the card has no clock to see a level reset
  logic sd_clk = 1'b1, emmc = 1'b0, cmd_m = 1'b0, cmd_m_oe = 1'b0, dat_m_oe = 1'b0;
  logic [7:0] dat_m = 8'h0;
  wire cmd_s, cmd_s_oe;
  wire [7:0] dat_s, dat_s_oe;

  always #5 clk = ~clk;

  sdm_model u_dut (.clk(clk), .rst_n(rst_n), .sd_clk(sd_clk), .emmc(emmc), .cmd_m(cmd_m), .cmd_m_oe(cmd_m_oe),
                   .dat_m(dat_m), .dat_m_oe(dat_m_oe), .cmd_s(cmd_s), .cmd_s_oe(cmd_s_oe), .dat_s(dat_s),
                   .dat_s_oe(dat_s_oe));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [6:0] crc7(input logic [119:0] d, input integer n);
    logic [6:0] c;
    logic fb;
    c = 7'h00;
    for (int i = 119; i >= 0; i--) if (i < n) begin fb = d[i] ^ c[6]; c = {c[5:0], 1'b0}; if (fb) c = c ^ 7'h09; end
    crc7 = c;
  endfunction
  function automatic logic [15:0] crc16(input logic [15:0] c, input logic b);
    crc16 = {c[14:0], 1'b0} ^ ((b ^ c[15]) ? 16'h1021 : 16'h0000);
  endfunction

  logic cl;
  logic [7:0] dl;
  integer conflict = 0, badoe = 0;
  task automatic clk1(input logic co, input logic c, input logic doe, input logic [7:0] d);
    @(negedge clk); sd_clk = 0; cmd_m_oe = co; cmd_m = c; dat_m_oe = doe; dat_m = d;
    @(negedge clk);
    sd_clk = 1;
    cl = co ? c : (cmd_s_oe ? cmd_s : 1'b1);
    for (int i = 0; i < 8; i++) dl[i] = doe ? d[i] : (dat_s_oe[i] ? dat_s[i] : 1'b1);
    if ((co && cmd_s_oe) || (doe && dat_s_oe != 0)) conflict = conflict + 1;
    if (!(dat_s_oe == 8'h00 || dat_s_oe == 8'h01 || dat_s_oe == 8'h0F || dat_s_oe == 8'hFF)) badoe = badoe + 1;
    @(negedge clk);
  endtask
  task automatic idle1(); clk1(0, 0, 0, 8'h0); endtask
  logic [135:0] r;
  integer ncr;
  logic got;
  task automatic cmd(input logic [5:0] i, input logic [31:0] a, input integer len = 48, input logic badcrc = 0,
                     input integer trail = 4);
    logic [39:0] b;
    logic [47:0] f;
    integer k;
    b = {2'b01, i, a}; f = {b, crc7({80'h0, b}, 40), 1'b1};
    if (badcrc) f[3] = ~f[3];
    repeat (2) idle1();
    for (int j = 47; j >= 0; j--) clk1(1, f[j], 0, 8'h0);
    got = 0; k = 0; r = 0;
    while (k < 64 && !got) begin idle1(); k = k + 1; if (!cl) got = 1; end
    ncr = k;
    if (got) for (int j = 1; j < len; j++) begin idle1(); r = {r[134:0], cl}; end
    repeat (trail) idle1();
  endtask
  function automatic logic r48_ok(input logic [5:0] i);
    r48_ok = r[46] == 1'b0 && r[45:40] == i && r[0] == 1'b1 && crc7({80'h0, 1'b0, r[46:8]}, 40) == r[7:1];
  endfunction
  integer busy, bk, tokk;
  task automatic r1b();
    bk = 0;
    do begin idle1(); bk = bk + 1; end while (dl[0] && bk < 16);
    busy = 0;
    while (!dl[0] && busy < 64) begin busy = busy + 1; idle1(); end
    repeat (2) idle1();
  endtask
  // bus width code 0 / 1 / 2
  integer w = 0;
  function automatic logic [7:0] lm(); lm = (w == 2) ? 8'hFF : (w == 1) ? 8'h0F : 8'h01; endfunction
  function automatic integer cpb(); cpb = (w == 2) ? 1 : (w == 1) ? 2 : 8; endfunction
  function automatic logic [7:0] lv(input logic [7:0] b, input integer s);
    if (w == 2) lv = b; else if (w == 1) lv = {4'hF, (s == 0) ? b[7:4] : b[3:0]}; else lv = {7'h7F, b[7 - s]};
  endfunction
  logic [7:0] wb [0:511];
  logic [7:0] rb [0:511];
  logic [3:0] tok;
  task automatic wr_blk(input integer n, input logic bad = 0);
    logic [15:0] c [0:7];
    logic [7:0] v, m;
    integer k;
    m = lm();
    for (int l = 0; l < 8; l++) c[l] = 0;
    clk1(0, 0, 1, 8'hFF); clk1(0, 0, 1, ~m);
    for (int i = 0; i < n; i++) for (int s = 0; s < cpb(); s++) begin
      v = lv(wb[i], s);
      for (int l = 0; l < 8; l++) if (m[l]) c[l] = crc16(c[l], v[l]);
      clk1(0, 0, 1, v);
    end
    if (bad) c[0][5] = ~c[0][5];
    for (int b = 15; b >= 0; b--) begin for (int l = 0; l < 8; l++) v[l] = m[l] ? c[l][b] : 1'b1; clk1(0, 0, 1, v); end
    clk1(0, 0, 1, 8'hFF);
    k = 0;
    do begin idle1(); k = k + 1; end while (dl[0] && k < 64);
    tokk = k;
    tok = {dl[0], 3'b000};
    for (int j = 2; j >= 0; j--) begin idle1(); tok[j] = dl[0]; end
    idle1();
    busy = 0;
    if (dl[0]) begin idle1(); while (!dl[0] && busy < 64) begin busy = busy + 1; idle1(); end end
    repeat (2) idle1();
  endtask
  logic rd_ok;
  integer rk;
  task automatic rd_blk(input integer n, input integer trail = 4);
    logic [15:0] c [0:7], x [0:7];
    logic [7:0] m, bb;
    logic se;
    m = lm();
    for (int l = 0; l < 8; l++) begin c[l] = 0; x[l] = 0; end
    rk = 0;
    do begin idle1(); rk = rk + 1; end while (dl[0] && rk < 64);
    se = (dl & m) == 8'h00 && (dl | m) == 8'hFF;
    for (int i = 0; i < n; i++) begin
      bb = 0;
      for (int s = 0; s < cpb(); s++) begin
        idle1();
        for (int l = 0; l < 8; l++) if (m[l]) c[l] = crc16(c[l], dl[l]);
        if (w == 2) bb = dl; else if (w == 1) bb = {bb[3:0], dl[3:0]}; else bb = {bb[6:0], dl[0]};
      end
      rb[i] = bb;
    end
    for (int b = 0; b < 16; b++) begin idle1(); for (int l = 0; l < 8; l++) x[l] = {x[l][14:0], dl[l]}; end
    idle1();
    rd_ok = se && (dl & m) == m;
    for (int l = 0; l < 8; l++) if (m[l] && c[l] != x[l]) rd_ok = 0;
    repeat (trail) idle1();
  endtask
  function automatic logic [7:0] ib(input integer i); ib = (i ^ (i >> 8) ^ 8'hA5); endfunction
  function automatic logic same(input integer n, input integer base);
    same = 1;
    for (int i = 0; i < n; i++) if (rb[i] !== ib(base + i)) same = 0;
  endfunction
  function automatic logic same_wb(input integer n);
    same_wb = 1;
    for (int i = 0; i < n; i++) if (rb[i] !== wb[i]) same_wb = 0;
  endfunction
  task automatic fill(input integer n, input integer sd);
    for (int i = 0; i < n; i++) wb[i] = (i * 37 + sd * 11) ^ (i >> 3);
  endtask
  logic [15:0] rca;
  logic ok;

  initial begin
    repeat (3) @(posedge clk);
    chk(cmd_s_oe === 1'b0 && dat_s_oe === 8'h0, "card off the bus in reset");
    rst_n = 1;
    repeat (4) idle1();
    // ------------------------------ SD ------------------------------
    cmd(6'd41, 32'h40FF_8000); chk(!got, "ACMD41 as the first command after reset: illegal");
    cmd(6'd13, 32'h0); chk(!got, "SD: CMD13 in idle: illegal");
    cmd(6'd0, 32'h0); chk(!got, "CMD0: no response");
    cmd(6'd8, 32'h0000_02AA); chk(!got, "CMD8 with VHS 2: no response");
    cmd(6'd8, 32'h0000_01AA); chk(got && ncr == 2 && r48_ok(6'd8) && r[19:8] == 12'h1AA, "CMD8: R7 echo, NCR = 2");
    cmd(6'd41, 32'h40FF_8000); chk(!got, "ACMD41 without CMD55: illegal");
    cmd(6'd55, 32'h0); chk(got && r48_ok(6'd55) && r[39:8] == 32'h0040_0120, "CMD55: ILLEGAL_COMMAND, idle, APP_CMD");
    cmd(6'd41, 32'h40FF_8000); chk(got && r[45:40] == 6'h3F && r[7:0] == 8'hFF && r[39:8] == 32'h00FF_8000, "ACMD41: busy");
    cmd(6'd55, 32'h0); cmd(6'd41, 32'h40FF_8000); chk(r[39:8] == 32'h00FF_8000, "ACMD41: busy (POLLS = 2)");
    cmd(6'd55, 32'h0); cmd(6'd41, 32'h40FF_8000); chk(r[39:8] == 32'hC0FF_8000, "ACMD41: ready, CCS");
    cmd(6'd1, 32'h40FF_8080); chk(!got, "SD: CMD1 illegal");
    cmd(6'd2, 32'h0, 136);
    chk(got && ncr == 2 && r[133:128] == 6'h3F && r[0] && crc7(r[127:8], 120) == r[7:1] && r[127:8] == 120'h1D4F5653444D43311012345678016A,
        "CMD2: SD CID");
    cmd(6'd3, 32'h0); rca = r[39:24];
    chk(got && r48_ok(6'd3) && rca == 16'hB37A && r[23:8] == 16'h4500, "CMD3: R6, RCA B37A, ILLEGAL_COMMAND (CMD1), ident");
    cmd(6'd13, {rca, 16'h0}, 48, 1); chk(!got, "bad CRC7: no response");
    cmd(6'd13, {rca, 16'h0}); chk(got && ncr == 2 && r48_ok(6'd13) && r[39:8] == 32'h0080_0700, "CMD13: COM_CRC_ERROR, stby");
    cmd(6'd17, 32'd1); chk(!got, "CMD17 in stby: illegal");
    cmd(6'd7, {rca, 16'h0}, 48, 0, 0);
    chk(got && r48_ok(6'd7) && r[39:8] == 32'h0040_0700, "CMD7: R1, ILLEGAL_COMMAND, stby"); r1b();
    chk(bk == 2 && busy == 3, "CMD7: R1b busy 3 clocks, 2 clocks after the end bit");
    cmd(6'd17, 32'd1, 48, 0, 0); rd_blk(512); chk(got && rd_ok && rk == 2 && same(512, 512), "1-bit CMD17: block 1, NAC = 2");
    fill(512, 1);
    cmd(6'd24, 32'd1, 48, 0, 0); chk(got && r[39:8] == 32'h0000_0900, "CMD24: R1, tran");
    wr_blk(512); chk(tok == 4'b0010 && busy == 4 && tokk == 2, "1-bit write: token 010 after 2 clocks, 4 clocks busy");
    cmd(6'd17, 32'd1, 48, 0, 0); rd_blk(512); chk(rd_ok && same_wb(512), "1-bit read-back");
    cmd(6'd55, {rca, 16'h0}); cmd(6'd6, 32'h2); chk(got && r48_ok(6'd6) && r[39:8] == 32'h0000_0920, "ACMD6: 4-bit, R1 with APP_CMD");
    w = 1;
    fill(512, 2);
    cmd(6'd25, 32'd2, 48, 0, 0); chk(got && r[39:8] == 32'h0000_0900, "CMD25: R1");
    wr_blk(512); ok = tok == 4'b0010; fill(512, 3); wr_blk(512); ok = ok && tok == 4'b0010 && busy == 4;
    cmd(6'd12, 32'h0, 48, 0, 0); chk(ok && got && r[39:8] == 32'h0000_0D00, "CMD25: 2 blocks, CMD12 in rcv state"); r1b();
    chk(busy == 3, "CMD12: R1b busy");
    cmd(6'd18, 32'd2, 48, 0, 0); rd_blk(512, 0); ok = rd_ok && rk == 2; fill(512, 2); ok = ok && same_wb(512);
    rd_blk(512, 0); fill(512, 3); ok = ok && rd_ok && rk == 3 && same_wb(512);
    rd_blk(512, 0); ok = ok && rd_ok && same(512, 2048);
    cmd(6'd12, 32'h0, 48, 0, 0); chk(ok && got && r[39:8] == 32'h0000_0B00, "4-bit CMD18: 3 blocks, NAC between, CMD12 in data state");
    r1b();
    cmd(6'd13, {rca, 16'h0}); chk(got && r[39:8] == 32'h0000_0900, "back in tran");
    fill(512, 4);
    cmd(6'd24, 32'd5, 48, 0, 0); wr_blk(512, 1); chk(tok == 4'b0101 && busy == 0, "bad CRC16: token 101, no busy");
    cmd(6'd17, 32'd5, 48, 0, 0); rd_blk(512); chk(rd_ok && same(512, 5 * 512), "and nothing written");
    cmd(6'd16, 32'd64); chk(got && r[39:8] == 32'h0000_0900, "CMD16: 64-byte blocks");
    cmd(6'd17, 32'd3, 48, 0, 0); rd_blk(64); chk(rd_ok && same(64, 192), "64-byte block 3 is bytes 192..255");
    cmd(6'd16, 32'd513); chk(!got, "CMD16 513: illegal");
    cmd(6'd16, 32'd512);
    chk(got && r[39:8] == 32'h0040_0900, "CMD16 512, ILLEGAL_COMMAND reported");
    cmd(6'd18, 32'd0, 48, 0, 0);
    rk = 0; do begin idle1(); rk = rk + 1; end while (dl[0] && rk < 64); repeat (40) idle1();
    cmd(6'd12, 32'h0, 48, 0, 0); ok = got && r[39:8] == 32'h0000_0B00; r1b();
    chk(ok && dat_s_oe === 8'h0 && busy == 3, "CMD12 stops a read in the middle of a block");
    cmd(6'd12, 32'h0); chk(!got, "CMD12 in tran: illegal");
    cmd(6'd7, {rca ^ 16'h1, 16'h0}); chk(!got, "CMD7 to another RCA: deselect");
    cmd(6'd13, {rca, 16'h0}); chk(got && r[39:8] == 32'h0040_0700, "stby, ILLEGAL_COMMAND (CMD12)");
    // ------------------------------ eMMC ------------------------------
    emmc = 1; w = 0;
    cmd(6'd0, 32'h0);
    cmd(6'd55, 32'h0); chk(!got, "eMMC: CMD55 illegal");
    cmd(6'd1, 32'h40FF_8080); chk(got && ncr == 2 && r[45:40] == 6'h3F && r[39:8] == 32'h40FF_8080, "CMD1: busy, sector mode");
    cmd(6'd1, 32'h40FF_8080); cmd(6'd1, 32'h40FF_8080); chk(r[39:8] == 32'hC0FF_8080, "CMD1: ready on the third poll");
    cmd(6'd2, 32'h0, 136);
    chk(got && crc7(r[127:8], 120) == r[7:1] && r[127:8] == 120'h150100454D4D4344361087654321A8, "CMD2: eMMC CID");
    cmd(6'd3, 32'h0); chk(!got, "CMD3 with RCA 0: illegal");
    cmd(6'd3, 32'h0005_0000); chk(got && r48_ok(6'd3) && r[39:8] == 32'h0040_0500, "CMD3: R1, ident, ILLEGAL_COMMAND");
    cmd(6'd7, 32'h0005_0000, 48, 0, 0); r1b(); chk(busy == 3, "CMD7: R1b");
    cmd(6'd8, 32'h0, 48, 0, 0); chk(got && r[39:8] == 32'h0000_0900, "CMD8: R1"); rd_blk(512);
    chk(rd_ok && rb[183] == 8'd0 && rb[192] == 8'd8 && rb[196] == 8'd7 && rb[212] == 8'd8 && rb[0] == 8'd0,
        "EXT_CSD: BUS_WIDTH 0, rev 8, SEC_COUNT 8");
    cmd(6'd6, {6'h0, 2'b11, 8'd183, 8'd2, 8'h0}, 48, 0, 0); chk(got && r48_ok(6'd6), "CMD6 SWITCH: 8 bits"); r1b();
    w = 2;
    cmd(6'd8, 32'h0, 48, 0, 0); rd_blk(512); chk(rd_ok && rb[183] == 8'd2, "8-bit EXT_CSD read: BUS_WIDTH 2");
    cmd(6'd17, 32'd1, 48, 0, 0); rd_blk(512); fill(512, 1); chk(rd_ok && same_wb(512), "8-bit read of SD's block 1");
    fill(512, 9);
    cmd(6'd25, 32'd6, 48, 0, 0); wr_blk(512); ok = tok == 4'b0010;
    cmd(6'd12, 32'h0, 48, 0, 0); r1b();
    cmd(6'd18, 32'd6, 48, 0, 0); rd_blk(512, 0); ok = ok && rd_ok && same_wb(512); rd_blk(512, 0);
    cmd(6'd12, 32'h0, 48, 0, 0); r1b();
    chk(ok && rd_ok && same(512, 7 * 512), "8-bit CMD25 / CMD18 with CMD12");
    cmd(6'd6, {6'h0, 2'b11, 8'd183, 8'd3, 8'h0}); chk(!got, "BUS_WIDTH 3: illegal");
    cmd(6'd6, {6'h0, 2'b11, 8'd185, 8'd1, 8'h0}); chk(!got, "SWITCH of another byte: illegal");
    cmd(6'd6, {6'h0, 2'b11, 8'd183, 8'd1, 8'h0}, 48, 0, 0); r1b(); w = 1;
    cmd(6'd16, 32'd128);
    fill(128, 5);
    cmd(6'd24, 32'd2, 48, 0, 0); wr_blk(128); chk(tok == 4'b0010, "4-bit 128-byte write");
    cmd(6'd17, 32'd2, 48, 0, 0); rd_blk(128); chk(rd_ok && same_wb(128), "and read-back");
    cmd(6'd16, 32'd512);
    cmd(6'd17, 32'd0, 48, 0, 0); rd_blk(512);
    ok = rd_ok;
    for (int i = 0; i < 256; i++) if (rb[i] !== ib(i)) ok = 0;
    for (int i = 0; i < 128; i++) if (rb[256 + i] !== wb[i]) ok = 0;
    chk(ok, "the 128-byte block 2 sits at bytes 256..383");
    cmd(6'd13, 32'h0005_0000); chk(got && r[39:8] == 32'h0000_0900, "CMD13: tran, flags cleared by the R1s since");
    cmd(6'd0, 32'h0);
    cmd(6'd13, 32'h0005_0000); chk(!got, "CMD0 from tran: idle");
    chk(conflict == 0 && badoe == 0, "no bus contention, only bus-width line sets");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
