// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SDM testbench top with a functional SDM DUT model

`ifndef SDMMC_CARD_UVM_VIP_TB_SV
`define SDMMC_CARD_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sdm_defs_pkg::*;
import sdm_pkg::*;
import sdm_env_pkg::*;
import sdm_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  sdm_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  sdm_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .sd_clk(vif.sd_clk),
    .emmc(vif.emmc),
    .cmd_m(vif.cmd_m),
    .cmd_m_oe(vif.cmd_m_oe),
    .dat_m(vif.dat_m),
    .dat_m_oe(vif.dat_m_oe),
    .cmd_s(vif.cmd_s),
    .cmd_s_oe(vif.cmd_s_oe),
    .dat_s(vif.dat_s),
    .dat_s_oe(vif.dat_s_oe)
  );

  // Concurrent protocol checks
  sdm_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .sd_clk(vif.sd_clk),
    .emmc(vif.emmc),
    .cmd_m(vif.cmd_m),
    .cmd_m_oe(vif.cmd_m_oe),
    .dat_m(vif.dat_m),
    .dat_m_oe(vif.dat_m_oe),
    .cmd_s(vif.cmd_s),
    .cmd_s_oe(vif.cmd_s_oe),
    .dat_s(vif.dat_s),
    .dat_s_oe(vif.dat_s_oe)
  );

  initial begin
    uvm_config_db#(virtual sdm_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module sdm_model #(
  parameter int          NBLK   = 8,
  parameter int          NCR    = 2,
  parameter int          NAC    = 2,
  parameter int          BUSY   = 4,
  parameter int          RBUSY  = 3,
  parameter int          POLLS  = 2,
  parameter logic [15:0] SD_RCA = 16'hB37A
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       sd_clk,
  input  logic       emmc,
  input  logic       cmd_m,
  input  logic       cmd_m_oe,
  input  logic [7:0] dat_m,
  input  logic       dat_m_oe,
  output logic       cmd_s,
  output logic       cmd_s_oe,
  output logic [7:0] dat_s,
  output logic [7:0] dat_s_oe
);
  localparam int MEMB = NBLK * 512;
  localparam logic [119:0] CID_SD   = 120'h1D4F5653444D43311012345678016A;
  localparam logic [119:0] CID_EMMC = 120'h150100454D4D4344361087654321A8;
  localparam logic [3:0] D_NONE = 4'd0, D_WWAIT = 4'd1, D_WDATA = 4'd2, D_WCRC = 4'd3, D_WEND = 4'd4,
                         D_TOK = 4'd5, D_BPEND = 4'd6, D_RPEND = 4'd7, D_RWAIT = 4'd8, D_RDATA = 4'd9,
                         D_RCRC = 4'd10, D_REND = 4'd11, D_RREL = 4'd12;
  function automatic logic [6:0] crc7(input logic [119:0] d, input integer n);
    logic [6:0] c;
    logic fb;
    c = 7'h00;
    for (int i = 119; i >= 0; i--) if (i < n) begin
      fb = d[i] ^ c[6];
      c = {c[5:0], 1'b0};
      if (fb) c = c ^ 7'h09;
    end
    crc7 = c;
  endfunction
  function automatic logic [15:0] crc16(input logic [15:0] c, input logic b);
    crc16 = {c[14:0], 1'b0} ^ ((b ^ c[15]) ? 16'h1021 : 16'h0000);
  endfunction
  // 8 CRC16s side by side, updated on the lines of mask m
  function automatic logic [127:0] crc8(input logic [127:0] c, input logic [7:0] v, input logic [7:0] m);
    for (int l = 0; l < 8; l++) if (m[l]) crc8[16 * l +: 16] = crc16(c[16 * l +: 16], v[l]);
    else crc8[16 * l +: 16] = c[16 * l +: 16];
  endfunction
  function automatic logic [47:0] frame(input logic [5:0] i, input logic [31:0] a);
    logic [39:0] b;
    b = {2'b00, i, a};
    frame = {b, crc7({80'h0, b}, 40), 1'b1};
  endfunction
  function automatic logic [7:0] mask(input logic [1:0] w);
    mask = (w == 2'd2) ? 8'hFF : (w == 2'd1) ? 8'h0F : 8'h01;
  endfunction
  function automatic logic [3:0] cpb(input logic [1:0] w);   // clocks per byte
    cpb = (w == 2'd2) ? 4'd1 : (w == 2'd1) ? 4'd2 : 4'd8;
  endfunction
  function automatic logic [7:0] lines(input logic [1:0] w, input logic [7:0] b, input logic [2:0] s);
    if (w == 2'd2) lines = b;
    else if (w == 2'd1) lines = {4'hF, (s == 3'd0) ? b[7:4] : b[3:0]};
    else lines = {7'h7F, b[3'd7 - s]};
  endfunction

  logic [7:0]   mem [0:MEMB-1];
  logic [7:0]   wbuf [0:511];
  logic [2:0]   cst;
  logic [3:0]   polls, dm;
  logic         app, crc_e, ill, multi, xcsd;
  logic [1:0]   w;
  logic [9:0]   blklen;
  logic [15:0]  rca;
  logic [5:0]   rxc;
  logic [47:0]  rxs;
  logic [7:0]   txn;
  logic [6:0]   txd;
  logic [135:0] txs;
  logic [12:0]  dcnt;
  logic [31:0]  baddr;
  logic [127:0] crc, rcrc;
  logic [7:0]   acc;
  logic [6:0]   rdd, tokd;
  logic [2:0]   tokn;
  logic [4:0]   tok;
  logic [7:0]   busyn;
  logic         n_cmd, n_cmd_oe;
  logic [7:0]   n_dat, n_dat_oe;
  wire          cl = cmd_m_oe ? cmd_m : (cmd_s_oe ? cmd_s : 1'b1);
  wire  [7:0]   dl = dat_m_oe ? dat_m : ((dat_s_oe & dat_s) | ~dat_s_oe);
  wire          _unused = &{1'b0, clk};

  function automatic logic [7:0] ext(input logic [8:0] i, input logic [1:0] wv);
    case (i)
      9'd183: ext = {6'h0, wv};
      9'd192: ext = 8'h08;
      9'd196: ext = 8'h07;
      9'd212: ext = 8'(NBLK);
      default: ext = 8'h00;
    endcase
  endfunction

  // rising sd_clk: receive, run the card, decide the next outputs
  always_ff @(posedge sd_clk or negedge rst_n) begin
    if (!rst_n) begin
      cst <= '0; polls <= '0; dm <= D_NONE; app <= 1'b0; crc_e <= 1'b0; ill <= 1'b0; multi <= 1'b0; xcsd <= 1'b0;
      w <= '0; blklen <= 10'd512; rca <= '0; rxc <= '0; rxs <= '0; txn <= '0; txd <= '0; txs <= '0;
      dcnt <= '0; baddr <= '0; crc <= '0; rcrc <= '0; acc <= '0; rdd <= '0; tokd <= '0; tokn <= '0; tok <= '0;
      busyn <= '0; n_cmd <= 1'b0; n_cmd_oe <= 1'b0; n_dat <= 8'h0; n_dat_oe <= 8'h0;
      for (int k = 0; k < MEMB; k++) mem[k] <= 8'(k ^ (k >> 8) ^ 8'hA5);
    end else begin : step
      logic [2:0]   v_cst, st;
      logic [3:0]   v_polls, v_dm;
      logic         v_app, v_crc_e, v_ill, v_multi, v_xcsd;
      logic [1:0]   v_w;
      logic [9:0]   v_blklen;
      logic [15:0]  v_rca;
      logic [5:0]   v_rxc;
      logic [47:0]  v_rxs, f;
      logic [7:0]   v_txn;
      logic [6:0]   v_txd;
      logic [135:0] v_txs;
      logic [12:0]  v_dcnt, nclk;
      logic [31:0]  v_baddr;
      logic [127:0] v_crc, v_rcrc;
      logic [7:0]   v_acc;
      logic [6:0]   v_rdd, v_tokd;
      logic [2:0]   v_tokn;
      logic [4:0]   v_tok;
      logic [7:0]   v_busyn;
      logic [7:0]   m, v, b;
      logic [3:0]   s;
      logic [12:0]  bi;
      logic         go, good, wa, rdy, ok1, ap, rb;
      logic [5:0]   i;
      logic [31:0]  a;
      logic [119:0] body;
      v_cst = cst; v_polls = polls; v_dm = dm; v_app = app; v_crc_e = crc_e; v_ill = ill; v_multi = multi;
      v_xcsd = xcsd; v_w = w; v_blklen = blklen; v_rca = rca; v_rxc = rxc; v_rxs = rxs; v_txn = txn;
      v_txd = txd; v_txs = txs; v_dcnt = dcnt; v_baddr = baddr; v_crc = crc; v_rcrc = rcrc; v_acc = acc;
      v_rdd = rdd; v_tokd = tokd; v_tokn = tokn; v_tok = tok; v_busyn = busyn;
      go = 1'b0; f = '0; ok1 = 1'b0; ap = 1'b0; rb = 1'b0;
      // command receiver
      if (v_txd == 0 && v_txn == 0) begin
        if (v_rxc == 0) begin if (!cl) begin v_rxc = 6'd1; v_rxs = '0; end end
        else begin
          v_rxs = {v_rxs[46:0], cl};
          v_rxc = v_rxc + 6'd1;
          if (v_rxc == 6'd48) begin v_rxc = '0; go = 1'b1; f = v_rxs; end
        end
      end
      if (go) begin
        i = f[45:40]; a = f[39:8]; st = v_cst; wa = v_app;
        if (crc7({80'h0, f[47:8]}, 40) != f[7:1] || !f[0] || !f[46]) v_crc_e = 1'b1;
        else begin
          v_app = 1'b0;
          if (i == 6'd0) begin
            v_cst = 3'd0; v_polls = '0; v_rca = '0; v_w = 2'd0; v_blklen = 10'd512; v_dm = D_NONE; v_multi = 1'b0;
          end else if (!emmc && i == 6'd8 && v_cst == 3'd0) begin
            if (a[11:8] == 4'h1) begin v_txs = {frame(6'd8, {20'h0, a[11:0]}), 88'h0}; v_txn = 8'd48; v_txd = 7'(NCR - 1); end
          end else if (emmc && i == 6'd8 && v_cst == 3'd4) begin
            ok1 = 1'b1; v_xcsd = 1'b1; v_multi = 1'b0; v_baddr = '0; v_dm = D_RPEND; v_cst = 3'd5;
          end else if (!emmc && i == 6'd55 && v_cst != 3'd2 && v_cst <= 3'd4) begin
            v_app = 1'b1; ok1 = 1'b1; ap = 1'b1;
          end else if (!emmc && i == 6'd41 && wa && v_cst <= 3'd1) begin
            rdy = v_polls >= 4'(POLLS);
            if (v_polls != 4'd15) v_polls = v_polls + 4'd1;
            if (rdy) v_cst = 3'd1;
            v_txs = {2'b00, 6'h3F, rdy, rdy, 6'h00, 24'hFF8000, 8'hFF, 88'h0};
            v_txn = 8'd48; v_txd = 7'(NCR - 1);
          end else if (emmc && i == 6'd1 && v_cst == 3'd0) begin
            rdy = v_polls >= 4'(POLLS);
            if (v_polls != 4'd15) v_polls = v_polls + 4'd1;
            if (rdy) v_cst = 3'd1;
            v_txs = {2'b00, 6'h3F, rdy, 2'b10, 29'h00FF_8080, 8'hFF, 88'h0};
            v_txn = 8'd48; v_txd = 7'(NCR - 1);
          end else if (i == 6'd2 && v_cst == 3'd1) begin
            body = emmc ? CID_EMMC : CID_SD;
            v_cst = 3'd2; v_txs = {2'b00, 6'h3F, body, crc7(body, 120), 1'b1}; v_txn = 8'd136; v_txd = 7'(NCR - 1);
          end else if (!emmc && i == 6'd3 && (v_cst == 3'd2 || v_cst == 3'd3)) begin
            v_cst = 3'd3; v_rca = SD_RCA;
            v_txs = {frame(6'd3, {SD_RCA, v_crc_e, v_ill, 2'b00, st, 1'b1, 2'b00, 1'b0, 5'h00}), 88'h0};
            v_txn = 8'd48; v_txd = 7'(NCR - 1); v_crc_e = 1'b0; v_ill = 1'b0;
          end else if (emmc && i == 6'd3 && v_cst == 3'd2 && a[31:16] != 16'h0) begin
            v_cst = 3'd3; v_rca = a[31:16]; ok1 = 1'b1;
          end else if (i == 6'd7 && (v_cst == 3'd3 || v_cst == 3'd4)) begin
            if (a[31:16] == v_rca) begin v_cst = 3'd4; ok1 = 1'b1; rb = 1'b1; end
            else if (v_cst == 3'd4) v_cst = 3'd3;
          end else if (i == 6'd13 && v_cst >= 3'd3) begin
            if (a[31:16] == v_rca) ok1 = 1'b1;
          end else if (!emmc && i == 6'd6 && wa && v_cst == 3'd4 && !a[0]) begin
            v_w = a[1] ? 2'd1 : 2'd0; ok1 = 1'b1; ap = 1'b1;
          end else if (emmc && i == 6'd6 && v_cst == 3'd4 && a[25:24] == 2'b11 && a[23:16] == 8'd183 &&
                       a[15:8] <= 8'd2) begin
            v_w = a[9:8]; ok1 = 1'b1; rb = 1'b1;
          end else if (i == 6'd16 && v_cst == 3'd4 && a != 0 && a <= 32'd512) begin
            v_blklen = a[9:0]; ok1 = 1'b1;
          end else if ((i == 6'd17 || i == 6'd18 || i == 6'd24 || i == 6'd25) && v_cst == 3'd4) begin
            ok1 = 1'b1;
            v_baddr = (a * 32'(v_blklen)) % 32'(MEMB); v_multi = (i == 6'd18 || i == 6'd25); v_xcsd = 1'b0;
            if (i == 6'd17 || i == 6'd18) begin v_dm = D_RPEND; v_cst = 3'd5; end
            else begin v_dm = D_WWAIT; v_cst = 3'd6; end
          end else if (i == 6'd12 && (v_cst == 3'd5 || v_cst == 3'd6)) begin
            ok1 = 1'b1; rb = 1'b1; v_cst = 3'd4; v_multi = 1'b0; v_xcsd = 1'b0;
          end else v_ill = 1'b1;
          if (ok1) begin
            v_txs = {frame(i, {8'h00, v_crc_e, v_ill, 9'h000, 1'b0, st, 1'b1, 2'b00, ap, 5'h00}), 88'h0};
            v_txn = 8'd48; v_txd = 7'(NCR - 1); v_crc_e = 1'b0; v_ill = 1'b0;
            if (rb) v_dm = D_BPEND;
          end
        end
      end
      m = mask(v_w);
      nclk = (v_xcsd ? 13'd512 : 13'(v_blklen)) * 13'(cpb(v_w));
      // write block receiver
      case (v_dm)
        D_WWAIT: if (!dl[0]) begin v_dm = D_WDATA; v_dcnt = '0; v_crc = '0; end
        D_WDATA: begin
          s = 4'(v_dcnt % 13'(cpb(v_w))); bi = v_dcnt / 13'(cpb(v_w));
          if (v_w == 2'd2) wbuf[bi[8:0]] <= dl;
          else if (v_w == 2'd1) begin if (s == 0) v_acc[7:4] = dl[3:0]; else wbuf[bi[8:0]] <= {v_acc[7:4], dl[3:0]}; end
          else begin v_acc = {v_acc[6:0], dl[0]}; if (s == 4'd7) wbuf[bi[8:0]] <= v_acc; end
          v_crc = crc8(v_crc, dl, m);
          v_dcnt = v_dcnt + 13'd1;
          if (v_dcnt == nclk) begin v_dm = D_WCRC; v_dcnt = '0; v_rcrc = '0; end
        end
        D_WCRC: begin
          for (int l = 0; l < 8; l++) if (m[l]) v_rcrc[16 * l +: 16] = {v_rcrc[16 * l +: 15], dl[l]};
          v_dcnt = v_dcnt + 13'd1;
          if (v_dcnt == 13'd16) v_dm = D_WEND;
        end
        D_WEND: begin
          good = (dl & m) == m && v_rcrc == v_crc;
          if (good) for (int k = 0; k < 512; k++) if (k < 32'(v_blklen)) mem[(v_baddr + k) % MEMB] <= wbuf[k];
          v_tok = good ? 5'b0_010_1 : 5'b0_101_1;
          v_dm = D_TOK; v_tokd = 7'd1; v_tokn = 3'd5; v_busyn = good ? 8'(BUSY) : 8'd0;
          v_baddr = (v_baddr + 32'(v_blklen)) % 32'(MEMB);
        end
        default: ;
      endcase
      // outputs for the next period
      if (v_txd != 0) begin v_txd = v_txd - 7'd1; n_cmd_oe <= 1'b0; end
      else if (v_txn != 0) begin
        n_cmd_oe <= 1'b1; n_cmd <= v_txs[135]; v_txs = v_txs << 1; v_txn = v_txn - 8'd1;
        if (v_txn == 0 && v_dm == D_RPEND) begin v_dm = D_RWAIT; v_rdd = 7'(NAC); end
        if (v_txn == 0 && v_dm == D_BPEND) begin v_dm = D_TOK; v_tokd = 7'd2; v_tokn = 3'd0; v_busyn = 8'(RBUSY); end
      end else n_cmd_oe <= 1'b0;
      case (v_dm)
        D_TOK:
          if (v_tokd != 0) begin v_tokd = v_tokd - 7'd1; n_dat_oe <= 8'h0; end
          else if (v_tokn != 0) begin n_dat_oe <= 8'h01; n_dat <= {7'h0, v_tok[4]}; v_tok = v_tok << 1; v_tokn = v_tokn - 3'd1; end
          else if (v_busyn != 0) begin n_dat_oe <= 8'h01; n_dat <= 8'h0; v_busyn = v_busyn - 8'd1; end
          else begin
            n_dat_oe <= 8'h0;
            if (v_cst == 3'd6 && v_multi) v_dm = D_WWAIT;
            else begin v_dm = D_NONE; if (v_cst == 3'd6) v_cst = 3'd4; end
          end
        D_RWAIT:
          if (v_rdd != 0) begin v_rdd = v_rdd - 7'd1; n_dat_oe <= 8'h0; end
          else begin n_dat_oe <= m; n_dat <= 8'h0; v_dm = D_RDATA; v_dcnt = '0; v_crc = '0; end
        D_RDATA: begin
          s = 4'(v_dcnt % 13'(cpb(v_w))); bi = v_dcnt / 13'(cpb(v_w));
          b = v_xcsd ? ext(bi[8:0], v_w) : mem[(v_baddr + 32'(bi)) % MEMB];
          v = lines(v_w, b, s[2:0]);
          n_dat_oe <= m; n_dat <= v & m;
          v_crc = crc8(v_crc, v, m);
          v_dcnt = v_dcnt + 13'd1;
          if (v_dcnt == nclk) begin v_dm = D_RCRC; v_dcnt = '0; end
        end
        D_RCRC: begin
          n_dat_oe <= m;
          for (int l = 0; l < 8; l++) begin v[l] = m[l] & v_crc[16 * l + 15]; v_crc[16 * l +: 16] = v_crc[16 * l +: 16] << 1; end
          n_dat <= v;
          v_dcnt = v_dcnt + 13'd1;
          if (v_dcnt == 13'd16) v_dm = D_REND;
        end
        D_REND: begin
          n_dat_oe <= m; n_dat <= m;
          if (v_multi) begin v_baddr = (v_baddr + 32'(v_blklen)) % 32'(MEMB); v_rdd = 7'(NAC); v_dm = D_RWAIT; end
          else v_dm = D_RREL;
        end
        D_RREL: begin n_dat_oe <= 8'h0; v_dm = D_NONE; v_cst = 3'd4; v_xcsd = 1'b0; end
        default: n_dat_oe <= 8'h0;
      endcase
      cst <= v_cst; polls <= v_polls; dm <= v_dm; app <= v_app; crc_e <= v_crc_e; ill <= v_ill; multi <= v_multi;
      xcsd <= v_xcsd; w <= v_w; blklen <= v_blklen; rca <= v_rca; rxc <= v_rxc; rxs <= v_rxs; txn <= v_txn;
      txd <= v_txd; txs <= v_txs; dcnt <= v_dcnt; baddr <= v_baddr; crc <= v_crc; rcrc <= v_rcrc; acc <= v_acc;
      rdd <= v_rdd; tokd <= v_tokd; tokn <= v_tokn; tok <= v_tok; busyn <= v_busyn;
    end
  end

  // falling sd_clk: the outputs change
  always_ff @(negedge sd_clk or negedge rst_n) begin
    if (!rst_n) begin
      cmd_s <= 1'b0; cmd_s_oe <= 1'b0; dat_s <= 8'h0; dat_s_oe <= 8'h0;
    end else begin
      cmd_s <= n_cmd; cmd_s_oe <= n_cmd_oe; dat_s <= n_dat; dat_s_oe <= n_dat_oe;
    end
  end
endmodule
`endif
