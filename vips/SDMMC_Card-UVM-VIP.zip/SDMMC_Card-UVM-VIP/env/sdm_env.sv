// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_env.sv -- SDM environment: reference-model scoreboard, checker, coverage

package sdm_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sdm_defs_pkg::*;
  import sdm_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class sdm_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(sdm_scoreboard)
    uvm_analysis_imp_exp #(sdm_transaction, sdm_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(sdm_transaction, sdm_scoreboard) obs_ap;

    sdm_config cfg;
    sdm_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // the card (scoreboard copy), kept across items
    localparam int NBLK = 8, MEMB = NBLK * 512, NCR = 2, NAC = 2, BUSY = 4, RBUSY = 3, POLLS = 2;
    localparam bit [15:0] SD_RCA = 16'hB37A;
    bit [7:0]   mem [MEMB];
    bit [7:0]   wbuf [512];
    bit         minit = 0;
    int         cst = 0, polls = 0, dm = 0, rdd = 0, tokd = 0, tokn = 0, busyn = 0, dcnt = 0, blklen = 512, baddr = 0;
    bit         app = 0, crc_e = 0, ill = 0, multi = 0, xcsd = 0;
    bit [1:0]   w = 0;
    bit [15:0]  rca = 0;
    int         rxc = 0, txd = 0, txn = 0;
    bit [47:0]  rxs = 0;
    bit [135:0] txs = 0;
    bit [15:0]  c [8], rc [8];
    bit [7:0]   acc = 0;
    bit [4:0]   tok = 0;
    bit         o_cmd = 0, o_cmd_oe = 0;
    bit [7:0]   o_dat = 0, o_dat_oe = 0;

    function bit [7:0] ext(int i);
      case (i)
        183: return {6'h0, w};
        192: return 8'h08;
        196: return 8'h07;
        212: return 8'(NBLK);
        default: return 8'h00;
      endcase
    endfunction
    function bit [7:0] rbyte(int i);
      return xcsd ? ext(i) : mem[(baddr + i) % MEMB];
    endfunction
    function int nclk();
      return (xcsd ? 512 : blklen) * sdm_cpb(w);
    endfunction
    function void send(bit [135:0] fr, int n);
      txs = fr; txn = n; txd = NCR - 1;
    endfunction
    function void r1(bit [5:0] i, int st, bit ap);
      send({sdm_frame(i, {8'h00, crc_e, ill, 9'h000, 4'(st), 1'b1, 2'b00, ap, 5'h00}, 1'b0), 88'h0}, 48);
      crc_e = 0; ill = 0;
    endfunction
    function void frame(bit [47:0] f, bit em);
      bit [5:0] i = f[45:40];
      bit [31:0] a = f[39:8];
      int st = cst;
      bit wa = app;
      if (sdm_crc7({80'h0, f[47:8]}, 40) != f[7:1] || !f[0] || !f[46]) begin crc_e = 1; return; end
      app = 0;
      if (i == 0) begin cst = 0; polls = 0; rca = 0; w = 0; blklen = 512; dm = 0; multi = 0; end
      else if (!em && i == 8 && cst == 0) begin
        if (a[11:8] == 4'h1) send({sdm_frame(6'd8, {20'h0, a[11:0]}, 1'b0), 88'h0}, 48);
      end else if (em && i == 8 && cst == 4) begin
        r1(i, st, 1'b0); xcsd = 1; multi = 0; baddr = 0; dm = 7; cst = 5;
      end else if (!em && i == 55 && cst != 2 && cst <= 4) begin
        app = 1; r1(i, st, 1'b1);
      end else if (!em && i == 41 && wa && cst <= 1) begin
        bit rdy = polls >= POLLS;
        if (polls != 15) polls++;
        if (rdy) cst = 1;
        send({2'b00, 6'h3F, rdy, rdy, 6'h00, 24'hFF8000, 8'hFF, 88'h0}, 48);
      end else if (em && i == 1 && cst == 0) begin
        bit rdy = polls >= POLLS;
        if (polls != 15) polls++;
        if (rdy) cst = 1;
        send({2'b00, 6'h3F, rdy, 2'b10, 29'h00FF_8080, 8'hFF, 88'h0}, 48);
      end else if (i == 2 && cst == 1) begin
        bit [119:0] body = em ? SDM_CID_EMMC : SDM_CID_SD;
        cst = 2; send({2'b00, 6'h3F, body, sdm_crc7(body, 120), 1'b1}, 136);
      end else if (!em && i == 3 && (cst == 2 || cst == 3)) begin
        cst = 3; rca = SD_RCA;
        send({sdm_frame(6'd3, {SD_RCA, crc_e, ill, 2'b00, 3'(st), 1'b1, 2'b00, 1'b0, 5'h00}, 1'b0), 88'h0}, 48);
        crc_e = 0; ill = 0;
      end else if (em && i == 3 && cst == 2 && a[31:16] != 0) begin
        cst = 3; rca = a[31:16]; r1(i, st, 1'b0);
      end else if (i == 7 && (cst == 3 || cst == 4)) begin
        if (a[31:16] == rca) begin cst = 4; r1(i, st, 1'b0); dm = 6; end
        else if (cst == 4) cst = 3;
      end else if (i == 13 && cst >= 3) begin
        if (a[31:16] == rca) r1(i, st, 1'b0);
      end else if (!em && i == 6 && wa && cst == 4 && a[0] == 1'b0) begin
        w = a[1] ? 2'd1 : 2'd0; r1(i, st, 1'b1);
      end else if (em && i == 6 && cst == 4 && a[25:24] == 2'b11 && a[23:16] == 8'd183 && a[15:8] <= 2) begin
        w = a[9:8]; r1(i, st, 1'b0); dm = 6;
      end else if (i == 16 && cst == 4 && a != 0 && a <= 512) begin
        blklen = int'(a); r1(i, st, 1'b0);
      end else if ((i == 17 || i == 18 || i == 24 || i == 25) && cst == 4) begin
        r1(i, st, 1'b0);
        baddr = int'((a * blklen) % MEMB); multi = (i == 18 || i == 25); xcsd = 0;
        if (i == 17 || i == 18) begin dm = 7; cst = 5; end
        else begin dm = 1; cst = 6; end
      end else if (i == 12 && (cst == 5 || cst == 6)) begin
        r1(i, st, 1'b0); dm = 6; cst = 4; multi = 0; xcsd = 0;
      end else ill = 1;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(sdm_config)::get(this, "", "cfg", cfg))
        cfg = sdm_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(sdm_transaction t);
      if (!minit) begin for (int i = 0; i < MEMB; i++) mem[i] = sdm_init_byte(i); minit = 1; end
      t.so.delete();
      foreach (t.mo[i]) begin
        bit cl, em;
        bit [7:0] dl, m;
        em = t.mo[i][11];
        t.so.push_back({o_cmd_oe, o_cmd & o_cmd_oe, o_dat_oe, o_dat & o_dat_oe});
        cl = t.mo[i][10] ? t.mo[i][9] : (o_cmd_oe ? o_cmd : 1'b1);
        for (int l = 0; l < 8; l++) dl[l] = t.mo[i][8] ? t.mo[i][l] : (o_dat_oe[l] ? o_dat[l] : 1'b1);
        m = sdm_mask(w);
        // command receiver (not while a response goes out)
        if (txd == 0 && txn == 0) begin
          if (rxc == 0) begin if (!cl) begin rxc = 1; rxs = 0; end end
          else begin
            rxs = {rxs[46:0], cl}; rxc++;
            if (rxc == 48) begin rxc = 0; frame(rxs, em); m = sdm_mask(w); end
          end
        end
        // write block receiver
        case (dm)
          1: if (!dl[0]) begin dm = 2; dcnt = 0; c = '{0, 0, 0, 0, 0, 0, 0, 0}; end
          2: begin
               int s = dcnt % sdm_cpb(w), bi = dcnt / sdm_cpb(w);
               if (w == 2) wbuf[bi] = dl;
               else if (w == 1) begin if (s == 0) acc[7:4] = dl[3:0]; else wbuf[bi] = {acc[7:4], dl[3:0]}; end
               else begin acc = {acc[6:0], dl[0]}; if (s == 7) wbuf[bi] = acc; end
               for (int l = 0; l < 8; l++) if (m[l]) c[l] = sdm_crc16(c[l], dl[l]);
               if (++dcnt == nclk()) begin dm = 3; dcnt = 0; rc = '{0, 0, 0, 0, 0, 0, 0, 0}; end
             end
          3: begin
               for (int l = 0; l < 8; l++) if (m[l]) rc[l] = {rc[l][14:0], dl[l]};
               if (++dcnt == 16) dm = 4;
             end
          4: begin
               bit good = (dl & m) == m && rc == c;
               if (good) for (int k = 0; k < blklen; k++) mem[(baddr + k) % MEMB] = wbuf[k];
               tok = good ? 5'b0_010_1 : 5'b0_101_1;
               dm = 5; tokd = 1; tokn = 5; busyn = good ? BUSY : 0;
               baddr = (baddr + blklen) % MEMB;
             end
          default: ;
        endcase
        // outputs for the next period
        if (txd > 0) begin txd--; o_cmd_oe = 0; end
        else if (txn > 0) begin
          o_cmd_oe = 1; o_cmd = txs[135]; txs = txs << 1; txn--;
          if (txn == 0 && dm == 7) begin dm = 8; rdd = NAC; end
          if (txn == 0 && dm == 6) begin dm = 5; tokd = 2; tokn = 0; busyn = RBUSY; end
        end else o_cmd_oe = 0;
        case (dm)
          5: if (tokd > 0) begin tokd--; o_dat_oe = 0; end
             else if (tokn > 0) begin o_dat_oe = 8'h01; o_dat[0] = tok[4]; tok = tok << 1; tokn--; end
             else if (busyn > 0) begin o_dat_oe = 8'h01; o_dat[0] = 1'b0; busyn--; end
             else begin
               o_dat_oe = 0;
               if (cst == 6 && multi) dm = 1;
               else begin dm = 0; if (cst == 6) cst = 4; end
             end
          8: if (rdd > 0) begin rdd--; o_dat_oe = 0; end
             else begin o_dat_oe = m; o_dat = 8'h00; dm = 9; dcnt = 0; c = '{0, 0, 0, 0, 0, 0, 0, 0}; end
          9: begin
               bit [7:0] v = sdm_lines(w, rbyte(dcnt / sdm_cpb(w)), dcnt % sdm_cpb(w));
               o_dat_oe = m; o_dat = v & m;
               for (int l = 0; l < 8; l++) if (m[l]) c[l] = sdm_crc16(c[l], v[l]);
               if (++dcnt == nclk()) begin dm = 10; dcnt = 0; end
             end
          10: begin
                o_dat_oe = m;
                for (int l = 0; l < 8; l++) begin o_dat[l] = m[l] & c[l][15]; c[l] = c[l] << 1; end
                if (++dcnt == 16) dm = 11;
              end
          11: begin
                o_dat_oe = m; o_dat = m;
                if (multi) begin baddr = (baddr + blklen) % MEMB; rdd = NAC; dm = 8; end
                else dm = 12;
              end
          12: begin o_dat_oe = 0; dm = 0; cst = 4; xcsd = 0; end
          default: o_dat_oe = 0;
        endcase
      end
    endfunction

    function void write_exp(sdm_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(sdm_transaction t);
      sdm_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        sdm_transaction e = exp_q.pop_front();
        sdm_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("sdm scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class sdm_env extends uvm_env;
    `uvm_component_utils(sdm_env)
    sdm_agent      agt;
    sdm_scoreboard sb;
    sdm_checker    chk;
    sdm_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = sdm_agent     ::type_id::create("agt", this);
      sb  = sdm_scoreboard::type_id::create("sb",  this);
      chk = sdm_checker   ::type_id::create("chk", this);
      cov = sdm_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
