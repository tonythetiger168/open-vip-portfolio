// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_checker.svh -- SDM protocol checker on monitored items

class sdm_checker extends uvm_component;
  `uvm_component_utils(sdm_checker)
  uvm_analysis_imp #(sdm_transaction, sdm_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  sdm_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(sdm_config)::get(this, "", "cfg", cfg))
      cfg = sdm_config::type_id::create("cfg");
  endfunction

  function void fail(sdm_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("SDM: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(sdm_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      foreach (t.so[i]) begin
        if (t.so[i][17] && t.mo[i][10]) fail(t, "host and card drive CMD together");
        if (t.so[i][15:8] != 0 && t.mo[i][8]) fail(t, "host and card drive DAT together");
      end
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("SDM checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
