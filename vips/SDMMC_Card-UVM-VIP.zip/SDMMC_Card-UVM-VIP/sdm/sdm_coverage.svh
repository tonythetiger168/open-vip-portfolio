// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_coverage.svh -- SDM functional coverage

class sdm_coverage extends uvm_subscriber #(sdm_transaction);
  `uvm_component_utils(sdm_coverage)
  sdm_config cfg;
  sdm_transaction tr;

  covergroup sdm_cg;
    cp_idx  : coverpoint tr.idx { bins c0 = {0}; bins c1 = {1}; bins c2 = {2}; bins c3 = {3}; bins c6 = {6}; bins c7 = {7};
                                  bins c8 = {8}; bins c12 = {12}; bins c13 = {13}; bins c16 = {16}; bins c17 = {17};
                                  bins c18 = {18}; bins c24 = {24}; bins c25 = {25}; bins c41 = {41}; bins c55 = {55};
                                  bins sw = {63}; }
    cp_got  : coverpoint tr.got;
    cp_len  : coverpoint tr.mo.size() { bins sw = {[1:40]}; bins cmd = {[100:260]}; bins blk = {[261:1500]};
                                        bins blk1 = {[1501:20000]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    sdm_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(sdm_config)::get(this, "", "cfg", cfg))
      cfg = sdm_config::type_id::create("cfg");
  endfunction

  function void write(sdm_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    sdm_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SDM coverage: %0.1f%%", sdm_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
