// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_transaction.svh -- SDM transaction

class sdm_transaction extends uvm_sequence_item;
  `uvm_object_utils(sdm_transaction)

  // request (driven by the agent)
  bit [11:0] mo[$];
  // response (returned by the DUT)
  bit [17:0] so[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [3:0] blk;
  rand bit [1:0] cnt;
  rand bit [31:0] seed;
  bit [5:0] idx;
  bit [31:0] arg;
  bit got;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "sdm_transaction"); super.new(name); endfunction

  // kind: 0 CMD0, 1 CMD8 (SD: VHS 1, eMMC: SEND_EXT_CSD), 2 CMD55, 3 ACMD41
  // (HCS), 4 CMD1, 5 CMD2, 6 CMD3 (eMMC: RCA 1 + blk), 7 CMD7 (RCA), 8 CMD7
  // (other RCA), 9 CMD13, 10 ACMD6 (seed[0]: 4-bit), 11 CMD6 SWITCH bus width
  // seed % 3, 12 CMD16 (64 << seed[1:0] bytes, seed[2]: 512), 13 CMD17, 14
  // CMD18 + CMD12 (cnt + 1 blocks), 15 CMD24, 16 CMD25 + CMD12, 17 CMD24 with
  // a bad CRC16, 18 CMD13 with a bad CRC7, 19 CMD12 alone, 20 CMD18 stopped
  // in its first block, 21 personality switch (no command), 22-31 CMD17 /
  // CMD24 / CMD13 / CMD18 mix
  function void set(int k, int b = 0, int n = 0, bit [31:0] s = 32'h1); kind = k; blk = b; cnt = n; seed = s; endfunction
  function int kk();
    if (kind >= 22) return (kind % 4 == 0) ? 13 : (kind % 4 == 1) ? 15 : (kind % 4 == 2) ? 9 : 14;
    return kind;
  endfunction
  function int nblocks();
    return int'(cnt) + 1;
  endfunction
  function bit [47:0] cmd(bit [15:0] rca, bit em);
    case (kk())
      0: begin idx = 0; arg = 0; end
      1: begin idx = 8; arg = em ? 32'h0 : 32'h0000_01AA; end
      2: begin idx = 55; arg = {rca, 16'h0}; end
      3: begin idx = 41; arg = 32'h40FF_8000; end
      4: begin idx = 1; arg = 32'h40FF_8080; end
      5: begin idx = 2; arg = 0; end
      6: begin idx = 3; arg = em ? {16'h1 + 16'(blk), 16'h0} : 32'h0; end
      7: begin idx = 7; arg = {rca, 16'h0}; end
      8: begin idx = 7; arg = {rca ^ 16'h0101, 16'h0}; end
      9, 18: begin idx = 13; arg = {rca, 16'h0}; end
      10: begin idx = 6; arg = seed[0] ? 32'h2 : 32'h0; end
      11: begin idx = 6; arg = {6'h0, 2'b11, 8'd183, 8'(seed % 3), 8'h0}; end
      12: begin idx = 16; arg = seed[2] ? 32'd512 : (32'd64 << seed[1:0]); end
      13: begin idx = 17; arg = {28'h0, blk}; end
      14, 20: begin idx = 18; arg = {28'h0, blk}; end
      15, 17: begin idx = 24; arg = {28'h0, blk}; end
      16: begin idx = 25; arg = {28'h0, blk}; end
      19: begin idx = 12; arg = 0; end
      default: begin idx = 63; arg = 0; end
    endcase
    if (kk() == 18) return sdm_frame(idx, arg) ^ 48'h4;
    return sdm_frame(idx, arg);
  endfunction
  function bit [7:0] wbyte(int blkno, int i);
    bit [31:0] x = (seed | 1) ^ (32'(blkno) * 32'h9E37_79B9) ^ (32'(i) * 32'h85EB_CA6B);
    x ^= x >> 15; x *= 32'h2C1B_3C6D; x ^= x >> 12;
    return x[7:0];
  endfunction
  function bit bad_crc(); return kk() == 17; endfunction

  function void do_copy(uvm_object rhs);
    sdm_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mo = rhs_.mo;
    so = rhs_.so;
    kind = rhs_.kind;
    blk = rhs_.blk;
    cnt = rhs_.cnt;
    seed = rhs_.seed;
    idx = rhs_.idx;
    arg = rhs_.arg;
    got = rhs_.got;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sdm_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(sdm_transaction rhs_);
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    return 1;
  endfunction

  function string qstr_mo();
    string s = $sformatf("[%0d]{", mo.size());
    foreach (mo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", mo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SDM{tag=%0d mo=%s so=%s}", tag, qstr_mo(), qstr_so());
  endfunction
endclass
