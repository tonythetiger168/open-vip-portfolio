// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_defs.sv -- SDM shared type definitions

package sdm_defs_pkg;

  typedef enum bit [1:0] {SDM_OK, SDM_ERR} sdm_status_e;

  function automatic bit [6:0] sdm_crc7(bit [119:0] d, int n);   // over d[n-1:0], MSB first
    bit [6:0] c = 0;
    for (int i = n - 1; i >= 0; i--) begin
      bit fb = d[i] ^ c[6];
      c = {c[5:0], 1'b0};
      if (fb) c ^= 7'h09;
    end
    return c;
  endfunction
  function automatic bit [15:0] sdm_crc16(bit [15:0] c, bit b);
    bit fb = b ^ c[15];
    return {c[14:0], 1'b0} ^ (fb ? 16'h1021 : 16'h0000);
  endfunction
  function automatic bit [47:0] sdm_frame(bit [5:0] i, bit [31:0] a, bit tx = 1'b1);
    bit [39:0] b = {1'b0, tx, i, a};
    return {b, sdm_crc7({80'h0, b}, 40), 1'b1};
  endfunction
  function automatic bit [7:0] sdm_init_byte(int i);
    return 8'(i ^ (i >> 8) ^ 8'hA5);
  endfunction
  // lines in use and clocks per byte for a bus-width code (0: 1, 1: 4, 2: 8 bits)
  function automatic bit [7:0] sdm_mask(bit [1:0] w);
    return (w == 2) ? 8'hFF : (w == 1) ? 8'h0F : 8'h01;
  endfunction
  function automatic int sdm_cpb(bit [1:0] w);
    return (w == 2) ? 1 : (w == 1) ? 2 : 8;
  endfunction
  // the lines' values for clock s (0 .. cpb - 1) of byte b
  function automatic bit [7:0] sdm_lines(bit [1:0] w, bit [7:0] b, int s);
    if (w == 2) return b;
    if (w == 1) return {4'hF, (s == 0) ? b[7:4] : b[3:0]};
    return {7'h7F, b[7 - s]};
  endfunction
  localparam bit [119:0] SDM_CID_SD   = 120'h1D4F5653444D43311012345678016A;
  localparam bit [119:0] SDM_CID_EMMC = 120'h150100454D4D4344361087654321A8;

endpackage
