// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_pkg.sv -- SDM UVM VIP package

package sdm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import sdm_defs_pkg::*;
  export sdm_defs_pkg::*;

  `include "sdm_transaction.svh"
  `include "sdm_config.svh"
  `include "sdm_sequencer.svh"
  `include "sdm_driver.svh"
  `include "sdm_monitor.svh"
  `include "sdm_agent.svh"
  `include "sdm_sequences.svh"
  `include "sdm_checker.svh"
  `include "sdm_coverage.svh"
endpackage
