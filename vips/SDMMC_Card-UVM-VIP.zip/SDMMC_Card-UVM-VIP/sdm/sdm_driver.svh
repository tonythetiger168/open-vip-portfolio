// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_driver.svh -- SDM driver: one item per command with sd_clk running: the 48-bit command, a response hunt of up to 64 clocks and the response; R1b busy waits; CMD17 / CMD8 EXT_CSD read blocks, CMD24 write blocks with token and busy, and for CMD18 / CMD25 cnt + 1 blocks followed by CMD12 and its busy (kind 20 sends CMD12 in the middle of the first block); a personality item flips emmc; then 8 idle clocks and sd_clk stopped for cfg.gap clocks

class sdm_driver extends uvm_driver #(sdm_transaction);
  `uvm_component_utils(sdm_driver)

  uvm_analysis_port #(sdm_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual sdm_if vif;
  sdm_config cfg;

  bit [15:0]      rca = 0;
  bit             em = 0;
  bit [1:0]       w = 0;
  int             blklen = 512;
  sdm_transaction cur;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sdm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sdm: virtual interface not set")
    if (!uvm_config_db#(sdm_config)::get(this, "", "cfg", cfg))
      cfg = sdm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    sdm_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.sd_clk   <= 1'b1;
    vif.drv_cb.emmc     <= 1'b0;
    vif.drv_cb.cmd_m    <= 1'b0;
    vif.drv_cb.cmd_m_oe <= 1'b0;
    vif.drv_cb.dat_m    <= 8'h0;
    vif.drv_cb.dat_m_oe <= 1'b0;
  endtask

  task drive_item(sdm_transaction t);
    bit cl, g12;
    bit [7:0] dl;
    bit [47:0] f;
    bit [135:0] r, r12;
    cur = t;
    t.mo.delete();
    f = t.cmd(rca, em);
    t.got = 0;
    @(vif.drv_cb);
    repeat (4) idle1(cl, dl);
    if (t.idx == 63) begin
      em = ~em;
      repeat (4) idle1(cl, dl);
    end else begin
      command(f, (t.idx == 2) ? 136 : 48, t.got, r);
      if (t.idx == 0) begin rca = 0; w = 0; blklen = 512; end
      if (t.got) begin
        if (t.idx == 3) rca = em ? t.arg[31:16] : r[39:24];
        if (t.idx == 6 && !em) w = t.arg[1] ? 2'd1 : 2'd0;
        if (t.idx == 6 && em) w = t.arg[9:8];
        if (t.idx == 16) blklen = int'(t.arg);
        if (t.idx == 7 || t.idx == 12 || (t.idx == 6 && em)) busy_wait();
        if (t.idx == 8 && em) read_blk(512);
        if (t.idx == 17) read_blk(blklen);
        if (t.idx == 24) write_blk(t, 0);
        if (t.idx == 18 && t.kk() == 20) begin
          int k = 0;
          do begin idle1(cl, dl); k++; end while (dl[0] && k < 64);
          repeat (8) idle1(cl, dl);
          command(sdm_frame(6'd12, 32'h0), 48, g12, r12);
          if (g12) busy_wait();
        end else if (t.idx == 18) begin
          for (int b = 0; b < t.nblocks(); b++) read_blk(blklen);
          command(sdm_frame(6'd12, 32'h0), 48, g12, r12);
          if (g12) busy_wait();
        end
        if (t.idx == 25) begin
          for (int b = 0; b < t.nblocks(); b++) write_blk(t, b);
          command(sdm_frame(6'd12, 32'h0), 48, g12, r12);
          if (g12) busy_wait();
        end
      end
    end
    repeat (8) idle1(cl, dl);
    repeat (cfg.gap) @(vif.drv_cb);
  endtask

  // one sd_clk period: outputs at the falling edge, the lines at the rising edge
  task automatic clk1(bit co, bit c, bit doe, bit [7:0] d, output bit cl, output bit [7:0] dl);
    vif.drv_cb.sd_clk   <= 1'b0;
    vif.drv_cb.emmc     <= em;
    vif.drv_cb.cmd_m_oe <= co; vif.drv_cb.cmd_m <= c;
    vif.drv_cb.dat_m_oe <= doe; vif.drv_cb.dat_m <= d;
    repeat (cfg.half) @(vif.drv_cb);
    vif.drv_cb.sd_clk <= 1'b1;
    cl = co ? c : (vif.drv_cb.cmd_s_oe ? vif.drv_cb.cmd_s : 1'b1);
    for (int i = 0; i < 8; i++) dl[i] = doe ? d[i] : (vif.drv_cb.dat_s_oe[i] ? vif.drv_cb.dat_s[i] : 1'b1);
    cur.mo.push_back({em, co, c & co, doe, d & {8{doe}}});
    repeat (cfg.half) @(vif.drv_cb);
  endtask
  task automatic idle1(output bit cl, output bit [7:0] dl);
    clk1(1'b0, 1'b0, 1'b0, 8'h0, cl, dl);
  endtask
  // a command and its response (hunted for 64 clocks); got / r
  task automatic command(bit [47:0] f, int len, output bit got, output bit [135:0] r);
    bit cl;
    bit [7:0] dl;
    int k = 0;
    got = 0; r = 0;
    repeat (2) idle1(cl, dl);
    for (int i = 47; i >= 0; i--) clk1(1'b1, f[i], 1'b0, 8'h0, cl, dl);
    while (k < 64 && !got) begin idle1(cl, dl); if (!cl) got = 1; k++; end
    if (got) for (int i = 1; i < len; i++) begin idle1(cl, dl); r = {r[134:0], cl}; end
  endtask
  // wait out DAT0 busy: up to 8 clocks for it to start, 512 for it to end
  task automatic busy_wait();
    bit cl;
    bit [7:0] dl;
    int k = 0;
    do begin idle1(cl, dl); k++; end while (dl[0] && k < 8);
    k = 0;
    while (!dl[0] && k < 512) begin idle1(cl, dl); k++; end
  endtask
  task automatic read_blk(int n);
    bit cl;
    bit [7:0] dl;
    int k = 0;
    do begin idle1(cl, dl); k++; end while (dl[0] && k < 64);
    if (!dl[0]) repeat (n * sdm_cpb(w) + 16 + 1) idle1(cl, dl);
  endtask
  task automatic write_blk(sdm_transaction t, int b);
    bit cl;
    bit [7:0] dl, m = sdm_mask(w), v;
    bit [15:0] c [8] = '{0, 0, 0, 0, 0, 0, 0, 0};
    int k;
    idle1(cl, dl); idle1(cl, dl);
    clk1(1'b0, 1'b0, 1'b1, 8'hFF, cl, dl);
    clk1(1'b0, 1'b0, 1'b1, ~m, cl, dl);
    for (int i = 0; i < blklen; i++)
      for (int s = 0; s < sdm_cpb(w); s++) begin
        v = sdm_lines(w, t.wbyte(b, i), s);
        for (int l = 0; l < 8; l++) if (m[l]) c[l] = sdm_crc16(c[l], v[l]);
        clk1(1'b0, 1'b0, 1'b1, v, cl, dl);
      end
    if (t.bad_crc()) c[0][t.seed[3:0]] ^= 1'b1;
    for (int n = 15; n >= 0; n--) begin
      for (int l = 0; l < 8; l++) v[l] = m[l] ? c[l][n] : 1'b1;
      clk1(1'b0, 1'b0, 1'b1, v, cl, dl);
    end
    clk1(1'b0, 1'b0, 1'b1, 8'hFF, cl, dl);
    k = 0;
    do begin idle1(cl, dl); k++; end while (dl[0] && k < 64);
    if (!dl[0]) begin
      repeat (4) idle1(cl, dl);
      k = 0;
      do begin idle1(cl, dl); k++; end while (!dl[0] && k < 512);
    end
  endtask
endclass
