// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_compliance_checker.sv -- SDM concurrent assertion checks (bindable)

module sdm_compliance_checker
  (input logic clk, input logic rst_n, input logic sd_clk, input logic emmc, input logic cmd_m, input logic cmd_m_oe, input logic [7:0] dat_m, input logic dat_m_oe, input logic cmd_s, input logic cmd_s_oe, input logic [7:0] dat_s, input logic [7:0] dat_s_oe);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({sd_clk, emmc, cmd_m_oe, dat_m_oe, cmd_s_oe, dat_s_oe}))
    else $error("SDM: X on sd_clk, emmc or an enable");
  assert property (@(posedge clk) disable iff (!rst_n) !(cmd_m_oe && cmd_s_oe))
    else $error("SDM: host and card drive CMD together");
  assert property (@(posedge clk) disable iff (!rst_n) !(dat_m_oe && dat_s_oe != 8'h0))
    else $error("SDM: host and card drive DAT together");
  assert property (@(posedge clk) disable iff (!rst_n) dat_s_oe inside {8'h00, 8'h01, 8'h0F, 8'hFF})
    else $error("SDM: card drives a line set that is no bus width");
  assert property (@(posedge clk) disable iff (!rst_n) $changed({cmd_s_oe, cmd_s, dat_s_oe, dat_s}) |-> !sd_clk)
    else $error("SDM: card output changed while sd_clk is high");
  cover property (@(posedge clk) disable iff (!rst_n) dat_s_oe == 8'hFF);
endmodule
