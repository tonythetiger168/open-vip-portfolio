// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdm_sequences.svh -- SDM sequences

// Random traffic: cfg.num_items constrained-random items.
class sdm_base_sequence extends uvm_sequence #(sdm_transaction);
  `uvm_object_utils(sdm_base_sequence)
  sdm_config cfg;

  function new(string name = "sdm_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = sdm_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "sdm_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class sdm_directed_sequence extends uvm_sequence #(sdm_transaction);
  `uvm_object_utils(sdm_directed_sequence)
  sdm_config cfg;

  function new(string name = "sdm_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function sdm_transaction item();
    item = sdm_transaction::type_id::create("req");
  endfunction

  task send(sdm_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    sdm_transaction t;
    // SD in 1 and 4 bits, then eMMC in 1, 4 and 8 bits, with every error path
    t = item(); t.set(9); send(t);              // illegal in idle
    t = item(); t.set(0); send(t);
    t = item(); t.set(1); send(t);              // R7
    t = item(); t.set(3); send(t);              // ACMD41 without CMD55: illegal
    for (int p = 0; p < 3; p++) begin t = item(); t.set(2); send(t); t = item(); t.set(3); send(t); end
    t = item(); t.set(5); send(t);
    t = item(); t.set(6); send(t);              // R6
    t = item(); t.set(18); send(t);             // bad CRC7
    t = item(); t.set(9); send(t);
    t = item(); t.set(7); send(t);              // R1b
    t = item(); t.set(13, 1); send(t);
    t = item(); t.set(15, 1, 0, 32'h11); send(t);
    t = item(); t.set(13, 1); send(t);
    t = item(); t.set(2); send(t); t = item(); t.set(10, 0, 0, 32'h1); send(t);   // 4-bit
    t = item(); t.set(16, 2, 1, 32'h22); send(t);
    t = item(); t.set(14, 2, 1); send(t);
    t = item(); t.set(17, 4, 0, 32'h33); send(t);
    t = item(); t.set(13, 4); send(t);
    t = item(); t.set(12, 0, 0, 32'h0); send(t); // 64-byte blocks
    t = item(); t.set(15, 3, 0, 32'h44); send(t);
    t = item(); t.set(14, 3, 2); send(t);
    t = item(); t.set(20, 1); send(t);          // stopped mid-block
    t = item(); t.set(19); send(t);             // CMD12 in tran: illegal
    t = item(); t.set(9); send(t);
    t = item(); t.set(8); send(t);              // deselect
    t = item(); t.set(13); send(t);             // illegal in stby
    t = item(); t.set(7); send(t);
    t = item(); t.set(21); send(t);             // eMMC
    t = item(); t.set(0); send(t);
    for (int p = 0; p < 3; p++) begin t = item(); t.set(4); send(t); end
    t = item(); t.set(5); send(t);
    t = item(); t.set(6, 4); send(t);
    t = item(); t.set(7); send(t);
    t = item(); t.set(1); send(t);              // EXT_CSD, 1 bit
    t = item(); t.set(11, 0, 0, 32'd2); send(t); // 8-bit
    t = item(); t.set(1); send(t);
    t = item(); t.set(13, 2); send(t);
    t = item(); t.set(16, 5, 1, 32'h55); send(t);
    t = item(); t.set(14, 5, 1); send(t);
    t = item(); t.set(11, 0, 0, 32'd1); send(t); // 4-bit
    t = item(); t.set(12, 0, 0, 32'h1); send(t); // 128-byte blocks
    t = item(); t.set(15, 6, 0, 32'h66); send(t);
    t = item(); t.set(13, 6); send(t);
    t = item(); t.set(10); send(t);             // ACMD6 means nothing to eMMC
    t = item(); t.set(2); send(t);              // nor CMD55
    t = item(); t.set(9); send(t);
    t = item(); t.set(0); send(t);              // CMD0 from tran
    t = item(); t.set(13, 1); send(t);
  endtask
endclass
