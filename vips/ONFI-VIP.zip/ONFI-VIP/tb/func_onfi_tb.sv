// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_onfi_tb.sv -- self-checking functional test for the ONFI NAND model
// (onfi_nand_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py ONFI-VIP
//
// Model contract (from tb_top.sv and onfi_pkg.sv's driver), asynchronous
// SDR bus sampled on clk: command/address/data latched on the WE# rising
// edge (CLE / ALE / neither), data out on the RE# falling edge. Address
// cycles as the VIP driver sends them: column, page, block (erase: page,
// block); the model uses the last two bytes. 64 blocks x 64 pages x
// 256 bytes, erased = 0xFF. R/B# low for tR = 25, tPROG = 200,
// tBERS = 2000, tRST = 10 clocks. Status: [7] WP# (1 = not protected),
// [6] ready, [0] FAIL. READ ID returns "ONFI" + 01h; the parameter page
// starts with "ONFI" and ends with its CRC-16. 80h fills the page register
// with FFh; SET/GET FEATURES carry P1..P4; 00h after 70h during a page read
// resumes the data output.
//
// Not modelled (limitations, not tested): column addressing, the ONFI
// 2-column + 3-row address format, multi-plane/cache operations.

module func_onfi_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic       clk = 1'b0, rst_n = 1'b0;
  logic       cle = 1'b0, ale = 1'b0, ce_n = 1'b1, re_n = 1'b1, we_n = 1'b1, wp_n = 1'b1;
  logic [7:0] dout = '0;
  logic       drv = 1'b0;
  wire  [7:0] io;
  wire        rb_n;

  assign io = drv ? dout : 8'hzz;
  always #5 clk = ~clk;

  onfi_nand_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_io(io), .vif_cle(cle), .vif_ale(ale),
    .vif_ce_n(ce_n), .vif_re_n(re_n), .vif_we_n(we_n), .vif_wp_n(wp_n), .vif_rb_n(rb_n)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // ---------------- bus cycles ----------------
  task automatic wcycle(input bit c, input bit a, input [7:0] v);
    @(negedge clk);
    ce_n = 1'b0; cle = c; ale = a; dout = v; drv = 1'b1;
    @(negedge clk); we_n = 1'b0;
    repeat (2) @(negedge clk);
    we_n = 1'b1;
    @(negedge clk);
    cle = 1'b0; ale = 1'b0; drv = 1'b0;
  endtask
  task automatic cmd(input [7:0] c);  wcycle(1, 0, c); endtask
  task automatic adr(input [7:0] a);  wcycle(0, 1, a); endtask
  task automatic din(input [7:0] d);  wcycle(0, 0, d); endtask
  task automatic dout_cyc(output [7:0] d, input int low = 2);
    @(negedge clk);
    ce_n = 1'b0; drv = 1'b0;
    re_n = 1'b0;
    repeat (low) @(negedge clk);
    d = io;
    re_n = 1'b1;
    @(negedge clk);
  endtask

  // R/B# low time after the last command (clocks); -1 if it never went low
  int busy;
  task automatic wait_rdy(input int max = 5000);
    int k;
    busy = 0; k = 0;
    while (rb_n === 1'b1 && k < 4) begin @(negedge clk); k++; end   // tWB
    if (rb_n === 1'b1) begin busy = -1; return; end
    while (rb_n !== 1'b1 && busy < max) begin @(negedge clk); busy++; end
  endtask

  logic [7:0] st;
  task automatic status(output [7:0] s);
    cmd(8'h70);
    dout_cyc(s);
  endtask

  task automatic page_read(input [7:0] blk, input [7:0] pg);
    cmd(8'h00); adr(8'h00); adr(pg); adr(blk); cmd(8'h30);
    wait_rdy();
  endtask

  logic [7:0] rbuf [0:299];
  task automatic read_bytes(input int n, input bit gaps = 0);
    for (int i = 0; i < n; i++) begin
      dout_cyc(rbuf[i]);
      if (gaps) repeat ($urandom_range(3)) @(negedge clk);   // RE# held high longer
    end
  endtask

  function automatic logic [7:0] pat(input [7:0] blk, input [7:0] pg, input int i);
    return 8'(i * 7 + blk * 13 + pg * 3 + 1);
  endfunction

  task automatic prog_page(input [7:0] blk, input [7:0] pg, input int n);
    cmd(8'h80); adr(8'h00); adr(pg); adr(blk);
    repeat (2) @(negedge clk);               // tADL
    for (int i = 0; i < n; i++) din(pat(blk, pg, i));
    cmd(8'h10);
    wait_rdy();
  endtask

  task automatic erase(input [7:0] blk);
    cmd(8'h60); adr(8'h00); adr(blk); cmd(8'hD0);
    wait_rdy();
  endtask

  function automatic bit page_is(input [7:0] blk, input [7:0] pg, input int n, input bit erased_tail = 1);
    for (int i = 0; i < 256; i++)
      if (rbuf[i] !== ((i < n) ? pat(blk, pg, i) : 8'hFF)) return 0;
    return 1;
  endfunction
  function automatic bit all_ff();
    for (int i = 0; i < 256; i++) if (rbuf[i] !== 8'hFF) return 0;
    return 1;
  endfunction

  // ONFI parameter page CRC-16: poly 0x8005, init 0x4F4E, MSB first
  function automatic logic [15:0] onfi_crc(input int n);
    logic [15:0] c;
    c = 16'h4F4E;
    for (int i = 0; i < n; i++)
      for (int b = 7; b >= 0; b--) begin
        logic x;
        x = c[15] ^ rbuf[i][b];
        c = {c[14:0], 1'b0};
        if (x) c ^= 16'h8005;
      end
    return c;
  endfunction

  bit ok;
  initial begin
    repeat (3) @(negedge clk);
    chk(rb_n === 1'b1 && io === 8'hzz, "reset: ready, IO bus released");
    rst_n = 1'b1;
    @(negedge clk);

    // ---- READ ID / parameter page ----
    cmd(8'h90); adr(8'h20);
    read_bytes(6);
    chk(rbuf[0] == "O" && rbuf[1] == "N" && rbuf[2] == "F" && rbuf[3] == "I",
        "READ ID (address 20h) returns the ONFI signature");
    chk(rbuf[4] == 8'h01 && rbuf[5] == "O", "READ ID 5th byte 01h, then wraps");
    @(negedge clk); ce_n = 1'b1; re_n = 1'b0;
    repeat (2) @(negedge clk);
    chk(io === 8'hzz, "IO not driven with CE# high");
    re_n = 1'b1;
    // the data pointer advances once per RE# rising edge with CE# low only
    begin
      logic [7:0] b0, b1, b2;
      cmd(8'h90); adr(8'h20);
      dout_cyc(b0, 5);                            // RE# held low for 5 clocks
      @(negedge clk); ce_n = 1'b1;
      repeat (3) begin re_n = 1'b0; @(negedge clk); re_n = 1'b1; @(negedge clk); end
      dout_cyc(b1);
      dout_cyc(b2, 4);
      chk(b0 == "O" && b1 == "N" && b2 == "F",
          "one byte per RE# pulse however long RE# is low; RE# pulses with CE# high are ignored");
    end
    cmd(8'hEC); adr(8'h00);
    read_bytes(256);
    chk(rbuf[0] == "O" && rbuf[1] == "N" && rbuf[2] == "F" && rbuf[3] == "I",
        "parameter page starts with the ONFI signature");
    chk({rbuf[255], rbuf[254]} == onfi_crc(254), "parameter page integrity CRC (bytes 254-255) valid");
    chk({rbuf[83], rbuf[82], rbuf[81], rbuf[80]} == 256 && {rbuf[95], rbuf[94], rbuf[93], rbuf[92]} == 64 &&
        {rbuf[99], rbuf[98], rbuf[97], rbuf[96]} == 64, "parameter page geometry: 256-byte pages, 64 pages, 64 blocks");

    // ---- status ----
    status(st);
    chk(st == 8'hC0, "READ STATUS: C0h (not protected, ready, pass)");
    wp_n = 1'b0;
    status(st);
    chk(st == 8'h40, "READ STATUS bit 7 low with WP# asserted");
    wp_n = 1'b1;

    // ---- read of an erased page ----
    page_read(8'd3, 8'd5);
    chk(busy == 25, "READ (00h-30h): R/B# low for tR = 25 clocks");
    read_bytes(257);
    chk(all_ff() && rbuf[256] == 8'hFF, "erased page reads FFh (and FFh past the page end)");

    // ---- program / read back ----
    prog_page(8'd3, 8'd5, 256);
    chk(busy == 200, "PROGRAM (80h-10h): R/B# low for tPROG = 200 clocks");
    status(st);
    chk(st == 8'hC0, "status after program: ready, pass");
    page_read(8'd3, 8'd5);
    read_bytes(256);
    chk(page_is(3, 5, 256), "programmed page reads back");
    page_read(8'd3, 8'd5);
    read_bytes(256, 1);
    chk(page_is(3, 5, 256), "page read with RE# high for 1..4 clocks between bytes");
    prog_page(8'd4, 8'd5, 256);
    prog_page(8'd3, 8'd6, 256);
    page_read(8'd3, 8'd5);
    read_bytes(256);
    ok = page_is(3, 5, 256);
    page_read(8'd4, 8'd5);
    read_bytes(256);
    ok &= page_is(4, 5, 256);
    page_read(8'd3, 8'd6);
    read_bytes(256);
    chk(ok && page_is(3, 6, 256), "pages in other blocks / pages are independent");

    // partial program after a read: 80h resets the page register to FFh
    page_read(8'd3, 8'd5);
    prog_page(8'd3, 8'd7, 4);
    page_read(8'd3, 8'd7);
    read_bytes(256);
    chk(rbuf[0] == pat(3, 7, 0) && rbuf[3] == pat(3, 7, 3), "partial program: written bytes stored");
    chk(page_is(3, 7, 4), "partial program: unwritten bytes of the page stay FFh");

    // ---- erase ----
    prog_page(8'd3, 8'd0, 256);
    prog_page(8'd3, 8'd63, 256);
    prog_page(8'd2, 8'd63, 256);
    erase(8'd3);
    chk(busy == 2000, "ERASE (60h-D0h): R/B# low for tBERS = 2000 clocks");
    status(st);
    chk(st == 8'hC0, "status after erase: ready, pass");
    page_read(8'd3, 8'd5);
    read_bytes(256);
    ok = all_ff();
    page_read(8'd3, 8'd6);
    read_bytes(256);
    chk(ok && all_ff(), "erased block reads FFh");
    page_read(8'd4, 8'd5);
    read_bytes(256);
    chk(page_is(4, 5, 256), "erase leaves other blocks intact");
    page_read(8'd3, 8'd0);
    read_bytes(256);
    ok = all_ff();
    page_read(8'd3, 8'd63);
    read_bytes(256);
    chk(ok && all_ff(), "erase clears the first and last page of the block");
    page_read(8'd2, 8'd63);
    read_bytes(256);
    chk(page_is(2, 63, 256), "erase leaves the last page of the previous block intact");

    // ---- write protect ----
    wp_n = 1'b0;
    prog_page(8'd5, 8'd0, 16);
    status(st);
    chk(st[7] == 1'b0 && st[0] == 1'b1, "program with WP# asserted: status protected + FAIL");
    erase(8'd4);
    status(st);
    chk(st[7] == 1'b0 && st[0] == 1'b1, "erase with WP# asserted: status protected + FAIL");
    wp_n = 1'b1;
    page_read(8'd5, 8'd0);
    read_bytes(256);
    ok = all_ff();
    page_read(8'd4, 8'd5);
    read_bytes(256);
    chk(ok && page_is(4, 5, 256), "write-protected program / erase leave the array unchanged");
    prog_page(8'd5, 8'd1, 8);
    status(st);
    chk(st == 8'hC0, "next program with WP# released passes (FAIL cleared)");

    // ---- features ----
    cmd(8'hEF); adr(8'h01);
    repeat (2) @(negedge clk);
    din(8'h05); din(8'h06); din(8'h07); din(8'h08);
    cmd(8'hEE); adr(8'h01);
    read_bytes(4);
    chk(rbuf[0] == 8'h05, "GET FEATURES returns P1 written by SET FEATURES");
    chk(rbuf[1] == 8'h06 && rbuf[2] == 8'h07 && rbuf[3] == 8'h08, "GET FEATURES returns P2..P4");
    cmd(8'hEE); adr(8'h02);
    read_bytes(1);
    chk(rbuf[0] == 8'h00, "unwritten feature address reads 00h");

    // ---- status polling during a read, then 00h to resume data output ----
    prog_page(8'd6, 8'd1, 256);
    cmd(8'h00); adr(8'h00); adr(8'd1); adr(8'd6); cmd(8'h30);
    repeat (3) @(negedge clk);
    status(st);
    chk(st[6] == 1'b0 && rb_n === 1'b0, "status bit 6 low while the array is busy");
    wait_rdy();
    status(st);
    chk(st[6] == 1'b1, "status bit 6 high once ready");
    cmd(8'h00);                               // back to data output
    read_bytes(4);
    chk(rbuf[0] == pat(6, 1, 0) && rbuf[3] == pat(6, 1, 3), "00h after 70h resumes page data output");

    // ---- RESET command ----
    cmd(8'hFF);
    wait_rdy();
    chk(busy == 10, "RESET (FFh): R/B# low for tRST = 10 clocks");
    status(st);
    chk(st == 8'hC0, "status after RESET: C0h");

    // ---- reset pin during erase ----
    erase_nowait: begin
      cmd(8'h60); adr(8'h00); adr(8'd6); cmd(8'hD0);
      repeat (20) @(negedge clk);
      chk(rb_n === 1'b0, "busy during erase");
      rst_n = 1'b0;
      @(negedge clk);
      chk(rb_n === 1'b1, "reset pin ends the busy period");
      rst_n = 1'b1;
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #3000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
