# Timer_WDT-UVM-VIP test plan

## Register test (`timer_wdt_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `timer_wdt_timer_test`: prescale 0, 1, 3, 7 and period 0, 1, 5, 23 with
  timestamp records into an 8- and a 5-word ring, the timer stopped and
  restarted, prescale and PERIOD changed on the fly (also below the
  running count); 12 phases of 600..2500 clocks. The
  model checks COUNT, IRQ_STATUS.TIMER and every record (address, data,
  order); TS_WP + TS_MISSED = recorded events, no record missed with an idle
  bus.
- `timer_wdt_wdt_test`: watchdog with WDT_LOAD 20, 10, 60 and prescale 0 / 2:
  kicked in time for a long run (no BARK, no bite), then left alone: BARK,
  then wdt_reset high one timeout later (pin checked every clock); a kick
  drops wdt_reset; wdt_en = 0 drops it; BARK again after re-enabling.
- `timer_wdt_ts_test`: records under heavy AXI back-pressure with period 0
  (events faster than records): TS_MISSED counts the skipped events and
  TS_WP + TS_MISSED = events; a record into a SLVERR region sets TS_ERR.
  The IP never reads (no AR at all) and writes with ID 11.
