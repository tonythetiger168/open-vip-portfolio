// Timer_WDT-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+timer_wdt
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/Timer_WDT_top.sv
rtl/Timer_WDT_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
timer_wdt/timer_wdt_pins_if.sv
common/ssv_pkg.sv
timer_wdt/timer_wdt_pkg.sv
tb/top_tb.sv
