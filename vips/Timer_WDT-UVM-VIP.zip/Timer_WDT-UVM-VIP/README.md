# Timer_WDT UVM VIP (Timer_WDT-UVM-VIP)

UVM verification IP for the open-ip-portfolio **Timer_WDT** subsystem: System timer and watchdog: periodic timer with AXI4 timestamp records, bark interrupt and bite reset request.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`b1cfc02463bd`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 11) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What Timer_WDT does (from the spec)

- Tick: one every PRESCALE + 1 clocks; COUNT counts ticks.
- Timer (TMR_EN): TIMER fires every PERIOD + 1 ticks (the event is the tick at which the timer count is >= PERIOD, so lowering PERIOD ends the current period at the next tick). With TS_EN and TS_WORDS != 0 each timer event writes COUNT (the value in the event's clock) at TS_BASE + 4 * (n mod TS_WORDS); TS_WP counts records, TS_MISSED events that came while a record was being written.
- Watchdog (WDT_EN): WDT_COUNT loads WDT_LOAD, counts down one per tick; CMD.kick reloads. At 0: BARK fires and it reloads; at 0 again without a kick wdt_reset goes high until a kick or WDT_EN = 0.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `timer_wdt/` -- `timer_wdt_ral.svh` register model (generated from the spec, same
  offsets as `Timer_WDT_apb`), `timer_wdt_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `timer_wdt_pins_if.sv` (wdt_reset)
- `rtl/` -- `Timer_WDT_apb.sv`, `Timer_WDT_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/timer_wdt.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | CTRL | rw |
| 0x018 | PERIOD | rw |
| 0x01C | TS_BASE | rw |
| 0x020 | TS_WORDS | rw |
| 0x024 | WDT_LOAD | rw |
| 0x028 | CMD | cmd |
| 0x02C | COUNT | ro |
| 0x030 | TS_STATE | ro |
| 0x034 | WDT_COUNT | ro |
| 0x038 | WDT_STATE | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 TIMER, 1 BARK, 2 TS_ERR.

## Tests

| Test | Seeds |
|---|---|
| `timer_wdt_ral_test` | 1 |
| `timer_wdt_timer_test` | 2 |
| `timer_wdt_wdt_test` | 2 |
| `timer_wdt_ts_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT Timer_WDT mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/timer_wdt.f
./obj_dir/Vtop_tb +UVM_TESTNAME=timer_wdt_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py Timer_WDT-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
