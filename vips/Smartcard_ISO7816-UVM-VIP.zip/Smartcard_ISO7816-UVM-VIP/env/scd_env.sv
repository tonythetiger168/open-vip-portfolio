// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// scd_env.sv -- SCD environment: reference-model scoreboard, checker, coverage

package scd_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import scd_defs_pkg::*;
  import scd_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class scd_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(scd_scoreboard)
    uvm_analysis_imp_exp #(scd_transaction, scd_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(scd_transaction, scd_scoreboard) obs_ap;

    scd_config cfg;
    scd_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // the card (scoreboard copy), kept across items
    localparam int ATR_DLY = 400;
    bit [7:0]  mem [256];
    bit        minit = 0;
    int        e = 372, ps = 0, atrc = 0, sinc = 16383;
    bit        neg = 0;
    bit        ra = 0;
    int        rt = 0;
    bit [9:0]  rsh = 0;
    bit        rbad = 0;
    bit [7:0]  h [5];
    int        hc = 0;
    bit [7:0]  pp [5];
    int        pc = 0, newe = 0;
    int        dk = 0, nn = 0, off = 0;
    bit        ta = 0, txp = 0, terr = 0;
    int        ct = 0, tries = 0, seq = 0, ti = 0, tn = 0;
    bit [7:0]  tb = 0, sw1 = 0, sw2 = 0;
    bit        o_lo = 0;

    function bit [7:0] txbyte(int i);
      case (seq)
        0: case (i) 0: return 8'h3B; 1: return 8'h02; 2: return 8'h53; default: return 8'h43; endcase
        1: return (i == tn - 1) ? pp[pc - 1] : pp[i];
        2: return (i == 0) ? sw1 : sw2;
        3: return (i == 0) ? h[1] : (i <= nn) ? mem[(off + i - 1) % 256] : (i == nn + 1) ? 8'h90 : 8'h00;
        default: return h[1];
      endcase
    endfunction
    function void start_seq(int s, int n);
      seq = s; tn = n; ti = 0; txp = 1; ps = 6;
    endfunction
    function void sw(bit [7:0] a, bit [7:0] b);
      sw1 = a; sw2 = b; start_seq(2, 2);
    endfunction
    function void got_char(bit [7:0] d);
      case (ps)
        2: if (neg && d == 8'hFF) begin ps = 4; pp[0] = d; pc = 1; end
           else begin neg = 0; h[0] = d; hc = 1; ps = 3; end
        4: begin
             int tot;
             pp[pc] = d; pc++;
             tot = 3 + pp[1][4] + pp[1][5] + pp[1][6];
             if (pc == tot) begin
               bit [7:0] x = 0;
               int ne = pp[1][4] ? scd_etu(pp[2]) : e;
               for (int i = 0; i < tot; i++) x ^= pp[i];
               if (x == 0 && pp[1][3:0] == 0 && pp[1][6:5] == 0 && ne != 0) begin
                 neg = 0; newe = ne; start_seq(1, tot);
               end else ps = 2;
             end
           end
        3: begin
             h[hc] = d; hc++;
             if (hc == 5) begin
               nn = (h[4] == 0) ? 256 : h[4];
               off = {h[2], h[3]};
               if (h[0] != 0) sw(8'h6E, 8'h00);
               else if (h[1] != 8'hB0 && h[1] != 8'hD6) sw(8'h6D, 8'h00);
               else if (off + nn > 256) sw(8'h6B, 8'h00);
               else if (h[1] == 8'hB0) start_seq(3, nn + 3);
               else begin dk = 0; start_seq(4, 1); end
             end
           end
        5: begin
             mem[(off + dk) % 256] = d; dk++;
             if (dk == nn) sw(8'h90, 8'h00);
           end
        default: ;
      endcase
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(scd_config)::get(this, "", "cfg", cfg))
        cfg = scd_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(scd_transaction t);
      if (!minit) begin for (int i = 0; i < 256; i++) mem[i] = 8'(i ^ 8'h5C); minit = 1; end
      t.so.delete();
      foreach (t.mo[i]) begin
        bit io;
        t.so.push_back(o_lo);
        io = !(t.mo[i][0] || o_lo);
        if (!t.mo[i][1]) begin
          e = 372; ps = 1; atrc = 0; sinc = 16383; neg = 0; ra = 0; rt = 0; ta = 0; txp = 0; o_lo = 0; hc = 0; pc = 0;
          continue;
        end
        if (sinc < 16383) sinc++;
        if (ps == 1) begin
          atrc++;
          if (atrc == ATR_DLY) start_seq(0, 4);
        end
        // receiver
        if (!ta && !txp && ps != 1) begin
          if (!ra) begin if (!io) begin ra = 1; rt = 0; rbad = 0; sinc = 0; end end
          else begin
            rt++;
            if (rt % e == e / 2 && rt / e <= 9) begin
              rsh[rt / e] = io;
              if (rt / e == 0 && io) ra = 0;
            end
            if (ra && rt == 10 * e && (^rsh[9:1]) == 1'b0) begin ra = 0; got_char(rsh[8:1]); end
            else if (ra && rt == 10 * e) rbad = 1;
            if (ra && rbad && rt == 23 * e / 2) ra = 0;
          end
        end
        // transmitter
        if (ta) begin
          ct++;
          if (ct == 11 * e && !io) terr = 1;
          if ((!terr && ct == 12 * e) || (terr && ct == 14 * e)) begin
            if (terr) begin
              tries++;
              if (tries == 4) begin ta = 0; ps = 2; end
              else begin ct = 0; terr = 0; end
            end else begin
              ti++;
              if (ti < tn) begin ct = 0; tb = txbyte(ti); tries = 0; end
              else begin
                ta = 0;
                if (seq == 1) e = newe;
                ps = (seq == 4) ? 5 : 2;
                if (seq == 0) neg = 1;
                sinc = 16383;
              end
            end
          end
        end else if (txp && (sinc >= 16 * e || seq == 0) && !ra) begin
          txp = 0; ta = 1; ct = 0; terr = 0; tries = 0; tb = txbyte(0);
        end
        // the pull for the next period
        if (ta) begin
          int k = ct / e;
          o_lo = (k == 0) ? 1'b1 : (k <= 8) ? !tb[k - 1] : (k == 9) ? !(^tb) : 1'b0;
        end else o_lo = ra && rbad && rt >= 21 * e / 2 && rt < 23 * e / 2;
      end
    endfunction

    function void write_exp(scd_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(scd_transaction t);
      scd_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        scd_transaction e = exp_q.pop_front();
        scd_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("scd scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class scd_env extends uvm_env;
    `uvm_component_utils(scd_env)
    scd_agent      agt;
    scd_scoreboard sb;
    scd_checker    chk;
    scd_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = scd_agent     ::type_id::create("agt", this);
      sb  = scd_scoreboard::type_id::create("sb",  this);
      chk = scd_checker   ::type_id::create("chk", this);
      cov = scd_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
