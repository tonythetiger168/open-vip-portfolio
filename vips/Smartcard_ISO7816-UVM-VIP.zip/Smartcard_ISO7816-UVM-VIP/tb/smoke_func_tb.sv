// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SCD DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened scd_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b1;
  initial #1 rst_n = 1'b0;      // a falling edge: the card has no clock to see a level reset
  logic sc_clk = 1'b0, sc_rst_n = 1'b1, io_m_lo = 1'b0;
  wire io_s_lo;

  always #5 clk = ~clk;

  scd_model u_dut (.clk(clk), .rst_n(rst_n), .sc_clk(sc_clk), .sc_rst_n(sc_rst_n), .io_m_lo(io_m_lo), .io_s_lo(io_s_lo));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  integer etu = 372;
  logic io;
  integer t_now = 0, t_lead = 0;
  task automatic clk1(input logic lo);
    @(negedge clk); sc_clk = 0; io_m_lo = lo;
    @(negedge clk);
    sc_clk = 1; io = !(lo || io_s_lo); t_now = t_now + 1;
    @(negedge clk);
  endtask
  task automatic idle(input integer n); repeat (n) clk1(0); endtask
  logic err;
  task automatic tx_char(input logic [7:0] b, input logic badpar = 0);
    logic [9:0] f;
    integer k;
    f = {(^b) ^ badpar, b, 1'b0};
    err = 0;
    for (int c = 0; c < 12 * etu; c++) begin
      k = c / etu;
      clk1(k <= 9 ? !f[k] : 1'b0);
      if (c == 11 * etu - etu / 4 && !io) err = 1;
    end
  endtask
  logic [7:0] rb;
  logic rok;
  integer rwait;
  task automatic rx_char(input logic sig_err = 0, input integer tmo = 40);
    logic [9:0] s;
    integer c;
    rok = 0; rb = 0; s = 0; c = 0;
    do begin clk1(0); c = c + 1; end while (io && c < tmo * etu);
    rwait = c;
    t_lead = t_now;
    if (io) return;
    for (c = 1; c < 10 * etu; c++) begin clk1(0); if (c % etu == etu / 2) s[c / etu] = io; end
    rb = s[8:1];
    rok = !s[0] && (^s[9:1]) == 1'b0;
    if (sig_err) begin
      for (; c < 21 * etu / 2; c++) clk1(0);
      for (; c < 23 * etu / 2; c++) clk1(1);
    end
  endtask
  logic [7:0] r [0:263];
  integer nr;
  // receive up to n characters, stop at the first missing one
  task automatic rx_n(input integer n);
    nr = 0;
    for (int i = 0; i < n; i++) begin rx_char(); if (!rok) return; r[i] = rb; nr = nr + 1; end
  endtask
  task automatic header(input logic [7:0] c, input logic [7:0] i, input logic [7:0] p1, input logic [7:0] p2,
                        input logic [7:0] p3);
    tx_char(c); tx_char(i); tx_char(p1); tx_char(p2); tx_char(p3);
  endtask
  function automatic logic [7:0] ib(input integer i); ib = i ^ 8'h5C; endfunction
  logic ok;
  integer t0, gapc;

  initial begin
    repeat (3) @(posedge clk);
    chk(io_s_lo === 1'b0, "card off I/O in reset");
    rst_n = 1;
    // powered with RST high and never reset: no ATR, no answer to a header
    idle(500);
    header(8'h00, 8'hB0, 8'h00, 8'h00, 8'h01);
    rx_char(0, 30); chk(!rok && rwait >= 30 * etu, "no RST yet: the card stays off");
    sc_rst_n = 0;
    idle(50);
    chk(io_s_lo === 1'b0, "RST low: the card stays silent");
    sc_rst_n = 1; t0 = t_now;
    rx_n(4);
    chk(nr == 4 && r[0] == 8'h3B && r[1] == 8'h02 && r[2] == 8'h53 && r[3] == 8'h43, "ATR 3B 02 53 43");
    // the first ATR character's leading edge: ATR_DLY clocks after RST
    sc_rst_n = 0; idle(10); sc_rst_n = 1; t0 = t_now;
    rx_char(); chk(rok && rb == 8'h3B && t_lead - t0 == 401, "ATR starts 400 clocks after RST");
    rx_char(); t0 = t_lead; rx_char(); chk(rok && t_lead - t0 == 12 * etu, "ATR characters 12 etu apart");
    rx_char(); idle(20 * etu);
    // PPS 14 (372 / 8): not supported, no answer
    tx_char(8'hFF); tx_char(8'h10); tx_char(8'h14); tx_char(8'hFF ^ 8'h10 ^ 8'h14);
    rx_char(0, 30); chk(!rok && rwait >= 30 * etu, "PPS 372 / 8: no answer");
    // bad PCK
    tx_char(8'hFF); tx_char(8'h10); tx_char(8'h94); tx_char(8'h00);
    rx_char(0, 30); chk(!rok, "PPS with a bad PCK: no answer");
    // PPS 94: 512 / 8
    tx_char(8'hFF); t0 = t_now; tx_char(8'h10); tx_char(8'h94); tx_char(8'hFF ^ 8'h10 ^ 8'h94); gapc = t_now;
    rx_n(4);
    chk(nr == 4 && r[0] == 8'hFF && r[1] == 8'h10 && r[2] == 8'h94 && r[3] == (8'hFF ^ 8'h10 ^ 8'h94), "PPS 94 echoed");
    etu = 64; idle(20 * etu);
    // right after an accepted PPS, FF is a class byte
    tx_char(8'hFF); tx_char(8'h10); tx_char(8'h11); tx_char(8'hFE); tx_char(8'h00);
    rx_n(2); chk(nr == 2 && r[0] == 8'h6E && r[1] == 8'h00, "after a PPS no second PPS: 6E 00");
    idle(20 * etu);
    // READ BINARY 4 bytes at 0x20
    header(8'h00, 8'hB0, 8'h00, 8'h20, 8'h04); t0 = t_now;
    rx_n(7);
    chk(nr == 7 && r[0] == 8'hB0 && r[1] == ib(32) && r[2] == ib(33) && r[3] == ib(34) && r[4] == ib(35) &&
        r[5] == 8'h90 && r[6] == 8'h00, "READ BINARY at the new etu: B0, data, 90 00");
    idle(20 * etu);
    // the 16 etu turnaround: leading edge of the last header byte to the procedure byte
    header(8'h00, 8'hB0, 8'h00, 8'h00, 8'h01); t0 = t_now - 12 * etu;
    rx_char(); chk(rok && t_lead - t0 == 16 * etu + 2, "card answers 16 etu after the last leading edge");
    rx_n(3); idle(20 * etu);
    // a second PPS is a header now: CLA FF -> 6E 00
    tx_char(8'hFF); tx_char(8'h10); tx_char(8'h11); tx_char(8'hFE); tx_char(8'h00);
    rx_n(2); chk(nr == 2 && r[0] == 8'h6E && r[1] == 8'h00, "after the first exchange FF is a class byte: 6E 00");
    idle(20 * etu);
    // UPDATE BINARY 3 bytes at 0x40
    header(8'h00, 8'hD6, 8'h00, 8'h40, 8'h03);
    rx_char(); chk(rok && rb == 8'hD6, "UPDATE BINARY: procedure byte D6");
    idle(16 * etu);
    tx_char(8'hA1); tx_char(8'hB2); tx_char(8'hC3);
    rx_n(2); chk(nr == 2 && r[0] == 8'h90 && r[1] == 8'h00, "UPDATE: 90 00");
    idle(20 * etu);
    header(8'h00, 8'hB0, 8'h00, 8'h3F, 8'h05); rx_n(8);
    chk(nr == 8 && r[1] == ib(63) && r[2] == 8'hA1 && r[3] == 8'hB2 && r[4] == 8'hC3 && r[5] == ib(67), "read-back");
    idle(20 * etu);
    header(8'h00, 8'hB0, 8'h00, 8'hFC, 8'h05); rx_n(2); chk(nr == 2 && r[0] == 8'h6B && r[1] == 8'h00, "past the end: 6B 00");
    idle(20 * etu);
    header(8'h00, 8'hB0, 8'h00, 8'hFC, 8'h04); rx_n(7); chk(nr == 7 && r[4] == ib(255), "up to the last byte");
    idle(20 * etu);
    header(8'h00, 8'hB0, 8'h01, 8'h00, 8'h01); rx_n(2); chk(nr == 2 && r[0] == 8'h6B, "P1 = 1: 6B 00");
    idle(20 * etu);
    header(8'h80, 8'hB0, 8'h00, 8'h00, 8'h01); rx_n(2); chk(nr == 2 && r[0] == 8'h6E, "CLA 80: 6E 00");
    idle(20 * etu);
    header(8'h00, 8'hCA, 8'h00, 8'h00, 8'h01); rx_n(2); chk(nr == 2 && r[0] == 8'h6D, "INS CA: 6D 00");
    idle(20 * etu);
    // parity error on P2: the card signals it, the reader repeats
    tx_char(8'h00); tx_char(8'hB0); tx_char(8'h00); tx_char(8'h10, 1); ok = err;
    idle(2 * etu); tx_char(8'h10); ok = ok && !err; tx_char(8'h02);
    rx_n(5); chk(ok && nr == 5 && r[1] == ib(16) && r[2] == ib(17), "bad parity: error signal, the repeat is taken");
    idle(20 * etu);
    // the reader signals an error on the card's first data byte: repeated
    header(8'h00, 8'hB0, 8'h00, 8'h08, 8'h02);
    rx_char(); ok = rok && rb == 8'hB0; rx_char(1);
    rx_char(); chk(ok && rok && rb == ib(8), "a refused character is sent again");
    rx_n(3); chk(nr == 3 && r[0] == ib(9) && r[1] == 8'h90, "and the response goes on");
    idle(20 * etu);
    // refuse all four tries: the card drops the response
    header(8'h00, 8'hB0, 8'h00, 8'h00, 8'h01);
    rx_char(1); rx_char(1); rx_char(1); rx_char(1); ok = rb == 8'hB0;
    rx_char(0, 30); chk(ok && !rok, "after 4 refused tries the card gives up");
    header(8'h00, 8'hB0, 8'h00, 8'h41, 8'h01); rx_n(4); chk(nr == 4 && r[1] == 8'hB2, "and takes the next command");
    idle(20 * etu);
    // 256 bytes (P3 = 0)
    header(8'h00, 8'hB0, 8'h00, 8'h00, 8'h00); rx_n(259);
    ok = nr == 259 && r[257] == 8'h90;
    for (int i = 0; i < 256; i++) if (r[1 + i] !== ((i >= 64 && i < 67) ? (i == 64 ? 8'hA1 : i == 65 ? 8'hB2 : 8'hC3) : ib(i))) ok = 0;
    chk(ok, "P3 = 0 reads all 256 bytes");
    // RST: back to F = 372 / D = 1; the file is kept
    sc_rst_n = 0; idle(20); chk(io_s_lo === 1'b0, "RST: off I/O"); sc_rst_n = 1; etu = 372;
    rx_n(4); chk(nr == 4 && r[0] == 8'h3B, "ATR again at 372");
    idle(20 * etu);
    tx_char(8'hFF); tx_char(8'h10); tx_char(8'h13); tx_char(8'hFF ^ 8'h10 ^ 8'h13);
    rx_n(4); chk(nr == 4 && r[2] == 8'h13, "PPS 13: 372 / 4"); etu = 93;
    idle(20 * etu);
    header(8'h00, 8'hB0, 8'h00, 8'h40, 8'h01); rx_n(4); chk(nr == 4 && r[1] == 8'hA1, "data kept across RST, etu 93");
    idle(20 * etu);
    // PPS0 = 00 (no PPS1): accepted, etu unchanged
    sc_rst_n = 0; idle(20); sc_rst_n = 1; etu = 372; rx_n(4); idle(20 * etu);
    tx_char(8'hFF); tx_char(8'h00); tx_char(8'hFF);
    rx_n(3); chk(nr == 3 && r[1] == 8'h00 && r[2] == 8'hFF, "PPS without PPS1 echoed");
    idle(20 * etu);
    header(8'h00, 8'hB0, 8'h00, 8'h00, 8'h01); rx_n(4); chk(nr == 4 && r[1] == ib(0), "still 372");
    // a header with a parity error on CLA; repeat with good parity
    idle(20 * etu);
    tx_char(8'h00, 1); ok = err; idle(2 * etu); tx_char(8'h00); tx_char(8'hB0); tx_char(8'h00); tx_char(8'h01); tx_char(8'h01);
    rx_n(4); chk(ok && nr == 4 && r[1] == ib(1), "parity error on the first byte");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
