// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SCD testbench top with a functional SCD DUT model

`ifndef SMARTCARD_ISO7816_UVM_VIP_TB_SV
`define SMARTCARD_ISO7816_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import scd_defs_pkg::*;
import scd_pkg::*;
import scd_env_pkg::*;
import scd_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  scd_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  scd_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .sc_clk(vif.sc_clk),
    .sc_rst_n(vif.sc_rst_n),
    .io_m_lo(vif.io_m_lo),
    .io_s_lo(vif.io_s_lo)
  );

  // Concurrent protocol checks
  scd_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .sc_clk(vif.sc_clk),
    .sc_rst_n(vif.sc_rst_n),
    .io_m_lo(vif.io_m_lo),
    .io_s_lo(vif.io_s_lo)
  );

  initial begin
    uvm_config_db#(virtual scd_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module scd_model #(
  parameter int ATR_DLY = 400
) (
  input  logic clk,
  input  logic rst_n,
  input  logic sc_clk,
  input  logic sc_rst_n,
  input  logic io_m_lo,
  output logic io_s_lo
);
  localparam logic [2:0] P_OFF = 3'd0, P_ATRW = 3'd1, P_IDLE = 3'd2, P_HDR = 3'd3, P_PPS = 3'd4,
                         P_DATA = 3'd5, P_RESP = 3'd6;
  localparam logic [2:0] S_ATR = 3'd0, S_PPS = 3'd1, S_SW = 3'd2, S_RD = 3'd3, S_ACK = 3'd4;
  function automatic logic [9:0] etu_of(input logic [7:0] p);
    logic [9:0] f, q;
    logic [3:0] d;
    f = (p[7:4] == 4'd1) ? 10'd372 : (p[7:4] == 4'd9) ? 10'd512 : 10'd0;
    d = (p[3:0] == 4'd1) ? 4'd1 : (p[3:0] == 4'd2) ? 4'd2 : (p[3:0] == 4'd3) ? 4'd4 : (p[3:0] == 4'd4) ? 4'd8 : 4'd0;
    if (d == 0) etu_of = 10'd0;      // f = 0 gives 0 below
    else begin
      q = f / 10'(d);
      etu_of = (q * 10'(d) == f) ? q : 10'd0;
    end
  endfunction

  logic [7:0]  mem [0:255];
  logic [9:0]  e, newe;
  logic [2:0]  ps, seq;
  logic        neg, ra, rbad, ta, txp, terr;
  logic [15:0] atrc;
  logic [13:0] sinc, rt, ct;
  logic [9:0]  rsh;
  logic [7:0]  h0, h1, h2, h3, h4, p0, p1, p2, p3, sw1, sw2;
  logic [2:0]  hc, pc, tries;
  logic [8:0]  dk, nn, ti, tn;
  logic [15:0] off;
  logic        n_lo;
  wire         io = !(io_m_lo || io_s_lo);
  wire         _unused = &{1'b0, clk};

  // the file is non-volatile: its factory content, kept across every reset
  initial foreach (mem[k]) mem[k] = 8'(k) ^ 8'h5C;

  always_ff @(posedge sc_clk or negedge rst_n) begin
    if (!rst_n) begin
      ps <= P_OFF;      // powered, RST not yet seen: the card ignores I/O; RST low sets the rest
      n_lo <= 1'b0;
    end else begin : step
      logic [9:0]  v_e, v_newe, ne;
      logic [2:0]  v_ps, v_seq, v_hc, v_pc, v_tries;
      logic        v_neg, v_ra, v_rbad, v_ta, v_txp, v_terr, got;
      logic [15:0] v_atrc, v_off;
      logic [13:0] v_sinc, v_rt, v_ct;
      logic [9:0]  v_rsh;
      logic [7:0]  v_h0, v_h1, v_h2, v_h3, v_h4, v_p0, v_p1, v_p2, v_p3, v_sw1, v_sw2, d, x, tb;
      logic [8:0]  v_dk, v_nn, v_ti, v_tn;
      logic [3:0]  k;
      logic [2:0]  tot;
      v_e = e; v_newe = newe; v_ps = ps; v_seq = seq; v_hc = hc; v_pc = pc; v_tries = tries;
      v_neg = neg; v_ra = ra; v_rbad = rbad; v_ta = ta; v_txp = txp; v_terr = terr;
      v_atrc = atrc; v_off = off; v_sinc = sinc; v_rt = rt; v_ct = ct; v_rsh = rsh;
      v_h0 = h0; v_h1 = h1; v_h2 = h2; v_h3 = h3; v_h4 = h4; v_p0 = p0; v_p1 = p1; v_p2 = p2; v_p3 = p3;
      v_sw1 = sw1; v_sw2 = sw2; v_dk = dk; v_nn = nn; v_ti = ti; v_tn = tn;
      got = 1'b0; d = '0; tb = '0;
      if (!sc_rst_n) begin
        v_e = 10'd372; v_ps = P_ATRW; v_atrc = '0; v_sinc = 14'h3FFF; v_neg = 1'b0; v_ra = 1'b0; v_rt = '0;
        v_ta = 1'b0; v_txp = 1'b0; v_hc = '0; v_pc = '0;
        n_lo <= 1'b0;
      end else if (v_ps == P_OFF) n_lo <= 1'b0;
      else begin
        if (v_sinc != 14'h3FFF) v_sinc = v_sinc + 14'd1;
        if (v_ps == P_ATRW) begin
          v_atrc = v_atrc + 16'd1;
          if (v_atrc == 16'(ATR_DLY)) begin v_seq = S_ATR; v_tn = 9'd4; v_ti = '0; v_txp = 1'b1; v_ps = P_RESP; end
        end
        // receiver
        if (!v_ta && !v_txp && v_ps != P_ATRW && v_ps != P_OFF) begin
          if (!v_ra) begin if (!io) begin v_ra = 1'b1; v_rt = '0; v_rbad = 1'b0; v_sinc = '0; end end
          else begin
            v_rt = v_rt + 14'd1;
            if (v_rt % 14'(v_e) == 14'(v_e / 10'd2) && v_rt / 14'(v_e) <= 14'd9) begin
              v_rsh[4'(v_rt / 14'(v_e))] = io;
              if (v_rt / 14'(v_e) == 14'd0 && io) v_ra = 1'b0;
            end
            if (v_ra && v_rt == 14'(v_e) * 14'd10) begin
              if ((^v_rsh[9:1]) == 1'b0) begin v_ra = 1'b0; got = 1'b1; d = v_rsh[8:1]; end
              else v_rbad = 1'b1;
            end
            if (v_ra && v_rbad && v_rt == 14'(v_e) * 14'd23 / 14'd2) v_ra = 1'b0;
          end
        end
        // a character received
        if (got) begin
          case (v_ps)
            P_IDLE:
              if (v_neg && d == 8'hFF) begin v_ps = P_PPS; v_p0 = d; v_pc = 3'd1; end
              else begin v_neg = 1'b0; v_h0 = d; v_hc = 3'd1; v_ps = P_HDR; end
            P_PPS: begin
              case (v_pc) 3'd1: v_p1 = d; 3'd2: v_p2 = d; 3'd3: v_p3 = d; default: ; endcase   // PPS2 / PPS3: refused below
              v_pc = v_pc + 3'd1;
              tot = 3'd3 + 3'(v_p1[4]) + 3'(v_p1[5]) + 3'(v_p1[6]);
              if (v_pc == tot) begin
                x = v_p0 ^ v_p1 ^ v_p2 ^ ((tot == 3'd4) ? v_p3 : 8'h0);
                ne = v_p1[4] ? etu_of(v_p2) : v_e;
                if (x == 8'h0 && v_p1[3:0] == 4'h0 && v_p1[6:5] == 2'b00 && ne != 0) begin
                  v_neg = 1'b0; v_newe = ne; v_seq = S_PPS; v_tn = 9'(tot); v_ti = '0; v_txp = 1'b1; v_ps = P_RESP;
                end else v_ps = P_IDLE;
              end
            end
            P_HDR: begin
              case (v_hc) 3'd1: v_h1 = d; 3'd2: v_h2 = d; 3'd3: v_h3 = d; default: v_h4 = d; endcase
              v_hc = v_hc + 3'd1;
              if (v_hc == 3'd5) begin
                v_nn = (v_h4 == 8'h0) ? 9'd256 : 9'(v_h4);
                v_off = {v_h2, v_h3};
                v_ti = '0; v_txp = 1'b1; v_ps = P_RESP;
                if (v_h0 != 8'h0) begin v_seq = S_SW; v_tn = 9'd2; v_sw1 = 8'h6E; v_sw2 = 8'h00; end
                else if (v_h1 != 8'hB0 && v_h1 != 8'hD6) begin v_seq = S_SW; v_tn = 9'd2; v_sw1 = 8'h6D; v_sw2 = 8'h00; end
                else if (17'(v_off) + 17'(v_nn) > 17'd256) begin v_seq = S_SW; v_tn = 9'd2; v_sw1 = 8'h6B; v_sw2 = 8'h00; end
                else if (v_h1 == 8'hB0) begin v_seq = S_RD; v_tn = v_nn + 9'd3; end
                else begin v_seq = S_ACK; v_tn = 9'd1; v_dk = '0; end
              end
            end
            P_DATA: begin
              mem[8'(v_off + 16'(v_dk))] <= d;
              v_dk = v_dk + 9'd1;
              if (v_dk == v_nn) begin
                v_seq = S_SW; v_tn = 9'd2; v_sw1 = 8'h90; v_sw2 = 8'h00; v_ti = '0; v_txp = 1'b1; v_ps = P_RESP;
              end
            end
            default: ;
          endcase
        end
        // transmitter
        if (v_ta) begin
          v_ct = v_ct + 14'd1;
          if (v_ct == 14'(v_e) * 14'd11 && !io) v_terr = 1'b1;
          if ((!v_terr && v_ct == 14'(v_e) * 14'd12) || (v_terr && v_ct == 14'(v_e) * 14'd14)) begin
            if (v_terr) begin
              v_tries = v_tries + 3'd1;
              if (v_tries == 3'd4) begin v_ta = 1'b0; v_ps = P_IDLE; end
              else begin v_ct = '0; v_terr = 1'b0; end
            end else begin
              v_ti = v_ti + 9'd1;
              if (v_ti < v_tn) begin v_ct = '0; v_tries = '0; end
              else begin
                v_ta = 1'b0;
                if (v_seq == S_PPS) v_e = v_newe;
                v_ps = (v_seq == S_ACK) ? P_DATA : P_IDLE;
                if (v_seq == S_ATR) v_neg = 1'b1;
                v_sinc = 14'h3FFF;
              end
            end
          end
        end else if (v_txp && (v_sinc >= 14'(v_e) * 14'd16 || v_seq == S_ATR) && !v_ra) begin
          v_txp = 1'b0; v_ta = 1'b1; v_ct = '0; v_terr = 1'b0; v_tries = '0;
        end
        // the character being sent
        case (v_seq)
          S_ATR: tb = (v_ti == 0) ? 8'h3B : (v_ti == 1) ? 8'h02 : (v_ti == 2) ? 8'h53 : 8'h43;
          S_PPS: tb = (v_ti == 0) ? v_p0 : (v_ti == 1) ? v_p1 : (v_ti == 2) ? v_p2 : v_p3;   // the echo
          S_SW:  tb = (v_ti == 0) ? v_sw1 : v_sw2;
          S_RD:  tb = (v_ti == 0) ? v_h1 : (v_ti <= v_nn) ? mem[8'(v_off + 16'(v_ti) - 16'd1)] :
                      (v_ti == v_nn + 9'd1) ? 8'h90 : 8'h00;
          default: tb = v_h1;
        endcase
        // the pull for the next period
        if (v_ta) begin
          k = 4'(v_ct / 14'(v_e));
          n_lo <= (k == 0) ? 1'b1 : (k <= 4'd8) ? !tb[k - 4'd1] : (k == 4'd9) ? !(^tb) : 1'b0;
        end else n_lo <= v_ra && v_rbad && v_rt >= 14'(v_e) * 14'd21 / 14'd2 && v_rt < 14'(v_e) * 14'd23 / 14'd2;
      end
      e <= v_e; newe <= v_newe; ps <= v_ps; seq <= v_seq; hc <= v_hc; pc <= v_pc; tries <= v_tries;
      neg <= v_neg; ra <= v_ra; rbad <= v_rbad; ta <= v_ta; txp <= v_txp; terr <= v_terr;
      atrc <= v_atrc; off <= v_off; sinc <= v_sinc; rt <= v_rt; ct <= v_ct; rsh <= v_rsh;
      h0 <= v_h0; h1 <= v_h1; h2 <= v_h2; h3 <= v_h3; h4 <= v_h4; p0 <= v_p0; p1 <= v_p1; p2 <= v_p2; p3 <= v_p3;
      sw1 <= v_sw1; sw2 <= v_sw2; dk <= v_dk; nn <= v_nn; ti <= v_ti; tn <= v_tn;
    end
  end

  // falling sc_clk: the pull changes
  always_ff @(negedge sc_clk or negedge rst_n) begin
    if (!rst_n) io_s_lo <= 1'b0;
    else        io_s_lo <= n_lo;
  end
endmodule
`endif
