// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// scd_if.sv -- SCD interface

interface scd_if (input logic clk);
  logic rst_n;

  logic sc_clk;
  logic sc_rst_n;
  logic io_m_lo;
  logic io_s_lo;

  modport DUT (input clk, rst_n, input sc_clk, input sc_rst_n, input io_m_lo, output io_s_lo);
  modport MON (input clk, rst_n, sc_clk, sc_rst_n, io_m_lo, io_s_lo);

  clocking drv_cb @(posedge clk);
    input rst_n, io_s_lo;
    inout sc_clk, sc_rst_n, io_m_lo;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, sc_clk, sc_rst_n, io_m_lo, io_s_lo;
  endclocking
endinterface
