// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// scd_driver.svh -- SCD driver: one item per exchange with sc_clk running: RST low and the ATR; a PPS request and its echo (the etu follows an accepted PPS); or a TPDU header, the procedure byte, the data in either direction and the status words, with parity errors sent and signalled as the kind asks; then 20 etu idle and sc_clk stopped for cfg.gap clocks

class scd_driver extends uvm_driver #(scd_transaction);
  `uvm_component_utils(scd_driver)

  uvm_analysis_port #(scd_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual scd_if vif;
  scd_config cfg;

  int             etu = 372;
  bit             rn = 0;
  scd_transaction cur;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual scd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "scd: virtual interface not set")
    if (!uvm_config_db#(scd_config)::get(this, "", "cfg", cfg))
      cfg = scd_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    scd_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.sc_clk   <= 1'b0;
    vif.drv_cb.sc_rst_n <= 1'b0;
    vif.drv_cb.io_m_lo  <= 1'b0;
  endtask

  task drive_item(scd_transaction t);
    bit [7:0] b, pb;
    bit ok, e;
    cur = t;
    t.mo.delete();
    t.sw1 = 0; t.sw2 = 0;
    @(vif.drv_cb);
    if (t.kk() == 0) begin
      rn = 0; idle(200);
      rn = 1; etu = 372;
      for (int i = 0; i < 4; i++) begin rx_char(1'b0, b, ok); if (!ok) break; end
    end else if (t.kk() == 1 || t.kk() == 2) begin
      bit [7:0] p [4] = '{8'hFF, 8'h10, t.pps1(), 8'h00};
      bit match = 1;
      p[3] = p[0] ^ p[1] ^ p[2] ^ (t.kk() == 2 ? 8'h01 : 8'h00);
      for (int i = 0; i < 4; i++) tx_rep(p[i], 1'b0);
      for (int i = 0; i < 4; i++) begin rx_char(1'b0, b, ok); if (!ok || b != p[i]) begin match = 0; break; end end
      if (match) etu = scd_etu(p[2]);
    end else begin
      int n = t.len();
      for (int i = 0; i < 5; i++) tx_rep(t.hdr(i), t.kk() == 8 && i == t.seed % 5);
      rx_rep(t.kk() == 12 ? 4 : (t.kk() == 9 && t.seed % 3 == 0) ? 1 : 0, pb, ok);
      if (ok && pb == t.hdr(1) && t.hdr(1) == 8'hB0) begin
        for (int i = 0; i < n && ok; i++) rx_rep((t.kk() == 9 && t.seed % 3 == 1 && i == 0) ? 1 : 0, b, ok);
        if (ok) rx_rep((t.kk() == 9 && t.seed % 3 == 2) ? 1 : 0, t.sw1, ok);
        if (ok) rx_char(1'b0, t.sw2, ok);
      end else if (ok && pb == t.hdr(1) && t.hdr(1) == 8'hD6) begin
        idle(16 * etu);
        for (int i = 0; i < n; i++) tx_rep(t.wbyte(i), t.kk() == 10 && i == t.seed % n);
        rx_char(1'b0, t.sw1, ok);
        if (ok) rx_char(1'b0, t.sw2, ok);
      end else if (ok) begin
        t.sw1 = pb;
        rx_char(1'b0, t.sw2, ok);
      end
    end
    idle(20 * etu);
    repeat (cfg.gap) @(vif.drv_cb);
  endtask

  // one sc_clk period: outputs at the falling edge, the line at the rising edge
  task automatic clk1(bit lo, output bit io);
    vif.drv_cb.sc_clk   <= 1'b0;
    vif.drv_cb.sc_rst_n <= rn;
    vif.drv_cb.io_m_lo  <= lo;
    repeat (cfg.half) @(vif.drv_cb);
    vif.drv_cb.sc_clk <= 1'b1;
    io = !(lo || vif.drv_cb.io_s_lo);
    cur.mo.push_back({rn, lo});
    repeat (cfg.half) @(vif.drv_cb);
  endtask
  task automatic idle(int n);
    bit io;
    repeat (n) clk1(1'b0, io);
  endtask
  // send a character; badpar sends it with odd parity. err: the card signalled an error
  task automatic tx_char(bit [7:0] b, bit badpar, output bit err);
    bit io;
    bit [9:0] f = {(^b) ^ badpar, b, 1'b0};    // start first, LSB first
    err = 0;
    for (int c = 0; c < 12 * etu; c++) begin
      int k = c / etu;
      clk1(k <= 9 ? !f[k] : 1'b0, io);
      if (c == 11 * etu - etu / 4 && !io) err = 1;
    end
  endtask
  // send with repetition: a bad parity first when badpar, then until accepted (4 tries)
  task automatic tx_rep(bit [7:0] b, bit badpar);
    bit err;
    int n = 0;
    tx_char(b, badpar, err);
    while (err && n < 4) begin idle(2 * etu); tx_char(b, 1'b0, err); n++; end
  endtask
  // receive a character: wait up to 40 etu for its start bit, sample mid-bit;
  // sig_err pulls I/O low at 10.5 .. 11.5 etu. ok = 0 on a timeout or bad parity
  task automatic rx_char(bit sig_err, output bit [7:0] b, output bit ok);
    bit io;
    bit [9:0] s = 0;
    int c = 0;
    ok = 0; b = 0;
    do begin clk1(1'b0, io); c++; end while (io && c < 40 * etu);
    if (io) return;
    for (c = 1; c < 10 * etu; c++) begin
      clk1(1'b0, io);
      if (c % etu == etu / 2) s[c / etu] = io;
    end
    b = s[8:1];
    ok = !s[0] && (^s[9:1]) == 1'b0;
    if (sig_err) begin
      for (; c < 21 * etu / 2; c++) clk1(1'b0, io);
      for (; c < 23 * etu / 2; c++) clk1(1'b1, io);
      ok = 0;
    end
  endtask
  // a character from the card that is repeated after an error: refuse the first `refuse` tries
  task automatic rx_rep(int refuse, output bit [7:0] b, output bit ok);
    rx_char(refuse > 0, b, ok);
    for (int n = 1; n <= refuse && n < 4; n++) rx_char(n < refuse, b, ok);
  endtask
endclass
