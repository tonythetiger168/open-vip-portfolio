// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// scd_compliance_checker.sv -- SCD concurrent assertion checks (bindable)

module scd_compliance_checker
  (input logic clk, input logic rst_n, input logic sc_clk, input logic sc_rst_n, input logic io_m_lo, input logic io_s_lo);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({sc_clk, sc_rst_n, io_m_lo, io_s_lo}))
    else $error("SCD: X on CLK, RST or I/O");
  assert property (@(posedge clk) disable iff (!rst_n) $changed(io_s_lo) |-> !sc_clk)
    else $error("SCD: card I/O changed while CLK is high");
  cover property (@(posedge clk) disable iff (!rst_n) io_m_lo && io_s_lo);
endmodule
