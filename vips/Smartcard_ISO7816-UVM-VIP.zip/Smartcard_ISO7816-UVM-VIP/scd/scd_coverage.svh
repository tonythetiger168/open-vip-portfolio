// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// scd_coverage.svh -- SCD functional coverage

class scd_coverage extends uvm_subscriber #(scd_transaction);
  `uvm_component_utils(scd_coverage)
  scd_config cfg;
  scd_transaction tr;

  covergroup scd_cg;
    cp_kind : coverpoint tr.kind { bins k[] = {[0:12]}; bins mix = {[13:15]}; }
    cp_sw1  : coverpoint tr.sw1 { bins ok = {8'h90}; bins wrong_p = {8'h6B}; bins wrong_ins = {8'h6D};
                                  bins wrong_cla = {8'h6E}; bins none = {8'h00}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    scd_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(scd_config)::get(this, "", "cfg", cfg))
      cfg = scd_config::type_id::create("cfg");
  endfunction

  function void write(scd_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    scd_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SCD coverage: %0.1f%%", scd_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
