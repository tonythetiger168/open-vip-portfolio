// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// scd_transaction.svh -- SCD transaction

class scd_transaction extends uvm_sequence_item;
  `uvm_object_utils(scd_transaction)

  // request (driven by the agent)
  bit [1:0] mo[$];
  // response (returned by the DUT)
  bit so[$];
  // bookkeeping (not compared)
  rand bit [3:0] kind;
  rand bit [3:0] blk;
  rand bit [2:0] cnt;
  rand bit [31:0] seed;
  bit [7:0] sw1;
  bit [7:0] sw2;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "scd_transaction"); super.new(name); endfunction

  // kind: 0 reset + ATR, 1 PPS (PPS1 from seed), 2 PPS with a bad PCK, 3 READ
  // BINARY (cnt + 1 bytes at 16 blk), 4 UPDATE BINARY, 5 READ past the end, 6
  // CLA 80, 7 INS CA, 8 READ with a parity error on header byte seed % 5, 9
  // READ with the reader signalling an error on card character seed % 3, 10
  // UPDATE with a parity error on a data byte, 11 READ of 256 bytes (P3 = 0),
  // 12 READ with every try of the first card character refused, 13-15 READ /
  // UPDATE mix
  function void set(int k, int b = 0, int n = 0, bit [31:0] s = 32'h1); kind = k; blk = b; cnt = n; seed = s; endfunction
  function int kk();
    if (kind >= 13) return (kind % 2 == 0) ? 4 : 3;
    return kind;
  endfunction
  function bit [7:0] pps1();
    bit [7:0] t [6] = '{8'h11, 8'h12, 8'h13, 8'h94, 8'h14, 8'h91};
    return t[seed % 6];
  endfunction
  function int len();
    return (kk() == 11) ? 256 : int'(cnt) + 1;
  endfunction
  function bit [7:0] hdr(int i);
    bit [7:0] h [5];
    h[0] = (kk() == 6) ? 8'h80 : 8'h00;
    h[1] = (kk() == 7) ? 8'hCA : (kk() == 4 || kk() == 10) ? 8'hD6 : 8'hB0;
    h[2] = 8'h00;
    h[3] = (kk() == 5) ? 8'hFC : (kk() == 11) ? 8'h00 : {blk, 4'h0};
    h[4] = (kk() == 11) ? 8'h00 : (kk() == 5) ? 8'h08 : 8'(len());
    return h[i];
  endfunction
  function bit [7:0] wbyte(int i);
    bit [31:0] x = (seed | 1) ^ (32'(i) * 32'h9E37_79B9);
    x ^= x >> 13; x *= 32'h5BD1_E995; x ^= x >> 15;
    return x[7:0];
  endfunction

  function void do_copy(uvm_object rhs);
    scd_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mo = rhs_.mo;
    so = rhs_.so;
    kind = rhs_.kind;
    blk = rhs_.blk;
    cnt = rhs_.cnt;
    seed = rhs_.seed;
    sw1 = rhs_.sw1;
    sw2 = rhs_.sw2;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    scd_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(scd_transaction rhs_);
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    return 1;
  endfunction

  function string qstr_mo();
    string s = $sformatf("[%0d]{", mo.size());
    foreach (mo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", mo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SCD{tag=%0d mo=%s so=%s}", tag, qstr_mo(), qstr_so());
  endfunction
endclass
