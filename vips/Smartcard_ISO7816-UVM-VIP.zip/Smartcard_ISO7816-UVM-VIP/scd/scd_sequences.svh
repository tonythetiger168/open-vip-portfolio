// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// scd_sequences.svh -- SCD sequences

// Random traffic: cfg.num_items constrained-random items.
class scd_base_sequence extends uvm_sequence #(scd_transaction);
  `uvm_object_utils(scd_base_sequence)
  scd_config cfg;

  function new(string name = "scd_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = scd_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "scd_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class scd_directed_sequence extends uvm_sequence #(scd_transaction);
  `uvm_object_utils(scd_directed_sequence)
  scd_config cfg;

  function new(string name = "scd_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function scd_transaction item();
    item = scd_transaction::type_id::create("req");
  endfunction

  task send(scd_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    scd_transaction t;
    // ATR, PPS paths, every TPDU outcome, parity errors both ways, repetition limit, reset in the middle
    t = item(); t.set(3); send(t);              // before any reset: the card is off
    t = item(); t.set(0); send(t);
    t = item(); t.set(1, 0, 0, 32'd4); send(t); // PPS 14: 372 / 8, refused
    t = item(); t.set(2, 0, 0, 32'd3); send(t); // bad PCK
    t = item(); t.set(1, 0, 0, 32'd3); send(t); // PPS 94: 512 / 8 = 64 clocks
    t = item(); t.set(1, 0, 0, 32'd1); send(t); // no longer negotiable
    t = item(); t.set(3, 2, 3); send(t);
    t = item(); t.set(4, 2, 3, 32'h77); send(t);
    t = item(); t.set(3, 2, 3); send(t);
    t = item(); t.set(5); send(t);
    t = item(); t.set(6); send(t);
    t = item(); t.set(7); send(t);
    for (int i = 0; i < 5; i++) begin t = item(); t.set(8, 1, 1, i); send(t); end
    for (int i = 0; i < 3; i++) begin t = item(); t.set(9, 3, 2, i); send(t); end
    t = item(); t.set(10, 4, 4, 32'h21); send(t);
    t = item(); t.set(3, 4, 4); send(t);
    t = item(); t.set(12, 5, 1); send(t);       // the card gives up
    t = item(); t.set(3, 5, 1); send(t);
    t = item(); t.set(11); send(t);             // 256 bytes
    t = item(); t.set(0); send(t);              // reset: back to 372, data kept
    t = item(); t.set(1, 0, 0, 32'd2); send(t); // PPS 13: 93 clocks
    t = item(); t.set(3, 2, 3); send(t);
    t = item(); t.set(0); send(t);
    t = item(); t.set(1, 0, 0, 32'd0); send(t); // PPS 11: 372
    t = item(); t.set(4, 15, 7, 32'h99); send(t);
    t = item(); t.set(3, 15, 7); send(t);
    t = item(); t.set(0); send(t);
    t = item(); t.set(1, 0, 0, 32'd3); send(t);
  endtask
endclass
