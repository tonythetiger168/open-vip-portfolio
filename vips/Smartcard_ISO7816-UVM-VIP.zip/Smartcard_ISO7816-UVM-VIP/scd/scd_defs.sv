// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// scd_defs.sv -- SCD shared type definitions

package scd_defs_pkg;

  typedef enum bit [1:0] {SCD_OK, SCD_ERR} scd_status_e;

  function automatic int scd_f(bit [3:0] fi);
    case (fi)
      4'd1: return 372;
      4'd9: return 512;
      default: return 0;
    endcase
  endfunction
  function automatic int scd_d(bit [3:0] di);
    case (di)
      4'd1: return 1;
      4'd2: return 2;
      4'd3: return 4;
      4'd4: return 8;
      default: return 0;
    endcase
  endfunction
  // the etu a PPS1 byte gives, 0 when the card does not support it
  function automatic int scd_etu(bit [7:0] pps1);
    int f = scd_f(pps1[7:4]), d = scd_d(pps1[3:0]);
    if (f == 0 || d == 0 || f % d != 0) return 0;
    return f / d;
  endfunction

endpackage
