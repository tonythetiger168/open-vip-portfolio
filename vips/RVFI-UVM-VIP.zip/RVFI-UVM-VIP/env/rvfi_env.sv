// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_env.sv -- RVFI environment: reference-model scoreboard, checker, coverage

package rvfi_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import rvfi_defs_pkg::*;
  import rvfi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class rvfi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(rvfi_scoreboard)
    uvm_analysis_imp_exp #(rvfi_transaction, rvfi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(rvfi_transaction, rvfi_scoreboard) obs_ap;

    rvfi_config cfg;
    rvfi_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [31:0] x [32];
    bit [31:0] pc = 0;
    bit [63:0] ord = 0;
    bit intr_n = 0;
    bit [31:0] dmem [bit [29:0]];

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(rvfi_config)::get(this, "", "cfg", cfg))
        cfg = rvfi_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(rvfi_transaction t);
      // RV32I instruction-set simulator: one step per retired instruction
      bit [31:0] i = t.insn, a, b, r = 0, npc, ea, w, sh;
      bit [31:0] ii = {{20{i[31]}}, i[31:20]}, is = {{20{i[31]}}, i[31:25], i[11:7]};
      bit [31:0] ib = {{19{i[31]}}, i[31], i[7], i[30:25], i[11:8], 1'b0};
      bit [31:0] ij = {{11{i[31]}}, i[31], i[19:12], i[20], i[30:21], 1'b0};
      bit [4:0] rd = i[11:7], rs1 = i[19:15], rs2 = i[24:20];
      bit [2:0] f3 = i[14:12];
      bit [6:0] f7 = i[31:25];
      bit trap = 0, wr = 0, u1 = 0, u2 = 0, ld = 0, st = 0, tk = 0;
      bit [3:0] m = 0;
      x[0] = 0;
      a = x[rs1]; b = x[rs2];
      npc = pc + 4;
      t.order = ord; t.pc_rdata = pc; t.intr = intr_n; t.halt = 0; t.mode = 2'd3; t.ixl = 2'd1;
      t.mem_addr = 0; t.mem_rmask = 0; t.mem_wmask = 0; t.mem_rdata = 0; t.mem_wdata = 0;
      case (i[6:0])
        7'h37: begin wr = 1; r = {i[31:12], 12'h0}; end
        7'h17: begin wr = 1; r = pc + {i[31:12], 12'h0}; end
        7'h6F: begin wr = 1; r = pc + 4; npc = pc + ij; trap = npc[1]; end
        7'h67: begin
          u1 = 1; wr = 1; r = pc + 4; npc = (a + ii) & ~32'h1;
          trap = (f3 != 0) || npc[1];
        end
        7'h63: begin
          u1 = 1; u2 = 1;
          case (f3)
            3'd0: tk = (a == b);
            3'd1: tk = (a != b);
            3'd4: tk = ($signed(a) < $signed(b));
            3'd5: tk = ($signed(a) >= $signed(b));
            3'd6: tk = (a < b);
            3'd7: tk = (a >= b);
            default: trap = 1;
          endcase
          if (tk) npc = pc + ib;
          if (tk && npc[1]) trap = 1;
        end
        7'h03: begin
          u1 = 1; wr = 1; ld = 1; ea = a + ii;
          if (f3 == 3 || f3 > 5) trap = 1;
          else if ((f3[1:0] == 1 && ea[0]) || (f3[1:0] == 2 && ea[1:0] != 0)) trap = 1;
          m = ((f3[1:0] == 0) ? 4'h1 : (f3[1:0] == 1) ? 4'h3 : 4'hF) << ea[1:0];
          w = dmem.exists(ea[31:2]) ? dmem[ea[31:2]] : rvfi_mem_init(ea);
          sh = w >> (8 * ea[1:0]);
          case (f3)
            3'd0: r = {{24{sh[7]}}, sh[7:0]};
            3'd1: r = {{16{sh[15]}}, sh[15:0]};
            3'd4: r = {24'h0, sh[7:0]};
            3'd5: r = {16'h0, sh[15:0]};
            default: r = sh;
          endcase
        end
        7'h23: begin
          u1 = 1; u2 = 1; st = 1; ea = a + is;
          if (f3 > 2) trap = 1;
          else if ((f3 == 1 && ea[0]) || (f3 == 2 && ea[1:0] != 0)) trap = 1;
          m = ((f3 == 0) ? 4'h1 : (f3 == 1) ? 4'h3 : 4'hF) << ea[1:0];
        end
        7'h13: begin
          u1 = 1; wr = 1;
          case (f3)
            3'd0: r = a + ii;
            3'd2: r = ($signed(a) < $signed(ii)) ? 1 : 0;
            3'd3: r = (a < ii) ? 1 : 0;
            3'd4: r = a ^ ii;
            3'd6: r = a | ii;
            3'd7: r = a & ii;
            3'd1: begin r = a << i[24:20]; trap = (f7 != 0); end
            3'd5: begin
              if (f7[5]) r = $signed(a) >>> i[24:20]; else r = a >> i[24:20];
              trap = (f7 != 0 && f7 != 7'h20);
            end
          endcase
        end
        7'h33: begin
          u1 = 1; u2 = 1; wr = 1;
          trap = !(f7 == 0 || (f7 == 7'h20 && (f3 == 0 || f3 == 5)));
          case (f3)
            3'd0: r = f7[5] ? a - b : a + b;
            3'd1: r = a << b[4:0];
            3'd2: r = ($signed(a) < $signed(b)) ? 1 : 0;
            3'd3: r = (a < b) ? 1 : 0;
            3'd4: r = a ^ b;
            3'd5: if (f7[5]) r = $signed(a) >>> b[4:0]; else r = a >> b[4:0];
            3'd6: r = a | b;
            3'd7: r = a & b;
          endcase
        end
        7'h0F: trap = (f3 != 0);
        default: trap = 1;                                   // ECALL, EBREAK, CSR, unknown
      endcase
      if (trap) begin
        npc = RVFI_MTVEC;
        t.rs1_addr = 0; t.rs1_rdata = 0; t.rs2_addr = 0; t.rs2_rdata = 0; t.rd_addr = 0; t.rd_wdata = 0;
      end else begin
        t.rs1_addr = u1 ? rs1 : 0; t.rs1_rdata = u1 ? a : 0;
        t.rs2_addr = u2 ? rs2 : 0; t.rs2_rdata = u2 ? b : 0;
        t.rd_addr = (wr && rd != 0) ? rd : 0;
        t.rd_wdata = (wr && rd != 0) ? r : 0;
        if (ld) begin t.mem_addr = {ea[31:2], 2'b00}; t.mem_rmask = m; t.mem_rdata = w; end
        if (st) begin
          t.mem_addr = {ea[31:2], 2'b00}; t.mem_wmask = m;
          w = dmem.exists(ea[31:2]) ? dmem[ea[31:2]] : rvfi_mem_init(ea);
          for (int k = 0; k < 4; k++) if (m[k]) begin
            t.mem_wdata[8*k +: 8] = b[8*(k - ea[1:0]) +: 8];
            w[8*k +: 8] = b[8*(k - ea[1:0]) +: 8];
          end
          dmem[ea[31:2]] = w;
        end
        if (wr && rd != 0) x[rd] = r;
      end
      t.trap = trap;
      t.pc_wdata = npc;
      pc = npc; ord++; intr_n = trap;
    endfunction

    function void write_exp(rvfi_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(rvfi_transaction t);
      rvfi_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        rvfi_transaction e = exp_q.pop_front();
        rvfi_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("rvfi scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class rvfi_env extends uvm_env;
    `uvm_component_utils(rvfi_env)
    rvfi_agent      agt;
    rvfi_scoreboard sb;
    rvfi_checker    chk;
    rvfi_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = rvfi_agent     ::type_id::create("agt", this);
      sb  = rvfi_scoreboard::type_id::create("sb",  this);
      chk = rvfi_checker   ::type_id::create("chk", this);
      cov = rvfi_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
