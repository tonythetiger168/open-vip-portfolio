// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_defs.sv -- RVFI shared type definitions

package rvfi_defs_pkg;

  typedef enum bit [1:0] {RVFI_OK, RVFI_ERR} rvfi_status_e;

  localparam bit [31:0] RVFI_MTVEC = 32'h0000_0100;
  function automatic bit [31:0] rvfi_mem_init(bit [31:0] a);
    bit [31:0] w = {a[31:2], 2'b00};
    return (w * 32'h9E37_79B1) ^ 32'h5A5A_A5A5;
  endfunction
  // encoders
  function automatic bit [31:0] rv_r(bit [6:0] f7, bit [4:0] rs2, bit [4:0] rs1, bit [2:0] f3, bit [4:0] rd, bit [6:0] op);
    return {f7, rs2, rs1, f3, rd, op};
  endfunction
  function automatic bit [31:0] rv_i(bit [11:0] imm, bit [4:0] rs1, bit [2:0] f3, bit [4:0] rd, bit [6:0] op);
    return {imm, rs1, f3, rd, op};
  endfunction
  function automatic bit [31:0] rv_s(bit [11:0] imm, bit [4:0] rs2, bit [4:0] rs1, bit [2:0] f3);
    return {imm[11:5], rs2, rs1, f3, imm[4:0], 7'h23};
  endfunction
  function automatic bit [31:0] rv_b(bit [12:0] imm, bit [4:0] rs2, bit [4:0] rs1, bit [2:0] f3);
    return {imm[12], imm[10:5], rs2, rs1, f3, imm[4:1], imm[11], 7'h63};
  endfunction
  function automatic bit [31:0] rv_j(bit [20:0] imm, bit [4:0] rd);
    return {imm[20], imm[10:1], imm[11], imm[19:12], rd, 7'h6F};
  endfunction

endpackage
