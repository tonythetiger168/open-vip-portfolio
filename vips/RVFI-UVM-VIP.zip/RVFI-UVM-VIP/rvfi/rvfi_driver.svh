// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_driver.svh -- RVFI driver: instruction fetches answered with the item's instruction after lat clocks; a background responder serves loads and stores from the agent's memory

class rvfi_driver extends uvm_driver #(rvfi_transaction);
  `uvm_component_utils(rvfi_driver)

  uvm_analysis_port #(rvfi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual rvfi_if vif;
  rvfi_config cfg;

  bit [31:0] mem [bit [29:0]];

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual rvfi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "rvfi: virtual interface not set")
    if (!uvm_config_db#(rvfi_config)::get(this, "", "cfg", cfg))
      cfg = rvfi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    rvfi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      int unsigned n = 0;
      forever begin
        @(vif.drv_cb);
        if (vif.drv_cb.d_req) begin
          bit [31:0] a = vif.drv_cb.d_addr, w;
          repeat (n % 3) @(vif.drv_cb);
          n++;
          w = mem.exists(a[31:2]) ? mem[a[31:2]] : rvfi_mem_init(a);
          if (vif.drv_cb.d_we) begin
            for (int i = 0; i < 4; i++) if (vif.drv_cb.d_wmask[i]) w[8*i +: 8] = vif.drv_cb.d_wdata[8*i +: 8];
            mem[a[31:2]] = w;
          end
          vif.drv_cb.d_ack <= 1'b1; vif.drv_cb.d_rdata <= w;
          @(vif.drv_cb);
          vif.drv_cb.d_ack <= 1'b0;
        end
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.i_ack   <= 1'b0;
    vif.drv_cb.i_rdata <= 32'h0;
    vif.drv_cb.d_ack   <= 1'b0;
    vif.drv_cb.d_rdata <= 32'h0;
  endtask

  task drive_item(rvfi_transaction t);
    while (!vif.drv_cb.i_req) @(vif.drv_cb);
    repeat (t.lat) @(vif.drv_cb);
    vif.drv_cb.i_ack <= 1'b1; vif.drv_cb.i_rdata <= t.insn;
    @(vif.drv_cb);
    vif.drv_cb.i_ack <= 1'b0;
    @(vif.drv_cb);
  endtask

endclass
