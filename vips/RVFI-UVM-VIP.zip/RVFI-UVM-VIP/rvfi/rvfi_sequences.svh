// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_sequences.svh -- RVFI sequences

// Random traffic: cfg.num_items constrained-random items.
class rvfi_base_sequence extends uvm_sequence #(rvfi_transaction);
  `uvm_object_utils(rvfi_base_sequence)
  rvfi_config cfg;

  function new(string name = "rvfi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = rvfi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "rvfi_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class rvfi_directed_sequence extends uvm_sequence #(rvfi_transaction);
  `uvm_object_utils(rvfi_directed_sequence)
  rvfi_config cfg;

  function new(string name = "rvfi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function rvfi_transaction item();
    item = rvfi_transaction::type_id::create("req");
  endfunction

  task send(rvfi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    rvfi_transaction t;
    // a short program with known results, then traps of every kind
    bit [31:0] p [$] = '{
      32'h1234_50B7,                         // lui   x1, 0x12345
      rv_i(12'h678, 5'd1, 3'd0, 5'd1, 7'h13), // addi  x1, x1, 0x678
      rv_i(12'hFFF, 5'd0, 3'd0, 5'd2, 7'h13), // addi  x2, x0, -1
      rv_s(12'h040, 5'd1, 5'd0, 3'd2),        // sw    x1, 0x40(x0)
      rv_i(12'h040, 5'd0, 3'd2, 5'd3, 7'h03), // lw    x3, 0x40(x0)
      rv_i(12'h041, 5'd0, 3'd0, 5'd4, 7'h03), // lb    x4, 0x41(x0)
      rv_i(12'h043, 5'd0, 3'd4, 5'd5, 7'h03), // lbu   x5, 0x43(x0)
      rv_i(12'h042, 5'd0, 3'd1, 5'd6, 7'h03), // lh    x6, 0x42(x0)
      rv_s(12'h045, 5'd2, 5'd0, 3'd0),        // sb    x2, 0x45(x0)
      rv_i(12'h044, 5'd0, 3'd5, 5'd7, 7'h03), // lhu   x7, 0x44(x0)
      rv_s(12'h046, 5'd1, 5'd0, 3'd1),        // sh    x1, 0x46(x0)
      rv_i(12'h044, 5'd0, 3'd2, 5'd7, 7'h03), // lw    x7, 0x44(x0)
      rv_r(7'h20, 5'd1, 5'd3, 3'd0, 5'd4, 7'h33), // sub x4, x3, x1
      rv_b(13'h008, 5'd0, 5'd4, 3'd0),        // beq   x4, x0, +8 (taken)
      rv_b(13'h008, 5'd0, 5'd4, 3'd1),        // bne   x4, x0, +8 (not taken)
      rv_i(12'h404, 5'd2, 3'd5, 5'd5, 7'h13), // srai  x5, x2, 4
      rv_j(21'h00C, 5'd6),                    // jal   x6, +12
      rv_i(12'h080, 5'd0, 3'd0, 5'd7, 7'h67), // jalr  x7, 0x80(x0)
      rv_i(12'h042, 5'd0, 3'd2, 5'd3, 7'h03), // lw    x3, 0x42(x0): misaligned
      rv_s(12'h041, 5'd1, 5'd0, 3'd1),        // sh    x1, 0x41(x0): misaligned
      rv_j(21'h006, 5'd1),                    // jal   x1, +6: misaligned target
      rv_i(12'h082, 5'd0, 3'd0, 5'd1, 7'h67), // jalr  x1, 0x82(x0): misaligned target
      32'h0000_0073, 32'h0010_0073,           // ecall, ebreak
      rv_i(12'h024, 5'd1, 3'd1, 5'd1, 7'h13), // slli with shamt bit 5: illegal
      rv_r(7'h01, 5'd1, 5'd1, 3'd0, 5'd1, 7'h33), // mul: not RV32I
      32'h3000_2073,                          // csrr mstatus: not implemented
      32'h0000_100F,                          // fence.i: not implemented
      32'h0FF0_000F,                          // fence
      rv_i(12'h000, 5'd0, 3'd0, 5'd0, 7'h13)  // nop
    };
    foreach (p[k]) begin t = item(); t.insn = p[k]; send(t); end
  endtask
endclass
