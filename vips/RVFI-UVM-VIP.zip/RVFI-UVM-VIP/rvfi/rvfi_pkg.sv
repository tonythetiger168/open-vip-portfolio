// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_pkg.sv -- RVFI UVM VIP package

package rvfi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import rvfi_defs_pkg::*;
  export rvfi_defs_pkg::*;

  `include "rvfi_transaction.svh"
  `include "rvfi_config.svh"
  `include "rvfi_sequencer.svh"
  `include "rvfi_driver.svh"
  `include "rvfi_monitor.svh"
  `include "rvfi_agent.svh"
  `include "rvfi_sequences.svh"
  `include "rvfi_checker.svh"
  `include "rvfi_coverage.svh"
endpackage
