// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_checker.svh -- RVFI protocol checker on monitored items

class rvfi_checker extends uvm_component;
  `uvm_component_utils(rvfi_checker)
  uvm_analysis_imp #(rvfi_transaction, rvfi_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  rvfi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(rvfi_config)::get(this, "", "cfg", cfg))
      cfg = rvfi_config::type_id::create("cfg");
  endfunction

  function void fail(rvfi_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("RVFI: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(rvfi_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.trap && (t.rd_addr != 0 || t.mem_rmask != 0 || t.mem_wmask != 0)) fail(t, "trapped instruction reports a register or memory access");
      if (t.rd_addr == 0 && t.rd_wdata != 0) fail(t, "rd_wdata nonzero without rd");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("RVFI checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
