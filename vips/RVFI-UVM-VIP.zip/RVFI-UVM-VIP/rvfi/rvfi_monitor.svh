// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_monitor.svh -- RVFI monitor: one item per rvfi_valid: the whole retirement record

class rvfi_monitor extends uvm_monitor;
  `uvm_component_utils(rvfi_monitor)

  virtual rvfi_if vif;
  uvm_analysis_port #(rvfi_transaction) ap;
  rvfi_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual rvfi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "rvfi: virtual interface not set")
    if (!uvm_config_db#(rvfi_config)::get(this, "", "cfg", cfg))
      cfg = rvfi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rvfi_valid) begin
          rvfi_transaction t = rvfi_transaction::type_id::create("t");
          t.insn = vif.mon_cb.rvfi_insn; t.order = vif.mon_cb.rvfi_order;
          t.trap = vif.mon_cb.rvfi_trap; t.halt = vif.mon_cb.rvfi_halt; t.intr = vif.mon_cb.rvfi_intr;
          t.mode = vif.mon_cb.rvfi_mode; t.ixl = vif.mon_cb.rvfi_ixl;
          t.rs1_addr = vif.mon_cb.rvfi_rs1_addr; t.rs2_addr = vif.mon_cb.rvfi_rs2_addr;
          t.rs1_rdata = vif.mon_cb.rvfi_rs1_rdata; t.rs2_rdata = vif.mon_cb.rvfi_rs2_rdata;
          t.rd_addr = vif.mon_cb.rvfi_rd_addr; t.rd_wdata = vif.mon_cb.rvfi_rd_wdata;
          t.pc_rdata = vif.mon_cb.rvfi_pc_rdata; t.pc_wdata = vif.mon_cb.rvfi_pc_wdata;
          t.mem_addr = vif.mon_cb.rvfi_mem_addr; t.mem_rmask = vif.mon_cb.rvfi_mem_rmask; t.mem_wmask = vif.mon_cb.rvfi_mem_wmask;
          t.mem_rdata = vif.mon_cb.rvfi_mem_rdata; t.mem_wdata = vif.mon_cb.rvfi_mem_wdata;
          publish(t);
        end
      end
    end
  endtask

  function void publish(rvfi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
