// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_if.sv -- RVFI interface

interface rvfi_if (input logic clk);
  logic rst_n;

  logic i_ack;
  logic [31:0] i_rdata;
  logic d_ack;
  logic [31:0] d_rdata;
  logic i_req;
  logic [31:0] i_addr;
  logic d_req;
  logic d_we;
  logic [31:0] d_addr;
  logic [3:0] d_wmask;
  logic [31:0] d_wdata;
  logic rvfi_valid;
  logic [63:0] rvfi_order;
  logic [31:0] rvfi_insn;
  logic rvfi_trap;
  logic rvfi_halt;
  logic rvfi_intr;
  logic [1:0] rvfi_mode;
  logic [1:0] rvfi_ixl;
  logic [4:0] rvfi_rs1_addr;
  logic [4:0] rvfi_rs2_addr;
  logic [31:0] rvfi_rs1_rdata;
  logic [31:0] rvfi_rs2_rdata;
  logic [4:0] rvfi_rd_addr;
  logic [31:0] rvfi_rd_wdata;
  logic [31:0] rvfi_pc_rdata;
  logic [31:0] rvfi_pc_wdata;
  logic [31:0] rvfi_mem_addr;
  logic [3:0] rvfi_mem_rmask;
  logic [3:0] rvfi_mem_wmask;
  logic [31:0] rvfi_mem_rdata;
  logic [31:0] rvfi_mem_wdata;

  modport DUT (input clk, rst_n, input i_ack, input i_rdata, input d_ack, input d_rdata, output i_req, output i_addr, output d_req, output d_we, output d_addr, output d_wmask, output d_wdata, output rvfi_valid, output rvfi_order, output rvfi_insn, output rvfi_trap, output rvfi_halt, output rvfi_intr, output rvfi_mode, output rvfi_ixl, output rvfi_rs1_addr, output rvfi_rs2_addr, output rvfi_rs1_rdata, output rvfi_rs2_rdata, output rvfi_rd_addr, output rvfi_rd_wdata, output rvfi_pc_rdata, output rvfi_pc_wdata, output rvfi_mem_addr, output rvfi_mem_rmask, output rvfi_mem_wmask, output rvfi_mem_rdata, output rvfi_mem_wdata);
  modport MON (input clk, rst_n, i_ack, i_rdata, d_ack, d_rdata, i_req, i_addr, d_req, d_we, d_addr, d_wmask, d_wdata, rvfi_valid, rvfi_order, rvfi_insn, rvfi_trap, rvfi_halt, rvfi_intr, rvfi_mode, rvfi_ixl, rvfi_rs1_addr, rvfi_rs2_addr, rvfi_rs1_rdata, rvfi_rs2_rdata, rvfi_rd_addr, rvfi_rd_wdata, rvfi_pc_rdata, rvfi_pc_wdata, rvfi_mem_addr, rvfi_mem_rmask, rvfi_mem_wmask, rvfi_mem_rdata, rvfi_mem_wdata);

  clocking drv_cb @(posedge clk);
    input rst_n, i_req, i_addr, d_req, d_we, d_addr, d_wmask, d_wdata, rvfi_valid, rvfi_order, rvfi_insn, rvfi_trap, rvfi_halt, rvfi_intr, rvfi_mode, rvfi_ixl, rvfi_rs1_addr, rvfi_rs2_addr, rvfi_rs1_rdata, rvfi_rs2_rdata, rvfi_rd_addr, rvfi_rd_wdata, rvfi_pc_rdata, rvfi_pc_wdata, rvfi_mem_addr, rvfi_mem_rmask, rvfi_mem_wmask, rvfi_mem_rdata, rvfi_mem_wdata;
    inout i_ack, i_rdata, d_ack, d_rdata;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, i_ack, i_rdata, d_ack, d_rdata, i_req, i_addr, d_req, d_we, d_addr, d_wmask, d_wdata, rvfi_valid, rvfi_order, rvfi_insn, rvfi_trap, rvfi_halt, rvfi_intr, rvfi_mode, rvfi_ixl, rvfi_rs1_addr, rvfi_rs2_addr, rvfi_rs1_rdata, rvfi_rs2_rdata, rvfi_rd_addr, rvfi_rd_wdata, rvfi_pc_rdata, rvfi_pc_wdata, rvfi_mem_addr, rvfi_mem_rmask, rvfi_mem_wmask, rvfi_mem_rdata, rvfi_mem_wdata;
  endclocking
endinterface
