// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_compliance_checker.sv -- RVFI concurrent assertion checks (bindable)

module rvfi_compliance_checker
  (input logic clk, input logic rst_n, input logic i_ack, input logic [31:0] i_rdata, input logic d_ack, input logic [31:0] d_rdata, input logic i_req, input logic [31:0] i_addr, input logic d_req, input logic d_we, input logic [31:0] d_addr, input logic [3:0] d_wmask, input logic [31:0] d_wdata, input logic rvfi_valid, input logic [63:0] rvfi_order, input logic [31:0] rvfi_insn, input logic rvfi_trap, input logic rvfi_halt, input logic rvfi_intr, input logic [1:0] rvfi_mode, input logic [1:0] rvfi_ixl, input logic [4:0] rvfi_rs1_addr, input logic [4:0] rvfi_rs2_addr, input logic [31:0] rvfi_rs1_rdata, input logic [31:0] rvfi_rs2_rdata, input logic [4:0] rvfi_rd_addr, input logic [31:0] rvfi_rd_wdata, input logic [31:0] rvfi_pc_rdata, input logic [31:0] rvfi_pc_wdata, input logic [31:0] rvfi_mem_addr, input logic [3:0] rvfi_mem_rmask, input logic [3:0] rvfi_mem_wmask, input logic [31:0] rvfi_mem_rdata, input logic [31:0] rvfi_mem_wdata);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({i_req, d_req, rvfi_valid}))
    else $error("RVFI: X on a request or rvfi_valid");
  assert property (@(posedge clk) disable iff (!rst_n) rvfi_valid |-> !$isunknown({rvfi_insn, rvfi_pc_rdata, rvfi_pc_wdata, rvfi_rd_wdata}))
    else $error("RVFI: X in a retirement record");
  // one memory request at a time, held until acknowledged
  assert property (@(posedge clk) disable iff (!rst_n) !(i_req && d_req))
    else $error("RVFI: fetch and data request together");
  assert property (@(posedge clk) disable iff (!rst_n) d_req && !d_ack |=> d_req && $stable(d_addr))
    else $error("RVFI: data request dropped or changed before its acknowledge");
  cover property (@(posedge clk) disable iff (!rst_n) rvfi_valid && rvfi_trap);
  cover property (@(posedge clk) disable iff (!rst_n) rvfi_valid && rvfi_intr);
endmodule
