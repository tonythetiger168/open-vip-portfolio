// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_coverage.svh -- RVFI functional coverage

class rvfi_coverage extends uvm_subscriber #(rvfi_transaction);
  `uvm_component_utils(rvfi_coverage)
  rvfi_config cfg;
  rvfi_transaction tr;

  covergroup rvfi_cg;
    cp_op : coverpoint tr.insn[6:0] { bins lui = {7'h37}; bins auipc = {7'h17}; bins jal = {7'h6F}; bins jalr = {7'h67};
                                      bins branch = {7'h63}; bins load = {7'h03}; bins store = {7'h23}; bins op_imm = {7'h13};
                                      bins op = {7'h33}; bins fence = {7'h0F}; bins system = {7'h73}; }
    cp_trap : coverpoint tr.trap;
    cp_intr : coverpoint tr.intr;
    cp_taken : coverpoint (tr.pc_wdata != tr.pc_rdata + 4) iff (tr.insn[6:0] == 7'h63 && !tr.trap);
    cp_lsize : coverpoint tr.mem_rmask iff (tr.mem_rmask != 0) { bins b[] = {4'h1, 4'h2, 4'h4, 4'h8}; bins h[] = {4'h3, 4'hC}; bins w = {4'hF}; }
    cp_ssize : coverpoint tr.mem_wmask iff (tr.mem_wmask != 0) { bins b[] = {4'h1, 4'h2, 4'h4, 4'h8}; bins h[] = {4'h3, 4'hC}; bins w = {4'hF}; }
    cp_alu : coverpoint tr.insn[14:12] iff ((tr.insn[6:0] == 7'h33 || tr.insn[6:0] == 7'h13) && !tr.trap);
    x_op_trap : cross cp_op, cp_trap { ignore_bins ok_sys = binsof(cp_op.system) && binsof(cp_trap) intersect {0};
                                       ignore_bins lui_trap = binsof(cp_op) intersect {7'h37, 7'h17} && binsof(cp_trap) intersect {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    rvfi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(rvfi_config)::get(this, "", "cfg", cfg))
      cfg = rvfi_config::type_id::create("cfg");
  endfunction

  function void write(rvfi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    rvfi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("RVFI coverage: %0.1f%%", rvfi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
