// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rvfi_transaction.svh -- RVFI transaction

class rvfi_transaction extends uvm_sequence_item;
  `uvm_object_utils(rvfi_transaction)

  // request (driven by the agent)
  rand bit [31:0] insn;
  // response (returned by the DUT)
  bit [63:0] order;
  bit trap;
  bit halt;
  bit intr;
  bit [1:0] mode;
  bit [1:0] ixl;
  bit [4:0] rs1_addr;
  bit [4:0] rs2_addr;
  bit [31:0] rs1_rdata;
  bit [31:0] rs2_rdata;
  bit [4:0] rd_addr;
  bit [31:0] rd_wdata;
  bit [31:0] pc_rdata;
  bit [31:0] pc_wdata;
  bit [31:0] mem_addr;
  bit [3:0] mem_rmask;
  bit [3:0] mem_wmask;
  bit [31:0] mem_rdata;
  bit [31:0] mem_wdata;
  // bookkeeping (not compared)
  rand bit [4:0] cls;
  rand bit [2:0] r_rd;
  rand bit [2:0] r_rs1;
  rand bit [2:0] r_rs2;
  rand bit [3:0] r_f;
  rand bit [31:0] r_imm;
  rand bit [1:0] lat;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "rvfi_transaction"); super.new(name); endfunction

  // an instruction of class cls; registers mostly x0..x7 so results are reused;
  // loads / stores mostly off x0 (address = immediate, so alignment is chosen)
  function void post_randomize();
    bit [4:0] rd = {2'b00, r_rd}, rs1 = {2'b00, r_rs1}, rs2 = {2'b00, r_rs2};
    bit [11:0] im = r_imm[11:0];
    bit [2:0] f3 = r_f[2:0];
    bit [2:0] alu [8] = '{3'd0, 3'd2, 3'd3, 3'd4, 3'd6, 3'd7, 3'd1, 3'd5};
    if (r_imm[31]) rd = r_imm[30:26];
    case (cls)
      0, 1, 2, 24, 25: begin                                  // OP-IMM
        f3 = alu[r_f[2:0]];
        if (f3 == 3'd1) im = {7'h00, im[4:0]};
        if (f3 == 3'd5) im = {r_f[3] ? 7'h20 : 7'h00, im[4:0]};
        insn = rv_i(im, rs1, f3, rd, 7'h13);
      end
      3, 4, 5, 26, 27: begin                                  // OP
        f3 = r_f[2:0];
        insn = rv_r((r_f[3] && (f3 == 3'd0 || f3 == 3'd5)) ? 7'h20 : 7'h00, rs2, rs1, f3, rd, 7'h33);
      end
      6: insn = {r_imm[31:12], rd, 7'h37};                     // LUI
      7: insn = {r_imm[31:12], rd, 7'h17};                     // AUIPC
      8: insn = rv_j({r_imm[20:2], r_f[0] & r_f[1], 1'b0}, rd); // JAL (target misaligned 1 in 4)
      9: insn = rv_i({im[11:2], r_f[0] & r_f[1], 1'b0}, r_f[2] ? rs1 : 5'd0, 3'd0, rd, 7'h67);  // JALR
      10, 11, 12: begin                                       // BRANCH
        f3 = (r_f[2:1] == 2'b01) ? {1'b0, 1'b0, r_f[0]} : r_f[2:0];
        insn = rv_b({r_imm[12:2], r_f[3] & r_imm[13], 1'b0}, rs2, rs1, f3);
      end
      13, 14, 15, 28, 29: begin                               // LOAD
        bit [2:0] lf [8] = '{3'd0, 3'd1, 3'd2, 3'd4, 3'd5, 3'd2, 3'd2, 3'd0};
        f3 = lf[r_f[2:0]];
        if (!r_f[3]) im = {4'h0, im[7:2], (f3[1:0] == 2'd2) ? 2'b00 : (f3[1:0] == 2'd1) ? {im[1], 1'b0} : im[1:0]};
        insn = rv_i(im, r_f[3] ? rs1 : 5'd0, f3, rd, 7'h03);
      end
      16, 17, 18, 30, 31: begin                               // STORE
        f3 = (r_f[1:0] == 2'd3) ? 3'd2 : {1'b0, r_f[1:0]};
        if (!r_f[3]) im = {4'h0, im[7:2], (f3 == 3'd2) ? 2'b00 : (f3 == 3'd1) ? {im[1], 1'b0} : im[1:0]};
        insn = rv_s(im, rs2, r_f[2] ? rs1 : 5'd0, f3);
      end
      19: insn = {4'h0, r_imm[27:20], 5'd0, 3'd0, 5'd0, 7'h0F};  // FENCE
      20: insn = 32'h0000_0073;                                // ECALL
      21: insn = 32'h0010_0073;                                // EBREAK
      22: insn = r_imm;                                        // anything
      default: insn = {r_imm[31:20], rs1, 3'd2, rd, 7'h73};    // CSRRS: not implemented
    endcase
  endfunction

  function void do_copy(uvm_object rhs);
    rvfi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    insn = rhs_.insn;
    order = rhs_.order;
    trap = rhs_.trap;
    halt = rhs_.halt;
    intr = rhs_.intr;
    mode = rhs_.mode;
    ixl = rhs_.ixl;
    rs1_addr = rhs_.rs1_addr;
    rs2_addr = rhs_.rs2_addr;
    rs1_rdata = rhs_.rs1_rdata;
    rs2_rdata = rhs_.rs2_rdata;
    rd_addr = rhs_.rd_addr;
    rd_wdata = rhs_.rd_wdata;
    pc_rdata = rhs_.pc_rdata;
    pc_wdata = rhs_.pc_wdata;
    mem_addr = rhs_.mem_addr;
    mem_rmask = rhs_.mem_rmask;
    mem_wmask = rhs_.mem_wmask;
    mem_rdata = rhs_.mem_rdata;
    mem_wdata = rhs_.mem_wdata;
    cls = rhs_.cls;
    r_rd = rhs_.r_rd;
    r_rs1 = rhs_.r_rs1;
    r_rs2 = rhs_.r_rs2;
    r_f = rhs_.r_f;
    r_imm = rhs_.r_imm;
    lat = rhs_.lat;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    rvfi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (insn != rhs_.insn) return 0;
    if (order != rhs_.order) return 0;
    if (trap != rhs_.trap) return 0;
    if (halt != rhs_.halt) return 0;
    if (intr != rhs_.intr) return 0;
    if (mode != rhs_.mode) return 0;
    if (ixl != rhs_.ixl) return 0;
    if (rs1_addr != rhs_.rs1_addr) return 0;
    if (rs2_addr != rhs_.rs2_addr) return 0;
    if (rs1_rdata != rhs_.rs1_rdata) return 0;
    if (rs2_rdata != rhs_.rs2_rdata) return 0;
    if (rd_addr != rhs_.rd_addr) return 0;
    if (rd_wdata != rhs_.rd_wdata) return 0;
    if (pc_rdata != rhs_.pc_rdata) return 0;
    if (pc_wdata != rhs_.pc_wdata) return 0;
    if (mem_addr != rhs_.mem_addr) return 0;
    if (mem_rmask != rhs_.mem_rmask) return 0;
    if (mem_wmask != rhs_.mem_wmask) return 0;
    if (mem_rdata != rhs_.mem_rdata) return 0;
    if (mem_wdata != rhs_.mem_wdata) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(rvfi_transaction rhs_);
    if (insn != rhs_.insn) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("RVFI{tag=%0d insn=0x%0h order=0x%0h trap=0x%0h halt=0x%0h intr=0x%0h mode=0x%0h ixl=0x%0h rs1_addr=0x%0h rs2_addr=0x%0h rs1_rdata=0x%0h rs2_rdata=0x%0h rd_addr=0x%0h rd_wdata=0x%0h pc_rdata=0x%0h pc_wdata=0x%0h mem_addr=0x%0h mem_rmask=0x%0h mem_wmask=0x%0h mem_rdata=0x%0h mem_wdata=0x%0h}", tag, insn, order, trap, halt, intr, mode, ixl, rs1_addr, rs2_addr, rs1_rdata, rs2_rdata, rd_addr, rd_wdata, pc_rdata, pc_wdata, mem_addr, mem_rmask, mem_wmask, mem_rdata, mem_wdata);
  endfunction
endclass
