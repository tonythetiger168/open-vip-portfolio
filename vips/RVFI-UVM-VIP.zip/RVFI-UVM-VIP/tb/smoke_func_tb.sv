// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (RVFI DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened rvfi_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic i_ack = 1'b0, d_ack = 1'b0;
  logic [31:0] i_rdata = 32'h0, d_rdata = 32'h0;
  wire i_req, d_req, d_we;
  wire [31:0] i_addr, d_addr, d_wdata;
  wire [3:0] d_wmask;
  wire rvfi_valid, rvfi_trap, rvfi_halt, rvfi_intr;
  wire [63:0] rvfi_order;
  wire [31:0] rvfi_insn, rvfi_rs1_rdata, rvfi_rs2_rdata, rvfi_rd_wdata, rvfi_pc_rdata, rvfi_pc_wdata;
  wire [31:0] rvfi_mem_addr, rvfi_mem_rdata, rvfi_mem_wdata;
  wire [1:0] rvfi_mode, rvfi_ixl;
  wire [4:0] rvfi_rs1_addr, rvfi_rs2_addr, rvfi_rd_addr;
  wire [3:0] rvfi_mem_rmask, rvfi_mem_wmask;

  always #5 clk = ~clk;

  rvfi_model u_dut (.clk(clk), .rst_n(rst_n), .i_ack(i_ack), .i_rdata(i_rdata), .d_ack(d_ack), .d_rdata(d_rdata),
    .i_req(i_req), .i_addr(i_addr), .d_req(d_req), .d_we(d_we), .d_addr(d_addr), .d_wmask(d_wmask), .d_wdata(d_wdata),
    .rvfi_valid(rvfi_valid), .rvfi_order(rvfi_order), .rvfi_insn(rvfi_insn), .rvfi_trap(rvfi_trap), .rvfi_halt(rvfi_halt),
    .rvfi_intr(rvfi_intr), .rvfi_mode(rvfi_mode), .rvfi_ixl(rvfi_ixl), .rvfi_rs1_addr(rvfi_rs1_addr),
    .rvfi_rs2_addr(rvfi_rs2_addr), .rvfi_rs1_rdata(rvfi_rs1_rdata), .rvfi_rs2_rdata(rvfi_rs2_rdata),
    .rvfi_rd_addr(rvfi_rd_addr), .rvfi_rd_wdata(rvfi_rd_wdata), .rvfi_pc_rdata(rvfi_pc_rdata),
    .rvfi_pc_wdata(rvfi_pc_wdata), .rvfi_mem_addr(rvfi_mem_addr), .rvfi_mem_rmask(rvfi_mem_rmask),
    .rvfi_mem_wmask(rvfi_mem_wmask), .rvfi_mem_rdata(rvfi_mem_rdata), .rvfi_mem_wdata(rvfi_mem_wdata));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // encoders
  function automatic logic [31:0] I(input integer imm, input integer rs1, input integer f3, input integer rd, input logic [6:0] op);
    I = {imm[11:0], rs1[4:0], f3[2:0], rd[4:0], op};
  endfunction
  function automatic logic [31:0] R(input logic [6:0] f7, input integer rs2, input integer rs1, input integer f3, input integer rd);
    R = {f7, rs2[4:0], rs1[4:0], f3[2:0], rd[4:0], 7'h33};
  endfunction
  function automatic logic [31:0] S(input integer imm, input integer rs2, input integer rs1, input integer f3);
    S = {imm[11:5], rs2[4:0], rs1[4:0], f3[2:0], imm[4:0], 7'h23};
  endfunction
  function automatic logic [31:0] B(input integer imm, input integer rs2, input integer rs1, input integer f3);
    B = {imm[12], imm[10:5], rs2[4:0], rs1[4:0], f3[2:0], imm[4:1], imm[11], 7'h63};
  endfunction
  function automatic logic [31:0] J(input integer imm, input integer rd);
    J = {imm[20], imm[10:1], imm[11], imm[19:12], rd[4:0], 7'h6F};
  endfunction

  // memories: program (by word address) and data (zero at reset)
  logic [31:0] im [0:255];
  logic [31:0] dm [0:63];
  integer lat = 0;
  always @(posedge clk) begin
    i_ack <= 1'b0; d_ack <= 1'b0;
    if (i_req && !i_ack) begin
      if (lat == 0) begin i_ack <= 1'b1; i_rdata <= im[i_addr[9:2]]; lat <= 2; end
      else lat <= lat - 1;
    end
    if (d_req && !d_ack) begin
      d_ack <= 1'b1;
      d_rdata <= dm[d_addr[7:2]];
      if (d_we) for (int k = 0; k < 4; k++) if (d_wmask[k]) dm[d_addr[7:2]][8*k +: 8] <= d_wdata[8*k +: 8];
    end
  end

  // retirement records
  logic [31:0] r_pc [0:127], r_pcw [0:127], r_wd [0:127], r_ma [0:127], r_mr [0:127], r_mw [0:127], r_r1 [0:127], r_r2 [0:127];
  logic [4:0]  r_rd [0:127], r_a1 [0:127], r_a2 [0:127];
  logic [3:0]  r_rm [0:127], r_wm [0:127];
  logic        r_tr [0:127], r_in [0:127], r_ok [0:127];
  logic [63:0] r_or [0:127];
  integer nr = 0, both = 0;
  always @(posedge clk) if (rst_n && i_req && d_req) both = both + 1;
  always @(posedge clk) if (rvfi_valid && nr < 128) begin
    r_pc[nr] = rvfi_pc_rdata; r_pcw[nr] = rvfi_pc_wdata; r_wd[nr] = rvfi_rd_wdata; r_rd[nr] = rvfi_rd_addr;
    r_ma[nr] = rvfi_mem_addr; r_mr[nr] = rvfi_mem_rdata; r_mw[nr] = rvfi_mem_wdata; r_rm[nr] = rvfi_mem_rmask;
    r_wm[nr] = rvfi_mem_wmask; r_tr[nr] = rvfi_trap; r_in[nr] = rvfi_intr; r_or[nr] = rvfi_order;
    r_ok[nr] = (rvfi_halt === 1'b0 && rvfi_mode === 2'd3 && rvfi_ixl === 2'd1);
    r_a1[nr] = rvfi_rs1_addr; r_a2[nr] = rvfi_rs2_addr; r_r1[nr] = rvfi_rs1_rdata; r_r2[nr] = rvfi_rs2_rdata;
    nr = nr + 1;
  end

  // record k: PC, next PC, rd and its value, trap
  function automatic logic rec(input integer k, input logic [31:0] pc, input logic [31:0] pcw, input integer rd,
                               input logic [31:0] wd, input logic tr);
    rec = k < nr && r_pc[k] == pc && r_pcw[k] == pcw && r_rd[k] == rd && r_wd[k] == wd && r_tr[k] == tr &&
          r_or[k] == k && (tr || r_in[k] == (k > 0 && r_tr[k - 1]));
  endfunction
  function automatic logic mem(input integer k, input logic [31:0] a, input logic [3:0] rm, input logic [3:0] wm,
                               input logic [31:0] rd, input logic [31:0] wd);
    mem = r_ma[k] == a && r_rm[k] == rm && r_wm[k] == wm && r_mr[k] == rd && r_mw[k] == wd;
  endfunction
  function automatic logic nomem(input integer k);
    nomem = r_ma[k] == 0 && r_rm[k] == 0 && r_wm[k] == 0 && r_mr[k] == 0 && r_mw[k] == 0;
  endfunction
  function automatic logic rs(input integer k, input integer a1, input logic [31:0] d1, input integer a2, input logic [31:0] d2);
    rs = r_a1[k] == a1 && r_r1[k] == d1 && r_a2[k] == a2 && r_r2[k] == d2;
  endfunction

  initial begin
    integer k;
    for (int j = 0; j < 256; j++) im[j] = 32'h0000_0013;
    for (int j = 0; j < 64; j++) dm[j] = 32'h0;
    im[0]  = 32'h1234_50B7;                 // 00 lui   x1, 0x12345
    im[1]  = I(12'h678, 1, 0, 1, 7'h13);    // 04 addi  x1, x1, 0x678
    im[2]  = I(-1, 0, 0, 2, 7'h13);         // 08 addi  x2, x0, -1
    im[3]  = S(12'h040, 1, 0, 2);           // 0C sw    x1, 0x40(x0)
    im[4]  = I(12'h040, 0, 2, 3, 7'h03);    // 10 lw    x3, 0x40(x0)
    im[5]  = I(12'h041, 0, 0, 4, 7'h03);    // 14 lb    x4, 0x41(x0)
    im[6]  = I(12'h043, 0, 4, 5, 7'h03);    // 18 lbu   x5, 0x43(x0)
    im[7]  = I(12'h042, 0, 1, 6, 7'h03);    // 1C lh    x6, 0x42(x0)
    im[8]  = S(12'h045, 2, 0, 0);           // 20 sb    x2, 0x45(x0)
    im[9]  = I(12'h045, 0, 0, 7, 7'h03);    // 24 lb    x7, 0x45(x0)
    im[10] = I(12'h045, 0, 4, 7, 7'h03);    // 28 lbu   x7, 0x45(x0)
    im[11] = I(12'h044, 0, 1, 8, 7'h03);    // 2C lh    x8, 0x44(x0)
    im[12] = S(12'h046, 1, 0, 1);           // 30 sh    x1, 0x46(x0)
    im[13] = I(12'h044, 0, 2, 9, 7'h03);    // 34 lw    x9, 0x44(x0)
    im[14] = R(7'h20, 1, 3, 0, 10);         // 38 sub   x10, x3, x1
    im[15] = B(8, 0, 10, 0);                // 3C beq   x10, x0, +8
    im[16] = I(1, 0, 0, 11, 7'h13);         // 40 addi  x11, x0, 1 (skipped)
    im[17] = B(8, 0, 10, 1);                // 44 bne   x10, x0, +8 (not taken)
    im[18] = R(7'h00, 0, 2, 2, 12);         // 48 slt   x12, x2, x0
    im[19] = R(7'h00, 0, 2, 3, 13);         // 4C sltu  x13, x2, x0
    im[20] = I(12'h404, 2, 5, 14, 7'h13);   // 50 srai  x14, x2, 4
    im[21] = I(12'h004, 1, 5, 15, 7'h13);   // 54 srli  x15, x1, 4
    im[22] = I(12'h004, 1, 1, 16, 7'h13);   // 58 slli  x16, x1, 4
    im[23] = I(-1, 1, 4, 17, 7'h13);        // 5C xori  x17, x1, -1
    im[24] = 32'h0000_1917;                 // 60 auipc x18, 1
    im[25] = J(12, 19);                     // 64 jal   x19, +12
    im[28] = I(12'h080, 0, 0, 20, 7'h67);   // 70 jalr  x20, 0x80(x0)
    im[32] = B(8, 0, 2, 4);                 // 80 blt   x2, x0, +8
    im[34] = B(8, 1, 2, 7);                 // 88 bgeu  x2, x1, +8
    im[36] = R(7'h00, 1, 1, 0, 0);          // 90 add   x0, x1, x1
    im[37] = R(7'h00, 17, 1, 6, 22);        // 94 or    x22, x1, x17
    im[38] = I(12'h0B0, 0, 0, 26, 7'h13);   // 98 addi  x26, x0, 0xB0
    im[39] = I(12'h042, 0, 2, 24, 7'h03);   // 9C lw    x24, 0x42(x0): misaligned
    im[64] = I(1, 25, 0, 25, 7'h13);        // 100 addi x25, x25, 1 (trap handler)
    im[65] = I(0, 26, 0, 0, 7'h67);         // 104 jalr x0, 0(x26)
    im[44] = I(12'h0C0, 0, 0, 26, 7'h13);   // B0 addi  x26, x0, 0xC0
    im[45] = 32'h0000_0073;                 // B4 ecall
    im[48] = I(12'h0D0, 0, 0, 26, 7'h13);   // C0 addi  x26, x0, 0xD0
    im[49] = 32'hFFFF_FFFF;                 // C4 illegal
    im[52] = I(12'h0E0, 0, 0, 26, 7'h13);   // D0 addi  x26, x0, 0xE0
    im[53] = J(6, 1);                       // D4 jal   x1, +6: misaligned target
    im[56] = I(12'h0F0, 0, 0, 26, 7'h13);   // E0 addi  x26, x0, 0xF0
    im[57] = S(12'h041, 1, 0, 2);           // E4 sw    x1, 0x41(x0): misaligned
    im[60] = I(12'h180, 0, 0, 26, 7'h13);   // F0 addi  x26, x0, 0x180
    im[61] = 32'h0010_0073;                 // F4 ebreak
    im[96] = I(12'h040, 0, 2, 27, 7'h03);   // 180 lw   x27, 0x40(x0)
    im[97] = R(7'h00, 0, 1, 0, 28);         // 184 add  x28, x1, x0
    im[98] = I(12'h194, 0, 0, 26, 7'h13);   // 188 addi x26, x0, 0x194
    im[99] = I(12'h024, 1, 1, 29, 7'h13);   // 18C slli with shamt bit 5: illegal
    im[101] = 32'h0FF0_000F;                // 194 fence
    im[102] = B(8, 2, 0, 5);                // 198 bge  x0, x2, +8
    im[104] = R(7'h20, 1, 2, 5, 30);        // 1A0 sra  x30, x2, x1 (shamt 24)
    im[105] = I(12'h1B0, 0, 0, 26, 7'h13);  // 1A4 addi x26, x0, 0x1B0
    im[106] = B(6, 0, 0, 0);                // 1A8 beq  x0, x0, +6: misaligned target
    im[108] = R(7'h00, 22, 1, 7, 31);       // 1B0 and  x31, x1, x22
    im[109] = I(12'h1C0, 0, 0, 26, 7'h13);  // 1B4 addi x26, x0, 0x1C0
    im[110] = I(12'h082, 0, 0, 1, 7'h67);   // 1B8 jalr x1, 0x82(x0): misaligned target
    im[112] = I(12'h1D0, 0, 0, 26, 7'h13);  // 1C0 addi x26, x0, 0x1D0
    im[113] = I(12'h080, 0, 1, 1, 7'h67);   // 1C4 jalr with funct3 1: illegal
    im[116] = I(12'h1E0, 0, 0, 26, 7'h13);  // 1D0 addi x26, x0, 0x1E0
    im[117] = B(8, 0, 0, 2);                // 1D4 branch funct3 2: illegal
    im[120] = I(12'h1F0, 0, 0, 26, 7'h13);  // 1E0 addi x26, x0, 0x1F0
    im[121] = I(12'h040, 0, 3, 1, 7'h03);   // 1E4 load funct3 3: illegal
    im[124] = I(12'h040, 0, 0, 5, 7'h13);   // 1F0 addi x5, x0, 0x40
    im[125] = I(12'h004, 5, 2, 6, 7'h03);   // 1F4 lw   x6, 4(x5)
    im[126] = I(12'h201, 0, 0, 7, 7'h67);   // 1F8 jalr x7, 0x201(x0): bit 0 cleared
    im[128] = J(0, 0);                      // 200 jal  x0, 0 (stay)
    repeat (3) @(posedge clk);
    chk(i_req === 1'b0 && rvfi_valid === 1'b0 && d_req === 1'b0 && d_we === 1'b0, "no fetch, data request or retirement in reset");
    rst_n = 1;
    k = 0;
    while (k < 4000 && nr < 60) begin @(posedge clk); k = k + 1; end
    chk(nr >= 56, $sformatf("program retired (%0d records)", nr));
    chk(rec(0, 32'h00, 32'h04, 1, 32'h1234_5000, 0) && nomem(0) && rs(0, 0, 0, 0, 0) && !r_in[0], "lui");
    chk(rec(1, 32'h04, 32'h08, 1, 32'h1234_5678, 0) && rs(1, 1, 32'h1234_5000, 0, 0), "addi reads x1");
    chk(rec(2, 32'h08, 32'h0C, 2, 32'hFFFF_FFFF, 0), "addi -1");
    chk(rec(3, 32'h0C, 32'h10, 0, 0, 0) && mem(3, 32'h40, 4'h0, 4'hF, 0, 32'h1234_5678) && rs(3, 0, 0, 1, 32'h1234_5678), "sw");
    chk(rec(4, 32'h10, 32'h14, 3, 32'h1234_5678, 0) && mem(4, 32'h40, 4'hF, 4'h0, 32'h1234_5678, 0), "lw");
    chk(rec(5, 32'h14, 32'h18, 4, 32'h56, 0) && mem(5, 32'h40, 4'h2, 4'h0, 32'h1234_5678, 0), "lb lane 1");
    chk(rec(6, 32'h18, 32'h1C, 5, 32'h12, 0) && mem(6, 32'h40, 4'h8, 4'h0, 32'h1234_5678, 0), "lbu lane 3");
    chk(rec(7, 32'h1C, 32'h20, 6, 32'h1234, 0) && mem(7, 32'h40, 4'hC, 4'h0, 32'h1234_5678, 0), "lh upper half");
    chk(rec(8, 32'h20, 32'h24, 0, 0, 0) && mem(8, 32'h44, 4'h0, 4'h2, 0, 32'h0000_FF00), "sb lane 1");
    chk(rec(9, 32'h24, 32'h28, 7, 32'hFFFF_FFFF, 0), "lb sign-extends");
    chk(rec(10, 32'h28, 32'h2C, 7, 32'h0000_00FF, 0), "lbu zero-extends");
    chk(rec(11, 32'h2C, 32'h30, 8, 32'hFFFF_FF00, 0), "lh sign-extends");
    chk(rec(12, 32'h30, 32'h34, 0, 0, 0) && mem(12, 32'h44, 4'h0, 4'hC, 0, 32'h5678_0000), "sh upper half");
    chk(rec(13, 32'h34, 32'h38, 9, 32'h5678_FF00, 0), "lw after sb / sh");
    chk(rec(14, 32'h38, 32'h3C, 10, 32'h0, 0) && rs(14, 3, 32'h1234_5678, 1, 32'h1234_5678), "sub");
    chk(rec(15, 32'h3C, 32'h44, 0, 0, 0) && rs(15, 10, 0, 0, 0), "beq taken");
    chk(rec(16, 32'h44, 32'h48, 0, 0, 0), "bne not taken");
    chk(rec(17, 32'h48, 32'h4C, 12, 32'h1, 0), "slt -1 < 0");
    chk(rec(18, 32'h4C, 32'h50, 13, 32'h0, 0), "sltu 0xFFFFFFFF < 0 false");
    chk(rec(19, 32'h50, 32'h54, 14, 32'hFFFF_FFFF, 0), "srai");
    chk(rec(20, 32'h54, 32'h58, 15, 32'h0123_4567, 0), "srli");
    chk(rec(21, 32'h58, 32'h5C, 16, 32'h2345_6780, 0), "slli");
    chk(rec(22, 32'h5C, 32'h60, 17, 32'hEDCB_A987, 0), "xori -1");
    chk(rec(23, 32'h60, 32'h64, 18, 32'h0000_1060, 0), "auipc");
    chk(rec(24, 32'h64, 32'h70, 19, 32'h68, 0), "jal");
    chk(rec(25, 32'h70, 32'h80, 20, 32'h74, 0) && rs(25, 0, 0, 0, 0), "jalr");
    chk(rec(26, 32'h80, 32'h88, 0, 0, 0), "blt taken");
    chk(rec(27, 32'h88, 32'h90, 0, 0, 0), "bgeu taken");
    chk(rec(28, 32'h90, 32'h94, 0, 0, 0) && rs(28, 1, 32'h1234_5678, 1, 32'h1234_5678), "add to x0: no rd");
    chk(rec(29, 32'h94, 32'h98, 22, 32'hFFFF_FFFF, 0), "or");
    chk(rec(31, 32'h9C, 32'h100, 0, 0, 1) && nomem(31) && rs(31, 0, 0, 0, 0), "misaligned lw traps");
    chk(rec(32, 32'h100, 32'h104, 25, 32'h1, 0) && r_in[32], "handler: intr on its first instruction");
    chk(rec(33, 32'h104, 32'hB0, 0, 0, 0) && !r_in[33], "handler returns");
    chk(rec(35, 32'hB4, 32'h100, 0, 0, 1), "ecall traps");
    chk(rec(39, 32'hC4, 32'h100, 0, 0, 1), "illegal instruction traps");
    chk(rec(43, 32'hD4, 32'h100, 0, 0, 1), "jal to a misaligned target traps, no link");
    chk(rec(47, 32'hE4, 32'h100, 0, 0, 1) && nomem(47), "misaligned sw traps, no write");
    chk(rec(51, 32'hF4, 32'h100, 0, 0, 1), "ebreak traps");
    chk(rec(52, 32'h100, 32'h104, 25, 32'h6, 0), "handler counted six traps");
    chk(rec(54, 32'h180, 32'h184, 27, 32'h1234_5678, 0), "memory unchanged by the trapped store");
    chk(rec(55, 32'h184, 32'h188, 28, 32'h1234_5678, 0), "x1 unchanged by the trapped jal");
    chk(rec(57, 32'h18C, 32'h100, 0, 0, 1), "slli with shamt bit 5 traps");
    k = 0;
    while (k < 6000 && nr < 89) begin @(posedge clk); k = k + 1; end
    chk(rec(60, 32'h194, 32'h198, 0, 0, 0) && nomem(60) && rs(60, 0, 0, 0, 0), "fence: no-op");
    chk(rec(61, 32'h198, 32'h1A0, 0, 0, 0), "bge 0 >= -1 taken");
    chk(rec(62, 32'h1A0, 32'h1A4, 30, 32'hFFFF_FFFF, 0) && rs(62, 2, 32'hFFFF_FFFF, 1, 32'h1234_5678), "sra by x1[4:0]");
    chk(rec(64, 32'h1A8, 32'h100, 0, 0, 1), "taken branch to a misaligned target traps");
    chk(rec(67, 32'h1B0, 32'h1B4, 31, 32'h1234_5678, 0), "and");
    chk(rec(69, 32'h1B8, 32'h100, 0, 0, 1), "jalr to a misaligned target traps, no link");
    chk(rec(73, 32'h1C4, 32'h100, 0, 0, 1), "jalr with funct3 1 traps");
    chk(rec(77, 32'h1D4, 32'h100, 0, 0, 1), "branch with funct3 2 traps");
    chk(rec(81, 32'h1E4, 32'h100, 0, 0, 1), "load with funct3 3 traps");
    chk(rec(85, 32'h1F4, 32'h1F8, 6, 32'h5678_FF00, 0) && rs(85, 5, 32'h40, 0, 0) && mem(85, 32'h44, 4'hF, 4'h0, 32'h5678_FF00, 0),
        "lw off a base register reports rs1");
    chk(rec(86, 32'h1F8, 32'h200, 7, 32'h1FC, 0), "jalr clears bit 0 of the target");
    chk(rec(87, 32'h200, 32'h200, 0, 0, 0) && rec(88, 32'h200, 32'h200, 0, 0, 0), "jal x0, 0 loops");
    k = 1;
    for (int j = 0; j < 89; j++) if (!r_ok[j]) k = 0;
    chk(k == 1, "halt 0, mode M, ixl 32 on every record");
    chk(both == 0, "never a fetch and a data request together");
    chk(dm[16] == 32'h1234_5678 && dm[17] == 32'h5678_FF00, "data memory after the stores");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
