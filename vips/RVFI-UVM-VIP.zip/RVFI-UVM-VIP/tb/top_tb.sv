// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- RVFI testbench top with a functional RVFI DUT model

`ifndef RVFI_UVM_VIP_TB_SV
`define RVFI_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import rvfi_defs_pkg::*;
import rvfi_pkg::*;
import rvfi_env_pkg::*;
import rvfi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  rvfi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  rvfi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .i_ack(vif.i_ack),
    .i_rdata(vif.i_rdata),
    .d_ack(vif.d_ack),
    .d_rdata(vif.d_rdata),
    .i_req(vif.i_req),
    .i_addr(vif.i_addr),
    .d_req(vif.d_req),
    .d_we(vif.d_we),
    .d_addr(vif.d_addr),
    .d_wmask(vif.d_wmask),
    .d_wdata(vif.d_wdata),
    .rvfi_valid(vif.rvfi_valid),
    .rvfi_order(vif.rvfi_order),
    .rvfi_insn(vif.rvfi_insn),
    .rvfi_trap(vif.rvfi_trap),
    .rvfi_halt(vif.rvfi_halt),
    .rvfi_intr(vif.rvfi_intr),
    .rvfi_mode(vif.rvfi_mode),
    .rvfi_ixl(vif.rvfi_ixl),
    .rvfi_rs1_addr(vif.rvfi_rs1_addr),
    .rvfi_rs2_addr(vif.rvfi_rs2_addr),
    .rvfi_rs1_rdata(vif.rvfi_rs1_rdata),
    .rvfi_rs2_rdata(vif.rvfi_rs2_rdata),
    .rvfi_rd_addr(vif.rvfi_rd_addr),
    .rvfi_rd_wdata(vif.rvfi_rd_wdata),
    .rvfi_pc_rdata(vif.rvfi_pc_rdata),
    .rvfi_pc_wdata(vif.rvfi_pc_wdata),
    .rvfi_mem_addr(vif.rvfi_mem_addr),
    .rvfi_mem_rmask(vif.rvfi_mem_rmask),
    .rvfi_mem_wmask(vif.rvfi_mem_wmask),
    .rvfi_mem_rdata(vif.rvfi_mem_rdata),
    .rvfi_mem_wdata(vif.rvfi_mem_wdata)
  );

  // Concurrent protocol checks
  rvfi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .i_ack(vif.i_ack),
    .i_rdata(vif.i_rdata),
    .d_ack(vif.d_ack),
    .d_rdata(vif.d_rdata),
    .i_req(vif.i_req),
    .i_addr(vif.i_addr),
    .d_req(vif.d_req),
    .d_we(vif.d_we),
    .d_addr(vif.d_addr),
    .d_wmask(vif.d_wmask),
    .d_wdata(vif.d_wdata),
    .rvfi_valid(vif.rvfi_valid),
    .rvfi_order(vif.rvfi_order),
    .rvfi_insn(vif.rvfi_insn),
    .rvfi_trap(vif.rvfi_trap),
    .rvfi_halt(vif.rvfi_halt),
    .rvfi_intr(vif.rvfi_intr),
    .rvfi_mode(vif.rvfi_mode),
    .rvfi_ixl(vif.rvfi_ixl),
    .rvfi_rs1_addr(vif.rvfi_rs1_addr),
    .rvfi_rs2_addr(vif.rvfi_rs2_addr),
    .rvfi_rs1_rdata(vif.rvfi_rs1_rdata),
    .rvfi_rs2_rdata(vif.rvfi_rs2_rdata),
    .rvfi_rd_addr(vif.rvfi_rd_addr),
    .rvfi_rd_wdata(vif.rvfi_rd_wdata),
    .rvfi_pc_rdata(vif.rvfi_pc_rdata),
    .rvfi_pc_wdata(vif.rvfi_pc_wdata),
    .rvfi_mem_addr(vif.rvfi_mem_addr),
    .rvfi_mem_rmask(vif.rvfi_mem_rmask),
    .rvfi_mem_wmask(vif.rvfi_mem_wmask),
    .rvfi_mem_rdata(vif.rvfi_mem_rdata),
    .rvfi_mem_wdata(vif.rvfi_mem_wdata)
  );

  initial begin
    uvm_config_db#(virtual rvfi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module rvfi_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        i_ack,
  input  logic [31:0] i_rdata,
  input  logic        d_ack,
  input  logic [31:0] d_rdata,
  output logic        i_req,
  output logic [31:0] i_addr,
  output logic        d_req,
  output logic        d_we,
  output logic [31:0] d_addr,
  output logic [3:0]  d_wmask,
  output logic [31:0] d_wdata,
  output logic        rvfi_valid,
  output logic [63:0] rvfi_order,
  output logic [31:0] rvfi_insn,
  output logic        rvfi_trap,
  output logic        rvfi_halt,
  output logic        rvfi_intr,
  output logic [1:0]  rvfi_mode,
  output logic [1:0]  rvfi_ixl,
  output logic [4:0]  rvfi_rs1_addr,
  output logic [4:0]  rvfi_rs2_addr,
  output logic [31:0] rvfi_rs1_rdata,
  output logic [31:0] rvfi_rs2_rdata,
  output logic [4:0]  rvfi_rd_addr,
  output logic [31:0] rvfi_rd_wdata,
  output logic [31:0] rvfi_pc_rdata,
  output logic [31:0] rvfi_pc_wdata,
  output logic [31:0] rvfi_mem_addr,
  output logic [3:0]  rvfi_mem_rmask,
  output logic [3:0]  rvfi_mem_wmask,
  output logic [31:0] rvfi_mem_rdata,
  output logic [31:0] rvfi_mem_wdata
);
  localparam logic [31:0] MTVEC = 32'h0000_0100;
  localparam logic [1:0]  S_FETCH = 2'd0, S_EXEC = 2'd1, S_MEM = 2'd2;

  logic [31:0] x [0:31];
  logic [31:0] pc, ir;
  logic [1:0]  state;
  logic [63:0] ord;
  logic        intr_n;
  logic [4:0]  l_rd;          // pending load: destination, funct3, byte offset
  logic [2:0]  l_f3;
  logic [1:0]  l_off;
  logic        l_ld;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int k = 0; k < 32; k++) x[k] <= 32'h0;
      pc <= 32'h0; ir <= 32'h0; state <= S_FETCH; ord <= 64'h0; intr_n <= 1'b0;
      l_rd <= '0; l_f3 <= '0; l_off <= '0; l_ld <= 1'b0;
      i_req <= 1'b0; i_addr <= 32'h0; d_req <= 1'b0; d_we <= 1'b0; d_addr <= 32'h0; d_wmask <= 4'h0; d_wdata <= 32'h0;
      rvfi_valid <= 1'b0; rvfi_order <= '0; rvfi_insn <= '0; rvfi_trap <= 1'b0; rvfi_halt <= 1'b0; rvfi_intr <= 1'b0;
      rvfi_mode <= 2'd3; rvfi_ixl <= 2'd1; rvfi_rs1_addr <= '0; rvfi_rs2_addr <= '0; rvfi_rs1_rdata <= '0;
      rvfi_rs2_rdata <= '0; rvfi_rd_addr <= '0; rvfi_rd_wdata <= '0; rvfi_pc_rdata <= '0; rvfi_pc_wdata <= '0;
      rvfi_mem_addr <= '0; rvfi_mem_rmask <= '0; rvfi_mem_wmask <= '0; rvfi_mem_rdata <= '0; rvfi_mem_wdata <= '0;
    end else begin
      rvfi_valid <= 1'b0;
      case (state)
        S_FETCH: begin
          i_req <= 1'b1; i_addr <= pc;
          if (i_req && i_ack) begin ir <= i_rdata; i_req <= 1'b0; state <= S_EXEC; end
        end
        S_EXEC: begin : exec
          logic [31:0] i, a, b, r, npc, ea, ii, is, ib, ij, wd;
          logic [4:0]  rd, rs1, rs2;
          logic [2:0]  f3;
          logic [6:0]  f7;
          logic        trap, wr, u1, u2, ld, st, tk;
          logic [3:0]  m;
          i = ir;
          rd = i[11:7]; rs1 = i[19:15]; rs2 = i[24:20]; f3 = i[14:12]; f7 = i[31:25];
          ii = {{20{i[31]}}, i[31:20]};
          is = {{20{i[31]}}, i[31:25], i[11:7]};
          ib = {{19{i[31]}}, i[31], i[7], i[30:25], i[11:8], 1'b0};
          ij = {{11{i[31]}}, i[31], i[19:12], i[20], i[30:21], 1'b0};
          a = (rs1 == 5'd0) ? 32'h0 : x[rs1];
          b = (rs2 == 5'd0) ? 32'h0 : x[rs2];
          trap = 1'b0; wr = 1'b0; u1 = 1'b0; u2 = 1'b0; ld = 1'b0; st = 1'b0; tk = 1'b0;
          r = 32'h0; ea = 32'h0; m = 4'h0; wd = 32'h0;
          npc = pc + 32'd4;
          case (i[6:0])
            7'h37: begin wr = 1'b1; r = {i[31:12], 12'h0}; end
            7'h17: begin wr = 1'b1; r = pc + {i[31:12], 12'h0}; end
            7'h6F: begin wr = 1'b1; r = pc + 32'd4; npc = pc + ij; trap = npc[1]; end
            7'h67: begin
              u1 = 1'b1; wr = 1'b1; r = pc + 32'd4; npc = (a + ii) & ~32'h1;
              trap = (f3 != 3'd0) || npc[1];
            end
            7'h63: begin
              u1 = 1'b1; u2 = 1'b1;
              case (f3)
                3'd0: tk = (a == b);
                3'd1: tk = (a != b);
                3'd4: tk = ($signed(a) < $signed(b));
                3'd5: tk = ($signed(a) >= $signed(b));
                3'd6: tk = (a < b);
                3'd7: tk = (a >= b);
                default: trap = 1'b1;
              endcase
              if (tk) npc = pc + ib;
              if (tk && npc[1]) trap = 1'b1;
            end
            7'h03: begin
              u1 = 1'b1; wr = 1'b1; ld = 1'b1; ea = a + ii;
              if (f3 == 3'd3 || f3 > 3'd5) trap = 1'b1;
              else if ((f3[1:0] == 2'd1 && ea[0]) || (f3[1:0] == 2'd2 && ea[1:0] != 2'd0)) trap = 1'b1;
              m = ((f3[1:0] == 2'd0) ? 4'h1 : (f3[1:0] == 2'd1) ? 4'h3 : 4'hF) << ea[1:0];
            end
            7'h23: begin
              u1 = 1'b1; u2 = 1'b1; st = 1'b1; ea = a + is;
              if (f3 > 3'd2) trap = 1'b1;
              else if ((f3 == 3'd1 && ea[0]) || (f3 == 3'd2 && ea[1:0] != 2'd0)) trap = 1'b1;
              m = ((f3 == 3'd0) ? 4'h1 : (f3 == 3'd1) ? 4'h3 : 4'hF) << ea[1:0];
              wd = b << (8 * ea[1:0]);
              for (int k = 0; k < 4; k++) if (!m[k]) wd[8*k +: 8] = 8'h00;
            end
            7'h13: begin
              u1 = 1'b1; wr = 1'b1;
              case (f3)
                3'd0: r = a + ii;
                3'd2: r = ($signed(a) < $signed(ii)) ? 32'd1 : 32'd0;
                3'd3: r = (a < ii) ? 32'd1 : 32'd0;
                3'd4: r = a ^ ii;
                3'd6: r = a | ii;
                3'd7: r = a & ii;
                3'd1: begin r = a << i[24:20]; trap = (f7 != 7'h00); end
                default: begin
                  if (f7[5]) r = $signed(a) >>> i[24:20]; else r = a >> i[24:20];
                  trap = (f7 != 7'h00 && f7 != 7'h20);
                end
              endcase
            end
            7'h33: begin
              u1 = 1'b1; u2 = 1'b1; wr = 1'b1;
              trap = !(f7 == 7'h00 || (f7 == 7'h20 && (f3 == 3'd0 || f3 == 3'd5)));
              case (f3)
                3'd0: r = f7[5] ? a - b : a + b;
                3'd1: r = a << b[4:0];
                3'd2: r = ($signed(a) < $signed(b)) ? 32'd1 : 32'd0;
                3'd3: r = (a < b) ? 32'd1 : 32'd0;
                3'd4: r = a ^ b;
                3'd5: if (f7[5]) r = $signed(a) >>> b[4:0]; else r = a >> b[4:0];
                3'd6: r = a | b;
                default: r = a & b;
              endcase
            end
            7'h0F: trap = (f3 != 3'd0);
            default: trap = 1'b1;
          endcase
          rvfi_order <= ord; rvfi_insn <= i; rvfi_pc_rdata <= pc; rvfi_intr <= intr_n; rvfi_trap <= trap;
          rvfi_mem_addr <= 32'h0; rvfi_mem_rmask <= 4'h0; rvfi_mem_wmask <= 4'h0; rvfi_mem_rdata <= 32'h0; rvfi_mem_wdata <= 32'h0;
          if (trap) begin
            npc = MTVEC;
            rvfi_rs1_addr <= 5'd0; rvfi_rs1_rdata <= 32'h0; rvfi_rs2_addr <= 5'd0; rvfi_rs2_rdata <= 32'h0;
            rvfi_rd_addr <= 5'd0; rvfi_rd_wdata <= 32'h0;
          end else begin
            rvfi_rs1_addr <= u1 ? rs1 : 5'd0; rvfi_rs1_rdata <= u1 ? a : 32'h0;
            rvfi_rs2_addr <= u2 ? rs2 : 5'd0; rvfi_rs2_rdata <= u2 ? b : 32'h0;
            rvfi_rd_addr <= (wr && rd != 5'd0) ? rd : 5'd0;
            rvfi_rd_wdata <= (wr && rd != 5'd0) ? r : 32'h0;
          end
          rvfi_pc_wdata <= npc;
          if (!trap && (ld || st)) begin
            d_req <= 1'b1; d_we <= st; d_addr <= {ea[31:2], 2'b00}; d_wmask <= st ? m : 4'h0; d_wdata <= wd;
            rvfi_mem_addr <= {ea[31:2], 2'b00};
            if (ld) rvfi_mem_rmask <= m;
            else begin rvfi_mem_wmask <= m; rvfi_mem_wdata <= wd; end
            l_rd <= rd; l_f3 <= f3; l_off <= ea[1:0]; l_ld <= ld;
            state <= S_MEM;
          end else begin
            if (!trap && wr && rd != 5'd0) x[rd] <= r;
            rvfi_valid <= 1'b1;
            pc <= npc; ord <= ord + 64'd1; intr_n <= trap;
            state <= S_FETCH;
          end
        end
        default: begin                                      // S_MEM
          if (d_req && d_ack) begin : mem_done
            logic [31:0] sh, r;
            d_req <= 1'b0; d_we <= 1'b0;
            sh = d_rdata >> (8 * l_off);
            case (l_f3)
              3'd0: r = {{24{sh[7]}}, sh[7:0]};
              3'd1: r = {{16{sh[15]}}, sh[15:0]};
              3'd4: r = {24'h0, sh[7:0]};
              3'd5: r = {16'h0, sh[15:0]};
              default: r = sh;
            endcase
            if (l_ld) begin
              rvfi_mem_rdata <= d_rdata;
              if (l_rd != 5'd0) begin x[l_rd] <= r; rvfi_rd_wdata <= r; end
            end
            rvfi_valid <= 1'b1;
            pc <= pc + 32'd4; ord <= ord + 64'd1; intr_n <= 1'b0;
            state <= S_FETCH;
          end
        end
      endcase
    end
  end
endmodule
`endif
