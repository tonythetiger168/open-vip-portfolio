// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_defs.sv -- ACE shared type definitions

package ace_defs_pkg;

  typedef enum bit [1:0] {ACE_OK, ACE_ERR} ace_status_e;

  localparam bit [3:0] C_RD_NOSNOOP = 4'd0;
  localparam bit [3:0] C_RD_ONCE = 4'd1;
  localparam bit [3:0] C_RD_SHARED = 4'd2;
  localparam bit [3:0] C_RD_UNIQUE = 4'd3;
  localparam bit [3:0] C_CLEAN_UNIQUE = 4'd4;
  localparam bit [3:0] C_WR_NOSNOOP = 4'd5;
  localparam bit [3:0] C_WR_UNIQUE = 4'd6;
  localparam bit [3:0] C_WR_BACK = 4'd7;
  localparam bit [3:0] C_SN_RD_ONCE = 4'd8;
  localparam bit [3:0] C_SN_RD_SHARED = 4'd9;
  localparam bit [3:0] C_SN_RD_UNIQUE = 4'd10;
  localparam bit [3:0] C_SN_CLEAN_INV = 4'd11;
  localparam bit [3:0] C_SN_MAKE_INV = 4'd12;
  localparam bit [3:0] C_BAD = 4'd15;
  // line states
  localparam bit [2:0] ST_I = 3'd0, ST_UC = 3'd1, ST_UD = 3'd2, ST_SC = 3'd3, ST_SD = 3'd4;

  // command -> AR / AW signals
  function automatic bit [3:0] ace_arsnoop(bit [3:0] c);
    case (c)
      C_RD_SHARED:    return 4'b0001;
      C_RD_UNIQUE:    return 4'b0111;
      C_CLEAN_UNIQUE: return 4'b1011;
      default:        return 4'b0000;     // ReadNoSnoop / ReadOnce
    endcase
  endfunction
  function automatic bit [2:0] ace_awsnoop(bit [3:0] c);
    return (c == C_WR_BACK) ? 3'b011 : 3'b000;   // WriteNoSnoop / WriteUnique 000
  endfunction
  // AR / AW / AC signals -> command
  function automatic bit [3:0] ace_ar_cmd(bit [3:0] snoop, bit [1:0] domain);
    if (domain == 2'b00 || domain == 2'b11) return snoop == 4'b0000 ? C_RD_NOSNOOP : C_BAD;
    case (snoop)
      4'b0000: return C_RD_ONCE;
      4'b0001: return C_RD_SHARED;
      4'b0111: return C_RD_UNIQUE;
      4'b1011: return C_CLEAN_UNIQUE;
      default: return C_BAD;
    endcase
  endfunction
  function automatic bit [3:0] ace_aw_cmd(bit [2:0] snoop, bit [1:0] domain);
    if (domain == 2'b00 || domain == 2'b11) return snoop == 3'b000 ? C_WR_NOSNOOP : C_BAD;
    case (snoop)
      3'b000:  return C_WR_UNIQUE;
      3'b011:  return C_WR_BACK;
      default: return C_BAD;
    endcase
  endfunction
  function automatic bit [3:0] ace_ac_cmd(bit [3:0] snoop);
    case (snoop)
      4'b0000: return C_SN_RD_ONCE;
      4'b0001: return C_SN_RD_SHARED;
      4'b0111: return C_SN_RD_UNIQUE;
      4'b1001: return C_SN_CLEAN_INV;
      4'b1101: return C_SN_MAKE_INV;
      default: return C_BAD;
    endcase
  endfunction
  // initial memory contents: word w of line i
  function automatic bit [127:0] ace_init_line(int i);
    bit [127:0] l;
    for (int w = 0; w < 4; w++) l[w*32 +: 32] = {24'hC0FFEE, 4'(i), 4'(w)};
    return l;
  endfunction
  // the peer's modification after its ReadUnique: every word + 1
  function automatic bit [127:0] ace_inc_line(bit [127:0] x);
    bit [127:0] l;
    for (int w = 0; w < 4; w++) l[w*32 +: 32] = x[w*32 +: 32] + 32'd1;
    return l;
  endfunction

endpackage
