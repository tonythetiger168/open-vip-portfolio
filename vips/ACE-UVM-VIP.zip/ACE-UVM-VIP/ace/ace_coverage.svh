// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_coverage.svh -- ACE functional coverage

class ace_coverage extends uvm_subscriber #(ace_transaction);
  `uvm_component_utils(ace_coverage)
  ace_config cfg;
  ace_transaction tr;

  covergroup ace_cg;
    cp_cmd    : coverpoint tr.cmd { bins rns = {C_RD_NOSNOOP}; bins ro = {C_RD_ONCE}; bins rs = {C_RD_SHARED};
                                    bins ru = {C_RD_UNIQUE}; bins cu = {C_CLEAN_UNIQUE}; bins wns = {C_WR_NOSNOOP};
                                    bins wu = {C_WR_UNIQUE}; bins wb = {C_WR_BACK}; bins s_ro = {C_SN_RD_ONCE};
                                    bins s_rs = {C_SN_RD_SHARED}; bins s_ru = {C_SN_RD_UNIQUE};
                                    bins s_ci = {C_SN_CLEAN_INV}; bins s_mi = {C_SN_MAKE_INV}; }
    cp_rs     : coverpoint tr.rresp[3:2] iff (tr.cmd == C_RD_SHARED) { bins uc = {0}; bins sc = {2}; bins sd = {3}; }
    cp_ru     : coverpoint tr.rresp[2] iff (tr.cmd == C_RD_UNIQUE);
    cp_ro     : coverpoint tr.rresp[3] iff (tr.cmd == C_RD_ONCE);
    cp_snoop  : coverpoint tr.cmd iff (tr.cmd >= C_SN_RD_ONCE && tr.cmd <= C_SN_MAKE_INV)
                           { bins ro = {C_SN_RD_ONCE}; bins rs = {C_SN_RD_SHARED}; bins ru = {C_SN_RD_UNIQUE};
                             bins ci = {C_SN_CLEAN_INV}; bins mi = {C_SN_MAKE_INV}; }
    cp_cr     : coverpoint {tr.crresp[2], tr.crresp[0]} iff (tr.cmd >= C_SN_RD_ONCE && tr.cmd <= C_SN_MAKE_INV)
                           { bins none = {2'b00}; bins clean = {2'b01}; bins dirty = {2'b11}; }
    cp_wasu   : coverpoint tr.crresp[4] iff (tr.cmd >= C_SN_RD_ONCE && tr.cmd <= C_SN_MAKE_INV);
    // legal combinations only: no data for MakeInvalid, no dirty data for ReadOnce / ReadShared here
    x_snoop_cr : cross cp_snoop, cp_cr {
      ignore_bins mi_data = binsof(cp_snoop.mi) && (binsof(cp_cr.clean) || binsof(cp_cr.dirty));
      ignore_bins ro_dirty = binsof(cp_snoop.ro) && binsof(cp_cr.dirty);
      ignore_bins rs_dirty = binsof(cp_snoop.rs) && binsof(cp_cr.dirty);
      ignore_bins ci_clean = binsof(cp_snoop.ci) && binsof(cp_cr.clean); }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ace_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ace_config)::get(this, "", "cfg", cfg))
      cfg = ace_config::type_id::create("cfg");
  endfunction

  function void write(ace_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ace_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("ACE coverage: %0.1f%%", ace_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
