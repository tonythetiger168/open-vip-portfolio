// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_monitor.svh -- ACE monitor: AR + R beats and AW + W beats + B rebuilt into transactions; AC + CR + CD into snoops

class ace_monitor extends uvm_monitor;
  `uvm_component_utils(ace_monitor)

  virtual ace_if vif;
  uvm_analysis_port #(ace_transaction) ap;
  ace_config cfg;
  int unsigned n_obs = 0;

  bit [35:0] ar_q[$], aw_q[$], ac_q[$];   // {cmd, addr}
  bit [127:0] r_line, w_line, cd_line;
  bit [15:0]  w_strb;
  int unsigned r_beats = 0, w_beats = 0, cd_beats = 0;
  bit cr_have = 0, cd_done = 0;
  bit [4:0] cr_v;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ace_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ace: virtual interface not set")
    if (!uvm_config_db#(ace_config)::get(this, "", "cfg", cfg))
      cfg = ace_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        @(vif.mon_cb);
        // ---- snoops: published once CR (and CD, with DataTransfer) are complete
        if (vif.mon_cb.acvalid && vif.mon_cb.acready) ac_q.push_back({ace_ac_cmd(vif.mon_cb.acsnoop), vif.mon_cb.acaddr});
        if (vif.mon_cb.crvalid && vif.mon_cb.crready) begin cr_have = 1; cr_v = vif.mon_cb.crresp; end
        if (vif.mon_cb.cdvalid && vif.mon_cb.cdready) begin
          cd_line[cd_beats[1:0]*32 +: 32] = vif.mon_cb.cddata; cd_beats++;
          if (vif.mon_cb.cdlast) begin
            cd_done = 1;
            if (cd_beats != 4) `uvm_error("MON", $sformatf("ACE: CD transfer of %0d beats, not a full line", cd_beats))
          end
        end
        if (cr_have && (!cr_v[0] || cd_done)) begin
          if (ac_q.size() == 0) `uvm_error("MON", "ACE: snoop response without an AC transfer")
          else begin
            ace_transaction t = ace_transaction::type_id::create("t");
            {t.cmd, t.addr} = ac_q.pop_front();
            t.crresp = cr_v; t.cdline = cr_v[0] ? cd_line : 128'h0;
            publish(t);
          end
          cr_have = 0; cd_done = 0; cd_beats = 0; cd_line = 0;
        end
        // ---- reads
        if (vif.mon_cb.arvalid && vif.mon_cb.arready) begin
          ar_q.push_back({ace_ar_cmd(vif.mon_cb.arsnoop, vif.mon_cb.ardomain), vif.mon_cb.araddr});
          if (vif.mon_cb.arlen != 8'd3 || vif.mon_cb.arsize != 3'd2)
            `uvm_error("MON", "ACE: read is not a full 16-byte line (ARLEN 3, ARSIZE 2)")
        end
        if (vif.mon_cb.rvalid && vif.mon_cb.rready) begin
          r_line[r_beats[1:0]*32 +: 32] = vif.mon_cb.rdata; r_beats++;
          if (vif.mon_cb.rlast) begin
            if (ar_q.size() == 0) `uvm_error("MON", "ACE: R transfer without an AR transfer")
            else begin
              ace_transaction t = ace_transaction::type_id::create("t");
              {t.cmd, t.addr} = ar_q.pop_front();
              if (r_beats != (t.cmd == C_CLEAN_UNIQUE ? 1 : 4))
                `uvm_error("MON", $sformatf("ACE: %0d R beats for command %0d", r_beats, t.cmd))
              t.rline = (t.cmd == C_CLEAN_UNIQUE) ? 128'h0 : r_line;
              t.rresp = vif.mon_cb.rresp;
              publish(t);
            end
            r_beats = 0; r_line = 0;
          end
        end
        // ---- writes: published at the B transfer
        if (vif.mon_cb.awvalid && vif.mon_cb.awready)
          aw_q.push_back({ace_aw_cmd(vif.mon_cb.awsnoop, vif.mon_cb.awdomain), vif.mon_cb.awaddr});
        if (vif.mon_cb.wvalid && vif.mon_cb.wready) begin
          w_line[w_beats[1:0]*32 +: 32] = vif.mon_cb.wdata; w_strb[w_beats[1:0]*4 +: 4] = vif.mon_cb.wstrb; w_beats++;
        end
        if (vif.mon_cb.bvalid && vif.mon_cb.bready) begin
          if (aw_q.size() == 0 || w_beats != 4) `uvm_error("MON", "ACE: B response without AW and four W beats")
          else begin
            ace_transaction t = ace_transaction::type_id::create("t");
            int n = 0;
            {t.cmd, t.addr} = aw_q.pop_front();
            t.bresp = vif.mon_cb.bresp;
            if (t.cmd == C_WR_BACK) begin
              t.wline = w_line;
              if (w_strb != 16'hFFFF) `uvm_error("MON", "ACE: WriteBack without every byte strobe")
            end else begin
              for (int b = 0; b < 4; b++) if (w_strb[b*4 +: 4] != 0) begin
                n++; t.word = b; t.wdata = w_line[b*32 +: 32]; t.wstrb = w_strb[b*4 +: 4];
              end
              if (n != 1) t.wline = w_line;   // the agent writes one word: anything else mismatches
            end
            publish(t);
          end
          w_beats = 0; w_line = 0; w_strb = 0;
        end
      end
    end
  endtask

  function void publish(ace_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
