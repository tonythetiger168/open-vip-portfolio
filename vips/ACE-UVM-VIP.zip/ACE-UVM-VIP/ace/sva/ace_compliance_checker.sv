// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_compliance_checker.sv -- ACE concurrent assertion checks (bindable)

module ace_compliance_checker
  (input logic clk, input logic rst_n, input logic arvalid, input logic arready, input logic [31:0] araddr, input logic [7:0] arlen, input logic [2:0] arsize, input logic [1:0] arburst, input logic [3:0] arsnoop, input logic [1:0] ardomain, input logic [1:0] arbar, input logic rvalid, input logic rready, input logic [31:0] rdata, input logic [3:0] rresp, input logic rlast, input logic rack, input logic awvalid, input logic awready, input logic [31:0] awaddr, input logic [7:0] awlen, input logic [2:0] awsize, input logic [1:0] awburst, input logic [2:0] awsnoop, input logic [1:0] awdomain, input logic [1:0] awbar, input logic wvalid, input logic wready, input logic [31:0] wdata, input logic [3:0] wstrb, input logic wlast, input logic bvalid, input logic bready, input logic [1:0] bresp, input logic wack, input logic acvalid, input logic acready, input logic [31:0] acaddr, input logic [3:0] acsnoop, input logic [2:0] acprot, input logic crvalid, input logic crready, input logic [4:0] crresp, input logic cdvalid, input logic cdready, input logic [31:0] cddata, input logic cdlast);

  // transfers counted for the RACK / WACK and response rules
  int unsigned n_rl = 0, n_rack = 0, n_b = 0, n_wack = 0, n_ar = 0;
  logic [31:0] last_rd;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin n_rl <= 0; n_rack <= 0; n_b <= 0; n_wack <= 0; n_ar <= 0; last_rd <= '0; end
    else begin
      if (arvalid && arready) begin n_ar <= n_ar + 1; last_rd <= araddr; end
      if (rvalid && rready && rlast) n_rl <= n_rl + 1;
      if (rack) n_rack <= n_rack + 1;
      if (bvalid && bready) n_b <= n_b + 1;
      if (wack) n_wack <= n_wack + 1;
    end
  assert property (@(posedge clk) !rst_n |-> !rvalid && !bvalid && !acvalid)
    else $error("ACE: VALID high in reset");
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({arready, awready, wready, rvalid, bvalid, acvalid, crready, cdready}))
    else $error("ACE: X on a handshake signal");
  // VALID held and payload stable until READY on every channel
  assert property (@(posedge clk) disable iff (!rst_n) arvalid && !arready |=> arvalid && $stable({araddr, arlen, arsize, arburst, arsnoop, ardomain, arbar}))
    else $error("ACE: AR changed before ARREADY");
  assert property (@(posedge clk) disable iff (!rst_n) awvalid && !awready |=> awvalid && $stable({awaddr, awlen, awsize, awburst, awsnoop, awdomain, awbar}))
    else $error("ACE: AW changed before AWREADY");
  assert property (@(posedge clk) disable iff (!rst_n) wvalid && !wready |=> wvalid && $stable({wdata, wstrb, wlast}))
    else $error("ACE: W changed before WREADY");
  assert property (@(posedge clk) disable iff (!rst_n) rvalid && !rready |=> rvalid && $stable({rdata, rresp, rlast}))
    else $error("ACE: R changed before RREADY");
  assert property (@(posedge clk) disable iff (!rst_n) bvalid && !bready |=> bvalid && $stable(bresp))
    else $error("ACE: B changed before BREADY");
  assert property (@(posedge clk) disable iff (!rst_n) acvalid && !acready |=> acvalid && $stable({acaddr, acsnoop, acprot}))
    else $error("ACE: AC changed before ACREADY");
  assert property (@(posedge clk) disable iff (!rst_n) crvalid && !crready |=> crvalid && $stable(crresp))
    else $error("ACE: CR changed before CRREADY");
  assert property (@(posedge clk) disable iff (!rst_n) cdvalid && !cdready |=> cdvalid && $stable({cddata, cdlast}))
    else $error("ACE: CD changed before CDREADY");
  // RACK / WACK only acknowledge completed transfers; CR: PassDirty needs DataTransfer
  assert property (@(posedge clk) disable iff (!rst_n) rack |-> n_rl > n_rack)
    else $error("ACE: RACK without an unacknowledged RLAST transfer");
  assert property (@(posedge clk) disable iff (!rst_n) wack |-> n_b > n_wack)
    else $error("ACE: WACK without an unacknowledged B transfer");
  assert property (@(posedge clk) disable iff (!rst_n) crvalid |-> !(crresp[2] && !crresp[0]))
    else $error("ACE: CRRESP PassDirty without DataTransfer");
  // no snoop to a line between its read response and RACK
  assert property (@(posedge clk) disable iff (!rst_n) $rose(acvalid) |-> !(n_rl > n_rack && acaddr[31:4] == last_rd[31:4]))
    else $error("ACE: snoop to a line whose read is not yet acknowledged");
  // ARBAR / AWBAR: no barriers on this interface
  assert property (@(posedge clk) disable iff (!rst_n) (arvalid |-> arbar == 2'b00) and (awvalid |-> awbar == 2'b00))
    else $error("ACE: barrier transaction");
  cover property (@(posedge clk) disable iff (!rst_n) acvalid && acready && acsnoop == 4'b0111);
  cover property (@(posedge clk) disable iff (!rst_n) crvalid && crready && crresp[2]);
  cover property (@(posedge clk) disable iff (!rst_n) rvalid && rready && rlast && rresp[3:2] == 2'b11);
  cover property (@(posedge clk) disable iff (!rst_n) acvalid && (arvalid || awvalid));
endmodule
