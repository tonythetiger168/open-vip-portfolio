// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_pkg.sv -- ACE UVM VIP package

package ace_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ace_defs_pkg::*;
  export ace_defs_pkg::*;

  `include "ace_transaction.svh"
  `include "ace_config.svh"
  `include "ace_sequencer.svh"
  `include "ace_driver.svh"
  `include "ace_monitor.svh"
  `include "ace_agent.svh"
  `include "ace_sequences.svh"
  `include "ace_checker.svh"
  `include "ace_coverage.svh"
endpackage
