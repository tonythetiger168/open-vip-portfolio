// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_sequences.svh -- ACE sequences

// Random traffic: cfg.num_items constrained-random items.
class ace_base_sequence extends uvm_sequence #(ace_transaction);
  `uvm_object_utils(ace_base_sequence)
  ace_config cfg;

  function new(string name = "ace_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ace_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ace_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ace_directed_sequence extends uvm_sequence #(ace_transaction);
  `uvm_object_utils(ace_directed_sequence)
  ace_config cfg;

  function new(string name = "ace_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ace_transaction item();
    item = ace_transaction::type_id::create("req");
  endfunction

  task send(ace_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ace_transaction t;
    // line 0: ReadShared, store via CleanUnique / WriteBack; line 1: ReadUnique
    // with a store, then a ReadShared request (dirty: becomes WriteBack); line 2:
    // ReadOnce / WriteUnique; non-shareable region; then a mix on four lines
    t = item(); t.cmd = C_RD_SHARED;    t.addr = 32'h00; send(t);
    t = item(); t.cmd = C_CLEAN_UNIQUE; t.addr = 32'h00; t.word = 1; t.wdata = 32'h1111_2222; t.wstrb = 4'hF; send(t);
    t = item(); t.cmd = C_WR_BACK;      t.addr = 32'h00; send(t);
    t = item(); t.cmd = C_RD_ONCE;      t.addr = 32'h00; send(t);
    t = item(); t.cmd = C_RD_UNIQUE;    t.addr = 32'h10; t.word = 3; t.wdata = 32'hAABB_CCDD; t.wstrb = 4'h6; send(t);
    t = item(); t.cmd = C_RD_SHARED;    t.addr = 32'h10; send(t);
    t = item(); t.cmd = C_RD_SHARED;    t.addr = 32'h10; send(t);
    t = item(); t.cmd = C_RD_ONCE;      t.addr = 32'h20; send(t);
    t = item(); t.cmd = C_WR_UNIQUE;    t.addr = 32'h20; t.word = 2; t.wdata = 32'h5555_6666; t.wstrb = 4'h9; send(t);
    t = item(); t.cmd = C_RD_ONCE;      t.addr = 32'h20; send(t);
    t = item(); t.cmd = C_WR_NOSNOOP;   t.addr = 32'h130; t.word = 0; t.wdata = 32'h0BAD_F00D; t.wstrb = 4'hF; send(t);
    t = item(); t.cmd = C_RD_NOSNOOP;   t.addr = 32'h130; send(t);
    for (int i = 0; i < 48; i++) begin
      t = item();
      t.cmd = (i % 5 == 0) ? C_RD_SHARED : (i % 5 == 1) ? C_CLEAN_UNIQUE : (i % 5 == 2) ? C_RD_UNIQUE :
              (i % 5 == 3) ? C_WR_BACK : C_RD_ONCE;
      t.addr = 32'h40 + 16 * (i % 4); t.word = i % 4; t.wdata = 32'h7000_0000 + i; t.wstrb = 4'hF;
      t.gap = i % 3; send(t);
    end
  endtask
endclass
