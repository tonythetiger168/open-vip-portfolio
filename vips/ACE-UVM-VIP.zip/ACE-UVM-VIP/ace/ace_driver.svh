// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_driver.svh -- ACE driver: cache controller: legal command for the line state, AR/R + RACK or AW/W/B + WACK, snoops answered on CR / CD from the cache

class ace_driver extends uvm_driver #(ace_transaction);
  `uvm_component_utils(ace_driver)

  uvm_analysis_port #(ace_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ace_if vif;
  ace_config cfg;

  bit [2:0]   cst [16];      // line states (ST_*)
  bit [127:0] cdat [16];     // line data
  bit         wb_busy = 0;   // WriteBack in progress to line wb_line
  bit [3:0]   wb_line;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ace_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ace: virtual interface not set")
    if (!uvm_config_db#(ace_config)::get(this, "", "cfg", cfg))
      cfg = ace_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ace_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      forever begin
        bit [3:0] c, l;
        bit [31:0] a;
        bit [4:0] cr;
        bit [127:0] d;
        bit valid, dirty, uniq;
        vif.drv_cb.acready <= 1'b1;
        do @(vif.drv_cb); while (vif.drv_cb.acvalid !== 1'b1);
        vif.drv_cb.acready <= 1'b0;
        a = vif.drv_cb.acaddr; c = ace_ac_cmd(vif.drv_cb.acsnoop); l = a[7:4];
        while (wb_busy && wb_line == l) @(vif.drv_cb);
        valid = cst[l] != ST_I; dirty = cst[l] == ST_UD || cst[l] == ST_SD; uniq = cst[l] == ST_UC || cst[l] == ST_UD;
        d = cdat[l];
        case (c)
          C_SN_RD_ONCE:   cr = valid ? {uniq, 1'b1, 1'b0, 1'b0, 1'b1} : 5'b0;      // keeps the line
          C_SN_RD_SHARED: begin
                            cr = valid ? {uniq, 1'b1, 1'b0, 1'b0, 1'b1} : 5'b0;    // keeps it, dirty stays here
                            if (cst[l] == ST_UC) cst[l] = ST_SC;
                            if (cst[l] == ST_UD) cst[l] = ST_SD;
                          end
          C_SN_RD_UNIQUE: begin cr = valid ? {uniq, 1'b0, dirty, 1'b0, 1'b1} : 5'b0; cst[l] = ST_I; end
          C_SN_CLEAN_INV: begin cr = {uniq, 1'b0, dirty, 1'b0, dirty}; cst[l] = ST_I; end
          C_SN_MAKE_INV:  begin cr = {uniq, 4'b0}; cst[l] = ST_I; end
          default: begin cr = 5'b00010; `uvm_error("SNOOP", $sformatf("ACE: unsupported ACSNOOP %b", vif.drv_cb.acsnoop)) end
        endcase
        vif.drv_cb.crvalid <= 1'b1; vif.drv_cb.crresp <= cr;
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.crready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.crready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("ACE CRREADY: no response within %0d cycles", cfg.timeout_cycles))
      end
        vif.drv_cb.crvalid <= 1'b0;
        if (cr[0]) for (int b = 0; b < 4; b++) begin
          vif.drv_cb.cdvalid <= 1'b1; vif.drv_cb.cddata <= d[b*32 +: 32]; vif.drv_cb.cdlast <= (b == 3);
        begin
          int unsigned to = 0;
          do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.cdready === 1'b1) && to < cfg.timeout_cycles);
          if (!(vif.drv_cb.cdready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("ACE CDREADY: no response within %0d cycles", cfg.timeout_cycles))
        end
        end
        vif.drv_cb.cdvalid <= 1'b0; vif.drv_cb.cdlast <= 1'b0;
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.arvalid <= 1'b0; vif.drv_cb.araddr <= '0; vif.drv_cb.arlen <= '0; vif.drv_cb.arsize <= '0;
    vif.drv_cb.arburst <= '0; vif.drv_cb.arsnoop <= '0; vif.drv_cb.ardomain <= '0; vif.drv_cb.arbar <= '0;
    vif.drv_cb.rready <= 1'b0; vif.drv_cb.rack <= 1'b0;
    vif.drv_cb.awvalid <= 1'b0; vif.drv_cb.awaddr <= '0; vif.drv_cb.awlen <= '0; vif.drv_cb.awsize <= '0;
    vif.drv_cb.awburst <= '0; vif.drv_cb.awsnoop <= '0; vif.drv_cb.awdomain <= '0; vif.drv_cb.awbar <= '0;
    vif.drv_cb.wvalid <= 1'b0; vif.drv_cb.wdata <= '0; vif.drv_cb.wstrb <= '0; vif.drv_cb.wlast <= 1'b0;
    vif.drv_cb.bready <= 1'b0; vif.drv_cb.wack <= 1'b0;
    vif.drv_cb.acready <= 1'b0; vif.drv_cb.crvalid <= 1'b0; vif.drv_cb.crresp <= '0;
    vif.drv_cb.cdvalid <= 1'b0; vif.drv_cb.cddata <= '0; vif.drv_cb.cdlast <= 1'b0;
    for (int i = 0; i < 16; i++) begin cst[i] = ST_I; cdat[i] = '0; end
  endtask

  task drive_item(ace_transaction t);
    bit [3:0] l, c;
    bit [2:0] s;
    repeat (t.gap) @(vif.drv_cb);
    l = t.addr[7:4];
    c = t.cmd;
    if (!t.addr[8]) begin
      // a legal command for the line state
      s = cst[l];
      if ((s == ST_UC || s == ST_SC) && !(c == C_CLEAN_UNIQUE && s == ST_SC)) begin cst[l] = ST_I; s = ST_I; end
      if (s == ST_UD || s == ST_SD) begin
        if (!(c == C_CLEAN_UNIQUE && s == ST_SD)) c = C_WR_BACK;
      end else if (s == ST_I) begin
        if (c == C_CLEAN_UNIQUE) c = C_RD_UNIQUE;
        else if (c == C_WR_BACK) begin c = C_WR_UNIQUE; if (t.wstrb == 0) t.wstrb = 4'hF; end
      end
    end
    t.cmd = c;
    t.rline = 0; t.rresp = 0; t.bresp = 0; t.crresp = 0; t.cdline = 0; t.wline = 0;
    if (c <= C_CLEAN_UNIQUE) begin
      bit [127:0] line = 0;
      int unsigned beat = 0, to = 0;
      bit done = 0;
      vif.drv_cb.arvalid <= 1'b1; vif.drv_cb.araddr <= t.addr; vif.drv_cb.arlen <= 8'd3;
      vif.drv_cb.arsize <= 3'd2; vif.drv_cb.arburst <= 2'b01; vif.drv_cb.arsnoop <= ace_arsnoop(c);
      vif.drv_cb.ardomain <= (c == C_RD_NOSNOOP) ? 2'b00 : 2'b01; vif.drv_cb.arbar <= 2'b00;
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.arready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.arready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("ACE ARREADY: no response within %0d cycles", cfg.timeout_cycles))
      end
      vif.drv_cb.arvalid <= 1'b0;
      vif.drv_cb.rready <= ($urandom_range(99) < cfg.ready_pct);
      while (!done && to < cfg.timeout_cycles) begin
        @(vif.drv_cb); to++;
        if (vif.drv_cb.rvalid === 1'b1 && vif.drv_cb.rready === 1'b1) begin
          line[beat[1:0]*32 +: 32] = vif.drv_cb.rdata; t.rresp = vif.drv_cb.rresp; beat++;
          done = vif.drv_cb.rlast;
        end
        vif.drv_cb.rready <= !done && ($urandom_range(99) < cfg.ready_pct);
      end
      if (!done) `uvm_error("TIMEOUT", "ACE: no RLAST")
      vif.drv_cb.rready <= 1'b0;
      vif.drv_cb.rack <= 1'b1;            // RACK in the clock after the last R transfer
      @(vif.drv_cb);
      vif.drv_cb.rack <= 1'b0;
      // new line state (a crossing snoop may have changed it since the decision)
      case (c)
        C_RD_SHARED: begin
          cst[l] = t.rresp[3] ? (t.rresp[2] ? ST_SD : ST_SC) : (t.rresp[2] ? ST_UD : ST_UC);
          cdat[l] = line;
        end
        C_RD_UNIQUE: begin cst[l] = t.rresp[2] ? ST_UD : ST_UC; cdat[l] = line; end
        C_CLEAN_UNIQUE: begin
          if (cst[l] == ST_SC) cst[l] = ST_UC;
          else if (cst[l] == ST_SD) cst[l] = ST_UD;
        end
        default: ;
      endcase
      // the store of ReadUnique / CleanUnique, once the line is unique
      if ((c == C_RD_UNIQUE || c == C_CLEAN_UNIQUE) && (cst[l] == ST_UC || cst[l] == ST_UD) && t.wstrb != 0) begin
        for (int b = 0; b < 4; b++) if (t.wstrb[b]) cdat[l][t.word*32 + b*8 +: 8] = t.wdata[b*8 +: 8];
        cst[l] = ST_UD;
      end
      t.rline = (c == C_CLEAN_UNIQUE) ? 128'h0 : line;
      t.word = 0; t.wdata = 0; t.wstrb = 0;
    end else begin
      bit [127:0] wl = 0;
      bit [15:0] st = 0;
      if (c == C_WR_BACK) begin
        wb_busy = 1; wb_line = l;
        wl = cdat[l]; st = 16'hFFFF;
      end else begin
        wl[t.word*32 +: 32] = t.wdata; st[t.word*4 +: 4] = t.wstrb;
      end
      vif.drv_cb.awvalid <= 1'b1; vif.drv_cb.awaddr <= t.addr; vif.drv_cb.awlen <= 8'd3;
      vif.drv_cb.awsize <= 3'd2; vif.drv_cb.awburst <= 2'b01; vif.drv_cb.awsnoop <= ace_awsnoop(c);
      vif.drv_cb.awdomain <= (c == C_WR_NOSNOOP) ? 2'b00 : 2'b01; vif.drv_cb.awbar <= 2'b00;
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.awready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.awready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("ACE AWREADY: no response within %0d cycles", cfg.timeout_cycles))
      end
      vif.drv_cb.awvalid <= 1'b0;
      for (int b = 0; b < 4; b++) begin
        vif.drv_cb.wvalid <= 1'b1; vif.drv_cb.wdata <= wl[b*32 +: 32]; vif.drv_cb.wstrb <= st[b*4 +: 4];
        vif.drv_cb.wlast <= (b == 3);
        begin
          int unsigned to = 0;
          do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.wready === 1'b1) && to < cfg.timeout_cycles);
          if (!(vif.drv_cb.wready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("ACE WREADY: no response within %0d cycles", cfg.timeout_cycles))
        end
      end
      vif.drv_cb.wvalid <= 1'b0; vif.drv_cb.wlast <= 1'b0;
      begin
        int unsigned to = 0;
        bit done = 0;
        vif.drv_cb.bready <= ($urandom_range(99) < cfg.ready_pct);
        while (!done && to < cfg.timeout_cycles) begin
          @(vif.drv_cb); to++;
          if (vif.drv_cb.bvalid === 1'b1 && vif.drv_cb.bready === 1'b1) begin done = 1; t.bresp = vif.drv_cb.bresp; end
          vif.drv_cb.bready <= !done && ($urandom_range(99) < cfg.ready_pct);
        end
        if (!done) `uvm_error("TIMEOUT", "ACE: no B response")
      end
      vif.drv_cb.bready <= 1'b0;
      vif.drv_cb.wack <= 1'b1;            // WACK in the clock after the B transfer
      @(vif.drv_cb);
      vif.drv_cb.wack <= 1'b0;
      if (c == C_WR_BACK) begin
        cst[l] = ST_I; wb_busy = 0;
        t.wline = wl; t.word = 0; t.wdata = 0; t.wstrb = 0;
      end
    end
  endtask

endclass
