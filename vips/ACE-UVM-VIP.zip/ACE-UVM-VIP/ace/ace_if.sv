// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_if.sv -- ACE interface

interface ace_if (input logic clk);
  logic rst_n;

  logic arvalid;
  logic arready;
  logic [31:0] araddr;
  logic [7:0] arlen;
  logic [2:0] arsize;
  logic [1:0] arburst;
  logic [3:0] arsnoop;
  logic [1:0] ardomain;
  logic [1:0] arbar;
  logic rvalid;
  logic rready;
  logic [31:0] rdata;
  logic [3:0] rresp;
  logic rlast;
  logic rack;
  logic awvalid;
  logic awready;
  logic [31:0] awaddr;
  logic [7:0] awlen;
  logic [2:0] awsize;
  logic [1:0] awburst;
  logic [2:0] awsnoop;
  logic [1:0] awdomain;
  logic [1:0] awbar;
  logic wvalid;
  logic wready;
  logic [31:0] wdata;
  logic [3:0] wstrb;
  logic wlast;
  logic bvalid;
  logic bready;
  logic [1:0] bresp;
  logic wack;
  logic acvalid;
  logic acready;
  logic [31:0] acaddr;
  logic [3:0] acsnoop;
  logic [2:0] acprot;
  logic crvalid;
  logic crready;
  logic [4:0] crresp;
  logic cdvalid;
  logic cdready;
  logic [31:0] cddata;
  logic cdlast;

  modport DUT (input clk, rst_n, input arvalid, input araddr, input arlen, input arsize, input arburst, input arsnoop, input ardomain, input arbar, input rready, input rack, input awvalid, input awaddr, input awlen, input awsize, input awburst, input awsnoop, input awdomain, input awbar, input wvalid, input wdata, input wstrb, input wlast, input bready, input wack, input acready, input crvalid, input crresp, input cdvalid, input cddata, input cdlast, output arready, output rvalid, output rdata, output rresp, output rlast, output awready, output wready, output bvalid, output bresp, output acvalid, output acaddr, output acsnoop, output acprot, output crready, output cdready);
  modport MON (input clk, rst_n, arvalid, arready, araddr, arlen, arsize, arburst, arsnoop, ardomain, arbar, rvalid, rready, rdata, rresp, rlast, rack, awvalid, awready, awaddr, awlen, awsize, awburst, awsnoop, awdomain, awbar, wvalid, wready, wdata, wstrb, wlast, bvalid, bready, bresp, wack, acvalid, acready, acaddr, acsnoop, acprot, crvalid, crready, crresp, cdvalid, cdready, cddata, cdlast);

  clocking drv_cb @(posedge clk);
    input rst_n, arready, rvalid, rdata, rresp, rlast, awready, wready, bvalid, bresp, acvalid, acaddr, acsnoop, acprot, crready, cdready;
    inout arvalid, araddr, arlen, arsize, arburst, arsnoop, ardomain, arbar, rready, rack, awvalid, awaddr, awlen, awsize, awburst, awsnoop, awdomain, awbar, wvalid, wdata, wstrb, wlast, bready, wack, acready, crvalid, crresp, cdvalid, cddata, cdlast;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, arvalid, arready, araddr, arlen, arsize, arburst, arsnoop, ardomain, arbar, rvalid, rready, rdata, rresp, rlast, rack, awvalid, awready, awaddr, awlen, awsize, awburst, awsnoop, awdomain, awbar, wvalid, wready, wdata, wstrb, wlast, bvalid, bready, bresp, wack, acvalid, acready, acaddr, acsnoop, acprot, crvalid, crready, crresp, cdvalid, cdready, cddata, cdlast;
  endclocking
endinterface
