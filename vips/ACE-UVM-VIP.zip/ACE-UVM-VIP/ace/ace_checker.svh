// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_checker.svh -- ACE protocol checker on monitored items

class ace_checker extends uvm_component;
  `uvm_component_utils(ace_checker)
  uvm_analysis_imp #(ace_transaction, ace_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  ace_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(ace_config)::get(this, "", "cfg", cfg))
      cfg = ace_config::type_id::create("cfg");
  endfunction

  function void fail(ace_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("ACE: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(ace_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      bit snoop = t.cmd >= C_SN_RD_ONCE && t.cmd <= C_SN_MAKE_INV;
      if (t.cmd == C_BAD) fail(t, "unsupported ARSNOOP / AWSNOOP / ACSNOOP encoding");
      if (snoop) begin
        if (t.crresp[2] && !t.crresp[0]) fail(t, "CRRESP PassDirty without DataTransfer");
        if (t.crresp[1]) fail(t, "CRRESP Error");
        if (t.cmd == C_SN_MAKE_INV && t.crresp[0]) fail(t, "data transfer for MakeInvalid");
        if ((t.cmd == C_SN_RD_UNIQUE || t.cmd == C_SN_CLEAN_INV || t.cmd == C_SN_MAKE_INV) && t.crresp[3])
          fail(t, "IsShared after an invalidating snoop");
        if (t.cmd == C_SN_RD_ONCE && t.crresp[2]) fail(t, "PassDirty for a ReadOnce snoop (the line stays here)");
      end else begin
        if (t.addr[3:0] != 0) fail(t, "address not line aligned");
        if (t.cmd <= C_CLEAN_UNIQUE && t.rresp[1:0] != 2'b00) fail(t, "read error response");
        if (t.cmd == C_RD_UNIQUE && t.rresp[3]) fail(t, "IsShared for ReadUnique");
        if (t.cmd == C_CLEAN_UNIQUE && t.rresp[3:2] != 2'b00) fail(t, "IsShared / PassDirty for CleanUnique");
        if ((t.cmd == C_RD_ONCE || t.cmd == C_RD_NOSNOOP) && t.rresp[2]) fail(t, "PassDirty for a non-caching read");
        if (t.cmd >= C_WR_NOSNOOP && t.cmd <= C_WR_BACK && t.bresp != 2'b00) fail(t, "write error response");
        if ((t.cmd == C_RD_NOSNOOP || t.cmd == C_WR_NOSNOOP) != t.addr[8]) fail(t, "shareability domain does not match the region");
      end
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("ACE checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
