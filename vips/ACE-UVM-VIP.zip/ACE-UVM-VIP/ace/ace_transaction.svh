// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_transaction.svh -- ACE transaction

class ace_transaction extends uvm_sequence_item;
  `uvm_object_utils(ace_transaction)

  // request (driven by the agent)
  rand bit [3:0] cmd;
  rand bit [31:0] addr;
  rand bit [1:0] word;
  rand bit [31:0] wdata;
  rand bit [3:0] wstrb;
  bit [127:0] wline;
  // response (returned by the DUT)
  bit [127:0] rline;
  bit [3:0] rresp;
  bit [1:0] bresp;
  bit [4:0] crresp;
  bit [127:0] cdline;
  // bookkeeping (not compared)
  rand bit [2:0] gap;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_cmd  { cmd dist { C_RD_NOSNOOP := 1, C_RD_ONCE := 1, C_RD_SHARED := 4, C_RD_UNIQUE := 3,
                                 C_CLEAN_UNIQUE := 3, C_WR_NOSNOOP := 1, C_WR_UNIQUE := 1, C_WR_BACK := 3 }; }
  constraint c_addr { addr[3:0] == 0; addr[31:9] == 0;
                      addr[8] == (cmd == C_RD_NOSNOOP || cmd == C_WR_NOSNOOP); }
  constraint c_wr   { (cmd == C_WR_NOSNOOP || cmd == C_WR_UNIQUE) -> wstrb != 4'h0; }
  constraint c_gap  { gap dist { 0 := 4, [1:7] :/ 2 }; }

  function new(string name = "ace_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    ace_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    cmd = rhs_.cmd;
    addr = rhs_.addr;
    word = rhs_.word;
    wdata = rhs_.wdata;
    wstrb = rhs_.wstrb;
    wline = rhs_.wline;
    rline = rhs_.rline;
    rresp = rhs_.rresp;
    bresp = rhs_.bresp;
    crresp = rhs_.crresp;
    cdline = rhs_.cdline;
    gap = rhs_.gap;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ace_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (cmd != rhs_.cmd) return 0;
    if (addr != rhs_.addr) return 0;
    if (word != rhs_.word) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (wstrb != rhs_.wstrb) return 0;
    if (wline != rhs_.wline) return 0;
    if (rline != rhs_.rline) return 0;
    if (rresp != rhs_.rresp) return 0;
    if (bresp != rhs_.bresp) return 0;
    if (crresp != rhs_.crresp) return 0;
    if (cdline != rhs_.cdline) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ace_transaction rhs_);
    if (cmd != rhs_.cmd) return 0;
    if (addr != rhs_.addr) return 0;
    if (word != rhs_.word) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (wstrb != rhs_.wstrb) return 0;
    if (wline != rhs_.wline) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("ACE{tag=%0d cmd=0x%0h addr=0x%0h word=0x%0h wdata=0x%0h wstrb=0x%0h wline=0x%0h rline=0x%0h rresp=0x%0h bresp=0x%0h crresp=0x%0h cdline=0x%0h}", tag, cmd, addr, word, wdata, wstrb, wline, rline, rresp, bresp, crresp, cdline);
  endfunction
endclass
