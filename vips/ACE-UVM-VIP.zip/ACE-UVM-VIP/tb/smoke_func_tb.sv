// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (ACE DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened ace_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic arvalid = 0, rready = 1, rack = 0, awvalid = 0, wvalid = 0, wlast = 0, bready = 1, wack = 0;
  logic acready = 0, crvalid = 0, cdvalid = 0, cdlast = 0;
  logic [31:0] araddr = 0, awaddr = 0, wdata = 0, cddata = 0;
  logic [3:0] arsnoop = 0, wstrb = 0;
  logic [2:0] awsnoop = 0;
  logic [1:0] ardomain = 0, awdomain = 0;
  logic [4:0] crresp = 0;
  wire arready, rvalid, rlast, awready, wready, bvalid, acvalid, crready, cdready;
  wire [31:0] rdata, acaddr;
  wire [3:0] rresp, acsnoop;
  wire [1:0] bresp;
  wire [2:0] acprot;

  always #5 clk = ~clk;

  ace_model u_dut (.clk(clk), .rst_n(rst_n), .arvalid(arvalid), .arready(arready), .araddr(araddr),
                   .arlen(8'd3), .arsize(3'd2), .arburst(2'b01), .arsnoop(arsnoop), .ardomain(ardomain),
                   .arbar(2'b00), .rvalid(rvalid), .rready(rready), .rdata(rdata), .rresp(rresp), .rlast(rlast),
                   .rack(rack), .awvalid(awvalid), .awready(awready), .awaddr(awaddr), .awlen(8'd3),
                   .awsize(3'd2), .awburst(2'b01), .awsnoop(awsnoop), .awdomain(awdomain), .awbar(2'b00),
                   .wvalid(wvalid), .wready(wready), .wdata(wdata), .wstrb(wstrb), .wlast(wlast),
                   .bvalid(bvalid), .bready(bready), .bresp(bresp), .wack(wack), .acvalid(acvalid),
                   .acready(acready), .acaddr(acaddr), .acsnoop(acsnoop), .acprot(acprot), .crvalid(crvalid),
                   .crready(crready), .crresp(crresp), .cdvalid(cdvalid), .cdready(cdready), .cddata(cddata),
                   .cdlast(cdlast));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // ---- reference: memory, non-shareable memory, the peer (0 I, 1 SC, 2 UD)
  logic [127:0] m_mem [16], m_ns [16], m_pd [16];
  logic [1:0]   m_peer [16];
  function automatic [127:0] inc_line(input [127:0] x);
    for (int w = 0; w < 4; w++) inc_line[w*32 +: 32] = x[w*32 +: 32] + 32'd1;
  endfunction

  // ---- snoop responder: no line is cached here unless dirty_mode, then
  // every snoop except MakeInvalid is answered with PassDirty data cd_val
  bit dirty_mode = 0;
  bit wb_busy = 0;      // a WriteBack is in progress: snoops are answered after it
  logic [127:0] cd_val = 0;
  int n_snoop [16];
  int ac_while_ack = 0;
  int bad_sel = 0;      // a snoop the peer would not start for its line state
  bit late = 0;
  int n_late = 0;
  initial forever begin
    logic [3:0] op_code, l;
    logic [4:0] r;
    @(negedge clk);
    if (acvalid) begin
      op_code = acsnoop; l = acaddr[7:4];
      acready = 1;
      @(negedge clk);
      acready = 0;
      while (wb_busy) @(negedge clk);
      n_snoop[op_code]++;
      if (late) n_late++;
      if (m_peer[l] == 2 && (op_code == 4'b0001 || op_code == 4'b0111 || op_code == 4'b1101)) bad_sel++;
      if (m_peer[l] == 1 && op_code == 4'b0001) bad_sel++;
      r = (dirty_mode && op_code != 4'b1101) ? 5'b00101 : 5'b00000;
      // the reference applies the snoop now: transactions the model accepts
      // from here on are answered after it
      case (op_code)
        4'b0000: if (r[2]) m_mem[l] = cd_val;
        4'b0001: begin if (r[2]) m_mem[l] = cd_val; if (m_peer[l] == 0) m_peer[l] = 1; end
        4'b0111: begin m_pd[l] = inc_line(r[0] ? cd_val : m_mem[l]); m_peer[l] = 2; end
        4'b1001: begin
                   if (r[2]) m_mem[l] = cd_val; else if (m_peer[l] == 2) m_mem[l] = m_pd[l];
                   m_peer[l] = 0;
                 end
        default: begin m_pd[l] = ~m_mem[l]; m_peer[l] = 2; end
      endcase
      crvalid = 1; crresp = r;
      @(posedge clk);
      while (!crready) @(posedge clk);
      @(negedge clk);
      crvalid = 0;
      if (r[0]) for (int b = 0; b < 4; b++) begin
        cdvalid = 1; cddata = cd_val[b*32 +: 32]; cdlast = (b == 3);
        @(posedge clk);
        while (!cdready) @(posedge clk);
        @(negedge clk);
      end
      cdvalid = 0; cdlast = 0;
    end
  end

  // read: cmd 0 ReadNoSnoop, 1 ReadOnce, 2 ReadShared, 3 ReadUnique, 4 CleanUnique
  int beats;
  task automatic rd(input int cmd, input logic [31:0] a, input int ack_delay,
                    output logic [127:0] q, output logic [3:0] r);
    int n;
    @(negedge clk);
    arvalid = 1; araddr = a;
    ardomain = (cmd == 0) ? 2'b00 : 2'b01;
    arsnoop = (cmd == 2) ? 4'b0001 : (cmd == 3) ? 4'b0111 : (cmd == 4) ? 4'b1011 : (cmd == 9) ? 4'b0101 : 4'b0000;
    n = 0;
    @(posedge clk);
    while (!arready && n < 100) begin @(posedge clk); n++; end
    @(negedge clk);
    arvalid = 0;
    q = 0; beats = 0; n = 0;
    forever begin
      @(posedge clk);
      if (rvalid && rready) begin
        q[beats[1:0]*32 +: 32] = rdata; r = rresp; beats++;
        if (rlast) break;
      end
      n++;
      if (n > 200) break;
    end
    @(negedge clk);
    repeat (ack_delay) begin @(negedge clk); if (acvalid) ac_while_ack++; end
    rack = 1;
    @(negedge clk);
    rack = 0;
  endtask

  // write: cmd 5 WriteNoSnoop, 6 WriteUnique, 7 WriteBack
  task automatic wr(input int cmd, input logic [31:0] a, input logic [127:0] d, input logic [15:0] st,
                    output logic [1:0] r);
    int n;
    @(negedge clk);
    awvalid = 1; awaddr = a;
    awdomain = (cmd == 5) ? 2'b00 : 2'b01;
    awsnoop = (cmd == 7) ? 3'b011 : (cmd == 9) ? 3'b110 : 3'b000;
    @(posedge clk);
    n = 0;
    while (!awready && n < 100) begin @(posedge clk); n++; end
    @(negedge clk);
    awvalid = 0;
    for (int b = 0; b < 4; b++) begin
      wvalid = 1; wdata = d[b*32 +: 32]; wstrb = st[b*4 +: 4]; wlast = (b == 3);
      @(posedge clk);
      while (!wready) @(posedge clk);
      @(negedge clk);
    end
    wvalid = 0; wlast = 0;
    @(posedge clk);
    while (!bvalid) @(posedge clk);
    r = bresp;
    @(negedge clk);
    wack = 1;
    @(negedge clk);
    wack = 0;
  endtask

  function automatic [127:0] merge(input [127:0] base, input [127:0] d, input [15:0] st);
    merge = base;
    for (int b = 0; b < 16; b++) if (st[b]) merge[b*8 +: 8] = d[b*8 +: 8];
  endfunction

  initial begin
    logic [127:0] q, e, d;
    logic [3:0] r, er;
    logic [1:0] br;
    int bad_d, bad_r, bad_n, n_ops;
    for (int i = 0; i < 16; i++) begin
      for (int w = 0; w < 4; w++) m_mem[i][w*32 +: 32] = {24'hC0FFEE, i[3:0], w[3:0]};
      m_ns[i] = 0; m_pd[i] = 0; m_peer[i] = 0; n_snoop[i] = 0;
    end
    repeat (3) @(posedge clk);
    chk(rvalid === 1'b0 && bvalid === 1'b0 && acvalid === 1'b0, "R / B / AC idle in reset");
    rst_n = 1;
    repeat (2) @(posedge clk);

    // non-shareable region: its own memory, not snooped
    rd(0, 32'h150, 0, q, r);
    chk(q === 0 && r === 4'b0000 && beats == 4, "ReadNoSnoop: four beats of 0");
    wr(5, 32'h150, 128'h4444_3333_2222_1111_0000_0000_0000_FFFF, 16'hF0F3, br);
    chk(br === 2'b00, "WriteNoSnoop: OKAY");
    rd(0, 32'h150, 0, q, r);
    chk(q === 128'h4444_3333_0000_0000_0000_0000_0000_FFFF, "WriteNoSnoop byte strobes merged");
    rd(1, 32'h050, 0, q, r);
    chk(q === ((m_peer[5] == 2) ? m_pd[5] : m_mem[5]), "ReadOnce of line 5 returns its current contents");

    // unsupported encodings answer SLVERR
    rd(9, 32'h010, 0, q, r);
    chk(r[1:0] === 2'b10 && q === 0, "unsupported ARSNOOP: SLVERR, no data");
    wr(9, 32'h010, '1, '1, br);
    chk(br === 2'b10, "unsupported AWSNOOP: SLVERR");

    // random coherent traffic against the reference, peer snoops in between
    bad_d = 0; bad_r = 0; bad_n = 0; n_ops = 0;
    for (int i = 0; i < 400; i++) begin
      int cmd, l;
      logic [31:0] x;
      x = $urandom;
      l = x[3:0];
      cmd = 1 + x[10:8] % 7;               // 1..7
      if (i == 150) begin dirty_mode = 1; cd_val = {4{32'hD1D1_0000 | i}}; end
      if (i == 200) dirty_mode = 0;
      if (i == 300) late = 1;
      if (cmd <= 4) begin
        rd(cmd, {l, 4'h0}, x[13:12], q, r);
        // the reference after any snoop the model ordered first
        case (cmd)
          1: begin e = (m_peer[l] == 2) ? m_pd[l] : m_mem[l]; er = {m_peer[l] != 0, 3'b000}; end
          2: if (m_peer[l] == 2) begin e = m_pd[l]; er = 4'b1100; m_peer[l] = 1; end
             else begin e = m_mem[l]; er = {m_peer[l] == 1, 3'b000}; end
          3: begin e = (m_peer[l] == 2) ? m_pd[l] : m_mem[l]; er = {1'b0, m_peer[l] == 2, 2'b00}; m_peer[l] = 0; end
          default: begin if (m_peer[l] == 2) m_mem[l] = m_pd[l]; m_peer[l] = 0; e = 0; er = 0; end
        endcase
        if (cmd != 4 && q !== e) begin bad_d++; if (bad_d < 4) $display("  op %0d line %0d: %h exp %h", cmd, l, q, e); end
        if (r !== er) begin bad_r++; if (bad_r < 4) $display("  op %0d line %0d: rresp %b exp %b", cmd, l, r, er); end
        if (beats != (cmd == 4 ? 1 : 4)) bad_n++;
      end else begin
        d = {$urandom, $urandom, $urandom, $urandom};
        if (cmd == 7) begin
          wb_busy = 1;
          wr(7, {l, 4'h0}, d, 16'hFFFF, br);
          m_mem[l] = d;
          wb_busy = 0;
        end else begin
          logic [15:0] st;
          st = {$urandom} | 16'h1;
          wr(6, {l, 4'h0}, d, st, br);
          m_mem[l] = merge((m_peer[l] == 2) ? m_pd[l] : m_mem[l], d, st);
          m_peer[l] = 0;
        end
        if (br !== 2'b00) bad_r++;
      end
      n_ops++;
    end
    chk(bad_d == 0, $sformatf("read data matches the reference (%0d of %0d wrong)", bad_d, n_ops));
    chk(bad_r == 0, $sformatf("RRESP IsShared / PassDirty and BRESP match the reference (%0d wrong)", bad_r));
    chk(bad_n == 0, "four R beats per read, one for CleanUnique");
    chk(n_snoop[0] > 0 && n_snoop[1] > 0 && n_snoop[7] > 0 && n_snoop[9] > 0 && n_snoop[13] > 0,
        $sformatf("snoops seen: ReadOnce %0d ReadShared %0d ReadUnique %0d CleanInvalid %0d MakeInvalid %0d",
                  n_snoop[0], n_snoop[1], n_snoop[7], n_snoop[9], n_snoop[13]));
    chk(ac_while_ack == 0, "no snoop while a RACK is owed");
    chk(n_late > 0, $sformatf("snoops still start late in the run (%0d in the last 100 transactions)", n_late));
    chk(bad_sel == 0, "the peer snoops only with commands its line state allows (no ReadShared / ReadUnique / MakeInvalid for a line it owns dirty, no ReadShared for one it shares)");

    // one transaction at a time: no AR while a write is in progress, no AW
    // while a read is (the requests are withdrawn again: test stimulus only)
    begin
      int acc;
      acc = 0;
      @(negedge clk);
      awvalid = 1; awaddr = 32'h0E0; awdomain = 2'b01; awsnoop = 3'b000;
      @(posedge clk);
      while (!awready) @(posedge clk);
      @(negedge clk);
      awvalid = 0;
      arvalid = 1; araddr = 32'h0F0; ardomain = 2'b01; arsnoop = 4'b0000;
      repeat (8) begin @(posedge clk); if (arready) acc++; @(negedge clk); end
      arvalid = 0;
      chk(acc == 0, "ARREADY low while a write waits for its data");
      for (int b = 0; b < 4; b++) begin
        wvalid = 1; wdata = 32'h0E0E_0000 + b; wstrb = 4'hF; wlast = (b == 3);
        @(posedge clk);
        while (!wready) @(posedge clk);
        @(negedge clk);
      end
      wvalid = 0; wlast = 0;
      m_mem[14] = merge((m_peer[14] == 2) ? m_pd[14] : m_mem[14], 128'h0E0E0003_0E0E0002_0E0E0001_0E0E0000, 16'hFFFF);
      m_peer[14] = 0;
      @(posedge clk);
      while (!bvalid) @(posedge clk);
      @(negedge clk);
      wack = 1; @(negedge clk); wack = 0;
      acc = 0;
      rready = 0;
      arvalid = 1; araddr = 32'h0E0; ardomain = 2'b01; arsnoop = 4'b0000;
      @(posedge clk);
      while (!arready) @(posedge clk);
      @(negedge clk);
      arvalid = 0;
      awvalid = 1; awaddr = 32'h0F0; awsnoop = 3'b000; awdomain = 2'b01;
      repeat (8) begin @(posedge clk); if (awready) acc++; @(negedge clk); end
      awvalid = 0;
      chk(acc == 0, "AWREADY low while a read waits for RREADY");
      rready = 1;
      q = 0; beats = 0;
      forever begin
        @(posedge clk);
        if (rvalid && rready) begin q[beats[1:0]*32 +: 32] = rdata; beats++; if (rlast) break; end
      end
      @(negedge clk);
      rack = 1; @(negedge clk); rack = 0;
      chk(q === ((m_peer[14] == 2) ? m_pd[14] : m_mem[14]), "the WriteUnique of line 14 read back");
    end
    chk(acprot === 3'b000, "ACPROT 0");

    // the final memory contents, line by line through ReadOnce
    begin
      int bad;
      bad = 0;
      repeat (40) @(negedge clk);
      for (int l = 0; l < 16; l++) begin
        rd(1, {l[3:0], 4'h0}, 0, q, r);
        if (q !== ((m_peer[l] == 2) ? m_pd[l] : m_mem[l])) bad++;
      end
      chk(bad == 0, $sformatf("all 16 lines match the reference at the end (%0d wrong)", bad));
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #3000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
