// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- ACE testbench top with a functional ACE DUT model

`ifndef ACE_UVM_VIP_TB_SV
`define ACE_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ace_defs_pkg::*;
import ace_pkg::*;
import ace_env_pkg::*;
import ace_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ace_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ace_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .arvalid(vif.arvalid),
    .arready(vif.arready),
    .araddr(vif.araddr),
    .arlen(vif.arlen),
    .arsize(vif.arsize),
    .arburst(vif.arburst),
    .arsnoop(vif.arsnoop),
    .ardomain(vif.ardomain),
    .arbar(vif.arbar),
    .rvalid(vif.rvalid),
    .rready(vif.rready),
    .rdata(vif.rdata),
    .rresp(vif.rresp),
    .rlast(vif.rlast),
    .rack(vif.rack),
    .awvalid(vif.awvalid),
    .awready(vif.awready),
    .awaddr(vif.awaddr),
    .awlen(vif.awlen),
    .awsize(vif.awsize),
    .awburst(vif.awburst),
    .awsnoop(vif.awsnoop),
    .awdomain(vif.awdomain),
    .awbar(vif.awbar),
    .wvalid(vif.wvalid),
    .wready(vif.wready),
    .wdata(vif.wdata),
    .wstrb(vif.wstrb),
    .wlast(vif.wlast),
    .bvalid(vif.bvalid),
    .bready(vif.bready),
    .bresp(vif.bresp),
    .wack(vif.wack),
    .acvalid(vif.acvalid),
    .acready(vif.acready),
    .acaddr(vif.acaddr),
    .acsnoop(vif.acsnoop),
    .acprot(vif.acprot),
    .crvalid(vif.crvalid),
    .crready(vif.crready),
    .crresp(vif.crresp),
    .cdvalid(vif.cdvalid),
    .cdready(vif.cdready),
    .cddata(vif.cddata),
    .cdlast(vif.cdlast)
  );

  // Concurrent protocol checks
  ace_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .arvalid(vif.arvalid),
    .arready(vif.arready),
    .araddr(vif.araddr),
    .arlen(vif.arlen),
    .arsize(vif.arsize),
    .arburst(vif.arburst),
    .arsnoop(vif.arsnoop),
    .ardomain(vif.ardomain),
    .arbar(vif.arbar),
    .rvalid(vif.rvalid),
    .rready(vif.rready),
    .rdata(vif.rdata),
    .rresp(vif.rresp),
    .rlast(vif.rlast),
    .rack(vif.rack),
    .awvalid(vif.awvalid),
    .awready(vif.awready),
    .awaddr(vif.awaddr),
    .awlen(vif.awlen),
    .awsize(vif.awsize),
    .awburst(vif.awburst),
    .awsnoop(vif.awsnoop),
    .awdomain(vif.awdomain),
    .awbar(vif.awbar),
    .wvalid(vif.wvalid),
    .wready(vif.wready),
    .wdata(vif.wdata),
    .wstrb(vif.wstrb),
    .wlast(vif.wlast),
    .bvalid(vif.bvalid),
    .bready(vif.bready),
    .bresp(vif.bresp),
    .wack(vif.wack),
    .acvalid(vif.acvalid),
    .acready(vif.acready),
    .acaddr(vif.acaddr),
    .acsnoop(vif.acsnoop),
    .acprot(vif.acprot),
    .crvalid(vif.crvalid),
    .crready(vif.crready),
    .crresp(vif.crresp),
    .cdvalid(vif.cdvalid),
    .cdready(vif.cdready),
    .cddata(vif.cddata),
    .cdlast(vif.cdlast)
  );

  initial begin
    uvm_config_db#(virtual ace_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ace_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        arvalid,
  output logic        arready,
  input  logic [31:0] araddr,
  input  logic [7:0]  arlen,
  input  logic [2:0]  arsize,
  input  logic [1:0]  arburst,
  input  logic [3:0]  arsnoop,
  input  logic [1:0]  ardomain,
  input  logic [1:0]  arbar,
  output logic        rvalid,
  input  logic        rready,
  output logic [31:0] rdata,
  output logic [3:0]  rresp,
  output logic        rlast,
  input  logic        rack,
  input  logic        awvalid,
  output logic        awready,
  input  logic [31:0] awaddr,
  input  logic [7:0]  awlen,
  input  logic [2:0]  awsize,
  input  logic [1:0]  awburst,
  input  logic [2:0]  awsnoop,
  input  logic [1:0]  awdomain,
  input  logic [1:0]  awbar,
  input  logic        wvalid,
  output logic        wready,
  input  logic [31:0] wdata,
  input  logic [3:0]  wstrb,
  input  logic        wlast,
  output logic        bvalid,
  input  logic        bready,
  output logic [1:0]  bresp,
  input  logic        wack,
  output logic        acvalid,
  input  logic        acready,
  output logic [31:0] acaddr,
  output logic [3:0]  acsnoop,
  output logic [2:0]  acprot,
  input  logic        crvalid,
  output logic        crready,
  input  logic [4:0]  crresp,
  input  logic        cdvalid,
  output logic        cdready,
  input  logic [31:0] cddata,
  input  logic        cdlast
);
  // commands (as in ace_defs_pkg)
  localparam [3:0] RNS = 4'd0, RO = 4'd1, RS = 4'd2, RU = 4'd3, CU = 4'd4, WNS = 4'd5, WU = 4'd6, WB = 4'd7,
                   SRO = 4'd8, SRS = 4'd9, SRU = 4'd10, SCI = 4'd11, SMI = 4'd12, BAD = 4'd15;
  localparam [1:0] P_I = 2'd0, P_SC = 2'd1, P_UD = 2'd2;

  logic [127:0] mem [0:15];
  logic [127:0] nsmem [0:15];
  logic [127:0] pdat [0:15];
  logic [1:0]   peer [0:15];
  logic [15:0]  lfsr;

  // master transaction: 0 idle, 1 read accepted, 2 read data, 3 write data, 4 write done, 5 B
  logic [2:0]   tx;
  logic [3:0]   t_cmd, t_line;
  logic [127:0] t_data, wbuf;
  logic [15:0]  wstb;
  logic [1:0]   t_beat;
  logic [3:0]   t_resp;
  logic [1:0]   t_bresp;
  logic [3:0]   acks;            // RLAST / B transfers not yet acknowledged
  // snoop: 0 idle, 1 AC, 2 waiting for CR / CD
  logic [1:0]   sn;
  logic [3:0]   s_op, s_line;
  logic         cr_got, cd_done;
  logic [4:0]   s_cr;
  logic [127:0] s_cd;
  logic [1:0]   s_cdb;
  logic [3:0]   rd_cmd, wr_cmd;

  always_comb begin
    if (ardomain == 2'b00 || ardomain == 2'b11) rd_cmd = (arsnoop == 4'b0000) ? RNS : BAD;
    else case (arsnoop)
      4'b0000: rd_cmd = RO;
      4'b0001: rd_cmd = RS;
      4'b0111: rd_cmd = RU;
      4'b1011: rd_cmd = CU;
      default: rd_cmd = BAD;
    endcase
    if (awdomain == 2'b00 || awdomain == 2'b11) wr_cmd = (awsnoop == 3'b000) ? WNS : BAD;
    else wr_cmd = (awsnoop == 3'b000) ? WU : (awsnoop == 3'b011) ? WB : BAD;
  end

  assign arready = (tx == 3'd0) && lfsr[0];
  assign awready = (tx == 3'd0) && !arvalid && lfsr[2];
  assign wready  = (tx == 3'd3) && lfsr[4];
  assign rvalid  = (tx == 3'd2);
  assign rdata   = t_data[t_beat*32 +: 32];
  assign rresp   = t_resp;
  assign rlast   = (tx == 3'd2) && (t_cmd == CU || t_beat == 2'd3);
  assign bvalid  = (tx == 3'd5);
  assign bresp   = t_bresp;
  assign acvalid = (sn == 2'd1);
  assign acaddr  = {24'h0, s_line, 4'h0};
  assign acsnoop = (s_op == SRS) ? 4'b0001 : (s_op == SRU) ? 4'b0111 : (s_op == SCI) ? 4'b1001 :
                   (s_op == SMI) ? 4'b1101 : 4'b0000;
  assign acprot  = 3'b000;
  assign crready = (sn == 2'd2) && !cr_got && lfsr[6];
  assign cdready = (sn == 2'd2) && !cd_done && lfsr[8];

  function automatic [127:0] merge(input [127:0] base, input [127:0] d, input [15:0] st);
    merge = base;
    for (int b = 0; b < 16; b++) if (st[b]) merge[b*8 +: 8] = d[b*8 +: 8];
  endfunction
  function automatic [127:0] inc_line(input [127:0] x);
    for (int w = 0; w < 4; w++) inc_line[w*32 +: 32] = x[w*32 +: 32] + 32'd1;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lfsr <= 16'hACE1;
      tx <= 3'd0; t_cmd <= '0; t_line <= '0; t_data <= '0; wbuf <= '0; wstb <= '0; t_beat <= '0;
      t_resp <= '0; t_bresp <= '0; acks <= '0;
      sn <= 2'd0; s_op <= '0; s_line <= '0; cr_got <= 1'b0; cd_done <= 1'b0; s_cr <= '0; s_cd <= '0; s_cdb <= '0;
      for (int i = 0; i < 16; i++) begin
        for (int w = 0; w < 4; w++) mem[i][w*32 +: 32] <= {24'hC0FFEE, i[3:0], w[3:0]};
        nsmem[i] <= '0; pdat[i] <= '0; peer[i] <= P_I;
      end
    end else begin
      logic [3:0] a_inc, a_dec;
      a_inc = 0; a_dec = 0;
      lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};

      // ---------------- master transactions ----------------
      if (arvalid && arready) begin tx <= 3'd1; t_cmd <= rd_cmd; t_line <= araddr[7:4]; t_beat <= 2'd0; end
      else if (awvalid && awready) begin tx <= 3'd3; t_cmd <= wr_cmd; t_line <= awaddr[7:4]; t_beat <= 2'd0; wstb <= '0; end
      case (tx)
        3'd1: if (sn == 2'd0) begin          // a snoop in progress goes first
          tx <= 3'd2;
          case (t_cmd)
            RNS: begin t_data <= nsmem[t_line]; t_resp <= 4'b0000; end
            RO:  begin t_data <= (peer[t_line] == P_UD) ? pdat[t_line] : mem[t_line];
                       t_resp <= {peer[t_line] != P_I, 3'b000}; end
            RS:  if (peer[t_line] == P_UD) begin t_data <= pdat[t_line]; t_resp <= 4'b1100; peer[t_line] <= P_SC; end
                 else begin t_data <= mem[t_line]; t_resp <= {peer[t_line] == P_SC, 3'b000}; end
            RU:  begin
                   if (peer[t_line] == P_UD) begin t_data <= pdat[t_line]; t_resp <= 4'b0100; end
                   else begin t_data <= mem[t_line]; t_resp <= 4'b0000; end
                   peer[t_line] <= P_I;
                 end
            CU:  begin
                   if (peer[t_line] == P_UD) mem[t_line] <= pdat[t_line];
                   peer[t_line] <= P_I; t_data <= '0; t_resp <= 4'b0000;
                 end
            default: begin t_data <= '0; t_resp <= 4'b0010; end   // SLVERR
          endcase
        end
        3'd2: if (rready) begin
          if (rlast) begin tx <= 3'd0; a_inc = a_inc + 1; end
          else t_beat <= t_beat + 2'd1;
        end
        3'd3: if (wvalid && wready) begin
          wbuf[t_beat*32 +: 32] <= wdata; wstb[t_beat*4 +: 4] <= wstrb; t_beat <= t_beat + 2'd1;
          if (wlast) tx <= 3'd4;
        end
        3'd4: if (t_cmd == WB || sn == 2'd0) begin   // a WriteBack does not wait for a snoop
          tx <= 3'd5; t_bresp <= 2'b00;
          case (t_cmd)
            WNS: nsmem[t_line] <= merge(nsmem[t_line], wbuf, wstb);
            WU:  begin mem[t_line] <= merge((peer[t_line] == P_UD) ? pdat[t_line] : mem[t_line], wbuf, wstb);
                       peer[t_line] <= P_I; end
            WB:  mem[t_line] <= merge(mem[t_line], wbuf, wstb);
            default: t_bresp <= 2'b10;
          endcase
        end
        3'd5: if (bready) begin tx <= 3'd0; a_inc = a_inc + 1; end
        default: ;
      endcase
      if (rack) a_dec = a_dec + 1;
      if (wack) a_dec = a_dec + 1;
      acks <= acks + a_inc - a_dec;

      // ---------------- snoops from the peer ----------------
      case (sn)
        2'd0: if (tx == 3'd0 && acks == 4'd0 && lfsr[7:4] == 4'h0) begin
          logic [3:0] o, l;
          l = lfsr[11:8];
          case (lfsr[14:12])
            3'd0, 3'd7: o = SRO;
            3'd1, 3'd5: o = SRS;
            3'd2, 3'd6: o = SRU;
            3'd3:       o = SCI;
            default:    o = SMI;
          endcase
          if (peer[l] == P_UD && (o == SRS || o == SRU || o == SMI)) o = SCI;   // it already owns the line
          if (peer[l] == P_SC && o == SRS) o = SRO;
          sn <= 2'd1; s_op <= o; s_line <= l;
        end
        2'd1: if (acready) begin sn <= 2'd2; cr_got <= 1'b0; cd_done <= 1'b0; s_cdb <= 2'd0; end
        2'd2: begin
          if (crvalid && crready) begin cr_got <= 1'b1; s_cr <= crresp; end
          if (cdvalid && cdready) begin
            s_cd[s_cdb*32 +: 32] <= cddata; s_cdb <= s_cdb + 2'd1;
            if (cdlast) cd_done <= 1'b1;
          end
          if (cr_got && (!s_cr[0] || cd_done)) begin
            sn <= 2'd0;
            case (s_op)
              SRO: if (s_cr[2]) mem[s_line] <= s_cd;
              SRS: begin
                     if (s_cr[2]) mem[s_line] <= s_cd;
                     if (peer[s_line] == P_I) peer[s_line] <= P_SC;
                   end
              SRU: begin pdat[s_line] <= inc_line(s_cr[0] ? s_cd : mem[s_line]); peer[s_line] <= P_UD; end
              SCI: begin
                     if (s_cr[2]) mem[s_line] <= s_cd;
                     else if (peer[s_line] == P_UD) mem[s_line] <= pdat[s_line];
                     peer[s_line] <= P_I;
                   end
              default: begin pdat[s_line] <= ~mem[s_line]; peer[s_line] <= P_UD; end   // MakeInvalid
            endcase
          end
        end
        default: sn <= 2'd0;
      endcase
    end
  end
endmodule
`endif
