// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ace_env.sv -- ACE environment: reference-model scoreboard, checker, coverage

package ace_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import ace_defs_pkg::*;
  import ace_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class ace_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(ace_scoreboard)
    uvm_analysis_imp_exp #(ace_transaction, ace_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(ace_transaction, ace_scoreboard) obs_ap;

    ace_config cfg;
    ace_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [127:0] mem [16], nsmem [16], pdat [16];
    bit [1:0]   peer [16];   // 0 I, 1 SC, 2 UD
    bit         init_done = 0;
    function bit [127:0] merge(bit [127:0] base, bit [127:0] d, bit [15:0] st);
      for (int b = 0; b < 16; b++) if (st[b]) base[b*8 +: 8] = d[b*8 +: 8];
      return base;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(ace_config)::get(this, "", "cfg", cfg))
        cfg = ace_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(ace_transaction t);
      bit [3:0] l;
      if (!init_done) begin
        for (int i = 0; i < 16; i++) begin mem[i] = ace_init_line(i); nsmem[i] = 0; pdat[i] = 0; peer[i] = 0; end
        init_done = 1;
      end
      l = t.addr[7:4];
      case (t.cmd)
        C_RD_NOSNOOP: begin t.rline = nsmem[l]; t.rresp = 4'b0000; end
        C_RD_ONCE:    begin t.rline = peer[l] == 2 ? pdat[l] : mem[l]; t.rresp = {peer[l] != 0, 3'b000}; end
        C_RD_SHARED:  begin
          if (peer[l] == 2) begin t.rline = pdat[l]; t.rresp = 4'b1100; peer[l] = 1; end
          else begin t.rline = mem[l]; t.rresp = {peer[l] == 1, 3'b000}; end
        end
        C_RD_UNIQUE:  begin
          if (peer[l] == 2) begin t.rline = pdat[l]; t.rresp = 4'b0100; end
          else begin t.rline = mem[l]; t.rresp = 4'b0000; end
          peer[l] = 0;
        end
        C_CLEAN_UNIQUE: begin
          if (peer[l] == 2) mem[l] = pdat[l];
          peer[l] = 0; t.rline = 0; t.rresp = 4'b0000;
        end
        C_WR_NOSNOOP, C_WR_UNIQUE: begin
          bit [127:0] d = 0; bit [15:0] st = 0;
          d[t.word*32 +: 32] = t.wdata; st[t.word*4 +: 4] = t.wstrb;
          if (t.cmd == C_WR_NOSNOOP) nsmem[l] = merge(nsmem[l], d, st);
          else begin
            mem[l] = merge(peer[l] == 2 ? pdat[l] : mem[l], d, st);
            peer[l] = 0;
          end
          t.bresp = 2'b00;
        end
        C_WR_BACK: begin mem[l] = t.wline; t.bresp = 2'b00; end
        // snoops: the response came from the agent; apply it as the peer's transaction
        C_SN_RD_ONCE, C_SN_RD_SHARED, C_SN_CLEAN_INV: begin
          if (t.crresp[2]) mem[l] = t.cdline;
          if (t.cmd == C_SN_RD_SHARED && peer[l] == 0) peer[l] = 1;
          if (t.cmd == C_SN_CLEAN_INV) begin
            if (!t.crresp[2] && peer[l] == 2) mem[l] = pdat[l];
            peer[l] = 0;
          end
        end
        C_SN_RD_UNIQUE: begin pdat[l] = ace_inc_line(t.crresp[0] ? t.cdline : mem[l]); peer[l] = 2; end
        C_SN_MAKE_INV:  begin pdat[l] = ~mem[l]; peer[l] = 2; end
        default: ;
      endcase
    endfunction

    function void write_exp(ace_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(ace_transaction t);
      ace_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active && !(t.cmd >= C_SN_RD_ONCE && t.cmd <= C_SN_MAKE_INV)) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        ace_transaction e = exp_q.pop_front();
        ace_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("ace scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class ace_env extends uvm_env;
    `uvm_component_utils(ace_env)
    ace_agent      agt;
    ace_scoreboard sb;
    ace_checker    chk;
    ace_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = ace_agent     ::type_id::create("agt", this);
      sb  = ace_scoreboard::type_id::create("sb",  this);
      chk = ace_checker   ::type_id::create("chk", this);
      cov = ace_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
