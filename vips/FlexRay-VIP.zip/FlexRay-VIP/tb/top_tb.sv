// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- FlexRay testbench top with a functional FlexRay node DUT

`ifndef FLEXRAY_TB_SV
`define FLEXRAY_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import flexray_pkg::*;
import flexray_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  logic rst_n;
  flexray_if vif(clk, rst_n);

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  // Functional FlexRay node: receives VIP frames, verifies CRCs, echoes
  flexray_node_model dut (
    .clk               (vif.clk),
    .rst_n             (vif.rst_n),
    .rxd_a             (vif.rxd_a),
    .rxd_b             (vif.rxd_b),
    .bgd_a             (vif.bgd_a),
    .bgd_b             (vif.bgd_b),
    .txd_a             (vif.txd_a),
    .txd_b             (vif.txd_b),
    .txen_a            (vif.txen_a),
    .txen_b            (vif.txen_b),
    .header_crc        (vif.header_crc),
    .frame_id          (vif.frame_id),
    .payload_length    (vif.payload_length),
    .header_crc_init   (vif.header_crc_init),
    .cycle_count       (vif.cycle_count),
    .channel           (vif.channel),
    .static_segment    (vif.static_segment),
    .dynamic_segment   (vif.dynamic_segment),
    .symbol_window     (vif.symbol_window),
    .network_idle      (vif.network_idle),
    .macrotick         (vif.macrotick),
    .slot              (vif.slot),
    .cycle             (vif.cycle),
    .coldstart         (vif.coldstart),
    .sync_frame        (vif.sync_frame),
    .startup_frame     (vif.startup_frame),
    .single_slot       (vif.single_slot),
    .wakeup_mode       (vif.wakeup_mode),
    .wakeup_pattern    (vif.wakeup_pattern),
    .syntax_error      (vif.syntax_error),
    .content_error     (vif.content_error),
    .boundary_violation(vif.boundary_violation),
    .tx_conflict       (vif.tx_conflict)
  );

  // SVA tiered compliance checker (L1-L4)
  flexray_compliance_sva sva_chk (vif);

  // L1/L2/L3 SVA rule modules (companions of the class checkers)
  flexray_protocol_compliance_sva protocol_sva (vif);
  flexray_data_integrity_sva      di_sva       (vif);
  flexray_timing_performance_sva  timing_sva   (vif);
  flexray_error_handling_sva      error_sva    (vif);

  initial begin
    uvm_config_db#(virtual flexray_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule
`endif
