// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_node_model.sv -- functional FlexRay node DUT (pure RTL, no UVM).
// Receives frames on rxd_a (8 clks per bit): TSS (2..5 dominant bits),
// FSS, then the FlexRay 2.1 frame MSB first without byte start sequences:
//   [0] reserved, [1] payload preamble, [2] null frame, [3] sync,
//   [4] startup, [5:15] frame ID, [16:22] payload length (2-byte words),
//   [23:33] header CRC-11 (0x385, init 0x01A, over bits 3..22),
//   [34:39] cycle count, payload (capped at MAX_WORDS words), frame
//   CRC-24 (0x5D6DCB, init 0xFEDCBA, over header and payload), FES (0, 1).
// A header or frame CRC mismatch sets content_error. The frame is echoed
// on txd_a/txd_b as 000 1 + the captured bits; a 6-bit dominant TSS is
// answered with a dominant error marker. Free-running slot/cycle counters
// model the TDMA schedule.

`ifndef FLEXRAY_NODE_MODEL_SV
`define FLEXRAY_NODE_MODEL_SV

module flexray_node_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rxd_a,
  input  logic        rxd_b,
  input  logic        bgd_a,
  input  logic        bgd_b,
  output logic        txd_a,
  output logic        txd_b,
  output logic        txen_a,
  output logic        txen_b,
  output logic [4:0]  header_crc,
  output logic [10:0] frame_id,
  output logic [15:0] payload_length,
  output logic [6:0]  header_crc_init,
  output logic [23:0] cycle_count,
  output logic [1:0]  channel,
  output logic        static_segment,
  output logic        dynamic_segment,
  output logic        symbol_window,
  output logic        network_idle,
  output logic [15:0] macrotick,
  output logic [11:0] slot,
  output logic [3:0]  cycle,
  output logic        coldstart,
  output logic        sync_frame,
  output logic        startup_frame,
  output logic        single_slot,
  output logic        wakeup_mode,
  output logic [7:0]  wakeup_pattern,
  output logic        syntax_error,
  output logic        content_error,
  output logic        boundary_violation,
  output logic        tx_conflict
);
  localparam int BIT_CLKS = 8;
  localparam int MAX_BITS = 200;
  localparam int MAX_WORDS = 4;    // payload words captured (8 bytes)
  localparam int HDR_BITS = 40;

  typedef enum logic [2:0] {S_IDLE, S_TSS, S_CAP, S_EVAL, S_TX, S_ERR} state_e;
  state_e state;

  int   dom_cnt;
  int   sclk;
  int   rcnt;
  logic [MAX_BITS-1:0] shift;      // captured bits after TSS+BSS
  int   need;                      // total bits to capture for this frame
  int   plen;

  logic [255:0] tx_shift;
  int   tx_len, tx_idx, tx_clk;
  int   err_cnt;
  int   tick_cnt;

  // header CRC: sync, startup, frame ID, payload length (captured bits 3..22)
  function automatic logic [10:0] crc11();
    logic [10:0] c;
    logic nxt;
    c = 11'h01A;
    for (int i = 3; i <= 22; i++) begin
      nxt = shift[MAX_BITS-1-i] ^ c[10];
      c = {c[9:0], 1'b0};
      if (nxt) c = c ^ 11'h385;
    end
    return c;
  endfunction

  // frame CRC (channel A): captured bits 0 .. n-1 (header and payload)
  function automatic logic [23:0] crc24(input int n);
    logic [23:0] c;
    logic nxt;
    c = 24'hFEDCBA;
    for (int i = 0; i < n; i++) begin
      nxt = shift[MAX_BITS-1-i] ^ c[23];
      c = {c[22:0], 1'b0};
      if (nxt) c = c ^ 24'h5D6DCB;
    end
    return c;
  endfunction

  initial begin
    txd_a = 1'b1; txd_b = 1'b1; txen_a = 0; txen_b = 0;
    frame_id = '0; payload_length = '0; header_crc = '0; header_crc_init = 7'h20;
    cycle_count = '0; channel = 2'd0;
    static_segment = 0; dynamic_segment = 0; symbol_window = 0; network_idle = 1;
    macrotick = '0; slot = '0; cycle = '0;
    coldstart = 0; sync_frame = 0; startup_frame = 0; single_slot = 0;
    wakeup_mode = 0; wakeup_pattern = '0;
    syntax_error = 0; content_error = 0;
    boundary_violation = 0; tx_conflict = 0;
    state = S_IDLE; dom_cnt = 0; sclk = 0; rcnt = 0; need = 0; plen = 0;
    tx_len = 0; tx_idx = 0; tx_clk = 0; err_cnt = 0; tick_cnt = 0;
  end

  // The node receives on both channels: a frame sent on A, B or both
  // reaches it (a dominant bit on either channel is dominant)
  wire rx = rxd_a & rxd_b;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; txd_a <= 1'b1; txd_b <= 1'b1; txen_a <= 0; txen_b <= 0;
      syntax_error <= 0; content_error <= 0; static_segment <= 0; network_idle <= 1;
      sync_frame <= 0; startup_frame <= 0;
      slot <= '0; cycle <= '0; macrotick <= '0; tick_cnt <= 0;
    end else begin
      // TDMA schedule model (free running)
      macrotick <= macrotick + 1;
      tick_cnt <= tick_cnt + 1;
      // 16 slots of 64 macroticks per communication cycle; the slot
      // counter restarts with each cycle
      if (tick_cnt % 1024 == 1023) begin
        cycle <= cycle + 1;
        slot  <= '0;
      end else if (tick_cnt % 64 == 63) slot <= slot + 1;

      case (state)
        S_IDLE: begin
          if (rx === 1'b0) begin
            dom_cnt <= 1;
            sclk <= BIT_CLKS - 2;
            state <= S_TSS;
          end
        end
        S_TSS: begin
          if (sclk > 0) sclk <= sclk - 1;
          else begin
            sclk <= BIT_CLKS - 1;
            if (rx === 1'b0) begin
              dom_cnt <= dom_cnt + 1;
              if (dom_cnt >= 6) begin          // error marker / garbage
                state <= S_ERR;
                err_cnt <= 6 * BIT_CLKS;
              end
            end else begin
              if (dom_cnt >= 3) begin          // TSS (>= 2 bits) + FSS
                rcnt <= 0;
                need <= HDR_BITS;              // extended once the length is known
                shift <= '0;
                state <= S_CAP;
              end else begin
                state <= S_IDLE;               // glitch
              end
            end
          end
        end
        S_CAP: begin
          if (sclk > 0) sclk <= sclk - 1;
          else begin
            sclk <= BIT_CLKS - 1;
            shift[MAX_BITS-1-rcnt] <= rx;
            rcnt <= rcnt + 1;
            if (rcnt == 23) begin
              // payload length (bits 16..22) is complete
              plen = 0;
              for (int i = 16; i <= 22; i++)
                plen = (plen << 1) | shift[MAX_BITS-1-i];
              if (plen > MAX_WORDS) plen = MAX_WORDS;
              need <= HDR_BITS + plen*16 + 24 + 2;
            end
            if (rcnt >= HDR_BITS && rcnt + 1 >= need) state <= S_EVAL;
          end
        end
        S_EVAL: begin
          logic [10:0] hc_rx;
          logic [23:0] fc_rx;
          int nb;
          nb = rcnt - 2 - 24;                  // header + payload bits
          for (int i = 0; i < 11; i++) begin
            frame_id[10-i] <= shift[MAX_BITS-1-5-i];
            hc_rx[10-i] = shift[MAX_BITS-1-23-i];
          end
          for (int i = 0; i < 24; i++) fc_rx[23-i] = shift[MAX_BITS-1-nb-i];
          header_crc <= hc_rx[4:0];
          content_error <= (crc11() != hc_rx) || (crc24(nb) != fc_rx);
          sync_frame <= shift[MAX_BITS-1-3];
          startup_frame <= shift[MAX_BITS-1-4];
          coldstart <= shift[MAX_BITS-1-4];    // a startup frame comes from a coldstart node
          static_segment <= 1;
          network_idle <= 0;
          payload_length <= '0;
          for (int i = 0; i < 7; i++) payload_length[6-i] <= shift[MAX_BITS-1-16-i];
          cycle_count <= '0;
          for (int i = 0; i < 6; i++) cycle_count[5-i] <= shift[MAX_BITS-1-34-i];

          // echo: TSS + FSS + captured bits
          tx_shift = '0;
          tx_len = 3 + 1 + rcnt;
          tx_shift[255 -: 3] = 3'b000;
          tx_shift[252] = 1'b1;
          for (int i = 0; i < rcnt; i++) tx_shift[251-i] = shift[MAX_BITS-1-i];
          tx_idx <= 0; tx_clk <= 0;
          txen_a <= 1;
          state <= S_TX;
        end
        S_TX: begin
          if (tx_clk == 0) begin
            txd_a <= tx_shift[255-tx_idx];
            txd_b <= tx_shift[255-tx_idx];
          end
          if (tx_clk == BIT_CLKS-1) begin
            tx_clk <= 0;
            if (tx_idx >= tx_len-1) begin
              txd_a <= 1'b1; txd_b <= 1'b1;
              txen_a <= 0; txen_b <= 0;
              static_segment <= 0;
              network_idle <= 1;
              state <= S_IDLE;
            end else tx_idx <= tx_idx + 1;
          end else tx_clk <= tx_clk + 1;
        end
        S_ERR: begin
          if (err_cnt > 0) begin
            txen_a <= 1'b1;                // the marker is a transmission
            txd_a <= 1'b0;                 // dominant error marker
            err_cnt <= err_cnt - 1;
            syntax_error <= 1;
          end else begin
            txd_a <= 1'b1;
            txen_a <= 1'b0;
            syntax_error <= 0;
            state <= S_IDLE;
          end
        end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule
`endif
