// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_node_model.sv -- functional FlexRay node DUT (pure RTL, no UVM).
// Receives frames on rxd_a (TSS / BSS / header / payload / CRCs / FES,
// 8 clks per bit), verifies header CRC-11 and payload CRC-24, echoes the
// frame on txd_a; emits a 6-bit dominant error marker on undecodable
// input. Free-running slot/cycle counters model the TDMA schedule.

`ifndef FLEXRAY_NODE_MODEL_SV
`define FLEXRAY_NODE_MODEL_SV

module flexray_node_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rxd_a,
  input  logic        rxd_b,
  input  logic        bgd_a,
  input  logic        bgd_b,
  output logic        txd_a,
  output logic        txd_b,
  output logic        txen_a,
  output logic        txen_b,
  output logic [4:0]  header_crc,
  output logic [10:0] frame_id,
  output logic [15:0] payload_length,
  output logic [6:0]  header_crc_init,
  output logic [23:0] cycle_count,
  output logic [1:0]  channel,
  output logic        static_segment,
  output logic        dynamic_segment,
  output logic        symbol_window,
  output logic        network_idle,
  output logic [15:0] macrotick,
  output logic [11:0] slot,
  output logic [3:0]  cycle,
  output logic        coldstart,
  output logic        sync_frame,
  output logic        startup_frame,
  output logic        single_slot,
  output logic        wakeup_mode,
  output logic [7:0]  wakeup_pattern,
  output logic        syntax_error,
  output logic        content_error,
  output logic        boundary_violation,
  output logic        tx_conflict
);
  localparam int BIT_CLKS = 8;
  localparam int MAX_BITS = 200;

  typedef enum logic [2:0] {S_IDLE, S_TSS, S_CAP, S_EVAL, S_TX, S_ERR} state_e;
  state_e state;

  int   dom_cnt;
  int   sclk;
  int   rcnt;
  logic [MAX_BITS-1:0] shift;      // captured bits after TSS+BSS
  int   need;                      // total bits to capture for this frame
  int   plen;

  logic [255:0] tx_shift;
  int   tx_len, tx_idx, tx_clk;
  int   err_cnt;
  int   tick_cnt;

  function automatic logic [10:0] crc11(input logic [24:0] d);
    logic [10:0] c;
    logic nxt;
    c = 11'h1A0;
    for (int i = 24; i >= 0; i--) begin
      nxt = d[i] ^ c[10];
      c = {c[9:0], 1'b0};
      if (nxt) c = c ^ 11'h385;
    end
    return c;
  endfunction

  initial begin
    txd_a = 1'b1; txd_b = 1'b1; txen_a = 0; txen_b = 0;
    frame_id = '0; payload_length = '0; header_crc = '0; header_crc_init = 7'h20;
    cycle_count = '0; channel = 2'd0;
    static_segment = 0; dynamic_segment = 0; symbol_window = 0; network_idle = 1;
    macrotick = '0; slot = '0; cycle = '0;
    coldstart = 0; sync_frame = 0; startup_frame = 0; single_slot = 0;
    wakeup_mode = 0; wakeup_pattern = '0;
    syntax_error = 0; content_error = 0;
    boundary_violation = 0; tx_conflict = 0;
    state = S_IDLE; dom_cnt = 0; sclk = 0; rcnt = 0; need = 0; plen = 0;
    tx_len = 0; tx_idx = 0; tx_clk = 0; err_cnt = 0; tick_cnt = 0;
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; txd_a <= 1'b1; txd_b <= 1'b1; txen_a <= 0; txen_b <= 0;
      syntax_error <= 0; content_error <= 0; static_segment <= 0; network_idle <= 1;
      slot <= '0; cycle <= '0; macrotick <= '0; tick_cnt <= 0;
    end else begin
      // TDMA schedule model (free running)
      macrotick <= macrotick + 1;
      tick_cnt <= tick_cnt + 1;
      if (tick_cnt % 64 == 63) slot <= slot + 1;
      if (tick_cnt % 1024 == 1023) cycle <= cycle + 1;

      case (state)
        S_IDLE: begin
          if (rxd_a === 1'b0) begin
            dom_cnt <= 1;
            sclk <= BIT_CLKS - 2;
            state <= S_TSS;
          end
        end
        S_TSS: begin
          if (sclk > 0) sclk <= sclk - 1;
          else begin
            sclk <= BIT_CLKS - 1;
            if (rxd_a === 1'b0) begin
              dom_cnt <= dom_cnt + 1;
              if (dom_cnt >= 6) begin          // error marker / garbage
                state <= S_ERR;
                err_cnt <= 6 * BIT_CLKS;
              end
            end else begin
              if (dom_cnt >= 3) begin          // TSS + BSS
                rcnt <= 0;
                need <= 25 + 11;               // header + hcrc (extended later)
                shift <= '0;
                state <= S_CAP;
              end else begin
                state <= S_IDLE;               // glitch
              end
            end
          end
        end
        S_CAP: begin
          if (sclk > 0) sclk <= sclk - 1;
          else begin
            sclk <= BIT_CLKS - 1;
            shift[MAX_BITS-1-rcnt] <= rxd_a;
            rcnt <= rcnt + 1;
            if (rcnt == 17) begin
              // payload length now known (bits 11..17)
              plen = 0;
              for (int i = 0; i < 7; i++)
                plen = (plen << 1) | shift[MAX_BITS-1-11-i];
              if (plen > 8) plen = 8;
              need <= 25 + 11 + plen*8 + 24 + 2;
            end
            if (rcnt > 36 && rcnt + 1 >= need) state <= S_EVAL;
          end
        end
        S_EVAL: begin
          logic [24:0] h;
          logic [10:0] hc, hc_rx;
          for (int i = 0; i < 25; i++) h[24-i] = shift[MAX_BITS-1-i];
          for (int i = 0; i < 11; i++) begin
            frame_id[10-i] <= shift[MAX_BITS-1-i];
            hc_rx[i] = shift[MAX_BITS-1-25-(10-i)];
          end
          hc = crc11(h);
          header_crc <= hc_rx[4:0];
          content_error <= (hc != hc_rx);
          static_segment <= 1;
          network_idle <= 0;
          payload_length <= '0;
          for (int i = 0; i < 7; i++) payload_length[6-i] <= shift[MAX_BITS-1-11-i];
          cycle_count <= '0;
          for (int i = 0; i < 6; i++) cycle_count[5-i] <= shift[MAX_BITS-1-18-i];

          // echo: TSS + BSS + captured bits
          tx_shift <= '0;
          tx_len = 3 + 1 + rcnt;
          tx_shift[255 -: 3] = 3'b000;
          tx_shift[252] = 1'b1;
          for (int i = 0; i < rcnt; i++) tx_shift[251-i] = shift[MAX_BITS-1-i];
          tx_idx <= 0; tx_clk <= 0;
          txen_a <= 1;
          state <= S_TX;
        end
        S_TX: begin
          if (tx_clk == 0) begin
            txd_a <= tx_shift[255-tx_idx];
            txd_b <= tx_shift[255-tx_idx];
          end
          if (tx_clk == BIT_CLKS-1) begin
            tx_clk <= 0;
            if (tx_idx >= tx_len-1) begin
              txd_a <= 1'b1; txd_b <= 1'b1;
              txen_a <= 0; txen_b <= 0;
              static_segment <= 0;
              network_idle <= 1;
              state <= S_IDLE;
            end else tx_idx <= tx_idx + 1;
          end else tx_clk <= tx_clk + 1;
        end
        S_ERR: begin
          if (err_cnt > 0) begin
            txd_a <= 1'b0;                 // dominant error marker
            err_cnt <= err_cnt - 1;
            syntax_error <= 1;
          end else begin
            txd_a <= 1'b1;
            syntax_error <= 0;
            state <= S_IDLE;
          end
        end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule
`endif
