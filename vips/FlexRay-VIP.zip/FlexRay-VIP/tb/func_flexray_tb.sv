// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_flexray_tb.sv -- self-checking functional test for the FlexRay node
// model (flexray_node_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py FlexRay-VIP
//
// Model contract (from tb/flexray_node_model.sv), 8 clocks per bit on rxd_a:
//   a dominant TSS (2..5 bits; a 6th dominant bit is a syntax error that
//   drives txd_a low for 48 clocks) followed by one recessive bit starts
//   capture of a simplified frame, MSB first, without byte start sequences:
//     [0:10] frame ID, [11:17] payload length (bytes, capped at 8),
//     [18:23] cycle count, [24] reserved, [25:35] header CRC,
//     payload, 24-bit frame CRC, 2-bit FES.
//   The header CRC is CRC-11 (poly 0x385, init 0x1A0) over bits [0:24];
//   a mismatch sets content_error. The node then echoes 000 1 + the frame on
//   txd_a/txd_b with txen_a high. macrotick counts clocks; slot advances
//   every 64 and cycle every 1024 clocks.
//
// The model departs from FlexRay 2.1 framing (no indicator bits / BSS,
// payload length in bytes, header CRC init and coverage); one check encodes
// a spec header to record this, as XFAIL.

module func_flexray_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int BC = 8;
  int checks = 0, fails = 0, xfails = 0;

  logic clk = 1'b0, rst_n = 1'b0, rxd_a = 1'b1, rxd_b = 1'b1;
  wire  txd_a, txd_b, txen_a, txen_b;
  wire  [4:0]  header_crc;
  wire  [10:0] frame_id;
  wire  [15:0] payload_length;
  wire  [6:0]  header_crc_init;
  wire  [23:0] cycle_count;
  wire  [1:0]  channel;
  wire  static_segment, dynamic_segment, symbol_window, network_idle;
  wire  [15:0] macrotick;
  wire  [11:0] slot;
  wire  [3:0]  cycle;
  wire  coldstart, sync_frame, startup_frame, single_slot, wakeup_mode;
  wire  [7:0]  wakeup_pattern;
  wire  syntax_error, content_error, boundary_violation, tx_conflict;

  always #5 clk = ~clk;

  flexray_node_model u_dut (
    .clk(clk), .rst_n(rst_n), .rxd_a(rxd_a), .rxd_b(rxd_b), .bgd_a(1'b1), .bgd_b(1'b1),
    .txd_a(txd_a), .txd_b(txd_b), .txen_a(txen_a), .txen_b(txen_b),
    .header_crc(header_crc), .frame_id(frame_id), .payload_length(payload_length),
    .header_crc_init(header_crc_init), .cycle_count(cycle_count), .channel(channel),
    .static_segment(static_segment), .dynamic_segment(dynamic_segment),
    .symbol_window(symbol_window), .network_idle(network_idle), .macrotick(macrotick),
    .slot(slot), .cycle(cycle), .coldstart(coldstart), .sync_frame(sync_frame),
    .startup_frame(startup_frame), .single_slot(single_slot), .wakeup_mode(wakeup_mode),
    .wakeup_pattern(wakeup_pattern), .syntax_error(syntax_error),
    .content_error(content_error), .boundary_violation(boundary_violation),
    .tx_conflict(tx_conflict)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // CRC-11, poly 0x385, MSB first, over n bits of d (left-aligned at d[n-1])
  function automatic logic [10:0] crc11(input logic [31:0] d, input int n, input logic [10:0] init);
    logic [10:0] c;
    logic nxt;
    c = init;
    for (int i = n - 1; i >= 0; i--) begin
      nxt = d[i] ^ c[10];
      c = {c[9:0], 1'b0};
      if (nxt) c = c ^ 11'h385;
    end
    return c;
  endfunction

  // frame bits (index 0 first on the wire)
  logic fb [0:511];
  int   flen;
  task automatic put(input logic [63:0] v, input int n);
    for (int i = n - 1; i >= 0; i--) begin fb[flen] = v[i]; flen++; end
  endtask

  // build a model-format frame; hdr_crc_xor corrupts the header CRC
  task automatic build(input [10:0] fid, input [6:0] plen, input [5:0] cyc,
                       input [10:0] hdr_crc_xor = '0, input int tss = 3);
    logic [24:0] h;
    flen = 0;
    for (int i = 0; i < tss; i++) put(0, 1);
    put(1, 1);                               // FSS
    h = {fid, plen, cyc, 1'b0};
    put(h, 25);
    put(crc11(h, 25, 11'h1A0) ^ hdr_crc_xor, 11);
    for (int i = 0; i < plen && i < 8; i++) put(8'hA0 + i, 8);
    put(24'hC0FFEE, 24);
    put(2'b01, 2);                           // FES
  endtask

  task automatic drive();
    for (int i = 0; i < flen; i++) begin
      rxd_a = fb[i];
      repeat (BC) @(negedge clk);
    end
    rxd_a = 1'b1;
  endtask

  // echo capture: txd_a sampled mid-bit while txen_a is high
  logic eb [0:511];
  int   elen, en_clks, txb_diff;
  always @(posedge clk) begin
    if (txen_a) begin
      if (en_clks % BC == BC / 2) begin eb[elen] = txd_a; elen++; end
      en_clks++;
      if (txd_b !== txd_a) txb_diff++;
    end
  end

  task automatic wait_echo();
    int k;
    k = 0;
    while (!txen_a && k < 1200) begin @(negedge clk); k++; end
    while (txen_a && k < 4000) begin @(negedge clk); k++; end
  endtask

  // echo length: 000 1 + the captured frame (everything after TSS+FSS)
  function automatic bit echo_len_ok(input int tss);
    return elen == 4 + flen - tss - 1;
  endfunction
  function automatic bit echo_ok(input int tss);
    if (!echo_len_ok(tss)) return 0;
    if (eb[0] || eb[1] || eb[2] || !eb[3]) return 0;
    for (int i = 0; i < elen - 4; i++) if (eb[4 + i] !== fb[tss + 1 + i]) return 0;
    return 1;
  endfunction

  int t0, t1;
  bit saw_static, saw_ce;
  always @(posedge clk) begin
    if (static_segment) saw_static = 1;
    if (content_error) saw_ce = 1;
  end

  initial begin
    repeat (3) @(negedge clk);
    chk(network_idle === 1'b1 && txen_a === 1'b0 && txd_a === 1'b1 && txd_b === 1'b1,
        "reset: network idle, transmitter off, bus recessive");
    rst_n = 1'b1;

    // timebase
    while (slot != 1) @(negedge clk);
    chk(macrotick == 64, "slot 1 starts at macrotick 64");
    @(negedge clk); t0 = macrotick;
    repeat (100) @(negedge clk);
    chk(macrotick - t0 == 100, "macrotick counts one per clock");
    while (slot != 3) @(negedge clk);
    t0 = macrotick;
    while (slot != 4) @(negedge clk);
    chk(macrotick - t0 == 64, "slot advances every 64 macroticks");
    while (cycle != 1) @(negedge clk);
    chk(macrotick == 1024 && slot == 16, "cycle 1 starts at macrotick 1024 (slot 16)");
    t0 = macrotick;
    while (cycle != 2) @(negedge clk);
    chk(macrotick - t0 == 1024, "cycle advances every 1024 macroticks");

    // 1. header-only frame
    elen = 0; en_clks = 0; txb_diff = 0; saw_static = 0;
    build(11'h2A5, 7'd0, 6'd17);
    drive();
    wait_echo();
    chk(frame_id == 11'h2A5 && payload_length == 0 && cycle_count == 17,
        "frame ID, payload length and cycle count decoded");
    chk(content_error === 1'b0 && header_crc == crc11({11'h2A5, 7'd0, 6'd17, 1'b0}, 25, 11'h1A0) % 32,
        "valid header CRC: no content error, header_crc output = CRC[4:0]");
    chk(echo_len_ok(3), "echo length = 4 + captured frame bits");
    // the echo buffer is filled with blocking writes in the same clock as a
    // non-blocking clear, which wins: the echo is all dominant
    chk_xfail(echo_ok(3), "frame echoed on txd_a as 000 1 + captured bits");
    chk(txb_diff == 0, "txd_b mirrors txd_a during the echo");
    chk(saw_static && static_segment === 1'b0 && network_idle === 1'b1,
        "static_segment high during the echo, back to idle after");

    // 2. frame with an even payload length
    repeat (20) @(negedge clk);
    elen = 0; en_clks = 0;
    build(11'h001, 7'd4, 6'd63);
    drive();
    wait_echo();
    chk(frame_id == 11'h001 && payload_length == 4 && cycle_count == 63 && !content_error,
        "4-byte payload frame decoded");
    chk(echo_len_ok(3), "4-byte payload frame captured in full (header + payload + CRC + FES)");

    // 3. odd payload length: the length is latched one bit early, its LSB
    //    still zero, so the capture ends one byte short
    repeat (20) @(negedge clk);
    elen = 0; en_clks = 0;
    build(11'h0F0, 7'd3, 6'd1);
    drive();
    wait_echo();
    chk(payload_length == 3, "payload length output 3");
    chk_xfail(echo_len_ok(3), "odd payload length: whole frame captured");

    // 4. maximum TSS (5 bits) accepted, 2-bit TSS accepted
    repeat (40) @(negedge clk);
    elen = 0; en_clks = 0;
    build(11'h155, 7'd2, 6'd5, '0, 5);
    drive();
    wait_echo();
    chk(frame_id == 11'h155 && !syntax_error && echo_len_ok(5), "5-bit TSS accepted");
    repeat (20) @(negedge clk);
    elen = 0; en_clks = 0;
    build(11'h0AA, 7'd0, 6'd2, '0, 2);
    drive();
    wait_echo();
    chk(frame_id == 11'h0AA && echo_len_ok(2), "2-bit TSS accepted");

    // 5. single dominant bit is a glitch, not a frame
    repeat (20) @(negedge clk);
    elen = 0; en_clks = 0;
    rxd_a = 1'b0; repeat (BC) @(negedge clk);
    rxd_a = 1'b1; repeat (40 * BC) @(negedge clk);
    chk(elen == 0 && frame_id == 11'h0AA, "1-bit dominant glitch ignored");

    // 6. header CRC error
    elen = 0; en_clks = 0; saw_ce = 0;
    build(11'h123, 7'd0, 6'd9, 11'h001);
    drive();
    wait_echo();
    chk(saw_ce && content_error === 1'b1, "corrupted header CRC sets content_error");
    repeat (20) @(negedge clk);
    elen = 0; en_clks = 0;
    build(11'h124, 7'd0, 6'd9);
    drive();
    wait_echo();
    chk(content_error === 1'b0, "content_error clears on the next good frame");

    // 7. frame CRC is not checked
    repeat (20) @(negedge clk);
    saw_ce = 0;
    build(11'h125, 7'd1, 6'd9);
    for (int i = flen - 26; i < flen - 2; i++) fb[i] = ~fb[i];
    drive();
    wait_echo();
    chk_xfail(saw_ce, "corrupted frame CRC flagged");

    // 8. spec (FlexRay 2.1) header: indicators + ID + length, CRC init 0x1A
    //    over 20 bits; the model expects its own layout and init
    repeat (20) @(negedge clk);
    begin
      logic [19:0] sh;
      logic [39:0] hdr;
      saw_ce = 0;
      sh = {1'b0, 1'b0, 11'h010, 7'd0};     // sync, startup, ID, length
      hdr = {1'b0, 1'b0, 1'b1, sh, crc11(sh, 20, 11'h01A), 6'd3};
      flen = 0;
      put(0, 3); put(1, 1); put(hdr, 40); put(24'h0, 24); put(2'b01, 2);
      drive();
      wait_echo();
      chk_xfail(!saw_ce && frame_id == 11'h010, "FlexRay 2.1 header with spec CRC accepted");
    end

    // 9. 6 dominant TSS bits: syntax error, 48 clocks of dominant txd_a
    repeat (40) @(negedge clk);
    rxd_a = 1'b0;
    t0 = -1; t1 = 0;
    for (int k = 0; k < 140; k++) begin
      @(negedge clk);
      if (k == 6 * BC) rxd_a = 1'b1;        // 6 dominant bits, then idle
      if (syntax_error && t0 < 0) t0 = k;
      if (txd_a === 1'b0 && !txen_a) t1++;
    end
    chk(t0 >= 0, "6 dominant TSS bits raise syntax_error");
    chk(t1 == 48, "syntax error drives txd_a dominant for 48 clocks");
    repeat (40) @(negedge clk);
    chk(syntax_error === 1'b0 && txd_a === 1'b1, "syntax_error clears and the bus is released");
    repeat (10) @(negedge clk);
    elen = 0; en_clks = 0;
    build(11'h3FF, 7'd0, 6'd0);
    drive();
    wait_echo();
    chk(frame_id == 11'h3FF && echo_len_ok(3), "node receives again after a syntax error");

    // 10. reset
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(macrotick == 0 && slot == 0 && cycle == 0 && network_idle && !syntax_error && !content_error,
        "reset clears timebase and status");
    rst_n = 1'b1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
