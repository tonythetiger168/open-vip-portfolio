// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// flexray_tests.sv -- FlexRay UVM tests

package flexray_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import flexray_pkg::*;
  import flexray_env_pkg::*;

  class base_test extends uvm_test;
    `uvm_component_utils(base_test)
    flexray_env env;
    function new(string name = "base_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = flexray_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      flexray_random_sequence seq;
      phase.raise_objection(this);
      seq = flexray_random_sequence::type_id::create("seq");
      seq.num_txns = 20;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class random_test extends base_test;
    `uvm_component_utils(random_test)
    function new(string name = "random_test", uvm_component parent = null); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      flexray_random_sequence seq;
      phase.raise_objection(this);
      seq = flexray_random_sequence::type_id::create("seq");
      seq.num_txns = 40;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class error_inject_test extends base_test;
    `uvm_component_utils(error_inject_test)
    function new(string name = "error_inject_test", uvm_component parent = null); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      flexray_error_inject_sequence seq;
      phase.raise_objection(this);
      seq = flexray_error_inject_sequence::type_id::create("seq");
      seq.num_txns = 10;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class regression_test extends base_test;
    `uvm_component_utils(regression_test)
    function new(string name = "regression_test", uvm_component parent = null); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      flexray_regression_sequence seq;
      phase.raise_objection(this);
      seq = flexray_regression_sequence::type_id::create("seq");
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass
endpackage
