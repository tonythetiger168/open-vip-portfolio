// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_coverage.svh

class flexray_coverage extends coverage_collector_base;
  `uvm_component_utils(flexray_coverage)
  uvm_analysis_imp #(flexray_transaction, flexray_coverage) analysis_export;

  flexray_transaction tx;

  covergroup fr_frame_cg;
    option.per_instance = 1;
    channel_cp: coverpoint tx.channel {
      bins ch_a  = {flexray_transaction::CHANNEL_A};
      bins ch_b  = {flexray_transaction::CHANNEL_B};
      bins ch_ab = {flexray_transaction::CHANNEL_AB};
    }
    segment_cp: coverpoint tx.segment {
      bins stat    = {flexray_transaction::STATIC_SEGMENT};
      bins dyn     = {flexray_transaction::DYNAMIC_SEGMENT};
      bins symbol  = {flexray_transaction::SYMBOL_WINDOW};
      bins idle    = {flexray_transaction::NETWORK_IDLE};
    }
    fid_cp: coverpoint tx.frame_id { bins low = {[1:256]}; bins mid = {[257:1024]}; bins high = {[1025:2047]}; }
    len_cp: coverpoint tx.payload_length { bins zero_len = {0}; bins s_len = {[2:16]}; bins m_len = {[18:64]}; bins l_len = {[66:254]}; }
    sync_cp: coverpoint tx.sync_frame;
    start_cp: coverpoint tx.startup_frame;
    cold_cp: coverpoint tx.coldstart;
    wakeup_cp: coverpoint tx.wakeup_mode;
    error_cp: coverpoint tx.with_error;
    cx_ch_seg: cross channel_cp, segment_cp;
    cx_sync_start_cold: cross sync_cp, start_cp, cold_cp;
    cx_seg_err: cross segment_cp, error_cp;
  endgroup


  // FSM transition coverage: segment/frame sequences on the bus
  covergroup flexray_fsm_cg;
    option.per_instance = 1;
    seg_trans_cp: coverpoint tx.segment {
      bins stat_stat = (flexray_transaction::STATIC_SEGMENT  => flexray_transaction::STATIC_SEGMENT);
      bins stat_dyn  = (flexray_transaction::STATIC_SEGMENT  => flexray_transaction::DYNAMIC_SEGMENT);
      bins dyn_stat  = (flexray_transaction::DYNAMIC_SEGMENT => flexray_transaction::STATIC_SEGMENT);
      bins dyn_dyn   = (flexray_transaction::DYNAMIC_SEGMENT => flexray_transaction::DYNAMIC_SEGMENT);
      bins sym_win   = (flexray_transaction::DYNAMIC_SEGMENT => flexray_transaction::SYMBOL_WINDOW);
    }
    err_trans_cp: coverpoint tx.with_error {
      bins ok_ok  = (0 => 0);
      bins ok_err = (0 => 1);
      bins err_ok = (1 => 0);
    }
    cx_seg_err_t: cross seg_trans_cp, err_trans_cp;
  endgroup

  // Data pattern coverage: payload corners x length
  covergroup flexray_data_cg;
    option.per_instance = 1;
    data0_cp: coverpoint tx.data_payload[0] iff (tx.payload_length > 0) {
      bins zero  = {8'h00};
      bins ones  = {8'hFF};
      bins aa    = {8'hAA};
      bins five5 = {8'h55};
      bins other = default;
    }
    plen_cp: coverpoint tx.payload_length {
      bins p0    = {0};
      bins p1_4  = {[1:4]};
      bins p5_8  = {[5:8]};
      bins p9_up = {[9:127]};
    }
    cycle_cp: coverpoint tx.cycle_count {
      bins low  = {[0:15]};
      bins mid  = {[16:47]};
      bins high = {[48:63]};
    }
    cx_data_plen: cross data0_cp, plen_cp;
  endgroup

  int sample_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    fr_frame_cg = new();
  endfunction
  function void write(flexray_transaction tx_);
    tx = tx_;
    sample_coverage(tx);
  endfunction
  virtual function void sample_coverage(uvm_sequence_item tx_);
    flexray_transaction ftx;
    if (!$cast(ftx, tx_)) return;
    tx = ftx;
    fr_frame_cg.sample();
    sample_count++;
  endfunction
  function void report_phase(uvm_phase phase);
    `uvm_info("FR_COV", $sformatf("Sampled %0d transactions", sample_count), UVM_LOW)
    `uvm_info("FR_COV", $sformatf("Frame coverage = %0.2f%%", fr_frame_cg.get_coverage()), UVM_LOW)
  endfunction
endclass
