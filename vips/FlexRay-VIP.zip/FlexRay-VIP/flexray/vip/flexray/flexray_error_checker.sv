// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// FlexRay protocol/data/timing/error checker (class handle + SVA module)
// UVM component handle + companion SVA module flexray_error_handling_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef FLEXRAY_ERROR_CHECKER_SV
`define FLEXRAY_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class flexray_error_handling_checker extends uvm_component;
  `uvm_component_utils(flexray_error_handling_checker)
  virtual flexray_if vif;
  function new(string name="flexray_error_handling_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual flexray_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module flexray_error_handling_sva(flexray_if vif);
  property p_fr_syntax_error; @(posedge vif.clk) disable iff (!vif.rst_n) vif.syntax_error == 1 |-> vif.tx_conflict == 0; endproperty
  assert_p_fr_syntax_error: assert property(p_fr_syntax_error) else `uvm_warning("FLEXRAY", "Syntax error failed");
  cover_p_fr_syntax_error: cover property(p_fr_syntax_error);
  property p_fr_boundary; @(posedge vif.clk) disable iff (!vif.rst_n) vif.boundary_violation == 1 |-> vif.slot > 12'd0; endproperty
  assert_p_fr_boundary: assert property(p_fr_boundary) else `uvm_warning("FLEXRAY", "Boundary violation failed");
  cover_p_fr_boundary: cover property(p_fr_boundary);
  property p_fr_tx_conflict; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tx_conflict == 1 |-> vif.txd_a != vif.rxd_a; endproperty
  assert_p_fr_tx_conflict: assert property(p_fr_tx_conflict) else `uvm_warning("FLEXRAY", "TX conflict failed");
  cover_p_fr_tx_conflict: cover property(p_fr_tx_conflict);
endmodule
`endif
