// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// FlexRay protocol/data/timing/error checker (class handle + SVA module)
// UVM component handle + companion SVA module flexray_protocol_compliance_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef FLEXRAY_PROTOCOL_CHECKER_SV
`define FLEXRAY_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class flexray_protocol_compliance_checker extends uvm_component;
  `uvm_component_utils(flexray_protocol_compliance_checker)
  virtual flexray_if vif;
  function new(string name="flexray_protocol_compliance_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual flexray_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module flexray_protocol_compliance_sva(flexray_if vif);
  property p_fr_channel; @(posedge vif.clk) disable iff (!vif.rst_n) vif.channel inside {2'b00,2'b01,2'b10}; endproperty
  assert_p_fr_channel: assert property(p_fr_channel) else `uvm_warning("FLEXRAY", "Channel valid failed");
  cover_p_fr_channel: cover property(p_fr_channel);
  property p_fr_frame_id; @(posedge vif.clk) disable iff (!vif.rst_n) vif.frame_id <= 11'd2047; endproperty
  assert_p_fr_frame_id: assert property(p_fr_frame_id) else `uvm_warning("FLEXRAY", "Frame ID range failed");
  cover_p_fr_frame_id: cover property(p_fr_frame_id);
  property p_fr_payload_len; @(posedge vif.clk) disable iff (!vif.rst_n) vif.payload_length <= 16'd254; endproperty
  assert_p_fr_payload_len: assert property(p_fr_payload_len) else `uvm_warning("FLEXRAY", "Payload length valid failed");
  cover_p_fr_payload_len: cover property(p_fr_payload_len);
  property p_fr_cycle; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cycle <= 6'd63; endproperty
  assert_p_fr_cycle: assert property(p_fr_cycle) else `uvm_warning("FLEXRAY", "Cycle 0-63 failed");
  cover_p_fr_cycle: cover property(p_fr_cycle);
  property p_fr_slot; @(posedge vif.clk) disable iff (!vif.rst_n) vif.slot <= 12'd2047; endproperty
  assert_p_fr_slot: assert property(p_fr_slot) else `uvm_warning("FLEXRAY", "Slot valid failed");
  cover_p_fr_slot: cover property(p_fr_slot);
endmodule
`endif
