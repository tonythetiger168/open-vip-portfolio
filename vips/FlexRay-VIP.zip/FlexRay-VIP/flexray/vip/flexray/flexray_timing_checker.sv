// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// FlexRay protocol/data/timing/error checker (class handle + SVA module)
// UVM component handle + companion SVA module flexray_timing_performance_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef FLEXRAY_TIMING_CHECKER_SV
`define FLEXRAY_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class flexray_timing_performance_checker extends uvm_component;
  `uvm_component_utils(flexray_timing_performance_checker)
  virtual flexray_if vif;
  function new(string name="flexray_timing_performance_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual flexray_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module flexray_timing_performance_sva(flexray_if vif);
  property p_fr_macrotick; @(posedge vif.clk) disable iff (!vif.rst_n) vif.macrotick <= 16'hFFFF; endproperty
  assert_p_fr_macrotick: assert property(p_fr_macrotick) else `uvm_warning("FLEXRAY", "Macrotick valid failed");
  cover_p_fr_macrotick: cover property(p_fr_macrotick);
  property p_fr_wakeup; @(posedge vif.clk) disable iff (!vif.rst_n) vif.wakeup_mode == 1 |-> vif.wakeup_pattern == 8'hAA || vif.wakeup_pattern == 8'h55; endproperty
  assert_p_fr_wakeup: assert property(p_fr_wakeup) else `uvm_warning("FLEXRAY", "Wakeup pattern valid failed");
  cover_p_fr_wakeup: cover property(p_fr_wakeup);
endmodule
`endif
