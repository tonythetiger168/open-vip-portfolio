// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// FlexRay protocol/data/timing/error checker (class handle + SVA module)
// UVM component handle + companion SVA module flexray_data_integrity_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef FLEXRAY_DATA_INTEGRITY_CHECKER_SV
`define FLEXRAY_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class flexray_data_integrity_checker extends uvm_component;
  `uvm_component_utils(flexray_data_integrity_checker)
  virtual flexray_if vif;
  function new(string name="flexray_data_integrity_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual flexray_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module flexray_data_integrity_sva(flexray_if vif);
  property p_fr_header_crc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.header_crc != 5'h00 |-> vif.frame_id > 0; endproperty
  assert_p_fr_header_crc: assert property(p_fr_header_crc) else `uvm_warning("FLEXRAY", "Header CRC non-zero failed");
  cover_p_fr_header_crc: cover property(p_fr_header_crc);
  property p_fr_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_frame == 1 |-> vif.coldstart == 0; endproperty
  assert_p_fr_sync: assert property(p_fr_sync) else `uvm_warning("FLEXRAY", "Sync frame valid failed");
  cover_p_fr_sync: cover property(p_fr_sync);
  property p_fr_startup; @(posedge vif.clk) disable iff (!vif.rst_n) vif.startup_frame == 1 |-> vif.coldstart == 1; endproperty
  assert_p_fr_startup: assert property(p_fr_startup) else `uvm_warning("FLEXRAY", "Startup frame valid failed");
  cover_p_fr_startup: cover property(p_fr_startup);
endmodule
`endif
