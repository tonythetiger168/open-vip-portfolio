// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_monitor.svh -- FlexRay monitor: decodes frames from the txd_a
// waveform (TSS / header / payload / CRCs / FES), verifies header CRC-11
// and trailer CRC-24, and publishes reconstructed transactions.

class flexray_monitor extends uvm_monitor;
  `uvm_component_utils(flexray_monitor)
  virtual flexray_if vif;
  uvm_analysis_port #(flexray_transaction) ap;
  flexray_config cfg;
  int unsigned txn_count = 0;

  localparam int BIT_CLKS = 8;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual flexray_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "FlexRay virtual interface not found")
    if (!uvm_config_db#(flexray_config)::get(this, "", "cfg", cfg))
      cfg = flexray_config::type_id::create("cfg");
  endfunction

  task sample_bit(output bit b);
    repeat (BIT_CLKS/2) @(posedge vif.clk);
    b = vif.txd_a;
    repeat (BIT_CLKS - BIT_CLKS/2) @(posedge vif.clk);
  endtask

  task run_phase(uvm_phase phase);
    flexray_transaction tx;
    bit b;
    bit hdr[$], pay[$], allbits[$];
    bit [10:0] hcrc_rx, hcrc_calc;
    bit [23:0] pcrc_rx, pcrc_calc;
    int dom_run, nbytes;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) continue;
      if (vif.txd_a === 1'b0) begin
        // count dominant bit-times (TSS or error marker)
        dom_run = 0;
        while (vif.txd_a === 1'b0) begin
          repeat (BIT_CLKS) @(posedge vif.clk);
          dom_run++;
          if (dom_run > 8) break;
        end
        if (dom_run >= 6) begin
          // error marker from the node
          flexray_transaction etx = flexray_transaction::type_id::create("etx");
          etx.with_error = 1;
          etx.syntax_error = 1;
          txn_count++;
          `uvm_info("FR_MON", "Monitored: error marker on channel A", UVM_MEDIUM)
          ap.write(etx);
          continue;
        end
        // TSS seen; skip the BSS (recessive) bit to reach header bit 0
        repeat (BIT_CLKS) @(posedge vif.clk);
        hdr.delete(); pay.delete(); allbits.delete();
        // header: frame_id(11) + payload_length(7) + cycle(6) + reserved(1)
        for (int i = 0; i < 25; i++) begin sample_bit(b); hdr.push_back(b); allbits.push_back(b); end
        for (int i = 0; i < 11; i++) begin sample_bit(b); hcrc_rx[10-i] = b; end
        hcrc_calc = fr_crc11(hdr);
        begin
          int plen;
          plen = 0;
          for (int i = 0; i < 7; i++) plen = (plen << 1) | hdr[11+i];
          nbytes = (plen > 8) ? 8 : plen;
          for (int bb = 0; bb < nbytes*8; bb++) begin sample_bit(b); pay.push_back(b); end
          for (int i = 0; i < 24; i++) begin sample_bit(b); pcrc_rx[23-i] = b; end
          pcrc_calc = fr_crc24(pay);
          // FES: recessive + dominant
          sample_bit(b);
          sample_bit(b);

          tx = flexray_transaction::type_id::create("tx");
          for (int i = 0; i < 11; i++) tx.frame_id[10-i] = hdr[i];
          tx.payload_length = plen;
          tx.cycle_count = '0;
          for (int i = 0; i < 6; i++) tx.cycle_count[5-i] = hdr[18+i];
          tx.header_crc = hcrc_rx;
          tx.payload_crc = pcrc_rx;
          tx.data_payload = new[nbytes];
          for (int bb = 0; bb < nbytes; bb++)
            for (int i = 0; i < 8; i++) tx.data_payload[bb][7-i] = pay[bb*8+i];
          tx.with_error = (hcrc_rx != hcrc_calc) || (pcrc_rx != pcrc_calc);
          tx.content_error = (hcrc_rx != hcrc_calc) || (pcrc_rx != pcrc_calc);
          tx.channel = flexray_transaction::CHANNEL_A;
          txn_count++;
          `uvm_info("FR_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_MEDIUM)
          ap.write(tx);
          repeat (BIT_CLKS*6) @(posedge vif.clk);   // idle gap
        end
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("FR_MON", $sformatf("flexray monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
