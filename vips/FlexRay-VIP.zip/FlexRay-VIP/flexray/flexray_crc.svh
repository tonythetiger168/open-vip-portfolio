// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// flexray_crc.svh -- FlexRay header CRC-11 (0x385) and payload CRC-24 helpers
`ifndef FLEXRAY_CRC_SVH
`define FLEXRAY_CRC_SVH

// FlexRay header CRC-11 (polynomial x^11+x^9+x^8+x^7+x^2+1 = 0x385)
function automatic bit [10:0] fr_crc11(const ref bit bits[$]);
  bit [10:0] crc = 11'h1A0;   // FlexRay header CRC init
  foreach (bits[i]) begin
    bit nxt = bits[i] ^ crc[10];
    crc = {crc[9:0], 1'b0};
    if (nxt) crc = crc ^ 11'h385;
  end
  return crc;
endfunction

// Payload CRC-24 (polynomial 0x5D6DCB), simplified init 0
function automatic bit [23:0] fr_crc24(const ref bit bits[$]);
  bit [23:0] crc = 24'h0;
  foreach (bits[i]) begin
    bit nxt = bits[i] ^ crc[23];
    crc = {crc[22:0], 1'b0};
    if (nxt) crc = crc ^ 24'h5D6DCB;
  end
  return crc;
endfunction

`endif
