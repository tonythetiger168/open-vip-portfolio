// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_driver.svh -- FlexRay node driver: serializes frames
// (TSS / header: frame_id+payload_length+cycle+header CRC-11 /
// payload / trailer CRC-24 / FES) onto rxd_a/rxd_b with a fixed bit
// time. Abstract model: up to 8 payload bytes per frame.

class flexray_driver extends uvm_driver #(flexray_transaction);
  `uvm_component_utils(flexray_driver)
  virtual flexray_if vif;
  flexray_config cfg;
  uvm_analysis_port #(flexray_transaction) drv_ap;  // expected items for scoreboard

  localparam int BIT_CLKS = 8;   // clock cycles per FlexRay bit

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual flexray_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "FlexRay virtual interface not found")
    if (!uvm_config_db#(flexray_config)::get(this, "", "cfg", cfg))
      cfg = flexray_config::type_id::create("cfg");
  endfunction

  task send_bit(bit b);
    if (req.channel inside {flexray_transaction::CHANNEL_A, flexray_transaction::CHANNEL_AB}) vif.drv_cb.rxd_a <= b;
    if (req.channel inside {flexray_transaction::CHANNEL_B, flexray_transaction::CHANNEL_AB}) vif.drv_cb.rxd_b <= b;
    repeat (BIT_CLKS) @(vif.drv_cb);
  endtask

  task send_frame(flexray_transaction tx);
    bit hdr[$];        // frame_id + payload_length + cycle + reserved
    bit pay[$];        // payload bits
    bit [10:0] hcrc;
    bit [23:0] pcrc;
    int nbytes;

    nbytes = (tx.payload_length > 8) ? 8 : tx.payload_length;

    // TSS: 3 dominant bits (skipped for syntax error injection)
    if (!tx.syntax_error) begin
      repeat (3) send_bit(1'b0);
      send_bit(1'b1);                                    // BSS (byte start)
    end
    // header fields (MSB first)
    for (int i = 10; i >= 0; i--) hdr.push_back(tx.frame_id[i]);
    for (int i = 6;  i >= 0; i--) hdr.push_back(tx.payload_length[i]);
    for (int i = 5;  i >= 0; i--) hdr.push_back(tx.cycle_count[i]);
    hdr.push_back(1'b0);                                     // reserved
    hcrc = fr_crc11(hdr);
    foreach (hdr[i]) send_bit(hdr[i]);
    for (int i = 10; i >= 0; i--) send_bit(hcrc[i]);         // header CRC-11
    // payload
    for (int b = 0; b < nbytes; b++)
      for (int i = 7; i >= 0; i--)
        pay.push_back(b < tx.data_payload.size() ? tx.data_payload[b][i] : 1'b0);
    pcrc = fr_crc24(pay);
    if (tx.with_error || tx.content_error) pcrc = pcrc ^ 24'h1;   // corrupt CRC
    foreach (pay[i]) send_bit(pay[i]);
    for (int i = 23; i >= 0; i--) send_bit(pcrc[i]);         // trailer CRC-24
    // FES: recessive then dominant frame end
    send_bit(1'b1);
    send_bit(1'b0);
    repeat (4) send_bit(1'b1);                               // channel idle
  endtask

  // legacy API: drive a single item (kept for backward compatibility)
  task drive_item(flexray_transaction tx);
    `uvm_info("FR_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)
    send_frame(tx);
  endtask

  task run_phase(uvm_phase phase);
    flexray_transaction exp;
    vif.drv_cb.rxd_a <= 1'b1;   // idle recessive
    vif.drv_cb.rxd_b <= 1'b1;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(req);
      `uvm_info("FR_DRV", $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
      send_frame(req);
      // publish what was actually put on the wire
      exp = flexray_transaction::type_id::create("exp");
      exp.copy(req);
      exp.with_error = (req.with_error || req.syntax_error || req.content_error ||
                        req.boundary_violation || req.tx_conflict);
      if (exp.payload_length > 8) exp.payload_length = 8;
      drv_ap.write(exp);
      seq_item_port.item_done();
    end
  endtask
endclass
