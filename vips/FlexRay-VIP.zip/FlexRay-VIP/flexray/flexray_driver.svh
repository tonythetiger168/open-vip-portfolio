// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_driver.svh -- FlexRay node driver: serializes frames
// (TSS / FSS / FlexRay 2.1 header with CRC-11 / payload / frame CRC-24 /
// FES, no byte start sequences) onto rxd_a/rxd_b with a fixed bit time.
// Abstract model: up to 8 payload bytes (4 words) per frame.

class flexray_driver extends uvm_driver #(flexray_transaction);
  `uvm_component_utils(flexray_driver)
  virtual flexray_if vif;
  flexray_config cfg;
  uvm_analysis_port #(flexray_transaction) drv_ap;  // expected items for scoreboard

  localparam int BIT_CLKS = 8;   // clock cycles per FlexRay bit

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual flexray_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "FlexRay virtual interface not found")
    if (!uvm_config_db#(flexray_config)::get(this, "", "cfg", cfg))
      cfg = flexray_config::type_id::create("cfg");
  endfunction

  task send_bit(bit b);
    if (req.channel inside {flexray_transaction::CHANNEL_A, flexray_transaction::CHANNEL_AB}) vif.drv_cb.rxd_a <= b;
    if (req.channel inside {flexray_transaction::CHANNEL_B, flexray_transaction::CHANNEL_AB}) vif.drv_cb.rxd_b <= b;
    repeat (BIT_CLKS) @(vif.drv_cb);
  endtask

  // FlexRay 2.1 frame without byte start sequences (as the node model takes
  // it): indicators, frame ID, payload length in 2-byte words, header CRC,
  // cycle count, payload, frame CRC, FES
  task send_frame(flexray_transaction tx);
    bit hcov[$];       // header CRC coverage: sync, startup, frame ID, length
    bit frm[$];        // frame CRC coverage: header + payload
    bit [10:0] hcrc;
    bit [23:0] pcrc;
    bit [6:0] words;
    int nbytes;

    nbytes = (tx.payload_length > 8) ? 8 : tx.payload_length;
    words = nbytes / 2;

    // TSS: 3 dominant bits (skipped for syntax error injection), FSS
    if (!tx.syntax_error) begin
      repeat (3) send_bit(1'b0);
      send_bit(1'b1);                                    // FSS
    end
    hcov.push_back(tx.sync_frame);
    hcov.push_back(tx.startup_frame);
    for (int i = 10; i >= 0; i--) hcov.push_back(tx.frame_id[i]);
    for (int i = 6;  i >= 0; i--) hcov.push_back(words[i]);
    hcrc = fr_crc11(hcov);
    frm.push_back(1'b0);                                 // reserved
    frm.push_back(1'b0);                                 // payload preamble
    frm.push_back(1'b1);                                 // null frame indicator: data
    foreach (hcov[i]) frm.push_back(hcov[i]);
    for (int i = 10; i >= 0; i--) frm.push_back(hcrc[i]);
    for (int i = 5;  i >= 0; i--) frm.push_back(tx.cycle_count[i]);
    for (int b = 0; b < 2 * words; b++)
      for (int i = 7; i >= 0; i--)
        frm.push_back(b < tx.data_payload.size() ? tx.data_payload[b][i] : 1'b0);
    pcrc = fr_crc24(frm);
    if (tx.with_error || tx.content_error) pcrc = pcrc ^ 24'h1;   // corrupt CRC
    foreach (frm[i]) send_bit(frm[i]);
    for (int i = 23; i >= 0; i--) send_bit(pcrc[i]);         // frame CRC-24
    // FES: dominant then recessive
    send_bit(1'b0);
    send_bit(1'b1);
    repeat (4) send_bit(1'b1);                               // channel idle
  endtask

  // legacy API: drive a single item (kept for backward compatibility)
  task drive_item(flexray_transaction tx);
    `uvm_info("FR_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)
    send_frame(tx);
  endtask

  // The node answers each frame on txd_a (echo, or an error marker) and
  // does not listen while it transmits: wait for that answer to finish, i.e.
  // 64 recessive bit times (frames have no byte start sequences, so
  // a payload can hold long runs of ones), before the next frame
  task wait_bus_idle();
    int quiet = 0;
    int waited = 0;
    while (vif.txd_a !== 1'b0 && waited < 20*BIT_CLKS) begin
      @(posedge vif.clk); waited++;
    end
    while (quiet < 64*BIT_CLKS) begin
      @(posedge vif.clk);
      if (vif.txd_a === 1'b1) quiet++; else quiet = 0;
    end
  endtask

  task run_phase(uvm_phase phase);
    flexray_transaction exp;
    vif.drv_cb.rxd_a <= 1'b1;   // idle recessive
    vif.drv_cb.rxd_b <= 1'b1;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(req);
      `uvm_info("FR_DRV", $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
      send_frame(req);
      wait_bus_idle();
      // publish what was actually put on the wire
      exp = flexray_transaction::type_id::create("exp");
      exp.copy(req);
      exp.with_error = (req.with_error || req.syntax_error || req.content_error ||
                        req.boundary_violation || req.tx_conflict);
      if (exp.payload_length > 8) exp.payload_length = 8;
      exp.payload_length &= ~16'h1;                    // whole 2-byte words
      drv_ap.write(exp);
      seq_item_port.item_done();
    end
  endtask
endclass
