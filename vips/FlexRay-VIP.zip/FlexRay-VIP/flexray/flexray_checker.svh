// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_checker.svh

class flexray_checker extends protocol_checker_base;
  `uvm_component_utils(flexray_checker)
  uvm_analysis_imp #(flexray_transaction, flexray_checker) analysis_export;
  flexray_config cfg;
  int tx_count = 0;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    cfg = flexray_config::type_id::create("cfg");
  endfunction
  function void write(flexray_transaction tx);
    tx_count++;
    check_frame_id(tx);
    check_payload_length(tx);
    check_slot(tx);
    check_cycle(tx);
    check_sync_startup(tx);
    check_wakeup(tx);
    check_channel(tx);
    check_header_crc(tx);
  endfunction
  function void check_frame_id(flexray_transaction tx);
    if (tx.frame_id == 0 || tx.frame_id > 2047)
      check_protocol_error($sformatf("Invalid frame ID %0d", tx.frame_id));
  endfunction
  function void check_payload_length(flexray_transaction tx);
    if (tx.payload_length > 254)
      check_protocol_error($sformatf("Payload length %0d > 254", tx.payload_length));
    if (tx.payload_length % 2 != 0)
      check_protocol_error($sformatf("Payload length %0d is odd (must be even)", tx.payload_length));
  endfunction
  function void check_slot(flexray_transaction tx);
    if (tx.segment == flexray_transaction::STATIC_SEGMENT && tx.slot > cfg.gNumberOfStaticSlots)
      check_protocol_error($sformatf("Static slot %0d exceeds max %0d", tx.slot, cfg.gNumberOfStaticSlots));
  endfunction
  function void check_cycle(flexray_transaction tx);
    if (tx.cycle > 63)
      check_protocol_error($sformatf("Cycle %0d > 63", tx.cycle));
  endfunction
  function void check_sync_startup(flexray_transaction tx);
    if (tx.startup_frame == 1 && tx.sync_frame == 0)
      check_protocol_error("Startup frame without sync frame set");
    if (tx.coldstart == 1 && tx.sync_frame == 0)
      check_protocol_error("Coldstart frame without sync frame set");
  endfunction
  function void check_wakeup(flexray_transaction tx);
    if (tx.wakeup_mode == 1 && tx.segment != flexray_transaction::SYMBOL_WINDOW)
      check_protocol_warning("Wakeup mode outside symbol window");
  endfunction
  function void check_channel(flexray_transaction tx);
    if (!cfg.dual_channel && tx.channel == flexray_transaction::CHANNEL_AB)
      check_protocol_warning("Dual channel frame on single channel config");
  endfunction
  function void check_header_crc(flexray_transaction tx);
    bit [10:0] header = {tx.frame_id, tx.payload_length[5:0], tx.header_crc_init};
    bit [4:0] expected_crc;
    expected_crc[0] = header[10] ^ header[9] ^ header[8] ^ header[7] ^ header[6] ^ header[5] ^ header[4] ^ header[3] ^ header[2] ^ header[1] ^ header[0];
    expected_crc[1] = header[10] ^ header[9] ^ header[8] ^ header[7] ^ header[6] ^ header[5] ^ header[4] ^ header[3] ^ header[2] ^ header[1];
    expected_crc[2] = header[10] ^ header[9] ^ header[8] ^ header[7] ^ header[6] ^ header[5] ^ header[4] ^ header[3] ^ header[2];
    expected_crc[3] = header[10] ^ header[9] ^ header[8] ^ header[7] ^ header[6] ^ header[5] ^ header[4] ^ header[3];
    expected_crc[4] = header[10] ^ header[9] ^ header[8] ^ header[7] ^ header[6] ^ header[5] ^ header[4];
    if (tx.header_crc != expected_crc)
      check_protocol_warning($sformatf("Header CRC mismatch: expected %b, got %b", expected_crc, tx.header_crc));
  endfunction
  task run_phase(uvm_phase phase); endtask
  function void report_phase(uvm_phase phase);
    `uvm_info("FR_CHK", $sformatf("Checked %0d transactions, %0d errors, %0d warnings",
      tx_count, error_count, warning_count), UVM_LOW)
  endfunction
endclass
