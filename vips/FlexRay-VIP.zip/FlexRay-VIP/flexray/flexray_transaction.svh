// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_transaction.svh

class flexray_transaction extends uvm_sequence_item;
  `uvm_object_utils(flexray_transaction)

  typedef enum bit [1:0] {
    CHANNEL_A  = 2'd0,
    CHANNEL_B  = 2'd1,
    CHANNEL_AB = 2'd2
  } fr_channel_e;

  typedef enum bit [1:0] {
    STATIC_SEGMENT  = 2'd0,
    DYNAMIC_SEGMENT = 2'd1,
    SYMBOL_WINDOW   = 2'd2,
    NETWORK_IDLE    = 2'd3
  } fr_segment_e;

  rand fr_channel_e   channel;
  rand fr_segment_e   segment;
  rand bit [10:0]     frame_id;
  rand bit [15:0]     payload_length;
  rand bit [10:0]     header_crc;
  rand bit [6:0]      header_crc_init;
  rand bit [23:0]     cycle_count;
  bit [23:0]          payload_crc;
  rand bit [11:0]     slot;
  rand bit [3:0]      cycle;
  rand bit            sync_frame;
  rand bit            startup_frame;
  rand bit            coldstart;
  rand bit            single_slot;
  rand bit            wakeup_mode;
  rand bit [7:0]      wakeup_pattern;
  rand bit [7:0]      data_payload[];
  rand bit            with_error;
  rand bit            syntax_error;
  rand bit            content_error;
  rand bit            boundary_violation;
  rand bit            tx_conflict;

  flexray_config      cfg;

  constraint c_frame_id { frame_id inside {[1:2047]}; }
  constraint c_payload {
    payload_length inside {[0:254]};
    payload_length % 2 == 0; // even number of bytes
    data_payload.size() == payload_length;
  }
  constraint c_slot {
    if (segment == STATIC_SEGMENT)  slot inside {[1:cfg.gNumberOfStaticSlots]};
    if (segment == DYNAMIC_SEGMENT) slot inside {[cfg.gNumberOfStaticSlots+1:2047]};
  }
  constraint c_cycle { cycle inside {[0:63]}; }
  constraint c_sync_startup {
    if (startup_frame == 1) sync_frame == 1;
  }
  constraint c_coldstart {
    if (coldstart == 1) sync_frame == 1;
  }
  constraint c_wakeup {
    wakeup_mode dist {0:=95, 1:=5};
    if (wakeup_mode == 1) { wakeup_pattern == 8'h5A; segment == SYMBOL_WINDOW; }
  }
  // Errors are injected only when a sequence asks for them. The driver
  // injects a syntax error (TSS too long) or a content error (bad frame
  // CRC); boundary violations and transmit conflicts are not modelled.
  constraint c_error {
    soft with_error == 0;
    soft syntax_error == 0;
    soft content_error == 0;
    boundary_violation == 0;
    tx_conflict == 0;
    with_error == (syntax_error || content_error);
  }

  function new(string name = "flexray_transaction");
    super.new(name);
    cfg = flexray_config::type_id::create("cfg");
  endfunction

  // There are no field macros, so uvm_object::copy() copied nothing and the
  // driver's expected item (exp.copy(req)) was all zeros
  function void do_copy(uvm_object rhs);
    flexray_transaction rhs_;
    super.do_copy(rhs);
    if (!$cast(rhs_, rhs)) `uvm_fatal("CAST", "flexray_transaction::do_copy: wrong type")
    channel = rhs_.channel;
    segment = rhs_.segment;
    frame_id = rhs_.frame_id;
    payload_length = rhs_.payload_length;
    header_crc = rhs_.header_crc;
    header_crc_init = rhs_.header_crc_init;
    cycle_count = rhs_.cycle_count;
    payload_crc = rhs_.payload_crc;
    slot = rhs_.slot;
    cycle = rhs_.cycle;
    sync_frame = rhs_.sync_frame;
    startup_frame = rhs_.startup_frame;
    coldstart = rhs_.coldstart;
    single_slot = rhs_.single_slot;
    wakeup_mode = rhs_.wakeup_mode;
    wakeup_pattern = rhs_.wakeup_pattern;
    data_payload = rhs_.data_payload;
    with_error = rhs_.with_error;
    syntax_error = rhs_.syntax_error;
    content_error = rhs_.content_error;
    boundary_violation = rhs_.boundary_violation;
    tx_conflict = rhs_.tx_conflict;
  endfunction

  function string convert2string();
    return $sformatf("FR: ch=%s seg=%s fid=%0d len=%0d slot=%0d cycle=%0d sync=%b start=%b cold=%b wakeup=%b err=%b",
      channel.name(), segment.name(), frame_id, payload_length, slot, cycle, sync_frame, startup_frame, coldstart, wakeup_mode, with_error);
  endfunction
endclass
