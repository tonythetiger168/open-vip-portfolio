// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_pkg.sv

package flexray_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  `include "flexray_crc.svh"
  `include "flexray_config.svh"
  `include "flexray_transaction.svh"
  `include "flexray_sequencer.svh"
  `include "flexray_driver.svh"
  `include "flexray_monitor.svh"
  `include "flexray_checker.svh"
  `include "flexray_coverage.svh"
  `include "flexray_agent.svh"
  `include "flexray_sequences.svh"
endpackage
