// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_if.sv
// FlexRay Interface (v2.1 / v3.0)

interface flexray_if (input logic clk, input logic rst_n);
  // Dual channel
  logic        txen_a, txen_b;
  logic        txd_a, txd_b;
  logic        rxd_a, rxd_b;
  logic        bgd_a, bgd_b;  // bus guardian disable
  // Frame structure
  logic [4:0]  header_crc;
  logic [10:0] frame_id;
  logic [15:0] payload_length;
  logic [6:0]  header_crc_init;
  logic [23:0] cycle_count;
  logic [1:0]  channel;       // 0=A, 1=B, 2=AB
  // Segment indicators
  logic        static_segment;
  logic        dynamic_segment;
  logic        symbol_window;
  logic        network_idle;
  // Timing
  logic [15:0] macrotick;
  logic [11:0] slot;
  logic [3:0]  cycle;
  // Status
  logic        coldstart;
  logic        sync_frame;
  logic        startup_frame;
  logic        single_slot;
  logic        wakeup_mode;
  logic [7:0]  wakeup_pattern;
  // Errors
  logic        syntax_error;
  logic        content_error;
  logic        boundary_violation;
  logic        tx_conflict;

  modport DUT (
    input  clk, rst_n, rxd_a, rxd_b, bgd_a, bgd_b,
    output txen_a, txen_b, txd_a, txd_b, header_crc, frame_id,
    output payload_length, header_crc_init, cycle_count, channel,
    output static_segment, dynamic_segment, symbol_window, network_idle,
    output macrotick, slot, cycle, coldstart, sync_frame, startup_frame,
    output single_slot, wakeup_mode, wakeup_pattern, syntax_error,
    output content_error, boundary_violation, tx_conflict
  );

  modport TB (
    input  clk, rst_n, txen_a, txen_b, txd_a, txd_b, header_crc, frame_id,
    input  payload_length, header_crc_init, cycle_count, channel,
    input  static_segment, dynamic_segment, symbol_window, network_idle,
    input  macrotick, slot, cycle, coldstart, sync_frame, startup_frame,
    input  single_slot, wakeup_mode, wakeup_pattern, syntax_error,
    input  content_error, boundary_violation, tx_conflict,
    output rxd_a, rxd_b, bgd_a, bgd_b
  );

  clocking mon_cb @(posedge clk);
    input txen_a, txen_b, txd_a, txd_b, rxd_a, rxd_b;
    input frame_id, payload_length, channel, static_segment, dynamic_segment;
    input slot, cycle, sync_frame, startup_frame, coldstart, wakeup_mode;
    input syntax_error, content_error, boundary_violation, tx_conflict;
  endclocking

  clocking drv_cb @(posedge clk);
    output rxd_a, rxd_b, bgd_a, bgd_b;
    input  txen_a, txen_b;
  endclocking
endinterface
