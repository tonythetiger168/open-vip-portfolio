// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_sequences.svh

class flexray_base_sequence extends uvm_sequence #(flexray_transaction);
  `uvm_object_utils(flexray_base_sequence)
  function new(string name = "flexray_base_sequence");
    super.new(name);
  endfunction
endclass

class flexray_random_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "flexray_random_sequence");
    super.new(name);
  endfunction
  task body();
    flexray_transaction tx;
    repeat (num_txns) begin
      tx = flexray_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "FlexRay tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class flexray_static_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_static_sequence)
  rand int num_txns = 50;
  function new(string name = "flexray_static_sequence");
    super.new(name);
  endfunction
  task body();
    flexray_transaction tx;
    repeat (num_txns) begin
      tx = flexray_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { segment == flexray_transaction::STATIC_SEGMENT; slot inside {[1:70]}; })
        `uvm_error("RANDFAIL", "FlexRay static randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class flexray_sync_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_sync_sequence)
  rand int num_txns = 20;
  function new(string name = "flexray_sync_sequence");
    super.new(name);
  endfunction
  task body();
    flexray_transaction tx;
    repeat (num_txns) begin
      tx = flexray_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { sync_frame == 1; startup_frame == 1; coldstart == 1; })
        `uvm_error("RANDFAIL", "FlexRay sync randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class flexray_wakeup_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_wakeup_sequence)
  rand int num_txns = 10;
  function new(string name = "flexray_wakeup_sequence");
    super.new(name);
  endfunction
  task body();
    flexray_transaction tx;
    repeat (num_txns) begin
      tx = flexray_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { wakeup_mode == 1; segment == flexray_transaction::SYMBOL_WINDOW; })
        `uvm_error("RANDFAIL", "FlexRay wakeup randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class flexray_error_inject_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_error_inject_sequence)
  rand int num_txns = 20;
  function new(string name = "flexray_error_inject_sequence");
    super.new(name);
  endfunction
  task body();
    flexray_transaction tx;
    repeat (num_txns) begin
      tx = flexray_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { with_error == 1; syntax_error == 1; })
        `uvm_error("RANDFAIL", "FlexRay error inject randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: back-to-back static segment frames
class flexray_back_to_back_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_back_to_back_sequence)
  rand int num_txns = 48;
  function new(string name = "flexray_back_to_back_sequence"); super.new(name); endfunction
  task body();
    flexray_transaction tx;
    repeat (num_txns) begin
      tx = flexray_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { segment == flexray_transaction::STATIC_SEGMENT;
                                 payload_length inside {[1:8]}; })
        `uvm_error("RANDFAIL", "FlexRay b2b randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Corner case: slot/cycle/payload extremes
class flexray_corner_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_corner_sequence)
  function new(string name = "flexray_corner_sequence"); super.new(name); endfunction
  task body();
    flexray_transaction tx;
    int slots[$] = '{1, 2, 15, 1023, 2047};
    foreach (slots[i]) begin
      tx = flexray_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { slot == slots[i]; cycle_count == (i*13) % 64;
                                 payload_length == (i % 2) ? 0 : 8; })
        `uvm_error("RANDFAIL", "FlexRay corner randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Reset behavior: single frame right after reset release
class flexray_reset_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_reset_sequence)
  function new(string name = "flexray_reset_sequence"); super.new(name); endfunction
  task body();
    flexray_transaction tx = flexray_transaction::type_id::create("tx");
    start_item(tx);
    if (!tx.randomize() with { frame_id == 11'h001; payload_length == 2; })
      `uvm_error("RANDFAIL", "FlexRay reset randomization failed")
    finish_item(tx);
  endtask
endclass

// Stress: dense traffic with error injection enabled
class flexray_stress_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_stress_sequence)
  rand int num_txns = 120;
  function new(string name = "flexray_stress_sequence"); super.new(name); endfunction
  task body();
    flexray_transaction tx;
    repeat (num_txns) begin
      tx = flexray_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { with_error dist {0:=85, 1:=15};
                                 payload_length inside {[0:8]}; })
        `uvm_error("RANDFAIL", "FlexRay stress randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Regression: weighted mix of all directed sequences
class flexray_regression_sequence extends flexray_base_sequence;
  `uvm_object_utils(flexray_regression_sequence)
  function new(string name = "flexray_regression_sequence"); super.new(name); endfunction
  task body();
    flexray_static_sequence       st  = flexray_static_sequence::type_id::create("st");
    flexray_sync_sequence         syn = flexray_sync_sequence::type_id::create("syn");
    flexray_back_to_back_sequence b2b = flexray_back_to_back_sequence::type_id::create("b2b");
    flexray_corner_sequence       cnr = flexray_corner_sequence::type_id::create("cnr");
    flexray_error_inject_sequence err = flexray_error_inject_sequence::type_id::create("err");
    flexray_stress_sequence       str = flexray_stress_sequence::type_id::create("str");
    st.num_txns = 20; syn.num_txns = 10; b2b.num_txns = 24; str.num_txns = 60;
    st.start(m_sequencer); syn.start(m_sequencer); b2b.start(m_sequencer);
    cnr.start(m_sequencer); err.start(m_sequencer); str.start(m_sequencer);
  endtask
endclass
