// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_config.svh

class flexray_config extends uvm_object;
  `uvm_object_utils(flexray_config)
  bit enable_checker  = 1;
  bit enable_coverage = 1;
  int max_payload_len = 254;   // 127 words * 2 bytes
  int max_slot        = 2047;
  int max_cycle       = 63;
  int gdStaticSlot    = 61;    // macroticks
  int gdDynamicSlot   = 10;
  int gNumberOfStaticSlots = 70;
  int gNumberOfMinislots   = 129;
  bit dual_channel    = 1;
  function new(string name = "flexray_config");
    super.new(name);
  endfunction
endclass
