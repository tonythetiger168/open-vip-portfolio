// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// FlexRay Tiered Compliance SVA Checker (module; instantiated from tb/top_tb.sv)
// L1=4 | L2=6 | L3=4 retained below; L4 FlexRay protocol-specific rules added
// UVM component handle + companion SVA module flexray_compliance_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef FLEXRAY_COMPLIANCE_CHECKER_SV
`define FLEXRAY_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class flexray_compliance_checker extends uvm_component;
  `uvm_component_utils(flexray_compliance_checker)
  virtual flexray_if vif;
  function new(string name="flexray_compliance_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual flexray_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module flexray_compliance_sva(flexray_if vif);
  // ---------------- L1: signal sanity (4) ----------------
  int l1_pass[4];
  int l1_fail[4];
  property p_fr_channel; @(posedge vif.clk) disable iff (!vif.rst_n) vif.channel inside {2'b00,2'b01,2'b10}; endproperty
  assert_p_fr_channel: assert property(p_fr_channel) l1_pass[0]++; else begin `uvm_warning("FLEXRAY_L1", "Channel failed"); l1_fail[0]++; end
  cover_p_fr_channel: cover property(p_fr_channel);
  property p_fr_frame_id; @(posedge vif.clk) disable iff (!vif.rst_n) vif.frame_id <= 11'd2047; endproperty
  assert_p_fr_frame_id: assert property(p_fr_frame_id) l1_pass[1]++; else begin `uvm_warning("FLEXRAY_L1", "Frame ID 0-2047 failed"); l1_fail[1]++; end
  cover_p_fr_frame_id: cover property(p_fr_frame_id);
  property p_fr_payload_len; @(posedge vif.clk) disable iff (!vif.rst_n) vif.payload_length <= 16'd254; endproperty
  assert_p_fr_payload_len: assert property(p_fr_payload_len) l1_pass[2]++; else begin `uvm_warning("FLEXRAY_L1", "Payload 0-254 failed"); l1_fail[2]++; end
  cover_p_fr_payload_len: cover property(p_fr_payload_len);
  property p_fr_cycle; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cycle <= 6'd63; endproperty
  assert_p_fr_cycle: assert property(p_fr_cycle) l1_pass[3]++; else begin `uvm_warning("FLEXRAY_L1", "Cycle 0-63 failed"); l1_fail[3]++; end
  cover_p_fr_cycle: cover property(p_fr_cycle);
  // ---------------- L2: FSM legality (6) ----------------
  int l2_pass[6];
  int l2_fail[6];
  property p_fr_header_crc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.header_crc != 5'h00 |-> vif.frame_id > 0; endproperty
  assert_p_fr_header_crc: assert property(p_fr_header_crc) l2_pass[0]++; else begin `uvm_warning("FLEXRAY_L2", "Header CRC failed"); l2_fail[0]++; end
  cover_p_fr_header_crc: cover property(p_fr_header_crc);
  property p_fr_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_frame == 1 |-> vif.coldstart == 0; endproperty
  assert_p_fr_sync: assert property(p_fr_sync) l2_pass[1]++; else begin `uvm_warning("FLEXRAY_L2", "Sync frame failed"); l2_fail[1]++; end
  cover_p_fr_sync: cover property(p_fr_sync);
  property p_fr_startup; @(posedge vif.clk) disable iff (!vif.rst_n) vif.startup_frame == 1 |-> vif.coldstart == 1; endproperty
  assert_p_fr_startup: assert property(p_fr_startup) l2_pass[2]++; else begin `uvm_warning("FLEXRAY_L2", "Startup frame failed"); l2_fail[2]++; end
  cover_p_fr_startup: cover property(p_fr_startup);
  property p_fr_macrotick; @(posedge vif.clk) disable iff (!vif.rst_n) vif.macrotick <= 16'hFFFF; endproperty
  assert_p_fr_macrotick: assert property(p_fr_macrotick) l2_pass[3]++; else begin `uvm_warning("FLEXRAY_L2", "Macrotick failed"); l2_fail[3]++; end
  cover_p_fr_macrotick: cover property(p_fr_macrotick);
  property p_fr_wakeup; @(posedge vif.clk) disable iff (!vif.rst_n) vif.wakeup_mode == 1 |-> vif.wakeup_pattern == 8'hAA || vif.wakeup_pattern == 8'h55; endproperty
  assert_p_fr_wakeup: assert property(p_fr_wakeup) l2_pass[4]++; else begin `uvm_warning("FLEXRAY_L2", "Wakeup failed"); l2_fail[4]++; end
  cover_p_fr_wakeup: cover property(p_fr_wakeup);
  property p_fr_slot; @(posedge vif.clk) disable iff (!vif.rst_n) vif.slot <= 12'd2047; endproperty
  assert_p_fr_slot: assert property(p_fr_slot) l2_pass[5]++; else begin `uvm_warning("FLEXRAY_L2", "Slot valid failed"); l2_fail[5]++; end
  cover_p_fr_slot: cover property(p_fr_slot);
  // ---------------- L3: FlexRay protocol rules (4) ----------------
  int l3_pass[4];
  int l3_fail[4];
  // L3-1: BSS must follow the TSS (frame start ordering); dominant TSS returns recessive or flags an error
  property p_fr_l3_bss_after_tss; @(posedge vif.clk) disable iff (!vif.rst_n) $fell(vif.txd_a) |-> s_eventually (vif.txd_a || vif.syntax_error); endproperty
  assert_p_fr_l3_bss_after_tss: assert property(p_fr_l3_bss_after_tss) l3_pass[0]++; else begin `uvm_warning("FLEXRAY_L3", "BSS not following TSS failed"); l3_fail[0]++; end
  cover_p_fr_l3_bss_after_tss: cover property(p_fr_l3_bss_after_tss);
  // L3-2: FES must follow payload/trailer CRC (frame ends recessive before transmitter releases)
  property p_fr_l3_fes_complete; @(posedge vif.clk) disable iff (!vif.rst_n) $fell(vif.txen_a) |-> vif.txd_a == 1'b1; endproperty
  assert_p_fr_l3_fes_complete: assert property(p_fr_l3_fes_complete) l3_pass[1]++; else begin `uvm_warning("FLEXRAY_L3", "Frame end without FES failed"); l3_fail[1]++; end
  cover_p_fr_l3_fes_complete: cover property(p_fr_l3_fes_complete);
  // L3-3: null frame carries no payload; its header CRC must still be valid
  property p_fr_l3_null_frame; @(posedge vif.clk) disable iff (!vif.rst_n) ($rose(vif.txen_a) && vif.payload_length == 16'd0) |-> !vif.content_error; endproperty
  assert_p_fr_l3_null_frame: assert property(p_fr_l3_null_frame) l3_pass[2]++; else begin `uvm_warning("FLEXRAY_L3", "Null frame header CRC failed"); l3_fail[2]++; end
  cover_p_fr_l3_null_frame: cover property(p_fr_l3_null_frame);
  // L3-4: static slot transmission must fit the slot window (no boundary violation)
  property p_fr_l3_slot_bound; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.static_segment && vif.txen_a) |-> !vif.boundary_violation; endproperty
  assert_p_fr_l3_slot_bound: assert property(p_fr_l3_slot_bound) l3_pass[3]++; else begin `uvm_warning("FLEXRAY_L3", "Static slot boundary violation failed"); l3_fail[3]++; end
  cover_p_fr_l3_slot_bound: cover property(p_fr_l3_slot_bound);

  // ---------------- L4: FlexRay protocol-specific rules (5) ----------------
  // L4-1: node drives the channel only while its transmitter is enabled
  a_fr_l4_drive_en : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.txd_a == 1'b0) |-> vif.txen_a)
    else `uvm_error("SVA_L4", "flexray: channel driven while transmitter disabled")

  // L4-2: every frame starts with a TSS (>=3 dominant bit-times = 24 clks)
  a_fr_l4_tss : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $fell(vif.txd_a) |-> (!vif.txd_a) [*24] or vif.syntax_error)
    else `uvm_error("SVA_L4", "flexray: frame without valid TSS")

  // L4-3: header CRC error is flagged around frame (transmitter) activity
  a_fr_l4_hcrc_flag : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.content_error) |-> ($past(vif.txen_a, 1) || vif.txen_a))
    else `uvm_error("SVA_L4", "flexray: content error flagged without bus activity")

  // L4-4: slot counter advances monotonically within a cycle
  a_fr_l4_slot_monotonic : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $changed(vif.slot) |-> (vif.slot == $past(vif.slot) + 1 || vif.slot == 0))
    else `uvm_error("SVA_L4", "flexray: slot counter not monotonic")

  // L4-5: cycle counter stays within its 4-bit range (wraps 0..15)
  a_fr_l4_cycle_wrap : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    vif.cycle <= 4'd15)
    else `uvm_error("SVA_L4", "flexray: cycle counter out of range")

  // ---------------- L4: protocol coverage ----------------
  c_fr_l4_frame : cover property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $fell(vif.txd_a) ##[24:48] $rose(vif.txd_a));
  c_fr_l4_err   : cover property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.syntax_error) ##[1:200] $fell(vif.syntax_error));
endmodule
`endif
