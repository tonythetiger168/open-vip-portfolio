// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// flexray_env.sv -- CAN verification environment with end-to-end scoreboard

package flexray_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import flexray_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) frames
  // against monitor-decoded (observed) frames.
  class flexray_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(flexray_scoreboard)
    uvm_analysis_imp_exp #(flexray_transaction, flexray_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(flexray_transaction, flexray_scoreboard) obs_ap;

    flexray_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(flexray_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(flexray_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        flexray_transaction e = exp_q.pop_front();
        flexray_transaction o = obs_q.pop_front();
        bit ok;
        if (e.with_error) begin
          ok = o.with_error;
        end else begin
          ok = (e.frame_id == o.frame_id) &&
               ((e.payload_length > 8 ? 8 : e.payload_length) == o.payload_length) &&
               (e.cycle_count[5:0] == o.cycle_count[5:0]);
          if (ok) begin
            int nb = (e.payload_length > 8) ? 8 : e.payload_length;
            for (int i = 0; i < nb; i++)
              if (i < e.data_payload.size() && i < o.data_payload.size())
                if (e.data_payload[i] != o.data_payload[i]) ok = 0;
          end
        end
        if (ok) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("flexray scoreboard: n_matches=%0d n_mismatches=%0d",
                n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  class flexray_env extends uvm_env;
    `uvm_component_utils(flexray_env)
    flexray_agent      agt;
    flexray_scoreboard sb;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = flexray_agent::type_id::create("agt", this);
      sb  = flexray_scoreboard::type_id::create("sb", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
    endfunction
  endclass
endpackage
