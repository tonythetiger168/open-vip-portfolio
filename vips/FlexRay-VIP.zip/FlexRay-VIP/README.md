# FlexRay — FlexRay UVM VIP

Open-source UVM verification IP for **FlexRay** (deterministic automotive bus).

## Protocol Overview
- **Frame (abstract model):** TSS (3 dominant bits) + BSS → header (frame_id[10:0], payload_length[6:0], cycle_count[5:0], header CRC-11) → payload (up to 8 bytes) → trailer CRC-24 → FES
- **Bit timing:** 8 clocks per bit; channels A/B driven in parallel
- **TDMA concept:** free-running slot/cycle/macrotick counters in the DUT model the communication cycle; static/dynamic segment frame types
- **Errors:** CRC / syntax / content / boundary / tx-conflict injection + error marker

## Contents
| Path | Description |
|------|-------------|
| `common/common_pkg.sv` | shared base classes |
| `flexray/flexray_if.sv` | interface + clocking blocks |
| `flexray/flexray_pkg.sv` + `*.svh` | UVM agent (driver/monitor/sequencer/coverage/checker) |
| `flexray/flexray_crc.svh` | header CRC-11 / payload CRC-24 helpers |
| `flexray/sva/flexray_compliance_checker.sv` | compliance SVA module (L1-L4) |
| `flexray/vip/flexray/` | protocol / timing / error / data-integrity checkers |
| `env/flexray_env.sv` | environment + end-to-end scoreboard |
| `tests/flexray_tests.sv` | base / random / error_inject / regression tests |
| `tb/top_tb.sv` + `tb/flexray_node_model.sv` | testbench top + functional FlexRay node DUT |
| `scripts/` | Makefile + coverage-driven regression |

## Architecture
The driver serializes frames onto `rxd_a`/`rxd_b`; the node DUT verifies
header CRC-11 / payload CRC-24 and echoes the frame on `txd_a`/`txd_b`
(dominant error marker on undecodable input); the monitor decodes `txd_a`
and the scoreboard compares expected vs observed (n_matches/n_mismatches,
UVM_ERROR on mismatch).

## Sequence Library
| Sequence | Purpose |
|----------|---------|
| `flexray_random_sequence` | constrained-random (normal) |
| `flexray_static_sequence` / `flexray_sync_sequence` / `flexray_wakeup_sequence` | per frame type |
| `flexray_back_to_back_sequence` | dense static-segment traffic |
| `flexray_error_inject_sequence` | error injection |
| `flexray_corner_sequence` | slot/cycle/payload extremes |
| `flexray_reset_sequence` | frame right after reset |
| `flexray_stress_sequence` | dense traffic with 15% CRC errors |
| `flexray_regression_sequence` | weighted mix |

## SVA (L1-L4)
- **L1 (4):** frame ID / payload length ranges, channel legality, slot range
- **L2 (6):** header CRC, payload CRC, TSS/FES presence, cycle/slot counters
- **L3 (5):** coldstart, sync/startup frames, wakeup, error rates
- **L4 (5):** drive only when enabled, TSS presence, CRC error around TX activity, slot monotonicity, cycle range

## Functional Coverage
- `flexray_frame_cg`: channel x segment, sync/startup/coldstart, segment x error (crosses)
- `flexray_error_cg`: error kinds (cross)
- `flexray_fsm_cg`: segment transition sequences x error transitions (cross)
- `flexray_data_cg`: payload corners x length, cycle ranges (cross)

## Quick start
```bash
cd scripts
make all TEST=base_test
./coverage_regression.sh
```
License: Apache-2.0
