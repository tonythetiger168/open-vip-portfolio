// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_checker.svh -- SDIO protocol checker on monitored items

class sdio_checker extends uvm_component;
  `uvm_component_utils(sdio_checker)
  uvm_analysis_imp #(sdio_transaction, sdio_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  sdio_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(sdio_config)::get(this, "", "cfg", cfg))
      cfg = sdio_config::type_id::create("cfg");
  endfunction

  function void fail(sdio_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("SDIO: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(sdio_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.crc != sdio_transaction::crc7({1'b0, 1'b1, t.cmd, t.arg})) fail(t, "command CRC7 mismatch");
      if (t.resp[46:45] != 2'b00) fail(t, "response start/transmission bits not 0");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("SDIO checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
