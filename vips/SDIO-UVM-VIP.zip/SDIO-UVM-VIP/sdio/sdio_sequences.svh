// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_sequences.svh -- SDIO sequences

// Random traffic: cfg.num_items constrained-random items.
class sdio_base_sequence extends uvm_sequence #(sdio_transaction);
  `uvm_object_utils(sdio_base_sequence)
  sdio_config cfg;

  function new(string name = "sdio_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = sdio_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "sdio_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class sdio_directed_sequence extends uvm_sequence #(sdio_transaction);
  `uvm_object_utils(sdio_directed_sequence)
  sdio_config cfg;

  function new(string name = "sdio_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function sdio_transaction item();
    item = sdio_transaction::type_id::create("req");
  endfunction

  task send(sdio_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    sdio_transaction t;
    bit [5:0] cmds [6] = '{6'd0, 6'd8, 6'd5, 6'd3, 6'd52, 6'd53};   // CMD0/8/5/3/52/53
    bit [31:0] args [6] = '{32'h0, 32'h0000_01AA, 32'h0030_0000, 32'h0, 32'h8000_0C00, 32'h1000_0004};
    foreach (cmds[i]) begin t = item(); t.cmd = cmds[i]; t.arg = args[i]; t.build(); send(t); end
  endtask
endclass
