// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_compliance_checker.sv -- SDIO concurrent assertion checks (bindable)

module sdio_compliance_checker
  (input logic clk, input logic rst_n, input cmd_i, input [3:0] dat_i, input cmd_o, input cmd_oe, input [3:0] dat_o, input dat_oe);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({cmd_o, cmd_oe, dat_o, dat_oe}))
    else $error("SDIO: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> cmd_o == '0)
    else $error("SDIO: output not in reset value");
  // CMD is only driven during the response window
  assert property (@(posedge clk) disable iff (!rst_n) cmd_oe |=> cmd_oe || $stable(cmd_o) || $fell(cmd_oe))
    else $error("SDIO: cmd drive outside response");
  cover property (@(posedge clk) disable iff (!rst_n) (cmd_o != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (dat_oe == 1'b1));
endmodule
