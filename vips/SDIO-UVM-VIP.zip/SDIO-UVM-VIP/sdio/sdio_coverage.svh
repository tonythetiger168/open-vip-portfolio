// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_coverage.svh -- SDIO functional coverage

class sdio_coverage extends uvm_subscriber #(sdio_transaction);
  `uvm_component_utils(sdio_coverage)
  sdio_config cfg;
  sdio_transaction tr;

  covergroup sdio_cg;
    coverpoint tr.cmd_i;
    coverpoint tr.dat_i;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(sdio_config)::get(this, "*", "cfg", cfg));
    sdio_cg = new();
  endfunction

  function void write(sdio_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    sdio_cg.sample();
  endfunction
endclass
