// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_coverage.svh -- SDIO functional coverage

class sdio_coverage extends uvm_subscriber #(sdio_transaction);
  `uvm_component_utils(sdio_coverage)
  sdio_config cfg;
  sdio_transaction tr;

  covergroup sdio_cg;
    cp_cmd : coverpoint tr.cmd { bins go_idle = {0}; bins send_if_cond = {8}; bins io_rw_direct = {52};
                                 bins io_rw_extended = {53}; bins app = {55}; bins other = default; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    sdio_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(sdio_config)::get(this, "", "cfg", cfg))
      cfg = sdio_config::type_id::create("cfg");
  endfunction

  function void write(sdio_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    sdio_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SDIO coverage: %0.1f%%", sdio_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
