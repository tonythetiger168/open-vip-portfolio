// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_driver.svh -- SDIO driver: 48-bit command on cmd_i (one bit per clock), then collects the response

class sdio_driver extends uvm_driver #(sdio_transaction);
  `uvm_component_utils(sdio_driver)

  uvm_analysis_port #(sdio_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual sdio_if vif;
  sdio_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sdio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sdio: virtual interface not set")
    if (!uvm_config_db#(sdio_config)::get(this, "", "cfg", cfg))
      cfg = sdio_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    sdio_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.cmd_i <= 1'b1; vif.drv_cb.dat_i <= 4'hF;
  endtask

  task drive_item(sdio_transaction t);
    bit [47:0] f = t.frame();
    @(vif.drv_cb);
    for (int i = 47; i >= 0; i--) begin
      vif.drv_cb.cmd_i <= f[i];
      @(vif.drv_cb);
    end
    vif.drv_cb.cmd_i <= 1'b1;
    begin
      int unsigned to = 0;
      while (vif.drv_cb.cmd_oe !== 1'b1 && to < cfg.resp_timeout) begin @(vif.drv_cb); to++; end
      if (vif.drv_cb.cmd_oe !== 1'b1) `uvm_error("TIMEOUT", "SDIO: no response")
    end
    t.resp = 0; t.resp_len = 0; t.busy_clks = 0;
    while (vif.drv_cb.cmd_oe === 1'b1) begin
      t.resp = {t.resp[45:0], vif.drv_cb.cmd_o};
      t.resp_len++;
      if (vif.drv_cb.dat_oe === 1'b1) t.busy_clks++;
      @(vif.drv_cb);
    end
    repeat (2) @(vif.drv_cb);
  endtask

endclass
