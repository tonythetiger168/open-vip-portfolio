// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_driver.svh -- SDIO driver: reset, then per-item protocol stimulus

class sdio_driver extends uvm_driver #(sdio_transaction);
  `uvm_component_utils(sdio_driver)

  virtual sdio_if vif;
  sdio_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sdio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sdio: virtual interface not set")
    void'(uvm_config_db#(sdio_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    vif.drv_cb.rst_n <= 1'b0;
    repeat (8) @(vif.drv_cb);
    vif.drv_cb.rst_n <= 1'b1;
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_item(sdio_transaction item);
    item.tag = item_cnt++;
    vif.cmd_i <= item.cmd_i;
    vif.dat_i <= item.dat_i;
    @(vif.drv_cb);
    ap.write(item);
  endtask
endclass
