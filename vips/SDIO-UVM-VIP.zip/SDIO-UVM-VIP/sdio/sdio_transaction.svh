// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_transaction.svh -- SDIO transaction

class sdio_transaction extends uvm_sequence_item;
  `uvm_object_utils(sdio_transaction)

  rand bit cmd_i;
  rand bit [3:0] dat_i;
  bit cmd_o_o;
  bit cmd_oe_o;
  bit [3:0] dat_o_o;
  bit dat_oe_o;
  bit [31:0] tag;

  function new(string name = "sdio_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    sdio_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    cmd_i = rhs_.cmd_i;
    dat_i = rhs_.dat_i;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sdio_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           cmd_i == rhs_.cmd_i &&
           dat_i == rhs_.dat_i;
  endfunction

  function string convert2string();
    return $sformatf("SDIO{tag=%0h cmd_i=0x%0h dat_i=0x%0h}", tag, cmd_i, dat_i);
  endfunction
endclass
