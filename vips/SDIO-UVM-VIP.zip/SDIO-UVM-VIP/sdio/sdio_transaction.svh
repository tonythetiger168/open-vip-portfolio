// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_transaction.svh -- SDIO transaction

class sdio_transaction extends uvm_sequence_item;
  `uvm_object_utils(sdio_transaction)

  // request (driven by the agent)
  rand bit [5:0] cmd;
  rand bit [31:0] arg;
  bit [6:0] crc;
  // response (returned by the DUT)
  bit [47:0] resp;
  bit [5:0] resp_len;
  bit [3:0] busy_clks;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "sdio_transaction"); super.new(name); endfunction

  // CRC7 (x^7 + x^3 + 1) over the first 40 bits of the command
  static function bit [6:0] crc7(bit [39:0] d);
    bit [6:0] c = 0;
    for (int i = 39; i >= 0; i--) begin
      bit fb = c[6] ^ d[i];
      c = {c[5:0], 1'b0};
      if (fb) c ^= 7'h09;
    end
    return c;
  endfunction

  // start 0, transmission 1, index, argument, CRC7, end 1
  function bit [47:0] frame();
    return {1'b0, 1'b1, cmd, arg, crc, 1'b1};
  endfunction

  function void build(); crc = crc7({1'b0, 1'b1, cmd, arg}); endfunction
  function void post_randomize(); build(); endfunction

  function void do_copy(uvm_object rhs);
    sdio_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    cmd = rhs_.cmd;
    arg = rhs_.arg;
    crc = rhs_.crc;
    resp = rhs_.resp;
    resp_len = rhs_.resp_len;
    busy_clks = rhs_.busy_clks;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sdio_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (cmd != rhs_.cmd) return 0;
    if (arg != rhs_.arg) return 0;
    if (crc != rhs_.crc) return 0;
    if (resp != rhs_.resp) return 0;
    if (resp_len != rhs_.resp_len) return 0;
    if (busy_clks != rhs_.busy_clks) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(sdio_transaction rhs_);
    if (cmd != rhs_.cmd) return 0;
    if (arg != rhs_.arg) return 0;
    if (crc != rhs_.crc) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("SDIO{tag=%0d cmd=0x%0h arg=0x%0h crc=0x%0h resp=0x%0h resp_len=0x%0h busy_clks=0x%0h}", tag, cmd, arg, crc, resp, resp_len, busy_clks);
  endfunction
endclass
