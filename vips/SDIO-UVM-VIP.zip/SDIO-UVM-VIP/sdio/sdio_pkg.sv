// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_pkg.sv -- SDIO UVM VIP package

package sdio_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import sdio_defs_pkg::*;
  export sdio_defs_pkg::*;

  `include "sdio_transaction.svh"
  `include "sdio_config.svh"
  `include "sdio_sequencer.svh"
  `include "sdio_driver.svh"
  `include "sdio_monitor.svh"
  `include "sdio_agent.svh"
  `include "sdio_sequences.svh"
  `include "sdio_checker.svh"
  `include "sdio_coverage.svh"
endpackage
