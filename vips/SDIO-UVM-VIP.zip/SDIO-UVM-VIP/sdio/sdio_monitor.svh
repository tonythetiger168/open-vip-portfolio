// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_monitor.svh -- SDIO monitor: decodes observed bus activity

class sdio_monitor extends uvm_monitor;
  `uvm_component_utils(sdio_monitor)

  virtual sdio_if vif;
  uvm_analysis_port #(sdio_transaction) ap;
  sdio_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual sdio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sdio: virtual interface not set")
    void'(uvm_config_db#(sdio_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    sdio_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = sdio_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.cmd_i = vif.cmd_i;
        t.dat_i = vif.dat_i;
        t.cmd_o_o = vif.cmd_o;
        t.cmd_oe_o = vif.cmd_oe;
        t.dat_o_o = vif.dat_o;
        t.dat_oe_o = vif.dat_oe;
        ap.write(t);
      end
    end
  endtask
endclass
