// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_monitor.svh -- SDIO monitor: commands on cmd_i (start bit to end bit) and the card's response on cmd_o

class sdio_monitor extends uvm_monitor;
  `uvm_component_utils(sdio_monitor)

  virtual sdio_if vif;
  uvm_analysis_port #(sdio_transaction) ap;
  sdio_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual sdio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sdio: virtual interface not set")
    if (!uvm_config_db#(sdio_config)::get(this, "", "cfg", cfg))
      cfg = sdio_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.cmd_i === 1'b0) begin           // start bit
          sdio_transaction t = sdio_transaction::type_id::create("t");
          bit [47:0] f = 0;
          int unsigned to = 0;
          for (int i = 0; i < 48; i++) begin
            if (i != 0) @(vif.mon_cb);
            f = {f[46:0], vif.mon_cb.cmd_i};
          end
          t.cmd = f[45:40]; t.arg = f[39:8]; t.crc = f[7:1];
          if (f[46] != 1'b1 || f[0] != 1'b1) `uvm_error("MON", "SDIO command without transmission / end bit")
          do begin @(vif.mon_cb); to++; end while (vif.mon_cb.cmd_oe !== 1'b1 && to < cfg.resp_timeout);
          while (vif.mon_cb.cmd_oe === 1'b1) begin
            t.resp = {t.resp[45:0], vif.mon_cb.cmd_o};
            t.resp_len++;
            if (vif.mon_cb.dat_oe === 1'b1) begin
              t.busy_clks++;
              if (vif.mon_cb.dat_o !== 4'h5) `uvm_error("MON", "SDIO unexpected DAT pattern during busy")
            end
            @(vif.mon_cb);
          end
          publish(t);
        end
      end
    end
  endtask

  function void publish(sdio_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
