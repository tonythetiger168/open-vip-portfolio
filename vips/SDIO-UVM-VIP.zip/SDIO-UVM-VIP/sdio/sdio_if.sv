// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdio_if.sv -- SDIO interface

interface sdio_if (input logic clk);
  logic rst_n;

  logic cmd_i;
  logic [3:0] dat_i;
  logic cmd_o;
  logic cmd_oe;
  logic [3:0] dat_o;
  logic dat_oe;

  modport DUT (input clk, rst_n, cmd_i, dat_i, output cmd_o, cmd_oe, dat_o, dat_oe);
  modport DRV (input clk, rst_n, cmd_o, cmd_oe, dat_o, dat_oe, output cmd_i, dat_i);
  modport MON (input clk, rst_n, cmd_i, dat_i, cmd_o, cmd_oe, dat_o, dat_oe);

  clocking drv_cb @(posedge clk);
    input rst_n, cmd_i, dat_i, cmd_o, cmd_oe, dat_o, dat_oe;
    output cmd_i, dat_i;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, cmd_i, dat_i, cmd_o, cmd_oe, dat_o, dat_oe;
  endclocking
endinterface
