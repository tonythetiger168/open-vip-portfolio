// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (SDIO command/response exchange)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened sdio_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic cmd_i = 1'b1;
  logic [3:0] dat_i = 4'hF;
  wire  cmd_o;
  wire  cmd_oe;
  wire  [3:0] dat_o;
  wire  dat_oe;

  always #5 clk = ~clk;

  sdio_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .cmd_i(cmd_i), .dat_i(dat_i),
    .cmd_o(cmd_o), .cmd_oe(cmd_oe),
    .dat_o(dat_o), .dat_oe(dat_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  task automatic send_cmd(input logic [47:0] frame);
    // 48-bit serial command: idle high, start bit, then 46 bits, stop bit
    cmd_i = 1'b0;                 // start
    repeat (2) step();
    for (int i = 45; i >= 0; i--) begin
      @(negedge clk); cmd_i = frame[i];
      step();
    end
    @(negedge clk); cmd_i = 1'b1;   // stop / idle
  endtask

  initial begin
    repeat (8) step();
    chk(cmd_oe === 1'b0 && dat_oe === 1'b0, "card quiet out of reset");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // idle: no response
    repeat (6) begin step(); chk(cmd_oe === 1'b0, "no response without command"); end

    // CMD8-like frame (cmd index 8): expect a response window
    send_cmd({8'h08, 32'h000001AA, 6'h00, 1'b1});
    begin : resp
      int to = 0, driven = 0;
      while (cmd_oe !== 1'b1 && to < 40) begin step(); to++; end
      chk(cmd_oe === 1'b1, "CMD8 response driven");
      while (cmd_oe === 1'b1 && to < 120) begin
        step(); to++;
        if (cmd_o === 1'b0) driven++;
      end
      chk(driven > 0, "response carries low bits (not stuck high)");
    end

    // back to idle afterwards
    repeat (6) begin step(); chk(cmd_oe === 1'b0, "card released after response"); end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
