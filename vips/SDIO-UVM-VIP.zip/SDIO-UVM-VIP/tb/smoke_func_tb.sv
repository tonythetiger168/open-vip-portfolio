// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (SDIO command/response exchange)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened sdio_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic cmd_i = 1'b1;
  logic [3:0] dat_i = 4'hF;
  wire  cmd_o;
  wire  cmd_oe;
  wire  [3:0] dat_o;
  wire  dat_oe;

  always #5 clk = ~clk;

  sdio_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .cmd_i(cmd_i), .dat_i(dat_i),
    .cmd_o(cmd_o), .cmd_oe(cmd_oe),
    .dat_o(dat_o), .dat_oe(dat_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  function automatic logic [6:0] crc7(input logic [39:0] d);
    logic [6:0] c = '0;
    for (int i = 39; i >= 0; i--) begin
      logic fb = c[6] ^ d[i];
      c = {c[5:0], 1'b0};
      if (fb) c ^= 7'h09;
    end
    return c;
  endfunction

  // SD command frame: start 0, transmission 1, index, argument, CRC7, end 1
  function automatic logic [47:0] cmd_frame(input logic [5:0] idx, input logic [31:0] arg);
    return {2'b01, idx, arg, crc7({2'b01, idx, arg}), 1'b1};
  endfunction

  // the card samples cmd_i on the falling edge; drive one bit per clock
  // just after the rising edge
  task automatic send_cmd(input logic [47:0] frame);
    for (int i = 47; i >= 0; i--) begin
      cmd_i = frame[i];
      step();
    end
    cmd_i = 1'b1;                 // idle
  endtask

  logic [5:0] idx_q[$] = '{6'd52, 6'd8, 6'd0, 6'd63};
  initial begin
    repeat (8) step();
    chk(cmd_oe === 1'b0 && dat_oe === 1'b0 && cmd_o === 1'b0, "card quiet out of reset");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // idle: no response
    repeat (6) begin step(); chk(cmd_oe === 1'b0, "no response without command"); end

    // CMD8-like frame (cmd index 8): expect a response window
    send_cmd(cmd_frame(6'd8, 32'h0000_01AA));
    begin : resp
      int to = 0, driven = 0;
      while (cmd_oe !== 1'b1 && to < 40) begin step(); to++; end
      chk(cmd_oe === 1'b1, "CMD8 response driven");
      while (cmd_oe === 1'b1 && to < 120) begin
        step(); to++;
        if (cmd_o === 1'b0) driven++;
      end
      chk(driven > 0, "response carries low bits (not stuck high)");
    end

    // back to idle afterwards
    repeat (6) begin step(); chk(cmd_oe === 1'b0, "card released after response"); end

    // exact response contents for two command indices
    foreach (idx_q[k]) begin
      logic [47:0] r, exp; int nb, ndat; bit dat_ok;
      send_cmd(cmd_frame(idx_q[k], 32'h0000_0000));
      r = '0; nb = 0; ndat = 0; dat_ok = 1;
      begin : cap
        int to;
        to = 0;
        while (cmd_oe !== 1'b1 && to < 40) begin step(); to++; end
        while (cmd_oe === 1'b1 && to < 120) begin
          r = {r[46:0], cmd_o}; nb++;
          if (dat_oe === 1'b1) begin ndat++; if (dat_o !== 4'h5) dat_ok = 0; end
          step(); to++;
        end
      end
      // R1-style response (tb/top_tb.sv sdio_model): 48 bits, MSB first:
      // start 0, transmission 0, the command index, card status 0x100,
      // CRC7, end 1; DAT drives 4'h5 (busy) for the first 8 bits
      exp = {2'b00, idx_q[k], 32'h0000_0100, crc7({2'b00, idx_q[k], 32'h0000_0100}), 1'b1};
      chk(nb == 48, $sformatf("CMD%0d: response is 48 bits long (%0d)", idx_q[k], nb));
      chk(r === exp, $sformatf("CMD%0d: response bits %h, expected %h", idx_q[k], r, exp));
      chk(ndat == 8 && dat_ok, $sformatf("CMD%0d: DAT drives 4'h5 for 8 bits (%0d)", idx_q[k], ndat));
      repeat (4) step();
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
