// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SDIO testbench top with a functional SDIO DUT model

`ifndef SDIO_TB_SV
`define SDIO_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sdio_defs_pkg::*;
import sdio_pkg::*;
import sdio_env_pkg::*;
import sdio_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  sdio_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  sdio_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cmd_i(vif.cmd_i),
    .dat_i(vif.dat_i),
    .cmd_o(vif.cmd_o),
    .cmd_oe(vif.cmd_oe),
    .dat_o(vif.dat_o),
    .dat_oe(vif.dat_oe)
  );

  // Concurrent protocol checks
  sdio_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .cmd_i(vif.cmd_i), .dat_i(vif.dat_i), .cmd_o(vif.cmd_o), .cmd_oe(vif.cmd_oe), .dat_o(vif.dat_o), .dat_oe(vif.dat_oe)
  );

  initial begin
    uvm_config_db#(virtual sdio_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module sdio_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       cmd_i,
  input  logic [3:0] dat_i,
  output logic       cmd_o,
  output logic       cmd_oe,
  output logic [3:0] dat_o,
  output logic       dat_oe
);
  logic [47:0] sh;
  logic [5:0]  bcnt;
  logic        resp;
  logic [47:0] rsh;
  typedef enum bit [1:0] {IDLE, COLLECT, RESP} state_e;
  state_e st;
  always_ff @(negedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st     <= IDLE;
      sh     <= '0;
      bcnt   <= '0;
      resp   <= 1'b0;
      rsh    <= '0;
      cmd_o  <= 1'b0;
      cmd_oe <= 1'b0;
      dat_o  <= '0;
      dat_oe <= 1'b0;
    end else begin
      case (st)
        IDLE: begin
          if (!cmd_i && bcnt == 0) begin
            st   <= COLLECT;
            bcnt <= 6'd1;
          end
        end
        COLLECT: begin
          sh   <= {sh[46:0], cmd_i};
          bcnt <= bcnt + 1'b1;
          if (bcnt == 6'd47) begin
            st   <= RESP;
            // echo back a fixed R1-style response: cmd index + card status
            rsh  <= {2'b00, sh[45:40], 8'h00, 8'h00, 8'h01, 8'h00, 7'h00, 1'b1};
            bcnt <= '0;
          end
        end
        RESP: begin
          cmd_oe <= 1'b1;
          cmd_o  <= rsh[47];
          rsh    <= {rsh[46:0], 1'b0};
          bcnt   <= bcnt + 1'b1;
          dat_oe <= (bcnt < 6'd8);
          dat_o  <= 4'h5;
          if (bcnt == 6'd47) begin
            st     <= IDLE;
            cmd_oe <= 1'b0;
            dat_oe <= 1'b0;
            bcnt   <= '0;
          end
        end
        default: st <= IDLE;
      endcase
    end
  end
endmodule
`endif
