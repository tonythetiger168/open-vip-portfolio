# SDIO UVM VIP (SDIO-UVM-VIP)

SDIO card UVM VIP: CMD serial command decode with R1/R3/R7-style responses and 4-bit DAT drive windows. Complements the SDIO RTL IP from the open-ip-portfolio sister project.

## Structure

- `sdio/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `sdio_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `sdio_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural SDIO DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/SDIO-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh SDIO-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
