# DPI — MIPI DPI (Display Pixel Interface) UVM VIP

Open-source UVM verification IP template for **MIPI DPI (Display Pixel Interface)** (MIPI).

## Contents

| Path | Description |
|------|-------------|
| `dpi/dpi_if.sv` | Protocol interface + FSM state enum |
| `dpi/dpi_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `dpi/sva/dpi_compliance_checker.sv` | SVA compliance checker (L1=4, L2=4, L3=4, L4=6) |
| `dpi/vip/dpi/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/dpi_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional display sink DUT |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **VGA-like raster source driver**: vsync pulse -> vblank -> per-line hsync/hblank/hactive timing generation, pixel items pulled per active cycle, blanking-DE violation injection with expected-event replay
- **Raster-decoding monitor**: tracks line/pixel position from sync edges, reconstructs pixel transactions with (hcount, vcount), detects DE in blanking
- **End-to-end scoreboard**: per-pixel comparison of data + raster position, DE-in-blanking error matching
- **Functional DUT model**: display sink counting DE pixels per frame, frame geometry check at VSYNC, DE-during-VSYNC detection
- **Directed sequence library**: full-frame / solid-color / gradient / pixel-corner / DE-in-blanking error-inject / reset + random + regression mix
- **Functional coverage**: pixel color corners, h/v position bins with four-corner cross, FSM states + frame/line transitions, DE error bins
- **SVA L4**: DE only in active region, HSYNC/VSYNC pulse widths, pixel data stable outside DE, frame starts with VSYNC
