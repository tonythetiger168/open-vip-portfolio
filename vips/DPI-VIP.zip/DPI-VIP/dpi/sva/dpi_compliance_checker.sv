// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_compliance_checker.sv -- DPI SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = DPI protocol-specific rules (DE only in hactive, sync pulse widths,
//      pixel stable outside DE, frame starts with VSYNC)

`ifndef DPI_COMPLIANCE_CHECKER_SV
`define DPI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import dpi_defs_pkg::*;

module dpi_compliance_checker
(
  input logic        pixelclk,
  input logic        rst_n,
  input dpi_state_e  state,
  input logic        hsync,
  input logic        vsync,
  input logic        de,
  input logic [23:0] data,
  input logic        error_inject
);

  // Procedural helper: a frame must begin with VSYNC before any HSYNC.
  bit seen_vsync = 0;
  always @(posedge pixelclk or negedge rst_n) begin
    if (!rst_n) seen_vsync <= 0;
    else if ($rose(vsync)) seen_vsync <= 1;
  end

  // ---------------- L1: signal sanity (4) ----------------
  a_dpi_l1_clk   : assert property (@(posedge pixelclk) disable iff (!rst_n) !$isunknown(pixelclk))
    else `uvm_error("SVA_L1", "dpi: clock unknown")
  a_dpi_l1_rst   : assert property (@(posedge pixelclk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "dpi: reset unknown")
  a_dpi_l1_state : assert property (@(posedge pixelclk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "dpi: state unknown")
  a_dpi_l1_valid : assert property (@(posedge pixelclk) disable iff (!rst_n)
    state inside {IDLE, VSYNC_PULSE, HBLANK, HACTIVE})
    else `uvm_error("SVA_L1", "dpi: state outside legal encoding")

  // ---------------- L2: FSM legality (4) ----------------
  // L2-1: legal FSM transition from IDLE
  a_dpi_trans_idle : assert property (@(posedge pixelclk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, VSYNC_PULSE})
    else `uvm_error("SVA_L2", "dpi: illegal transition from IDLE")
  // L2-2: legal FSM transition from VSYNC_PULSE
  a_dpi_trans_vsync : assert property (@(posedge pixelclk) disable iff (!rst_n)
    state == VSYNC_PULSE |=> state inside {VSYNC_PULSE, HBLANK})
    else `uvm_error("SVA_L2", "dpi: illegal transition from VSYNC_PULSE")
  // L2-3: legal FSM transition from HBLANK
  a_dpi_trans_hblank : assert property (@(posedge pixelclk) disable iff (!rst_n)
    state == HBLANK |=> state inside {HBLANK, HACTIVE, VSYNC_PULSE})
    else `uvm_error("SVA_L2", "dpi: illegal transition from HBLANK")
  // L2-4: legal FSM transition from HACTIVE
  a_dpi_trans_hactive : assert property (@(posedge pixelclk) disable iff (!rst_n)
    state == HACTIVE |=> state inside {HACTIVE, HBLANK})
    else `uvm_error("SVA_L2", "dpi: illegal transition from HACTIVE")

  // ---------------- L3: protocol rules (4) ----------------
  a_dpi_l3_reset_idle : assert property (@(posedge pixelclk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "dpi: state not IDLE during reset")
  a_dpi_l3_no_stuck   : assert property (@(posedge pixelclk) disable iff (!rst_n)
    state == HACTIVE |-> ##[1:1024] (state != HACTIVE))
    else `uvm_error("SVA_L3", "dpi: stuck in HACTIVE")
  a_dpi_l3_full_cycle : cover property (@(posedge pixelclk) disable iff (!rst_n)
    state == VSYNC_PULSE ##1 state == HBLANK);
  a_dpi_l3_active     : cover property (@(posedge pixelclk) disable iff (!rst_n)
    state == HBLANK ##1 state == HACTIVE);

  // ---------------- L4: DPI protocol-specific rules (6) ----------------
  // L4-1: DE is only raised inside the active region
  a_dpi_l4_de_in_hactive : assert property (@(posedge pixelclk)
    disable iff (!rst_n || error_inject)
    de |-> state == HACTIVE)
    else `uvm_error("SVA_L4", "dpi: DE outside active region")
  // L4-2a: HSYNC pulse width is exactly DPI_H_SYNC pixel clocks
  a_dpi_l4_hsync_width : assert property (@(posedge pixelclk)
    disable iff (!rst_n || error_inject)
    $rose(hsync) |-> ##(DPI_H_SYNC) $fell(hsync))
    else `uvm_error("SVA_L4", "dpi: HSYNC pulse width violation")
  // L4-2b: VSYNC pulse width is exactly one line
  a_dpi_l4_vsync_width : assert property (@(posedge pixelclk)
    disable iff (!rst_n || error_inject)
    $rose(vsync) |-> ##(DPI_V_SYNC * DPI_H_TOTAL) $fell(vsync))
    else `uvm_error("SVA_L4", "dpi: VSYNC pulse width violation")
  // L4-3: pixel data only changes while DE is active
  a_dpi_l4_pixel_stable : assert property (@(posedge pixelclk)
    disable iff (!rst_n || error_inject)
    (!de && $past(!de)) |-> $stable(data))
    else `uvm_error("SVA_L4", "dpi: pixel data changed outside DE")
  // L4-4a: a frame begins with VSYNC - no HSYNC before the first VSYNC
  a_dpi_l4_frame_start : assert property (@(posedge pixelclk) disable iff (!rst_n)
    $rose(hsync) |-> (seen_vsync || vsync))
    else `uvm_error("SVA_L4", "dpi: HSYNC before first VSYNC (frame must start with VSYNC)")
  // L4-4b: VSYNC pulse is marked by the VSYNC_PULSE state
  a_dpi_l4_vsync_state : assert property (@(posedge pixelclk) disable iff (!rst_n)
    $rose(vsync) |-> state == VSYNC_PULSE)
    else `uvm_error("SVA_L4", "dpi: VSYNC outside VSYNC_PULSE state")

endmodule
`endif
