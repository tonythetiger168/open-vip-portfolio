// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_coverage.svh -- DPI functional coverage

`ifndef DPI_COVERAGE_SVH
`define DPI_COVERAGE_SVH

class dpi_coverage extends uvm_subscriber #(dpi_transaction);
  `uvm_component_utils(dpi_coverage)

  dpi_transaction tr;

  covergroup cg_protocol;
    cp_pixel : coverpoint tr.pixel {
      bins zero  = {24'h00_0000};
      bins ones  = {24'hFF_FFFF};
      bins red   = {24'hFF_0000};
      bins green = {24'h00_FF00};
      bins blue  = {24'h00_00FF};
      bins other = default;
    }
    cp_hcount : coverpoint tr.hcount iff (!tr.de_error) {
      bins first = {0};
      bins last  = {dpi_defs_pkg::DPI_H_ACTIVE-1};
      bins mid   = {[1:dpi_defs_pkg::DPI_H_ACTIVE-2]};
    }
    cp_vcount : coverpoint tr.vcount iff (!tr.de_error) {
      bins first = {0};
      bins last  = {dpi_defs_pkg::DPI_V_ACTIVE-1};
      bins mid   = {[1:dpi_defs_pkg::DPI_V_ACTIVE-2]};
    }
    cx_corners : cross cp_hcount, cp_vcount {
      bins tl = binsof(cp_hcount.first) && binsof(cp_vcount.first);
      bins tr = binsof(cp_hcount.last)  && binsof(cp_vcount.first);
      bins bl = binsof(cp_hcount.first) && binsof(cp_vcount.last);
      bins br = binsof(cp_hcount.last)  && binsof(cp_vcount.last);
    }
  endgroup

  covergroup cg_fsm with function sample(dpi_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {dpi_defs_pkg::IDLE, dpi_defs_pkg::VSYNC_PULSE,
                           dpi_defs_pkg::HBLANK, dpi_defs_pkg::HACTIVE};
    }
    cp_trans : coverpoint s {
      bins v_to_blank  = (dpi_defs_pkg::VSYNC_PULSE => dpi_defs_pkg::HBLANK);
      bins blank_to_act= (dpi_defs_pkg::HBLANK => dpi_defs_pkg::HACTIVE);
      bins act_to_blank= (dpi_defs_pkg::HACTIVE => dpi_defs_pkg::HBLANK);
      bins frame_wrap  = (dpi_defs_pkg::HBLANK => dpi_defs_pkg::VSYNC_PULSE);
    }
  endgroup

  covergroup cg_error;
    cp_de_error : coverpoint tr.de_error { bins ok = {0}; bins err = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(dpi_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_fsm.sample(t.fsm_state);
    cg_error.sample();
  endfunction
endclass
`endif
