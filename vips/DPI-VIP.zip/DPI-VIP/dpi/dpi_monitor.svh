// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_monitor.svh -- DPI monitor: tracks the raster from hsync/vsync edges,
// counts active pixels per line, reconstructs pixel transactions with their
// (hcount, vcount) position and flags DE raised inside blanking.

`ifndef DPI_MONITOR_SVH
`define DPI_MONITOR_SVH

class dpi_monitor extends uvm_monitor;
  `uvm_component_utils(dpi_monitor)
  virtual dpi_if vif;
  uvm_analysis_port #(dpi_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned de_err_count = 0;

  protected bit hsync_d = 0, vsync_d = 0;
  protected int line_no = -1;      // current line within the frame
  protected int de_cnt  = 0;       // DE-active cycles seen in this line

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual dpi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "dpi virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    dpi_transaction tr;
    forever begin
      @(posedge vif.pixelclk);
      if (!vif.rst_n) begin
        line_no = -1; de_cnt = 0; hsync_d = 0; vsync_d = 0;
        continue;
      end

      // raster tracking from sync edges (vsync wraps the frame)
      if (vif.vsync && !vsync_d)      line_no = 0;
      else if (vif.hsync && !hsync_d) line_no++;
      if (vif.hsync && !hsync_d)      de_cnt = 0;

      if (vif.de) begin
        tr = dpi_transaction::type_id::create("tr");
        tr.pixel  = vif.data;
        tr.hcount = de_cnt[11:0];
        tr.vcount = (line_no - dpi_defs_pkg::DPI_V_OFF >= 0) ?
                    (line_no - dpi_defs_pkg::DPI_V_OFF) : 0;
        tr.fsm_state = vif.state;
        // DE outside the active window is a protocol violation
        if (line_no < dpi_defs_pkg::DPI_V_OFF ||
            line_no >= dpi_defs_pkg::DPI_V_OFF + dpi_defs_pkg::DPI_V_ACTIVE ||
            de_cnt  >= dpi_defs_pkg::DPI_H_ACTIVE) begin
          tr.de_error = 1;
          de_err_count++;
          `uvm_warning("MON", $sformatf("DE in blanking (line=%0d cnt=%0d)", line_no, de_cnt))
        end
        de_cnt++;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end

      hsync_d = vif.hsync; vsync_d = vif.vsync;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("dpi monitor observed %0d pixels, %0d DE-in-blanking errors",
              txn_count, de_err_count), UVM_LOW)
  endfunction
endclass
`endif
