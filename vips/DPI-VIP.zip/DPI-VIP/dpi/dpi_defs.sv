// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_defs.sv -- DPI (display pixel interface) shared types and video timing
//
// VGA-like raster (small frame for simulation):
//   line  : [0..1] HSYNC pulse | [2..3] back porch | [4..19] active (DE=1)
//           | [20..21] front porch                          (22 pixel clocks)
//   frame : line 0 VSYNC pulse | line 1 vblank | lines 2-9 active
//           | line 10 vblank                                (11 lines)

package dpi_defs_pkg;
  typedef enum bit [1:0] {
    IDLE,
    VSYNC_PULSE,
    HBLANK,
    HACTIVE
  } dpi_state_e;

  localparam int DPI_H_ACTIVE = 16;
  localparam int DPI_H_SYNC   = 2;
  localparam int DPI_H_BP     = 2;
  localparam int DPI_H_FP     = 2;
  localparam int DPI_H_TOTAL  = DPI_H_SYNC + DPI_H_BP + DPI_H_ACTIVE + DPI_H_FP; // 22

  localparam int DPI_V_ACTIVE = 8;
  localparam int DPI_V_SYNC   = 1;
  localparam int DPI_V_BP     = 1;
  localparam int DPI_V_FP     = 1;
  localparam int DPI_V_TOTAL  = DPI_V_SYNC + DPI_V_BP + DPI_V_ACTIVE + DPI_V_FP; // 11

  // active region offsets within the raster
  localparam int DPI_H_OFF = DPI_H_SYNC + DPI_H_BP;  // first active cycle = 4
  localparam int DPI_V_OFF = DPI_V_SYNC + DPI_V_BP;  // first active line  = 2

  localparam int DPI_FRAME_PIXELS = DPI_H_ACTIVE * DPI_V_ACTIVE; // 128
endpackage
