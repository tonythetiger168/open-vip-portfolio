// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_transaction.svh -- DPI transaction (one active pixel, or one
// blanking-DE protocol-error event)

`ifndef DPI_TRANSACTION_SVH
`define DPI_TRANSACTION_SVH

class dpi_transaction extends uvm_sequence_item;

  rand bit [23:0] pixel;      // RGB888 pixel data
  rand bit [11:0] hcount;     // pixel column within the active region (0-15)
  rand bit [11:0] vcount;     // pixel line within the active region (0-7)
  rand bit        de_error;   // error injection: DE raised in blanking

  // Observed field (filled by monitor decode)
  dpi_state_e     fsm_state;  // monitor: bus state when observed

  constraint c_pos   { hcount inside {[0:dpi_defs_pkg::DPI_H_ACTIVE-1]};
                       vcount inside {[0:dpi_defs_pkg::DPI_V_ACTIVE-1]}; }
  constraint c_err   { de_error dist { 0 := 9, 1 := 1 }; }

  `uvm_object_utils_begin(dpi_transaction)
    `uvm_field_int(pixel, UVM_ALL_ON)
    `uvm_field_int(hcount, UVM_ALL_ON)
    `uvm_field_int(vcount, UVM_ALL_ON)
    `uvm_field_int(de_error, UVM_ALL_ON)
    `uvm_field_enum(dpi_state_e, fsm_state, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "dpi_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    dpi_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    ok &= comparer.compare_field("hcount", hcount, t.hcount, 12);
    ok &= comparer.compare_field("vcount", vcount, t.vcount, 12);
    return ok;
  endfunction

  function string convert2string();
    string s = $sformatf("DPI pixel=0x%06h @(%0d,%0d)", pixel, hcount, vcount);
    if (de_error) s = {s, " [DE_IN_BLANKING]"};
    return s;
  endfunction
endclass
`endif
