// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_if.sv -- DPI interface (pixelclk / hsync / vsync / de / data[23:0],
// source/sink modports)

interface dpi_if (input logic pixelclk);
  import dpi_defs_pkg::dpi_state_e;

  logic        rst_n;
  logic        hsync;
  logic        vsync;
  logic        de;
  logic [23:0] data;

  dpi_state_e state;

  // Protocol bookkeeping (driven by source, used by monitor/SVA/coverage)
  logic        error_inject;  // DE raised inside blanking on purpose

  modport SOURCE (input  pixelclk, rst_n,
                  output hsync, vsync, de, data, state, error_inject);
  modport SINK   (input  pixelclk, rst_n, hsync, vsync, de, data);
  modport MON    (input  pixelclk, rst_n, hsync, vsync, de, data, state,
                         error_inject);

  clocking drv_cb @(posedge pixelclk);
    input  rst_n;
    output hsync, vsync, de, data;
  endclocking

  clocking mon_cb @(posedge pixelclk);
    input rst_n, hsync, vsync, de, data, state, error_inject;
  endclocking
endinterface
