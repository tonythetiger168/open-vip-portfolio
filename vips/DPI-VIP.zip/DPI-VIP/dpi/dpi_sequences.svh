// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_sequences.svh -- DPI sequence library (pixel streams)

`ifndef DPI_SEQUENCES_SVH
`define DPI_SEQUENCES_SVH

class dpi_base_sequence extends uvm_sequence #(dpi_transaction);
  `uvm_object_utils(dpi_base_sequence)
  int num_txns = 32;
  function new(string name = "dpi_base_sequence"); super.new(name); endfunction
  task body();
    dpi_transaction tr;
    repeat (num_txns) begin
      tr = dpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: exactly one full frame of random pixels
class dpi_full_frame_seq extends dpi_base_sequence;
  `uvm_object_utils(dpi_full_frame_seq)
  function new(string name = "dpi_full_frame_seq"); super.new(name); endfunction
  task body();
    dpi_transaction tr;
    repeat (dpi_defs_pkg::DPI_FRAME_PIXELS) begin
      tr = dpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { de_error == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: solid color frame
class dpi_solid_color_seq extends dpi_base_sequence;
  `uvm_object_utils(dpi_solid_color_seq)
  function new(string name = "dpi_solid_color_seq"); super.new(name); endfunction
  rand bit [23:0] color = 24'h3F_7F_BF;
  task body();
    dpi_transaction tr;
    repeat (num_txns) begin
      tr = dpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { pixel == local::color; de_error == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: gradient frame (pixel value follows the stream index)
class dpi_gradient_seq extends dpi_base_sequence;
  `uvm_object_utils(dpi_gradient_seq)
  function new(string name = "dpi_gradient_seq"); super.new(name); endfunction
  task body();
    dpi_transaction tr;
    for (int i = 0; i < num_txns; i++) begin
      tr = dpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { pixel == {8'h00, i[7:0], 8'(255 - i)};
                                  de_error == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: pixel data corners (all-off / all-on / single channels)
class dpi_corner_seq extends dpi_base_sequence;
  `uvm_object_utils(dpi_corner_seq)
  function new(string name = "dpi_corner_seq"); super.new(name); endfunction
  task body();
    dpi_transaction tr;
    bit [23:0] corners[$] = '{24'h00_0000, 24'hFF_FFFF, 24'hFF_0000,
                              24'h00_FF00, 24'h00_00FF, 24'hAA_5555};
    foreach (corners[i]) begin
      tr = dpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { pixel == corners[i]; de_error == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: DE raised inside the blanking region
class dpi_error_inject_seq extends dpi_base_sequence;
  `uvm_object_utils(dpi_error_inject_seq)
  function new(string name = "dpi_error_inject_seq"); super.new(name); endfunction
  task body();
    dpi_transaction tr;
    repeat (num_txns) begin
      // clean pixel, then a flagged pixel that is replayed as a violation
      tr = dpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { de_error == 0; });
      finish_item(tr);
      tr = dpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { de_error == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: a few pixels issued right after reset release
class dpi_reset_seq extends dpi_base_sequence;
  `uvm_object_utils(dpi_reset_seq)
  function new(string name = "dpi_reset_seq"); super.new(name); endfunction
  task body();
    dpi_transaction tr;
    repeat (4) begin
      tr = dpi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { de_error == 0; });
      finish_item(tr);
    end
  endtask
endclass

class dpi_random_sequence extends dpi_base_sequence;
  `uvm_object_utils(dpi_random_sequence)
  function new(string name = "dpi_random_sequence"); super.new(name); num_txns = 256; endfunction
endclass

// Regression: weighted mix of all directed sequences
class dpi_regression_sequence extends dpi_base_sequence;
  `uvm_object_utils(dpi_regression_sequence)
  function new(string name = "dpi_regression_sequence"); super.new(name); endfunction
  task body();
    dpi_full_frame_seq   ff  = dpi_full_frame_seq::type_id::create("ff");
    dpi_solid_color_seq  sc  = dpi_solid_color_seq::type_id::create("sc");
    dpi_gradient_seq     gr  = dpi_gradient_seq::type_id::create("gr");
    dpi_corner_seq       co  = dpi_corner_seq::type_id::create("co");
    dpi_error_inject_seq err = dpi_error_inject_seq::type_id::create("err");
    sc.num_txns = 64; gr.num_txns = 64; err.num_txns = 16;
    ff.start(m_sequencer); sc.start(m_sequencer); gr.start(m_sequencer);
    co.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
`endif
