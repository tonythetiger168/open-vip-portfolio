// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_driver.svh -- DPI video source driver.
// Runs a VGA-like raster engine (vsync pulse -> vblank -> per-line
// hsync/hblank/hactive) and pulls pixel items from the sequencer for the
// active region. Items flagged with de_error are additionally replayed as
// a blanking-DE protocol violation during the following blanking cycles.

`ifndef DPI_DRIVER_SVH
`define DPI_DRIVER_SVH

class dpi_driver extends uvm_driver #(dpi_transaction);
  `uvm_component_utils(dpi_driver)
  virtual dpi_if vif;
  dpi_config cfg;
  uvm_analysis_port #(dpi_transaction) drv_ap;  // expected items for scoreboard

  protected dpi_transaction err_q[$];           // pending blanking-DE injections

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual dpi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "dpi virtual interface not set")
  endfunction

  function bit is_active(int line, int cyc);
    return line >= dpi_defs_pkg::DPI_V_OFF &&
           line <  dpi_defs_pkg::DPI_V_OFF + dpi_defs_pkg::DPI_V_ACTIVE &&
           cyc  >= dpi_defs_pkg::DPI_H_OFF &&
           cyc  <  dpi_defs_pkg::DPI_H_OFF + dpi_defs_pkg::DPI_H_ACTIVE;
  endfunction

  task run_phase(uvm_phase phase);
    dpi_transaction tr, eslot, epulse;
    vif.drv_cb.hsync <= 1'b0; vif.drv_cb.vsync <= 1'b0;
    vif.drv_cb.de <= 1'b0;    vif.drv_cb.data  <= 24'h0;
    vif.state <= dpi_defs_pkg::IDLE;
    vif.error_inject <= 1'b0;
    wait (vif.rst_n === 1'b1);
    @(vif.drv_cb);
    vif.state <= dpi_defs_pkg::VSYNC_PULSE;
    forever begin
      for (int line = 0; line < dpi_defs_pkg::DPI_V_TOTAL; line++) begin
        for (int cyc = 0; cyc < dpi_defs_pkg::DPI_H_TOTAL; cyc++) begin
          @(vif.drv_cb);
          vif.drv_cb.hsync <= (cyc < dpi_defs_pkg::DPI_H_SYNC);
          vif.drv_cb.vsync <= (line < dpi_defs_pkg::DPI_V_SYNC);
          // bus state follows the raster position
          if (line < dpi_defs_pkg::DPI_V_SYNC)      vif.state <= dpi_defs_pkg::VSYNC_PULSE;
          else if (is_active(line, cyc))            vif.state <= dpi_defs_pkg::HACTIVE;
          else                                      vif.state <= dpi_defs_pkg::HBLANK;

          if (is_active(line, cyc)) begin
            // active pixel: pull the next item from the sequencer
            seq_item_port.get_next_item(tr);
            tr.hcount = cyc - dpi_defs_pkg::DPI_H_OFF;
            tr.vcount = line - dpi_defs_pkg::DPI_V_OFF;
            vif.drv_cb.de   <= 1'b1;
            vif.drv_cb.data <= tr.pixel;
            vif.error_inject <= 1'b0;
            if (tr.de_error) begin
              // expected slot pixel (clean) + remember the error replay
              eslot = dpi_transaction::type_id::create("eslot");
              eslot.copy(tr);
              eslot.de_error = 0;
              drv_ap.write(eslot);
              epulse = dpi_transaction::type_id::create("epulse");
              epulse.copy(tr);
              epulse.de_error = 1;
              err_q.push_back(epulse);
            end else begin
              drv_ap.write(tr);          // broadcast expected pixel
            end
            seq_item_port.item_done();
          end else begin
            vif.drv_cb.de <= 1'b0;
            // blanking: replay pending DE violations (one per cycle)
            if (err_q.size() > 0 && cyc >= dpi_defs_pkg::DPI_H_OFF + dpi_defs_pkg::DPI_H_ACTIVE) begin
              epulse = err_q.pop_front();
              epulse.hcount = cyc - dpi_defs_pkg::DPI_H_OFF;
              epulse.vcount = line - dpi_defs_pkg::DPI_V_OFF;
              vif.drv_cb.de   <= 1'b1;   // protocol violation
              vif.drv_cb.data <= epulse.pixel;
              vif.error_inject <= 1'b1;
              drv_ap.write(epulse);      // expected error event
            end else begin
              vif.error_inject <= 1'b0;
            end
          end
        end
      end
    end
  endtask
endclass
`endif
