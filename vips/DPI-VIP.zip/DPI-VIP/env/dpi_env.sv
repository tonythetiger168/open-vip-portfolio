// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dpi_env.sv -- DPI verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import dpi_defs_pkg::*;
  import dpi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares source-issued (expected) pixels against
  // monitor-decoded (observed) pixels, including raster position.
  class dpi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(dpi_scoreboard)
    uvm_analysis_imp_exp #(dpi_transaction, dpi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(dpi_transaction, dpi_scoreboard) obs_ap;

    dpi_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0, n_error_matches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(dpi_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(dpi_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        dpi_transaction e = exp_q.pop_front();
        dpi_transaction o = obs_q.pop_front();
        if (e.de_error || o.de_error) begin
          // error injection: both sides must flag DE in blanking, same pixel
          if (e.de_error && o.de_error && e.pixel == o.pixel) n_error_matches++;
          else begin
            n_mismatches++;
            `uvm_error("SB", $sformatf("DE-error mismatch exp{%s} obs{%s}",
                       e.convert2string(), o.convert2string()))
          end
        end else if (e.pixel == o.pixel && e.hcount == o.hcount &&
                     e.vcount == o.vcount) begin
          n_matches++;
        end else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("dpi scoreboard: n_matches=%0d n_error_matches=%0d n_mismatches=%0d",
                n_matches, n_error_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
      if (exp_q.size() || obs_q.size())
        `uvm_warning("SB", $sformatf("unmatched transactions left: exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
    endfunction
  endclass

  class dpi_env extends uvm_env;
    `uvm_component_utils(dpi_env)
    dpi_agent      agt;
    dpi_scoreboard sb;
    dpi_checker    chk;
    dpi_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = dpi_agent::type_id::create("agt", this);
      sb  = dpi_scoreboard::type_id::create("sb", this);
      chk = dpi_checker::type_id::create("chk", this);
      cov = dpi_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
