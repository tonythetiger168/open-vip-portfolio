// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_dpi_tb.sv -- self-checking functional test for the MIPI DPI display
// sink model (dpi_display_sink, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py DPI-VIP
//
// Model contract (from tb/top_tb.sv and dpi_defs_pkg):
//   frames of 11 lines x 22 clocks (VSYNC 1 line, HSYNC 2 clocks, DE window
//   16 pixels x 8 lines = 128 pixels). At every VSYNC rising edge the sink
//   checks that the previous frame carried exactly 128 DE cycles, and it
//   flags DE asserted during VSYNC; both are reported with `uvm_error.
//   error_inject marks the current frame as intentionally corrupted, which
//   suppresses its checks. The sink has no outputs: the test checks its
//   counters hierarchically and counts its error reports (dut_errors).

module func_dpi_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int H_TOTAL = 22, V_TOTAL = 11;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, hsync = 1'b0, vsync = 1'b0, de = 1'b0, inj = 1'b0;
  logic [23:0] data = '0;

  always #5 clk = ~clk;

  dpi_display_sink u_dut (
    .pixelclk(clk), .rst_n(rst_n), .hsync(hsync), .vsync(vsync), .de(de),
    .data(data), .error_inject(inj)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one frame; drop=1 removes the last pixel, de_in_vs=1 adds a DE cycle in
  // the VSYNC line, inject pulses error_inject mid-frame
  int pix;
  task automatic frame(input bit drop = 0, input bit de_in_vs = 0, input bit inject = 0);
    pix = 0;
    for (int v = 0; v < V_TOTAL; v++)
      for (int h = 0; h < H_TOTAL; h++) begin
        @(negedge clk);
        vsync = (v < 1);
        hsync = (h < 2);
        de    = (v >= 2 && v < 10 && h >= 4 && h < 20);
        if (drop && v == 9 && h == 19) de = 1'b0;
        if (de_in_vs && v == 0 && h == 10) de = 1'b1;
        inj   = inject && v == 5 && h == 0;
        data  = de ? {8'(v), 8'(h), 8'hA5} : '0;
        pix  += de;
      end
  endtask

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1'b1;

    frame();
    chk(u_dut.started == 1 && u_dut.frame_no == 1, "first VSYNC starts frame tracking");
    chk(pix == 128 && u_dut.pixel_cnt == 128, "a frame carries 16x8 = 128 DE cycles");
    frame();
    frame(1);                         // 127 pixels -> error at next VSYNC
    chk(u_dut.pixel_cnt == 127, "short frame counted as 127 pixels");
    frame(0, 1);                      // DE inside VSYNC -> error now, 129 pixels -> error later
    chk(u_dut.pixel_cnt == 129, "DE during VSYNC is counted as an extra pixel");
    frame(1, 0, 1);                   // corrupted on purpose: checks suppressed
    chk(u_dut.err_seen === 1'b1, "error_inject marks the frame as corrupted");
    frame();
    chk(u_dut.err_seen === 1'b0, "error_inject marking cleared at the next frame");
    frame();
    chk(u_dut.frame_no == 7, "frame counter advances on every VSYNC rising edge");

    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(u_dut.frame_no == 0 && u_dut.pixel_cnt == 0 && u_dut.started == 0, "reset clears frame tracking");
    chk(u_dut.err_seen === 1'b0 && u_dut.vsync_d === 1'b0, "reset clears the error mark and the VSYNC edge detector");
    rst_n = 1'b1;
    frame();
    frame();
    chk(u_dut.frame_no == 2 && u_dut.pixel_cnt == 128 && u_dut.started == 1,
        "frame tracking restarts after reset (clean frames, no error)");

    // expected DUT error reports: short frame, DE in VSYNC, long frame
    if (fails == 0) $display("FUNC_PASS checks=%0d dut_errors=3", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
