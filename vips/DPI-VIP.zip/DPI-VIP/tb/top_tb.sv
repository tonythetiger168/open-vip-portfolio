// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- DPI testbench top with a functional display sink DUT

`ifndef DPI_TB_SV
`define DPI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import dpi_defs_pkg::*;
import dpi_pkg::*;
import dpi_test_pkg::*;

module top_tb;
  logic pixelclk = 0;
  always #5ns pixelclk = ~pixelclk;

  dpi_if vif(pixelclk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  dpi_display_sink dut (
    .pixelclk    (vif.pixelclk),
    .rst_n       (vif.rst_n),
    .hsync       (vif.hsync),
    .vsync       (vif.vsync),
    .de          (vif.de),
    .data        (vif.data),
    .error_inject(vif.error_inject)
  );

  initial begin
    uvm_config_db#(virtual dpi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional DPI display sink:
//  - counts DE-active pixels per frame and checks the count against the
//    expected frame geometry at every VSYNC
//  - flags DE observed during the VSYNC pulse itself
//  - frames containing an injected violation are reported, not failed
module dpi_display_sink
(
  input  logic        pixelclk,
  input  logic        rst_n,
  input  logic        hsync,
  input  logic        vsync,
  input  logic        de,
  input  logic [23:0] data,
  input  logic        error_inject
);
  import dpi_defs_pkg::*;

  int unsigned pixel_cnt = 0;
  int unsigned frame_no  = 0;
  bit          vsync_d   = 0;
  bit          err_seen  = 0;
  bit          started   = 0;

  always @(posedge pixelclk or negedge rst_n) begin
    if (!rst_n) begin
      pixel_cnt <= 0; frame_no <= 0; vsync_d <= 0;
      err_seen <= 0; started <= 0;
    end else begin
      vsync_d <= vsync;
      if (error_inject) err_seen <= 1;
      if (de) begin
        pixel_cnt <= pixel_cnt + 1;
        if (vsync && !err_seen)
          `uvm_error("DUT", "DPI sink: DE active during VSYNC pulse")
      end
      if (vsync && !vsync_d) begin
        if (started && !err_seen && pixel_cnt != DPI_FRAME_PIXELS)
          `uvm_error("DUT", $sformatf("DPI sink: frame %0d had %0d pixels, expected %0d",
                     frame_no, pixel_cnt, DPI_FRAME_PIXELS))
        if (started && err_seen)
          `uvm_info("DUT", $sformatf("DPI sink: frame %0d had injected violation (%0d DE cycles)",
                    frame_no, pixel_cnt), UVM_MEDIUM)
        pixel_cnt <= 0;
        err_seen  <= 0;
        started   <= 1;
        frame_no  <= frame_no + 1;
      end
    end
  end
endmodule
`endif
