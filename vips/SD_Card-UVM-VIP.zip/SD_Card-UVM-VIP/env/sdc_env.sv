// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_env.sv -- SDC environment: reference-model scoreboard, checker, coverage

package sdc_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sdc_defs_pkg::*;
  import sdc_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class sdc_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(sdc_scoreboard)
    uvm_analysis_imp_exp #(sdc_transaction, sdc_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(sdc_transaction, sdc_scoreboard) obs_ap;

    sdc_config cfg;
    sdc_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // the card (scoreboard copy), kept across items
    bit [255:0] mem [16];
    bit         minit = 0;
    int         cst = 0, polls = 0, dm = 0, rdd = 0, tokd = 0, tokn = 0, busyn = 0, dcnt = 0;
    bit         app = 0, crc_e = 0, ill = 0, ccs = 0;
    bit [15:0]  rca = 0;
    int         rxc = 0, txd = 0, txn = 0;
    bit [47:0]  rxs = 0;
    bit [135:0] txs = 0;
    bit [3:0]   blk = 0;
    bit [255:0] buff = 0;
    bit [15:0]  c [4], rc [4];
    bit [4:0]   tok = 0;
    bit         o_cmd = 0, o_cmd_oe = 0;
    bit [3:0]   o_dat = 0, o_dat_oe = 0;
    localparam int NCR = 2, NAC = 2, BUSY = 4, POLLS = 1;
    localparam bit HC = 1;
    localparam bit [15:0] RCA = 16'h1234;

    function void send(bit [135:0] fr, int n);
      txs = fr; txn = n; txd = NCR - 1;
    endfunction
    function bit [31:0] r1st(int st, bit appc);
      return {8'h00, crc_e, ill, 9'h000, 4'(st), 1'b1, 2'b00, appc, 5'h00};
    endfunction
    function void frame(bit [47:0] f);
      bit [5:0] i = f[45:40];
      bit [31:0] a = f[39:8];
      int st = cst;
      bit wa = app;
      if (sdc_crc7({80'h0, f[47:8]}, 40) != f[7:1] || !f[0] || !f[46]) begin crc_e = 1; return; end
      app = 0;
      if (i == 0) begin cst = 0; polls = 0; ccs = 0; rca = 0; dm = 0; end
      else if (i == 8 && cst == 0) begin
        if (a[11:8] == 4'h1) send({sdc_frame(6'd8, {20'h0, a[11:0]}, 1'b0), 88'h0}, 48);
      end else if (i == 55 && cst != 2) begin
        app = 1; send({sdc_frame(6'd55, r1st(st, 1'b1), 1'b0), 88'h0}, 48); crc_e = 0; ill = 0;
      end else if (i == 41 && wa && (cst == 0 || cst == 1)) begin
        bit rdy = polls >= POLLS;
        if (polls != 15) polls++;
        if (rdy) begin cst = 1; ccs = HC && a[30]; end
        send({2'b00, 6'h3F, rdy, rdy && HC && a[30], 6'h00, 24'hFF8000, 8'hFF, 88'h0}, 48);
      end else if (i == 2 && cst == 1) begin
        bit [127:0] cid = {SDC_CID_BODY, sdc_crc7(SDC_CID_BODY, 120), 1'b1};
        cst = 2; send({2'b00, 6'h3F, cid[127:1], 1'b1}, 136);
      end else if (i == 3 && (cst == 2 || cst == 3)) begin
        cst = 3; rca = RCA;
        send({sdc_frame(6'd3, {RCA, crc_e, ill, 1'b0, 4'(st), 1'b1, 2'b00, 1'b0, 5'h00}, 1'b0), 88'h0}, 48);
        crc_e = 0; ill = 0;
      end else if (i == 7 && (cst == 3 || cst == 4)) begin
        if (a[31:16] == rca && rca != 0) begin
          cst = 4; send({sdc_frame(6'd7, r1st(st, 1'b0), 1'b0), 88'h0}, 48); crc_e = 0; ill = 0;
        end else if (cst == 4) cst = 3;
      end else if (i == 13 && (cst == 3 || cst == 4)) begin
        if (a[31:16] == rca) begin send({sdc_frame(6'd13, r1st(st, 1'b0), 1'b0), 88'h0}, 48); crc_e = 0; ill = 0; end
      end else if ((i == 17 || i == 24) && cst == 4) begin
        send({sdc_frame(i, r1st(st, 1'b0), 1'b0), 88'h0}, 48); crc_e = 0; ill = 0;
        blk = ccs ? a[3:0] : a[8:5];
        if (i == 17) begin dm = 7; buff = mem[blk]; end
        else dm = 1;
      end else ill = 1;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(sdc_config)::get(this, "", "cfg", cfg))
        cfg = sdc_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(sdc_transaction t);
      if (!minit) begin for (int b = 0; b < 16; b++) mem[b] = sdc_init_blk(b); minit = 1; end
      t.so.delete();
      foreach (t.mo[i]) begin
        bit cl;
        bit [3:0] dl;
        t.so.push_back({o_cmd_oe, o_cmd & o_cmd_oe, o_dat_oe, o_dat & o_dat_oe});
        cl = t.mo[i][6] ? t.mo[i][5] : (o_cmd_oe ? o_cmd : 1'b1);
        for (int l = 0; l < 4; l++) dl[l] = t.mo[i][4] ? t.mo[i][l] : (o_dat_oe[l] ? o_dat[l] : 1'b1);
        // command receiver (not while a response goes out)
        if (txd == 0 && txn == 0) begin
          if (rxc == 0) begin if (!cl) begin rxc = 1; rxs = 0; end end
          else begin
            rxs = {rxs[46:0], cl}; rxc++;
            if (rxc == 48) begin rxc = 0; frame(rxs); end
          end
        end
        // write block receiver
        case (dm)
          1: if (dl == 4'h0) begin dm = 2; dcnt = 0; c = '{0, 0, 0, 0}; end
          2: begin
               buff = {buff[251:0], dl};
               for (int l = 0; l < 4; l++) c[l] = sdc_crc16(c[l], dl[l]);
               if (++dcnt == 64) begin dm = 3; dcnt = 0; rc = '{0, 0, 0, 0}; end
             end
          3: begin
               for (int l = 0; l < 4; l++) rc[l] = {rc[l][14:0], dl[l]};
               if (++dcnt == 16) dm = 4;
             end
          4: begin
               bit good = dl == 4'hF && rc[0] == c[0] && rc[1] == c[1] && rc[2] == c[2] && rc[3] == c[3];
               if (good) mem[blk] = buff;
               tok = good ? 5'b0_010_1 : 5'b0_101_1;
               dm = 5; tokd = 1; tokn = 5; busyn = good ? BUSY : 0;
             end
          default: ;
        endcase
        // outputs for the next period
        if (txd > 0) begin txd--; o_cmd_oe = 0; end
        else if (txn > 0) begin
          o_cmd_oe = 1; o_cmd = txs[135]; txs = txs << 1; txn--;
          if (txn == 0 && dm == 7) begin dm = 8; rdd = NAC; end
        end else o_cmd_oe = 0;
        case (dm)
          5: if (tokd > 0) begin tokd--; o_dat_oe = 0; end
             else if (tokn > 0) begin o_dat_oe = 4'b0001; o_dat[0] = tok[4]; tok = tok << 1; tokn--; end
             else if (busyn > 0) begin o_dat_oe = 4'b0001; o_dat[0] = 1'b0; busyn--; end
             else begin o_dat_oe = 0; dm = 0; end
          8: if (rdd > 0) begin rdd--; o_dat_oe = 0; end
             else begin o_dat_oe = 4'hF; o_dat = 4'h0; dm = 9; dcnt = 0; c = '{0, 0, 0, 0}; end
          9: begin
               bit [3:0] v = buff[255 - 4 * dcnt -: 4];
               o_dat_oe = 4'hF; o_dat = v;
               for (int l = 0; l < 4; l++) c[l] = sdc_crc16(c[l], v[l]);
               if (++dcnt == 64) begin dm = 10; dcnt = 0; end
             end
          10: begin
                o_dat_oe = 4'hF; o_dat = {c[3][15], c[2][15], c[1][15], c[0][15]};
                for (int l = 0; l < 4; l++) c[l] = c[l] << 1;
                if (++dcnt == 16) dm = 11;
              end
          11: begin o_dat_oe = 4'hF; o_dat = 4'hF; dm = 12; end
          12: begin o_dat_oe = 0; dm = 0; end
          default: o_dat_oe = 0;
        endcase
      end
    endfunction

    function void write_exp(sdc_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(sdc_transaction t);
      sdc_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        sdc_transaction e = exp_q.pop_front();
        sdc_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("sdc scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class sdc_env extends uvm_env;
    `uvm_component_utils(sdc_env)
    sdc_agent      agt;
    sdc_scoreboard sb;
    sdc_checker    chk;
    sdc_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = sdc_agent     ::type_id::create("agt", this);
      sb  = sdc_scoreboard::type_id::create("sb",  this);
      chk = sdc_checker   ::type_id::create("chk", this);
      cov = sdc_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
