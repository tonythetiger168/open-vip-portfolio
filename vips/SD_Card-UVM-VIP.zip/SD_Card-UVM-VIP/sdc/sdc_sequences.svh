// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_sequences.svh -- SDC sequences

// Random traffic: cfg.num_items constrained-random items.
class sdc_base_sequence extends uvm_sequence #(sdc_transaction);
  `uvm_object_utils(sdc_base_sequence)
  sdc_config cfg;

  function new(string name = "sdc_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = sdc_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "sdc_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class sdc_directed_sequence extends uvm_sequence #(sdc_transaction);
  `uvm_object_utils(sdc_directed_sequence)
  sdc_config cfg;

  function new(string name = "sdc_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function sdc_transaction item();
    item = sdc_transaction::type_id::create("req");
  endfunction

  task send(sdc_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    sdc_transaction t;
    // identification, both addressing modes, transfers, every error path, reset in transfer state
    t = item(); t.set(13); send(t);            // illegal in idle
    t = item(); t.set(0); send(t);
    t = item(); t.set(2); send(t);             // VHS 2: no response
    t = item(); t.set(1); send(t);
    t = item(); t.set(4); send(t);             // ACMD41 without CMD55: illegal
    t = item(); t.set(3); send(t);             // reports ILLEGAL_COMMAND
    t = item(); t.set(4); send(t);             // busy
    t = item(); t.set(3); send(t);
    t = item(); t.set(4); send(t);             // ready, CCS 1
    t = item(); t.set(6); send(t);
    t = item(); t.set(7); send(t);
    t = item(); t.set(14); send(t);            // bad CRC7
    t = item(); t.set(10); send(t);            // reports COM_CRC_ERROR
    t = item(); t.set(8); send(t);
    for (int b = 0; b < 4; b++) begin
      t = item(); t.set(13, b); send(t);
      t = item(); t.set(11, b, 32'h1000 + b); send(t);
      t = item(); t.set(13, b); send(t);
    end
    t = item(); t.set(12, 5, 32'h77); send(t);
    t = item(); t.set(13, 5); send(t);
    t = item(); t.set(15); send(t);
    t = item(); t.set(10); send(t);
    t = item(); t.set(17); send(t);
    t = item(); t.set(9); send(t);             // deselect
    t = item(); t.set(13); send(t);            // illegal in stby
    t = item(); t.set(8); send(t);
    t = item(); t.set(16); send(t);
    t = item(); t.set(8); send(t);
    t = item(); t.set(0); send(t);             // reset from transfer state
    t = item(); t.set(1); send(t);
    t = item(); t.set(3); send(t);
    t = item(); t.set(5); send(t);             // no HCS: byte addressing
    t = item(); t.set(3); send(t);
    t = item(); t.set(5); send(t);
    t = item(); t.set(6); send(t);
    t = item(); t.set(7); send(t);
    t = item(); t.set(7); send(t);             // CMD3 again in stby
    t = item(); t.set(8); send(t);
    t = item(); t.set(11, 9, 32'h55); send(t);
    t = item(); t.set(13, 9); send(t);
    t = item(); t.set(13, 1); send(t);
  endtask
endclass
