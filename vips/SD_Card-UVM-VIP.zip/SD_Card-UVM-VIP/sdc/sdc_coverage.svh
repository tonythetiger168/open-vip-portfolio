// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_coverage.svh -- SDC functional coverage

class sdc_coverage extends uvm_subscriber #(sdc_transaction);
  `uvm_component_utils(sdc_coverage)
  sdc_config cfg;
  sdc_transaction tr;

  covergroup sdc_cg;
    cp_idx  : coverpoint tr.idx { bins c0 = {0}; bins c2 = {2}; bins c3 = {3}; bins c7 = {7}; bins c8 = {8}; bins c13 = {13};
                                  bins c17 = {17}; bins c24 = {24}; bins c41 = {41}; bins c55 = {55}; bins other = {6}; }
    cp_got  : coverpoint tr.got;
    cp_len  : coverpoint tr.mo.size() { bins cmd = {[100:200]}; bins r2 = {[201:260]}; bins blk = {[261:500]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    sdc_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(sdc_config)::get(this, "", "cfg", cfg))
      cfg = sdc_config::type_id::create("cfg");
  endfunction

  function void write(sdc_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    sdc_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SDC coverage: %0.1f%%", sdc_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
