// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_monitor.svh -- SDC monitor: host and card drive (masked by their enables) at every sd_clk rising edge; sd_clk stopped for more than half of cfg.gap clocks ends the item

class sdc_monitor extends uvm_monitor;
  `uvm_component_utils(sdc_monitor)

  virtual sdc_if vif;
  uvm_analysis_port #(sdc_transaction) ap;
  sdc_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual sdc_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sdc: virtual interface not set")
    if (!uvm_config_db#(sdc_config)::get(this, "", "cfg", cfg))
      cfg = sdc_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        sdc_transaction t;
        bit pc;
        int q = 0;
        pc = vif.mon_cb.sd_clk;
        @(vif.mon_cb);
        while (!(pc === 1'b0 && vif.mon_cb.sd_clk === 1'b1)) begin pc = vif.mon_cb.sd_clk; @(vif.mon_cb); end
        t = sdc_transaction::type_id::create("t");
        forever begin
          if (pc === 1'b0 && vif.mon_cb.sd_clk === 1'b1) begin
            t.mo.push_back({vif.mon_cb.cmd_m_oe, vif.mon_cb.cmd_m & vif.mon_cb.cmd_m_oe, vif.mon_cb.dat_m_oe,
                            vif.mon_cb.dat_m & {4{vif.mon_cb.dat_m_oe}}});
            t.so.push_back({vif.mon_cb.cmd_s_oe, vif.mon_cb.cmd_s & vif.mon_cb.cmd_s_oe, vif.mon_cb.dat_s_oe,
                            vif.mon_cb.dat_s & vif.mon_cb.dat_s_oe});
            q = 0;
          end else if (++q > cfg.gap / 2) break;
          pc = vif.mon_cb.sd_clk;
          @(vif.mon_cb);
        end
        publish(t);
      end
    end
  endtask

  function void publish(sdc_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
