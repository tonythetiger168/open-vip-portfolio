// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_transaction.svh -- SDC transaction

class sdc_transaction extends uvm_sequence_item;
  `uvm_object_utils(sdc_transaction)

  // request (driven by the agent)
  bit [6:0] mo[$];
  // response (returned by the DUT)
  bit [9:0] so[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [3:0] blk;
  rand bit [31:0] seed;
  bit [5:0] idx;
  bit [31:0] arg;
  bit got;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "sdc_transaction"); super.new(name); endfunction

  // kind: 0 CMD0, 1 CMD8 (VHS 1), 2 CMD8 (VHS 2), 3 CMD55, 4 ACMD41 with HCS,
  // 5 ACMD41 without HCS, 6 CMD2, 7 CMD3, 8 CMD7 (RCA), 9 CMD7 (other RCA),
  // 10 CMD13, 11 CMD24, 12 CMD24 with a bad CRC16, 13 CMD17, 14 CMD13 with a
  // bad CRC7, 15 CMD6 (illegal), 16 CMD7 (RCA 0), 17 CMD13 (other RCA),
  // 18-31 CMD24 / CMD17 / CMD13 / CMD55 mix
  function void set(int k, int b = 0, bit [31:0] s = 32'h1); kind = k; blk = b; seed = s; endfunction
  function bit [47:0] cmd(bit [15:0] rca, bit hc);
    bit [31:0] ba = hc ? {28'h0, blk} : {23'h0, blk, 5'h0};
    int k = kind;
    if (k >= 18) k = (k % 4 == 0) ? 11 : (k % 4 == 1) ? 13 : (k % 4 == 2) ? 10 : 3;
    case (k)
      0: begin idx = 0; arg = 0; end
      1: begin idx = 8; arg = 32'h0000_01AA; end
      2: begin idx = 8; arg = 32'h0000_02AA; end
      3: begin idx = 55; arg = {rca, 16'h0}; end
      4: begin idx = 41; arg = 32'h40FF_8000; end
      5: begin idx = 41; arg = 32'h00FF_8000; end
      6: begin idx = 2; arg = 0; end
      7: begin idx = 3; arg = 0; end
      8: begin idx = 7; arg = {rca, 16'h0}; end
      9: begin idx = 7; arg = {rca ^ 16'h0101, 16'h0}; end
      10, 14: begin idx = 13; arg = {rca, 16'h0}; end
      11, 12: begin idx = 24; arg = ba; end
      13: begin idx = 17; arg = ba; end
      15: begin idx = 6; arg = 0; end
      16: begin idx = 7; arg = 0; end
      default: begin idx = 13; arg = {rca ^ 16'h8000, 16'h0}; end
    endcase
    if (k == 14) return sdc_frame(idx, arg) ^ 48'h4;
    return sdc_frame(idx, arg);
  endfunction
  function bit [255:0] wdata();
    bit [31:0] x = seed | 1;
    bit [255:0] v;
    for (int i = 0; i < 8; i++) begin x ^= x << 13; x ^= x >> 17; x ^= x << 5; v[32 * i +: 32] = x; end
    return v;
  endfunction
  function bit bad_crc(); return kind == 12; endfunction

  function void do_copy(uvm_object rhs);
    sdc_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mo = rhs_.mo;
    so = rhs_.so;
    kind = rhs_.kind;
    blk = rhs_.blk;
    seed = rhs_.seed;
    idx = rhs_.idx;
    arg = rhs_.arg;
    got = rhs_.got;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sdc_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(sdc_transaction rhs_);
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    return 1;
  endfunction

  function string qstr_mo();
    string s = $sformatf("[%0d]{", mo.size());
    foreach (mo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", mo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SDC{tag=%0d mo=%s so=%s}", tag, qstr_mo(), qstr_so());
  endfunction
endclass
