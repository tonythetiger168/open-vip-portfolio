// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_defs.sv -- SDC shared type definitions

package sdc_defs_pkg;

  typedef enum bit [1:0] {SDC_OK, SDC_ERR} sdc_status_e;

  function automatic bit [6:0] sdc_crc7(bit [119:0] d, int n);   // over d[n-1:0], MSB first
    bit [6:0] c = 0;
    for (int i = n - 1; i >= 0; i--) begin
      bit fb = d[i] ^ c[6];
      c = {c[5:0], 1'b0};
      if (fb) c ^= 7'h09;
    end
    return c;
  endfunction
  function automatic bit [15:0] sdc_crc16(bit [15:0] c, bit b);
    bit fb = b ^ c[15];
    return {c[14:0], 1'b0} ^ (fb ? 16'h1021 : 16'h0000);
  endfunction
  function automatic bit [47:0] sdc_frame(bit [5:0] i, bit [31:0] a, bit tx = 1'b1);
    bit [39:0] b = {1'b0, tx, i, a};
    return {b, sdc_crc7({80'h0, b}, 40), 1'b1};
  endfunction
  function automatic bit [255:0] sdc_init_blk(int b);
    bit [255:0] v;
    for (int i = 0; i < 32; i++) v[255 - 8 * i -: 8] = 8'((16 * b + i) ^ 8'h3C);
    return v;
  endfunction
  localparam bit [119:0] SDC_CID_BODY = 120'h1D4F565344433110123456780016A0;

endpackage
