// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_compliance_checker.sv -- SDC concurrent assertion checks (bindable)

module sdc_compliance_checker
  (input logic clk, input logic rst_n, input logic sd_clk, input logic cmd_m, input logic cmd_m_oe, input logic [3:0] dat_m, input logic dat_m_oe, input logic cmd_s, input logic cmd_s_oe, input logic [3:0] dat_s, input logic [3:0] dat_s_oe);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({sd_clk, cmd_m_oe, dat_m_oe, cmd_s_oe, dat_s_oe}))
    else $error("SDC: X on sd_clk or an enable");
  assert property (@(posedge clk) disable iff (!rst_n) !(cmd_m_oe && cmd_s_oe))
    else $error("SDC: host and card drive CMD together");
  assert property (@(posedge clk) disable iff (!rst_n) !(dat_m_oe && dat_s_oe != 4'h0))
    else $error("SDC: host and card drive DAT together");
  assert property (@(posedge clk) disable iff (!rst_n) $changed({cmd_s_oe, cmd_s, dat_s_oe, dat_s}) |-> !sd_clk)
    else $error("SDC: card output changed while sd_clk is high");
  cover property (@(posedge clk) disable iff (!rst_n) dat_s_oe == 4'b0001 && !dat_s[0]);
endmodule
