// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_if.sv -- SDC interface

interface sdc_if (input logic clk);
  logic rst_n;

  logic sd_clk;
  logic cmd_m;
  logic cmd_m_oe;
  logic [3:0] dat_m;
  logic dat_m_oe;
  logic cmd_s;
  logic cmd_s_oe;
  logic [3:0] dat_s;
  logic [3:0] dat_s_oe;

  modport DUT (input clk, rst_n, input sd_clk, input cmd_m, input cmd_m_oe, input dat_m, input dat_m_oe, output cmd_s, output cmd_s_oe, output dat_s, output dat_s_oe);
  modport MON (input clk, rst_n, sd_clk, cmd_m, cmd_m_oe, dat_m, dat_m_oe, cmd_s, cmd_s_oe, dat_s, dat_s_oe);

  clocking drv_cb @(posedge clk);
    input rst_n, cmd_s, cmd_s_oe, dat_s, dat_s_oe;
    inout sd_clk, cmd_m, cmd_m_oe, dat_m, dat_m_oe;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, sd_clk, cmd_m, cmd_m_oe, dat_m, dat_m_oe, cmd_s, cmd_s_oe, dat_s, dat_s_oe;
  endclocking
endinterface
