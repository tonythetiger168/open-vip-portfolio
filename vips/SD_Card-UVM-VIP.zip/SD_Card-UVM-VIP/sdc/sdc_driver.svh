// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_driver.svh -- SDC driver: one command per item with sd_clk running: 4 idle clocks, the 48-bit command, a response hunt of up to 64 clocks and the response; for CMD24 the block (start, 64 nibbles, CRC16s, end), the CRC status token and the busy wait; for CMD17 the block hunt and the block; then 8 idle clocks and sd_clk stopped for cfg.gap clocks

class sdc_driver extends uvm_driver #(sdc_transaction);
  `uvm_component_utils(sdc_driver)

  uvm_analysis_port #(sdc_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual sdc_if vif;
  sdc_config cfg;

  bit [15:0]      rca = 0;
  bit             hc = 0;
  sdc_transaction cur;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sdc_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sdc: virtual interface not set")
    if (!uvm_config_db#(sdc_config)::get(this, "", "cfg", cfg))
      cfg = sdc_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    sdc_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.sd_clk   <= 1'b1;
    vif.drv_cb.cmd_m    <= 1'b0;
    vif.drv_cb.cmd_m_oe <= 1'b0;
    vif.drv_cb.dat_m    <= 4'h0;
    vif.drv_cb.dat_m_oe <= 1'b0;
  endtask

  task drive_item(sdc_transaction t);
    bit cl;
    bit [3:0] dl;
    bit [47:0] f;
    bit [135:0] r = 0;
    int k;
    cur = t;
    t.mo.delete();
    f = t.cmd(rca, hc);
    t.got = 0;
    @(vif.drv_cb);
    repeat (4) idle1(cl, dl);
    for (int i = 47; i >= 0; i--) clk1(1'b1, f[i], 1'b0, 4'h0, cl, dl);
    k = 0;
    while (k < 64 && !t.got) begin idle1(cl, dl); if (!cl) t.got = 1; k++; end
    if (t.got) begin
      int len = (t.idx == 2) ? 136 : 48;
      for (int i = 1; i < len; i++) begin idle1(cl, dl); r = {r[134:0], cl}; end
      if (t.idx == 3) rca = r[39:24];
      if (t.idx == 41) hc = r[38];
      if (t.idx == 0) begin rca = 0; hc = 0; end
    end
    if (t.idx == 0) begin rca = 0; hc = 0; end
    if (t.got && t.idx == 24) begin
      bit [255:0] w = t.wdata();
      bit [15:0] c [4] = '{0, 0, 0, 0};
      idle1(cl, dl); idle1(cl, dl);
      clk1(1'b0, 1'b0, 1'b1, 4'hF, cl, dl);
      clk1(1'b0, 1'b0, 1'b1, 4'h0, cl, dl);
      for (int n = 0; n < 64; n++) begin
        bit [3:0] v = w[255 - 4 * n -: 4];
        for (int l = 0; l < 4; l++) c[l] = sdc_crc16(c[l], v[l]);
        clk1(1'b0, 1'b0, 1'b1, v, cl, dl);
      end
      if (t.bad_crc()) c[t.seed[1:0]][t.seed[5:2]] ^= 1'b1;
      for (int n = 15; n >= 0; n--) clk1(1'b0, 1'b0, 1'b1, {c[3][n], c[2][n], c[1][n], c[0][n]}, cl, dl);
      clk1(1'b0, 1'b0, 1'b1, 4'hF, cl, dl);
      k = 0;
      do begin idle1(cl, dl); k++; end while (dl[0] && k < 64);
      if (!dl[0]) begin
        repeat (4) idle1(cl, dl);
        k = 0;
        do begin idle1(cl, dl); k++; end while (!dl[0] && k < 256);
      end
    end
    if (t.got && t.idx == 17) begin
      k = 0;
      do begin idle1(cl, dl); k++; end while (dl != 4'h0 && k < 64);
      if (dl == 4'h0) repeat (64 + 16 + 1) idle1(cl, dl);
    end
    repeat (8) idle1(cl, dl);
    repeat (cfg.gap) @(vif.drv_cb);
  endtask

  // one sd_clk period: outputs at the falling edge, the lines at the rising edge
  task automatic clk1(bit co, bit c, bit doe, bit [3:0] d, output bit cl, output bit [3:0] dl);
    vif.drv_cb.sd_clk   <= 1'b0;
    vif.drv_cb.cmd_m_oe <= co; vif.drv_cb.cmd_m <= c;
    vif.drv_cb.dat_m_oe <= doe; vif.drv_cb.dat_m <= d;
    repeat (cfg.half) @(vif.drv_cb);
    vif.drv_cb.sd_clk <= 1'b1;
    cl = co ? c : (vif.drv_cb.cmd_s_oe ? vif.drv_cb.cmd_s : 1'b1);
    for (int i = 0; i < 4; i++) dl[i] = doe ? d[i] : (vif.drv_cb.dat_s_oe[i] ? vif.drv_cb.dat_s[i] : 1'b1);
    cur.mo.push_back({co, c & co, doe, d & {4{doe}}});
    repeat (cfg.half) @(vif.drv_cb);
  endtask
  task automatic idle1(output bit cl, output bit [3:0] dl);
    clk1(1'b0, 1'b0, 1'b0, 4'h0, cl, dl);
  endtask
endclass
