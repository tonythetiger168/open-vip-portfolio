// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sdc_pkg.sv -- SDC UVM VIP package

package sdc_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import sdc_defs_pkg::*;
  export sdc_defs_pkg::*;

  `include "sdc_transaction.svh"
  `include "sdc_config.svh"
  `include "sdc_sequencer.svh"
  `include "sdc_driver.svh"
  `include "sdc_monitor.svh"
  `include "sdc_agent.svh"
  `include "sdc_sequences.svh"
  `include "sdc_checker.svh"
  `include "sdc_coverage.svh"
endpackage
