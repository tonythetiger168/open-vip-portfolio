// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SDC DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened sdc_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b1;
  initial #1 rst_n = 1'b0;      // a falling edge: the card has no clock to see a level reset
  logic sd_clk = 1'b1, cmd_m = 1'b0, cmd_m_oe = 1'b0, dat_m_oe = 1'b0;
  logic [3:0] dat_m = 4'h0;
  wire cmd_s, cmd_s_oe;
  wire [3:0] dat_s, dat_s_oe;

  always #5 clk = ~clk;

  sdc_model u_dut (.clk(clk), .rst_n(rst_n), .sd_clk(sd_clk), .cmd_m(cmd_m), .cmd_m_oe(cmd_m_oe), .dat_m(dat_m),
                   .dat_m_oe(dat_m_oe), .cmd_s(cmd_s), .cmd_s_oe(cmd_s_oe), .dat_s(dat_s), .dat_s_oe(dat_s_oe));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [6:0] crc7(input logic [119:0] d, input integer n);
    logic [6:0] c;
    logic fb;
    c = 7'h00;
    for (int i = 119; i >= 0; i--) if (i < n) begin fb = d[i] ^ c[6]; c = {c[5:0], 1'b0}; if (fb) c = c ^ 7'h09; end
    crc7 = c;
  endfunction
  function automatic logic [15:0] crc16(input logic [15:0] c, input logic b);
    crc16 = {c[14:0], 1'b0} ^ ((b ^ c[15]) ? 16'h1021 : 16'h0000);
  endfunction

  logic cl;
  logic [3:0] dl;
  integer conflict = 0;
  task automatic clk1(input logic co, input logic c, input logic doe, input logic [3:0] d);
    @(negedge clk); sd_clk = 0; cmd_m_oe = co; cmd_m = c; dat_m_oe = doe; dat_m = d;
    @(negedge clk);
    sd_clk = 1;
    cl = co ? c : (cmd_s_oe ? cmd_s : 1'b1);
    for (int i = 0; i < 4; i++) dl[i] = doe ? d[i] : (dat_s_oe[i] ? dat_s[i] : 1'b1);
    if ((co && cmd_s_oe) || (doe && dat_s_oe != 0)) conflict = conflict + 1;
    @(negedge clk);
  endtask
  task automatic idle1(); clk1(0, 0, 0, 4'h0); endtask
  logic [135:0] r;
  integer ncr, rlen_got;
  logic got;
  // command; response hunted for 64 clocks, len bits
  task automatic cmd(input logic [5:0] i, input logic [31:0] a, input integer len = 48, input logic badcrc = 0,
                     input integer trail = 4);
    logic [39:0] b;
    logic [47:0] f;
    integer k;
    b = {2'b01, i, a}; f = {b, crc7({80'h0, b}, 40), 1'b1};
    if (badcrc) f[3] = ~f[3];
    repeat (2) idle1();
    for (int j = 47; j >= 0; j--) clk1(1, f[j], 0, 4'h0);
    got = 0; k = 0; r = 0;
    while (k < 64 && !got) begin idle1(); k = k + 1; if (!cl) got = 1; end
    ncr = k;
    if (got) for (int j = 1; j < len; j++) begin idle1(); r = {r[134:0], cl}; end
    repeat (trail) idle1();
  endtask
  function automatic logic r48_ok(input logic [5:0] i);
    r48_ok = r[46] == 1'b0 && r[45:40] == i && r[0] == 1'b1 && crc7({80'h0, 1'b0, r[46:8]}, 40) == r[7:1];
  endfunction
  logic [255:0] wb, rb;
  logic [3:0] tok;
  integer busy, tokk;
  localparam int TOKK = 2;
  task automatic wr_blk(input logic bad = 0);
    logic [15:0] c [0:3];
    logic [3:0] v;
    integer k;
    for (int l = 0; l < 4; l++) c[l] = 16'h0;
    clk1(0, 0, 1, 4'hF); clk1(0, 0, 1, 4'h0);
    for (int n = 0; n < 64; n++) begin
      v = wb[255 - 4 * n -: 4];
      for (int l = 0; l < 4; l++) c[l] = crc16(c[l], v[l]);
      clk1(0, 0, 1, v);
    end
    if (bad) c[2][7] = ~c[2][7];
    for (int n = 15; n >= 0; n--) clk1(0, 0, 1, {c[3][n], c[2][n], c[1][n], c[0][n]});
    clk1(0, 0, 1, 4'hF);
    k = 0;
    do begin idle1(); k = k + 1; end while (dl[0] && k < 64);
    tokk = k;
    tok = {dl[0], 3'b000};
    for (int j = 2; j >= 0; j--) begin idle1(); tok[j] = dl[0]; end
    idle1();
    busy = 0;
    if (dl[0]) begin idle1(); while (!dl[0] && busy < 64) begin busy = busy + 1; idle1(); end end
    repeat (4) idle1();
  endtask
  logic rd_ok;
  task automatic rd_blk();
    logic [15:0] c [0:3], x [0:3];
    integer k;
    for (int l = 0; l < 4; l++) begin c[l] = 16'h0; x[l] = 16'h0; end
    k = 0;
    do begin idle1(); k = k + 1; end while (dl != 4'h0 && k < 64);
    for (int n = 0; n < 64; n++) begin
      idle1(); rb[255 - 4 * n -: 4] = dl;
      for (int l = 0; l < 4; l++) c[l] = crc16(c[l], dl[l]);
    end
    for (int n = 0; n < 16; n++) begin idle1(); for (int l = 0; l < 4; l++) x[l] = {x[l][14:0], dl[l]}; end
    idle1();
    rd_ok = k == 2 && dl == 4'hF && c[0] == x[0] && c[1] == x[1] && c[2] == x[2] && c[3] == x[3];
    repeat (4) idle1();
  endtask
  function automatic logic [255:0] init_blk(input integer b);
    for (int i = 0; i < 32; i++) init_blk[255 - 8 * i -: 8] = (16 * b + i) ^ 8'h3C;
  endfunction
  logic [15:0] rca;

  initial begin
    repeat (3) @(posedge clk);
    chk(cmd_s_oe === 1'b0 && dat_s_oe === 4'h0, "card off the bus in reset");
    rst_n = 1;
    repeat (4) idle1();
    cmd(6'd0, 32'h0); chk(!got, "CMD0: no response");
    cmd(6'd8, 32'h0000_02AA); chk(!got, "CMD8 with VHS 2: no response");
    cmd(6'd8, 32'h0000_01AA); chk(got && ncr == 2 && r48_ok(6'd8) && r[19:8] == 12'h1AA, "CMD8: R7 echo after NCR = 2");
    cmd(6'd41, 32'h40FF_8000); chk(!got, "CMD41 without CMD55: illegal, no response");
    cmd(6'd55, 32'h0); chk(got && r48_ok(6'd55) && r[39:8] == 32'h0040_0120, "CMD55: ILLEGAL_COMMAND, idle, APP_CMD");
    cmd(6'd41, 32'h40FF_8000);
    chk(got && r[45:40] == 6'h3F && r[7:0] == 8'hFF && r[39:8] == 32'h00FF_8000, "ACMD41: R3, busy");
    cmd(6'd55, 32'h0); chk(r[39:8] == 32'h0000_0120, "flags cleared after a report");
    cmd(6'd41, 32'h40FF_8000); chk(got && r[39:8] == 32'hC0FF_8000, "ACMD41: ready, CCS 1");
    cmd(6'd3, 32'h0); chk(!got, "CMD3 in ready: illegal, no response");
    cmd(6'd2, 32'h0, 136);
    chk(got && r[133:128] == 6'h3F && r[0] && crc7(r[127:8], 120) == r[7:1] && r[127:8] == 120'h1D4F565344433110123456780016A0,
        "CMD2: R2 with the CID and its CRC7");
    cmd(6'd3, 32'h0); rca = r[39:24];
    chk(got && r48_ok(6'd3) && rca == 16'h1234 && r[23:8] == 16'h4500, "CMD3: R6 with the RCA, ILLEGAL_COMMAND, ident state");
    cmd(6'd55, 32'h0); chk(got && r48_ok(6'd55), "CMD55 in stby");
    cmd(6'd41, 32'h40FF_8000); chk(!got, "ACMD41 in stby: illegal, no response");
    cmd(6'd13, {rca, 16'h0}, 48, 1); chk(!got, "bad CRC7: no response");
    cmd(6'd13, {rca, 16'h0}); chk(got && ncr == 2 && r48_ok(6'd13) && r[39:8] == 32'h00C0_0700, "CMD13: COM_CRC_ERROR and ILLEGAL_COMMAND, stby, NCR = 2");
    cmd(6'd7, {rca, 16'h0}); chk(got && r48_ok(6'd7) && r[20:17] == 4'd3, "CMD7: selected");
    wb = 256'hDEADBEEF_01234567_89ABCDEF_FEDCBA98_76543210_A5A5A5A5_5A5A5A5A_00FF00FF;
    cmd(6'd24, 32'd2, 48, 0, 0); chk(got && ncr == 2 && r48_ok(6'd24) && r[39:8] == 32'h0000_0900, "CMD24: R1 after NCR = 2, tran state, flags clear");
    wr_blk(); chk(tok == 4'b0010 && busy == 4 && tokk == TOKK, "block accepted: token 010 after 2 clocks, 4 clocks busy");
    cmd(6'd17, 32'd2, 48, 0, 0); rd_blk(); chk(rd_ok && rb == wb, "CMD17 reads the block back, NAC = 2, CRC16s good");
    cmd(6'd17, 32'd3, 48, 0, 0); rd_blk(); chk(rd_ok && rb == init_blk(3), "an untouched block");
    cmd(6'd24, 32'd3, 48, 0, 0); wr_blk(1); chk(tok == 4'b0101 && busy == 0, "bad CRC16: token 101, no busy");
    cmd(6'd17, 32'd3, 48, 0, 0); rd_blk(); chk(rb == init_blk(3), "and nothing written");
    cmd(6'd6, 32'h0); chk(!got, "CMD6: illegal");
    cmd(6'd7, {rca ^ 16'h1, 16'h0}); chk(!got, "CMD7 to another RCA: deselected, no response");
    cmd(6'd17, 32'd2); chk(!got, "CMD17 in stby: illegal");
    cmd(6'd13, {rca, 16'h0}); chk(got && r[39:8] == 32'h0040_0700, "CMD13: ILLEGAL_COMMAND, stby");
    cmd(6'd13, {rca ^ 16'h8000, 16'h0}); chk(!got, "CMD13 to another RCA: no response");
    cmd(6'd0, 32'h0);
    cmd(6'd8, 32'h0000_01AA);
    cmd(6'd55, 32'h0); cmd(6'd41, 32'h00FF_8000); chk(got && r[39:8] == 32'h00FF_8000, "after CMD0: busy again");
    cmd(6'd55, 32'h0); cmd(6'd41, 32'h00FF_8000); chk(r[39:8] == 32'h80FF_8000, "no HCS: ready with CCS 0");
    cmd(6'd2, 32'h0, 136); cmd(6'd3, 32'h0); cmd(6'd7, {rca, 16'h0});
    cmd(6'd17, {23'h0, 4'd2, 5'h0}, 48, 0, 0); rd_blk(); chk(rd_ok && rb == wb, "byte addressing: address 64 is block 2");
    chk(conflict == 0, "no bus contention");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
