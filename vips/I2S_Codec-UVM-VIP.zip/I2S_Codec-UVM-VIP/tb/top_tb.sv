// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- I2SC testbench top with a functional I2SC DUT model

`ifndef I2S_CODEC_UVM_VIP_TB_SV
`define I2S_CODEC_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import i2sc_defs_pkg::*;
import i2sc_pkg::*;
import i2sc_env_pkg::*;
import i2sc_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  i2sc_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  i2sc_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .bclk(vif.bclk),
    .lrck(vif.lrck),
    .sdin(vif.sdin),
    .sdout(vif.sdout)
  );

  // Concurrent protocol checks
  i2sc_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .bclk(vif.bclk),
    .lrck(vif.lrck),
    .sdin(vif.sdin),
    .sdout(vif.sdout)
  );

  initial begin
    uvm_config_db#(virtual i2sc_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module i2sc_model #(parameter int DW = 16) (
  input  logic clk,
  input  logic rst_n,
  input  logic bclk,
  input  logic lrck,
  input  logic sdin,
  output logic sdout
);
  localparam int CW = $clog2(DW + 1);
  logic [DW-1:0] tx_left, tx_right;
  logic [DW-1:0] tx_shift;
  logic [DW-2:0] rx_shift;
  logic [CW-1:0] rx_cnt;
  logic          tx_pend, tx_ch, rx_pend, rx_ch_n, rx_ch;
  logic          bclk_s, bclk_d, lrck_s, lrck_d, sdin_s;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bclk_s <= 1'b0; bclk_d <= 1'b0; lrck_s <= 1'b0; lrck_d <= 1'b0; sdin_s <= 1'b0;
    end else begin
      bclk_s <= bclk; bclk_d <= bclk_s; lrck_s <= lrck; lrck_d <= lrck_s; sdin_s <= sdin;
    end
  end
  wire bclk_rise   =  bclk_s & ~bclk_d;
  wire bclk_fall   = ~bclk_s &  bclk_d;
  wire lrck_change =  lrck_s ^  lrck_d;
  wire [DW-1:0] rx_word = {rx_shift, sdin_s};

  // transmit (I2S_top), loading the loopback registers
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_shift <= '0; tx_pend <= 1'b0; tx_ch <= 1'b0;
    end else begin
      if (bclk_fall) begin
        if (tx_pend) begin
          tx_shift <= tx_ch ? tx_right : tx_left;
          tx_pend  <= 1'b0;
        end else tx_shift <= {tx_shift[DW-2:0], 1'b0};
      end
      if (lrck_change) begin tx_pend <= 1'b1; tx_ch <= lrck_s; end
    end
  end

  // receive (I2S_top); each word written back to the same channel
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_left <= '0; tx_right <= '0; rx_shift <= '0;
      rx_cnt <= CW'(DW); rx_pend <= 1'b0; rx_ch_n <= 1'b0; rx_ch <= 1'b0;
    end else begin
      if (bclk_rise) begin
        if (rx_cnt != CW'(DW)) begin
          rx_shift <= rx_word[DW-2:0];
          rx_cnt   <= rx_cnt + 1'b1;
          if (rx_cnt == CW'(DW - 1)) begin
            if (!rx_ch) tx_left  <= rx_word;
            else        tx_right <= rx_word;
          end
        end
        if (rx_pend) begin rx_cnt <= '0; rx_ch <= rx_ch_n; rx_pend <= 1'b0; end
      end
      if (lrck_change) begin rx_pend <= 1'b1; rx_ch_n <= lrck_s; end
    end
  end

  assign sdout = tx_shift[DW-1];
endmodule
`endif
