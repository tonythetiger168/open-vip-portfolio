// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (I2SC DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened i2sc_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic bclk = 1'b1, lrck = 1'b0, sdin = 1'b0;
  wire sdout;

  always #5 clk = ~clk;

  i2sc_model u_dut (.clk(clk), .rst_n(rst_n), .bclk(bclk), .lrck(lrck), .sdin(sdin), .sdout(sdout));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // a burst: frames of (L, R) words in slot periods; slot of channel 0 / 1 of the first frame may be cut
  logic [15:0] wl [0:7], wr [0:7];
  logic        lb [0:1023], db [0:1023], ob [0:1023];
  integer      nb = 0;
  task automatic burst(input integer nfr, input integer slot, input integer h = 4, input integer cut0 = 0,
                       input integer cut1 = 0);
    integer n, k;
    nb = 0;
    db[0] = 0;
    for (int f = 0; f < nfr; f++)
      for (int ch = 0; ch < 2; ch++) begin
        n = slot;
        if (f == 0 && ch == 0 && cut0 != 0) n = cut0;
        if (f == 0 && ch == 1 && cut1 != 0) n = cut1;
        for (int b = 0; b < n; b++) begin
          lb[nb] = ch;
          db[nb + 1] = (b < 16) ? ((ch == 0) ? wl[f][15 - b] : wr[f][15 - b]) : 1'b0;
          nb = nb + 1;
        end
      end
    lb[nb] = 1; nb = nb + 1;
    for (int i = 0; i < nb; i++) begin
      @(negedge clk); bclk = 0; lrck = lb[i]; sdin = db[i];
      repeat (h) @(negedge clk);
      bclk = 1;
      repeat (h - 1) @(negedge clk);
      ob[i] = sdout;
    end
    @(negedge clk); sdin = 0;
    repeat (40) @(negedge clk);
  endtask
  // DAC word of slot j (start period s0): sdout at periods s0 + 1 .. s0 + 16
  function automatic logic [15:0] dac(input integer s0);
    logic [15:0] w;
    for (int b = 0; b < 16; b++) w[15 - b] = ob[s0 + 1 + b];
    dac = w;
  endfunction
  function automatic logic pad_zero(input integer s0, input integer slot);
    logic ok;
    ok = 1;
    for (int b = 16; b < 32; b++) if (b < slot && ob[s0 + 1 + b] !== 1'b0) ok = 0;
    pad_zero = ok;
  endfunction

  initial begin
    repeat (3) @(posedge clk);
    chk(sdout === 1'b0, "sdout low in reset");
    rst_n = 1;
    repeat (10) @(posedge clk);
    wl[0] = 16'hA55A; wr[0] = 16'h1234; wl[1] = 16'h8001; wr[1] = 16'hFFFF; wl[2] = 16'h0F0F; wr[2] = 16'h7FFE;
    burst(3, 16);
    chk(dac(0) == 16'h0000 && dac(16) == 16'h0000, "first frame: transmit registers still 0");
    chk(dac(32) == 16'h0000 && dac(48) == 16'h1234,
        "lrck low from reset: the first left slot is not taken, the first right one is sent back");
    chk(dac(64) == 16'h8001 && dac(80) == 16'hFFFF, "frame 3 sends frame 2 back");
    wl[0] = 16'h3C3C; wr[0] = 16'hC3C3; wl[1] = 16'h0001; wr[1] = 16'h8000;
    burst(2, 24);
    chk(dac(0) == 16'h0F0F && dac(24) == 16'h7FFE, "frame 3's words come back in the next burst");
    chk(dac(48) == 16'h3C3C && dac(72) == 16'hC3C3, "24-bit slots");
    chk(pad_zero(48, 24) && pad_zero(72, 24), "padding after the LSB is 0");
    wl[0] = 16'hDEAD; wr[0] = 16'hBEEF; wl[1] = 16'h5555; wr[1] = 16'hAAAA;
    burst(2, 32, 8);
    chk(dac(0) == 16'h0001 && dac(32) == 16'h8000 && dac(64) == 16'hDEAD && dac(96) == 16'hBEEF,
        "32-bit slots at a slower bclk");
    chk(pad_zero(64, 32), "16 padding bits");
    wl[0] = 16'h1111; wr[0] = 16'h2222; wl[1] = 16'h3333; wr[1] = 16'h4444;
    burst(2, 16, 4, 10);
    chk(dac(10) == 16'hAAAA && dac(26) == 16'h5555 && dac(42) == 16'h2222,
        "left slot cut to 10 bits: word lost, the older left word is sent again");
    wl[0] = 16'h6666; wr[0] = 16'h7777; wl[1] = 16'h9999; wr[1] = 16'hEEEE;
    burst(2, 18, 4, 0, 12);
    chk(dac(0) == 16'h3333 && dac(30) == 16'h6666 && dac(48) == 16'h4444,
        "right slot cut to 12 bits: the older right word again");
    wl[0] = 16'hFFFF; wr[0] = 16'h0000;
    burst(1, 16, 5);
    chk(dac(0) == 16'h9999 && dac(16) == 16'hEEEE, "odd bclk half-period");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
