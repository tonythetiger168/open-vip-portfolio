// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// i2sc_env.sv -- I2SC environment: reference-model scoreboard, checker, coverage

package i2sc_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import i2sc_defs_pkg::*;
  import i2sc_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class i2sc_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(i2sc_scoreboard)
    uvm_analysis_imp_exp #(i2sc_transaction, i2sc_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(i2sc_transaction, i2sc_scoreboard) obs_ap;

    i2sc_config cfg;
    i2sc_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // I2S_top state after reset (lrck low from reset on, so the first left
    // slot of the first burst has no lrck change before it and is not taken)
    bit        lrp = 0, tpend = 0, tch = 0, rpend = 0, rchn = 0, rch = 0;
    bit [15:0] tsh = 0, txl = 0, txr = 0;
    bit [14:0] rsh = 0;
    int        rcnt = 16;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(i2sc_config)::get(this, "", "cfg", cfg))
        cfg = i2sc_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(i2sc_transaction t);
      t.dout.delete();
      foreach (t.rises[i]) begin
        bit lr = t.rises[i][1], sd = t.rises[i][0];
        bit [15:0] w = {rsh, sd};
        // falling edge: load on a pending lrck change, else shift; then the change
        if (tpend) begin tsh = tch ? txr : txl; tpend = 0; end
        else tsh = {tsh[14:0], 1'b0};
        if (lr != lrp) begin tpend = 1; tch = lr; rpend = 1; rchn = lr; end
        lrp = lr;
        t.dout.push_back(tsh[15]);
        // rising edge: take sdin; a complete word goes to the loopback register
        if (rcnt != 16) begin
          rsh = w[14:0];
          if (rcnt == 15) begin if (!rch) txl = w; else txr = w; end
          rcnt++;
        end
        if (rpend) begin rcnt = 0; rch = rchn; rpend = 0; end
      end
    endfunction

    function void write_exp(i2sc_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(i2sc_transaction t);
      i2sc_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        i2sc_transaction e = exp_q.pop_front();
        i2sc_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("i2sc scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class i2sc_env extends uvm_env;
    `uvm_component_utils(i2sc_env)
    i2sc_agent      agt;
    i2sc_scoreboard sb;
    i2sc_checker    chk;
    i2sc_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = i2sc_agent     ::type_id::create("agt", this);
      sb  = i2sc_scoreboard::type_id::create("sb",  this);
      chk = i2sc_checker   ::type_id::create("chk", this);
      cov = i2sc_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
