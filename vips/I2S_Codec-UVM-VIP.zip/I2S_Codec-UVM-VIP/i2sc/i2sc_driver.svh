// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// i2sc_driver.svh -- I2SC driver: one burst of bclk periods per item: lrck and sdin set at each falling edge, bclk high for the second half; then bclk idles high for cfg.idle clocks

class i2sc_driver extends uvm_driver #(i2sc_transaction);
  `uvm_component_utils(i2sc_driver)

  uvm_analysis_port #(i2sc_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual i2sc_if vif;
  i2sc_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual i2sc_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "i2sc: virtual interface not set")
    if (!uvm_config_db#(i2sc_config)::get(this, "", "cfg", cfg))
      cfg = i2sc_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    i2sc_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.bclk <= 1'b1;
    vif.drv_cb.lrck <= 1'b0;
    vif.drv_cb.sdin <= 1'b0;
  endtask

  task drive_item(i2sc_transaction t);
    bit lr [$], dat [$];
    int h = t.period(cfg.div) / 2;
    t.build(lr, dat);
    t.rises.delete();
    foreach (lr[i]) t.rises.push_back({lr[i], dat[i]});
    @(vif.drv_cb);
    foreach (lr[i]) begin
      vif.drv_cb.bclk <= 1'b0; vif.drv_cb.lrck <= lr[i]; vif.drv_cb.sdin <= dat[i];
      repeat (h) @(vif.drv_cb);
      vif.drv_cb.bclk <= 1'b1;
      repeat (h) @(vif.drv_cb);
    end
    repeat (cfg.idle) @(vif.drv_cb);
  endtask

endclass
