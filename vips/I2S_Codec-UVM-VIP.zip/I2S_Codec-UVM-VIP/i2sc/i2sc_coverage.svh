// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// i2sc_coverage.svh -- I2SC functional coverage

class i2sc_coverage extends uvm_subscriber #(i2sc_transaction);
  `uvm_component_utils(i2sc_coverage)
  i2sc_config cfg;
  i2sc_transaction tr;

  covergroup i2sc_cg;
    cp_len   : coverpoint tr.rises.size() { bins one = {[33:65]}; bins two = {[66:130]}; bins more = {[131:300]}; }
    cp_first : coverpoint (tr.dout.size() > 1 ? tr.dout[1] : 1'b0);
    cp_ones  : coverpoint (tr.ones() > 0) { bins silent = {0}; bins data = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    i2sc_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(i2sc_config)::get(this, "", "cfg", cfg))
      cfg = i2sc_config::type_id::create("cfg");
  endfunction

  function void write(i2sc_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    i2sc_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("I2SC coverage: %0.1f%%", i2sc_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
