// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// i2sc_transaction.svh -- I2SC transaction

class i2sc_transaction extends uvm_sequence_item;
  `uvm_object_utils(i2sc_transaction)

  // request (driven by the agent)
  bit [1:0] rises[$];
  // response (returned by the DUT)
  bit dout[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [1:0] nfr;
  rand bit [1:0] ssel;
  rand bit [1:0] dsel;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "i2sc_transaction"); super.new(name); endfunction

  // kind: 0-23 nfr + 1 stereo frames in slot_of() periods, 24-27 the first left
  // slot cut to 8-15 periods, 28-31 the first right slot cut. dsel: bclk
  // period cfg.div + 0 / 2 / 8 / 0.
  function void set(int k, int frames = 2, int s = 0, bit [31:0] sd = 32'h1); kind = k; nfr = frames - 1; ssel = s; seed = sd; endfunction
  function int ones(); int n = 0; foreach (dout[i]) n += dout[i]; return n; endfunction
  function int slot_of();
    case (ssel)
      0: return 16;
      1: return 24;
      2: return 32;
      default: return 18;
    endcase
  endfunction
  function int period(int d);
    return d + ((dsel == 1) ? 2 : (dsel == 2) ? 8 : 0);
  endfunction
  // lrck / data bit per bclk period; data is the slot bit stream delayed by one period
  function void build(ref bit lr [$], ref bit dat [$]);
    bit [31:0] x = seed | 1;
    bit s [$];
    int S = slot_of();
    lr.delete(); dat.delete();
    for (int f = 0; f <= nfr; f++)
      for (int ch = 0; ch < 2; ch++) begin
        int n = S;
        bit [15:0] w;
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        w = x[15:0];
        if (f == 0 && ((kind inside {[24:27]} && ch == 0) || (kind inside {[28:31]} && ch == 1))) n = 8 + x[18:16];
        for (int b = 0; b < n; b++) begin lr.push_back(ch); s.push_back((b < 16) ? w[15 - b] : 1'b0); end
      end
    lr.push_back(1'b1);                       // the extra period carries the last LSB
    dat.push_back(1'b0);
    for (int i = 0; i < s.size(); i++) dat.push_back(s[i]);
  endfunction

  function void do_copy(uvm_object rhs);
    i2sc_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    rises = rhs_.rises;
    dout = rhs_.dout;
    kind = rhs_.kind;
    nfr = rhs_.nfr;
    ssel = rhs_.ssel;
    dsel = rhs_.dsel;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    i2sc_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (rises.size() != rhs_.rises.size()) return 0;
    foreach (rises[i]) if (rises[i] != rhs_.rises[i]) return 0;
    if (dout.size() != rhs_.dout.size()) return 0;
    foreach (dout[i]) if (dout[i] != rhs_.dout[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(i2sc_transaction rhs_);
    if (rises.size() != rhs_.rises.size()) return 0;
    foreach (rises[i]) if (rises[i] != rhs_.rises[i]) return 0;
    return 1;
  endfunction

  function string qstr_rises();
    string s = $sformatf("[%0d]{", rises.size());
    foreach (rises[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rises[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_dout();
    string s = $sformatf("[%0d]{", dout.size());
    foreach (dout[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", dout[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("I2SC{tag=%0d rises=%s dout=%s}", tag, qstr_rises(), qstr_dout());
  endfunction
endclass
