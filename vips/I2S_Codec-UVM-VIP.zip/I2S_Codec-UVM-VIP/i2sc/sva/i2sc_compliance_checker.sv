// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// i2sc_compliance_checker.sv -- I2SC concurrent assertion checks (bindable)

module i2sc_compliance_checker
  (input logic clk, input logic rst_n, input logic bclk, input logic lrck, input logic sdin, input logic sdout);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({bclk, lrck, sdin, sdout}))
    else $error("I2SC: X on the bus");
  assert property (@(posedge clk) disable iff (!rst_n) $changed(lrck) |-> $fell(bclk))
    else $error("I2SC: lrck changed away from a bclk falling edge");
  assert property (@(posedge clk) disable iff (!rst_n) $changed(sdin) |-> $fell(bclk))
    else $error("I2SC: sdin changed away from a bclk falling edge");
  assert property (@(posedge clk) disable iff (!rst_n) $rose(bclk) |-> $stable(sdout))
    else $error("I2SC: sdout changing at the bclk rising edge");
  cover property (@(posedge clk) disable iff (!rst_n) $rose(bclk) && sdout);
endmodule
