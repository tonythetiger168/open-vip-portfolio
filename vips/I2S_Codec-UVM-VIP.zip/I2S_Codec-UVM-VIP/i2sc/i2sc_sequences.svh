// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// i2sc_sequences.svh -- I2SC sequences

// Random traffic: cfg.num_items constrained-random items.
class i2sc_base_sequence extends uvm_sequence #(i2sc_transaction);
  `uvm_object_utils(i2sc_base_sequence)
  i2sc_config cfg;

  function new(string name = "i2sc_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = i2sc_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "i2sc_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class i2sc_directed_sequence extends uvm_sequence #(i2sc_transaction);
  `uvm_object_utils(i2sc_directed_sequence)
  i2sc_config cfg;

  function new(string name = "i2sc_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function i2sc_transaction item();
    item = i2sc_transaction::type_id::create("req");
  endfunction

  task send(i2sc_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    i2sc_transaction t;
    // every slot width, short slots on each channel, bclk rate changes, long bursts
    for (int s = 0; s < 4; s++)
      for (int d = 0; d < 3; d++) begin t = item(); t.set(s * 5, 1 + d, s, 32'h100 * s + d + 1); t.dsel = d; send(t); end
    for (int k = 24; k < 32; k += 2) begin
      t = item(); t.set(k, 2, k % 4, 32'h4000 + k); send(t);
      t = item(); t.set(0, 2, k % 4, 32'h5000 + k); send(t);
    end
    t = item(); t.set(1, 4, 2, 32'hBEEF); t.dsel = 2; send(t);
  endtask
endclass
