// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// i2sc_monitor.svh -- I2SC monitor: {lrck, sdin} and sdout at every bclk rising edge of a burst; bclk high for more than half of cfg.idle ends it

class i2sc_monitor extends uvm_monitor;
  `uvm_component_utils(i2sc_monitor)

  virtual i2sc_if vif;
  uvm_analysis_port #(i2sc_transaction) ap;
  i2sc_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual i2sc_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "i2sc: virtual interface not set")
    if (!uvm_config_db#(i2sc_config)::get(this, "", "cfg", cfg))
      cfg = i2sc_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        i2sc_transaction t;
        bit pb;
        int hi = 0;
        pb = vif.mon_cb.bclk;
        while (!(pb === 1'b1 && vif.mon_cb.bclk === 1'b0)) begin pb = vif.mon_cb.bclk; @(vif.mon_cb); end
        t = i2sc_transaction::type_id::create("t");
        forever begin
          pb = vif.mon_cb.bclk;
          @(vif.mon_cb);
          if (pb === 1'b0 && vif.mon_cb.bclk === 1'b1) begin
            t.rises.push_back({vif.mon_cb.lrck, vif.mon_cb.sdin});
            t.dout.push_back(vif.mon_cb.sdout);
          end
          if (vif.mon_cb.bclk === 1'b1) hi++; else hi = 0;
          if (hi > cfg.idle / 2) break;
        end
        publish(t);
      end
    end
  endtask

  function void publish(i2sc_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
