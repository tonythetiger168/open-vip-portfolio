// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (CSIS DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened csis_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic rx_valid = 1'b0, rx_bit = 1'b0;
  wire rep_valid, out_valid;
  wire [3:0] rep_flags;
  wire [7:0] rep_dt, out_data;
  wire [15:0] rep_wc, rep_frame, rep_line;

  always #5 clk = ~clk;

  csis_model u_dut (.clk(clk), .rst_n(rst_n), .rx_valid(rx_valid), .rx_bit(rx_bit), .rep_valid(rep_valid),
                    .rep_flags(rep_flags), .rep_dt(rep_dt), .rep_wc(rep_wc), .rep_frame(rep_frame),
                    .rep_line(rep_line), .out_valid(out_valid), .out_data(out_data));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [5:0] ecc24(input logic [23:0] d);
    ecc24[0] = d[0]^d[1]^d[2]^d[4]^d[5]^d[7]^d[10]^d[11]^d[13]^d[16]^d[20]^d[21]^d[22]^d[23];
    ecc24[1] = d[0]^d[1]^d[3]^d[4]^d[6]^d[8]^d[10]^d[12]^d[14]^d[17]^d[20]^d[21]^d[22]^d[23];
    ecc24[2] = d[0]^d[2]^d[3]^d[5]^d[6]^d[9]^d[11]^d[12]^d[15]^d[18]^d[20]^d[21]^d[22];
    ecc24[3] = d[1]^d[2]^d[3]^d[7]^d[8]^d[9]^d[13]^d[14]^d[15]^d[19]^d[20]^d[21]^d[23];
    ecc24[4] = d[4]^d[5]^d[6]^d[7]^d[8]^d[9]^d[16]^d[17]^d[18]^d[19]^d[20]^d[22]^d[23];
    ecc24[5] = d[10]^d[11]^d[12]^d[13]^d[14]^d[15]^d[16]^d[17]^d[18]^d[19]^d[21]^d[22]^d[23];
  endfunction
  function automatic logic [15:0] crc16(input logic [15:0] c, input logic [7:0] d);
    logic [15:0] v;
    v = c ^ {8'h00, d};
    for (int k = 0; k < 8; k++) v = v[0] ? (v >> 1) ^ 16'h8408 : (v >> 1);
    crc16 = v;
  endfunction

  logic [7:0] pb [0:1023];
  integer pn = 0, p0 = 0, pw = 0;
  // packet at pb[pn]: hf 1 data bit hb, 2 ECC bit hb, 3 ECC bits 7:6, 4 data bits hb and hb+5;
  // pf 1 last payload byte bit 3, 2 CRC bit 9
  task automatic addpkt(input logic [7:0] di, input logic [15:0] w, input integer hf = 0, input integer hb = 0,
                        input integer pf = 0);
    logic [23:0] h;
    logic [7:0] e;
    logic [15:0] c;
    h = {w, di}; e = {2'b00, ecc24(h)}; c = 16'hFFFF;
    if (hf == 1) h[hb] = ~h[hb];
    if (hf == 2) e[hb] = ~e[hb];
    if (hf == 3) e[7:6] = 2'b11;
    if (hf == 4) begin h[hb] = ~h[hb]; h[(hb + 5) % 24] = ~h[(hb + 5) % 24]; end
    pb[pn] = 8'hB8; pb[pn + 1] = h[7:0]; pb[pn + 2] = h[15:8]; pb[pn + 3] = h[23:16]; pb[pn + 4] = e;
    pn = pn + 5; p0 = pn; pw = 0;
    if (di[5:0] >= 6'h10) begin
      for (int i = 0; i < w; i++) begin pb[pn] = (8'h30 + i * 13) ^ di; c = crc16(c, pb[pn]); pn = pn + 1; end
      pw = w;
      if (pf == 1) pb[pn - 1][3] = ~pb[pn - 1][3];
      if (pf == 2) c[9] = ~c[9];
      pb[pn] = c[7:0]; pb[pn + 1] = c[15:8]; pn = pn + 2;
    end
  endtask

  logic [7:0] ob [0:1023];
  integer on = 0, nrep = 0, r0 = 0, both = 0;
  logic [3:0]  r_f  [0:255];
  logic [7:0]  r_dt [0:255];
  logic [15:0] r_wc [0:255], r_fr [0:255], r_ln [0:255];
  always @(posedge clk) begin
    if (out_valid) begin ob[on] = out_data; on = on + 1; end
    if (out_valid && rep_valid) both = both + 1;
    if (rep_valid) begin
      r_f[nrep] = rep_flags; r_dt[nrep] = rep_dt; r_wc[nrep] = rep_wc; r_fr[nrep] = rep_frame; r_ln[nrep] = rep_line;
      nrep = nrep + 1;
    end
  end
  // one burst: lead zeros, the first nb bits of pb (all when -1), trail bits of value tv, gap clocks low
  task automatic send(input integer lead = 3, input integer nb = -1, input integer trail = 4, input logic tv = 1'b1,
                      input integer gap = 6);
    integer n;
    r0 = nrep; on = 0;
    n = (nb < 0) ? 8 * pn : nb;
    for (int i = 0; i < lead; i++) begin @(negedge clk); rx_valid = 1; rx_bit = 0; end
    for (int i = 0; i < n; i++) begin @(negedge clk); rx_valid = 1; rx_bit = pb[i / 8][i % 8]; end
    for (int i = 0; i < trail; i++) begin @(negedge clk); rx_valid = 1; rx_bit = tv; end
    @(negedge clk); rx_valid = 0; rx_bit = 0;
    repeat (gap) @(negedge clk);
    pn = 0;
  endtask
  function automatic logic rep(input integer i, input logic [3:0] f, input logic [7:0] dt, input logic [15:0] wc,
                               input logic [15:0] fr, input logic [15:0] ln);
    rep = r_f[r0 + i] == f && r_dt[r0 + i] == dt && r_wc[r0 + i] == wc && r_fr[r0 + i] == fr && r_ln[r0 + i] == ln;
  endfunction
  function automatic logic delivered();
    logic ok;
    ok = (on == pw);
    for (int i = 0; i < 1024; i++) if (i < pw && ob[i] !== pb[p0 + i]) ok = 0;
    delivered = ok;
  endfunction
  logic [7:0] keep [0:1023];
  integer allok;

  initial begin
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0 && out_valid === 1'b0, "nothing out in reset");
    rst_n = 1;
    repeat (5) @(negedge clk);
    pb[0] = 8'h00; pn = 1; send(5, 8, 0);
    chk(nrep == 0 && on == 0, "a burst of HS-zeros only: no report");
    addpkt(8'h00, 16'd7); send();
    chk(nrep == r0 + 1 && rep(0, 4'h0, 8'h00, 16'd7, 16'd1, 16'd0), "FS with frame number 7");
    addpkt(8'h2A, 16'd16); send(13);
    chk(nrep == r0 + 1 && rep(0, 4'h0, 8'h2A, 16'd16, 16'd1, 16'd1) && delivered(), "RAW8 line of 16 after 13 lead-in zeros");
    addpkt(8'h9E, 16'd9); send(0, -1, 0);
    chk(rep(0, 4'h0, 8'h9E, 16'd9, 16'd1, 16'd2) && delivered(), "YUV422 on VC 2, no lead-in or trailer");
    addpkt(8'h2B, 16'd0); send();
    chk(rep(0, 4'h0, 8'h2B, 16'd0, 16'd1, 16'd3) && on == 0, "long packet with WC 0");
    allok = 1;
    for (int b = 0; b < 24; b++) begin
      addpkt(8'h24, 16'd5, 1, b); send();
      if (!(nrep == r0 + 1 && rep(0, 4'h8, 8'h24, 16'd5, 16'd1, 16'd4 + b) && delivered())) allok = 0;
    end
    chk(allok, "header bit error in each of the 24 positions: corrected, line counted");
    allok = 1;
    for (int b = 0; b < 6; b++) begin
      addpkt(8'h02, 16'd3, 2, b); send();
      if (!rep(0, 4'h8, 8'h02, 16'd3, 16'd1, 16'd27)) allok = 0;
    end
    chk(allok, "ECC bit errors: corrected");
    addpkt(8'h03, 16'd4, 3); send();
    chk(rep(0, 4'h0, 8'h03, 16'd4, 16'd1, 16'd27), "ECC bits 7:6 are ignored");
    addpkt(8'h2A, 16'd8, 4, 2); send();
    chk(nrep == r0 + 1 && rep(0, 4'h2, 8'h00, 16'd0, 16'd1, 16'd27) && on == 0, "two-bit header error: dropped");
    addpkt(8'h2A, 16'd8, 0, 0, 1); send();
    chk(rep(0, 4'h1, 8'h2A, 16'd8, 16'd1, 16'd27) && on == 8, "payload bit error: CRC error, line not counted");
    addpkt(8'h2A, 16'd8, 0, 0, 2); send();
    chk(rep(0, 4'h1, 8'h2A, 16'd8, 16'd1, 16'd27), "CRC bit error");
    addpkt(8'h2A, 16'd8); send(3, 8 * 2 + 3, 0);
    chk(nrep == r0 + 1 && rep(0, 4'h4, 8'h00, 16'd0, 16'd1, 16'd27), "burst cut in the header");
    addpkt(8'h2A, 16'd8); send(3, 8 * 5, 0);
    chk(rep(0, 4'h4, 8'h2A, 16'd8, 16'd1, 16'd27) && on == 0, "burst cut right after the ECC byte");
    addpkt(8'h2A, 16'd8, 1, 20); send(3, 8 * 9 + 5, 0);
    chk(rep(0, 4'hC, 8'h2A, 16'd8, 16'd1, 16'd27) && on == 4, "corrected header, burst cut in the payload");
    addpkt(8'h2A, 16'd8); send(3, 8 * 13 + 2, 0);
    chk(rep(0, 4'h4, 8'h2A, 16'd8, 16'd1, 16'd27), "burst cut in the CRC");
    addpkt(8'h2A, 16'd8); send(3, 8 * 14, 0);
    chk(rep(0, 4'h4, 8'h2A, 16'd8, 16'd1, 16'd27), "burst cut after the CRC low byte");
    addpkt(8'h02, 16'd0); addpkt(8'h2A, 16'd6); addpkt(8'h03, 16'd0); send();
    chk(nrep == r0 + 3 && rep(0, 4'h0, 8'h02, 16'd0, 16'd1, 16'd27) && rep(1, 4'h0, 8'h2A, 16'd6, 16'd1, 16'd28)
        && rep(2, 4'h0, 8'h03, 16'd0, 16'd1, 16'd28), "LS + line + LE in one burst");
    addpkt(8'h2A, 16'd6); pb[pn] = 8'h00; pn = pn + 1; addpkt(8'h2A, 16'd6); send();
    chk(nrep == r0 + 1 && rep(0, 4'h0, 8'h2A, 16'd6, 16'd1, 16'd29), "junk byte after a packet: rest of the burst ignored");
    addpkt(8'h2A, 16'd6); send(3, -1, 7, 1'b0);
    chk(nrep == r0 + 1, "trailer of zeros: no further report");
    addpkt(8'h2A, 16'd300); send();
    chk(rep(0, 4'h0, 8'h2A, 16'd300, 16'd1, 16'd31) && delivered(), "line of 300 bytes");
    addpkt(8'h01, 16'd7); send(3, -1, 4, 1'b1, 1);
    chk(rep(0, 4'h0, 8'h01, 16'd7, 16'd1, 16'd31), "FE");
    addpkt(8'h40, 16'd8); send(3, -1, 4, 1'b1, 1);
    chk(rep(0, 4'h0, 8'h40, 16'd8, 16'd2, 16'd0), "FS on VC 1 after a one-clock gap: frame 2, line count cleared");
    addpkt(8'h2A, 16'd8, 4, 2); addpkt(8'h2A, 16'd8); send();
    chk(nrep == r0 + 1 && r_f[r0] == 4'h2, "packet after a dropped header in the same burst is not taken");
    chk(both == 0, "no payload byte in the clock of a report");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
