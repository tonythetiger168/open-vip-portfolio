// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CSIS testbench top with a functional CSIS DUT model

`ifndef CSI2_SENSOR_UVM_VIP_TB_SV
`define CSI2_SENSOR_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import csis_defs_pkg::*;
import csis_pkg::*;
import csis_env_pkg::*;
import csis_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  csis_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  csis_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx_valid(vif.rx_valid),
    .rx_bit(vif.rx_bit),
    .rep_valid(vif.rep_valid),
    .rep_flags(vif.rep_flags),
    .rep_dt(vif.rep_dt),
    .rep_wc(vif.rep_wc),
    .rep_frame(vif.rep_frame),
    .rep_line(vif.rep_line),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data)
  );

  // Concurrent protocol checks
  csis_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx_valid(vif.rx_valid),
    .rx_bit(vif.rx_bit),
    .rep_valid(vif.rep_valid),
    .rep_flags(vif.rep_flags),
    .rep_dt(vif.rep_dt),
    .rep_wc(vif.rep_wc),
    .rep_frame(vif.rep_frame),
    .rep_line(vif.rep_line),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data)
  );

  initial begin
    uvm_config_db#(virtual csis_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module csis_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rx_valid,
  input  logic        rx_bit,
  output logic        rep_valid,
  output logic [3:0]  rep_flags,
  output logic [7:0]  rep_dt,
  output logic [15:0] rep_wc,
  output logic [15:0] rep_frame,
  output logic [15:0] rep_line,
  output logic        out_valid,
  output logic [7:0]  out_data
);
  localparam logic [3:0] S_HUNT = 4'd0, S_HDR0 = 4'd1, S_HDR1 = 4'd2, S_HDR2 = 4'd3, S_ECC = 4'd4,
                         S_PAY = 4'd5, S_CRC0 = 4'd6, S_CRC1 = 4'd7, S_NEXT = 4'd8, S_EOT = 4'd9;

  function automatic logic [5:0] ecc24(input logic [23:0] d);
    ecc24[0] = d[0]^d[1]^d[2]^d[4]^d[5]^d[7]^d[10]^d[11]^d[13]^d[16]^d[20]^d[21]^d[22]^d[23];
    ecc24[1] = d[0]^d[1]^d[3]^d[4]^d[6]^d[8]^d[10]^d[12]^d[14]^d[17]^d[20]^d[21]^d[22]^d[23];
    ecc24[2] = d[0]^d[2]^d[3]^d[5]^d[6]^d[9]^d[11]^d[12]^d[15]^d[18]^d[20]^d[21]^d[22];
    ecc24[3] = d[1]^d[2]^d[3]^d[7]^d[8]^d[9]^d[13]^d[14]^d[15]^d[19]^d[20]^d[21]^d[23];
    ecc24[4] = d[4]^d[5]^d[6]^d[7]^d[8]^d[9]^d[16]^d[17]^d[18]^d[19]^d[20]^d[22]^d[23];
    ecc24[5] = d[10]^d[11]^d[12]^d[13]^d[14]^d[15]^d[16]^d[17]^d[18]^d[19]^d[21]^d[22]^d[23];
  endfunction
  function automatic logic [23:0] ecc_fix(input logic [5:0] syn);
    ecc_fix = '0;
    for (int i = 0; i < 24; i++) if (syn == ecc24(24'h1 << i)) ecc_fix = 24'h1 << i;
  endfunction
  function automatic logic [15:0] crc16_byte(input logic [15:0] c, input logic [7:0] d);
    logic [15:0] v;
    v = c ^ {8'h00, d};
    for (int k = 0; k < 8; k++) v = v[0] ? (v >> 1) ^ 16'h8408 : (v >> 1);
    crc16_byte = v;
  endfunction

  logic [3:0]  state;
  logic [6:0]  shreg;
  logic [2:0]  bit_cnt;
  logic [23:0] hdr, hc_r;
  logic [15:0] wc, pay_cnt, crc, frame_cnt, line_cnt;
  logic [7:0]  crc_lo;
  logic        corr;

  wire [7:0]  rx_byte  = {rx_bit, shreg};
  wire        byte_rdy = rx_valid && bit_cnt == 3'd7;
  wire [5:0]  syn      = rx_byte[5:0] ^ ecc24(hdr);
  wire [23:0] fix      = ecc_fix(syn);
  wire        ecc_bit  = syn != 6'h00 && (syn & (syn - 6'd1)) == 6'h00;
  wire        ecc_ok   = syn == 6'h00 || fix != '0 || ecc_bit;
  wire [23:0] hc       = hdr ^ fix;
  wire        in_pkt   = state != S_HUNT && state != S_NEXT && state != S_EOT;
  wire        hdr_done = state == S_PAY || state == S_CRC0 || state == S_CRC1;

  assign rep_frame = frame_cnt;
  assign rep_line  = line_cnt;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_HUNT; shreg <= '0; bit_cnt <= '0; hdr <= '0; hc_r <= '0; wc <= '0;
      pay_cnt <= '0; crc <= 16'hFFFF; crc_lo <= '0; corr <= 1'b0; frame_cnt <= '0; line_cnt <= '0;
      rep_valid <= 1'b0; rep_flags <= '0; rep_dt <= '0; rep_wc <= '0; out_valid <= 1'b0; out_data <= '0;
    end else begin
      rep_valid <= 1'b0;
      out_valid <= 1'b0;
      if (!rx_valid) begin
        bit_cnt <= '0;
        state   <= S_HUNT;
        if (in_pkt) begin
          rep_valid <= 1'b1;
          rep_flags <= {corr && hdr_done, 3'b100};
          rep_dt    <= hdr_done ? hc_r[7:0] : 8'h00;
          rep_wc    <= hdr_done ? hc_r[23:8] : 16'h0000;
        end
      end else begin
        shreg   <= rx_byte[7:1];
        bit_cnt <= bit_cnt + 3'd1;
        if (state == S_HUNT) begin
          if (rx_byte == 8'hB8) begin state <= S_HDR0; bit_cnt <= '0; end
        end else if (byte_rdy) begin
          case (state)
            S_NEXT: state <= (rx_byte == 8'hB8) ? S_HDR0 : S_EOT;
            S_HDR0: begin hdr[7:0]   <= rx_byte; state <= S_HDR1; end
            S_HDR1: begin hdr[15:8]  <= rx_byte; state <= S_HDR2; end
            S_HDR2: begin hdr[23:16] <= rx_byte; state <= S_ECC;  end
            S_ECC: begin
              if (!ecc_ok) begin
                state <= S_NEXT;
                rep_valid <= 1'b1; rep_flags <= 4'b0010; rep_dt <= 8'h00; rep_wc <= 16'h0000;
              end else begin
                hc_r <= hc;
                corr <= syn != 6'h00;
                if (hc[5:0] < 6'h10) begin
                  state <= S_NEXT;
                  rep_valid <= 1'b1; rep_flags <= {syn != 6'h00, 3'b000}; rep_dt <= hc[7:0]; rep_wc <= hc[23:8];
                  if (hc[5:0] == 6'h00) begin frame_cnt <= frame_cnt + 16'd1; line_cnt <= '0; end
                end else begin
                  wc <= hc[23:8]; pay_cnt <= '0; crc <= 16'hFFFF;
                  state <= (hc[23:8] == 16'h0) ? S_CRC0 : S_PAY;
                end
              end
            end
            S_PAY: begin
              crc <= crc16_byte(crc, rx_byte);
              out_valid <= 1'b1; out_data <= rx_byte;
              pay_cnt <= pay_cnt + 16'd1;
              if (pay_cnt == wc - 16'd1) state <= S_CRC0;
            end
            S_CRC0: begin crc_lo <= rx_byte; state <= S_CRC1; end
            S_CRC1: begin
              state <= S_NEXT;
              rep_valid <= 1'b1;
              rep_flags <= {corr, 2'b00, {rx_byte, crc_lo} != crc};
              rep_dt <= hc_r[7:0]; rep_wc <= hc_r[23:8];
              if ({rx_byte, crc_lo} == crc) line_cnt <= line_cnt + 16'd1;
            end
            default: ;
          endcase
        end
      end
    end
  end
endmodule
`endif
