// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_defs.sv -- CSIS shared type definitions

package csis_defs_pkg;

  typedef enum bit [1:0] {CSIS_OK, CSIS_ERR} csis_status_e;

  function automatic bit [5:0] csis_ecc(bit [23:0] d);
    bit [5:0] e;
    e[0] = d[0]^d[1]^d[2]^d[4]^d[5]^d[7]^d[10]^d[11]^d[13]^d[16]^d[20]^d[21]^d[22]^d[23];
    e[1] = d[0]^d[1]^d[3]^d[4]^d[6]^d[8]^d[10]^d[12]^d[14]^d[17]^d[20]^d[21]^d[22]^d[23];
    e[2] = d[0]^d[2]^d[3]^d[5]^d[6]^d[9]^d[11]^d[12]^d[15]^d[18]^d[20]^d[21]^d[22];
    e[3] = d[1]^d[2]^d[3]^d[7]^d[8]^d[9]^d[13]^d[14]^d[15]^d[19]^d[20]^d[21]^d[23];
    e[4] = d[4]^d[5]^d[6]^d[7]^d[8]^d[9]^d[16]^d[17]^d[18]^d[19]^d[20]^d[22]^d[23];
    e[5] = d[10]^d[11]^d[12]^d[13]^d[14]^d[15]^d[16]^d[17]^d[18]^d[19]^d[21]^d[22]^d[23];
    return e;
  endfunction
  function automatic bit [23:0] csis_fix(bit [5:0] syn);   // data bit a syndrome points at, 0 if none
    for (int i = 0; i < 24; i++) if (syn == csis_ecc(24'h1 << i)) return 24'h1 << i;
    return 24'h0;
  endfunction
  function automatic bit [15:0] csis_crc(bit [15:0] c, bit [7:0] d);
    bit [15:0] v = c ^ {8'h00, d};
    for (int k = 0; k < 8; k++) v = v[0] ? (v >> 1) ^ 16'h8408 : (v >> 1);
    return v;
  endfunction
  // report word: {4'h0, flags, dt, wc, frame, line}
  function automatic bit [63:0] csis_rep(bit [3:0] f, bit [23:0] h, bit [15:0] fr, bit [15:0] ln);
    return {4'h0, f, h[7:0], h[23:8], fr, ln};
  endfunction

endpackage
