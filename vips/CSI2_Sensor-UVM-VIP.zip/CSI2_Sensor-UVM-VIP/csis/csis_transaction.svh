// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_transaction.svh -- CSIS transaction

class csis_transaction extends uvm_sequence_item;
  `uvm_object_utils(csis_transaction)

  // request (driven by the agent)
  bit bits[$];
  // response (returned by the DUT)
  bit [63:0] rep[$];
  bit [7:0] pay[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [1:0] dsel;
  rand bit [1:0] vc;
  rand bit [7:0] wc;
  rand bit [3:0] lead;
  rand bit [3:0] trail;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "csis_transaction"); super.new(name); endfunction

  // kind: 0-9 one image line, 10 FS, 11 FE, 12 LS / LE, 13 FS + line in one
  // burst, 14 two lines + FE in one burst, 15 long packet with WC 0, 16 header
  // data bit error, 17 ECC bit error, 18 ECC bits 7:6 set, 19 two-bit header
  // error, 20 payload bit error, 21 CRC bit error, 22 burst cut in the header,
  // 23 cut in the payload, 24 cut in the CRC, 25 uncorrectable packet then a
  // good one, 26 junk byte between two packets, 27 line of 100-355 bytes,
  // 28 line with a header bit error, 29-31 image line.
  function void set(int k, int w = 8, bit [31:0] s = 32'h1); kind = k; wc = w; seed = s; endfunction
  function bit [5:0] dt_of();
    case (dsel)
      0: return 6'h2A;      // RAW8
      1: return 6'h2B;      // RAW10
      2: return 6'h1E;      // YUV422 8-bit
      default: return 6'h24; // RGB888
    endcase
  endfunction
  // one packet; hf: 1 data bit, 2 ECC bit, 3 ECC bits 7:6, 4 two data bits;
  // pf: 1 payload bit, 2 CRC bit
  function void pkt(ref bit [7:0] b[$], input bit [7:0] di, input bit [15:0] w, input int hf, input int pf,
                    ref bit [31:0] x);
    bit [23:0] h = {w, di};
    bit [7:0] e = {2'b00, csis_ecc(h)};
    bit [15:0] c = 16'hFFFF;
    bit [7:0] p [$];
    int j;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    case (hf)
      1: h[x[15:8] % 24] ^= 1'b1;
      2: e[x[15:8] % 6] ^= 1'b1;
      3: e[7:6] = x[9:8] | 2'b01;
      4: begin j = x[15:8] % 24; h[j] ^= 1'b1; h[(j + 1 + x[23:16] % 23) % 24] ^= 1'b1; end
      default: ;
    endcase
    b.push_back(8'hB8); b.push_back(h[7:0]); b.push_back(h[15:8]); b.push_back(h[23:16]); b.push_back(e);
    if (di[5:0] >= 6'h10) begin
      for (int i = 0; i < w; i++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        p.push_back(x[7:0]); c = csis_crc(c, x[7:0]);
      end
      if (pf == 1 && w != 0) begin j = x[7:0] % w; p[j][x[10:8]] ^= 1'b1; end
      if (pf == 2) c[x[11:8]] ^= 1'b1;
      foreach (p[i]) b.push_back(p[i]);
      b.push_back(c[7:0]); b.push_back(c[15:8]);
    end
  endfunction
  function void build();
    bit [31:0] x = seed | 1;
    bit [7:0] b [$];
    bit [7:0] di = {vc, dt_of()};
    bit [15:0] w = 1 + wc % 48;
    int cut = -1;
    case (kind)
      10: pkt(b, {vc, 6'h00}, seed[15:0], 0, 0, x);
      11: pkt(b, {vc, 6'h01}, seed[15:0], 0, 0, x);
      12: pkt(b, {vc, 5'h01, seed[0]}, seed[15:0], 0, 0, x);
      13: begin pkt(b, {vc, 6'h00}, seed[15:0], 0, 0, x); pkt(b, di, w, 0, 0, x); end
      14: begin pkt(b, di, w, 0, 0, x); pkt(b, di, w, 0, 0, x); pkt(b, {vc, 6'h01}, seed[15:0], 0, 0, x); end
      15: pkt(b, di, 16'h0, 0, 0, x);
      16: pkt(b, di, w, 1, 0, x);
      17: pkt(b, di, w, 2, 0, x);
      18: pkt(b, di, w, 3, 0, x);
      19: pkt(b, di, w, 4, 0, x);
      20: pkt(b, di, w, 0, 1, x);
      21: pkt(b, di, w, 0, 2, x);
      22: begin pkt(b, di, w, 0, 0, x); cut = 1 + x[1:0]; end
      23: begin pkt(b, di, w, 0, 0, x); cut = 5 + x[15:8] % w; end
      24: begin pkt(b, di, w, 0, 0, x); cut = 5 + w + x[0]; end
      25: begin pkt(b, di, w, 4, 0, x); pkt(b, di, w, 0, 0, x); end
      26: begin pkt(b, di, w, 0, 0, x); b.push_back(8'h00); pkt(b, di, w, 0, 0, x); end
      27: pkt(b, di, 16'd100 + wc, 0, 0, x);
      28: pkt(b, di, w, 1, 0, x);
      default: pkt(b, di, w, 0, 0, x);
    endcase
    bits.delete();
    for (int i = 0; i < lead; i++) bits.push_back(1'b0);
    foreach (b[i]) for (int k = 0; k < 8; k++) bits.push_back(b[i][k]);
    if (cut >= 0) begin
      int n = lead + 8 * cut + x[18:16];
      while (bits.size() > n) void'(bits.pop_back());
    end else begin
      bit l = bits[bits.size() - 1];
      for (int i = 0; i < trail; i++) bits.push_back(!l);
    end
  endfunction

  function void do_copy(uvm_object rhs);
    csis_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    bits = rhs_.bits;
    rep = rhs_.rep;
    pay = rhs_.pay;
    kind = rhs_.kind;
    dsel = rhs_.dsel;
    vc = rhs_.vc;
    wc = rhs_.wc;
    lead = rhs_.lead;
    trail = rhs_.trail;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    csis_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (bits.size() != rhs_.bits.size()) return 0;
    foreach (bits[i]) if (bits[i] != rhs_.bits[i]) return 0;
    if (rep.size() != rhs_.rep.size()) return 0;
    foreach (rep[i]) if (rep[i] != rhs_.rep[i]) return 0;
    if (pay.size() != rhs_.pay.size()) return 0;
    foreach (pay[i]) if (pay[i] != rhs_.pay[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(csis_transaction rhs_);
    if (bits.size() != rhs_.bits.size()) return 0;
    foreach (bits[i]) if (bits[i] != rhs_.bits[i]) return 0;
    return 1;
  endfunction

  function string qstr_bits();
    string s = $sformatf("[%0d]{", bits.size());
    foreach (bits[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bits[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rep();
    string s = $sformatf("[%0d]{", rep.size());
    foreach (rep[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rep[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_pay();
    string s = $sformatf("[%0d]{", pay.size());
    foreach (pay[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", pay[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("CSIS{tag=%0d bits=%s rep=%s pay=%s}", tag, qstr_bits(), qstr_rep(), qstr_pay());
  endfunction
endclass
