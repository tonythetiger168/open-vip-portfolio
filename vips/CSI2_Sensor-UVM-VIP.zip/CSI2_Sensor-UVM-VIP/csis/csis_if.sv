// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_if.sv -- CSIS interface

interface csis_if (input logic clk);
  logic rst_n;

  logic rx_valid;
  logic rx_bit;
  logic rep_valid;
  logic [3:0] rep_flags;
  logic [7:0] rep_dt;
  logic [15:0] rep_wc;
  logic [15:0] rep_frame;
  logic [15:0] rep_line;
  logic out_valid;
  logic [7:0] out_data;

  modport DUT (input clk, rst_n, input rx_valid, input rx_bit, output rep_valid, output rep_flags, output rep_dt, output rep_wc, output rep_frame, output rep_line, output out_valid, output out_data);
  modport MON (input clk, rst_n, rx_valid, rx_bit, rep_valid, rep_flags, rep_dt, rep_wc, rep_frame, rep_line, out_valid, out_data);

  clocking drv_cb @(posedge clk);
    input rst_n, rep_valid, rep_flags, rep_dt, rep_wc, rep_frame, rep_line, out_valid, out_data;
    inout rx_valid, rx_bit;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, rx_valid, rx_bit, rep_valid, rep_flags, rep_dt, rep_wc, rep_frame, rep_line, out_valid, out_data;
  endclocking
endinterface
