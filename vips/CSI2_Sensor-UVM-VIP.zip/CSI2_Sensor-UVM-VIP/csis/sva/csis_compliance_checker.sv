// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_compliance_checker.sv -- CSIS concurrent assertion checks (bindable)

module csis_compliance_checker
  (input logic clk, input logic rst_n, input logic rx_valid, input logic rx_bit, input logic rep_valid, input logic [3:0] rep_flags, input logic [7:0] rep_dt, input logic [15:0] rep_wc, input logic [15:0] rep_frame, input logic [15:0] rep_line, input logic out_valid, input logic [7:0] out_data);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({rx_valid, rep_valid, out_valid}))
    else $error("CSIS: X on a valid");
  assert property (@(posedge clk) disable iff (!rst_n) rx_valid |-> !$isunknown(rx_bit))
    else $error("CSIS: X on rx_bit inside a burst");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_flags[1] |-> rep_flags == 4'b0010 && rep_dt == 8'h00 && rep_wc == 16'h0)
    else $error("CSIS: dropped header reported with fields");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_flags[0] |-> rep_dt[5:0] >= 6'h10)
    else $error("CSIS: CRC error on a short packet");
  assert property (@(posedge clk) disable iff (!rst_n) out_valid |-> !rep_valid)
    else $error("CSIS: payload byte and report in the same clock");
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_flags == 4'b1000);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_flags[2]);
endmodule
