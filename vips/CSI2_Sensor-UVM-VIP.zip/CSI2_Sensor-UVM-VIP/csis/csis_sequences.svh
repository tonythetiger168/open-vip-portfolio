// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_sequences.svh -- CSIS sequences

// Random traffic: cfg.num_items constrained-random items.
class csis_base_sequence extends uvm_sequence #(csis_transaction);
  `uvm_object_utils(csis_base_sequence)
  csis_config cfg;

  function new(string name = "csis_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = csis_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "csis_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class csis_directed_sequence extends uvm_sequence #(csis_transaction);
  `uvm_object_utils(csis_directed_sequence)
  csis_config cfg;

  function new(string name = "csis_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function csis_transaction item();
    item = csis_transaction::type_id::create("req");
  endfunction

  task send(csis_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    csis_transaction t;
    // a frame of RAW8 lines with line start / end, every data type, every fault, multi-packet bursts
    t = item(); t.set(10, 0, 32'h1); send(t);
    for (int i = 0; i < 6; i++) begin t = item(); t.set(0, 8 + i, 32'h100 + i); t.dsel = i % 4; send(t); end
    t = item(); t.set(12, 0, 32'h2); send(t);
    t = item(); t.set(12, 0, 32'h3); send(t);
    t = item(); t.set(11, 0, 32'h1); send(t);
    for (int k = 13; k < 32; k++)
      for (int s = 0; s < 3; s++) begin t = item(); t.set(k, 5 + 11 * s, 32'h1000 * k + 7 * s + 1); send(t); end
    for (int i = 0; i < 24; i++) begin t = item(); t.set(16, 3 + i, 32'h5000 + i); send(t); end
    t = item(); t.set(10, 0, 32'hFFFF); send(t);
  endtask
endclass
