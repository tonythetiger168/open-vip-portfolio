// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_coverage.svh -- CSIS functional coverage

class csis_coverage extends uvm_subscriber #(csis_transaction);
  `uvm_component_utils(csis_coverage)
  csis_config cfg;
  csis_transaction tr;

  covergroup csis_cg;
    cp_flags : coverpoint (tr.rep.size() ? tr.rep[0][59:56] : 4'h0) { bins clean = {0}; bins crc = {1}; bins unc = {2};
                                                                       bins cut = {4}; bins corr = {8}; bins corr_cut = {12}; }
    cp_dt    : coverpoint (tr.rep.size() ? tr.rep[0][53:48] : 6'h3F) { bins fs = {6'h00}; bins fe = {6'h01}; bins ls_le = {6'h02, 6'h03};
                                                                       bins raw8 = {6'h2A}; bins raw10 = {6'h2B}; bins yuv = {6'h1E};
                                                                       bins rgb = {6'h24}; }
    cp_vc    : coverpoint (tr.rep.size() ? tr.rep[0][55:54] : 2'd0);
    cp_npk   : coverpoint tr.rep.size() { bins one = {1}; bins multi = {[2:3]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    csis_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(csis_config)::get(this, "", "cfg", cfg))
      cfg = csis_config::type_id::create("cfg");
  endfunction

  function void write(csis_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    csis_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CSIS coverage: %0.1f%%", csis_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
