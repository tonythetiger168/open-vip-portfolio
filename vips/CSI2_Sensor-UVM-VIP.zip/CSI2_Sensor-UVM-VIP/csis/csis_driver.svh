// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_driver.svh -- CSIS driver: one HS burst per item: rx_valid high for the lead-in, packet and trailer bits (one per clock), then cfg.gap clocks low

class csis_driver extends uvm_driver #(csis_transaction);
  `uvm_component_utils(csis_driver)

  uvm_analysis_port #(csis_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual csis_if vif;
  csis_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual csis_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "csis: virtual interface not set")
    if (!uvm_config_db#(csis_config)::get(this, "", "cfg", cfg))
      cfg = csis_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    csis_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.rx_valid <= 1'b0;
    vif.drv_cb.rx_bit   <= 1'b0;
  endtask

  task drive_item(csis_transaction t);
    t.build();
    @(vif.drv_cb);
    foreach (t.bits[i]) begin
      vif.drv_cb.rx_valid <= 1'b1;
      vif.drv_cb.rx_bit   <= t.bits[i];
      @(vif.drv_cb);
    end
    vif.drv_cb.rx_valid <= 1'b0;
    vif.drv_cb.rx_bit   <= 1'b0;
    repeat ((cfg.gap < 4) ? 4 : cfg.gap) @(vif.drv_cb);
  endtask

endclass
