// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_monitor.svh -- CSIS monitor: the bits of each HS burst (rx_valid high) with the payload bytes and reports up to three clocks after it

class csis_monitor extends uvm_monitor;
  `uvm_component_utils(csis_monitor)

  virtual csis_if vif;
  uvm_analysis_port #(csis_transaction) ap;
  csis_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual csis_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "csis: virtual interface not set")
    if (!uvm_config_db#(csis_config)::get(this, "", "cfg", cfg))
      cfg = csis_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      csis_transaction t;
      int idle = 0;
      forever begin
        @(vif.mon_cb);
        if (t == null && vif.mon_cb.rx_valid === 1'b1) begin t = csis_transaction::type_id::create("t"); idle = 0; end
        if (t != null) begin
          if (vif.mon_cb.rep_valid === 1'b1)
            t.rep.push_back(csis_rep(vif.mon_cb.rep_flags, {vif.mon_cb.rep_wc, vif.mon_cb.rep_dt},
                                     vif.mon_cb.rep_frame, vif.mon_cb.rep_line));
          if (vif.mon_cb.out_valid === 1'b1) t.pay.push_back(vif.mon_cb.out_data);
          if (vif.mon_cb.rx_valid === 1'b1) begin t.bits.push_back(vif.mon_cb.rx_bit); idle = 0; end
          else if (++idle == 3) begin publish(t); t = null; end
        end
      end
    end
  endtask

  function void publish(csis_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
