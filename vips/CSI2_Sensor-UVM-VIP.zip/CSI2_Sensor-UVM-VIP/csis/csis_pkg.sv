// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_pkg.sv -- CSIS UVM VIP package

package csis_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import csis_defs_pkg::*;
  export csis_defs_pkg::*;

  `include "csis_transaction.svh"
  `include "csis_config.svh"
  `include "csis_sequencer.svh"
  `include "csis_driver.svh"
  `include "csis_monitor.svh"
  `include "csis_agent.svh"
  `include "csis_sequences.svh"
  `include "csis_checker.svh"
  `include "csis_coverage.svh"
endpackage
