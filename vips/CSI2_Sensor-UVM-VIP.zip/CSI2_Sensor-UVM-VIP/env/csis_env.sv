// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// csis_env.sv -- CSIS environment: reference-model scoreboard, checker, coverage

package csis_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import csis_defs_pkg::*;
  import csis_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class csis_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(csis_scoreboard)
    uvm_analysis_imp_exp #(csis_transaction, csis_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(csis_transaction, csis_scoreboard) obs_ap;

    csis_config cfg;
    csis_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [15:0] frm = 0;
    bit [15:0] lin = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(csis_config)::get(this, "", "cfg", cfg))
        cfg = csis_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(csis_transaction t);
      // bit-level receiver: sync hunt, header + ECC, payload + CRC, next sync or EoT
      int st = 0;                 // 0 hunt 1-3 header 4 ECC 5 payload 6-7 CRC 8 next 9 EoT
      int bc = 0;
      bit [6:0] sh = 0;
      bit [23:0] hdr = 0, hc = 0;
      bit [15:0] w = 0, pc = 0, crc = 0;
      bit [7:0] clo = 0;
      bit corr = 0;
      t.rep.delete(); t.pay.delete();
      foreach (t.bits[i]) begin
        bit [7:0] rb = {t.bits[i], sh};
        bit rdy = (bc == 7);
        sh = rb[7:1];
        bc = (bc + 1) % 8;
        if (st == 0) begin
          if (rb == 8'hB8) begin st = 1; bc = 0; end
        end else if (rdy) begin
          case (st)
            8: st = (rb == 8'hB8) ? 1 : 9;
            1: begin hdr[7:0] = rb; st = 2; end
            2: begin hdr[15:8] = rb; st = 3; end
            3: begin hdr[23:16] = rb; st = 4; end
            4: begin
                 bit [5:0] syn = rb[5:0] ^ csis_ecc(hdr);
                 bit [23:0] fx = csis_fix(syn);
                 bit oh = syn != 0 && (syn & (syn - 6'd1)) == 0;
                 if (!(syn == 0 || fx != 0 || oh)) begin st = 8; t.rep.push_back(csis_rep(4'b0010, 24'h0, frm, lin)); end
                 else begin
                   hc = hdr ^ fx; corr = (syn != 0);
                   if (hc[5:0] < 6'h10) begin
                     st = 8;
                     if (hc[5:0] == 6'h00) begin frm++; lin = 0; end
                     t.rep.push_back(csis_rep({corr, 3'b000}, hc, frm, lin));
                   end else begin
                     w = hc[23:8]; pc = 0; crc = 16'hFFFF;
                     st = (w == 0) ? 6 : 5;
                   end
                 end
               end
            5: begin crc = csis_crc(crc, rb); t.pay.push_back(rb); pc++; if (pc == w) st = 6; end
            6: begin clo = rb; st = 7; end
            7: begin
                 st = 8;
                 if ({rb, clo} == crc) lin++;
                 t.rep.push_back(csis_rep({corr, 2'b00, {rb, clo} != crc}, hc, frm, lin));
               end
            default: ;
          endcase
        end
      end
      if (st >= 1 && st <= 7) t.rep.push_back(csis_rep({corr && st >= 5, 3'b100}, (st >= 5) ? hc : 24'h0, frm, lin));
    endfunction

    function void write_exp(csis_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(csis_transaction t);
      csis_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        csis_transaction e = exp_q.pop_front();
        csis_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("csis scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class csis_env extends uvm_env;
    `uvm_component_utils(csis_env)
    csis_agent      agt;
    csis_scoreboard sb;
    csis_checker    chk;
    csis_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = csis_agent     ::type_id::create("agt", this);
      sb  = csis_scoreboard::type_id::create("sb",  this);
      chk = csis_checker   ::type_id::create("chk", this);
      cov = csis_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
