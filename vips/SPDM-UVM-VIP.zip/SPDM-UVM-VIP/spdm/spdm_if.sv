// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_if.sv -- SPDM interface

interface spdm_if (input logic clk);
  logic rst_n;

  logic req_valid;
  logic [7:0] req_data;
  logic req_last;
  logic rsp_valid;
  logic [7:0] rsp_data;
  logic rsp_last;
  logic err;

  modport DUT (input clk, rst_n, input req_valid, input req_data, input req_last, output rsp_valid, output rsp_data, output rsp_last, output err);
  modport MON (input clk, rst_n, req_valid, req_data, req_last, rsp_valid, rsp_data, rsp_last, err);

  clocking drv_cb @(posedge clk);
    input rst_n, rsp_valid, rsp_data, rsp_last, err;
    inout req_valid, req_data, req_last;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, req_valid, req_data, req_last, rsp_valid, rsp_data, rsp_last, err;
  endclocking
endinterface
