// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_defs.sv -- SPDM shared type definitions

package spdm_defs_pkg;

  typedef enum bit [1:0] {SPDM_OK, SPDM_ERR} spdm_status_e;

  localparam bit [7:0] SPDM_V10 = 8'h10, SPDM_V14 = 8'h14;
  localparam bit [7:0] SPDM_GET_VERSION = 8'h84, SPDM_GET_CAPS = 8'hE1, SPDM_NEG_ALGS = 8'hE3, SPDM_GET_MEAS = 8'hE0;
  localparam bit [7:0] SPDM_ERROR = 8'h7F;
  localparam bit [7:0] SPDM_E_INVALID = 8'h01, SPDM_E_UNEXPECTED = 8'h04, SPDM_E_UNSUPPORTED = 8'h07,
                       SPDM_E_RSP_TOO_LARGE = 8'h0D, SPDM_E_REQ_TOO_LARGE = 8'h0E, SPDM_E_VERSION = 8'h41;

endpackage
