// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_transaction.svh -- SPDM transaction

class spdm_transaction extends uvm_sequence_item;
  `uvm_object_utils(spdm_transaction)

  // request (driven by the agent)
  bit [7:0] rq[$];
  // response (returned by the DUT)
  bit [7:0] rs[$];
  // bookkeeping (not compared)
  rand bit [3:0] kind;
  rand bit [7:0] p;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { kind dist { 0 := 2, 1 := 3, 2 := 3, 3 := 6, 4 := 2, 5 := 2, 6 := 1, 7 := 1 }; kind <= 7; }

  function new(string name = "spdm_transaction"); super.new(name); endfunction

  // message builders (little-endian multi-byte fields, as DSP0274 requires)
  function void get_version(bit [7:0] v = SPDM_V10, int extra = 0);
    rq.delete(); rq = '{v, SPDM_GET_VERSION, 8'h00, 8'h00};
    repeat (extra) rq.push_back(8'h00);
  endfunction
  function void get_caps(bit [7:0] v = SPDM_V14, bit [31:0] dts = 64, bit [31:0] mx = 64, bit chunk = 0,
                         bit [7:0] p1 = 0, int len = 20);
    bit [31:0] fl = {14'h0, chunk, 17'h0};
    rq.delete();
    rq = '{v, SPDM_GET_CAPS, p1, 8'h00, 8'h00, 8'd10, 8'h00, 8'h00,
           fl[7:0], fl[15:8], fl[23:16], fl[31:24], dts[7:0], dts[15:8], dts[23:16], dts[31:24],
           mx[7:0], mx[15:8], mx[23:16], mx[31:24]};
    while (rq.size() > len) void'(rq.pop_back());
    while (rq.size() < len) rq.push_back(8'h00);
  endfunction
  function void neg_algs(bit [7:0] v = SPDM_V14, bit [7:0] mspec = 8'h01, int len = 32, int lfield = -1);
    bit [15:0] l = (lfield < 0) ? 16'(len) : 16'(lfield);
    rq.delete();
    rq = '{v, SPDM_NEG_ALGS, 8'h00, 8'h00, l[7:0], l[15:8], mspec, 8'h00};
    rq.push_back(8'h10); rq.push_back(8'h00); rq.push_back(8'h00); rq.push_back(8'h00);   // BaseAsymAlgo: ECDSA P-256
    rq.push_back(8'h01); rq.push_back(8'h00); rq.push_back(8'h00); rq.push_back(8'h00);   // BaseHashAlgo: SHA-256
    while (rq.size() < len) rq.push_back(8'h00);
  endfunction
  function void get_meas(bit [7:0] op, bit [7:0] p1 = 0, bit [63:0] ctx = 64'h0, bit [7:0] v = SPDM_V14, int len = 12);
    rq.delete();
    rq = '{v, SPDM_GET_MEAS, p1, op};
    for (int i = 0; i < 8; i++) rq.push_back(ctx[8 * i +: 8]);
    while (rq.size() > len) void'(rq.pop_back());
    while (rq.size() < len) rq.push_back(8'h00);
  endfunction
  function void raw(bit [7:0] v, bit [7:0] code, int len);
    rq.delete(); rq.push_back(v); rq.push_back(code);
    for (int i = 2; i < len; i++) rq.push_back(8'(i * 37));
    while (rq.size() > len) void'(rq.pop_back());
  endfunction
  // for coverage
  function bit [7:0] rcode(); return (rs.size() >= 2) ? rs[1] : 8'h00; endfunction
  function bit [7:0] ecode(); return (rs.size() >= 3 && rs[1] == SPDM_ERROR) ? rs[2] : 8'h00; endfunction
  function bit [7:0] qcode(); return (rq.size() >= 2) ? rq[1] : 8'h00; endfunction
  function int mop(); return (rs.size() >= 2 && rs[1] == 8'h60 && rq.size() >= 4) ? rq[3] : -1; endfunction

  function void do_copy(uvm_object rhs);
    spdm_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    rq = rhs_.rq;
    rs = rhs_.rs;
    kind = rhs_.kind;
    p = rhs_.p;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    spdm_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (rq.size() != rhs_.rq.size()) return 0;
    foreach (rq[i]) if (rq[i] != rhs_.rq[i]) return 0;
    if (rs.size() != rhs_.rs.size()) return 0;
    foreach (rs[i]) if (rs[i] != rhs_.rs[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(spdm_transaction rhs_);
    if (rq.size() != rhs_.rq.size()) return 0;
    foreach (rq[i]) if (rq[i] != rhs_.rq[i]) return 0;
    return 1;
  endfunction

  function string qstr_rq();
    string s = $sformatf("[%0d]{", rq.size());
    foreach (rq[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rq[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rs();
    string s = $sformatf("[%0d]{", rs.size());
    foreach (rs[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rs[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SPDM{tag=%0d rq=%s rs=%s}", tag, qstr_rq(), qstr_rs());
  endfunction
endclass
