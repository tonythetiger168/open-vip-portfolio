// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_coverage.svh -- SPDM functional coverage

class spdm_coverage extends uvm_subscriber #(spdm_transaction);
  `uvm_component_utils(spdm_coverage)
  spdm_config cfg;
  spdm_transaction tr;

  covergroup spdm_cg;
    cp_req  : coverpoint tr.qcode() { bins version = {8'h84}; bins caps = {8'hE1}; bins algs = {8'hE3}; bins meas = {8'hE0};
                                      bins rir = {8'hFF}; bins other = default; }
    cp_rsp  : coverpoint tr.rcode() { bins version = {8'h04}; bins caps = {8'h61}; bins algs = {8'h63}; bins meas = {8'h60};
                                      bins error = {8'h7F}; bins none = {8'h00}; }
    cp_err  : coverpoint tr.ecode() { bins invalid = {8'h01}; bins unexpected = {8'h04}; bins unsupported = {8'h07};
                                      bins rsp_large = {8'h0D}; bins req_large = {8'h0E}; bins version = {8'h41}; bins none = {8'h00}; }
    cp_mop  : coverpoint tr.mop() { bins count = {0}; bins one[] = {[1:3]}; bins all = {255}; }
    cx_req_err : cross cp_req, cp_err {
      ignore_bins na = binsof(cp_req.version) && binsof(cp_err.unsupported);
      ignore_bins na2 = binsof(cp_req.version) && binsof(cp_err.unexpected);
      ignore_bins na3 = binsof(cp_req.rir) && (binsof(cp_err.invalid) || binsof(cp_err.unsupported) || binsof(cp_err.rsp_large));
      ignore_bins na4 = binsof(cp_req.other) && (binsof(cp_err.invalid) || binsof(cp_err.rsp_large));
      ignore_bins na5 = (binsof(cp_req.caps) || binsof(cp_req.algs) || binsof(cp_req.version)) && (binsof(cp_err.unsupported) || binsof(cp_err.rsp_large));
      ignore_bins na6 = binsof(cp_req.meas) && binsof(cp_err.unsupported);
      ignore_bins na7 = (binsof(cp_req.version) || binsof(cp_req.caps) || binsof(cp_req.algs) || binsof(cp_req.meas) || binsof(cp_req.rir)) && binsof(cp_err.req_large);
      ignore_bins na8 = binsof(cp_req.other) && binsof(cp_err.none);
      ignore_bins na9 = binsof(cp_req.rir) && binsof(cp_err.none);
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    spdm_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(spdm_config)::get(this, "", "cfg", cfg))
      cfg = spdm_config::type_id::create("cfg");
  endfunction

  function void write(spdm_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    spdm_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SPDM coverage: %0.1f%%", spdm_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
