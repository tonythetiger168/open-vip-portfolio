// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_sequences.svh -- SPDM sequences

// Random traffic: cfg.num_items constrained-random items.
class spdm_base_sequence extends uvm_sequence #(spdm_transaction);
  `uvm_object_utils(spdm_base_sequence)
  spdm_config cfg;

  function new(string name = "spdm_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = spdm_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "spdm_transaction randomize() failed")
      case (req.kind)
        0: req.get_version((req.p[7:6] == 0) ? 8'h11 : SPDM_V10, (req.p[5:4] == 0) ? 1 : 0);
        1: req.get_caps((req.p[7:5] == 0) ? 8'h13 : SPDM_V14, 32'(40 + req.p[3:0] * 8), 32'(40 + req.p[3:0] * 8 + (req.p[4] ? 16 : 0)), req.p[4]);
        2: req.neg_algs(SPDM_V14, {7'h0, req.p[0]}, 32 + 4 * req.p[2:1], (req.p[7:5] == 0) ? 40 : -1);
        3: req.get_meas((req.p[2:0] == 7) ? 8'hFF : 8'(req.p[2:0] % 5), {7'h0, req.p[7:6] == 0}, {req.seed, req.seed ^ 32'hA5A5});
        4: req.raw(SPDM_V14, 8'h80 | req.p[6:0], 4 + req.p[3:0]);
        5: req.raw(SPDM_V14, 8'hE0, 60 + req.p[3:0]);
        6: req.raw(SPDM_V14, 8'hFF, 4);
        default: req.raw(SPDM_V14, req.p, 1);
      endcase
      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class spdm_directed_sequence extends uvm_sequence #(spdm_transaction);
  `uvm_object_utils(spdm_directed_sequence)
  spdm_config cfg;

  function new(string name = "spdm_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function spdm_transaction item();
    item = spdm_transaction::type_id::create("req");
  endfunction

  task send(spdm_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    spdm_transaction t;
    // the connection from scratch: out of order, version errors, VCA, retries, every measurement operation,
    // size limits, unsupported requests, a restart
    t = item(); t.get_caps(); send(t);                                   // before GET_VERSION
    t = item(); t.get_version(8'h11); send(t);                           // VersionMismatch
    t = item(); t.get_version(SPDM_V10, 1); send(t);                     // 5 bytes: InvalidRequest
    t = item(); t.raw(SPDM_V10, 8'hFF, 4); send(t);                      // RESPOND_IF_READY before VERSION
    t = item(); t.raw(SPDM_V14, 8'h81, 4); send(t);                      // GET_DIGESTS before VERSION
    t = item(); t.get_version(); send(t);
    t = item(); t.get_caps(8'h12); send(t);                              // wrong SPDMVersion
    t = item(); t.neg_algs(8'h12); send(t);
    t = item(); t.get_meas(8'h00, 0, 0, 8'h13); send(t);
    t = item(); t.raw(8'h13, 8'h81, 4); send(t);
    t = item(); t.raw(SPDM_V10, 8'hFF, 4); send(t);
    t = item(); t.neg_algs(); send(t);                                   // before CAPABILITIES
    t = item(); t.get_caps(SPDM_V14, 41, 41); send(t);                   // DataTransferSize < 42
    t = item(); t.get_caps(SPDM_V14, 64, 64, 0, 8'h01); send(t);         // Supported Algorithms block
    t = item(); t.get_caps(SPDM_V14, 64, 63, 1); send(t);                // MaxSPDMmsgSize < DataTransferSize
    t = item(); t.get_caps(SPDM_V14, 64, 96, 0); send(t);                // no CHUNK_CAP, sizes differ
    t = item(); t.get_caps(SPDM_V14, 64, 64, 0, 0, 19); send(t);         // short
    t = item(); t.get_caps(SPDM_V14, 64, 64); send(t);
    t = item(); t.get_caps(SPDM_V14, 64, 64); send(t);                   // identical retry
    t = item(); t.get_caps(SPDM_V14, 80, 80); send(t);                   // non-identical
    t = item(); t.get_meas(8'h00); send(t);                              // before ALGORITHMS
    t = item(); t.neg_algs(SPDM_V14, 8'h01, 32, 34); send(t);            // Length field wrong
    t = item(); t.neg_algs(SPDM_V14, 8'h01, 30, 30); send(t);            // too short
    t = item(); t.neg_algs(); send(t);
    t = item(); t.neg_algs(); send(t);                                   // identical retry
    t = item(); t.neg_algs(SPDM_V14, 8'h01, 36); send(t);                // non-identical
    t = item(); t.get_caps(SPDM_V14, 64, 64); send(t);                   // out of order now
    for (int op = 0; op <= 4; op++) begin t = item(); t.get_meas(8'(op), 0, 64'h0102030405060708 + op); send(t); end
    t = item(); t.get_meas(8'hFF); send(t);                              // 85 bytes > 64: ResponseTooLarge
    t = item(); t.get_meas(8'h01, 8'h01); send(t);                       // SignatureRequested
    t = item(); t.get_meas(8'h01, 8'h02); send(t);                       // RawBitStreamRequested
    t = item(); t.get_meas(8'h01, 0, 0, SPDM_V14, 11); send(t);          // short
    t = item(); t.raw(SPDM_V14, 8'h81, 4); send(t);                      // GET_DIGESTS: unsupported
    t = item(); t.raw(SPDM_V14, 8'h83, 40); send(t);                     // CHALLENGE: unsupported
    t = item(); t.raw(SPDM_V14, 8'h60, 4); send(t);                      // a response code as a request
    t = item(); t.raw(SPDM_V14, 8'hFF, 4); send(t);                      // RESPOND_IF_READY: nothing pending
    t = item(); t.raw(SPDM_V14, 8'hE0, 70); send(t);                     // RequestTooLarge
    t = item(); t.raw(SPDM_V14, 8'h81, 70); send(t);
    t = item(); t.raw(SPDM_V14, 8'hE0, 1); send(t);                      // 1 byte: discarded
    t = item(); t.get_meas(8'h03, 0, 64'hFEED); send(t);
    // restart with room for every block, and without the DMTF measurement specification
    t = item(); t.get_version(); send(t);
    t = item(); t.get_meas(8'h01); send(t);                              // state cleared
    t = item(); t.get_caps(SPDM_V14, 128, 128); send(t);
    t = item(); t.neg_algs(); send(t);
    t = item(); t.get_meas(8'hFF, 8'h06, 64'hC0FFEE); send(t);
    t = item(); t.get_meas(8'h02); send(t);
    t = item(); t.get_version(); send(t);
    t = item(); t.get_caps(SPDM_V14, 256, 1024, 1); send(t);
    t = item(); t.neg_algs(SPDM_V14, 8'h00); send(t);                    // no DMTF: nothing selected
    t = item(); t.get_meas(8'h00); send(t);
  endtask
endclass
