// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_compliance_checker.sv -- SPDM concurrent assertion checks (bindable)

module spdm_compliance_checker
  (input logic clk, input logic rst_n, input logic req_valid, input logic [7:0] req_data, input logic req_last, input logic rsp_valid, input logic [7:0] rsp_data, input logic rsp_last, input logic err);

  // outputs are never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({rsp_valid, rsp_last, err}))
    else $error("SPDM: X on rsp_valid / rsp_last / err");
  assert property (@(posedge clk) disable iff (!rst_n) rsp_valid |-> !$isunknown(rsp_data))
    else $error("SPDM: X on response data");
  // a response follows the last byte of a request, without gaps, and ends once
  assert property (@(posedge clk) disable iff (!rst_n) $rose(rsp_valid) |-> $past(req_valid && req_last))
    else $error("SPDM: response without a request");
  assert property (@(posedge clk) disable iff (!rst_n) rsp_valid && !rsp_last |=> rsp_valid)
    else $error("SPDM: gap inside a response");
  assert property (@(posedge clk) disable iff (!rst_n) rsp_last |-> rsp_valid)
    else $error("SPDM: rsp_last without rsp_valid");
  // every response starts with an SPDMVersion of 1.0 or 1.4 (4-byte header, SPDM version)
  assert property (@(posedge clk) disable iff (!rst_n) $rose(rsp_valid) |-> rsp_data inside {8'h10, 8'h14})
    else $error("SPDM: response SPDMVersion");
  cover property (@(posedge clk) disable iff (!rst_n) err);
  cover property (@(posedge clk) disable iff (!rst_n) rsp_valid && rsp_last);
endmodule
