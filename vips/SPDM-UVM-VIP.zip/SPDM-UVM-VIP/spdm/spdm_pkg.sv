// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_pkg.sv -- SPDM UVM VIP package

package spdm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import spdm_defs_pkg::*;
  export spdm_defs_pkg::*;

  `include "spdm_transaction.svh"
  `include "spdm_config.svh"
  `include "spdm_sequencer.svh"
  `include "spdm_driver.svh"
  `include "spdm_monitor.svh"
  `include "spdm_agent.svh"
  `include "spdm_sequences.svh"
  `include "spdm_checker.svh"
  `include "spdm_coverage.svh"
endpackage
