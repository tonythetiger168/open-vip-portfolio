// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_checker.svh -- SPDM protocol checker on monitored items

class spdm_checker extends uvm_component;
  `uvm_component_utils(spdm_checker)
  uvm_analysis_imp #(spdm_transaction, spdm_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  spdm_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(spdm_config)::get(this, "", "cfg", cfg))
      cfg = spdm_config::type_id::create("cfg");
  endfunction

  function void fail(spdm_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("SPDM: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(spdm_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.rs.size() != 0 && t.rs.size() < 4) fail(t, "response shorter than the 4-byte SPDM header");
      if (t.rs.size() >= 2 && t.rq.size() >= 2 && t.rs[1] != SPDM_ERROR && t.rs[1] != (t.rq[1] & 8'h7F))
        fail(t, "response code is not the request code with bit 7 cleared");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("SPDM checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
