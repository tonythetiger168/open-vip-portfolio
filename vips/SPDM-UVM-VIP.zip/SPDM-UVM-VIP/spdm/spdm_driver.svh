// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_driver.svh -- SPDM driver: one item per request message: its bytes one per clock (last flagged), then the response until its last byte, or cfg.wait_rsp clocks without one (a discarded request), then two idle clocks

class spdm_driver extends uvm_driver #(spdm_transaction);
  `uvm_component_utils(spdm_driver)

  uvm_analysis_port #(spdm_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual spdm_if vif;
  spdm_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual spdm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spdm: virtual interface not set")
    if (!uvm_config_db#(spdm_config)::get(this, "", "cfg", cfg))
      cfg = spdm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    spdm_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.req_valid <= 1'b0; vif.drv_cb.req_data <= 8'h00; vif.drv_cb.req_last <= 1'b0;
  endtask

  task drive_item(spdm_transaction t);
    int w = 0;
    bit got = 0, done = 0;
    foreach (t.rq[i]) begin
      vif.drv_cb.req_valid <= 1'b1;
      vif.drv_cb.req_data  <= t.rq[i];
      vif.drv_cb.req_last  <= (i == t.rq.size() - 1);
      @(vif.drv_cb);
    end
    vif.drv_cb.req_valid <= 1'b0; vif.drv_cb.req_last <= 1'b0; vif.drv_cb.req_data <= 8'h00;
    while (!done) begin
      @(vif.drv_cb);
      if (vif.drv_cb.rsp_valid === 1'b1) begin
        got = 1;
        if (vif.drv_cb.rsp_last === 1'b1) done = 1;
      end else if (!got && ++w >= cfg.wait_rsp) done = 1;
    end
    repeat (2) @(vif.drv_cb);
  endtask

endclass
