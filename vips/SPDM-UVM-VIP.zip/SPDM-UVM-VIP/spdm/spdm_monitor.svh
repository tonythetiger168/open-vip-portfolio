// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_monitor.svh -- SPDM monitor: one item per request message, completed by the response message (or by the next request when the Responder discarded it)

class spdm_monitor extends uvm_monitor;
  `uvm_component_utils(spdm_monitor)

  virtual spdm_if vif;
  uvm_analysis_port #(spdm_transaction) ap;
  spdm_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual spdm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spdm: virtual interface not set")
    if (!uvm_config_db#(spdm_config)::get(this, "", "cfg", cfg))
      cfg = spdm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      spdm_transaction t = null;
      bit in_req = 0;
      wait (vif.rst_n === 1'b1);
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.req_valid === 1'b1) begin
          if (!in_req) begin
            if (t != null) publish(t);            // the previous request got no response
            t = spdm_transaction::type_id::create("t");
            in_req = 1;
          end
          t.rq.push_back(vif.mon_cb.req_data);
          if (vif.mon_cb.req_last === 1'b1) in_req = 0;
        end
        if (vif.mon_cb.rsp_valid === 1'b1 && t != null) begin
          t.rs.push_back(vif.mon_cb.rsp_data);
          if (vif.mon_cb.rsp_last === 1'b1) begin publish(t); t = null; end
        end
      end
    end
  endtask

  function void publish(spdm_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
