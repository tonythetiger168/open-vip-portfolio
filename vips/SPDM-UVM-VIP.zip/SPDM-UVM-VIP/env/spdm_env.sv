// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdm_env.sv -- SPDM environment: reference-model scoreboard, checker, coverage

package spdm_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import spdm_defs_pkg::*;
  import spdm_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class spdm_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(spdm_scoreboard)
    uvm_analysis_imp_exp #(spdm_transaction, spdm_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(spdm_transaction, spdm_scoreboard) obs_ap;

    spdm_config cfg;
    spdm_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // the Responder (scoreboard copy), kept across items
    int        st = 0;                     // 0 start, 1 VERSION sent, 2 CAPABILITIES sent, 3 ALGORITHMS sent
    bit [7:0]  caps [$], algs [$];
    bit [31:0] rmax = 0;
    bit        msel = 0;
    bit [31:0] ns = 32'h5EED1234;
    function void err(ref bit [7:0] r [$], input bit [7:0] v, bit [7:0] code, bit [7:0] d = 8'h00);
      r = '{v, SPDM_ERROR, code, d};
    endfunction
    function void block(ref bit [7:0] r [$], input int i);
      bit [7:0] val [$];
      case (i)
        1: val = '{8'h12, 8'h34, 8'h56, 8'h78};
        2: val = '{8'hA0, 8'hA1, 8'hA2, 8'hA3, 8'hA4, 8'hA5, 8'hA6, 8'hA7};
        default: val = '{8'h04, 8'h01};
      endcase
      r.push_back(8'(i)); r.push_back(8'h01); r.push_back(8'(3 + val.size())); r.push_back(8'h00);
      r.push_back((i == 1) ? 8'h80 : (i == 2) ? 8'h81 : 8'h86); r.push_back(8'(val.size())); r.push_back(8'h00);
      foreach (val[k]) r.push_back(val[k]);
    endfunction
    function void respond(bit [7:0] q [$], ref bit [7:0] r [$]);
      int n = q.size();
      r.delete();
      if (n < 2) return;
      if (n > 64) begin err(r, (st == 0 || q[1] == SPDM_GET_VERSION) ? SPDM_V10 : SPDM_V14, SPDM_E_REQ_TOO_LARGE); return; end
      if (q[1] == SPDM_GET_VERSION) begin
        if (q[0] != SPDM_V10) err(r, SPDM_V10, SPDM_E_VERSION);
        else if (n != 4) err(r, SPDM_V10, SPDM_E_INVALID);
        else begin st = 1; caps.delete(); algs.delete(); msel = 0; r = '{SPDM_V10, 8'h04, 8'h00, 8'h00, 8'h00, 8'h01, 8'h00, 8'h14}; end
        return;
      end
      if (st == 0) begin err(r, SPDM_V10, SPDM_E_UNEXPECTED); return; end
      if (q[0] != SPDM_V14) begin err(r, SPDM_V14, SPDM_E_VERSION); return; end
      case (q[1])
        SPDM_GET_CAPS: begin
          bit [31:0] dts = {q[15], q[14], q[13], q[12]}, mx = {q[19], q[18], q[17], q[16]};
          if (st == 3 || (st == 2 && q != caps)) err(r, SPDM_V14, SPDM_E_UNEXPECTED);
          else if (n != 20 || q[2][0] || dts < 42 || mx < dts || (!q[10][1] && mx != dts)) err(r, SPDM_V14, SPDM_E_INVALID);
          else begin
            st = 2; caps = q; rmax = mx;
            r = '{SPDM_V14, 8'h61, 8'h00, 8'h00, 8'h00, 8'd12, 8'h00, 8'h00, 8'h08, 8'h00, 8'h00, 8'h00,
                  8'd64, 8'h00, 8'h00, 8'h00, 8'd64, 8'h00, 8'h00, 8'h00};
          end
        end
        SPDM_NEG_ALGS: begin
          if (st == 1 || (st == 3 && q != algs)) err(r, SPDM_V14, SPDM_E_UNEXPECTED);
          else if (n < 32 || {q[5], q[4]} != n) err(r, SPDM_V14, SPDM_E_INVALID);
          else begin
            st = 3; algs = q; msel = q[6][0];
            r = '{SPDM_V14, 8'h63, 8'h00, 8'h00, 8'd36, 8'h00, {7'h0, msel}, 8'h00, {7'h0, msel}};
            while (r.size() < 36) r.push_back(8'h00);
          end
        end
        SPDM_GET_MEAS: begin
          if (st != 3 || !msel) err(r, SPDM_V14, SPDM_E_UNEXPECTED);
          else if (n != 12 || q[2][0] || !(q[3] inside {[0:3], 8'hFF})) err(r, SPDM_V14, SPDM_E_INVALID);
          else begin
            bit [7:0] rec [$];
            int nb = 0;
            if (q[3] == 8'hFF) begin for (int i = 1; i <= 3; i++) block(rec, i); nb = 3; end
            else if (q[3] != 0) begin block(rec, q[3]); nb = 1; end
            r = '{SPDM_V14, 8'h60, (q[3] == 0) ? 8'd3 : 8'h00, 8'h00, 8'(nb), 8'(rec.size()), 8'h00, 8'h00};
            foreach (rec[i]) r.push_back(rec[i]);
            if (r.size() + 42 > rmax) begin
              bit [31:0] a = r.size() + 42;
              err(r, SPDM_V14, SPDM_E_RSP_TOO_LARGE);
              r.push_back(a[7:0]); r.push_back(a[15:8]); r.push_back(a[23:16]); r.push_back(a[31:24]);
            end else begin
              for (int w = 0; w < 8; w++) begin
                ns ^= ns << 13; ns ^= ns >> 17; ns ^= ns << 5;
                for (int b = 0; b < 4; b++) r.push_back(ns[8 * b +: 8]);
              end
              r.push_back(8'h00); r.push_back(8'h00);
              for (int i = 4; i < 12; i++) r.push_back(q[i]);
            end
          end
        end
        8'hFF: err(r, SPDM_V14, SPDM_E_UNEXPECTED);
        default: err(r, SPDM_V14, SPDM_E_UNSUPPORTED, q[1]);
      endcase
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(spdm_config)::get(this, "", "cfg", cfg))
        cfg = spdm_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(spdm_transaction t);
      respond(t.rq, t.rs);
    endfunction

    function void write_exp(spdm_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(spdm_transaction t);
      spdm_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        spdm_transaction e = exp_q.pop_front();
        spdm_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("spdm scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class spdm_env extends uvm_env;
    `uvm_component_utils(spdm_env)
    spdm_agent      agt;
    spdm_scoreboard sb;
    spdm_checker    chk;
    spdm_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = spdm_agent     ::type_id::create("agt", this);
      sb  = spdm_scoreboard::type_id::create("sb",  this);
      chk = spdm_checker   ::type_id::create("chk", this);
      cov = spdm_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
