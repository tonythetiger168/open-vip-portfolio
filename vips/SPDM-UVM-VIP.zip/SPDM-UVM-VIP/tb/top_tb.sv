// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SPDM testbench top with a functional SPDM DUT model

`ifndef SPDM_UVM_VIP_TB_SV
`define SPDM_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import spdm_defs_pkg::*;
import spdm_pkg::*;
import spdm_env_pkg::*;
import spdm_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  spdm_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  spdm_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .req_valid(vif.req_valid),
    .req_data(vif.req_data),
    .req_last(vif.req_last),
    .rsp_valid(vif.rsp_valid),
    .rsp_data(vif.rsp_data),
    .rsp_last(vif.rsp_last),
    .err(vif.err)
  );

  // Concurrent protocol checks
  spdm_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .req_valid(vif.req_valid),
    .req_data(vif.req_data),
    .req_last(vif.req_last),
    .rsp_valid(vif.rsp_valid),
    .rsp_data(vif.rsp_data),
    .rsp_last(vif.rsp_last),
    .err(vif.err)
  );

  initial begin
    uvm_config_db#(virtual spdm_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module spdm_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       req_valid,
  input  logic [7:0] req_data,
  input  logic       req_last,
  output logic       rsp_valid,
  output logic [7:0] rsp_data,
  output logic       rsp_last,
  output logic       err
);
  logic [7:0]  q  [0:63];
  logic [7:0]  r  [0:127];
  logic [7:0]  cq [0:19];          // the GET_CAPABILITIES that succeeded
  logic [7:0]  aq [0:63];          // the NEGOTIATE_ALGORITHMS that succeeded
  integer      qn, rn, ri, an, st, i, w, nb, k;
  logic [31:0] rmax, ns, dts, mx, a;
  logic        msel, busy, same;

  task automatic put(input logic [7:0] b); r[rn] = b; rn = rn + 1; endtask
  task automatic error(input logic [7:0] v, input logic [7:0] code, input logic [7:0] d);
    rn = 0; put(v); put(8'h7F); put(code); put(d);
  endtask
  task automatic block(input integer idx);
    put(idx[7:0]); put(8'h01);
    case (idx)
      1: begin put(8'd7);  put(8'h00); put(8'h80); put(8'd4); put(8'h00);
               put(8'h12); put(8'h34); put(8'h56); put(8'h78); end
      2: begin put(8'd11); put(8'h00); put(8'h81); put(8'd8); put(8'h00);
               for (k = 0; k < 8; k = k + 1) put(8'hA0 + k[7:0]); end
      default: begin put(8'd5); put(8'h00); put(8'h86); put(8'd2); put(8'h00); put(8'h04); put(8'h01); end
    endcase
  endtask

  task automatic respond();
    rn = 0;
    if (qn < 2) rn = 0;
    else if (qn > 64) error((st == 0 || q[1] == 8'h84) ? 8'h10 : 8'h14, 8'h0E, 8'h00);
    else if (q[1] == 8'h84) begin
      if (q[0] != 8'h10) error(8'h10, 8'h41, 8'h00);
      else if (qn != 4) error(8'h10, 8'h01, 8'h00);
      else begin
        st = 1; an = 0; msel = 1'b0;
        put(8'h10); put(8'h04); put(8'h00); put(8'h00); put(8'h00); put(8'h01); put(8'h00); put(8'h14);
      end
    end
    else if (st == 0) error(8'h10, 8'h04, 8'h00);
    else if (q[0] != 8'h14) error(8'h14, 8'h41, 8'h00);
    else if (q[1] == 8'hE1) begin
      dts = {q[15], q[14], q[13], q[12]};
      mx  = {q[19], q[18], q[17], q[16]};
      same = (qn == 20);
      for (i = 0; i < 20; i = i + 1) if (i < qn && q[i] != cq[i]) same = 1'b0;
      if (st == 3 || (st == 2 && !same)) error(8'h14, 8'h04, 8'h00);
      else if (qn != 20 || q[2][0] || dts < 42 || mx < dts || (!q[10][1] && mx != dts)) error(8'h14, 8'h01, 8'h00);
      else begin
        st = 2; rmax = mx;
        for (i = 0; i < 20; i = i + 1) cq[i] = q[i];
        put(8'h14); put(8'h61); put(8'h00); put(8'h00); put(8'h00); put(8'd12); put(8'h00); put(8'h00);
        put(8'h08); put(8'h00); put(8'h00); put(8'h00); put(8'd64); put(8'h00); put(8'h00); put(8'h00);
        put(8'd64); put(8'h00); put(8'h00); put(8'h00);
      end
    end
    else if (q[1] == 8'hE3) begin
      same = (qn == an);
      for (i = 0; i < 64; i = i + 1) if (i < qn && q[i] != aq[i]) same = 1'b0;
      if (st == 1 || (st == 3 && !same)) error(8'h14, 8'h04, 8'h00);
      else if (qn < 32 || {q[5], q[4]} != qn) error(8'h14, 8'h01, 8'h00);
      else begin
        st = 3; an = qn; msel = q[6][0];
        for (i = 0; i < 64; i = i + 1) aq[i] = (i < qn) ? q[i] : 8'h00;
        put(8'h14); put(8'h63); put(8'h00); put(8'h00); put(8'd36); put(8'h00); put({7'h0, msel}); put(8'h00);
        put({7'h0, msel});
        while (rn < 36) put(8'h00);
      end
    end
    else if (q[1] == 8'hE0) begin
      if (st != 3 || !msel) error(8'h14, 8'h04, 8'h00);
      else if (qn != 12 || q[2][0] || (q[3] > 8'd3 && q[3] != 8'hFF)) error(8'h14, 8'h01, 8'h00);
      else begin
        nb = (q[3] == 8'hFF) ? 3 : (q[3] == 8'h00) ? 0 : 1;
        put(8'h14); put(8'h60); put((q[3] == 8'h00) ? 8'd3 : 8'h00); put(8'h00); put(nb[7:0]);
        put(8'h00); put(8'h00); put(8'h00);           // MeasurementRecordLength, filled in below
        if (q[3] == 8'hFF) for (i = 1; i <= 3; i = i + 1) block(i);
        else if (q[3] != 8'h00) block(q[3]);
        r[5] = rn - 8;
        if (rn + 42 > rmax) begin
          a = rn + 42;
          error(8'h14, 8'h0D, 8'h00); put(a[7:0]); put(a[15:8]); put(a[23:16]); put(a[31:24]);
        end else begin
          for (w = 0; w < 8; w = w + 1) begin
            ns = ns ^ (ns << 13); ns = ns ^ (ns >> 17); ns = ns ^ (ns << 5);
            put(ns[7:0]); put(ns[15:8]); put(ns[23:16]); put(ns[31:24]);
          end
          put(8'h00); put(8'h00);
          for (i = 4; i < 12; i = i + 1) put(q[i]);
        end
      end
    end
    else if (q[1] == 8'hFF) error(8'h14, 8'h04, 8'h00);
    else error(8'h14, 8'h07, q[1]);
  endtask

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      qn = 0; rn = 0; ri = 0; an = 0; st = 0; rmax = 0; ns = 32'h5EED1234; msel = 1'b0; busy = 1'b0;
      rsp_valid <= 1'b0; rsp_data <= 8'h00; rsp_last <= 1'b0; err <= 1'b0;
    end else begin
      err <= 1'b0;
      if (req_valid && busy) err <= 1'b1;          // the Responder is still answering: dropped
      else if (req_valid) begin
        if (qn < 64) q[qn] = req_data;
        qn = qn + 1;
        if (req_last) begin
          respond();
          qn = 0; ri = 0;
          busy = (rn > 0);
        end
      end
      if (busy) begin
        rsp_valid <= 1'b1; rsp_data <= r[ri]; rsp_last <= (ri == rn - 1);
        ri = ri + 1;
        if (ri == rn) busy = 1'b0;
      end else begin
        rsp_valid <= 1'b0; rsp_data <= 8'h00; rsp_last <= 1'b0;
      end
    end
  end
endmodule
`endif
