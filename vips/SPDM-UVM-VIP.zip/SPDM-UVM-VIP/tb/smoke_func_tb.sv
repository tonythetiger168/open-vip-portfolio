// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SPDM DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened spdm_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic       req_valid = 1'b0, req_last = 1'b0;
  logic [7:0] req_data = 8'h00;
  wire        rsp_valid, rsp_last, err;
  wire  [7:0] rsp_data;

  always #5 clk = ~clk;

  spdm_model u_dut (.clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_data(req_data), .req_last(req_last),
                    .rsp_valid(rsp_valid), .rsp_data(rsp_data), .rsp_last(rsp_last), .err(err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // the response collector
  logic [7:0] rb [0:255];
  integer rl = 0, nresp = 0, nerr = 0;
  logic   rdone = 1'b0;
  always @(posedge clk) begin
    if (rsp_valid) begin
      rb[rl] = rsp_data; rl = rl + 1;
      if (rsp_last) begin rdone = 1'b1; nresp = nresp + 1; end
    end
    if (err) nerr = nerr + 1;
  end
  // the request being built
  logic [7:0] m [0:127];
  integer ml;
  task automatic b(input logic [7:0] x); m[ml] = x; ml = ml + 1; endtask
  task automatic b4(input logic [31:0] x); b(x[7:0]); b(x[15:8]); b(x[23:16]); b(x[31:24]); endtask
  // send m[0:ml-1] and wait for the response (or 30 quiet clocks)
  task automatic xfer();
    integer i, wq;
    rl = 0; rdone = 1'b0;
    for (i = 0; i < ml; i++) begin
      @(negedge clk); req_valid = 1'b1; req_data = m[i]; req_last = (i == ml - 1);
    end
    @(negedge clk); req_valid = 1'b0; req_last = 1'b0;
    wq = 0;
    while (!rdone && wq < 30) begin @(negedge clk); if (rl == 0) wq = wq + 1; end
    @(negedge clk);
  endtask
  function automatic bit is_err(input logic [7:0] v, input logic [7:0] code, input logic [7:0] d = 8'h00);
    is_err = rl == 4 && rb[0] == v && rb[1] == 8'h7F && rb[2] == code && rb[3] == d;
  endfunction
  task automatic get_version(input logic [7:0] v = 8'h10, input integer len = 4);
    ml = 0; b(v); b(8'h84); b(8'h00); b(8'h00); while (ml < len) b(8'h00); xfer();
  endtask
  task automatic get_caps(input logic [31:0] dts, input logic [31:0] mx, input bit chunk = 0, input logic [7:0] p1 = 0,
                          input logic [7:0] v = 8'h14, input integer len = 20);
    ml = 0; b(v); b(8'hE1); b(p1); b(8'h00); b(8'h00); b(8'd10); b(8'h00); b(8'h00);
    b4({14'h0, chunk, 17'h0}); b4(dts); b4(mx);
    ml = len; xfer();
  endtask
  task automatic neg_algs(input logic [7:0] mspec = 8'h01, input integer len = 32, input integer lf = -1);
    integer i;
    ml = 0; b(8'h14); b(8'hE3); b(8'h00); b(8'h00);
    b((lf < 0) ? len[7:0] : lf[7:0]); b(8'h00); b(mspec); b(8'h00); b4(32'h10); b4(32'h01);
    while (ml < len) b(8'h00);
    xfer();
  endtask
  task automatic get_meas(input logic [7:0] op, input logic [7:0] p1 = 0, input logic [63:0] ctx = 0, input integer len = 12);
    integer i;
    ml = 0; b(8'h14); b(8'hE0); b(p1); b(op);
    for (i = 0; i < 8; i++) b(ctx[8 * i +: 8]);
    ml = len; xfer();
  endtask
  // the Responder's Nonce stream, computed here independently
  logic [31:0] xs = 32'h5EED1234;
  function automatic bit nonce_ok(input integer at);
    integer wd, j;
    logic [31:0] v;
    nonce_ok = 1;
    for (wd = 0; wd < 8; wd++) begin
      xs = xs ^ (xs << 13); xs = xs ^ (xs >> 17); xs = xs ^ (xs << 5);
      v = {rb[at + 4 * wd + 3], rb[at + 4 * wd + 2], rb[at + 4 * wd + 1], rb[at + 4 * wd]};
      if (v != xs) nonce_ok = 0;
    end
  endfunction
  integer i;
  bit ok;

  initial begin
    repeat (3) @(posedge clk);
    #1 chk(rsp_valid === 1'b0 && err === 1'b0, "reset: no response");
    rst_n = 1;
    repeat (2) @(posedge clk);

    // before GET_VERSION
    get_caps(64, 64);
    chk(is_err(8'h10, 8'h04), "GET_CAPABILITIES before GET_VERSION: ERROR UnexpectedRequest (SPDMVersion 1.0)");
    get_version(8'h11);
    chk(is_err(8'h10, 8'h41), "GET_VERSION with SPDMVersion 1.1: ERROR VersionMismatch with SPDMVersion 1.0");
    get_version(8'h10, 5);
    chk(is_err(8'h10, 8'h01), "5-byte GET_VERSION: ERROR InvalidRequest");
    get_caps(64, 64);
    chk(is_err(8'h10, 8'h04), "an invalid GET_VERSION does not start the connection");
    get_version();
    chk(rl == 8 && rb[0] == 8'h10 && rb[1] == 8'h04 && rb[4] == 8'h00 && rb[5] == 8'h01 && rb[6] == 8'h00 && rb[7] == 8'h14,
        "VERSION: SPDMVersion 1.0, one entry 0x1400 (1.4) little-endian");
    // GET_CAPABILITIES
    get_caps(64, 64, 0, 0, 8'h12);
    chk(is_err(8'h14, 8'h41), "GET_CAPABILITIES with SPDMVersion 1.2: VersionMismatch");
    neg_algs();
    chk(is_err(8'h14, 8'h04), "NEGOTIATE_ALGORITHMS before CAPABILITIES: UnexpectedRequest");
    get_caps(41, 41);
    chk(is_err(8'h14, 8'h01), "DataTransferSize 41 < MinDataTransferSize 42: InvalidRequest");
    get_caps(42, 42);
    chk(rl == 20 && rb[1] == 8'h61, "DataTransferSize 42 accepted");
    get_version();
    get_caps(64, 64, 0, 8'h01);
    chk(is_err(8'h14, 8'h01), "Param1 bit 0 (Supported Algorithms) without CHUNK_CAP: InvalidRequest");
    get_caps(64, 63, 1);
    chk(is_err(8'h14, 8'h01), "MaxSPDMmsgSize < DataTransferSize: InvalidRequest");
    get_caps(64, 96, 0);
    chk(is_err(8'h14, 8'h01), "no CHUNK_CAP and MaxSPDMmsgSize != DataTransferSize: InvalidRequest");
    get_caps(64, 64, 0, 0, 8'h14, 19);
    chk(is_err(8'h14, 8'h01), "19-byte GET_CAPABILITIES: InvalidRequest");
    get_caps(64, 64);
    ok = rl == 20 && rb[0] == 8'h14 && rb[1] == 8'h61 && rb[5] == 8'd12 && rb[8] == 8'h08 && rb[9] == 8'h00 &&
         rb[12] == 8'd64 && rb[16] == 8'd64;
    for (i = 2; i < 20; i++) if (i != 5 && i != 8 && i != 12 && i != 16 && rb[i] != 8'h00) ok = 0;
    chk(ok, "CAPABILITIES: CTExponent 12, MEAS_CAP = 01b only, DataTransferSize = MaxSPDMmsgSize = 64");
    get_caps(64, 64);
    chk(rl == 20 && rb[1] == 8'h61, "identical GET_CAPABILITIES retry: CAPABILITIES again");
    get_caps(80, 80);
    chk(is_err(8'h14, 8'h04), "non-identical GET_CAPABILITIES: UnexpectedRequest");
    get_meas(8'h00);
    chk(is_err(8'h14, 8'h04), "GET_MEASUREMENTS before ALGORITHMS: UnexpectedRequest");
    // NEGOTIATE_ALGORITHMS
    neg_algs(8'h01, 32, 34);
    chk(is_err(8'h14, 8'h01), "Length field 34 in a 32-byte request: InvalidRequest");
    neg_algs(8'h01, 30, 30);
    chk(is_err(8'h14, 8'h01), "30-byte NEGOTIATE_ALGORITHMS: InvalidRequest");
    neg_algs();
    ok = rl == 36 && rb[1] == 8'h63 && rb[4] == 8'd36 && rb[5] == 8'h00 && rb[6] == 8'h01 && rb[8] == 8'h01;
    for (i = 9; i < 36; i++) if (rb[i] != 8'h00) ok = 0;
    chk(ok, "ALGORITHMS: Length 36, DMTF, Raw Bit Stream Only, no asymmetric / hash / PQC selection");
    neg_algs();
    chk(rl == 36 && rb[1] == 8'h63, "identical NEGOTIATE_ALGORITHMS retry: ALGORITHMS again");
    neg_algs(8'h01, 36);
    chk(is_err(8'h14, 8'h04), "non-identical NEGOTIATE_ALGORITHMS: UnexpectedRequest");
    get_caps(64, 64);
    chk(is_err(8'h14, 8'h04), "GET_CAPABILITIES after ALGORITHMS: UnexpectedRequest");
    // GET_MEASUREMENTS
    get_meas(8'h00, 0, 64'h1122334455667788);
    chk(rl == 50 && rb[1] == 8'h60 && rb[2] == 8'd3 && rb[3] == 8'h00 && rb[4] == 8'h00 && rb[5] == 8'h00,
        "operation 0: 3 indices in Param1, no blocks, 50 bytes");
    chk(nonce_ok(8), "Nonce: 32 bytes from the Responder's generator");
    chk(rb[40] == 8'h00 && rb[41] == 8'h00 && rb[42] == 8'h88 && rb[49] == 8'h11, "OpaqueDataLength 0, Context echoed");
    get_meas(8'h01, 0, 64'hAB);
    chk(rl == 61 && rb[4] == 8'd1 && rb[5] == 8'd11 && rb[8] == 8'd1 && rb[9] == 8'h01 && rb[10] == 8'd7 && rb[12] == 8'h80 &&
        rb[13] == 8'd4 && rb[15] == 8'h12 && rb[18] == 8'h78, "block 1: DMTF, raw immutable ROM, 4 bytes 12 34 56 78");
    chk(nonce_ok(19), "the Nonce advances per MEASUREMENTS");
    get_meas(8'h03);
    chk(rl == 59 && rb[8] == 8'd3 && rb[12] == 8'h86 && rb[15] == 8'h04 && rb[16] == 8'h01, "block 3: raw firmware version 04 01");
    chk(nonce_ok(17), "Nonce after block 3");
    get_meas(8'h02);
    chk(rl == 8 && rb[1] == 8'h7F && rb[2] == 8'h0D && rb[4] == 8'd65 && rb[5] == 8'h00,
        "block 2 needs 65 bytes > MaxSPDMmsgSize 64: ResponseTooLarge, ActualSize 65");
    get_meas(8'hFF);
    chk(rl == 8 && rb[2] == 8'h0D && rb[4] == 8'd85, "all blocks: 85 bytes, ResponseTooLarge");
    get_meas(8'h04);
    chk(is_err(8'h14, 8'h01), "index 4 does not exist: InvalidRequest");
    get_meas(8'h01, 8'h01);
    chk(is_err(8'h14, 8'h01), "SignatureRequested from a MEAS_CAP = 01b Responder: InvalidRequest");
    get_meas(8'h01, 8'h02);
    chk(rl == 61 && rb[12] == 8'h80, "RawBitStreamRequested: raw block as before");
    chk(nonce_ok(19), "Nonce");
    get_meas(8'h01, 0, 0, 11);
    chk(is_err(8'h14, 8'h01), "11-byte GET_MEASUREMENTS: InvalidRequest");
    // other requests
    ml = 0; b(8'h14); b(8'h81); b(8'h00); b(8'h00); xfer();
    chk(is_err(8'h14, 8'h07, 8'h81), "GET_DIGESTS: UnsupportedRequest naming 0x81");
    ml = 0; b(8'h14); b(8'h60); b(8'h00); b(8'h00); xfer();
    chk(is_err(8'h14, 8'h07, 8'h60), "a response code sent as a request: UnsupportedRequest");
    ml = 0; b(8'h14); b(8'hFF); b(8'h00); b(8'h00); xfer();
    chk(is_err(8'h14, 8'h04), "RESPOND_IF_READY with nothing pending: UnexpectedRequest");
    ml = 0; b(8'h14); b(8'hE0); for (i = 2; i < 65; i++) b(8'h00); xfer();
    chk(is_err(8'h14, 8'h0E), "65-byte request > 64: RequestTooLarge");
    ml = 0; b(8'h14); b(8'h81); for (i = 2; i < 64; i++) b(8'h00); xfer();
    chk(is_err(8'h14, 8'h07, 8'h81), "64-byte request: not too large (UnsupportedRequest for its code)");
    ml = 0; b(8'h14); xfer();
    chk(rl == 0, "1-byte message: silently discarded");
    // a request while the Responder is still answering
    get_meas(8'h03);
    chk(nonce_ok(17), "Nonce");
    ml = 0; b(8'h14); b(8'hE0); b(8'h00); b(8'h03); for (i = 0; i < 8; i++) b(8'h00);
    rl = 0; rdone = 0; nerr = 0;
    for (i = 0; i < ml; i++) begin @(negedge clk); req_valid = 1'b1; req_data = m[i]; req_last = (i == ml - 1); end
    @(negedge clk); req_valid = 1'b1; req_data = 8'h14; req_last = 1'b0;
    @(negedge clk); req_valid = 1'b1; req_data = 8'h84; req_last = 1'b1;
    @(negedge clk); req_valid = 1'b0; req_last = 1'b0;
    repeat (70) @(negedge clk);
    chk(nerr == 2 && nresp > 0 && rl == 59, "bytes during a response: dropped (err), the response is whole");
    chk(nonce_ok(17), "Nonce");
    // restart
    get_version();
    get_meas(8'h01);
    chk(is_err(8'h14, 8'h04), "GET_VERSION clears the connection: GET_MEASUREMENTS is unexpected");
    get_caps(128, 128);
    neg_algs();
    get_meas(8'hFF, 0, 64'hC0FFEE);
    chk(rl == 85 && rb[4] == 8'd3 && rb[5] == 8'd35 && rb[8] == 8'd1 && rb[19] == 8'd2 && rb[34] == 8'd3,
        "MaxSPDMmsgSize 128: all 3 blocks (35-byte record, 85 bytes)");
    chk(nonce_ok(43) && rb[77] == 8'hEE && rb[78] == 8'hFF && rb[79] == 8'hC0, "Nonce and Context after the record");
    get_version();
    get_caps(61, 61);
    neg_algs();
    get_meas(8'h01);
    chk(rl == 61 && rb[1] == 8'h60, "a 61-byte MEASUREMENTS fits MaxSPDMmsgSize 61 exactly");
    chk(nonce_ok(19), "Nonce");
    get_meas(8'h02);
    chk(rl == 8 && rb[2] == 8'h0D && rb[4] == 8'd65, "65 bytes do not");
    get_version();
    get_caps(256, 1024, 1);
    chk(rl == 20 && rb[1] == 8'h61, "CHUNK_CAP Requester: MaxSPDMmsgSize may exceed DataTransferSize");
    neg_algs(8'h00);
    chk(rl == 36 && rb[6] == 8'h00 && rb[8] == 8'h00, "no DMTF offered: no measurement specification or hash selected");
    get_meas(8'h00);
    chk(is_err(8'h14, 8'h04), "no measurement specification: GET_MEASUREMENTS unexpected");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #3000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
