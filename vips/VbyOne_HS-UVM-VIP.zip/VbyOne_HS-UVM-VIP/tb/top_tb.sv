// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- VbyOne testbench top with a functional VbyOne DUT model

`ifndef VBYONE_HS_UVM_VIP_TB_SV
`define VBYONE_HS_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import vbo_defs_pkg::*;
import vbo_pkg::*;
import vbo_env_pkg::*;
import vbo_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  vbo_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  vbo_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .pix_valid(vif.pix_valid),
    .pix_sol(vif.pix_sol),
    .pix_sof(vif.pix_sof),
    .pix_eol(vif.pix_eol),
    .pix_data(vif.pix_data),
    .vbo_htpdn_n(vif.vbo_htpdn_n),
    .vbo_lockn_n(vif.vbo_lockn_n),
    .vbo_lane_d(vif.vbo_lane_d),
    .vbo_lane_k(vif.vbo_lane_k),
    .vbo_sym(vif.vbo_sym)
  );

  // Concurrent protocol checks
  vbo_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .pix_valid(vif.pix_valid),
    .pix_sol(vif.pix_sol),
    .pix_sof(vif.pix_sof),
    .pix_eol(vif.pix_eol),
    .pix_data(vif.pix_data),
    .vbo_htpdn_n(vif.vbo_htpdn_n),
    .vbo_lockn_n(vif.vbo_lockn_n),
    .vbo_lane_d(vif.vbo_lane_d),
    .vbo_lane_k(vif.vbo_lane_k),
    .vbo_sym(vif.vbo_sym)
  );

  initial begin
    uvm_config_db#(virtual vbo_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module vbo_model #(parameter int LANES = 8, parameter int SYM_DIV = 2) (
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic                  pix_valid,
  input  logic                  pix_sol,
  input  logic                  pix_sof,
  input  logic                  pix_eol,
  input  logic [31:0]           pix_data,
  input  logic                  vbo_htpdn_n,
  input  logic                  vbo_lockn_n,
  output logic [LANES-1:0][7:0] vbo_lane_d,
  output logic [LANES-1:0]      vbo_lane_k,
  output logic                  vbo_sym
);
  logic [31:0] pb [0:63];
  logic [6:0]  nw;
  logic        eol, sof, pend;
  logic [3:0]  sdiv;
  logic [1:0]  st;          // 0 idle, 1 in a line
  logic [3:0]  g;
  logic [1:0]  j;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      nw <= '0; eol <= 1'b0; sof <= 1'b0; pend <= 1'b0; sdiv <= '0; st <= '0; g <= '0; j <= '0;
      vbo_lane_d <= '0; vbo_lane_k <= '0; vbo_sym <= 1'b0;
    end else begin : step
      logic [6:0]  n;
      logic        e, ready;
      n = nw; e = eol;
      if (pix_valid) begin
        if (pix_sol) begin
          pb[0] <= pix_data; n = 7'd1; e = pix_eol; sof <= pix_sof; pend <= 1'b1;
        end else if (nw < 7'd64) begin
          pb[nw[5:0]] <= pix_data; n = nw + 7'd1; if (pix_eol) e = 1'b1;
        end
      end
      nw <= n; eol <= e;
      vbo_sym <= 1'b0;
      sdiv <= (sdiv == SYM_DIV - 1) ? 4'd0 : sdiv + 4'd1;
      if (sdiv == 4'd0) begin
        vbo_sym <= 1'b1;
        if (vbo_htpdn_n || vbo_lockn_n) begin
          for (int l = 0; l < LANES; l++) begin vbo_lane_d[l] <= 8'h4A; vbo_lane_k[l] <= 1'b0; end
          st <= 2'd0;
        end else if (st == 2'd0) begin
          for (int l = 0; l < LANES; l++) begin
            vbo_lane_k[l] <= 1'b1;
            vbo_lane_d[l] <= pend ? (sof ? 8'h5C : 8'h1C) : 8'hBC;
          end
          if (pend) begin pend <= 1'b0; st <= 2'd1; g <= '0; j <= '0; end
        end else begin
          ready = (nw >= (g + 1) * LANES) || (eol && nw > g * LANES);
          if (j == 2'd0 && !ready) begin
            for (int l = 0; l < LANES; l++) begin vbo_lane_d[l] <= 8'hBC; vbo_lane_k[l] <= 1'b1; end
          end else begin
            for (int l = 0; l < LANES; l++) begin
              vbo_lane_k[l] <= 1'b0;
              vbo_lane_d[l] <= (g * LANES + l < nw) ? pb[g * LANES + l][8 * j +: 8] : 8'h00;
            end
            j <= j + 2'd1;
            if (j == 2'd3) begin
              g <= g + 4'd1;
              if (eol && (g + 1) * LANES >= nw) st <= 2'd0;
            end
          end
        end
      end
    end
  end
endmodule
`endif
