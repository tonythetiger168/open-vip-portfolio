// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (VbyOne DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened vbo_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;
  localparam integer L = 8, H = 12;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic pix_valid = 1'b0, pix_sol = 1'b0, pix_sof = 1'b0, pix_eol = 1'b0;
  logic [31:0] pix_data = 32'h0;
  logic vbo_htpdn_n = 1'b1, vbo_lockn_n = 1'b1;
  wire [7:0][7:0] vbo_lane_d;
  wire [7:0] vbo_lane_k;
  wire vbo_sym;

  always #5 clk = ~clk;

  vbo_model u_dut (.clk(clk), .rst_n(rst_n), .pix_valid(pix_valid), .pix_sol(pix_sol), .pix_sof(pix_sof),
                   .pix_eol(pix_eol), .pix_data(pix_data), .vbo_htpdn_n(vbo_htpdn_n), .vbo_lockn_n(vbo_lockn_n),
                   .vbo_lane_d(vbo_lane_d), .vbo_lane_k(vbo_lane_k), .vbo_sym(vbo_sym));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // symbol log: kind 0 training, 1 idle, 2 K28.2, 3 K28.0, 4 data, 5 other
  integer nsym = 0, ntrain = 0, nidle = 0, nk2 = 0, nk0 = 0, ndat = 0, nbad = 0, nsym_clk = 0, last_sym = 0;
  logic [31:0] got [0:63];
  integer ng, gj, gi;
  always @(posedge clk) if (rst_n) begin
    nsym_clk = nsym_clk + 1;
    if (vbo_sym) begin
      logic allk, nok, same;
      allk = 1; nok = 1; same = 1;
      for (int l = 0; l < L; l++) begin
        if (vbo_lane_k[l]) nok = 0; else allk = 0;
        if (vbo_lane_d[l] != vbo_lane_d[0]) same = 0;
      end
      if (nsym != 0 && nsym_clk - last_sym != 2) nbad = nbad + 1;
      last_sym = nsym_clk;
      nsym = nsym + 1;
      if (nok && same && vbo_lane_d[0] == 8'h4A) ntrain = ntrain + 1;
      else if (allk && same && vbo_lane_d[0] == 8'hBC) nidle = nidle + 1;
      else if (allk && same && vbo_lane_d[0] == 8'h5C) begin nk2 = nk2 + 1; gi = 0; gj = 0; end
      else if (allk && same && vbo_lane_d[0] == 8'h1C) begin nk0 = nk0 + 1; gi = 0; gj = 0; end
      else if (nok) begin
        ndat = ndat + 1;
        for (int l = 0; l < L; l++) begin
          if (gj == 0) got[gi + l] = 0;
          got[gi + l][8 * gj +: 8] = vbo_lane_d[l];
        end
        gj = gj + 1;
        if (gj == 4) begin gj = 0; gi = gi + L; end
      end else nbad = nbad + 1;
    end
  end

  logic [31:0] pv [0:63];
  task automatic line(input integer n, input logic sof, input integer gap = 0, input logic [31:0] v0 = 32'h01020304);
    for (int i = 0; i < 64; i++) pv[i] = v0 * (i + 1) ^ {i[7:0], 24'h0};
    for (int i = 0; i < 64; i++) if (i < n) begin
      if (gap != 0 && i % gap == gap - 1) begin pix_valid = 0; pix_sol = 0; pix_sof = 0; pix_eol = 0; repeat (12) @(negedge clk); end
      pix_valid = 1; pix_data = pv[i]; pix_sol = (i == 0); pix_sof = sof && (i == 0); pix_eol = (i == n - 1);
      @(negedge clk);
    end
    pix_valid = 0; pix_sol = 0; pix_sof = 0; pix_eol = 0;
    repeat (120) @(negedge clk);
  endtask
  function automatic logic same_px(input integer n);
    logic ok;
    ok = 1;
    for (int i = 0; i < 64; i++) if (i < n && got[i] !== pv[i]) ok = 0;
    for (int i = 0; i < 64; i++) if (i >= n && i < ((n + L - 1) / L) * L && got[i] !== 32'h0) ok = 0;
    same_px = ok;
  endfunction

  integer d0, i0, t0;
  initial begin
    repeat (3) @(posedge clk);
    rst_n = 1;
    repeat (40) @(negedge clk);
    chk(ntrain > 10 && nidle == 0 && nbad == 0, "unplugged: training only, a symbol every 2 clocks");
    vbo_htpdn_n = 0; repeat (20) @(negedge clk);
    chk(nidle == 0, "HTPDN low, LOCKN high: still training");
    vbo_lockn_n = 0; repeat (20) @(negedge clk);
    chk(nidle > 5, "locked: K28.5 idle");
    d0 = ndat; line(H, 1); chk(nk2 == 1 && ndat - d0 == 8 && same_px(H), "frame start: K28.2, 2 groups, 4 padded pixels");
    d0 = ndat; line(H, 0); chk(nk0 == 1 && ndat - d0 == 8 && same_px(H), "next line: K28.0");
    d0 = ndat; line(16, 0); chk(ndat - d0 == 8 && same_px(16), "two full groups");
    d0 = ndat; line(1, 0); chk(ndat - d0 == 4 && same_px(1), "one pixel, 7 padded");
    d0 = ndat; i0 = nidle; line(24, 0, 6); chk(ndat - d0 == 12 && same_px(24) && nidle - i0 > 60, "input gaps: K28.5 between groups");
    d0 = ndat; line(40, 1); chk(nk2 == 2 && ndat - d0 == 20 && same_px(40), "40 pixels");
    t0 = ntrain; vbo_lockn_n = 1; repeat (20) @(negedge clk); chk(ntrain - t0 >= 9, "LOCKN high: training again");
    vbo_lockn_n = 0; repeat (10) @(negedge clk);
    d0 = ndat; line(H, 0, 0, 32'hFFFFFFFF); chk(ndat - d0 == 8 && same_px(H), "line after the relock");
    chk(nbad == 0, "no malformed symbol");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
