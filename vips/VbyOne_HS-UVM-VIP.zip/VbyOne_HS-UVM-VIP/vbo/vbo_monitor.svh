// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// vbo_monitor.svh -- VbyOne monitor: the pixel lines into the transmitter, and every line the panel decodes from the lanes (control symbol, groups of 4 symbols, K28.5 fillers, zero padding)

class vbo_monitor extends uvm_monitor;
  `uvm_component_utils(vbo_monitor)

  virtual vbo_if vif;
  uvm_analysis_port #(vbo_transaction) ap;
  vbo_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual vbo_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "vbo: virtual interface not set")
    if (!uvm_config_db#(vbo_config)::get(this, "", "cfg", cfg))
      cfg = vbo_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [31:0] in_l[$][$];
      bit in_s[$];
      bit [31:0] cur[$];
      bit cur_s = 0;
      int st = 0, g = 0, j = 0, ng = 0, ntr = 0;
      bit [31:0] grp[8];
      vbo_transaction t;
      forever begin
        @(vif.mon_cb);
        // transmitter input
        if (vif.mon_cb.pix_valid) begin
          if (vif.mon_cb.pix_sol) begin cur.delete(); cur_s = vif.mon_cb.pix_sof; end
          cur.push_back(vif.mon_cb.pix_data);
          if (vif.mon_cb.pix_eol) begin in_l.push_back(cur); in_s.push_back(cur_s); end
        end
        if (!vif.mon_cb.vbo_sym) continue;
        // panel side: one symbol on every lane
        begin
          bit allk = 1, anyk = 0, same = 1;
          bit [7:0] d0 = vif.mon_cb.vbo_lane_d[0];
          for (int l = 0; l < cfg.lanes; l++) begin
            if (vif.mon_cb.vbo_lane_k[l]) anyk = 1; else allk = 0;
            if (vif.mon_cb.vbo_lane_d[l] != d0) same = 0;
          end
          if (anyk && !(allk && same)) `uvm_error("MON", "VbyOne: K symbol not on every lane")
          if (!anyk && same && d0 == 8'h4A && st == 0) begin ntr++; continue; end
          case (st)
            0: if (allk && (d0 == 8'h5C || d0 == 8'h1C)) begin
                 t = vbo_transaction::type_id::create("t");
                 t.rsof = (d0 == 8'h5C); t.ntrain = ntr; ntr = 0;
                 ng = (cfg.h_active + cfg.lanes - 1) / cfg.lanes;
                 g = 0; j = 0; st = 1; t.rpad = 1;
               end else if (!(allk && d0 == 8'hBC)) `uvm_error("MON", $sformatf("VbyOne: symbol %02h outside a line", d0))
            1: if (allk) begin
                 if (d0 == 8'hBC && j == 0) t.nfill++;
                 else begin
                   `uvm_error("MON", $sformatf("VbyOne: K symbol %02h inside a line (group %0d, symbol %0d)", d0, g, j))
                   st = 0;
                 end
               end else begin
                 for (int l = 0; l < cfg.lanes; l++) begin
                   if (j == 0) grp[l] = 0;
                   grp[l][8 * j +: 8] = vif.mon_cb.vbo_lane_d[l];
                 end
                 j++;
                 if (j == 4) begin
                   for (int l = 0; l < cfg.lanes; l++)
                     if (g * cfg.lanes + l < cfg.h_active) t.rpix.push_back(grp[l]);
                     else if (grp[l] != 0) t.rpad = 0;
                   j = 0; g++;
                   if (g == ng) begin
                     if (in_l.size()) begin t.pix = in_l.pop_front(); t.sof = in_s.pop_front(); end
                     publish(t);
                     st = 0;
                   end
                 end
               end
          endcase
        end
      end
    end
  endtask

  function void publish(vbo_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
