// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// vbo_driver.svh -- VbyOne driver: one line of pixels per item into the transmitter (random gaps for kinds 4-7), after the HTPDN / LOCKN handshake (again for a relock item); then waits for the line to leave the link

class vbo_driver extends uvm_driver #(vbo_transaction);
  `uvm_component_utils(vbo_driver)

  uvm_analysis_port #(vbo_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual vbo_if vif;
  vbo_config cfg;

  bit locked = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual vbo_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "vbo: virtual interface not set")
    if (!uvm_config_db#(vbo_config)::get(this, "", "cfg", cfg))
      cfg = vbo_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    vbo_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.pix_valid   <= 1'b0;
    vif.drv_cb.pix_sol     <= 1'b0;
    vif.drv_cb.pix_sof     <= 1'b0;
    vif.drv_cb.pix_eol     <= 1'b0;
    vif.drv_cb.pix_data    <= '0;
    vif.drv_cb.vbo_htpdn_n <= 1'b0;
    vif.drv_cb.vbo_lockn_n <= 1'b1;
  endtask

  task drive_item(vbo_transaction t);
    bit [31:0] x = t.seed ^ 32'h5bd1_e995;
    t.build(cfg.h_active);
    @(vif.drv_cb);
    if (t.relock() && locked) begin
      vif.drv_cb.vbo_lockn_n <= 1'b1;
      locked = 0;
      repeat (8) @(vif.drv_cb);
    end
    if (!locked) begin
      int n = 0, to = 0;
      vif.drv_cb.vbo_lockn_n <= 1'b1;
      while (n < cfg.train_syms && to < cfg.timeout_cycles) begin
        @(vif.drv_cb); to++;
        if (vif.drv_cb.vbo_sym) n = training() ? n + 1 : 0;
      end
      if (n < cfg.train_syms) `uvm_error("DRV", "VbyOne: no CDR training pattern")
      vif.drv_cb.vbo_lockn_n <= 1'b0;
      locked = 1;
      repeat (16) @(vif.drv_cb);
    end
    foreach (t.pix[i]) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      if (t.kind inside {[4:7]} && x[1:0] == 0) begin
        vif.drv_cb.pix_valid <= 1'b0; vif.drv_cb.pix_sol <= 1'b0; vif.drv_cb.pix_sof <= 1'b0; vif.drv_cb.pix_eol <= 1'b0;
        repeat (2 + x[5:2]) @(vif.drv_cb);
      end
      vif.drv_cb.pix_valid <= 1'b1; vif.drv_cb.pix_data <= t.pix[i];
      vif.drv_cb.pix_sol <= (i == 0); vif.drv_cb.pix_sof <= t.sof && (i == 0);
      vif.drv_cb.pix_eol <= (i == t.pix.size() - 1);
      @(vif.drv_cb);
    end
    vif.drv_cb.pix_valid <= 1'b0; vif.drv_cb.pix_sol <= 1'b0; vif.drv_cb.pix_sof <= 1'b0; vif.drv_cb.pix_eol <= 1'b0;
    repeat (cfg.line_wait) @(vif.drv_cb);
  endtask

  function bit training();
    for (int l = 0; l < cfg.lanes; l++)
      if (vif.drv_cb.vbo_lane_k[l] !== 1'b0 || vif.drv_cb.vbo_lane_d[l] !== 8'h4A) return 0;
    return 1;
  endfunction
endclass
