// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// vbo_compliance_checker.sv -- VbyOne concurrent assertion checks (bindable)

module vbo_compliance_checker
  (input logic clk, input logic rst_n, input logic pix_valid, input logic pix_sol, input logic pix_sof, input logic pix_eol, input logic [31:0] pix_data, input logic vbo_htpdn_n, input logic vbo_lockn_n, input logic [7:0][7:0] vbo_lane_d, input logic [7:0] vbo_lane_k, input logic vbo_sym);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({vbo_sym, vbo_lane_k, vbo_htpdn_n, vbo_lockn_n}))
    else $error("VbyOne: X on the link control");
  assert property (@(posedge clk) disable iff (!rst_n) vbo_sym |-> !$isunknown(vbo_lane_d))
    else $error("VbyOne: X on a lane");
  assert property (@(posedge clk) disable iff (!rst_n) vbo_sym && $past(vbo_lockn_n) && $past(vbo_lockn_n, 2) |-> vbo_lane_k == '0 && vbo_lane_d[0] == 8'h4A)
    else $error("VbyOne: not training while LOCKN is high");
  assert property (@(posedge clk) disable iff (!rst_n) vbo_sym |-> vbo_lane_k == '0 || vbo_lane_k == '1)
    else $error("VbyOne: K symbol on some lanes only");
  assert property (@(posedge clk) disable iff (!rst_n) pix_sof |-> pix_sol && pix_valid)
    else $error("VbyOne: frame start without line start");
  cover property (@(posedge clk) disable iff (!rst_n) vbo_sym && vbo_lane_k[0] && vbo_lane_d[0] == 8'h5C);
endmodule
