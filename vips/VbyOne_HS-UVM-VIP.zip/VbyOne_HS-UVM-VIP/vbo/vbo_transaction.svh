// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// vbo_transaction.svh -- VbyOne transaction

class vbo_transaction extends uvm_sequence_item;
  `uvm_object_utils(vbo_transaction)

  // request (driven by the agent)
  bit [31:0] pix[$];
  bit sof;
  // response (returned by the DUT)
  bit [31:0] rpix[$];
  bit rsof;
  bit rpad;
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [31:0] seed;
  int unsigned nfill;
  int unsigned ntrain;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "vbo_transaction"); super.new(name); endfunction

  // kind: 0-3 frame start, 4-7 pixel gaps (underruns), 8 drop and re-acquire the
  // lock first, 9 all-zero pixels, 10 all-one pixels, 11-31 plain lines
  function void set(int k, bit [31:0] s = 1); kind = k; seed = s; endfunction
  function bit relock(); return kind == 8; endfunction
  function void build(int unsigned n);
    bit [31:0] x = seed | 1;
    sof = (kind inside {[0:3]});
    pix.delete();
    for (int i = 0; i < n; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      pix.push_back((kind == 9) ? 32'h0 : (kind == 10) ? 32'hFFFF_FFFF : x);
    end
  endfunction

  function void do_copy(uvm_object rhs);
    vbo_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    pix = rhs_.pix;
    sof = rhs_.sof;
    rpix = rhs_.rpix;
    rsof = rhs_.rsof;
    rpad = rhs_.rpad;
    kind = rhs_.kind;
    seed = rhs_.seed;
    nfill = rhs_.nfill;
    ntrain = rhs_.ntrain;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    vbo_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (pix.size() != rhs_.pix.size()) return 0;
    foreach (pix[i]) if (pix[i] != rhs_.pix[i]) return 0;
    if (sof != rhs_.sof) return 0;
    if (rpix.size() != rhs_.rpix.size()) return 0;
    foreach (rpix[i]) if (rpix[i] != rhs_.rpix[i]) return 0;
    if (rsof != rhs_.rsof) return 0;
    if (rpad != rhs_.rpad) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(vbo_transaction rhs_);
    if (pix.size() != rhs_.pix.size()) return 0;
    foreach (pix[i]) if (pix[i] != rhs_.pix[i]) return 0;
    if (sof != rhs_.sof) return 0;
    return 1;
  endfunction

  function string qstr_pix();
    string s = $sformatf("[%0d]{", pix.size());
    foreach (pix[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", pix[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rpix();
    string s = $sformatf("[%0d]{", rpix.size());
    foreach (rpix[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rpix[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("VbyOne{tag=%0d pix=%s sof=0x%0h rpix=%s rsof=0x%0h rpad=0x%0h}", tag, qstr_pix(), sof, qstr_rpix(), rsof, rpad);
  endfunction
endclass
