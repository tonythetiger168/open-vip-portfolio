// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// vbo_if.sv -- VbyOne interface

interface vbo_if (input logic clk);
  logic rst_n;

  logic pix_valid;
  logic pix_sol;
  logic pix_sof;
  logic pix_eol;
  logic [31:0] pix_data;
  logic vbo_htpdn_n;
  logic vbo_lockn_n;
  logic [7:0][7:0] vbo_lane_d;
  logic [7:0] vbo_lane_k;
  logic vbo_sym;

  modport DUT (input clk, rst_n, input pix_valid, input pix_sol, input pix_sof, input pix_eol, input pix_data, input vbo_htpdn_n, input vbo_lockn_n, output vbo_lane_d, output vbo_lane_k, output vbo_sym);
  modport MON (input clk, rst_n, pix_valid, pix_sol, pix_sof, pix_eol, pix_data, vbo_htpdn_n, vbo_lockn_n, vbo_lane_d, vbo_lane_k, vbo_sym);

  clocking drv_cb @(posedge clk);
    input rst_n, vbo_lane_d, vbo_lane_k, vbo_sym;
    inout pix_valid, pix_sol, pix_sof, pix_eol, pix_data, vbo_htpdn_n, vbo_lockn_n;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, pix_valid, pix_sol, pix_sof, pix_eol, pix_data, vbo_htpdn_n, vbo_lockn_n, vbo_lane_d, vbo_lane_k, vbo_sym;
  endclocking
endinterface
