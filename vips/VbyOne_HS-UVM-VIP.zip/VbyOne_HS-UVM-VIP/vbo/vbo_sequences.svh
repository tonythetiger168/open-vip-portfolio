// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// vbo_sequences.svh -- VbyOne sequences

// Random traffic: cfg.num_items constrained-random items.
class vbo_base_sequence extends uvm_sequence #(vbo_transaction);
  `uvm_object_utils(vbo_base_sequence)
  vbo_config cfg;

  function new(string name = "vbo_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = vbo_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "vbo_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class vbo_directed_sequence extends uvm_sequence #(vbo_transaction);
  `uvm_object_utils(vbo_directed_sequence)
  vbo_config cfg;

  function new(string name = "vbo_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function vbo_transaction item();
    item = vbo_transaction::type_id::create("req");
  endfunction

  task send(vbo_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    vbo_transaction t;
    // a frame of 4 lines, gaps, a relock, extreme pixels, a second frame
    t = item(); t.set(0, 32'h10); send(t);
    for (int i = 0; i < 3; i++) begin t = item(); t.set(11, 32'h20 + i); send(t); end
    for (int i = 0; i < 4; i++) begin t = item(); t.set(4, 32'h30 + i); send(t); end
    t = item(); t.set(8, 32'h40); send(t);
    t = item(); t.set(9); send(t);
    t = item(); t.set(10); send(t);
    t = item(); t.set(1, 32'h50); send(t);
    t = item(); t.set(8, 32'h60); send(t);
    t = item(); t.set(5, 32'h70); send(t);
  endtask
endclass
