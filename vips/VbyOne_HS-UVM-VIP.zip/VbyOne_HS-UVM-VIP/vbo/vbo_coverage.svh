// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// vbo_coverage.svh -- VbyOne functional coverage

class vbo_coverage extends uvm_subscriber #(vbo_transaction);
  `uvm_component_utils(vbo_coverage)
  vbo_config cfg;
  vbo_transaction tr;

  covergroup vbo_cg;
    cp_sof   : coverpoint tr.rsof;
    cp_fill  : coverpoint tr.nfill { bins none = {0}; bins some = {[1:$]}; }
    cp_train : coverpoint tr.ntrain { bins none = {0}; bins trained = {[1:$]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    vbo_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(vbo_config)::get(this, "", "cfg", cfg))
      cfg = vbo_config::type_id::create("cfg");
  endfunction

  function void write(vbo_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    vbo_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("VbyOne coverage: %0.1f%%", vbo_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
