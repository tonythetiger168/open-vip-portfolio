// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// vbo_pkg.sv -- VbyOne UVM VIP package

package vbo_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import vbo_defs_pkg::*;
  export vbo_defs_pkg::*;

  `include "vbo_transaction.svh"
  `include "vbo_config.svh"
  `include "vbo_sequencer.svh"
  `include "vbo_driver.svh"
  `include "vbo_monitor.svh"
  `include "vbo_agent.svh"
  `include "vbo_sequences.svh"
  `include "vbo_checker.svh"
  `include "vbo_coverage.svh"
endpackage
