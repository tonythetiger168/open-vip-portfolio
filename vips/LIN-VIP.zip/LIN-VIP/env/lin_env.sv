// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_env.sv -- LIN verification environment with end-to-end scoreboard

package lin_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import lin_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) frames
  // against monitor-decoded (observed) frames.
  class lin_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(lin_scoreboard)
    uvm_analysis_imp_exp #(lin_transaction, lin_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(lin_transaction, lin_scoreboard) obs_ap;

    lin_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(lin_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(lin_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        lin_transaction e = exp_q.pop_front();
        lin_transaction o = obs_q.pop_front();
        bit ok;
        if (e.with_error) begin
          // error-injected frames must surface as errors on the bus
          ok = o.with_error;
        end else if (e.frame_type == lin_transaction::SLEEP) begin
          ok = (o.frame_type == lin_transaction::SLEEP);
        end else if (e.frame_type == lin_transaction::WAKEUP) begin
          ok = (o.frame_type == lin_transaction::WAKEUP);
        end else begin
          ok = (e.pid == o.pid) && (e.parity == o.parity) &&
               (e.data_len == o.data_len);
          if (ok) begin
            for (int i = 0; i < e.data_len; i++)
              if (e.data_payload[i] != o.data_payload[i]) ok = 0;
          end
        end
        if (ok) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("lin scoreboard: n_matches=%0d n_mismatches=%0d",
                n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  class lin_env extends uvm_env;
    `uvm_component_utils(lin_env)
    lin_agent      agt;
    lin_scoreboard sb;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = lin_agent::type_id::create("agt", this);
      sb  = lin_scoreboard::type_id::create("sb", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
    endfunction
  endclass
endpackage
