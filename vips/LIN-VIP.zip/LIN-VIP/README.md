# LIN — LIN 1.3 / 2.x UVM VIP

Open-source UVM verification IP for **LIN** (Local Interconnect Network, automotive serial bus).

## Protocol Overview

- **Frame:** sync break (>=13 dominant bits) → sync field 0x55 → PID (6-bit id + 2 parity bits) → response (2/4/8 data bytes, length from PID) → checksum (classic / enhanced)
- **Bit timing:** UART-style bytes (start bit, LSB first, stop bit), 8 clocks per bit
- **Network states:** sleep (long recessive) / wakeup (dominant pulse), tracked by the DUT and monitor
- **Errors:** parity / checksum / bit / framing / timeout injection + detection

## Contents
| Path | Description |
|------|-------------|
| `common/common_pkg.sv` | shared base classes |
| `lin/lin_if.sv` | interface + clocking blocks |
| `lin/lin_pkg.sv` + `*.svh` | UVM agent (driver/monitor/sequencer/coverage/checker) |
| `lin/lin_checksum.svh` | PID parity + classic/enhanced checksum functions |
| `lin/sva/lin_compliance_checker.sv` | compliance SVA module (L1-L4) |
| `lin/vip/lin/` | protocol / timing / error / data-integrity checkers |
| `env/lin_env.sv` | environment + end-to-end scoreboard |
| `tests/lin_tests.sv` | base / random / sleep_wakeup / error_inject / regression tests |
| `tb/top_tb.sv` + `tb/lin_slave_model.sv` | testbench top + functional LIN slave DUT |
| `scripts/` | Makefile + coverage-driven regression |

## Architecture
```
lin_tests -> lin_env -> lin_agent (sequencer -> driver -> monitor) -> scoreboard
                |                                          ^
                v                                          |
        lin_if (lin_rx) -> LIN slave DUT (parity/checksum) -+ (lin_tx)
```
The driver emits full LIN frames on `lin_rx`; the slave DUT verifies PID
parity and checksum, echoes the frame on `lin_tx` (0xFF error marker on
parity failure); the monitor decodes `lin_tx` and the scoreboard compares
expected vs observed (n_matches / n_mismatches, UVM_ERROR on mismatch).

## Sequence Library
| Sequence | Purpose |
|----------|---------|
| `lin_random_sequence` | constrained-random (normal) |
| `lin_unconditional_sequence` / `lin_event_triggered_sequence` / `lin_sporadic_sequence` / `lin_diagnostic_sequence` | per frame type |
| `lin_back_to_back_sequence` | minimal inter-frame gap |
| `lin_sleep_wakeup_sequence` | sleep + wakeup |
| `lin_error_inject_sequence` | checksum error injection |
| `lin_corner_sequence` | PID extremes incl. diagnostic 0x3C/0x3D |
| `lin_reset_sequence` | frame right after reset |
| `lin_stress_sequence` | dense traffic with 15% errors |
| `lin_regression_sequence` | weighted mix |

## SVA (L1-L4)
- **L1 (4):** PID range, break/sync presence, checksum presence
- **L2 (5):** break length, sync=0x55, parity, checksum, frame timing
- **L3 (4):** sleep/wakeup, error injection, schedule timing, timeout
- **L4 (5):** dominant drive only when enabled, break→sync, sync→PID, PID parity P0, sleep exit on wakeup

## Functional Coverage
- `lin_frame_cg`: PID ranges x frame type, data length bins (cross)
- `lin_fsm_cg`: frame-type transition sequences x error transitions (cross)
- `lin_data_cg`: payload corners (0x00/0xFF/0xAA/0x55) x length, checksum ranges (cross)

## Quick start
```bash
cd scripts
make all TEST=base_test
./coverage_regression.sh         # full regression + 100% coverage gate
```

License: Apache-2.0
