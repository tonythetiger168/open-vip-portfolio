// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lin_tests.sv -- LIN UVM tests

package lin_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import lin_pkg::*;
  import lin_env_pkg::*;

  class base_test extends uvm_test;
    `uvm_component_utils(base_test)
    lin_env env;
    function new(string name = "base_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = lin_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      lin_random_sequence seq;
      phase.raise_objection(this);
      seq = lin_random_sequence::type_id::create("seq");
      seq.num_txns = 20;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class random_test extends base_test;
    `uvm_component_utils(random_test)
    function new(string name = "random_test", uvm_component parent = null); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      lin_random_sequence seq;
      phase.raise_objection(this);
      seq = lin_random_sequence::type_id::create("seq");
      seq.num_txns = 50;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class sleep_wakeup_test extends base_test;
    `uvm_component_utils(sleep_wakeup_test)
    function new(string name = "sleep_wakeup_test", uvm_component parent = null); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      lin_sleep_wakeup_sequence seq;
      phase.raise_objection(this);
      seq = lin_sleep_wakeup_sequence::type_id::create("seq");
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  // Injected checksum / parity / sync / timeout errors are expected in the
  // error tests: the scoreboard checks each one is seen on the bus, so the
  // checker's reports for them are demoted to info.
  class lin_expected_error_catcher extends uvm_report_catcher;
    function new(string name = "lin_expected_error_catcher"); super.new(name); endfunction
    function action_e catch();
      string m = get_message();
      if (get_id() == "PROTOCOL_CHK" && get_severity() == UVM_ERROR &&
          (uvm_is_match("*Checksum error detected*", m) || uvm_is_match("*PID parity mismatch*", m)))
        set_severity(UVM_INFO);
      return THROW;
    endfunction
  endclass

  class error_inject_test extends base_test;
    `uvm_component_utils(error_inject_test)
    function new(string name = "error_inject_test", uvm_component parent = null); super.new(name, parent); endfunction
    function void end_of_elaboration_phase(uvm_phase phase);
      lin_expected_error_catcher c = new();
      super.end_of_elaboration_phase(phase);
      uvm_report_cb::add(null, c);
    endfunction
    task run_phase(uvm_phase phase);
      lin_error_inject_sequence seq;
      phase.raise_objection(this);
      seq = lin_error_inject_sequence::type_id::create("seq");
      seq.num_txns = 10;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class cov_test extends base_test;
    `uvm_component_utils(cov_test)
    function new(string name = "cov_test", uvm_component parent = null); super.new(name, parent); endfunction
    function void end_of_elaboration_phase(uvm_phase phase);
      lin_expected_error_catcher c = new();
      super.end_of_elaboration_phase(phase);
      uvm_report_cb::add(null, c);
    endfunction
    task run_phase(uvm_phase phase);
      lin_cov_sequence seq;
      phase.raise_objection(this);
      seq = lin_cov_sequence::type_id::create("seq");
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class regression_test extends base_test;
    `uvm_component_utils(regression_test)
    function new(string name = "regression_test", uvm_component parent = null); super.new(name, parent); endfunction
    function void end_of_elaboration_phase(uvm_phase phase);
      lin_expected_error_catcher c = new();
      super.end_of_elaboration_phase(phase);
      uvm_report_cb::add(null, c);
    endfunction
    task run_phase(uvm_phase phase);
      lin_regression_sequence seq;
      phase.raise_objection(this);
      seq = lin_regression_sequence::type_id::create("seq");
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass
endpackage
