// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_checker.svh

class lin_checker extends protocol_checker_base;
  `uvm_component_utils(lin_checker)
  uvm_analysis_imp #(lin_transaction, lin_checker) analysis_export;
  int tx_count = 0;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
  endfunction
  function void write(lin_transaction tx);
    tx_count++;
    check_pid(tx);
    check_parity(tx);
    check_data_len(tx);
    check_checksum(tx);
    check_diagnostic(tx);
    check_wakeup(tx);
    check_sleep(tx);
  endfunction
  function void check_pid(lin_transaction tx);
    if (tx.pid > 59 && tx.frame_type != lin_transaction::DIAGNOSTIC)
      check_protocol_error($sformatf("Invalid PID 0x%0x for non-diagnostic frame", tx.pid));
  endfunction
  function void check_parity(lin_transaction tx);
    bit [1:0] expected_parity;
    expected_parity[0] = ~(tx.pid[0] ^ tx.pid[1] ^ tx.pid[2] ^ tx.pid[4]);
    expected_parity[1] =   tx.pid[1] ^ tx.pid[3] ^ tx.pid[4] ^ tx.pid[5];
    if (tx.parity != expected_parity)
      check_protocol_error($sformatf("PID parity mismatch: expected %b, got %b", expected_parity, tx.parity));
  endfunction
  function void check_data_len(lin_transaction tx);
    if (tx.data_len > 8)
      check_protocol_error($sformatf("LIN data length %0d > 8", tx.data_len));
    if (tx.frame_type == lin_transaction::DIAGNOSTIC && tx.data_len != 8)
      check_protocol_warning($sformatf("Diagnostic frame with len=%0d (expected 8)", tx.data_len));
  endfunction
  function void check_checksum(lin_transaction tx);
    if (tx.checksum_error)
      check_protocol_error("Checksum error detected");
  endfunction
  function void check_diagnostic(lin_transaction tx);
    if (tx.frame_type == lin_transaction::DIAGNOSTIC && !(tx.pid inside {60, 61}))
      check_protocol_error($sformatf("Diagnostic frame with invalid PID %0d", tx.pid));
  endfunction
  function void check_wakeup(lin_transaction tx);
    if (tx.wakeup_signal && tx.sleep_mode)
      check_protocol_warning("Wakeup and sleep signals both asserted");
  endfunction
  function void check_sleep(lin_transaction tx);
    if (tx.sleep_mode && tx.data_len > 0)
      check_protocol_warning("Sleep frame with non-zero data length");
  endfunction
  task run_phase(uvm_phase phase); endtask
  function void report_phase(uvm_phase phase);
    `uvm_info("LIN_CHK", $sformatf("Checked %0d transactions, %0d errors, %0d warnings",
      tx_count, error_count, warning_count), UVM_LOW)
  endfunction
endclass
