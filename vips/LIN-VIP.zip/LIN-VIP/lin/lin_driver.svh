// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_driver.svh -- LIN master driver: transmits full LIN frames
// (break / sync 0x55 / PID+parity / data / checksum) on lin_rx with
// UART-style bytes (start bit, LSB first, stop bit) and a fixed bit
// time. Also drives sleep (long recessive) and wakeup (dominant pulse).

class lin_driver extends uvm_driver #(lin_transaction);
  `uvm_component_utils(lin_driver)
  virtual lin_if vif;
  lin_config cfg;
  uvm_analysis_port #(lin_transaction) drv_ap;  // expected items for scoreboard

  localparam int BIT_CLKS = 8;    // clock cycles per LIN bit (bit timing)
  localparam int BREAK_BITS = 13; // sync break >= 13 dominant bits

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual lin_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "LIN virtual interface not found")
    if (!uvm_config_db#(lin_config)::get(this, "", "cfg", cfg))
      cfg = lin_config::type_id::create("cfg");
  endfunction

  task send_bit(bit b);
    vif.drv_cb.lin_rx <= b;
    repeat (BIT_CLKS) @(vif.drv_cb);
  endtask

  // UART byte: start (dominant), 8 data bits LSB first, stop (recessive)
  task send_byte(bit [7:0] d);
    send_bit(1'b0);
    for (int i = 0; i < 8; i++) send_bit(d[i]);
    send_bit(1'b1);
  endtask

  task send_frame(lin_transaction tx);
    bit [1:0] parity;
    bit [7:0] cs;
    bit [7:0] payload[$];
    int nbytes;

    nbytes = lin_len_from_pid(tx.pid);
    for (int i = 0; i < nbytes; i++)
      payload.push_back(i < tx.data_payload.size() ? tx.data_payload[i] : 8'h00);

    parity = lin_pid_parity(tx.pid);
    if (tx.with_error && tx.parity_error) parity = parity ^ 2'b01;

    // header: break + delimiter + sync
    vif.drv_cb.lin_en <= 1;
    repeat ((tx.with_error && tx.bit_error) ? 8 : BREAK_BITS) send_bit(1'b0);
    send_bit(1'b1);                                     // break delimiter
    send_byte(8'h55);                                   // sync field
    send_byte({parity, tx.pid});                        // PID
    // response: data + checksum (enhanced except diagnostic PIDs)
    if (tx.pid >= 60) cs = lin_classic_checksum(payload);
    else              cs = lin_enhanced_checksum(payload, tx.pid);
    if (tx.with_error && tx.checksum_error) cs = cs ^ 8'h01;
    if (!(tx.with_error && tx.timeout_error)) begin
      foreach (payload[i]) send_byte(payload[i]);
      send_byte(cs);
    end
    repeat (4) send_bit(1'b1);                          // inter-frame gap
    vif.drv_cb.lin_en <= 0;
  endtask

  // legacy API: drive a single item (kept for backward compatibility)
  task drive_item(lin_transaction tx);
    `uvm_info("LIN_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)
    vif.drv_cb.lin_en <= 1;
    if (tx.wakeup_signal) begin
      repeat (16) send_bit(1'b0);                       // wakeup pulse
      repeat (4)  send_bit(1'b1);
    end else if (tx.sleep_mode) begin
      repeat (30) send_bit(1'b1);                       // bus sleep (recessive)
    end else begin
      send_frame(tx);
      return;
    end
    vif.drv_cb.lin_en <= 0;
  endtask

  task run_phase(uvm_phase phase);
    lin_transaction exp;
    vif.drv_cb.lin_rx <= 1'b1;   // recessive idle
    vif.drv_cb.lin_en <= 1'b0;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(req);
      `uvm_info("LIN_DRV", $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
      drive_item(req);
      // publish what was actually put on the wire
      exp = lin_transaction::type_id::create("exp");
      exp.copy(req);
      if (!req.sleep_mode && !req.wakeup_signal) begin
        int nbytes = lin_len_from_pid(req.pid);
        exp.data_len = nbytes;
        exp.data_payload = new[nbytes];
        for (int i = 0; i < nbytes; i++)
          exp.data_payload[i] = (i < req.data_payload.size()) ? req.data_payload[i] : 8'h00;
        exp.parity = lin_pid_parity(req.pid);
        exp.enhanced_checksum = (req.pid < 60);
      end
      drv_ap.write(exp);
      seq_item_port.item_done();
    end
  endtask
endclass
