// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_monitor.svh -- LIN monitor: decodes frames from the lin_tx waveform
// (break / sync / PID+parity / data / checksum), verifies parity and
// checksum, tracks sleep/wakeup, and publishes reconstructed transactions.

class lin_monitor extends uvm_monitor;
  `uvm_component_utils(lin_monitor)
  virtual lin_if vif;
  uvm_analysis_port #(lin_transaction) ap;
  lin_config cfg;
  int unsigned txn_count = 0;

  localparam int BIT_CLKS = 8;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual lin_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "LIN virtual interface not found")
    if (!uvm_config_db#(lin_config)::get(this, "", "cfg", cfg))
      cfg = lin_config::type_id::create("cfg");
  endfunction

  // sample one bit at the bit center (caller aligned to bit start)
  task sample_bit(output bit b);
    repeat (BIT_CLKS/2) @(posedge vif.clk);
    b = vif.lin_tx;
    repeat (BIT_CLKS - BIT_CLKS/2) @(posedge vif.clk);
  endtask

  task sample_byte(output bit [7:0] d, output bit stop_ok);
    bit b;
    sample_bit(b);                       // start bit
    for (int i = 0; i < 8; i++) begin sample_bit(b); d[i] = b; end
    sample_bit(b);                       // stop bit
    stop_ok = (b == 1'b1);
  endtask

  task run_phase(uvm_phase phase);
    lin_transaction tx;
    bit [7:0] d;
    bit stop_ok;
    int dom_run;
    fork
      // ---- frame decoder on lin_tx ----
      forever begin
        @(posedge vif.clk);
        if (!vif.rst_n) continue;
        if (vif.lin_tx === 1'b0) begin
          // count dominant bit-times (break or wakeup)
          dom_run = 0;
          while (vif.lin_tx === 1'b0) begin
            repeat (BIT_CLKS) @(posedge vif.clk);
            dom_run++;
            if (dom_run > 20) break;
          end
          // recessive delimiter seen; align to next bit start
          repeat (BIT_CLKS) @(posedge vif.clk);
          if (vif.lin_tx === 1'b0) begin
            // start bit of first byte -> sync field or error marker
            sample_byte(d, stop_ok);
            if (d == 8'h55 && stop_ok) begin
              decode_frame_after_sync();
            end else if (d == 8'hFF && stop_ok) begin
              // slave error marker
              lin_transaction etx = lin_transaction::type_id::create("etx");
              etx.with_error = 1;
              etx.parity_error = 1;
              etx.frame_type = lin_transaction::UNCONDITIONAL;
              txn_count++;
              `uvm_info("LIN_MON", "Monitored: parity error marker", UVM_MEDIUM)
              ap.write(etx);
            end
            // else: garbage; resync at next falling edge
          end else begin
            // no byte follows -> wakeup pulse on the bus
            lin_transaction wtx = lin_transaction::type_id::create("wtx");
            wtx.frame_type = lin_transaction::WAKEUP;
            wtx.wakeup_signal = 1;
            txn_count++;
            `uvm_info("LIN_MON", "Monitored: WAKEUP pulse", UVM_MEDIUM)
            ap.write(wtx);
          end
        end
      end
      // ---- sleep tracker (from DUT status pin) ----
      forever begin
        @(posedge vif.sleep_mode);
        begin
          lin_transaction stx = lin_transaction::type_id::create("stx");
          stx.frame_type = lin_transaction::SLEEP;
          stx.sleep_mode = 1;
          txn_count++;
          `uvm_info("LIN_MON", "Monitored: SLEEP mode entered", UVM_MEDIUM)
          ap.write(stx);
        end
      end
    join
  endtask

  // decode PID + data + checksum after a valid sync field
  task decode_frame_after_sync();
    lin_transaction tx;
    bit [7:0] d, pid_byte, cs_rx, cs_calc;
    bit stop_ok;
    bit [7:0] payload[$];
    int nbytes;

    sample_byte(pid_byte, stop_ok);
    tx = lin_transaction::type_id::create("tx");
    tx.pid = pid_byte[5:0];
    tx.parity = pid_byte[7:6];
    tx.frame_type = lin_transaction::UNCONDITIONAL;
    tx.with_error = (tx.parity != lin_pid_parity(tx.pid));
    tx.parity_error = tx.with_error;

    nbytes = lin_len_from_pid(tx.pid);
    for (int i = 0; i < nbytes; i++) begin
      sample_byte(d, stop_ok);
      payload.push_back(d);
    end
    sample_byte(cs_rx, stop_ok);
    if (tx.pid >= 60) cs_calc = lin_classic_checksum(payload);
    else              cs_calc = lin_enhanced_checksum(payload, tx.pid);

    tx.data_len = nbytes;
    tx.data_payload = new[nbytes];
    foreach (payload[i]) tx.data_payload[i] = payload[i];
    tx.checksum = cs_rx;
    tx.enhanced_checksum = (tx.pid < 60);
    if (cs_rx != cs_calc) begin
      tx.with_error = 1;
      tx.checksum_error = 1;
    end
    txn_count++;
    `uvm_info("LIN_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_MEDIUM)
    ap.write(tx);
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("LIN_MON", $sformatf("lin monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
