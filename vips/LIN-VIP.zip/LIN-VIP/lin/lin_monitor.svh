// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_monitor.svh -- LIN monitor: decodes frames from the lin_tx waveform
// (break / sync / PID+parity / data / checksum), verifies parity and
// checksum, tracks sleep/wakeup, and publishes reconstructed transactions.

class lin_monitor extends uvm_monitor;
  `uvm_component_utils(lin_monitor)
  virtual lin_if vif;
  uvm_analysis_port #(lin_transaction) ap;
  lin_config cfg;
  int unsigned txn_count = 0;

  localparam int BIT_CLKS = 8;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual lin_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "LIN virtual interface not found")
    if (!uvm_config_db#(lin_config)::get(this, "", "cfg", cfg))
      cfg = lin_config::type_id::create("cfg");
  endfunction

  // sample one bit at the bit center (caller aligned to bit start)
  task sample_bit(output bit b);
    repeat (BIT_CLKS/2) @(posedge vif.clk);
    b = vif.lin_tx;
    repeat (BIT_CLKS - BIT_CLKS/2) @(posedge vif.clk);
  endtask

  // A UART byte. start_ok is 0 when no start bit came (the sender went
  // quiet, e.g. a slave response that never started): the rest is skipped.
  task sample_byte(output bit [7:0] d, output bit stop_ok, output bit start_ok);
    bit b;
    d = '0;
    sample_bit(b);                       // start bit
    start_ok = (b == 1'b0);
    stop_ok  = 1'b0;
    if (!start_ok) return;
    for (int i = 0; i < 8; i++) begin sample_bit(b); d[i] = b; end
    sample_bit(b);                       // stop bit
    stop_ok = (b == 1'b1);
  endtask

  task run_phase(uvm_phase phase);
    bit [7:0] d;
    bit stop_ok, start_ok;
    int dom_run;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) continue;
      if (vif.lin_tx === 1'b0) begin
        // count dominant bit-times (break or wakeup)
        dom_run = 0;
        while (vif.lin_tx === 1'b0) begin
          repeat (BIT_CLKS) @(posedge vif.clk);
          dom_run++;
          if (dom_run > 20) break;
        end
        // recessive delimiter seen; align to next bit start
        repeat (BIT_CLKS) @(posedge vif.clk);
        if (vif.lin_tx === 1'b0) begin
          // start bit of first byte -> sync field or error marker
          sample_byte(d, stop_ok, start_ok);
          if (d == 8'h55 && stop_ok) begin
            decode_frame_after_sync();
          end else if (d == 8'hFF && stop_ok) begin
            // slave error marker (bad PID parity or bad sync)
            lin_transaction etx = lin_transaction::type_id::create("etx");
            etx.with_error = 1;
            etx.parity_error = 1;
            etx.frame_type = lin_transaction::UNCONDITIONAL;
            etx.parity = lin_pid_parity(etx.pid);
            txn_count++;
            `uvm_info("LIN_MON", "Monitored: error marker", UVM_MEDIUM)
            ap.write(etx);
          end
          // else: garbage; resync at next falling edge
        end else begin
          // no byte follows -> wakeup pulse on the bus
          lin_transaction wtx = lin_transaction::type_id::create("wtx");
          wtx.frame_type = lin_transaction::WAKEUP;
          wtx.wakeup_signal = 1;
          txn_count++;
          `uvm_info("LIN_MON", "Monitored: WAKEUP pulse", UVM_MEDIUM)
          ap.write(wtx);
        end
      end
    end
  endtask

  function lin_transaction::lin_frame_type_e frame_class();
    if (vif.event_triggered_frame === 1'b1) return lin_transaction::EVENT_TRIGGERED;
    if (vif.sporadic_frame === 1'b1)        return lin_transaction::SPORADIC;
    if (vif.diagnostic_frame === 1'b1)      return lin_transaction::DIAGNOSTIC;
    if (vif.user_defined_frame === 1'b1)    return lin_transaction::USER_DEFINED;
    if (vif.reserved_frame === 1'b1)        return lin_transaction::RESERVED;
    return lin_transaction::UNCONDITIONAL;
  endfunction

  // decode PID + data + checksum after a valid sync field
  task decode_frame_after_sync();
    lin_transaction tx;
    bit [7:0] d, pid_byte, cs_rx, cs_calc;
    bit stop_ok, start_ok;
    bit [7:0] payload[$];
    int nbytes;
    sample_byte(pid_byte, stop_ok, start_ok);
    tx = lin_transaction::type_id::create("tx");
    tx.pid = pid_byte[5:0];
    tx.parity = pid_byte[7:6];
    tx.frame_type = frame_class();
    tx.with_error = (tx.parity != lin_pid_parity(tx.pid));
    tx.parity_error = tx.with_error;
    nbytes = lin_len_from_pid(tx.pid);
    for (int i = 0; i < nbytes && start_ok; i++) begin
      sample_byte(d, stop_ok, start_ok);
      if (start_ok) payload.push_back(d);
    end
    if (start_ok) sample_byte(cs_rx, stop_ok, start_ok);
    if (!start_ok) begin
      // the response stopped: slave-not-responding (timeout)
      tx.with_error = 1;
      tx.timeout_error = 1;
    end
    else begin
      if (tx.pid >= 60) cs_calc = lin_classic_checksum(payload);
      else              cs_calc = lin_enhanced_checksum(payload, tx.pid);
      tx.checksum = cs_rx;
      if (cs_rx != cs_calc) begin
        tx.with_error = 1;
        tx.checksum_error = 1;
      end
    end
    tx.data_len = payload.size();
    tx.data_payload = new[payload.size()];
    foreach (payload[i]) tx.data_payload[i] = payload[i];
    tx.enhanced_checksum = (tx.pid < 60);
    // the go-to-sleep command (master request 0x3C, first byte 0)
    if (!tx.with_error && tx.pid == 6'h3C && payload.size() > 0 && payload[0] == 8'h00) begin
      tx.frame_type = lin_transaction::SLEEP;
      tx.sleep_mode = 1;
      tx.data_len = 0;
      tx.data_payload.delete();
    end
    txn_count++;
    `uvm_info("LIN_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_MEDIUM)
    ap.write(tx);
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("LIN_MON", $sformatf("lin monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
