// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_if.sv
// LIN Interface (LIN 2.x / LIN 2.2A / SAE J2602)

interface lin_if (input logic clk, input logic rst_n);
  // Single wire bus
  logic lin_tx;
  logic lin_rx;
  logic lin_en;
  // Break / sync
  logic break_field;
  logic [7:0] sync_field;
  // PID
  logic [5:0] pid;
  logic [1:0] parity;
  // Data
  logic [7:0] data;
  logic [3:0] data_len;
  logic [7:0] checksum;
  // Frame types
  logic        unconditional_frame;
  logic        event_triggered_frame;
  logic        sporadic_frame;
  logic        diagnostic_frame;
  logic        user_defined_frame;
  logic        reserved_frame;
  // Schedule
  logic [7:0]  schedule_table_id;
  logic        schedule_entry_point;
  // Sleep / wakeup
  logic        sleep_mode;
  logic        wakeup_signal;
  // Error
  logic        bit_error;
  logic        checksum_error;
  logic        timeout_error;
  logic        parity_error;
  logic        framing_error;

  modport DUT (
    input  clk, rst_n, lin_rx, lin_en,
    output lin_tx, break_field, sync_field, pid, parity, data, data_len,
    output checksum, unconditional_frame, event_triggered_frame,
    output sporadic_frame, diagnostic_frame, user_defined_frame,
    output reserved_frame, schedule_table_id, schedule_entry_point,
    output sleep_mode, wakeup_signal, bit_error, checksum_error,
    output timeout_error, parity_error, framing_error
  );

  modport TB (
    input  clk, rst_n, lin_tx, break_field, sync_field, pid, parity,
    input  data, data_len, checksum, unconditional_frame, event_triggered_frame,
    input  sporadic_frame, diagnostic_frame, user_defined_frame, reserved_frame,
    input  schedule_table_id, schedule_entry_point, sleep_mode, wakeup_signal,
    input  bit_error, checksum_error, timeout_error, parity_error,
    output lin_rx, lin_en
  );

  clocking mon_cb @(posedge clk);
    input lin_tx, lin_rx, pid, parity, data, data_len, checksum;
    input unconditional_frame, event_triggered_frame, sporadic_frame;
    input diagnostic_frame, sleep_mode, wakeup_signal;
    input bit_error, checksum_error, timeout_error, parity_error;
  endclocking

  clocking drv_cb @(posedge clk);
    output lin_rx, lin_en;
    input  lin_tx, sleep_mode;
  endclocking
endinterface
