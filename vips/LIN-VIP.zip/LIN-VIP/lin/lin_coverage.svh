// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_coverage.svh -- LIN functional coverage:
//   lin_frame_cg - protocol config (PID / frame type / length, with cross)
//   lin_fsm_cg   - frame-type (FSM) transition sequences
//   lin_data_cg  - data pattern corners (with cross)

class lin_coverage extends coverage_collector_base;
  `uvm_component_utils(lin_coverage)
  uvm_analysis_port #(lin_transaction) analysis_export;

  lin_transaction tx;


  covergroup lin_frame_cg;
    option.per_instance = 1;
    pid_cp: coverpoint tx.pid {
      bins low = {[0:15]};
      bins mid = {[16:47]};
      bins high = {[48:59]};
      bins diag = {[60:61]};
      // REACHABILITY: PIDs 62/63 are reserved by the LIN specification, so no
      // legal frame can carry them.
      ignore_bins reserved = {[62:63]};
    }
    frame_type_cp: coverpoint tx.frame_type;
    data_len_cp: coverpoint tx.data_len {
      bins d2 = {2};
      bins d4 = {4};
      bins d8 = {8};
    }
    cx_pid_frame: cross pid_cp, frame_type_cp;
  endgroup

  // FSM transition coverage: frame-type sequences on the bus
  covergroup lin_fsm_cg;
    option.per_instance = 1;
    frame_trans_cp: coverpoint tx.frame_type {
      bins unc_unc   = (lin_transaction::UNCONDITIONAL => lin_transaction::UNCONDITIONAL);
      bins unc_evt   = (lin_transaction::UNCONDITIONAL => lin_transaction::EVENT_TRIGGERED);
      bins unc_diag  = (lin_transaction::UNCONDITIONAL => lin_transaction::DIAGNOSTIC);
      bins diag_unc  = (lin_transaction::DIAGNOSTIC    => lin_transaction::UNCONDITIONAL);
      bins sleep_wake= (lin_transaction::SLEEP         => lin_transaction::WAKEUP);
      bins wake_unc  = (lin_transaction::WAKEUP        => lin_transaction::UNCONDITIONAL);
    }
    error_trans_cp: coverpoint tx.with_error {
      bins ok_ok   = (0 => 0);
      bins ok_err  = (0 => 1);
      bins err_ok  = (1 => 0);
    }
    cx_frame_err: cross frame_trans_cp, error_trans_cp;
  endgroup

  // Data pattern coverage: payload corners x length
  covergroup lin_data_cg;
    option.per_instance = 1;
    data0_cp: coverpoint tx.data_payload[0] iff (tx.data_len > 0) {
      bins zero  = {8'h00};
      bins ones  = {8'hFF};
      bins aa    = {8'hAA};
      bins five5 = {8'h55};
      bins other = default;
    }
    data_len_cp: coverpoint tx.data_len {
      bins d2 = {2};
      bins d4 = {4};
      bins d8 = {8};
    }
    checksum_cp: coverpoint tx.checksum iff (tx.data_len > 0) {
      bins low  = {[8'h00:8'h3F]};
      bins mid  = {[8'h40:8'hBF]};
      bins high = {[8'hC0:8'hFF]};
    }
    cx_data_len: cross data0_cp, data_len_cp;
  endgroup

  int sample_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    lin_frame_cg = new();
    lin_fsm_cg = new();
    lin_data_cg = new();
  endfunction
  function void write(lin_transaction tx_);
    tx = tx_;
    sample_coverage(tx);
  endfunction
  virtual function void sample_coverage(uvm_sequence_item tx_);
    lin_transaction ltx;
    if (!$cast(ltx, tx_)) return;
    tx = ltx;
    lin_frame_cg.sample();
    lin_fsm_cg.sample();
    lin_data_cg.sample();
    sample_count++;
  endfunction
  virtual function void report_phase(uvm_phase phase);
    `uvm_info("LIN_COV", $sformatf("Samples: %0d | Frame: %.1f%% | FSM: %.1f%% | Data: %.1f%%",
      sample_count,
      lin_frame_cg.get_coverage(),
      lin_fsm_cg.get_coverage(),
      lin_data_cg.get_coverage()), UVM_LOW)
  endfunction
endclass
