// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_config.svh

class lin_config extends uvm_object;
  `uvm_object_utils(lin_config)
  bit enable_checker  = 1;
  bit enable_coverage = 1;
  int max_data_len    = 8;
  int baud_rate       = 19200; // default LIN baud
  bit enhanced_checksum = 1;   // LIN 2.0+
  int schedule_table_count = 4;
  function new(string name = "lin_config");
    super.new(name);
  endfunction
endclass
