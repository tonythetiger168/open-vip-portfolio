// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_sequences.svh

class lin_base_sequence extends uvm_sequence #(lin_transaction);
  `uvm_object_utils(lin_base_sequence)
  function new(string name = "lin_base_sequence");
    super.new(name);
  endfunction
endclass

class lin_random_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "lin_random_sequence");
    super.new(name);
  endfunction
  task body();
    lin_transaction tx;
    repeat (num_txns) begin
      tx = lin_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "LIN tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class lin_diagnostic_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_diagnostic_sequence)
  rand int num_txns = 30;
  function new(string name = "lin_diagnostic_sequence");
    super.new(name);
  endfunction
  task body();
    lin_transaction tx;
    repeat (num_txns) begin
      tx = lin_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type == lin_transaction::DIAGNOSTIC; data_len == 8; })
        `uvm_error("RANDFAIL", "LIN diagnostic randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class lin_sleep_wakeup_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_sleep_wakeup_sequence)
  rand int num_txns = 20;
  function new(string name = "lin_sleep_wakeup_sequence");
    super.new(name);
  endfunction
  task body();
    lin_transaction tx;
    repeat (num_txns) begin
      tx = lin_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type inside {lin_transaction::SLEEP, lin_transaction::WAKEUP}; })
        `uvm_error("RANDFAIL", "LIN sleep/wakeup randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class lin_error_inject_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_error_inject_sequence)
  rand int num_txns = 20;
  function new(string name = "lin_error_inject_sequence");
    super.new(name);
  endfunction
  task body();
    lin_transaction tx;
    repeat (num_txns) begin
      tx = lin_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { with_error == 1; checksum_error == 1; })
        `uvm_error("RANDFAIL", "LIN error inject randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: back-to-back frames with minimal inter-frame gap
class lin_back_to_back_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_back_to_back_sequence)
  rand int num_txns = 48;
  function new(string name = "lin_back_to_back_sequence"); super.new(name); endfunction
  task body();
    lin_transaction tx;
    repeat (num_txns) begin
      tx = lin_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { frame_type == lin_transaction::UNCONDITIONAL; })
        `uvm_error("RANDFAIL", "LIN b2b randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Corner case: PID extremes (0x00, 0x3B, diagnostic 0x3C/0x3D)
class lin_corner_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_corner_sequence)
  function new(string name = "lin_corner_sequence"); super.new(name); endfunction
  task body();
    lin_transaction tx;
    bit [5:0] pids[$] = '{6'h00, 6'h01, 6'h3B, 6'h3C, 6'h3D, 6'h10, 6'h20, 6'h30};
    foreach (pids[i]) begin
      tx = lin_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { pid == pids[i]; frame_type == lin_transaction::UNCONDITIONAL; })
        `uvm_error("RANDFAIL", "LIN corner randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Reset behavior: single frame right after reset release
class lin_reset_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_reset_sequence)
  function new(string name = "lin_reset_sequence"); super.new(name); endfunction
  task body();
    lin_transaction tx = lin_transaction::type_id::create("tx");
    start_item(tx);
    if (!tx.randomize() with { pid == 6'h12; frame_type == lin_transaction::UNCONDITIONAL; })
      `uvm_error("RANDFAIL", "LIN reset randomization failed")
    finish_item(tx);
  endtask
endclass

// Stress: dense traffic with error injection enabled
class lin_stress_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_stress_sequence)
  rand int num_txns = 150;
  function new(string name = "lin_stress_sequence"); super.new(name); endfunction
  task body();
    lin_transaction tx;
    repeat (num_txns) begin
      tx = lin_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { with_error dist {0:=85, 1:=15}; })
        `uvm_error("RANDFAIL", "LIN stress randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Regression: weighted mix of all directed sequences
class lin_regression_sequence extends lin_base_sequence;
  `uvm_object_utils(lin_regression_sequence)
  function new(string name = "lin_regression_sequence"); super.new(name); endfunction
  task body();
    // Unconditional (normal) frame traffic is covered by the random sequence
    lin_random_sequence         unc = lin_random_sequence::type_id::create("unc");
    lin_diagnostic_sequence     dia = lin_diagnostic_sequence::type_id::create("dia");
    lin_back_to_back_sequence   b2b = lin_back_to_back_sequence::type_id::create("b2b");
    lin_corner_sequence         cnr = lin_corner_sequence::type_id::create("cnr");
    lin_sleep_wakeup_sequence   slp = lin_sleep_wakeup_sequence::type_id::create("slp");
    lin_error_inject_sequence   err = lin_error_inject_sequence::type_id::create("err");
    lin_stress_sequence         st  = lin_stress_sequence::type_id::create("st");
    unc.num_txns = 20; dia.num_txns = 5; b2b.num_txns = 24; st.num_txns = 60;
    unc.start(m_sequencer); dia.start(m_sequencer); b2b.start(m_sequencer);
    cnr.start(m_sequencer); slp.start(m_sequencer);
    err.start(m_sequencer); st.start(m_sequencer);
  endtask
endclass
