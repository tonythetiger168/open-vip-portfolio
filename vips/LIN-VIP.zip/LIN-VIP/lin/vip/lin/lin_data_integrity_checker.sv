// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// LIN protocol/data/timing/error checker (class handle + SVA module)
// UVM component handle + companion SVA module lin_data_integrity_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef LIN_DATA_INTEGRITY_CHECKER_SV
`define LIN_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class lin_data_integrity_checker extends uvm_component;
  `uvm_component_utils(lin_data_integrity_checker)
  virtual lin_if vif;
  function new(string name="lin_data_integrity_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual lin_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module lin_data_integrity_sva(lin_if vif);
  property p_lin_checksum; @(posedge vif.clk) disable iff (!vif.rst_n) vif.checksum != 8'h00 |-> vif.data_len > 0; endproperty
  assert_p_lin_checksum: assert property(p_lin_checksum) else `uvm_warning("LIN", "Checksum valid failed");
  cover_p_lin_checksum: cover property(p_lin_checksum);
  property p_lin_frame_type; @(posedge vif.clk) disable iff (!vif.rst_n) $countones({vif.unconditional_frame, vif.event_triggered_frame, vif.sporadic_frame, vif.diagnostic_frame, vif.user_defined_frame, vif.reserved_frame}) <= 1; endproperty
  assert_p_lin_frame_type: assert property(p_lin_frame_type) else `uvm_warning("LIN", "One frame type active failed");
  cover_p_lin_frame_type: cover property(p_lin_frame_type);
endmodule
`endif
