// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// LIN protocol/data/timing/error checker (class handle + SVA module)
// UVM component handle + companion SVA module lin_error_handling_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef LIN_ERROR_CHECKER_SV
`define LIN_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class lin_error_handling_checker extends uvm_component;
  `uvm_component_utils(lin_error_handling_checker)
  virtual lin_if vif;
  function new(string name="lin_error_handling_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual lin_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module lin_error_handling_sva(lin_if vif);
  property p_lin_bit_error; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bit_error == 1 |-> vif.lin_tx != vif.lin_rx; endproperty
  assert_p_lin_bit_error: assert property(p_lin_bit_error) else `uvm_warning("LIN", "Bit error detected failed");
  cover_p_lin_bit_error: cover property(p_lin_bit_error);
  property p_lin_parity_error; @(posedge vif.clk) disable iff (!vif.rst_n) vif.parity_error == 1 |-> vif.parity != {^vif.pid[5:3], ^vif.pid[1:0]}; endproperty
  assert_p_lin_parity_error: assert property(p_lin_parity_error) else `uvm_warning("LIN", "Parity error failed");
  cover_p_lin_parity_error: cover property(p_lin_parity_error);
  property p_lin_timeout; @(posedge vif.clk) disable iff (!vif.rst_n) vif.timeout_error == 1 |-> vif.lin_en == 1; endproperty
  assert_p_lin_timeout: assert property(p_lin_timeout) else `uvm_warning("LIN", "Timeout valid failed");
  cover_p_lin_timeout: cover property(p_lin_timeout);
endmodule
`endif
