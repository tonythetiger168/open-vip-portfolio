// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// LIN protocol/data/timing/error checker (class handle + SVA module)
// UVM component handle + companion SVA module lin_protocol_compliance_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef LIN_PROTOCOL_CHECKER_SV
`define LIN_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class lin_protocol_compliance_checker extends uvm_component;
  `uvm_component_utils(lin_protocol_compliance_checker)
  virtual lin_if vif;
  function new(string name="lin_protocol_compliance_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual lin_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module lin_protocol_compliance_sva(lin_if vif);
  // ---- shared bookkeeping for the rules below ----
  function automatic logic [1:0] pid_par(input logic [5:0] p);
    return {~(p[1] ^ p[3] ^ p[4] ^ p[5]), p[0] ^ p[1] ^ p[2] ^ p[4]};
  endfunction
  int   dom_clks;       // clocks of the current dominant run on lin_rx
  int   last_dom;       // length of the last completed dominant run
  bit   after_break;    // a break was seen and its sync is still due
  always @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) begin dom_clks <= 0; last_dom <= 0; after_break <= 0; end
    else begin
      if (vif.lin_rx === 1'b0) dom_clks <= dom_clks + 1;
      else if (dom_clks != 0) begin last_dom <= dom_clks; dom_clks <= 0; end
      if (vif.break_field) after_break <= 1;
      else if (vif.sync_field || vif.bit_error) after_break <= 0;
    end
  property p_lin_break; @(posedge vif.clk) disable iff (!vif.rst_n) vif.break_field == 1 |-> (last_dom >= 10*8 || dom_clks >= 10*8); endproperty
  assert_p_lin_break: assert property(p_lin_break) else `uvm_warning("LIN", "Break field 13+ bits failed");
  cover_p_lin_break: cover property(p_lin_break);
  property p_lin_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_field |-> after_break; endproperty
  assert_p_lin_sync: assert property(p_lin_sync) else `uvm_warning("LIN", "Sync field 0x55 failed");
  cover_p_lin_sync: cover property(p_lin_sync);
  property p_lin_pid; @(posedge vif.clk) disable iff (!vif.rst_n) !$isunknown(vif.pid); endproperty
  assert_p_lin_pid: assert property(p_lin_pid) else `uvm_warning("LIN", "PID range failed");
  cover_p_lin_pid: cover property(p_lin_pid);
  property p_lin_parity; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.pid_rcvd && !vif.parity_error) |=> vif.parity == pid_par(vif.pid); endproperty
  assert_p_lin_parity: assert property(p_lin_parity) else `uvm_warning("LIN", "Parity valid failed");
  cover_p_lin_parity: cover property(p_lin_parity);
  property p_lin_data_len; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_len >= 4'd1 && vif.data_len <= 4'd8; endproperty
  assert_p_lin_data_len: assert property(p_lin_data_len) else `uvm_warning("LIN", "Data length 1-8 failed");
  cover_p_lin_data_len: cover property(p_lin_data_len);
endmodule
`endif
