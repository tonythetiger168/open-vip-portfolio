// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// LIN Tiered Compliance SVA Checker (module; instantiated from tb/top_tb.sv)
// L1=4 | L2=2 | L3=4 retained below; L4 LIN protocol-specific rules added
// UVM component handle + companion SVA module lin_compliance_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef LIN_COMPLIANCE_CHECKER_SV
`define LIN_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
class lin_compliance_checker extends uvm_component;
  `uvm_component_utils(lin_compliance_checker)
  virtual lin_if vif;
  function new(string name="lin_compliance_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual lin_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module lin_compliance_sva(lin_if vif);
  // ---- shared bookkeeping for the rules below ----
  function automatic logic [1:0] pid_par(input logic [5:0] p);
    return {~(p[1] ^ p[3] ^ p[4] ^ p[5]), p[0] ^ p[1] ^ p[2] ^ p[4]};
  endfunction
  int   dom_clks;       // clocks of the current dominant run on lin_rx
  int   last_dom;       // length of the last completed dominant run
  bit   after_break;    // a break was seen and its sync is still due
  always @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) begin dom_clks <= 0; last_dom <= 0; after_break <= 0; end
    else begin
      if (vif.lin_rx === 1'b0) dom_clks <= dom_clks + 1;
      else if (dom_clks != 0) begin last_dom <= dom_clks; dom_clks <= 0; end
      if (vif.break_field) after_break <= 1;
      else if (vif.sync_field || vif.bit_error) after_break <= 0;
    end
  // ---------------- L1: signal sanity (4) ----------------
  int l1_pass[4];
  int l1_fail[4];
  // a break is at least 10 dominant bit times (8 clocks each) on lin_rx
  property p_lin_break; @(posedge vif.clk) disable iff (!vif.rst_n) vif.break_field |-> (last_dom >= 10*8 || dom_clks >= 10*8); endproperty
  assert_p_lin_break: assert property(p_lin_break) l1_pass[0]++; else begin `uvm_warning("LIN_L1", "Break 13+ bits failed"); l1_fail[0]++; end
  cover_p_lin_break: cover property(p_lin_break);
  // the sync byte (0x55) is accepted only right after a break
  property p_lin_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync_field |-> after_break; endproperty
  assert_p_lin_sync: assert property(p_lin_sync) l1_pass[1]++; else begin `uvm_warning("LIN_L1", "Sync 0x55 failed"); l1_fail[1]++; end
  cover_p_lin_sync: cover property(p_lin_sync);
  property p_lin_pid; @(posedge vif.clk) disable iff (!vif.rst_n) !$isunknown(vif.pid); endproperty
  assert_p_lin_pid: assert property(p_lin_pid) l1_pass[2]++; else begin `uvm_warning("LIN_L1", "PID 0-63 failed"); l1_fail[2]++; end
  cover_p_lin_pid: cover property(p_lin_pid);
  // P0 = ID0^ID1^ID2^ID4, P1 = ~(ID1^ID3^ID4^ID5) unless a parity error is flagged
  property p_lin_parity; @(posedge vif.clk) disable iff (!vif.rst_n) !vif.parity_error |-> vif.parity == pid_par(vif.pid); endproperty
  assert_p_lin_parity: assert property(p_lin_parity) l1_pass[3]++; else begin `uvm_warning("LIN_L1", "Parity failed"); l1_fail[3]++; end
  cover_p_lin_parity: cover property(p_lin_parity);
  // ---------------- L2: FSM legality (2) ----------------
  int l2_pass[2];
  int l2_fail[2];
  property p_lin_data_len; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_len >= 4'd1 && vif.data_len <= 4'd8; endproperty
  assert_p_lin_data_len: assert property(p_lin_data_len) l2_pass[0]++; else begin `uvm_warning("LIN_L2", "Data 1-8 failed"); l2_fail[0]++; end
  cover_p_lin_data_len: cover property(p_lin_data_len);
  property p_lin_checksum; @(posedge vif.clk) disable iff (!vif.rst_n) vif.checksum != 8'h00 |-> vif.data_len > 0; endproperty
  assert_p_lin_checksum: assert property(p_lin_checksum) l2_pass[1]++; else begin `uvm_warning("LIN_L2", "Checksum failed"); l2_fail[1]++; end
  cover_p_lin_checksum: cover property(p_lin_checksum);
  // ---------------- L3: LIN protocol rules (4) ----------------
  int l3_pass[4];
  int l3_fail[4];
  // L3-1: checksum field must follow the data bytes within a frame (no checksum without a data phase)
  property p_lin_l3_csum_after_data; @(posedge vif.clk) disable iff (!vif.rst_n) $changed(vif.checksum) |-> ($changed(vif.data_len) || vif.data_len != 4'd0); endproperty
  assert_p_lin_l3_csum_after_data: assert property(p_lin_l3_csum_after_data) l3_pass[0]++; else begin `uvm_warning("LIN_L3", "Checksum without preceding data failed"); l3_fail[0]++; end
  cover_p_lin_l3_csum_after_data: cover property(p_lin_l3_csum_after_data);
  // L3-2: data phase only after a valid PID (no orphan data); bad PID must flag parity_error
  property p_lin_l3_data_after_pid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_len != 4'd0 |-> (vif.parity[0] == (vif.pid[0]^vif.pid[1]^vif.pid[2]^vif.pid[4])) || vif.parity_error; endproperty
  assert_p_lin_l3_data_after_pid: assert property(p_lin_l3_data_after_pid) l3_pass[1]++; else begin `uvm_warning("LIN_L3", "Data without valid PID failed"); l3_fail[1]++; end
  cover_p_lin_l3_data_after_pid: cover property(p_lin_l3_data_after_pid);
  // L3-3: data byte count must match the length encoded by PID bits [5:4] (2/4/8 bytes)
  property p_lin_l3_dlc; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.data_len != 4'd0 && !vif.parity_error) |-> ((vif.pid[5:4] == 2'b11) ? (vif.data_len == 4'd8) : (vif.pid[5:4] == 2'b10) ? (vif.data_len == 4'd4) : (vif.data_len == 4'd2)); endproperty
  assert_p_lin_l3_dlc: assert property(p_lin_l3_dlc) l3_pass[2]++; else begin `uvm_warning("LIN_L3", "Data length vs PID DLC failed"); l3_fail[2]++; end
  cover_p_lin_l3_dlc: cover property(p_lin_l3_dlc);
  // L3-4: enhanced checksum not used on diagnostic frames (PID 0x3C/0x3D keep classic 8-byte data)
  property p_lin_l3_diag_classic; @(posedge vif.clk) disable iff (!vif.rst_n) ((vif.pid == 6'h3C || vif.pid == 6'h3D) && vif.data_len != 4'd0) |-> vif.data_len == 4'd8; endproperty
  assert_p_lin_l3_diag_classic: assert property(p_lin_l3_diag_classic) l3_pass[3]++; else begin `uvm_warning("LIN_L3", "Diagnostic frame not classic 8-byte failed"); l3_fail[3]++; end
  cover_p_lin_l3_diag_classic: cover property(p_lin_l3_diag_classic);

  // ---------------- L4: LIN protocol-specific rules (5) ----------------
  // L4-1: bus idle is recessive; dominant drive only while enabled
  a_lin_l4_idle : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.lin_rx == 1'b0) |-> vif.lin_en)
    else `uvm_error("SVA_L4", "lin: dominant drive while transmitter disabled")

  // L4-2: every sync break is followed by a sync field or an error indication
  a_lin_l4_break_sync : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.break_field) |-> s_eventually (vif.sync_field || vif.wakeup_signal ||
                                             vif.parity_error || vif.bit_error))
    else `uvm_error("SVA_L4", "lin: sync break not followed by sync field")

  // L4-3: sync field is followed by a PID (slave updates pid/length or flags parity)
  a_lin_l4_sync_then_pid : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.sync_field) |-> s_eventually (vif.pid_rcvd || vif.parity_error))
    else `uvm_error("SVA_L4", "lin: sync not followed by PID")

  // L4-4: parity field matches the PID parity bits when no parity error flagged
  a_lin_l4_parity_ok : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.sync_field && !vif.parity_error) |-> (vif.parity[0] == (vif.pid[0]^vif.pid[1]^vif.pid[2]^vif.pid[4])))
    else `uvm_error("SVA_L4", "lin: PID parity P0 mismatch")

  // L4-5: sleep is exited by activity (wakeup)
  a_lin_l4_sleep_wake : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.sleep_mode && !vif.lin_rx) |-> s_eventually !vif.sleep_mode)
    else `uvm_error("SVA_L4", "lin: sleep not exited after wakeup pulse")

  // ---------------- L4: protocol coverage ----------------
  c_lin_l4_frame : cover property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.break_field) ##[1:500] $rose(vif.sync_field));
  c_lin_l4_sleep : cover property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.sleep_mode) ##[1:2000] $fell(vif.sleep_mode));
endmodule
`endif
