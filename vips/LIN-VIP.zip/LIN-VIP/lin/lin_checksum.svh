// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lin_checksum.svh -- LIN PID parity + classic/enhanced checksum helpers
`ifndef LIN_CHECKSUM_SVH
`define LIN_CHECKSUM_SVH

// PID parity: P0 = id0^id1^id2^id4, P1 = ~(id1^id3^id4^id5)
function automatic bit [1:0] lin_pid_parity(bit [5:0] pid);
  bit p0, p1;
  p0 = pid[0] ^ pid[1] ^ pid[2] ^ pid[4];
  p1 = ~(pid[1] ^ pid[3] ^ pid[4] ^ pid[5]);
  return {p1, p0};
endfunction

// LIN 1.x length encoding from PID bits [5:4]; diagnostic PIDs use 8 bytes
function automatic int lin_len_from_pid(bit [5:0] pid);
  if (pid >= 60) return 8;
  case (pid[5:4])
    2'b00, 2'b01: return 2;
    2'b10:        return 4;
    default:      return 8;
  endcase
endfunction

// Classic checksum: inverted carry-sum of data bytes
function automatic bit [7:0] lin_classic_checksum(const ref bit [7:0] data[$]);
  int sum = 0;
  foreach (data[i]) begin
    sum += data[i];
    sum = (sum & 8'hFF) + (sum >> 8);
  end
  return ~sum[7:0];
endfunction

// Enhanced checksum: classic + PID (LIN 2.x, non-diagnostic frames)
function automatic bit [7:0] lin_enhanced_checksum(const ref bit [7:0] data[$], bit [5:0] pid);
  int sum = {2'b0, pid};
  foreach (data[i]) begin
    sum += data[i];
    sum = (sum & 8'hFF) + (sum >> 8);
  end
  sum = (sum & 8'hFF) + (sum >> 8);
  return ~sum[7:0];
endfunction

`endif
