// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_transaction.svh

class lin_transaction extends uvm_sequence_item;
  `uvm_object_utils(lin_transaction)

  typedef enum bit [2:0] {
    UNCONDITIONAL  = 3'd0,
    EVENT_TRIGGERED= 3'd1,
    SPORADIC       = 3'd2,
    DIAGNOSTIC     = 3'd3,
    USER_DEFINED   = 3'd4,
    RESERVED       = 3'd5,
    SLEEP          = 3'd6,
    WAKEUP         = 3'd7
  } lin_frame_type_e;

  rand lin_frame_type_e frame_type;
  rand bit [5:0]  pid;
  rand bit [1:0]  parity;
  rand bit [7:0]  data_payload[];
  rand bit [3:0]  data_len;
  rand bit [7:0]  checksum;
  rand bit        enhanced_checksum;
  rand bit [7:0]  schedule_table_id;
  rand bit        sleep_mode;
  rand bit        wakeup_signal;
  rand bit        with_error;
  rand bit        checksum_error;
  rand bit        parity_error;
  rand bit        timeout_error;
  rand bit        bit_error;

  // REACHABILITY: PIDs 60 (master req) / 61 (slave resp) are legal diagnostic
  // frames; extend domain so lin_frame_cg diag bin can be hit. 62/63 stay excluded
  // (reserved by the LIN spec) and are ignore_bins in the covergroup.
  constraint c_pid { pid inside {[0:61]}; } // valid PID range incl. diagnostic
  // Frame length follows the identifier (ID[5:4]: 0x/01 -> 2, 10 -> 4,
  // 11 -> 8 bytes; the diagnostic IDs carry 8), as the bus node decodes it
  constraint c_data_len {
    data_payload.size() == data_len;
    if (frame_type inside {SLEEP, WAKEUP}) data_len == 0;
    else if (pid >= 60 || pid[5:4] == 2'b11) data_len == 8;
    else if (pid[5:4] == 2'b10) data_len == 4;
    else data_len == 2;
  }
  // Only the diagnostic frames use the diagnostic IDs 60/61
  constraint c_pid_class { (frame_type != DIAGNOSTIC) -> pid <= 59; }
  // sleep_mode / wakeup_signal say the same as the frame type
  constraint c_mode {
    sleep_mode    == (frame_type == SLEEP);
    wakeup_signal == (frame_type == WAKEUP);
  }
  constraint c_frame_type {
    frame_type dist {UNCONDITIONAL:=60, EVENT_TRIGGERED:=10, SPORADIC:=10,
                     DIAGNOSTIC:=10, SLEEP:=5, WAKEUP:=5};
  }
  constraint c_diagnostic {
    if (frame_type == DIAGNOSTIC) {
      pid inside {60, 61}; // 0x3C=master request, 0x3D=slave response
      data_len == 8;
      // a master request whose first byte is 0 is the go-to-sleep command
      (pid == 60) -> data_payload[0] != 8'h00;
    }
  }
  // Errors are injected only when a sequence asks for them, only on frames,
  // and with_error says that at least one of them is injected
  constraint c_error {
    soft with_error == 0;
    soft checksum_error == 0;
    soft parity_error == 0;
    soft timeout_error == 0;
    soft bit_error == 0;
    with_error == (checksum_error || parity_error || timeout_error || bit_error);
    (frame_type inside {SLEEP, WAKEUP}) -> !with_error;
  }

  function new(string name = "lin_transaction");
    super.new(name);
  endfunction

  // There are no field macros, so uvm_object::copy() copied nothing and the
  // driver's expected item (exp.copy(req)) was all zeros
  function void do_copy(uvm_object rhs);
    lin_transaction rhs_;
    super.do_copy(rhs);
    if (!$cast(rhs_, rhs)) `uvm_fatal("CAST", "lin_transaction::do_copy: wrong type")
    frame_type = rhs_.frame_type;
    pid = rhs_.pid;
    parity = rhs_.parity;
    data_payload = rhs_.data_payload;
    data_len = rhs_.data_len;
    checksum = rhs_.checksum;
    enhanced_checksum = rhs_.enhanced_checksum;
    schedule_table_id = rhs_.schedule_table_id;
    sleep_mode = rhs_.sleep_mode;
    wakeup_signal = rhs_.wakeup_signal;
    with_error = rhs_.with_error;
    checksum_error = rhs_.checksum_error;
    parity_error = rhs_.parity_error;
    timeout_error = rhs_.timeout_error;
    bit_error = rhs_.bit_error;
  endfunction

  function string convert2string();
    return $sformatf("LIN: type=%s pid=0x%0x len=%0d cs=%0x enh=%b sleep=%b wakeup=%b err=%b",
      frame_type.name(), pid, data_len, checksum, enhanced_checksum, sleep_mode, wakeup_signal, with_error);
  endfunction
endclass
