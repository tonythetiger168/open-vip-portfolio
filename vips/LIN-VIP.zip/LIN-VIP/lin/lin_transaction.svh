// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_transaction.svh

class lin_transaction extends uvm_sequence_item;
  `uvm_object_utils(lin_transaction)

  typedef enum bit [2:0] {
    UNCONDITIONAL  = 3'd0,
    EVENT_TRIGGERED= 3'd1,
    SPORADIC       = 3'd2,
    DIAGNOSTIC     = 3'd3,
    USER_DEFINED   = 3'd4,
    RESERVED       = 3'd5,
    SLEEP          = 3'd6,
    WAKEUP         = 3'd7
  } lin_frame_type_e;

  rand lin_frame_type_e frame_type;
  rand bit [5:0]  pid;
  rand bit [1:0]  parity;
  rand bit [7:0]  data_payload[];
  rand bit [3:0]  data_len;
  rand bit [7:0]  checksum;
  rand bit        enhanced_checksum;
  rand bit [7:0]  schedule_table_id;
  rand bit        sleep_mode;
  rand bit        wakeup_signal;
  rand bit        with_error;
  rand bit        checksum_error;
  rand bit        parity_error;
  rand bit        timeout_error;
  rand bit        bit_error;

  // REACHABILITY: PIDs 60 (master req) / 61 (slave resp) are legal diagnostic
  // frames; extend domain so lin_frame_cg diag bin can be hit. 62/63 stay excluded
  // (reserved by the LIN spec) and are ignore_bins in the covergroup.
  constraint c_pid { pid inside {[0:61]}; } // valid PID range incl. diagnostic
  constraint c_data_len { data_len inside {[0:8]}; data_payload.size() == data_len; }
  constraint c_frame_type {
    frame_type dist {UNCONDITIONAL:=60, EVENT_TRIGGERED:=10, SPORADIC:=10,
                     DIAGNOSTIC:=10, SLEEP:=5, WAKEUP:=5};
  }
  constraint c_diagnostic {
    if (frame_type == DIAGNOSTIC) {
      pid inside {60, 61}; // 0x3C=master request, 0x3D=slave response
      data_len == 8;
    }
  }
  constraint c_sleep {
    if (frame_type == SLEEP) { data_len == 0; sleep_mode == 1; }
  }
  constraint c_wakeup {
    if (frame_type == WAKEUP) { data_len == 0; wakeup_signal == 1; }
  }
  constraint c_error {
    with_error dist {0:=95, 1:=5};
    checksum_error dist {0:=98, 1:=2};
    parity_error   dist {0:=98, 1:=2};
    timeout_error  dist {0:=98, 1:=2};
    bit_error      dist {0:=98, 1:=2};
  }

  function new(string name = "lin_transaction");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("LIN: type=%s pid=0x%0x len=%0d cs=%0x enh=%b sleep=%b wakeup=%b err=%b",
      frame_type.name(), pid, data_len, checksum, enhanced_checksum, sleep_mode, wakeup_signal, with_error);
  endfunction
endclass
