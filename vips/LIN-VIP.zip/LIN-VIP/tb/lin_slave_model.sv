// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lin_slave_model.sv -- functional LIN slave node DUT (pure RTL, no UVM).
// Receives LIN frames on lin_rx (break / sync / PID / data / checksum,
// 8 clks per bit), verifies PID parity and checksum, echoes the frame
// on lin_tx (error marker 0xFF after sync on parity failure), tracks
// bus sleep and wakeup.

`ifndef LIN_SLAVE_MODEL_SV
`define LIN_SLAVE_MODEL_SV

module lin_slave_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        lin_rx,
  input  logic        lin_en,
  output logic        lin_tx,
  output logic        sleep_mode,
  output logic        wakeup_signal,
  output logic        bit_error,
  output logic        checksum_error,
  output logic        parity_error,
  output logic        timeout_error,
  output logic        framing_error,
  output logic [5:0]  pid,
  output logic [1:0]  parity,
  output logic        sync_field,
  output logic        break_field,
  output logic [3:0]  data_len,
  output logic [7:0]  checksum
);
  localparam int BIT_CLKS  = 8;
  localparam int BREAK_MIN = 10;   // min dominant bit-times for a valid break
  localparam int SLEEP_BITS= 24;   // recessive bit-times to enter sleep
  localparam int MAXB      = 11;   // sync + pid + 8 data + checksum

  typedef enum logic [3:0] {S_IDLE, S_DOM, S_WAIT_START, S_RX, S_EVAL, S_TX, S_WAKEUP} state_e;
  state_e state;

  int   dom_cnt;
  int   rec_cnt;                    // recessive bit-times (sleep detect)
  int   sclk;
  int   bit_cnt;
  logic [7:0] shreg;
  int   nrx;
  logic [7:0] rxb [MAXB];
  int   exp_bytes;                  // expected total bytes for this frame
  int   tmo;                        // start-bit timeout counter

  // tx serializer
  logic [255:0] tx_shift;
  int   tx_len, tx_idx, tx_clk;

  function automatic int len_from_pid(input logic [5:0] p);
    if (p >= 60) return 8;
    case (p[5:4])
      2'b00, 2'b01: return 2;
      2'b10:        return 4;
      default:      return 8;
    endcase
  endfunction

  function automatic logic [1:0] pid_parity(input logic [5:0] p);
    logic p0, p1;
    p0 = p[0] ^ p[1] ^ p[2] ^ p[4];
    p1 = ~(p[1] ^ p[3] ^ p[4] ^ p[5]);
    return {p1, p0};
  endfunction

  // push one UART byte (start, LSB first, stop) onto tx_shift
  task automatic tx_push_byte(input logic [7:0] d);
    tx_shift[tx_len] = 1'b0; tx_len++;
    for (int i = 0; i < 8; i++) begin tx_shift[tx_len] = d[i]; tx_len++; end
    tx_shift[tx_len] = 1'b1; tx_len++;
  endtask

  // build the echo bit stream from the received frame
  task automatic build_tx(input bit parity_bad);
    int nb;
    tx_len = 0;
    for (int i = 0; i < 13; i++) begin tx_shift[tx_len] = 1'b0; tx_len++; end // break
    tx_shift[tx_len] = 1'b1; tx_len++;                                        // delim
    tx_push_byte(8'h55);                                                      // sync
    if (parity_bad) begin
      tx_push_byte(8'hFF);                                                    // error marker
    end else begin
      nb = len_from_pid(rxb[1][5:0]);
      for (int i = 1; i <= 1 + nb && i < nrx; i++) tx_push_byte(rxb[i]);      // pid+data
      if (nrx > 1 + nb) tx_push_byte(rxb[1+nb]);                              // checksum
    end
    for (int i = 0; i < 6; i++) begin tx_shift[tx_len] = 1'b1; tx_len++; end  // gap
  endtask

  integer i;
  initial begin
    lin_tx = 1'b1; sleep_mode = 0; wakeup_signal = 0;
    bit_error = 0; checksum_error = 0; parity_error = 0;
    timeout_error = 0; framing_error = 0;
    pid = '0; parity = '0; sync_field = 0; break_field = 0;
    data_len = '0; checksum = '0;
    state = S_IDLE; dom_cnt = 0; rec_cnt = 0; sclk = 0; bit_cnt = 0;
    shreg = '0; nrx = 0; exp_bytes = 0; tmo = 0;
    tx_len = 0; tx_idx = 0; tx_clk = 0;
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; lin_tx <= 1'b1; sleep_mode <= 0; wakeup_signal <= 0;
      parity_error <= 0; checksum_error <= 0; timeout_error <= 0; bit_error <= 0;
      framing_error <= 0; sync_field <= 0; break_field <= 0;
      dom_cnt <= 0; rec_cnt <= 0; nrx <= 0; tmo <= 0;
    end else begin
      sync_field <= 0; break_field <= 0;
      case (state)
        S_IDLE: begin
          if (lin_rx === 1'b0) begin
            sleep_mode <= 0;
            rec_cnt <= 0;
            dom_cnt <= 1;
            sclk <= BIT_CLKS - 2;    // next sample ~1 bit later
            state <= S_DOM;
          end else begin
            // sleep detect: count recessive bit-times
            if (rec_cnt < SLEEP_BITS*BIT_CLKS) rec_cnt <= rec_cnt + 1;
            if (rec_cnt == SLEEP_BITS*BIT_CLKS - 1) sleep_mode <= 1;
          end
        end
        S_DOM: begin
          if (sclk > 0) sclk <= sclk - 1;
          else begin
            sclk <= BIT_CLKS - 1;
            if (lin_rx === 1'b0) begin
              dom_cnt <= dom_cnt + 1;
              if (dom_cnt > 24) begin state <= S_IDLE; end // stuck dominant
            end else begin
              if (dom_cnt >= BREAK_MIN) begin
                break_field <= 1;
                nrx <= 0;
                tmo <= 0;
                state <= S_WAIT_START;
              end else begin
                // short dominant pulse: wakeup
                state <= S_WAKEUP;
                tx_len <= dom_cnt * BIT_CLKS;
                tx_idx <= 0;
                wakeup_signal <= 1;
              end
            end
          end
        end
        S_WAKEUP: begin
          // echo the wakeup pulse on lin_tx
          if (tx_idx < tx_len) begin
            lin_tx <= 1'b0;
            tx_idx <= tx_idx + 1;
          end else begin
            lin_tx <= 1'b1;
            wakeup_signal <= 0;
            state <= S_IDLE;
          end
        end
        S_WAIT_START: begin
          if (lin_rx === 1'b0) begin
            sclk <= BIT_CLKS/2 - 1;
            bit_cnt <= 0;
            shreg <= '0;
            state <= S_RX;
            tmo <= 0;
          end else if (tmo > 24*BIT_CLKS) begin
            timeout_error <= 1;
            state <= S_EVAL;         // partial frame
          end else tmo <= tmo + 1;
        end
        S_RX: begin
          if (sclk > 0) sclk <= sclk - 1;
          else begin
            sclk <= BIT_CLKS - 1;
            if (bit_cnt < 8) begin
              shreg[bit_cnt] <= lin_rx;   // LSB first
              bit_cnt <= bit_cnt + 1;
            end else begin
              // stop bit
              if (lin_rx !== 1'b1) framing_error <= 1;
              if (nrx == 0 && shreg != 8'h55) begin
                bit_error <= 1;           // sync field must be 0x55
                state <= S_IDLE;
              end else begin
                if (nrx == 0) sync_field <= 1;
                rxb[nrx] <= shreg;
                nrx <= nrx + 1;
                if (nrx == 0) exp_bytes <= MAXB;
                if (nrx == 1) exp_bytes <= 2 + len_from_pid(shreg[5:0]) + 1;
                if (nrx >= 2 && nrx + 1 >= exp_bytes) state <= S_EVAL;
                else state <= S_WAIT_START;
              end
            end
          end
        end
        S_EVAL: begin
          if (nrx >= 2) begin
            logic [5:0] p;
            int nb;
            p = rxb[1][5:0];
            nb = len_from_pid(p);
            pid <= p;
            parity <= rxb[1][7:6];
            data_len <= nb[3:0];
            if (nrx > 1 + nb) checksum <= rxb[1+nb];
            if (rxb[1][7:6] != pid_parity(p)) begin
              parity_error <= 1;
              build_tx(1'b1);
            end else begin
              parity_error <= 0;
              build_tx(1'b0);
            end
            state <= S_TX;
            tx_idx <= 0; tx_clk <= 0;
          end else begin
            state <= S_IDLE;
          end
        end
        S_TX: begin
          if (tx_clk == 0) lin_tx <= tx_shift[tx_idx];
          if (tx_clk == BIT_CLKS-1) begin
            tx_clk <= 0;
            if (tx_idx >= tx_len-1) begin
              lin_tx <= 1'b1;
              state <= S_IDLE;
            end else tx_idx <= tx_idx + 1;
          end else tx_clk <= tx_clk + 1;
        end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule
`endif
