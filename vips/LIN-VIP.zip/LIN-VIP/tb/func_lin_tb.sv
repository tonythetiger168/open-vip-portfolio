// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_lin_tb.sv -- self-checking functional test for the LIN slave model
// (tb/lin_slave_model.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py LIN-VIP
//
// Model contract (from tb/lin_slave_model.sv), 8 clocks per bit:
//   * a header is a break (>= 10 dominant bits, then a recessive delimiter),
//     the sync byte 0x55 and the protected identifier; bytes are UART frames
//     (start 0, 8 data bits LSB first, stop 1). Data length follows the ID:
//     ID[5:4] 00/01 -> 2 bytes, 10 -> 4, 11 -> 8, IDs 60-63 -> 8; a checksum
//     byte follows the data.
//   * PID parity: P0 = ID0^ID1^ID2^ID4, P1 = ~(ID1^ID3^ID4^ID5) (LIN 2.x).
//   * after the frame the slave reports pid/parity/data_len/checksum and
//     re-transmits the frame on lin_tx (13-bit break, delimiter, 0x55, PID,
//     data, checksum); on a parity error it sends 0xFF after the sync.
//   * errors: sync other than 0x55 -> bit_error; a 0 stop bit ->
//     framing_error; no start bit within 24 bit times -> timeout_error.
//   * a dominant pulse shorter than a break is a wake-up: the slave answers
//     with a dominant pulse of the measured length (bit-sampled, so up to
//     one bit longer) with wakeup_signal.
//   * 24 recessive bit times on an idle bus -> sleep_mode.
// Known defects (XFAIL):
//   * the byte receiver samples the middle of the start bit as data bit 0
//     (it does not skip the start bit), so the sync byte 0x55 is read as
//     0xAA and every frame ends in bit_error. The frame-level checks below
//     only run once that is fixed (the XFAIL then turns into an XPASS).
//   * a LIN slave must verify the checksum byte; the model never sets
//     checksum_error.
//   * (seen with the start-bit sampling corrected) the reported checksum
//     and the re-transmitted last byte are rxb[1+len], the last data byte,
//     instead of the checksum byte rxb[2+len].

module func_lin_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int BT = 8;
  int checks = 0, fails = 0, xfails = 0;

  logic clk = 1'b0, rst_n = 1'b0, rx = 1'b1, en = 1'b1;
  wire  tx, sleep, wake, bit_err, cks_err, par_err, tmo_err, frm_err, sync_f, brk_f;
  wire  [5:0] pid;
  wire  [1:0] parity;
  wire  [3:0] dlen;
  wire  [7:0] cks;

  always #5 clk = ~clk;

  lin_slave_model u_dut (
    .clk(clk), .rst_n(rst_n), .lin_rx(rx), .lin_en(en), .lin_tx(tx), .sleep_mode(sleep),
    .wakeup_signal(wake), .bit_error(bit_err), .checksum_error(cks_err), .parity_error(par_err),
    .timeout_error(tmo_err), .framing_error(frm_err), .pid(pid), .parity(parity),
    .sync_field(sync_f), .break_field(brk_f), .data_len(dlen), .checksum(cks)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // reference PID and checksum (LIN 2.x enhanced: PID included)
  function automatic logic [7:0] prot(input logic [5:0] id);
    logic p0 = id[0] ^ id[1] ^ id[2] ^ id[4];
    logic p1 = ~(id[1] ^ id[3] ^ id[4] ^ id[5]);
    return {p1, p0, id};
  endfunction
  function automatic logic [7:0] lin_cks(input logic [7:0] p, input logic [7:0] d[$]);
    int s = p;
    foreach (d[i]) begin s += d[i]; if (s > 255) s -= 255; end
    return ~s[7:0];
  endfunction
  function automatic int nlen(input logic [5:0] id);
    if (id >= 60) return 8;
    return id[5:4] == 2'b10 ? 4 : id[5:4] == 2'b11 ? 8 : 2;
  endfunction

  task automatic bits(input bit v, input int n); rx = v; repeat (n * BT) @(negedge clk); endtask
  task automatic ubyte(input [7:0] d, input bit stop = 1);
    bits(0, 1);
    for (int i = 0; i < 8; i++) bits(d[i], 1);
    bits(stop, 1);
  endtask

  // capture the slave's re-transmission: sample lin_tx mid-bit
  logic [7:0] txb[$];
  int brk_len;
  task automatic capture_tx(input int nbytes);
    int t = 0;
    txb.delete(); brk_len = 0;
    while (tx === 1'b1 && t < 4000) begin @(negedge clk); t++; end
    while (tx === 1'b0) begin @(negedge clk); brk_len++; end
    for (int k = 0; k < nbytes; k++) begin
      logic [7:0] d;
      t = 0;
      while (tx === 1'b1 && t < 400) begin @(negedge clk); t++; end
      if (t >= 400) break;
      repeat (BT / 2) @(negedge clk);            // middle of the start bit
      for (int i = 0; i < 8; i++) begin repeat (BT) @(negedge clk); d[i] = tx; end
      repeat (BT) @(negedge clk);                // stop bit
      txb.push_back(d);
    end
  endtask

  logic [7:0] data[$];
  logic [7:0] frame[$];
  int sync_seen, brk_seen;
  always @(posedge clk) begin if (sync_f) sync_seen++; if (brk_f) brk_seen++; end

  task automatic frame_tx(input logic [5:0] id, input logic [7:0] d[$], input bit bad_par = 0,
                          input logic [7:0] sync = 8'h55, input int brk = 13);
    logic [7:0] p = prot(id) ^ (bad_par ? 8'h40 : 8'h00);
    sync_seen = 0; brk_seen = 0;
    bits(0, brk); bits(1, 1);
    ubyte(sync);
    ubyte(p);
    foreach (d[i]) ubyte(d[i]);
    ubyte(lin_cks(p, d));
    rx = 1;
    frame.delete(); frame.push_back(8'h55); frame.push_back(p);
    foreach (d[i]) frame.push_back(d[i]);
    frame.push_back(lin_cks(p, d));
  endtask

  // re-transmitted bytes match the frame except the last (checksum) one
  function automatic bit same_but_last(input int n);
    if (txb.size() != n) return 0;
    for (int i = 0; i < n - 1; i++) if (txb[i] != frame[i]) return 0;
    return 1;
  endfunction

  bit ok, rx_ok;
  int wl;

  initial begin
    chk(prot(6'h00) == 8'h80 && prot(6'h3C) == 8'h3C && prot(6'h3D) == 8'h7D && prot(6'h01) == 8'hC1,
        "PID reference matches the LIN specification table");
    repeat (2) @(negedge clk);
    rst_n = 1;
    bits(1, 4);

    // header reception
    data = '{8'h12, 8'h34};
    frame_tx(6'h05, data);
    chk(brk_seen == 1, "break field (13 dominant bits + delimiter) detected");
    chk_xfail(sync_seen == 1 && !bit_err, "sync byte 0x55 received without bit error");
    rx_ok = (sync_seen == 1 && !bit_err);
    bits(1, 40);

    if (rx_ok) begin
      // 2-byte frame (ID 0x05)
      rst_n = 0; @(negedge clk); rst_n = 1; bits(1, 4);
      data = '{8'h12, 8'h35};
      frame_tx(6'h05, data);
      capture_tx(5);
      chk(pid == 6'h05 && parity == prot(6'h05) >> 6 && !par_err, "PID and parity decoded");
      chk(dlen == 2, "2-byte length from ID[5:4]=00");
      chk_xfail(cks == lin_cks(prot(6'h05), data), "checksum output carries the received checksum byte");
      chk(brk_len >= 13 * BT - 2 && brk_len <= 13 * BT + 2, $sformatf("re-transmitted break is 13 bits (%0d clocks)", brk_len));
      chk(same_but_last(5), $sformatf("frame re-transmitted: sync, PID, data (%0d bytes)", txb.size()));
      chk_xfail(txb.size() == 5 && txb[4] == frame[4], "re-transmitted frame ends with the checksum");
      bits(1, 4);

      // 4- and 8-byte frames
      data = '{8'hA1, 8'hB2, 8'hC3, 8'hD4};
      frame_tx(6'h25, data);
      capture_tx(7);
      chk(pid == 6'h25 && dlen == 4 && same_but_last(7), "4-byte frame (ID[5:4]=10)");
      bits(1, 4);
      data = '{1, 2, 3, 4, 5, 6, 7, 8};
      frame_tx(6'h3C, data);
      capture_tx(11);
      chk(pid == 6'h3C && dlen == 8 && same_but_last(11), "8-byte frame (ID 0x3C)");
      bits(1, 4);

      // parity error
      data = '{8'h55, 8'hAA};
      frame_tx(6'h05, data, 1);
      capture_tx(2);
      chk(par_err === 1'b1, "PID parity error flagged");
      chk(txb.size() == 2 && txb[0] == 8'h55 && txb[1] == 8'hFF, "parity error answered with 0xFF after the sync");
      bits(1, 4);

      // checksum
      bits(0, 13); bits(1, 1);
      ubyte(8'h55); ubyte(prot(6'h06)); ubyte(8'h01); ubyte(8'h02); ubyte(8'h00);
      rx = 1;
      capture_tx(5);
      chk_xfail(cks_err === 1'b1, "wrong checksum byte flagged");
      bits(1, 4);

      // framing error
      bits(0, 13); bits(1, 1);
      ubyte(8'h55); ubyte(prot(6'h05), 0);
      rx = 1;
      bits(1, 2);
      chk(frm_err === 1'b1, "stop bit 0 flagged as framing error");
    end

    // bad sync
    rst_n = 0; @(negedge clk); rst_n = 1; bits(1, 4);
    bits(0, 13); bits(1, 1);
    ubyte(8'h54);
    rx = 1;
    bits(1, 2);
    chk(bit_err === 1'b1, "sync byte other than 0x55 flagged as bit error");
    bits(1, 30);

    // timeout: break and delimiter, then silence
    rst_n = 0; @(negedge clk); rst_n = 1; bits(1, 4);
    bits(0, 13); bits(1, 1);
    bits(1, 23);
    chk(!tmo_err, "no timeout within 23 bit times after the break");
    bits(1, 3);
    chk(tmo_err === 1'b1, "no byte within 24 bit times after the break: timeout");
    bits(1, 40);

    // wake-up pulse
    rst_n = 0; @(negedge clk); rst_n = 1;
    bits(1, 2);
    bits(0, 5);
    rx = 1;
    wl = 0;
    while (!wake && wl < 100) begin @(negedge clk); wl++; end
    chk(wake === 1'b1, "short dominant pulse answered as a wake-up");
    wl = 0;
    while (tx === 1'b1 && wl < 50) begin @(negedge clk); wl++; end
    wl = 0;
    while (tx === 1'b0 && wl < 200) begin @(negedge clk); wl++; end
    chk(wl >= 5 * BT && wl <= 6 * BT, $sformatf("wake-up answer as long as the pulse, to the bit sampling (%0d clocks)", wl));

    // sleep after 24 idle bit times
    rst_n = 0; @(negedge clk); rst_n = 1;
    bits(1, 23);
    chk(!sleep, "awake after 23 idle bit times");
    bits(1, 2);
    chk(sleep === 1'b1, "sleep after 24 idle bit times");
    bits(0, 1); bits(1, 1);
    chk(!sleep, "bus activity leaves sleep");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #3000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
