// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- LIN testbench top with a functional LIN slave DUT (closed loop)

`ifndef LIN_TB_SV
`define LIN_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import lin_pkg::*;
import lin_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  logic rst_n;
  lin_if vif(clk, rst_n);

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  // Functional LIN slave: receives VIP frames, checks parity/checksum, echoes
  lin_slave_model dut (
    .clk           (vif.clk),
    .rst_n         (vif.rst_n),
    .lin_rx        (vif.lin_rx),
    .lin_en        (vif.lin_en),
    .lin_tx        (vif.lin_tx),
    .sleep_mode    (vif.sleep_mode),
    .wakeup_signal (vif.wakeup_signal),
    .bit_error     (vif.bit_error),
    .checksum_error(vif.checksum_error),
    .parity_error  (vif.parity_error),
    .timeout_error (vif.timeout_error),
    .framing_error (vif.framing_error),
    .pid           (vif.pid),
    .parity        (vif.parity),
    .sync_field    (vif.sync_field),
    .break_field   (vif.break_field),
    .data_len      (vif.data_len),
    .checksum      (vif.checksum)
  );

  // SVA tiered compliance checker (L1-L4)
  lin_compliance_sva sva_chk (vif);

  // L1/L2/L3 SVA rule modules (companions of the class checkers)
  lin_protocol_compliance_sva protocol_sva (vif);
  lin_data_integrity_sva      di_sva       (vif);
  lin_timing_performance_sva  timing_sva   (vif);
  lin_error_handling_sva      error_sva    (vif);

  initial begin
    uvm_config_db#(virtual lin_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule
`endif
