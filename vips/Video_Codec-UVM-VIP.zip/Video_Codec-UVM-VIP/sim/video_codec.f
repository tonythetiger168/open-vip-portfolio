// Video_Codec-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+video_codec
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/Video_Codec_top.sv
rtl/Video_Codec_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
video_codec/video_codec_pins_if.sv
common/ssv_pkg.sv
video_codec/video_codec_pkg.sv
tb/top_tb.sv
