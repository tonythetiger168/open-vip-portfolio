# Video_Codec-UVM-VIP test plan

## Register test (`video_codec_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `video_codec_roundtrip_test`: 16 frames: ENCODE, then DECODE the residual
  into a third buffer: every word of both jobs against the model, the
  decoded frame = the original, ZEROS and CHECKSUM of both jobs, CHECKSUM
  equal in both directions. Frames: random, flat (all ZEROS), ramps, and
  smooth images; LINE_WORDS 0, 1, 7, 480 (1920 px) and 1920 (7680 px, 8K)
  with lengths that end mid-line; four back-pressure settings.
- `video_codec_err_test`: ENCODE from a SLVERR region (those words read as
  0), DECODE into a DECERR region (untouched): DONE + ERR, STATUS.err; a
  clean job clears it.
