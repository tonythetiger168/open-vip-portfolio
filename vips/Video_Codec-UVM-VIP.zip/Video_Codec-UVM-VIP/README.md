# Video_Codec UVM VIP (Video_Codec-UVM-VIP)

UVM verification IP for the open-ip-portfolio **Video_Codec** subsystem: Video codec: lossless DPCM intra encoder / decoder of 8-bit frames over AXI4.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`b1cfc02463bd`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 5) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What Video_Codec does (from the spec)

- Four 8-bit samples per word, byte 0 first; LEN words from SRC to DST.
- Predictor: the previous sample of the job (mod 256); 128 for the first sample of the job and, when LINE_WORDS != 0, of every line of LINE_WORDS words.
- MODE 0 ENCODE: out = (x - pred) mod 256. MODE 1 DECODE: out = (in + pred) mod 256, pred = the decoded sample. DECODE(ENCODE(frame)) = frame.
- ZEROS counts zero residuals (ENCODE: output bytes, DECODE: input bytes), saturating.
- CHECKSUM is the 32-bit sum of the frame words (ENCODE: input, DECODE: output), so both directions of one frame give the same value.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `video_codec/` -- `video_codec_ral.svh` register model (generated from the spec, same
  offsets as `Video_Codec_apb`), `video_codec_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `video_codec_pins_if.sv`
- `rtl/` -- `Video_Codec_apb.sv`, `Video_Codec_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/video_codec.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | SRC_ADDR | rw |
| 0x018 | DST_ADDR | rw |
| 0x01C | LEN | rw |
| 0x020 | CTRL | rw |
| 0x024 | LINE | rw |
| 0x028 | CMD | cmd |
| 0x02C | STATUS | ro |
| 0x030 | ZEROS | ro |
| 0x034 | CHECKSUM | ro |
| 0x038 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR.

## Tests

| Test | Seeds |
|---|---|
| `video_codec_ral_test` | 1 |
| `video_codec_roundtrip_test` | 3 |
| `video_codec_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT Video_Codec mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/video_codec.f
./obj_dir/Vtop_tb +UVM_TESTNAME=video_codec_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py Video_Codec-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
