// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (TDM audio DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened tdm_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic fsync = 0, sd = 0;
  wire rep_valid, rep_err;
  wire [127:0] rep_slots;

  always #5 clk = ~clk;

  tdm_model u_dut (.clk(clk), .rst_n(rst_n), .fsync(fsync), .sd(sd), .rep_valid(rep_valid),
                   .rep_slots(rep_slots), .rep_err(rep_err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  int nrep = 0;
  logic [127:0] r_slots; logic r_err;
  logic [127:0] p_slots; logic p_err;   // the report before the last
  always @(posedge clk) if (rep_valid) begin
    nrep++; p_slots = r_slots; p_err = r_err; r_slots = rep_slots; r_err = rep_err;
  end

  logic [127:0] f;
  // one frame: FSYNC at bit 0 (and bit 1 when wide), stop after n bits
  task automatic frame(input logic [127:0] v, input int n = 128, input bit wide = 0);
    for (int i = 0; i < n; i++) begin
      fsync = (i == 0) || (i == 1 && wide); sd = v[127 - i];
      @(posedge clk); #1;
    end
    fsync = 0; sd = 0;
  endtask
  task automatic idle(input int n); fsync = 0; sd = 0; repeat (n) @(posedge clk); #1; endtask

  initial begin
    int b;
    repeat (3) @(posedge clk);
    chk(nrep == 0, "no report during reset");
    rst_n = 1;
    idle(128 + 20);
    chk(nrep == 0, "no frame open after reset");
    // channels 0..7 in slots 0..7
    for (int i = 0; i < 8; i++) f[127 - 16*i -: 16] = 16'(i);
    b = nrep; frame(f); idle(2);
    chk(nrep == b + 1 && r_slots == f && r_err === 1'b0, "TDM8 frame: slot i = i, no error");
    // two frames back to back, no idle clock
    b = nrep;
    frame({8{16'h8000}});
    chk(nrep == b, "report only after the frame's last bit");
    frame({8{16'h7FFF}}); idle(2);
    chk(nrep == b + 2 && r_slots == {8{16'h7FFF}} && r_err === 1'b0, "back-to-back frames: both reported");
    // MSB first, bit order inside a slot
    f = '0; f[127] = 1'b1;
    b = nrep; frame(f); idle(2);
    chk(r_slots[127 -: 16] == 16'h8000 && r_slots[126 - 15 -: 16] == 16'h0, "first bit after FSYNC is the MSB of slot 0");
    f = '0; f[0] = 1'b1;
    b = nrep; frame(f); idle(2);
    chk(r_slots[15:0] == 16'h0001 && r_err === 1'b0, "last bit is the LSB of slot 7");
    // wide FSYNC
    b = nrep; frame({8{16'h1234}}, 128, 1); idle(2);
    chk(nrep == b + 1 && r_err === 1'b1 && r_slots == {8{16'h1234}}, "FSYNC two clocks wide: framing error, data kept");
    // early FSYNC: the open frame reported broken, the new one fine
    b = nrep; frame({8{16'hAAAA}}, 40); frame({8{16'h5555}}); idle(2);
    chk(nrep == b + 2, "early FSYNC: two reports");
    chk(p_err === 1'b1 && p_slots == ({8{16'hAAAA}} & ~({128{1'b1}} >> 40)),
        "the cut frame: framing error, its 40 bits MSB-aligned");
    chk(r_err === 1'b0 && r_slots == {8{16'h5555}}, "the restarted frame is clean");
    // an idle gap of any length between frames
    b = nrep; frame({8{16'h0F0F}}); idle(1); frame({8{16'hF0F0}}); idle(37); frame({8{16'h00FF}}); idle(2);
    chk(nrep == b + 3 && r_slots == {8{16'h00FF}}, "frames after idle gaps");
    // nothing without FSYNC
    b = nrep; sd = 1; idle(300);
    chk(nrep == b, "no frame without FSYNC");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #400000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
