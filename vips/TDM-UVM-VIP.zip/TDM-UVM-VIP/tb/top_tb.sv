// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- TDM audio testbench top with a functional TDM audio DUT model

`ifndef TDM_UVM_VIP_TB_SV
`define TDM_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import tdm_defs_pkg::*;
import tdm_pkg::*;
import tdm_env_pkg::*;
import tdm_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  tdm_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  tdm_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .fsync(vif.fsync),
    .sd(vif.sd),
    .rep_valid(vif.rep_valid),
    .rep_slots(vif.rep_slots),
    .rep_err(vif.rep_err)
  );

  // Concurrent protocol checks
  tdm_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .fsync(vif.fsync),
    .sd(vif.sd),
    .rep_valid(vif.rep_valid),
    .rep_slots(vif.rep_slots),
    .rep_err(vif.rep_err)
  );

  initial begin
    uvm_config_db#(virtual tdm_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module tdm_model (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          fsync,
  input  logic          sd,
  output logic          rep_valid,
  output logic [127:0] rep_slots,
  output logic          rep_err
);
  logic [127:0] sh;
  logic [7:0]   nbit;
  logic         active, err;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sh <= '0; nbit <= '0; active <= 1'b0; err <= 1'b0;
      rep_valid <= 1'b0; rep_slots <= '0; rep_err <= 1'b0;
    end else begin
      rep_valid <= 1'b0;
      if (fsync && !(active && nbit == 8'd1)) begin
        // a new frame; one still open is reported as broken
        if (active) begin
          rep_valid <= 1'b1; rep_slots <= sh << (128 - nbit); rep_err <= 1'b1;
        end
        active <= 1'b1; nbit <= 8'd1; err <= 1'b0; sh <= {{127{1'b0}}, sd};
      end else if (active) begin
        if (fsync) err <= 1'b1;                     // FSYNC on the second bit: too wide
        sh <= {sh[126:0], sd};
        nbit <= nbit + 8'd1;
        if (nbit == 8'd127) begin
          active <= 1'b0;
          rep_valid <= 1'b1; rep_slots <= {sh[126:0], sd}; rep_err <= err | fsync;
        end
      end
    end
  end
endmodule
`endif
