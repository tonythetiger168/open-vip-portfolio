// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tdm_driver.svh -- TDM audio driver: FSYNC on the first bit of each frame, the 8 slots MSB first, optional idle clocks before a frame

class tdm_driver extends uvm_driver #(tdm_transaction);
  `uvm_component_utils(tdm_driver)

  uvm_analysis_port #(tdm_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual tdm_if vif;
  tdm_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual tdm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tdm: virtual interface not set")
    if (!uvm_config_db#(tdm_config)::get(this, "", "cfg", cfg))
      cfg = tdm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    tdm_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.fsync <= 1'b0; vif.drv_cb.sd <= 1'b0;
  endtask

  task drive_item(tdm_transaction t);
    repeat (t.gap) begin vif.drv_cb.fsync <= 1'b0; vif.drv_cb.sd <= 1'b0; @(vif.drv_cb); end
    for (int s = 0; s < 8; s++)
      for (int b = 15; b >= 0; b--) begin
        int n = s * 16 + (15 - b);
        vif.drv_cb.fsync <= (n == 0) || (n == 1 && t.bad_sync);
        vif.drv_cb.sd <= t.slot[s][b];
        @(vif.drv_cb);
      end
    vif.drv_cb.fsync <= 1'b0; vif.drv_cb.sd <= 1'b0;
  endtask

endclass
