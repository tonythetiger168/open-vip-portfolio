// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tdm_if.sv -- TDM audio interface

interface tdm_if (input logic clk);
  logic rst_n;

  logic fsync;
  logic sd;
  logic rep_valid;
  logic [127:0] rep_slots;
  logic rep_err;

  modport DUT (input clk, rst_n, input fsync, input sd, output rep_valid, output rep_slots, output rep_err);
  modport MON (input clk, rst_n, fsync, sd, rep_valid, rep_slots, rep_err);

  clocking drv_cb @(posedge clk);
    input rst_n, rep_valid, rep_slots, rep_err;
    inout fsync, sd;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, fsync, sd, rep_valid, rep_slots, rep_err;
  endclocking
endinterface
