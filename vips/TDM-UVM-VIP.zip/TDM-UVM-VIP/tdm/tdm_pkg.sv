// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tdm_pkg.sv -- TDM audio UVM VIP package

package tdm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import tdm_defs_pkg::*;
  export tdm_defs_pkg::*;

  `include "tdm_transaction.svh"
  `include "tdm_config.svh"
  `include "tdm_sequencer.svh"
  `include "tdm_driver.svh"
  `include "tdm_monitor.svh"
  `include "tdm_agent.svh"
  `include "tdm_sequences.svh"
  `include "tdm_checker.svh"
  `include "tdm_coverage.svh"
endpackage
