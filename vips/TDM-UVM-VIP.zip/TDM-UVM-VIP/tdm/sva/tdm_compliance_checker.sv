// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tdm_compliance_checker.sv -- TDM audio concurrent assertion checks (bindable)

module tdm_compliance_checker
  (input logic clk, input logic rst_n, input logic fsync, input logic sd, input logic rep_valid, input logic [127:0] rep_slots, input logic rep_err);

  logic [7:0] n;
  logic act;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin n <= '0; act <= 1'b0; end
    else if (fsync && !(act && n == 8'd1)) begin act <= 1'b1; n <= 8'd1; end
    else if (act) begin n <= n + 8'd1; if (n == 8'd127) act <= 1'b0; end
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({fsync, sd, rep_valid}))
    else $error("TDM: X on FSYNC / SD / report");
  // the receiver reports a framing fault for an FSYNC in the wrong place
  // (the tests plant some on purpose, so these are not assertions)
  cover property (@(posedge clk) disable iff (!rst_n) fsync ##1 fsync);
  cover property (@(posedge clk) disable iff (!rst_n) act && n > 8'd1 && fsync);
  // a wide FSYNC is reported as an error with the frame
  assert property (@(posedge clk) disable iff (!rst_n) act && n == 8'd1 && fsync |-> ##[1:128] rep_valid && rep_err)
    else $error("TDM: wide FSYNC not reported");
  // a frame is reported one clock after its last bit
  assert property (@(posedge clk) disable iff (!rst_n) act && n == 8'd127 && !fsync |=> rep_valid)
    else $error("TDM: complete frame not reported");
  cover property (@(posedge clk) disable iff (!rst_n) act && n == 8'd127 ##1 fsync);
  cover property (@(posedge clk) disable iff (!rst_n) act && n == 8'd127 ##1 !fsync);
endmodule
