// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tdm_coverage.svh -- TDM audio functional coverage

class tdm_coverage extends uvm_subscriber #(tdm_transaction);
  `uvm_component_utils(tdm_coverage)
  tdm_config cfg;
  tdm_transaction tr;

  covergroup tdm_cg;
    cp_gap  : coverpoint tr.gap { bins b2b = {0}; bins gap = {[1:7]}; }
    cp_s0   : coverpoint tr.slot[0] { bins neg_fs = {16'h8000}; bins pos_fs = {16'h7FFF}; bins zero = {0}; bins other = default; }
    cp_s7   : coverpoint tr.slot[7] { bins neg = {[16'h8000:16'hFFFF]}; bins pos = {[16'h0001:16'h7FFF]}; bins zero = {0}; }
    cp_err  : coverpoint tr.err;
    x_gap_err : cross cp_gap, cp_err;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    tdm_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(tdm_config)::get(this, "", "cfg", cfg))
      cfg = tdm_config::type_id::create("cfg");
  endfunction

  function void write(tdm_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    tdm_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("TDM audio coverage: %0.1f%%", tdm_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
