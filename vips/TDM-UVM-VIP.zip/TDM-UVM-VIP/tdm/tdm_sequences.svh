// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tdm_sequences.svh -- TDM audio sequences

// Random traffic: cfg.num_items constrained-random items.
class tdm_base_sequence extends uvm_sequence #(tdm_transaction);
  `uvm_object_utils(tdm_base_sequence)
  tdm_config cfg;

  function new(string name = "tdm_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = tdm_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "tdm_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class tdm_directed_sequence extends uvm_sequence #(tdm_transaction);
  `uvm_object_utils(tdm_directed_sequence)
  tdm_config cfg;

  function new(string name = "tdm_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function tdm_transaction item();
    item = tdm_transaction::type_id::create("req");
  endfunction

  task send(tdm_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    tdm_transaction t;
    // channel numbers, full scale both ways, alternating bits, one channel only,
    // frames back to back and after a gap, then framing faults
    t = item(); t.gap = 0; for (int i = 0; i < 8; i++) t.slot.push_back(16'(i)); send(t);
    t = item(); t.gap = 0; repeat (8) t.slot.push_back(16'h8000); send(t);
    t = item(); t.gap = 0; repeat (8) t.slot.push_back(16'h7FFF); send(t);
    t = item(); t.gap = 3; repeat (8) t.slot.push_back(16'hAAAA); send(t);
    t = item(); t.gap = 0; repeat (8) t.slot.push_back(16'h5555); send(t);
    t = item(); t.gap = 1; for (int i = 0; i < 8; i++) t.slot.push_back(i == 5 ? 16'hFFFF : 16'h0000); send(t);
    t = item(); t.gap = 0; t.bad_sync = 1; for (int i = 0; i < 8; i++) t.slot.push_back(16'h1111 * i); send(t);
    t = item(); t.gap = 0; for (int i = 0; i < 8; i++) t.slot.push_back(16'h0101 << i); send(t);
    t = item(); t.gap = 7; t.bad_sync = 1; repeat (8) t.slot.push_back(16'h0001); send(t);
  endtask
endclass
