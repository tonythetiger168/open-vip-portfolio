// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tdm_transaction.svh -- TDM audio transaction

class tdm_transaction extends uvm_sequence_item;
  `uvm_object_utils(tdm_transaction)

  // request (driven by the agent)
  bit [15:0] slot[$];
  rand bit bad_sync;
  // response (returned by the DUT)
  bit [15:0] rslot[$];
  bit err;
  // bookkeeping (not compared)
  rand bit [2:0] gap;
  rand bit [31:0] seed;
  rand bit [3:0] kind;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_gap { gap dist { 0 := 6, [1:7] :/ 2 }; kind dist { 0 := 12, [1:15] :/ 4 }; }

  function new(string name = "tdm_transaction"); super.new(name); endfunction

  function void post_randomize();
    bit [31:0] x = seed | 32'h1;
    slot.delete();
    for (int i = 0; i < 8; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      case (kind)
        1: slot.push_back(16'h8000);               // full-scale negative
        2: slot.push_back(16'h7FFF);               // full-scale positive
        3: slot.push_back(16'(i));                 // channel number
        default: slot.push_back(x[15:0]);
      endcase
    end
    bad_sync = (kind == 15);
  endfunction

  function void do_copy(uvm_object rhs);
    tdm_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    slot = rhs_.slot;
    bad_sync = rhs_.bad_sync;
    rslot = rhs_.rslot;
    err = rhs_.err;
    gap = rhs_.gap;
    seed = rhs_.seed;
    kind = rhs_.kind;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    tdm_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (slot.size() != rhs_.slot.size()) return 0;
    foreach (slot[i]) if (slot[i] != rhs_.slot[i]) return 0;
    if (bad_sync != rhs_.bad_sync) return 0;
    if (rslot.size() != rhs_.rslot.size()) return 0;
    foreach (rslot[i]) if (rslot[i] != rhs_.rslot[i]) return 0;
    if (err != rhs_.err) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(tdm_transaction rhs_);
    if (slot.size() != rhs_.slot.size()) return 0;
    foreach (slot[i]) if (slot[i] != rhs_.slot[i]) return 0;
    if (bad_sync != rhs_.bad_sync) return 0;
    return 1;
  endfunction

  function string qstr_slot();
    string s = $sformatf("[%0d]{", slot.size());
    foreach (slot[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", slot[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rslot();
    string s = $sformatf("[%0d]{", rslot.size());
    foreach (rslot[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rslot[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("TDM audio{tag=%0d slot=%s bad_sync=0x%0h rslot=%s err=0x%0h}", tag, qstr_slot(), bad_sync, qstr_rslot(), err);
  endfunction
endclass
