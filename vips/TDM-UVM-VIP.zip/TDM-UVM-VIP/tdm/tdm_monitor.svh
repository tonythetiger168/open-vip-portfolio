// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tdm_monitor.svh -- TDM audio monitor: frames rebuilt from FSYNC and SD, completed by the receiver's report

class tdm_monitor extends uvm_monitor;
  `uvm_component_utils(tdm_monitor)

  virtual tdm_if vif;
  uvm_analysis_port #(tdm_transaction) ap;
  tdm_config cfg;
  int unsigned n_obs = 0;

  tdm_transaction cur; int unsigned nbit; tdm_transaction done_q[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual tdm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tdm: virtual interface not set")
    if (!uvm_config_db#(tdm_config)::get(this, "", "cfg", cfg))
      cfg = tdm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rep_valid) begin
          if (done_q.size() == 0) `uvm_error("MON", "TDM: frame report without a frame")
          else begin
            tdm_transaction t = done_q.pop_front();
            for (int s = 0; s < 8; s++) t.rslot.push_back(vif.mon_cb.rep_slots[128 - 1 - s*16 -: 16]);
            t.err = vif.mon_cb.rep_err;
            publish(t);
          end
        end
        if (vif.mon_cb.fsync && !(cur != null && nbit == 1)) begin
          if (cur != null) `uvm_error("MON", $sformatf("TDM: FSYNC after %0d bits of a frame", nbit))
          cur = tdm_transaction::type_id::create("t");
          nbit = 0;
        end else if (vif.mon_cb.fsync && cur != null && nbit == 1) cur.bad_sync = 1;
        if (cur != null) begin
          if (nbit % 16 == 0) cur.slot.push_back(0);
          cur.slot[nbit / 16][15 - nbit % 16] = vif.mon_cb.sd;
          nbit++;
          if (nbit == 128) begin done_q.push_back(cur); cur = null; end
        end
      end
    end
  endtask

  function void publish(tdm_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
