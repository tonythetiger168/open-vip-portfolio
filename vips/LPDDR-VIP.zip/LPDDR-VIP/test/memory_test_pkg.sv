// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// Memory UVM Test Package (LPDDR)
//------------------------------------------------------------------------------
package memory_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import ddr_pkg::*;
  import lpddr_pkg::*;
  import hbm_pkg::*;
  import ufs_pkg::*;
  import unipro_pkg::*;
  import emmc_pkg::*;
  import onfi_pkg::*;
  import sd_pkg::*;
  import memory_env_pkg::*;

  class memory_base_test extends uvm_test;
    `uvm_component_utils(memory_base_test)
    memory_env env;
    memory_env_cfg env_cfg;
    int random_seed;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env_cfg = memory_env_cfg::type_id::create("env_cfg");
      env_cfg.coverage_enable = 1;
      env_cfg.scoreboard_enable = 1;
      env = memory_env::type_id::create("env", this);
      uvm_config_db#(memory_env_cfg)::set(this, "env", "cfg", env_cfg);
      if (!$value$plusargs("ntb_random_seed=%d", random_seed))
        random_seed = $urandom;
      process::self().srandom(random_seed);   // $srandom is not a system task
    endfunction
    task run_phase(uvm_phase phase);
      lpddr_rw_seq seq;
      phase.raise_objection(this);
      seq = lpddr_rw_seq::type_id::create("seq");
      seq.num_trans = env_cfg.num_lpddr;
      seq.start(env.lpddr_ag.sqr);
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server server = uvm_report_server::get_server();
      int err_count = server.get_severity_count(UVM_ERROR);
      `uvm_info(get_type_name(),
        $sformatf("Seed: %0d | Errors: %0d", random_seed, err_count), UVM_LOW)
      if (err_count == 0)
        `uvm_info(get_type_name(), "TEST PASSED", UVM_LOW)
      else
        `uvm_error(get_type_name(), $sformatf("TEST FAILED with %0d errors", err_count))
    endfunction
  endclass

  // Directed regression: every LPDDR directed sequence
  class memory_directed_test extends memory_base_test;
    `uvm_component_utils(memory_directed_test)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    task run_phase(uvm_phase phase);
      lpddr_regression_seq seq;
      phase.raise_objection(this);
      seq = lpddr_regression_seq::type_id::create("seq");
      seq.start(env.lpddr_ag.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class memory_coverage_regression_test extends memory_base_test;
    `uvm_component_utils(memory_coverage_regression_test)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    // this test promises 100% LPDDR coverage: a shortfall is a warning
    function void build_phase(uvm_phase phase);
      uvm_config_db#(bit)::set(null, "", "enforce_cov_target", 1'b1);
      super.build_phase(phase);
    endfunction
    task run_phase(uvm_phase phase);
      phase.raise_objection(this);
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), "  MEMORY PROTOCOL COVERAGE REGRESSION", UVM_NONE)
      `uvm_info(get_type_name(), "  Target: 100% Coverage", UVM_NONE)
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), "LPDDR Coverage Sequences", UVM_LOW)
      begin lpddr_cov_cmd_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_cov_bank_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_write_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_read_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_refresh_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_bank_conflict_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_back_to_back_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_page_hit_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_page_miss_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_lpddr;
            seq.start(env.lpddr_ag.sqr); end
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), "  All Coverage Sequences Complete", UVM_NONE)
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      phase.drop_objection(this);
    endtask
  endclass
endpackage : memory_test_pkg
