// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// Memory UVM Test Package (LPDDR)
//------------------------------------------------------------------------------
package memory_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import ddr_pkg::*;
  import lpddr_pkg::*;
  import hbm_pkg::*;
  import ufs_pkg::*;
  import unipro_pkg::*;
  import emmc_pkg::*;
  import onfi_pkg::*;
  import sd_pkg::*;
  import memory_env_pkg::*;

  class memory_base_test extends uvm_test;
    `uvm_component_utils(memory_base_test)
    memory_env env;
    memory_env_cfg env_cfg;
    int random_seed;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env_cfg = memory_env_cfg::type_id::create("env_cfg");
      env_cfg.coverage_enable = 1;
      env_cfg.scoreboard_enable = 1;
      env = memory_env::type_id::create("env", this);
      uvm_config_db#(memory_env_cfg)::set(this, "env", "cfg", env_cfg);
      if (!$value$plusargs("ntb_random_seed=%d", random_seed))
        random_seed = $urandom;
      process::self().srandom(random_seed);   // $srandom is not a system task
    endfunction
    task run_phase(uvm_phase phase);
      lpddr_rw_seq seq;
      phase.raise_objection(this);
      seq = lpddr_rw_seq::type_id::create("seq");
      seq.num_trans = env_cfg.num_lpddr;
      seq.start(env.lpddr_ag.sqr);
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server server = uvm_report_server::get_server();
      int err_count = server.get_severity_count(UVM_ERROR);
      `uvm_info(get_type_name(),
        $sformatf("Seed: %0d | Errors: %0d", random_seed, err_count), UVM_LOW)
      if (err_count == 0)
        `uvm_info(get_type_name(), "TEST PASSED", UVM_LOW)
      else
        `uvm_error(get_type_name(), $sformatf("TEST FAILED with %0d errors", err_count))
    endfunction
  endclass

  // Directed regression: every LPDDR directed sequence
  class memory_directed_test extends memory_base_test;
    `uvm_component_utils(memory_directed_test)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    task run_phase(uvm_phase phase);
      lpddr_regression_seq seq;
      phase.raise_objection(this);
      seq = lpddr_regression_seq::type_id::create("seq");
      seq.start(env.lpddr_ag.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  // Negative test: tb_top corrupts the stored word at each read burst's
  // start column; the scoreboard must report a bad beat in every read
  // burst of the data sequence. The catcher demotes those errors.
  class lpddr_data_err_catcher extends uvm_report_catcher;
    int unsigned n_caught;
    function new(string name = "lpddr_data_err_catcher"); super.new(name); endfunction
    function action_e catch();
      if (get_severity() == UVM_ERROR && get_id() == "SB_DATA" &&
          uvm_is_match("*LPDDR read data mismatch*", get_message())) begin
        n_caught++;
        set_severity(UVM_INFO);
      end
      return THROW;
    endfunction
  endclass

  class memory_lpddr_data_err_test extends memory_base_test;
    `uvm_component_utils(memory_lpddr_data_err_test)
    lpddr_data_err_catcher catcher;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      uvm_config_db#(bit)::set(null, "", "lpddr_corrupt_reads", 1'b1);
    endfunction
    function void end_of_elaboration_phase(uvm_phase phase);
      super.end_of_elaboration_phase(phase);
      catcher = new();
      uvm_report_cb::add(null, catcher);
    endfunction
    task run_phase(uvm_phase phase);
      lpddr_data_seq seq;
      phase.raise_objection(this);
      seq = lpddr_data_seq::type_id::create("seq");
      seq.start(env.lpddr_ag.sqr);
      phase.drop_objection(this);
    endtask
    function void check_phase(uvm_phase phase);
      super.check_phase(phase);
      if (catcher.n_caught < lpddr_data_seq::exp_reads)
        `uvm_error("ERR_TEST", $sformatf("corrupted reads: scoreboard flagged %0d bad beats, expected at least one in each of %0d read bursts",
                   catcher.n_caught, lpddr_data_seq::exp_reads))
      else
        $display("SB_PASS checks=%0d", catcher.n_caught);
    endfunction
  endclass

  class memory_coverage_regression_test extends memory_base_test;
    `uvm_component_utils(memory_coverage_regression_test)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    // this test promises 100% LPDDR coverage: a shortfall is a warning
    function void build_phase(uvm_phase phase);
      uvm_config_db#(bit)::set(null, "", "enforce_cov_target", 1'b1);
      super.build_phase(phase);
    endfunction
    task run_phase(uvm_phase phase);
      phase.raise_objection(this);
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), "  MEMORY PROTOCOL COVERAGE REGRESSION", UVM_NONE)
      `uvm_info(get_type_name(), "  Target: 100% Coverage", UVM_NONE)
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), "LPDDR Coverage Sequences", UVM_LOW)
      begin lpddr_cov_cmd_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_cov_bank_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_write_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_read_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_refresh_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_bank_conflict_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_back_to_back_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_page_hit_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_page_miss_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_data_seq seq = new("seq"); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_lpddr;
            seq.start(env.lpddr_ag.sqr); end
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), "  All Coverage Sequences Complete", UVM_NONE)
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      phase.drop_objection(this);
    endtask
  endclass
endpackage : memory_test_pkg
