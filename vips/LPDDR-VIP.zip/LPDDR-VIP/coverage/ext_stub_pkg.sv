// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// External protocol stub packages.
// Minimal self-contained stubs for cross-protocol types referenced by the
// shared memory coverage/env/test infrastructure (config object, sequence
// item, agent). Only the members actually used by this testbench are modeled.
//------------------------------------------------------------------------------
package ddr_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class ddr_seq_item extends uvm_sequence_item;
    `uvm_object_utils(ddr_seq_item)
  rand bit [3:0]  cmd_type;
  rand bit [2:0]  bank;
  rand bit [1:0]  bank_group;
  rand bit [7:0]  burst_len;

    function new(string name = "ddr_seq_item");
      super.new(name);
    endfunction
  endclass

  class ddr_cfg extends uvm_object;
    `uvm_object_utils(ddr_cfg)
    function new(string name = "ddr_cfg");
      super.new(name);
    endfunction
  endclass

  class ddr_agent extends uvm_agent;
    `uvm_component_utils(ddr_agent)
    function new(string name = "ddr_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
endpackage : ddr_pkg

package hbm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class hbm_seq_item extends uvm_sequence_item;
    `uvm_object_utils(hbm_seq_item)
  rand bit [3:0]  cmd_type;
  rand bit [2:0]  cid;
  rand bit [1:0]  bank;

    function new(string name = "hbm_seq_item");
      super.new(name);
    endfunction
  endclass

  class hbm_cfg extends uvm_object;
    `uvm_object_utils(hbm_cfg)
    function new(string name = "hbm_cfg");
      super.new(name);
    endfunction
  endclass

  class hbm_agent extends uvm_agent;
    `uvm_component_utils(hbm_agent)
    function new(string name = "hbm_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
endpackage : hbm_pkg

package ufs_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class ufs_seq_item extends uvm_sequence_item;
    `uvm_object_utils(ufs_seq_item)
  rand bit [7:0]  upiu_type;
  rand bit [2:0]  lun;

    function new(string name = "ufs_seq_item");
      super.new(name);
    endfunction
  endclass

  class ufs_cfg extends uvm_object;
    `uvm_object_utils(ufs_cfg)
    function new(string name = "ufs_cfg");
      super.new(name);
    endfunction
  endclass

  class ufs_agent extends uvm_agent;
    `uvm_component_utils(ufs_agent)
    function new(string name = "ufs_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
endpackage : ufs_pkg

package unipro_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class unipro_seq_item extends uvm_sequence_item;
    `uvm_object_utils(unipro_seq_item)
  rand bit [7:0]  msg_type;
  rand bit [4:0]  cportid;

    function new(string name = "unipro_seq_item");
      super.new(name);
    endfunction
  endclass

  class unipro_cfg extends uvm_object;
    `uvm_object_utils(unipro_cfg)
    function new(string name = "unipro_cfg");
      super.new(name);
    endfunction
  endclass

  class unipro_agent extends uvm_agent;
    `uvm_component_utils(unipro_agent)
    function new(string name = "unipro_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
endpackage : unipro_pkg

package emmc_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class emmc_seq_item extends uvm_sequence_item;
    `uvm_object_utils(emmc_seq_item)
  rand bit [5:0]  cmd_type;
  rand bit [1:0]  bus_width;

    function new(string name = "emmc_seq_item");
      super.new(name);
    endfunction
  endclass

  class emmc_cfg extends uvm_object;
    `uvm_object_utils(emmc_cfg)
    function new(string name = "emmc_cfg");
      super.new(name);
    endfunction
  endclass

  class emmc_agent extends uvm_agent;
    `uvm_component_utils(emmc_agent)
    function new(string name = "emmc_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
endpackage : emmc_pkg

package onfi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class onfi_seq_item extends uvm_sequence_item;
    `uvm_object_utils(onfi_seq_item)
  rand bit [7:0]  cmd_type;

    function new(string name = "onfi_seq_item");
      super.new(name);
    endfunction
  endclass

  class onfi_cfg extends uvm_object;
    `uvm_object_utils(onfi_cfg)
    function new(string name = "onfi_cfg");
      super.new(name);
    endfunction
  endclass

  class onfi_agent extends uvm_agent;
    `uvm_component_utils(onfi_agent)
    function new(string name = "onfi_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
endpackage : onfi_pkg

package sd_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class sd_seq_item extends uvm_sequence_item;
    `uvm_object_utils(sd_seq_item)
  rand bit [5:0]  cmd_type;
  rand bit [1:0]  bus_width;

    function new(string name = "sd_seq_item");
      super.new(name);
    endfunction
  endclass

  class sd_cfg extends uvm_object;
    `uvm_object_utils(sd_cfg)
    function new(string name = "sd_cfg");
      super.new(name);
    endfunction
  endclass

  class sd_agent extends uvm_agent;
    `uvm_component_utils(sd_agent)
    function new(string name = "sd_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
endpackage : sd_pkg

