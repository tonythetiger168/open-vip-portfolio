// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// Memory Protocol Functional Coverage Package (LPDDR deepened: 3 covergroups)
//------------------------------------------------------------------------------
package memory_coverage_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import ddr_pkg::*;
  import lpddr_pkg::*;
  import hbm_pkg::*;
  import ufs_pkg::*;
  import unipro_pkg::*;
  import emmc_pkg::*;
  import onfi_pkg::*;
  import sd_pkg::*;

  class ddr_coverage extends uvm_component;
    `uvm_component_utils(ddr_coverage)
    uvm_analysis_imp #(ddr_seq_item, ddr_coverage) analysis_export;
    ddr_seq_item item;
    real coverage_target = 100.0;
    covergroup ddr_cg;
      option.per_instance = 1;
      option.goal = 100;
      cmd: coverpoint item.cmd_type;
      bank: coverpoint item.bank { bins b[8] = {[0:7]}; }
      bank_group: coverpoint item.bank_group { bins bg[4] = {[0:3]}; }
      burst_len: coverpoint item.burst_len { bins bl[2] = {8, 16}; }
      cmd_x_bank: cross cmd, bank;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      ddr_cg = new();
    endfunction
    virtual function void write(ddr_seq_item t);
      item = t;
      ddr_cg.sample();
    endfunction
    function real get_coverage();
      return ddr_cg.get_coverage();
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("DDR Coverage: %0.2f%%", cov), UVM_LOW)
    endfunction
  endclass

  //==========================================================================
  // LPDDR functional coverage (deepened): command distribution, bank state
  // transitions, address/page patterns -- with crosses.
  //==========================================================================
  class lpddr_coverage extends uvm_subscriber #(lpddr_seq_item);
    `uvm_component_utils(lpddr_coverage)
    lpddr_seq_item item;
    real coverage_target = 100.0;

    covergroup lpddr_cmd_cg;
      option.per_instance = 1;
      option.goal = 100;
      cmd: coverpoint item.cmd_type;
      bank: coverpoint item.bank;
      ca: coverpoint item.ca { bins op[4] = {[0:63]}; }
      cmd_x_ca: cross cmd, ca;
      burst: coverpoint item.burst_len { bins b8 = {8}; }  // BL8 only per c_burst_len constraint
      cmd_x_bank: cross cmd, bank;
    endgroup

    covergroup lpddr_bank_state_cg with function sample(bank_state_e s);
      option.per_instance = 1;
      option.goal = 100;
      state: coverpoint s { bins idle = {B_IDLE}; bins active = {B_ACTIVE}; }
      trans: coverpoint s {
        bins row_open  = (B_IDLE   => B_ACTIVE);
        bins access    = (B_ACTIVE => B_ACTIVE);
        bins row_close = (B_ACTIVE => B_IDLE);
      }
      cmd: coverpoint item.cmd_type;
      state_x_cmd: cross state, cmd;
    endgroup

    covergroup lpddr_addr_cg;
      option.per_instance = 1;
      option.goal = 100;
      row: coverpoint item.addr[15:0] iff (item.cmd_type == lpddr_seq_item::ACT) {
        bins low  = {[16'h0000:16'h00FF]};
        bins mid  = {[16'h0100:16'h7FFF]};
        bins high = {[16'h8000:16'hFFFF]};
      }
      page: coverpoint item.page_hit iff (item.cmd_type inside {lpddr_seq_item::READ,
                                                                  lpddr_seq_item::WRITE}) {
        bins hit  = {1};
        bins miss = {0};
      }
      cmd: coverpoint item.cmd_type {
        bins rd = {lpddr_seq_item::READ};
        bins wr = {lpddr_seq_item::WRITE};
      }
      cmd_x_page: cross cmd, page;
    endgroup

    function new(string name, uvm_component parent);
      super.new(name, parent);
      lpddr_cmd_cg = new();
      lpddr_bank_state_cg = new();
      lpddr_addr_cg = new();
    endfunction
    virtual function void write(lpddr_seq_item t);
      item = t;
      lpddr_cmd_cg.sample();
      lpddr_bank_state_cg.sample(t.bstate);
      lpddr_addr_cg.sample();
    endfunction
    function real get_coverage();
      return (lpddr_cmd_cg.get_coverage() + lpddr_bank_state_cg.get_coverage() +
              lpddr_addr_cg.get_coverage()) / 3.0;
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("LPDDR Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target)
        `uvm_warning(get_type_name(), "LPDDR Coverage < 100%")
    endfunction
  endclass

  class hbm_coverage extends uvm_component;
    `uvm_component_utils(hbm_coverage)
    uvm_analysis_imp #(hbm_seq_item, hbm_coverage) analysis_export;
    hbm_seq_item item;
    real coverage_target = 100.0;
    covergroup hbm_cg;
      option.per_instance = 1;
      option.goal = 100;
      cmd: coverpoint item.cmd_type;
      cid: coverpoint item.cid { bins ch[8] = {[0:7]}; }
      bank: coverpoint item.bank { bins b[4] = {[0:3]}; }
      cmd_x_cid: cross cmd, cid;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      hbm_cg = new();
    endfunction
    virtual function void write(hbm_seq_item t);
      item = t;
      hbm_cg.sample();
    endfunction
    function real get_coverage();
      return hbm_cg.get_coverage();
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("HBM Coverage: %0.2f%%", cov), UVM_LOW)
    endfunction
  endclass

  class ufs_coverage extends uvm_component;
    `uvm_component_utils(ufs_coverage)
    uvm_analysis_imp #(ufs_seq_item, ufs_coverage) analysis_export;
    ufs_seq_item item;
    real coverage_target = 100.0;
    covergroup ufs_cg;
      option.per_instance = 1;
      option.goal = 100;
      upiu: coverpoint item.upiu_type;
      lun: coverpoint item.lun { bins l[8] = {[0:7]}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      ufs_cg = new();
    endfunction
    virtual function void write(ufs_seq_item t);
      item = t;
      ufs_cg.sample();
    endfunction
    function real get_coverage();
      return ufs_cg.get_coverage();
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("UFS Coverage: %0.2f%%", cov), UVM_LOW)
    endfunction
  endclass

  class unipro_coverage extends uvm_component;
    `uvm_component_utils(unipro_coverage)
    uvm_analysis_imp #(unipro_seq_item, unipro_coverage) analysis_export;
    unipro_seq_item item;
    real coverage_target = 100.0;
    covergroup unipro_cg;
      option.per_instance = 1;
      option.goal = 100;
      msg: coverpoint item.msg_type;
      cport: coverpoint item.cportid { bins cp[8] = {[0:31]}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      unipro_cg = new();
    endfunction
    virtual function void write(unipro_seq_item t);
      item = t;
      unipro_cg.sample();
    endfunction
    function real get_coverage();
      return unipro_cg.get_coverage();
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("UNIPRO Coverage: %0.2f%%", cov), UVM_LOW)
    endfunction
  endclass

  class emmc_coverage extends uvm_component;
    `uvm_component_utils(emmc_coverage)
    uvm_analysis_imp #(emmc_seq_item, emmc_coverage) analysis_export;
    emmc_seq_item item;
    real coverage_target = 100.0;
    covergroup emmc_cg;
      option.per_instance = 1;
      option.goal = 100;
      cmd: coverpoint item.cmd_type;
      bw: coverpoint item.bus_width { bins width[3] = {[0:2]}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      emmc_cg = new();
    endfunction
    virtual function void write(emmc_seq_item t);
      item = t;
      emmc_cg.sample();
    endfunction
    function real get_coverage();
      return emmc_cg.get_coverage();
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("EMMC Coverage: %0.2f%%", cov), UVM_LOW)
    endfunction
  endclass

  class onfi_coverage extends uvm_component;
    `uvm_component_utils(onfi_coverage)
    uvm_analysis_imp #(onfi_seq_item, onfi_coverage) analysis_export;
    onfi_seq_item item;
    real coverage_target = 100.0;
    covergroup onfi_cg;
      option.per_instance = 1;
      option.goal = 100;
      cmd: coverpoint item.cmd_type;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      onfi_cg = new();
    endfunction
    virtual function void write(onfi_seq_item t);
      item = t;
      onfi_cg.sample();
    endfunction
    function real get_coverage();
      return onfi_cg.get_coverage();
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("ONFI Coverage: %0.2f%%", cov), UVM_LOW)
    endfunction
  endclass

  class sd_coverage extends uvm_component;
    `uvm_component_utils(sd_coverage)
    uvm_analysis_imp #(sd_seq_item, sd_coverage) analysis_export;
    sd_seq_item item;
    real coverage_target = 100.0;
    covergroup sd_cg;
      option.per_instance = 1;
      option.goal = 100;
      cmd: coverpoint item.cmd_type;
      bw: coverpoint item.bus_width { bins width[3] = {[0:2]}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      sd_cg = new();
    endfunction
    virtual function void write(sd_seq_item t);
      item = t;
      sd_cg.sample();
    endfunction
    function real get_coverage();
      return sd_cg.get_coverage();
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("SD Coverage: %0.2f%%", cov), UVM_LOW)
    endfunction
  endclass

  //==========================================================================
  // Coverage report checker: aggregates per-protocol coverage at end of test
  //==========================================================================
  class memory_coverage_report_checker extends uvm_component;
    `uvm_component_utils(memory_coverage_report_checker)
    ddr_coverage ddr_cov_h;
    lpddr_coverage lpddr_cov_h;
    hbm_coverage hbm_cov_h;
    ufs_coverage ufs_cov_h;
    unipro_coverage unipro_cov_h;
    emmc_coverage emmc_cov_h;
    onfi_coverage onfi_cov_h;
    sd_coverage sd_cov_h;
    real overall_target = 100.0;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void report_phase(uvm_phase phase);
      real lpddr_cov = 0;
      if (lpddr_cov_h != null) lpddr_cov = lpddr_cov_h.get_coverage();
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), "  MEMORY PROTOCOL COVERAGE FINAL REPORT", UVM_NONE)
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("LPDDR Coverage: %6.2f%%", lpddr_cov), UVM_NONE)
      if (lpddr_cov < overall_target)
        `uvm_warning(get_type_name(), "LPDDR Coverage below target")
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
    endfunction
  endclass
endpackage : memory_coverage_pkg
