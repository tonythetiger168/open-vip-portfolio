// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_mem_tb.sv -- self-checking functional test for the LPDDR memory model
// (lpddr_mem_model, flattened by smoke/flatten.py). Run: python3 tools/run_func_tests.py LPDDR-VIP
//
// Model contract (from LPDDR-VIP/tb_top.sv):
//   Commands on CA[5:0] with CS high: ACT 010bbb, WR 101bbb, RD 100bbb,
//   PRE 011bbb, REF 110000 (bbb = bank). ACT is followed by two CA cycles
//   with the row (R[11:6], R[5:0]), RD / WR by one with the start column
//   C[9:4] (cs low in those cycles).
//   WR/RD start a 16-beat burst at column c, beat i at column c+i. Write
//   beat 0 is sampled TCWL=11 clocks after the command, read beat 0 is
//   driven TCL=22 clocks after it; one beat per clock.
// dq is a variable shared by the model and the controller in the original
// interface, so the test writes it hierarchically (u_dut.vif_dq) exactly as
// the UVM driver writes vif.dq.

module func_mem_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int TCL = 22, TCWL = 11, BL = 16, DW = 32;
  int checks = 0, fails = 0;

  logic ck = 1'b0, rst_n = 1'b0;
  logic cs = 1'b0;
  logic [5:0] ca = '0;
  wire [DW-1:0] dq;
  // idle value the test parks on the shared dq variable between bursts
  // (Verilator cannot write Z through a hierarchical reference)
  localparam [DW-1:0] IDLE = {(DW/16){16'hD1E5}};

  always #5 ck = ~ck;

  lpddr_mem_model u_dut (
    .vif_ck(ck), .vif_rst_n(rst_n), .vif_ca(ca), .vif_cs(cs), .vif_dq(dq)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one command cycle on the 6-bit CA bus (cs active high): drive at
  // negedge, sampled at P0, returns at N0
  task automatic cmd(input [5:0] c, input bit sel = 1'b1);
    @(negedge ck);
    cs = sel; ca = c;
    @(posedge ck);
    @(negedge ck);
    cs = 1'b0; ca = 6'h00;
  endtask
  // an address cycle (cs low) right after a command: sampled at the next
  // edge, returns at the following negedge
  task automatic addr_cycle(input [5:0] a);
    ca = a;
    @(posedge ck);
    @(negedge ck);
    ca = 6'h00;
  endtask
  task automatic act(input int b, input [15:0] row);
    cmd({3'b010, 3'(b)}); addr_cycle(row[11:6]); addr_cycle(row[5:0]);
  endtask
  task automatic pre(input int b);                   cmd({3'b011, 3'(b)}); endtask
  task automatic refresh();                          cmd(6'b110000);       endtask
  // RD / WR return one clock after the command (at N1, after the column cycle)
  task automatic issue_wr(input int b, input [15:0] col, input bit sel);
    cmd({3'b101, 3'(b)}, sel); addr_cycle(col[9:4]);
  endtask
  task automatic issue_rd(input int b, input [15:0] col);
    cmd({3'b100, 3'(b)}); addr_cycle(col[9:4]);
  endtask

  // beat i of the burst pattern seeded by s
  function automatic [DW-1:0] pat(input [15:0] s, input int i);
    return {(DW/64 > 1 ? DW/64 : 1){s, 16'(i), ~s, 16'(i * 3 + 1)}};
  endfunction

  // burst write; a garbage word sits on dq the clock before TCWL so an early
  // sample would be detected
  task automatic wr(input int b, input [15:0] col, input [15:0] s, input bit sel = 1'b1);
    issue_wr(b, col, sel);                     // returns at N1
    repeat (TCWL - 3) @(negedge ck);
    u_dut.vif_dq = '1;
    for (int i = 0; i < BL; i++) begin
      @(negedge ck);
      u_dut.vif_dq = pat(s, i);                // sampled at P(TCWL + i)
    end
    @(negedge ck);
    u_dut.vif_dq = IDLE;
  endtask

  // burst read into q[]; early = dq one clock before beat 0
  logic [DW-1:0] q [BL];
  logic [DW-1:0] early, after;
  task automatic rd(input int b, input [15:0] col);
    u_dut.vif_dq = IDLE;
    issue_rd(b, col);                          // returns at N1
    repeat (TCL - 2) @(negedge ck);
    early = dq;
    for (int i = 0; i < BL; i++) begin
      @(negedge ck);
      q[i] = dq;
    end
    @(negedge ck);
    after = dq;
  endtask

  // dq left untouched for n clocks (no burst started)
  task automatic watch_quiet(input int n, output bit ok);
    ok = 1;
    for (int i = 0; i < n; i++) begin
      @(negedge ck);
      if (dq !== IDLE) ok = 0;
    end
  endtask

  // reference of every written beat: {bank, row, col} -> data
  logic [DW-1:0] ref_m [bit [36:0]];
  function automatic bit burst_ok(input int b, input [15:0] row, input [15:0] col);
    for (int i = 0; i < BL; i++) begin
      bit [36:0] k;
      k = {5'(b), row, 16'(col + i)};
      if (q[i] !== (ref_m.exists(k) ? ref_m[k] : '0)) return 0;
    end
    return 1;
  endfunction

  function automatic bit burst_is(input [15:0] s, input int shift);
    for (int i = 0; i < BL; i++) begin
      if (i + shift < BL) begin
        if (q[i] !== pat(s, i + shift)) return 0;
      end else if (q[i] !== '0) return 0;
    end
    return 1;
  endfunction

  function automatic bit all_zero();
    for (int i = 0; i < BL; i++) if (q[i] !== '0) return 0;
    return 1;
  endfunction

  initial begin
    u_dut.vif_dq = IDLE;
    repeat (2) @(posedge ck);
    // a write issued while reset is asserted must be ignored
    act(0, 16'h0007);
    wr(0, 16'h0000, 16'h0BAD);
    rst_n = 1'b1;
    repeat (2) @(posedge ck);

    act(0, 16'h0011);
    wr(0, 16'h0000, 16'h1111);
    rd(0, 16'h0000);
    chk(burst_is(16'h1111, 0), "burst write reads back beat-for-beat in order");
    chk(early === IDLE, "read data not driven before TCL");
    chk(after === q[BL-1], "read data not driven past the burst");

    // overwrite
    wr(0, 16'h0000, 16'h2222);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "second burst overwrites the first");

    // bank independence
    act(1, 16'h0011);
    wr(1, 16'h0000, 16'h3333);
    act(6, 16'h0011);
    wr(6, 16'h0000, 16'h4444);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "bank 0 unaffected by other banks");
    rd(1, 16'h0000);
    chk(burst_is(16'h3333, 0), "bank 1 holds its own burst");
    rd(6, 16'h0000);
    chk(burst_is(16'h4444, 0), "bank 6 holds its own burst");

    // PRE / ACT of the same row keeps the data
    pre(0);
    act(0, 16'h0011);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "bank data retained across PRE/ACT");

    // rows are separate: another row of bank 0 is empty, and writing it
    // leaves row 0x011 alone
    pre(0);
    act(0, 16'h0A5C);
    rd(0, 16'h0000);
    chk(all_zero(), "another row of the bank starts empty");
    wr(0, 16'h0000, 16'h5A5A);
    rd(0, 16'h0000);
    chk(burst_is(16'h5A5A, 0), "second row holds its own burst");
    pre(0);
    act(0, 16'h0011);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "first row kept its burst");

    // columns are separate: the next BL16 column holds its own burst and
    // the last column of the row works
    wr(0, 16'h0010, 16'h7777);
    rd(0, 16'h0010);
    chk(burst_is(16'h7777, 0), "column 0x10 holds its own burst");
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "column 0 unaffected by column 0x10");
    wr(0, 16'h03F0, 16'h7E7E);
    rd(0, 16'h03F0);
    chk(burst_is(16'h7E7E, 0), "last column (0x3F0) holds its burst");

    // refresh must not disturb stored data
    refresh();
    act(0, 16'h0011);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "data retained across REFRESH");

    // deselected write ignored
    wr(0, 16'h0000, 16'h6666, 1'b0);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "write while chip deselected is ignored");

    // write during reset did not land
    act(3, 16'h0007);
    rd(3, 16'h0000);
    chk(all_zero(), "command during reset had no effect");


    // a burst write does not spill into the next burst
    act(4, 16'h0041);
    wr(4, 16'h0000, 16'h8888);
    rd(4, 16'h0000);
    chk(burst_is(16'h8888, 0), "fresh bank: burst written");
    rd(4, 16'(BL));
    chk(all_zero(), "burst write does not spill into the next burst's columns");

    // REFRESH must not start a read burst
    begin
      bit ok1;
      u_dut.vif_dq = IDLE;
      refresh();
      watch_quiet(TCL + BL + 4, ok1);
      chk(ok1, "REFRESH does not drive dq");
    end

    // random bursts
    begin
      int bad;
      bit [15:0] rows [8];
      bad = 0;
      for (int b = 0; b < 8; b++) begin
        rows[b] = 16'(16'h0100 * b + 16'h0033); pre(b); act(b, rows[b]);
        wr(b, 16'h0000, 16'(16'hA000 + b));   // known contents for every bank
        for (int i = 0; i < BL; i++) ref_m[{5'(b), rows[b], 16'(i)}] = pat(16'(16'hA000 + b), i);
      end
      for (int t = 0; t < 24; t++) begin
        int b;
        bit [15:0] col, s;
        b = $urandom_range(8 - 1);
        col = 16'(16 * $urandom_range(3));
        if ($urandom_range(1)) begin
          s = $urandom;
          wr(b, col, s);
          for (int i = 0; i < BL; i++) ref_m[{5'(b), rows[b], 16'(col + i)}] = pat(s, i);
        end else begin
          rd(b, col);
          if (!burst_ok(b, rows[b], col)) bad++;
        end
      end
      chk(bad == 0, "24 random bursts match the reference");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
