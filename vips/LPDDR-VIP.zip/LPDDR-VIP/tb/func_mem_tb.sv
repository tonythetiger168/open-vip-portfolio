// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_mem_tb.sv -- self-checking functional test for the LPDDR memory model
// (lpddr_mem_model, flattened by smoke/flatten.py). Run: python3 tools/run_func_tests.py LPDDR-VIP
//
// Model contract (from LPDDR-VIP/tb_top.sv):
//   Commands on CA[5:0] with CS high: ACT 010bbb, WR 101bbb, RD 100bbb,
//   PRE 011bbb, REF 110000 (bbb = bank). The model always uses row 0 and
//   column 0, so each bank holds exactly one burst.
//   WR/RD start a 8-beat burst at column c, beat i at column c+8*i. Write
//   beat 0 is sampled TCWL=11 clocks after the command, read beat 0 is
//   driven TCL=22 clocks after it; one beat per clock.
// dq is a variable shared by the model and the controller in the original
// interface, so the test writes it hierarchically (u_dut.vif_dq) exactly as
// the UVM driver writes vif.dq.

module func_mem_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int TCL = 22, TCWL = 11, BL = 8, DW = 32;
  int checks = 0, fails = 0;

  logic ck = 1'b0, rst_n = 1'b0;
  logic cs = 1'b0;
  logic [5:0] ca = '0;
  wire [DW-1:0] dq;
  // idle value the test parks on the shared dq variable between bursts
  // (Verilator cannot write Z through a hierarchical reference)
  localparam [DW-1:0] IDLE = {(DW/16){16'hD1E5}};

  always #5 ck = ~ck;

  lpddr_mem_model u_dut (
    .vif_ck(ck), .vif_rst_n(rst_n), .vif_ca(ca), .vif_cs(cs), .vif_dq(dq)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one command cycle on the 6-bit CA bus (cs active high): drive at
  // negedge, sampled at P0, returns at N0
  task automatic cmd(input [5:0] c, input bit sel = 1'b1);
    @(negedge ck);
    cs = sel; ca = c;
    @(posedge ck);
    @(negedge ck);
    cs = 1'b0; ca = 6'h00;
  endtask
  task automatic act(input int b, input [15:0] row); cmd({3'b010, 3'(b)}); endtask
  task automatic pre(input int b);                   cmd({3'b011, 3'(b)}); endtask
  task automatic refresh();                          cmd(6'b110000);       endtask
  task automatic issue_wr(input int b, input [15:0] col, input bit sel); cmd({3'b101, 3'(b)}, sel); endtask
  task automatic issue_rd(input int b, input [15:0] col);                cmd({3'b100, 3'(b)});      endtask

  // beat i of the burst pattern seeded by s
  function automatic [DW-1:0] pat(input [15:0] s, input int i);
    return {(DW/64 > 1 ? DW/64 : 1){s, 16'(i), ~s, 16'(i * 3 + 1)}};
  endfunction

  // burst write; a garbage word sits on dq the clock before TCWL so an early
  // sample would be detected
  task automatic wr(input int b, input [15:0] col, input [15:0] s, input bit sel = 1'b1);
    issue_wr(b, col, sel);                     // returns at N0
    repeat (TCWL - 2) @(negedge ck);
    u_dut.vif_dq = '1;
    for (int i = 0; i < BL; i++) begin
      @(negedge ck);
      u_dut.vif_dq = pat(s, i);                // sampled at P(TCWL + i)
    end
    @(negedge ck);
    u_dut.vif_dq = IDLE;
  endtask

  // burst read into q[]; early = dq one clock before beat 0
  logic [DW-1:0] q [BL];
  logic [DW-1:0] early;
  task automatic rd(input int b, input [15:0] col);
    u_dut.vif_dq = IDLE;
    issue_rd(b, col);                          // returns at N0
    repeat (TCL - 1) @(negedge ck);
    early = dq;
    for (int i = 0; i < BL; i++) begin
      @(negedge ck);
      q[i] = dq;
    end
  endtask

  function automatic bit burst_is(input [15:0] s, input int shift);
    for (int i = 0; i < BL; i++) begin
      if (i + shift < BL) begin
        if (q[i] !== pat(s, i + shift)) return 0;
      end else if (q[i] !== '0) return 0;
    end
    return 1;
  endfunction

  function automatic bit all_zero();
    for (int i = 0; i < BL; i++) if (q[i] !== '0) return 0;
    return 1;
  endfunction

  initial begin
    u_dut.vif_dq = IDLE;
    repeat (2) @(posedge ck);
    // a write issued while reset is asserted must be ignored
    act(0, 16'h0007);
    wr(0, 16'h0000, 16'h0BAD);
    rst_n = 1'b1;
    repeat (2) @(posedge ck);

    act(0, 16'h0011);
    wr(0, 16'h0000, 16'h1111);
    rd(0, 16'h0000);
    chk(burst_is(16'h1111, 0), "burst write reads back beat-for-beat in order");
    chk(early === IDLE, "read data not driven before TCL");

    // overwrite
    wr(0, 16'h0000, 16'h2222);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "second burst overwrites the first");

    // bank independence
    act(1, 16'h0011);
    wr(1, 16'h0000, 16'h3333);
    act(6, 16'h0011);
    wr(6, 16'h0000, 16'h4444);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "bank 0 unaffected by other banks");
    rd(1, 16'h0000);
    chk(burst_is(16'h3333, 0), "bank 1 holds its own burst");
    rd(6, 16'h0000);
    chk(burst_is(16'h4444, 0), "bank 6 holds its own burst");

    // the model has a single (row 0, col 0) burst slot per bank: PRE/ACT
    // must still keep the data
    pre(0);
    act(0, 16'h0000);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "bank data retained across PRE/ACT");

    // refresh must not disturb stored data
    refresh();
    act(0, 16'h0000);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "data retained across REFRESH");

    // deselected write ignored
    wr(0, 16'h0000, 16'h6666, 1'b0);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "write while chip deselected is ignored");

    // write during reset did not land
    act(3, 16'h0007);
    rd(3, 16'h0000);
    chk(all_zero(), "command during reset had no effect");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
