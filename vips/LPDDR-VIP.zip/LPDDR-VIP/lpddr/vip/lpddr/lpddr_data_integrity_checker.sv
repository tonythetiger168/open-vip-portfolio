// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// LPDDR Data Integrity Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef LPDDR_DATA_INTEGRITY_CHECKER_SV
`define LPDDR_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module lpddr_data_integrity_checker (lpddr_if vif);

  property p_lpddr_rdqs_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.rdqs == 1 |-> vif.cs_n == 0; endproperty
  assert_p_lpddr_rdqs_valid: assert property(p_lpddr_rdqs_valid) else `uvm_warning("LPDDR_DI", "RDQS valid failed");
  cover_p_lpddr_rdqs_valid: cover property(p_lpddr_rdqs_valid);
  property p_lpddr_odt_ca; @(posedge vif.ck) disable iff (!vif.rst_n) vif.odt_ca == 1 |-> vif.cs_n == 0; endproperty
  assert_p_lpddr_odt_ca: assert property(p_lpddr_odt_ca) else `uvm_warning("LPDDR_DI", "ODT-CA active failed");
  cover_p_lpddr_odt_ca: cover property(p_lpddr_odt_ca);

endmodule : lpddr_data_integrity_checker
`endif
