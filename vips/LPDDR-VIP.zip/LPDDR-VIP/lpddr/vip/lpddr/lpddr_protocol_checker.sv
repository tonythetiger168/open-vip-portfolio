// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// LPDDR Protocol Compliance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef LPDDR_PROTOCOL_CHECKER_SV
`define LPDDR_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module lpddr_protocol_checker (lpddr_if vif);

  property p_lpddr_ca_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_lpddr_ca_valid: assert property(p_lpddr_ca_valid) else `uvm_warning("LPDDR_CHK", "CA valid when CS active failed");
  cover_p_lpddr_ca_valid: cover property(p_lpddr_ca_valid);
  property p_lpddr_wck_ratio; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_lpddr_wck_ratio: assert property(p_lpddr_wck_ratio) else `uvm_warning("LPDDR_CHK", "WCK ratio valid failed");
  cover_p_lpddr_wck_ratio: cover property(p_lpddr_wck_ratio);
  property p_lpddr_bl_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_lpddr_bl_valid: assert property(p_lpddr_bl_valid) else `uvm_warning("LPDDR_CHK", "Burst length valid failed");
  cover_p_lpddr_bl_valid: cover property(p_lpddr_bl_valid);
  property p_lpddr_dmi_write; @(posedge vif.ck) disable iff (!vif.rst_n) (|vif.dqs) == 1'b1 && vif.ca[4] == 0 |-> vif.dmi == 1; endproperty
  assert_p_lpddr_dmi_write: assert property(p_lpddr_dmi_write) else `uvm_warning("LPDDR_CHK", "DMI on write failed");
  cover_p_lpddr_dmi_write: cover property(p_lpddr_dmi_write);

endmodule : lpddr_protocol_checker
`endif
