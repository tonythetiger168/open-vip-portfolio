// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// LPDDR Timing & Performance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef LPDDR_TIMING_CHECKER_SV
`define LPDDR_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module lpddr_timing_checker (lpddr_if vif);

  property p_lpddr_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cs_n) |-> ##[2:6] vif.ca[4] == 0; endproperty
  assert_p_lpddr_tRCD: assert property(p_lpddr_tRCD) else `uvm_warning("LPDDR_TIM", "tRCD timing violated");
  cover_p_lpddr_tRCD: cover property(p_lpddr_tRCD);
  property p_lpddr_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.cs_n) |-> ##[2:6] $fell(vif.cs_n); endproperty
  assert_p_lpddr_tRP: assert property(p_lpddr_tRP) else `uvm_warning("LPDDR_TIM", "tRP timing violated");
  cover_p_lpddr_tRP: cover property(p_lpddr_tRP);

endmodule : lpddr_timing_checker
`endif
