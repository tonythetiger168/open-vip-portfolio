// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// LPDDR Error Handling Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef LPDDR_ERROR_CHECKER_SV
`define LPDDR_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module lpddr_error_checker (lpddr_if vif);

  property p_lpddr_reset; @(posedge vif.ck) disable iff (!vif.rst_n) vif.rst_n == 0 |-> ##[200:300] vif.rst_n == 1; endproperty
  assert_p_lpddr_reset: assert property(p_lpddr_reset) else `uvm_warning("LPDDR_ERR", "Reset duration failed");
  cover_p_lpddr_reset: cover property(p_lpddr_reset);
  property p_lpddr_zqcal; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ca == 6'b100100 |-> ##[1:1000] vif.cs_n == 1; endproperty
  assert_p_lpddr_zqcal: assert property(p_lpddr_zqcal) else `uvm_warning("LPDDR_ERR", "ZQ calibration failed");
  cover_p_lpddr_zqcal: cover property(p_lpddr_zqcal);

endmodule : lpddr_error_checker
`endif
