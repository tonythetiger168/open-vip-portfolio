// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// LPDDR Tiered Compliance SVA Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.
// L1=4 | L2=4 | L3=4 retained below; L4 LPDDR protocol-specific rules added

`ifndef LPDDR_COMPLIANCE_CHECKER_SV
`define LPDDR_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module lpddr_compliance_checker (lpddr_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  real l1_cov, l2_cov, l3_cov, total_cov;

  // ---------------- L1: signal sanity (4) ----------------
  property p_lpddr_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_lpddr_cmd_valid: assert property(p_lpddr_cmd_valid) l1_pass[0]++; else begin `uvm_warning("LPDDR_L1", "Command valid failed"); l1_fail[0]++; end
  cover_p_lpddr_cmd_valid: cover property(p_lpddr_cmd_valid);
  property p_lpddr_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs == 1 |-> !$isunknown(vif.dq); endproperty
  assert_p_lpddr_addr_valid: assert property(p_lpddr_addr_valid) l1_pass[1]++; else begin `uvm_warning("LPDDR_L1", "Address valid failed"); l1_fail[1]++; end
  cover_p_lpddr_addr_valid: cover property(p_lpddr_addr_valid);
  property p_lpddr_data_valid; @(posedge vif.ck) disable iff (!vif.rst_n) (|vif.dqs) == 1'b1 |-> !$isunknown(vif.dq); endproperty
  assert_p_lpddr_data_valid: assert property(p_lpddr_data_valid) l1_pass[2]++; else begin `uvm_warning("LPDDR_L1", "Data valid failed"); l1_fail[2]++; end
  cover_p_lpddr_data_valid: cover property(p_lpddr_data_valid);
  property p_lpddr_no_x; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_lpddr_no_x: assert property(p_lpddr_no_x) l1_pass[3]++; else begin `uvm_warning("LPDDR_L1", "No X when active failed"); l1_fail[3]++; end
  cover_p_lpddr_no_x: cover property(p_lpddr_no_x);
  // ---------------- L2: FSM legality (4) ----------------
  property p_lpddr_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cs_n) |-> ##[2:6] vif.ca[4] == 0; endproperty
  assert_p_lpddr_tRCD: assert property(p_lpddr_tRCD) l2_pass[0]++; else begin `uvm_warning("LPDDR_L2", "tRCD timing failed"); l2_fail[0]++; end
  cover_p_lpddr_tRCD: cover property(p_lpddr_tRCD);
  property p_lpddr_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.cs_n) |-> ##[2:6] $fell(vif.cs_n); endproperty
  assert_p_lpddr_tRP: assert property(p_lpddr_tRP) l2_pass[1]++; else begin `uvm_warning("LPDDR_L2", "tRP timing failed"); l2_fail[1]++; end
  cover_p_lpddr_tRP: cover property(p_lpddr_tRP);
  property p_lpddr_wck_ratio; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_lpddr_wck_ratio: assert property(p_lpddr_wck_ratio) l2_pass[2]++; else begin `uvm_warning("LPDDR_L2", "WCK ratio failed"); l2_fail[2]++; end
  cover_p_lpddr_wck_ratio: cover property(p_lpddr_wck_ratio);
  property p_lpddr_bl; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_lpddr_bl: assert property(p_lpddr_bl) l2_pass[3]++; else begin `uvm_warning("LPDDR_L2", "Burst length failed"); l2_fail[3]++; end
  cover_p_lpddr_bl: cover property(p_lpddr_bl);
  // ---------------- L3: protocol rules (4) ----------------
  property p_lpddr_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> ##[1:7812] vif.cs_n == 0; endproperty
  assert_p_lpddr_refresh: assert property(p_lpddr_refresh) l3_pass[0]++; else begin `uvm_warning("LPDDR_L3", "Refresh interval failed"); l3_fail[0]++; end
  cover_p_lpddr_refresh: cover property(p_lpddr_refresh);
  property p_lpddr_reset; @(posedge vif.ck) disable iff (!vif.rst_n) vif.rst_n == 0 |-> ##[100:300] vif.rst_n == 1; endproperty
  assert_p_lpddr_reset: assert property(p_lpddr_reset) l3_pass[1]++; else begin `uvm_warning("LPDDR_L3", "Reset timing failed"); l3_fail[1]++; end
  cover_p_lpddr_reset: cover property(p_lpddr_reset);
  property p_lpddr_odt; @(posedge vif.ck) disable iff (!vif.rst_n) vif.we_n == 0 |-> vif.odt == 1; endproperty
  assert_p_lpddr_odt: assert property(p_lpddr_odt) l3_pass[2]++; else begin `uvm_warning("LPDDR_L3", "ODT active failed"); l3_fail[2]++; end
  cover_p_lpddr_odt: cover property(p_lpddr_odt);
  property p_lpddr_cke; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ras_n == 0 |-> vif.cke == 1; endproperty
  assert_p_lpddr_cke: assert property(p_lpddr_cke) l3_pass[3]++; else begin `uvm_warning("LPDDR_L3", "CKE active failed"); l3_fail[3]++; end
  cover_p_lpddr_cke: cover property(p_lpddr_cke);

  // ---------------- L4: LPDDR protocol-specific rules (6) ----------------
  // Command decode helpers
  wire is_act = vif.cs && (vif.ca[5:3] == 3'b010);
  wire is_rd  = vif.cs && (vif.ca[5:3] == 3'b100);
  wire is_wr  = vif.cs && (vif.ca[5:3] == 3'b101);
  wire is_cas = is_rd || is_wr;
  wire is_pre = vif.cs && (vif.ca[5:3] == 3'b011);
  wire is_ref = vif.cs && (vif.ca == 6'b110000);
  wire [2:0] cur_bank = vif.ca[2:0];

  // Protocol state tracked for L4 rules
  int unsigned cyc = 0;
  bit          bank_open [32];
  int unsigned act_hist [4];
  int          act_hist_idx = 0;
  int unsigned last_ref_cyc = 0;
  bit          seen_ref = 0;

  always @(posedge vif.ck) begin
    if (!vif.rst_n) begin
      cyc <= 0;
      for (int b = 0; b < 32; b++) bank_open[b] <= 1'b0;
      for (int i = 0; i < 4; i++) act_hist[i] <= 0;
      act_hist_idx <= 0;
      last_ref_cyc <= 0;
      seen_ref <= 1'b0;
    end
    else begin
      cyc <= cyc + 1;
      if (is_act) begin
        bank_open[cur_bank] <= 1'b1;
        act_hist[act_hist_idx] <= cyc;
        act_hist_idx <= (act_hist_idx + 1) % 4;
      end
      if (is_pre) bank_open[cur_bank] <= 1'b0;
      if (is_ref) begin
        for (int b = 0; b < 32; b++) bank_open[b] <= 1'b0;
        last_ref_cyc <= cyc;
        seen_ref <= 1'b1;
      end
    end
  end

  // L4-1: tRCD -- no CAS within tRCD cycles after ACT
  a_lpddr_l4_trcd : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act |=> !is_cas[*17])
    else `uvm_error("SVA_L4", "LPDDR: tRCD violated (CAS too soon after ACT)")

  // L4-2: tRAS -- no PRE within tRAS cycles after ACT
  a_lpddr_l4_tras : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act |=> !is_pre[*41])
    else `uvm_error("SVA_L4", "LPDDR: tRAS violated (PRE too soon after ACT)")

  // L4-3: tFAW -- no more than 4 ACTs inside the rolling tFAW window
  a_lpddr_l4_tfaw : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act |-> (act_hist[act_hist_idx] == 0) ||
               (cyc - act_hist[act_hist_idx] > 24))
    else `uvm_error("SVA_L4", "LPDDR: tFAW violated (5th ACT inside window)")

  // L4-4: bank state legality -- RD/WR only to an open bank
  a_lpddr_l4_rdwr_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_cas |-> bank_open[cur_bank])
    else `uvm_error("SVA_L4", "LPDDR: RD/WR to a closed bank")

  // L4-5: ACT to an already-open bank is illegal (missing PRE)
  a_lpddr_l4_act_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act |-> !bank_open[cur_bank])
    else `uvm_error("SVA_L4", "LPDDR: ACT to an already-open bank")

  // L4-6: refresh interval -- REF at least every tREFI cycles
  a_lpddr_l4_trefi : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    seen_ref |-> (cyc - last_ref_cyc <= 3900))
    else `uvm_error("SVA_L4", "LPDDR: refresh interval exceeded")

  c_lpddr_l4_act_to_cas : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act ##[18:22] is_cas);
  c_lpddr_l4_full_cycle : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act ##[1:64] is_pre);

  // SVA tier coverage report (was report_phase in the class-based version)
  final begin
    int l1_total = 0, l2_total = 0, l3_total = 0;
    int l1_hit = 0, l2_hit = 0, l3_hit = 0;
    foreach (l1_pass[i]) begin l1_total++; if (l1_pass[i] > 0) l1_hit++; end
    foreach (l2_pass[i]) begin l2_total++; if (l2_pass[i] > 0) l2_hit++; end
    foreach (l3_pass[i]) begin l3_total++; if (l3_pass[i] > 0) l3_hit++; end
    l1_cov = (l1_total > 0) ? (l1_hit * 100.0 / l1_total) : 0;
    l2_cov = (l2_total > 0) ? (l2_hit * 100.0 / l2_total) : 0;
    l3_cov = (l3_total > 0) ? (l3_hit * 100.0 / l3_total) : 0;
    total_cov = (l1_total + l2_total + l3_total > 0)
                ? ((l1_hit + l2_hit + l3_hit) * 100.0 / (l1_total + l2_total + l3_total)) : 0;
    `uvm_info("LPDDR_RPT", "=== LPDDR Tiered SVA Report ===", UVM_LOW)
    `uvm_info("LPDDR_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)",
              l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("LPDDR_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)",
              l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("LPDDR_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)",
              l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("LPDDR_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%%",
              total_cov), UVM_LOW)
  end

endmodule : lpddr_compliance_checker
`endif
