// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// LPDDR4/5/6 UVM VIP Package
// Deepened: CA-bus command driver with tRCD/tRP/tRAS/tFAW timing, bus-decoding
// monitor with bank/page tracking, directed sequence library.
//
// Single-cycle CA encoding used by this VIP (ca[5:0], cs active high):
//   MRW=00_0xxx  MRR=00_1xxx  ACT=010bbb  PRE=011bbb
//   RD =100bbb   WR =101bbb   REF=110000  SRE=110001
//   SRX=110010   MST=110011   PDE=110100  PDX=110101  NOP=111111
//------------------------------------------------------------------------------
package lpddr_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // Bank state tracked by the monitor, sampled by functional coverage
  typedef enum {B_IDLE, B_ACTIVE} bank_state_e;

  //==========================================================================
  // LPDDR Sequence Item
  //==========================================================================
  class lpddr_seq_item extends uvm_sequence_item;
    `uvm_object_utils(lpddr_seq_item)
    typedef enum {MRR, MRW, READ, WRITE, MST, SRE, SRX, PDE, PDX,
                  ACT, PRE, REF} cmd_type_e;
    rand cmd_type_e cmd_type;
    rand bit [15:0] addr;
    rand bit [5:0]  ca;      // Command/Address bus
    rand bit [2:0]  bank;
    rand bit [31:0] data[];
    rand bit [3:0]  dm;
    rand bit [3:0]  burst_len;
    bit [31:0]      rdata[];
    // LPDDR5/6 specific
    rand bit        wck_en;
    rand bit        rdqs;
    rand bit [1:0]  dbi;     // Data bus inversion
    // filled in by the monitor
    bit             page_hit;
    bank_state_e    bstate;

    constraint c_burst_len { burst_len inside {8, 16}; }
    constraint c_data_size { data.size() == burst_len; }
    constraint c_cmd_dist { cmd_type dist {READ := 25, WRITE := 25, MRR := 10,
                                           MRW := 10, MST := 5, SRE := 5,
                                           SRX := 5, PDE := 5, PDX := 5,
                                           ACT := 3, PRE := 3, REF := 4}; }
    function new(string name = "lpddr_seq_item");
      super.new(name);
    endfunction
    // rdata is not rand: a size constraint on it would pin burst_len to its
    // current size (0), so it is sized here instead
    function void post_randomize();
      rdata = new[burst_len];
      // A rand dynamic array is left unsized on Verilator even with the
      // data.size() == burst_len constraint: every write then drove zeros
      // and a read-data check could not fail. Size and fill it here.
      if (data.size() != burst_len) begin
        data = new[burst_len];
        foreach (data[i]) data[i] = {$urandom()};
      end
    endfunction
    function string convert2string();
      return $sformatf("LPDDR %s: bank=%0d addr=0x%0h bl=%0d",
                       cmd_type.name(), bank, addr, burst_len);
    endfunction
  endclass : lpddr_seq_item

  //==========================================================================
  // LPDDR Configuration
  //==========================================================================
  class lpddr_cfg extends uvm_object;
    `uvm_object_utils(lpddr_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1;
    int tRCD = 18;
    int tRP  = 18;
    int tRAS = 42;
    int tCL  = 22;
    int tCWL = 11;
    int tRRD = 6;
    int tFAW = 24;
    int tWR  = 18;
    int tRTP = 10;
    int tWTR = 10;
    int tPPD = 2;   // Precharge to precharge delay
    int tREFI = 3900;   // average refresh interval, in clocks
    function new(string name = "lpddr_cfg");
      super.new(name);
    endfunction
  endclass : lpddr_cfg

  //==========================================================================
  // LPDDR Sequencer
  //==========================================================================
  class lpddr_sequencer extends uvm_sequencer #(lpddr_seq_item);
    `uvm_component_utils(lpddr_sequencer)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
  endclass : lpddr_sequencer

  //==========================================================================
  // LPDDR Driver -- drives CA-bus command sequences on lpddr_if with
  // JEDEC-style timing; publishes expected items for the scoreboard.
  //==========================================================================
  class lpddr_driver extends uvm_driver #(lpddr_seq_item);
    `uvm_component_utils(lpddr_driver)
    virtual lpddr_if vif;
    lpddr_cfg cfg;
    uvm_analysis_port #(lpddr_seq_item) drv_ap;  // expected items for scoreboard

    bit          bank_active [8];
    bit [15:0]   active_row  [8];
    int unsigned act_cycle   [8];
    int unsigned act_hist    [4];
    int          act_hist_idx = 0;
    int unsigned cyc = 0;
    int unsigned last_act_cyc = 0;   // latest ACT to any bank
    int unsigned last_ref_cyc = 0;
    bit          low_power = 0;      // in self refresh or power down

    function new(string name, uvm_component parent);
      super.new(name, parent);
      drv_ap = new("drv_ap", this);
      foreach (bank_active[i]) bank_active[i] = 0;
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual lpddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "LPDDR virtual interface not found")
      if (!uvm_config_db#(lpddr_cfg)::get(this, "", "cfg", cfg))
        cfg = lpddr_cfg::type_id::create("cfg");
    endfunction

    // One CA command cycle (cs high for exactly one clock). With Verilator
    // 5.052 a clocking-block drive issued right after the clock edge lands in
    // the same step, so cs was cleared before any edge sampled it: drive the
    // pins directly on the falling edge instead.
    task drive_ca(bit [5:0] ca);
      @(negedge vif.ck);
      vif.ca = ca;
      vif.cs = 1'b1;
      @(posedge vif.ck);
      cyc++;
      vif.cs <= 1'b0;
    endtask

    task idle(int n);
      repeat (n) begin
        @(posedge vif.ck);
        cyc++;
      end
    endtask

    // A command the driver adds on its own, as a memory controller does
    // (open a closed bank, close an open one, refresh in time): it goes on
    // the expected stream like any sequence item.
    function void expect_cmd(lpddr_seq_item::cmd_type_e c, bit [5:0] ca, bit [2:0] b);
      lpddr_seq_item e = lpddr_seq_item::type_id::create("auto");
      e.cmd_type = c; e.ca = ca; e.bank = b;
      `uvm_info(get_type_name(), $sformatf("Controller adds: %s", e.convert2string()), UVM_HIGH)
      drv_ap.write(e);
    endfunction

    task activate(bit [15:0] row, bit [2:0] b);
      if (bank_active[b]) begin         // ACT to an open bank: close it first
        precharge(b);
        expect_cmd(lpddr_seq_item::PRE, {3'b011, b}, b);
      end
      while (cyc - act_hist[act_hist_idx] <= cfg.tFAW && act_hist[act_hist_idx] != 0)
        idle(1);                        // tFAW window
      drive_ca({3'b010, b});            // ACT encoding (row tracked by model)
      bank_active[b] = 1;
      active_row[b]  = row;
      act_cycle[b]   = cyc;
      last_act_cyc   = cyc;
      act_hist[act_hist_idx] = cyc;
      act_hist_idx = (act_hist_idx + 1) % 4;
      idle(cfg.tRCD - 1);               // tRCD
    endtask

    task precharge(bit [2:0] b);
      while (cyc - last_act_cyc < cfg.tRAS)
        idle(1);                        // tRAS
      drive_ca({3'b011, b});            // PRE encoding
      bank_active[b] = 0;
      idle(cfg.tRP - 1);                // tRP
    endtask

    // RD/WR to a closed bank: open a row first
    task ensure_open(bit [2:0] b);
      if (!bank_active[b]) begin
        activate(16'h0, b);
        expect_cmd(lpddr_seq_item::ACT, {3'b010, b}, b);
      end
    endtask

    // Close every open bank (before REF / self refresh)
    task precharge_all();
      bit any = 0;
      while (cyc - last_act_cyc < cfg.tRAS)
        idle(1);
      foreach (bank_active[i])
        if (bank_active[i]) begin
          drive_ca({3'b011, 3'(i)});
          bank_active[i] = 0;
          expect_cmd(lpddr_seq_item::PRE, {3'b011, 3'(i)}, 3'(i));
          any = 1;
        end
      if (any) idle(cfg.tRP - 1);
    endtask

    // Refresh before tREFI runs out, then reopen the rows that were open
    task refresh_if_due();
      bit        was_open[8];
      bit [15:0] rows[8];
      if (low_power || cyc - last_ref_cyc + 300 < cfg.tREFI) return;
      foreach (bank_active[i]) begin was_open[i] = bank_active[i]; rows[i] = active_row[i]; end
      precharge_all();
      drive_ca(6'b110000);
      last_ref_cyc = cyc;
      expect_cmd(lpddr_seq_item::REF, 6'b110000, 3'b000);
      idle(cfg.tRAS - 1);               // tRFC
      foreach (was_open[i])
        if (was_open[i]) begin
          activate(rows[i], 3'(i));
          expect_cmd(lpddr_seq_item::ACT, {3'b010, 3'(i)}, 3'(i));
        end
    endtask

    task drive_act(lpddr_seq_item item);
      item.ca = {3'b010, item.bank};
      activate(item.addr, item.bank);
    endtask

    task drive_read(lpddr_seq_item item);
      ensure_open(item.bank);
      item.ca = {3'b100, item.bank};   // RD encoding
      drive_ca(item.ca);
      idle(cfg.tCL);                    // CAS latency
      item.rdata = new[item.burst_len];
      for (int i = 0; i < item.burst_len; i++) begin
        @(vif.drv_cb);
        cyc++;
        item.rdata[i] = vif.drv_cb.dq;  // sample read data burst
      end
    endtask

    task drive_write(lpddr_seq_item item);
      ensure_open(item.bank);
      item.ca = {3'b101, item.bank};   // WR encoding
      drive_ca(item.ca);
      idle(cfg.tCWL - 1);               // CAS write latency
      for (int i = 0; i < item.burst_len; i++) begin
        vif.drv_cb.dq <= item.data[i];
        vif.drv_cb.dm <= item.dm;
        @(vif.drv_cb);
        cyc++;
      end
    endtask

    task drive_pre(lpddr_seq_item item);
      item.ca = {3'b011, item.bank};   // PRE encoding
      precharge(item.bank);
    endtask

    task drive_ref(lpddr_seq_item item);
      precharge_all();                  // REF needs every bank idle
      item.ca = 6'b110000;             // REF encoding
      drive_ca(item.ca);
      last_ref_cyc = cyc;
      idle(cfg.tRAS - 1);               // tRFC
    endtask

    task drive_mrr(lpddr_seq_item item);
      item.ca = {3'b001, item.addr[2:0]};
      drive_ca(item.ca);
      idle(cfg.tCL);
    endtask

    task drive_mrw(lpddr_seq_item item);
      item.ca = {3'b000, item.addr[2:0]};
      drive_ca(item.ca);
      idle(4);                          // tMRW
    endtask

    task drive_mst(lpddr_seq_item item);
      item.ca = 6'b110011;
      drive_ca(item.ca);
      idle(4);
    endtask

    task drive_sre(lpddr_seq_item item);
      precharge_all();                  // self refresh starts with every bank idle
      item.ca = 6'b110001;
      drive_ca(item.ca);
      low_power = 1;
      idle(4);
    endtask

    task drive_srx(lpddr_seq_item item);
      item.ca = 6'b110010;
      drive_ca(item.ca);
      low_power = 0;
      last_ref_cyc = cyc;               // the device refreshed itself
      idle(10);
    endtask

    task drive_pde(lpddr_seq_item item);
      item.ca = 6'b110100;
      drive_ca(item.ca);
      low_power = 1;
      idle(2);
    endtask

    task drive_pdx(lpddr_seq_item item);
      item.ca = 6'b110101;
      drive_ca(item.ca);
      low_power = 0;
      idle(5);
    endtask

    task run_phase(uvm_phase phase);
      vif.cs = 1'b0;
      idle(1);
      wait (vif.rst_n === 1'b1);
      idle(5);
      forever begin
        seq_item_port.get_next_item(req);
        `uvm_info(get_type_name(), $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
        refresh_if_due();
        case (req.cmd_type)
          lpddr_seq_item::MRR:   drive_mrr(req);
          lpddr_seq_item::MRW:   drive_mrw(req);
          lpddr_seq_item::READ:  drive_read(req);
          lpddr_seq_item::WRITE: drive_write(req);
          lpddr_seq_item::MST:   drive_mst(req);
          lpddr_seq_item::SRE:   drive_sre(req);
          lpddr_seq_item::SRX:   drive_srx(req);
          lpddr_seq_item::PDE:   drive_pde(req);
          lpddr_seq_item::PDX:   drive_pdx(req);
          lpddr_seq_item::ACT:   drive_act(req);
          lpddr_seq_item::PRE:   drive_pre(req);
          lpddr_seq_item::REF:   drive_ref(req);
        endcase
        req.bank = req.ca[2:0];         // the bank field as the CA bus carries it
        drv_ap.write(req);              // broadcast expected transaction
        seq_item_port.item_done();
      end
    endtask
  endclass : lpddr_driver

  //==========================================================================
  // LPDDR Monitor -- decodes CA-bus commands, tracks per-bank state and page
  // hit/miss, publishes reconstructed transactions.
  //==========================================================================
  class lpddr_monitor extends uvm_monitor;
    `uvm_component_utils(lpddr_monitor)
    virtual lpddr_if vif;
    uvm_analysis_port #(lpddr_seq_item) item_collected_port;
    int unsigned txn_count = 0;

    protected bit        bank_active [8];
    protected bit [15:0] active_row  [8];
    protected bit        accessed    [8];   // row read/written since its ACT
    protected bit [5:0]  prev_ca = 6'h3f;
    protected bit        prev_cs = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual lpddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "LPDDR virtual interface not found")
    endfunction

    task run_phase(uvm_phase phase);
      lpddr_seq_item item;
      int id;
      forever begin
        @(vif.mon_cb);
        if (vif.rst_n !== 1'b1) begin
          foreach (bank_active[i]) bank_active[i] = 0;
          prev_cs = 0;
          continue;
        end
        // publish once per command: on cs rise or CA change while selected
        if (vif.mon_cb.cs && (!prev_cs || vif.mon_cb.ca != prev_ca)) begin
          item = lpddr_seq_item::type_id::create("item");
          item.ca   = vif.mon_cb.ca;
          item.bank = vif.mon_cb.ca[2:0];
          item.page_hit = 1'b0;
          casez (vif.mon_cb.ca)
            6'b000???: item.cmd_type = lpddr_seq_item::MRW;
            6'b001???: item.cmd_type = lpddr_seq_item::MRR;
            6'b010???: item.cmd_type = lpddr_seq_item::ACT;
            6'b011???: item.cmd_type = lpddr_seq_item::PRE;
            6'b100???: item.cmd_type = lpddr_seq_item::READ;
            6'b101???: item.cmd_type = lpddr_seq_item::WRITE;
            6'b110000: item.cmd_type = lpddr_seq_item::REF;
            6'b110001: item.cmd_type = lpddr_seq_item::SRE;
            6'b110010: item.cmd_type = lpddr_seq_item::SRX;
            6'b110011: item.cmd_type = lpddr_seq_item::MST;
            6'b110100: item.cmd_type = lpddr_seq_item::PDE;
            6'b110101: item.cmd_type = lpddr_seq_item::PDX;
            default:   item.cmd_type = lpddr_seq_item::MST;
          endcase
          id = item.bank;
          case (item.cmd_type)
            lpddr_seq_item::ACT: begin
              item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
              bank_active[id] = 1;
              active_row[id]  = item.addr;
              accessed[id]    = 0;
            end
            lpddr_seq_item::READ, lpddr_seq_item::WRITE: begin
              item.bstate    = bank_active[id] ? B_ACTIVE : B_IDLE;
              // page hit: the open row was accessed before; miss: first access after ACT
              item.page_hit  = bank_active[id] && accessed[id];
              accessed[id]   = 1;
              item.burst_len = 8;   // the device's burst (BL8, as the memory model transfers)
            end
            lpddr_seq_item::PRE: begin
              item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
              bank_active[id] = 0;
            end
            lpddr_seq_item::REF: begin
              item.bstate = B_IDLE;
              foreach (bank_active[i]) bank_active[i] = 0;
            end
            default: item.bstate = B_IDLE;
          endcase
          begin
            txn_count++;
            item_collected_port.write(item);
            `uvm_info(get_type_name(),
              $sformatf("Monitored: %s", item.convert2string()), UVM_MEDIUM)
          end
        end
        prev_ca = vif.mon_cb.ca;
        prev_cs = vif.mon_cb.cs;
      end
    endtask

    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(),
        $sformatf("LPDDR monitor observed %0d transactions", txn_count), UVM_LOW)
    endfunction
  endclass : lpddr_monitor

  //==========================================================================
  // LPDDR Agent
  //==========================================================================
  class lpddr_agent extends uvm_agent;
    `uvm_component_utils(lpddr_agent)
    lpddr_sequencer sqr;
    lpddr_driver    drv;
    lpddr_monitor   mon;
    lpddr_cfg       cfg;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(lpddr_cfg)::get(this, "", "cfg", cfg))
        cfg = lpddr_cfg::type_id::create("cfg");
      mon = lpddr_monitor::type_id::create("mon", this);
      if (cfg.is_active == UVM_ACTIVE) begin
        sqr = lpddr_sequencer::type_id::create("sqr", this);
        drv = lpddr_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.is_active == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass : lpddr_agent

  //==========================================================================
  // Directed sequence library (normal R/W, refresh, bank conflict,
  // back-to-back, page hit/miss corner cases, stress, regression)
  //==========================================================================
  class lpddr_base_seq extends uvm_sequence #(lpddr_seq_item);
    `uvm_object_utils(lpddr_base_seq)
    rand int num_trans = 20;
    rand bit [15:0] row;
    rand bit [15:0] col;
    rand bit [2:0]  chan_n;
    rand bit [2:0]  bank_n;
    rand bit        rd_not_wr;
    constraint c_col { col[2:0] == 3'b000; }
    
    function new(string name = "lpddr_base_seq");
      super.new(name);
    endfunction
    // issue one command item with explicit geometry
    task issue(lpddr_seq_item::cmd_type_e c, bit [15:0] a, bit [2:0] ch, bit [2:0] b);
      lpddr_seq_item item = lpddr_seq_item::type_id::create("item");
      start_item(item);
      // the command is fixed: drop the dist (Verilator 5.052 reports a dist
      // plus an inline == on the same variable as unsatisfiable)
      item.c_cmd_dist.constraint_mode(0);
      if (!(item.randomize() with { cmd_type == c; addr == a; bank == b; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    endtask
    // random-but-legal ACT -> RD/WR -> PRE rounds, REF every 8th round
    task body();
      for (int i = 0; i < num_trans; i++) begin
        if (!(this.randomize(row, col, chan_n, bank_n, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
        if (i % 8 == 7) issue(lpddr_seq_item::REF, 16'h0, 3'h0, 3'h0);
        issue(lpddr_seq_item::ACT, row, chan_n, bank_n);
        issue(rd_not_wr ? lpddr_seq_item::READ : lpddr_seq_item::WRITE, col, chan_n, bank_n);
        issue(lpddr_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // Legacy random read/write mix (kept API): legal rounds
  class lpddr_rw_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_rw_seq)
    function new(string name = "lpddr_rw_seq");
      super.new(name);
      num_trans = 30;
    endfunction
  endclass

  // 1) Directed: write rounds (normal write traffic)
  class lpddr_write_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_write_seq)
    function new(string name = "lpddr_write_seq");
      super.new(name);
    endfunction
    constraint c_wr { rd_not_wr == 0; }
  endclass

  // 2) Directed: read rounds (normal read traffic)
  class lpddr_read_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_read_seq)
    function new(string name = "lpddr_read_seq");
      super.new(name);
    endfunction
    constraint c_rd { rd_not_wr == 1; }
  endclass

  // 3) Directed: refresh traffic
  class lpddr_refresh_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_refresh_seq)
    function new(string name = "lpddr_refresh_seq");
      super.new(name);
    endfunction
    task body();
      for (int i = 0; i < num_trans; i++)
        issue(lpddr_seq_item::REF, 16'h0, 3'h0, 3'h0);
    endtask
  endclass

  // 4) Directed: bank conflict -- repeated ACT to the SAME bank forces
  //    PRE/ACT turnaround (tRP + tRCD pressure)
  class lpddr_bank_conflict_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_bank_conflict_seq)
    function new(string name = "lpddr_bank_conflict_seq");
      super.new(name);
    endfunction
    task body();
      lpddr_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a lpddr_base_seq handle
      bit [15:0] crow = 16'h0100;
      if (!(rnd_h.randomize(chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
      for (int i = 0; i < num_trans; i++) begin
        issue(lpddr_seq_item::ACT, crow, chan_n, bank_n);
        issue(lpddr_seq_item::WRITE, 16'h0, chan_n, bank_n);
        issue(lpddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h100;
      end
    endtask
  endclass

  // 5) Directed: back-to-back accesses across 4 banks (no PRE between)
  class lpddr_back_to_back_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_back_to_back_seq)
    function new(string name = "lpddr_back_to_back_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h2000;
      for (int i = 0; i < num_trans; i++) begin
        for (int b = 0; b < 4; b++)
          issue(lpddr_seq_item::ACT, crow, chan_n, b[2:0]);
        for (int b = 0; b < 4; b++) begin
          issue(lpddr_seq_item::WRITE, 16'h0, chan_n, b[2:0]);
          issue(lpddr_seq_item::READ, 16'h0, chan_n, b[2:0]);
        end
        for (int b = 0; b < 4; b++)
          issue(lpddr_seq_item::PRE, 16'h0, chan_n, b[2:0]);
        crow = crow + 16'h400;
      end
    endtask
  endclass

  // 6) Corner case: page hit -- one ACT, many RD/WR to the SAME open row
  class lpddr_page_hit_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_page_hit_seq)
    function new(string name = "lpddr_page_hit_seq");
      super.new(name);
    endfunction
    task body();
      lpddr_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a lpddr_base_seq handle
      for (int i = 0; i < num_trans; i++) begin
        if (!(rnd_h.randomize(row, chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
        issue(lpddr_seq_item::ACT, row, chan_n, bank_n);
        for (int k = 0; k < 4; k++) begin
          if (!(rnd_h.randomize(col, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
          issue(rd_not_wr ? lpddr_seq_item::READ : lpddr_seq_item::WRITE, col, chan_n, bank_n);
        end
        issue(lpddr_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // 7) Corner case: page miss -- every access targets a different row
  class lpddr_page_miss_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_page_miss_seq)
    function new(string name = "lpddr_page_miss_seq");
      super.new(name);
    endfunction
    task body();
      lpddr_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a lpddr_base_seq handle
      bit [15:0] crow = 16'h0;
      if (!(rnd_h.randomize(chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
      for (int i = 0; i < num_trans; i++) begin
        if (!(rnd_h.randomize(col, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
        issue(lpddr_seq_item::ACT, crow, chan_n, bank_n);
        issue(rd_not_wr ? lpddr_seq_item::READ : lpddr_seq_item::WRITE, col, chan_n, bank_n);
        issue(lpddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h311;
      end
    endtask
  endclass

  // 8) Stress: long legal mix of rounds
  class lpddr_stress_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_stress_seq)
    function new(string name = "lpddr_stress_seq");
      super.new(name);
      num_trans = 200;
    endfunction
  endclass

  // Regression: weighted mix of every directed sequence
  class lpddr_regression_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_regression_seq)
    function new(string name = "lpddr_regression_seq");
      super.new(name);
    endfunction
    task body();
      lpddr_write_seq         wr   = lpddr_write_seq::type_id::create("wr");
      lpddr_read_seq          rd   = lpddr_read_seq::type_id::create("rd");
      lpddr_refresh_seq       refs = lpddr_refresh_seq::type_id::create("refs");
      lpddr_bank_conflict_seq bc   = lpddr_bank_conflict_seq::type_id::create("bc");
      lpddr_back_to_back_seq  b2b  = lpddr_back_to_back_seq::type_id::create("b2b");
      lpddr_page_hit_seq      hit  = lpddr_page_hit_seq::type_id::create("hit");
      lpddr_page_miss_seq     miss = lpddr_page_miss_seq::type_id::create("miss");
      wr.num_trans   = 10; rd.num_trans   = 10;
      refs.num_trans = 4;  bc.num_trans   = 5;
      b2b.num_trans  = 4;  hit.num_trans  = 4;
      miss.num_trans = 5;
      wr.start(m_sequencer);
      rd.start(m_sequencer);
      hit.start(m_sequencer);
      miss.start(m_sequencer);
      bc.start(m_sequencer);
      b2b.start(m_sequencer);
      refs.start(m_sequencer);
    endtask
  endclass

  //==========================================================================
  // Legacy directed coverage sequences (kept API)
  //==========================================================================
  class lpddr_cov_cmd_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_cov_cmd_seq)
    function new(string name = "lpddr_cov_cmd_seq");
      super.new(name);
    endfunction
    task body();
      lpddr_seq_item item;
      lpddr_seq_item::cmd_type_e cmds[12] = '{lpddr_seq_item::MRR, lpddr_seq_item::MRW, lpddr_seq_item::READ, lpddr_seq_item::WRITE, lpddr_seq_item::MST, lpddr_seq_item::SRE,
                                             lpddr_seq_item::SRX, lpddr_seq_item::PDE, lpddr_seq_item::PDX, lpddr_seq_item::ACT, lpddr_seq_item::PRE, lpddr_seq_item::REF};
      foreach (cmds[i]) begin
        item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        item.c_cmd_dist.constraint_mode(0);
        if (!item.randomize() with { cmd_type == cmds[i]; })
          `uvm_error(get_type_name(), "Rand failed")
        finish_item(item);
      end
    endtask
  endclass : lpddr_cov_cmd_seq

  class lpddr_cov_bank_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_cov_bank_seq)
    function new(string name = "lpddr_cov_bank_seq");
      super.new(name);
    endfunction
    task body();
      for (int b = 0; b < 8; b++) begin
        issue(lpddr_seq_item::ACT, 16'h100 * (b + 1), 3'h0, b[2:0]);
        issue(lpddr_seq_item::WRITE, 16'h0, 3'h0, b[2:0]);
        issue(lpddr_seq_item::READ, 16'h0, 3'h0, b[2:0]);
        issue(lpddr_seq_item::PRE, 16'h0, 3'h0, b[2:0]);
      end
    endtask
  endclass : lpddr_cov_bank_seq
endpackage : lpddr_pkg
