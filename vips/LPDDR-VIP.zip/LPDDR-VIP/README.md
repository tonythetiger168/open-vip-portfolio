# LPDDR UVM VIP

**Protocol:** LPDDR4/5/6 SDRAM
**License:** Apache-2.0

## 1. Protocol Overview

LPDDR4/5/6 low-power DRAM VIP. Commands travel on the shared 6-bit CA bus (cs active high); the driver issues ACT/RD/WR/PRE/REF/MRR/MRW/self-refresh/power-down with timing.

Timing parameters (cycles): tRCD=18, tRP=18, tRAS=42,
tCL=22, tCWL=11, tFAW=24, tRFC=42.

## 2. Architecture

```
interfaces/memory_interfaces.sv   9 memory protocol interfaces (lpddr_if is the DUT-side bus)
lpddr/lpddr_pkg.sv                    LPDDR VIP package:
    lpddr_seq_item                  transaction (cmd/addr/bank/data + page_hit/bstate)
    lpddr_cfg                       timing + mode configuration
    lpddr_sequencer / lpddr_driver    command driver (timing-accurate, drv_ap broadcast)
    lpddr_monitor                   CA-bus command decoder (analysis port)
    lpddr_agent                     sequencer + driver + monitor
    sequences                     directed library (below)
coverage/memory_coverage_pkg.sv   LPDDR functional coverage (3 covergroups + crosses)
env/memory_env_pkg.sv             memory_env_cfg / memory_scoreboard / memory_env
                                  end-to-end: driver drv_ap (expected) vs
                                  monitor item_collected_port (observed),
                                  n_matches/n_mismatches, UVM_ERROR on mismatch
env/vip/lpddr/lpddr_*_checker.sv      legacy L1/L2/L3 SVA checkers (module-based)
env/sva/lpddr_compliance_checker.sv consolidated L1-L4 compliance checker
test/memory_test_pkg.sv           memory_base_test / memory_directed_test /
                                  memory_coverage_regression_test
tb_top.sv                         testbench top: 9 protocol interfaces, LPDDR DRAM
                                  memory model (bank/row/col storage + refresh
                                  counter), SVA checker instantiation
```

The `tb_top.sv` DRAM model tracks bank/row state, stores write data in a
sparse `{bank,row,col}` array, returns it on reads after tCL, and counts
refreshes -- closing the end-to-end data loop.

## 3. Sequence Library

| `lpddr_base_seq`          | randomized legal ACT->RD/WR->PRE rounds |
| `lpddr_rw_seq`            | legacy random R/W mix (kept API) |
| `lpddr_write_seq`         | directed write rounds |
| `lpddr_read_seq`          | directed read rounds |
| `lpddr_refresh_seq`       | refresh traffic |
| `lpddr_bank_conflict_seq` | same-bank ACT/PRE turnaround (tRP/tRCD pressure) |
| `lpddr_back_to_back_seq`  | inter-bank back-to-back accesses |
| `lpddr_page_hit_seq`      | corner: multiple accesses to one open row |
| `lpddr_page_miss_seq`     | corner: every access forces PRE+ACT |
| `lpddr_stress_seq`        | long randomized legal mix |
| `lpddr_regression_seq`    | weighted mix of all directed sequences |

Legacy coverage sequences: `lpddr_cov_cmd_seq`, `lpddr_cov_bank_seq`.

## 4. SVA Checkers (L1-L4)

Legacy tiered checkers (module-based, `env/vip/lpddr/`):
- `lpddr_protocol_checker` (L1: basic compliance)
- `lpddr_timing_checker` (L2: timing windows)
- `lpddr_data_integrity_checker` (L2/L3: data rules)
- `lpddr_error_checker` (L3: error conditions)

Consolidated `lpddr_compliance_checker` keeps the tiered L1/L2/L3 rule sets with
pass/fail counters and adds:
- **L4 (6):** tRCD (ACT->CAS), tRAS (ACT->PRE), tFAW (<=4 ACT/window),
  RD/WR only to open bank, no ACT to an already-open bank,
  refresh interval (tREFI) -- plus ACT->CAS / full-cycle covers.

## 5. Functional Coverage

- `lpddr_cmd_cg`        : command distribution x bank geometry (crosses)
- `lpddr_bank_state_cg` : bank state transitions (IDLE/ACTIVE) x command (cross)
- `lpddr_addr_cg`       : row regions, page hit/miss x command (cross)

## 6. Quick Start

```bash
# Portable multi-simulator flow (VCS / Xcelium / Questa)
make -C scripts SIMULATOR=vcs TEST=memory_directed_test
# or use the wrapper
./run.sh TESTNAME=memory_directed_test
```

Tests: `memory_base_test` (default), `memory_directed_test`,
`memory_coverage_regression_test`.
