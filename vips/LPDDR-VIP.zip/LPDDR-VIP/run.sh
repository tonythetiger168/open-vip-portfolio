#!/bin/bash
# LPDDR Memory UVM VIP regression launcher
TESTNAME=${TESTNAME:-memory_directed_test}
SEED=${SEED:-$RANDOM}
SIMULATOR=${SIMULATOR:-xrun}
echo "========================================"
echo "  LPDDR Memory UVM VIP Framework"
echo "  Test: $TESTNAME"
echo "  Seed: $SEED"
echo "  Simulator: $SIMULATOR"
echo "========================================"
SV_FILES=(
    interfaces/memory_interfaces.sv
    lpddr/lpddr_pkg.sv
    coverage/memory_coverage_pkg.sv
    env/memory_env_pkg.sv
    lpddr/sva/lpddr_compliance_checker.sv
    lpddr/vip/lpddr/lpddr_protocol_checker.sv lpddr/vip/lpddr/lpddr_data_integrity_checker.sv lpddr/vip/lpddr/lpddr_timing_checker.sv lpddr/vip/lpddr/lpddr_error_checker.sv
    test/memory_test_pkg.sv
    tb_top.sv
)
FLIST=$(IFS=' '; echo ${SV_FILES[*]})
case $SIMULATOR in
    xrun)  xrun -uvm -sv $FLIST +UVM_TESTNAME=$TESTNAME +ntb_random_seed=$SEED \
           -timescale 1ns/1ps -access +rw -l sim.log ;;
    vcs)   vcs -sverilog -ntb_opts uvm $FLIST -timescale=1ns/1ps -l comp.log && \
           ./simv +UVM_TESTNAME=$TESTNAME +ntb_random_seed=$SEED -l sim.log ;;
    vsim)  vlib work && vlog -sv $FLIST && \
           vsim -c tb_top -sv_seed $SEED +UVM_TESTNAME=$TESTNAME \
                -do "run -all; quit" -l sim.log ;;
    *)     echo "Unknown simulator: $SIMULATOR"; exit 1 ;;
esac
echo "========================================"
echo "  Simulation Complete"
echo "  Test: $TESTNAME"
echo "========================================"
