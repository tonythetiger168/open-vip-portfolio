// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_mem_tb.sv -- self-checking functional test for the DDR5 memory model
// (ddr5_mem_model, flattened by smoke/flatten.py). Run: python3 tools/run_func_tests.py ddr5-VIP
//
// Model contract (from ddr5-VIP/ddr5_vip/tb/tb_top.sv):
//   ACT (act_n=0) latches the row of bank bg*4+ba; WR/RD are ras_n=1,cas_n=0,
//   we_n=0/1; PRE is ras_n=0,cas_n=1,we_n=0; REF is ras_n=0,cas_n=0,we_n=1.
//   WR/RD start a 16-beat burst at column c, beat i at column c+8*i. Write
//   beat 0 is sampled TCWL=20 clocks after the command, read beat 0 is
//   driven TCL=22 clocks after it; one beat per clock.
// dq is a variable shared by the model and the controller in the original
// interface, so the test writes it hierarchically (u_dut.vif_dq) exactly as
// the UVM driver writes vif.dq.

module func_mem_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int TCL = 22, TCWL = 20, BL = 16, DW = 64;
  int checks = 0, fails = 0;

  logic ck = 1'b0, rst_n = 1'b0;
  logic cs_n = 1'b1, act_n = 1'b1, ras_n = 1'b1, cas_n = 1'b1, we_n = 1'b1;
  logic [15:0] addr = '0;
  logic [2:0] bg = '0;
  logic [1:0] ba = '0;
  wire [DW-1:0] dq;
  // idle value the test parks on the shared dq variable between bursts
  // (Verilator cannot write Z through a hierarchical reference)
  localparam [DW-1:0] IDLE = {(DW/16){16'hD1E5}};

  always #5 ck = ~ck;

  ddr5_mem_model u_dut (
    .vif_ck(ck), .vif_rst_n(rst_n), .vif_cs_n(cs_n), .vif_act_n(act_n),
    .vif_ras_n(ras_n), .vif_cas_n(cas_n), .vif_we_n(we_n), .vif_addr(addr),
    .vif_bg(bg), .vif_ba(ba), .vif_dq(dq)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one command cycle: drive at negedge, sampled at the next posedge (P0),
  // returns at the following negedge (N0)
  task automatic cmd(input bit a_n, input bit r_n, input bit c_n, input bit w_n,
                     input int b, input [15:0] ad, input bit sel = 1'b1);
    @(negedge ck);
    cs_n = !sel; act_n = a_n; ras_n = r_n; cas_n = c_n; we_n = w_n;
    {bg, ba} = 5'(b);    // bank index = bg*4 + ba
    addr = ad;
    @(posedge ck);
    @(negedge ck);
    cs_n = 1'b1; act_n = 1'b1; ras_n = 1'b1; cas_n = 1'b1; we_n = 1'b1;
  endtask
  task automatic act(input int b, input [15:0] row); cmd(0, 1, 1, 1, b, row); endtask
  task automatic pre(input int b);                   cmd(1, 0, 1, 0, b, '0); endtask
  task automatic refresh();                          cmd(1, 0, 0, 1, 0, '0); endtask
  task automatic issue_wr(input int b, input [15:0] col, input bit sel); cmd(1, 1, 0, 0, b, col, sel); endtask
  task automatic issue_rd(input int b, input [15:0] col);                cmd(1, 1, 0, 1, b, col); endtask

  // beat i of the burst pattern seeded by s
  function automatic [DW-1:0] pat(input [15:0] s, input int i);
    return {(DW/64 > 1 ? DW/64 : 1){s, 16'(i), ~s, 16'(i * 3 + 1)}};
  endfunction

  // burst write; a garbage word sits on dq the clock before TCWL so an early
  // sample would be detected
  task automatic wr(input int b, input [15:0] col, input [15:0] s, input bit sel = 1'b1);
    issue_wr(b, col, sel);                     // returns at N0
    repeat (TCWL - 2) @(negedge ck);
    u_dut.vif_dq = '1;
    for (int i = 0; i < BL; i++) begin
      @(negedge ck);
      u_dut.vif_dq = pat(s, i);                // sampled at P(TCWL + i)
    end
    @(negedge ck);
    u_dut.vif_dq = IDLE;
  endtask

  // burst read into q[]; early = dq one clock before beat 0
  logic [DW-1:0] q [BL];
  logic [DW-1:0] early, after;
  task automatic rd(input int b, input [15:0] col);
    u_dut.vif_dq = IDLE;
    issue_rd(b, col);                          // returns at N0
    repeat (TCL - 1) @(negedge ck);
    early = dq;
    for (int i = 0; i < BL; i++) begin
      @(negedge ck);
      q[i] = dq;
    end
    @(negedge ck);
    after = dq;
  endtask

  // dq left untouched for n clocks (no burst started)
  task automatic watch_quiet(input int n, output bit ok);
    ok = 1;
    for (int i = 0; i < n; i++) begin
      @(negedge ck);
      if (dq !== IDLE) ok = 0;
    end
  endtask

  // reference of every written beat: {bank, row, col} -> data
  logic [DW-1:0] ref_m [bit [36:0]];
  function automatic bit burst_ok(input int b, input [15:0] row, input [15:0] col);
    for (int i = 0; i < BL; i++) begin
      bit [36:0] k;
      k = {5'(b), row, 16'(col + 8 * i)};
      if (q[i] !== (ref_m.exists(k) ? ref_m[k] : '0)) return 0;
    end
    return 1;
  endfunction

  function automatic bit burst_is(input [15:0] s, input int shift);
    for (int i = 0; i < BL; i++) begin
      if (i + shift < BL) begin
        if (q[i] !== pat(s, i + shift)) return 0;
      end else if (q[i] !== '0) return 0;
    end
    return 1;
  endfunction

  function automatic bit all_zero();
    for (int i = 0; i < BL; i++) if (q[i] !== '0) return 0;
    return 1;
  endfunction

  initial begin
    u_dut.vif_dq = IDLE;
    repeat (2) @(posedge ck);
    // a write issued while reset is asserted must be ignored
    act(0, 16'h0007);
    wr(0, 16'h0000, 16'h0BAD);
    rst_n = 1'b1;
    repeat (2) @(posedge ck);

    act(0, 16'h0011);
    wr(0, 16'h0000, 16'h1111);
    rd(0, 16'h0000);
    chk(burst_is(16'h1111, 0), "burst write reads back beat-for-beat in order");
    chk(early === IDLE, "read data not driven before TCL");
    chk(after === q[BL-1], "read data not driven past the 16-beat burst");

    // a read starting one burst column later returns the tail of the burst
    rd(0, 16'h0008);
    chk(burst_is(16'h1111, 1), "burst column mapping: col+8 starts at beat 1");
    // unwritten region reads zero
    rd(0, 16'h0400);
    chk(all_zero(), "unwritten columns read 0");

    // overwrite
    wr(0, 16'h0000, 16'h2222);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "second burst overwrites the first");

    // bank independence
    act(1, 16'h0011);
    wr(1, 16'h0000, 16'h3333);
    act(22, 16'h0011);
    wr(22, 16'h0000, 16'h4444);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "bank 0 unaffected by other banks");
    rd(1, 16'h0000);
    chk(burst_is(16'h3333, 0), "bank 1 holds its own burst");
    rd(22, 16'h0000);
    chk(burst_is(16'h4444, 0), "bank group 5 / bank 2 holds its own burst");

    // row isolation and retention across PRE / ACT
    pre(0);
    act(0, 16'h0022);
    rd(0, 16'h0000);
    chk(all_zero(), "other row of same bank does not alias");
    wr(0, 16'h0000, 16'h5555);
    pre(0);
    act(0, 16'h0011);
    rd(0, 16'h0000);
    chk(burst_is(16'h2222, 0), "row data retained across PRE/ACT");

    // refresh must not disturb stored data
    refresh();
    act(0, 16'h0022);
    rd(0, 16'h0000);
    chk(burst_is(16'h5555, 0), "data retained across REFRESH");

    // deselected write ignored
    wr(0, 16'h0000, 16'h6666, 1'b0);
    rd(0, 16'h0000);
    chk(burst_is(16'h5555, 0), "write while chip deselected is ignored");

    // write during reset did not land
    act(3, 16'h0007);
    rd(3, 16'h0000);
    chk(all_zero(), "command during reset had no effect");

    // REFRESH and a selected NOP must not start a read burst
    begin
      bit ok1, ok2;
      u_dut.vif_dq = IDLE;
      refresh();
      watch_quiet(TCL + BL + 4, ok1);
      cmd(1, 1, 1, 1, 0, '0);                  // NOP with CS_n low
      watch_quiet(TCL + BL + 4, ok2);
      chk(ok1 && ok2, "REFRESH / selected NOP do not drive dq");
    end

    // random bursts over 4 banks x 2 rows, overlapping columns
    begin
      int bad;
      bit [15:0] rows [4];
      bad = 0;
      for (int b = 0; b < 4; b++) begin rows[b] = 16'h0100; act(8 * b, rows[b]); end
      for (int t = 0; t < 24; t++) begin
        int b;
        bit [15:0] col, s;
        b = $urandom_range(3);
        if ($urandom_range(3) == 0) begin
          pre(8 * b);
          rows[b] = rows[b] ^ 16'h0001;
          act(8 * b, rows[b]);
        end
        col = 16'(8 * $urandom_range(40));
        if ($urandom_range(1)) begin
          s = $urandom;
          wr(8 * b, col, s);
          for (int i = 0; i < BL; i++) ref_m[{5'(8 * b), rows[b], 16'(col + 8 * i)}] = pat(s, i);
        end else begin
          rd(8 * b, col);
          if (!burst_ok(8 * b, rows[b], col)) bad++;
        end
      end
      chk(bad == 0, "24 random bursts on 4 banks / 2 rows match the reference");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
