// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR5 Protocol Compliance Checker (L1)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR5_PROTOCOL_CHECKER_SV
`define DDR5_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr5_protocol_checker (ddr5_if vif);

  property p_ddr5_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_ddr5_cmd_valid: assert property(p_ddr5_cmd_valid) else `uvm_warning("DDR5_L1", "Command valid when CS active failed");
  cover_p_ddr5_cmd_valid: cover property(p_ddr5_cmd_valid);
  property p_ddr5_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_ddr5_addr_valid: assert property(p_ddr5_addr_valid) else `uvm_warning("DDR5_L1", "Address valid failed");
  cover_p_ddr5_addr_valid: cover property(p_ddr5_addr_valid);
  property p_ddr5_bg; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bg <= 2'd3; endproperty
  assert_p_ddr5_bg: assert property(p_ddr5_bg) else `uvm_warning("DDR5_L1", "Bank group 0-3 failed");
  cover_p_ddr5_bg: cover property(p_ddr5_bg);
  property p_ddr5_ba; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ba <= 2'd3; endproperty
  assert_p_ddr5_ba: assert property(p_ddr5_ba) else `uvm_warning("DDR5_L1", "Bank address 0-3 failed");
  cover_p_ddr5_ba: cover property(p_ddr5_ba);

endmodule : ddr5_protocol_checker
`endif
