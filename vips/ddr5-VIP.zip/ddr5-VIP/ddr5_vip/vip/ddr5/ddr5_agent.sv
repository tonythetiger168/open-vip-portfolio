// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR5 UVM agent -- sequencer + driver + monitor
`ifndef DDR5_AGENT_SV
`define DDR5_AGENT_SV

import uvm_pkg::*;
typedef class ddr5_driver;
typedef class ddr5_monitor;

class ddr5_sequencer extends uvm_sequencer #(ddr5_transaction);
  `uvm_component_utils(ddr5_sequencer)
  function new(string name = "ddr5_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

class ddr5_agent extends uvm_agent;
  `uvm_component_utils(ddr5_agent)
  ddr5_sequencer sqr;
  ddr5_driver    drv;
  ddr5_monitor   mon;

  function new(string name = "ddr5_agent", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    mon = ddr5_monitor::type_id::create("mon", this);
    if (is_active == UVM_ACTIVE) begin
      sqr = ddr5_sequencer::type_id::create("sqr", this);
      drv = ddr5_driver::type_id::create("drv", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (is_active == UVM_ACTIVE)
      drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
