// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR5 Timing Performance Checker (L2)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR5_TIMING_CHECKER_SV
`define DDR5_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr5_timing_checker (ddr5_if vif);

  property p_ddr5_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[14:18] $fell(vif.cas_n); endproperty
  assert_p_ddr5_tRCD: assert property(p_ddr5_tRCD) else `uvm_warning("DDR5_TIM", "tRCD 14-18 cycles violated");
  cover_p_ddr5_tRCD: cover property(p_ddr5_tRCD);
  property p_ddr5_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.act_n) |-> ##[14:18] $fell(vif.act_n); endproperty
  assert_p_ddr5_tRP: assert property(p_ddr5_tRP) else `uvm_warning("DDR5_TIM", "tRP 14-18 cycles violated");
  cover_p_ddr5_tRP: cover property(p_ddr5_tRP);
  property p_ddr5_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[32:39] $rose(vif.act_n); endproperty
  assert_p_ddr5_tRAS: assert property(p_ddr5_tRAS) else `uvm_warning("DDR5_TIM", "tRAS 32-39 cycles violated");
  cover_p_ddr5_tRAS: cover property(p_ddr5_tRAS);
  property p_ddr5_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cas_n) && vif.we_n == 1 |-> ##[22:28] vif.dqs_t == 1; endproperty
  assert_p_ddr5_tCL: assert property(p_ddr5_tCL) else `uvm_warning("DDR5_TIM", "tCL 22-28 cycles violated");
  cover_p_ddr5_tCL: cover property(p_ddr5_tCL);

endmodule : ddr5_timing_checker
`endif
