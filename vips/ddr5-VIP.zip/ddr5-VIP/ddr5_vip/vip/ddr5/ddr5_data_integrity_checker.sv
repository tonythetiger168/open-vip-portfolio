// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR5 Data Integrity Checker (L2)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR5_DATA_INTEGRITY_CHECKER_SV
`define DDR5_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr5_data_integrity_checker (ddr5_if vif);

  property p_ddr5_bl; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {4'b1000,4'b1001}; endproperty
  assert_p_ddr5_bl: assert property(p_ddr5_bl) else `uvm_warning("DDR5_L2", "Burst length 8/16 failed");
  cover_p_ddr5_bl: cover property(p_ddr5_bl);
  property p_ddr5_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[14:18] $fell(vif.cas_n); endproperty
  assert_p_ddr5_tRCD: assert property(p_ddr5_tRCD) else `uvm_warning("DDR5_L2", "tRCD 14-18 cycles failed");
  cover_p_ddr5_tRCD: cover property(p_ddr5_tRCD);
  property p_ddr5_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.act_n) |-> ##[14:18] $fell(vif.act_n); endproperty
  assert_p_ddr5_tRP: assert property(p_ddr5_tRP) else `uvm_warning("DDR5_L2", "tRP 14-18 cycles failed");
  cover_p_ddr5_tRP: cover property(p_ddr5_tRP);
  property p_ddr5_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.act_n) |-> ##[32:39] $rose(vif.act_n); endproperty
  assert_p_ddr5_tRAS: assert property(p_ddr5_tRAS) else `uvm_warning("DDR5_L2", "tRAS 32-39 cycles failed");
  cover_p_ddr5_tRAS: cover property(p_ddr5_tRAS);
  property p_ddr5_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cas_n) && vif.we_n == 1 |-> ##[22:28] vif.dqs_t == 1; endproperty
  assert_p_ddr5_tCL: assert property(p_ddr5_tCL) else `uvm_warning("DDR5_L2", "tCL 22-28 cycles failed");
  cover_p_ddr5_tCL: cover property(p_ddr5_tCL);
  property p_ddr5_odt; @(posedge vif.ck) disable iff (!vif.rst_n) vif.we_n == 0 && vif.cs_n == 0 |-> vif.odt == 1; endproperty
  assert_p_ddr5_odt: assert property(p_ddr5_odt) else `uvm_warning("DDR5_L2", "ODT during write failed");
  cover_p_ddr5_odt: cover property(p_ddr5_odt);
  property p_ddr5_dbim; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dbim inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ddr5_dbim: assert property(p_ddr5_dbim) else `uvm_warning("DDR5_L2", "DBI mode valid failed");
  cover_p_ddr5_dbim: cover property(p_ddr5_dbim);
  property p_ddr5_crc; @(posedge vif.ck) disable iff (!vif.rst_n) vif.crc_en == 1 && vif.we_n == 0 |-> vif.crc != 8'h00; endproperty
  assert_p_ddr5_crc: assert property(p_ddr5_crc) else `uvm_warning("DDR5_L2", "CRC on write failed");
  cover_p_ddr5_crc: cover property(p_ddr5_crc);

endmodule : ddr5_data_integrity_checker
`endif
