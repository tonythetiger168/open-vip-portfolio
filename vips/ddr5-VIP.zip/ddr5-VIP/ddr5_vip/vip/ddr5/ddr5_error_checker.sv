// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR5 Error Handling Checker (L3)
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR5_ERROR_CHECKER_SV
`define DDR5_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr5_error_checker (ddr5_if vif);

  property p_ddr5_pm; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ddr5_pm: assert property(p_ddr5_pm) else `uvm_warning("DDR5_L3", "Power management failed");
  cover_p_ddr5_pm: cover property(p_ddr5_pm);
  property p_ddr5_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.refresh |-> ##[1:3900] vif.cs_n == 0; endproperty
  assert_p_ddr5_refresh: assert property(p_ddr5_refresh) else `uvm_warning("DDR5_L3", "Refresh interval failed");
  cover_p_ddr5_refresh: cover property(p_ddr5_refresh);
  property p_ddr5_samebank; @(posedge vif.ck) disable iff (!vif.rst_n) vif.same_bank_ref |-> vif.bg == $past(vif.bg,1); endproperty
  assert_p_ddr5_samebank: assert property(p_ddr5_samebank) else `uvm_warning("DDR5_L3", "Same bank refresh failed");
  cover_p_ddr5_samebank: cover property(p_ddr5_samebank);
  property p_ddr5_wck; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ddr5_wck: assert property(p_ddr5_wck) else `uvm_warning("DDR5_L3", "WCK ratio failed");
  cover_p_ddr5_wck: cover property(p_ddr5_wck);
  property p_ddr5_dfe; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dfe_tap <= 4'd15; endproperty
  assert_p_ddr5_dfe: assert property(p_ddr5_dfe) else `uvm_warning("DDR5_L3", "DFE tap valid failed");
  cover_p_ddr5_dfe: cover property(p_ddr5_dfe);
  property p_ddr5_temp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp_sensor <= 8'd127; endproperty
  assert_p_ddr5_temp: assert property(p_ddr5_temp) else `uvm_warning("DDR5_L3", "Temperature sensor failed");
  cover_p_ddr5_temp: cover property(p_ddr5_temp);
  property p_ddr5_vrefca; @(posedge vif.ck) disable iff (!vif.rst_n) vif.vrefca_train |-> vif.cs_n == 0; endproperty
  assert_p_ddr5_vrefca: assert property(p_ddr5_vrefca) else `uvm_warning("DDR5_L3", "VrefCA training failed");
  cover_p_ddr5_vrefca: cover property(p_ddr5_vrefca);
  property p_ddr5_ca_parity; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ca_parity |-> ^vif.ca != 1'bx; endproperty
  assert_p_ddr5_ca_parity: assert property(p_ddr5_ca_parity) else `uvm_warning("DDR5_L3", "CA parity check failed");
  cover_p_ddr5_ca_parity: cover property(p_ddr5_ca_parity);

endmodule : ddr5_error_checker
`endif
