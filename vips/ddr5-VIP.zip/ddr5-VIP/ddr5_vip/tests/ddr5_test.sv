// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR5 UVM tests
`ifndef DDR5_TEST_SV
`define DDR5_TEST_SV

class ddr5_base_test extends uvm_test;
  `uvm_component_utils(ddr5_base_test)
  ddr5_env env;
  function new(string name = "ddr5_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = ddr5_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    ddr5_base_sequence seq;
    phase.raise_objection(this);
    seq = ddr5_base_sequence::type_id::create("seq");
    seq.num_transactions = 100;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed regression: every directed sequence in turn
class ddr5_directed_test extends ddr5_base_test;
  `uvm_component_utils(ddr5_directed_test)
  function new(string name = "ddr5_directed_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_phase(uvm_phase phase);
    ddr5_regression_seq seq;
    phase.raise_objection(this);
    seq = ddr5_regression_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress: long randomized command mix
class ddr5_stress_test extends ddr5_base_test;
  `uvm_component_utils(ddr5_stress_test)
  function new(string name = "ddr5_stress_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  task run_phase(uvm_phase phase);
    ddr5_stress_seq seq;
    phase.raise_objection(this);
    seq = ddr5_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
