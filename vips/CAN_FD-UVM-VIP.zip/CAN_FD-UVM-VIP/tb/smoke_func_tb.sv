// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (CAN-FD bit error detection and loopback)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened can_fd_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic rx = 1'b1;
  wire  tx;
  wire  [3:0] error_cnt;
  wire  stuff_err;

  always #5 clk = ~clk;

  can_fd_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .rx(rx), .tx(tx),
    .error_cnt(error_cnt), .stuff_err(stuff_err)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(tx === 1'b1, "tx recessive out of reset");
    chk(error_cnt === 4'h0 && stuff_err === 1'b0, "error state clean");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // idle bus stays recessive
    repeat (6) begin step(); chk(tx === 1'b1, "tx recessive while idle"); end

    // 8 consecutive dominant bits: stuff error pulse + counter
    begin : stuff
      bit seen = 0;
      @(negedge clk); rx = 1'b0;
      repeat (12) begin step(); if (stuff_err === 1'b1) seen = 1; end
      chk(seen, "stuff error pulse on 6+ dominant");
    end
    chk(error_cnt === 4'h1, "error counter incremented");
    @(negedge clk); rx = 1'b1;
    step();
    chk(stuff_err === 1'b0, "stuff error clears with recessive");

    // delayed loopback: dominant on rx shows on tx 4 cycles later
    begin : lb
      @(negedge clk); rx = 1'b0;
      repeat (3) step();
      chk(tx === 1'b1, "tx still recessive (IFS of delay pipe)");
      step(); step();
      chk(tx === 1'b0, "dominant propagated after delay");
      @(negedge clk); rx = 1'b1;
      repeat (6) begin step(); end
      chk(tx === 1'b1, "recessive restored after delay");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
