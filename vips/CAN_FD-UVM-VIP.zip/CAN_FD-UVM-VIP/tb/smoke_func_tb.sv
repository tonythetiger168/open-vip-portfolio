// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (CAN-FD DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened can_fd_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic rx = 1'b1;
  logic [3:0] nbt = 4'd1, dbt = 4'd1;      // DUT bit-time inputs
  int tn = 1, td = 1;                      // bit times the testbench drives
  logic pex_en = 1'b1;
  logic [28:0] acc_id = 29'h0, acc_msk = 29'h0;
  wire tx, rx_ok, rx_err, pex, err_pas, out_ide, out_fdf, out_brs, out_esi, out_rtr;
  wire [2:0] err_code;
  wire [7:0] rec;
  wire [28:0] out_id;
  wire [3:0] out_dlc;
  wire [6:0] out_len;
  wire [15:0] out_sum;

  always #5 clk = ~clk;

  can_fd_model u_dut (.clk(clk), .rst_n(rst_n), .rx(rx), .nbt(nbt), .dbt(dbt), .pex_en(pex_en), .acc_id(acc_id),
                      .acc_msk(acc_msk), .tx(tx), .rx_ok(rx_ok), .rx_err(rx_err), .pex(pex), .err_code(err_code),
                      .rec(rec), .err_pas(err_pas), .out_id(out_id), .out_ide(out_ide), .out_fdf(out_fdf),
                      .out_brs(out_brs), .out_esi(out_esi), .out_rtr(out_rtr), .out_dlc(out_dlc), .out_len(out_len),
                      .out_sum(out_sum));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [14:0] f15(input logic [14:0] c, input logic b);
    f15 = (b ^ c[14]) ? ((c << 1) ^ 15'h4599) : (c << 1);
  endfunction
  function automatic logic [16:0] f17(input logic [16:0] c, input logic b);
    f17 = (b ^ c[16]) ? ((c << 1) ^ 17'h1685B) : (c << 1);
  endfunction
  function automatic logic [20:0] f21(input logic [20:0] c, input logic b);
    f21 = (b ^ c[20]) ? ((c << 1) ^ 21'h102899) : (c << 1);
  endfunction
  function automatic int flen(input logic [3:0] d, input logic fd, input logic r);
    if (!fd) flen = r ? 0 : ((d > 8) ? 8 : d);
    else case (d)
      9: flen = 12;  10: flen = 16;  11: flen = 20;  12: flen = 24;
      13: flen = 32; 14: flen = 48;  15: flen = 64;
      default: flen = d;
    endcase
  endfunction

  logic lb [0:1023];               // line bits SOF .. CRC delimiter
  logic lf [0:1023];               // 1: data-phase bit
  int nl;
  int tsb;                         // index of a stuff bit after the last CRC15 bit (-1 none)
  logic [7:0] dat [0:63];
  logic [15:0] esum;               // sum of the frame's data bytes
  logic saw_ack, saw_ok, saw_err, saw_pex;
  int ntxlow, t_ok, t_err, cyc, ack_c;
  int adel_dom = 0, eof_dom = -1;  // trailer faults: dominant ACK delimiter / EOF bit

  task automatic fill(input int seed);
    for (int j = 0; j < 64; j++) dat[j] = (seed * 37 + j * 11 + (j >> 2)) ^ (j[0] ? 8'h5A : 8'hC3);
  endtask

  // err: 0 none, 1 stuff, 2 dominant CRC delimiter, 3 CRC, 4 stuff count, 5 fixed stuff bit, 6 res recessive
  task automatic build(input logic ide, input logic [28:0] id0, input logic rtr, input logic fdf, input logic brs,
                       input logic esi, input logic [3:0] dlc, input int err);
    logic a [0:700];
    logic f [0:31];
    logic [28:0] id;
    int na, n, run, nsb, nf, ncrc, brs_i, i, j;
    logic last, s, fst, dd;
    logic [14:0] c15;
    logic [16:0] c17;
    logic [20:0] c21, crc;
    logic [2:0] g;
    id = id0;
    if (err == 1) begin if (ide) id[28:25] = 4'h0; else id[10:7] = 4'h0; end
    na = 0; nl = 0; tsb = -1;
    a[na] = 0; na++;
    if (ide) begin
      for (i = 28; i >= 18; i--) begin a[na] = id[i]; na++; end
      a[na] = 1; a[na + 1] = 1; na += 2;
      for (i = 17; i >= 0; i--) begin a[na] = id[i]; na++; end
      a[na] = fdf ? 1'b0 : rtr; a[na + 1] = fdf; na += 2;
      if (!fdf) begin a[na] = 0; na++; end
    end else begin
      for (i = 10; i >= 0; i--) begin a[na] = id[i]; na++; end
      a[na] = fdf ? 1'b0 : rtr; a[na + 1] = 0; a[na + 2] = fdf; na += 3;
    end
    brs_i = -1;
    if (fdf) begin a[na] = (err == 6); a[na + 1] = brs; a[na + 2] = esi; brs_i = na + 1; na += 3; end
    for (i = 3; i >= 0; i--) begin a[na] = dlc[i]; na++; end
    n = flen(dlc, fdf, rtr);
    esum = 0;
    for (j = 0; j < n; j++) begin
      esum = esum + dat[j];
      for (i = 7; i >= 0; i--) begin a[na] = dat[j][i]; na++; end
    end
    if (!fdf) begin
      c15 = 0;
      for (i = 0; i < na; i++) c15 = f15(c15, a[i]);
      if (err == 3) c15[0] = !c15[0];
      for (i = 14; i >= 0; i--) begin a[na] = c15[i]; na++; end
    end
    last = 1; run = 0; nsb = 0; fst = 0; dd = 0;
    c17 = 17'h10000; c21 = 21'h100000;
    for (i = 0; i <= na; i++) begin
      if (run == 5 && (i < na || !fdf)) begin
        s = !last;
        if (err == 1 && !dd) begin s = last; dd = 1; end
        if (i == na) tsb = nl;
        lb[nl] = s; lf[nl] = fst; nl++;
        c17 = f17(c17, s); c21 = f21(c21, s); nsb++; last = s; run = 1;
      end
      if (i == na) break;
      lb[nl] = a[i]; lf[nl] = fst; nl++;
      c17 = f17(c17, a[i]); c21 = f21(c21, a[i]);
      if (a[i] == last) run++; else begin last = a[i]; run = 1; end
      if (i == brs_i && brs) fst = 1;
    end
    if (fdf) begin
      g = nsb[2:0] ^ (nsb[2:0] >> 1);
      f[0] = g[2]; f[1] = g[1]; f[2] = g[0]; f[3] = ^g; nf = 4;
      for (i = 0; i < 4; i++) begin c17 = f17(c17, f[i]); c21 = f21(c21, f[i]); end
      ncrc = (n <= 16) ? 17 : 21;
      crc = (ncrc == 17) ? {4'h0, c17} : c21;
      for (i = ncrc - 1; i >= 0; i--) begin f[nf] = crc[i]; nf++; end
      if (err == 4) f[3] = !f[3];
      if (err == 3) f[nf - 1] = !f[nf - 1];
      for (i = 0; i < nf; i++) begin
        if (i % 4 == 0) begin
          s = (err == 5 && i == 0) ? last : !last;
          lb[nl] = s; lf[nl] = fst; nl++; last = s;
        end
        lb[nl] = f[i]; lf[nl] = fst; nl++; last = f[i];
      end
    end
    lb[nl] = (err == 2) ? 1'b0 : 1'b1; lf[nl] = 0; nl++;
  endtask

  task automatic sample();
    if (!tx) ntxlow++;
    if (rx_ok) begin saw_ok = 1; if (t_ok < 0) t_ok = cyc; end
    if (rx_err) begin saw_err = 1; if (t_err < 0) t_err = cyc; end
    if (pex) saw_pex = 1;
  endtask

  // idle bits, the frame at its bit times, then ACK slot, ACK delimiter, EOF
  task automatic send(input int idle);
    int k, b, L;
    saw_ack = 0; saw_ok = 0; saw_err = 0; saw_pex = 0; ntxlow = 0; t_ok = -1; t_err = -1; cyc = 0;
    repeat (idle * tn) begin @(negedge clk); rx = 1; end
    for (k = 0; k < nl; k++) begin
      L = lf[k] ? td : tn;
      repeat (L) begin @(negedge clk); rx = lb[k]; cyc++; sample(); end
    end
    ack_c = cyc + 1;
    for (k = 0; k < 9 * tn; k++) begin
      b = k / tn;                     // 0 ACK slot, 1 ACK delimiter, 2..8 EOF
      @(negedge clk);
      rx = !((b == 1 && adel_dom) || (eof_dom >= 0 && b == 2 + eof_dom));
      cyc++; sample();
      if (b == 0 && !tx && !saw_err) saw_ack = 1;
    end
  endtask

  int r0, nok;

  initial begin
    repeat (3) @(posedge clk);
    chk(tx === 1'b1, "tx recessive in reset");
    chk(rx_ok === 1'b0 && rx_err === 1'b0 && pex === 1'b0 && rec === 8'd0 && err_code === 3'd0, "no reports in reset");
    chk(out_id === 29'h0 && {out_ide, out_fdf, out_brs, out_esi, out_rtr} === 5'b0 && out_dlc === 4'd0 &&
        out_len === 7'd0 && out_sum === 16'h0, "frame outputs clear in reset");
    rst_n = 1;

    // no bus integration yet: a frame straight after reset is ignored
    fill(1); build(0, 29'h123, 0, 0, 0, 0, 4'd2, 0); send(0);
    chk(!saw_ack && !saw_ok && !saw_err && ntxlow == 0, "frame before bus integration ignored");

    // classical base data frame
    fill(2); build(0, 29'h123, 0, 0, 0, 0, 4'd2, 0); send(11);
    chk(saw_ack && saw_ok && !saw_err, "classical base frame ACKed and reported");
    chk(out_id === 29'h123 && !out_ide && !out_fdf && !out_rtr && !out_brs && out_dlc === 4'd2 && out_len === 7'd2,
        "classical base fields");
    chk(out_sum === esum, "data byte sum");
    chk(ntxlow == 1, $sformatf("one dominant bit (ACK) for a good frame (%0d)", ntxlow));
    chk(t_ok - ack_c == 8, $sformatf("rx_ok after the sixth EOF bit (%0d)", t_ok - ack_c));
    // classical extended remote frame
    build(1, 29'h1ABC_1234, 1, 0, 0, 0, 4'd3, 0); send(11);
    chk(saw_ack && saw_ok && out_id === 29'h1ABC_1234 && out_ide && out_rtr && out_dlc === 4'd3 && out_len === 7'd0,
        "classical extended remote frame");
    // classical DLC above 8 carries 8 bytes
    fill(3); build(0, 29'h050, 0, 0, 0, 0, 4'd12, 0); send(11);
    chk(saw_ok && out_len === 7'd8 && out_dlc === 4'd12 && out_sum === esum, "classical DLC 12 = 8 bytes");
    // FD base frame, no rate switch, CRC17
    fill(4); build(0, 29'h2A5, 0, 1, 0, 0, 4'd9, 0); send(11);
    chk(saw_ack && saw_ok && out_fdf && !out_brs && !out_esi && !out_rtr && out_len === 7'd12 && out_sum === esum,
        "FD frame, 12 bytes, CRC17");

    // dual bit rate: nominal 4 clocks, data 1 clock, 64 bytes, CRC21
    nbt = 4; dbt = 1; tn = 4; td = 1;
    fill(5); build(1, 29'h0F0F_0F0F, 0, 1, 1, 1, 4'd15, 0); send(11);
    chk(saw_ack && saw_ok && !saw_err, "FD extended frame with BRS ACKed");
    chk(out_id === 29'h0F0F_0F0F && out_brs && out_esi && out_ide && out_len === 7'd64 && out_sum === esum,
        "BRS / ESI / 64 bytes reported");
    chk(ntxlow == 4, $sformatf("ACK lasts one nominal bit (%0d clocks)", ntxlow));
    chk(t_ok - ack_c == 31, $sformatf("rx_ok at the nominal bit time (%0d)", t_ok - ack_c));
    // nominal 3, data 2: CRC17 / CRC21 boundary
    nbt = 3; dbt = 2; tn = 3; td = 2;
    fill(6); build(0, 29'h3C3, 0, 1, 1, 0, 4'd10, 0); send(11);
    chk(saw_ack && saw_ok && out_len === 7'd16 && out_sum === esum, "16 bytes at 3/2 clocks (CRC17)");
    fill(7); build(0, 29'h3C4, 0, 1, 1, 0, 4'd11, 0); send(11);
    chk(saw_ack && saw_ok && out_len === 7'd20 && out_sum === esum, "20 bytes at 3/2 clocks (CRC21)");
    // every FD DLC at 2/1 clocks, and classical frames with many stuff patterns
    nbt = 2; dbt = 1; tn = 2; td = 1;
    nok = 0;
    for (int d = 0; d < 16; d++) begin
      fill(10 + d); build(d[0], 29'h0155_5000 + d * 29'h31, 0, 1, 1, d[1], d[3:0], 0); send(11);
      if (saw_ack && saw_ok && !saw_err && out_len == flen(d[3:0], 1, 0) && out_sum === esum) nok++;
    end
    chk(nok == 16, $sformatf("all 16 FD DLCs received (%0d)", nok));
    nbt = 1; dbt = 1; tn = 1; td = 1;
    nok = 0;
    for (int d = 0; d < 40; d++) begin
      fill(40 + d); build(d[0], d[0] ? 29'h0 + d : 29'h7C0 + d, 0, 0, 0, 0, d % 9, 0); send(11);
      if (saw_ack && saw_ok && !saw_err && out_sum === esum) nok++;
    end
    chk(nok == 40, $sformatf("40 classical frames received (%0d)", nok));
    // nbt / dbt of 0 count as one clock
    nbt = 0; dbt = 0;
    fill(8); build(0, 29'h111, 0, 1, 1, 0, 4'd4, 0); send(11);
    chk(saw_ack && saw_ok && out_sum === esum, "bit time 0 treated as one clock");
    nbt = 1; dbt = 1;

    // errors
    r0 = rec;
    fill(9); build(0, 29'h4F0, 0, 0, 0, 0, 4'd1, 1); send(11);
    chk(saw_err && !saw_ack && !saw_ok && err_code === 3'd1, "stuff error flagged, no ACK");
    chk(ntxlow == 6, $sformatf("six-bit error flag (%0d)", ntxlow));
    chk(rec == r0 + 1 && !err_pas, "receive error counter +1");
    build(0, 29'h0F0, 0, 1, 1, 0, 4'd8, 3); send(11);
    chk(saw_err && !saw_ack && err_code === 3'd3 && rec == r0 + 2, "FD CRC error flagged, no ACK");
    chk(t_err - ack_c == 2, $sformatf("CRC error flag after the ACK delimiter (%0d)", t_err - ack_c));
    chk(ntxlow == 6, "CRC error flag six bits");
    // after the error (at the ACK delimiter) the node needs 11 recessive bits:
    // 7 EOF bits + 3 idle bits are too few, 7 + 4 are enough
    fill(13); build(0, 29'h0E1, 0, 1, 0, 0, 4'd1, 0); send(3);
    chk(!saw_ack && !saw_ok && !saw_err, "SOF ignored 10 recessive bits after an error");
    build(0, 29'h0E2, 0, 1, 0, 0, 4'd1, 3); send(11);
    build(0, 29'h0E3, 0, 1, 0, 0, 4'd1, 0); send(4);
    chk(saw_ack && saw_ok, "SOF accepted 11 recessive bits after an error");
    build(1, 29'h0ABC_DEF0, 0, 1, 1, 0, 4'd13, 3); send(11);
    chk(saw_err && err_code === 3'd3, "FD CRC21 error flagged");
    build(0, 29'h0F1, 0, 1, 0, 0, 4'd3, 4); send(11);
    chk(saw_err && !saw_ack && err_code === 3'd3, "stuff count error flagged as CRC error");
    build(0, 29'h0F2, 0, 1, 1, 0, 4'd5, 5); send(11);
    chk(saw_err && !saw_ack && err_code === 3'd4, "fixed stuff bit error");
    build(0, 29'h0F3, 0, 0, 0, 0, 4'd2, 2); send(11);
    chk(saw_err && !saw_ack && !saw_ok && err_code === 3'd2, "dominant CRC delimiter: form error");
    build(0, 29'h0F4, 0, 0, 0, 0, 4'd2, 3); send(11);
    chk(saw_err && !saw_ack && err_code === 3'd3, "classical CRC15 error");
    // a stuff bit after the last CRC15 bit is checked too
    begin : trail
      int sd;
      sd = 0;
      do begin fill(100 + sd); build(0, 29'h200 + sd, 0, 0, 0, 0, 4'd1 + sd % 8, 0); sd++; end
      while (tsb < 0 && sd < 400);
      chk(tsb >= 0, "found a classical frame ending in a stuff bit");
      send(11);
      chk(saw_ok && !saw_err, "trailing CRC15 stuff bit accepted");
      lb[tsb] = !lb[tsb]; send(11);
      chk(saw_err && !saw_ack && err_code === 3'd1, "bad trailing CRC15 stuff bit: stuff error");
    end
    // a dominant glitch shorter than the sample point is not a SOF
    nbt = 4; tn = 4;
    repeat (12 * 4) @(negedge clk);
    rx = 0; @(negedge clk); rx = 1;
    repeat (20) @(negedge clk);
    chk(!rx_err && !rx_ok && tx === 1'b1, "one-clock glitch ignored");
    fill(15); build(0, 29'h0E4, 0, 0, 0, 0, 4'd1, 0); send(11);
    chk(saw_ack && saw_ok, "frame after a glitch received");
    nbt = 1; tn = 1;
    adel_dom = 1; build(0, 29'h0F5, 0, 1, 0, 0, 4'd1, 0); send(11); adel_dom = 0;
    chk(saw_ack && saw_err && !saw_ok && err_code === 3'd2, "dominant ACK delimiter: form error after the ACK");
    eof_dom = 5; build(0, 29'h0F6, 0, 0, 0, 0, 4'd1, 0); send(11); eof_dom = -1;
    chk(saw_err && !saw_ok && err_code === 3'd2, "dominant sixth EOF bit: form error");
    r0 = rec;
    eof_dom = 6; build(0, 29'h0F7, 0, 0, 0, 0, 4'd1, 0); send(11); eof_dom = -1;
    chk(saw_ok && !saw_err && rec == r0 - 1, "dominant last EOF bit ignored, counter -1");
    // protocol exception
    r0 = rec;
    build(0, 29'h0F8, 0, 1, 1, 0, 4'd6, 6); send(11);
    chk(saw_pex && !saw_err && !saw_ack && !saw_ok && rec == r0, "res recessive: protocol exception, no flag");
    build(0, 29'h0F8, 0, 1, 1, 0, 4'd6, 0); send(11);
    chk(saw_ok && !saw_pex, "frame after a protocol exception received");
    pex_en = 0;
    build(0, 29'h0F9, 0, 1, 1, 0, 4'd6, 6); send(11);
    chk(saw_err && !saw_pex && err_code === 3'd2, "res recessive without protocol exception: form error");
    pex_en = 1;

    // acceptance filter
    acc_id = 29'h124; acc_msk = 29'h7FF;
    fill(11); build(0, 29'h123, 0, 1, 1, 0, 4'd2, 0); send(11);
    chk(saw_ack && !saw_ok && out_id !== 29'h123, "filtered frame ACKed, not reported");
    build(0, 29'h124, 0, 1, 1, 0, 4'd2, 0); send(11);
    chk(saw_ok && out_id === 29'h124, "matching frame reported");
    acc_msk = 29'h0;

    // error passive and back
    while (rec < 8'd130) begin build(0, 29'h055, 0, 0, 0, 0, 4'd0, 1); send(11); end
    chk(err_pas && rec == 8'd130, "error passive at 128 and above");
    fill(12); build(0, 29'h056, 0, 1, 0, 0, 4'd1, 0); send(11);
    chk(saw_ok && rec == 8'd127 && !err_pas, "good frame sets an error-passive counter to 127");
    while (rec < 8'd255) begin build(0, 29'h055, 0, 0, 0, 0, 4'd0, 1); send(11); end
    build(0, 29'h055, 0, 0, 0, 0, 4'd0, 1); send(11);
    chk(saw_err && rec == 8'd255, "counter saturates at 255");

    // bus integration after reset: 11 recessive bits before the first SOF
    @(negedge clk); rst_n = 0; @(negedge clk); rst_n = 1;
    chk(rec === 8'd0 && !err_pas, "reset clears the error counter");
    fill(14); build(0, 29'h0D1, 0, 0, 0, 0, 4'd1, 0); send(9);
    chk(!saw_ack && !saw_ok && !saw_err, "SOF after 10 recessive bits from reset ignored");
    @(negedge clk); rst_n = 0; @(negedge clk); rst_n = 1;
    build(0, 29'h0D1, 0, 0, 0, 0, 4'd1, 0); send(10);
    chk(saw_ack && saw_ok, "SOF after 11 recessive bits from reset received");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #5000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
