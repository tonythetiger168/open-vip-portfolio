// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CAN-FD testbench top with a functional CAN-FD DUT model

`ifndef CAN-FD_TB_SV
`define CAN-FD_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import can_fd_defs_pkg::*;
import can_fd_pkg::*;
import can_fd_env_pkg::*;
import can_fd_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  can_fd_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  can_fd_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx(vif.rx),
    .tx(vif.tx),
    .error_cnt(vif.error_cnt),
    .stuff_err(vif.stuff_err)
  );

  // Concurrent protocol checks
  can_fd_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .rx(vif.rx), .tx(vif.tx), .error_cnt(vif.error_cnt), .stuff_err(vif.stuff_err)
  );

  initial begin
    uvm_config_db#(virtual can_fd_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module can_fd_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       rx,
  output logic       tx,
  output logic [3:0] error_cnt,
  output logic       stuff_err
);
  logic [1:0] dly;
  logic [3:0] same_cnt;
  logic       rx_d;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      dly       <= '0;
      rx_d      <= 1'b1;
      same_cnt  <= '0;
      error_cnt <= '0;
      stuff_err <= 1'b0;
      tx        <= 1'b1;
    end else begin
      tx   <= (dly == 2'd3) ? rx_d : 1'b1;   // delayed loopback with IFS recessive
      dly  <= (dly == 2'd3) ? 2'd0 : dly + 1'b1;
      rx_d <= rx;
      if (rx == rx_d && rx == 1'b0)
        same_cnt <= same_cnt + 1'b1;
      else
        same_cnt <= 1'b0;
      // six consecutive dominant bits is a stuff error
      stuff_err <= (same_cnt == 4'd5);
      if (stuff_err)
        error_cnt <= error_cnt + 1'b1;
    end
  end
endmodule
`endif
