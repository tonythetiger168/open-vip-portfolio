// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CAN-FD testbench top with a functional CAN-FD DUT model

`ifndef CAN_FD_UVM_VIP_TB_SV
`define CAN_FD_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import can_fd_defs_pkg::*;
import can_fd_pkg::*;
import can_fd_env_pkg::*;
import can_fd_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  can_fd_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  can_fd_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx(vif.rx),
    .nbt(vif.nbt),
    .dbt(vif.dbt),
    .pex_en(vif.pex_en),
    .acc_id(vif.acc_id),
    .acc_msk(vif.acc_msk),
    .tx(vif.tx),
    .rx_ok(vif.rx_ok),
    .rx_err(vif.rx_err),
    .pex(vif.pex),
    .err_code(vif.err_code),
    .rec(vif.rec),
    .err_pas(vif.err_pas),
    .out_id(vif.out_id),
    .out_ide(vif.out_ide),
    .out_fdf(vif.out_fdf),
    .out_brs(vif.out_brs),
    .out_esi(vif.out_esi),
    .out_rtr(vif.out_rtr),
    .out_dlc(vif.out_dlc),
    .out_len(vif.out_len),
    .out_sum(vif.out_sum)
  );

  // Concurrent protocol checks
  can_fd_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx(vif.rx),
    .nbt(vif.nbt),
    .dbt(vif.dbt),
    .pex_en(vif.pex_en),
    .acc_id(vif.acc_id),
    .acc_msk(vif.acc_msk),
    .tx(vif.tx),
    .rx_ok(vif.rx_ok),
    .rx_err(vif.rx_err),
    .pex(vif.pex),
    .err_code(vif.err_code),
    .rec(vif.rec),
    .err_pas(vif.err_pas),
    .out_id(vif.out_id),
    .out_ide(vif.out_ide),
    .out_fdf(vif.out_fdf),
    .out_brs(vif.out_brs),
    .out_esi(vif.out_esi),
    .out_rtr(vif.out_rtr),
    .out_dlc(vif.out_dlc),
    .out_len(vif.out_len),
    .out_sum(vif.out_sum)
  );

  initial begin
    uvm_config_db#(virtual can_fd_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module can_fd_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rx,
  input  logic [3:0]  nbt,
  input  logic [3:0]  dbt,
  input  logic        pex_en,
  input  logic [28:0] acc_id,
  input  logic [28:0] acc_msk,
  output logic        tx,
  output logic        rx_ok,
  output logic        rx_err,
  output logic        pex,
  output logic [2:0]  err_code,
  output logic [7:0]  rec,
  output logic        err_pas,
  output logic [28:0] out_id,
  output logic        out_ide,
  output logic        out_fdf,
  output logic        out_brs,
  output logic        out_esi,
  output logic        out_rtr,
  output logic [3:0]  out_dlc,
  output logic [6:0]  out_len,
  output logic [15:0] out_sum
);
  localparam logic [14:0] P15 = 15'h4599;
  localparam logic [16:0] P17 = 17'h1685B, I17 = 17'h10000;
  localparam logic [20:0] P21 = 21'h102899, I21 = 21'h100000;

  // ERRW: after an error or a protocol exception, wait for 11 recessive bits
  typedef enum logic [3:0] {IDLE, SOFS, DYN, FIX, CDEL, ACKS, ADEL, EOFS, ERRW} st_t;
  typedef enum logic [3:0] {F_ID, F_B12, F_IDE, F_IDX, F_RTR, F_FDF, F_R0, F_RES, F_BRS, F_ESI,
                            F_DLC, F_DATA, F_CRC} fld_t;
  st_t         st;
  fld_t        fld;
  logic [3:0]  cnt, len_q;      // clock in bit, clocks in this bit
  logic        fast;            // the next bit is a data-phase bit
  logic        rxp;             // rx one clock ago
  logic        integ;           // 11 recessive bits seen (bus integration)
  logic        tx_nx;           // tx for the next bit
  logic [3:0]  ones;            // recessive bits in a row (saturates at 11)
  logic        last;
  logic [2:0]  run, nsb;
  logic [9:0]  fc;              // field bit counter
  logic [4:0]  xc;              // SC + CRC bits taken (FD)
  logic        fsbd;            // fixed stuff bit taken for this group of four
  logic [14:0] c15;
  logic [16:0] c17;
  logic [20:0] c21, rcrc;
  logic [3:0]  scv;
  logic        crc_bad;
  logic [28:0] id;
  logic        b12, ide, rtr, fdf, brs, esi;
  logic [3:0]  dlc;
  logic [6:0]  len;
  logic [7:0]  cur;
  logic [15:0] sum;
  logic [2:0]  eflag;           // error-flag bits still to send after the first
  logic [2:0]  eofc;

  function automatic logic [14:0] f15(input logic [14:0] c, input logic b);
    f15 = (b ^ c[14]) ? ((c << 1) ^ P15) : (c << 1);
  endfunction
  function automatic logic [16:0] f17(input logic [16:0] c, input logic b);
    f17 = (b ^ c[16]) ? ((c << 1) ^ P17) : (c << 1);
  endfunction
  function automatic logic [20:0] f21(input logic [20:0] c, input logic b);
    f21 = (b ^ c[20]) ? ((c << 1) ^ P21) : (c << 1);
  endfunction
  function automatic logic [3:0] f_sc(input logic [2:0] n);
    logic [2:0] g;
    g = n ^ (n >> 1);
    f_sc = {g, ^g};
  endfunction
  function automatic logic [6:0] f_len(input logic [3:0] d, input logic fd, input logic r);
    if (!fd) f_len = r ? 7'd0 : ((d > 4'd8) ? 7'd8 : {3'b0, d});
    else case (d)
      4'd9:  f_len = 7'd12;
      4'd10: f_len = 7'd16;
      4'd11: f_len = 7'd20;
      4'd12: f_len = 7'd24;
      4'd13: f_len = 7'd32;
      4'd14: f_len = 7'd48;
      4'd15: f_len = 7'd64;
      default: f_len = {3'b0, d};
    endcase
  endfunction

  wire [3:0] nb = (nbt == 4'd0) ? 4'd1 : nbt;
  wire [3:0] db = (dbt == 4'd0) ? 4'd1 : dbt;
  assign err_pas = rec[7];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= IDLE; fld <= F_ID; cnt <= '0; len_q <= 4'd1; fast <= 1'b0; rxp <= 1'b1; integ <= 1'b0;
      tx_nx <= 1'b1; ones <= '0; last <= 1'b1; run <= '0; nsb <= '0; fc <= '0; xc <= '0; fsbd <= 1'b0;
      c15 <= '0; c17 <= I17; c21 <= I21; rcrc <= '0; scv <= '0; crc_bad <= 1'b0;
      id <= '0; b12 <= 1'b0; ide <= 1'b0; rtr <= 1'b0; fdf <= 1'b0; brs <= 1'b0; esi <= 1'b0;
      dlc <= '0; len <= '0; cur <= '0; sum <= '0; eflag <= '0; eofc <= '0;
      tx <= 1'b1; rx_ok <= 1'b0; rx_err <= 1'b0; pex <= 1'b0; err_code <= '0; rec <= '0;
      out_id <= '0; out_ide <= 1'b0; out_fdf <= 1'b0; out_brs <= 1'b0; out_esi <= 1'b0; out_rtr <= 1'b0;
      out_dlc <= '0; out_len <= '0; out_sum <= '0;
    end else begin : step
      logic       sync, smp, wrap, nx, fst, b, fe, dend;
      logic [2:0] ec;
      logic [3:0] c, lc;
      st_t        stc;
      fe = 1'b0; ec = 3'd0; dend = 1'b0;
      rx_ok <= 1'b0; rx_err <= 1'b0; pex <= 1'b0;
      rxp <= rx;
      // bit timing: hard synchronisation on the SOF edge, sample in mid-bit
      sync = (st == IDLE) && integ && rxp && !rx;
      c    = sync ? 4'd0 : cnt;
      lc   = sync ? nb : len_q;
      smp  = (c == (lc >> 1));
      wrap = (c >= lc - 4'd1);
      cnt  <= wrap ? 4'd0 : c + 4'd1;
      if (sync) stc = SOFS; else stc = st;
      if (sync) st <= SOFS;
      nx = tx_nx; fst = fast; b = rx;
      if (smp) begin
        ones <= b ? ((ones == 4'd11) ? ones : ones + 4'd1) : 4'd0;
        if (eflag != 3'd0) begin nx = 1'b0; eflag <= eflag - 3'd1; end
        else nx = 1'b1;
        case (stc)
          IDLE:
            if (b && ones >= 4'd10) integ <= 1'b1;
          SOFS:
            if (b) st <= IDLE;
            else begin
              st <= DYN; fld <= F_ID; fc <= '0; last <= 1'b0; run <= 3'd1; nsb <= '0;
              c15 <= f15(15'h0, 1'b0); c17 <= f17(I17, 1'b0); c21 <= f21(I21, 1'b0);
              id <= '0; brs <= 1'b0; esi <= 1'b0; sum <= '0;   // the other fields are always written
            end
          DYN:
            if (run == 3'd5) begin                 // dynamic stuff bit
              if (b == last) begin fe = 1'b1; ec = 3'd1; end
              nsb <= nsb + 3'd1; last <= b; run <= 3'd1;
              c17 <= f17(c17, b); c21 <= f21(c21, b);
            end else begin
              run <= (b == last) ? run + 3'd1 : 3'd1;
              last <= b;
              if (fld != F_CRC) begin c15 <= f15(c15, b); c17 <= f17(c17, b); c21 <= f21(c21, b); end
              fc <= fc + 10'd1;
              case (fld)
                F_ID:  begin id <= {id[27:0], b}; if (fc == 10'd10) fld <= F_B12; end
                F_B12: begin b12 <= b; fld <= F_IDE; end
                F_IDE: begin
                  ide <= b; fc <= '0;
                  if (b) fld <= F_IDX;
                  else begin rtr <= b12; fld <= F_FDF; end
                end
                F_IDX: begin id <= {id[27:0], b}; if (fc == 10'd17) fld <= F_RTR; end
                F_RTR: begin rtr <= b; fld <= F_FDF; end
                F_FDF: begin
                  fdf <= b; fc <= '0;
                  if (b) begin rtr <= 1'b0; fld <= F_RES; end
                  else if (ide) fld <= F_R0;
                  else fld <= F_DLC;
                end
                F_R0:  begin fc <= '0; fld <= F_DLC; end
                F_RES: begin
                  if (b) begin
                    if (pex_en) begin st <= ERRW; pex <= 1'b1; ones <= '0; end
                    else begin fe = 1'b1; ec = 3'd2; end
                  end
                  fld <= F_BRS;
                end
                F_BRS: begin brs <= b; if (b) fst = 1'b1; fld <= F_ESI; end
                F_ESI: begin esi <= b; fc <= '0; fld <= F_DLC; end
                F_DLC: begin
                  dlc <= {dlc[2:0], b};
                  if (fc == 10'd3) begin
                    len <= f_len({dlc[2:0], b}, fdf, rtr);
                    fc <= '0; fld <= F_DATA;
                    if (f_len({dlc[2:0], b}, fdf, rtr) == 7'd0) dend = 1'b1;
                  end
                end
                F_DATA: begin
                  cur <= {cur[6:0], b};
                  if (fc[2:0] == 3'd7) sum <= sum + {8'h0, cur[6:0], b};
                  if (fc == ({3'b0, len} << 3) - 10'd1) dend = 1'b1;
                end
                default: begin                       // F_CRC: classical CRC15
                  rcrc <= {rcrc[19:0], b};
                  if (fc == 10'd14) begin crc_bad <= ({rcrc[13:0], b} != c15); st <= CDEL; end
                end
              endcase
              if (dend) begin
                fc <= '0;
                if (fdf) begin st <= FIX; xc <= '0; fsbd <= 1'b0; run <= 3'd0; end
                else fld <= F_CRC;
              end
            end
          FIX:
            if (xc[1:0] == 2'd0 && !fsbd) begin   // fixed stuff bit
              if (b == last) begin fe = 1'b1; ec = 3'd4; end
              fsbd <= 1'b1; last <= b;
            end else begin
              fsbd <= 1'b0; last <= b; xc <= xc + 5'd1;
              if (xc < 5'd4) begin scv <= {scv[2:0], b}; c17 <= f17(c17, b); c21 <= f21(c21, b); end
              else rcrc <= {rcrc[19:0], b};
              if (xc == ((len > 7'd16) ? 5'd24 : 5'd20)) begin
                st <= CDEL; fst = 1'b0;              // nominal rate from the CRC delimiter
                if (len > 7'd16) crc_bad <= (scv != f_sc(nsb)) || ({rcrc[19:0], b} != c21);
                else             crc_bad <= (scv != f_sc(nsb)) || ({rcrc[15:0], b} != c17);
              end
            end
          CDEL:
            if (!fdf && run == 3'd5) begin         // stuff bit after the last CRC15 bit
              if (b == last) begin fe = 1'b1; ec = 3'd1; end
              run <= 3'd0;
            end else begin
              if (!b) begin fe = 1'b1; ec = 3'd2; end
              else if (!crc_bad) nx = 1'b0;          // dominant ACK in the slot
              st <= ACKS;
            end
          ACKS: st <= ADEL;
          ADEL:
            if (!b) begin fe = 1'b1; ec = 3'd2; end
            else if (crc_bad) begin fe = 1'b1; ec = 3'd3; end
            else begin st <= EOFS; eofc <= '0; end
          EOFS: begin                               // a dominant last EOF bit is not an error
            eofc <= eofc + 3'd1;
            if (eofc < 3'd6 && !b) begin fe = 1'b1; ec = 3'd2; end
            else if (eofc == 3'd5) begin             // frame valid for a receiver
              if (rec > 8'd127) rec <= 8'd127;
              else if (rec != 8'd0) rec <= rec - 8'd1;
              if (((id ^ acc_id) & acc_msk) == 29'h0) begin
                rx_ok <= 1'b1;
                out_id <= id; out_ide <= ide; out_fdf <= fdf; out_brs <= brs; out_esi <= esi;
                out_rtr <= rtr; out_dlc <= dlc; out_len <= len; out_sum <= sum;
              end
            end
            if (eofc == 3'd6) st <= IDLE;
          end
          default:                                 // ERRW: 11 recessive bits after the error
            if (b && ones >= 4'd10) st <= IDLE;
        endcase
        if (fe) begin
          st <= ERRW; eflag <= 3'd5; nx = 1'b0; fst = 1'b0; ones <= '0;
          err_code <= ec; rx_err <= 1'b1;
          if (rec != 8'hFF) rec <= rec + 8'd1;
        end
        tx_nx <= nx; fast <= fst;
      end
      if (wrap) begin tx <= nx; len_q <= fst ? db : nb; end
    end
  end
endmodule
`endif
