// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_sequences.svh -- CAN-FD sequences

// Random traffic: cfg.num_items constrained-random items.
class can_fd_base_sequence extends uvm_sequence #(can_fd_transaction);
  `uvm_object_utils(can_fd_base_sequence)
  can_fd_config cfg;

  function new(string name = "can_fd_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = can_fd_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "can_fd_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class can_fd_directed_sequence extends uvm_sequence #(can_fd_transaction);
  `uvm_object_utils(can_fd_directed_sequence)
  can_fd_config cfg;

  function new(string name = "can_fd_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function can_fd_transaction item();
    item = can_fd_transaction::type_id::create("req");
  endfunction

  task send(can_fd_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    can_fd_transaction t;
    // every DLC in classical / FD x base / extended format (BRS and ESI vary in FD)
    for (int f = 0; f < 4; f++)
      for (int d = 0; d < 16; d++) begin
        t = item(); t.fdf = f[1]; t.ide = f[0];
        t.id = f[0] ? (29'h0ABC_DE00 + d) : (29'h120 + d);
        t.brs = f[1] & d[0]; t.esi = f[1] & d[1]; t.dlc = d; t.seed = 16 * f + d + 1;
        t.post_randomize(); send(t);
      end
    // classical remote frames
    t = item(); t.id = 29'h7FF; t.rtr = 1; t.dlc = 8; t.post_randomize(); send(t);
    t = item(); t.ide = 1; t.id = 29'h1FFF_FFFF; t.rtr = 1; t.dlc = 3; t.post_randomize(); send(t);
    // every error kind in an FD frame, then the classical ones
    for (int k = 1; k < 7; k++) begin
      t = item(); t.fdf = 1; t.brs = 1; t.ide = k[0]; t.id = 29'h0123_4567 & (k[0] ? 29'h0FFF_FFFF : 29'h7FF);
      t.dlc = 8 + k; t.seed = 40 + k; t.err_kind = canfd_err_e'(k);
      t.post_randomize(); send(t);
    end
    for (int k = 1; k < 4; k++) begin
      t = item(); t.id = 29'h3A5; t.dlc = k; t.seed = 50 + k; t.err_kind = canfd_err_e'(k);
      t.post_randomize(); send(t);
    end
    // acceptance filter miss (ACKed, not reported)
    t = item(); t.fdf = 1; t.ide = 1; t.id = 29'h1000_0001; t.dlc = 2; t.seed = 60; t.post_randomize(); send(t);
    // error passive: 130 errors, then good frames bring the counter back
    for (int k = 0; k < 130; k++) begin
      t = item(); t.id = 29'h055; t.err_kind = FD_STUFF; t.seed = k; t.post_randomize(); send(t);
    end
    repeat (3) begin
      t = item(); t.fdf = 1; t.brs = 1; t.id = 29'h321; t.dlc = 1; t.seed = 99; t.post_randomize(); send(t);
    end
  endtask
endclass
