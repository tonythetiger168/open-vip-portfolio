// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_sequences.svh -- CAN-FD sequences

// Random traffic: cfg.num_items constrained-random items.
class can_fd_base_sequence extends uvm_sequence #(can_fd_transaction);
  `uvm_object_utils(can_fd_base_sequence)
  can_fd_config cfg;

  function new(string name = "can_fd_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = can_fd_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "can_fd_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class can_fd_directed_sequence extends uvm_sequence #(can_fd_transaction);
  `uvm_object_utils(can_fd_directed_sequence)
  can_fd_config cfg;

  function new(string name = "can_fd_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function can_fd_transaction item();
    item = can_fd_transaction::type_id::create("req");
  endfunction

  task send(can_fd_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    can_fd_transaction t;
    t = item(); t.payload = 32'h0;         t.nbits = 32; t.build(); send(t);   // maximum stuffing
    t = item(); t.payload = 32'hFFFF_FFFF; t.nbits = 32; t.build(); send(t);
    t = item(); t.payload = 32'h5555_5555; t.nbits = 32; t.build(); send(t);   // no stuffing
    t = item(); t.payload = 32'h0000_00F0; t.nbits = 12; t.inject_err = 1; t.build(); send(t);
    t = item(); t.payload = 32'h1;         t.nbits = 1;  t.inject_err = 1; t.build(); send(t);
    t = item(); t.payload = 32'hA5;        t.nbits = 8;  t.build(); send(t);
  endtask
endclass
