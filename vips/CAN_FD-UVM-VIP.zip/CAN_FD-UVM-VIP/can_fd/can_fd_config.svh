// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_config.svh -- CAN-FD agent configuration

class can_fd_config extends uvm_object;
  `uvm_object_utils(can_fd_config)
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  bit coverage_enable = 1;
  bit checks_enable   = 1;
  int unsigned num_items      = 32;     // random items per base sequence
  int unsigned timeout_cycles = 100;   // handshake / response watchdog
  int unsigned idle_bits = 11;    // recessive bits before each frame
  bit [3:0] nbt = 4'd4;             // clocks per nominal bit
  bit [3:0] dbt = 4'd1;             // clocks per data-phase bit (<= nbt)
  bit       pex_en = 1'b1;          // receiver protocol exception enabled
  bit [28:0] acc_id  = 29'h0;       // acceptance filter: (id ^ acc_id) & acc_msk == 0
  bit [28:0] acc_msk = 29'h1000_0000;
  function new(string name = "can_fd_config"); super.new(name); endfunction
endclass
