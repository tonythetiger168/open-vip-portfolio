// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_pkg.sv -- CAN-FD UVM VIP package

package can_fd_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import can_fd_defs_pkg::*;
  export can_fd_defs_pkg::*;

  `include "can_fd_transaction.svh"
  `include "can_fd_config.svh"
  `include "can_fd_sequencer.svh"
  `include "can_fd_driver.svh"
  `include "can_fd_monitor.svh"
  `include "can_fd_agent.svh"
  `include "can_fd_sequences.svh"
  `include "can_fd_checker.svh"
  `include "can_fd_coverage.svh"
endpackage
