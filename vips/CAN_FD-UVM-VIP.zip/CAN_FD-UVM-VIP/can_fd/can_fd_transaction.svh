// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_transaction.svh -- CAN-FD transaction

class can_fd_transaction extends uvm_sequence_item;
  `uvm_object_utils(can_fd_transaction)

  // request (driven by the agent)
  bit bits[$];
  // response (returned by the DUT)
  bit [7:0] stuff_errs;
  bit [3:0] error_cnt;
  bit [7:0] loop_errs;
  // bookkeeping (not compared)
  rand bit [31:0] payload;
  rand bit [5:0] nbits;
  rand bit inject_err;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len { nbits inside {[1:32]}; inject_err dist { 0 := 4, 1 := 1 }; }

  function new(string name = "can_fd_transaction"); super.new(name); endfunction

  // SOF, payload LSB first with a complement bit stuffed after five equal bits,
  // optional stuff violation; trailing recessive bits are idle, not frame
  function void build();
    bit last = 1'b0;
    int run = 1;
    bits.delete();
    bits.push_back(1'b0);                       // start of frame
    for (int i = 0; i < nbits; i++) begin
      bit b = payload[i];
      if (run == 5) begin                       // stuff bit
        bits.push_back(!last); last = !last; run = 1;
      end
      bits.push_back(b);
      if (b == last) run++; else begin last = b; run = 1; end
    end
    if (run == 5) bits.push_back(!last);
    if (inject_err) repeat (7) bits.push_back(1'b0);
    while (bits.size() > 1 && bits[bits.size() - 1] == 1'b1) void'(bits.pop_back());
  endfunction

  function void post_randomize(); build(); endfunction

  // inverse of build(): recover payload, nbits and the stuff violation from bits
  function void unstuff();
    bit last = 1'b0;
    int run = 1, zeros = 0;
    payload = 0; nbits = 0; inject_err = 0;
    // a trailing run of seven dominant bits that follows the payload is the
    // injected violation
    for (int i = bits.size() - 1; i >= 0 && bits[i] == 1'b0; i--) zeros++;
    for (int i = 1; i < bits.size() - ((zeros >= 7) ? 7 : 0); i++) begin
      if (run == 5) begin                       // drop the stuff bit
        last = bits[i]; run = 1;
        continue;
      end
      if (nbits < 32) payload[nbits] = bits[i];
      nbits++;
      if (bits[i] == last) run++; else begin last = bits[i]; run = 1; end
    end
    inject_err = (zeros >= 7);
  endfunction

  function void do_copy(uvm_object rhs);
    can_fd_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    bits = rhs_.bits;
    stuff_errs = rhs_.stuff_errs;
    error_cnt = rhs_.error_cnt;
    loop_errs = rhs_.loop_errs;
    payload = rhs_.payload;
    nbits = rhs_.nbits;
    inject_err = rhs_.inject_err;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    can_fd_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (bits.size() != rhs_.bits.size()) return 0;
    foreach (bits[i]) if (bits[i] != rhs_.bits[i]) return 0;
    if (stuff_errs != rhs_.stuff_errs) return 0;
    if (error_cnt != rhs_.error_cnt) return 0;
    if (loop_errs != rhs_.loop_errs) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(can_fd_transaction rhs_);
    if (bits.size() != rhs_.bits.size()) return 0;
    foreach (bits[i]) if (bits[i] != rhs_.bits[i]) return 0;
    return 1;
  endfunction

  function string qstr_bits();
    string s = $sformatf("[%0d]{", bits.size());
    foreach (bits[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bits[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("CAN-FD{tag=%0d bits=%s stuff_errs=0x%0h error_cnt=0x%0h loop_errs=0x%0h}", tag, qstr_bits(), stuff_errs, error_cnt, loop_errs);
  endfunction
endclass
