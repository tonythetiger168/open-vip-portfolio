// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_transaction.svh -- CAN-FD transaction

class can_fd_transaction extends uvm_sequence_item;
  `uvm_object_utils(can_fd_transaction)

  // request (driven by the agent)
  rand bit ide;
  rand bit [28:0] id;
  rand bit rtr;
  rand bit fdf;
  rand bit brs;
  rand bit esi;
  rand bit [3:0] dlc;
  bit [7:0] data[$];
  rand canfd_err_e err_kind;
  // response (returned by the DUT)
  bit acked;
  bit eflag;
  bit rx_ok;
  bit pex;
  bit [2:0] err_code;
  bit [7:0] rec;
  bit err_pas;
  bit [28:0] out_id;
  bit out_ide;
  bit out_fdf;
  bit out_brs;
  bit out_esi;
  bit out_rtr;
  bit [3:0] out_dlc;
  bit [6:0] out_len;
  bit [15:0] out_sum;
  // bookkeeping (not compared)
  rand bit [31:0] seed;
  bit bits[$];
  bit fast[$];
  int unsigned ack_clk;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_fmt { fdf dist { 1 := 3, 0 := 1 };
                     !ide -> id[28:11] == 0;
                     fdf -> rtr == 0;
                     !fdf -> (brs == 0 && esi == 0);
                     brs dist { 1 := 3, 0 := 1 }; }
  constraint c_err { err_kind dist { FD_OK := 12, FD_STUFF := 1, FD_FORM := 1, FD_CRC := 1,
                                     FD_SC := 1, FD_FSB := 1, FD_PEX := 1 };
                     (err_kind inside {FD_SC, FD_FSB, FD_PEX}) -> fdf; }

  function new(string name = "can_fd_transaction"); super.new(name); endfunction

  function void post_randomize();
    bit [31:0] x = seed | 1;
    data.delete();
    for (int i = 0; i < canfd_len(dlc, fdf, rtr); i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      data.push_back(x[7:0]);
    end
    build();
  endfunction

  function void push(bit b, bit f);
    bits.push_back(b);
    fast.push_back(f);
  endfunction

  // line bits for the frame, with err_kind injected
  function void build();
    bit a[$], f[$];
    bit last = 1, s, fst = 0, dyn_done = 0;
    int run = 0, nsb = 0, brs_i = -1, ncrc;
    bit [14:0] c15 = 0;
    bit [16:0] c17 = CANFD_CRC17_INIT;
    bit [20:0] c21 = CANFD_CRC21_INIT, crc;
    bit [3:0] sc;
    if (err_kind == FD_STUFF) begin                   // SOF + four zeros force a stuff bit
      if (ide) id[28:25] = 4'h0; else id[10:7] = 4'h0;
    end
    bits.delete(); fast.delete();
    a.push_back(1'b0);
    if (ide) begin
      for (int i = 28; i >= 18; i--) a.push_back(id[i]);
      a.push_back(1'b1); a.push_back(1'b1);           // SRR, IDE
      for (int i = 17; i >= 0; i--) a.push_back(id[i]);
      a.push_back(fdf ? 1'b0 : rtr);                  // RTR / RRS
      a.push_back(fdf);
      if (!fdf) a.push_back(1'b0);                    // r0
    end else begin
      for (int i = 10; i >= 0; i--) a.push_back(id[i]);
      a.push_back(fdf ? 1'b0 : rtr); a.push_back(1'b0); a.push_back(fdf);
    end
    if (fdf) begin
      a.push_back(err_kind == FD_PEX);                // res
      a.push_back(brs); brs_i = a.size() - 1;
      a.push_back(esi);
    end
    for (int i = 3; i >= 0; i--) a.push_back(dlc[i]);
    foreach (data[j]) for (int i = 7; i >= 0; i--) a.push_back(data[j][i]);
    if (!fdf) begin                                   // CRC15 over the de-stuffed bits
      foreach (a[i]) c15 = canfd_crc15(c15, a[i]);
      if (err_kind == FD_CRC) c15[0] = !c15[0];
      for (int i = 14; i >= 0; i--) a.push_back(c15[i]);
    end
    // dynamic stuffing (FD: no stuff bit after the last data bit, the FSB follows)
    for (int i = 0; i <= a.size(); i++) begin
      if (run == 5 && (i < a.size() || !fdf)) begin
        s = !last;
        if (err_kind == FD_STUFF && !dyn_done) begin s = last; dyn_done = 1; end
        push(s, fst); c17 = canfd_crc17(c17, s); c21 = canfd_crc21(c21, s);
        nsb++; last = s; run = 1;
      end
      if (i == a.size()) break;
      push(a[i], fst); c17 = canfd_crc17(c17, a[i]); c21 = canfd_crc21(c21, a[i]);
      if (a[i] == last) run++; else begin last = a[i]; run = 1; end
      if (i == brs_i && brs) fst = 1;
    end
    if (fdf) begin
      sc = canfd_sc(nsb);
      for (int i = 3; i >= 0; i--) begin f.push_back(sc[i]); c17 = canfd_crc17(c17, sc[i]); c21 = canfd_crc21(c21, sc[i]); end
      ncrc = (data.size() <= 16) ? 17 : 21;
      crc = (ncrc == 17) ? {4'h0, c17} : c21;
      for (int i = ncrc - 1; i >= 0; i--) f.push_back(crc[i]);
      if (err_kind == FD_SC)  f[3] = !f[3];                       // SC parity
      if (err_kind == FD_CRC) f[f.size() - 1] = !f[f.size() - 1];   // CRC LSB
      foreach (f[i]) begin
        if (i % 4 == 0) begin                         // fixed stuff bit
          s = (err_kind == FD_FSB && i == 0) ? last : !last;
          push(s, fst); last = s;
        end
        push(f[i], fst); last = f[i];
      end
    end
    push(err_kind == FD_FORM ? 1'b0 : 1'b1, 1'b0);   // CRC delimiter
  endfunction

  function void do_copy(uvm_object rhs);
    can_fd_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    ide = rhs_.ide;
    id = rhs_.id;
    rtr = rhs_.rtr;
    fdf = rhs_.fdf;
    brs = rhs_.brs;
    esi = rhs_.esi;
    dlc = rhs_.dlc;
    data = rhs_.data;
    err_kind = rhs_.err_kind;
    acked = rhs_.acked;
    eflag = rhs_.eflag;
    rx_ok = rhs_.rx_ok;
    pex = rhs_.pex;
    err_code = rhs_.err_code;
    rec = rhs_.rec;
    err_pas = rhs_.err_pas;
    out_id = rhs_.out_id;
    out_ide = rhs_.out_ide;
    out_fdf = rhs_.out_fdf;
    out_brs = rhs_.out_brs;
    out_esi = rhs_.out_esi;
    out_rtr = rhs_.out_rtr;
    out_dlc = rhs_.out_dlc;
    out_len = rhs_.out_len;
    out_sum = rhs_.out_sum;
    seed = rhs_.seed;
    bits = rhs_.bits;
    fast = rhs_.fast;
    ack_clk = rhs_.ack_clk;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    can_fd_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (ide != rhs_.ide) return 0;
    if (id != rhs_.id) return 0;
    if (rtr != rhs_.rtr) return 0;
    if (fdf != rhs_.fdf) return 0;
    if (brs != rhs_.brs) return 0;
    if (esi != rhs_.esi) return 0;
    if (dlc != rhs_.dlc) return 0;
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (err_kind != rhs_.err_kind) return 0;
    if (acked != rhs_.acked) return 0;
    if (eflag != rhs_.eflag) return 0;
    if (rx_ok != rhs_.rx_ok) return 0;
    if (pex != rhs_.pex) return 0;
    if (err_code != rhs_.err_code) return 0;
    if (rec != rhs_.rec) return 0;
    if (err_pas != rhs_.err_pas) return 0;
    if (out_id != rhs_.out_id) return 0;
    if (out_ide != rhs_.out_ide) return 0;
    if (out_fdf != rhs_.out_fdf) return 0;
    if (out_brs != rhs_.out_brs) return 0;
    if (out_esi != rhs_.out_esi) return 0;
    if (out_rtr != rhs_.out_rtr) return 0;
    if (out_dlc != rhs_.out_dlc) return 0;
    if (out_len != rhs_.out_len) return 0;
    if (out_sum != rhs_.out_sum) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(can_fd_transaction rhs_);
    if (ide != rhs_.ide) return 0;
    if (id != rhs_.id) return 0;
    if (rtr != rhs_.rtr) return 0;
    if (fdf != rhs_.fdf) return 0;
    if (brs != rhs_.brs) return 0;
    if (esi != rhs_.esi) return 0;
    if (dlc != rhs_.dlc) return 0;
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (err_kind != rhs_.err_kind) return 0;
    return 1;
  endfunction

  function string qstr_data();
    string s = $sformatf("[%0d]{", data.size());
    foreach (data[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", data[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_bits();
    string s = $sformatf("[%0d]{", bits.size());
    foreach (bits[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bits[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_fast();
    string s = $sformatf("[%0d]{", fast.size());
    foreach (fast[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", fast[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("CAN-FD{tag=%0d ide=0x%0h id=0x%0h rtr=0x%0h fdf=0x%0h brs=0x%0h esi=0x%0h dlc=0x%0h data=%s err_kind=0x%0h acked=0x%0h eflag=0x%0h rx_ok=0x%0h pex=0x%0h err_code=0x%0h rec=0x%0h err_pas=0x%0h out_id=0x%0h out_ide=0x%0h out_fdf=0x%0h out_brs=0x%0h out_esi=0x%0h out_rtr=0x%0h out_dlc=0x%0h out_len=0x%0h out_sum=0x%0h}", tag, ide, id, rtr, fdf, brs, esi, dlc, qstr_data(), err_kind, acked, eflag, rx_ok, pex, err_code, rec, err_pas, out_id, out_ide, out_fdf, out_brs, out_esi, out_rtr, out_dlc, out_len, out_sum);
  endfunction
endclass
