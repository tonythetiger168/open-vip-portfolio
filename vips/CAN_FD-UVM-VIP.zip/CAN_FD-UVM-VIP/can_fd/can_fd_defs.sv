// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_defs.sv -- CAN-FD shared type definitions

package can_fd_defs_pkg;

  typedef enum bit [1:0] {CAN_FD_OK, CAN_FD_ERR} can_fd_status_e;

  // serial CRCs, MSB first: c = (c << 1) ^ poly when (bit ^ c[msb])
  localparam bit [14:0] CANFD_CRC15_POLY = 15'h4599;
  localparam bit [16:0] CANFD_CRC17_POLY = 17'h1685B;
  localparam bit [16:0] CANFD_CRC17_INIT = 17'h10000;
  localparam bit [20:0] CANFD_CRC21_POLY = 21'h102899;
  localparam bit [20:0] CANFD_CRC21_INIT = 21'h100000;

  // injected error (FD_SC / FD_FSB / FD_PEX need an FD frame)
  typedef enum bit [2:0] {FD_OK, FD_STUFF, FD_FORM, FD_CRC, FD_SC, FD_FSB, FD_PEX} canfd_err_e;

  function automatic bit [14:0] canfd_crc15(bit [14:0] c, bit b);
    bit fb = b ^ c[14];
    c = c << 1;
    return fb ? c ^ CANFD_CRC15_POLY : c;
  endfunction

  function automatic bit [16:0] canfd_crc17(bit [16:0] c, bit b);
    bit fb = b ^ c[16];
    c = c << 1;
    return fb ? c ^ CANFD_CRC17_POLY : c;
  endfunction

  function automatic bit [20:0] canfd_crc21(bit [20:0] c, bit b);
    bit fb = b ^ c[20];
    c = c << 1;
    return fb ? c ^ CANFD_CRC21_POLY : c;
  endfunction

  // stuff count field: Gray code of the dynamic stuff bits mod 8, parity
  function automatic bit [3:0] canfd_sc(int unsigned nsb);
    bit [2:0] b = nsb % 8;
    bit [2:0] g = b ^ (b >> 1);
    return {g, ^g};
  endfunction

  // data bytes for a DLC
  function automatic int unsigned canfd_len(bit [3:0] dlc, bit fdf, bit rtr);
    if (!fdf) return rtr ? 0 : ((dlc > 8) ? 8 : dlc);
    case (dlc)
      4'd9:  return 12;
      4'd10: return 16;
      4'd11: return 20;
      4'd12: return 24;
      4'd13: return 32;
      4'd14: return 48;
      4'd15: return 64;
      default: return dlc;
    endcase
  endfunction

  // error code reported by the receiver for an injected error
  function automatic bit [2:0] canfd_code(canfd_err_e e, bit pex_en);
    case (e)
      FD_STUFF:      return 3'd1;
      FD_FORM:       return 3'd2;
      FD_CRC, FD_SC: return 3'd3;
      FD_FSB:        return 3'd4;
      FD_PEX:        return pex_en ? 3'd0 : 3'd2;
      default:       return 3'd0;
    endcase
  endfunction

endpackage
