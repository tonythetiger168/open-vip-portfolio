// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_compliance_checker.sv -- CAN-FD concurrent assertion checks (bindable)

module can_fd_compliance_checker
  (input logic clk, input logic rst_n, input rx, input tx, input [3:0] error_cnt, input stuff_err);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tx, error_cnt, stuff_err}))
    else $error("CAN-FD: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> tx == '0)
    else $error("CAN-FD: output not in reset value");
  // tx is recessive whenever the delay pipe is in IFS
  assert property (@(posedge clk) disable iff (!rst_n) 1'b1 |-> tx == 1'b1)
    else $error("CANFD: tx dominant during IFS");
  cover property (@(posedge clk) disable iff (!rst_n) (tx != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (error_cnt != 4'h0));
endmodule
