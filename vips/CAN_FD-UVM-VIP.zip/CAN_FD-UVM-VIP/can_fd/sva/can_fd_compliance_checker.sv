// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_compliance_checker.sv -- CAN-FD concurrent assertion checks (bindable)

module can_fd_compliance_checker
  (input logic clk, input logic rst_n, input logic rx, input logic [3:0] nbt, input logic [3:0] dbt, input logic pex_en, input logic [28:0] acc_id, input logic [28:0] acc_msk, input logic tx, input logic rx_ok, input logic rx_err, input logic pex, input logic [2:0] err_code, input logic [7:0] rec, input logic err_pas, input logic [28:0] out_id, input logic out_ide, input logic out_fdf, input logic out_brs, input logic out_esi, input logic out_rtr, input logic [3:0] out_dlc, input logic [6:0] out_len, input logic [15:0] out_sum);

  // outputs never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tx, rx_ok, rx_err, pex, err_code, rec, err_pas}))
    else $error("CAN FD: X on outputs");
  // recessive in reset
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |=> tx)
    else $error("CAN FD: tx not recessive in reset");
  // a good frame, an error and a protocol exception are never reported together
  assert property (@(posedge clk) disable iff (!rst_n) !(rx_ok && rx_err) && !(pex && rx_err) && !(pex && rx_ok))
    else $error("CAN FD: rx_ok / rx_err / pex together");
  // error passive from a receive error count of 128
  assert property (@(posedge clk) disable iff (!rst_n) err_pas == rec[7])
    else $error("CAN FD: err_pas does not follow rec");
  // an error moves the counter up by one (saturating)
  assert property (@(posedge clk) disable iff (!rst_n) rx_err |-> rec == $past(rec) + 8'd1 || $past(rec) == 8'hFF)
    else $error("CAN FD: receive error counter not incremented");
  // tx is dominant for at most six nominal bits in a row (the error flag)
  int unsigned low_clk;
  always @(posedge clk or negedge rst_n)
    if (!rst_n) low_clk <= 0;
    else low_clk <= tx ? 0 : low_clk + 1;
  assert property (@(posedge clk) disable iff (!rst_n) low_clk <= 6 * ((nbt == 4'd0) ? 1 : nbt))
    else $error("CAN FD: tx dominant for more than six nominal bits");
  cover property (@(posedge clk) disable iff (!rst_n) rx_ok && out_fdf && out_brs);
  cover property (@(posedge clk) disable iff (!rst_n) rx_err && err_code == 3'd4);
  cover property (@(posedge clk) disable iff (!rst_n) pex);
endmodule
