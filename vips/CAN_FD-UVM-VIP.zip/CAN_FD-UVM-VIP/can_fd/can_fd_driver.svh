// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_driver.svh -- CAN-FD driver: idle recessive bits, then the frame's line bits one per clock

class can_fd_driver extends uvm_driver #(can_fd_transaction);
  `uvm_component_utils(can_fd_driver)

  uvm_analysis_port #(can_fd_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual can_fd_if vif;
  can_fd_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual can_fd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "can_fd: virtual interface not set")
    if (!uvm_config_db#(can_fd_config)::get(this, "", "cfg", cfg))
      cfg = can_fd_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    can_fd_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.rx <= 1'b1;
  endtask

  task drive_item(can_fd_transaction t);
    @(vif.drv_cb);
    repeat (cfg.idle_bits) begin vif.drv_cb.rx <= 1'b1; @(vif.drv_cb); end
    foreach (t.bits[i]) begin vif.drv_cb.rx <= t.bits[i]; @(vif.drv_cb); end
    vif.drv_cb.rx <= 1'b1;
  endtask

endclass
