// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_driver.svh -- CAN-FD driver: reset, then per-item protocol stimulus

class can_fd_driver extends uvm_driver #(can_fd_transaction);
  `uvm_component_utils(can_fd_driver)

  virtual can_fd_if vif;
  can_fd_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual can_fd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "can_fd: virtual interface not set")
    void'(uvm_config_db#(can_fd_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    vif.drv_cb.rst_n <= 1'b0;
    repeat (8) @(vif.drv_cb);
    vif.drv_cb.rst_n <= 1'b1;
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_item(can_fd_transaction item);
    item.tag = item_cnt++;
    vif.rx <= item.rx;
    @(vif.drv_cb);
    ap.write(item);
  endtask
endclass
