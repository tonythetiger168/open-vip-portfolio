// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_if.sv -- CAN-FD interface

interface can_fd_if (input logic clk);
  logic rst_n;

  logic rx;
  logic [3:0] nbt;
  logic [3:0] dbt;
  logic pex_en;
  logic [28:0] acc_id;
  logic [28:0] acc_msk;
  logic tx;
  logic rx_ok;
  logic rx_err;
  logic pex;
  logic [2:0] err_code;
  logic [7:0] rec;
  logic err_pas;
  logic [28:0] out_id;
  logic out_ide;
  logic out_fdf;
  logic out_brs;
  logic out_esi;
  logic out_rtr;
  logic [3:0] out_dlc;
  logic [6:0] out_len;
  logic [15:0] out_sum;

  modport DUT (input clk, rst_n, input rx, input nbt, input dbt, input pex_en, input acc_id, input acc_msk, output tx, output rx_ok, output rx_err, output pex, output err_code, output rec, output err_pas, output out_id, output out_ide, output out_fdf, output out_brs, output out_esi, output out_rtr, output out_dlc, output out_len, output out_sum);
  modport MON (input clk, rst_n, rx, nbt, dbt, pex_en, acc_id, acc_msk, tx, rx_ok, rx_err, pex, err_code, rec, err_pas, out_id, out_ide, out_fdf, out_brs, out_esi, out_rtr, out_dlc, out_len, out_sum);

  clocking drv_cb @(posedge clk);
    input rst_n, tx, rx_ok, rx_err, pex, err_code, rec, err_pas, out_id, out_ide, out_fdf, out_brs, out_esi, out_rtr, out_dlc, out_len, out_sum;
    inout rx, nbt, dbt, pex_en, acc_id, acc_msk;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, rx, nbt, dbt, pex_en, acc_id, acc_msk, tx, rx_ok, rx_err, pex, err_code, rec, err_pas, out_id, out_ide, out_fdf, out_brs, out_esi, out_rtr, out_dlc, out_len, out_sum;
  endclocking
endinterface
