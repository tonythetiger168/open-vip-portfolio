// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_if.sv -- CAN-FD interface

interface can_fd_if (input logic clk);
  logic rst_n;

  logic rx;
  logic tx;
  logic [3:0] error_cnt;
  logic stuff_err;

  modport DUT (input clk, rst_n, rx, output tx, error_cnt, stuff_err);
  modport DRV (input clk, rst_n, tx, error_cnt, stuff_err, output rx);
  modport MON (input clk, rst_n, rx, tx, error_cnt, stuff_err);

  clocking drv_cb @(posedge clk);
    input rst_n, rx, tx, error_cnt, stuff_err;
    output rx;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, rx, tx, error_cnt, stuff_err;
  endclocking
endinterface
