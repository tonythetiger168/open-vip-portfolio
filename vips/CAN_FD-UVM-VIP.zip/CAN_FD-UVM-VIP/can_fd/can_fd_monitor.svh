// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_monitor.svh -- CAN-FD monitor: decodes observed bus activity

class can_fd_monitor extends uvm_monitor;
  `uvm_component_utils(can_fd_monitor)

  virtual can_fd_if vif;
  uvm_analysis_port #(can_fd_transaction) ap;
  can_fd_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual can_fd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "can_fd: virtual interface not set")
    void'(uvm_config_db#(can_fd_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    can_fd_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = can_fd_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.rx = vif.rx;
        t.tx_o = vif.tx;
        t.error_cnt_o = vif.error_cnt;
        t.stuff_err_o = vif.stuff_err;
        ap.write(t);
      end
    end
  endtask
endclass
