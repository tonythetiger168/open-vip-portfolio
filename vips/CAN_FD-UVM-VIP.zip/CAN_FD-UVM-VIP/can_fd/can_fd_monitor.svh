// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_monitor.svh -- CAN-FD monitor: frames from SOF (after 8 idle bits) to 8 recessive bits; stuff errors and tx loopback checked

class can_fd_monitor extends uvm_monitor;
  `uvm_component_utils(can_fd_monitor)

  virtual can_fd_if vif;
  uvm_analysis_port #(can_fd_transaction) ap;
  can_fd_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual can_fd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "can_fd: virtual interface not set")
    if (!uvm_config_db#(can_fd_config)::get(this, "", "cfg", cfg))
      cfg = can_fd_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      can_fd_transaction t;
      int unsigned ones = 0;
      bit rx_h1 = 1, rx_h2 = 1;      // rx one and two clocks ago
      bit [7:0] lerr = 0;
      forever begin
        bit rx;
        @(vif.mon_cb);
        rx = vif.mon_cb.rx;
        if (vif.mon_cb.tx == 1'b0 && rx_h2 != 1'b0) lerr++;
        rx_h2 = rx_h1; rx_h1 = rx;
        if (t == null) begin
          if (rx == 1'b0 && ones >= 8) begin
            t = can_fd_transaction::type_id::create("t");
            t.bits.push_back(1'b0);
            lerr = 0;
          end
          ones = rx ? ones + 1 : 0;
        end else begin
          t.bits.push_back(rx);
          ones = rx ? ones + 1 : 0;
          if (vif.mon_cb.stuff_err) t.stuff_errs++;
          if (ones == 8) begin
            while (t.bits.size() > 1 && t.bits[t.bits.size() - 1] == 1'b1) void'(t.bits.pop_back());
            t.error_cnt = vif.mon_cb.error_cnt;
            t.loop_errs = lerr;
            t.unstuff();
            publish(t);
            t = null;
          end
        end
      end
    end
  endtask

  function void publish(can_fd_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
