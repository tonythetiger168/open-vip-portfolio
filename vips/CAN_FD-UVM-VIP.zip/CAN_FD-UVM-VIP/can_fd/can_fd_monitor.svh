// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_monitor.svh -- CAN-FD monitor: frames from SOF to the end of EOF; own bit timing (nominal / data rate), de-stuffer, field decoder and CRC / SC / FSB checks; DUT ACK, error flag and outputs

class can_fd_monitor extends uvm_monitor;
  `uvm_component_utils(can_fd_monitor)

  virtual can_fd_if vif;
  uvm_analysis_port #(can_fd_transaction) ap;
  can_fd_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual can_fd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "can_fd: virtual interface not set")
    if (!uvm_config_db#(can_fd_config)::get(this, "", "cfg", cfg))
      cfg = can_fd_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit rxq[$], txq[$];
      int unsigned ones = 0;
      bit in_frame = 0, okp = 0, errp = 0, pexp = 0;
      forever begin
        bit rx;
        @(vif.mon_cb);
        rx = vif.mon_cb.rx;
        if (!in_frame && rx == 1'b0 && ones >= 10 * cfg.nbt) begin
          in_frame = 1; rxq.delete(); txq.delete(); okp = 0; errp = 0; pexp = 0;
        end
        if (in_frame) begin
          rxq.push_back(rx); txq.push_back(vif.mon_cb.tx);
          if (vif.mon_cb.rx_ok) okp = 1;
          if (vif.mon_cb.rx_err) errp = 1;
          if (vif.mon_cb.pex) pexp = 1;
          // a frame never holds 8 recessive nominal bits before its ACK slot
          if (rx && ones >= 8 * cfg.nbt) begin
            can_fd_transaction t = can_fd_transaction::type_id::create("t");
            dq = rxq;
            if (decode(t) && t.ack_clk + 8 * cfg.nbt < rxq.size()) begin
              // tx sampled with the ACK slot is the DUT's ACK (or its error flag)
              t.eflag = errp;
              t.acked = !txq[t.ack_clk] && !errp;
              t.rx_ok = okp;
              t.pex = pexp;
              t.err_code = vif.mon_cb.err_code; t.rec = vif.mon_cb.rec; t.err_pas = vif.mon_cb.err_pas;
              t.out_id = vif.mon_cb.out_id; t.out_ide = vif.mon_cb.out_ide; t.out_fdf = vif.mon_cb.out_fdf;
              t.out_brs = vif.mon_cb.out_brs; t.out_esi = vif.mon_cb.out_esi; t.out_rtr = vif.mon_cb.out_rtr;
              t.out_dlc = vif.mon_cb.out_dlc; t.out_len = vif.mon_cb.out_len; t.out_sum = vif.mon_cb.out_sum;
              publish(t);
              in_frame = 0;
            end else if (ones >= 20 * cfg.nbt) begin
              `uvm_error("MON", "CAN FD frame could not be decoded")
              in_frame = 0;
            end
          end
        end
        ones = rx ? ones + 1 : 0;
      end
    end
  endtask

  function void publish(can_fd_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // independent decoder over the clock samples of one frame (from SOF)
  bit dq[$];
  int unsigned dp, dsmp;
  bit dfast, dshort, dlast;
  int unsigned drun, dnsb;
  bit [14:0] d15;
  bit [16:0] d17;
  bit [20:0] d21;
  canfd_err_e de;

  // next line bit, sampled in the middle of its bit time
  function bit rb();
    int unsigned L = dfast ? cfg.dbt : cfg.nbt;
    if (dp + L > dq.size()) begin dshort = 1; return 1'b1; end
    dsmp = dp + L / 2;
    dp += L;
    return dq[dsmp];
  endfunction

  // next de-stuffed bit; crc15 = 0 for the CRC15 field itself
  function bit db(bit crc15 = 1);
    bit b;
    if (drun == 5) begin
      b = rb();
      if (b == dlast && de == FD_OK) de = FD_STUFF;
      d17 = canfd_crc17(d17, b); d21 = canfd_crc21(d21, b);
      dnsb++; dlast = b; drun = 1;
    end
    b = rb();
    if (crc15) begin d15 = canfd_crc15(d15, b); d17 = canfd_crc17(d17, b); d21 = canfd_crc21(d21, b); end
    drun = (b == dlast) ? drun + 1 : 1;
    dlast = b;
    return b;
  endfunction

  // returns 0 while the frame is incomplete
  function bit decode(can_fd_transaction t);
    bit b, crc_bad = 0;
    bit [3:0] sc;
    bit [20:0] rc = 0;
    int unsigned n;
    dp = 0; dfast = 0; dshort = 0; dlast = 1; drun = 0; dnsb = 0; de = FD_OK;
    d15 = 0; d17 = CANFD_CRC17_INIT; d21 = CANFD_CRC21_INIT;
    t.id = 0; t.dlc = 0;
    void'(db());                                     // SOF
    for (int i = 0; i < 11; i++) t.id = {t.id[27:0], db()};
    b = db();                                        // RTR (base) / SRR (extended)
    t.ide = db();
    if (t.ide) begin
      for (int i = 0; i < 18; i++) t.id = {t.id[27:0], db()};
      t.rtr = db();
    end else t.rtr = b;
    t.fdf = db();
    t.brs = 0; t.esi = 0;
    if (t.fdf) begin
      t.rtr = 0;                                     // RRS
      if (db() && de == FD_OK) de = FD_PEX;
      t.brs = db();
      if (t.brs) dfast = 1;
      t.esi = db();
    end else if (t.ide) void'(db());                 // r0
    for (int i = 0; i < 4; i++) t.dlc = {t.dlc[2:0], db()};
    n = canfd_len(t.dlc, t.fdf, t.rtr);
    t.data.delete();
    for (int j = 0; j < n; j++) begin
      bit [7:0] v;
      for (int i = 0; i < 8; i++) v = {v[6:0], db()};
      t.data.push_back(v);
    end
    if (dshort) return 0;
    if (t.fdf) begin
      int unsigned ncrc = (n <= 16) ? 17 : 21;
      for (int i = 0; i < 4 + ncrc; i++) begin
        if (i % 4 == 0) begin                        // fixed stuff bit
          b = rb();
          if (b == dlast && de == FD_OK) de = FD_FSB;
          dlast = b;
        end
        b = rb(); dlast = b;
        if (i < 4) begin sc = {sc[2:0], b}; d17 = canfd_crc17(d17, b); d21 = canfd_crc21(d21, b); end
        else rc = {rc[19:0], b};
      end
      if (sc != canfd_sc(dnsb)) crc_bad = 1;
      if (ncrc == 17 ? (rc[16:0] != d17) : (rc != d21)) crc_bad = 1;
      if (crc_bad && de == FD_OK) de = (sc != canfd_sc(dnsb)) ? FD_SC : FD_CRC;
    end else begin
      bit [14:0] c = d15;
      for (int i = 0; i < 15; i++) rc = {rc[19:0], db(0)};
      if (drun == 5) begin                           // stuff bit after the last CRC bit
        b = rb();
        if (b == dlast && de == FD_OK) de = FD_STUFF;
      end
      if (rc[14:0] != c && de == FD_OK) de = FD_CRC;
    end
    dfast = 0;
    b = rb();                                        // CRC delimiter
    if (!b && (de == FD_OK || de == FD_CRC || de == FD_SC)) de = FD_FORM;
    t.ack_clk = dp + cfg.nbt / 2;
    if (dshort) return 0;
    t.err_kind = de;
    return 1;
  endfunction
endclass
