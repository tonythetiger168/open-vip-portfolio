// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_sequencer.svh -- CAN-FD sequencer

class can_fd_sequencer extends uvm_sequencer #(can_fd_transaction);
  `uvm_component_utils(can_fd_sequencer)
  function new(string name = "can_fd_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
