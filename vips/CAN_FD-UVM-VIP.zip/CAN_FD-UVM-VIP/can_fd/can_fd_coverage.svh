// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_coverage.svh -- CAN-FD functional coverage

class can_fd_coverage extends uvm_subscriber #(can_fd_transaction);
  `uvm_component_utils(can_fd_coverage)
  can_fd_config cfg;
  can_fd_transaction tr;

  covergroup can_fd_cg;
    cp_err : coverpoint tr.err_kind;
    cp_fdf : coverpoint tr.fdf;
    cp_ide : coverpoint tr.ide;
    cp_dlc : coverpoint tr.dlc;
    cp_brs : coverpoint tr.brs iff (tr.fdf);
    cp_esi : coverpoint tr.esi iff (tr.fdf);
    cp_rtr : coverpoint tr.rtr iff (!tr.fdf);
    cp_ok  : coverpoint tr.rx_ok;
    cp_pas : coverpoint tr.err_pas;
    x_fmt_dlc : cross cp_fdf, cp_ide, cp_dlc;
    cp_err_fd  : coverpoint tr.err_kind iff (tr.fdf);
    cp_err_cls : coverpoint tr.err_kind iff (!tr.fdf) { bins k[] = {FD_OK, FD_STUFF, FD_FORM, FD_CRC}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    can_fd_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(can_fd_config)::get(this, "", "cfg", cfg))
      cfg = can_fd_config::type_id::create("cfg");
  endfunction

  function void write(can_fd_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    can_fd_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CAN-FD coverage: %0.1f%%", can_fd_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
