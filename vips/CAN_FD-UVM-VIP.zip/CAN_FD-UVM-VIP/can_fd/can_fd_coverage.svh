// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_coverage.svh -- CAN-FD functional coverage

class can_fd_coverage extends uvm_subscriber #(can_fd_transaction);
  `uvm_component_utils(can_fd_coverage)
  can_fd_config cfg;
  can_fd_transaction tr;

  covergroup can_fd_cg;
    coverpoint tr.rx;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(can_fd_config)::get(this, "*", "cfg", cfg));
    can_fd_cg = new();
  endfunction

  function void write(can_fd_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    can_fd_cg.sample();
  endfunction
endclass
