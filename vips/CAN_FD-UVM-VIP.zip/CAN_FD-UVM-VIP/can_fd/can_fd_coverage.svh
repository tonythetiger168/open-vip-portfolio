// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_fd_coverage.svh -- CAN-FD functional coverage

class can_fd_coverage extends uvm_subscriber #(can_fd_transaction);
  `uvm_component_utils(can_fd_coverage)
  can_fd_config cfg;
  can_fd_transaction tr;

  covergroup can_fd_cg;
    cp_err  : coverpoint tr.inject_err;
    cp_len  : coverpoint tr.nbits { bins short_ = {[1:8]}; bins mid = {[9:24]}; bins long_ = {[25:32]}; }
    cp_serr : coverpoint tr.stuff_errs { bins none = {0}; bins one = {1}; bins more = {[2:$]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    can_fd_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(can_fd_config)::get(this, "", "cfg", cfg))
      cfg = can_fd_config::type_id::create("cfg");
  endfunction

  function void write(can_fd_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    can_fd_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CAN-FD coverage: %0.1f%%", can_fd_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
