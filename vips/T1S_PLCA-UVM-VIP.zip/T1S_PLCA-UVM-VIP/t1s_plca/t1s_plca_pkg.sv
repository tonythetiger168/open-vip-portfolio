// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_pkg.sv -- 10BASE-T1S PLCA UVM VIP package

package t1s_plca_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import t1s_plca_defs_pkg::*;
  export t1s_plca_defs_pkg::*;

  `include "t1s_plca_transaction.svh"
  `include "t1s_plca_config.svh"
  `include "t1s_plca_sequencer.svh"
  `include "t1s_plca_driver.svh"
  `include "t1s_plca_monitor.svh"
  `include "t1s_plca_agent.svh"
  `include "t1s_plca_sequences.svh"
  `include "t1s_plca_checker.svh"
  `include "t1s_plca_coverage.svh"
endpackage
