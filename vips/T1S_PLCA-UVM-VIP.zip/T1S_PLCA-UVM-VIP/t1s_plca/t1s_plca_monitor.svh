// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_monitor.svh -- 10BASE-T1S PLCA monitor: nibbles while TX_EN collected into a frame, completed by the segment's report

class t1s_plca_monitor extends uvm_monitor;
  `uvm_component_utils(t1s_plca_monitor)

  virtual t1s_plca_if vif;
  uvm_analysis_port #(t1s_plca_transaction) ap;
  t1s_plca_config cfg;
  int unsigned n_obs = 0;

  t1s_plca_transaction cur; bit [3:0] nib[$]; bit [7:0] done_q[$][$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual t1s_plca_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "t1s_plca: virtual interface not set")
    if (!uvm_config_db#(t1s_plca_config)::get(this, "", "cfg", cfg))
      cfg = t1s_plca_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rep_valid) begin
          t1s_plca_transaction t = t1s_plca_transaction::type_id::create("t");
          if (done_q.size() == 0) `uvm_error("MON", "PLCA: frame report without a frame")
          else begin
            bit [7:0] b[$] = done_q.pop_front();
            // the last four bytes are the FCS
            for (int i = 0; i + 4 < b.size(); i++) t.bytes.push_back(b[i]);
          end
          t.slot = vif.mon_cb.rep_slot; t.ok = vif.mon_cb.rep_ok; t.err = vif.mon_cb.rep_err;
          publish(t);
        end
        if (vif.mon_cb.tx_en === 1'b1) nib.push_back(vif.mon_cb.txd);
        else if (nib.size() != 0) begin
          bit [7:0] b[$];
          for (int i = 0; i + 1 < nib.size(); i += 2) b.push_back({nib[i + 1], nib[i]});
          if (nib.size() % 2) `uvm_error("MON", "PLCA: odd number of nibbles")
          done_q.push_back(b);
          nib.delete();
        end
      end
    end
  endtask

  function void publish(t1s_plca_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
