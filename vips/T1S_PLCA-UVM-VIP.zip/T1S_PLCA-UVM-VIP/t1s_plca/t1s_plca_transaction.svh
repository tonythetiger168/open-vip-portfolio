// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_transaction.svh -- 10BASE-T1S PLCA transaction

class t1s_plca_transaction extends uvm_sequence_item;
  `uvm_object_utils(t1s_plca_transaction)

  // request (driven by the agent)
  bit [7:0] bytes[$];
  // response (returned by the DUT)
  bit [3:0] slot;
  bit ok;
  bit err;
  // bookkeeping (not compared)
  rand bit [5:0] nbytes;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len { nbytes inside {[1:40]}; }

  function new(string name = "t1s_plca_transaction"); super.new(name); endfunction

  function void fill_bytes(int unsigned n);
    bit [31:0] x = seed | 32'h1;
    bytes.delete();
    for (int unsigned i = 0; i < n; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      bytes.push_back(x[7:0]);
    end
  endfunction

  function void post_randomize();
    fill_bytes(nbytes);
  endfunction

  // IEEE 802.3 CRC-32 of the payload (reflected, init / final xor all ones)
  function bit [31:0] fcs();
    bit [31:0] c = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      c ^= {24'h0, bytes[i]};
      for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    return ~c;
  endfunction

  function void do_copy(uvm_object rhs);
    t1s_plca_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    bytes = rhs_.bytes;
    slot = rhs_.slot;
    ok = rhs_.ok;
    err = rhs_.err;
    nbytes = rhs_.nbytes;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    t1s_plca_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (slot != rhs_.slot) return 0;
    if (ok != rhs_.ok) return 0;
    if (err != rhs_.err) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(t1s_plca_transaction rhs_);
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    return 1;
  endfunction

  function string qstr_bytes();
    string s = $sformatf("[%0d]{", bytes.size());
    foreach (bytes[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bytes[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("10BASE-T1S PLCA{tag=%0d bytes=%s slot=0x%0h ok=0x%0h err=0x%0h}", tag, qstr_bytes(), slot, ok, err);
  endfunction
endclass
