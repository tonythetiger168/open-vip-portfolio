// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_driver.svh -- 10BASE-T1S PLCA driver: tracks the PLCA transmit opportunities from the BEACON and the carrier, sends one frame (payload + FCS, low nibble first) in each opportunity of its own node ID

class t1s_plca_driver extends uvm_driver #(t1s_plca_transaction);
  `uvm_component_utils(t1s_plca_driver)

  uvm_analysis_port #(t1s_plca_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual t1s_plca_if vif;
  t1s_plca_config cfg;

  // PLCA state, updated every clock by the background process
  int unsigned cur, tmr;
  bit busy, synced, my_tx, used;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual t1s_plca_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "t1s_plca: virtual interface not set")
    if (!uvm_config_db#(t1s_plca_config)::get(this, "", "cfg", cfg))
      cfg = t1s_plca_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    t1s_plca_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      forever begin
        bit beacon, act;
        @(vif.drv_cb);
        beacon = vif.drv_cb.beacon === 1'b1;
        act = vif.drv_cb.crs === 1'b1 || my_tx;
        // one clock of the PLCA transmit-opportunity counter (same rule as the
        // segment model): act = a carrier on the segment this clock
        if (beacon) begin cur = 0; tmr = 0; busy = 0; synced = 1; end
        else if (act) busy = 1;
        else if (busy) begin cur++; tmr = 0; busy = 0; end
        else if (tmr == 8 - 1) begin cur++; tmr = 0; end
        else tmr++;
        if (tmr == 0 && !busy) used = 0;     // a new opportunity
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.tx_en <= 1'b0; vif.drv_cb.txd <= '0;
  endtask

  task drive_item(t1s_plca_transaction t);
    bit [7:0] fr[$];
    bit [31:0] f = t.fcs();
    fr = t.bytes;
    for (int i = 0; i < 4; i++) fr.push_back(f[i*8 +: 8]);
    // wait for an unused opportunity of this node with room to start before
    // TO_TIMER runs out (the driver's state is updated at the same clock edge)
    begin
      int unsigned to = 0;
      do begin @(vif.drv_cb); #0; to++; end
      while (!(synced && cur == cfg.local_id && !busy && !used && tmr <= 8 - 3 && vif.drv_cb.crs !== 1'b1)
             && to < cfg.timeout_cycles * 4);
      if (to >= cfg.timeout_cycles * 4) `uvm_error("TIMEOUT", "PLCA: no transmit opportunity of this node")
    end
    used = 1;
    my_tx = 1;
    foreach (fr[i]) begin
      vif.drv_cb.tx_en <= 1'b1; vif.drv_cb.txd <= fr[i][3:0];
      @(vif.drv_cb);
      vif.drv_cb.txd <= fr[i][7:4];
      @(vif.drv_cb);
    end
    vif.drv_cb.tx_en <= 1'b0; vif.drv_cb.txd <= '0;
    @(vif.drv_cb);
    my_tx = 0;
  endtask

endclass
