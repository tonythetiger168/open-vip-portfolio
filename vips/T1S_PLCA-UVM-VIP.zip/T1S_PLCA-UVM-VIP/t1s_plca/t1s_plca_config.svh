// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_config.svh -- 10BASE-T1S PLCA agent configuration

class t1s_plca_config extends uvm_object;
  `uvm_object_utils(t1s_plca_config)
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  bit coverage_enable = 1;
  bit checks_enable   = 1;
  int unsigned num_items      = 32;     // random items per base sequence
  int unsigned timeout_cycles = 400;   // handshake / response watchdog
  int unsigned local_id = 3;   // PLCA node ID of the agent
  int unsigned nodes    = 8;     // node count (PLCA nodes)
  function new(string name = "t1s_plca_config"); super.new(name); endfunction
endclass
