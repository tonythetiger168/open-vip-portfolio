// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_agent.svh -- 10BASE-T1S PLCA agent

class t1s_plca_agent extends uvm_agent;
  `uvm_component_utils(t1s_plca_agent)

  t1s_plca_sequencer sqr;
  t1s_plca_driver    drv;
  t1s_plca_monitor   mon;
  t1s_plca_config    cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(t1s_plca_config)::get(this, "", "cfg", cfg)) begin
      cfg = t1s_plca_config::type_id::create("cfg");
      uvm_config_db#(t1s_plca_config)::set(this, "*", "cfg", cfg);
    end
    is_active = cfg.is_active;
    mon = t1s_plca_monitor::type_id::create("mon", this);
    if (is_active == UVM_ACTIVE) begin
      sqr = t1s_plca_sequencer::type_id::create("sqr", this);
      drv = t1s_plca_driver   ::type_id::create("drv", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (is_active == UVM_ACTIVE)
      drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
