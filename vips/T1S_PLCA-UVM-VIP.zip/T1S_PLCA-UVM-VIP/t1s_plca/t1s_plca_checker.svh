// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_checker.svh -- 10BASE-T1S PLCA protocol checker on monitored items

class t1s_plca_checker extends uvm_component;
  `uvm_component_utils(t1s_plca_checker)
  uvm_analysis_imp #(t1s_plca_transaction, t1s_plca_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  t1s_plca_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(t1s_plca_config)::get(this, "", "cfg", cfg))
      cfg = t1s_plca_config::type_id::create("cfg");
  endfunction

  function void fail(t1s_plca_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("10BASE-T1S PLCA: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(t1s_plca_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.err) fail(t, "frame started outside this node's transmit opportunity or over a carrier");
      if (!t.ok) fail(t, "segment saw a bad FCS");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("10BASE-T1S PLCA checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
