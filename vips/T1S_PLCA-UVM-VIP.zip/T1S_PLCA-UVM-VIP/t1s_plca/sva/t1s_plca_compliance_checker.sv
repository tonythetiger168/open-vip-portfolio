// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_compliance_checker.sv -- 10BASE-T1S PLCA concurrent assertion checks (bindable)

module t1s_plca_compliance_checker
  (input logic clk, input logic rst_n, input logic tx_en, input logic [3:0] txd, input logic beacon, input logic crs, input logic rep_valid, input logic [3:0] rep_slot, input logic rep_ok, input logic rep_err);

  logic tx_d;
  always_ff @(posedge clk or negedge rst_n) if (!rst_n) tx_d <= 1'b0; else tx_d <= tx_en;
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tx_en, beacon, crs, rep_valid}))
    else $error("PLCA: X on TX_EN / BEACON / CRS / report");
  assert property (@(posedge clk) disable iff (!rst_n) tx_en |-> !$isunknown(txd))
    else $error("PLCA: X on TXD while TX_EN");
  // a frame never starts during the BEACON or over another node's carrier
  assert property (@(posedge clk) disable iff (!rst_n) $rose(tx_en) |-> !crs)
    else $error("PLCA: frame started over a carrier");
  // the BEACON lasts 4 clocks
  assert property (@(posedge clk) disable iff (!rst_n) $rose(beacon) |-> beacon [*4] ##1 !beacon)
    else $error("PLCA: BEACON length");
  // a report follows the end of each frame, one clock later
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |-> $past(tx_d && !tx_en))
    else $error("PLCA: report without the end of a frame");
  assert property (@(posedge clk) disable iff (!rst_n) $fell(tx_en) |=> rep_valid)
    else $error("PLCA: frame not reported");
  cover property (@(posedge clk) disable iff (!rst_n) crs && !beacon ##[1:$] $rose(tx_en));
  cover property (@(posedge clk) disable iff (!rst_n) $fell(tx_en) ##[1:40] beacon);
endmodule
