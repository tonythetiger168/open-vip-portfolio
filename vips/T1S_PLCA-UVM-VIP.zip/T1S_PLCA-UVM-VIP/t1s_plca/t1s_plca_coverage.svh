// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_coverage.svh -- 10BASE-T1S PLCA functional coverage

class t1s_plca_coverage extends uvm_subscriber #(t1s_plca_transaction);
  `uvm_component_utils(t1s_plca_coverage)
  t1s_plca_config cfg;
  t1s_plca_transaction tr;

  covergroup t1s_plca_cg;
    cp_len  : coverpoint tr.bytes.size() { bins one = {1}; bins short_ = {[2:8]}; bins mid = {[9:24]}; bins long_ = {[25:40]}; }
    cp_b0   : coverpoint tr.bytes[0] { bins zero = {0}; bins ff = {8'hFF}; bins other = default; }
    cp_slot : coverpoint tr.slot { bins mine = {3}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    t1s_plca_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(t1s_plca_config)::get(this, "", "cfg", cfg))
      cfg = t1s_plca_config::type_id::create("cfg");
  endfunction

  function void write(t1s_plca_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    t1s_plca_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("10BASE-T1S PLCA coverage: %0.1f%%", t1s_plca_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
