// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_sequences.svh -- 10BASE-T1S PLCA sequences

// Random traffic: cfg.num_items constrained-random items.
class t1s_plca_base_sequence extends uvm_sequence #(t1s_plca_transaction);
  `uvm_object_utils(t1s_plca_base_sequence)
  t1s_plca_config cfg;

  function new(string name = "t1s_plca_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = t1s_plca_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "t1s_plca_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class t1s_plca_directed_sequence extends uvm_sequence #(t1s_plca_transaction);
  `uvm_object_utils(t1s_plca_directed_sequence)
  t1s_plca_config cfg;

  function new(string name = "t1s_plca_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function t1s_plca_transaction item();
    item = t1s_plca_transaction::type_id::create("req");
  endfunction

  task send(t1s_plca_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    t1s_plca_transaction t;
    // one byte, the CRC check string, all-zero and all-ones payloads, then a run
    // of frames that need one PLCA cycle each
    t = item(); t.bytes = '{8'h00}; send(t);
    begin
      string cv = "123456789";
      t = item();
      foreach (cv[i]) t.bytes.push_back(cv[i]);
      send(t);
    end
    t = item(); repeat (16) t.bytes.push_back(8'h00); send(t);
    t = item(); repeat (16) t.bytes.push_back(8'hFF); send(t);
    for (int i = 0; i < 6; i++) begin t = item(); t.seed = 50 + i; t.fill_bytes(1 + 7 * i); send(t); end
  endtask
endclass
