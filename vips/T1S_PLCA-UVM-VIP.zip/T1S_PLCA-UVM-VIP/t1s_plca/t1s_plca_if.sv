// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// t1s_plca_if.sv -- 10BASE-T1S PLCA interface

interface t1s_plca_if (input logic clk);
  logic rst_n;

  logic tx_en;
  logic [3:0] txd;
  logic beacon;
  logic crs;
  logic rep_valid;
  logic [3:0] rep_slot;
  logic rep_ok;
  logic rep_err;

  modport DUT (input clk, rst_n, input tx_en, input txd, output beacon, output crs, output rep_valid, output rep_slot, output rep_ok, output rep_err);
  modport MON (input clk, rst_n, tx_en, txd, beacon, crs, rep_valid, rep_slot, rep_ok, rep_err);

  clocking drv_cb @(posedge clk);
    input rst_n, beacon, crs, rep_valid, rep_slot, rep_ok, rep_err;
    inout tx_en, txd;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, tx_en, txd, beacon, crs, rep_valid, rep_slot, rep_ok, rep_err;
  endclocking
endinterface
