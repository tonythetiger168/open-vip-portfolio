// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- 10BASE-T1S PLCA testbench top with a functional 10BASE-T1S PLCA DUT model

`ifndef T1S_PLCA_UVM_VIP_TB_SV
`define T1S_PLCA_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import t1s_plca_defs_pkg::*;
import t1s_plca_pkg::*;
import t1s_plca_env_pkg::*;
import t1s_plca_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  t1s_plca_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  t1s_plca_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tx_en(vif.tx_en),
    .txd(vif.txd),
    .beacon(vif.beacon),
    .crs(vif.crs),
    .rep_valid(vif.rep_valid),
    .rep_slot(vif.rep_slot),
    .rep_ok(vif.rep_ok),
    .rep_err(vif.rep_err)
  );

  // Concurrent protocol checks
  t1s_plca_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tx_en(vif.tx_en),
    .txd(vif.txd),
    .beacon(vif.beacon),
    .crs(vif.crs),
    .rep_valid(vif.rep_valid),
    .rep_slot(vif.rep_slot),
    .rep_ok(vif.rep_ok),
    .rep_err(vif.rep_err)
  );

  initial begin
    uvm_config_db#(virtual t1s_plca_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module t1s_plca_model #(
  parameter int N = 8, LOCAL = 3, TO_TIMER = 8, BEACON = 4
)(
  input  logic       clk,
  input  logic       rst_n,
  input  logic       tx_en,
  input  logic [3:0] txd,
  output logic       beacon,
  output logic       crs,
  output logic       rep_valid,
  output logic [3:0] rep_slot,
  output logic       rep_ok,
  output logic       rep_err
);
  logic [3:0]  cur, tmr, bcnt, olen;
  logic        busy, o_tx, tx_d, lo, err;
  logic [7:0]  lfsr, sh;
  logic [3:0]  slot;
  logic [31:0] crc;
  logic        act;

  assign beacon = bcnt != 0;
  assign crs    = beacon || o_tx;
  assign act    = tx_en || o_tx;

  function automatic logic [31:0] crc_nib(input logic [31:0] c, input logic [3:0] d);
    c = c ^ {28'h0, d};
    for (int i = 0; i < 4; i++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : c >> 1;
    return c;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cur <= '0; tmr <= '0; bcnt <= 4'(BEACON); busy <= 1'b0; o_tx <= 1'b0; olen <= '0;
      lfsr <= 8'h5A; tx_d <= 1'b0; lo <= 1'b0; err <= 1'b0; sh <= '0;
      slot <= '0; crc <= '1;
      rep_valid <= 1'b0; rep_slot <= '0; rep_ok <= 1'b0; rep_err <= 1'b0;
    end else begin
      lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};
      rep_valid <= 1'b0;
      tx_d <= tx_en;
      // ---- transmit-opportunity counter
      if (bcnt != 0) begin
        bcnt <= bcnt - 4'd1;
        if (bcnt == 4'd1) begin cur <= '0; tmr <= '0; busy <= 1'b0; end
      end else if (act) busy <= 1'b1;
      else if (busy || tmr == 4'(TO_TIMER - 1)) begin
        tmr <= '0; busy <= 1'b0;
        if (cur == 4'(N - 1)) bcnt <= 4'(BEACON);
        else cur <= cur + 4'd1;
      end else tmr <= tmr + 4'd1;
      // ---- the other nodes: a frame of 3..10 clocks, decided in the
      // opportunity's second clock
      if (o_tx) begin
        if (olen == 4'd1) o_tx <= 1'b0;
        olen <= olen - 4'd1;
      end else if (bcnt == 0 && cur != 4'(LOCAL) && tmr == 4'd1 && !busy && lfsr[0] ^ lfsr[6]) begin
        o_tx <= 1'b1; olen <= 4'd3 + {1'b0, lfsr[3:1]};
      end
      // ---- the agent's frames
      if (tx_en) begin
        if (!tx_d) begin                              // start of frame
          slot <= cur; lo <= 1'b1; crc <= crc_nib(32'hFFFF_FFFF, txd);
          // a second frame in the same opportunity cannot happen: the
          // opportunity ends the clock its frame's carrier falls
          err <= bcnt != 0 || cur != 4'(LOCAL) || busy || o_tx;
        end else begin
          lo <= ~lo; crc <= crc_nib(crc, txd);
          if (o_tx) err <= 1'b1;                      // collision
        end
      end else if (tx_d) begin                        // end of frame: report
        rep_valid <= 1'b1; rep_slot <= slot; rep_err <= err;
        rep_ok <= !lo && crc == 32'hDEBB_20E3;        // whole bytes, CRC-32 residue
      end
    end
  end
endmodule
`endif
