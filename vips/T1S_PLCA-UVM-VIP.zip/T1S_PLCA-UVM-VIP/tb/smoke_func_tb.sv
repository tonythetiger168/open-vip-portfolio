// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (10BASE-T1S PLCA DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened t1s_plca_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic tx_en = 0;
  logic [3:0] txd = 0;
  wire beacon, crs, rep_valid, rep_ok, rep_err;
  wire [3:0] rep_slot;

  always #5 clk = ~clk;

  t1s_plca_model u_dut (.clk(clk), .rst_n(rst_n), .tx_en(tx_en), .txd(txd), .beacon(beacon), .crs(crs),
                        .rep_valid(rep_valid), .rep_slot(rep_slot), .rep_ok(rep_ok), .rep_err(rep_err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // the PLCA counter as every node runs it (clause 148), mirrored from the
  // reset values on: compared with the segment's BEACON every clock, and the
  // other nodes may only start in their own opportunity's third clock
  int cur = 0, tmr = 0, bcnt = 4;
  bit busy = 0, synced = 0;
  int n_beacon = 0, n_other = 0, n_yield = 0, beacon_len = 0, max_beacon_len = 0;
  int n_bmis = 0, n_obad = 0, olen = 0, olen_min = 99, olen_max = 0;
  bit crs_d = 0;
  always @(posedge clk) if (rst_n) begin
    bit act;
    act = (crs && !beacon) || tx_en;
    if (bcnt != 0) begin
      if (bcnt == 1) begin cur = 0; tmr = 0; busy = 0; synced = 1; end
      bcnt--;
    end else if (act) busy = 1;
    else if (busy || tmr == 8 - 1) begin
      if (!busy) n_yield++;
      tmr = 0; busy = 0;
      if (cur == 8 - 1) bcnt = 4;
      else cur++;
    end else tmr++;
    #1;
    if (beacon !== (bcnt != 0)) n_bmis++;
    if (beacon) begin
      if (beacon_len == 0) n_beacon++;
      beacon_len++;
      if (beacon_len > max_beacon_len) max_beacon_len = beacon_len;
    end else beacon_len = 0;
    if (crs && !beacon) begin
      if (!crs_d) begin
        n_other++;
        if (cur == 3 || tmr != 2) n_obad++;
      end
      olen++;
    end else if (olen != 0) begin
      if (olen < olen_min) olen_min = olen;
      if (olen > olen_max) olen_max = olen;
      olen = 0;
    end
    crs_d = crs && !beacon;
  end

  int nrep = 0;
  logic r_ok, r_err; logic [3:0] r_slot;
  always @(posedge clk) if (rep_valid) begin nrep++; r_ok = rep_ok; r_err = rep_err; r_slot = rep_slot; end

  // CRC-32 with the FCS appended
  bit [7:0] fr[$];
  task automatic make(input string s, input bit bad);
    bit [31:0] c = 32'hFFFF_FFFF;
    fr.delete();
    foreach (s[i]) begin
      fr.push_back(s[i]);
      c ^= {24'h0, s[i]};
      for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    c = ~c ^ {31'h0, bad};
    for (int i = 0; i < 4; i++) fr.push_back(c[i*8 +: 8]);
  endtask
  // wait until this node's counter says ID == id, no carrier, room left
  task automatic wait_to(input int id);
    int n = 0;
    do begin @(posedge clk); #1; n++; end
    while (!(synced && cur == id && !busy && tmr <= 5 && !crs) && n < 2000);
  endtask
  task automatic send(input bit odd = 0);
    foreach (fr[i]) begin
      tx_en = 1; txd = fr[i][3:0]; @(posedge clk); #1;
      txd = fr[i][7:4]; @(posedge clk); #1;
    end
    if (odd) begin txd = 4'h5; @(posedge clk); #1; end
    tx_en = 0; txd = 0;
  endtask
  task automatic wait_rep(input int prev);
    int n = 0;
    while (nrep == prev && n < 10) begin @(posedge clk); n++; end
    #1;
  endtask

  initial begin
    int b;
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0, "no report in reset");
    rst_n = 1;
    #1;
    chk(beacon === 1'b1 && crs === 1'b1, "the coordinator starts with a BEACON, carrier on");
    repeat (400) @(posedge clk); #1;
    chk(nrep == 0, "no report without a frame");
    chk(n_beacon >= 3, $sformatf("BEACONs repeat (%0d in 400 clocks)", n_beacon));
    chk(n_bmis == 0, $sformatf("BEACON exactly when the clause 148 counter ends a cycle (%0d clocks differ)", n_bmis));
    chk(n_obad == 0, "other nodes start only in their own opportunity, never in node 3's");
    chk(olen_min >= 3 && olen_max <= 10, $sformatf("other nodes' frames %0d..%0d clocks", olen_min, olen_max));
    chk(max_beacon_len == 4, $sformatf("BEACON lasts %0d clocks", max_beacon_len));
    chk(n_other > 0 && n_yield > 0, "other nodes send frames, unused opportunities expire");

    // a frame in this node's opportunity
    make("123456789", 0); wait_to(3); b = nrep; send(); wait_rep(b);
    chk(nrep == b + 1 && r_ok === 1'b1 && r_err === 1'b0 && r_slot == 3, "frame in its own opportunity: FCS good, no error, slot 3");
    // a second frame in the same opportunity
    b = nrep; send(); wait_rep(b);
    chk(r_err === 1'b1, "second frame in the same opportunity flagged");
    // a frame in another node's opportunity
    wait_to(5); b = nrep; send(); wait_rep(b);
    chk(r_err === 1'b1 && r_slot == 5, "frame in node 5's opportunity flagged");
    // the next cycle: allowed again
    make("a", 0); wait_to(3); b = nrep; send(); wait_rep(b);
    chk(r_err === 1'b0 && r_ok === 1'b1, "the next cycle's opportunity: accepted");
    // bad FCS, odd nibble count
    make("hello", 1); wait_to(3); b = nrep; send(); wait_rep(b);
    chk(r_ok === 1'b0 && r_err === 1'b0, "bad FCS reported");
    make("hello", 0); wait_to(3); b = nrep; send(1); wait_rep(b);
    chk(r_ok === 1'b0, "odd nibble count reported");
    // during a BEACON
    make("x", 0);
    do begin @(posedge clk); #1; end while (!beacon);
    b = nrep; send(); wait_rep(b);
    chk(r_err === 1'b1, "frame during the BEACON flagged");
    // over another node's carrier
    do begin @(posedge clk); #1; end while (!(crs && !beacon));
    b = nrep; send(); wait_rep(b);
    chk(r_err === 1'b1, "frame over another node's carrier flagged");
    // a long frame in its own opportunity holds the opportunity open
    make("the quick brown fox jumps over the lazy dog", 0);
    wait_to(3); b = nrep; send(); wait_rep(b);
    chk(r_err === 1'b0 && r_ok === 1'b1, "long frame: the opportunity lasts until the carrier falls");
    chk(cur == 4 || beacon, "the next opportunity starts after the frame");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #400000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
