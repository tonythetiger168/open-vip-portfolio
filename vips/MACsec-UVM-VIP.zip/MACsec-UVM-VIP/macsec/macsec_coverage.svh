// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// macsec_coverage.svh -- MACsec functional coverage

class macsec_coverage extends uvm_subscriber #(macsec_transaction);
  `uvm_component_utils(macsec_coverage)
  macsec_config cfg;
  macsec_transaction tr;

  covergroup macsec_cg;
    cp_status : coverpoint tr.status { bins passed = {0}; bins untagged = {1}; bins bad_tag = {2}; bins no_sa = {3};
                                       bins late = {4}; bins icv_fail = {5}; }
    cp_mode : coverpoint tr.tci[1] iff (tr.status == 0) { bins integrity = {0}; bins confidential = {1}; }
    cp_sci : coverpoint tr.tci[4:3] iff (tr.status == 0) { bins implicit = {2'b00}; bins es = {2'b10}; bins explicit = {2'b01}; }
    cp_an : coverpoint tr.an iff (tr.status == 0) { bins an0 = {0}; bins an1 = {1}; }
    cp_sl : coverpoint (tr.sl != 0) iff (tr.status == 0) { bins long_frame = {0}; bins short_frame = {1}; }
    x_mode_sl : cross cp_mode, cp_sl;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    macsec_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(macsec_config)::get(this, "", "cfg", cfg))
      cfg = macsec_config::type_id::create("cfg");
  endfunction

  function void write(macsec_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    macsec_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("MACsec coverage: %0.1f%%", macsec_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
