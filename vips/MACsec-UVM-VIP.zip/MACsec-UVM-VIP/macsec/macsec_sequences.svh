// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// macsec_sequences.svh -- MACsec sequences

// Random traffic: cfg.num_items constrained-random items.
class macsec_base_sequence extends uvm_sequence #(macsec_transaction);
  `uvm_object_utils(macsec_base_sequence)
  macsec_config cfg;

  function new(string name = "macsec_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = macsec_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "macsec_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class macsec_directed_sequence extends uvm_sequence #(macsec_transaction);
  `uvm_object_utils(macsec_directed_sequence)
  macsec_config cfg;

  function new(string name = "macsec_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function macsec_transaction item();
    item = macsec_transaction::type_id::create("req");
  endfunction

  task send(macsec_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    macsec_transaction t;
    // both modes, every SCI form, both SAs, short and long data; then each fault
    for (int e = 0; e < 2; e++) begin
      t = item(); t.mk(0, e, 1, 0, 0, 30); t.psel = 0; send(t);
      t = item(); t.mk(0, e, 1, 0, 1, 60); t.psel = 0; send(t);
      t = item(); t.mk(0, e, 0, 0, 0, 47); t.psel = 0; send(t);
      t = item(); t.mk(0, e, 0, 1, 1, 48); t.psel = 0; send(t);
    end
    for (int k = 20; k < 32; k++) begin
      t = item(); t.mk(k, 1, 1, 0, 0, 40); t.psel = 0; send(t);
    end
    // replay: the last PN again (passed before), then a resend of a PN whose frame failed its ICV
    t = item(); t.mk(0, 1, 1, 0, 0, 20); t.psel = 0; send(t);
    t = item(); t.mk(0, 1, 1, 0, 0, 20); t.psel = 6; send(t);
    t = item(); t.mk(31, 1, 1, 0, 1, 20); t.psel = 0; send(t);
    t = item(); t.mk(0, 1, 1, 0, 1, 20); t.psel = 6; send(t);
    t = item(); t.mk(0, 0, 1, 0, 1, 50); t.psel = 7; send(t);
  endtask
endclass
