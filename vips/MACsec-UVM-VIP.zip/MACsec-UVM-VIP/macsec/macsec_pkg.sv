// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// macsec_pkg.sv -- MACsec UVM VIP package

package macsec_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import macsec_defs_pkg::*;
  export macsec_defs_pkg::*;

  `include "macsec_transaction.svh"
  `include "macsec_config.svh"
  `include "macsec_sequencer.svh"
  `include "macsec_driver.svh"
  `include "macsec_monitor.svh"
  `include "macsec_agent.svh"
  `include "macsec_sequences.svh"
  `include "macsec_checker.svh"
  `include "macsec_coverage.svh"
endpackage
