// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// macsec_transaction.svh -- MACsec transaction

class macsec_transaction extends uvm_sequence_item;
  `uvm_object_utils(macsec_transaction)

  // request (driven by the agent)
  rand bit untag;
  rand bit [47:0] sa;
  rand bit [5:0] tci;
  rand bit [1:0] an;
  rand bit [5:0] sl;
  rand bit [31:0] pn;
  rand bit [63:0] sci;
  bit [7:0] body[$];
  // response (returned by the DUT)
  bit [2:0] status;
  bit [7:0] odata[$];
  // bookkeeping (not compared)
  bit [7:0] pt[$];
  rand bit [4:0] kind;
  rand bit e_r;
  rand bit sc_r;
  rand bit es_r;
  rand bit an_r;
  rand bit [6:0] n_r;
  rand bit [2:0] psel;
  bit [1:0] icv;
  bit zero_pn;
  bit short_b;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_n { n_r >= 2; n_r <= 80; }

  function new(string name = "macsec_transaction"); super.new(name); endfunction

  // kind: 0-19 good, 20 untagged, 21 V, 22 ES+SC, 23 SC+SCB, 24 C without E, 25 E without C,
  // 26 PN 0, 27 SL wrong, 28 body too short, 29 foreign SCI, 30 AN 2/3, 31 ICV / data corrupted
  function void post_randomize(); mk(kind, e_r, sc_r, es_r, an_r, n_r); endfunction
  function void mk(int k, bit e_, bit sc_, bit es_, bit [1:0] an_, int n_);
    bit [31:0] x = seed | 1;
    untag = (k == 20); icv = 0; zero_pn = 0; short_b = 0;
    sa = MCS_PEER_SA; sci = MCS_PEER_SCI; an = an_; pn = 0;
    tci = {1'b0, sc_ ? 1'b0 : es_, sc_, 1'b0, e_, e_};
    pt.delete();
    for (int i = 0; i < n_; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      pt.push_back(x[7:0]);
    end
    sl = (n_ < 48) ? 6'(n_) : 6'd0;
    case (k)
      21: tci[5] = 1'b1;
      22: tci[4:3] = 2'b11;
      23: tci[3:2] = 2'b11;
      24: tci[1:0] = 2'b01;
      25: tci[1:0] = 2'b10;
      26: zero_pn = 1;
      27: sl = (n_ < 48) ? 6'((n_ + 1) % 48) : 6'd5;
      28: short_b = 1;
      29: if (tci[3]) sci ^= 64'h100; else sa ^= 48'h1;
      30: an = {1'b1, an_[0]};
      31: icv = x[9] ? 2'd1 : 2'd2;
      default: ;
    endcase
    if (untag) begin
      tci = 0; an = 0; sl = 0; sci = 0;
      pt[0] = 8'h08; pt[1] = 8'h00;
    end
    if (!tci[3]) sci = 0;
  endfunction

  // DA, SA, SecTAG
  function void hdr(output bit [7:0] b[$]);
    b.delete();
    for (int i = 5; i >= 0; i--) b.push_back(MCS_DA[8*i +: 8]);
    for (int i = 5; i >= 0; i--) b.push_back(sa[8*i +: 8]);
    if (untag) return;
    b.push_back(8'h88); b.push_back(8'hE5);
    b.push_back({tci, an}); b.push_back({2'b00, sl});
    for (int i = 3; i >= 0; i--) b.push_back(pn[8*i +: 8]);
    if (tci[3]) for (int i = 7; i >= 0; i--) b.push_back(sci[8*i +: 8]);
  endfunction
  function bit [63:0] iv_sci(); return tci[3] ? sci : {sa, 16'h0001}; endfunction

  // body from pt (pn already set)
  function void seal();
    bit [7:0] h[$], a[$], o[$], none[$];
    bit [127:0] tag;
    body.delete();
    if (untag) begin body = pt; return; end
    hdr(h);
    if (tci[1]) tag = mcs_gcm(mcs_key(an), {iv_sci(), pn}, h, pt, 1'b1, o);
    else begin
      a = h;
      foreach (pt[i]) a.push_back(pt[i]);
      tag = mcs_gcm(mcs_key(an), {iv_sci(), pn}, a, none, 1'b1, o);
      o = pt;
    end
    if (icv == 1) tag[0] = ~tag[0];
    if (icv == 2) o[0][3] = ~o[0][3];
    body = o;
    for (int i = 15; i >= 0; i--) body.push_back(tag[8*i +: 8]);
    if (short_b) while (body.size() > 10) void'(body.pop_back());
  endfunction
  function void frame(output bit [7:0] b[$]);
    hdr(b);
    foreach (body[i]) b.push_back(body[i]);
  endfunction
  // request fields from a received frame
  function void from_frame(bit [7:0] b[$]);
    int h;
    sa = {b[6], b[7], b[8], b[9], b[10], b[11]};
    untag = ({b[12], b[13]} != 16'h88E5);
    tci = 0; an = 0; sl = 0; pn = 0; sci = 0; body.delete();
    if (untag) begin
      for (int i = 12; i < b.size(); i++) body.push_back(b[i]);
      return;
    end
    {tci, an} = b[14]; sl = b[15][5:0];
    pn = {b[16], b[17], b[18], b[19]};
    h = 20;
    if (tci[3]) begin sci = {b[20], b[21], b[22], b[23], b[24], b[25], b[26], b[27]}; h = 28; end
    for (int i = h; i < b.size(); i++) body.push_back(b[i]);
  endfunction
  function bit tag_bad();
    int n = body.size() - 16;
    return body.size() < 16 || tci[5] || (tci[4] && tci[3]) || (tci[3] && tci[2]) || (tci[1] != tci[0]) || pn == 0 ||
           sl >= 48 || (sl != 0 && sl != n) || (sl == 0 && n < 48);
  endfunction

  function void do_copy(uvm_object rhs);
    macsec_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    untag = rhs_.untag;
    sa = rhs_.sa;
    tci = rhs_.tci;
    an = rhs_.an;
    sl = rhs_.sl;
    pn = rhs_.pn;
    sci = rhs_.sci;
    body = rhs_.body;
    status = rhs_.status;
    odata = rhs_.odata;
    pt = rhs_.pt;
    kind = rhs_.kind;
    e_r = rhs_.e_r;
    sc_r = rhs_.sc_r;
    es_r = rhs_.es_r;
    an_r = rhs_.an_r;
    n_r = rhs_.n_r;
    psel = rhs_.psel;
    icv = rhs_.icv;
    zero_pn = rhs_.zero_pn;
    short_b = rhs_.short_b;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    macsec_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (untag != rhs_.untag) return 0;
    if (sa != rhs_.sa) return 0;
    if (tci != rhs_.tci) return 0;
    if (an != rhs_.an) return 0;
    if (sl != rhs_.sl) return 0;
    if (pn != rhs_.pn) return 0;
    if (sci != rhs_.sci) return 0;
    if (body.size() != rhs_.body.size()) return 0;
    foreach (body[i]) if (body[i] != rhs_.body[i]) return 0;
    if (status != rhs_.status) return 0;
    if (odata.size() != rhs_.odata.size()) return 0;
    foreach (odata[i]) if (odata[i] != rhs_.odata[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(macsec_transaction rhs_);
    if (untag != rhs_.untag) return 0;
    if (sa != rhs_.sa) return 0;
    if (tci != rhs_.tci) return 0;
    if (an != rhs_.an) return 0;
    if (sl != rhs_.sl) return 0;
    if (pn != rhs_.pn) return 0;
    if (sci != rhs_.sci) return 0;
    if (body.size() != rhs_.body.size()) return 0;
    foreach (body[i]) if (body[i] != rhs_.body[i]) return 0;
    return 1;
  endfunction

  function string qstr_body();
    string s = $sformatf("[%0d]{", body.size());
    foreach (body[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", body[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_odata();
    string s = $sformatf("[%0d]{", odata.size());
    foreach (odata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", odata[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_pt();
    string s = $sformatf("[%0d]{", pt.size());
    foreach (pt[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", pt[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("MACsec{tag=%0d untag=0x%0h sa=0x%0h tci=0x%0h an=0x%0h sl=0x%0h pn=0x%0h sci=0x%0h body=%s status=0x%0h odata=%s}", tag, untag, sa, tci, an, sl, pn, sci, qstr_body(), status, qstr_odata());
  endfunction
endclass
