// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// macsec_driver.svh -- MACsec driver: one protected frame per item: PN from the driver's per-AN counter (or replayed / zero), sealed with GCM-AES-128, sent a byte a clock; then the delivered frame and status

class macsec_driver extends uvm_driver #(macsec_transaction);
  `uvm_component_utils(macsec_driver)

  uvm_analysis_port #(macsec_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual macsec_if vif;
  macsec_config cfg;

  bit [31:0] last_pn [4] = '{0, 0, 0, 0};

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual macsec_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "macsec: virtual interface not set")
    if (!uvm_config_db#(macsec_config)::get(this, "", "cfg", cfg))
      cfg = macsec_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    macsec_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.in_valid <= 1'b0;
    vif.drv_cb.in_data  <= 8'h00;
    vif.drv_cb.in_last  <= 1'b0;
  endtask

  task drive_item(macsec_transaction t);
    bit [7:0] b[$];
    int k = 0;
    if (!t.untag) begin
      case (t.psel)
        3'd6: t.pn = last_pn[t.an];
        3'd7: t.pn = last_pn[t.an] + 100;
        default: t.pn = last_pn[t.an] + 1;
      endcase
      if (t.zero_pn) t.pn = 0;
      else if (t.pn > last_pn[t.an]) last_pn[t.an] = t.pn;
    end
    t.seal();
    t.frame(b);
    foreach (b[i]) begin
      vif.drv_cb.in_valid <= 1'b1; vif.drv_cb.in_data <= b[i]; vif.drv_cb.in_last <= (i == b.size() - 1);
      @(vif.drv_cb);
    end
    vif.drv_cb.in_valid <= 1'b0; vif.drv_cb.in_last <= 1'b0;
    t.odata.delete();
    do begin
      @(vif.drv_cb);
      if (vif.drv_cb.out_valid) t.odata.push_back(vif.drv_cb.out_data);
      k++;
    end while (!vif.drv_cb.rep_valid && k < cfg.timeout_cycles);
    if (!vif.drv_cb.rep_valid) `uvm_error("DRV", "MACsec: no status for a frame")
    t.status = vif.drv_cb.rep_status;
    repeat (2) @(vif.drv_cb);
  endtask

endclass
