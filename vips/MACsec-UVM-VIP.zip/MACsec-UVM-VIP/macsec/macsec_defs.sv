// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// macsec_defs.sv -- MACsec shared type definitions

package macsec_defs_pkg;

  typedef enum bit [1:0] {MACSEC_OK, MACSEC_ERR} macsec_status_e;

  localparam bit [63:0]  MCS_PEER_SCI = 64'h0012_3456_789A_0001;
  localparam bit [47:0]  MCS_PEER_SA  = 48'h0012_3456_789A;
  localparam bit [47:0]  MCS_DA       = 48'h02AA_BBCC_DDEE;
  function automatic bit [127:0] mcs_key(bit [1:0] an);
    case (an)
      2'd0: return 128'hFEFF_E992_8665_731C_6D6A_8F94_6730_8308;
      2'd1: return 128'hAD7A_2BD0_3EAC_835A_6F62_0FDC_B506_B345;
      default: return 128'h0;
    endcase
  endfunction
  function automatic bit [7:0] mcs_xt(bit [7:0] a); return {a[6:0], 1'b0} ^ (a[7] ? 8'h1B : 8'h00); endfunction
  function automatic bit [7:0] mcs_gm(bit [7:0] a, bit [7:0] b);
    bit [7:0] p = 0;
    for (int i = 0; i < 8; i++) begin
      if (b[i]) p ^= a;
      a = mcs_xt(a);
    end
    return p;
  endfunction
  // AES S-box: inverse in GF(2^8) (a^254), then the affine map
  function automatic bit [7:0] mcs_sbox(bit [7:0] a);
    bit [7:0] r = 8'h01;
    for (int i = 7; i >= 0; i--) begin
      r = mcs_gm(r, r);
      if (i != 0) r = mcs_gm(r, a);
    end
    return r ^ {r[6:0], r[7]} ^ {r[5:0], r[7:6]} ^ {r[4:0], r[7:5]} ^ {r[3:0], r[7:4]} ^ 8'h63;
  endfunction
  // AES-128 encryption, byte 0 in bits 127:120
  function automatic bit [127:0] mcs_aes(bit [127:0] key, bit [127:0] blk);
    bit [127:0] s = blk ^ key, k = key, t;
    bit [7:0] rc = 8'h01, a0, a1, a2, a3;
    bit [31:0] w;
    for (int r = 1; r <= 10; r++) begin
      for (int c = 0; c < 4; c++)
        for (int j = 0; j < 4; j++)
          t[127 - 8*(4*c + j) -: 8] = mcs_sbox(s[127 - 8*(4*((c + j) % 4) + j) -: 8]);
      if (r != 10)
        for (int c = 0; c < 4; c++) begin
          a0 = t[127 - 32*c -: 8]; a1 = t[119 - 32*c -: 8]; a2 = t[111 - 32*c -: 8]; a3 = t[103 - 32*c -: 8];
          t[127 - 32*c -: 8] = mcs_xt(a0) ^ mcs_xt(a1) ^ a1 ^ a2 ^ a3;
          t[119 - 32*c -: 8] = a0 ^ mcs_xt(a1) ^ mcs_xt(a2) ^ a2 ^ a3;
          t[111 - 32*c -: 8] = a0 ^ a1 ^ mcs_xt(a2) ^ mcs_xt(a3) ^ a3;
          t[103 - 32*c -: 8] = mcs_xt(a0) ^ a0 ^ a1 ^ a2 ^ mcs_xt(a3);
        end
      w = k[31:0];
      w = {mcs_sbox(w[23:16]) ^ rc, mcs_sbox(w[15:8]), mcs_sbox(w[7:0]), mcs_sbox(w[31:24])};
      k[127:96] ^= w; k[95:64] ^= k[127:96]; k[63:32] ^= k[95:64]; k[31:0] ^= k[63:32];
      rc = mcs_xt(rc);
      s = t ^ k;
    end
    return s;
  endfunction
  // GHASH multiply in GF(2^128) (GCM bit order)
  function automatic bit [127:0] mcs_gmul(bit [127:0] x, bit [127:0] y);
    bit [127:0] z = 0, v = y;
    for (int i = 0; i < 128; i++) begin
      if (x[127 - i]) z ^= v;
      v = v[0] ? ((v >> 1) ^ {8'hE1, 120'h0}) : (v >> 1);
    end
    return z;
  endfunction
  function automatic bit [127:0] mcs_ghash(bit [127:0] h, bit [127:0] x, bit [7:0] q[$]);
    for (int i = 0; i < q.size(); i += 16) begin
      bit [127:0] b = 0;
      for (int j = 0; j < 16; j++) if (i + j < q.size()) b[127 - 8*j -: 8] = q[i + j];
      x = mcs_gmul(x ^ b, h);
    end
    return x;
  endfunction
  // GCM with a 96-bit IV: out = text XOR keystream; returns the tag over aad and
  // the ciphertext (out when enc, text otherwise)
  function automatic bit [127:0] mcs_gcm(bit [127:0] key, bit [95:0] iv, bit [7:0] aad[$], bit [7:0] txt[$], bit enc,
                                         output bit [7:0] out[$]);
    bit [127:0] h = mcs_aes(key, 128'h0), x, ks;
    bit [63:0] la = 64'(aad.size()) * 8, lc = 64'(txt.size()) * 8;
    out.delete();
    for (int i = 0; i < txt.size(); i += 16) begin
      ks = mcs_aes(key, {iv, 32'(2 + i / 16)});
      for (int j = 0; j < 16; j++) if (i + j < txt.size()) out.push_back(txt[i + j] ^ ks[127 - 8*j -: 8]);
    end
    x = mcs_ghash(h, 128'h0, aad);
    if (enc) x = mcs_ghash(h, x, out);
    else     x = mcs_ghash(h, x, txt);
    x = mcs_gmul(x ^ {la, lc}, h);
    return x ^ mcs_aes(key, {iv, 32'h1});
  endfunction

endpackage
