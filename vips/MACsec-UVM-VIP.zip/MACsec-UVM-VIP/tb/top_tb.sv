// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- MACsec testbench top with a functional MACsec DUT model

`ifndef MACSEC_UVM_VIP_TB_SV
`define MACSEC_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import macsec_defs_pkg::*;
import macsec_pkg::*;
import macsec_env_pkg::*;
import macsec_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  macsec_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  macsec_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .in_valid(vif.in_valid),
    .in_data(vif.in_data),
    .in_last(vif.in_last),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data),
    .out_last(vif.out_last),
    .rep_valid(vif.rep_valid),
    .rep_status(vif.rep_status)
  );

  // Concurrent protocol checks
  macsec_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .in_valid(vif.in_valid),
    .in_data(vif.in_data),
    .in_last(vif.in_last),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data),
    .out_last(vif.out_last),
    .rep_valid(vif.rep_valid),
    .rep_status(vif.rep_status)
  );

  initial begin
    uvm_config_db#(virtual macsec_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module macsec_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       in_valid,
  input  logic [7:0] in_data,
  input  logic       in_last,
  output logic       out_valid,
  output logic [7:0] out_data,
  output logic       out_last,
  output logic       rep_valid,
  output logic [2:0] rep_status
);
  localparam logic [127:0] K0   = 128'hFEFF_E992_8665_731C_6D6A_8F94_6730_8308;
  localparam logic [127:0] K1   = 128'hAD7A_2BD0_3EAC_835A_6F62_0FDC_B506_B345;
  localparam logic [63:0]  PEER = 64'h0012_3456_789A_0001;

  function automatic logic [7:0] xt(input logic [7:0] a);
    xt = {a[6:0], 1'b0} ^ (a[7] ? 8'h1B : 8'h00);
  endfunction
  function automatic logic [7:0] gm(input logic [7:0] a, input logic [7:0] b);
    logic [7:0] p, x;
    p = 8'h00; x = a;
    for (int i = 0; i < 8; i++) begin
      if (b[i]) p = p ^ x;
      x = xt(x);
    end
    gm = p;
  endfunction
  function automatic logic [7:0] sbox(input logic [7:0] a);
    logic [7:0] r;
    r = 8'h01;
    for (int i = 7; i >= 0; i--) begin
      r = gm(r, r);
      if (i != 0) r = gm(r, a);
    end
    sbox = r ^ {r[6:0], r[7]} ^ {r[5:0], r[7:6]} ^ {r[4:0], r[7:5]} ^ {r[3:0], r[7:4]} ^ 8'h63;
  endfunction
  function automatic logic [127:0] aes(input logic [127:0] key, input logic [127:0] blk);
    logic [127:0] s, k, t;
    logic [7:0]   rc, a0, a1, a2, a3;
    logic [31:0]  w;
    s = blk ^ key; k = key; rc = 8'h01;
    for (int r = 1; r <= 10; r++) begin
      for (int c = 0; c < 4; c++)
        for (int j = 0; j < 4; j++)
          t[127 - 8*(4*c + j) -: 8] = sbox(s[127 - 8*(4*((c + j) % 4) + j) -: 8]);
      if (r != 10)
        for (int c = 0; c < 4; c++) begin
          a0 = t[127 - 32*c -: 8]; a1 = t[119 - 32*c -: 8]; a2 = t[111 - 32*c -: 8]; a3 = t[103 - 32*c -: 8];
          t[127 - 32*c -: 8] = xt(a0) ^ xt(a1) ^ a1 ^ a2 ^ a3;
          t[119 - 32*c -: 8] = a0 ^ xt(a1) ^ xt(a2) ^ a2 ^ a3;
          t[111 - 32*c -: 8] = a0 ^ a1 ^ xt(a2) ^ xt(a3) ^ a3;
          t[103 - 32*c -: 8] = xt(a0) ^ a0 ^ a1 ^ a2 ^ xt(a3);
        end
      w = k[31:0];
      w = {sbox(w[23:16]) ^ rc, sbox(w[15:8]), sbox(w[7:0]), sbox(w[31:24])};
      k[127:96] = k[127:96] ^ w;
      k[95:64]  = k[95:64] ^ k[127:96];
      k[63:32]  = k[63:32] ^ k[95:64];
      k[31:0]   = k[31:0] ^ k[63:32];
      rc = xt(rc);
      s = t ^ k;
    end
    aes = s;
  endfunction
  function automatic logic [127:0] gmul(input logic [127:0] x, input logic [127:0] y);
    logic [127:0] z, v;
    z = 128'h0; v = y;
    for (int i = 0; i < 128; i++) begin
      if (x[127 - i]) z = z ^ v;
      v = v[0] ? ((v >> 1) ^ {8'hE1, 120'h0}) : (v >> 1);
    end
    gmul = z;
  endfunction

  logic [7:0]  rb [0:127];      // received frame
  logic [7:0]  ob [0:127];      // frame delivered
  logic [7:0]  nrb, olen, opos;
  logic        go, busy;
  logic [31:0] npn0, npn1;      // lowest acceptable PN of AN 0 / AN 1

  // 16 frame bytes from 'from' (zero at and after 'lim')
  function automatic logic [127:0] blk(input integer from, input integer lim);
    logic [127:0] v;
    for (int j = 0; j < 16; j++) v[127 - 8*j -: 8] = (from + j < lim) ? rb[from + j] : 8'h00;
    blk = v;
  endfunction
  function automatic logic [127:0] ghash(input logic [127:0] h, input logic [127:0] x0, input integer from,
                                         input integer lim);
    logic [127:0] x;
    x = x0;
    for (int b = 0; b < 8; b++) if (from + 16*b < lim) x = gmul(x ^ blk(from + 16*b, lim), h);
    ghash = x;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      nrb <= '0; olen <= '0; opos <= '0; go <= 1'b0; busy <= 1'b0; npn0 <= 32'd1; npn1 <= 32'd1;
      out_valid <= 1'b0; out_data <= '0; out_last <= 1'b0; rep_valid <= 1'b0; rep_status <= '0;
    end else begin
      rep_valid <= 1'b0; out_valid <= 1'b0; out_last <= 1'b0;
      go <= in_valid && in_last;
      if (in_valid) begin
        if (nrb < 8'd128) rb[nrb[6:0]] <= in_data;
        nrb <= nrb + 8'd1;
      end
      if (go) begin : receive
        logic [5:0]   tci;
        logic [1:0]   an;
        logic [31:0]  pn;
        logic [63:0]  sci;
        logic [127:0] key, hk, x, tag, ks, cb;
        logic [63:0]  la, lc;
        logic [2:0]   st;
        integer       n, h, dn, alen;
        n = nrb; st = 3'd0;
        nrb <= '0;
        if (n < 14 || {rb[12], rb[13]} != 16'h88E5) st = 3'd1;
        else begin
          tci = rb[14][7:2]; an = rb[14][1:0];
          pn = {rb[16], rb[17], rb[18], rb[19]};
          h = tci[3] ? 28 : 20;
          dn = n - h - 16;
          if (n < h + 16 || tci[5] || (tci[4] && tci[3]) || (tci[3] && tci[2]) || (tci[1] != tci[0]) || pn == 32'd0 ||
              rb[15] >= 8'd48 || (rb[15] != 8'd0 && rb[15] != dn) || (rb[15] == 8'd0 && dn < 48)) st = 3'd2;
          else begin
            sci = tci[3] ? {rb[20], rb[21], rb[22], rb[23], rb[24], rb[25], rb[26], rb[27]}
                         : {rb[6], rb[7], rb[8], rb[9], rb[10], rb[11], 16'h0001};
            if (sci != PEER || an[1]) st = 3'd3;
            else if (pn < (an[0] ? npn1 : npn0)) st = 3'd4;
            else begin
              key = an[0] ? K1 : K0;
              hk = aes(key, 128'h0);
              alen = tci[1] ? h : h + dn;
              x = ghash(hk, 128'h0, 0, alen);
              if (tci[1]) x = ghash(hk, x, h, h + dn);
              la = alen * 8;
              lc = tci[1] ? dn * 8 : 0;
              x = gmul(x ^ {la, lc}, hk);
              tag = x ^ aes(key, {sci, pn, 32'h1});
              if (tag != blk(n - 16, n)) st = 3'd5;
              else begin
                if (an[0]) npn1 <= pn + 32'd1; else npn0 <= pn + 32'd1;
                for (int i = 0; i < 12; i++) ob[i] <= rb[i];
                for (int b = 0; b < 6; b++)
                  if (16*b < dn) begin
                    ks = tci[1] ? aes(key, {sci, pn, 32'd2 + b}) : 128'h0;
                    cb = blk(h + 16*b, h + dn);
                    for (int j = 0; j < 16; j++)
                      if (16*b + j < dn) ob[12 + 16*b + j] <= cb[127 - 8*j -: 8] ^ ks[127 - 8*j -: 8];
                  end
                olen <= 8'(12 + dn);
                opos <= '0;
                busy <= 1'b1;
              end
            end
          end
        end
        if (st != 3'd0) begin rep_valid <= 1'b1; rep_status <= st; end
      end
      if (busy) begin
        out_valid <= 1'b1;
        out_data <= ob[opos[6:0]];
        opos <= opos + 8'd1;
        if (opos == olen - 8'd1) begin
          out_last <= 1'b1; busy <= 1'b0;
          rep_valid <= 1'b1; rep_status <= 3'd0;
        end
      end
    end
  end
endmodule
`endif
