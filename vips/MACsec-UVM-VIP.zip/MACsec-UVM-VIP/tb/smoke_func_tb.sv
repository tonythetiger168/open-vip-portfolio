// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (MACsec DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened macsec_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic in_valid = 1'b0, in_last = 1'b0;
  logic [7:0] in_data = 8'h00;
  wire out_valid, out_last, rep_valid;
  wire [7:0] out_data;
  wire [2:0] rep_status;

  always #5 clk = ~clk;

  macsec_model u_dut (.clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_data(in_data), .in_last(in_last),
                      .out_valid(out_valid), .out_data(out_data), .out_last(out_last),
                      .rep_valid(rep_valid), .rep_status(rep_status));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // reference AES-128 / GHASH (checked against FIPS-197 and the GCM test cases below)
  function automatic logic [7:0] r_xt(input logic [7:0] a); r_xt = {a[6:0], 1'b0} ^ (a[7] ? 8'h1B : 8'h00); endfunction
  function automatic logic [7:0] r_inv(input logic [7:0] a);
    // brute-force inverse: the b with a * b = 1
    logic [7:0] p, x, y;
    r_inv = 8'h00;
    for (int b = 1; b < 256; b++) begin
      p = 8'h00; x = a; y = b;
      for (int i = 0; i < 8; i++) begin
        if (y[i]) p = p ^ x;
        x = r_xt(x);
      end
      if (p == 8'h01) r_inv = b;
    end
  endfunction
  logic [7:0] sb [0:255];
  initial for (int i = 0; i < 256; i++) begin : mk_sbox
    logic [7:0] r;
    r = r_inv(i);
    sb[i] = r ^ {r[6:0], r[7]} ^ {r[5:0], r[7:6]} ^ {r[4:0], r[7:5]} ^ {r[3:0], r[7:4]} ^ 8'h63;
  end
  function automatic logic [31:0] r_mixcol(input logic [31:0] c);
    logic [7:0] a0, a1, a2, a3;
    {a0, a1, a2, a3} = c;
    r_mixcol = {r_xt(a0) ^ r_xt(a1) ^ a1 ^ a2 ^ a3, a0 ^ r_xt(a1) ^ r_xt(a2) ^ a2 ^ a3,
                a0 ^ a1 ^ r_xt(a2) ^ r_xt(a3) ^ a3, r_xt(a0) ^ a0 ^ a1 ^ a2 ^ r_xt(a3)};
  endfunction
  function automatic logic [127:0] r_aes(input logic [127:0] key, input logic [127:0] pt);
    logic [127:0] s, k, t;
    logic [31:0] w;
    logic [7:0] rc;
    s = pt ^ key; k = key; rc = 8'h01;
    for (int r = 0; r < 10; r++) begin
      // SubBytes + ShiftRows: row j of column c comes from column c + j
      for (int c = 0; c < 4; c++)
        for (int j = 0; j < 4; j++)
          t[8*(15 - 4*c - j) +: 8] = sb[s[8*(15 - 4*((c + j) & 3) - j) +: 8]];
      if (r < 9) for (int c = 0; c < 4; c++) t[32*(3 - c) +: 32] = r_mixcol(t[32*(3 - c) +: 32]);
      w = {sb[k[23:16]], sb[k[15:8]], sb[k[7:0]], sb[k[31:24]]} ^ {rc, 24'h0};
      k = {k[127:96] ^ w, k[95:64] ^ k[127:96] ^ w, k[63:32] ^ k[95:64] ^ k[127:96] ^ w,
           k[31:0] ^ k[63:32] ^ k[95:64] ^ k[127:96] ^ w};
      rc = r_xt(rc);
      s = t ^ k;
    end
    r_aes = s;
  endfunction
  function automatic logic [127:0] r_gmul(input logic [127:0] x, input logic [127:0] y);
    logic [127:0] z, v;
    z = 0; v = x;
    for (int i = 127; i >= 0; i--) begin
      if (y[i]) z = z ^ v;
      v = v[0] ? ((v >> 1) ^ {8'hE1, 120'h0}) : (v >> 1);
    end
    r_gmul = z;
  endfunction

  // frame under construction: DA, SA, SecTAG, data, ICV
  logic [7:0] fb [0:127];
  logic [7:0] pt [0:127];
  integer fn, fh, fdn;
  logic [47:0] DA = 48'h02AA_BBCC_DDEE;
  logic [47:0] PSA = 48'h0012_3456_789A;
  logic [127:0] K0 = 128'hFEFF_E992_8665_731C_6D6A_8F94_6730_8308;
  logic [127:0] K1 = 128'hAD7A_2BD0_3EAC_835A_6F62_0FDC_B506_B345;
  function automatic logic [127:0] fblk(input integer from, input integer lim);
    logic [127:0] v;
    for (int j = 0; j < 16; j++) v[8*(15 - j) +: 8] = (from + j < lim) ? fb[from + j] : 8'h00;
    fblk = v;
  endfunction
  // tci {V ES SC SCB E C}; sci used only with SC; ivsci / key: what the sender uses
  task automatic build(input logic [5:0] tci, input logic [1:0] an, input integer sl, input logic [31:0] pn,
                       input logic [47:0] sa, input logic [63:0] sci, input integer n, input logic [7:0] v0);
    logic [63:0] ivs;
    logic [127:0] key, hk, x, ks, tag;
    logic [63:0] la, lc;
    integer alen;
    for (int i = 0; i < 128; i++) fb[i] = 8'h00;
    for (int i = 0; i < n; i++) pt[i] = v0 + 8'd37 * i;
    for (int i = 0; i < 6; i++) begin fb[i] = DA[8*(5 - i) +: 8]; fb[6 + i] = sa[8*(5 - i) +: 8]; end
    fb[12] = 8'h88; fb[13] = 8'hE5; fb[14] = {tci, an}; fb[15] = sl;
    fb[16] = pn[31:24]; fb[17] = pn[23:16]; fb[18] = pn[15:8]; fb[19] = pn[7:0];
    fh = 20;
    if (tci[3]) begin
      for (int i = 0; i < 8; i++) fb[20 + i] = sci[8*(7 - i) +: 8];
      fh = 28;
    end
    ivs = tci[3] ? sci : {sa, 16'h0001};
    key = an[0] ? K1 : K0;
    hk = r_aes(key, 0);
    fdn = n;
    for (int b = 0; b < 6; b++) begin
      ks = tci[1] ? r_aes(key, {ivs, pn, 32'd2 + b}) : 0;
      for (int j = 0; j < 16; j++) if (16*b + j < n) fb[fh + 16*b + j] = pt[16*b + j] ^ ks[8*(15 - j) +: 8];
    end
    alen = tci[1] ? fh : fh + n;
    x = 0;
    for (int b = 0; b < 8; b++) if (16*b < alen) x = r_gmul(x ^ fblk(16*b, alen), hk);
    if (tci[1]) for (int b = 0; b < 6; b++) if (16*b < n) x = r_gmul(x ^ fblk(fh + 16*b, fh + n), hk);
    la = alen * 8; lc = tci[1] ? n * 8 : 0;
    x = r_gmul(x ^ {la, lc}, hk);
    tag = x ^ r_aes(key, {ivs, pn, 32'h1});
    for (int j = 0; j < 16; j++) fb[fh + n + j] = tag[8*(15 - j) +: 8];
    fn = fh + n + 16;
  endtask

  // delivery capture
  logic [7:0] ob [0:255];
  integer on = 0, nrep = 0, nlast = 0;
  logic [2:0] st;
  always @(posedge clk) begin
    if (out_valid) begin ob[on] = out_data; on = on + 1; if (out_last) nlast = nlast + 1; end
    if (rep_valid) begin nrep = nrep + 1; st = rep_status; end
  end
  task automatic send();
    integer r0, k;
    r0 = nrep; on = 0;
    for (int i = 0; i < 128; i++)
      if (i < fn) begin @(negedge clk); in_valid = 1; in_data = fb[i]; in_last = (i == fn - 1); end
    @(negedge clk); in_valid = 0; in_last = 0;
    k = 0;
    while (k < 200 && nrep == r0) begin @(negedge clk); k = k + 1; end
    @(negedge clk);
  endtask
  // delivered frame = DA, SA, plaintext
  function automatic logic delivered(input integer n);
    logic ok;
    ok = (on == 12 + n);
    for (int i = 0; i < 12; i++) if (ob[i] !== fb[i]) ok = 0;
    for (int i = 0; i < 128; i++) if (i < n && ob[12 + i] !== pt[i]) ok = 0;
    delivered = ok;
  endfunction
  task automatic want(input integer s, input integer n, input string msg);
    if (s == 0) chk(st == 3'd0 && delivered(n), msg);
    else chk(st == s && on == 0, msg);
  endtask

  logic [31:0] pa, pb;
  initial begin
    logic [127:0] h0, c2;
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0 && out_valid === 1'b0, "nothing out in reset");
    rst_n = 1;
    // the reference itself
    chk(r_aes(128'h0001_0203_0405_0607_0809_0A0B_0C0D_0E0F, 128'h0011_2233_4455_6677_8899_AABB_CCDD_EEFF) ==
        128'h69C4_E0D8_6A7B_0430_D8CD_B780_70B4_C55A, "reference AES-128: FIPS-197 C.1");
    h0 = r_aes(0, 0);
    chk(h0 == 128'h66E9_4BD4_EF8A_2C3B_884C_FA59_CA34_2B2E, "reference H for the zero key (GCM test case 1)");
    chk(r_aes(0, 1) == 128'h58E2_FCCE_FA7E_3061_367F_1D57_A4E7_455A, "GCM test case 1 tag");
    c2 = r_aes(0, 2);
    chk(c2 == 128'h0388_DACE_60B6_A392_F328_C2B9_71B2_FE78, "GCM test case 2 ciphertext");
    chk((r_gmul(r_gmul(c2, h0) ^ 128'd128, h0) ^ r_aes(0, 1)) == 128'hAB6E_47D4_2CEC_13BD_F53A_67B2_1257_BDDF,
        "GCM test case 2 tag");
    repeat (4) @(negedge clk);
    chk(nrep == 0 && on == 0, "no status or output after reset without a frame");

    // confidentiality, explicit SCI, AN 0 / 1, short and long data
    build(6'b001011, 0, 30, 32'd1, PSA, 64'h0012_3456_789A_0001, 30, 8'h11); send();
    want(0, 30, "E/C, explicit SCI, AN 0, 30 bytes (SL 30)");
    build(6'b001011, 1, 0, 32'd5, PSA, 64'h0012_3456_789A_0001, 64, 8'h22); send();
    want(0, 64, "E/C, AN 1, 64 bytes (SL 0)");
    build(6'b001011, 0, 0, 32'd2, PSA, 64'h0012_3456_789A_0001, 48, 8'h33); send();
    want(0, 48, "48 bytes with SL 0");
    build(6'b001011, 0, 47, 32'd3, PSA, 64'h0012_3456_789A_0001, 47, 8'h34); send();
    want(0, 47, "47 bytes with SL 47");
    // implicit SCI (SC 0), ES; integrity only
    build(6'b000011, 0, 20, 32'd4, PSA, 0, 20, 8'h44); send();
    want(0, 20, "SC 0: SCI from SA || 0x0001");
    build(6'b010011, 1, 0, 32'd6, PSA, 0, 70, 8'h55); send();
    want(0, 70, "ES 1, SC 0");
    build(6'b001000, 0, 10, 32'd7, PSA, 64'h0012_3456_789A_0001, 10, 8'h66); send();
    chk(st == 0 && delivered(10) && fb[28] === 8'h66, "integrity only: data sent in clear and delivered");
    build(6'b000000, 1, 0, 32'd8, PSA, 0, 80, 8'h67); send();
    want(0, 80, "integrity only, SC 0, 80 bytes");
    build(6'b001011, 0, 17, 32'd10, PSA, 64'h0012_3456_789A_0001, 17, 8'h35); send();
    want(0, 17, "17 bytes: a single byte in the second block");
    build(6'b001011, 0, 0, 32'd11, PSA, 64'h0012_3456_789A_0001, 66, 8'h36); send();
    want(0, 66, "66 bytes: two bytes in the fifth block");

    // untagged and bad tags
    build(6'b001011, 0, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h70);
    fb[12] = 8'h08; fb[13] = 8'h00; send();
    want(1, 0, "EtherType 0x0800: untagged");
    fn = 14; fb[12] = 8'h88; fb[13] = 8'hE5; send(); want(2, 0, "14 bytes up to EtherType 0x88E5: bad tag");
    fn = 13; send(); want(1, 0, "13 bytes: untagged");
    build(6'b101011, 0, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h71); send(); want(2, 0, "V set: bad tag");
    build(6'b011011, 0, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h72); send(); want(2, 0, "ES with SC: bad tag");
    build(6'b001111, 0, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h73); send(); want(2, 0, "SC with SCB: bad tag");
    build(6'b001001, 0, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h74); send(); want(2, 0, "C without E: bad tag");
    build(6'b001010, 0, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h75); send(); want(2, 0, "E without C: bad tag");
    build(6'b001011, 0, 30, 32'd0, PSA, 64'h0012_3456_789A_0001, 30, 8'h76); send(); want(2, 0, "PN 0: bad tag");
    build(6'b001011, 0, 31, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h77); send(); want(2, 0, "SL 31 for 30 bytes: bad tag");
    build(6'b001011, 0, 0, 32'd9, PSA, 64'h0012_3456_789A_0001, 47, 8'h78); send(); want(2, 0, "SL 0 for 47 bytes: bad tag");
    build(6'b001011, 0, 48, 32'd9, PSA, 64'h0012_3456_789A_0001, 48, 8'h79); send(); want(2, 0, "SL 48: bad tag");
    build(6'b001011, 0, 0, 32'd9, PSA, 64'h0012_3456_789A_0001, 0, 8'h7B);
    fn = 28 + 15; send(); want(2, 0, "SecTAG and 15 bytes: too short");
    // no SA
    build(6'b001011, 0, 30, 32'd9, PSA, 64'h0012_3456_789A_0002, 30, 8'h80); send(); want(3, 0, "SCI port 2: no SA");
    build(6'b000011, 0, 30, 32'd9, 48'h0012_3456_789B, 0, 30, 8'h81); send(); want(3, 0, "SC 0 from another SA: no SA");
    build(6'b001011, 2, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h82); send(); want(3, 0, "AN 2: no SA");
    build(6'b001011, 3, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h83); send(); want(3, 0, "AN 3: no SA");

    // replay protection (AN 0 accepted up to PN 11, AN 1 up to PN 8)
    build(6'b001011, 0, 30, 32'd7, PSA, 64'h0012_3456_789A_0001, 30, 8'h90); send(); want(4, 0, "AN 0 PN 7 again: late");
    build(6'b001011, 0, 30, 32'd3, PSA, 64'h0012_3456_789A_0001, 30, 8'h91); send(); want(4, 0, "AN 0 PN 3: late");
    build(6'b001011, 0, 30, 32'd12, PSA, 64'h0012_3456_789A_0001, 30, 8'h92); send(); want(0, 30, "AN 0 PN 12: next");
    build(6'b001011, 1, 30, 32'd8, PSA, 64'h0012_3456_789A_0001, 30, 8'h93); send(); want(4, 0, "AN 1 keeps its own PN (8 late)");
    build(6'b001011, 1, 30, 32'd9, PSA, 64'h0012_3456_789A_0001, 30, 8'h94); send(); want(0, 30, "AN 1 PN 9");
    build(6'b001011, 0, 30, 32'h7FFF_0000, PSA, 64'h0012_3456_789A_0001, 30, 8'h95); send(); want(0, 30, "AN 0 jumps ahead");
    build(6'b001011, 0, 30, 32'd6, PSA, 64'h0012_3456_789A_0001, 30, 8'h96); send(); want(4, 0, "AN 0 below the jump: late");

    // ICV failures: the PN is not consumed
    build(6'b001011, 1, 30, 32'd10, PSA, 64'h0012_3456_789A_0001, 30, 8'hA0);
    fb[fn - 1] = fb[fn - 1] ^ 8'h01; send(); want(5, 0, "ICV bit flipped");
    build(6'b001011, 1, 30, 32'd10, PSA, 64'h0012_3456_789A_0001, 30, 8'hA1);
    fb[30] = fb[30] ^ 8'h80; send(); want(5, 0, "ciphertext bit flipped");
    build(6'b001011, 1, 30, 32'd10, PSA, 64'h0012_3456_789A_0001, 30, 8'hA2);
    fb[0] = fb[0] ^ 8'h02; send(); want(5, 0, "DA bit flipped (AAD)");
    build(6'b001011, 1, 30, 32'd10, PSA, 64'h0012_3456_789A_0001, 30, 8'hA3);
    send(); want(0, 30, "after the failures PN 10 still passes");
    build(6'b000000, 1, 0, 32'd11, PSA, 0, 60, 8'hA4);
    fb[60] = fb[60] ^ 8'h10; send(); want(5, 0, "integrity only: data bit flipped");
    build(6'b001011, 1, 30, 32'd11, PSA, 64'h0012_3456_789A_0001, 30, 8'hA5);
    for (int i = 0; i < 16; i++) fb[fn - 16 + i] = fb[fn - 16 + i] ^ 8'hFF; send(); want(5, 0, "ICV inverted");
    // AN changed after sealing (other SA key, other AAD)
    build(6'b001011, 1, 30, 32'h7FFF_0001, PSA, 64'h0012_3456_789A_0001, 30, 8'hA6);
    fb[14] = {6'b001011, 2'd0}; send(); want(5, 0, "AN 0 frame sealed with the AN 1 key");
    build(6'b001011, 0, 30, 32'h7FFF_0001, PSA, 64'h0012_3456_789A_0001, 30, 8'hA7); send(); want(0, 30, "AN 0 PN 0x7FFF0001");
    chk(nlast == 15, $sformatf("one last-byte strobe per delivered frame (%0d)", nlast));

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
