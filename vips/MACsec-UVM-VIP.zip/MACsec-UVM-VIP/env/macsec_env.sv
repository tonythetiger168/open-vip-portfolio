// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// macsec_env.sv -- MACsec environment: reference-model scoreboard, checker, coverage

package macsec_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import macsec_defs_pkg::*;
  import macsec_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class macsec_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(macsec_scoreboard)
    uvm_analysis_imp_exp #(macsec_transaction, macsec_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(macsec_transaction, macsec_scoreboard) obs_ap;

    macsec_config cfg;
    macsec_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [31:0] next_pn [2] = '{1, 1};
    bit kat_done = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(macsec_config)::get(this, "", "cfg", cfg))
        cfg = macsec_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(macsec_transaction t);
      bit [7:0] h[$], a[$], c[$], p[$], none[$];
      bit [127:0] tag, icv;
      int n;
      if (!kat_done) begin
        // FIPS-197 C.1 and GCM test case 2 on the scoreboard's own AES / GHASH
        kat_done = 1;
        if (mcs_aes(128'h0001_0203_0405_0607_0809_0A0B_0C0D_0E0F, 128'h0011_2233_4455_6677_8899_AABB_CCDD_EEFF) !=
            128'h69C4_E0D8_6A7B_0430_D8CD_B780_70B4_C55A) `uvm_error("SB", "MACsec: AES-128 known answer wrong")
        if ((mcs_gmul(mcs_gmul(128'h0388_DACE_60B6_A392_F328_C2B9_71B2_FE78, mcs_aes(0, 0)) ^ 128'd128, mcs_aes(0, 0)) ^ mcs_aes(0, 1)) !=
            128'hAB6E_47D4_2CEC_13BD_F53A_67B2_1257_BDDF) `uvm_error("SB", "MACsec: GCM known answer wrong")
      end
      t.odata.delete();
      if (t.untag) t.status = 1;
      else if (t.tag_bad()) t.status = 2;
      else if (t.iv_sci() != MCS_PEER_SCI || t.an > 1) t.status = 3;
      else if (t.pn < next_pn[t.an[0]]) t.status = 4;
      else begin
        n = t.body.size() - 16;
        t.hdr(h);
        for (int i = 0; i < n; i++) c.push_back(t.body[i]);
        for (int i = 0; i < 16; i++) icv[127 - 8*i -: 8] = t.body[n + i];
        if (t.tci[1]) tag = mcs_gcm(mcs_key(t.an), {t.iv_sci(), t.pn}, h, c, 1'b0, p);
        else begin
          a = h;
          foreach (c[i]) a.push_back(c[i]);
          tag = mcs_gcm(mcs_key(t.an), {t.iv_sci(), t.pn}, a, none, 1'b0, p);
          p = c;
        end
        if (tag != icv) t.status = 5;
        else begin
          t.status = 0;
          next_pn[t.an[0]] = t.pn + 1;
          for (int i = 0; i < 12; i++) t.odata.push_back(h[i]);
          foreach (p[i]) t.odata.push_back(p[i]);
        end
      end
    endfunction

    function void write_exp(macsec_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(macsec_transaction t);
      macsec_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        macsec_transaction e = exp_q.pop_front();
        macsec_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("macsec scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class macsec_env extends uvm_env;
    `uvm_component_utils(macsec_env)
    macsec_agent      agt;
    macsec_scoreboard sb;
    macsec_checker    chk;
    macsec_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = macsec_agent     ::type_id::create("agt", this);
      sb  = macsec_scoreboard::type_id::create("sb",  this);
      chk = macsec_checker   ::type_id::create("chk", this);
      cov = macsec_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
