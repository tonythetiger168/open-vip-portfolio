// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_env.sv -- RGMII environment: reference-model scoreboard, checker, coverage

package rgmii_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import rgmii_defs_pkg::*;
  import rgmii_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class rgmii_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(rgmii_scoreboard)
    uvm_analysis_imp_exp #(rgmii_transaction, rgmii_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(rgmii_transaction, rgmii_scoreboard) obs_ap;

    rgmii_config cfg;
    rgmii_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(rgmii_config)::get(this, "", "cfg", cfg))
        cfg = rgmii_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(rgmii_transaction t);
      bit [2:0] st; bit [15:0] et, qz; bit [1:0] ca; bit vl, pz;
      if (t.kind == RGMII_FRAME) begin
        rgmii_mac_check(t.bytes, t.pre_bad, t.code_err, cfg.station, cfg.promisc, cfg.mcast_en, st, et, ca, vl, pz, qz);
        t.status = st; t.len = t.bytes.size(); t.etype = et; t.cast = ca; t.vlan = vl; t.pause = pz; t.quanta = qz;
      end else begin
        t.status = 0; t.len = 0; t.etype = 0; t.cast = 0; t.vlan = 0; t.pause = 0; t.quanta = 0;
      end
      t.fc_out = (t.kind == RGMII_FC);
      t.st_out = (t.kind == RGMII_STATUS) ? t.st_nib : 4'h0;
    endfunction

    function void write_exp(rgmii_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(rgmii_transaction t);
      rgmii_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        rgmii_transaction e = exp_q.pop_front();
        rgmii_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("rgmii scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class rgmii_env extends uvm_env;
    `uvm_component_utils(rgmii_env)
    rgmii_agent      agt;
    rgmii_scoreboard sb;
    rgmii_checker    chk;
    rgmii_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = rgmii_agent     ::type_id::create("agt", this);
      sb  = rgmii_scoreboard::type_id::create("sb",  this);
      chk = rgmii_checker   ::type_id::create("chk", this);
      cov = rgmii_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
