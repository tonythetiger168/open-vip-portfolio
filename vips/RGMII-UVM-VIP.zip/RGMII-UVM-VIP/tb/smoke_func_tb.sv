// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (RGMII PHY loopback)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened rgmii_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [3:0] rxd = '0;
  logic rx_ctl = 1'b0;
  wire  [3:0] txd;
  wire  tx_ctl;

  always #5 clk = ~clk;

  rgmii_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .rxd(rxd), .rx_ctl(rx_ctl),
    .txd(txd), .tx_ctl(tx_ctl)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [3:0] strm [0:5];
  initial begin
    strm[0]=4'h5; strm[1]=4'hA; strm[2]=4'h0; strm[3]=4'hF;
    strm[4]=4'h3; strm[5]=4'hC;
    repeat (8) step();
    chk(tx_ctl === 1'b0 && txd === 4'h0, "tx path reset quiet");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    for (int i = 0; i < 6; i++) begin
      @(negedge clk); rxd = strm[i]; rx_ctl = 1;
      step();
      chk(tx_ctl === 1'b1, "tx_ctl high during stream");
      chk(txd === strm[i], "loopback nibble integrity");
    end
    @(negedge clk); rx_ctl = 0; rxd = '0;
    step();
    chk(tx_ctl === 1'b0, "tx_ctl drops after stream");
    repeat (2) step();

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
