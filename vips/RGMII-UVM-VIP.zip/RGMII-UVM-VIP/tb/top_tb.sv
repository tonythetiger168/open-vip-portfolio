// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- RGMII testbench top with a functional RGMII DUT model

`ifndef RGMII_TB_SV
`define RGMII_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import rgmii_defs_pkg::*;
import rgmii_pkg::*;
import rgmii_env_pkg::*;
import rgmii_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  rgmii_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  rgmii_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rxd(vif.rxd),
    .rx_ctl(vif.rx_ctl),
    .txd(vif.txd),
    .tx_ctl(vif.tx_ctl)
  );

  // Concurrent protocol checks
  rgmii_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .rxd(vif.rxd), .rx_ctl(vif.rx_ctl), .txd(vif.txd), .tx_ctl(vif.tx_ctl)
  );

  initial begin
    uvm_config_db#(virtual rgmii_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module rgmii_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [3:0] rxd,
  input  logic       rx_ctl,
  output logic [3:0] txd,
  output logic       tx_ctl
);
  // Simplified DDR model: registered loopback on the rising edge.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      txd   <= '0;
      tx_ctl <= 1'b0;
    end else begin
      txd    <= rxd;
      tx_ctl <= rx_ctl;
    end
  end
endmodule
`endif
