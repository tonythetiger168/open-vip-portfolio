# RGMII UVM VIP (RGMII-UVM-VIP)

RGMII (802.3 clause 35 reduced) UVM VIP with 4-bit DDR loopback model. Complements the RGMII RTL IP from the open-ip-portfolio sister project.

## Structure

- `rgmii/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `rgmii_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `rgmii_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural RGMII DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/RGMII-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh RGMII-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
