// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_sequences.svh -- RGMII sequences

// Random traffic: cfg.num_items constrained-random items.
class rgmii_base_sequence extends uvm_sequence #(rgmii_transaction);
  `uvm_object_utils(rgmii_base_sequence)
  rgmii_config cfg;

  function new(string name = "rgmii_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = rgmii_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "rgmii_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class rgmii_directed_sequence extends uvm_sequence #(rgmii_transaction);
  `uvm_object_utils(rgmii_directed_sequence)
  rgmii_config cfg;

  function new(string name = "rgmii_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function rgmii_transaction item();
    item = rgmii_transaction::type_id::create("req");
  endfunction

  task send(rgmii_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    rgmii_transaction t;
    // good frames: unicast, broadcast, multicast, vtag, PAUSE, minimum and maximum length
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_SELF; t.vtag = 0; t.use_len = 1; t.plen = 46; send(t);
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_BCAST; t.vtag = 0; t.use_len = 0; t.plen = 1500; send(t);
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_MCAST; t.vtag = 1; t.use_len = 0; t.plen = 1500; send(t);
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_SELF; t.vtag = 1; t.use_len = 1; t.plen = 10; send(t);
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_PAUSE; t.vtag = 0; t.pq = 16'h1234; send(t);
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_OTHER; t.vtag = 0; t.plen = 80; send(t);
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_SELF; t.vtag = 0; t.use_len = 0; t.plen = 100; send(t);
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_SELF; t.vtag = 0; t.use_len = 0; t.plen = 1000; send(t);
    // every injected error
    for (int i = 1; i < 8; i++) begin
      t = item(); t.kind = RGMII_FRAME; t.inj = rgmii_inj_e'(i); t.dak = RGMII_D_SELF; t.plen = 60 + i; t.use_len = 1; send(t);
    end

    t = item(); t.kind = RGMII_STATUS; t.st_nib = 4'hD; send(t);
    t = item(); t.kind = RGMII_STATUS; t.st_nib = 4'h3; send(t);
    t = item(); t.kind = RGMII_STATUS; t.st_nib = 4'h0; send(t);
    t = item(); t.kind = RGMII_STATUS; t.st_nib = 4'h9; send(t);
    t = item(); t.kind = RGMII_FC; send(t);
    t = item(); t.kind = RGMII_FRAME; t.inj = RGMII_X_NONE; t.dak = RGMII_D_SELF; t.pre_n = 1; send(t);
  endtask
endclass
