// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_transaction.svh -- RGMII transaction

class rgmii_transaction extends uvm_sequence_item;
  `uvm_object_utils(rgmii_transaction)

  rand bit [3:0] rxd;
  rand bit rx_ctl;
  bit [3:0] txd_o;
  bit tx_ctl_o;
  bit [31:0] tag;

  function new(string name = "rgmii_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    rgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    rxd = rhs_.rxd;
    rx_ctl = rhs_.rx_ctl;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    rgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           rxd == rhs_.rxd &&
           rx_ctl == rhs_.rx_ctl;
  endfunction

  function string convert2string();
    return $sformatf("RGMII{tag=%0h rxd=0x%0h rx_ctl=0x%0h}", tag, rxd, rx_ctl);
  endfunction
endclass
