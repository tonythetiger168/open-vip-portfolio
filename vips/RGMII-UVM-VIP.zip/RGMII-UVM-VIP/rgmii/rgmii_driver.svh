// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_driver.svh -- RGMII driver: preamble, SFD and one MAC frame, then the inter-frame gap

class rgmii_driver extends uvm_driver #(rgmii_transaction);
  `uvm_component_utils(rgmii_driver)

  uvm_analysis_port #(rgmii_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual rgmii_if vif;
  rgmii_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual rgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "rgmii: virtual interface not set")
    if (!uvm_config_db#(rgmii_config)::get(this, "", "cfg", cfg))
      cfg = rgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    rgmii_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.rxd <= '0; vif.drv_cb.rx_ctl <= 1'b0;
  endtask

  task drive_item(rgmii_transaction t);
    bit [7:0] line[$];
    @(vif.drv_cb);
    for (int i = 0; i < 7; i++) line.push_back(8'h55);
    line.push_back(8'hD5);
    foreach (t.bytes[i]) line.push_back(t.bytes[i]);
    foreach (line[i]) for (int h = 0; h < 2; h++) begin
      vif.drv_cb.rxd <= h ? line[i][7:4] : line[i][3:0];
      vif.drv_cb.rx_ctl <= 1'b1;
      @(vif.drv_cb);
    end
    vif.drv_cb.rx_ctl <= 1'b0;
    vif.drv_cb.rxd <= '0;
    repeat (cfg.ifg_clks) @(vif.drv_cb);
  endtask

endclass
