// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_driver.svh -- RGMII driver: one frame or bus event per item on the receive pins, then the inter-frame gap

class rgmii_driver extends uvm_driver #(rgmii_transaction);
  `uvm_component_utils(rgmii_driver)

  uvm_analysis_port #(rgmii_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual rgmii_if vif;
  rgmii_config cfg;

  bit [3:0] cur_st = 4'h0;   // in-band status sent between frames

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual rgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "rgmii: virtual interface not set")
    if (!uvm_config_db#(rgmii_config)::get(this, "", "cfg", cfg))
      cfg = rgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    rgmii_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.rxd <= cur_st; vif.rx_ctl <= 1'b0;
    vif.drv_cb.station <= cfg.station; vif.drv_cb.promisc <= cfg.promisc; vif.drv_cb.mcast_en <= cfg.mcast_en;
  endtask

  task drive_item(rgmii_transaction t);
    bit [7:0] ln[$];
    int ci = -1;
    @(vif.drv_cb);
    repeat (t.gap) idle_byte();
    t.pre_bad = 0; t.code_err = 0;
    if (t.kind != RGMII_STATUS) t.st_nib = 0;
    if (t.kind == RGMII_FC) begin
      t.bytes.delete(); t.inj = RGMII_X_NONE;
      repeat (2 + t.gap) put_byte(8'h0E, 1'b0, 1'b1);
      repeat (cfg.ifg) idle_byte();
      return;
    end
    if (t.kind == RGMII_STATUS) begin
      t.bytes.delete(); t.inj = RGMII_X_NONE;
      if (t.st_nib == cur_st) t.st_nib = t.st_nib ^ 4'h1;   // always a change
      cur_st = t.st_nib;
      repeat (8 + cfg.ifg) idle_byte();
      return;
    end
    t.build(cfg.station);
    for (int i = 0; i < t.pre_n; i++) ln.push_back(8'h55);
    if (t.inj == RGMII_X_PRE) begin ln[0] = 8'h5D; t.pre_bad = 1; end
    if (t.inj != RGMII_X_NOSFD) begin
      ln.push_back(8'hD5);
      foreach (t.bytes[i]) ln.push_back(t.bytes[i]);
    end else begin
      int k = -1;
      t.pre_bad = 1;
      foreach (t.bytes[i]) if (k < 0 && t.bytes[i] == 8'hD5) k = i;
      foreach (t.bytes[i]) ln.push_back(t.bytes[i]);
      if (k < 0) t.bytes.delete(); else t.bytes = t.bytes[k + 1 : $];
    end
    if (t.inj == RGMII_X_CODE) begin ci = t.pre_n + 1 + t.bytes.size() / 2; t.code_err = 1; end
    foreach (ln[i]) put_byte(ln[i], 1'b1, i == ci);
    repeat (cfg.ifg) idle_byte();
  endtask

  // one byte: low nibble for the next rising edge, high nibble for the falling edge after it
  task put_byte(bit [7:0] b, bit dv, bit er);
    @(negedge vif.clk);
    vif.rxd <= b[3:0]; vif.rx_ctl <= dv;
    @(posedge vif.clk);
    vif.rxd <= b[7:4]; vif.rx_ctl <= dv ^ er;
  endtask

  task idle_byte();
    put_byte({cur_st, cur_st}, 1'b0, 1'b0);
  endtask
endclass
