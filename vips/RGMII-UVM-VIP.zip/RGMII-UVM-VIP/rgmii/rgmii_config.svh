// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_config.svh -- RGMII agent configuration

class rgmii_config extends uvm_object;
  `uvm_object_utils(rgmii_config)
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  bit coverage_enable = 1;
  bit checks_enable   = 1;
  int unsigned num_items      = 32;     // random items per base sequence
  int unsigned timeout_cycles = 4000;   // handshake / response watchdog
  bit [47:0] station = RGMII_STATION;
  bit        promisc = 0;
  bit        mcast_en = 1;
  int unsigned ifg = 12;   // idle bytes after each item
  function new(string name = "rgmii_config"); super.new(name); endfunction
endclass
