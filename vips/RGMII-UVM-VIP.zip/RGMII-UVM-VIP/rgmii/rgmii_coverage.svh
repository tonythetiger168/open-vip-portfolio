// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_coverage.svh -- RGMII functional coverage

class rgmii_coverage extends uvm_subscriber #(rgmii_transaction);
  `uvm_component_utils(rgmii_coverage)
  rgmii_config cfg;
  rgmii_transaction tr;

  covergroup rgmii_cg;
    cp_len : coverpoint tr.bytes.size() { bins min_ = {[64:70]}; bins mid = {[71:100]}; bins long_ = {[101:$]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    rgmii_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(rgmii_config)::get(this, "", "cfg", cfg))
      cfg = rgmii_config::type_id::create("cfg");
  endfunction

  function void write(rgmii_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    rgmii_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("RGMII coverage: %0.1f%%", rgmii_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
