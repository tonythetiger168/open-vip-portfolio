// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_if.sv -- RGMII interface

interface rgmii_if (input logic clk);
  logic rst_n;

  logic [47:0] station;
  logic        promisc;
  logic        mcast_en;
  logic [3:0]  rxd;
  logic        rx_ctl;
  logic        fr_done;
  logic [2:0]  fr_status;
  logic [15:0] fr_len;
  logic [15:0] fr_etype;
  logic [1:0]  fr_cast;
  logic        fr_vlan;
  logic        pause_valid;
  logic [15:0] pause_quanta;
  logic        false_carrier;
  logic        link_up;
  logic [1:0]  speed;
  logic        duplex;

  clocking drv_cb @(posedge clk);
    input rst_n, fr_done, fr_status, fr_len, fr_etype, fr_cast, fr_vlan, pause_valid, pause_quanta,
          false_carrier, link_up, speed, duplex;
    inout station, promisc, mcast_en;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, station, promisc, mcast_en, rxd, rx_ctl, fr_done, fr_status, fr_len, fr_etype, fr_cast, fr_vlan,
          pause_valid, pause_quanta, false_carrier, link_up, speed, duplex;
  endclocking
endinterface
