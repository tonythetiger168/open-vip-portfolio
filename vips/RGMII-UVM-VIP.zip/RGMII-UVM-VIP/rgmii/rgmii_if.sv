// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_if.sv -- RGMII interface

interface rgmii_if (input logic clk);
  logic rst_n;

  logic [3:0] rxd;
  logic rx_ctl;
  logic [3:0] txd;
  logic tx_ctl;

  modport DUT (input clk, rst_n, rxd, rx_ctl, output txd, tx_ctl);
  modport DRV (input clk, rst_n, txd, tx_ctl, output rxd, rx_ctl);
  modport MON (input clk, rst_n, rxd, rx_ctl, txd, tx_ctl);

  clocking drv_cb @(posedge clk);
    input rst_n, rxd, rx_ctl, txd, tx_ctl;
    output rxd, rx_ctl;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, rxd, rx_ctl, txd, tx_ctl;
  endclocking
endinterface
