// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_monitor.svh -- RGMII monitor: frames and bus events on the receive pins, with the MAC's status and reported fields

class rgmii_monitor extends uvm_monitor;
  `uvm_component_utils(rgmii_monitor)

  virtual rgmii_if vif;
  uvm_analysis_port #(rgmii_transaction) ap;
  rgmii_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual rgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "rgmii: virtual interface not set")
    if (!uvm_config_db#(rgmii_config)::get(this, "", "cfg", cfg))
      cfg = rgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] b[$];
      bit inf = 0, sfd = 0, pb = 0, ce = 0, fcq = 0;
      bit [3:0] cur = 0;
      int st_wait = 0;
      rgmii_transaction pend[$];
      rgmii_transaction fct, stt;
      forever begin
        bit [3:0] lo;
        bit [7:0] d;
        bit dv, er, fc;
        @(posedge vif.clk);
        if (vif.rst_n !== 1'b1) begin inf = 0; fcq = 0; cur = 0; pend.delete(); fct = null; stt = null; continue; end
        // DUT results (values from before this edge)
        if (fct != null) begin fct.fc_out = vif.false_carrier; publish(fct); fct = null; end
        else if (vif.false_carrier) `uvm_error("MON", "RGMII false_carrier without a false carrier on the bus")
        if (stt != null && --st_wait == 0) begin
          stt.st_out = {vif.duplex, vif.speed, vif.link_up}; publish(stt); stt = null;
        end
        if (vif.fr_done) begin
          if (pend.size() == 0) `uvm_error("MON", "RGMII fr_done without a frame")
          else begin
            rgmii_transaction t = pend.pop_front();
            t.status = vif.fr_status; t.len = vif.fr_len; t.etype = vif.fr_etype;
            t.cast = vif.fr_cast; t.vlan = vif.fr_vlan; t.pause = vif.pause_valid;
            t.quanta = t.pause ? vif.pause_quanta : 16'h0;
            publish(t);
          end
        end
        // the bus: low nibble and RX_DV now, high nibble and RX_DV ^ RX_ER on the falling edge
        lo = vif.rxd; dv = vif.rx_ctl;
        @(negedge vif.clk);
        d = {vif.rxd, lo}; er = vif.rx_ctl ^ dv;
        if (dv) begin
          fcq = 0;
          if (!inf) begin inf = 1; b.delete(); sfd = (d == 8'hD5); pb = (d != 8'h55 && d != 8'hD5); ce = er; end
          else begin
            if (er) ce = 1;
            if (!sfd) begin if (d == 8'hD5) sfd = 1; else if (d != 8'h55) pb = 1; end
            else b.push_back(d);
          end
        end else begin
          if (inf) begin
            rgmii_transaction t = rgmii_transaction::type_id::create("t");
            inf = 0; t.kind = RGMII_FRAME; t.bytes = b; t.pre_bad = pb || !sfd; t.code_err = ce;
            pend.push_back(t);
          end
          fc = er && d == 8'h0E;
          if (fc && !fcq) begin fct = rgmii_transaction::type_id::create("fc"); fct.kind = RGMII_FC; end
          fcq = fc;
          if (!er && d[7:4] == d[3:0] && d[3:0] != cur && stt == null) begin
            cur = d[3:0];
            stt = rgmii_transaction::type_id::create("st"); stt.kind = RGMII_STATUS; stt.st_nib = cur; st_wait = 2;
          end
        end
      end
    end
  endtask

  function void publish(rgmii_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
