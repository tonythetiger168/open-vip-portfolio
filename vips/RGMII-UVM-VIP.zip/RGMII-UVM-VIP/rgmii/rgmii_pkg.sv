// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rgmii_pkg.sv -- RGMII UVM VIP package

package rgmii_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import rgmii_defs_pkg::*;
  export rgmii_defs_pkg::*;

  `include "rgmii_transaction.svh"
  `include "rgmii_config.svh"
  `include "rgmii_sequencer.svh"
  `include "rgmii_driver.svh"
  `include "rgmii_monitor.svh"
  `include "rgmii_agent.svh"
  `include "rgmii_sequences.svh"
  `include "rgmii_checker.svh"
  `include "rgmii_coverage.svh"
endpackage
