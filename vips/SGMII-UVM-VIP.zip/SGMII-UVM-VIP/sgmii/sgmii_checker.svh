// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_checker.svh -- SGMII protocol checker on monitored items

class sgmii_checker extends uvm_component;
  `uvm_component_utils(sgmii_checker)
  uvm_analysis_imp #(sgmii_transaction, sgmii_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  sgmii_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(sgmii_config)::get(this, "", "cfg", cfg))
      cfg = sgmii_config::type_id::create("cfg");
  endfunction

  function void fail(sgmii_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("SGMII: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(sgmii_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (!t.is_cfg) begin
        if (!(t.pre_len inside {5, 6})) fail(t, $sformatf("%0d preamble bytes after /S/ (6, or 5 after alignment)", t.pre_len));
        if (t.n_r != (t.t_odd ? 2 : 1)) fail(t, $sformatf("/T/ at %s position followed by %0d /R/", t.t_odd ? "an odd" : "an even", t.n_r));
        if (t.er_pos < 0 && !t.fcs_ok()) fail(t, "frame FCS wrong");
      end else if (!t.cfg_word[0]) fail(t, "SGMII config word bit 0 must be 1");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("SGMII checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
