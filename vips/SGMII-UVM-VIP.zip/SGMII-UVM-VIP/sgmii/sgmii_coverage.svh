// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_coverage.svh -- SGMII functional coverage

class sgmii_coverage extends uvm_subscriber #(sgmii_transaction);
  `uvm_component_utils(sgmii_coverage)
  sgmii_config cfg;
  sgmii_transaction tr;

  covergroup sgmii_cg;
    cp_kind  : coverpoint tr.is_cfg;
    cp_err   : coverpoint (tr.er_pos >= 0);
    cp_todd  : coverpoint tr.t_odd iff (!tr.is_cfg);
    cp_pre   : coverpoint tr.pre_len iff (!tr.is_cfg) { bins aligned = {6}; bins shrunk = {5}; }
    cp_speed : coverpoint tr.cfg_word[11:10] iff (tr.is_cfg) { bins s10 = {0}; bins s100 = {1}; bins s1000 = {2}; }
    cp_link  : coverpoint tr.cfg_word[15] iff (tr.is_cfg);
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    sgmii_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(sgmii_config)::get(this, "", "cfg", cfg))
      cfg = sgmii_config::type_id::create("cfg");
  endfunction

  function void write(sgmii_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    sgmii_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SGMII coverage: %0.1f%%", sgmii_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
