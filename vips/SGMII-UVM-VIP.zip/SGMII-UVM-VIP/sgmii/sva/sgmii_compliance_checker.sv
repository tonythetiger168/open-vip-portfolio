// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_compliance_checker.sv -- SGMII concurrent assertion checks (bindable)

module sgmii_compliance_checker
  (input logic clk, input logic rst_n, input logic [7:0] txd, input logic tx_en, input logic tx_er, input logic cfg_tx, input logic [15:0] cfg_word, input logic [9:0] tbi);

  // code groups are never X and always have 4, 5 or 6 ones
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(tbi))
    else $error("SGMII: X on tbi");
  assert property (@(posedge clk) disable iff (!rst_n) $countones(tbi) inside {4, 5, 6})
    else $error("SGMII: code group with %0d ones", $countones(tbi));
  // running disparity alternates: two consecutive unbalanced code groups have
  // opposite disparity
  assert property (@(posedge clk) disable iff (!rst_n)
                   $countones(tbi) != 5 ##1 $countones(tbi) != 5 |-> ($countones(tbi) > 5) != ($countones($past(tbi)) > 5))
    else $error("SGMII: running disparity violated");
  cover property (@(posedge clk) disable iff (!rst_n) tbi == 10'b1101101000);   // /S/ RD-
  cover property (@(posedge clk) disable iff (!rst_n) tx_en && tx_er);
  cover property (@(posedge clk) disable iff (!rst_n) cfg_tx);
endmodule
