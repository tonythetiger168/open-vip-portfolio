// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_sequences.svh -- SGMII sequences

// Random traffic: cfg.num_items constrained-random items.
class sgmii_base_sequence extends uvm_sequence #(sgmii_transaction);
  `uvm_object_utils(sgmii_base_sequence)
  sgmii_config cfg;

  function new(string name = "sgmii_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = sgmii_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "sgmii_transaction randomize() failed")

      finish_item(req);
    end
  endtask

  function void add_fcs(sgmii_transaction t);
    bit [31:0] f = t.crc32(t.bytes, t.bytes.size());
    for (int i = 0; i < 4; i++) t.bytes.push_back(f[i*8 +: 8]);
  endfunction
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class sgmii_directed_sequence extends uvm_sequence #(sgmii_transaction);
  `uvm_object_utils(sgmii_directed_sequence)
  sgmii_config cfg;

  function new(string name = "sgmii_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function sgmii_transaction item();
    item = sgmii_transaction::type_id::create("req");
  endfunction

  task send(sgmii_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    sgmii_transaction t;
    // minimum and odd-length frames (/T/ on both positions), a /V/ error, config words
    t = item(); t.plen = 46; t.seed = 32'h1; t.build_frame(46, 32'h1, 16'h0800); t.er_pos = -1; send(t);
    t = item(); t.plen = 47; t.seed = 32'h2; t.build_frame(47, 32'h2, 16'h0800); t.er_pos = -1; send(t);
    t = item(); t.plen = 64; t.seed = 32'h3; t.build_frame(64, 32'h3, 16'h86DD); t.er_pos = 20; send(t);
    t = item(); t.is_cfg = 1; t.cfg_word = 16'h9801; t.cfg_sets = 4; t.er_pos = -1; send(t);   // link, full duplex, 1000
    t = item(); t.is_cfg = 1; t.cfg_word = 16'h9401; t.cfg_sets = 3; t.er_pos = -1; send(t);   // 100 Mb/s
    t = item(); t.is_cfg = 1; t.cfg_word = 16'h0001; t.cfg_sets = 3; t.er_pos = -1; send(t);   // link down
    t = item(); t.plen = 100; t.seed = 32'hABCD; t.build_frame(100, 32'hABCD, 16'h0800); t.er_pos = -1; send(t);
    // all data byte values through the encoder (both disparities across frames)
    t = item(); t.bytes.delete(); for (int i = 0; i < 256; i++) t.bytes.push_back(i); add_fcs(t); t.er_pos = -1; send(t);
    t = item(); t.bytes.delete(); for (int i = 255; i >= 0; i--) t.bytes.push_back(i); t.bytes.push_back(8'h00); add_fcs(t); t.er_pos = -1; send(t);
  endtask

  function void add_fcs(sgmii_transaction t);
    bit [31:0] f = t.crc32(t.bytes, t.bytes.size());
    for (int i = 0; i < 4; i++) t.bytes.push_back(f[i*8 +: 8]);
  endfunction
endclass
