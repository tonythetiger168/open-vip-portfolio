// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_monitor.svh -- SGMII monitor: independent 8b/10b decoder (disparity and code checks), ordered-set parser, frames and configuration words

class sgmii_monitor extends uvm_monitor;
  `uvm_component_utils(sgmii_monitor)

  virtual sgmii_if vif;
  uvm_analysis_port #(sgmii_transaction) ap;
  sgmii_config cfg;
  int unsigned n_obs = 0;

  bit [9:0] dec_code[$];        // code groups for RD- and RD+
  bit [8:0] dec_val[$];         // {K, byte}
  bit       dec_rd[$];          // RD the code is legal for

  function void init_tables();
    // decode table from the encoder: 256 data + 12 control codes, both disparities
    for (int k = 0; k < 2; k++)
      for (int v = 0; v < 256; v++) begin
        bit [7:0] d = v;
        if (k && !(d inside {8'h1C, 8'h3C, 8'h5C, 8'h7C, 8'h9C, 8'hBC, 8'hDC, 8'hFC,
                             8'hF7, 8'hFB, 8'hFD, 8'hFE})) continue;
        for (int r = 0; r < 2; r++) begin
          bit rr = r;
          dec_code.push_back(enc8b10b(d, k, rr));
          dec_val.push_back({k[0], d});
          dec_rd.push_back(r);
        end
      end
  endfunction

  // decode with the current running disparity; ok = 0 for an invalid code or a
  // code of the wrong disparity
  function void decode(bit [9:0] c, ref bit rd, output bit [8:0] v, output bit ok);
    ok = 0;
    foreach (dec_code[i])
      if (dec_code[i] == c && dec_rd[i] == rd) begin v = dec_val[i]; ok = 1; break; end
    if ($countones(c) > 5) rd = 1'b1;
    else if ($countones(c) < 5) rd = 1'b0;
  endfunction

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual sgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sgmii: virtual interface not set")
    if (!uvm_config_db#(sgmii_config)::get(this, "", "cfg", cfg))
      cfg = sgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      // stream positions are counted from the first comma (K28.5 = even position)
      typedef enum {M_IDLE, M_PKT, M_R, M_CFG} st_e;
      st_e st = M_IDLE;
      bit rd = 0, synced = 0, even = 1, rd_set = 0;
      bit [8:0] v, prev = 0;
      int unsigned cpos = 0, nerr = 0, cfg_n = 0;
      bit [7:0] pk[$];
      bit [15:0] cw = 0, cur_cw = 0;
      bit cfg_open = 0;
      int erp = -1;
      sgmii_transaction t;
      init_tables();
      forever begin
        bit ok;
        bit [9:0] c;
        bit rd_in;
        @(vif.mon_cb);
        c = vif.mon_cb.tbi;
        rd_in = rd;
        if (!synced) begin
          if (c == K28_5_RDN) begin synced = 1; rd = 0; even = 1; end
          else if (c == ~K28_5_RDN) begin synced = 1; rd = 1; even = 1; end
          else continue;
        end
        decode(c, rd, v, ok);
        if (!ok) begin
          nerr++;
          `uvm_error("MON", $sformatf("SGMII: invalid code group / disparity error %b (RD%s)", c, rd_in ? "+" : "-"))
        end
        if (v == 9'h1BC && !even) `uvm_error("MON", "SGMII: comma at an odd position")
        case (st)
          M_IDLE: begin
            if (v == 9'h1FB) begin                          // /S/
              if (!even) `uvm_error("MON", "SGMII: /S/ at an odd position")
              if (cfg_open) begin flush_cfg(cur_cw, nerr); cfg_open = 0; end
              pk.delete(); erp = -1; st = M_PKT;
            end else if (prev == 9'h1BC && !even) begin    // second code of an ordered set
              if (v == 9'h0B5 || v == 9'h042) begin         // /C1/ /C2/: config word follows
                st = M_CFG; cpos = 0;
              end else if (v == 9'h0C5 || v == 9'h050) begin   // /I1/ D5.6, /I2/ D16.2
                if (cfg_open) begin flush_cfg(cur_cw, nerr); cfg_open = 0; end
                // /I1/ follows a positive RD at the ordered set, i.e. a negative
                // RD after its K28.5
                if (rd_set && ((v == 9'h0C5) == rd_in))
                  `uvm_error("MON", $sformatf("SGMII: %s with RD%s at the ordered set", v == 9'h0C5 ? "/I1/" : "/I2/", rd_in ? "+" : "-"))
              end else
                `uvm_error("MON", $sformatf("SGMII: K28.5 followed by %h", v))
            end
          end
          M_PKT: begin
            if (v == 9'h1FD) begin                          // /T/
              t = sgmii_transaction::type_id::create("t");
              t.t_odd = !even; t.n_r = 0; t.er_pos = -1;
              frame(t, pk, erp);
              st = M_R;
            end else if (v == 9'h1FE) begin pk.push_back(8'h00); if (erp < 0) erp = pk.size() - 1; end   // /V/
            else if (v[8]) `uvm_error("MON", $sformatf("SGMII: control code %h inside a packet", v))
            else pk.push_back(v[7:0]);
          end
          M_R: begin
            if (v == 9'h1F7) t.n_r++;                       // /R/
            else begin
              t.code_errs = nerr; nerr = 0;
              publish(t);
              st = M_IDLE;
              if (v != 9'h1BC) `uvm_error("MON", $sformatf("SGMII: %h after /T/ /R/ instead of an idle", v))
              if (!even) `uvm_error("MON", "SGMII: idle after /R/ at an odd position")
            end
          end
          M_CFG: begin
            cw[8*cpos +: 8] = v[7:0];
            cpos++;
            if (cpos == 2) begin
              if (cfg_open && cw != cur_cw) flush_cfg(cur_cw, nerr);
              cur_cw = cw; cfg_open = 1;
              st = M_IDLE;
            end
          end
        endcase
        // the disparity check of /I1/ / /I2/ needs a known RD at the ordered set
        if (v == 9'h1BC && even) rd_set = 1;
        prev = v;
        even = !even;
      end
    end
  endtask

  function void publish(sgmii_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // preamble (0x55 ...) and SFD (0xD5) stripped; /V/ position kept
  function void frame(sgmii_transaction t, bit [7:0] pk[$], int erp);
    int i = 0;
    while (i < pk.size() && pk[i] == 8'h55) i++;
    t.pre_len = i;
    if (i >= pk.size() || pk[i] != 8'hD5) `uvm_error("MON", "SGMII: no SFD after the preamble")
    for (int j = i + 1; j < pk.size(); j++) t.bytes.push_back(pk[j]);
    t.er_pos = (erp > i) ? erp - i - 1 : -1;
    t.is_cfg = 0;
  endfunction

  function void flush_cfg(bit [15:0] w, ref int unsigned nerr);
    sgmii_transaction c = sgmii_transaction::type_id::create("cfg");
    c.is_cfg = 1; c.cfg_word = w; c.er_pos = -1; c.code_errs = nerr; nerr = 0;
    publish(c);
  endfunction
endclass
