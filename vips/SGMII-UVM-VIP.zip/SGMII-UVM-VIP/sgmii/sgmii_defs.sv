// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_defs.sv -- SGMII shared type definitions

package sgmii_defs_pkg;

  typedef enum bit [1:0] {SGMII_OK, SGMII_ERR} sgmii_status_e;

  // SGMII configuration word (PHY to MAC): [15] link, [14] ack, [12] duplex,
  // [11:10] speed (10 = 1000, 01 = 100, 00 = 10 Mb/s), [0] = 1
  localparam bit [9:0] K28_5_RDN = 10'b0011111010;

  // IEEE 802.3 Clause 36 8b/10b encoder: d = HGFEDCBA, returns {abcdei, fghj};
  // rd: running disparity (1 = positive) before / after the code group
  function automatic bit [9:0] enc8b10b(bit [7:0] d, bit k, ref bit rd);
    // 5b/6b (EDCBA -> abcdei) and 3b/4b (HGF -> fghj) for RD-
    bit [5:0] t6[32] = '{6'b100111, 6'b011101, 6'b101101, 6'b110001, 6'b110101, 6'b101001, 6'b011001, 6'b111000,
                         6'b111001, 6'b100101, 6'b010101, 6'b110100, 6'b001101, 6'b101100, 6'b011100, 6'b010111,
                         6'b011011, 6'b100011, 6'b010011, 6'b110010, 6'b001011, 6'b101010, 6'b011010, 6'b111010,
                         6'b110011, 6'b100110, 6'b010110, 6'b110110, 6'b001110, 6'b101110, 6'b011110, 6'b101011};
    bit [3:0] t4[8] = '{4'b1011, 4'b1001, 4'b0101, 4'b1100, 4'b1101, 4'b1010, 4'b0110, 4'b1110};
    bit [5:0] c6;
    bit [3:0] c4;
    bit r = k ? 1'b0 : rd;           // a K code is built for RD- and complemented for RD+
    int x = d[4:0], y = d[7:5];
    c6 = (x == 28 && k) ? 6'b001111 : t6[x];
    if (r && ($countones(c6) != 3 || c6 == 6'b111000)) c6 = ~c6;
    if ($countones(c6) != 3) r = !r;
    if (y == 7 && (k || (!r && (x == 17 || x == 18 || x == 20)) || (r && (x == 11 || x == 13 || x == 14))))
      c4 = 4'b0111;                  // A7
    else
      c4 = t4[y];
    if (r && ($countones(c4) != 2 || c4 == 4'b1100)) c4 = ~c4;
    enc8b10b = {c6, c4};
    if (k && rd) enc8b10b = ~enc8b10b;
    if ($countones(enc8b10b) > 5) rd = 1'b1;
    else if ($countones(enc8b10b) < 5) rd = 1'b0;
  endfunction

endpackage
