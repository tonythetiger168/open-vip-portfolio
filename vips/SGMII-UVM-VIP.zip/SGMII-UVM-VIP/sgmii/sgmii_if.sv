// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_if.sv -- SGMII interface

interface sgmii_if (input logic clk);
  logic rst_n;

  logic [7:0] txd;
  logic tx_en;
  logic tx_er;
  logic cfg_tx;
  logic [15:0] cfg_word;
  logic [9:0] tbi;

  modport DUT (input clk, rst_n, input txd, input tx_en, input tx_er, input cfg_tx, input cfg_word, output tbi);
  modport MON (input clk, rst_n, txd, tx_en, tx_er, cfg_tx, cfg_word, tbi);

  clocking drv_cb @(posedge clk);
    input rst_n, tbi;
    inout txd, tx_en, tx_er, cfg_tx, cfg_word;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, txd, tx_en, tx_er, cfg_tx, cfg_word, tbi;
  endclocking
endinterface
