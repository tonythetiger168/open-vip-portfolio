// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_transaction.svh -- SGMII transaction

class sgmii_transaction extends uvm_sequence_item;
  `uvm_object_utils(sgmii_transaction)

  // request (driven by the agent)
  rand bit is_cfg;
  bit [7:0] bytes[$];
  int er_pos;
  bit [15:0] cfg_word;
  // response (returned by the DUT)
  bit [7:0] code_errs;
  // bookkeeping (not compared)
  rand bit [10:0] plen;
  rand bit [31:0] seed;
  rand bit [2:0] cfg_sets;
  rand bit inj_er;
  int unsigned pre_len;
  bit t_odd;
  int unsigned n_r;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { is_cfg dist { 0 := 4, 1 := 1 }; inj_er dist { 0 := 5, 1 := 1 }; }
  constraint c_len  { plen inside {[46:160]}; cfg_sets inside {[2:6]}; }

  function new(string name = "sgmii_transaction"); super.new(name); endfunction

  // IEEE 802.3 CRC-32 (reflected 0xEDB88320, init/final xor all ones)
  function bit [31:0] crc32(bit [7:0] b[$], int unsigned n);
    bit [31:0] c = 32'hFFFF_FFFF;
    for (int unsigned i = 0; i < n; i++) begin
      c ^= {24'h0, b[i]};
      for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    return ~c;
  endfunction

  // destination/source address, length/type, payload from seed, FCS
  function void build_frame(int unsigned payload_len, bit [31:0] seed, bit [15:0] etype);
    bit [31:0] x = seed | 32'h1;
    bit [31:0] fcs;
    bytes.delete();
    for (int i = 0; i < 6; i++) bytes.push_back(8'hFF);                 // broadcast
    for (int i = 0; i < 6; i++) bytes.push_back(i == 0 ? 8'h02 : 8'(seed >> (i * 4)));
    bytes.push_back(etype[15:8]);
    bytes.push_back(etype[7:0]);
    for (int unsigned i = 0; i < payload_len; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      bytes.push_back(x[7:0]);
    end
    fcs = crc32(bytes, bytes.size());
    for (int i = 0; i < 4; i++) bytes.push_back(fcs[i*8 +: 8]);       // LSB first
  endfunction

  // FCS of a received frame (last four bytes) is correct
  function bit fcs_ok();
    bit [31:0] fcs;
    if (bytes.size() < 18) return 0;
    fcs = crc32(bytes, bytes.size() - 4);
    for (int i = 0; i < 4; i++) if (bytes[bytes.size() - 4 + i] != fcs[i*8 +: 8]) return 0;
    return 1;
  endfunction

  function void post_randomize();
    bytes.delete();
    er_pos = -1;
    cfg_word = 16'h0;
    if (is_cfg)
      cfg_word = {seed[15], 1'b0, 1'b0, seed[12:10] == 3'b111 ? 3'b110 : seed[12:10], 9'h0, 1'b1};
    else begin
      build_frame(plen, seed, 16'h0800);
      if (inj_er) er_pos = seed % bytes.size();
    end
  endfunction

  function void do_copy(uvm_object rhs);
    sgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    is_cfg = rhs_.is_cfg;
    bytes = rhs_.bytes;
    er_pos = rhs_.er_pos;
    cfg_word = rhs_.cfg_word;
    code_errs = rhs_.code_errs;
    plen = rhs_.plen;
    seed = rhs_.seed;
    cfg_sets = rhs_.cfg_sets;
    inj_er = rhs_.inj_er;
    pre_len = rhs_.pre_len;
    t_odd = rhs_.t_odd;
    n_r = rhs_.n_r;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (is_cfg != rhs_.is_cfg) return 0;
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (er_pos != rhs_.er_pos) return 0;
    if (cfg_word != rhs_.cfg_word) return 0;
    if (code_errs != rhs_.code_errs) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(sgmii_transaction rhs_);
    if (is_cfg != rhs_.is_cfg) return 0;
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (er_pos != rhs_.er_pos) return 0;
    if (cfg_word != rhs_.cfg_word) return 0;
    return 1;
  endfunction

  function string qstr_bytes();
    string s = $sformatf("[%0d]{", bytes.size());
    foreach (bytes[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bytes[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SGMII{tag=%0d is_cfg=0x%0h bytes=%s er_pos=0x%0h cfg_word=0x%0h code_errs=0x%0h}", tag, is_cfg, qstr_bytes(), er_pos, cfg_word, code_errs);
  endfunction
endclass
