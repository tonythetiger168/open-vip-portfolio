// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// sgmii_driver.svh -- SGMII driver: GMII frames (7 preamble bytes, SFD, frame, tx_er on one byte) or a run of configuration ordered sets

class sgmii_driver extends uvm_driver #(sgmii_transaction);
  `uvm_component_utils(sgmii_driver)

  uvm_analysis_port #(sgmii_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual sgmii_if vif;
  sgmii_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sgmii: virtual interface not set")
    if (!uvm_config_db#(sgmii_config)::get(this, "", "cfg", cfg))
      cfg = sgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    sgmii_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.txd      <= 8'h0;
    vif.drv_cb.tx_en    <= 1'b0;
    vif.drv_cb.tx_er    <= 1'b0;
    vif.drv_cb.cfg_tx   <= 1'b0;
    vif.drv_cb.cfg_word <= 16'h0;
  endtask

  task drive_item(sgmii_transaction t);
    @(vif.drv_cb);
    if (t.is_cfg) begin
      vif.drv_cb.cfg_word <= t.cfg_word;
      vif.drv_cb.cfg_tx   <= 1'b1;
      repeat (4 * t.cfg_sets) @(vif.drv_cb);
      vif.drv_cb.cfg_tx   <= 1'b0;
      repeat (12) @(vif.drv_cb);
    end else begin
      for (int i = 0; i < 8 + t.bytes.size(); i++) begin
        vif.drv_cb.tx_en <= 1'b1;
        vif.drv_cb.txd   <= (i < 7) ? 8'h55 : (i == 7) ? 8'hD5 : t.bytes[i - 8];
        vif.drv_cb.tx_er <= (i >= 8 && i - 8 == t.er_pos);
        @(vif.drv_cb);
      end
      vif.drv_cb.tx_en <= 1'b0;
      vif.drv_cb.tx_er <= 1'b0;
      vif.drv_cb.txd   <= 8'h0;
      repeat (12) @(vif.drv_cb);                // inter-packet gap
      if (t.er_pos >= 0) t.bytes[t.er_pos] = 8'h00;   // the line carries /V/, not the byte
    end
  endtask

endclass
