// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SGMII testbench top with a functional SGMII DUT model

`ifndef SGMII_UVM_VIP_TB_SV
`define SGMII_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sgmii_defs_pkg::*;
import sgmii_pkg::*;
import sgmii_env_pkg::*;
import sgmii_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  sgmii_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  sgmii_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .txd(vif.txd),
    .tx_en(vif.tx_en),
    .tx_er(vif.tx_er),
    .cfg_tx(vif.cfg_tx),
    .cfg_word(vif.cfg_word),
    .tbi(vif.tbi)
  );

  // Concurrent protocol checks
  sgmii_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .txd(vif.txd),
    .tx_en(vif.tx_en),
    .tx_er(vif.tx_er),
    .cfg_tx(vif.cfg_tx),
    .cfg_word(vif.cfg_word),
    .tbi(vif.tbi)
  );

  initial begin
    uvm_config_db#(virtual sgmii_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module sgmii_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [7:0]  txd,
  input  logic        tx_en,
  input  logic        tx_er,
  input  logic        cfg_tx,
  input  logic [15:0] cfg_word,
  output logic [9:0]  tbi
);
  typedef enum logic [2:0] {S_IDLE, S_IDLE2, S_DATA, S_R, S_R2, S_CFG} st_t;
  st_t        st;
  logic       rd, even, i1, c2;
  logic [1:0] cn;
  logic [15:0] cw;

  // 5b/6b and 3b/4b sub-blocks for RD- (abcdei / fghj)
  function automatic logic [5:0] sb6(input logic [4:0] x);
    case (x)
      5'd0: sb6 = 6'b100111;  5'd1: sb6 = 6'b011101;  5'd2: sb6 = 6'b101101;  5'd3: sb6 = 6'b110001;
      5'd4: sb6 = 6'b110101;  5'd5: sb6 = 6'b101001;  5'd6: sb6 = 6'b011001;  5'd7: sb6 = 6'b111000;
      5'd8: sb6 = 6'b111001;  5'd9: sb6 = 6'b100101;  5'd10: sb6 = 6'b010101; 5'd11: sb6 = 6'b110100;
      5'd12: sb6 = 6'b001101; 5'd13: sb6 = 6'b101100; 5'd14: sb6 = 6'b011100; 5'd15: sb6 = 6'b010111;
      5'd16: sb6 = 6'b011011; 5'd17: sb6 = 6'b100011; 5'd18: sb6 = 6'b010011; 5'd19: sb6 = 6'b110010;
      5'd20: sb6 = 6'b001011; 5'd21: sb6 = 6'b101010; 5'd22: sb6 = 6'b011010; 5'd23: sb6 = 6'b111010;
      5'd24: sb6 = 6'b110011; 5'd25: sb6 = 6'b100110; 5'd26: sb6 = 6'b010110; 5'd27: sb6 = 6'b110110;
      5'd28: sb6 = 6'b001110; 5'd29: sb6 = 6'b101110; 5'd30: sb6 = 6'b011110; default: sb6 = 6'b101011;
    endcase
  endfunction
  function automatic logic [3:0] sb4(input logic [2:0] y);
    case (y)
      3'd0: sb4 = 4'b1011; 3'd1: sb4 = 4'b1001; 3'd2: sb4 = 4'b0101; 3'd3: sb4 = 4'b1100;
      3'd4: sb4 = 4'b1101; 3'd5: sb4 = 4'b1010; 3'd6: sb4 = 4'b0110; default: sb4 = 4'b1110;
    endcase
  endfunction
  function automatic logic [3:0] ones6(input logic [5:0] v); ones6 = v[0]+v[1]+v[2]+v[3]+v[4]+v[5]; endfunction
  function automatic logic [3:0] ones4(input logic [3:0] v); ones4 = v[0]+v[1]+v[2]+v[3]; endfunction

  // {rd_out, code}
  function automatic logic [10:0] encode(input logic [7:0] d, input logic k, input logic rdi);
    logic [5:0] a6; logic [3:0] a4; logic r; logic [9:0] c;
    r  = k ? 1'b0 : rdi;
    a6 = (k && d[4:0] == 5'd28) ? 6'b001111 : sb6(d[4:0]);
    if (r && (ones6(a6) != 4'd3 || a6 == 6'b111000)) a6 = ~a6;
    if (ones6(a6) != 4'd3) r = ~r;
    if (d[7:5] == 3'd7 && (k || (!r && (d[4:0] == 5'd17 || d[4:0] == 5'd18 || d[4:0] == 5'd20))
                           || (r && (d[4:0] == 5'd11 || d[4:0] == 5'd13 || d[4:0] == 5'd14))))
      a4 = 4'b0111;
    else
      a4 = sb4(d[7:5]);
    if (r && (ones4(a4) != 4'd2 || a4 == 4'b1100)) a4 = ~a4;
    if (ones4(a4) != 4'd2) r = ~r;
    c = {a6, a4};
    if (k && rdi) begin c = ~c; r = ~r; end
    encode = {r, c};
  endfunction

  localparam logic [7:0] K28_5 = 8'hBC, K27_7 = 8'hFB, K29_7 = 8'hFD, K23_7 = 8'hF7, K30_7 = 8'hFE;
  localparam logic [7:0] D16_2 = 8'h50, D5_6 = 8'hC5, D21_5 = 8'hB5, D2_2 = 8'h42;

  logic [7:0] sym;
  logic       symk;
  st_t        nst;
  always_comb begin
    sym = K28_5; symk = 1'b1; nst = st;
    case (st)
      S_IDLE:
        if (cfg_tx) begin sym = K28_5; symk = 1'b1; nst = S_CFG; end
        else if (tx_en) begin sym = K27_7; symk = 1'b1; nst = S_DATA; end
        else begin sym = K28_5; symk = 1'b1; nst = S_IDLE2; end
      S_IDLE2: begin sym = i1 ? D5_6 : D16_2; symk = 1'b0; nst = S_IDLE; end
      S_DATA:
        if (tx_en) begin sym = tx_er ? K30_7 : txd; symk = tx_er; nst = S_DATA; end
        else begin sym = K29_7; symk = 1'b1; nst = S_R; end
      S_R:  begin sym = K23_7; symk = 1'b1; if (even) nst = S_R2; else nst = S_IDLE; end
      S_R2: begin sym = K23_7; symk = 1'b1; nst = S_IDLE; end
      default: begin                               // S_CFG: /C1/ or /C2/ after K28.5
        symk = 1'b0;
        case (cn)
          2'd0: sym = c2 ? D2_2 : D21_5;
          2'd1: sym = cw[7:0];
          default: sym = cw[15:8];
        endcase
        if (cn == 2'd2) nst = S_IDLE; else nst = S_CFG;
      end
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      // the reset code group is the K28.5 (RD-) of an /I2/ at position 0;
      // it leaves the disparity positive and D16.2 follows
      st <= S_IDLE2; rd <= 1'b1; even <= 1'b0; i1 <= 1'b0; c2 <= 1'b0; cn <= '0; cw <= '0;
      tbi <= 10'b0011111010;
    end else begin
      logic [10:0] e;
      e = encode(sym, symk, rd);
      tbi <= e[9:0];
      rd  <= e[10];
      even <= !even;
      st <= nst;
      if (st == S_IDLE && !cfg_tx && !tx_en) i1 <= rd;     // /I1/ corrects a positive RD
      if (st == S_IDLE && cfg_tx) begin cn <= '0; cw <= cfg_word; end
      if (st == S_CFG) begin
        cn <= cn + 2'd1;
        if (cn == 2'd2) c2 <= !c2;
      end
    end
  end
endmodule
`endif
