// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SGMII DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened sgmii_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [7:0] txd = 0;
  logic tx_en = 0, tx_er = 0, cfg_tx = 0;
  logic [15:0] cfg_word = 0;
  wire [9:0] tbi;

  always #5 clk = ~clk;

  sgmii_model u_dut (.clk(clk), .rst_n(rst_n), .txd(txd), .tx_en(tx_en), .tx_er(tx_er), .cfg_tx(cfg_tx),
                     .cfg_word(cfg_word), .tbi(tbi));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic [9:0] hist [0:4095];
  int n = 0;
  logic [15:0] cwh [0:4095];
  always @(posedge clk) if (rst_n) begin hist[n % 4096] <= tbi; cwh[n % 4096] <= cfg_word; n <= n + 1; end

  // Reference 8b/10b data encoder written from the IEEE 802.3 Clause 36
  // tables (Table 36-1a..e): explicit RD- and RD+ columns, independent of the
  // model's complement-based encoder. rd = 1 means RD+. Returns {rd', code}.
  logic [5:0] t6n [0:31] = '{6'b100111, 6'b011101, 6'b101101, 6'b110001, 6'b110101, 6'b101001, 6'b011001, 6'b111000,
                              6'b111001, 6'b100101, 6'b010101, 6'b110100, 6'b001101, 6'b101100, 6'b011100, 6'b010111,
                              6'b011011, 6'b100011, 6'b010011, 6'b110010, 6'b001011, 6'b101010, 6'b011010, 6'b111010,
                              6'b110011, 6'b100110, 6'b010110, 6'b110110, 6'b001110, 6'b101110, 6'b011110, 6'b101011};
  logic [5:0] t6p [0:31] = '{6'b011000, 6'b100010, 6'b010010, 6'b110001, 6'b001010, 6'b101001, 6'b011001, 6'b000111,
                              6'b000110, 6'b100101, 6'b010101, 6'b110100, 6'b001101, 6'b101100, 6'b011100, 6'b101000,
                              6'b100100, 6'b100011, 6'b010011, 6'b110010, 6'b001011, 6'b101010, 6'b011010, 6'b000101,
                              6'b001100, 6'b100110, 6'b010110, 6'b001001, 6'b001110, 6'b010001, 6'b100001, 6'b010100};
  logic [3:0] t4n [0:8] = '{4'b1011, 4'b1001, 4'b0101, 4'b1100, 4'b1101, 4'b1010, 4'b0110, 4'b1110, 4'b0111};
  logic [3:0] t4p [0:8] = '{4'b0100, 4'b1001, 4'b0101, 4'b0011, 4'b0010, 4'b1010, 4'b0110, 4'b0001, 4'b1000};
  int a7_hits = 0;
  function automatic logic [10:0] ref_enc(input logic [7:0] d, input logic rd);
    logic [5:0] c6; logic [3:0] c4; logic r; int y;
    c6 = rd ? t6p[d[4:0]] : t6n[d[4:0]];
    r  = ($countones(c6) == 3) ? rd : !rd;
    y  = d[7:5];
    if (y == 7 && ((!r && d[4:0] inside {5'd17, 5'd18, 5'd20}) || (r && d[4:0] inside {5'd11, 5'd13, 5'd14}))) begin
      y = 8; a7_hits++;
    end
    c4 = r ? t4p[y] : t4n[y];
    if ($countones(c4) != 2) r = !r;
    return {r, c6, c4};
  endfunction
  // data code group -> byte (-1 if not a valid data code group)
  function automatic int ref_dec(input logic [9:0] c);
    logic [10:0] e;
    for (int v = 0; v < 256; v++) for (int r = 0; r < 2; r++) begin
      e = ref_enc(v[7:0], r[0]);
      if (e[9:0] == c) return v;
    end
    return -1;
  endfunction

  // index of the first code group equal to c at or after position from
  function automatic int find(input logic [9:0] c, input int from);
    for (int i = from; i < n; i++) if (hist[i] == c) return i;
    return -1;
  endfunction

  initial begin
    int s, t, r, s0;
    repeat (3) @(posedge clk);
    rst_n = 1;
    repeat (10) @(negedge clk);
    // idle from RD-: K28.5 (RD-) then D16.2 (RD+), repeating; positions are
    // counted from this first comma (even)
    s0 = find(10'b0011111010, 1);
    chk(s0 >= 0 && hist[s0 + 1] == 10'b1001000101, "/I2/ idle ordered set");
    chk(hist[s0 + 2] == hist[s0] && hist[s0 + 3] == hist[s0 + 1], "idle repeats with RD- at every ordered set");
    // a short frame: 7 x 0x55, SFD, 4 bytes
    for (int i = 0; i < 12; i++) begin
      @(negedge clk); tx_en = 1; txd = (i < 7) ? 8'h55 : (i == 7) ? 8'hD5 : 8'hA0 + i;
    end
    @(negedge clk); tx_en = 0;
    repeat (12) @(negedge clk);
    s = find(10'b1101101000, 0);
    chk(s >= 0 && (s - s0) % 2 == 0, "/S/ (K27.7 RD-) at an even position");
    chk(hist[s + 1] == 10'b1010100101, "preamble 0x55 = D21.2");
    t = find(10'b1011101000, s);
    if (t < 0) t = find(10'b0100010111, s);
    chk(t > s, "/T/ (K29.7) after the frame");
    r = t + 1;
    chk(hist[r] == 10'b1110101000 || hist[r] == 10'b0001010111, "/R/ (K23.7) after /T/");
    if ((t - s0) % 2 == 1) begin chk(hist[r + 1] == hist[r] || hist[r + 1] == ~hist[r], "second /R/ when /T/ is odd"); r++; end
    chk((r + 1 - s0) % 2 == 0 && (hist[r + 1] == 10'b0011111010 || hist[r + 1] == 10'b1100000101), "idle comma at an even position after /R/");
    // tx_er inside a frame becomes /V/ (K30.7)
    for (int i = 0; i < 10; i++) begin
      @(negedge clk); tx_en = 1; tx_er = (i == 9); txd = (i < 7) ? 8'h55 : 8'hD5;
    end
    @(negedge clk); tx_en = 0; tx_er = 0;
    repeat (12) @(negedge clk);
    chk(find(10'b0111101000, r) > 0 || find(10'b1000010111, r) > 0, "/V/ (K30.7) for tx_er");
    // configuration ordered sets: K28.5, D21.5, then the word
    @(negedge clk); cfg_word = 16'h9801; cfg_tx = 1;
    repeat (16) @(negedge clk);
    cfg_tx = 0;
    repeat (8) @(negedge clk);
    s = find(10'b1010101010, r);
    chk(s > 0 && (hist[s - 1] == 10'b0011111010 || hist[s - 1] == 10'b1100000101), "/C1/ = K28.5 D21.5");
    begin
      int c2a, c2b;
      c2a = find(10'b1011010101, r); c2b = find(10'b0100100101, r);
      chk((c2a < 0 || c2a > s) && (c2b < 0 || c2b > s), "the first configuration ordered set after reset is /C1/");
    end
    chk(hist[s + 1] == 10'b0111010100 || hist[s + 1] == 10'b1000101011, "config word low byte 0x01 = D1.0");
    chk(find(10'b1011010101, s) > 0 || find(10'b0100100101, s) > 0, "/C2/ = K28.5 D2.2");

    // every byte value through the data path, compared code group by code
    // group with the table encoder (both running disparities: the stream is
    // sent twice with an odd-disparity byte between)
    begin : all_bytes
      logic [10:0] e; logic rd; int bad = 0, s1, j;
      a7_hits = 0;
      for (int i = 0; i < 8 + 513; i++) begin
        @(negedge clk); tx_en = 1;
        txd = (i < 7) ? 8'h55 : (i == 7) ? 8'hD5 : (i < 264) ? 8'(i - 8) : (i == 264) ? 8'h00 : 8'(i - 265);
      end
      @(negedge clk); tx_en = 0;
      repeat (12) @(negedge clk);
      s1 = find(10'b1101101000, s);
      // the preamble is shortened when /S/ waits for an even position; data
      // starts after the SFD (D21.6). Preamble and SFD are balanced, so RD- holds.
      j = s1 + 1;
      while (j < s1 + 10 && ref_dec(hist[j]) != 8'hD5) j++;
      rd = 1'b0;
      for (int i = 0; i < 513; i++) begin
        e = ref_enc((i < 256) ? 8'(i) : (i == 256) ? 8'h00 : 8'(i - 257), rd);
        if (hist[j + 1 + i] !== e[9:0]) begin
          if (bad < 4) $display("  byte %0d: got %b exp %b", i, hist[j + 1 + i], e[9:0]);
          bad++;
        end
        rd = e[10];
      end
      chk(s1 > 0 && bad == 0, $sformatf("all 256 data bytes match the Clause 36 tables (%0d mismatches)", bad));
      chk(a7_hits >= 6, "alternate D.x.A7 encodings exercised");
      s = s1;
    end
    // /T/ on both even and odd positions: the extra /R/ is K23.7 too
    for (int len = 9; len <= 10; len++) begin
      for (int i = 0; i < len; i++) begin
        @(negedge clk); tx_en = 1; txd = (i < 7) ? 8'h55 : (i == 7) ? 8'hD5 : 8'h3C;
      end
      @(negedge clk); tx_en = 0;
      repeat (8) @(negedge clk);
    end
    begin : rr
      int nr = 0, odd = 0;
      for (int i = s + 1; i < n - 2; i++)
        if (hist[i] == 10'b1011101000 || hist[i] == 10'b0100010111) begin
          chk(hist[i + 1] == 10'b1110101000 || hist[i + 1] == 10'b0001010111, "/R/ after /T/");
          if ((i - s0) % 2 == 1) begin
            odd++;
            chk(hist[i + 2] == 10'b1110101000 || hist[i + 2] == 10'b0001010111, "second /R/ (K23.7) when /T/ is odd");
          end
          nr++;
        end
      chk(nr >= 3 && odd >= 1, "/T/ seen at both parities");
    end
    // after every comma of an idle ordered set: /I1/ (D5.6) follows K28.5 RD+,
    // /I2/ (D16.2 RD+) follows K28.5 RD-
    begin : idle
      int bad = 0, n1 = 0;
      for (int i = 0; i < n - 1; i++) begin
        if (hist[i] == 10'b1100000101 && ref_dec(hist[i + 1]) == 8'hC5) n1++;
        else if (hist[i] == 10'b1100000101 && !(ref_dec(hist[i + 1]) inside {8'hB5, 8'h42})) bad++;
        if (hist[i] == 10'b0011111010 && !(hist[i + 1] inside {10'b1001000101, 10'b1010101010, 10'b0100100101})) bad++;
      end
      chk(bad == 0 && n1 > 0, $sformatf("/I1/ and /I2/ chosen by the comma disparity (%0d bad)", bad));
    end
    // reset state: the first code group is D16.2 RD+ of an /I2/, then K28.5 RD-
    chk((hist[0] == 10'b0011111010 && hist[1] == 10'b1001000101) || (hist[0] == 10'b1001000101 && hist[1] == 10'b0011111010),
        "first code groups after reset: K28.5 RD- then D16.2 RD+");
    // configuration with a word that changes every clock: each /C/ carries the
    // word sampled with its K28.5, and /C1/ comes first
    begin : cfgw
      int c0, bad = 0, nc = 0, alt = 0, prev = -1;
      c0 = n;
      @(negedge clk); cfg_tx = 1;
      repeat (40) begin cfg_word = $urandom; @(negedge clk); end
      cfg_tx = 0;
      repeat (8) @(negedge clk);
      for (int i = c0; i < n - 3; i++)
        if ((hist[i] == 10'b0011111010 || hist[i] == 10'b1100000101) && ref_dec(hist[i + 1]) inside {8'hB5, 8'h42}) begin
          if (prev >= 0 && ref_dec(hist[i + 1]) == prev) alt++;
          prev = ref_dec(hist[i + 1]);
          nc++;
          if (ref_dec(hist[i + 2]) != cwh[i - 1][7:0] || ref_dec(hist[i + 3]) != cwh[i - 1][15:8]) bad++;
        end
      chk(nc >= 8 && bad == 0, $sformatf("config word sampled with its comma (%0d of %0d bad)", bad, nc));
      chk(alt == 0, "/C1/ and /C2/ alternate");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
