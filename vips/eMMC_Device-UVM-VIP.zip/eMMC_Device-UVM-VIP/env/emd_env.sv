// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// emd_env.sv -- EMD environment: reference-model scoreboard, checker, coverage

package emd_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import emd_defs_pkg::*;
  import emd_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class emd_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(emd_scoreboard)
    uvm_analysis_imp_exp #(emd_transaction, emd_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(emd_transaction, emd_scoreboard) obs_ap;

    emd_config cfg;
    emd_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    // the device (scoreboard copy), kept across items
    bit [255:0] mem [16];
    bit         minit = 0;
    int         cst = 0, polls = 0, dm = 0, rdd = 0, tokd = 0, tokn = 0, busyn = 0, dcnt = 0;
    bit         crc_e = 0, ill = 0;
    bit [15:0]  rca = 0;
    int         rxc = 0, txd = 0, txn = 0;
    bit [47:0]  rxs = 0;
    bit [135:0] txs = 0;
    bit [3:0]   blk = 0;
    bit [255:0] buff = 0;
    bit [15:0]  c = 0, rc = 0;
    bit [4:0]   tok = 0;
    bit         o_cmd = 0, o_cmd_oe = 0, o_dat = 0, o_dat_oe = 0;
    localparam int NCR = 2, NAC = 2, BUSY = 4, SELBUSY = 3, POLLS = 1;

    function void reset_dev();
      cst = 0; polls = 0; dm = 0; rdd = 0; tokd = 0; tokn = 0; busyn = 0; dcnt = 0; crc_e = 0; ill = 0; rca = 0;
      rxc = 0; txd = 0; txn = 0; rxs = 0; txs = 0; blk = 0; buff = 0; c = 0; rc = 0; tok = 0;
      o_cmd = 0; o_cmd_oe = 0; o_dat = 0; o_dat_oe = 0;
    endfunction
    function void send(bit [135:0] fr, int n);
      txs = fr; txn = n; txd = NCR - 1;
    endfunction
    function void r1(bit [5:0] i, int st);
      send({emd_frame(i, {8'h00, crc_e, ill, 9'h000, 4'(st), 1'b1, 8'h00}, 1'b0), 88'h0}, 48);
      crc_e = 0; ill = 0;
    endfunction
    function void frame(bit [47:0] f);
      bit [5:0] i = f[45:40];
      bit [31:0] a = f[39:8];
      int st = cst;
      if (emd_crc7({80'h0, f[47:8]}, 40) != f[7:1] || !f[0] || !f[46]) begin crc_e = 1; return; end
      if (i == 0) begin cst = 0; polls = 0; rca = 0; dm = 0; end
      else if (i == 1 && cst == 0) begin
        bit rdy = polls >= POLLS;
        if (polls != 15) polls++;
        if (rdy) cst = 1;
        send({2'b00, 6'h3F, rdy, 2'b10, 29'h00FF_8080, 8'hFF, 88'h0}, 48);
      end else if (i == 2 && cst == 1) begin
        bit [127:0] cid = {EMD_CID_BODY, emd_crc7(EMD_CID_BODY, 120), 1'b1};
        cst = 2; send({2'b00, 6'h3F, cid[127:1], 1'b1}, 136);
      end else if (i == 3 && cst == 2 && a[31:16] != 0) begin
        cst = 3; rca = a[31:16]; r1(i, st);
      end else if (i == 7 && (cst == 3 || cst == 4)) begin
        if (a[31:16] == rca) begin cst = 4; r1(i, st); dm = 6; end
        else if (cst == 4) cst = 3;
      end else if (i == 13 && (cst == 3 || cst == 4)) begin
        if (a[31:16] == rca) r1(i, st);
      end else if ((i == 17 || i == 24) && cst == 4) begin
        r1(i, st);
        blk = a[3:0];
        if (i == 17) begin dm = 7; buff = mem[blk]; end
        else dm = 1;
      end else ill = 1;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(emd_config)::get(this, "", "cfg", cfg))
        cfg = emd_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(emd_transaction t);
      if (!minit) begin for (int b = 0; b < 16; b++) mem[b] = emd_init_blk(b); minit = 1; end
      t.so.delete();
      foreach (t.mo[i]) begin
        bit cl, dl;
        if (!t.mo[i][4]) begin reset_dev(); t.so.push_back(4'h0); continue; end
        t.so.push_back({o_cmd_oe, o_cmd & o_cmd_oe, o_dat_oe, o_dat & o_dat_oe});
        cl = t.mo[i][3] ? t.mo[i][2] : (o_cmd_oe ? o_cmd : 1'b1);
        dl = t.mo[i][1] ? t.mo[i][0] : (o_dat_oe ? o_dat : 1'b1);
        // command receiver (not while a response goes out)
        if (txd == 0 && txn == 0) begin
          if (rxc == 0) begin if (!cl) begin rxc = 1; rxs = 0; end end
          else begin
            rxs = {rxs[46:0], cl}; rxc++;
            if (rxc == 48) begin rxc = 0; frame(rxs); end
          end
        end
        // write block receiver
        case (dm)
          1: if (!dl) begin dm = 2; dcnt = 0; c = 0; end
          2: begin
               buff = {buff[254:0], dl};
               c = emd_crc16(c, dl);
               if (++dcnt == 256) begin dm = 3; dcnt = 0; rc = 0; end
             end
          3: begin
               rc = {rc[14:0], dl};
               if (++dcnt == 16) dm = 4;
             end
          4: begin
               bit good = dl && rc == c;
               if (good) mem[blk] = buff;
               tok = good ? 5'b0_010_1 : 5'b0_101_1;
               dm = 5; tokd = 1; tokn = 5; busyn = good ? BUSY : 0;
             end
          default: ;
        endcase
        // outputs for the next period
        if (txd > 0) begin txd--; o_cmd_oe = 0; end
        else if (txn > 0) begin
          o_cmd_oe = 1; o_cmd = txs[135]; txs = txs << 1; txn--;
          if (txn == 0 && dm == 7) begin dm = 8; rdd = NAC; end
          if (txn == 0 && dm == 6) begin dm = 5; tokd = 2; tokn = 0; busyn = SELBUSY; end
        end else o_cmd_oe = 0;
        case (dm)
          5: if (tokd > 0) begin tokd--; o_dat_oe = 0; end
             else if (tokn > 0) begin o_dat_oe = 1; o_dat = tok[4]; tok = tok << 1; tokn--; end
             else if (busyn > 0) begin o_dat_oe = 1; o_dat = 1'b0; busyn--; end
             else begin o_dat_oe = 0; dm = 0; end
          8: if (rdd > 0) begin rdd--; o_dat_oe = 0; end
             else begin o_dat_oe = 1; o_dat = 1'b0; dm = 9; dcnt = 0; c = 0; end
          9: begin
               o_dat_oe = 1; o_dat = buff[255 - dcnt];
               c = emd_crc16(c, o_dat);
               if (++dcnt == 256) begin dm = 10; dcnt = 0; end
             end
          10: begin
                o_dat_oe = 1; o_dat = c[15]; c = c << 1;
                if (++dcnt == 16) dm = 11;
              end
          11: begin o_dat_oe = 1; o_dat = 1'b1; dm = 12; end
          12: begin o_dat_oe = 0; dm = 0; end
          default: o_dat_oe = 0;
        endcase
      end
    endfunction

    function void write_exp(emd_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(emd_transaction t);
      emd_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        emd_transaction e = exp_q.pop_front();
        emd_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("emd scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class emd_env extends uvm_env;
    `uvm_component_utils(emd_env)
    emd_agent      agt;
    emd_scoreboard sb;
    emd_checker    chk;
    emd_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = emd_agent     ::type_id::create("agt", this);
      sb  = emd_scoreboard::type_id::create("sb",  this);
      chk = emd_checker   ::type_id::create("chk", this);
      cov = emd_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
