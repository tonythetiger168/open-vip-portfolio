// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (EMD DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened emd_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b1;
  initial #1 rst_n = 1'b0;      // a falling edge: the device has no clock to see a level reset
  logic emmc_clk = 1'b1, emmc_rst_n = 1'b1, cmd_m = 1'b0, cmd_m_oe = 1'b0, dat0_m = 1'b0, dat0_m_oe = 1'b0;
  wire cmd_s, cmd_s_oe, dat0_s, dat0_s_oe;

  always #5 clk = ~clk;

  emd_model u_dut (.clk(clk), .rst_n(rst_n), .emmc_clk(emmc_clk), .emmc_rst_n(emmc_rst_n), .cmd_m(cmd_m),
                   .cmd_m_oe(cmd_m_oe), .dat0_m(dat0_m), .dat0_m_oe(dat0_m_oe), .cmd_s(cmd_s), .cmd_s_oe(cmd_s_oe),
                   .dat0_s(dat0_s), .dat0_s_oe(dat0_s_oe));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [6:0] crc7(input logic [119:0] d, input integer n);
    logic [6:0] c;
    logic fb;
    c = 7'h00;
    for (int i = 119; i >= 0; i--) if (i < n) begin fb = d[i] ^ c[6]; c = {c[5:0], 1'b0}; if (fb) c = c ^ 7'h09; end
    crc7 = c;
  endfunction
  function automatic logic [15:0] crc16(input logic [15:0] c, input logic b);
    crc16 = {c[14:0], 1'b0} ^ ((b ^ c[15]) ? 16'h1021 : 16'h0000);
  endfunction

  logic cl, dl;
  logic rn = 1'b1;
  integer conflict = 0;
  task automatic clk1(input logic co, input logic c, input logic doe, input logic d);
    @(negedge clk); emmc_clk = 0; emmc_rst_n = rn; cmd_m_oe = co; cmd_m = c; dat0_m_oe = doe; dat0_m = d;
    @(negedge clk);
    emmc_clk = 1;
    cl = co ? c : (cmd_s_oe ? cmd_s : 1'b1);
    dl = doe ? d : (dat0_s_oe ? dat0_s : 1'b1);
    if ((co && cmd_s_oe) || (doe && dat0_s_oe)) conflict = conflict + 1;
    @(negedge clk);
  endtask
  task automatic idle1(); clk1(0, 0, 0, 0); endtask
  logic [135:0] r;
  integer ncr;
  logic got;
  // command; response hunted for 64 clocks, len bits
  task automatic cmd(input logic [5:0] i, input logic [31:0] a, input integer len = 48, input logic badcrc = 0,
                     input integer trail = 4);
    logic [39:0] b;
    logic [47:0] f;
    integer k;
    b = {2'b01, i, a}; f = {b, crc7({80'h0, b}, 40), 1'b1};
    if (badcrc) f[3] = ~f[3];
    repeat (2) idle1();
    for (int j = 47; j >= 0; j--) clk1(1, f[j], 0, 0);
    got = 0; k = 0; r = 0;
    while (k < 64 && !got) begin idle1(); k = k + 1; if (!cl) got = 1; end
    ncr = k;
    if (got) for (int j = 1; j < len; j++) begin idle1(); r = {r[134:0], cl}; end
    repeat (trail) idle1();
  endtask
  function automatic logic r48_ok(input logic [5:0] i);
    r48_ok = r[46] == 1'b0 && r[45:40] == i && r[0] == 1'b1 && crc7({80'h0, 1'b0, r[46:8]}, 40) == r[7:1];
  endfunction
  integer busy, bk, tokk;
  task automatic sel_busy();
    bk = 0;
    do begin idle1(); bk = bk + 1; end while (dl && bk < 16);
    busy = 0;
    while (!dl && busy < 64) begin busy = busy + 1; idle1(); end
    repeat (4) idle1();
  endtask
  logic [255:0] wb, rb;
  logic [3:0] tok;
  task automatic wr_blk(input logic bad = 0);
    logic [15:0] c;
    integer k;
    c = 16'h0;
    clk1(0, 0, 1, 1); clk1(0, 0, 1, 0);
    for (int n = 255; n >= 0; n--) begin c = crc16(c, wb[n]); clk1(0, 0, 1, wb[n]); end
    if (bad) c[7] = ~c[7];
    for (int n = 15; n >= 0; n--) clk1(0, 0, 1, c[n]);
    clk1(0, 0, 1, 1);
    k = 0;
    do begin idle1(); k = k + 1; end while (dl && k < 64);
    tokk = k;
    tok = {dl, 3'b000};
    for (int j = 2; j >= 0; j--) begin idle1(); tok[j] = dl; end
    idle1();
    busy = 0;
    if (dl) begin idle1(); while (!dl && busy < 64) begin busy = busy + 1; idle1(); end end
    repeat (4) idle1();
  endtask
  logic rd_ok;
  task automatic rd_blk();
    logic [15:0] c, x;
    integer k;
    c = 16'h0; x = 16'h0;
    k = 0;
    do begin idle1(); k = k + 1; end while (dl && k < 64);
    for (int n = 255; n >= 0; n--) begin idle1(); rb[n] = dl; c = crc16(c, dl); end
    for (int n = 0; n < 16; n++) begin idle1(); x = {x[14:0], dl}; end
    idle1();
    rd_ok = k == 2 && dl && c == x;
    repeat (4) idle1();
  endtask
  function automatic logic [255:0] init_blk(input integer b);
    for (int i = 0; i < 32; i++) init_blk[255 - 8 * i -: 8] = (16 * b + i) ^ 8'hC3;
  endfunction

  initial begin
    repeat (3) @(posedge clk);
    chk(cmd_s_oe === 1'b0 && dat0_s_oe === 1'b0, "device off the bus in reset");
    rst_n = 1;
    repeat (4) idle1();
    cmd(6'd13, 32'h0001_0000); chk(!got, "CMD13 in idle: illegal, no response");
    cmd(6'd0, 32'h0); chk(!got, "CMD0: no response");
    cmd(6'd1, 32'h40FF_8080);
    chk(got && ncr == 2 && r[46] == 1'b0 && r[45:40] == 6'h3F && r[7:0] == 8'hFF && r[39:8] == 32'h40FF_8080,
        "CMD1: R3 after NCR = 2, busy, sector mode");
    cmd(6'd2, 32'h0, 136); chk(!got, "CMD2 in idle: illegal");
    cmd(6'd1, 32'h40FF_8080); chk(got && r[39:8] == 32'hC0FF_8080, "CMD1: ready");
    cmd(6'd1, 32'h40FF_8080); chk(!got, "CMD1 in ready: illegal");
    cmd(6'd2, 32'h0, 136);
    chk(got && ncr == 2 && r[133:128] == 6'h3F && r[0] && crc7(r[127:8], 120) == r[7:1] &&
        r[127:8] == 120'h150100454D4D43313600123456789A, "CMD2: R2 with the CID and its CRC7");
    cmd(6'd3, 32'h0); chk(!got, "CMD3 with RCA 0: illegal");
    cmd(6'd3, 32'h0001_0000);
    chk(got && ncr == 2 && r48_ok(6'd3) && r[39:8] == 32'h0040_0500, "CMD3: R1, ILLEGAL_COMMAND reported, ident");
    cmd(6'd3, 32'h0001_0000); chk(!got, "CMD3 in stby: illegal");
    cmd(6'd13, 32'h0001_0000, 48, 1); chk(!got, "bad CRC7: no response");
    cmd(6'd13, 32'h0001_0000);
    chk(got && ncr == 2 && r48_ok(6'd13) && r[39:8] == 32'h00C0_0700, "CMD13: COM_CRC_ERROR and ILLEGAL_COMMAND, stby");
    cmd(6'd13, 32'h0002_0000); chk(!got, "CMD13 to another RCA: no response");
    cmd(6'd7, 32'h0001_0000, 48, 0, 0);
    chk(got && ncr == 2 && r48_ok(6'd7) && r[39:8] == 32'h0000_0700, "CMD7: R1 from stby");
    sel_busy(); chk(bk == 2 && busy == 3, "CMD7: R1b busy, 3 clocks from 2 clocks after the end bit");
    cmd(6'd17, 32'd0, 48, 0, 0); rd_blk(); chk(rd_ok && rb == init_blk(0), "block 0 after reset");
    wb = 256'hDEADBEEF_01234567_89ABCDEF_FEDCBA98_76543210_A5A5A5A5_5A5A5A5A_00FF00FF;
    cmd(6'd24, 32'd2, 48, 0, 0); chk(got && ncr == 2 && r48_ok(6'd24) && r[39:8] == 32'h0000_0900, "CMD24: R1, tran state");
    wr_blk(); chk(tok == 4'b0010 && busy == 4 && tokk == 2, "block accepted: token 010 after 2 clocks, 4 clocks busy");
    cmd(6'd17, 32'd2, 48, 0, 0); rd_blk(); chk(rd_ok && rb == wb, "CMD17 reads the block back, NAC = 2, CRC16 good");
    cmd(6'd17, 32'd3, 48, 0, 0); rd_blk(); chk(rd_ok && rb == init_blk(3), "an untouched block");
    cmd(6'd24, 32'd3, 48, 0, 0); wr_blk(1); chk(tok == 4'b0101 && busy == 0, "bad CRC16: token 101, no busy");
    cmd(6'd17, 32'd3, 48, 0, 0); rd_blk(); chk(rb == init_blk(3), "and nothing written");
    cmd(6'd8, 32'h0); chk(!got, "CMD8: illegal");
    cmd(6'd13, 32'h0001_0000); chk(got && r[39:8] == 32'h0040_0900, "CMD13: ILLEGAL_COMMAND, tran");
    cmd(6'd7, 32'h0001_0000, 48, 0, 0); sel_busy(); chk(got && r[39:8] == 32'h0000_0900 && busy == 3, "CMD7 again in tran");
    rn = 0; repeat (2) idle1(); chk(cmd_s_oe === 1'b0 && dat0_s_oe === 1'b0, "RST_n: off the bus");
    repeat (2) idle1(); rn = 1; repeat (4) idle1();
    cmd(6'd13, 32'h0001_0000); chk(!got, "after RST_n: idle, CMD13 illegal");
    cmd(6'd0, 32'h0);
    cmd(6'd1, 32'h40FF_8080); chk(got && r[39:8] == 32'h40FF_8080, "after RST_n: busy again");
    cmd(6'd1, 32'h40FF_8080);
    cmd(6'd2, 32'h0, 136);
    cmd(6'd3, 32'h0006_0000); chk(got && r[39:8] == 32'h0040_0500, "flags cleared by RST_n, new ILLEGAL_COMMAND");
    cmd(6'd7, 32'h0006_0000, 48, 0, 0); sel_busy();
    cmd(6'd17, 32'd2, 48, 0, 0); rd_blk(); chk(rd_ok && rb == wb, "the block survives RST_n");
    cmd(6'd7, 32'h0007_0000); chk(!got, "CMD7 to another RCA: deselected, no response");
    cmd(6'd13, 32'h0006_0000); chk(got && r[39:8] == 32'h0000_0700, "CMD13: stby");
    cmd(6'd17, 32'd2); chk(!got, "CMD17 in stby: illegal");
    cmd(6'd0, 32'h0);
    cmd(6'd2, 32'h0, 136); chk(!got, "CMD0 resets: CMD2 illegal in idle");
    chk(conflict == 0, "no bus contention");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
