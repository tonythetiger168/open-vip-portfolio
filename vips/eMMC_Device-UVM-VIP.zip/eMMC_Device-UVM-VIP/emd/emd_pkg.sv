// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// emd_pkg.sv -- EMD UVM VIP package

package emd_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import emd_defs_pkg::*;
  export emd_defs_pkg::*;

  `include "emd_transaction.svh"
  `include "emd_config.svh"
  `include "emd_sequencer.svh"
  `include "emd_driver.svh"
  `include "emd_monitor.svh"
  `include "emd_agent.svh"
  `include "emd_sequences.svh"
  `include "emd_checker.svh"
  `include "emd_coverage.svh"
endpackage
