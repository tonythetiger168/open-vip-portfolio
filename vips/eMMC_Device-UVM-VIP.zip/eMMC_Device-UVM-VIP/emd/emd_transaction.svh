// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// emd_transaction.svh -- EMD transaction

class emd_transaction extends uvm_sequence_item;
  `uvm_object_utils(emd_transaction)

  // request (driven by the agent)
  bit [4:0] mo[$];
  // response (returned by the DUT)
  bit [3:0] so[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [3:0] blk;
  rand bit [31:0] seed;
  bit [5:0] idx;
  bit [31:0] arg;
  bit got;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "emd_transaction"); super.new(name); endfunction

  // kind: 0 CMD0, 1 CMD1, 2 CMD2, 3 CMD3 (RCA 1 + blk), 4 CMD7 (RCA), 5 CMD7
  // (other RCA), 6 CMD7 (RCA 0), 7 CMD13, 8 CMD13 (other RCA), 9 CMD24, 10
  // CMD24 with a bad CRC16, 11 CMD17, 12 CMD13 with a bad CRC7, 13 CMD8 (not
  // modelled: illegal), 14 RST_n pulse (idx 63, no command), 15 CMD3 with RCA
  // 0, 16-31 CMD24 / CMD17 / CMD13 / CMD1 mix
  function void set(int k, int b = 0, bit [31:0] s = 32'h1); kind = k; blk = b; seed = s; endfunction
  function int kk();
    if (kind >= 16) return (kind % 4 == 0) ? 9 : (kind % 4 == 1) ? 11 : (kind % 4 == 2) ? 7 : 1;
    return kind;
  endfunction
  function bit [47:0] cmd(bit [15:0] rca);
    case (kk())
      0: begin idx = 0; arg = 0; end
      1: begin idx = 1; arg = 32'h40FF_8080; end
      2: begin idx = 2; arg = 0; end
      3: begin idx = 3; arg = {16'h1 + 16'(blk), 16'h0}; end
      4: begin idx = 7; arg = {rca, 16'h0}; end
      5: begin idx = 7; arg = {rca ^ 16'h0101, 16'h0}; end
      6: begin idx = 7; arg = 0; end
      7, 12: begin idx = 13; arg = {rca, 16'h0}; end
      8: begin idx = 13; arg = {rca ^ 16'h8000, 16'h0}; end
      9, 10: begin idx = 24; arg = {28'h0, blk}; end
      11: begin idx = 17; arg = {28'h0, blk}; end
      13: begin idx = 8; arg = 0; end
      14: begin idx = 63; arg = 0; end
      default: begin idx = 3; arg = 0; end
    endcase
    if (kk() == 12) return emd_frame(idx, arg) ^ 48'h4;
    return emd_frame(idx, arg);
  endfunction
  function bit [255:0] wdata();
    bit [31:0] x = seed | 1;
    bit [255:0] v;
    for (int i = 0; i < 8; i++) begin x ^= x << 13; x ^= x >> 17; x ^= x << 5; v[32 * i +: 32] = x; end
    return v;
  endfunction
  function bit bad_crc(); return kk() == 10; endfunction

  function void do_copy(uvm_object rhs);
    emd_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mo = rhs_.mo;
    so = rhs_.so;
    kind = rhs_.kind;
    blk = rhs_.blk;
    seed = rhs_.seed;
    idx = rhs_.idx;
    arg = rhs_.arg;
    got = rhs_.got;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    emd_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(emd_transaction rhs_);
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    return 1;
  endfunction

  function string qstr_mo();
    string s = $sformatf("[%0d]{", mo.size());
    foreach (mo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", mo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("EMD{tag=%0d mo=%s so=%s}", tag, qstr_mo(), qstr_so());
  endfunction
endclass
