// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// emd_sequences.svh -- EMD sequences

// Random traffic: cfg.num_items constrained-random items.
class emd_base_sequence extends uvm_sequence #(emd_transaction);
  `uvm_object_utils(emd_base_sequence)
  emd_config cfg;

  function new(string name = "emd_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = emd_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "emd_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class emd_directed_sequence extends uvm_sequence #(emd_transaction);
  `uvm_object_utils(emd_directed_sequence)
  emd_config cfg;

  function new(string name = "emd_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function emd_transaction item();
    item = emd_transaction::type_id::create("req");
  endfunction

  task send(emd_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    emd_transaction t;
    // identification, transfers, every error path, CMD0 and RST_n in transfer state
    t = item(); t.set(7); send(t);             // illegal in idle
    t = item(); t.set(0); send(t);
    t = item(); t.set(1); send(t);             // busy
    t = item(); t.set(2); send(t);             // illegal in idle
    t = item(); t.set(1); send(t);             // ready
    t = item(); t.set(1); send(t);             // illegal in ready
    t = item(); t.set(2); send(t);
    t = item(); t.set(15); send(t);            // RCA 0: illegal
    t = item(); t.set(3); send(t);             // reports ILLEGAL_COMMAND
    t = item(); t.set(12); send(t);            // bad CRC7
    t = item(); t.set(7); send(t);             // reports COM_CRC_ERROR
    t = item(); t.set(8); send(t);
    t = item(); t.set(4); send(t);
    for (int b = 0; b < 4; b++) begin
      t = item(); t.set(11, b); send(t);
      t = item(); t.set(9, b, 32'h1000 + b); send(t);
      t = item(); t.set(11, b); send(t);
    end
    t = item(); t.set(10, 5, 32'h77); send(t);
    t = item(); t.set(11, 5); send(t);
    t = item(); t.set(13); send(t);
    t = item(); t.set(7); send(t);
    t = item(); t.set(4); send(t);             // CMD7 again in tran
    t = item(); t.set(14); send(t);            // RST_n in tran
    t = item(); t.set(7); send(t);             // idle again
    t = item(); t.set(0); send(t);
    t = item(); t.set(1); send(t);
    t = item(); t.set(1); send(t);
    t = item(); t.set(2); send(t);
    t = item(); t.set(3, 6); send(t);
    t = item(); t.set(4); send(t);
    t = item(); t.set(11, 2); send(t);         // the block survives RST_n
    t = item(); t.set(5); send(t);             // deselect
    t = item(); t.set(7); send(t);
    t = item(); t.set(9, 1); send(t);          // illegal in stby
    t = item(); t.set(6); send(t);
    t = item(); t.set(4); send(t);
    t = item(); t.set(9, 9, 32'h55); send(t);
    t = item(); t.set(11, 9); send(t);
    t = item(); t.set(0); send(t);             // CMD0 from transfer state
    t = item(); t.set(11, 1); send(t);
  endtask
endclass
