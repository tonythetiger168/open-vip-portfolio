// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// emd_if.sv -- EMD interface

interface emd_if (input logic clk);
  logic rst_n;

  logic emmc_clk;
  logic emmc_rst_n;
  logic cmd_m;
  logic cmd_m_oe;
  logic dat0_m;
  logic dat0_m_oe;
  logic cmd_s;
  logic cmd_s_oe;
  logic dat0_s;
  logic dat0_s_oe;

  modport DUT (input clk, rst_n, input emmc_clk, input emmc_rst_n, input cmd_m, input cmd_m_oe, input dat0_m, input dat0_m_oe, output cmd_s, output cmd_s_oe, output dat0_s, output dat0_s_oe);
  modport MON (input clk, rst_n, emmc_clk, emmc_rst_n, cmd_m, cmd_m_oe, dat0_m, dat0_m_oe, cmd_s, cmd_s_oe, dat0_s, dat0_s_oe);

  clocking drv_cb @(posedge clk);
    input rst_n, cmd_s, cmd_s_oe, dat0_s, dat0_s_oe;
    inout emmc_clk, emmc_rst_n, cmd_m, cmd_m_oe, dat0_m, dat0_m_oe;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, emmc_clk, emmc_rst_n, cmd_m, cmd_m_oe, dat0_m, dat0_m_oe, cmd_s, cmd_s_oe, dat0_s, dat0_s_oe;
  endclocking
endinterface
