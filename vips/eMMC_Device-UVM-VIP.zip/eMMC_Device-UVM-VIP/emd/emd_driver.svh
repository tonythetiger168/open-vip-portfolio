// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// emd_driver.svh -- EMD driver: one command per item with emmc_clk running: 4 idle clocks, the 48-bit command, a response hunt of up to 64 clocks and the response; for CMD7 the R1b busy wait; for CMD24 the block (start, 256 bits, CRC16, end), the CRC status token and the busy wait; for CMD17 the block hunt and the block; an RST_n pulse item holds emmc_rst_n low 4 clocks; then 8 idle clocks and emmc_clk stopped for cfg.gap clocks

class emd_driver extends uvm_driver #(emd_transaction);
  `uvm_component_utils(emd_driver)

  uvm_analysis_port #(emd_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual emd_if vif;
  emd_config cfg;

  bit [15:0]      rca = 0;
  bit             rn = 1;
  emd_transaction cur;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual emd_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "emd: virtual interface not set")
    if (!uvm_config_db#(emd_config)::get(this, "", "cfg", cfg))
      cfg = emd_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    emd_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.emmc_clk   <= 1'b1;
    vif.drv_cb.emmc_rst_n <= 1'b1;
    vif.drv_cb.cmd_m      <= 1'b0;
    vif.drv_cb.cmd_m_oe   <= 1'b0;
    vif.drv_cb.dat0_m     <= 1'b0;
    vif.drv_cb.dat0_m_oe  <= 1'b0;
  endtask

  task drive_item(emd_transaction t);
    bit cl, dl;
    bit [47:0] f;
    bit [135:0] r = 0;
    int k;
    cur = t;
    t.mo.delete();
    f = t.cmd(rca);
    t.got = 0;
    @(vif.drv_cb);
    repeat (4) idle1(cl, dl);
    if (t.idx == 63) begin
      rn = 0; repeat (4) idle1(cl, dl);
      rn = 1; rca = 0;
    end else begin
      for (int i = 47; i >= 0; i--) clk1(1'b1, f[i], 1'b0, 1'b0, cl, dl);
      k = 0;
      while (k < 64 && !t.got) begin idle1(cl, dl); if (!cl) t.got = 1; k++; end
      if (t.got) begin
        int len = (t.idx == 2) ? 136 : 48;
        for (int i = 1; i < len; i++) begin idle1(cl, dl); r = {r[134:0], cl}; end
        if (t.idx == 3) rca = t.arg[31:16];
      end
      if (t.idx == 0) rca = 0;
      if (t.got && t.idx == 7) begin
        k = 0;
        do begin idle1(cl, dl); k++; end while (dl && k < 8);
        k = 0;
        while (!dl && k < 256) begin idle1(cl, dl); k++; end
      end
      if (t.got && t.idx == 24) begin
        bit [255:0] w = t.wdata();
        bit [15:0] c = 0;
        idle1(cl, dl); idle1(cl, dl);
        clk1(1'b0, 1'b0, 1'b1, 1'b1, cl, dl);
        clk1(1'b0, 1'b0, 1'b1, 1'b0, cl, dl);
        for (int n = 255; n >= 0; n--) begin c = emd_crc16(c, w[n]); clk1(1'b0, 1'b0, 1'b1, w[n], cl, dl); end
        if (t.bad_crc()) c[t.seed[3:0]] ^= 1'b1;
        for (int n = 15; n >= 0; n--) clk1(1'b0, 1'b0, 1'b1, c[n], cl, dl);
        clk1(1'b0, 1'b0, 1'b1, 1'b1, cl, dl);
        k = 0;
        do begin idle1(cl, dl); k++; end while (dl && k < 64);
        if (!dl) begin
          repeat (4) idle1(cl, dl);
          k = 0;
          do begin idle1(cl, dl); k++; end while (!dl && k < 256);
        end
      end
      if (t.got && t.idx == 17) begin
        k = 0;
        do begin idle1(cl, dl); k++; end while (dl && k < 64);
        if (!dl) repeat (256 + 16 + 1) idle1(cl, dl);
      end
    end
    repeat (8) idle1(cl, dl);
    repeat (cfg.gap) @(vif.drv_cb);
  endtask

  // one emmc_clk period: outputs at the falling edge, the lines at the rising edge
  task automatic clk1(bit co, bit c, bit doe, bit d, output bit cl, output bit dl);
    vif.drv_cb.emmc_clk   <= 1'b0;
    vif.drv_cb.emmc_rst_n <= rn;
    vif.drv_cb.cmd_m_oe   <= co; vif.drv_cb.cmd_m  <= c;
    vif.drv_cb.dat0_m_oe  <= doe; vif.drv_cb.dat0_m <= d;
    repeat (cfg.half) @(vif.drv_cb);
    vif.drv_cb.emmc_clk <= 1'b1;
    cl = co ? c : (vif.drv_cb.cmd_s_oe ? vif.drv_cb.cmd_s : 1'b1);
    dl = doe ? d : (vif.drv_cb.dat0_s_oe ? vif.drv_cb.dat0_s : 1'b1);
    cur.mo.push_back({rn, co, c & co, doe, d & doe});
    repeat (cfg.half) @(vif.drv_cb);
  endtask
  task automatic idle1(output bit cl, output bit dl);
    clk1(1'b0, 1'b0, 1'b0, 1'b0, cl, dl);
  endtask
endclass
