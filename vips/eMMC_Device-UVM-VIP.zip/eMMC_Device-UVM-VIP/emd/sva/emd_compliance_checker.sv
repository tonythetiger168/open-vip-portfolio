// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// emd_compliance_checker.sv -- EMD concurrent assertion checks (bindable)

module emd_compliance_checker
  (input logic clk, input logic rst_n, input logic emmc_clk, input logic emmc_rst_n, input logic cmd_m, input logic cmd_m_oe, input logic dat0_m, input logic dat0_m_oe, input logic cmd_s, input logic cmd_s_oe, input logic dat0_s, input logic dat0_s_oe);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({emmc_clk, emmc_rst_n, cmd_m_oe, dat0_m_oe, cmd_s_oe, dat0_s_oe}))
    else $error("EMD: X on emmc_clk, RST_n or an enable");
  assert property (@(posedge clk) disable iff (!rst_n) !(cmd_m_oe && cmd_s_oe))
    else $error("EMD: host and device drive CMD together");
  assert property (@(posedge clk) disable iff (!rst_n) !(dat0_m_oe && dat0_s_oe))
    else $error("EMD: host and device drive DAT0 together");
  assert property (@(posedge clk) disable iff (!rst_n) !emmc_rst_n |-> !cmd_s_oe && !dat0_s_oe)
    else $error("EMD: device drives the bus in RST_n");
  assert property (@(posedge clk) disable iff (!rst_n) $changed({cmd_s_oe, cmd_s, dat0_s_oe, dat0_s}) |-> !emmc_clk || !emmc_rst_n)
    else $error("EMD: device output changed while emmc_clk is high");
  cover property (@(posedge clk) disable iff (!rst_n) dat0_s_oe && !dat0_s);
endmodule
