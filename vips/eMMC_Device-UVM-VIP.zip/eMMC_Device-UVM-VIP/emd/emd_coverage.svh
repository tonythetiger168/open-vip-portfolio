// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// emd_coverage.svh -- EMD functional coverage

class emd_coverage extends uvm_subscriber #(emd_transaction);
  `uvm_component_utils(emd_coverage)
  emd_config cfg;
  emd_transaction tr;

  covergroup emd_cg;
    cp_idx  : coverpoint tr.idx { bins c0 = {0}; bins c1 = {1}; bins c2 = {2}; bins c3 = {3}; bins c7 = {7}; bins c13 = {13};
                                  bins c17 = {17}; bins c24 = {24}; bins c8 = {8}; bins rst = {63}; }
    cp_got  : coverpoint tr.got;
    cp_len  : coverpoint tr.mo.size() { bins rst = {[1:40]}; bins cmd = {[100:200]}; bins r2 = {[201:260]}; bins blk = {[261:700]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    emd_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(emd_config)::get(this, "", "cfg", cfg))
      cfg = emd_config::type_id::create("cfg");
  endfunction

  function void write(emd_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    emd_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("EMD coverage: %0.1f%%", emd_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
