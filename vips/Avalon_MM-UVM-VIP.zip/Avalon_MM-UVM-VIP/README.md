# Avalon-MM UVM VIP (Avalon_MM-UVM-VIP)

Avalon-MM slave UVM VIP with waitrequest/readdatavalid register model. Complements the Avalon-MM RTL IP from the open-ip-portfolio sister project.

## Structure

- `avalon_mm/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `avalon_mm_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `avalon_mm_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural Avalon-MM DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/Avalon_MM-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh Avalon_MM-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
