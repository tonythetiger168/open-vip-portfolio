// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_env.sv -- Avalon-MM environment: reference-model scoreboard, checker, coverage

package avalon_mm_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import avalon_mm_defs_pkg::*;
  import avalon_mm_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // ---- UVM RAL model: avalon_mm_model memory words 0..63 (byte address 0x000-0x0FC), reset 0
  class avalon_mm_data_reg extends uvm_reg;
    `uvm_object_utils(avalon_mm_data_reg)
    rand uvm_reg_field DATA;
    function new(string name = "avalon_mm_data_reg"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      DATA = uvm_reg_field::type_id::create("DATA");
      //            parent size lsb access volatile reset has_reset rand individually_accessible
      DATA.configure(this, 32,  0,  "RW",  0,       32'h0, 1,        1,   1);
    endfunction
  endclass

  class avalon_mm_reg_block extends uvm_reg_block;
    `uvm_object_utils(avalon_mm_reg_block)
    localparam int N_REGS = 64;
    rand avalon_mm_data_reg REG[N_REGS];
    uvm_reg_map       map;
    function new(string name = "avalon_mm_reg_block"); super.new(name, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      map = create_map("map", 'h0, 4, UVM_LITTLE_ENDIAN, 1);
      default_map = map;
      foreach (REG[i]) begin
        REG[i] = avalon_mm_data_reg::type_id::create($sformatf("REG%0d", i));
        REG[i].configure(this, null, "");
        REG[i].build();
        map.add_reg(REG[i], i * 4, "RW");
      end
    endfunction
  endclass

  // register access <-> Avalon-MM transaction (the driver fills the read data
  // into the request item, so no separate response is needed)
  class avalon_mm_reg_adapter extends uvm_reg_adapter;
    `uvm_object_utils(avalon_mm_reg_adapter)
    function new(string name = "avalon_mm_reg_adapter");
      super.new(name);
      supports_byte_enable = 0;
      provides_responses   = 0;
    endfunction
    virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
      avalon_mm_transaction t = avalon_mm_transaction::type_id::create("t");
      t.write      = (rw.kind == UVM_WRITE);
      t.address    = rw.addr[11:0];
      t.burstcount = 1;
      t.pbe        = t.write ? 32'hF : 32'h0;
      t.wdata      = t.write ? {224'h0, rw.data[31:0]} : 256'h0;
      return t;
    endfunction
    virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
      avalon_mm_transaction t;
      if (!$cast(t, bus_item)) begin
        `uvm_fatal("RAL", "bus2reg: not a avalon_mm_transaction")
        return;
      end
      rw.kind   = t.write ? UVM_WRITE : UVM_READ;
      rw.addr   = t.address;
      rw.data   = t.write ? t.wdata[31:0] : t.rdata[31:0];
      rw.status = (t.resp[1:0] == 2'b00) ? UVM_IS_OK : UVM_NOT_OK;
    endfunction
  endclass

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class avalon_mm_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(avalon_mm_scoreboard)
    uvm_analysis_imp_exp #(avalon_mm_transaction, avalon_mm_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(avalon_mm_transaction, avalon_mm_scoreboard) obs_ap;

    avalon_mm_config cfg;
    avalon_mm_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [31:0] mem [256];   // reset value 0
    function bit [1:0] code(bit [11:0] a);
      return a[11] ? 2'b11 : a[10] ? 2'b10 : 2'b00;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(avalon_mm_config)::get(this, "", "cfg", cfg))
        cfg = avalon_mm_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(avalon_mm_transaction t);
      begin
        int unsigned n = (t.burstcount == 0) ? 1 : t.burstcount;
        bit [1:0] w = 2'b00;
        t.rdata = 0;
        if (t.write) t.resp = 0;
        for (int unsigned i = 0; i < n; i++) begin
          bit [11:0] a = t.address + 12'(4 * i);
          if (t.write) begin
            if (code(a) != 2'b00) begin if (w == 2'b00) w = code(a); end
            else for (int b = 0; b < 4; b++) if (t.pbe[4 * i + b]) mem[a[9:2]][8 * b +: 8] = t.wdata[32 * i + 8 * b +: 8];
          end else begin
            t.resp[2 * i +: 2] = code(a);
            t.rdata[32 * i +: 32] = (code(a) == 2'b00) ? mem[a[9:2]] : 32'h0;
          end
        end
        if (t.write) t.resp = {14'h0, w};
        else for (int unsigned i = n; i < 8; i++) t.resp[2 * i +: 2] = 2'b00;
      end
    endfunction

    function void write_exp(avalon_mm_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(avalon_mm_transaction t);
      avalon_mm_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        avalon_mm_transaction e = exp_q.pop_front();
        avalon_mm_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("avalon_mm scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class avalon_mm_env extends uvm_env;
    `uvm_component_utils(avalon_mm_env)
    avalon_mm_agent      agt;
    avalon_mm_scoreboard sb;
    avalon_mm_checker    chk;
    avalon_mm_coverage   cov;

    // UVM RAL: register model of the DUT model, frontdoor through the agent,
    // mirror kept by an explicit predictor fed by the monitor
    avalon_mm_reg_block                         regmodel;
    avalon_mm_reg_adapter                       reg_adapter;
    uvm_reg_predictor #(avalon_mm_transaction)  reg_predictor;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = avalon_mm_agent     ::type_id::create("agt", this);
      sb  = avalon_mm_scoreboard::type_id::create("sb",  this);
      chk = avalon_mm_checker   ::type_id::create("chk", this);
      cov = avalon_mm_coverage  ::type_id::create("cov", this);
      regmodel = avalon_mm_reg_block::type_id::create("regmodel");
      regmodel.configure(null, "");
      regmodel.build();
      regmodel.lock_model();
      reg_adapter   = avalon_mm_reg_adapter::type_id::create("reg_adapter");
      reg_predictor = uvm_reg_predictor#(avalon_mm_transaction)::type_id::create("reg_predictor", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
      regmodel.default_map.set_sequencer(agt.sqr, reg_adapter);
      regmodel.default_map.set_auto_predict(0);
      reg_predictor.map     = regmodel.default_map;
      reg_predictor.adapter = reg_adapter;
      agt.mon.ap.connect(reg_predictor.bus_in);
    endfunction
  endclass
endpackage
