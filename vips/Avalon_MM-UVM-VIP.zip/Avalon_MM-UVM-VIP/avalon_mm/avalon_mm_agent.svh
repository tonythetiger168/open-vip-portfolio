// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_agent.svh -- Avalon-MM agent

class avalon_mm_agent extends uvm_agent;
  `uvm_component_utils(avalon_mm_agent)

  avalon_mm_sequencer sqr;
  avalon_mm_driver    drv;
  avalon_mm_monitor   mon;
  avalon_mm_config    cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    cfg = avalon_mm_config::type_id::create("cfg", this);
    uvm_config_db#(avalon_mm_config)::set(this, "*", "cfg", cfg);
    sqr = avalon_mm_sequencer::type_id::create("sqr", this);
    drv = avalon_mm_driver   ::type_id::create("drv", this);
    mon = avalon_mm_monitor  ::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
