// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_compliance_checker.sv -- Avalon-MM concurrent assertion checks (bindable)

module avalon_mm_compliance_checker
  (input logic clk, input logic rst_n, input logic [11:0] av_address, input logic [3:0] av_burstcount, input logic [3:0] av_byteenable, input logic av_read, input logic av_write, input logic [31:0] av_writedata, input logic av_waitrequest, input logic [31:0] av_readdata, input logic av_readdatavalid, input logic [1:0] av_response, input logic av_writeresponsevalid);

  logic in_wr;            // a write burst has started and not finished
  logic [3:0] wleft;
  always @(posedge clk or negedge rst_n)
    if (!rst_n) begin in_wr <= 1'b0; wleft <= 4'd0; end
    else if (av_write && !av_waitrequest) begin
      if (!in_wr) begin in_wr <= (av_burstcount > 4'd1); wleft <= av_burstcount - 4'd2; end
      else if (wleft == 4'd0) in_wr <= 1'b0;
      else wleft <= wleft - 4'd1;
    end
  // no X on the agent's outputs out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({av_waitrequest, av_readdatavalid, av_writeresponsevalid}))
    else $error("Avalon-MM: X on waitrequest / readdatavalid / writeresponsevalid");
  assert property (@(posedge clk) disable iff (!rst_n) av_readdatavalid |-> !$isunknown({av_readdata, av_response}))
    else $error("Avalon-MM: X on readdata / response with readdatavalid");
  // host rules
  assert property (@(posedge clk) disable iff (!rst_n) !(av_read && av_write))
    else $error("Avalon-MM: read and write in the same clock");
  assert property (@(posedge clk) disable iff (!rst_n) (av_read || av_write) |-> av_burstcount inside {[1:8]})
    else $error("Avalon-MM: burstcount outside 1..maxBurstSize");
  assert property (@(posedge clk) disable iff (!rst_n) (av_read || av_write) && av_waitrequest |=>
                   $stable({av_read, av_write, av_address, av_burstcount, av_byteenable, av_writedata}))
    else $error("Avalon-MM: command changed while waitrequest was high");
  assert property (@(posedge clk) disable iff (!rst_n) in_wr |-> !av_read)
    else $error("Avalon-MM: read during a write burst");
  // agent rules
  assert property (@(posedge clk) disable iff (!rst_n) !(av_readdatavalid && av_writeresponsevalid))
    else $error("Avalon-MM: readdatavalid and writeresponsevalid together");
  assert property (@(posedge clk) disable iff (!rst_n) (av_readdatavalid || av_writeresponsevalid) |-> av_response != 2'b01)
    else $error("Avalon-MM: reserved response 2'b01");
  cover property (@(posedge clk) disable iff (!rst_n) av_read && av_waitrequest ##1 av_read && !av_waitrequest);
  cover property (@(posedge clk) disable iff (!rst_n) av_writeresponsevalid && av_response == 2'b10);
  cover property (@(posedge clk) disable iff (!rst_n) av_read && !av_waitrequest && av_burstcount == 4'd8);
endmodule
