// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_compliance_checker.sv -- Avalon-MM concurrent assertion checks (bindable)

module avalon_mm_compliance_checker
  (input logic clk, input logic rst_n, input [7:0] av_address, input [31:0] av_writedata, input av_write, input av_read, input av_waitrequest, input [31:0] av_readdata, input av_readdatavalid, input [1:0] av_response);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({av_waitrequest, av_readdata, av_readdatavalid, av_response}))
    else $error("Avalon-MM: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> av_waitrequest == '0)
    else $error("Avalon-MM: output not in reset value");
  // response is always OKAY
  assert property (@(posedge clk) disable iff (!rst_n) av_response == 2'b00)
    else $error("AVMM: non-OKAY response");
  // readdatavalid only after a read
  assert property (@(posedge clk) disable iff (!rst_n) $rose(av_readdatavalid) |-> $past(av_read, 2))
    else $error("AVMM: unexpected readdatavalid");
  cover property (@(posedge clk) disable iff (!rst_n) (av_waitrequest != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (av_waitrequest == 1'b1));
endmodule
