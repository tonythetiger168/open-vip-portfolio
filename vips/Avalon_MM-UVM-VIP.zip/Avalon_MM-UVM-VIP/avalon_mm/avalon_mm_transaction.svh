// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_transaction.svh -- Avalon-MM transaction

class avalon_mm_transaction extends uvm_sequence_item;
  `uvm_object_utils(avalon_mm_transaction)

  // request (driven by the agent)
  rand bit write;
  rand bit [7:0] address;
  rand bit [31:0] writedata;
  // response (returned by the DUT)
  bit [31:0] readdata;
  bit [1:0] response;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_addr { address[1:0] == 2'b00; }
  constraint c_data { !write -> writedata == 0; }

  function new(string name = "avalon_mm_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    avalon_mm_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    write = rhs_.write;
    address = rhs_.address;
    writedata = rhs_.writedata;
    readdata = rhs_.readdata;
    response = rhs_.response;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    avalon_mm_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (write != rhs_.write) return 0;
    if (address != rhs_.address) return 0;
    if (writedata != rhs_.writedata) return 0;
    if (readdata != rhs_.readdata) return 0;
    if (response != rhs_.response) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(avalon_mm_transaction rhs_);
    if (write != rhs_.write) return 0;
    if (address != rhs_.address) return 0;
    if (writedata != rhs_.writedata) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("Avalon-MM{tag=%0d write=0x%0h address=0x%0h writedata=0x%0h readdata=0x%0h response=0x%0h}", tag, write, address, writedata, readdata, response);
  endfunction
endclass
