// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_transaction.svh -- Avalon-MM transaction

class avalon_mm_transaction extends uvm_sequence_item;
  `uvm_object_utils(avalon_mm_transaction)

  rand bit [7:0] av_address;
  rand bit [31:0] av_writedata;
  rand bit av_write;
  rand bit av_read;
  bit av_waitrequest_o;
  bit [31:0] av_readdata_o;
  bit av_readdatavalid_o;
  bit [1:0] av_response_o;
  bit [31:0] tag;

  function new(string name = "avalon_mm_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    avalon_mm_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    av_address = rhs_.av_address;
    av_writedata = rhs_.av_writedata;
    av_write = rhs_.av_write;
    av_read = rhs_.av_read;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    avalon_mm_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           av_address == rhs_.av_address &&
           av_writedata == rhs_.av_writedata &&
           av_write == rhs_.av_write &&
           av_read == rhs_.av_read;
  endfunction

  function string convert2string();
    return $sformatf("Avalon-MM{tag=%0h av_address=0x%0h av_writedata=0x%0h av_write=0x%0h av_read=0x%0h}", tag, av_address, av_writedata, av_write, av_read);
  endfunction
endclass
