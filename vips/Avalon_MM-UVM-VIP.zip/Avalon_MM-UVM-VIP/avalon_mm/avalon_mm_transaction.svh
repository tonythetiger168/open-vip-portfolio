// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_transaction.svh -- Avalon-MM transaction

class avalon_mm_transaction extends uvm_sequence_item;
  `uvm_object_utils(avalon_mm_transaction)

  // request (driven by the agent)
  rand bit write;
  rand bit [11:0] address;
  rand bit [3:0] burstcount;
  rand bit [31:0] pbe;
  rand bit [255:0] wdata;
  // response (returned by the DUT)
  bit [255:0] rdata;
  bit [15:0] resp;
  // bookkeeping (not compared)
  rand bit [2:0] gap;
  rand bit [7:0] bgap;
  rand bit [1:0] region;
  int unsigned wait_cyc;
  int unsigned npend;
  rand bit pipe;
  bit done;
  int unsigned tag;   // sequence number (driver/monitor order)


  // region 0: memory, 1: SLVERR, 2: DECODEERROR, 3: a burst that runs from memory into the SLVERR region
  constraint c_addr { address[1:0] == 2'b00;
                      region dist { 0 := 6, 1 := 1, 2 := 1, 3 := 2 };
                      region == 0 -> address[11:10] == 2'b00;
                      region == 1 -> address[11:10] == 2'b01;
                      region == 2 -> address[11] == 1'b1;
                      region == 3 -> address[11:5] == 7'h1F && address[4:2] >= 3'd5; }
  constraint c_bc   { burstcount inside {[1:8]};
                      region == 3 -> burstcount >= 4; }
  constraint c_wd   { !write -> wdata == 0 && pbe == 0 && bgap == 0; }
  constraint c_gap  { gap dist { 0 := 6, [1:7] :/ 2 }; }
  constraint c_pipe { pipe dist { 1 := 4, 0 := 1 }; }

  function new(string name = "avalon_mm_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    avalon_mm_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    write = rhs_.write;
    address = rhs_.address;
    burstcount = rhs_.burstcount;
    pbe = rhs_.pbe;
    wdata = rhs_.wdata;
    rdata = rhs_.rdata;
    resp = rhs_.resp;
    gap = rhs_.gap;
    bgap = rhs_.bgap;
    region = rhs_.region;
    wait_cyc = rhs_.wait_cyc;
    npend = rhs_.npend;
    pipe = rhs_.pipe;
    done = rhs_.done;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    avalon_mm_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (write != rhs_.write) return 0;
    if (address != rhs_.address) return 0;
    if (burstcount != rhs_.burstcount) return 0;
    if (pbe != rhs_.pbe) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (rdata != rhs_.rdata) return 0;
    if (resp != rhs_.resp) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(avalon_mm_transaction rhs_);
    if (write != rhs_.write) return 0;
    if (address != rhs_.address) return 0;
    if (burstcount != rhs_.burstcount) return 0;
    if (pbe != rhs_.pbe) return 0;
    if (wdata != rhs_.wdata) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("Avalon-MM{tag=%0d write=0x%0h address=0x%0h burstcount=0x%0h pbe=0x%0h wdata=0x%0h rdata=0x%0h resp=0x%0h}", tag, write, address, burstcount, pbe, wdata, rdata, resp);
  endfunction
endclass
