// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_if.sv -- Avalon-MM interface

interface avalon_mm_if (input logic clk);
  logic rst_n;

  logic [11:0] av_address;
  logic [3:0] av_burstcount;
  logic [3:0] av_byteenable;
  logic av_read;
  logic av_write;
  logic [31:0] av_writedata;
  logic av_waitrequest;
  logic [31:0] av_readdata;
  logic av_readdatavalid;
  logic [1:0] av_response;
  logic av_writeresponsevalid;

  modport DUT (input clk, rst_n, input av_address, input av_burstcount, input av_byteenable, input av_read, input av_write, input av_writedata, output av_waitrequest, output av_readdata, output av_readdatavalid, output av_response, output av_writeresponsevalid);
  modport MON (input clk, rst_n, av_address, av_burstcount, av_byteenable, av_read, av_write, av_writedata, av_waitrequest, av_readdata, av_readdatavalid, av_response, av_writeresponsevalid);

  clocking drv_cb @(posedge clk);
    input rst_n, av_waitrequest, av_readdata, av_readdatavalid, av_response, av_writeresponsevalid;
    inout av_address, av_burstcount, av_byteenable, av_read, av_write, av_writedata;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, av_address, av_burstcount, av_byteenable, av_read, av_write, av_writedata, av_waitrequest, av_readdata, av_readdatavalid, av_response, av_writeresponsevalid;
  endclocking
endinterface
