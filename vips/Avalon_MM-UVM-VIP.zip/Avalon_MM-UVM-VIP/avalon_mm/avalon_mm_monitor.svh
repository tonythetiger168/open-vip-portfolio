// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_monitor.svh -- Avalon-MM monitor: commands taken on read/write without waitrequest (write bursts beat by beat), completed in command order by readdatavalid beats or writeresponsevalid

class avalon_mm_monitor extends uvm_monitor;
  `uvm_component_utils(avalon_mm_monitor)

  virtual avalon_mm_if vif;
  uvm_analysis_port #(avalon_mm_transaction) ap;
  avalon_mm_config cfg;
  int unsigned n_obs = 0;

  avalon_mm_transaction pend[$];   // accepted commands waiting for their response

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual avalon_mm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avalon_mm: virtual interface not set")
    if (!uvm_config_db#(avalon_mm_config)::get(this, "", "cfg", cfg))
      cfg = avalon_mm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      avalon_mm_transaction wr;          // write burst being collected
      int unsigned wbeat = 0, rbeat = 0, waits = 0;
      bit idle_in_burst = 0;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rst_n !== 1'b1) begin pend.delete(); wr = null; wbeat = 0; rbeat = 0; waits = 0; continue; end
        // responses first: a response never answers a command of the same clock
        if (vif.mon_cb.av_readdatavalid) begin
          if (pend.size() == 0 || pend[0].write) `uvm_error("MON", "Avalon-MM readdatavalid without a pending read")
          else begin
            pend[0].rdata[32 * rbeat +: 32] = vif.mon_cb.av_readdata;
            pend[0].resp[2 * rbeat +: 2] = vif.mon_cb.av_response;
            if (++rbeat == (pend[0].burstcount == 0 ? 1 : pend[0].burstcount)) begin publish(pend.pop_front()); rbeat = 0; end
          end
        end
        if (vif.mon_cb.av_writeresponsevalid) begin
          if (pend.size() == 0 || !pend[0].write) `uvm_error("MON", "Avalon-MM writeresponsevalid without a pending write")
          else begin pend[0].resp = {14'h0, vif.mon_cb.av_response}; publish(pend.pop_front()); end
        end
        if (wr != null && !vif.mon_cb.av_write) idle_in_burst = 1;
        if (vif.mon_cb.av_read || vif.mon_cb.av_write) begin
          if (vif.mon_cb.av_waitrequest) waits++;
          else if (vif.mon_cb.av_read) begin
            avalon_mm_transaction t = avalon_mm_transaction::type_id::create("t");
            t.write = 0; t.address = vif.mon_cb.av_address; t.burstcount = vif.mon_cb.av_burstcount;
            t.wait_cyc = waits; t.npend = pend.size(); waits = 0;
            pend.push_back(t);
          end else begin
            if (wr == null) begin
              wr = avalon_mm_transaction::type_id::create("t");
              wr.write = 1; wr.address = vif.mon_cb.av_address; wr.burstcount = vif.mon_cb.av_burstcount;
              wr.wait_cyc = waits; wr.npend = pend.size(); wbeat = 0;
            end
            waits = 0;
            wr.bgap[wbeat] = idle_in_burst; idle_in_burst = 0;
            wr.wdata[32 * wbeat +: 32] = vif.mon_cb.av_writedata;
            wr.pbe[4 * wbeat +: 4] = vif.mon_cb.av_byteenable;
            if (++wbeat == (wr.burstcount == 0 ? 1 : wr.burstcount)) begin pend.push_back(wr); wr = null; end
          end
        end
      end
    end
  endtask

  function void publish(avalon_mm_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
