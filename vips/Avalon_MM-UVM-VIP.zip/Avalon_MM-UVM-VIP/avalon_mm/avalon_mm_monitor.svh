// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_monitor.svh -- Avalon-MM monitor: transfer on each clock with read/write high and waitrequest low, reads completed by readdatavalid

class avalon_mm_monitor extends uvm_monitor;
  `uvm_component_utils(avalon_mm_monitor)

  virtual avalon_mm_if vif;
  uvm_analysis_port #(avalon_mm_transaction) ap;
  avalon_mm_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual avalon_mm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avalon_mm: virtual interface not set")
    if (!uvm_config_db#(avalon_mm_config)::get(this, "", "cfg", cfg))
      cfg = avalon_mm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      avalon_mm_transaction rd;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.av_readdatavalid) begin
          if (rd == null) `uvm_error("MON", "Avalon-MM readdatavalid without an outstanding read")
          else begin
            rd.readdata = vif.mon_cb.av_readdata;
            rd.response = vif.mon_cb.av_response;
            publish(rd);
            rd = null;
          end
        end
        if ((vif.mon_cb.av_write || vif.mon_cb.av_read) && !vif.mon_cb.av_waitrequest) begin
          avalon_mm_transaction t = avalon_mm_transaction::type_id::create("t");
          t.write     = vif.mon_cb.av_write;
          t.address   = vif.mon_cb.av_address;
          t.writedata = t.write ? vif.mon_cb.av_writedata : 32'h0;
          if (t.write) publish(t);
          else if (rd != null) `uvm_error("MON", "Avalon-MM read issued with a read outstanding")
          else rd = t;
        end
      end
    end
  endtask

  function void publish(avalon_mm_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
