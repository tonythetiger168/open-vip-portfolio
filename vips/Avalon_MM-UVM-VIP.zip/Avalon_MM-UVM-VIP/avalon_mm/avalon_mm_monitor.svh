// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_monitor.svh -- Avalon-MM monitor: decodes observed bus activity

class avalon_mm_monitor extends uvm_monitor;
  `uvm_component_utils(avalon_mm_monitor)

  virtual avalon_mm_if vif;
  uvm_analysis_port #(avalon_mm_transaction) ap;
  avalon_mm_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual avalon_mm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avalon_mm: virtual interface not set")
    void'(uvm_config_db#(avalon_mm_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    avalon_mm_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = avalon_mm_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.av_address = vif.av_address;
        t.av_writedata = vif.av_writedata;
        t.av_write = vif.av_write;
        t.av_read = vif.av_read;
        t.av_waitrequest_o = vif.av_waitrequest;
        t.av_readdata_o = vif.av_readdata;
        t.av_readdatavalid_o = vif.av_readdatavalid;
        t.av_response_o = vif.av_response;
        ap.write(t);
      end
    end
  endtask
endclass
