// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_sequences.svh -- Avalon-MM sequences

// Random traffic: cfg.num_items constrained-random items.
class avalon_mm_base_sequence extends uvm_sequence #(avalon_mm_transaction);
  `uvm_object_utils(avalon_mm_base_sequence)
  avalon_mm_config cfg;

  function new(string name = "avalon_mm_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = avalon_mm_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "avalon_mm_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class avalon_mm_directed_sequence extends uvm_sequence #(avalon_mm_transaction);
  `uvm_object_utils(avalon_mm_directed_sequence)
  avalon_mm_config cfg;

  function new(string name = "avalon_mm_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function avalon_mm_transaction item();
    item = avalon_mm_transaction::type_id::create("req");
  endfunction

  task send(avalon_mm_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    avalon_mm_transaction t;
    // single beats, then bursts of every length, read back
    for (int i = 0; i < 8; i++) begin
      t = item(); t.write = 1; t.address = 12'h40 * i; t.burstcount = i + 1; t.region = 0; t.gap = 0;
      for (int b = 0; b < 8; b++) t.wdata[32 * b +: 32] = 32'hA000_0000 | (i << 8) | b;
      t.pbe = '1; t.bgap = (i == 7) ? 8'b1010_1010 : 8'h0; send(t);
    end
    for (int i = 0; i < 8; i++) begin
      t = item(); t.write = 0; t.address = 12'h40 * i; t.burstcount = 8 - i; t.region = 0; t.gap = 0; send(t);
    end
    // byte enables beat by beat, and a write with none
    t = item(); t.write = 1; t.address = 12'h200; t.burstcount = 4; t.region = 0; t.pbe = 32'h0000_8421; t.wdata = '1; send(t);
    t = item(); t.write = 1; t.address = 12'h200; t.burstcount = 1; t.region = 0; t.pbe = 32'h0; t.wdata = 32'h1234; send(t);
    t = item(); t.write = 0; t.address = 12'h200; t.burstcount = 4; t.region = 0; send(t);
    // error regions, a burst running out of memory, the address wrap at 0xFFC
    t = item(); t.write = 1; t.address = 12'h3F0; t.burstcount = 8; t.region = 3; t.pbe = '1; t.wdata = '1; send(t);
    t = item(); t.write = 0; t.address = 12'h3F0; t.burstcount = 8; t.region = 3; send(t);
    t = item(); t.write = 0; t.address = 12'h7F8; t.burstcount = 4; t.region = 1; send(t);
    t = item(); t.write = 1; t.address = 12'h7FC; t.burstcount = 2; t.region = 1; t.pbe = '1; send(t);
    t = item(); t.write = 0; t.address = 12'hFF8; t.burstcount = 4; t.region = 2; send(t);
    t = item(); t.write = 1; t.address = 12'hFFC; t.burstcount = 2; t.region = 2; t.pbe = '1; t.wdata = '1; send(t);
    t = item(); t.write = 0; t.address = 12'h000; t.burstcount = 1; t.region = 0; send(t);
    // eight back-to-back reads fill the pending-response limit
    for (int i = 0; i < 8; i++) begin t = item(); t.pipe = 1; t.write = 0; t.address = 12'h20 * i; t.burstcount = 1 + i % 3; t.region = 0; t.gap = 0; send(t); end
  endtask
endclass
