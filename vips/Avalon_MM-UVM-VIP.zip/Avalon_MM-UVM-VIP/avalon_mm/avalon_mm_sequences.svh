// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_sequences.svh -- Avalon-MM sequences

class avalon_mm_base_sequence extends uvm_sequence #(avalon_mm_transaction);
  `uvm_object_utils(avalon_mm_base_sequence)
  avalon_mm_config cfg;
  function new(string name = "avalon_mm_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin
      `uvm_do_with(req, 1 == 1)
    end
  endtask
endclass
