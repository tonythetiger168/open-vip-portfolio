// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_sequences.svh -- Avalon-MM sequences

// Random traffic: cfg.num_items constrained-random items.
class avalon_mm_base_sequence extends uvm_sequence #(avalon_mm_transaction);
  `uvm_object_utils(avalon_mm_base_sequence)
  avalon_mm_config cfg;

  function new(string name = "avalon_mm_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = avalon_mm_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "avalon_mm_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class avalon_mm_directed_sequence extends uvm_sequence #(avalon_mm_transaction);
  `uvm_object_utils(avalon_mm_directed_sequence)
  avalon_mm_config cfg;

  function new(string name = "avalon_mm_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function avalon_mm_transaction item();
    item = avalon_mm_transaction::type_id::create("req");
  endfunction

  task send(avalon_mm_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    avalon_mm_transaction t;
    for (int i = 0; i < 64; i += 7) begin
      t = item(); t.write = 1; t.address = i * 4; t.writedata = 32'h5A00_0000 | i; send(t);
      t = item(); t.write = 0; t.address = i * 4; send(t);
    end
    t = item(); t.write = 0; t.address = 8'h04; send(t);              // never written: 0
    t = item(); t.write = 1; t.address = 8'hFC; t.writedata = '1; send(t);
    t = item(); t.write = 1; t.address = 8'hFC; t.writedata = 32'h1; send(t);
    t = item(); t.write = 0; t.address = 8'hFC; send(t);
  endtask
endclass
