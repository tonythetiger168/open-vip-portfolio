// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_pkg.sv -- Avalon-MM UVM VIP package

package avalon_mm_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import avalon_mm_defs_pkg::*;
  export avalon_mm_defs_pkg::*;

  `include "avalon_mm_transaction.svh"
  `include "avalon_mm_config.svh"
  `include "avalon_mm_sequencer.svh"
  `include "avalon_mm_driver.svh"
  `include "avalon_mm_monitor.svh"
  `include "avalon_mm_agent.svh"
  `include "avalon_mm_sequences.svh"
  `include "avalon_mm_checker.svh"
  `include "avalon_mm_coverage.svh"
endpackage
