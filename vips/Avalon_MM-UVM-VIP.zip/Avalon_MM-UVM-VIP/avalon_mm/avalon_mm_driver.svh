// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_driver.svh -- Avalon-MM driver: pipelined commands (an item with pipe = 0, e.g. from the register layer, waits for its response); write bursts beat by beat, with optional idle clocks

class avalon_mm_driver extends uvm_driver #(avalon_mm_transaction);
  `uvm_component_utils(avalon_mm_driver)

  uvm_analysis_port #(avalon_mm_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual avalon_mm_if vif;
  avalon_mm_config cfg;

  avalon_mm_transaction dq[$];   // accepted commands, in order, waiting for their response
  int unsigned dbeat = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual avalon_mm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avalon_mm: virtual interface not set")
    if (!uvm_config_db#(avalon_mm_config)::get(this, "", "cfg", cfg))
      cfg = avalon_mm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    avalon_mm_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      forever begin
        @(vif.drv_cb);
        if (vif.drv_cb.av_readdatavalid === 1'b1 && dq.size() != 0) begin
          dq[0].rdata[32 * dbeat +: 32] = vif.drv_cb.av_readdata;
          dq[0].resp[2 * dbeat +: 2] = vif.drv_cb.av_response;
          if (++dbeat >= dq[0].burstcount) begin dq[0].done = 1; void'(dq.pop_front()); dbeat = 0; end
        end
        if (vif.drv_cb.av_writeresponsevalid === 1'b1 && dq.size() != 0) begin
          dq[0].resp = {14'h0, vif.drv_cb.av_response}; dq[0].done = 1; void'(dq.pop_front());
        end
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.av_read <= 1'b0; vif.drv_cb.av_write <= 1'b0; vif.drv_cb.av_address <= '0;
    vif.drv_cb.av_burstcount <= 4'd1; vif.drv_cb.av_byteenable <= 4'hF; vif.drv_cb.av_writedata <= '0;
  endtask

  task drive_item(avalon_mm_transaction t);
    // beats past the burst carry nothing (the monitor sees only real beats)
    for (int i = 0; i < 8; i++)
      if (!t.write || i >= t.burstcount) begin t.wdata[32 * i +: 32] = 0; t.pbe[4 * i +: 4] = 0; t.bgap[i] = 0; end
    t.bgap[0] = 0;
    repeat (t.gap) @(vif.drv_cb);
    for (int i = 0; i < (t.write ? t.burstcount : 1); i++) begin
      if (t.bgap[i]) begin vif.drv_cb.av_write <= 1'b0; @(vif.drv_cb); end
      vif.drv_cb.av_read <= !t.write; vif.drv_cb.av_write <= t.write;
      vif.drv_cb.av_address <= t.address; vif.drv_cb.av_burstcount <= t.burstcount;
      vif.drv_cb.av_byteenable <= t.write ? t.pbe[4 * i +: 4] : 4'hF;
      vif.drv_cb.av_writedata <= t.wdata[32 * i +: 32];
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.av_waitrequest === 1'b0) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.av_waitrequest === 1'b0)) `uvm_error("TIMEOUT", $sformatf("Avalon-MM command accept: no response within %0d cycles", cfg.timeout_cycles))
      end
    end
    vif.drv_cb.av_read <= 1'b0; vif.drv_cb.av_write <= 1'b0;
    t.done = 0; t.rdata = 0; t.resp = 0;
    dq.push_back(t);
    if (!t.pipe) begin
      int unsigned to = 0;
      while (!t.done && to < cfg.timeout_cycles) begin @(vif.drv_cb); to++; end
      if (!t.done) `uvm_error("TIMEOUT", "Avalon-MM: no response")
    end
  endtask

endclass
