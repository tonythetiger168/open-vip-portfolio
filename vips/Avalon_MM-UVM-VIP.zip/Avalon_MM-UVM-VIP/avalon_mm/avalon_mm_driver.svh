// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_driver.svh -- Avalon-MM driver: single read / write, held until the clock where waitrequest is low

class avalon_mm_driver extends uvm_driver #(avalon_mm_transaction);
  `uvm_component_utils(avalon_mm_driver)

  uvm_analysis_port #(avalon_mm_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual avalon_mm_if vif;
  avalon_mm_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual avalon_mm_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avalon_mm: virtual interface not set")
    if (!uvm_config_db#(avalon_mm_config)::get(this, "", "cfg", cfg))
      cfg = avalon_mm_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    avalon_mm_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.av_write <= 1'b0; vif.drv_cb.av_read <= 1'b0;
    vif.drv_cb.av_address <= '0; vif.drv_cb.av_writedata <= '0;
  endtask

  task drive_item(avalon_mm_transaction t);
    @(vif.drv_cb);
    vif.drv_cb.av_address   <= t.address;
    vif.drv_cb.av_writedata <= t.writedata;
    vif.drv_cb.av_write     <= t.write;
    vif.drv_cb.av_read      <= !t.write;
    begin
      int unsigned to = 0;
      do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.av_waitrequest === 1'b0) && to < cfg.timeout_cycles);
      if (!(vif.drv_cb.av_waitrequest === 1'b0)) `uvm_error("TIMEOUT", $sformatf("Avalon-MM command accept: no response within %0d cycles", cfg.timeout_cycles))
    end
    vif.drv_cb.av_write <= 1'b0;
    vif.drv_cb.av_read  <= 1'b0;
    t.response = 2'b00;
    if (!t.write) begin
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.av_readdatavalid === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.av_readdatavalid === 1'b1)) `uvm_error("TIMEOUT", $sformatf("Avalon-MM readdatavalid: no response within %0d cycles", cfg.timeout_cycles))
      end
      t.readdata = vif.drv_cb.av_readdata;
      t.response = vif.drv_cb.av_response;
    end
  endtask

endclass
