// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_checker.svh -- Avalon-MM protocol checker on monitored items

class avalon_mm_checker extends uvm_component;
  `uvm_component_utils(avalon_mm_checker)
  uvm_analysis_imp #(avalon_mm_transaction, avalon_mm_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  avalon_mm_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(avalon_mm_config)::get(this, "", "cfg", cfg))
      cfg = avalon_mm_config::type_id::create("cfg");
  endfunction

  function void fail(avalon_mm_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("Avalon-MM: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(avalon_mm_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.address[1:0] != 2'b00) fail(t, "address not word aligned");
      if (t.burstcount == 0 || t.burstcount > cfg.max_beats) fail(t, $sformatf("burstcount %0d outside 1..%0d", t.burstcount, cfg.max_beats));
      if (t.npend > 3) fail(t, $sformatf("%0d responses pending when a command was taken, the agent allows 4 in all", t.npend));
      if (t.wait_cyc > 80) fail(t, $sformatf("command waited %0d clocks", t.wait_cyc));
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("Avalon-MM checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
