// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_coverage.svh -- Avalon-MM functional coverage

class avalon_mm_coverage extends uvm_subscriber #(avalon_mm_transaction);
  `uvm_component_utils(avalon_mm_coverage)
  avalon_mm_config cfg;
  avalon_mm_transaction tr;

  covergroup avalon_mm_cg;
    coverpoint tr.av_address;
    coverpoint tr.av_writedata;
    coverpoint tr.av_write;
    coverpoint tr.av_read;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(avalon_mm_config)::get(this, "*", "cfg", cfg));
    avalon_mm_cg = new();
  endfunction

  function void write(avalon_mm_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    avalon_mm_cg.sample();
  endfunction
endclass
