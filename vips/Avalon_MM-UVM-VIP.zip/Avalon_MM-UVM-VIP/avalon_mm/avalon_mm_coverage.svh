// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_coverage.svh -- Avalon-MM functional coverage

class avalon_mm_coverage extends uvm_subscriber #(avalon_mm_transaction);
  `uvm_component_utils(avalon_mm_coverage)
  avalon_mm_config cfg;
  avalon_mm_transaction tr;

  covergroup avalon_mm_cg;
    cp_write  : coverpoint tr.write;
    cp_bc     : coverpoint tr.burstcount { bins one = {1}; bins short_ = {[2:4]}; bins long_ = {[5:7]}; bins max = {8}; }
    cp_region : coverpoint tr.address[11:10] { bins mem = {0}; bins slverr = {1}; bins decerr = {[2:3]}; }
    cp_rresp  : coverpoint tr.resp[1:0] iff (!tr.write) { bins okay = {0}; bins slverr = {2}; bins decerr = {3}; }
    cp_wresp  : coverpoint tr.resp[1:0] iff (tr.write) { bins okay = {0}; bins slverr = {2}; bins decerr = {3}; }
    cp_cross  : coverpoint (tr.address[11:10] == 0 && tr.address[9:2] + tr.burstcount > 256) { bins straddle = {1}; }
    cp_be     : coverpoint tr.pbe[3:0] iff (tr.write) { bins full = {4'hF}; bins none = {4'h0}; bins part = {[4'h1:4'hE]}; }
    cp_bgap   : coverpoint (tr.bgap != 0) iff (tr.write && tr.burstcount > 1) { bins gaps = {1}; bins none = {0}; }
    cp_pend   : coverpoint tr.npend { bins none = {0}; bins one = {1}; bins two = {2}; bins three = {3}; }
    cp_wait   : coverpoint tr.wait_cyc { bins zero = {0}; bins one = {1}; bins more = {[2:$]}; }
    x_rw_bc   : cross cp_write, cp_bc;
    x_rw_reg  : cross cp_write, cp_region;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    avalon_mm_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(avalon_mm_config)::get(this, "", "cfg", cfg))
      cfg = avalon_mm_config::type_id::create("cfg");
  endfunction

  function void write(avalon_mm_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    avalon_mm_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("Avalon-MM coverage: %0.1f%%", avalon_mm_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
