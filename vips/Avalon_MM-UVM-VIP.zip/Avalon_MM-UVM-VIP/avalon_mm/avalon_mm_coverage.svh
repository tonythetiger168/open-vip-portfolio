// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_mm_coverage.svh -- Avalon-MM functional coverage

class avalon_mm_coverage extends uvm_subscriber #(avalon_mm_transaction);
  `uvm_component_utils(avalon_mm_coverage)
  avalon_mm_config cfg;
  avalon_mm_transaction tr;

  covergroup avalon_mm_cg;
    cp_write : coverpoint tr.write;
    cp_word  : coverpoint tr.address[7:2] { bins low = {[0:15]}; bins mid = {[16:47]}; bins high = {[48:63]}; }
    x_rw     : cross cp_write, cp_word;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    avalon_mm_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(avalon_mm_config)::get(this, "", "cfg", cfg))
      cfg = avalon_mm_config::type_id::create("cfg");
  endfunction

  function void write(avalon_mm_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    avalon_mm_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("Avalon-MM coverage: %0.1f%%", avalon_mm_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
