// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (Avalon-MM write/read with waitrequest)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened avalon_mm_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [7:0]  av_address = '0;
  logic [31:0] av_writedata = '0;
  logic av_write = 1'b0;
  logic av_read = 1'b0;
  wire  av_waitrequest;
  wire  [31:0] av_readdata;
  wire  av_readdatavalid;
  wire  [1:0]  av_response;

  always #5 clk = ~clk;

  avalon_mm_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .av_address(av_address), .av_writedata(av_writedata),
    .av_write(av_write), .av_read(av_read),
    .av_waitrequest(av_waitrequest), .av_readdata(av_readdata),
    .av_readdatavalid(av_readdatavalid), .av_response(av_response)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [31:0] wdata [0:3];
  initial begin
    wdata[0] = 32'hC0FFEE00; wdata[1] = 32'h0BADF00D;
    wdata[2] = 32'h55AA55AA; wdata[3] = 32'h7FFFFFFF;

    repeat (8) step();
    chk(av_waitrequest === 1'b0, "waitrequest reset low");
    chk(av_response === 2'b00, "response reset OKAY");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    for (int a = 0; a < 4; a++) begin
      // write: hold request through the stall (accept on 2nd cycle)
      @(negedge clk);
      av_address = a*4; av_writedata = wdata[a]; av_write = 1;
      step();
      chk(av_waitrequest === 1'b1, "write stalls on waitrequest");
      step();                                  // accept cycle (write held)
      chk(av_waitrequest === 1'b0, "waitrequest released");
      @(negedge clk); av_write = 0;
      step();
    end

    for (int a = 0; a < 4; a++) begin
      // read: hold request through the stall, then readdatavalid
      @(negedge clk);
      av_address = a*4; av_read = 1;
      step();
      chk(av_waitrequest === 1'b1, "read stalls on waitrequest");
      step();                                  // accept cycle (read held)
      chk(av_waitrequest === 1'b0, "read waitrequest released");
      @(negedge clk); av_read = 0;
      step();
      begin : rd
        int to = 0;
        while (av_readdatavalid !== 1'b1 && to < 10) begin step(); to++; end
        chk(av_readdatavalid === 1'b1, "readdatavalid after read");
        chk(av_readdata === wdata[a], "read data integrity");
      end
      chk(av_response === 2'b00, "response OKAY");
    end

    repeat (4) begin step(); chk(av_readdatavalid === 1'b0, "no readdatavalid when idle"); end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
