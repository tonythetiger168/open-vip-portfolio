// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (Avalon-MM DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened avalon_mm_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [11:0] av_address = 0;
  logic [3:0]  av_burstcount = 1, av_byteenable = 4'hF;
  logic        av_read = 0, av_write = 0;
  logic [31:0] av_writedata = 0;
  wire         av_waitrequest, av_readdatavalid, av_writeresponsevalid;
  wire  [31:0] av_readdata;
  wire  [1:0]  av_response;

  always #5 clk = ~clk;

  avalon_mm_model u_dut (.clk(clk), .rst_n(rst_n), .av_address(av_address), .av_burstcount(av_burstcount),
                         .av_byteenable(av_byteenable), .av_read(av_read), .av_write(av_write),
                         .av_writedata(av_writedata), .av_waitrequest(av_waitrequest), .av_readdata(av_readdata),
                         .av_readdatavalid(av_readdatavalid), .av_response(av_response),
                         .av_writeresponsevalid(av_writeresponsevalid));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // response log, filled at every posedge
  logic [31:0] r_data [0:255];
  logic [1:0]  r_rsp  [0:255];
  logic        r_wr   [0:255];
  int nr = 0, nwait = 0, nacc = 0;
  always @(posedge clk) begin
    if (av_readdatavalid || av_writeresponsevalid) begin
      r_data[nr % 256] = av_readdata; r_rsp[nr % 256] = av_response; r_wr[nr % 256] = av_writeresponsevalid; nr++;
    end
    if ((av_read || av_write) && av_waitrequest) nwait++;
    if ((av_read || av_write) && !av_waitrequest) nacc++;
  end

  // hold the current command until a clock without waitrequest
  task automatic beat_go();
    bit w;
    do begin @(posedge clk); w = av_waitrequest; @(negedge clk); end while (w);   // waitrequest as sampled by the edge
  endtask
  task automatic idle(input int n); repeat (n) @(negedge clk); endtask

  task automatic wr(input logic [11:0] a, input logic [3:0] bc, input logic [31:0] be, input logic [255:0] d,
                    input logic [7:0] gaps);
    int n = (bc == 0) ? 1 : bc;
    for (int i = 0; i < n; i++) begin
      if (gaps[i]) begin av_write = 0; idle(1); end
      av_write = 1; av_address = a; av_burstcount = bc; av_byteenable = be[4 * i +: 4]; av_writedata = d[32 * i +: 32];
      beat_go();
    end
    av_write = 0;
  endtask
  task automatic rd(input logic [11:0] a, input logic [3:0] bc);
    av_read = 1; av_address = a; av_burstcount = bc; av_byteenable = 4'hF;
    beat_go();
    av_read = 0;
  endtask
  // wait until k responses have arrived since r0
  int r0;
  task automatic resp(input int k);
    int t = 0;
    while (nr < r0 + k && t < 200) begin @(negedge clk); t++; end
    chk(nr >= r0 + k, $sformatf("%0d responses arrived", k));
  endtask

  initial begin
    idle(3);
    chk(!av_waitrequest && !av_readdatavalid && !av_writeresponsevalid && av_response == 0, "idle in reset");
    av_read = 1; #1; chk(!av_waitrequest, "no waitrequest in reset"); av_read = 0;
    @(negedge clk); rst_n = 1; idle(2);
    chk(!av_waitrequest, "no waitrequest without a command");

    // single write, read back
    r0 = nr; wr(12'h010, 1, 32'hF, 256'hCAFE_F00D, 0); resp(1);
    chk(r_wr[r0 % 256] && r_rsp[r0 % 256] == 2'b00, "write response OKAY");
    r0 = nr; rd(12'h010, 1); resp(1);
    chk(!r_wr[r0 % 256] && r_data[r0 % 256] == 32'hCAFE_F00D && r_rsp[r0 % 256] == 2'b00, "read back the word");
    r0 = nr; rd(12'h014, 1); resp(1);
    chk(r_data[r0 % 256] == 32'h0, "neighbour word still 0");
    // byte lanes
    r0 = nr; wr(12'h010, 1, 32'h2, 256'h0000_AB00, 0); wr(12'h010, 1, 32'h8, 256'h7700_0000, 0);
    wr(12'h010, 1, 32'h0, 256'hFFFF_FFFF, 0); resp(3);
    r0 = nr; rd(12'h010, 1); resp(1);
    chk(r_data[r0 % 256] == 32'h77FE_AB0D, $sformatf("byte-enable merge, no-byte write ignored (%h)", r_data[r0 % 256]));
    r0 = nr; wr(12'h020, 1, 32'h1, 256'h0000_0011, 0); wr(12'h020, 1, 32'h4, 256'h0022_0000, 0); resp(2);
    r0 = nr; rd(12'h020, 1); resp(1);
    chk(r_data[r0 % 256] == 32'h0022_0011, "lanes 0 and 2");

    // write burst of 8 with idle clocks between beats, read burst of 8
    r0 = nr;
    wr(12'h100, 8, 32'hFFFF_FFFF, {32'h88, 32'h77, 32'h66, 32'h55, 32'h44, 32'h33, 32'h22, 32'h11}, 8'b1001_0110);
    resp(1);
    chk(nr == r0 + 1 && r_wr[r0 % 256] && r_rsp[r0 % 256] == 0, "one write response for the 8-beat burst");
    r0 = nr; rd(12'h100, 8); resp(8);
    begin
      bit ok = 1;
      for (int i = 0; i < 8; i++) if (r_data[(r0 + i) % 256] != 32'h11 * (i + 1) || r_wr[(r0 + i) % 256]) ok = 0;
      chk(ok, "8 read beats, sequential words");
    end
    r0 = nr; rd(12'h108, 3); resp(3);
    chk(r_data[r0 % 256] == 32'h33 && r_data[(r0 + 2) % 256] == 32'h55, "3-beat burst from the middle");
    r0 = nr; rd(12'h11C, 1); resp(1);
    chk(r_data[r0 % 256] == 32'h88, "last word of the burst");
    r0 = nr; rd(12'h120, 1); resp(1);
    chk(r_data[r0 % 256] == 32'h0, "word after the burst untouched");
    // burst byte enables beat by beat
    r0 = nr; wr(12'h180, 4, 32'h0000_8421, {4{32'hFFFF_FFFF}}, 0); resp(1);
    r0 = nr; rd(12'h180, 4); resp(4);
    chk(r_data[r0 % 256] == 32'h0000_00FF && r_data[(r0 + 1) % 256] == 32'h0000_FF00 &&
        r_data[(r0 + 2) % 256] == 32'h00FF_0000 && r_data[(r0 + 3) % 256] == 32'hFF00_0000, "per-beat byteenable");
    // burstcount 0 is one beat
    r0 = nr; wr(12'h1C0, 0, 32'hF, 256'h5A5A, 0); resp(1);
    chk(r_wr[r0 % 256], "burstcount 0 write: one beat, one response");
    r0 = nr; rd(12'h1C0, 0); resp(1); idle(5);
    chk(nr == r0 + 1 && r_data[r0 % 256] == 32'h5A5A, "burstcount 0 read: one beat");
    // last word, error regions
    r0 = nr; wr(12'h3FC, 1, 32'hF, 256'h1357, 0); rd(12'h3FC, 1); resp(2);
    chk(r_rsp[r0 % 256] == 2'b00 && r_data[(r0 + 1) % 256] == 32'h1357 && r_rsp[(r0 + 1) % 256] == 2'b00, "0x3FC is memory");
    r0 = nr; rd(12'h400, 1); rd(12'h7FC, 1); rd(12'h800, 1); rd(12'hFFC, 1); resp(4);
    chk(r_rsp[r0 % 256] == 2'b10 && r_rsp[(r0 + 1) % 256] == 2'b10 && r_data[r0 % 256] == 0, "0x400..0x7FF: SLVERR, data 0");
    chk(r_rsp[(r0 + 2) % 256] == 2'b11 && r_rsp[(r0 + 3) % 256] == 2'b11, "0x800..0xFFF: DECODEERROR");
    r0 = nr; wr(12'h400, 1, 32'hF, 256'h1, 0); wr(12'h800, 1, 32'hF, 256'h1, 0); resp(2);
    chk(r_rsp[r0 % 256] == 2'b10 && r_rsp[(r0 + 1) % 256] == 2'b11, "write responses SLVERR / DECODEERROR");
    r0 = nr; rd(12'h000, 1); resp(1);
    chk(r_data[r0 % 256] == 32'h0, "an error-region write lands nowhere (0x400 does not alias 0x000)");
    // bursts across region boundaries: each beat by its own address
    r0 = nr; wr(12'h3F8, 4, 32'hFFFF, {32'h4, 32'h3, 32'h2, 32'h1}, 0); resp(1);
    chk(r_rsp[r0 % 256] == 2'b10, "write burst into SLVERR: first error response");
    r0 = nr; rd(12'h3F8, 4); resp(4);
    chk(r_data[r0 % 256] == 32'h1 && r_data[(r0 + 1) % 256] == 32'h2 && r_rsp[(r0 + 1) % 256] == 2'b00 &&
        r_rsp[(r0 + 2) % 256] == 2'b10 && r_rsp[(r0 + 3) % 256] == 2'b10 && r_data[(r0 + 2) % 256] == 0,
        "read burst into SLVERR: in-range beats OKAY, the rest SLVERR");
    r0 = nr; wr(12'h7FC, 2, 32'hFF, 256'h0, 0); rd(12'h7FC, 2); resp(3);
    chk(r_rsp[r0 % 256] == 2'b10 && r_rsp[(r0 + 1) % 256] == 2'b10 && r_rsp[(r0 + 2) % 256] == 2'b11,
        "SLVERR beat then DECODEERROR beat");
    r0 = nr; wr(12'h7F8, 4, 32'hFFFF, 256'h0, 0); resp(1);
    chk(r_rsp[r0 % 256] == 2'b10, "SLVERR, SLVERR, DECODEERROR, DECODEERROR: the first error is reported");
    r0 = nr; wr(12'hFFC, 2, 32'hFF, {32'hBEEF, 32'h0}, 0); resp(1);
    chk(r_rsp[r0 % 256] == 2'b11, "write wrapping 0xFFC -> 0x000: first beat DECODEERROR");
    r0 = nr; rd(12'h000, 1); resp(1);
    chk(r_data[r0 % 256] == 32'hBEEF, "the wrapped beat lands at 0x000");

    // pipelined reads: four pending, a fifth waits until the first burst has returned all its beats
    begin : pipe
      int acc = 0, t = 0, early = 0;
      r0 = nr;
      av_read = 1; av_address = 12'h100; av_burstcount = 8;
      while (acc < 5 && t < 300) begin
        #4; if (!av_waitrequest) begin acc++; if (acc == 5) early = (nr < r0 + 7); end
        @(negedge clk); t++;
      end
      av_read = 0;
      chk(acc == 5 && !early, $sformatf("a fifth read waits for the first burst (%0d, %0d)", acc, nr - r0));
      resp(40);
      idle(5);
      chk(nr == r0 + 40, "five bursts of 8 beats");
    end
    idle(10);

    // a write waits while reads are pending
    r0 = nr;
    av_read = 1; av_address = 12'h100; av_burstcount = 8; beat_go(); av_read = 0;
    av_write = 1; av_address = 12'h104; av_burstcount = 1; av_byteenable = 4'hF; av_writedata = 32'hDEAD;
    #1; chk(av_waitrequest, "write waits while a read is pending");
    beat_go(); av_write = 0;
    chk(nr == r0 + 8, $sformatf("the write is accepted only after the 8 read beats (%0d)", nr - r0));
    resp(9);
    chk(r_wr[(r0 + 8) % 256] && r_data[(r0 + 1) % 256] == 32'h22, "read returned the old word");
    r0 = nr; rd(12'h104, 1); resp(1);
    chk(r_data[r0 % 256] == 32'hDEAD, "the write landed after the read");
    // the LFSR wait-state pattern (about one clock in four) plus the full-queue waits of the pipelined reads
    chk(nwait == 54 && nacc == 61, $sformatf("wait states %0d for %0d accepted beats", nwait, nacc));

    // reset in the middle of a burst
    av_write = 1; av_address = 12'h300; av_burstcount = 4; av_writedata = 32'h1; beat_go();
    av_write = 0; rd(12'h300, 1);
    @(negedge clk); rst_n = 0; idle(2);
    chk(!av_readdatavalid && !av_writeresponsevalid && !av_waitrequest, "reset clears the responses");
    rst_n = 1; idle(2);
    r0 = nr; rd(12'h300, 1); resp(1);
    chk(r_data[r0 % 256] == 32'h0, "reset clears the memory");
    r0 = nr; wr(12'h304, 2, 32'hFF, {32'h2, 32'h1}, 0); resp(1);
    chk(r_wr[r0 % 256] && r_rsp[r0 % 256] == 0, "a new burst after reset starts at beat 0");
    r0 = nr; rd(12'h304, 2); resp(2);
    chk(r_data[r0 % 256] == 32'h1 && r_data[(r0 + 1) % 256] == 32'h2, "burst after reset at the right words");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
