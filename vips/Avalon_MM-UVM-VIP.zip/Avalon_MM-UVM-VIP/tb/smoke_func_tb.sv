// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (Avalon-MM write/read with waitrequest)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened avalon_mm_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [7:0]  av_address = '0;
  logic [31:0] av_writedata = '0;
  logic av_write = 1'b0;
  logic av_read = 1'b0;
  wire  av_waitrequest;
  wire  [31:0] av_readdata;
  wire  av_readdatavalid;
  wire  [1:0]  av_response;

  always #5 clk = ~clk;

  avalon_mm_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .av_address(av_address), .av_writedata(av_writedata),
    .av_write(av_write), .av_read(av_read),
    .av_waitrequest(av_waitrequest), .av_readdata(av_readdata),
    .av_readdatavalid(av_readdatavalid), .av_response(av_response)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [31:0] wdata [0:3];
  initial begin
    wdata[0] = 32'hC0FFEE00; wdata[1] = 32'h0BADF00D;
    wdata[2] = 32'h55AA55AA; wdata[3] = 32'h7FFFFFFF;

    repeat (8) step();
    chk(av_waitrequest === 1'b0, "waitrequest reset low");
    av_write = 1;
    #1 chk(av_waitrequest === 1'b0, "waitrequest stays low in reset even with a command");
    av_write = 0;
    chk(av_response === 2'b00, "response reset OKAY");
    chk(av_readdatavalid === 1'b0, "readdatavalid reset low");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) begin step(); chk(av_readdatavalid === 1'b0, "no readdatavalid out of reset"); end

    // Avalon-MM transfer: waitrequest is high on the first clock of a
    // command and low on the second; the transfer completes on the clock
    // where waitrequest is low, and the host drops the command right after it.
    for (int a = 0; a < 4; a++) begin
      @(negedge clk);
      av_address = a*4; av_writedata = wdata[a]; av_write = 1;
      #1 chk(av_waitrequest === 1'b1, "write: waitrequest high on the first clock");
      step();
      chk(av_waitrequest === 1'b0, "write: waitrequest low on the second clock");
      chk(u_dut.mem[a] === 32'h0, "write not taken while waitrequest was high");
      step();                                  // transfer completes on this clock
      av_write = 0;
      chk(u_dut.mem[a] === wdata[a], "write taken on the clock waitrequest was low");
      repeat (3) begin step(); chk(av_readdatavalid === 1'b0, "a write returns no readdatavalid"); end
    end

    for (int a = 0; a < 4; a++) begin
      @(negedge clk);
      av_address = a*4; av_read = 1;
      #1 chk(av_waitrequest === 1'b1, "read: waitrequest high on the first clock");
      step();
      chk(av_waitrequest === 1'b0, "read: waitrequest low on the second clock");
      step();                                  // transfer completes on this clock
      av_read = 0; av_address = 8'hFC;         // address may change once accepted
      begin : rd
        int to;
        to = 0;
        while (av_readdatavalid !== 1'b1 && to < 10) begin step(); to++; end
        chk(av_readdatavalid === 1'b1 && to == 1, "readdatavalid two clocks after the transfer");
        chk(av_readdata === wdata[a], "read data from the accepted address");
      end
      chk(av_response === 2'b00, "response OKAY");
      step();
      chk(av_readdatavalid === 1'b0, "readdatavalid lasts one clock");
    end

    // a host that keeps write asserted issues back-to-back transfers, each
    // with its own wait state
    @(negedge clk);
    av_address = 8'h40; av_writedata = 32'h1111_1111; av_write = 1;
    step(); step();                            // first transfer completes
    av_address = 8'h44; av_writedata = 32'h2222_2222;
    chk(av_waitrequest === 1'b1, "held command: next transfer starts with a wait state");
    step();
    chk(av_waitrequest === 1'b0 && u_dut.mem[17] === 32'h0, "second transfer not taken during its wait state");
    step();
    av_write = 0;
    chk(u_dut.mem[16] === 32'h1111_1111 && u_dut.mem[17] === 32'h2222_2222,
        "back-to-back writes both stored, once each");
    step();
    chk(av_waitrequest === 1'b0, "waitrequest low while idle");

    repeat (4) begin step(); chk(av_readdatavalid === 1'b0, "no readdatavalid when idle"); end

    // reset clears the whole memory: every word written above reads back 0
    @(negedge clk); rst_n = 1'b0;
    repeat (2) step();
    // a command already present when reset is released still gets its wait state
    @(negedge clk); rst_n = 1'b1; av_address = 8'h00; av_read = 1;
    #1 chk(av_waitrequest === 1'b1, "command at reset release: waitrequest high on its first clock");
    step(); step();
    av_read = 0;
    repeat (2) step();
    for (int a = 0; a < 4; a++) begin
      @(negedge clk); av_address = a*4; av_read = 1;
      step(); step();
      av_read = 0;
      begin : rd0
        int to;
        to = 0;
        while (av_readdatavalid !== 1'b1 && to < 10) begin step(); to++; end
        chk(av_readdatavalid === 1'b1 && av_readdata === 32'h0, $sformatf("word %0d reads 0 after reset", a));
      end
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
