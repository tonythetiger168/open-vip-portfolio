// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- Avalon-MM testbench top with a functional Avalon-MM DUT model

`ifndef AVALON_MM_UVM_VIP_TB_SV
`define AVALON_MM_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import avalon_mm_defs_pkg::*;
import avalon_mm_pkg::*;
import avalon_mm_env_pkg::*;
import avalon_mm_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  avalon_mm_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  avalon_mm_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .av_address(vif.av_address),
    .av_burstcount(vif.av_burstcount),
    .av_byteenable(vif.av_byteenable),
    .av_read(vif.av_read),
    .av_write(vif.av_write),
    .av_writedata(vif.av_writedata),
    .av_waitrequest(vif.av_waitrequest),
    .av_readdata(vif.av_readdata),
    .av_readdatavalid(vif.av_readdatavalid),
    .av_response(vif.av_response),
    .av_writeresponsevalid(vif.av_writeresponsevalid)
  );

  // Concurrent protocol checks
  avalon_mm_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .av_address(vif.av_address),
    .av_burstcount(vif.av_burstcount),
    .av_byteenable(vif.av_byteenable),
    .av_read(vif.av_read),
    .av_write(vif.av_write),
    .av_writedata(vif.av_writedata),
    .av_waitrequest(vif.av_waitrequest),
    .av_readdata(vif.av_readdata),
    .av_readdatavalid(vif.av_readdatavalid),
    .av_response(vif.av_response),
    .av_writeresponsevalid(vif.av_writeresponsevalid)
  );

  initial begin
    uvm_config_db#(virtual avalon_mm_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module avalon_mm_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [11:0] av_address,
  input  logic [3:0]  av_burstcount,
  input  logic [3:0]  av_byteenable,
  input  logic        av_read,
  input  logic        av_write,
  input  logic [31:0] av_writedata,
  output logic        av_waitrequest,
  output logic [31:0] av_readdata,
  output logic        av_readdatavalid,
  output logic [1:0]  av_response,
  output logic        av_writeresponsevalid
);
  logic [31:0] mem [0:255];
  // pending responses, in command order: {write, beats - 1, base address, write response}
  logic        q_wr  [0:3];
  logic [2:0]  q_n   [0:3];
  logic [11:0] q_a   [0:3];
  logic [1:0]  q_rsp [0:3];
  logic [1:0]  wp, rp;
  logic [2:0]  cnt, nrd;             // pending responses, pending reads
  logic [2:0]  beat;                 // read beat being returned
  logic [7:0]  lfsr;
  logic        wact;                 // a write burst is in progress
  logic [2:0]  wbeat, wlast;
  logic [11:0] wbase;
  logic [1:0]  wrsp;
  logic [11:0] wa, ra;
  logic        stall, acc_rd, acc_wr, wdone, give, last;

  function automatic logic [1:0] code(input logic [11:0] a);
    code = a[11] ? 2'b11 : a[10] ? 2'b10 : 2'b00;
  endfunction

  assign stall  = (lfsr[1:0] == 2'b00);
  // a new command waits while four responses are queued; a write burst starts only with no read pending
  assign av_waitrequest = rst_n && (av_read || av_write) &&
                          (stall || (cnt == 3'd4 && (av_read || !wact)) || (av_write && !wact && nrd != 3'd0));
  assign acc_rd = av_read && !av_write && !wact && !av_waitrequest;
  assign acc_wr = av_write && !av_waitrequest;
  assign wa     = (wact ? wbase : av_address) + {7'h0, (wact ? wbeat : 3'd0), 2'b00};
  assign wdone  = acc_wr && ((wact ? wbeat : 3'd0) == (wact ? wlast : (av_burstcount == 4'd0 ? 3'd0 : 3'(av_burstcount - 4'd1))));
  // response side: the head of the queue, a read beat when the LFSR allows (bit 3)
  assign give   = (cnt != 3'd0) && (q_wr[rp] || !lfsr[3]);
  assign ra     = q_a[rp] + {7'h0, beat, 2'b00};
  assign last   = q_wr[rp] || beat == q_n[rp];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 256; i++) mem[i] <= 32'h0;
      for (int i = 0; i < 4; i++) begin q_wr[i] <= 1'b0; q_n[i] <= 3'd0; q_a[i] <= 12'h0; q_rsp[i] <= 2'b00; end
      wp <= 2'd0; rp <= 2'd0; cnt <= 3'd0; nrd <= 3'd0; beat <= 3'd0; lfsr <= 8'h5B;
      wact <= 1'b0; wbeat <= 3'd0; wlast <= 3'd0; wbase <= 12'h0; wrsp <= 2'b00;
      av_readdata <= 32'h0; av_readdatavalid <= 1'b0; av_response <= 2'b00; av_writeresponsevalid <= 1'b0;
    end else begin
      lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};
      av_readdatavalid <= 1'b0; av_writeresponsevalid <= 1'b0; av_response <= 2'b00; av_readdata <= 32'h0;
      // ---- write beats: memory updated beat by beat, the response queued after the last one
      if (acc_wr) begin
        if (code(wa) == 2'b00) begin
          for (int b = 0; b < 4; b++) if (av_byteenable[b]) mem[wa[9:2]][8 * b +: 8] <= av_writedata[8 * b +: 8];
        end
        if (!wact) begin
          wbase <= av_address; wlast <= (av_burstcount == 4'd0) ? 3'd0 : 3'(av_burstcount - 4'd1);
        end
        if (wdone) begin
          q_wr[wp] <= 1'b1; q_n[wp] <= 3'd0; q_a[wp] <= 12'h0;
          q_rsp[wp] <= ((wact ? wrsp : 2'b00) != 2'b00) ? wrsp : code(wa);
          wp <= wp + 2'd1; wact <= 1'b0; wbeat <= 3'd0; wrsp <= 2'b00;
        end else begin
          wact <= 1'b1; wbeat <= (wact ? wbeat : 3'd0) + 3'd1;
          if ((wact ? wrsp : 2'b00) == 2'b00) wrsp <= code(wa);
        end
      end
      // ---- read command queued
      if (acc_rd) begin
        q_wr[wp] <= 1'b0; q_n[wp] <= (av_burstcount == 4'd0) ? 3'd0 : 3'(av_burstcount - 4'd1); q_a[wp] <= av_address;
        q_rsp[wp] <= 2'b00; wp <= wp + 2'd1;
      end
      // ---- responses, in command order
      if (give) begin
        if (q_wr[rp]) begin
          av_writeresponsevalid <= 1'b1; av_response <= q_rsp[rp];
        end else begin
          av_readdatavalid <= 1'b1; av_response <= code(ra);
          av_readdata <= (code(ra) == 2'b00) ? mem[ra[9:2]] : 32'h0;
        end
        if (last) begin rp <= rp + 2'd1; beat <= 3'd0; end
        else beat <= beat + 3'd1;
      end
      cnt <= cnt + {2'b0, acc_rd || wdone} - {2'b0, give && last};
      nrd <= nrd + {2'b0, acc_rd} - {2'b0, give && last && !q_wr[rp]};
    end
  end
endmodule
`endif
