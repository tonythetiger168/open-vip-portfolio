// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- Avalon-MM testbench top with a functional Avalon-MM DUT model

`ifndef Avalon-MM_TB_SV
`define Avalon-MM_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import avalon_mm_defs_pkg::*;
import avalon_mm_pkg::*;
import avalon_mm_env_pkg::*;
import avalon_mm_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  avalon_mm_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  avalon_mm_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .av_address(vif.av_address),
    .av_writedata(vif.av_writedata),
    .av_write(vif.av_write),
    .av_read(vif.av_read),
    .av_waitrequest(vif.av_waitrequest),
    .av_readdata(vif.av_readdata),
    .av_readdatavalid(vif.av_readdatavalid),
    .av_response(vif.av_response)
  );

  // Concurrent protocol checks
  avalon_mm_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .av_address(vif.av_address), .av_writedata(vif.av_writedata), .av_write(vif.av_write), .av_read(vif.av_read), .av_waitrequest(vif.av_waitrequest), .av_readdata(vif.av_readdata), .av_readdatavalid(vif.av_readdatavalid), .av_response(vif.av_response)
  );

  initial begin
    uvm_config_db#(virtual avalon_mm_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module avalon_mm_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [7:0]  av_address,
  input  logic [31:0] av_writedata,
  input  logic        av_write,
  input  logic        av_read,
  output logic        av_waitrequest,
  output logic [31:0] av_readdata,
  output logic        av_readdatavalid,
  output logic [1:0]  av_response
);
  logic [31:0] mem [0:63];
  logic        rd_d;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      av_waitrequest    <= 1'b0;
      av_readdata       <= '0;
      av_readdatavalid  <= 1'b0;
      av_response       <= 2'b00;
      rd_d              <= 1'b0;
      for (int i = 0; i < 64; i++) mem[i] <= '0;
    end else begin
      // single wait-state on request, then accept
      av_waitrequest <= (av_write || av_read) && !av_waitrequest;
      if ((av_write || av_read) && !av_waitrequest)
        av_waitrequest <= 1'b1;
      else
        av_waitrequest <= 1'b0;
      if (av_write && av_waitrequest)
        mem[av_address[7:2]] <= av_writedata;
      rd_d             <= av_read && av_waitrequest;
      av_readdatavalid <= rd_d;
      if (rd_d)
        av_readdata <= mem[av_address[7:2]];
      av_response <= 2'b00; // OKAY
    end
  end
endmodule
`endif
