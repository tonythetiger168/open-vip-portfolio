// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- IO-Link testbench top with a functional IO-Link DUT model

`ifndef IO-Link_TB_SV
`define IO-Link_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import io_link_defs_pkg::*;
import io_link_pkg::*;
import io_link_env_pkg::*;
import io_link_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  io_link_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  io_link_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx(vif.rx),
    .tx_data(vif.tx_data),
    .tx_req(vif.tx_req),
    .tx(vif.tx),
    .tx_cnf(vif.tx_cnf),
    .rx_data(vif.rx_data),
    .rx_valid(vif.rx_valid)
  );

  // Concurrent protocol checks
  io_link_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .rx(vif.rx), .tx_data(vif.tx_data), .tx_req(vif.tx_req), .tx(vif.tx), .tx_cnf(vif.tx_cnf), .rx_data(vif.rx_data), .rx_valid(vif.rx_valid)
  );

  initial begin
    uvm_config_db#(virtual io_link_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module io_link_model #(
  parameter int BIT_CLKS = 4
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       rx,
  input  logic [7:0] tx_data,
  input  logic       tx_req,
  output logic       tx,
  output logic       tx_cnf,
  output logic [7:0] rx_data,
  output logic       rx_valid
);
  typedef enum bit [1:0] {TX_IDLE, TX_START, TX_DATA, TX_STOP} tx_e;
  tx_e tst;
  logic [7:0] tsh;
  logic [3:0] tbit;
  logic [3:0] tcnt;
  logic [7:0] rsh;
  logic [3:0] rbit;
  logic [3:0] rcnt;
  logic       rstart;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tst     <= TX_IDLE;
      tsh     <= '0;
      tbit    <= '0;
      tcnt    <= '0;
      rsh     <= '0;
      rbit    <= '0;
      rcnt    <= '0;
      rstart  <= 1'b0;
      tx      <= 1'b1;
      tx_cnf  <= 1'b0;
      rx_data <= '0;
      rx_valid<= 1'b0;
    end else begin
      // transmitter
      case (tst)
        TX_IDLE: if (tx_req) begin
          tst  <= TX_START;
          tsh  <= tx_data;
          tbit <= '0;
          tx   <= 1'b0;
        end
        TX_START, TX_DATA, TX_STOP: begin
          if (tcnt == BIT_CLKS-1) begin
            tcnt <= '0;
            if (tst == TX_START) begin
              tst <= TX_DATA;
              tx  <= tsh[0];
            end else if (tst == TX_DATA) begin
              tsh  <= {1'b0, tsh[7:1]};
              tbit <= tbit + 1'b1;
              if (tbit == 4'd7) begin
                tst <= TX_STOP;
                tx  <= 1'b1;
              end else
                tx <= tsh[1];
            end else begin
              tst    <= TX_IDLE;
              tx_cnf <= 1'b1;
            end
          end else
            tcnt <= tcnt + 1'b1;
        end
        default: tst <= TX_IDLE;
      endcase
      if (tst == TX_IDLE && tx_cnf)
        tx_cnf <= 1'b0;
      // receiver: detect start bit, sample mid-bit
      if (!rstart && !rx) begin
        rstart <= 1'b1;
        rcnt   <= '0;
        rbit   <= '0;
      end else if (rstart) begin
        if (rcnt == BIT_CLKS-1) begin
          rcnt <= '0;
          if (rbit < 4'd8) begin
            rsh  <= {rx, rsh[7:1]};
            rbit <= rbit + 1'b1;
          end else begin
            rx_data  <= rsh;
            rx_valid <= 1'b1;
            rstart   <= 1'b0;
          end
        end else
          rcnt <= rcnt + 1'b1;
      end
      if (rx_valid)
        rx_valid <= 1'b0;
    end
  end
endmodule
`endif
