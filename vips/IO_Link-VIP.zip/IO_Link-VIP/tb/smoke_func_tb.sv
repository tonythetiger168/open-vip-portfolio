// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (IO-Link message exchange)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened io_link_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic rx = 1'b1;
  logic [7:0] host_byte = 8'h3C;
  bit seen_rx_valid = 0;
  always @(posedge clk) if (rx_valid === 1'b1) seen_rx_valid = 1;
  logic [7:0] tx_data = '0;
  logic tx_req = 1'b0;
  wire  tx;
  wire  tx_cnf;
  wire  [7:0] rx_data;
  wire  rx_valid;

  always #5 clk = ~clk;

  io_link_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .rx(rx), .tx_data(tx_data), .tx_req(tx_req),
    .tx(tx), .tx_cnf(tx_cnf),
    .rx_data(rx_data), .rx_valid(rx_valid)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  // serial receiver monitor for the device TX pin
  bit [7:0] tx_capture;
  bit       tx_got;
  initial begin
    tx_got = 0;
    // wait for a start bit (high->low)
    @(negedge tx);
    repeat (2) @(posedge clk);      // mid start bit
    for (int i = 0; i < 8; i++) begin
      repeat (4) @(posedge clk);    // BIT_CLKS = 4
      tx_capture[i] = tx;
    end
    tx_got = 1;
  end

  initial begin
    repeat (8) step();
    chk(tx === 1'b1, "tx line idle high");
    chk(tx_cnf === 1'b0 && rx_valid === 1'b0, "handshakes quiet");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // device transmit: request a message, expect confirm + serialised data
    @(negedge clk); tx_data = 8'hA5; tx_req = 1;
    begin : cnf
      int to = 0;
      while (tx_cnf !== 1'b1 && to < 80) begin step(); to++; end
      chk(tx_cnf === 1'b1, "tx_cnf after transmission");
    end
    @(negedge clk); tx_req = 0;
    begin : cap
      int to = 0;
      while (!tx_got && to < 100) begin step(); to++; end
      chk(tx_got, "serial frame observed on tx");
      chk(tx_capture === 8'hA5, "serialised data integrity");
    end

    // host -> device: send one byte serially into rx
    begin : h2d
      seen_rx_valid = 0;
      @(negedge clk); rx = 1'b0;          // start bit
      repeat (4) step();
      for (int i = 0; i < 8; i++) begin
        @(negedge clk); rx = host_byte[i];
        repeat (4) step();
      end
      @(negedge clk); rx = 1'b1;          // stop
      repeat (6) step();
      chk(seen_rx_valid, "rx_valid after host byte");
      chk(rx_data === host_byte, "received data integrity");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
