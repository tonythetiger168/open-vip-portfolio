# IO-Link UVM VIP (IO_Link-VIP)

IO-Link device UVM VIP: UART-framed 8-bit message exchange with request/confirm and receive indication handshakes.

## Structure

- `io_link/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `io_link_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `io_link_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural IO-Link DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/IO_Link-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh IO_Link-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
