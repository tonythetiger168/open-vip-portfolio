// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_pkg.sv -- IO-Link UVM VIP package

package io_link_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import io_link_defs_pkg::*;
  export io_link_defs_pkg::*;

  `include "io_link_transaction.svh"
  `include "io_link_config.svh"
  `include "io_link_sequencer.svh"
  `include "io_link_driver.svh"
  `include "io_link_monitor.svh"
  `include "io_link_agent.svh"
  `include "io_link_sequences.svh"
  `include "io_link_checker.svh"
  `include "io_link_coverage.svh"
endpackage
