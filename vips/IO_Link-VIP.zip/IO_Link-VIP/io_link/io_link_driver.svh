// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_driver.svh -- IO-Link driver: UART character on rx (start, 8 data LSB first, stop), or a tx_req for the DUT to send

class io_link_driver extends uvm_driver #(io_link_transaction);
  `uvm_component_utils(io_link_driver)

  uvm_analysis_port #(io_link_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual io_link_if vif;
  io_link_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual io_link_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "io_link: virtual interface not set")
    if (!uvm_config_db#(io_link_config)::get(this, "", "cfg", cfg))
      cfg = io_link_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    io_link_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.rx <= 1'b1; vif.drv_cb.tx_req <= 1'b0; vif.drv_cb.tx_data <= '0;
  endtask

  task drive_item(io_link_transaction t);
    @(vif.drv_cb);
    if (!t.dut_tx) begin
      send_bit(1'b0);
      for (int i = 0; i < 8; i++) send_bit(t.data[i]);
      send_bit(1'b1);
      send_bit(1'b1);                       // one idle bit time
    end else begin
      vif.drv_cb.tx_req  <= 1'b1;
      vif.drv_cb.tx_data <= t.data;
      @(vif.drv_cb);
      vif.drv_cb.tx_req  <= 1'b0;
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (vif.drv_cb.tx_cnf !== 1'b1 && to < cfg.timeout_cycles);
        if (vif.drv_cb.tx_cnf !== 1'b1) `uvm_error("TIMEOUT", "IO-Link: no tx_cnf")
      end
      // idle for two bit times: the monitor watches tx for 12 bit times from
      // the start bit, so an earlier tx_req would be missed
      repeat (2 * cfg.bit_clks) @(vif.drv_cb);
    end
  endtask

  task send_bit(bit b);
    vif.drv_cb.rx <= b;
    repeat (cfg.bit_clks) @(vif.drv_cb);
  endtask
endclass
