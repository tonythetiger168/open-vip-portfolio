// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_if.sv -- IO-Link interface

interface io_link_if (input logic clk);
  logic rst_n;

  logic rx;
  logic [7:0] tx_data;
  logic tx_req;
  logic tx;
  logic tx_cnf;
  logic [7:0] rx_data;
  logic rx_valid;

  modport DUT (input clk, rst_n, rx, tx_data, tx_req, output tx, tx_cnf, rx_data, rx_valid);
  modport DRV (input clk, rst_n, tx, tx_cnf, rx_data, rx_valid, output rx, tx_data, tx_req);
  modport MON (input clk, rst_n, rx, tx_data, tx_req, tx, tx_cnf, rx_data, rx_valid);

  clocking drv_cb @(posedge clk);
    input rst_n, rx, tx_data, tx_req, tx, tx_cnf, rx_data, rx_valid;
    output rx, tx_data, tx_req;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, rx, tx_data, tx_req, tx, tx_cnf, rx_data, rx_valid;
  endclocking
endinterface
