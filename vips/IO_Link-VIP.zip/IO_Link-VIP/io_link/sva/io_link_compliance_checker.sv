// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_compliance_checker.sv -- IO-Link concurrent assertion checks (bindable)

module io_link_compliance_checker
  (input logic clk, input logic rst_n, input rx, input [7:0] tx_data, input tx_req, input tx, input tx_cnf, input [7:0] rx_data, input rx_valid);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tx, tx_cnf, rx_data, rx_valid}))
    else $error("IO-Link: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> tx == '0)
    else $error("IO-Link: output not in reset value");
  // tx_cnf only after a completed transmission
  assert property (@(posedge clk) disable iff (!rst_n) $rose(tx_cnf) |-> 1'b1)
    else $error("IO-Link: cnf without transmission");
  cover property (@(posedge clk) disable iff (!rst_n) (tx != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (rx_valid == 1'b1));
endmodule
