// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_monitor.svh -- IO-Link monitor: decodes observed bus activity

class io_link_monitor extends uvm_monitor;
  `uvm_component_utils(io_link_monitor)

  virtual io_link_if vif;
  uvm_analysis_port #(io_link_transaction) ap;
  io_link_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual io_link_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "io_link: virtual interface not set")
    void'(uvm_config_db#(io_link_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    io_link_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = io_link_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.rx = vif.rx;
        t.tx_data = vif.tx_data;
        t.tx_req = vif.tx_req;
        t.tx_o = vif.tx;
        t.tx_cnf_o = vif.tx_cnf;
        t.rx_data_o = vif.rx_data;
        t.rx_valid_o = vif.rx_valid;
        ap.write(t);
      end
    end
  endtask
endclass
