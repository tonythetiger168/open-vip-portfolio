// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_monitor.svh -- IO-Link monitor: decodes characters on rx and tx (mid-bit sampling) with rx_valid / tx_cnf

class io_link_monitor extends uvm_monitor;
  `uvm_component_utils(io_link_monitor)

  virtual io_link_if vif;
  uvm_analysis_port #(io_link_transaction) ap;
  io_link_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual io_link_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "io_link: virtual interface not set")
    if (!uvm_config_db#(io_link_config)::get(this, "", "cfg", cfg))
      cfg = io_link_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      fork
        forever begin                          // agent -> DUT on rx
          @(vif.mon_cb);
          if (vif.mon_cb.rx === 1'b0) begin
            io_link_transaction t = io_link_transaction::type_id::create("t");
            bit got = 0;
            t.dut_tx = 0;
            decode_char(0, t, got);
            if (!got) `uvm_error("MON", "IO-Link: character on rx not reported by rx_valid")
            publish(t);
          end
        end
        forever begin                          // DUT -> agent on tx
          @(vif.mon_cb);
          if (vif.mon_cb.tx_req === 1'b1) begin
            io_link_transaction t = io_link_transaction::type_id::create("t");
            bit got = 0;
            int unsigned to = 0;
            t.dut_tx = 1;
            t.data = vif.mon_cb.tx_data;
            do begin @(vif.mon_cb); to++; end while (vif.mon_cb.tx !== 1'b0 && to < 8);
            if (vif.mon_cb.tx !== 1'b0) `uvm_error("MON", "IO-Link: tx_req without a start bit on tx")
            decode_char(1, t, got);
            publish(t);
          end
        end
      join
    end
  endtask

  function void publish(io_link_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // called on the first clock of the start bit; samples each bit in its middle
  // and watches rx_valid (line rx) or tx_cnf (line tx) until the stop bit ends
  task decode_char(bit line_tx, io_link_transaction t, output bit got);
    int unsigned n = cfg.bit_clks;
    bit v;
    got = 0;
    t.framing_ok = 1;
    for (int c = 1; c < 10 * n + (line_tx ? 2 * n : 0); c++) begin
      @(vif.mon_cb);
      v = line_tx ? vif.mon_cb.tx : vif.mon_cb.rx;
      if (c == n / 2 && v != 1'b0) t.framing_ok = 0;                  // start bit
      if (c % n == n / 2 && c / n >= 1 && c / n <= 8) begin
        if (line_tx) t.rx_data[c / n - 1] = v; else t.data[c / n - 1] = v;
      end
      if (c == 9 * n + n / 2 && v != 1'b1) t.framing_ok = 0;          // stop bit
      if (!line_tx && vif.mon_cb.rx_valid) begin got = 1; t.rx_data = vif.mon_cb.rx_data; end
      if (line_tx && vif.mon_cb.tx_cnf) begin got = 1; t.cnf = 1; end
    end
  endtask
endclass
