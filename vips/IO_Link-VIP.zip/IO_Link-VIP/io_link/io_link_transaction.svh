// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_transaction.svh -- IO-Link transaction

class io_link_transaction extends uvm_sequence_item;
  `uvm_object_utils(io_link_transaction)

  // request (driven by the agent)
  rand bit dut_tx;
  rand bit [7:0] data;
  // response (returned by the DUT)
  bit [7:0] rx_data;
  bit cnf;
  bit framing_ok;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "io_link_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    io_link_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    dut_tx = rhs_.dut_tx;
    data = rhs_.data;
    rx_data = rhs_.rx_data;
    cnf = rhs_.cnf;
    framing_ok = rhs_.framing_ok;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    io_link_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (dut_tx != rhs_.dut_tx) return 0;
    if (data != rhs_.data) return 0;
    if (rx_data != rhs_.rx_data) return 0;
    if (cnf != rhs_.cnf) return 0;
    if (framing_ok != rhs_.framing_ok) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(io_link_transaction rhs_);
    if (dut_tx != rhs_.dut_tx) return 0;
    if (data != rhs_.data) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("IO-Link{tag=%0d dut_tx=0x%0h data=0x%0h rx_data=0x%0h cnf=0x%0h framing_ok=0x%0h}", tag, dut_tx, data, rx_data, cnf, framing_ok);
  endfunction
endclass
