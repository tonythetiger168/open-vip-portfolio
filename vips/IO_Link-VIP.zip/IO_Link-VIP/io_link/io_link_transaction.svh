// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_transaction.svh -- IO-Link transaction

class io_link_transaction extends uvm_sequence_item;
  `uvm_object_utils(io_link_transaction)

  rand bit rx;
  rand bit [7:0] tx_data;
  rand bit tx_req;
  bit tx_o;
  bit tx_cnf_o;
  bit [7:0] rx_data_o;
  bit rx_valid_o;
  bit [31:0] tag;

  function new(string name = "io_link_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    io_link_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    rx = rhs_.rx;
    tx_data = rhs_.tx_data;
    tx_req = rhs_.tx_req;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    io_link_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           rx == rhs_.rx &&
           tx_data == rhs_.tx_data &&
           tx_req == rhs_.tx_req;
  endfunction

  function string convert2string();
    return $sformatf("IO-Link{tag=%0h rx=0x%0h tx_data=0x%0h tx_req=0x%0h}", tag, rx, tx_data, tx_req);
  endfunction
endclass
