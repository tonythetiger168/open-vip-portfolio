// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_coverage.svh -- IO-Link functional coverage

class io_link_coverage extends uvm_subscriber #(io_link_transaction);
  `uvm_component_utils(io_link_coverage)
  io_link_config cfg;
  io_link_transaction tr;

  covergroup io_link_cg;
    coverpoint tr.rx;
    coverpoint tr.tx_data;
    coverpoint tr.tx_req;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(io_link_config)::get(this, "*", "cfg", cfg));
    io_link_cg = new();
  endfunction

  function void write(io_link_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    io_link_cg.sample();
  endfunction
endclass
