// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// io_link_sequences.svh -- IO-Link sequences

// Random traffic: cfg.num_items constrained-random items.
class io_link_base_sequence extends uvm_sequence #(io_link_transaction);
  `uvm_object_utils(io_link_base_sequence)
  io_link_config cfg;

  function new(string name = "io_link_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = io_link_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "io_link_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class io_link_directed_sequence extends uvm_sequence #(io_link_transaction);
  `uvm_object_utils(io_link_directed_sequence)
  io_link_config cfg;

  function new(string name = "io_link_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function io_link_transaction item();
    item = io_link_transaction::type_id::create("req");
  endfunction

  task send(io_link_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    io_link_transaction t;
    bit [7:0] chars [5] = '{8'h00, 8'hFF, 8'h55, 8'hA5, 8'h81};
    foreach (chars[i]) begin
      t = item(); t.dut_tx = 0; t.data = chars[i]; send(t);
      t = item(); t.dut_tx = 1; t.data = chars[i]; send(t);
    end
  endtask
endclass
