# ToggleNAND — Toggle Mode NAND UVM VIP

Open-source UVM verification IP template for **Toggle Mode NAND** (Storage).

## Contents

| Path | Description |
|------|-------------|
| `tnand/tnand_if.sv` | Protocol interface + FSM state enum |
| `tnand/tnand_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `tnand/sva/tnand_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4) |
| `tnand/vip/tnand/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/tnand_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with FSM-walking DUT stub |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Protocol-level host driver**: CLE/ALE command + address latches on we_n pulses, 5-byte address cycle, DQS-timed DDR write data (host drives dqs/dq), re_n-timed read data sampling (NAND drives dqs/dq), rb_n ready/busy polling, closing status read (0x70) for every operation
- **Bus-decoding monitor**: clk-synchronous decode of we_n latch edges, dqs data strobes with direction from dq ownership, rb_n busy tracking, status capture; one transaction per NAND operation
- **End-to-end scoreboard**: compares driver-issued vs monitor-decoded operations (cmd, 40-bit address, program data, read data, status, violation flags)
- **Functional DUT model**: NAND array model with byte-addressable memory, page buffer, busy delays (tPROG/tR/tBERS), status register (ready/fail bits), busy-violation and illegal-opcode detection
- **Directed sequence library**: page read / page program / block erase / status read / busy-violation error injection / illegal-command error injection / reset + regression mix
- **Functional coverage**: command × length cross, address ranges, data corners, host FSM states + transitions, error coverage (busy violation / illegal cmd / status fail)
- **SVA L4**: CLE/ALE mutual exclusion, we_n pulse-width bounds, only status/reset commands while busy, mandatory status read after program/erase, command latch requires ce_n low

Note: `state` is the host controller phase marker; every operation walks
the full phase sequence (phases without bus activity are brief
pass-throughs) so FSM coverage and L2 transition checks hold for all ops.
