// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_tnand_tb.sv -- self-checking functional test for the Toggle-mode NAND
// model (tnand_nand_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py ToggleNAND-VIP
//
// Model contract (from tnand_defs.sv and tnand_driver.svh):
//   commands / 5 address bytes latched on WE# rising (CLE / ALE), address
//   bytes sent LSB first as the VIP driver does; program data captured on
//   DQS rising with host_dq_oe; read data on each RE# low pulse with DQS
//   high. 80h-10h program (busy 16 clk), 00h-30h read (busy 8), 60h-D0h
//   erase of the 32-byte page (busy 24). 70h status: [6] ready, [0] fail
//   (READ/PROG/ERASE while busy, or an undefined opcode); FFh reset aborts.
//
// Model defects recorded as XFAIL: the address register shifts each byte in
// at the bottom, so the first (column LSB) byte becomes the MSB; data
// programmed at the start of a page cannot be read at a column offset, and
// erase misses bytes programmed at a non-zero column. Data are single data
// rate (one byte per DQS / RE# cycle), and in status mode the NAND drives
// DQ whenever CE# is low, also while the host drives a command. The status
// concatenation is 7 bits wide, so READY lands in bit 5 instead of bit 6;
// the other checks accept either bit (st_ok).

module func_tnand_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic       clk = 1'b0, rst_n = 1'b0;
  logic       dqs = 1'b0, cle = 1'b0, ale = 1'b0, ce_n = 1'b1, we_n = 1'b1, re_n = 1'b1;
  logic       host_dq_oe = 1'b0;
  logic [7:0] dq = '0;
  wire        rb_n, nand_dq_oe, nand_dqs_oe, nand_dqs_o;
  wire  [7:0] nand_dq_o;

  always #5 clk = ~clk;

  tnand_nand_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_dqs(dqs), .vif_dq(dq), .vif_cle(cle),
    .vif_ale(ale), .vif_ce_n(ce_n), .vif_we_n(we_n), .vif_re_n(re_n), .vif_rb_n(rb_n),
    .vif_host_dq_oe(host_dq_oe), .vif_nand_dq_oe(nand_dq_oe), .vif_nand_dq_o(nand_dq_o),
    .vif_nand_dqs_oe(nand_dqs_oe), .vif_nand_dqs_o(nand_dqs_o)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // bus contention: NAND and host both drive DQ
  int contention = 0;
  always @(posedge clk) if (nand_dq_oe && host_dq_oe) contention++;

  task automatic latch(input bit c, input [7:0] v);
    @(negedge clk);
    ce_n = 1'b0; cle = c; ale = !c; dq = v; host_dq_oe = 1'b1;
    @(negedge clk); we_n = 1'b0;
    @(negedge clk); we_n = 1'b1;
    @(negedge clk); cle = 1'b0; ale = 1'b0; host_dq_oe = 1'b0;
  endtask
  task automatic cmd(input [7:0] c); latch(1, c); endtask
  task automatic addr5(input [39:0] a);
    for (int i = 0; i < 5; i++) latch(0, a[8*i +: 8]);
  endtask
  task automatic wbyte(input [7:0] d, input bit oe = 1);
    @(negedge clk); dq = d; host_dq_oe = oe;
    @(negedge clk); dqs = 1'b1;
    @(negedge clk); dqs = 1'b0;
    @(negedge clk); host_dq_oe = 1'b0;
  endtask
  logic [7:0] rd;
  bit         rd_strobe;
  task automatic rbyte();
    @(negedge clk); re_n = 1'b0;
    repeat (2) @(negedge clk);
    rd = nand_dq_oe ? nand_dq_o : 8'hzz;
    rd_strobe = nand_dqs_oe && nand_dqs_o;
    re_n = 1'b1;
    repeat (2) @(negedge clk);
  endtask

  int busy;
  task automatic wait_rdy();
    int k;
    busy = 0; k = 0;
    while (rb_n === 1'b1 && k < 3) begin @(negedge clk); k++; end
    if (rb_n === 1'b1) begin busy = -1; return; end
    while (rb_n !== 1'b1 && busy < 200) begin @(negedge clk); busy++; end
  endtask

  logic [7:0] st;
  task automatic status();
    cmd(8'h70);
    repeat (3) @(negedge clk);
    st = nand_dq_oe ? nand_dq_o : 8'hzz;
  endtask

  // status = ready, fail as expected (READY in bit 6, or bit 5 as modelled)
  function automatic bit st_ok(input bit ready, input bit fail);
    return st[4:1] == 0 && st[7] == 0 && (st[6] | st[5]) == ready && st[0] == fail;
  endfunction

  function automatic logic [7:0] pat(input int i, input int seed);
    return 8'(seed * 17 + i * 5 + 3);
  endfunction

  task automatic prog(input [39:0] a, input int n, input int seed, input bit confirm_wait = 1);
    cmd(8'h80); addr5(a);
    for (int i = 0; i < n; i++) wbyte(pat(i, seed));
    cmd(8'h10);
    if (confirm_wait) wait_rdy();
  endtask

  logic [7:0] rbuf [0:63];
  bit         strobes_ok;
  task automatic read(input [39:0] a, input int n);
    cmd(8'h00); addr5(a); cmd(8'h30);
    wait_rdy();
    strobes_ok = 1;
    for (int i = 0; i < n; i++) begin rbyte(); rbuf[i] = rd; if (!rd_strobe) strobes_ok = 0; end
  endtask
  function automatic bit match(input int n, input int seed, input int from = 0);
    for (int i = 0; i < n; i++) if (rbuf[i] !== pat(from + i, seed)) return 0;
    return 1;
  endfunction
  function automatic bit all_ff(input int n);
    for (int i = 0; i < n; i++) if (rbuf[i] !== 8'hFF) return 0;
    return 1;
  endfunction

  task automatic erase(input [39:0] a);
    cmd(8'h60); addr5(a); cmd(8'hD0);
    wait_rdy();
  endtask

  localparam bit [39:0] P1 = 40'h00_0001_0000, P2 = 40'h00_0002_0000, P3 = 40'h00_0003_0000;

  initial begin
    repeat (3) @(negedge clk);
    chk(rb_n === 1'b1 && !nand_dq_oe && !nand_dqs_oe, "reset: ready, DQ / DQS not driven");
    rst_n = 1'b1;
    @(negedge clk);

    status();
    chk(st_ok(1, 0), "READ STATUS 70h: ready, no fail");
    chk_xfail(st == 8'h40, "status READY flag in bit 6 (40h)");

    // ---- program / read / erase ----
    prog(P1, 16, 1);
    chk(busy == 16, "program 80h-10h: R/B# low for 16 clocks");
    status();
    chk(st_ok(1, 0), "status after program: ready, pass");
    read(P1, 18);
    chk(busy == 8, "read 00h-30h: R/B# low for 8 clocks");
    chk(match(16, 1), "read returns the 16 programmed bytes");
    chk(rbuf[16] == 8'hFF && rbuf[17] == 8'hFF, "bytes past the programmed data read FFh");
    chk(strobes_ok, "NAND drives DQS high with every read byte");
    @(negedge clk);
    chk(!nand_dq_oe && !nand_dqs_oe, "DQ / DQS released after RE# rises");
    prog(P2, 32, 2);
    read(P2, 32);
    chk(match(32, 2), "full 32-byte page programmed and read back");
    read(P1, 4);
    chk(match(4, 1), "other page unaffected");
    erase(P1);
    chk(busy == 24, "erase 60h-D0h: R/B# low for 24 clocks");
    read(P1, 16);
    chk(all_ff(16), "erased page reads FFh");
    read(P2, 4);
    chk(match(4, 2), "erase leaves the next page intact");

    // ---- column addressing ----
    read(P2 + 5, 4);
    chk_xfail(match(4, 2, 5), "read at column 5 returns bytes 5..8 of the page");
    prog(P3 + 8, 4, 3);
    erase(P3);
    read(P3 + 8, 4);
    chk_xfail(all_ff(4), "erase clears data programmed at a non-zero column");

    // ---- data capture rules ----
    cmd(8'h80);
    latch(0, 8'h00); latch(0, 8'h00);
    wbyte(8'hAA);                             // before the address is complete
    latch(0, 8'h04); latch(0, 8'h00); latch(0, 8'h00);
    wbyte(8'h11);
    wbyte(8'h77, 0);                          // DQS without host_dq_oe
    wbyte(8'h22);
    cmd(8'h10);
    wait_rdy();
    read(40'h00_0004_0000, 3);
    chk(rbuf[0] == 8'h11 && rbuf[1] == 8'h22 && rbuf[2] == 8'hFF,
        "DQS before the 5th address byte or without host_dq_oe is ignored");
    // DDR: a byte on each DQS edge
    cmd(8'h80); addr5(40'h00_0005_0000);
    @(negedge clk); dq = 8'h31; host_dq_oe = 1;
    @(negedge clk); dqs = 1'b1;
    @(negedge clk); dq = 8'h32;
    @(negedge clk); dqs = 1'b0;
    @(negedge clk); host_dq_oe = 0;
    cmd(8'h10);
    wait_rdy();
    read(40'h00_0005_0000, 2);
    chk(rbuf[0] == 8'h31, "byte captured on the DQS rising edge");
    chk_xfail(rbuf[1] == 8'h32, "byte captured on the DQS falling edge (DDR)");

    // ---- busy / illegal commands ----
    prog(40'h00_0006_0000, 4, 6, 0);
    repeat (3) @(negedge clk);
    chk(rb_n === 1'b0, "busy after program confirm");
    cmd(8'h00);                               // READ while busy
    wait_rdy();
    status();
    chk(st_ok(1, 1), "READ latched while busy sets the fail bit");
    read(40'h00_0006_0000, 4);
    chk(match(4, 6), "the program in progress still completes");
    status();
    chk(st_ok(1, 0), "next READ clears the fail bit");
    cmd(8'h55);
    status();
    chk(st_ok(1, 1), "undefined opcode sets the fail bit");

    // ---- RESET during program ----
    prog(40'h00_0007_0000, 4, 7, 0);
    repeat (3) @(negedge clk);
    cmd(8'hFF);
    @(negedge clk);
    chk(rb_n === 1'b1, "RESET (FFh) ends the busy period");
    status();
    chk(st_ok(1, 0), "status after RESET: ready, no fail");
    cmd(8'h30);                               // confirm without a READ setup
    repeat (3) @(negedge clk);
    chk(rb_n === 1'b1, "30h after RESET (no 00h + address) does not start a read");
    cmd(8'h10);
    repeat (3) @(negedge clk);
    chk(rb_n === 1'b1, "10h without 80h does not start a program");
    read(40'h00_0007_0000, 4);
    chk(all_ff(4), "program aborted by RESET is not committed");

    // ---- status mode drives DQ only on RE# ----
    contention = 0;
    status();
    cmd(8'h00);                               // host drives DQ while in status mode
    chk_xfail(contention == 0, "NAND does not drive DQ while the host drives a command");

    // ---- reset pin ----
    prog(40'h00_0008_0000, 4, 8, 0);
    repeat (3) @(negedge clk);
    rst_n = 1'b0;
    @(negedge clk);
    chk(rb_n === 1'b1 && !nand_dq_oe, "reset pin: ready, DQ released");
    rst_n = 1'b1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
