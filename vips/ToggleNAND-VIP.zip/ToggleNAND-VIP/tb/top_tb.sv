// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- Toggle Mode NAND testbench top with a functional NAND
// array DUT model

`ifndef TNAND_TB_SV
`define TNAND_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import tnand_defs_pkg::*;
import tnand_pkg::*;
import tnand_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  tnand_if vif(clk);

  initial begin
    vif.rst_n = 0;
    vif.state = IDLE;
    #100ns;
    vif.rst_n = 1;
  end

  tnand_nand_model dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual tnand_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional Toggle NAND array model: latches commands/addresses on we_n
// rising edges (CLE/ALE), captures DQS-timed write data into a page
// buffer, serves re_n-timed read data from the array, models rb_n
// busy delays (tPROG / tR / tBERS) and drives the status register (0x70).
// Program/erase commands latched while busy are ignored and set the
// status fail bit; undefined opcodes also set the fail bit.
module tnand_nand_model (tnand_if vif);
  import tnand_defs_pkg::*;

  typedef enum bit [2:0] {OP_NONE, OP_READ, OP_PROG, OP_ERASE} op_e;

  bit [7:0]  mem [bit [39:0]];       // byte-addressable array (default 0xFF)
  op_e       op;
  bit [39:0] cur_addr;
  bit [39:0] prog_addr;
  int unsigned addr_cnt;
  bit [7:0]  wr_buf[$];
  int unsigned rd_idx;
  bit        busy;
  int unsigned busy_cnt;
  bit        status_mode;
  bit        fail;
  bit        we_n_d, re_n_d, dqs_d;

  function automatic bit [7:0] mem_read(input bit [39:0] a);
    return mem.exists(a) ? mem[a] : 8'hFF;
  endfunction

  // Commit buffered writes / erase when the busy delay expires
  task automatic commit_op();
    if (op == OP_PROG) begin
      foreach (wr_buf[i]) mem[prog_addr + i] = wr_buf[i];
      `uvm_info("DUT", $sformatf("programmed %0d bytes at 0x%010h",
                wr_buf.size(), prog_addr), UVM_HIGH)
    end else if (op == OP_ERASE) begin
      bit [39:0] base = {prog_addr[39:5], 5'b0};
      for (int i = 0; i < TNAND_PAGE_BYTES; i++) mem.delete(base + i);
      `uvm_info("DUT", $sformatf("erased page at 0x%010h", base), UVM_HIGH)
    end
  endtask

  // Command dispatch (executed on we_n rising edge with CLE high)
  task automatic handle_cmd(input bit [7:0] c);
    case (c)
      TNAND_CMD_STATUS: status_mode <= 1'b1;
      TNAND_CMD_RESET: begin
        op <= OP_NONE; busy <= 0; status_mode <= 0; fail <= 0;
        vif.rb_n <= 1'b1; wr_buf.delete();
      end
      TNAND_CMD_READ_PAGE, TNAND_CMD_PROG, TNAND_CMD_ERASE: begin
        if (busy) begin
          fail <= 1'b1;                    // command while busy: violation
          `uvm_warning("DUT", $sformatf("cmd 0x%02h latched while busy", c))
        end else begin
          op <= (c == TNAND_CMD_READ_PAGE) ? OP_READ :
                (c == TNAND_CMD_PROG)      ? OP_PROG : OP_ERASE;
          addr_cnt    <= 0;
          cur_addr    <= 40'h0;
          rd_idx      <= 0;
          fail        <= 0;
          status_mode <= 0;
          wr_buf.delete();
        end
      end
      TNAND_CMD_READ_CONFIRM: if (op == OP_READ && !busy) begin
        busy <= 1'b1; busy_cnt <= TNAND_T_R; vif.rb_n <= 1'b0;
        prog_addr <= cur_addr;
      end
      TNAND_CMD_PROG_CONFIRM: if (op == OP_PROG && !busy) begin
        busy <= 1'b1; busy_cnt <= TNAND_T_PROG; vif.rb_n <= 1'b0;
        prog_addr <= cur_addr;
      end
      TNAND_CMD_ERASE_CONFIRM: if (op == OP_ERASE && !busy) begin
        busy <= 1'b1; busy_cnt <= TNAND_T_BERS; vif.rb_n <= 1'b0;
        prog_addr <= cur_addr;
      end
      default: begin
        fail <= 1'b1;                      // illegal opcode
        status_mode <= 0;
        `uvm_warning("DUT", $sformatf("illegal cmd 0x%02h", c))
      end
    endcase
  endtask

  wire [7:0] status_val = {1'b0, ~busy, 4'b0, fail};   // bit6=ready, bit0=fail

  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      op <= OP_NONE; busy <= 0; busy_cnt <= 0; status_mode <= 0; fail <= 0;
      cur_addr <= 40'h0; prog_addr <= 40'h0; addr_cnt <= 0; rd_idx <= 0;
      we_n_d <= 1'b1; re_n_d <= 1'b1; dqs_d <= 1'b0;
      vif.rb_n <= 1'b1;
      vif.nand_dq_oe <= 1'b0; vif.nand_dq_o <= 8'h00;
      vif.nand_dqs_oe <= 1'b0; vif.nand_dqs_o <= 1'b0;
    end else begin
      we_n_d <= vif.we_n;
      re_n_d <= vif.re_n;
      dqs_d  <= vif.dqs;

      // busy countdown -> commit + ready
      if (busy) begin
        if (busy_cnt <= 1) begin
          busy <= 1'b0;
          vif.rb_n <= 1'b1;
          commit_op();
        end else busy_cnt <= busy_cnt - 1;
      end

      // command / address latch on we_n rising edge
      if (we_n_d == 1'b0 && vif.we_n == 1'b1 && vif.ce_n == 1'b0) begin
        if (vif.cle)          handle_cmd(vif.dq);
        else if (vif.ale) begin
          cur_addr <= {cur_addr[31:0], vif.dq};
          addr_cnt <= addr_cnt + 1;
        end
      end

      // write data capture on dqs rising edge (after 5 address cycles)
      if (dqs_d == 1'b0 && vif.dqs == 1'b1 && op == OP_PROG &&
          addr_cnt >= TNAND_ADDR_CYCLES && !busy && vif.host_dq_oe)
        wr_buf.push_back(vif.dq);

      // dq/dqs output ownership
      if (status_mode && vif.ce_n == 1'b0) begin
        vif.nand_dq_oe  <= 1'b1;
        vif.nand_dq_o   <= status_val;
        vif.nand_dqs_oe <= 1'b0;
      end else if (op == OP_READ && !busy && addr_cnt >= TNAND_ADDR_CYCLES &&
                   re_n_d == 1'b1 && vif.re_n == 1'b0) begin
        // re_n fell: serve next read byte + dqs strobe
        vif.nand_dq_o   <= mem_read(prog_addr + rd_idx);
        vif.nand_dq_oe  <= 1'b1;
        vif.nand_dqs_oe <= 1'b1;
        vif.nand_dqs_o  <= 1'b1;
        rd_idx <= rd_idx + 1;
      end else if (re_n_d == 1'b0 && vif.re_n == 1'b1) begin
        // re_n rose: release the bus
        vif.nand_dq_oe  <= 1'b0;
        vif.nand_dqs_oe <= 1'b0;
        vif.nand_dqs_o  <= 1'b0;
      end
    end
  end
endmodule
`endif
