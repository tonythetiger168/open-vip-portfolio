// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_if.sv -- Toggle Mode NAND interface
//
// dq/dqs are shared bidirectional lines. Host (controller) drives
// cle/ale/ce_n/we_n/re_n and owns dq/dqs during command, address and
// data-write phases; the NAND owns dq/dqs during data-read and status
// phases and drives rb_n. Ownership is resolved through *_oe/*_o pairs.

interface tnand_if (input logic clk);
  import tnand_defs_pkg::tnand_state_e;

  logic rst_n;
  logic dqs;
  logic [7:0] dq;
  logic cle;
  logic ale;
  logic ce_n;
  logic we_n;
  logic re_n;
  logic rb_n;

  tnand_state_e state;      // host controller phase marker

  // Drive resolution for the shared dq/dqs lines
  logic       host_dq_oe;
  logic [7:0] host_dq_o;
  logic       nand_dq_oe;
  logic [7:0] nand_dq_o;
  logic       host_dqs_oe;
  logic       host_dqs_o;
  logic       nand_dqs_oe;
  logic       nand_dqs_o;

  assign dq  = host_dq_oe  ? host_dq_o  : (nand_dq_oe  ? nand_dq_o  : 8'hzz);
  assign dqs = host_dqs_oe ? host_dqs_o : (nand_dqs_oe ? nand_dqs_o : 1'bz);

  modport HOST (input  clk, rst_n, rb_n, dq,
                output cle, ale, ce_n, we_n, re_n, state,
                host_dq_oe, host_dq_o, host_dqs_oe, host_dqs_o);
  modport NAND (input  clk, rst_n, cle, ale, ce_n, we_n, re_n, dq, dqs,
                host_dq_oe,
                output rb_n, nand_dq_oe, nand_dq_o, nand_dqs_oe, nand_dqs_o);
  modport MON  (input  clk, rst_n, state, cle, ale, ce_n, we_n, re_n, rb_n,
                dq, dqs, host_dq_oe, nand_dq_oe);

  clocking drv_cb @(posedge clk);
    input  rst_n, rb_n, dq;
    output cle, ale, ce_n, we_n, re_n,
           host_dq_oe, host_dq_o, host_dqs_oe, host_dqs_o;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, state, cle, ale, ce_n, we_n, re_n, rb_n, dq, dqs,
          host_dq_oe, nand_dq_oe;
  endclocking
endinterface
