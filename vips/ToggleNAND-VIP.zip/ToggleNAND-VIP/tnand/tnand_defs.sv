// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_defs.sv -- Toggle Mode NAND shared type definitions

package tnand_defs_pkg;
  typedef enum bit [2:0] {
    IDLE,
    CMD_LATCH,
    ADDR_LATCH,
    DATA_WRITE,
    DATA_READ,
    STATUS_READ
  } tnand_state_e;

  // ---- ONFI/Toggle-style command opcodes ----
  localparam bit [7:0] TNAND_CMD_READ_PAGE     = 8'h00;  // read page (cycle 1)
  localparam bit [7:0] TNAND_CMD_READ_CONFIRM  = 8'h30;  // read confirm
  localparam bit [7:0] TNAND_CMD_PROG          = 8'h80;  // page program (cycle 1)
  localparam bit [7:0] TNAND_CMD_PROG_CONFIRM  = 8'h10;  // program confirm
  localparam bit [7:0] TNAND_CMD_ERASE         = 8'h60;  // block erase (cycle 1)
  localparam bit [7:0] TNAND_CMD_ERASE_CONFIRM = 8'hD0;  // erase confirm
  localparam bit [7:0] TNAND_CMD_STATUS        = 8'h70;  // status read
  localparam bit [7:0] TNAND_CMD_RESET         = 8'hFF;  // device reset

  // ---- Array model parameters (in clk cycles / bytes) ----
  localparam int unsigned TNAND_ADDR_CYCLES = 5;   // 5-byte address cycle
  localparam int unsigned TNAND_T_PROG      = 16;  // busy time after program confirm
  localparam int unsigned TNAND_T_R         = 8;   // busy time after read confirm
  localparam int unsigned TNAND_T_BERS      = 24;  // busy time after erase confirm
  localparam int unsigned TNAND_MAX_DATA    = 32;  // max data bytes per op
  localparam int unsigned TNAND_PAGE_BYTES  = 32;  // erase page size

  // ---- Status register bit map ----
  localparam int unsigned TNAND_ST_FAIL  = 0;  // bit 0: fail
  localparam int unsigned TNAND_ST_READY = 6;  // bit 6: ready (not busy)
endpackage
