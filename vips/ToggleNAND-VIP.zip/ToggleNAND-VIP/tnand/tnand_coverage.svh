// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_coverage.svh -- Toggle NAND functional coverage: protocol
// (command x length cross), host FSM, and error-injection coverage.

class tnand_coverage extends uvm_subscriber #(tnand_transaction);
  `uvm_component_utils(tnand_coverage)

  tnand_transaction tr;
  tnand_state_e cur_state;

  covergroup cg_protocol;
    cp_cmd : coverpoint tr.cmd {
      bins read    = {tnand_defs_pkg::TNAND_CMD_READ_PAGE};
      bins prog    = {tnand_defs_pkg::TNAND_CMD_PROG};
      bins erase   = {tnand_defs_pkg::TNAND_CMD_ERASE};
      bins status  = {tnand_defs_pkg::TNAND_CMD_STATUS};
      bins illegal = default;
    }
    cp_addr : coverpoint tr.addr[39:32] {
      bins low  = {[8'h00 : 8'h3F]};
      bins mid  = {[8'h40 : 8'hBF]};
      bins high = {[8'hC0 : 8'hFF]};
    }
    cp_len  : coverpoint tr.data.size() {
      bins single = {1};
      bins short  = {[2:8]};
      bins mid    = {[9:31]};
      bins page   = {tnand_defs_pkg::TNAND_MAX_DATA};
    }
    cp_data0 : coverpoint tr.data[0] iff (tr.data.size() > 0) {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins data = default;
    }
    cx_cmd_len : cross cp_cmd, cp_len;
  endgroup

  covergroup cg_fsm with function sample(tnand_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, CMD_LATCH, ADDR_LATCH, DATA_WRITE, DATA_READ, STATUS_READ};
    }
    cp_trans : coverpoint s {
      bins prog_flow = (CMD_LATCH => ADDR_LATCH => DATA_WRITE);
      bins rd_flow   = (DATA_WRITE => DATA_READ => STATUS_READ);
      bins op_done   = (STATUS_READ => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.error_inject {
      bins none    = {tnand_transaction::TNAND_ERR_NONE};
      bins busy    = {tnand_transaction::TNAND_ERR_BUSY};
      bins illegal = {tnand_transaction::TNAND_ERR_ILLEGAL};
    }
    cp_busy_viol  : coverpoint tr.busy_violation { bins no = {0}; bins yes = {1}; }
    cp_illegal    : coverpoint tr.illegal_cmd    { bins no = {0}; bins yes = {1}; }
    cp_st_fail    : coverpoint tr.status[tnand_defs_pkg::TNAND_ST_FAIL]
                      iff (tr.status !== 8'hxx) { bins pass = {0}; bins fail = {1}; }
    cx_err_fail : cross cp_err, cp_st_fail;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(tnand_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_fsm.sample(cur_state);
    cg_error.sample();
  endfunction
endclass
