// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_timing_checker.sv -- Toggle Mode NAND timing parameter checker

`ifndef TNAND_TIMING_CHECKER_SV
`define TNAND_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import tnand_defs_pkg::tnand_state_e;

module tnand_timing_checker
(
  input logic clk,
  input logic rst_n,
  input tnand_state_e state
);
  a_tnand_timing_state_known : assert property (@(posedge clk)
    disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("TIMING", "tnand timing: state unknown")
endmodule
`endif
