// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_driver.svh -- Toggle NAND host (controller) driver. Drives CLE/ALE
// command and address latches (we_n pulses), DQS-timed DDR write data,
// re_n-timed read data sampling, rb_n ready/busy polling and closing
// status reads (0x70). Publishes expected transactions on drv_ap.

class tnand_driver extends uvm_driver #(tnand_transaction);
  `uvm_component_utils(tnand_driver)
  virtual tnand_if vif;
  tnand_config cfg;
  uvm_analysis_port #(tnand_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual tnand_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tnand virtual interface not set")
  endfunction

  // ---------------- bus primitives ----------------
  task automatic bus_idle();
    vif.drv_cb.cle         <= 1'b0;
    vif.drv_cb.ale         <= 1'b0;
    vif.drv_cb.ce_n        <= 1'b1;
    vif.drv_cb.we_n        <= 1'b1;
    vif.drv_cb.re_n        <= 1'b1;
    vif.drv_cb.host_dq_oe  <= 1'b0;
    vif.drv_cb.host_dq_o   <= 8'h00;
    vif.drv_cb.host_dqs_oe <= 1'b0;
    vif.drv_cb.host_dqs_o  <= 1'b0;
  endtask

  // Command latch: CLE high, we_n pulse, NAND latches on we_n rising edge
  task automatic latch_cmd(input bit [7:0] c);
    vif.drv_cb.ce_n <= 1'b0;
    vif.drv_cb.cle  <= 1'b1;
    vif.drv_cb.host_dq_o  <= c;
    vif.drv_cb.host_dq_oe <= 1'b1;
    @(vif.drv_cb);
    vif.drv_cb.we_n <= 1'b0;
    @(vif.drv_cb);
    vif.drv_cb.we_n <= 1'b1;          // latch point
    @(vif.drv_cb);
    vif.drv_cb.cle <= 1'b0;
    vif.drv_cb.host_dq_oe <= 1'b0;
    @(vif.drv_cb);
  endtask

  // Address latch: ALE high, we_n pulse
  task automatic latch_addr(input bit [7:0] a);
    vif.drv_cb.ce_n <= 1'b0;
    vif.drv_cb.ale  <= 1'b1;
    vif.drv_cb.host_dq_o  <= a;
    vif.drv_cb.host_dq_oe <= 1'b1;
    @(vif.drv_cb);
    vif.drv_cb.we_n <= 1'b0;
    @(vif.drv_cb);
    vif.drv_cb.we_n <= 1'b1;          // latch point
    @(vif.drv_cb);
    vif.drv_cb.ale <= 1'b0;
    vif.drv_cb.host_dq_oe <= 1'b0;
    @(vif.drv_cb);
  endtask

  // DDR write data: host drives dq + dqs strobe (1 byte per dqs pulse)
  task automatic write_data_byte(input bit [7:0] d);
    vif.drv_cb.ce_n <= 1'b0;
    vif.drv_cb.host_dq_o  <= d;
    vif.drv_cb.host_dq_oe <= 1'b1;
    @(vif.drv_cb);
    vif.drv_cb.host_dqs_oe <= 1'b1;
    vif.drv_cb.host_dqs_o  <= 1'b1;   // NAND samples dq on dqs rising
    @(vif.drv_cb);
    vif.drv_cb.host_dqs_o  <= 1'b0;
    vif.drv_cb.host_dq_oe  <= 1'b0;
    vif.drv_cb.host_dqs_oe <= 1'b0;
    @(vif.drv_cb);
  endtask

  // Read data: host pulses re_n, NAND drives dq + dqs
  task automatic read_data_byte(output bit [7:0] d);
    vif.drv_cb.ce_n <= 1'b0;
    vif.drv_cb.re_n <= 1'b0;
    @(vif.drv_cb);
    @(vif.drv_cb);
    d = vif.dq;                        // NAND byte valid
    vif.drv_cb.re_n <= 1'b1;
    @(vif.drv_cb);
    @(vif.drv_cb);
  endtask

  task automatic wait_ready();
    wait (vif.rb_n === 1'b1);
    repeat (2) @(vif.drv_cb);
  endtask

  // Status read (0x70): NAND drives the status register on dq
  task automatic read_status(output bit [7:0] s);
    latch_cmd(tnand_defs_pkg::TNAND_CMD_STATUS);
    vif.state = tnand_defs_pkg::STATUS_READ;
    repeat (3) @(vif.drv_cb);
    s = vif.dq;
    repeat (2) @(vif.drv_cb);
  endtask

  task automatic latch_5byte_addr(input bit [39:0] a);
    vif.state = tnand_defs_pkg::ADDR_LATCH;
    for (int i = 0; i < tnand_defs_pkg::TNAND_ADDR_CYCLES; i++)
      latch_addr(a[8*i +: 8]);
  endtask

  // ---------------- operation flows ----------------
  // Page program: 80h + addr + data-in + 10h (+ optional busy violation) + status
  task automatic do_program(tnand_transaction tr);
    vif.state = tnand_defs_pkg::CMD_LATCH;
    latch_cmd(tnand_defs_pkg::TNAND_CMD_PROG);
    latch_5byte_addr(tr.addr);
    vif.state = tnand_defs_pkg::DATA_WRITE;
    foreach (tr.data[i]) write_data_byte(tr.data[i]);
    latch_cmd(tnand_defs_pkg::TNAND_CMD_PROG_CONFIRM);   // busy starts
    vif.state = tnand_defs_pkg::DATA_READ;               // busy-wait phase
    if (tr.error_inject == tnand_transaction::TNAND_ERR_BUSY) begin
      latch_cmd(tnand_defs_pkg::TNAND_CMD_PROG);         // violation: no rb_n wait
      tr.busy_violation = 1;
      `uvm_warning("DRV", "program issued while rb_n busy (error injection)")
    end
    wait_ready();
    read_status(tr.status);
  endtask

  // Page read: 00h + addr + 30h + busy + DDR data-out + status
  task automatic do_read(tnand_transaction tr);
    bit [7:0] d;
    vif.state = tnand_defs_pkg::CMD_LATCH;
    latch_cmd(tnand_defs_pkg::TNAND_CMD_READ_PAGE);
    latch_5byte_addr(tr.addr);
    vif.state = tnand_defs_pkg::DATA_WRITE;              // pass-through phase
    latch_cmd(tnand_defs_pkg::TNAND_CMD_READ_CONFIRM);   // busy starts
    wait_ready();
    vif.state = tnand_defs_pkg::DATA_READ;
    for (int i = 0; i < tr.data.size(); i++) begin       // data.size() = read length
      read_data_byte(d);
      tr.rdata.push_back(d);
    end
    read_status(tr.status);
  endtask

  // Block erase: 60h + addr + D0h + busy + status
  task automatic do_erase(tnand_transaction tr);
    vif.state = tnand_defs_pkg::CMD_LATCH;
    latch_cmd(tnand_defs_pkg::TNAND_CMD_ERASE);
    latch_5byte_addr(tr.addr);
    vif.state = tnand_defs_pkg::DATA_WRITE;              // pass-through phase
    latch_cmd(tnand_defs_pkg::TNAND_CMD_ERASE_CONFIRM);  // busy starts
    wait_ready();
    vif.state = tnand_defs_pkg::DATA_READ;               // pass-through phase
    repeat (2) @(vif.drv_cb);
    read_status(tr.status);
  endtask

  // Status-only operation
  task automatic do_status(tnand_transaction tr);
    vif.state = tnand_defs_pkg::CMD_LATCH;
    latch_cmd(tnand_defs_pkg::TNAND_CMD_STATUS);
    vif.state = tnand_defs_pkg::ADDR_LATCH;              // pass-through phases
    repeat (2) @(vif.drv_cb);
    vif.state = tnand_defs_pkg::DATA_WRITE;
    repeat (2) @(vif.drv_cb);
    vif.state = tnand_defs_pkg::DATA_READ;
    repeat (2) @(vif.drv_cb);
    vif.state = tnand_defs_pkg::STATUS_READ;
    repeat (3) @(vif.drv_cb);
    tr.status = vif.dq;
    repeat (2) @(vif.drv_cb);
  endtask

  // Illegal opcode injection: latch undefined command, then read status
  task automatic do_illegal(tnand_transaction tr);
    vif.state = tnand_defs_pkg::CMD_LATCH;
    latch_cmd(tr.cmd);                                   // undefined opcode
    tr.illegal_cmd = 1;
    `uvm_warning("DRV", $sformatf("illegal cmd 0x%02h latched (error injection)", tr.cmd))
    vif.state = tnand_defs_pkg::ADDR_LATCH;              // pass-through phases
    repeat (2) @(vif.drv_cb);
    vif.state = tnand_defs_pkg::DATA_WRITE;
    repeat (2) @(vif.drv_cb);
    vif.state = tnand_defs_pkg::DATA_READ;
    repeat (2) @(vif.drv_cb);
    read_status(tr.status);
  endtask

  task run_phase(uvm_phase phase);
    tnand_transaction tr;
    bus_idle();
    vif.state = tnand_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    wait (vif.rb_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      if (tr.error_inject == tnand_transaction::TNAND_ERR_ILLEGAL)
        do_illegal(tr);
      else begin
        case (tr.cmd)
          tnand_defs_pkg::TNAND_CMD_READ_PAGE: do_read(tr);
          tnand_defs_pkg::TNAND_CMD_PROG:      do_program(tr);
          tnand_defs_pkg::TNAND_CMD_ERASE:     do_erase(tr);
          default:                           do_status(tr);
        endcase
      end
      vif.state = tnand_defs_pkg::IDLE;
      bus_idle();
      repeat (2) @(vif.drv_cb);
      drv_ap.write(tr);                    // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask

endclass
