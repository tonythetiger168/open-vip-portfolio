// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_compliance_checker.sv -- Toggle Mode NAND SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = Toggle NAND specific rules

`ifndef TNAND_COMPLIANCE_CHECKER_SV
`define TNAND_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import tnand_defs_pkg::*;

module tnand_compliance_checker
(
  input logic clk,
  input logic rst_n,
  input tnand_state_e state,
  input logic cle,
  input logic ale,
  input logic ce_n,
  input logic we_n,
  input logic re_n,
  input logic rb_n,
  input logic [7:0] dq
);

  // ---------------- L1: signal sanity (4) ----------------
  a_tnand_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "tnand: clock unknown")
  a_tnand_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "tnand: reset unknown")
  a_tnand_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "tnand: state unknown")
  a_tnand_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, CMD_LATCH, ADDR_LATCH, DATA_WRITE, DATA_READ, STATUS_READ})
    else `uvm_error("SVA_L1", "tnand: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from IDLE
  a_tnand_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, CMD_LATCH})
    else `uvm_error("SVA_L2", "tnand: illegal transition from IDLE")

  // L2-2: legal FSM transition from CMD_LATCH
  a_tnand_trans_cmd_latch : assert property (@(posedge clk) disable iff (!rst_n)
    state == CMD_LATCH |=> state inside {CMD_LATCH, ADDR_LATCH})
    else `uvm_error("SVA_L2", "tnand: illegal transition from CMD_LATCH")

  // L2-3: legal FSM transition from ADDR_LATCH
  a_tnand_trans_addr_latch : assert property (@(posedge clk) disable iff (!rst_n)
    state == ADDR_LATCH |=> state inside {ADDR_LATCH, DATA_WRITE})
    else `uvm_error("SVA_L2", "tnand: illegal transition from ADDR_LATCH")

  // L2-4: legal FSM transition from DATA_WRITE
  a_tnand_trans_data_write : assert property (@(posedge clk) disable iff (!rst_n)
    state == DATA_WRITE |=> state inside {DATA_WRITE, DATA_READ})
    else `uvm_error("SVA_L2", "tnand: illegal transition from DATA_WRITE")

  // L2-5: legal FSM transition from DATA_READ
  a_tnand_trans_data_read : assert property (@(posedge clk) disable iff (!rst_n)
    state == DATA_READ |=> state inside {DATA_READ, STATUS_READ})
    else `uvm_error("SVA_L2", "tnand: illegal transition from DATA_READ")

  // L2-6: legal FSM transition from STATUS_READ
  a_tnand_trans_status_read : assert property (@(posedge clk) disable iff (!rst_n)
    state == STATUS_READ |=> state inside {STATUS_READ, IDLE})
    else `uvm_error("SVA_L2", "tnand: illegal transition from STATUS_READ")

  // ---------------- L3: protocol rules (4) ----------------
  a_tnand_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "tnand: state not IDLE during reset")
  a_tnand_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == STATUS_READ |-> ##[1:8] (state != STATUS_READ))
    else `uvm_error("SVA_L3", "tnand: stuck in STATUS_READ")
  a_tnand_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == CMD_LATCH);
  a_tnand_l3_back_idle  : cover property (@(posedge clk) disable iff (!rst_n)
    state == STATUS_READ ##1 state == IDLE);

  // ---------------- L4: Toggle NAND specific rules (5) ----------------
  // L4-1: CLE and ALE are mutually exclusive
  a_tnand_l4_cle_ale_mutex : assert property (@(posedge clk) disable iff (!rst_n)
    cle |-> !ale)
    else `uvm_error("SVA_L4", "tnand: CLE and ALE asserted simultaneously")

  // L4-2: we_n latch pulse width is bounded
  a_tnand_l4_we_pulse : assert property (@(posedge clk) disable iff (!rst_n)
    $fell(we_n) |-> ##[1:4] $rose(we_n))
    else `uvm_error("SVA_L4", "tnand: we_n pulse width out of bounds")

  // L4-3: while rb_n busy only status (70h) / reset (FFh) may be latched
  a_tnand_l4_busy_cmds : assert property (@(posedge clk) disable iff (!rst_n)
    (!rb_n && $rose(cle)) |-> (dq inside {TNAND_CMD_STATUS, TNAND_CMD_RESET}))
    else `uvm_error("SVA_L4", "tnand: data command latched while NAND busy")

  // L4-4: program (10h) / erase (D0h) confirm must be followed by a status read
  a_tnand_l4_status_after_prog : assert property (@(posedge clk) disable iff (!rst_n)
    ($rose(cle) && (dq inside {TNAND_CMD_PROG_CONFIRM, TNAND_CMD_ERASE_CONFIRM}))
      |-> s_eventually ($rose(cle) && dq == TNAND_CMD_STATUS))
    else `uvm_error("SVA_L4", "tnand: no status read after program/erase")

  // L4-5: command latch requires the chip to be selected
  a_tnand_l4_cmd_ce : assert property (@(posedge clk) disable iff (!rst_n)
    $rose(cle) |-> !ce_n)
    else `uvm_error("SVA_L4", "tnand: command latched with ce_n high")

endmodule
`endif
