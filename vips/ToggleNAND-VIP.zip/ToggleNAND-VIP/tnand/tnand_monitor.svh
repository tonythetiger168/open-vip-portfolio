// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_monitor.svh -- Toggle NAND monitor: clk-synchronous decode of the
// command/address latches (we_n edges), DQS-timed data phases (direction
// from dq ownership), rb_n busy tracking and status reads; publishes one
// reconstructed transaction per NAND operation.

class tnand_monitor extends uvm_monitor;
  `uvm_component_utils(tnand_monitor)
  virtual tnand_if vif;
  uvm_analysis_port #(tnand_transaction) ap;
  int unsigned txn_count = 0;

  protected tnand_transaction cur;
  protected bit          pending = 0;
  protected int unsigned addr_cnt = 0;
  protected int          status_cnt = -1;   // clks until status sample
  protected bit          we_n_d = 1, dqs_d = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual tnand_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "tnand virtual interface not set")
  endfunction

  function bit is_op_start(input bit [7:0] c);
    return c inside {tnand_defs_pkg::TNAND_CMD_READ_PAGE,
                     tnand_defs_pkg::TNAND_CMD_PROG,
                     tnand_defs_pkg::TNAND_CMD_ERASE};
  endfunction

  function bit is_legal(input bit [7:0] c);
    return c inside {tnand_defs_pkg::TNAND_CMD_READ_PAGE,
                     tnand_defs_pkg::TNAND_CMD_READ_CONFIRM,
                     tnand_defs_pkg::TNAND_CMD_PROG,
                     tnand_defs_pkg::TNAND_CMD_PROG_CONFIRM,
                     tnand_defs_pkg::TNAND_CMD_ERASE,
                     tnand_defs_pkg::TNAND_CMD_ERASE_CONFIRM,
                     tnand_defs_pkg::TNAND_CMD_STATUS,
                     tnand_defs_pkg::TNAND_CMD_RESET};
  endfunction

  function void new_txn(input bit [7:0] c);
    cur = tnand_transaction::type_id::create("cur");
    cur.cmd = c;
    pending = 1;
    addr_cnt = 0;
  endfunction

  function void publish();
    if (!pending) return;
    if (cur.illegal_cmd)         cur.error_inject = tnand_transaction::TNAND_ERR_ILLEGAL;
    else if (cur.busy_violation) cur.error_inject = tnand_transaction::TNAND_ERR_BUSY;
    else                         cur.error_inject = tnand_transaction::TNAND_ERR_NONE;
    txn_count++;
    `uvm_info("MON", {"mon: ", cur.convert2string()}, UVM_HIGH)
    ap.write(cur);
    pending = 0;
  endfunction

  function void cmd_latch(input bit [7:0] c);
    if (is_op_start(c)) begin
      if (!vif.mon_cb.rb_n) begin
        // Command latched while NAND busy: protocol violation on current op
        if (pending) cur.busy_violation = 1;
      end else begin
        new_txn(c);                    // start of a fresh operation
      end
    end else if (c == tnand_defs_pkg::TNAND_CMD_STATUS) begin
      if (!pending) new_txn(c);        // status-only operation
      status_cnt = 3;                  // sample dq 3 clks later
    end else if (!is_legal(c)) begin
      if (!pending) new_txn(c);
      cur.illegal_cmd = 1;
      cur.cmd = c;
    end
    // confirm opcodes (30/10/D0) and reset (FF): phase markers, no action
  endfunction

  task run_phase(uvm_phase phase);
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        pending = 0; status_cnt = -1; we_n_d = 1; dqs_d = 0;
        continue;
      end

      // ---- command / address latch on we_n rising edge ----
      if (we_n_d == 1'b0 && vif.mon_cb.we_n == 1'b1 && vif.mon_cb.ce_n == 1'b0) begin
        if (vif.mon_cb.cle)      cmd_latch(vif.mon_cb.dq);
        else if (vif.mon_cb.ale && pending && addr_cnt < tnand_defs_pkg::TNAND_ADDR_CYCLES) begin
          cur.addr = {cur.addr[31:0], vif.mon_cb.dq};
          addr_cnt++;
        end
      end

      // ---- data transfer on dqs rising edge; direction from dq ownership ----
      if (dqs_d == 1'b0 && vif.mon_cb.dqs == 1'b1 && pending) begin
        if (vif.mon_cb.host_dq_oe)      cur.data.push_back(vif.mon_cb.dq);   // write
        else if (vif.mon_cb.nand_dq_oe) cur.rdata.push_back(vif.mon_cb.dq);  // read
      end

      // ---- status sample + publish ----
      if (status_cnt > 0) status_cnt--;
      else if (status_cnt == 0) begin
        cur.status = vif.mon_cb.dq;
        status_cnt = -1;
        publish();
      end

      we_n_d = vif.mon_cb.we_n;
      dqs_d  = vif.mon_cb.dqs;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("tnand monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
