// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_pkg.sv -- Toggle Mode NAND UVM VIP package

package tnand_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import tnand_defs_pkg::*;
  export tnand_defs_pkg::*;

  `include "tnand_transaction.svh"
  `include "tnand_config.svh"
  `include "tnand_sequencer.svh"
  `include "tnand_driver.svh"
  `include "tnand_monitor.svh"
  `include "tnand_agent.svh"
  `include "tnand_sequences.svh"
  `include "tnand_checker.svh"
  `include "tnand_coverage.svh"
endpackage
