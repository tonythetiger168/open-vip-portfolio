// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_sequences.svh -- Toggle NAND sequence library: each item is one
// complete NAND operation incl. address cycle, data phase and status read.

class tnand_base_sequence extends uvm_sequence #(tnand_transaction);
  `uvm_object_utils(tnand_base_sequence)
  int num_txns = 20;
  function new(string name = "tnand_base_sequence"); super.new(name); endfunction
  task body();
    tnand_transaction tr;
    repeat (num_txns) begin
      tr = tnand_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: page reads (00h + 30h), varying read lengths
class tnand_read_seq extends tnand_base_sequence;
  `uvm_object_utils(tnand_read_seq)
  function new(string name = "tnand_read_seq"); super.new(name); endfunction
  task body();
    tnand_transaction tr;
    repeat (num_txns) begin
      tr = tnand_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == tnand_defs_pkg::TNAND_CMD_READ_PAGE;
                                  error_inject == TNAND_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: page programs (80h + data + 10h)
class tnand_program_seq extends tnand_base_sequence;
  `uvm_object_utils(tnand_program_seq)
  function new(string name = "tnand_program_seq"); super.new(name); endfunction
  task body();
    tnand_transaction tr;
    repeat (num_txns) begin
      tr = tnand_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == tnand_defs_pkg::TNAND_CMD_PROG;
                                  error_inject == TNAND_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: block erases (60h + D0h)
class tnand_erase_seq extends tnand_base_sequence;
  `uvm_object_utils(tnand_erase_seq)
  function new(string name = "tnand_erase_seq"); super.new(name); endfunction
  task body();
    tnand_transaction tr;
    repeat (num_txns) begin
      tr = tnand_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == tnand_defs_pkg::TNAND_CMD_ERASE;
                                  error_inject == TNAND_ERR_NONE;
                                  data.size() == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: status reads (70h) interleaved with array ops
class tnand_status_seq extends tnand_base_sequence;
  `uvm_object_utils(tnand_status_seq)
  function new(string name = "tnand_status_seq"); super.new(name); endfunction
  task body();
    tnand_transaction tr;
    repeat (num_txns) begin
      tr = tnand_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == tnand_defs_pkg::TNAND_CMD_STATUS;
                                  error_inject == TNAND_ERR_NONE;
                                  data.size() == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: program issued without waiting for rb_n (busy violation)
class tnand_busy_violation_seq extends tnand_base_sequence;
  `uvm_object_utils(tnand_busy_violation_seq)
  function new(string name = "tnand_busy_violation_seq"); super.new(name); endfunction
  task body();
    tnand_transaction tr;
    repeat (num_txns) begin
      tr = tnand_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cmd == tnand_defs_pkg::TNAND_CMD_PROG;
                                  error_inject == TNAND_ERR_BUSY; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: undefined opcode latched
class tnand_illegal_cmd_seq extends tnand_base_sequence;
  `uvm_object_utils(tnand_illegal_cmd_seq)
  function new(string name = "tnand_illegal_cmd_seq"); super.new(name); endfunction
  task body();
    tnand_transaction tr;
    repeat (num_txns) begin
      tr = tnand_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == TNAND_ERR_ILLEGAL;
                                  !(cmd inside {tnand_defs_pkg::TNAND_CMD_READ_PAGE,
                                                tnand_defs_pkg::TNAND_CMD_READ_CONFIRM,
                                                tnand_defs_pkg::TNAND_CMD_PROG,
                                                tnand_defs_pkg::TNAND_CMD_PROG_CONFIRM,
                                                tnand_defs_pkg::TNAND_CMD_ERASE,
                                                tnand_defs_pkg::TNAND_CMD_ERASE_CONFIRM,
                                                tnand_defs_pkg::TNAND_CMD_STATUS,
                                                tnand_defs_pkg::TNAND_CMD_RESET}); });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: one program op right after reset release
class tnand_reset_seq extends tnand_base_sequence;
  `uvm_object_utils(tnand_reset_seq)
  function new(string name = "tnand_reset_seq"); super.new(name); endfunction
  task body();
    tnand_transaction tr = tnand_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { cmd == tnand_defs_pkg::TNAND_CMD_PROG;
                                error_inject == TNAND_ERR_NONE;
                                data.size() == 1; });
    finish_item(tr);
  endtask
endclass

class tnand_random_sequence extends tnand_base_sequence;
  `uvm_object_utils(tnand_random_sequence)
  function new(string name = "tnand_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class tnand_regression_sequence extends tnand_base_sequence;
  `uvm_object_utils(tnand_regression_sequence)
  function new(string name = "tnand_regression_sequence"); super.new(name); endfunction
  task body();
    tnand_read_seq           rd  = tnand_read_seq::type_id::create("rd");
    tnand_program_seq        wr  = tnand_program_seq::type_id::create("wr");
    tnand_erase_seq          er  = tnand_erase_seq::type_id::create("er");
    tnand_status_seq         st  = tnand_status_seq::type_id::create("st");
    tnand_busy_violation_seq bsy = tnand_busy_violation_seq::type_id::create("bsy");
    tnand_illegal_cmd_seq    ill = tnand_illegal_cmd_seq::type_id::create("ill");
    rd.num_txns = 15; wr.num_txns = 15; er.num_txns = 6;
    st.num_txns = 6;  bsy.num_txns = 4; ill.num_txns = 4;
    rd.start(m_sequencer);  wr.start(m_sequencer);
    er.start(m_sequencer);  st.start(m_sequencer);
    bsy.start(m_sequencer); ill.start(m_sequencer);
  endtask
endclass
