// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// tnand_transaction.svh -- Toggle NAND transaction: one NAND operation
// (read page / page program / block erase / status read) including its
// 5-byte address cycle, data phase and closing status read.

class tnand_transaction extends uvm_sequence_item;

  // Error-injection knobs
  typedef enum bit [1:0] {
    TNAND_ERR_NONE,     // legal operation
    TNAND_ERR_BUSY,     // program issued again while rb_n busy (no wait)
    TNAND_ERR_ILLEGAL   // undefined opcode latched
  } tnand_err_e;

  rand bit [7:0]  cmd;          // op-start command (00/80/60/70)
  rand bit [39:0] addr;         // 5-byte column+row address
  rand bit [7:0]  data[$];      // program data (write length for reads)
  rand tnand_err_e error_inject;

  // Observed by monitor / driver (not randomized)
  bit [7:0] status;             // status register read at end of op
  bit [7:0] rdata[$];           // data read from the array (read op)
  bit       busy_violation;     // command latched while rb_n was low
  bit       illegal_cmd;        // undefined opcode latched

  constraint c_cmd { soft cmd inside {tnand_defs_pkg::TNAND_CMD_READ_PAGE,
                                      tnand_defs_pkg::TNAND_CMD_PROG,
                                      tnand_defs_pkg::TNAND_CMD_ERASE,
                                      tnand_defs_pkg::TNAND_CMD_STATUS}; }
  constraint c_len { data.size() inside {[1:tnand_defs_pkg::TNAND_MAX_DATA]}; }
  constraint c_err { error_inject dist {TNAND_ERR_NONE    := 7,
                                        TNAND_ERR_BUSY    := 2,
                                        TNAND_ERR_ILLEGAL := 1}; }

  `uvm_object_utils_begin(tnand_transaction)
    `uvm_field_int(cmd, UVM_ALL_ON)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_queue_int(data, UVM_ALL_ON)
    `uvm_field_enum(tnand_err_e, error_inject, UVM_ALL_ON)
    `uvm_field_int(status, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_queue_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(busy_violation, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(illegal_cmd, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "tnand_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    tnand_transaction t;
    bit ok = 1;
    ok &= super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    ok &= comparer.compare_field("cmd", cmd, t.cmd, 8);
    ok &= comparer.compare_field("addr", addr, t.addr, 40);
    if (cmd == tnand_defs_pkg::TNAND_CMD_PROG && !busy_violation)
      ok &= comparer.compare_field("data_size", data.size(), t.data.size(), 32);
    return ok;
  endfunction

  function string convert2string();
    string op;
    case (cmd)
      tnand_defs_pkg::TNAND_CMD_READ_PAGE: op = "READ";
      tnand_defs_pkg::TNAND_CMD_PROG:      op = "PROG";
      tnand_defs_pkg::TNAND_CMD_ERASE:     op = "ERASE";
      tnand_defs_pkg::TNAND_CMD_STATUS:    op = "STATUS";
      default:                             op = "ILLEGAL";
    endcase
    return $sformatf("TNAND %s cmd=0x%02h addr=0x%010h len=%0d status=0x%02h err=%s%s%s",
                     op, cmd, addr, data.size(), status, error_inject.name(),
                     busy_violation ? " BUSY_VIOL" : "",
                     illegal_cmd ? " ILLEGAL" : "");
  endfunction
endclass
