# QSPI Test Plan（QSPI-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | QSPI |
| 家族 | Serial |
| 類型 | RTL IP |
| 交付目錄 | `QSPI-VIP/` |
| 目前 L1b 狀態 | PASS(directed tb) |

## 2. DUT / 待測對象

- 合成參考 RTL（`rtl/`）+ directed testbench（`tb/`）

## 3. 驗證環境

- directed testbench（`tb/*_tb.sv`）+ 合成 RTL（`rtl/*_top.sv`）
- 完整 UVM VIP 對應請見同協定的 `*-UVM-VIP` 條目

## 4. 測試項目

### 4.1 Functional smoke

- 狀態：**尚未導入**（目前為 model smoke / directed-tb smoke）
- 導入方式：比照 `gen_func_tb.py` 產出的 self-checking tb，對展平後的 behavioral model 做 directed 檢查

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Reset / initial-state values on all outputs |
| PT-02 | Basic protocol transfer against the directed testbench |
| PT-03 | Protocol-corner sequences (max burst, back-to-back, abort) |
| PT-04 | Error-response paths (illegal address, bad CRC, timeout) |

## 5. 覆蓋與檢查

- （本 VIP 無獨立 SVA/coverage 檔案，覆蓋由 directed tb 之通過/失敗判定承擔。）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/QSPI-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py QSPI-VIP && python3 smoke/smoke_run.py QSPI-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- functional smoke 為後續補強對象。

---
*文件版本：v1.7.5 自動產生*
