// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- MIL-STD-1553 testbench top with a functional MIL-STD-1553 DUT model

`ifndef MIL-STD-1553_TB_SV
`define MIL-STD-1553_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import mil_std_1553_defs_pkg::*;
import mil_std_1553_pkg::*;
import mil_std_1553_env_pkg::*;
import mil_std_1553_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  mil_std_1553_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  mil_std_1553_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .busa_rx_data(vif.busa_rx_data),
    .busa_rx_sync(vif.busa_rx_sync),
    .busa_rx_valid(vif.busa_rx_valid),
    .busa_tx_data(vif.busa_tx_data),
    .busa_tx_sync(vif.busa_tx_sync),
    .busa_tx_valid(vif.busa_tx_valid),
    .rt_addr(vif.rt_addr)
  );

  // Concurrent protocol checks
  mil_std_1553_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .busa_rx_data(vif.busa_rx_data), .busa_rx_sync(vif.busa_rx_sync), .busa_rx_valid(vif.busa_rx_valid), .busa_tx_data(vif.busa_tx_data), .busa_tx_sync(vif.busa_tx_sync), .busa_tx_valid(vif.busa_tx_valid), .rt_addr(vif.rt_addr)
  );

  initial begin
    uvm_config_db#(virtual mil_std_1553_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module mil_std_1553_model #(
  parameter bit [4:0] RT_ADDRESS = 5'h05
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [15:0] busa_rx_data,
  input  logic        busa_rx_sync,
  input  logic        busa_rx_valid,
  output logic [15:0] busa_tx_data,
  output logic        busa_tx_sync,
  output logic        busa_tx_valid,
  output logic [4:0]  rt_addr
);
  logic [3:0] gap;
  logic       pending;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      gap          <= '0;
      pending      <= 1'b0;
      busa_tx_data <= '0;
      busa_tx_sync <= 1'b0;
      busa_tx_valid<= 1'b0;
      rt_addr      <= RT_ADDRESS;
    end else begin
      // command word: sync + valid, RT address field matches
      if (busa_rx_sync && busa_rx_valid && busa_rx_data[15:11] == RT_ADDRESS)
        pending <= 1'b1;
      if (pending) begin
        if (gap == 4'd7) begin
          busa_tx_valid <= 1'b1;
          busa_tx_sync  <= 1'b1;
          busa_tx_data  <= {RT_ADDRESS, 3'b000, 8'h80}; // status word
          pending       <= 1'b0;
          gap           <= '0;
        end else
          gap <= gap + 1'b1;
      end else begin
        busa_tx_valid <= 1'b0;
        busa_tx_sync  <= 1'b0;
      end
    end
  end
endmodule
`endif
