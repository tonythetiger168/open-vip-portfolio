// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (MIL-STD-1553 command/status exchange)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened mil_std_1553_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [15:0] busa_rx_data = '0;
  logic busa_rx_sync = 1'b0;
  logic busa_rx_valid = 1'b0;
  wire  [15:0] busa_tx_data;
  wire  busa_tx_sync;
  wire  busa_tx_valid;
  wire  [4:0]  rt_addr;

  always #5 clk = ~clk;

  mil_std_1553_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .busa_rx_data(busa_rx_data), .busa_rx_sync(busa_rx_sync),
    .busa_rx_valid(busa_rx_valid),
    .busa_tx_data(busa_tx_data), .busa_tx_sync(busa_tx_sync),
    .busa_tx_valid(busa_tx_valid), .rt_addr(rt_addr)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(busa_tx_valid === 1'b0, "tx quiet out of reset");
    chk(rt_addr === 5'h05, "RT address is the configured 0x05");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // command for a DIFFERENT RT: no response
    @(negedge clk);
    busa_rx_data = {5'h0A, 11'h000}; busa_rx_sync = 1; busa_rx_valid = 1;
    step();
    chk(busa_tx_valid === 1'b0, "no response to other RT");
    @(negedge clk); busa_rx_sync = 0; busa_rx_valid = 0;
    repeat (12) begin step(); chk(busa_tx_valid === 1'b0, "still quiet for other RT"); end

    // command for THIS RT (5): status word follows after the gap
    @(negedge clk);
    busa_rx_data = {5'h05, 11'h100}; busa_rx_sync = 1; busa_rx_valid = 1;
    step();
    @(negedge clk); busa_rx_sync = 0; busa_rx_valid = 0;
    begin : stw
      int to = 0;
      while (busa_tx_valid !== 1'b1 && to < 20) begin step(); to++; end
      chk(busa_tx_valid === 1'b1, "status word transmitted");
      chk(busa_tx_data[15:11] === 5'h05, "status word carries RT address");
      chk(busa_tx_sync === 1'b1, "status word sync asserted");
    end
    step();
    chk(busa_tx_valid === 1'b0, "status word completes");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
