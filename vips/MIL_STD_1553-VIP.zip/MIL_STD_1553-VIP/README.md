# MIL-STD-1553 UVM VIP (MIL_STD_1553-VIP)

MIL-STD-1553 remote terminal UVM VIP: command word decode and status word reply on the redundant bus pair.

## Structure

- `mil_std_1553/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `mil_std_1553_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `mil_std_1553_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural MIL-STD-1553 DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/MIL_STD_1553-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh MIL_STD_1553-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
