// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_agent.svh -- MIL-STD-1553 agent

class mil_std_1553_agent extends uvm_agent;
  `uvm_component_utils(mil_std_1553_agent)

  mil_std_1553_sequencer sqr;
  mil_std_1553_driver    drv;
  mil_std_1553_monitor   mon;
  mil_std_1553_config    cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    cfg = mil_std_1553_config::type_id::create("cfg", this);
    uvm_config_db#(mil_std_1553_config)::set(this, "*", "cfg", cfg);
    sqr = mil_std_1553_sequencer::type_id::create("sqr", this);
    drv = mil_std_1553_driver   ::type_id::create("drv", this);
    mon = mil_std_1553_monitor  ::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
