// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_if.sv -- MIL-STD-1553 interface

interface mil_std_1553_if (input logic clk);
  logic rst_n;

  logic [15:0] busa_rx_data;
  logic busa_rx_sync;
  logic busa_rx_valid;
  logic [15:0] busa_tx_data;
  logic busa_tx_sync;
  logic busa_tx_valid;
  logic [4:0] rt_addr;

  modport DUT (input clk, rst_n, busa_rx_data, busa_rx_sync, busa_rx_valid, output busa_tx_data, busa_tx_sync, busa_tx_valid, rt_addr);
  modport DRV (input clk, rst_n, busa_tx_data, busa_tx_sync, busa_tx_valid, rt_addr, output busa_rx_data, busa_rx_sync, busa_rx_valid);
  modport MON (input clk, rst_n, busa_rx_data, busa_rx_sync, busa_rx_valid, busa_tx_data, busa_tx_sync, busa_tx_valid, rt_addr);

  clocking drv_cb @(posedge clk);
    input rst_n, busa_rx_data, busa_rx_sync, busa_rx_valid, busa_tx_data, busa_tx_sync, busa_tx_valid, rt_addr;
    output busa_rx_data, busa_rx_sync, busa_rx_valid;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, busa_rx_data, busa_rx_sync, busa_rx_valid, busa_tx_data, busa_tx_sync, busa_tx_valid, rt_addr;
  endclocking
endinterface
