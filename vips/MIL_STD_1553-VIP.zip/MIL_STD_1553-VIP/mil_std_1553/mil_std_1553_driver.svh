// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_driver.svh -- MIL-STD-1553 driver: reset, then per-item protocol stimulus

class mil_std_1553_driver extends uvm_driver #(mil_std_1553_transaction);
  `uvm_component_utils(mil_std_1553_driver)

  virtual mil_std_1553_if vif;
  mil_std_1553_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual mil_std_1553_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "mil_std_1553: virtual interface not set")
    void'(uvm_config_db#(mil_std_1553_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    vif.drv_cb.rst_n <= 1'b0;
    repeat (8) @(vif.drv_cb);
    vif.drv_cb.rst_n <= 1'b1;
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_item(mil_std_1553_transaction item);
    item.tag = item_cnt++;
    vif.busa_rx_data <= item.busa_rx_data;
    vif.busa_rx_sync <= item.busa_rx_sync;
    vif.busa_rx_valid <= item.busa_rx_valid;
    @(vif.drv_cb);
    ap.write(item);
  endtask
endclass
