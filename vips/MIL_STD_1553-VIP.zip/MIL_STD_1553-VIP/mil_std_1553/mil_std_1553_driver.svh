// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_driver.svh -- MIL-STD-1553 driver: one word on the decoded bus interface, then the response window

class mil_std_1553_driver extends uvm_driver #(mil_std_1553_transaction);
  `uvm_component_utils(mil_std_1553_driver)

  uvm_analysis_port #(mil_std_1553_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual mil_std_1553_if vif;
  mil_std_1553_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual mil_std_1553_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "mil_std_1553: virtual interface not set")
    if (!uvm_config_db#(mil_std_1553_config)::get(this, "", "cfg", cfg))
      cfg = mil_std_1553_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    mil_std_1553_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.busa_rx_data <= '0; vif.drv_cb.busa_rx_sync <= 1'b0; vif.drv_cb.busa_rx_valid <= 1'b0;
  endtask

  task drive_item(mil_std_1553_transaction t);
    @(vif.drv_cb);
    vif.drv_cb.busa_rx_data  <= t.word;
    vif.drv_cb.busa_rx_sync  <= t.sync;
    vif.drv_cb.busa_rx_valid <= 1'b1;
    @(vif.drv_cb);
    vif.drv_cb.busa_rx_valid <= 1'b0;
    vif.drv_cb.busa_rx_sync  <= 1'b0;
    t.responded = 0; t.status = 0;
    repeat (cfg.resp_window) begin
      @(vif.drv_cb);
      if (vif.drv_cb.busa_tx_valid === 1'b1 && !t.responded) begin
        t.responded = 1;
        t.status = vif.drv_cb.busa_tx_data;
      end
    end
    t.rt_addr = vif.drv_cb.rt_addr;
  endtask

endclass
