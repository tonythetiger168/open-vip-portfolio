// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_transaction.svh -- MIL-STD-1553 transaction

class mil_std_1553_transaction extends uvm_sequence_item;
  `uvm_object_utils(mil_std_1553_transaction)

  // request (driven by the agent)
  rand bit sync;
  rand bit [15:0] word;
  // response (returned by the DUT)
  bit responded;
  bit [15:0] status;
  bit [4:0] rt_addr;
  int unsigned tag;   // sequence number (driver/monitor order)


  // command word: RT address [15:11], T/R [10], subaddress [9:5], word count [4:0]
  constraint c_rt { sync -> word[15:11] dist { 5'h05 := 3, 5'h1F := 1, [0:4] :/ 1, [6:30] :/ 1 }; }

  function new(string name = "mil_std_1553_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    mil_std_1553_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    sync = rhs_.sync;
    word = rhs_.word;
    responded = rhs_.responded;
    status = rhs_.status;
    rt_addr = rhs_.rt_addr;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    mil_std_1553_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (sync != rhs_.sync) return 0;
    if (word != rhs_.word) return 0;
    if (responded != rhs_.responded) return 0;
    if (status != rhs_.status) return 0;
    if (rt_addr != rhs_.rt_addr) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(mil_std_1553_transaction rhs_);
    if (sync != rhs_.sync) return 0;
    if (word != rhs_.word) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("MIL-STD-1553{tag=%0d sync=0x%0h word=0x%0h responded=0x%0h status=0x%0h rt_addr=0x%0h}", tag, sync, word, responded, status, rt_addr);
  endfunction
endclass
