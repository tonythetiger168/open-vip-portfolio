// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_transaction.svh -- MIL-STD-1553 transaction

class mil_std_1553_transaction extends uvm_sequence_item;
  `uvm_object_utils(mil_std_1553_transaction)

  rand bit [15:0] busa_rx_data;
  rand bit busa_rx_sync;
  rand bit busa_rx_valid;
  bit [15:0] busa_tx_data_o;
  bit busa_tx_sync_o;
  bit busa_tx_valid_o;
  bit [4:0] rt_addr_o;
  bit [31:0] tag;

  function new(string name = "mil_std_1553_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    mil_std_1553_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    busa_rx_data = rhs_.busa_rx_data;
    busa_rx_sync = rhs_.busa_rx_sync;
    busa_rx_valid = rhs_.busa_rx_valid;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    mil_std_1553_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           busa_rx_data == rhs_.busa_rx_data &&
           busa_rx_sync == rhs_.busa_rx_sync &&
           busa_rx_valid == rhs_.busa_rx_valid;
  endfunction

  function string convert2string();
    return $sformatf("MIL-STD-1553{tag=%0h busa_rx_data=0x%0h busa_rx_sync=0x%0h busa_rx_valid=0x%0h}", tag, busa_rx_data, busa_rx_sync, busa_rx_valid);
  endfunction
endclass
