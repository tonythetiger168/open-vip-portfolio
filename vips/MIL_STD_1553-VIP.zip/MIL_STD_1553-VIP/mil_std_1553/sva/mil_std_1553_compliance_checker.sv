// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_compliance_checker.sv -- MIL-STD-1553 concurrent assertion checks (bindable)

module mil_std_1553_compliance_checker
  (input logic clk, input logic rst_n, input [15:0] busa_rx_data, input busa_rx_sync, input busa_rx_valid, input [15:0] busa_tx_data, input busa_tx_sync, input busa_tx_valid, input [4:0] rt_addr);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({busa_tx_data, busa_tx_sync, busa_tx_valid, rt_addr}))
    else $error("MIL-STD-1553: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> busa_tx_data == '0)
    else $error("MIL-STD-1553: output not in reset value");
  // status word carries the configured RT address
  assert property (@(posedge clk) disable iff (!rst_n) busa_tx_valid |-> busa_tx_data[15:11] == rt_addr)
    else $error("1553: status RT address mismatch");
  cover property (@(posedge clk) disable iff (!rst_n) (busa_tx_data != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (busa_tx_valid == 1'b1));
endmodule
