// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_coverage.svh -- MIL-STD-1553 functional coverage

class mil_std_1553_coverage extends uvm_subscriber #(mil_std_1553_transaction);
  `uvm_component_utils(mil_std_1553_coverage)
  mil_std_1553_config cfg;
  mil_std_1553_transaction tr;

  covergroup mil_std_1553_cg;
    cp_kind : coverpoint tr.sync { bins data = {0}; bins command = {1}; }
    cp_rt   : coverpoint tr.word[15:11] iff (tr.sync) { bins mine = {5'h05}; bins bcast = {5'h1F}; bins other = default; }
    cp_tr   : coverpoint tr.word[10] iff (tr.sync);
    cp_resp : coverpoint tr.responded;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    mil_std_1553_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(mil_std_1553_config)::get(this, "", "cfg", cfg))
      cfg = mil_std_1553_config::type_id::create("cfg");
  endfunction

  function void write(mil_std_1553_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    mil_std_1553_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("MIL-STD-1553 coverage: %0.1f%%", mil_std_1553_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
