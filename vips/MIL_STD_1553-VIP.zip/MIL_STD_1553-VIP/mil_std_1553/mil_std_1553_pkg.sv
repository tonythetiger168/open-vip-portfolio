// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_pkg.sv -- MIL-STD-1553 UVM VIP package

package mil_std_1553_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import mil_std_1553_defs_pkg::*;
  export mil_std_1553_defs_pkg::*;

  `include "mil_std_1553_transaction.svh"
  `include "mil_std_1553_config.svh"
  `include "mil_std_1553_sequencer.svh"
  `include "mil_std_1553_driver.svh"
  `include "mil_std_1553_monitor.svh"
  `include "mil_std_1553_agent.svh"
  `include "mil_std_1553_sequences.svh"
  `include "mil_std_1553_checker.svh"
  `include "mil_std_1553_coverage.svh"
endpackage
