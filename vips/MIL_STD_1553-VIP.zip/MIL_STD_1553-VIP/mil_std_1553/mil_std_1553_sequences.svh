// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_sequences.svh -- MIL-STD-1553 sequences

// Random traffic: cfg.num_items constrained-random items.
class mil_std_1553_base_sequence extends uvm_sequence #(mil_std_1553_transaction);
  `uvm_object_utils(mil_std_1553_base_sequence)
  mil_std_1553_config cfg;

  function new(string name = "mil_std_1553_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = mil_std_1553_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "mil_std_1553_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class mil_std_1553_directed_sequence extends uvm_sequence #(mil_std_1553_transaction);
  `uvm_object_utils(mil_std_1553_directed_sequence)
  mil_std_1553_config cfg;

  function new(string name = "mil_std_1553_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function mil_std_1553_transaction item();
    item = mil_std_1553_transaction::type_id::create("req");
  endfunction

  task send(mil_std_1553_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    mil_std_1553_transaction t;
    t = item(); t.sync = 1; t.word = {5'h05, 1'b1, 5'h01, 5'd4}; send(t);   // transmit command to RT 5
    t = item(); t.sync = 1; t.word = {5'h05, 1'b0, 5'h02, 5'd1}; send(t);   // receive command to RT 5
    t = item(); t.sync = 0; t.word = 16'h2BAD; send(t);                     // its data word: no response
    t = item(); t.sync = 1; t.word = {5'h04, 1'b1, 5'h01, 5'd1}; send(t);   // another terminal
    t = item(); t.sync = 1; t.word = {5'h1F, 1'b0, 5'h03, 5'd2}; send(t);   // broadcast
    t = item(); t.sync = 0; t.word = {5'h05, 11'h0}; send(t);               // data word with RT 5 bits
  endtask
endclass
