// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_monitor.svh -- MIL-STD-1553 monitor: decodes observed bus activity

class mil_std_1553_monitor extends uvm_monitor;
  `uvm_component_utils(mil_std_1553_monitor)

  virtual mil_std_1553_if vif;
  uvm_analysis_port #(mil_std_1553_transaction) ap;
  mil_std_1553_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual mil_std_1553_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "mil_std_1553: virtual interface not set")
    void'(uvm_config_db#(mil_std_1553_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    mil_std_1553_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = mil_std_1553_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.busa_rx_data = vif.busa_rx_data;
        t.busa_rx_sync = vif.busa_rx_sync;
        t.busa_rx_valid = vif.busa_rx_valid;
        t.busa_tx_data_o = vif.busa_tx_data;
        t.busa_tx_sync_o = vif.busa_tx_sync;
        t.busa_tx_valid_o = vif.busa_tx_valid;
        t.rt_addr_o = vif.rt_addr;
        ap.write(t);
      end
    end
  endtask
endclass
