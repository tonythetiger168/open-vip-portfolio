// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_monitor.svh -- MIL-STD-1553 monitor: each received word with the terminal's status word (if any) in the response window

class mil_std_1553_monitor extends uvm_monitor;
  `uvm_component_utils(mil_std_1553_monitor)

  virtual mil_std_1553_if vif;
  uvm_analysis_port #(mil_std_1553_transaction) ap;
  mil_std_1553_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual mil_std_1553_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "mil_std_1553: virtual interface not set")
    if (!uvm_config_db#(mil_std_1553_config)::get(this, "", "cfg", cfg))
      cfg = mil_std_1553_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.busa_tx_valid)
          `uvm_error("MON", "MIL-STD-1553 status word outside a response window")
        if (vif.mon_cb.busa_rx_valid) begin
          mil_std_1553_transaction t = mil_std_1553_transaction::type_id::create("t");
          t.sync = vif.mon_cb.busa_rx_sync;
          t.word = vif.mon_cb.busa_rx_data;
          repeat (cfg.resp_window) begin
            @(vif.mon_cb);
            if (vif.mon_cb.busa_rx_valid) `uvm_error("MON", "MIL-STD-1553 word inside the response window")
            if (vif.mon_cb.busa_tx_valid) begin
              if (t.responded) `uvm_error("MON", "MIL-STD-1553 second status word")
              t.responded = 1;
              t.status = vif.mon_cb.busa_tx_data;
              if (!vif.mon_cb.busa_tx_sync) `uvm_error("MON", "MIL-STD-1553 status word without sync")
            end
          end
          t.rt_addr = vif.mon_cb.rt_addr;
          publish(t);
        end
      end
    end
  endtask

  function void publish(mil_std_1553_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
