// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mil_std_1553_env.sv -- MIL-STD-1553 verification environment with end-to-end scoreboard

package mil_std_1553_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import mil_std_1553_defs_pkg::*;
  import mil_std_1553_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: driver-issued (expected) vs monitor-observed items.
  class mil_std_1553_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(mil_std_1553_scoreboard)
    uvm_analysis_imp_exp #(mil_std_1553_transaction, mil_std_1553_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(mil_std_1553_transaction, mil_std_1553_scoreboard) obs_ap;

    mil_std_1553_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(mil_std_1553_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(mil_std_1553_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        mil_std_1553_transaction e = exp_q.pop_front();
        mil_std_1553_transaction o = obs_q.pop_front();
        if (e.tag == o.tag) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("mil_std_1553 scoreboard: n_matches=%0d n_mismatches=%0d",
                n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  class mil_std_1553_env extends uvm_env;
    `uvm_component_utils(mil_std_1553_env)
    mil_std_1553_agent      agt;
    mil_std_1553_scoreboard sb;
    mil_std_1553_checker    chk;
    mil_std_1553_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = mil_std_1553_agent     ::type_id::create("agt", this);
      sb  = mil_std_1553_scoreboard::type_id::create("sb",  this);
      chk = mil_std_1553_checker   ::type_id::create("chk", this);
      cov = mil_std_1553_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
