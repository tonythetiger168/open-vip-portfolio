// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// mipi_vip_pkg.sv -- MIPI protocol VIP package
// Supports: CSI-2, DSI, D-PHY, C-PHY, M-PHY, UniPro, DigRF, HSI, CSE
// Contains: enumerations, transaction (with real CRC-32), agent
// (sequencer/driver/monitor), functional coverage, end-to-end scoreboard
// and the directed sequence library.

`ifndef MIPI_VIP_PKG_SV
`define MIPI_VIP_PKG_SV

package mipi_vip_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef enum int {
    MIPI_CSI2   = 0,
    MIPI_DSI    = 1,
    MIPI_DPHY   = 2,
    MIPI_CPHY   = 3,
    MIPI_MPHY   = 4,
    MIPI_UNIPRO = 5,
    MIPI_DIGRF  = 6,
    MIPI_HSI    = 7,
    MIPI_CSE    = 8,
    MIPI_MAX    = 9
  } mipi_protocol_e;

  typedef enum int {
    SPEED_DPHY_1G5  = 1500,
    SPEED_DPHY_2G5  = 2500,
    SPEED_DPHY_4G5  = 4500,
    SPEED_CPHY_2G   = 2000,
    SPEED_CPHY_4G   = 4000,
    SPEED_MPHY_G1   = 1248,
    SPEED_MPHY_G2   = 2496,
    SPEED_MPHY_G3   = 4992,
    SPEED_MPHY_G4   = 9984,
    SPEED_MPHY_G5   = 19968,
    SPEED_UNIPRO_1G = 1000,
    SPEED_HSI_150M  = 150
  } mipi_speed_e;

  // Aliases kept out of the enum: IEEE 1800 requires unique enumeration values
  localparam mipi_speed_e SPEED_UNIPRO_2G  = SPEED_CPHY_2G;   // 2000
  localparam mipi_speed_e SPEED_UNIPRO_4G  = SPEED_CPHY_4G;   // 4000
  localparam mipi_speed_e SPEED_DIGRF_150M = SPEED_HSI_150M;  // 150
  localparam mipi_speed_e SPEED_CSE_1G     = SPEED_UNIPRO_1G; // 1000

  typedef enum logic [3:0] {
    ST_STOP     = 4'h0,
    ST_HS_REQ   = 4'h1,
    ST_HS_ZERO  = 4'h2,
    ST_HS_SYNC  = 4'h3,
    ST_HS_DATA  = 4'h4,
    ST_HS_TRAIL = 4'h5,
    ST_HS_EXIT  = 4'h6,
    ST_LP11     = 4'h7,
    ST_LP00     = 4'h8,
    ST_LP01     = 4'h9,
    ST_LP10     = 4'hA,
    ST_TA_REQ   = 4'hB,
    ST_TA_GRANT = 4'hC,
    ST_ULPS     = 4'hD
  } mipi_lane_state_e;

  typedef enum logic [5:0] {
    PKT_FS         = 6'h00,
    PKT_FE         = 6'h01,
    PKT_LS         = 6'h02,
    PKT_LE         = 6'h03,
    PKT_RGB565     = 6'h0E,
    PKT_RGB666     = 6'h1E,
    PKT_RGB888     = 6'h2E,
    PKT_RAW6       = 6'h28,
    PKT_RAW7       = 6'h29,
    PKT_RAW8       = 6'h2A,
    PKT_RAW10      = 6'h2B,
    PKT_RAW12      = 6'h2C,
    PKT_RAW14      = 6'h2D,
    PKT_YUV422_10B = 6'h1F,
    PKT_USER_0     = 6'h30,
    PKT_USER_1     = 6'h31,
    PKT_USER_2     = 6'h32,
    PKT_USER_3     = 6'h33,
    PKT_USER_4     = 6'h34,
    PKT_USER_5     = 6'h35,
    PKT_USER_6     = 6'h36,
    PKT_USER_7     = 6'h37,
    PKT_NULL       = 6'h3A,
    PKT_BLANK      = 6'h3B,
    PKT_EMBEDDED   = 6'h3C
  } mipi_pkt_type_e;

  // Alias: YUV422 8-bit shares data type code 6'h1E with RGB666
  localparam mipi_pkt_type_e PKT_YUV422_8B = PKT_RGB666;

  typedef enum logic [2:0] {
    VC_0 = 3'd0,
    VC_1 = 3'd1,
    VC_2 = 3'd2,
    VC_3 = 3'd3,
    VC_4 = 3'd4,
    VC_5 = 3'd5,
    VC_6 = 3'd6,
    VC_7 = 3'd7
  } mipi_vc_e;

  //==========================================================================
  // Shared CRC-32 (reflected polynomial 0xEDB88320)
  //==========================================================================
  function automatic bit [31:0] mipi_crc32(ref bit [7:0] bytes[$]);
    bit [31:0] crc;
    crc = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 32'hEDB8_8320 : (crc >> 1);
    end
    return ~crc;
  endfunction

  //==========================================================================
  // Transaction descriptor
  //==========================================================================
  class mipi_txn extends uvm_object;
    `uvm_object_utils(mipi_txn)

    rand mipi_protocol_e protocol;
    rand mipi_pkt_type_e pkt_type;
    rand mipi_vc_e       vc;
    rand logic [15:0]    word_count;
    rand logic [31:0]    data[];
    rand logic [15:0]    ecc;
    rand logic [31:0]    crc;
    rand int             lane_count;
    rand int             data_rate;
    rand bit             lp_mode;
    rand bit             hs_mode;
    rand bit             ulps;
    rand bit             inject_err;
    rand int             delay;

    constraint c_wc   { word_count inside {[1:4095]}; }
    constraint c_data { data.size() == ((word_count + 1) / 2); }
    constraint c_lane {
      if (protocol == MIPI_DPHY)      lane_count inside {1, 2, 4};
      else if (protocol == MIPI_CPHY) lane_count inside {1, 2, 3};
      else if (protocol == MIPI_MPHY) lane_count inside {1, 2};
      else                            lane_count inside {1, 2, 4};
    }
    constraint c_mode { lp_mode != hs_mode; }
    constraint c_err  { inject_err dist {0 := 95, 1 := 5}; }
    constraint c_dly  { delay inside {[0:20]}; }

    function new(string name = "mipi_txn");
      super.new(name);
    endfunction

    // Assemble the payload byte stream (word_count bytes, LSB-first per word)
    function void assemble_bytes(ref bit [7:0] bytes[$]);
      bytes.delete();
      for (int i = 0; i < word_count; i++)
        bytes.push_back(data[i/2][(i%2)*16 +: 8]);
    endfunction

    function void post_randomize();
      bit [7:0] bytes[$];
      bit [15:0] e;
      assemble_bytes(bytes);
      crc = mipi_crc32(bytes);
      // simple ECC: XOR fold of all payload bytes
      e = 16'h0;
      foreach (bytes[i]) e = e ^ {8'h00, bytes[i]} ^ {bytes[i], 8'h00};
      ecc = e;
    endfunction

    virtual function string convert2string();
      return $sformatf("%s pkt=%s vc=%0d wc=%0d err=%0b",
                       protocol.name(), pkt_type.name(), vc, word_count, inject_err);
    endfunction
  endclass

  //==========================================================================
  // Sequence item
  //==========================================================================
  class mipi_seq_item extends uvm_sequence_item;
    `uvm_object_utils(mipi_seq_item)

    rand mipi_txn txn;

    function new(string name = "mipi_seq_item");
      super.new(name);
      txn = mipi_txn::type_id::create("txn");
    endfunction

    virtual function string convert2string();
      return txn.convert2string();
    endfunction
  endclass

  //==========================================================================
  // Sequencer
  //==========================================================================
  class mipi_sequencer extends uvm_sequencer #(mipi_seq_item);
    `uvm_component_utils(mipi_sequencer)
    function new(string name = "mipi_sequencer", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass

  //==========================================================================
  // Driver
  //   Streams the packet on the generic layer (sop..eop, 4-byte beats,
  //   valid/ready flow control) and drives the protocol-specific sideband.
  //   HSI: wake pulse + channel + hsi_data observability + flow encoding.
  //==========================================================================
  class mipi_driver extends uvm_driver #(mipi_seq_item);
    `uvm_component_utils(mipi_driver)

    virtual mipi_vip_if vif;
    mipi_protocol_e     protocol;
    uvm_analysis_port #(mipi_seq_item) drv_ap;  // expected items

    int txn_count;

    function new(string name = "mipi_driver", uvm_component parent = null);
      super.new(name, parent);
      drv_ap = new("drv_ap", this);
      txn_count = 0;
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual mipi_vip_if)::get(this, "", "vif", vif))
        `uvm_fatal("CONFIG", "Virtual interface not found")
      if (!uvm_config_db#(mipi_protocol_e)::get(this, "", "protocol", protocol))
        protocol = MIPI_DIGRF;
    endfunction

    task run_phase(uvm_phase phase);
      init_signals();
      wait (vif.rst_n === 1'b1);
      forever begin
        mipi_seq_item item;
        seq_item_port.get_next_item(item);
        drive_item(item);
        seq_item_port.item_done();
      end
    endtask

    virtual task init_signals();
      vif.drv_cb.valid <= 1'b0;
      vif.drv_cb.sop   <= 1'b0;
      vif.drv_cb.eop   <= 1'b0;
      vif.drv_cb.hsi_valid <= 1'b0;
      vif.drv_cb.hsi_wake  <= 1'b0;
      vif.drv_cb.break_sig <= 1'b0;
      vif.drv_cb.flow      <= 2'b00;
      vif.drv_cb.digrf_valid      <= 1'b0;
      vif.drv_cb.digrf_frame_sync <= 1'b0;
      vif.drv_cb.mrd              <= 1'b0;
      vif.drv_cb.blank            <= 1'b1;
      vif.drv_cb.subframe         <= 4'h0;
    endtask

    virtual task drive_item(mipi_seq_item item);
      mipi_txn txn = item.txn;
      bit [7:0] bytes[$];
      int idx = 0;
      int sub_cnt = 0;
      `uvm_info("DRIVER", $sformatf("Driving: %s", txn.convert2string()), UVM_HIGH)
      repeat (txn.delay) @(vif.drv_cb);

      // DigRF link behavior: frame sync + antenna + I/Q sideband
      if (txn.protocol == MIPI_DIGRF) begin
        @(vif.drv_cb);
        vif.drv_cb.digrf_frame_sync <= 1'b1;
        vif.drv_cb.digrf_antenna    <= 4'(txn.vc);
        vif.drv_cb.mrd              <= 1'b1;
        vif.drv_cb.data_type        <= txn.pkt_type[3:0];
        vif.drv_cb.rate             <= 3'b001;
        vif.drv_cb.blank            <= 1'b0;
        vif.drv_cb.subframe         <= 4'h0;
        @(vif.drv_cb);
        vif.drv_cb.digrf_frame_sync <= 1'b0;
        vif.drv_cb.digrf_valid      <= 1'b1;
        sub_cnt = 0;
      end

      // HSI link behavior: wake the receiver before the frame
      if (txn.protocol == MIPI_HSI) begin
        @(vif.drv_cb);
        vif.drv_cb.hsi_wake    <= 1'b1;
        vif.drv_cb.hsi_channel <= 4'(txn.vc);
        @(vif.drv_cb);
        vif.drv_cb.hsi_wake    <= 1'b0;
        vif.drv_cb.flow        <= 2'b01;
        vif.drv_cb.hsi_valid   <= 1'b1;
      end

      txn.assemble_bytes(bytes);
      // corrupt the CRC sideband on request (receiver must detect it)
      while (idx < bytes.size()) begin
        logic [31:0] beat;
        int n;
        beat = '0;
        n = (bytes.size() - idx < 4) ? (bytes.size() - idx) : 4;
        for (int j = 0; j < n; j++)
          beat[j*8 +: 8] = bytes[idx + j];
        @(vif.drv_cb);
        while (vif.drv_cb.ready !== 1'b1) @(vif.drv_cb);
        vif.drv_cb.valid <= 1'b1;
        vif.drv_cb.data  <= beat;
        vif.drv_cb.sop   <= (idx == 0);
        vif.drv_cb.eop   <= (idx + n >= bytes.size());
        if (txn.protocol == MIPI_HSI)
          vif.drv_cb.hsi_data <= bytes[idx];
        if (txn.protocol == MIPI_DIGRF) begin
          vif.drv_cb.digrf_i  <= {4'h0, bytes[idx]};
          vif.drv_cb.digrf_q  <= {4'h0, ((idx + 1 < bytes.size()) ? bytes[idx+1] : 8'h00)};
          vif.drv_cb.subframe <= 4'(sub_cnt);
          sub_cnt++;
        end
        if (idx == 0) begin
          vif.drv_cb.pkt_type   <= txn.pkt_type;
          vif.drv_cb.vc         <= txn.vc;
          vif.drv_cb.word_count <= txn.word_count;
          vif.drv_cb.ecc        <= txn.ecc;
          vif.drv_cb.crc        <= txn.inject_err ? (txn.crc ^ 32'hA5A5_5A5A) : txn.crc;
        end
        idx += n;
      end
      @(vif.drv_cb);
      vif.drv_cb.valid <= 1'b0;
      vif.drv_cb.sop   <= 1'b0;
      vif.drv_cb.eop   <= 1'b0;
      if (txn.protocol == MIPI_HSI) begin
        vif.drv_cb.hsi_valid <= 1'b0;
        vif.drv_cb.flow      <= 2'b00;
      end
      if (txn.protocol == MIPI_DIGRF) begin
        vif.drv_cb.digrf_valid <= 1'b0;
        vif.drv_cb.mrd         <= 1'b0;
        vif.drv_cb.blank       <= 1'b1;
      end
      txn_count++;
      drv_ap.write(item);   // broadcast expected transaction
    endtask
  endclass

  //==========================================================================
  // Monitor
  //   Reassembles packets from the generic-layer waveform, re-computes the
  //   CRC-32 and compares against the received CRC sideband, then publishes.
  //==========================================================================
  class mipi_monitor extends uvm_monitor;
    `uvm_component_utils(mipi_monitor)

    virtual mipi_vip_if vif;
    mipi_protocol_e     protocol;
    uvm_analysis_port #(mipi_seq_item) analysis_port;

    int txn_count;
    int error_count;

    function new(string name = "mipi_monitor", uvm_component parent = null);
      super.new(name, parent);
      analysis_port = new("analysis_port", this);
      txn_count = 0;
      error_count = 0;
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual mipi_vip_if)::get(this, "", "vif", vif))
        `uvm_fatal("CONFIG", "Virtual interface not found")
      if (!uvm_config_db#(mipi_protocol_e)::get(this, "", "protocol", protocol))
        protocol = MIPI_DIGRF;
    endfunction

    task run_phase(uvm_phase phase);
      wait (vif.rst_n === 1'b1);
      forever collect_transaction();
    endtask

    virtual task collect_transaction();
      mipi_seq_item item;
      bit [7:0] bytes[$];
      bit [31:0] calc_crc;

      @(vif.mon_cb);
      while (vif.mon_cb.sop !== 1'b1 || vif.mon_cb.valid !== 1'b1)
        @(vif.mon_cb);

      item = mipi_seq_item::type_id::create("item");
      item.txn.protocol   = protocol;
      item.txn.pkt_type   = mipi_pkt_type_e'(vif.mon_cb.pkt_type);
      item.txn.vc         = mipi_vc_e'(vif.mon_cb.vc);
      item.txn.word_count = vif.mon_cb.word_count;
      item.txn.ecc        = vif.mon_cb.ecc;
      item.txn.crc        = vif.mon_cb.crc;

      // capture beats until EOP
      bytes.delete();
      for (int j = 0; j < 4; j++)
        bytes.push_back(vif.mon_cb.data[j*8 +: 8]);
      while (vif.mon_cb.eop !== 1'b1) begin
        @(vif.mon_cb);
        if (vif.mon_cb.valid === 1'b1)
          for (int j = 0; j < 4; j++)
            bytes.push_back(vif.mon_cb.data[j*8 +: 8]);
      end
      // trim to word_count payload bytes
      while (bytes.size() > item.txn.word_count)
        void'(bytes.pop_back());

      item.txn.data = new[(item.txn.word_count + 1) / 2];
      foreach (item.txn.data[i]) item.txn.data[i] = 32'h0;
      foreach (bytes[i])
        item.txn.data[i/2][(i%2)*16 +: 8] = bytes[i];

      // CRC-32 re-computation over the payload
      calc_crc = mipi_crc32(bytes);
      item.txn.inject_err = (calc_crc != item.txn.crc) || (vif.mon_cb.err === 1'b1);
      if (item.txn.inject_err) error_count++;

      analysis_port.write(item);
      txn_count++;
    endtask

    function void report_phase(uvm_phase phase);
      `uvm_info("MONITOR", $sformatf("Observed %0d transactions (%0d CRC errors)",
                txn_count, error_count), UVM_LOW)
    endfunction
  endclass

  //==========================================================================
  // Functional coverage
  //   cg_mipi      : protocol / packet-type / VC / lane / mode + crosses
  //   cg_wc        : word-count corners cross packet type
  //   cg_lane_fsm  : lane-state bins + HS entry/exit transition sequences
  //==========================================================================
  class mipi_cov extends uvm_component;
    `uvm_component_utils(mipi_cov)

    // Coverpoint sample variables (declared before the covergroups that
    // reference them, per IEEE 1800 declaration-before-use rules)
    mipi_protocol_e   txn_protocol;
    mipi_pkt_type_e   txn_pkt;
    mipi_vc_e         txn_vc;
    int               txn_lane;
    int               txn_mode;
    int               txn_wc;

    covergroup cg_mipi;
      option.per_instance = 1;
      cp_prot: coverpoint txn_protocol {
        bins csi2   = {MIPI_CSI2};
        bins dsi    = {MIPI_DSI};
        bins dphy   = {MIPI_DPHY};
        bins cphy   = {MIPI_CPHY};
        bins mphy   = {MIPI_MPHY};
        bins unipro = {MIPI_UNIPRO};
        bins digrf  = {MIPI_DIGRF};
        bins hsi    = {MIPI_HSI};
        bins cse    = {MIPI_CSE};
      }
      cp_pkt: coverpoint txn_pkt {
        bins fs     = {PKT_FS};
        bins fe     = {PKT_FE};
        bins ls     = {PKT_LS};
        bins le     = {PKT_LE};
        bins rgb    = {PKT_RGB565, PKT_RGB666, PKT_RGB888};
        bins raw    = {PKT_RAW6, PKT_RAW8, PKT_RAW10, PKT_RAW12};
        bins yuv    = {PKT_YUV422_8B, PKT_YUV422_10B};
        bins user   = {[PKT_USER_0:PKT_USER_7]};
        bins null_b = {PKT_NULL, PKT_BLANK};
      }
      cp_vc: coverpoint txn_vc {
        bins vc0   = {VC_0};
        bins vc1   = {VC_1};
        bins vc2   = {VC_2};
        bins vc3   = {VC_3};
        bins vc4_7 = {[VC_4:VC_7]};
      }
      cp_lane: coverpoint txn_lane {
        bins x1 = {1};
        bins x2 = {2};
        bins x3 = {3};
        bins x4 = {4};
      }
      cp_mode: coverpoint txn_mode {
        bins lp   = {0};
        bins hs   = {1};
        bins ulps = {2};
      }
      cross_pkt_vc:    cross cp_pkt, cp_vc;
      cross_prot_lane: cross cp_prot, cp_lane;
    endgroup

    covergroup cg_wc;
      option.per_instance = 1;
      cp_wc: coverpoint txn_wc {
        bins single  = {1};
        bins short   = {[2:15]};
        bins mid     = {[16:255]};
        bins long    = {[256:1023]};
        bins max_len = {[1024:4095]};
      }
      cp_pkt: coverpoint txn_pkt {
        bins sync  = {PKT_FS, PKT_FE, PKT_LS, PKT_LE};
        bins video = {PKT_RGB565, PKT_RGB666, PKT_RGB888};
        bins raw   = {PKT_RAW6, PKT_RAW8, PKT_RAW10, PKT_RAW12};
        bins user  = {[PKT_USER_0:PKT_USER_7]};
        bins ctrl  = {PKT_NULL, PKT_BLANK, PKT_EMBEDDED};
      }
      cross_wc_pkt: cross cp_wc, cp_pkt;
    endgroup

    covergroup cg_lane_fsm with function sample(mipi_lane_state_e s);
      option.per_instance = 1;
      cp_state: coverpoint s {
        bins stop  = {ST_STOP};
        bins hs    = {ST_HS_REQ, ST_HS_ZERO, ST_HS_SYNC, ST_HS_DATA};
        bins trail = {ST_HS_TRAIL, ST_HS_EXIT};
        bins lp    = {ST_LP11, ST_LP00, ST_LP01, ST_LP10};
        bins ulps  = {ST_ULPS};
      }
      cp_trans: coverpoint s {
        bins hs_entry = (ST_STOP => ST_HS_REQ => ST_HS_ZERO => ST_HS_SYNC => ST_HS_DATA);
        bins hs_exit  = (ST_HS_DATA => ST_HS_TRAIL => ST_HS_EXIT => ST_STOP);
        bins ulps_seq = (ST_STOP => ST_ULPS => ST_STOP);
      }
    endgroup

    mipi_lane_state_e txn_lane_state;

    uvm_analysis_imp #(mipi_seq_item, mipi_cov) analysis_export;

    function new(string name = "mipi_cov", uvm_component parent = null);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      cg_mipi = new();
      cg_wc = new();
      cg_lane_fsm = new();
    endfunction

    // analysis entry: sample transaction + derived lane state
    virtual function void write(mipi_seq_item item);
      mipi_lane_state_e s;
      sample(item.txn);
      s = item.txn.ulps    ? ST_ULPS :
          item.txn.hs_mode ? ST_HS_DATA :
          item.txn.lp_mode ? ST_LP11 : ST_STOP;
      sample_lane_state(s);
    endfunction

    function void sample(mipi_txn t);
      txn_protocol = t.protocol;
      txn_pkt      = t.pkt_type;
      txn_vc       = t.vc;
      txn_lane     = t.lane_count;
      txn_mode     = t.lp_mode ? 0 : (t.hs_mode ? 1 : 2);
      txn_wc       = t.word_count;
      cg_mipi.sample();
      cg_wc.sample();
    endfunction

    function void sample_lane_state(mipi_lane_state_e s);
      cg_lane_fsm.sample(s);
    endfunction

    function real get_cov();
      return (cg_mipi.get_coverage() + cg_wc.get_coverage() +
              cg_lane_fsm.get_coverage()) / 3.0;
    endfunction
  endclass

  //==========================================================================
  // End-to-end scoreboard
  //==========================================================================
  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  class mipi_sb extends uvm_scoreboard;
    `uvm_component_utils(mipi_sb)

    uvm_analysis_imp_exp #(mipi_seq_item, mipi_sb) exp_ap;
    uvm_analysis_imp_obs #(mipi_seq_item, mipi_sb) obs_ap;

    // Legacy single-port analysis imp (backward compatible)
    uvm_analysis_imp #(mipi_seq_item, mipi_sb) analysis_imp;

    mipi_seq_item exp_q[$], obs_q[$];
    int txn_cnt, err_cnt;
    int unsigned n_matches;
    int unsigned n_mismatches;

    function new(string name = "mipi_sb", uvm_component parent = null);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
      analysis_imp = new("analysis_imp", this);
      txn_cnt = 0;
      err_cnt = 0;
      n_matches = 0;
      n_mismatches = 0;
    endfunction

    virtual function void write(mipi_seq_item item);
      // legacy entry: treat as observed
      write_obs(item);
    endfunction

    virtual function void write_exp(mipi_seq_item t);
      exp_q.push_back(t);
      txn_cnt++;
      check();
    endfunction

    virtual function void write_obs(mipi_seq_item t);
      obs_q.push_back(t);
      if (t.txn.inject_err) err_cnt++;
      check();
    endfunction

    virtual function void check();
      while (exp_q.size() > 0 && obs_q.size() > 0) begin
        mipi_seq_item e = exp_q.pop_front();
        mipi_seq_item o = obs_q.pop_front();
        if (compare_txn(e, o)) begin
          n_matches++;
        end else begin
          n_mismatches++;
          `uvm_error("SCOREBOARD", $sformatf("end-to-end mismatch\n  exp: %s\n  obs: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    // Injected CRC errors count as a match only when detected by the monitor
    virtual function bit compare_txn(mipi_seq_item e, mipi_seq_item o);
      if (e.txn.inject_err)
        return (o.txn.inject_err == 1'b1);
      if (o.txn.inject_err) return 0;
      if (e.txn.protocol != o.txn.protocol) return 0;
      if (e.txn.pkt_type != o.txn.pkt_type) return 0;
      if (e.txn.vc != o.txn.vc) return 0;
      if (e.txn.word_count != o.txn.word_count) return 0;
      for (int i = 0; i < e.txn.word_count; i++) begin
        if (e.txn.data[i/2][(i%2)*16 +: 8] != o.txn.data[i/2][(i%2)*16 +: 8])
          return 0;
      end
      return 1;
    endfunction

    virtual function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("TXN:%0d ERR:%0d n_matches=%0d n_mismatches=%0d",
                txn_cnt, err_cnt, n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches > 0)
        `uvm_error("SCOREBOARD", "end-to-end n_mismatches detected")
    endfunction
  endclass

  //==========================================================================
  // Agent
  //==========================================================================
  class mipi_agent extends uvm_agent;
    `uvm_component_utils(mipi_agent)

    mipi_sequencer sqr;
    mipi_driver    drv;
    mipi_monitor   mon;

    uvm_analysis_port #(mipi_seq_item) ap;

    function new(string name = "mipi_agent", uvm_component parent = null);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = mipi_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = mipi_sequencer::type_id::create("sqr", this);
        drv = mipi_driver::type_id::create("drv", this);
      end
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
      mon.analysis_port.connect(ap);
    endfunction
  endclass

  //==========================================================================
  // Sequence library
  //==========================================================================
  class mipi_base_sequence extends uvm_sequence #(mipi_seq_item);
    `uvm_object_utils(mipi_base_sequence)

    rand int num_frames;
    rand mipi_protocol_e target_protocol;

    constraint c_num { num_frames inside {[10:200]}; }

    function new(string name = "mipi_base_sequence");
      super.new(name);
    endfunction

    virtual task body();
      repeat (num_frames) begin
        mipi_seq_item item;
        item = mipi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { txn.protocol == target_protocol; })
          `uvm_error("SEQ", "Randomization failed")
        finish_item(item);
      end
    endtask
  endclass

  // Directed: HSI data frames on multiple logical channels
  class mipi_hsi_sequence extends mipi_base_sequence;
    `uvm_object_utils(mipi_hsi_sequence)
    function new(string name = "mipi_hsi_sequence");
      super.new(name);
    endfunction
    virtual task body();
      repeat (num_frames) begin
        mipi_seq_item item;
        item = mipi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          txn.protocol == MIPI_HSI;
          txn.hs_mode  == 1;
          txn.lp_mode  == 0;
          txn.vc       inside {VC_0, VC_1, VC_2, VC_3};
          txn.inject_err == 0;
        }) `uvm_error("SEQ", "HSI randomization failed")
        finish_item(item);
      end
    endtask
  endclass

  // Directed: DigRF I/Q frames across antennas with frame sync
  class mipi_digrf_sequence extends mipi_base_sequence;
    `uvm_object_utils(mipi_digrf_sequence)
    function new(string name = "mipi_digrf_sequence");
      super.new(name);
    endfunction
    virtual task body();
      repeat (num_frames) begin
        mipi_seq_item item;
        item = mipi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          txn.protocol == MIPI_DIGRF;
          txn.hs_mode  == 1;
          txn.lp_mode  == 0;
          txn.vc       inside {VC_0, VC_1, VC_2, VC_3};
          txn.word_count inside {[2:256]};
          txn.inject_err == 0;
        }) `uvm_error("SEQ", "DigRF randomization failed")
        finish_item(item);
      end
    endtask
  endclass

  // Directed: back-to-back frames with zero inter-packet delay
  class mipi_back_to_back_sequence extends mipi_base_sequence;
    `uvm_object_utils(mipi_back_to_back_sequence)
    function new(string name = "mipi_back_to_back_sequence");
      super.new(name);
    endfunction
    virtual task body();
      repeat (num_frames) begin
        mipi_seq_item item;
        item = mipi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          txn.protocol == target_protocol;
          txn.delay    == 0;
          txn.word_count inside {[1:16]};
        }) `uvm_error("SEQ", "Back-to-back randomization failed")
        finish_item(item);
      end
    endtask
  endclass

  // Corner: maximum-length payloads
  class mipi_max_payload_sequence extends mipi_base_sequence;
    `uvm_object_utils(mipi_max_payload_sequence)
    function new(string name = "mipi_max_payload_sequence");
      super.new(name);
    endfunction
    virtual task body();
      repeat (num_frames) begin
        mipi_seq_item item;
        item = mipi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          txn.protocol   == target_protocol;
          txn.word_count inside {[4090:4095]};
        }) `uvm_error("SEQ", "Max-payload randomization failed")
        finish_item(item);
      end
    endtask
  endclass

  // Error injection: corrupted CRC must be detected by the monitor
  class mipi_error_inject_sequence extends mipi_base_sequence;
    `uvm_object_utils(mipi_error_inject_sequence)
    function new(string name = "mipi_error_inject_sequence");
      super.new(name);
    endfunction
    virtual task body();
      repeat (num_frames) begin
        mipi_seq_item item;
        item = mipi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          txn.protocol   == target_protocol;
          txn.inject_err == 1;
        }) `uvm_error("SEQ", "Error-inject randomization failed")
        finish_item(item);
      end
    endtask
  endclass

  // Reset behavior: single short frame right after reset release
  class mipi_reset_sequence extends mipi_base_sequence;
    `uvm_object_utils(mipi_reset_sequence)
    function new(string name = "mipi_reset_sequence");
      super.new(name);
    endfunction
    virtual task body();
      mipi_seq_item item;
      item = mipi_seq_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol   == target_protocol;
        txn.word_count == 1;
        txn.delay      == 0;
      }) `uvm_error("SEQ", "Reset randomization failed")
      finish_item(item);
    endtask
  endclass

  // Stress: long randomized burst across VCs and sizes
  class mipi_stress_sequence extends mipi_base_sequence;
    `uvm_object_utils(mipi_stress_sequence)
    function new(string name = "mipi_stress_sequence");
      super.new(name);
    endfunction
    virtual task body();
      repeat (num_frames) begin
        mipi_seq_item item;
        item = mipi_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          txn.protocol == target_protocol;
          txn.word_count dist {1 := 20, [2:64] := 50, [65:512] := 20, [513:4095] := 10};
          txn.delay inside {[0:4]};
        }) `uvm_error("SEQ", "Stress randomization failed")
        finish_item(item);
      end
    endtask
  endclass

  // Regression: weighted mix of all directed sequences
  class mipi_regression_sequence extends mipi_base_sequence;
    `uvm_object_utils(mipi_regression_sequence)
    function new(string name = "mipi_regression_sequence");
      super.new(name);
    endfunction
    virtual task body();
      mipi_hsi_sequence          hsi_seq;
      mipi_back_to_back_sequence b2b_seq;
      mipi_max_payload_sequence  max_seq;
      mipi_error_inject_sequence err_seq;
      mipi_stress_sequence       stress_seq;

      b2b_seq = mipi_back_to_back_sequence::type_id::create("b2b_seq");
      b2b_seq.num_frames = num_frames / 4 + 1;
      b2b_seq.target_protocol = target_protocol;
      b2b_seq.start(m_sequencer);

      max_seq = mipi_max_payload_sequence::type_id::create("max_seq");
      max_seq.num_frames = 2;
      max_seq.target_protocol = target_protocol;
      max_seq.start(m_sequencer);

      err_seq = mipi_error_inject_sequence::type_id::create("err_seq");
      err_seq.num_frames = 4;
      err_seq.target_protocol = target_protocol;
      err_seq.start(m_sequencer);

      stress_seq = mipi_stress_sequence::type_id::create("stress_seq");
      stress_seq.num_frames = num_frames / 2 + 1;
      stress_seq.target_protocol = target_protocol;
      stress_seq.start(m_sequencer);

      if (target_protocol == MIPI_HSI) begin
        hsi_seq = mipi_hsi_sequence::type_id::create("hsi_seq");
        hsi_seq.num_frames = num_frames / 4 + 1;
        hsi_seq.start(m_sequencer);
      end

      if (target_protocol == MIPI_DIGRF) begin
        mipi_digrf_sequence drf_seq;
        drf_seq = mipi_digrf_sequence::type_id::create("drf_seq");
        drf_seq.num_frames = num_frames / 4 + 1;
        drf_seq.start(m_sequencer);
      end
    endtask
  endclass

endpackage
`endif
