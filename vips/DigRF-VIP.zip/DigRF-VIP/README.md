# DigRF — MIPI DigRFv4 UVM VIP

Open-source UVM verification IP for **MIPI DigRFv4** (BBIC↔RFIC digital
interface: frame sync, I/Q sample transport, antenna select, blanking,
rate/gear control), built on the shared `mipi_*` infrastructure that also
carries CSI-2/DSI/D-PHY/C-PHY/M-PHY/UniPro/HSI/CSE sideband layers.

## Contents

| Path | Description |
|------|-------------|
| `rtl/mipi_vip_if.sv` | Protocol interface (generic packet layer + all MIPI sidebands, DigRF aliases: mrd/data_type/frame/subframe/antenna_id/iq_valid/iq_data/sync/rate/blank) |
| `vip/base/mipi_vip_pkg.sv` | Enums, `mipi_txn` (real CRC-32/ECC), sequencer/driver/monitor/agent, coverage model, end-to-end scoreboard, sequence library |
| `vip/digrf/digrf_protocol_checker.sv` | DigRF SVA: frame-sync/valid, antenna range, I/Q known |
| `vip/<proto>/...` | Companion protocol checkers (csi2/dsi/dphy/cphy/mphy/unipro/hsi/cse) |
| `rtl/sva/digrf_compliance_checker.sv` | Tiered SVA compliance checker (L1=4, L2=4, L3=0, L4=5) |
| `env/mipi_env.sv` | Environment: agent + scoreboard + coverage + checkers |
| `tests/mipi_tests.sv` | base + per-protocol tests |
| `tb/top_tb.sv` | Testbench top + functional DUT (DigRF RFIC model) |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Architecture

```
sequence -> mipi_sequencer -> mipi_driver --drv_ap--> mipi_sb (expected)
                                     |
   frame_sync/antenna/I-Q sideband   |  packet beats (sop..eop, valid/ready)
                                     v
                                mipi_vip_if <--> mipi_dut (DigRF RFIC model:
                                     |           ready backpressure, sync
                                     v           tracking, CRC check, err)
                               mipi_monitor --ap--> mipi_sb (observed)
                                     +-> mipi_cov (3 covergroups)
                                     +-> digrf_protocol_checker + SVA L1-L4
```

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `mipi_base_sequence` | constrained-random packets |
| `mipi_digrf_sequence` | directed DigRF I/Q frames, antenna/VC sweep, frame sync |
| `mipi_back_to_back_sequence` | zero-delay back-to-back stress |
| `mipi_max_payload_sequence` | corner: 4090–4095 byte payloads |
| `mipi_error_inject_sequence` | corrupted CRC (must be detected) |
| `mipi_reset_sequence` | frame right after reset release |
| `mipi_stress_sequence` | weighted-size stress burst |
| `mipi_regression_sequence` | mix of all of the above |

## SVA compliance checker

- **L1 (4)**: MRD data type legal, subframe 0–15, antenna 0–15, I/Q known
- **L2 (4)**: sync only when idle, rate encoding legal, blank only when
  idle, no-X when valid
- **L4 (5)**: frame sync precedes I/Q frame, I/Q known during frame, antenna
  stable mid-frame, no blanking during frame, blanking follows frame end

## Functional coverage

- `cg_mipi`: protocol / packet-type / VC / lane / mode + pkt×VC, prot×lane cross
- `cg_wc`: word-count corners × packet-type cross
- `cg_lane_fsm`: lane-state bins + HS entry/exit/ULPS transition sequences
- interface `cg_mipi_if`: pkt×VC cross + per-layer activity (incl. DigRF)

## Quick start

```bash
cd scripts
make all                        # TEST=mipi_csi2_test (default)
make run TEST=mipi_digrf_test
./coverage_regression.sh        # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.4.0)

- **Driver**: real DigRFv4 link behavior — frame sync pulse, antenna select,
  12-bit I/Q sample sideband from the payload stream, subframe counting,
  blanking at frame end, valid/ready flow control, corrupt-CRC injection
- **Monitor**: SOP→EOP packet reassembly, word-count trim, **CRC-32
  re-computation** and error classification, analysis-port publish
- **End-to-end scoreboard**: expected-vs-observed pairing with payload
  compare; injected CRC errors must be *detected* to match
  (`n_matches`/`n_mismatches`, `UVM_ERROR` on mismatch)
- **Functional DUT**: DigRF RFIC model (ready backpressure, frame-sync
  tracking, frame capture, CRC check, `err` flag) closing the loop
- **Coverage**: 3 covergroups (protocol config, word-count data patterns,
  lane-FSM transitions) with crosses + analysis-driven sampling
- **SVA L4**: five DigRFv4-specific rules on top of the tiered L1/L2 set
