// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// mipi_tests.sv -- MIPI test library (HSI VIP)
// Base test builds mipi_env and wires vif/protocol; each protocol test
// selects its protocol and stimulus.

`ifndef MIPI_TESTS_SV
`define MIPI_TESTS_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import mipi_vip_pkg::*;

class mipi_base_test extends uvm_test;
  `uvm_component_utils(mipi_base_test)

  mipi_env        env;
  mipi_protocol_e protocol;
  int             num_frames;

  function new(string name = "mipi_base_test", uvm_component parent = null);
    super.new(name, parent);
    protocol   = MIPI_DIGRF;
    num_frames = 20;
  endfunction

  virtual function void build_phase(uvm_phase phase);
    virtual mipi_vip_if vif;
    super.build_phase(phase);
    if (!uvm_config_db#(virtual mipi_vip_if)::get(this, "", "mipi_vif", vif))
      `uvm_fatal("NOVIF", "mipi virtual interface not found")
    uvm_config_db#(virtual mipi_vip_if)::set(this, "env.agt.*", "vif", vif);
    uvm_config_db#(virtual mipi_vip_if)::set(this, "env.digrf_chk", "vif", vif);
    uvm_config_db#(virtual mipi_vip_if)::set(this, "env.sva_chk", "vif", vif);
    uvm_config_db#(mipi_protocol_e)::set(this, "env.agt.*", "protocol", protocol);
    env = mipi_env::type_id::create("env", this);
  endfunction

  virtual task run_phase(uvm_phase phase);
    mipi_base_sequence seq;
    phase.raise_objection(this);
    seq = mipi_base_sequence::type_id::create("seq");
    seq.num_frames = num_frames;
    seq.target_protocol = protocol;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class mipi_csi2_test extends mipi_base_test;
  `uvm_component_utils(mipi_csi2_test)
  function new(string name = "mipi_csi2_test", uvm_component parent = null);
    super.new(name, parent);
    protocol = MIPI_CSI2;
  endfunction
endclass

class mipi_dsi_test extends mipi_base_test;
  `uvm_component_utils(mipi_dsi_test)
  function new(string name = "mipi_dsi_test", uvm_component parent = null);
    super.new(name, parent);
    protocol = MIPI_DSI;
  endfunction
endclass

class mipi_dphy_test extends mipi_base_test;
  `uvm_component_utils(mipi_dphy_test)
  function new(string name = "mipi_dphy_test", uvm_component parent = null);
    super.new(name, parent);
    protocol = MIPI_DPHY;
  endfunction
endclass

class mipi_cphy_test extends mipi_base_test;
  `uvm_component_utils(mipi_cphy_test)
  function new(string name = "mipi_cphy_test", uvm_component parent = null);
    super.new(name, parent);
    protocol = MIPI_CPHY;
  endfunction
endclass

class mipi_mphy_test extends mipi_base_test;
  `uvm_component_utils(mipi_mphy_test)
  function new(string name = "mipi_mphy_test", uvm_component parent = null);
    super.new(name, parent);
    protocol = MIPI_MPHY;
  endfunction
endclass

class mipi_unipro_test extends mipi_base_test;
  `uvm_component_utils(mipi_unipro_test)
  function new(string name = "mipi_unipro_test", uvm_component parent = null);
    super.new(name, parent);
    protocol = MIPI_UNIPRO;
  endfunction
endclass

class mipi_digrf_test extends mipi_base_test;
  `uvm_component_utils(mipi_digrf_test)
  function new(string name = "mipi_digrf_test", uvm_component parent = null);
    super.new(name, parent);
    protocol   = MIPI_DIGRF;
    num_frames = 32;
  endfunction
  virtual task run_phase(uvm_phase phase);
    mipi_regression_sequence seq;
    phase.raise_objection(this);
    seq = mipi_regression_sequence::type_id::create("seq");
    seq.num_frames = num_frames;
    seq.target_protocol = protocol;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class mipi_hsi_test extends mipi_base_test;
  `uvm_component_utils(mipi_hsi_test)
  function new(string name = "mipi_hsi_test", uvm_component parent = null);
    super.new(name, parent);
    protocol   = MIPI_HSI;
    num_frames = 32;
  endfunction
  virtual task run_phase(uvm_phase phase);
    mipi_regression_sequence seq;
    phase.raise_objection(this);
    seq = mipi_regression_sequence::type_id::create("seq");
    seq.num_frames = num_frames;
    seq.target_protocol = protocol;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class mipi_cse_test extends mipi_base_test;
  `uvm_component_utils(mipi_cse_test)
  function new(string name = "mipi_cse_test", uvm_component parent = null);
    super.new(name, parent);
    protocol = MIPI_CSE;
  endfunction
endclass
`endif
