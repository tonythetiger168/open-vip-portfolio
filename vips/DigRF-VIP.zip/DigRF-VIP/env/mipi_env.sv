// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// mipi_env.sv -- MIPI verification environment (DigRFv4 focus)
// Agent + end-to-end scoreboard + functional coverage + DigRF protocol
// checker + tiered SVA compliance checker.

`ifndef MIPI_ENV_SV
`define MIPI_ENV_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import mipi_vip_pkg::*;

// Tiered L1/L2/L3 + L4 SVA compliance checker (compiled via include path rtl/)
`include "sva/digrf_compliance_checker.sv"

class mipi_env extends uvm_env;
  `uvm_component_utils(mipi_env)

  mipi_agent               agt;
  mipi_cov                 cov;
  mipi_sb                  sb;

  // Protocol checkers
  digrf_protocol_checker   digrf_chk;
  digrf_compliance_checker sva_chk;

  function new(string name = "mipi_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agt       = mipi_agent::type_id::create("agt", this);
    cov       = mipi_cov::type_id::create("cov", this);
    sb        = mipi_sb::type_id::create("sb", this);
    digrf_chk = digrf_protocol_checker::type_id::create("digrf_chk", this);
    sva_chk   = digrf_compliance_checker::type_id::create("sva_chk", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    // end-to-end: expected (driver) vs observed (monitor)
    agt.drv.drv_ap.connect(sb.exp_ap);
    agt.mon.analysis_port.connect(sb.obs_ap);
    // functional coverage follows the observed stream
    agt.mon.analysis_port.connect(cov.analysis_export);
  endfunction

  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("ENV_RPT", "MIPI VIP Done", UVM_LOW);
    `uvm_info("COV", $sformatf(" Coverage: %0.2f%%", cov.get_cov()), UVM_LOW);
  endfunction
endclass
`endif
