// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- MIPI testbench top (DigRFv4 VIP)
// Single MIPI interface + functional DUT (mipi_dut): DigRF RFIC-side model
// with frame-sync capture, ready backpressure, packet CRC check and error
// flagging. Closes the loop with the UVM monitor.

`ifndef TOP_TB_SV
`define TOP_TB_SV

`include "uvm_macros.svh"
import uvm_pkg::*;
import mipi_vip_pkg::*;

module top_tb;

  logic clk = 0;
  logic rst_n;
  always #2ns clk = ~clk;   // 250MHz

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  mipi_vip_if #(.DATA_WIDTH(32), .LANE_COUNT(4)) mipi_if(clk, rst_n);

  mipi_dut dut (.vif(mipi_if));

  // Tiered SVA compliance checker (module form)
  digrf_compliance_checker_sva u_digrf_sva_chk (.vif(mipi_if));

  // Protocol-specific SVA checkers (module form)
  digrf_protocol_checker_sva  u_digrf_proto_sva  (.vif(mipi_if));
  cphy_protocol_checker_sva   u_cphy_proto_sva   (.vif(mipi_if));
  cse_protocol_checker_sva    u_cse_proto_sva    (.vif(mipi_if));
  csi2_protocol_checker_sva   u_csi2_proto_sva   (.vif(mipi_if));
  dphy_protocol_checker_sva   u_dphy_proto_sva   (.vif(mipi_if));
  dsi_protocol_checker_sva    u_dsi_proto_sva    (.vif(mipi_if));
  mphy_protocol_checker_sva   u_mphy_proto_sva   (.vif(mipi_if));
  unipro_protocol_checker_sva u_unipro_proto_sva (.vif(mipi_if));

  initial begin
    uvm_config_db#(virtual mipi_vip_if)::set(null, "*", "mipi_vif", mipi_if);
    run_test();
  end
endmodule

//==========================================================================
// Functional MIPI DUT: DigRF RFIC / generic packet sink.
//  - generates ready with light randomized backpressure
//  - answers PHY handshakes (dphy_hs_rdy / mphy_ready / unipro_ready /
//    hsi_ready / cse_ready)
//  - tracks DigRF frame sync, captures packets, re-computes CRC-32 and
//    raises err on mismatch
//==========================================================================
module mipi_dut (mipi_vip_if vif);

  function automatic bit [31:0] crc32(ref bit [7:0] bytes[$]);
    bit [31:0] c;
    c = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      c ^= bytes[i];
      for (int b = 0; b < 8; b++)
        c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    return ~c;
  endfunction

  bit [7:0] frame_q[$];
  bit       in_frame;
  int       bp_timer;
  int       drf_frame_cnt;

  // Ready / handshake generation
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      vif.ready         <= 1'b0;
      vif.hsi_ready     <= 1'b0;
      vif.dphy_hs_rdy   <= 1'b0;
      vif.mphy_ready    <= 1'b0;
      vif.unipro_ready  <= 1'b0;
      vif.cse_ready     <= 1'b0;
      vif.err           <= 1'b0;
      bp_timer          <= 0;
    end else begin
      // light backpressure: ready drops for 1 cycle every ~16 cycles
      if (bp_timer >= 15) begin
        bp_timer  <= 0;
        vif.ready <= 1'b0;
      end else begin
        bp_timer  <= bp_timer + 1;
        vif.ready <= 1'b1;
      end
      vif.hsi_ready    <= vif.hsi_wake | vif.hsi_valid;
      vif.dphy_hs_rdy  <= vif.dphy_hs_rqst;
      vif.mphy_ready   <= 1'b1;
      vif.unipro_ready <= vif.unipro_valid;
      vif.cse_ready    <= vif.cse_valid;
      vif.err          <= 1'b0;
    end
  end

  // DigRF frame tracking (sync starts a frame, blank ends it)
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      drf_frame_cnt <= 0;
    end else begin
      if (vif.digrf_frame_sync)
        drf_frame_cnt <= drf_frame_cnt + 1;
    end
  end

  // Frame capture + CRC check
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      frame_q.delete();
      in_frame <= 0;
    end else begin
      if (vif.valid && vif.ready) begin
        if (vif.sop) begin
          frame_q.delete();
          in_frame <= 1;
        end
        if (in_frame || vif.sop) begin
          for (int j = 0; j < 4; j++)
            frame_q.push_back(vif.data[j*8 +: 8]);
        end
        if (vif.eop) begin
          bit [31:0] calc;
          in_frame <= 0;
          while (frame_q.size() > vif.word_count)
            void'(frame_q.pop_back());
          calc = crc32(frame_q);
          if (calc != vif.crc)
            vif.err <= 1'b1;   // CRC mismatch: flag receiver error
        end
      end
    end
  end
endmodule
`endif
