// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_mipi_tb.sv -- self-checking functional test for the MIPI DigRF frame sink
// model (mipi_dut, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py DigRF-VIP
//
// Model contract (from tb/top_tb.sv):
//   * ready is high for 15 clocks and low for 1 (periodic backpressure);
//     a beat is taken when valid && ready.
//   * a frame runs from the sop beat to the eop beat, 4 bytes per beat,
//     byte 0 in data[7:0]; at eop the byte stream is cut to word_count bytes
//     and checked against crc (IEEE 802.3 CRC-32, reflected, init and final
//     xor 0xFFFFFFFF). A mismatch pulses err for one clock.
//   * side-band: hsi_ready <= hsi_wake | hsi_valid, dphy_hs_rdy <= dphy_hs_rqst,
//     unipro/cse ready <= valid, mphy_ready is 1 out of reset.
//   * DigRF: each clock with digrf_frame_sync high counts one frame.
// The CRC reference is anchored on the standard check value
// CRC-32("123456789") = 0xCBF43926.

`timescale 1ns/1ps

module func_mipi_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [31:0] data = '0, crc = '0;
  logic        valid = 1'b0, sop = 1'b0, eop = 1'b0;
  logic [15:0] word_count = '0;
  logic        dphy_hs_rqst = 0, unipro_valid = 0, hsi_valid = 0, hsi_wake = 0, cse_valid = 0;
  logic        frame_sync = 0;
  wire         ready, dphy_hs_rdy, mphy_ready, unipro_ready, hsi_ready, cse_ready, err;

  always #5 clk = ~clk;

  mipi_dut u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_data(data), .vif_valid(valid), .vif_ready(ready),
    .vif_sop(sop), .vif_eop(eop), .vif_word_count(word_count), .vif_crc(crc),
    .vif_dphy_hs_rqst(dphy_hs_rqst), .vif_dphy_hs_rdy(dphy_hs_rdy), .vif_mphy_ready(mphy_ready),
    .vif_unipro_valid(unipro_valid), .vif_unipro_ready(unipro_ready),
    .vif_digrf_frame_sync(frame_sync),
    .vif_hsi_valid(hsi_valid), .vif_hsi_ready(hsi_ready), .vif_hsi_wake(hsi_wake), .vif_err(err),
    .vif_cse_valid(cse_valid), .vif_cse_ready(cse_ready)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [31:0] ref_crc32(input logic [7:0] b[$], input int n);
    logic [31:0] c = 32'hFFFF_FFFF;
    for (int i = 0; i < n; i++)
      for (int k = 0; k < 8; k++) begin
        logic fb = c[0] ^ b[i][k];
        c = c >> 1;
        if (fb) c ^= 32'hEDB8_8320;
      end
    return ~c;
  endfunction

  // err pulses seen since the last clear
  int err_cnt;
  always @(posedge clk) if (err === 1'b1) err_cnt++;

  // send a frame of 'n' bytes from 'b' (padded to whole beats); crc_xor
  // corrupts the CRC. Returns the number of clocks spent stalled on ready.
  int stalls;
  task automatic send_frame(input logic [7:0] b[$], input int n, input logic [31:0] crc_xor = 0,
                            input int pad_val = 8'hEE);
    int nb = (n + 3) / 4;
    logic [7:0] q[$] = b;
    while (q.size() < nb * 4) q.push_back(pad_val);
    stalls = 0;
    for (int i = 0; i < nb; i++) begin
      @(negedge clk);
      valid = 1; sop = (i == 0); eop = (i == nb - 1);
      data = {q[4*i+3], q[4*i+2], q[4*i+1], q[4*i]};
      word_count = n; crc = ref_crc32(b, n) ^ crc_xor;
      @(posedge clk);
      while (!ready) begin stalls++; @(posedge clk); end
    end
    @(negedge clk);
    valid = 0; sop = 0; eop = 0;
    repeat (2) @(negedge clk);
  endtask

  logic [7:0] chkstr[$] = '{"1", "2", "3", "4", "5", "6", "7", "8", "9"};
  logic [7:0] big[$];
  int lows, period, last_low, first_low;

  initial begin
    repeat (2) @(negedge clk);
    chk(!ready && !mphy_ready && !err, "outputs held low in reset");
    rst_n = 1;
    @(negedge clk);
    chk(mphy_ready === 1'b1, "M-PHY ready out of reset");

    chk(ref_crc32(chkstr, 9) == 32'hCBF4_3926, "CRC-32 reference matches the standard check value");

    // periodic backpressure: one ready-low clock in every 16
    lows = 0; last_low = -1; first_low = -1; period = 0;
    for (int t = 0; t < 64; t++) begin
      @(negedge clk);
      if (!ready) begin
        if (last_low >= 0 && period == 0) period = t - last_low;
        if (first_low < 0) first_low = t;
        last_low = t; lows++;
      end
    end
    chk(lows == 4 && period == 16, $sformatf("ready low 1 clock in 16 (lows=%0d period=%0d)", lows, period));

    // good frames: no error
    err_cnt = 0;
    send_frame(chkstr, 9);
    chk(err_cnt == 0, "frame with the correct CRC raises no error");
    chk(u_dut.frame_q.size() == 9, "frame cut to word_count bytes (padding dropped)");
    send_frame(chkstr, 9, 0, 8'h00);
    chk(err_cnt == 0, "padding bytes are excluded from the CRC");

    // long frame across ready-low stalls
    big.delete();
    for (int i = 0; i < 128; i++) big.push_back(i * 7 + 3);
    send_frame(big, 126);
    chk(stalls > 0, "long frame spans at least one ready-low stall");
    chk(err_cnt == 0 && u_dut.frame_q.size() == 126, "frame held across backpressure is received intact");

    // bad CRC: one-clock err pulse
    send_frame(chkstr, 9, 32'h0000_0100);
    chk(err_cnt == 1, "wrong CRC pulses err once");
    err_cnt = 0;
    send_frame(big, 126, 32'h8000_0000);
    chk(err_cnt == 1, "wrong CRC on a long frame pulses err once");

    // payload corruption caught (CRC computed over different data)
    err_cnt = 0;
    begin
      logic [7:0] bad[$] = chkstr;
      // drive bytes of 'bad' with the CRC of chkstr
      bad[4] = "X";
      @(negedge clk);
      valid = 1; sop = 1; eop = 0; word_count = 9; data = {bad[3], bad[2], bad[1], bad[0]};
      crc = ref_crc32(chkstr, 9);
      @(posedge clk); while (!ready) @(posedge clk);
      @(negedge clk); sop = 0; data = {bad[7], bad[6], bad[5], bad[4]};
      @(posedge clk); while (!ready) @(posedge clk);
      @(negedge clk); eop = 1; data = {24'h0, bad[8]};
      @(posedge clk); while (!ready) @(posedge clk);
      @(negedge clk); valid = 0; eop = 0;
      repeat (2) @(negedge clk);
    end
    chk(err_cnt == 1, "corrupted payload byte detected by CRC");

    // beats without sop are not collected
    @(negedge clk); valid = 1; data = 32'hDEAD_BEEF;
    @(negedge clk); @(negedge clk); valid = 0;
    chk(u_dut.in_frame === 1'b0, "beats outside a frame are ignored");

    // side-band handshakes
    @(negedge clk); hsi_wake = 1;
    @(negedge clk); chk(hsi_ready === 1'b1, "HSI wake raises hsi_ready");
    hsi_wake = 0; hsi_valid = 1;
    @(negedge clk); chk(hsi_ready === 1'b1, "HSI valid raises hsi_ready");
    hsi_valid = 0;
    @(negedge clk); chk(hsi_ready === 1'b0, "hsi_ready drops without wake/valid");
    dphy_hs_rqst = 1; unipro_valid = 1; cse_valid = 1;
    @(negedge clk); chk(dphy_hs_rdy && unipro_ready && cse_ready, "D-PHY/UniPro/CSE requests acknowledged");
    dphy_hs_rqst = 0; unipro_valid = 0; cse_valid = 0;
    @(negedge clk); chk(!dphy_hs_rdy && !unipro_ready && !cse_ready, "acknowledges drop with the requests");

    // DigRF frame sync counter
    begin
      int c0;
      c0 = u_dut.drf_frame_cnt;
      for (int i = 0; i < 3; i++) begin
        @(negedge clk); frame_sync = 1;
        @(negedge clk); frame_sync = 0;
        repeat (3) @(negedge clk);
      end
      chk(u_dut.drf_frame_cnt == c0 + 3, "each frame-sync pulse counts one DigRF frame");
    end

    // reset mid-frame
    @(negedge clk); valid = 1; sop = 1; data = 32'h0102_0304;
    @(posedge clk); while (!ready) @(posedge clk);
    @(negedge clk); sop = 0; rst_n = 0;
    @(negedge clk);
    chk(!ready && !err && u_dut.frame_q.size() == 0 && !u_dut.in_frame, "reset drops the partial frame");
    valid = 0; rst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
