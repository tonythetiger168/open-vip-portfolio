// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// DigRF Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 17
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=Protocol-Specific Rules
`ifndef DIGRF_COMPLIANCE_CHECKER_SV
`define DIGRF_COMPLIANCE_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// digrf_compliance_checker_sva -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module digrf_compliance_checker_sva (mipi_vip_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; l4_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_digrf_mrd; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mrd |-> vif.data_type inside {4'b0000,4'b0001,4'b0010,4'b0011,4'b0100,4'b0101,4'b0110,4'b0111,4'b1000,4'b1001,4'b1010,4'b1011,4'b1100,4'b1101,4'b1110,4'b1111}; endproperty
  assert_p_digrf_mrd: assert property(p_digrf_mrd) l1_pass[0]++; else begin `uvm_warning("DIGRF_L1", "MRD valid failed"); l1_fail[0]++; end
  cover_p_digrf_mrd: cover property(p_digrf_mrd);
  property p_digrf_frame; @(posedge vif.clk) disable iff (!vif.rst_n) vif.frame |-> vif.subframe <= 4'd15; endproperty
  assert_p_digrf_frame: assert property(p_digrf_frame) l1_pass[1]++; else begin `uvm_warning("DIGRF_L1", "Frame 0-15 failed"); l1_fail[1]++; end
  cover_p_digrf_frame: cover property(p_digrf_frame);
  property p_digrf_antenna; @(posedge vif.clk) disable iff (!vif.rst_n) vif.antenna_id <= 4'd15; endproperty
  assert_p_digrf_antenna: assert property(p_digrf_antenna) l1_pass[2]++; else begin `uvm_warning("DIGRF_L1", "Antenna 0-15 failed"); l1_fail[2]++; end
  cover_p_digrf_antenna: cover property(p_digrf_antenna);
  property p_digrf_iq; @(posedge vif.clk) disable iff (!vif.rst_n) vif.iq_valid |-> !$isunknown(vif.iq_data); endproperty
  assert_p_digrf_iq: assert property(p_digrf_iq) l1_pass[3]++; else begin `uvm_warning("DIGRF_L1", "IQ valid failed"); l1_fail[3]++; end
  cover_p_digrf_iq: cover property(p_digrf_iq);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_digrf_sync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sync |-> vif.frame == 0; endproperty
  assert_p_digrf_sync: assert property(p_digrf_sync) l2_pass[0]++; else begin `uvm_warning("DIGRF_L2", "Sync valid failed"); l2_fail[0]++; end
  cover_p_digrf_sync: cover property(p_digrf_sync);
  property p_digrf_rate; @(posedge vif.clk) disable iff (!vif.rst_n) vif.rate inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_digrf_rate: assert property(p_digrf_rate) l2_pass[1]++; else begin `uvm_warning("DIGRF_L2", "Rate valid failed"); l2_fail[1]++; end
  cover_p_digrf_rate: cover property(p_digrf_rate);
  property p_digrf_blank; @(posedge vif.clk) disable iff (!vif.rst_n) vif.blank |-> vif.frame == 0; endproperty
  assert_p_digrf_blank: assert property(p_digrf_blank) l2_pass[2]++; else begin `uvm_warning("DIGRF_L2", "Blank valid failed"); l2_fail[2]++; end
  cover_p_digrf_blank: cover property(p_digrf_blank);
  property p_digrf_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.iq_valid |-> !$isunknown(vif.iq_data); endproperty
  assert_p_digrf_no_x: assert property(p_digrf_no_x) l2_pass[3]++; else begin `uvm_warning("DIGRF_L2", "No X when valid failed"); l2_fail[3]++; end
  cover_p_digrf_no_x: cover property(p_digrf_no_x);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: data rate changes are only allowed at a frame boundary
  property p_digrf_l3_rate_boundary; @(posedge vif.clk) disable iff (!vif.rst_n) $changed(vif.rate) |-> (vif.sync || vif.frame == 0); endproperty
  assert_p_digrf_l3_rate_boundary: assert property(p_digrf_l3_rate_boundary) l3_pass[0]++; else begin `uvm_warning("DIGRF_L3", "Rate changed mid-frame failed"); l3_fail[0]++; end
  cover_p_digrf_l3_rate_boundary: cover property(p_digrf_l3_rate_boundary);
  // L3-2: frame counter advances by one or wraps to zero
  property p_digrf_l3_frame_seq; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.frame != $past(vif.frame)) |-> (vif.frame == $past(vif.frame) + 1'b1 || vif.frame == 0); endproperty
  assert_p_digrf_l3_frame_seq: assert property(p_digrf_l3_frame_seq) l3_pass[1]++; else begin `uvm_warning("DIGRF_L3", "Frame counter discontinuity failed"); l3_fail[1]++; end
  cover_p_digrf_l3_frame_seq: cover property(p_digrf_l3_frame_seq);
  // L3-3: blanking and frame sync are mutually exclusive
  property p_digrf_l3_blank_sync; @(posedge vif.clk) disable iff (!vif.rst_n) !(vif.blank && vif.sync); endproperty
  assert_p_digrf_l3_blank_sync: assert property(p_digrf_l3_blank_sync) l3_pass[2]++; else begin `uvm_warning("DIGRF_L3", "Blank and sync simultaneous failed"); l3_fail[2]++; end
  cover_p_digrf_l3_blank_sync: cover property(p_digrf_l3_blank_sync);
  // L3-4: I/Q payload transfer requires the DigRF datapath valid
  property p_digrf_l3_iq_needs_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.iq_valid |-> vif.digrf_valid; endproperty
  assert_p_digrf_l3_iq_needs_valid: assert property(p_digrf_l3_iq_needs_valid) l3_pass[3]++; else begin `uvm_warning("DIGRF_L3", "IQ valid without DigRF valid failed"); l3_fail[3]++; end
  cover_p_digrf_l3_iq_needs_valid: cover property(p_digrf_l3_iq_needs_valid);

  // ---------------- L4: DigRF protocol-specific rules (5) ----------------
  // L4-1: I/Q data may only be sent after a frame sync has been seen
  property p_digrf_l4_sync_before_data; @(posedge vif.clk) disable iff (!vif.rst_n) vif.digrf_valid && !$past(vif.digrf_valid) |-> vif.digrf_frame_sync || $past(vif.digrf_frame_sync); endproperty
  assert_p_digrf_l4_sync_before_data: assert property(p_digrf_l4_sync_before_data) l4_pass[0]++; else begin `uvm_warning("DIGRF_L4", "I/Q data sent before frame sync"); l4_fail[0]++; end
  cover_p_digrf_l4_sync_before_data: cover property(p_digrf_l4_sync_before_data);
  // L4-2: I/Q sideband samples are known (not X) while valid
  property p_digrf_l4_iq_known; @(posedge vif.clk) disable iff (!vif.rst_n) vif.digrf_valid |-> !$isunknown({vif.digrf_i, vif.digrf_q}); endproperty
  assert_p_digrf_l4_iq_known: assert property(p_digrf_l4_iq_known) l4_pass[1]++; else begin `uvm_warning("DIGRF_L4", "I/Q sample unknown while valid"); l4_fail[1]++; end
  cover_p_digrf_l4_iq_known: cover property(p_digrf_l4_iq_known);
  // L4-3: antenna identifier stays constant within a frame
  property p_digrf_l4_antenna_stable; @(posedge vif.clk) disable iff (!vif.rst_n) vif.digrf_valid && $past(vif.digrf_valid) |-> $stable(vif.digrf_antenna); endproperty
  assert_p_digrf_l4_antenna_stable: assert property(p_digrf_l4_antenna_stable) l4_pass[2]++; else begin `uvm_warning("DIGRF_L4", "Antenna changed inside a frame"); l4_fail[2]++; end
  cover_p_digrf_l4_antenna_stable: cover property(p_digrf_l4_antenna_stable);
  // L4-4: packet SOP is paired with an EOP within 64 cycles
  property p_digrf_l4_sop_eop_pairing; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sop && !vif.eop |-> ##[1:64] vif.eop; endproperty
  assert_p_digrf_l4_sop_eop_pairing: assert property(p_digrf_l4_sop_eop_pairing) l4_pass[3]++; else begin `uvm_warning("DIGRF_L4", "SOP without matching EOP"); l4_fail[3]++; end
  cover_p_digrf_l4_sop_eop_pairing: cover property(p_digrf_l4_sop_eop_pairing);
  // L4-5: frame sync is not re-asserted in the middle of a frame
  property p_digrf_l4_sync_once_per_frame; @(posedge vif.clk) disable iff (!vif.rst_n) vif.digrf_valid && $past(vif.digrf_valid) |-> !vif.digrf_frame_sync; endproperty
  assert_p_digrf_l4_sync_once_per_frame: assert property(p_digrf_l4_sync_once_per_frame) l4_pass[4]++; else begin `uvm_warning("DIGRF_L4", "Frame sync re-asserted mid-frame"); l4_fail[4]++; end
  cover_p_digrf_l4_sync_once_per_frame: cover property(p_digrf_l4_sync_once_per_frame);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("DIGRF_RPT", $sformatf("=== DigRF Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("DIGRF_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("DIGRF_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("DIGRF_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("DIGRF_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("DIGRF_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule

// ============================================================================
// digrf_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the digrf_compliance_checker_sva module above)
// ============================================================================
class digrf_compliance_checker extends uvm_component;
  `uvm_component_utils(digrf_compliance_checker)
  function new(string name = "digrf_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

`endif
