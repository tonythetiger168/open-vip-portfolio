// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_compliance_checker.sv -- OBI concurrent assertion checks (bindable)

module obi_compliance_checker
  (input logic clk, input logic rst_n, input logic req, input logic gnt, input logic [31:0] addr, input logic we, input logic [3:0] be, input logic [31:0] wdata, input logic [3:0] aid, input logic rvalid, input logic rready, input logic [31:0] rdata, input logic err, input logic [3:0] rid);

  // no X on the subordinate outputs out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({gnt, rvalid}))
    else $error("OBI: X on gnt/rvalid");
  assert property (@(posedge clk) disable iff (!rst_n) rvalid |-> !$isunknown({rdata, err, rid}))
    else $error("OBI: X on the R channel while rvalid");
  // A phase: a request is not retracted and its signals are stable until granted
  assert property (@(posedge clk) disable iff (!rst_n) req && !gnt |=> req)
    else $error("OBI: req retracted before gnt");
  assert property (@(posedge clk) disable iff (!rst_n) req && !gnt |=> $stable({addr, we, be, wdata, aid}))
    else $error("OBI: A-phase signals changed before gnt");
  // R phase: a response is held until accepted
  assert property (@(posedge clk) disable iff (!rst_n) rvalid && !rready |=> rvalid && $stable({rdata, err, rid}))
    else $error("OBI: R-phase response dropped or changed before rready");
  // gnt only answers a request
  assert property (@(posedge clk) disable iff (!rst_n) gnt |-> req)
    else $error("OBI: gnt without req");
  cover property (@(posedge clk) disable iff (!rst_n) req && !gnt ##1 req && gnt);
  cover property (@(posedge clk) disable iff (!rst_n) rvalid && !rready ##1 rvalid && rready);
  cover property (@(posedge clk) disable iff (!rst_n) rvalid && err);
endmodule
