// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_sequences.svh -- OBI sequences

// Random traffic: cfg.num_items constrained-random items.
class obi_base_sequence extends uvm_sequence #(obi_transaction);
  `uvm_object_utils(obi_base_sequence)
  obi_config cfg;

  function new(string name = "obi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = obi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "obi_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class obi_directed_sequence extends uvm_sequence #(obi_transaction);
  `uvm_object_utils(obi_directed_sequence)
  obi_config cfg;

  function new(string name = "obi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function obi_transaction item();
    item = obi_transaction::type_id::create("req");
  endfunction

  task send(obi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    obi_transaction t;
    // fill a few words with byte-lane writes and read them back
    for (int i = 0; i < 4; i++) begin
      t = item(); t.we = 1; t.addr = 32'h10; t.be = 4'h1 << i; t.wdata = 32'h11 << (8 * i) | 32'hEEEE_EEEE; t.aid = i; send(t);
    end
    t = item(); t.we = 0; t.addr = 32'h10; t.be = 4'hF; t.aid = 4; send(t);
    t = item(); t.we = 1; t.addr = 32'h3FC; t.be = 4'hF; t.wdata = 32'hDEAD_BEEF; t.aid = 5; send(t);
    t = item(); t.we = 1; t.addr = 32'h3FC; t.be = 4'h6; t.wdata = 32'h00AA_5500; t.aid = 6; send(t);
    t = item(); t.we = 0; t.addr = 32'h3FC; t.be = 4'hF; t.aid = 7; send(t);
    // error region: the write must not land anywhere, the read returns err
    t = item(); t.we = 1; t.addr = 32'h400; t.be = 4'hF; t.wdata = 32'h1234_5678; t.aid = 8; send(t);
    t = item(); t.we = 0; t.addr = 32'h400; t.be = 4'hF; t.aid = 9; send(t);
    t = item(); t.we = 0; t.addr = 32'h0;   t.be = 4'hF; t.aid = 10; send(t);
    // back-to-back burst: eight requests with no gap keep four outstanding
    for (int i = 0; i < 8; i++) begin
      t = item(); t.we = i[0]; t.addr = 32'h100 + 4 * (i / 2); t.be = 4'hF; t.wdata = t.we ? 32'hC0DE_0000 + i : 0; t.aid = i; send(t);
    end
  endtask
endclass
