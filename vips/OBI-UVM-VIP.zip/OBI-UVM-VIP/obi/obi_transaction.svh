// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_transaction.svh -- OBI transaction

class obi_transaction extends uvm_sequence_item;
  `uvm_object_utils(obi_transaction)

  // request (driven by the agent)
  rand bit we;
  rand bit [31:0] addr;
  rand bit [3:0] be;
  rand bit [31:0] wdata;
  rand bit [3:0] aid;
  // response (returned by the DUT)
  bit [31:0] rdata;
  bit err;
  bit [3:0] rid;
  // bookkeeping (not compared)
  rand bit [2:0] gap;
  rand bit oob;
  int unsigned gnt_wait;
  int unsigned tag;   // sequence number (driver/monitor order)


  // one request in ten goes to the error region 0x400-0xFFC (a dist over the
  // address ranges would make Verilator pick a value before the alignment)
  constraint c_addr { addr[1:0] == 2'b00; addr[31:12] == 0;
                      oob dist { 0 := 9, 1 := 1 };
                      oob -> addr[11:10] != 2'b00; !oob -> addr[11:10] == 2'b00; }
  constraint c_be   { be != 4'h0; !we -> be == 4'hF; }
  constraint c_wd   { !we -> wdata == 0; }
  constraint c_gap  { gap dist { 0 := 6, [1:7] :/ 2 }; }

  function new(string name = "obi_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    obi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    we = rhs_.we;
    addr = rhs_.addr;
    be = rhs_.be;
    wdata = rhs_.wdata;
    aid = rhs_.aid;
    rdata = rhs_.rdata;
    err = rhs_.err;
    rid = rhs_.rid;
    gap = rhs_.gap;
    oob = rhs_.oob;
    gnt_wait = rhs_.gnt_wait;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    obi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (we != rhs_.we) return 0;
    if (addr != rhs_.addr) return 0;
    if (be != rhs_.be) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (aid != rhs_.aid) return 0;
    if (rdata != rhs_.rdata) return 0;
    if (err != rhs_.err) return 0;
    if (rid != rhs_.rid) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(obi_transaction rhs_);
    if (we != rhs_.we) return 0;
    if (addr != rhs_.addr) return 0;
    if (be != rhs_.be) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (aid != rhs_.aid) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("OBI{tag=%0d we=0x%0h addr=0x%0h be=0x%0h wdata=0x%0h aid=0x%0h rdata=0x%0h err=0x%0h rid=0x%0h}", tag, we, addr, be, wdata, aid, rdata, err, rid);
  endfunction
endclass
