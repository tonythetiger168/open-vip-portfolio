// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_driver.svh -- OBI driver: A-phase requests, back to back, without waiting for the response; random rready

class obi_driver extends uvm_driver #(obi_transaction);
  `uvm_component_utils(obi_driver)

  uvm_analysis_port #(obi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual obi_if vif;
  obi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual obi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "obi: virtual interface not set")
    if (!uvm_config_db#(obi_config)::get(this, "", "cfg", cfg))
      cfg = obi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    obi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      forever begin
        @(vif.drv_cb);
        vif.drv_cb.rready <= ($urandom_range(99) < cfg.rready_pct);
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.req   <= 1'b0;
    vif.drv_cb.addr  <= '0;
    vif.drv_cb.we    <= 1'b0;
    vif.drv_cb.be    <= '0;
    vif.drv_cb.wdata <= '0;
    vif.drv_cb.aid   <= '0;
    vif.drv_cb.rready <= 1'b0;
  endtask

  task drive_item(obi_transaction t);
    repeat (t.gap) @(vif.drv_cb);
    vif.drv_cb.req   <= 1'b1;
    vif.drv_cb.addr  <= t.addr;
    vif.drv_cb.we    <= t.we;
    vif.drv_cb.be    <= t.be;
    vif.drv_cb.wdata <= t.wdata;
    vif.drv_cb.aid   <= t.aid;
    begin
      int unsigned to = 0;
      // the request is accepted on the clock gnt is sampled high with req
      do begin @(vif.drv_cb); to++; end while (vif.drv_cb.gnt !== 1'b1 && to < cfg.timeout_cycles);
      if (vif.drv_cb.gnt !== 1'b1) `uvm_error("TIMEOUT", "OBI: no gnt")
      t.gnt_wait = to - 1;
    end
    vif.drv_cb.req <= 1'b0;
  endtask

endclass
