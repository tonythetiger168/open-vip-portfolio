// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_coverage.svh -- OBI functional coverage

class obi_coverage extends uvm_subscriber #(obi_transaction);
  `uvm_component_utils(obi_coverage)
  obi_config cfg;
  obi_transaction tr;

  covergroup obi_cg;
    cp_we   : coverpoint tr.we;
    cp_be   : coverpoint tr.be { bins full = {4'hF}; bins byte_[] = {4'h1, 4'h2, 4'h4, 4'h8};
                                 bins half[] = {4'h3, 4'hC}; bins other = default; }
    cp_err  : coverpoint tr.err;
    cp_wait : coverpoint tr.gnt_wait { bins zero = {0}; bins one = {1}; bins more = {[2:$]}; }
    x_we_err : cross cp_we, cp_err;
    x_we_be  : cross cp_we, cp_be;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    obi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(obi_config)::get(this, "", "cfg", cfg))
      cfg = obi_config::type_id::create("cfg");
  endfunction

  function void write(obi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    obi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("OBI coverage: %0.1f%%", obi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
