// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_monitor.svh -- OBI monitor: A-phase handshakes (req & gnt) queued, completed by R-phase handshakes (rvalid & rready) in order

class obi_monitor extends uvm_monitor;
  `uvm_component_utils(obi_monitor)

  virtual obi_if vif;
  uvm_analysis_port #(obi_transaction) ap;
  obi_config cfg;
  int unsigned n_obs = 0;

  obi_transaction pend[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual obi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "obi: virtual interface not set")
    if (!uvm_config_db#(obi_config)::get(this, "", "cfg", cfg))
      cfg = obi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      int unsigned waits = 0;
      forever begin
        @(vif.mon_cb);
        // R phase first: a response can complete in the clock after its grant
        if (vif.mon_cb.rvalid && vif.mon_cb.rready) begin
          if (pend.size() == 0)
            `uvm_error("MON", "OBI: response without an outstanding request")
          else begin
            obi_transaction t = pend.pop_front();
            t.rdata = vif.mon_cb.rdata;
            t.err   = vif.mon_cb.err;
            t.rid   = vif.mon_cb.rid;
            publish(t);
          end
        end
        if (vif.mon_cb.req) begin
          if (vif.mon_cb.gnt) begin
            obi_transaction t = obi_transaction::type_id::create("t");
            t.we    = vif.mon_cb.we;
            t.addr  = vif.mon_cb.addr;
            t.be    = vif.mon_cb.be;
            t.wdata = t.we ? vif.mon_cb.wdata : 32'h0;
            t.aid   = vif.mon_cb.aid;
            t.gnt_wait = waits;
            waits = 0;
            pend.push_back(t);
          end else
            waits++;
        end
      end
    end
  endtask

  function void publish(obi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
