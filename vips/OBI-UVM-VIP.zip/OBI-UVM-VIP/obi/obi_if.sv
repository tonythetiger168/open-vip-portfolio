// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_if.sv -- OBI interface

interface obi_if (input logic clk);
  logic rst_n;

  logic req;
  logic gnt;
  logic [31:0] addr;
  logic we;
  logic [3:0] be;
  logic [31:0] wdata;
  logic [3:0] aid;
  logic rvalid;
  logic rready;
  logic [31:0] rdata;
  logic err;
  logic [3:0] rid;

  modport DUT (input clk, rst_n, input req, input addr, input we, input be, input wdata, input aid, input rready, output gnt, output rvalid, output rdata, output err, output rid);
  modport MON (input clk, rst_n, req, gnt, addr, we, be, wdata, aid, rvalid, rready, rdata, err, rid);

  clocking drv_cb @(posedge clk);
    input rst_n, gnt, rvalid, rdata, err, rid;
    inout req, addr, we, be, wdata, aid, rready;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, req, gnt, addr, we, be, wdata, aid, rvalid, rready, rdata, err, rid;
  endclocking
endinterface
