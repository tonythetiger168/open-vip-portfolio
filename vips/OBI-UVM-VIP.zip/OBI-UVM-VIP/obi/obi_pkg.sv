// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_pkg.sv -- OBI UVM VIP package

package obi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import obi_defs_pkg::*;
  export obi_defs_pkg::*;

  `include "obi_transaction.svh"
  `include "obi_config.svh"
  `include "obi_sequencer.svh"
  `include "obi_driver.svh"
  `include "obi_monitor.svh"
  `include "obi_agent.svh"
  `include "obi_sequences.svh"
  `include "obi_checker.svh"
  `include "obi_coverage.svh"
endpackage
