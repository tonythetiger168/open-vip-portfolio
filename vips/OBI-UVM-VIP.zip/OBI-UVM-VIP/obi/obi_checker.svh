// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// obi_checker.svh -- OBI protocol checker on monitored items

class obi_checker extends uvm_component;
  `uvm_component_utils(obi_checker)
  uvm_analysis_imp #(obi_transaction, obi_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  obi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(obi_config)::get(this, "", "cfg", cfg))
      cfg = obi_config::type_id::create("cfg");
  endfunction

  function void fail(obi_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("OBI: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(obi_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.rid != t.aid) fail(t, "rid does not match the in-order request's aid");
      if (t.addr[1:0] != 2'b00) fail(t, "unaligned word address");
      if (t.we && t.be == 4'h0) fail(t, "write with no byte enabled");
      if (t.gnt_wait > 16) fail(t, $sformatf("request waited %0d clocks for gnt", t.gnt_wait));
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("OBI checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
