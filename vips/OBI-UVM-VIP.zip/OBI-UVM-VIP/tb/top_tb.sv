// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- OBI testbench top with a functional OBI DUT model

`ifndef OBI_UVM_VIP_TB_SV
`define OBI_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import obi_defs_pkg::*;
import obi_pkg::*;
import obi_env_pkg::*;
import obi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  obi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  obi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .req(vif.req),
    .gnt(vif.gnt),
    .addr(vif.addr),
    .we(vif.we),
    .be(vif.be),
    .wdata(vif.wdata),
    .aid(vif.aid),
    .rvalid(vif.rvalid),
    .rready(vif.rready),
    .rdata(vif.rdata),
    .err(vif.err),
    .rid(vif.rid)
  );

  // Concurrent protocol checks
  obi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .req(vif.req),
    .gnt(vif.gnt),
    .addr(vif.addr),
    .we(vif.we),
    .be(vif.be),
    .wdata(vif.wdata),
    .aid(vif.aid),
    .rvalid(vif.rvalid),
    .rready(vif.rready),
    .rdata(vif.rdata),
    .err(vif.err),
    .rid(vif.rid)
  );

  initial begin
    uvm_config_db#(virtual obi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module obi_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        req,
  output logic        gnt,
  input  logic [31:0] addr,
  input  logic        we,
  input  logic [3:0]  be,
  input  logic [31:0] wdata,
  input  logic [3:0]  aid,
  output logic        rvalid,
  input  logic        rready,
  output logic [31:0] rdata,
  output logic        err,
  output logic [3:0]  rid
);
  logic [31:0] mem [0:255];
  // response FIFO: {err, rid, rdata}
  logic [36:0] fifo [0:3];
  logic [1:0]  wp, rp;
  logic [2:0]  cnt;
  logic [7:0]  lfsr;
  logic        stall, push, pop;

  assign stall  = (lfsr[1:0] == 2'b00);              // about one clock in four
  assign gnt    = req && !stall && (cnt < 3'd4 || pop);
  assign push   = req && gnt;
  assign rvalid = (cnt != 3'd0);
  assign pop    = rvalid && rready;
  assign {err, rid, rdata} = rvalid ? fifo[rp] : 37'h0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; cnt <= '0;
      lfsr <= 8'hA5;
      for (int i = 0; i < 256; i++) mem[i] <= 32'h0;
      for (int i = 0; i < 4; i++) fifo[i] <= '0;
    end else begin
      lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};
      if (push) begin
        if (addr >= 32'h400)
          fifo[wp] <= {1'b1, aid, 32'h0};
        else if (we) begin
          for (int b = 0; b < 4; b++)
            if (be[b]) mem[addr[9:2]][b*8 +: 8] <= wdata[b*8 +: 8];
          fifo[wp] <= {1'b0, aid, 32'h0};
        end else
          fifo[wp] <= {1'b0, aid, mem[addr[9:2]]};
        wp <= wp + 2'd1;
      end
      if (pop) rp <= rp + 2'd1;
      cnt <= cnt + {2'b0, push} - {2'b0, pop};
    end
  end
endmodule
`endif
