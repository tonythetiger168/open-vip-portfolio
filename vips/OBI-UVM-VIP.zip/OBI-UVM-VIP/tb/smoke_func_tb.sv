// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (OBI DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened obi_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic req = 0, we = 0, rready = 1;
  logic [31:0] addr = 0, wdata = 0;
  logic [3:0] be = 0, aid = 0;
  wire gnt, rvalid, err;
  wire [31:0] rdata;
  wire [3:0] rid;

  always #5 clk = ~clk;

  obi_model u_dut (.clk(clk), .rst_n(rst_n), .req(req), .gnt(gnt), .addr(addr), .we(we), .be(be),
                   .wdata(wdata), .aid(aid), .rvalid(rvalid), .rready(rready), .rdata(rdata),
                   .err(err), .rid(rid));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one transfer: A phase until gnt, then wait for the response
  task automatic xfer(input logic w, input logic [31:0] a, input logic [3:0] b, input logic [31:0] d,
                      input logic [3:0] id, output logic [31:0] q, output logic e);
    int n;
    @(negedge clk);
    req = 1; we = w; addr = a; be = b; wdata = d; aid = id;
    n = 0;
    while (!gnt && n < 50) begin @(negedge clk); n++; end
    chk(gnt === 1'b1, "request granted");
    @(negedge clk);
    req = 0;
    n = 0;
    while (!rvalid && n < 50) begin @(negedge clk); n++; end
    chk(rvalid === 1'b1, "response returned");
    chk(rid === id, "rid echoes aid");
    q = rdata; e = err;
    @(posedge clk); #1;
  endtask

  initial begin
    logic [31:0] q; logic e;
    repeat (3) @(posedge clk);
    chk(gnt === 1'b0 && rvalid === 1'b0, "idle out of reset");
    rst_n = 1;
    repeat (2) @(posedge clk);

    xfer(0, 32'h0, 4'hF, 0, 4'h7, q, e);
    chk(q === 32'h0 && e === 1'b0, "word 0 reads 0 after reset");
    xfer(0, 32'h3FC, 4'hF, 0, 4'h8, q, e);
    chk(q === 32'h0 && e === 1'b0, "last word (0x3FC) reads 0 after reset, in range");
    xfer(0, 32'h400, 4'hF, 0, 4'h9, q, e);
    chk(e === 1'b1, "0x400 is the first out-of-range address");
    xfer(1, 32'h20, 4'hF, 32'hCAFE_F00D, 4'h1, q, e);
    chk(e === 1'b0, "write in range: no error");
    xfer(0, 32'h20, 4'hF, 0, 4'h2, q, e);
    chk(q === 32'hCAFE_F00D && e === 1'b0, "read back full word");
    xfer(1, 32'h20, 4'h2, 32'h0000_AB00, 4'h3, q, e);
    xfer(0, 32'h20, 4'hF, 0, 4'h4, q, e);
    chk(q === 32'hCAFE_AB0D, "byte-enable merge on lane 1");
    xfer(1, 32'h800, 4'hF, 32'h1, 4'h5, q, e);
    chk(e === 1'b1, "write above 0x3FF: error response");
    xfer(0, 32'h800, 4'hF, 0, 4'h6, q, e);
    chk(e === 1'b1 && q === 32'h0, "read above 0x3FF: error response, rdata 0");

    // back-pressure: hold rready low, four requests fill the FIFO, the fifth waits
    begin : bp
      int granted = 0;
      @(negedge clk); rready = 0;
      req = 1; we = 0; addr = 32'h20; be = 4'hF;
      repeat (20) begin #1; if (gnt) granted++; @(negedge clk); end   // gnt half a clock before each edge
      chk(granted == 4, "four outstanding requests, then no gnt while the FIFO is full");
      chk(rvalid === 1'b1 && rdata === 32'hCAFE_AB0D, "response held while rready is low");
      rready = 1;
      repeat (10) @(negedge clk);
      req = 0;
      repeat (10) @(negedge clk);
      chk(rvalid === 1'b0, "FIFO drains when rready returns");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
