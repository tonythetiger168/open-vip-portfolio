// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// atb_if.sv -- ATB interface

interface atb_if (input logic clk);
  logic rst_n;

  logic [31:0] at_data;
  logic at_valid;
  logic at_afvalid;
  logic at_flush;
  logic at_ready;
  logic at_afready;

  modport DUT (input clk, rst_n, at_data, at_valid, at_afvalid, at_flush, output at_ready, at_afready);
  modport DRV (input clk, rst_n, at_ready, at_afready, output at_data, at_valid, at_afvalid, at_flush);
  modport MON (input clk, rst_n, at_data, at_valid, at_afvalid, at_flush, at_ready, at_afready);

  clocking drv_cb @(posedge clk);
    input rst_n, at_data, at_valid, at_afvalid, at_flush, at_ready, at_afready;
    output at_data, at_valid, at_afvalid, at_flush;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, at_data, at_valid, at_afvalid, at_flush, at_ready, at_afready;
  endclocking
endinterface
