// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// atb_transaction.svh -- ATB transaction

class atb_transaction extends uvm_sequence_item;
  `uvm_object_utils(atb_transaction)

  rand bit [31:0] at_data;
  rand bit at_valid;
  rand bit at_afvalid;
  rand bit at_flush;
  bit at_ready_o;
  bit at_afready_o;
  bit [31:0] tag;

  function new(string name = "atb_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    atb_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    at_data = rhs_.at_data;
    at_valid = rhs_.at_valid;
    at_afvalid = rhs_.at_afvalid;
    at_flush = rhs_.at_flush;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    atb_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           at_data == rhs_.at_data &&
           at_valid == rhs_.at_valid &&
           at_afvalid == rhs_.at_afvalid &&
           at_flush == rhs_.at_flush;
  endfunction

  function string convert2string();
    return $sformatf("ATB{tag=%0h at_data=0x%0h at_valid=0x%0h at_afvalid=0x%0h at_flush=0x%0h}", tag, at_data, at_valid, at_afvalid, at_flush);
  endfunction
endclass
