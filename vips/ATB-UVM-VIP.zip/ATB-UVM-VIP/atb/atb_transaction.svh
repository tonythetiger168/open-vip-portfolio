// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// atb_transaction.svh -- ATB transaction

class atb_transaction extends uvm_sequence_item;
  `uvm_object_utils(atb_transaction)

  // request (driven by the agent)
  rand bit flush;
  rand bit [31:0] data;
  // response (returned by the DUT)
  int unsigned waits;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { flush dist { 0 := 6, 1 := 1 }; flush -> data == 0; }

  function new(string name = "atb_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    atb_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    flush = rhs_.flush;
    data = rhs_.data;
    waits = rhs_.waits;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    atb_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (flush != rhs_.flush) return 0;
    if (data != rhs_.data) return 0;
    if (waits != rhs_.waits) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(atb_transaction rhs_);
    if (flush != rhs_.flush) return 0;
    if (data != rhs_.data) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("ATB{tag=%0d flush=0x%0h data=0x%0h waits=0x%0h}", tag, flush, data, waits);
  endfunction
endclass
