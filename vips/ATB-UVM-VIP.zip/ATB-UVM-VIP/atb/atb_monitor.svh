// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// atb_monitor.svh -- ATB monitor: one item per accepted beat or flush handshake

class atb_monitor extends uvm_monitor;
  `uvm_component_utils(atb_monitor)

  virtual atb_if vif;
  uvm_analysis_port #(atb_transaction) ap;
  atb_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual atb_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "atb: virtual interface not set")
    if (!uvm_config_db#(atb_config)::get(this, "", "cfg", cfg))
      cfg = atb_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      int unsigned dw = 0, fw = 0;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.at_valid) begin
          if (vif.mon_cb.at_ready) begin
            atb_transaction t = atb_transaction::type_id::create("t");
            t.flush = 0; t.data = vif.mon_cb.at_data; t.waits = dw; dw = 0;
            publish(t);
          end else dw++;
        end
        if (vif.mon_cb.at_afvalid) begin
          if (vif.mon_cb.at_afready) begin
            atb_transaction t = atb_transaction::type_id::create("t");
            t.flush = 1; t.data = 0; t.waits = fw; fw = 0;
            publish(t);
          end else fw++;
        end
      end
    end
  endtask

  function void publish(atb_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
