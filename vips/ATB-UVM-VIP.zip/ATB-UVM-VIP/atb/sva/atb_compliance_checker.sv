// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// atb_compliance_checker.sv -- ATB concurrent assertion checks (bindable)

module atb_compliance_checker
  (input logic clk, input logic rst_n, input [31:0] at_data, input at_valid, input at_afvalid, input at_flush, input at_ready, input at_afready);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({at_ready, at_afready}))
    else $error("ATB: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> at_ready == '0)
    else $error("ATB: output not in reset value");
  // afready only in response to afvalid
  assert property (@(posedge clk) disable iff (!rst_n) at_afready |-> at_afvalid || $past(at_afvalid))
    else $error("ATB: afready without afvalid");
  cover property (@(posedge clk) disable iff (!rst_n) (at_ready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (at_valid == 1'b1));
endmodule
