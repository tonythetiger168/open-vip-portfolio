// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// atb_coverage.svh -- ATB functional coverage

class atb_coverage extends uvm_subscriber #(atb_transaction);
  `uvm_component_utils(atb_coverage)
  atb_config cfg;
  atb_transaction tr;

  covergroup atb_cg;
    coverpoint tr.at_data;
    coverpoint tr.at_valid;
    coverpoint tr.at_afvalid;
    coverpoint tr.at_flush;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(atb_config)::get(this, "*", "cfg", cfg));
    atb_cg = new();
  endfunction

  function void write(atb_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    atb_cg.sample();
  endfunction
endclass
