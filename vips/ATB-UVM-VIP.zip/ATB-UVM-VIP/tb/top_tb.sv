// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- ATB testbench top with a functional ATB DUT model

`ifndef ATB_TB_SV
`define ATB_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import atb_defs_pkg::*;
import atb_pkg::*;
import atb_env_pkg::*;
import atb_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  atb_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  atb_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .at_data(vif.at_data),
    .at_valid(vif.at_valid),
    .at_afvalid(vif.at_afvalid),
    .at_flush(vif.at_flush),
    .at_ready(vif.at_ready),
    .at_afready(vif.at_afready)
  );

  // Concurrent protocol checks
  atb_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .at_data(vif.at_data), .at_valid(vif.at_valid), .at_afvalid(vif.at_afvalid), .at_flush(vif.at_flush), .at_ready(vif.at_ready), .at_afready(vif.at_afready)
  );

  initial begin
    uvm_config_db#(virtual atb_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module atb_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [31:0] at_data,
  input  logic        at_valid,
  input  logic        at_afvalid,
  input  logic        at_flush,
  output logic        at_ready,
  output logic        at_afready
);
  logic flush_d;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      at_ready   <= 1'b0;
      at_afready <= 1'b0;
      flush_d    <= 1'b0;
    end else begin
      at_ready   <= at_valid && !at_ready;
      at_afready <= at_afvalid && !flush_d;
      flush_d    <= at_flush;
    end
  end
endmodule
`endif
