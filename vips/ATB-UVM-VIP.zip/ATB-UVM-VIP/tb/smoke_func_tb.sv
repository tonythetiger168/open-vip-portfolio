// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (ATB flush/afready handshake)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened atb_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [31:0] at_data = '0;
  logic at_valid = 1'b0;
  logic at_afvalid = 1'b0;
  logic at_flush = 1'b0;
  wire  at_ready;
  wire  at_afready;

  always #5 clk = ~clk;

  atb_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .at_data(at_data), .at_valid(at_valid),
    .at_afvalid(at_afvalid), .at_flush(at_flush),
    .at_ready(at_ready), .at_afready(at_afready)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(at_ready === 1'b0 && at_afready === 1'b0, "handshakes reset low");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    repeat (4) begin step(); chk(at_afready === 1'b0, "no afready without afvalid"); end

    @(negedge clk); at_afvalid = 1;
    step(); step();
    chk(at_afready === 1'b1, "afready after afvalid");
    @(negedge clk); at_afvalid = 0;
    step();
    chk(at_afready === 1'b0, "afready drops after afvalid");

    begin : beats
      int acc = 0;
      @(negedge clk); at_valid = 1;
      repeat (10) begin
        step();
        if (at_ready === 1'b1) acc++;
      end
      chk(acc >= 3, "trace beats accepted over time");
      @(negedge clk); at_valid = 0;
    end

    @(negedge clk); at_afvalid = 1; at_flush = 1;
    step(); step();
    chk(at_afready === 1'b0, "flush suppresses afready");
    @(negedge clk); at_flush = 0; at_afvalid = 0;
    step();

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
