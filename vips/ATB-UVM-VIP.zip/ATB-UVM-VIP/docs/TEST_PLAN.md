# ATB Test Plan（ATB-UVM-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | ATB |
| 家族 | Debug |
| 類型 | UVM VIP |
| 交付目錄 | `ATB-UVM-VIP/` |
| 目前 L1b 狀態 | PASS(functional) |

## 2. DUT / 待測對象

- `atb_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | handshakes reset low | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | no afready without afvalid | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | afready after afvalid | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | afready drops after afvalid | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | trace beats accepted over time | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | flush suppresses afready | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Agent reset and first-transaction bring-up |
| PT-02 | Constrained-random sequence sweep (base sequence extended) |
| PT-03 | Error injection and protocol-violation response |
| PT-04 | Backpressure / wait-state interaction |
| PT-05 | End-to-end scoreboard matching (exp vs obs streams) |
| PT-06 | Coverage closure toward the self-served COV_GOAL=100 checklist |

## 5. 覆蓋與檢查

**SVA 協定斷言（須全程成立）：**

- ATB: X on outputs
- ATB: afready without afvalid
- ATB: output not in reset value

**Coverpoints（功能覆蓋取樣點）：**

- `tr.at_afvalid`
- `tr.at_data`
- `tr.at_flush`
- `tr.at_valid`

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/ATB-UVM-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py ATB-UVM-VIP && python3 smoke/smoke_run.py ATB-UVM-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 無特別備註。

---
*文件版本：v1.7.5 自動產生*
