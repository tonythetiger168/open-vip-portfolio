// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- DDR5 testbench top: the UVM controller agent on the device
// pins of the pin-level command decoder (ddr5_dev/tb/ddr5_ca_decoder_model.sv)
// and the device model with the JESD79-5 bank state machine and DDR5-4800B
// timing (ddr5_dev/tb/ddr5_dev_model.sv). Any command the decoder or the
// device rejects is a UVM error.

`ifndef DDR5_TB_SV
`define DDR5_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ddr5_defs_pkg::*;
import ddr5_pkg::*;
import ddr5_env_pkg::*;
import ddr5_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ddr5_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // pin-level command decoder
  wire        d_v;
  wire [4:0]  d_cmd;
  wire [3:0]  d_cid;
  wire [2:0]  d_bg;
  wire [1:0]  d_ba;
  wire [17:0] d_row;
  wire [10:0] d_col;
  wire        d_bl_alt, d_wr_partial, d_cw, d_rir;
  wire [7:0]  d_mra, d_op;
  wire [3:0]  d_err;
  ddr5_ca_decoder u_dec (.clk(clk), .rst_n(vif.rst_n), .cs_n(vif.cs_n), .ca(vif.ca),
    .cmd_v(d_v), .cmd(d_cmd), .cid(d_cid), .bg(d_bg), .ba(d_ba), .row(d_row), .col(d_col),
    .bl_alt(d_bl_alt), .wr_partial(d_wr_partial), .mra(d_mra), .op(d_op), .cw(d_cw), .rir(d_rir),
    .err(d_err));

  // the device executes ACT .. MRR (codes 1..10); an MRW with CW high is ignored
  wire [3:0]  m_cmd = (d_v && d_cmd >= 1 && d_cmd <= 10 && !(d_cmd == 5'd9 && d_cw)) ? d_cmd[3:0] : 4'd0;
  wire [7:0]  bank_open;
  wire [14:0] m_err;
  ddr5_dev_model #(.tRCD(40), .tRAS(77), .tRP(40), .tRRD_S(8), .tRRD_L(13), .tFAW(40),
    .tCCD_S(8), .tCCD_L(12), .tRTP(19), .tWR(72), .tWTR_S(7), .tWTR_L(25), .tRFC(710),
    .tMRD(34), .tMRR(34), .tREFI(9375), .REF_POSTPONE(4))
    u_dev (.clk(clk), .rst_n(vif.rst_n), .cmd(m_cmd), .bg(d_bg[0]), .ba(d_ba), .row(d_row[15:0]),
           .col(d_col[9:0]), .mra(d_mra), .mrd(d_op), .wdq(vif.wdq), .wdq_valid(vif.wdq_valid),
           .rdq(vif.rdq), .rd_valid(vif.rd_valid), .bank_open(bank_open), .err(m_err));

  // pin-level assertions
  ddr5_compliance_checker u_chk (.clk(clk), .rst_n(vif.rst_n), .cs_n(vif.cs_n), .ca(vif.ca),
    .wdq_valid(vif.wdq_valid), .rd_valid(vif.rd_valid), .rdq(vif.rdq));

  always @(posedge clk) if (vif.rst_n === 1'b1) begin
    if (d_err != 0) `uvm_error("DDR5_DEC", $sformatf("command decoder error %b", d_err))
    if (m_err != 0) `uvm_error("DDR5_DEV", $sformatf("device rejected a command: err %b", m_err))
  end

  initial begin
    uvm_config_db#(virtual ddr5_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule
`endif
