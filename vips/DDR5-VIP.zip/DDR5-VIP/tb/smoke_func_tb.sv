// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (DDR5 write/read data integrity)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened ddr5_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic cs_n = 1'b1;
  logic act_n = 1'b1;
  logic [1:0] bank = '0;
  logic [13:0] addr = '0;
  logic [127:0] wr_data = '0;
  wire  [127:0] rd_data;
  wire  rd_valid;

  always #5 clk = ~clk;

  ddr5_model u_dut (
    .clk(clk), .rst_n(rst_n), .cs_n(cs_n),
    .act_n(act_n), .bank(bank), .addr(addr),
    .wr_data(wr_data), .rd_data(rd_data),
    .rd_valid(rd_valid)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(rd_valid === 1'b0, "rd_valid quiet in reset");
    @(negedge clk); rst_n = 1'b1;

    // write bank0 col0 = A5A5
    @(negedge clk); cs_n = 1'b0; act_n = 1'b1;
    addr = 14'd0; wr_data = 128'hA5A5;
    step();
    @(negedge clk); cs_n = 1'b1;
    step();

    // read bank0 col0 back: RL=5 total latency
    @(negedge clk); cs_n = 1'b0; addr = 14'd1;
    step();
    @(negedge clk); cs_n = 1'b1; addr = 14'd0;
    repeat (3) begin step(); chk(rd_valid === 1'b0, "read latency respected"); end
    step();
    chk(rd_valid === 1'b1, "rd_valid after RL");
    chk(rd_data === 128'hA5A5, "read data matches write");
    step();
    chk(rd_valid === 1'b0, "rd_valid is a pulse");

    // distinct address holds distinct data
    @(negedge clk); cs_n = 1'b0; addr = 14'd2; wr_data = 128'h1234;
    step();
    @(negedge clk); cs_n = 1'b1;
    step();
    @(negedge clk); cs_n = 1'b0; addr = 14'd3;
    step();
    @(negedge clk); cs_n = 1'b1;
    repeat (3) step();
    step();
    chk(rd_valid === 1'b1 && rd_data === 128'h1234, "second address data");

    // bank independence: bank1 untouched col0 reads zero
    @(negedge clk); cs_n = 1'b0; bank = 2'd1; addr = 14'd1;
    step();
    @(negedge clk); cs_n = 1'b1; bank = 2'd0;
    repeat (3) step();
    step();
    chk(rd_valid === 1'b1 && rd_data === 128'h0, "bank isolation");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
