// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// common_pkg.sv -- shared typedefs

package common_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef enum bit [1:0] {VIP_OK, VIP_WARN, VIP_ERROR, VIP_FATAL} vip_status_e;

  class vip_config extends uvm_object;
    `uvm_object_utils(vip_config)
    int unsigned seed = 32'hC0FFEE;
    bit coverage_enable = 1;
    function new(string name = "vip_config"); super.new(name); endfunction
  endclass
endpackage
