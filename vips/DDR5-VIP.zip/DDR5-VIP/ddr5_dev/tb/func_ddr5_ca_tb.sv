// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator
//
// func_ddr5_ca_tb.sv -- the DDR5 CS_n / CA[13:0] command bus (JESD79-5
// section 4.1) and DDR5-4800B timing through the pin-level decoder into
// ddr5_dev_model:
//   * every command of the truth table, encoded here from the table (not
//     from the decoder) with random values on the "valid" bits, decoded with
//     all of its fields: ACT, RD/RDA, WR/WRA (burst select, partial write),
//     WRP/WRPA, MRW (incl. CW), MRR, VrefCA/VrefCS, REFab/REFsb, RFMab/RFMsb,
//     PREab/PREsb/PREpb, SRE/SREF/PDE, MPC, NOP
//   * reserved codes, CS_n low in cycle 2 of ACT / MRW / WRP (dropped) and
//     of RD / WR / MRR (allowed), DES with random CA
//   * CL 40 / CWL 38 programmed with MRW MR0 on the pins, MRR data,
//     write / read data through the device at the DDR5-4800B latencies
//   * DDR5-4800B timing in clocks (tCK 0.416 ns): tRCD, tRP, tRAS, tRRD_S,
//     tRRD_L, tCCD_S, tCCD_L, tRTP, tWR, tRFC1 (16 Gb) at their boundaries
// The decoder hands every command to the device two clocks after the clock
// that started it; data timing below includes those two clocks.
// Run: python3 tools/run_func_tests.py DDR5-VIP
module func_ddr5_ca_tb;
`ifdef VIP_SMOKE_FLATTENED
  // DDR5-4800B (JESD79-5 speed bin and timing tables), in nCK of 0.416 ns
  localparam int tRCD = 40, tRP = 40, tRAS = 77, tRRD_S = 8, tRRD_L = 13, tFAW = 40;
  localparam int tCCD_S = 8, tCCD_L = 12, tRTP = 19, tWR = 72, tWTR_S = 7, tWTR_L = 25;
  localparam int tRFC = 710, tMRD = 34, tMRR = 34, tREFI = 9375;
  localparam int CL = 40, CWL = 38, LAT = 2;
  // command kinds (decoder cmd codes)
  localparam int K_ACT = 1, K_RD = 2, K_RDA = 3, K_WR = 4, K_WRA = 5, K_PREPB = 6, K_PREAB = 7,
    K_REFAB = 8, K_MRW = 9, K_MRR = 10, K_PRESB = 11, K_REFSB = 12, K_RFMAB = 13, K_RFMSB = 14,
    K_WRP = 15, K_WRPA = 16, K_VREFCA = 17, K_VREFCS = 18, K_SRE = 19, K_SREF = 20, K_PDE = 21,
    K_MPC = 22, K_NOP = 23;

  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic cs_n = 1;
  logic [13:0] ca = '0;
  always #5 clk = ~clk;

  wire        d_v;
  wire [4:0]  d_cmd;
  wire [3:0]  d_cid;
  wire [2:0]  d_bg;
  wire [1:0]  d_ba;
  wire [17:0] d_row;
  wire [10:0] d_col;
  wire        d_bl_alt, d_wr_partial, d_cw, d_rir;
  wire [7:0]  d_mra, d_op;
  wire [3:0]  d_err;
  ddr5_ca_decoder u_dec (.clk, .rst_n, .cs_n, .ca, .cmd_v(d_v), .cmd(d_cmd), .cid(d_cid), .bg(d_bg),
    .ba(d_ba), .row(d_row), .col(d_col), .bl_alt(d_bl_alt), .wr_partial(d_wr_partial), .mra(d_mra),
    .op(d_op), .cw(d_cw), .rir(d_rir), .err(d_err));

  // the device executes ACT .. MRR (codes 1..10); an MRW with CW high is ignored
  logic [3:0] m_cmd;
  assign m_cmd = (d_v && d_cmd >= 1 && d_cmd <= 10 && !(d_cmd == K_MRW && d_cw)) ? d_cmd[3:0] : 4'd0;
  logic        wdq_valid = 0;
  logic [31:0] wdq = 0;
  wire  [31:0] rdq;
  wire         rd_valid;
  wire  [7:0]  bank_open;
  wire  [14:0] m_err;
  ddr5_dev_model #(.tRCD(tRCD), .tRAS(tRAS), .tRP(tRP), .tRRD_S(tRRD_S), .tRRD_L(tRRD_L),
    .tFAW(tFAW), .tCCD_S(tCCD_S), .tCCD_L(tCCD_L), .tRTP(tRTP), .tWR(tWR), .tWTR_S(tWTR_S),
    .tWTR_L(tWTR_L), .tRFC(tRFC), .tMRD(tMRD), .tMRR(tMRR), .tREFI(tREFI), .REF_POSTPONE(4))
    u_dev (.clk, .rst_n, .cmd(m_cmd), .bg(d_bg[0]), .ba(d_ba), .row(d_row[15:0]), .col(d_col[9:0]),
           .mra(d_mra), .mrd(d_op), .wdq, .wdq_valid, .rdq, .rd_valid, .bank_open, .err(m_err));

  // ------------------------------------------------------------ monitor
  // cyc = number of rising edges so far; a pin value driven while cyc == k
  // is sampled at edge k + 1.
  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  typedef struct { int e; logic [4:0] cmd; logic [3:0] cid; logic [2:0] bg; logic [1:0] ba;
                   logic [17:0] row; logic [10:0] col; logic bl_alt, wr_partial, cw, rir;
                   logic [7:0] mra, op; } dec_t;
  dec_t       dq[$];                 // decoded commands, with the edge they appeared at
  logic [3:0] derr_acc = 0;          // decoder errors since the last clear
  logic [14:0] merr_at [int];        // device error pulses by edge
  logic [31:0] rd_at [int];          // read data by edge
  always @(posedge clk) begin
    #1;
    if (d_v) begin
      dec_t x;
      x.e = cyc; x.cmd = d_cmd; x.cid = d_cid; x.bg = d_bg; x.ba = d_ba; x.row = d_row; x.col = d_col;
      x.bl_alt = d_bl_alt; x.wr_partial = d_wr_partial; x.cw = d_cw; x.rir = d_rir;
      x.mra = d_mra; x.op = d_op;
      dq.push_back(x);
    end
    derr_acc = derr_acc | d_err;
    if (m_err != 0) merr_at[cyc] = m_err;
    if (rd_valid) rd_at[cyc] = rdq;
  end
  // write data plan by edge
  logic [31:0] wplan [int];
  always @(negedge clk) begin
    if (wplan.exists(cyc + 1)) begin wdq_valid <= 1'b1; wdq <= wplan[cyc + 1]; end
    else begin wdq_valid <= 1'b0; wdq <= 32'hDEAD_BEEF; end
  end

  // ------------------------------------------------------------ encoder
  // Written from the truth table: CA0..CA4 opcode (listed CA0 first), then
  // the fields. Bits the table marks "V" carry random values.
  typedef struct { int k; logic [3:0] cid; logic [2:0] bg; logic [1:0] ba; logic [17:0] row;
                   logic [10:0] col; logic bl_alt, partial, cw, rir, odt; logic [7:0] mra, op; } cmd_t;
  function automatic logic [13:0] op5(input logic [13:0] w, input logic [4:0] lst);   // lst = {CA0,CA1,CA2,CA3,CA4}
    w[0] = lst[4]; w[1] = lst[3]; w[2] = lst[2]; w[3] = lst[1]; w[4] = lst[0];
    return w;
  endfunction
  function automatic bit enc(input cmd_t c, output logic [13:0] w1, output logic [13:0] w2);
    w1 = 14'($urandom); w2 = 14'($urandom);
    case (c.k)
      K_ACT: begin
        w1[1:0] = 2'b00; w1[5:2] = c.row[3:0]; w1[7:6] = c.ba; w1[10:8] = c.bg; w1[13:11] = c.cid[2:0];
        w2 = c.row[17:4];
        return 1;
      end
      K_WRP, K_WRPA, K_WR, K_WRA: begin
        w1 = op5(w1, (c.k == K_WRP || c.k == K_WRPA) ? 5'b10010 : 5'b10110);
        w1[5] = (c.k == K_WRP || c.k == K_WRPA) ? 1'b1 : !c.bl_alt;
        w1[7:6] = c.ba; w1[10:8] = c.bg; w1[13:11] = c.cid[2:0];
        w2[8:1] = c.col[10:3]; w2[10] = !(c.k == K_WRA || c.k == K_WRPA);
        w2[11] = (c.k == K_WRP || c.k == K_WRPA) ? 1'b1 : !c.partial; w2[13] = c.cid[3];
        return 1;
      end
      K_RD, K_RDA: begin
        w1 = op5(w1, 5'b10111); w1[5] = !c.bl_alt; w1[7:6] = c.ba; w1[10:8] = c.bg; w1[13:11] = c.cid[2:0];
        w2[8:0] = c.col[10:2]; w2[10] = (c.k == K_RD); w2[13] = c.cid[3];
        return 1;
      end
      K_MRW: begin w1 = op5(w1, 5'b10100); w1[12:5] = c.mra; w2[7:0] = c.op; w2[10] = c.cw; return 1; end
      K_MRR: begin w1 = op5(w1, 5'b10101); w1[12:5] = c.mra; w2[1:0] = 2'b00; w2[10] = c.cw; return 1; end
      K_VREFCA, K_VREFCS: begin w1 = op5(w1, 5'b11000); w1[11:5] = c.op[6:0]; w1[12] = (c.k == K_VREFCS); end
      K_REFAB, K_REFSB, K_RFMAB, K_RFMSB: begin
        w1 = op5(w1, 5'b11001); w1[5] = c.cid[3]; w1[8] = c.rir;
        w1[9] = (c.k == K_REFAB || c.k == K_REFSB); w1[10] = (c.k == K_REFSB || c.k == K_RFMSB);
        if (c.k == K_REFSB || c.k == K_RFMSB) w1[7:6] = c.ba;
        w1[13:11] = c.cid[2:0];
      end
      K_PREAB, K_PRESB: begin
        w1 = op5(w1, 5'b11010); w1[5] = c.cid[3]; w1[10] = (c.k == K_PRESB);
        if (c.k == K_PRESB) w1[7:6] = c.ba;
        w1[13:11] = c.cid[2:0];
      end
      K_PREPB: begin
        w1 = op5(w1, 5'b11011); w1[5] = c.cid[3]; w1[7:6] = c.ba; w1[10:8] = c.bg; w1[13:11] = c.cid[2:0];
      end
      K_SRE, K_SREF, K_PDE: begin
        w1 = op5(w1, 5'b11101); w1[10] = (c.k == K_PDE);
        if (c.k != K_PDE) w1[9] = (c.k == K_SRE); else w1[11] = c.odt;
      end
      K_MPC: begin w1 = op5(w1, 5'b11110); w1[12:5] = c.op; end
      K_NOP: w1 = op5(w1, 5'b11111);
      default: ;
    endcase
    return 0;
  endfunction

  function automatic cmd_t rnd_cmd(input int k);
    cmd_t c;
    c.k = k; c.cid = 4'($urandom); c.bg = 3'($urandom); c.ba = 2'($urandom); c.row = 18'($urandom);
    c.col = 11'($urandom); c.bl_alt = 1'($urandom); c.partial = 1'($urandom); c.cw = 1'($urandom);
    c.rir = 1'($urandom); c.odt = 1'($urandom); c.mra = 8'($urandom); c.op = 8'($urandom);
    return c;
  endfunction

  // drive one command starting at edge `at` (0: next free edge); returns
  // its start edge. cs2 is CS_n in the second cycle of a two-cycle command.
  int bus_free = 0;
  task automatic send(input cmd_t c, input int at, output int e0, input logic cs2 = 1'b1);
    logic [13:0] w1, w2;
    bit two;
    two = enc(c, w1, w2);
    if (at < bus_free) at = bus_free;
    while (cyc + 1 < at) @(negedge clk);
    e0 = cyc + 1;
    cs_n = 1'b0; ca = w1;
    @(negedge clk);
    if (two) begin cs_n = cs2; ca = w2; @(negedge clk); end
    cs_n = 1'b1; ca = 14'($urandom);
    bus_free = cyc + 1;
  endtask
  task automatic idle(input int n);
    repeat (n) @(negedge clk);
  endtask
  // the decoded command that appeared LAT - 1 edges after start edge e0
  function automatic bit find(input int e0, output dec_t x);
    foreach (dq[i]) if (dq[i].e == e0 + LAT - 1) begin x = dq[i]; return 1; end
    return 0;
  endfunction

  // compare the decoded fields that the command defines
  function automatic bit same(input cmd_t c, input dec_t x);
    if (x.cmd != 5'(c.k)) return 0;
    case (c.k)
      K_ACT: return x.row == c.row && x.ba == c.ba && x.bg == c.bg && x.cid[2:0] == c.cid[2:0];
      K_WR, K_WRA: return x.col == {c.col[10:3], 3'b000} && x.ba == c.ba && x.bg == c.bg && x.cid == c.cid &&
                          x.bl_alt == c.bl_alt && x.wr_partial == c.partial;
      K_WRP, K_WRPA: return x.col == {c.col[10:3], 3'b000} && x.ba == c.ba && x.bg == c.bg && x.cid == c.cid &&
                            !x.bl_alt && !x.wr_partial;
      K_RD, K_RDA: return x.col == {c.col[10:2], 2'b00} && x.ba == c.ba && x.bg == c.bg && x.cid == c.cid &&
                          x.bl_alt == c.bl_alt;
      K_MRW: return x.mra == c.mra && x.op == c.op && x.cw == c.cw;
      K_MRR: return x.mra == c.mra && x.cw == c.cw;
      K_VREFCA, K_VREFCS: return x.op == {1'b0, c.op[6:0]};
      K_REFAB, K_RFMAB: return x.cid == c.cid && x.rir == c.rir;
      K_REFSB, K_RFMSB: return x.cid == c.cid && x.rir == c.rir && x.ba == c.ba;
      K_PREAB: return x.cid == c.cid;
      K_PRESB: return x.cid == c.cid && x.ba == c.ba;
      K_PREPB: return x.cid == c.cid && x.ba == c.ba && x.bg == c.bg;
      K_MPC: return x.op == c.op;
      default: return 1;
    endcase
  endfunction

  // device error pulse of a command that started at e0
  function automatic logic [14:0] merr(input int e0);
    return merr_at.exists(e0 + LAT) ? merr_at[e0 + LAT] : 15'h0;
  endfunction

  function automatic logic [255:0] rnd256();
    logic [255:0] v;
    for (int i = 0; i < 256; i += 32) v[i +: 32] = $urandom;
    return v;
  endfunction
  task automatic plan_wr(input int e0, input logic [255:0] d);
    for (int i = 0; i < 8; i++) wplan[e0 + LAT + CWL + i] = d[32 * i +: 32];
  endtask
  function automatic bit burst_ok(input int e0, input logic [255:0] d);
    for (int i = 0; i < 8; i++)
      if (!rd_at.exists(e0 + LAT + CL + i) || rd_at[e0 + LAT + CL + i] !== d[32 * i +: 32]) return 0;
    return 1;
  endfunction

  function automatic cmd_t mk(input int k, input logic [2:0] g = 0, input logic [1:0] b = 0,
                              input logic [17:0] r = 0, input logic [10:0] co = 0,
                              input logic [7:0] a = 0, input logic [7:0] o = 0);
    cmd_t c;
    c = rnd_cmd(k);
    c.bg = g; c.ba = b; c.row = r; c.col = co; c.mra = a; c.op = o; c.cw = 0; c.cid = 0;
    c.bl_alt = 0; c.partial = 0;
    return c;
  endfunction

  // A then B `gap` clocks later; B is rejected with err bit `bitn` when
  // `early`, else accepted. Afterwards every bank is closed again.
  task automatic rule(input string name, input int bitn, input cmd_t a, input cmd_t b,
                      input int gap, input bit early, input cmd_t pre_a, input int pre_d);
    int e, ea, eb;
    if (pre_a.k != 0) begin send(pre_a, 0, e); ea = e + pre_d; end else ea = 0;
    send(a, ea, ea);
    if (a.k == K_WR) plan_wr(ea, rnd256());
    send(b, ea + gap, eb);
    chk(eb == ea + gap, $sformatf("%s: bus timing (B at +%0d)", name, eb - ea));
    idle(LAT + 2);
    if (early) chk(merr(eb) == (15'd1 << bitn), $sformatf("%s: at %0d clocks rejected (err=%h)", name, gap, merr(eb)));
    else       chk(merr(eb) == 0, $sformatf("%s: at %0d clocks accepted (err=%h)", name, gap, merr(eb)));
    // close everything: PREab once tRAS / tWR / tRTP have passed, then tRP
    send(mk(K_PREAB), eb + tWR + CWL + 16 + tRAS, e);
    idle(tRP + LAT + 2);
    chk(bank_open == 8'h00 && merr(e) == 0, $sformatf("%s: banks closed afterwards", name));
  endtask

  cmd_t none_c;
  initial begin
    int e, e1, e2, n_ok, n_bad;
    dec_t x;
    cmd_t c;
    logic [255:0] d0, d1;
    idle(3); rst_n = 1; idle(2);

    // ======================================== truth table (decoder only)
    n_ok = 0; n_bad = 0;
    for (int k = K_ACT; k <= K_NOP; k++)
      for (int i = 0; i < 12; i++) begin
        c = rnd_cmd(k);
        if (k == K_MRW) c.cw = 1;                  // keep the device's mode registers untouched
        send(c, 0, e);
        idle(LAT);
        if (find(e, x) && same(c, x)) n_ok++;
        else begin n_bad++; if (n_bad < 6) $display("  [FAIL] decode kind %0d", k); end
      end
    chk(n_bad == 0, $sformatf("truth table: %0d commands decoded with all fields (%0d wrong)", n_ok + n_bad, n_bad));
    chk(derr_acc == 0, $sformatf("truth table: no decoder error (%b)", derr_acc));
    chk(dq.size() == n_ok + n_bad, $sformatf("one decoded command per command (%0d)", dq.size()));
    // the device also saw these (random) commands: reset it before the timing part
    idle(tRFC + 50);
    rst_n = 0; idle(2); rst_n = 1; idle(2);
    merr_at.delete(); rd_at.delete(); dq.delete(); bus_free = 0;

    // ---- reserved codes, CA0 L with CA1 H
    begin
      logic [13:0] rsv [5];
      rsv[0] = 14'b0; rsv[1] = 14'b0; rsv[2] = 14'b0; rsv[3] = 14'b0; rsv[4] = 14'b0;
      rsv[0] = op5(rsv[0], 5'b10000); rsv[1] = op5(rsv[1], 5'b10001); rsv[2] = op5(rsv[2], 5'b10011); rsv[3] = op5(rsv[3], 5'b11100);
      rsv[4] = op5(rsv[4], 5'b01111);
      foreach (rsv[i]) begin
        derr_acc = 0;
        idle(1); cs_n = 0; ca = rsv[i]; idle(1); cs_n = 1; ca = 14'($urandom); idle(LAT + 1);
        chk(derr_acc == 4'b0001 && dq.size() == 0, $sformatf("reserved code CA0..CA4 = %b%b%b%b%b rejected (err %b)", rsv[i][0], rsv[i][1], rsv[i][2], rsv[i][3], rsv[i][4], derr_acc));
      end
    end
    // ---- DES: CA is don't care while CS_n is high
    derr_acc = 0;
    for (int i = 0; i < 16; i++) begin cs_n = 1; ca = 14'($urandom); idle(1); end
    idle(LAT);
    chk(derr_acc == 0 && dq.size() == 0, "DES: CA is don't care");
    // ---- CS_n low in cycle 2
    for (int i = 0; i < 3; i++) begin
      int kk;
      kk = i == 0 ? K_ACT : i == 1 ? K_MRW : K_WRP;
      derr_acc = 0;
      c = mk(kk, 3'b111); c.cw = 1;
      send(c, 0, e, 1'b0); idle(LAT + 1);
      chk(derr_acc == 4'b0100 && !find(e, x), $sformatf("kind %0d with CS_n low in cycle 2 not executed", kk));
    end
    for (int i = 0; i < 3; i++) begin
      int kk;
      kk = i == 0 ? K_RD : i == 1 ? K_WR : K_MRR;
      derr_acc = 0;
      c = mk(kk, 3'b111, 0, 0, 11'h040, 8'd2);
      send(c, 0, e, 1'b0); idle(LAT + 1);
      chk(derr_acc == 0 && find(e, x) && same(c, x), $sformatf("kind %0d with CS_n low in cycle 2 (ODT) executed", kk));
    end
    idle(tMRR + 60);
    rst_n = 0; idle(2); rst_n = 1; idle(2);
    merr_at.delete(); rd_at.delete(); dq.delete(); bus_free = 0;

    // ======================================== device at DDR5-4800B
    // MR0: CL 40 = code 9 in OP[6:2], BL16
    send(mk(K_MRW, 0, 0, 0, 0, 8'd0, 8'h24), 0, e);
    idle(LAT + 1);
    chk(merr(e) == 0, "MRW MR0 = CL40 / BL16 accepted");
    // an MRW with CW high is ignored by the DRAM
    c = mk(K_MRW, 0, 0, 0, 0, 8'd0, 8'h00); c.cw = 1;
    send(c, e + tMRD, e1);
    send(mk(K_MRR, 0, 0, 0, 0, 8'd0), e1 + tMRD, e2);
    idle(LAT + CL + 10);
    chk(merr(e2) == 0 && rd_at.exists(e2 + LAT + CL) && rd_at[e2 + LAT + CL][7:0] == 8'h24,
        "MRR MR0 returns CL40 at RL 40 (the CW=1 MRW was ignored)");
    chk(!rd_at.exists(e2 + LAT + CL - 1), "no MRR data before RL");

    // WR / RD data round trip in both bank groups
    d0 = rnd256(); d1 = rnd256();
    send(mk(K_ACT, 0, 1, 18'h2345), e2 + tMRR, e);
    send(mk(K_ACT, 1, 2, 18'h0777), e + tRRD_S, e1);
    chk(merr(e) == 0 && merr(e1) == 0, "ACT in BG0 then BG1 at tRRD_S");
    send(mk(K_WR, 0, 1, 0, 11'h080), e + tRCD, e2);
    plan_wr(e2, d0);
    send(mk(K_WR, 1, 2, 0, 11'h100), e2 + tCCD_S, e);
    plan_wr(e, d1);
    send(mk(K_RD, 0, 1, 0, 11'h080), e + CWL + 8 + tWTR_L, e1);
    send(mk(K_RD, 1, 2, 0, 11'h100), e1 + tCCD_S, e2);
    idle(LAT + CL + 20);
    chk(merr(e1) == 0 && merr(e2) == 0, "RDs accepted after tWTR");
    chk(burst_ok(e1, d0) && !rd_at.exists(e1 + LAT + CL - 1), "BG0 read data at CL 40 = written data (CWL 38)");
    chk(burst_ok(e2, d1), "BG1 read data right behind it (tCCD_S = burst) = written data");
    send(mk(K_PREAB), e2 + tRTP + tRAS, e);
    idle(tRP + LAT);
    chk(merr(e) == 0 && bank_open == 0, "PREab closes both banks");

    // timing rules at their DDR5-4800B values
    rule("tRCD", 1, mk(K_ACT, 0, 0, 18'h10), mk(K_RD, 0, 0, 0, 11'h0), tRCD - 1, 1, none_c, 0);
    rule("tRCD", 1, mk(K_ACT, 0, 0, 18'h10), mk(K_RD, 0, 0, 0, 11'h0), tRCD, 0, none_c, 0);
    rule("tRRD_L", 4, mk(K_ACT, 0, 0, 18'h1), mk(K_ACT, 0, 1, 18'h2), tRRD_L - 1, 1, none_c, 0);
    rule("tRRD_L", 4, mk(K_ACT, 0, 0, 18'h1), mk(K_ACT, 0, 1, 18'h2), tRRD_L, 0, none_c, 0);
    rule("tRRD_S", 4, mk(K_ACT, 0, 0, 18'h1), mk(K_ACT, 1, 0, 18'h2), tRRD_S - 1, 1, none_c, 0);
    rule("tRRD_S", 4, mk(K_ACT, 0, 0, 18'h1), mk(K_ACT, 1, 0, 18'h2), tRRD_S, 0, none_c, 0);
    rule("tRAS", 2, mk(K_ACT, 0, 3, 18'h5), mk(K_PREPB, 0, 3), tRAS - 1, 1, none_c, 0);
    rule("tRAS", 2, mk(K_ACT, 0, 3, 18'h5), mk(K_PREPB, 0, 3), tRAS, 0, none_c, 0);
    rule("tRP", 3, mk(K_PREPB, 0, 3), mk(K_ACT, 0, 3, 18'h6), tRP - 1, 1, mk(K_ACT, 0, 3, 18'h5), tRAS);
    rule("tRP", 3, mk(K_PREPB, 0, 3), mk(K_ACT, 0, 3, 18'h6), tRP, 0, mk(K_ACT, 0, 3, 18'h5), tRAS);
    rule("tCCD_L", 6, mk(K_RD, 0, 2, 0, 11'h0), mk(K_RD, 0, 2, 0, 11'h10), tCCD_L - 1, 1, mk(K_ACT, 0, 2, 18'h9), tRCD);
    rule("tCCD_L", 6, mk(K_RD, 0, 2, 0, 11'h0), mk(K_RD, 0, 2, 0, 11'h10), tCCD_L, 0, mk(K_ACT, 0, 2, 18'h9), tRCD);
    rule("tRTP", 8, mk(K_RD, 0, 2, 0, 11'h0), mk(K_PREPB, 0, 2), tRTP - 1, 1, mk(K_ACT, 0, 2, 18'h9), tRAS);
    rule("tRTP", 8, mk(K_RD, 0, 2, 0, 11'h0), mk(K_PREPB, 0, 2), tRTP, 0, mk(K_ACT, 0, 2, 18'h9), tRAS);
    rule("tWR", 7, mk(K_WR, 0, 2, 0, 11'h0), mk(K_PREPB, 0, 2), CWL + 8 + tWR - 1, 1, mk(K_ACT, 0, 2, 18'h9), tRCD);
    rule("tWR", 7, mk(K_WR, 0, 2, 0, 11'h0), mk(K_PREPB, 0, 2), CWL + 8 + tWR, 0, mk(K_ACT, 0, 2, 18'h9), tRCD);
    rule("tRFC1", 10, mk(K_REFAB), mk(K_ACT, 0, 0, 18'h1), tRFC - 1, 1, none_c, 0);
    rule("tRFC1", 10, mk(K_REFAB), mk(K_ACT, 0, 0, 18'h1), tRFC, 0, none_c, 0);

    idle(20);
    if (fails == 0) $display("FUNC_PASS func_ddr5_ca_tb checks=%0d", checks);
    else $display("FUNC_FAIL func_ddr5_ca_tb checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #20000000; $display("FUNC_FAIL func_ddr5_ca_tb timeout"); $finish; end
`else
  initial begin $display("FUNC_PASS func_ddr5_ca_tb checks=0 (needs VIP_SMOKE_FLATTENED)"); $finish; end
`endif
endmodule
