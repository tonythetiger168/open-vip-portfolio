// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ddr5_dev_model.sv -- DDR5 SDRAM device reference model at the decoded
// command level (JESD79-5 bank state machine and timing rules), x16 device:
//   2 bank groups x 4 banks, 64k rows, 1k columns, BL16 (8 clocks of two
//   16-bit beats on wdq / rdq[31:0]; beat 2i in [15:0], beat 2i+1 in [31:16]).
// Commands (cmd, sampled when cmd != NOP):
//   1 ACT  2 RD  3 RDA  4 WR  5 WRA  6 PREpb  7 PREab  8 REFab  9 MRW  10 MRR
// The CA-bus encoding is not modelled: a controller VIP decodes into cmd.
// Latencies: RL = CL = 22 + 2 * MR0[6:2], CWL = CL - 2. Write data are
// expected on wdq with wdq_valid in the 8 clocks starting CWL clocks after
// the WR; read data / MRR data (MR value on rdq[7:0], first clock) come
// with rd_valid RL clocks after the RD / MRR.
// Timing (clocks between commands, as parameters):
//   tRCD ACT->RD/WR same bank, tRAS ACT->PRE, tRP PRE->ACT/REF,
//   tRRD_S / tRRD_L ACT->ACT other bank (other / same bank group),
//   tFAW four-activate window, tCCD_S / tCCD_L column->column,
//   tRTP RD->PRE, tWR (from end of write data) ->PRE, tWTR_S / tWTR_L (from
//   end of write data) ->RD, RD->WR turnaround RL + 8 + 2 - CWL,
//   tRFC REF->any, tMRD MRW->any, tMRR MRR->any.
//   RDA / WRA precharge automatically at the earliest legal time.
// Refresh: one REFab is owed every tREFI; more than REF_POSTPONE owed is
// err[12]. Up to REF_POSTPONE refreshes may be pulled in.
// A command that breaks a state or timing rule is not executed and pulses
// the matching err bit one clock later:
//   [0] state (ACT to open bank, RD/WR/PREpb... to closed bank)  [1] tRCD
//   [2] tRAS [3] tRP [4] tRRD [5] tFAW [6] tCCD [7] tWR [8] tRTP
//   [9] tWTR / RD->WR turnaround [10] tRFC / tMRD / tMRR busy
//   [11] REF / MRW with a bank open [12] refresh overdue (pulse when it
//   happens) [13] illegal cmd, col[3:0] != 0 or MR0 burst length != BL16
//   [14] write data missing (wdq_valid low in a write data clock)
module ddr5_dev_model #(
  parameter int tRCD = 8, tRAS = 20, tRP = 8, tRRD_S = 2, tRRD_L = 4,
  parameter int tFAW = 16, tCCD_S = 8, tCCD_L = 10, tRTP = 6, tWR = 12,
  parameter int tWTR_S = 3, tWTR_L = 8, tRFC = 40, tMRD = 8, tMRR = 8,
  parameter int tREFI = 600, REF_POSTPONE = 4
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [3:0]  cmd,
  input  logic        bg,          // bank group
  input  logic [1:0]  ba,          // bank in group
  input  logic [15:0] row,
  input  logic [9:0]  col,
  input  logic [7:0]  mra,         // MRW / MRR mode register address
  input  logic [7:0]  mrd,         // MRW data
  input  logic [31:0] wdq,
  input  logic        wdq_valid,
  output logic [31:0] rdq,
  output logic        rd_valid,
  output logic [7:0]  bank_open,
  output logic [14:0] err
);
  localparam logic [3:0] NOP = 0, ACT = 1, RD = 2, RDA = 3, WR = 4, WRA = 5,
                         PREPB = 6, PREAB = 7, REFAB = 8, MRW = 9, MRR = 10;
  localparam int RS = 128;          // read / write slot ring (RL + 8 < RS)

  logic [255:0] mem [logic [24:0]];  // {bank, row, col[9:4]} -> burst
  logic [7:0]   mr [0:255];
  int           now;
  // per bank
  logic         open_ [0:7];
  logic [15:0]  orow [0:7];
  int           t_act [0:7], t_pre [0:7], t_rd [0:7], t_wre [0:7];
  int           ap_at [0:7];        // auto precharge time, -1 none
  // global
  int           t_act_bg [0:1], t_col_bg [0:1], t_wre_bg [0:1];
  int           t_act_any, t_col_any, t_rd_any, t_wre_any, t_busy;
  int           faw [0:3];
  int           ref_owed, ref_t;
  // data slots
  logic         rs_v [0:RS-1];
  logic [31:0]  rs_d [0:RS-1];
  logic         ws_v [0:RS-1];
  logic [24:0]  ws_k [0:RS-1];
  logic [2:0]   ws_b [0:RS-1];

  function automatic int rl_of(input logic [7:0] mr0);
    return 22 + 2 * int'(mr0[6:2]);
  endfunction
  function automatic int bk(input logic g, input logic [1:0] b);
    return int'({g, b});
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mem.delete();
      for (int i = 0; i < 256; i++) mr[i] = 8'h00;
      for (int i = 0; i < 8; i++) begin
        open_[i] = 1'b0; orow[i] = '0; ap_at[i] = -1;
        t_act[i] = -100000; t_pre[i] = -100000; t_rd[i] = -100000; t_wre[i] = -100000;
      end
      for (int i = 0; i < 2; i++) begin t_act_bg[i] = -100000; t_col_bg[i] = -100000; t_wre_bg[i] = -100000; end
      for (int i = 0; i < 4; i++) faw[i] = -100000;
      t_act_any = -100000; t_col_any = -100000; t_rd_any = -100000; t_wre_any = -100000;
      t_busy = 0; ref_owed = 0; ref_t = 0; now = 0;
      for (int i = 0; i < RS; i++) begin rs_v[i] = 1'b0; ws_v[i] = 1'b0; end
      rdq <= '0; rd_valid <= 1'b0; bank_open <= '0; err <= '0;
    end else begin : step
      logic [14:0] e;
      int b, rl, cwl, s;
      logic [24:0] key;
      logic [255:0] line;
      e = '0;
      now = now + 1;
      rl = rl_of(mr[0]);
      cwl = rl - 2;
      s = now % RS;

      // ---- write data capture (slot filled by an earlier WR)
      if (ws_v[s]) begin
        ws_v[s] = 1'b0;
        if (!wdq_valid) e[14] = 1'b1;
        else begin
          line = mem.exists(ws_k[s]) ? mem[ws_k[s]] : '0;
          line[32 * ws_b[s] +: 32] = wdq;
          mem[ws_k[s]] = line;
        end
      end

      // ---- read data out
      rd_valid <= rs_v[s];
      rdq <= rs_v[s] ? rs_d[s] : 32'h0;
      rs_v[s] = 1'b0;

      // ---- auto precharge
      for (int i = 0; i < 8; i++)
        if (open_[i] && ap_at[i] >= 0 && now >= ap_at[i]) begin
          open_[i] = 1'b0; t_pre[i] = ap_at[i]; ap_at[i] = -1;
        end

      // ---- refresh bookkeeping
      if (now - ref_t >= tREFI) begin
        ref_t = ref_t + tREFI;
        ref_owed = ref_owed + 1;
        if (ref_owed == REF_POSTPONE + 1) e[12] = 1'b1;
      end

      // ---- command
      b = bk(bg, ba);
      if (cmd != NOP) begin
        if (now - t_busy < 0) e[10] = 1'b1;
        else case (cmd)
          ACT: begin
            if (open_[b]) e[0] = 1'b1;
            else if (now - t_pre[b] < tRP) e[3] = 1'b1;
            else if (now - t_act_bg[bg] < tRRD_L || now - t_act_any < tRRD_S) e[4] = 1'b1;
            else if (now - faw[0] < tFAW) e[5] = 1'b1;
            else begin
              open_[b] = 1'b1; orow[b] = row; t_act[b] = now;
              t_act_bg[bg] = now; t_act_any = now;
              faw[0] = faw[1]; faw[1] = faw[2]; faw[2] = faw[3]; faw[3] = now;
            end
          end
          RD, RDA, WR, WRA: begin
            logic w;
            w = (cmd == WR || cmd == WRA);
            if (col[3:0] != 4'h0 || mr[0][1:0] != 2'b00) e[13] = 1'b1;
            else if (!open_[b] || ap_at[b] >= 0) e[0] = 1'b1;
            else if (now - t_act[b] < tRCD) e[1] = 1'b1;
            else if (now - t_col_bg[bg] < tCCD_L || now - t_col_any < tCCD_S) e[6] = 1'b1;
            else if (!w && (now - t_wre_bg[bg] < tWTR_L || now - t_wre_any < tWTR_S)) e[9] = 1'b1;
            else if (w && now - t_rd_any < rl + 8 + 2 - cwl) e[9] = 1'b1;
            else begin
              key = {3'(b), orow[b], col[9:4]};
              t_col_bg[bg] = now; t_col_any = now;
              if (w) begin
                for (int i = 0; i < 8; i++) begin
                  ws_v[(now + cwl + i) % RS] = 1'b1;
                  ws_k[(now + cwl + i) % RS] = key;
                  ws_b[(now + cwl + i) % RS] = 3'(i);
                end
                t_wre[b] = now + cwl + 8; t_wre_bg[bg] = now + cwl + 8; t_wre_any = now + cwl + 8;
                if (cmd == WRA) ap_at[b] = (now + cwl + 8 + tWR > t_act[b] + tRAS) ? now + cwl + 8 + tWR : t_act[b] + tRAS;
              end else begin
                line = mem.exists(key) ? mem[key] : '0;
                for (int i = 0; i < 8; i++) begin
                  rs_v[(now + rl + i) % RS] = 1'b1;
                  rs_d[(now + rl + i) % RS] = line[32 * i +: 32];
                end
                t_rd[b] = now; t_rd_any = now;
                if (cmd == RDA) ap_at[b] = (now + tRTP > t_act[b] + tRAS) ? now + tRTP : t_act[b] + tRAS;
              end
            end
          end
          PREPB: begin
            if (!open_[b]) begin end                       // PRE to an idle bank is a NOP
            else if (ap_at[b] >= 0) e[0] = 1'b1;
            else if (now - t_act[b] < tRAS) e[2] = 1'b1;
            else if (now - t_rd[b] < tRTP) e[8] = 1'b1;
            else if (now - t_wre[b] < tWR) e[7] = 1'b1;
            else begin open_[b] = 1'b0; t_pre[b] = now; end
          end
          PREAB: begin : pa
            logic ok;
            ok = 1'b1;
            for (int i = 0; i < 8; i++)
              if (open_[i] && ok) begin
                if (ap_at[i] >= 0) begin e[0] = 1'b1; ok = 1'b0; end
                else if (now - t_act[i] < tRAS) begin e[2] = 1'b1; ok = 1'b0; end
                else if (now - t_rd[i] < tRTP) begin e[8] = 1'b1; ok = 1'b0; end
                else if (now - t_wre[i] < tWR) begin e[7] = 1'b1; ok = 1'b0; end
              end
            if (ok)
              for (int i = 0; i < 8; i++)
                if (open_[i]) begin open_[i] = 1'b0; t_pre[i] = now; end
          end
          REFAB, MRW: begin : rm
            logic any_open, prp;
            any_open = 1'b0; prp = 1'b0;
            for (int i = 0; i < 8; i++) begin
              if (open_[i]) any_open = 1'b1;
              if (now - t_pre[i] < tRP) prp = 1'b1;
            end
            if (any_open) e[11] = 1'b1;
            else if (prp) e[3] = 1'b1;
            else if (cmd == REFAB) begin
              t_busy = now + tRFC;
              if (ref_owed > -REF_POSTPONE) ref_owed = ref_owed - 1;
            end else if (mra == 8'd0 && mrd[1:0] != 2'b00) e[13] = 1'b1;
            else begin
              mr[mra] = mrd;
              t_busy = now + tMRD;
            end
          end
          MRR: begin
            if (now - t_col_any < tCCD_S) e[6] = 1'b1;
            else begin
              rs_v[(now + rl) % RS] = 1'b1;
              rs_d[(now + rl) % RS] = {24'h0, mr[mra]};
              for (int i = 1; i < 8; i++) begin
                rs_v[(now + rl + i) % RS] = 1'b1;
                rs_d[(now + rl + i) % RS] = 32'h0;
              end
              t_col_any = now; t_rd_any = now;
              t_busy = now + tMRR;
            end
          end
          default: e[13] = 1'b1;
        endcase
      end
      for (int i = 0; i < 8; i++) bank_open[i] <= open_[i];
      err <= e;
    end
  end
endmodule
