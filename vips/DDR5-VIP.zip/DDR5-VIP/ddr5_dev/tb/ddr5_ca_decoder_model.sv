// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ddr5_ca_decoder_model.sv -- pin-level DDR5 command/address bus decoder
// (JESD79-5 section 4.1, command truth table).
//
// Pins: CS_n and CA[13:0], sampled on the rising edge of CK_t only (the
// DDR5 CA bus is single data rate). CS_n low starts a command. CA1 low
// marks a two-cycle command (ACT has CA0 and CA1 low; WRP, MRW, MRR, WR and
// RD have CA0 high, CA1 low); CA1 high marks a one-cycle command. The second
// cycle of a two-cycle command is the next clock; CS_n low there is only
// allowed for RD, WR and MRR (non-target ODT control) -- an ACT, MRW or WRP
// with CS_n low in its second cycle is not executed.
//
// Output: one decoded command (cmd_v / cmd and its fields) a fixed two
// clocks after the clock that started it, for one- and two-cycle commands
// alike, so the spacing of commands on the pins is kept for the device
// model behind the decoder.
//
// cmd codes 0..10 are the codes of ddr5_dev_model:
//   0 none 1 ACT 2 RD 3 RDA 4 WR 5 WRA 6 PREpb 7 PREab 8 REFab 9 MRW 10 MRR
//   11 PREsb 12 REFsb 13 RFMab 14 RFMsb 15 WRP 16 WRPA 17 VrefCA 18 VrefCS
//   19 SRE 20 SREF 21 PDE 22 MPC 23 NOP (also PDX)
// err (one-clock pulse, with the clock the bad cycle was sampled):
//   [0] reserved (RFU) command code, the command is dropped
//   [1] CA bit X/Z in a command cycle, the command is dropped
//   [2] CS_n low in cycle 2 of ACT / MRW / WRP, the command is dropped
//   [3] CS_n X/Z
// (bits 1 and 3 need a four-state simulator)
module ddr5_ca_decoder (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        cs_n,
  input  logic [13:0] ca,
  output logic        cmd_v,
  output logic [4:0]  cmd,
  output logic [3:0]  cid,
  output logic [2:0]  bg,
  output logic [1:0]  ba,
  output logic [17:0] row,
  output logic [10:0] col,
  output logic        bl_alt,      // CA5 low in cycle 1 of RD / WR: the MR0 alternate burst
  output logic        wr_partial,  // CA11 low in cycle 2 of WR: partial write
  output logic [7:0]  mra,
  output logic [7:0]  op,          // MRW / MPC / Vref opcode
  output logic        cw,          // MRW control word bit (high: the DRAM ignores the MRW)
  output logic        rir,         // REF CA8 (refresh interval rate indication)
  output logic [3:0]  err
);
  localparam logic [4:0] C_NONE = 0, C_ACT = 1, C_RD = 2, C_RDA = 3, C_WR = 4, C_WRA = 5,
    C_PREPB = 6, C_PREAB = 7, C_REFAB = 8, C_MRW = 9, C_MRR = 10, C_PRESB = 11, C_REFSB = 12,
    C_RFMAB = 13, C_RFMSB = 14, C_WRP = 15, C_WRPA = 16, C_VREFCA = 17, C_VREFCS = 18,
    C_SRE = 19, C_SREF = 20, C_PDE = 21, C_MPC = 22, C_NOP = 23;

  // first cycle of a two-cycle command waiting for its second cycle
  logic        c2;
  logic [4:0]  c2_kind;            // C_ACT / C_WRP / C_MRW / C_MRR / C_WR / C_RD
  logic [13:0] c2_ca;
  // one-cycle command held one clock (fixed two-clock latency)
  logic        h_v;
  logic [4:0]  h_cmd;
  logic [13:0] h_ca;

  task automatic clear_out();
    cmd_v <= 1'b0; cmd <= C_NONE; cid <= '0; bg <= '0; ba <= '0; row <= '0; col <= '0;
    bl_alt <= 1'b0; wr_partial <= 1'b0; mra <= '0; op <= '0; cw <= 1'b0; rir <= 1'b0;
  endtask

  // emit a one-cycle command from its (only) CA word
  task automatic emit1(input logic [4:0] k, input logic [13:0] a);
    cmd_v <= 1'b1; cmd <= k;
    cid <= {1'b0, a[13:11]}; bg <= '0; ba <= '0; row <= '0; col <= '0;
    bl_alt <= 1'b0; wr_partial <= 1'b0; mra <= '0; op <= '0; cw <= 1'b0; rir <= 1'b0;
    case (k)
      C_PREPB: begin cid <= {a[5], a[13:11]}; ba <= a[7:6]; bg <= a[10:8]; end
      C_PRESB: begin cid <= {a[5], a[13:11]}; ba <= a[7:6]; end
      C_PREAB: cid <= {a[5], a[13:11]};
      C_REFAB, C_RFMAB: begin cid <= {a[5], a[13:11]}; rir <= a[8]; end
      C_REFSB, C_RFMSB: begin cid <= {a[5], a[13:11]}; ba <= a[7:6]; rir <= a[8]; end
      C_VREFCA, C_VREFCS: op <= {1'b0, a[11:5]};
      C_MPC: op <= a[12:5];
      default: ;
    endcase
  endtask

  // emit a two-cycle command from its two CA words
  task automatic emit2(input logic [4:0] k, input logic [13:0] a, input logic [13:0] b);
    cmd_v <= 1'b1;
    cid <= {b[13], a[13:11]}; bg <= a[10:8]; ba <= a[7:6]; row <= '0; col <= '0;
    bl_alt <= 1'b0; wr_partial <= 1'b0; mra <= '0; op <= '0; cw <= 1'b0; rir <= 1'b0;
    cmd <= k;
    case (k)
      C_ACT: begin
        row <= {b[13:0], a[5:2]};
        cid <= {1'b0, a[13:11]};          // CA13 of cycle 2 is R17 here
      end
      C_WR, C_WRP: begin
        col <= {b[8:1], 3'b000};
        bl_alt <= (k == C_WR) && !a[5];
        wr_partial <= (k == C_WR) && !b[11];
        if (!b[10]) cmd <= (k == C_WR) ? C_WRA : C_WRPA;
      end
      C_RD: begin
        col <= {b[8:0], 2'b00};
        bl_alt <= !a[5];
        if (!b[10]) cmd <= C_RDA;
      end
      C_MRW: begin
        mra <= a[12:5]; op <= b[7:0]; cw <= b[10]; cid <= '0; bg <= '0; ba <= '0;
      end
      C_MRR: begin
        mra <= a[12:5]; cw <= b[10]; cid <= '0; bg <= '0; ba <= '0;
      end
      default: ;
    endcase
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      c2 <= 1'b0; c2_kind <= C_NONE; c2_ca <= '0;
      h_v <= 1'b0; h_cmd <= C_NONE; h_ca <= '0;
      clear_out();
      err <= '0;
    end else begin : step
      logic [3:0] e;
      logic [4:0] k;
      e = '0;
      clear_out();
      // a held one-cycle command leaves now
      if (h_v) begin emit1(h_cmd, h_ca); h_v <= 1'b0; end

      if ($isunknown(cs_n)) begin
        e[3] = 1'b1;
        c2 <= 1'b0;
      end else if (c2) begin
        // ---------------- second cycle
        c2 <= 1'b0;
        if (!cs_n && (c2_kind == C_ACT || c2_kind == C_MRW || c2_kind == C_WRP)) e[2] = 1'b1;
        else if ($isunknown(ca)) e[1] = 1'b1;
        else emit2(c2_kind, c2_ca, ca);
      end else if (!cs_n) begin
        // ---------------- first cycle
        if ($isunknown(ca)) e[1] = 1'b1;
        else begin
          // CA0..CA4 of the truth table, CA0 first
          k = C_NONE;
          if (!ca[1]) begin
            if (!ca[0]) k = C_ACT;
            else case ({ca[2], ca[3], ca[4]})
              3'b010: k = C_WRP;          // H L L H L
              3'b100: k = C_MRW;          // H L H L L
              3'b101: k = C_MRR;          // H L H L H
              3'b110: k = C_WR;           // H L H H L
              3'b111: k = C_RD;           // H L H H H
              default: e[0] = 1'b1;       // H L L L L / H L L L H / H L L H H: RFU
            endcase
            if (k != C_NONE) begin c2 <= 1'b1; c2_kind <= k; c2_ca <= ca; end
          end else if (!ca[0]) e[0] = 1'b1;   // CA0 L with CA1 H: no such command
          else begin
            case ({ca[2], ca[3], ca[4]})
              3'b000: k = ca[12] ? C_VREFCS : C_VREFCA;                    // H H L L L
              3'b001: k = ca[9] ? (ca[10] ? C_REFSB : C_REFAB)              // H H L L H
                                : (ca[10] ? C_RFMSB : C_RFMAB);
              3'b010: k = ca[10] ? C_PRESB : C_PREAB;                       // H H L H L
              3'b011: k = C_PREPB;                                          // H H L H H
              3'b100: e[0] = 1'b1;                                          // H H H L L: RFU
              3'b101: k = ca[10] ? C_PDE : (ca[9] ? C_SRE : C_SREF);        // H H H L H
              3'b110: k = C_MPC;                                            // H H H H L
              3'b111: k = C_NOP;                                            // H H H H H (NOP / PDX)
            endcase
            if (k != C_NONE) begin h_v <= 1'b1; h_cmd <= k; h_ca <= ca; end
          end
        end
      end
      err <= e;
    end
  end
endmodule
