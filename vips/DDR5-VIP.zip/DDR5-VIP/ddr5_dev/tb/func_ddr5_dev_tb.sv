// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator
//
// func_ddr5_dev_tb.sv -- memory controller for ddr5_dev_model, written from
// the JESD79-5 rules rather than from the model:
//   * every timing parameter at its boundary: one clock early is rejected
//     with the matching error and has no effect, on time is accepted
//     (tRCD, tRAS, tRP, tRRD_S/L, tFAW, tCCD_S/L, tRTP, tWR, tWTR_S/L,
//     RD->WR turnaround, tRFC, tMRD)
//   * bank state: ACT to an open bank, RD / WR to an idle bank, PREpb to
//     an idle bank (no-op), PREab, auto precharge timing of RDA / WRA
//   * RL / CWL from MR0 (CL 22 and CL 28), MRR data and latency, illegal
//     burst length, column alignment, missing write data
//   * refresh: REF with a bank open, tRFC, postponed refresh limit
//   * 300 random commands from a timing-legal scheduler against a
//     reference memory (data and latency of every burst)
// Run: python3 tools/run_func_tests.py DDR5-VIP
module func_ddr5_dev_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int tRCD = 8, tRAS = 20, tRP = 8, tRRD_S = 2, tRRD_L = 4, tFAW = 16;
  localparam int tCCD_S = 8, tCCD_L = 10, tRTP = 6, tWR = 12, tWTR_S = 3, tWTR_L = 8;
  localparam int tRFC = 40, tMRD = 8, tMRR = 8, tREFI = 600, REF_POSTPONE = 4;
  localparam logic [3:0] NOP = 0, ACT = 1, RD = 2, RDA = 3, WR = 4, WRA = 5,
                         PREPB = 6, PREAB = 7, REFAB = 8, MRW = 9, MRR = 10;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic [3:0] cmd = 0;
  logic bg = 0, wdq_valid = 0;
  logic [1:0] ba = 0;
  logic [15:0] row = 0;
  logic [9:0] col = 0;
  logic [7:0] mra = 0, mrd = 0;
  logic [31:0] wdq = 0;
  wire [31:0] rdq;
  wire rd_valid;
  wire [7:0] bank_open;
  wire [14:0] err;
  always #5 clk = ~clk;

  ddr5_dev_model #(.tRCD(tRCD), .tRAS(tRAS), .tRP(tRP), .tRRD_S(tRRD_S), .tRRD_L(tRRD_L),
    .tFAW(tFAW), .tCCD_S(tCCD_S), .tCCD_L(tCCD_L), .tRTP(tRTP), .tWR(tWR), .tWTR_S(tWTR_S),
    .tWTR_L(tWTR_L), .tRFC(tRFC), .tMRD(tMRD), .tMRR(tMRR), .tREFI(tREFI),
    .REF_POSTPONE(REF_POSTPONE)) u_dut (.clk, .rst_n, .cmd, .bg, .ba, .row, .col, .mra, .mrd,
    .wdq, .wdq_valid, .rdq, .rd_valid, .bank_open, .err);

  // ------------------------------------------------------------ bench clock
  // cyc counts rising edges; a command driven while cyc == k is taken at
  // edge k + 1, its "issue time".
  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int mnow = 0;                          // clocks since reset release (the device's time base)
  always @(posedge clk) mnow <= rst_n ? mnow + 1 : 0;
  int last_t = 0;
  int cl = 22;
  logic [14:0] e_seen;              // err pulse of the last command

  // write data plan and read expectations, indexed by edge number
  logic        wp_v [int];
  logic [31:0] wp_d [int];
  logic        ex_v [int];
  logic [31:0] ex_d [int];
  int rd_bad = 0, rd_extra = 0, rd_cnt = 0;
  bit drop_wdq = 0;
  always @(negedge clk) begin
    if (wp_v.exists(cyc + 1) && !drop_wdq) begin wdq_valid <= 1'b1; wdq <= wp_d[cyc + 1]; end
    else begin wdq_valid <= 1'b0; wdq <= 32'hDEAD_BEEF; end
  end
  always @(posedge clk) begin
    #1;
    if (rd_valid) begin
      rd_cnt++;
      if (!ex_v.exists(cyc)) rd_extra++;
      else if (rdq !== ex_d[cyc]) rd_bad++;
    end else if (ex_v.exists(cyc)) rd_bad++;
  end

  // reference memory: {bank, row, col[9:4]} -> 8 x 32-bit
  logic [255:0] ref_m [logic [24:0]];
  function automatic logic [24:0] key(input logic g, input logic [1:0] b, input logic [15:0] r, input logic [9:0] c);
    return {g, b, r, c[9:4]};
  endfunction

  // issue a command n clocks after the previous one; returns its error pulse
  task automatic issue(input int n, input logic [3:0] c, input logic g = 0, input logic [1:0] b = 0,
                       input logic [15:0] r = 0, input logic [9:0] co = 0,
                       input logic [7:0] a = 0, input logic [7:0] d = 0);
    while (cyc + 1 < last_t + n) @(negedge clk);
    cmd = c; bg = g; ba = b; row = r; col = co; mra = a; mrd = d;
    last_t = cyc + 1;
    @(negedge clk);
    cmd = NOP;
    e_seen = err;
  endtask
  task automatic wait_clk(input int n);
    repeat (n) @(negedge clk);
  endtask

  // expected data for a WR / RD that was just issued (when accepted)
  task automatic plan_wr(input logic g, input logic [1:0] b, input logic [15:0] r, input logic [9:0] c,
                         input logic [255:0] d);
    for (int i = 0; i < 8; i++) begin wp_v[last_t + cl - 2 + i] = 1'b1; wp_d[last_t + cl - 2 + i] = d[32 * i +: 32]; end
    ref_m[key(g, b, r, c)] = d;
  endtask
  task automatic plan_rd(input logic g, input logic [1:0] b, input logic [15:0] r, input logic [9:0] c);
    logic [255:0] d;
    d = ref_m.exists(key(g, b, r, c)) ? ref_m[key(g, b, r, c)] : '0;
    for (int i = 0; i < 8; i++) begin ex_v[last_t + cl + i] = 1'b1; ex_d[last_t + cl + i] = d[32 * i +: 32]; end
  endtask
  function automatic logic [255:0] rnd256();
    logic [255:0] v;
    for (int i = 0; i < 256; i += 32) v[i +: 32] = $urandom;
    return v;
  endfunction

  // a rule boundary: the command `early` clocks after the previous one is
  // rejected with err[bit] (and must be re-issued), then accepted at `ok`
  task automatic boundary(input string name, input int bitn, input int early, input int ok,
                          input logic [3:0] c, input logic g, input logic [1:0] b,
                          input logic [15:0] r = 0, input logic [9:0] co = 0);
    int t0;
    t0 = last_t;
    issue(early, c, g, b, r, co);
    chk(e_seen == (15'd1 << bitn), $sformatf("%s: one clock early rejected (err=%h)", name, e_seen));
    last_t = t0;
    issue(ok, c, g, b, r, co);
    chk(e_seen == 0, $sformatf("%s: on time accepted (err=%h)", name, e_seen));
  endtask

  initial begin
    logic [255:0] d0, d1, d2;
    int t_a, t_w;
    wait_clk(3); rst_n = 1; wait_clk(2);
    last_t = cyc;

    // ---------------------------------------------------- MR0, MRR latency
    issue(1, MRR, 0, 0, 0, 0, 8'd0);
    chk(e_seen == 0, "MRR MR0 accepted");
    ex_v[last_t + cl] = 1'b1; ex_d[last_t + cl] = 32'h0;
    for (int i = 1; i < 8; i++) begin ex_v[last_t + cl + i] = 1'b1; ex_d[last_t + cl + i] = 32'h0; end
    issue(tMRR - 1, MRW, 0, 0, 0, 0, 8'd10, 8'h5A);
    chk(e_seen == 15'h400, "command inside tMRR rejected");
    issue(1, MRW, 0, 0, 0, 0, 8'd10, 8'h5A);
    chk(e_seen == 0, "MRW MR10 after tMRR accepted");
    issue(tMRD - 1, MRR, 0, 0, 0, 0, 8'd10);
    chk(e_seen == 15'h400, "MRR inside tMRD rejected");
    issue(1, MRR, 0, 0, 0, 0, 8'd10);
    chk(e_seen == 0, "MRR MR10 accepted");
    ex_v[last_t + cl] = 1'b1; ex_d[last_t + cl] = 32'h5A;
    for (int i = 1; i < 8; i++) begin ex_v[last_t + cl + i] = 1'b1; ex_d[last_t + cl + i] = 32'h0; end
    issue(tMRR, MRW, 0, 0, 0, 0, 8'd0, 8'h01);
    chk(e_seen == 15'h2000, "MR0 burst length BC8 rejected (only BL16 modelled)");
    wait_clk(40);
    chk(rd_cnt == 16 && rd_bad == 0 && rd_extra == 0, $sformatf("MRR data at RL=22 (cnt %0d bad %0d)", rd_cnt, rd_bad));

    // ---------------------------------------------------- ACT / tRCD / WR / RD
    d0 = rnd256(); d1 = rnd256();
    issue(tMRD, ACT, 0, 1, 16'h1234);
    chk(e_seen == 0 && bank_open == 8'h02, "ACT bank 0.1 opens it");
    t_a = last_t;
    boundary("tRCD (WR)", 1, tRCD - 1, tRCD, WR, 0, 1, 0, 10'h040);
    plan_wr(0, 1, 16'h1234, 10'h040, d0);
    t_w = last_t;
    issue(1, ACT, 0, 1, 16'h0001);
    chk(e_seen == 15'h1, "ACT to an open bank rejected");
    last_t = t_w;
    boundary("tCCD_L WR->WR same bank group", 6, tCCD_L - 1, tCCD_L, WR, 0, 1, 0, 10'h050);
    plan_wr(0, 1, 16'h1234, 10'h050, d1);
    // WR -> RD same bank group: CWL + 8 + tWTR_L after the WR
    boundary("tWTR_L", 9, (cl - 2) + 8 + tWTR_L - 1, (cl - 2) + 8 + tWTR_L, RD, 0, 1, 0, 10'h040);
    plan_rd(0, 1, 16'h1234, 10'h040);
    issue(1, RD, 0, 1, 0, 10'h05F);
    chk(e_seen == 15'h2000, "column not BL16-aligned rejected");
    last_t = last_t - 1;
    boundary("tCCD_L RD->RD", 6, tCCD_L - 1, tCCD_L, RD, 0, 1, 0, 10'h050);
    plan_rd(0, 1, 16'h1234, 10'h050);
    issue(tCCD_L, RD, 0, 2, 0, 10'h000);
    chk(e_seen == 15'h1, "RD to an idle bank rejected");
    // RD -> WR turnaround RL + 8 + 2 - CWL = 12
    last_t = last_t - tCCD_L;
    boundary("RD->WR turnaround", 9, cl + 10 - (cl - 2) - 1, cl + 10 - (cl - 2), WR, 0, 1, 0, 10'h060);
    d2 = rnd256();
    plan_wr(0, 1, 16'h1234, 10'h060, d2);
    // PRE: tWR after the end of write data
    t_w = last_t;
    issue((cl - 2) + 8 + tWR - 1, PREPB, 0, 1);
    chk(e_seen == 15'h80 && bank_open == 8'h02, "PRE inside tWR rejected, bank stays open");
    last_t = t_w;
    issue((cl - 2) + 8 + tWR, PREPB, 0, 1);
    chk(e_seen == 0 && bank_open == 8'h00, "PRE after tWR closes the bank");
    boundary("tRP", 3, tRP - 1, tRP, ACT, 0, 1, 16'h1234);
    issue(tRAS, RD, 0, 1, 0, 10'h060);
    plan_rd(0, 1, 16'h1234, 10'h060);
    chk(e_seen == 0, "RD of the reopened row");
    boundary("tRTP", 8, tRTP - 1, tRTP, PREPB, 0, 1);
    issue(1, PREPB, 0, 1);
    chk(e_seen == 0, "PREpb to an idle bank is a no-op");
    wait_clk(40);
    chk(rd_bad == 0 && rd_extra == 0 && rd_cnt == 40, $sformatf("burst data and RL (cnt %0d bad %0d extra %0d)", rd_cnt, rd_bad, rd_extra));

    // ---------------------------------------------------- tRAS, tRRD, tFAW
    issue(tRP, ACT, 0, 0, 16'h0010);
    t_a = last_t;
    boundary("tRRD_L same bank group", 4, tRRD_L - 1, tRRD_L, ACT, 0, 1, 16'h0011);
    boundary("tRRD_S other bank group", 4, tRRD_S - 1, tRRD_S, ACT, 1, 0, 16'h0012);
    issue(tRRD_L, ACT, 1, 1, 16'h0013);
    chk(e_seen == 0 && bank_open == 8'h33, "four banks open");
    // the fifth ACT inside tFAW of the first (t_a)
    issue(t_a + tFAW - 1 - last_t, ACT, 0, 2, 16'h0014);
    chk(e_seen == 15'h20, "fifth ACT inside tFAW rejected");
    last_t = t_a;
    issue(tFAW, ACT, 0, 2, 16'h0014);
    chk(e_seen == 0 && bank_open == 8'h37, "fifth ACT at tFAW accepted");
    last_t = t_a;
    issue(tRAS - 1, PREPB, 0, 0);
    chk(e_seen == 15'h4, "PRE inside tRAS rejected");
    issue(1, PREPB, 0, 0);
    chk(e_seen == 0 && bank_open == 8'h36, "PRE at tRAS accepted");
    // column commands across bank groups: tCCD_S
    issue(tRCD, WR, 0, 1, 0, 10'h000);
    plan_wr(0, 1, 16'h0011, 10'h000, rnd256());
    boundary("tCCD_S WR->WR other bank group", 6, tCCD_S - 1, tCCD_S, WR, 1, 0, 0, 10'h000);
    plan_wr(1, 0, 16'h0012, 10'h000, rnd256());
    // after the bank group 1 write: RD in group 1 needs tWTR_L, group 0 tWTR_S
    t_w = last_t;
    issue((cl - 2) + 8 + tWTR_S - 2, RD, 1, 1, 0, 10'h000);
    chk(e_seen == 15'h200, $sformatf("RD same group inside tWTR_L rejected (err=%h)", e_seen));
    issue(1, RD, 0, 1, 0, 10'h000);
    chk(e_seen == 15'h200, $sformatf("RD other group inside tWTR_S rejected (err=%h)", e_seen));
    issue(1, RD, 0, 1, 0, 10'h000);
    plan_rd(0, 1, 16'h0011, 10'h000);
    chk(e_seen == 0 && last_t - t_w == (cl - 2) + 8 + tWTR_S, $sformatf("RD other group at tWTR_S accepted (err=%h)", e_seen));
    // REF / MRW need all banks idle
    issue(tCCD_S, REFAB);
    chk(e_seen == 15'h800, "REFab with banks open rejected");
    issue(1, MRW, 0, 0, 0, 0, 8'd0, 8'h0C);
    chk(e_seen == 15'h800, "MRW with banks open rejected");
    issue(tRTP + 40, PREAB);
    chk(e_seen == 0 && bank_open == 8'h00, "PREab closes all banks");
    boundary("tRP before REFab", 3, tRP - 1, tRP, REFAB, 0, 0);
    boundary("tRFC", 10, tRFC - 1, tRFC, ACT, 0, 3, 16'h0042);
    issue(tRCD, RDA, 0, 3, 0, 10'h3F0);
    plan_rd(0, 3, 16'h0042, 10'h3F0);
    chk(e_seen == 0, "RDA accepted");
    // auto precharge at max(RDA + tRTP, ACT + tRAS) = ACT + 20
    issue(1, PREPB, 0, 3);
    chk(e_seen == 15'h1, "PRE to a bank with auto precharge pending rejected");
    wait_clk(tRAS - tRCD - 3);
    chk(bank_open == 8'h08, "bank open until ACT + tRAS");
    wait_clk(2);
    chk(bank_open == 8'h00, "auto precharge after RDA");
    last_t = last_t - 1;
    issue(tRAS - tRCD + tRP - 1, ACT, 0, 3, 16'h0043);
    chk(e_seen == 15'h8, "ACT inside tRP of the auto precharge rejected");
    issue(1, ACT, 0, 3, 16'h0043);
    chk(e_seen == 0, "ACT at tRP after auto precharge");
    issue(tRCD, WRA, 0, 3, 0, 10'h010);
    d0 = rnd256();
    plan_wr(0, 3, 16'h0043, 10'h010, d0);
    t_w = last_t;
    wait_clk((cl - 2) + 8 + tWR - 2);
    chk(bank_open == 8'h08, "bank open until write recovery ends");
    wait_clk(2);
    chk(bank_open == 8'h00, "auto precharge after WRA + CWL + 8 + tWR");

    // ---------------------------------------------------- CL 28 via MR0
    last_t = cyc;
    issue(tRP, MRW, 0, 0, 0, 0, 8'd0, 8'h0C);          // MR0[6:2] = 3
    chk(e_seen == 0, "MRW MR0 CL code 3");
    cl = 28;
    issue(tMRD, ACT, 1, 2, 16'h7777);
    issue(tRCD, WR, 1, 2, 0, 10'h100);
    plan_wr(1, 2, 16'h7777, 10'h100, rnd256());
    issue((cl - 2) + 8 + tWTR_L, RD, 1, 2, 0, 10'h100);
    plan_rd(1, 2, 16'h7777, 10'h100);
    chk(e_seen == 0, "WR / RD at CL 28");
    issue(tCCD_L, RD, 0, 3, 0, 10'h010);
    chk(e_seen == 15'h1, "RD to a bank closed by WRA rejected");
    wait_clk(50);
    chk(rd_bad == 0 && rd_extra == 0, $sformatf("bursts at CL 22 and CL 28 (bad %0d extra %0d)", rd_bad, rd_extra));
    // missing write data
    issue(tCCD_L, WR, 1, 2, 0, 10'h110);
    drop_wdq = 1;
    wait_clk(cl);
    chk(err == 15'h4000, "write data missing flagged");
    wait_clk(10);
    drop_wdq = 0;
    issue(1, 4'd11);
    chk(e_seen == 15'h2000, "reserved command rejected");
    issue(tCCD_L + 30, PREAB);
    issue(tRP, REFAB);
    repeat (3) issue(tRFC, REFAB);

    // ---------------------------------------------------- random legal traffic
    begin : rnd
      int ta [0:7], tp [0:7], trd [0:7], twe [0:7];
      int tag [0:1], tcg [0:1], tweg [0:1], tf [0:3];
      int tas, tcs, trs, tws, ok, rcmd;
      logic op [0:7];
      logic [15:0] orw [0:7];
      int n, nerr;
      nerr = 0;
      for (int i = 0; i < 8; i++) begin op[i] = 0; ta[i] = -1000; tp[i] = cyc + tRFC; trd[i] = -1000; twe[i] = -1000; end
      for (int i = 0; i < 2; i++) begin tag[i] = -1000; tcg[i] = -1000; tweg[i] = -1000; end
      for (int i = 0; i < 4; i++) tf[i] = -1000;
      tas = -1000; tcs = -1000; trs = -1000; tws = -1000;
      n = 0;
      while (n < 300) begin : one
        int b, t, g;
        logic [9:0] c;
        b = $urandom_range(7); g = b / 4;
        t = cyc + 1;
        c = 10'($urandom_range(3)) << 4;
        if (!op[b]) begin
          if (t - tp[b] >= tRP && t - tag[g] >= tRRD_L && t - tas >= tRRD_S && t - tf[0] >= tFAW) begin
            issue(1, ACT, g, b % 4, 16'($urandom_range(3)));
            op[b] = 1; orw[b] = row; ta[b] = last_t; tag[g] = last_t; tas = last_t;
            tf[0] = tf[1]; tf[1] = tf[2]; tf[2] = tf[3]; tf[3] = last_t;
            n++; if (e_seen != 0) nerr++;
          end else wait_clk(1);
        end else begin
          rcmd = $urandom_range(9);
          if (rcmd < 4 && t - ta[b] >= tRCD && t - tcg[g] >= tCCD_L && t - tcs >= tCCD_S &&
              t - tweg[g] >= tWTR_L && t - tws >= tWTR_S) begin
            issue(1, RD, g, b % 4, 0, c);
            plan_rd(g, b % 4, orw[b], c);
            trd[b] = last_t; tcg[g] = last_t; tcs = last_t; trs = last_t;
            n++; if (e_seen != 0) nerr++;
          end else if (rcmd >= 4 && rcmd < 8 && t - ta[b] >= tRCD && t - tcg[g] >= tCCD_L &&
                       t - tcs >= tCCD_S && t - trs >= cl + 10 - (cl - 2)) begin
            issue(1, WR, g, b % 4, 0, c);
            plan_wr(g, b % 4, orw[b], c, rnd256());
            twe[b] = last_t + cl - 2 + 8; tweg[g] = twe[b]; tws = twe[b]; tcg[g] = last_t; tcs = last_t;
            n++; if (e_seen != 0) nerr++;
          end else if (rcmd >= 8 && t - ta[b] >= tRAS && t - trd[b] >= tRTP && t - twe[b] >= tWR) begin
            issue(1, PREPB, g, b % 4);
            op[b] = 0; tp[b] = last_t;
            n++; if (e_seen != 0) nerr++;
          end else wait_clk(1);
        end
      end
      chk(nerr == 0, $sformatf("300 legal random commands raise no error (%0d)", nerr));
    end
    wait_clk(60);
    chk(rd_bad == 0 && rd_extra == 0, $sformatf("random traffic read data and latency (reads %0d bad %0d extra %0d)", rd_cnt, rd_bad, rd_extra));

    // ---------------------------------------------------- PREab rules, MRR spacing
    begin : preab
      int ta, tw;
      issue(1, PREAB);
      issue(tRP, ACT, 0, 0, 16'h0100);
      ta = last_t;
      issue(tRRD_S, ACT, 1, 0, 16'h0101);
      issue(ta + tRAS + 2 - last_t, RD, 0, 0, 0, 10'h000);
      plan_rd(0, 0, 16'h0100, 10'h000);
      issue(tRTP - 1, PREAB);
      chk(e_seen == 15'h100 && bank_open == 8'h11, "PREab inside tRTP of a read rejected, banks stay open");
      issue(2, MRR, 0, 0, 0, 0, 8'd0);
      chk(e_seen == 15'h40, "MRR inside tCCD_S of a read rejected");
      issue(1, MRR, 0, 0, 0, 0, 8'd0);
      chk(e_seen == 0, "MRR at tCCD_S accepted");
      ex_v[last_t + cl] = 1'b1; ex_d[last_t + cl] = 32'h0C;
      for (int i = 1; i < 8; i++) begin ex_v[last_t + cl + i] = 1'b1; ex_d[last_t + cl + i] = 32'h0; end
      issue(cl + 10 - (cl - 2), WR, 1, 0, 0, 10'h000);
      chk(e_seen == 0, "WR after the MRR turnaround");
      plan_wr(1, 0, 16'h0101, 10'h000, rnd256());
      tw = last_t;
      issue((cl - 2) + 8 + tWR - 1, PREAB);
      chk(e_seen == 15'h80 && bank_open == 8'h11, "PREab inside tWR of a write rejected, banks stay open");
      issue(1, RDA, 0, 0, 0, 10'h010);
      plan_rd(0, 0, 16'h0100, 10'h010);
      chk(e_seen == 0, "RDA accepted");
      issue(1, PREAB);
      chk(e_seen == 15'h1 && bank_open == 8'h11, "PREab with an auto precharge pending rejected");
      wait_clk(40);
      issue(1, PREAB);
      chk(e_seen == 0 && bank_open == 8'h00, "PREab after the auto precharge closes the rest");
      chk(rd_bad == 0 && rd_extra == 0, "MRR data and reads around the PREab checks");
    end

    // ---------------------------------------------------- refresh limit
    // 12 REFs pull in the maximum (REF_POSTPONE) ahead; then 2 * REF_POSTPONE
    // intervals pass without a flag and the next one is flagged
    issue(1, PREAB);
    issue(tRP, REFAB);
    chk(e_seen == 0, "REFab after PREab");
    repeat (11) issue(tRFC, REFAB);
    begin : refl
      int seen, early, t0;
      seen = 0; early = 0; t0 = cyc;
      while (cyc - t0 < (2 * REF_POSTPONE + 2) * tREFI) begin
        @(negedge clk);
        if (err[12]) begin seen++; if (cyc - t0 < 2 * REF_POSTPONE * tREFI) early++; end
      end
      chk(early == 0, "refreshes pulled in delay the overdue flag by REF_POSTPONE intervals");
      chk(seen == 1, $sformatf("postponed refresh limit flagged once (%0d)", seen));
    end

    // ---------------------------------------------------- reset with reads in flight
    // reads alternate between bank groups every tCCD_S, so every clock slot
    // a quarter turn of the device's 128-slot data ring ahead is busy; reset
    // then must drop all of them
    begin : rst_mid
      int k, n0;
      issue(tRFC, ACT, 0, 0, 16'h0200);
      issue(tRRD_S, ACT, 1, 0, 16'h0201);
      k = 0;
      issue(tRCD, RD, 0, 0, 0, 10'h000);
      while (!(k > 12 && mnow % 128 >= 104 && mnow % 128 <= 111)) begin
        k++;
        issue(tCCD_S, RD, 1'(k % 2), 0, 0, 10'h000);
      end
      rst_n = 0;
      wait_clk(3);
      ex_v.delete(); ex_d.delete();
      rst_n = 1;
      n0 = rd_cnt;
      wait_clk(300);
      chk(rd_cnt == n0, $sformatf("reset drops every read in flight (%0d bursts issued, %0d beats after reset)", k + 1, rd_cnt - n0));
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #20ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
