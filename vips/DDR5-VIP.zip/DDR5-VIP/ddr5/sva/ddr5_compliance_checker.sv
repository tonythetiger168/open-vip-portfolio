// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_compliance_checker.sv -- DDR5 pin-level assertions (bindable)
//   * CS_n is high (deselect) while RESET is applied
//   * CA has no X / Z in a clock where CS_n is low
//   * CS_n is high in the second cycle of ACT, MRW and WRP (JESD79-5 lets it
//     be low only for the non-target ODT case of RD / WR / MRR)
//   * read data is never X while rd_valid is high
//   * write data valid only as a burst of eight beats

module ddr5_compliance_checker
  (input logic clk, input logic rst_n, input logic cs_n, input logic [13:0] ca,
   input logic wdq_valid, input logic rd_valid, input logic [31:0] rdq);

  // command first cycle: two-cycle ACT / MRW / WRP
  wire act1 = !cs_n && !ca[0] && !ca[1];
  wire mrw1 = !cs_n && !ca[1] && {ca[2], ca[3], ca[4]} == 3'b100;
  wire wrp1 = !cs_n && !ca[1] && {ca[2], ca[3], ca[4]} == 3'b010;
  wire two1 = !cs_n && !ca[1];               // any two-cycle command
  logic in2;                                  // this clock is a second cycle
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) in2 <= 1'b0;
    else in2 <= two1 && !in2;

  a_cs_reset: assert property (@(posedge clk) !rst_n |-> cs_n !== 1'b0)
    else $error("DDR5: CS_n low during reset");
  a_ca_x: assert property (@(posedge clk) disable iff (!rst_n) !cs_n |-> !$isunknown(ca))
    else $error("DDR5: X on CA with CS_n low");
  a_cs_cycle2: assert property (@(posedge clk) disable iff (!rst_n)
    (act1 || mrw1 || wrp1) && !in2 |=> cs_n)
    else $error("DDR5: CS_n low in the second cycle of ACT / MRW / WRP");
  a_rd_x: assert property (@(posedge clk) disable iff (!rst_n) rd_valid |-> !$isunknown(rdq))
    else $error("DDR5: X on read data");
  a_wd_burst: assert property (@(posedge clk) disable iff (!rst_n)
    $rose(wdq_valid) |-> wdq_valid [*8])
    else $error("DDR5: write data valid for less than eight beats");

  c_act: cover property (@(posedge clk) disable iff (!rst_n) act1 && !in2);
  c_two_cycle: cover property (@(posedge clk) disable iff (!rst_n) two1 && !in2);
  c_rd: cover property (@(posedge clk) disable iff (!rst_n) rd_valid);
  c_wd: cover property (@(posedge clk) disable iff (!rst_n) wdq_valid);
endmodule
