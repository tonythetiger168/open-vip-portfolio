// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_driver.svh -- DDR5 memory controller on the device pins.
//
// Each item is one BL16 column access. The driver turns it into commands on
// CS_n / CA[13:0] (PREpb on a row miss, ACT, RD / RDA / WR / WRA), issues
// each one at the first clock all JESD79-5 timing rules allow (tRCD, tRP,
// tRAS, tRRD_S/L, tFAW, tCCD_S/L, tRTP, tWR, tWTR_S/L, RD->WR turnaround,
// tRFC, tMRD), puts the write data on the data path CWL clocks after the
// device takes the WR, programs MR0 (CL, BL16) after reset, and refreshes
// (PREab + REFab) every tREFI. One clock per loop iteration: commands, data
// and timing state change in one place.

class ddr5_driver extends uvm_driver #(ddr5_transaction);
  `uvm_component_utils(ddr5_driver)

  uvm_analysis_port #(ddr5_transaction) ap;  // items as driven
  int unsigned item_cnt = 0;
  int unsigned n_cmds[ddr5_cmd_e];

  virtual ddr5_if vif;
  ddr5_config cfg;

  typedef struct { ddr5_cmd_e k; bit bg; bit [1:0] ba; bit [15:0] row; bit [10:0] col;
                   bit [7:0] mra, op; } cmd_t;

  // timing state, in clocks of the command's first cycle
  protected int     cyc, bus_free, t_busy, last_ref;
  protected bit     open_[8];
  protected bit [15:0] orow[8];
  protected int     t_act[8], t_pre[8], t_rd[8], t_wre[8], ap_at[8];
  protected int     t_act_bg[2], t_col_bg[2], t_wre_bg[2];
  protected int     t_act_any, t_col_any, t_rd_any, t_wre_any;
  protected int     faw[4];
  protected cmd_t   pend[$];
  protected bit [31:0] wplan[int];
  protected bit     c2_due;
  protected bit [13:0] c2_word;
  protected ddr5_transaction cur;          // item whose column command is still pending
  protected int     cl, cwl;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ddr5_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ddr5: virtual interface not set")
    if (!uvm_config_db#(ddr5_config)::get(this, "", "cfg", cfg))
      cfg = ddr5_config::type_id::create("cfg");
  endfunction

  protected function void reset_state();
    cyc = 0; bus_free = 0; t_busy = 0; last_ref = 0; c2_due = 0;
    for (int i = 0; i < 8; i++) begin
      open_[i] = 0; orow[i] = '0; ap_at[i] = -1;
      t_act[i] = -100000; t_pre[i] = -100000; t_rd[i] = -100000; t_wre[i] = -100000;
    end
    for (int i = 0; i < 2; i++) begin t_act_bg[i] = -100000; t_col_bg[i] = -100000; t_wre_bg[i] = -100000; end
    for (int i = 0; i < 4; i++) faw[i] = -100000;
    t_act_any = -100000; t_col_any = -100000; t_rd_any = -100000; t_wre_any = -100000;
    pend.delete(); wplan.delete();
    cl = cfg.tm.CL; cwl = cfg.tm.CWL;
  endfunction

  task run_phase(uvm_phase phase);
    vif.cs_n <= 1'b1; vif.ca <= '0; vif.wdq <= '0; vif.wdq_valid <= 1'b0;
    forever begin
      reset_state();
      wait (vif.rst_n === 1'b1);
      repeat (4) @(vif.drv_cb);
      begin
        cmd_t m; m = '{k: D5_MRW, mra: 8'd0, op: ddr5_mr0(cfg.tm.CL), default: '0};
        pend.push_back(m);                       // MR0: CL, BL16
      end
      fork
        clock_loop();
        wait (vif.rst_n !== 1'b1);
      join_any
      disable fork;
      if (cur != null) begin seq_item_port.item_done(); cur = null; end
      vif.cs_n <= 1'b1; vif.wdq_valid <= 1'b0;
    end
  endtask

  // ---------------------------------------------------------------- timing
  protected function int bk(bit g, bit [1:0] b); return int'({g, b}); endfunction

  protected function bit all_closed_since_trp(int n);
    for (int i = 0; i < 8; i++) if (open_[i] || n - t_pre[i] < cfg.tm.tRP) return 0;
    return 1;
  endfunction

  protected function bit can_close(int b, int n);
    return ap_at[b] < 0 && n - t_act[b] >= cfg.tm.tRAS && n - t_rd[b] >= cfg.tm.tRTP &&
           n - t_wre[b] >= cfg.tm.tWR;
  endfunction

  protected function bit ready(cmd_t c, int n);
    int b = bk(c.bg, c.ba);
    if (n < bus_free || n < t_busy) return 0;
    case (c.k)
      D5_ACT:   return !open_[b] && n - t_pre[b] >= cfg.tm.tRP &&
                       n - t_act_bg[c.bg] >= cfg.tm.tRRD_L && n - t_act_any >= cfg.tm.tRRD_S &&
                       n - faw[0] >= cfg.tm.tFAW;
      D5_RD, D5_RDA:
                return open_[b] && ap_at[b] < 0 && n - t_act[b] >= cfg.tm.tRCD &&
                       n - t_col_bg[c.bg] >= cfg.tm.tCCD_L && n - t_col_any >= cfg.tm.tCCD_S &&
                       n - t_wre_bg[c.bg] >= cfg.tm.tWTR_L && n - t_wre_any >= cfg.tm.tWTR_S;
      D5_WR, D5_WRA:
                return open_[b] && ap_at[b] < 0 && n - t_act[b] >= cfg.tm.tRCD &&
                       n - t_col_bg[c.bg] >= cfg.tm.tCCD_L && n - t_col_any >= cfg.tm.tCCD_S &&
                       n - t_rd_any >= cl + 8 + 2 - cwl;
      D5_PREPB: return !open_[b] || can_close(b, n);
      D5_PREAB: begin
        for (int i = 0; i < 8; i++) if (open_[i] && !can_close(i, n)) return 0;
        return 1;
      end
      D5_REFAB, D5_MRW: return all_closed_since_trp(n);
      default:  return 1;
    endcase
  endfunction

  protected function void commit(cmd_t c, int n);
    int b = bk(c.bg, c.ba);
    case (c.k)
      D5_ACT: begin
        open_[b] = 1; orow[b] = c.row; t_act[b] = n; t_act_bg[c.bg] = n; t_act_any = n;
        faw[0] = faw[1]; faw[1] = faw[2]; faw[2] = faw[3]; faw[3] = n;
      end
      D5_RD, D5_RDA: begin
        t_col_bg[c.bg] = n; t_col_any = n; t_rd[b] = n; t_rd_any = n;
        if (c.k == D5_RDA) ap_at[b] = (n + cfg.tm.tRTP > t_act[b] + cfg.tm.tRAS) ? n + cfg.tm.tRTP : t_act[b] + cfg.tm.tRAS;
      end
      D5_WR, D5_WRA: begin
        int e = n + cwl + 8;
        t_col_bg[c.bg] = n; t_col_any = n; t_wre[b] = e; t_wre_bg[c.bg] = e; t_wre_any = e;
        if (c.k == D5_WRA) ap_at[b] = (e + cfg.tm.tWR > t_act[b] + cfg.tm.tRAS) ? e + cfg.tm.tWR : t_act[b] + cfg.tm.tRAS;
      end
      D5_PREPB: if (open_[b]) begin open_[b] = 0; t_pre[b] = n; end
      D5_PREAB: for (int i = 0; i < 8; i++) if (open_[i]) begin open_[i] = 0; t_pre[i] = n; end
      D5_REFAB: begin t_busy = n + cfg.tm.tRFC; last_ref = n; end
      D5_MRW: begin
        t_busy = n + cfg.tm.tMRD;
        if (c.mra == 0) begin cl = ddr5_cl_of(c.op); cwl = cl - 2; end
      end
      default: ;
    endcase
    bus_free = n + (ddr5_two_cycle(c.k) ? 2 : 1);
    if (n_cmds.exists(c.k)) n_cmds[c.k]++; else n_cmds[c.k] = 1;
  endfunction

  // ---------------------------------------------------------------- items
  protected function void plan(ddr5_transaction t);
    int b = bk(t.bg, t.ba);
    cmd_t c = '{k: D5_NONE, bg: t.bg, ba: t.ba, row: t.row, col: {1'b0, t.burst, 4'b0}, default: '0};
    if (open_[b] && ap_at[b] < 0 && orow[b] != t.row) begin c.k = D5_PREPB; pend.push_back(c); end
    if (!open_[b] || orow[b] != t.row || ap_at[b] >= 0) begin c.k = D5_ACT; pend.push_back(c); end
    c.k = t.write ? (t.auto_pre ? D5_WRA : D5_WR) : (t.auto_pre ? D5_RDA : D5_RD);
    pend.push_back(c);
  endfunction

  protected task clock_loop();
    forever begin
      @(vif.drv_cb);
      cyc++;
      // auto precharge completes
      for (int i = 0; i < 8; i++)
        if (ap_at[i] >= 0 && cyc >= ap_at[i]) begin open_[i] = 0; t_pre[i] = ap_at[i]; ap_at[i] = -1; end
      // write data for this clock
      if (wplan.exists(cyc)) begin
        vif.drv_cb.wdq <= wplan[cyc]; vif.drv_cb.wdq_valid <= 1'b1; wplan.delete(cyc);
      end else begin
        vif.drv_cb.wdq <= '0; vif.drv_cb.wdq_valid <= 1'b0;
      end
      // second cycle of a two-cycle command
      if (c2_due) begin
        vif.drv_cb.cs_n <= 1'b1; vif.drv_cb.ca <= c2_word; c2_due = 0;
        continue;
      end
      // refresh before tREFI runs out, ahead of new work
      if (pend.size() == 0 && cur == null && cyc - last_ref >= cfg.tm.tREFI - cfg.ref_margin) begin
        cmd_t r = '{k: D5_PREAB, default: '0};
        bit any = 0;
        for (int i = 0; i < 8; i++) any |= open_[i] || ap_at[i] >= 0;
        if (any) pend.push_back(r);
        r.k = D5_REFAB; pend.push_back(r);
      end
      // next item
      if (pend.size() == 0 && cur == null) begin
        seq_item_port.try_next_item(req);
        if (req != null) begin
          cur = req;
          cur.tag = item_cnt++;
          `uvm_info("DRV", {"drive: ", cur.convert2string()}, UVM_HIGH)
          plan(cur);
        end
      end
      // issue the oldest command once its timing allows
      if (pend.size() && ready(pend[0], cyc)) begin
        cmd_t c = pend.pop_front();
        bit [13:0] w1, w2;
        ddr5_encode(c.k, {2'b00, c.bg}, c.ba, {2'b00, c.row}, c.col, c.mra, c.op, w1, w2);
        vif.drv_cb.cs_n <= 1'b0; vif.drv_cb.ca <= w1;
        if (ddr5_two_cycle(c.k)) begin c2_due = 1; c2_word = w2; end
        commit(c, cyc);
        if (c.k inside {D5_WR, D5_WRA})
          for (int i = 0; i < 8; i++) wplan[cyc + cfg.cmd_lat + cwl + i] = cur.wdata[32 * i +: 32];
        if (c.k inside {D5_RD, D5_RDA, D5_WR, D5_WRA}) begin
          ddr5_transaction d;
          $cast(d, cur.clone());
          ap.write(d);
          seq_item_port.item_done();
          cur = null;
        end
      end else begin
        vif.drv_cb.cs_n <= 1'b1; vif.drv_cb.ca <= '0;
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    string s = "";
    foreach (n_cmds[k]) s = {s, $sformatf(" %s=%0d", k.name(), n_cmds[k])};
    `uvm_info("DRV", {"commands:", s}, UVM_LOW)
  endfunction
endclass
