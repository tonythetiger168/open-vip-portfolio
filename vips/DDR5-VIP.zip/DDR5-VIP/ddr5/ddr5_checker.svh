// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_checker.svh -- JESD79-5 command rules on the commands the monitor
// decodes from the pins (a controller under test is checked here; the
// device model checks the same rules on its side):
//   state  ACT to an open bank; RD / WR / RDA / WRA to an idle bank;
//          REFab / MRW with a bank open; reserved commands; CS_n low in the
//          second cycle of ACT / MRW / WRP; MR0 burst length other than BL16
//   timing tRCD, tRP, tRAS, tRRD_S, tRRD_L, tFAW, tCCD_S, tCCD_L, tRTP, tWR,
//          tWTR_S, tWTR_L, RD->WR turnaround, tRFC, tMRD, refresh interval
//          (more than 4 tREFI without REFab)
// Times are clocks between first cycles. Errors are "DDR5_RULE" with the
// rule name in brackets.

class ddr5_checker extends uvm_component;
  `uvm_component_utils(ddr5_checker)
  uvm_analysis_imp #(ddr5_cmd_item, ddr5_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  int unsigned viol[string];
  ddr5_config cfg;

  protected bit  open_[8];
  protected int  t_act[8], t_pre[8], t_rd[8], t_wre[8], ap_at[8];
  protected int  t_act_bg[8], t_col_bg[8], t_wre_bg[8];
  protected int  t_act_any, t_col_any, t_rd_any, t_wre_any, t_busy, t_last_ref, cl, cwl;
  protected int  faw[4];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(ddr5_config)::get(this, "", "cfg", cfg))
      cfg = ddr5_config::type_id::create("cfg");
    for (int i = 0; i < 8; i++) begin
      open_[i] = 0; ap_at[i] = -1;
      t_act[i] = -100000; t_pre[i] = -100000; t_rd[i] = -100000; t_wre[i] = -100000;
      t_act_bg[i] = -100000; t_col_bg[i] = -100000; t_wre_bg[i] = -100000;
    end
    for (int i = 0; i < 4; i++) faw[i] = -100000;
    t_act_any = -100000; t_col_any = -100000; t_rd_any = -100000; t_wre_any = -100000;
    t_busy = -100000; t_last_ref = 0; cl = cfg.tm.CL; cwl = cfg.tm.CWL;
  endfunction

  protected function void bad(string rule, string msg);
    n_violations++;
    if (viol.exists(rule)) viol[rule]++; else viol[rule] = 1;
    `uvm_error("DDR5_RULE", $sformatf("[%s] %s", rule, msg))
  endfunction

  protected function void need(int have, int want, string rule, ddr5_cmd_item c);
    if (have < want) bad(rule, $sformatf("%s: %0d clocks, needs %0d", c.convert2string(), have, want));
  endfunction

  function void write(ddr5_cmd_item c);
    int n = c.t;
    int b = int'({c.bg[0], c.ba});
    int g = int'(c.bg);
    n_checked++;
    for (int i = 0; i < 8; i++)
      if (ap_at[i] >= 0 && n >= ap_at[i]) begin open_[i] = 0; t_pre[i] = ap_at[i]; ap_at[i] = -1; end
    if (c.kind == D5_RSVD) begin bad("RESERVED", "reserved command code"); return; end
    if (c.cs2_low && c.kind inside {D5_ACT, D5_MRW, D5_WRP, D5_WRPA})
      bad("CS_CYCLE2", {c.kind.name(), " with CS_n low in its second cycle"});
    if (c.kind != D5_NOP && n < t_busy)
      bad("tRFC_tMRD", $sformatf("%s %0d clocks before the device is free after REF / MRW", c.convert2string(), t_busy - n));
    case (c.kind)
      D5_ACT: begin
        if (open_[b]) bad("ACT_OPEN", $sformatf("ACT to open bank %0d", b));
        need(n - t_pre[b], cfg.tm.tRP, "tRP", c);
        need(n - t_act_bg[g], cfg.tm.tRRD_L, "tRRD_L", c);
        need(n - t_act_any, cfg.tm.tRRD_S, "tRRD_S", c);
        need(n - faw[0], cfg.tm.tFAW, "tFAW", c);
        open_[b] = 1; t_act[b] = n; t_act_bg[g] = n; t_act_any = n;
        faw[0] = faw[1]; faw[1] = faw[2]; faw[2] = faw[3]; faw[3] = n;
      end
      D5_RD, D5_RDA, D5_WR, D5_WRA: begin
        bit w = c.kind inside {D5_WR, D5_WRA};
        if (!open_[b] || ap_at[b] >= 0) bad("COL_IDLE", $sformatf("%s to idle bank %0d", c.kind.name(), b));
        if (c.col[3:0] != 0) bad("COL_ALIGN", $sformatf("%s column %0h not BL16-aligned", c.kind.name(), c.col));
        need(n - t_act[b], cfg.tm.tRCD, "tRCD", c);
        need(n - t_col_bg[g], cfg.tm.tCCD_L, "tCCD_L", c);
        need(n - t_col_any, cfg.tm.tCCD_S, "tCCD_S", c);
        if (!w) begin
          need(n - t_wre_bg[g], cfg.tm.tWTR_L, "tWTR_L", c);
          need(n - t_wre_any, cfg.tm.tWTR_S, "tWTR_S", c);
          t_rd[b] = n; t_rd_any = n;
          if (c.kind == D5_RDA) ap_at[b] = (n + cfg.tm.tRTP > t_act[b] + cfg.tm.tRAS) ? n + cfg.tm.tRTP : t_act[b] + cfg.tm.tRAS;
        end else begin
          int e = n + cwl + 8;
          need(n - t_rd_any, cl + 8 + 2 - cwl, "RD_WR", c);
          t_wre[b] = e; t_wre_bg[g] = e; t_wre_any = e;
          if (c.kind == D5_WRA) ap_at[b] = (e + cfg.tm.tWR > t_act[b] + cfg.tm.tRAS) ? e + cfg.tm.tWR : t_act[b] + cfg.tm.tRAS;
        end
        t_col_bg[g] = n; t_col_any = n;
      end
      D5_PREPB, D5_PREAB: begin
        for (int i = 0; i < 8; i++)
          if (open_[i] && (c.kind == D5_PREAB || i == b)) begin
            if (ap_at[i] >= 0) bad("PRE_AP", $sformatf("%s to bank %0d with an auto precharge pending", c.kind.name(), i));
            need(n - t_act[i], cfg.tm.tRAS, "tRAS", c);
            need(n - t_rd[i], cfg.tm.tRTP, "tRTP", c);
            need(n - t_wre[i], cfg.tm.tWR, "tWR", c);
            open_[i] = 0; t_pre[i] = n;
          end
      end
      D5_REFAB, D5_MRW: begin
        for (int i = 0; i < 8; i++) begin
          if (open_[i]) bad("REF_MRW_OPEN", $sformatf("%s with bank %0d open", c.kind.name(), i));
          need(n - t_pre[i], cfg.tm.tRP, "tRP", c);
        end
        if (c.kind == D5_REFAB) begin
          if (n - t_last_ref > 5 * cfg.tm.tREFI)
            bad("tREFI", $sformatf("REFab %0d clocks after the previous one (more than 4 postponed)", n - t_last_ref));
          t_busy = n + cfg.tm.tRFC; t_last_ref = n;
        end else begin
          t_busy = n + cfg.tm.tMRD;
          if (c.mra == 0) begin
            if (c.op[1:0] != 2'b00) bad("MR0_BL", $sformatf("MR0 burst length code %b, not BL16", c.op[1:0]));
            cl = ddr5_cl_of(c.op); cwl = cl - 2;
          end
        end
      end
      default: ;
    endcase
  endfunction

  function void report_phase(uvm_phase phase);
    string s = "";
    foreach (viol[r]) s = {s, $sformatf(" %s=%0d", r, viol[r])};
    `uvm_info("DDR5_RULE", $sformatf("%0d commands checked, %0d violations%s", n_checked, n_violations, s), UVM_LOW)
  endfunction
endclass
