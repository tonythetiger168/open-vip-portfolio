// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_agent.svh -- DDR5 agent

class ddr5_agent extends uvm_agent;
  `uvm_component_utils(ddr5_agent)

  ddr5_sequencer sqr;
  ddr5_driver    drv;
  ddr5_monitor   mon;
  ddr5_config    cfg;
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    cfg = ddr5_config::type_id::create("cfg", this);
    uvm_config_db#(ddr5_config)::set(this, "*", "cfg", cfg);
    sqr = ddr5_sequencer::type_id::create("sqr", this);
    drv = ddr5_driver   ::type_id::create("drv", this);
    mon = ddr5_monitor  ::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
