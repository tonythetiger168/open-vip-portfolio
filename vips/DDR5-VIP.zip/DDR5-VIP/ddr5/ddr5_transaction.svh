// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_transaction.svh -- one BL16 column access (256 bits) and one command
// seen on the CS_n / CA pins.

class ddr5_transaction extends uvm_sequence_item;
  `uvm_object_utils(ddr5_transaction)

  // request (driven by the agent)
  rand bit         write;
  rand bit         bg;            // bank group (2 groups x 4 banks)
  rand bit [1:0]   ba;
  rand bit [15:0]  row;
  rand bit [5:0]   burst;         // column / 16: col = {burst, 4'b0}
  rand bit [255:0] wdata;
  rand bit         auto_pre;      // RDA / WRA instead of RD / WR
  // response
  bit [255:0]      rdata;
  // bookkeeping (not compared)
  int unsigned     tag;
  int              t_cmd;         // clock of the RD / WR command's first cycle (monitor)

  constraint c_data { !write -> wdata == 0; }

  function new(string name = "ddr5_transaction"); super.new(name); endfunction

  function bit [24:0] key();      // {bank, row, column burst}
    return {bg, ba, row, burst};
  endfunction

  function void do_copy(uvm_object rhs);
    ddr5_transaction r;
    if (!$cast(r, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    write = r.write; bg = r.bg; ba = r.ba; row = r.row; burst = r.burst; wdata = r.wdata;
    auto_pre = r.auto_pre; rdata = r.rdata; tag = r.tag; t_cmd = r.t_cmd;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ddr5_transaction r;
    if (!$cast(r, rhs)) return 0;
    return write == r.write && bg == r.bg && ba == r.ba && row == r.row && burst == r.burst &&
           wdata == r.wdata && rdata == r.rdata;
  endfunction

  // request fields only (driver view vs monitor view)
  function bit req_equal(ddr5_transaction r);
    return write == r.write && bg == r.bg && ba == r.ba && row == r.row && burst == r.burst &&
           (!write || wdata == r.wdata);
  endfunction

  function string convert2string();
    return $sformatf("DDR5{tag=%0d %s%s bg=%0d ba=%0d row=%0h col=%0h wdata=%0h rdata=%0h}", tag,
                     write ? "WR" : "RD", auto_pre ? "A" : "", bg, ba, row, {burst, 4'h0}, wdata, rdata);
  endfunction
endclass

// A command decoded from the pins (monitor): kind, fields, first clock.
class ddr5_cmd_item extends uvm_sequence_item;
  `uvm_object_utils(ddr5_cmd_item)
  ddr5_cmd_e  kind;
  bit [2:0]   bg;
  bit [1:0]   ba;
  bit [17:0]  row;
  bit [10:0]  col;
  bit [7:0]   mra, op;
  int         t;               // clock of the first cycle
  bit         cs2_low;         // CS_n low in the second cycle
  function new(string name = "ddr5_cmd_item"); super.new(name); endfunction
  function string convert2string();
    return $sformatf("%s @%0d bg=%0d ba=%0d row=%0h col=%0h mra=%0h op=%0h", kind.name(), t, bg, ba, row, col, mra, op);
  endfunction
endclass
