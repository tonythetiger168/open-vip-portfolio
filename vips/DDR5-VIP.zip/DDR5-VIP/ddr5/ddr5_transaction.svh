// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_transaction.svh -- DDR5 transaction

class ddr5_transaction extends uvm_sequence_item;
  `uvm_object_utils(ddr5_transaction)

  // request (driven by the agent)
  rand bit write;
  rand bit [1:0] bank;
  rand bit [12:0] col;
  rand bit [127:0] wdata;
  // response (returned by the DUT)
  bit [127:0] rdata;
  // bookkeeping (not compared)
  rand bit [13:0] row;
  int unsigned rl;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_data { !write -> wdata == 0; }
  constraint c_col  { col dist { [0:15] := 2, [16:8190] := 1, 8191 := 1 }; }

  function new(string name = "ddr5_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    ddr5_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    write = rhs_.write;
    bank = rhs_.bank;
    col = rhs_.col;
    wdata = rhs_.wdata;
    rdata = rhs_.rdata;
    row = rhs_.row;
    rl = rhs_.rl;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ddr5_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (write != rhs_.write) return 0;
    if (bank != rhs_.bank) return 0;
    if (col != rhs_.col) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (rdata != rhs_.rdata) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ddr5_transaction rhs_);
    if (write != rhs_.write) return 0;
    if (bank != rhs_.bank) return 0;
    if (col != rhs_.col) return 0;
    if (wdata != rhs_.wdata) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("DDR5{tag=%0d write=0x%0h bank=0x%0h col=0x%0h wdata=0x%0h rdata=0x%0h}", tag, write, bank, col, wdata, rdata);
  endfunction
endclass
