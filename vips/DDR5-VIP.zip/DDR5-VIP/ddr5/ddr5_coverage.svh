// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_coverage.svh -- DDR5 functional coverage

class ddr5_coverage extends uvm_subscriber #(ddr5_transaction);
  `uvm_component_utils(ddr5_coverage)
  ddr5_config cfg;
  ddr5_transaction tr;

  covergroup ddr5_cg;
    coverpoint tr.cs_n;
    coverpoint tr.act_n;
    coverpoint tr.bank;
    coverpoint tr.addr;
    coverpoint tr.wr_data;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(ddr5_config)::get(this, "*", "cfg", cfg));
    ddr5_cg = new();
  endfunction

  function void write(ddr5_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    ddr5_cg.sample();
  endfunction
endclass
