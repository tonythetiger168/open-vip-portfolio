// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_coverage.svh -- DDR5 functional coverage on the decoded commands:
// every command the controller uses, per bank group; page hit / page miss
// (ACT first) for reads and writes; back-to-back column commands to the same
// and to the other bank group (tCCD_L / tCCD_S paths); read-to-write and
// write-to-read turnarounds; auto precharge.

class ddr5_coverage extends uvm_subscriber #(ddr5_cmd_item);
  `uvm_component_utils(ddr5_coverage)

  ddr5_cmd_e kind;
  bit        bg;
  bit        page_hit;
  int        pair;          // 0 RD-RD, 1 RD-WR, 2 WR-RD, 3 WR-WR (consecutive column commands)
  bit        same_bg;
  protected ddr5_cmd_e last_bank_cmd[8];
  protected bit        have_col;
  protected bit        last_w, last_bg;

  covergroup cg_cmd;
    option.per_instance = 1;
    cp_kind: coverpoint kind {
      bins act = {D5_ACT}; bins rd = {D5_RD}; bins rda = {D5_RDA}; bins wr = {D5_WR};
      bins wra = {D5_WRA}; bins prepb = {D5_PREPB}; bins preab = {D5_PREAB};
      bins refab = {D5_REFAB}; bins mrw = {D5_MRW};
    }
    cp_bg: coverpoint bg;
    x_kind_bg: cross cp_kind, cp_bg {
      ignore_bins all_banks = binsof(cp_kind) intersect {D5_PREAB, D5_REFAB, D5_MRW};
    }
  endgroup

  covergroup cg_col;
    option.per_instance = 1;
    cp_page: coverpoint page_hit { bins miss = {0}; bins hit = {1}; }
    cp_rw:   coverpoint kind { bins rd = {D5_RD, D5_RDA}; bins wr = {D5_WR, D5_WRA}; }
    x_page_rw: cross cp_page, cp_rw;
  endgroup

  covergroup cg_pair;
    option.per_instance = 1;
    cp_pair: coverpoint pair { bins rr = {0}; bins rw = {1}; bins wr = {2}; bins ww = {3}; }
    cp_bg:   coverpoint same_bg { bins other_bg = {0}; bins same_bg = {1}; }
    x_pair_bg: cross cp_pair, cp_bg;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_cmd = new(); cg_col = new(); cg_pair = new();
    foreach (last_bank_cmd[i]) last_bank_cmd[i] = D5_NONE;
  endfunction

  function void write(ddr5_cmd_item t);
    int b = int'({t.bg[0], t.ba});
    kind = t.kind; bg = t.bg[0];
    cg_cmd.sample();
    if (t.kind inside {D5_RD, D5_RDA, D5_WR, D5_WRA}) begin
      bit w = t.kind inside {D5_WR, D5_WRA};
      page_hit = last_bank_cmd[b] != D5_ACT;
      cg_col.sample();
      if (have_col) begin
        pair = {last_w, w};
        same_bg = (last_bg == t.bg[0]);
        cg_pair.sample();
      end
      have_col = 1; last_w = w; last_bg = t.bg[0];
    end
    if (t.kind inside {D5_ACT, D5_RD, D5_RDA, D5_WR, D5_WRA, D5_PREPB}) last_bank_cmd[b] = t.kind;
  endfunction

  function real total();
    return (cg_cmd.get_inst_coverage() + cg_col.get_inst_coverage() + cg_pair.get_inst_coverage()) / 3.0;
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("ddr5 coverage %0.1f%% (commands %0.1f, page %0.1f, column pairs %0.1f)",
              total(), cg_cmd.get_inst_coverage(), cg_col.get_inst_coverage(), cg_pair.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
