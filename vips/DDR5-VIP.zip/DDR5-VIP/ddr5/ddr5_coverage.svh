// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_coverage.svh -- DDR5 functional coverage

class ddr5_coverage extends uvm_subscriber #(ddr5_transaction);
  `uvm_component_utils(ddr5_coverage)
  ddr5_config cfg;
  ddr5_transaction tr;

  covergroup ddr5_cg;
    cp_write : coverpoint tr.write;
    cp_bank  : coverpoint tr.bank;
    cp_col   : coverpoint tr.col { bins low = {[0:15]}; bins mid = {[16:8190]}; bins top = {8191}; }
    x_wr_bank : cross cp_write, cp_bank;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ddr5_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ddr5_config)::get(this, "", "cfg", cfg))
      cfg = ddr5_config::type_id::create("cfg");
  endfunction

  function void write(ddr5_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ddr5_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("DDR5 coverage: %0.1f%%", ddr5_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
