// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_monitor.svh -- DDR5 pin monitor. Decodes CS_n / CA[13:0] itself (one-
// and two-cycle commands, JESD79-5 truth table) and publishes every command
// on cmd_ap; tracks the open row of each bank and CL / CWL from MRW MR0, and
// publishes each RD / WR as a ddr5_transaction on ap once its eight data
// beats are in: write beats CWL clocks, read beats CL clocks after the
// device takes the command (cfg.cmd_lat clocks after its first cycle).
// A read beat that is missing or early, or write data that is not valid
// when due, is a "DDR5_MON" error.

class ddr5_monitor extends uvm_monitor;
  `uvm_component_utils(ddr5_monitor)

  uvm_analysis_port #(ddr5_transaction) ap;
  uvm_analysis_port #(ddr5_cmd_item)    cmd_ap;
  int unsigned item_cnt = 0;

  virtual ddr5_if vif;
  ddr5_config cfg;

  protected int        cyc, cl, cwl;
  protected bit        open_[8];
  protected bit [15:0] orow[8];
  protected int        ap_at[8];
  protected bit        c2;               // second cycle of a two-cycle command next
  protected bit [13:0] w1;
  protected int        t1;
  // data in flight: one entry per RD / WR, with the clock of its first beat
  protected ddr5_transaction xq[$];
  protected int        xbeat[$], xstart[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
    cmd_ap = new("cmd_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ddr5_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ddr5: virtual interface not set")
    if (!uvm_config_db#(ddr5_config)::get(this, "", "cfg", cfg))
      cfg = ddr5_config::type_id::create("cfg");
  endfunction

  protected function void reset_state();
    cyc = 0; cl = cfg.tm.CL; cwl = cfg.tm.CWL; c2 = 0;
    for (int i = 0; i < 8; i++) begin open_[i] = 0; orow[i] = '0; ap_at[i] = -1; end
    xq.delete(); xbeat.delete(); xstart.delete();
  endfunction

  task run_phase(uvm_phase phase);
    reset_state();
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        if (xq.size()) `uvm_info("MON", $sformatf("reset: %0d transfers dropped", xq.size()), UVM_LOW)
        reset_state();
        continue;
      end
      cyc++;
      for (int i = 0; i < 8; i++)
        if (ap_at[i] >= 0 && cyc >= ap_at[i]) begin open_[i] = 0; ap_at[i] = -1; end
      sample_data();
      sample_cmd();
    end
  endtask

  // ---------------------------------------------------------------- commands
  protected task sample_cmd();
    if (c2) begin
      c2 = 0;
      decode2(w1, vif.mon_cb.ca, vif.mon_cb.cs_n === 1'b0);
    end else if (vif.mon_cb.cs_n === 1'b0) begin
      ddr5_cmd_e k = ddr5_kind1(vif.mon_cb.ca);
      w1 = vif.mon_cb.ca; t1 = cyc;
      if (ddr5_two_cycle(k)) c2 = 1;
      else begin
        ddr5_cmd_item c = ddr5_cmd_item::type_id::create("cmd");
        c.kind = k; c.t = cyc;
        if (k inside {D5_PREPB}) begin c.ba = w1[7:6]; c.bg = w1[10:8]; end
        if (k == D5_PREPB && open_[int'({w1[8], w1[7:6]})] && ap_at[int'({w1[8], w1[7:6]})] < 0)
          open_[int'({w1[8], w1[7:6]})] = 0;
        if (k == D5_PREAB) for (int i = 0; i < 8; i++) if (ap_at[i] < 0) open_[i] = 0;
        cmd_ap.write(c);
      end
    end
  endtask

  protected function void decode2(bit [13:0] a, bit [13:0] b, bit cs2_low);
    ddr5_cmd_item c = ddr5_cmd_item::type_id::create("cmd");
    int bn;
    c.kind = ddr5_kind1(a); c.t = t1; c.cs2_low = cs2_low;
    c.bg = a[10:8]; c.ba = a[7:6];
    bn = int'({a[8], a[7:6]});
    case (c.kind)
      D5_ACT: begin
        c.row = {b, a[5:2]};
        open_[bn] = 1; orow[bn] = c.row[15:0]; ap_at[bn] = -1;
      end
      D5_RD: begin
        c.col = {b[8:0], 2'b00};
        if (!b[10]) c.kind = D5_RDA;
      end
      D5_WR: begin
        c.col = {b[8:1], 3'b000};
        if (!b[10]) c.kind = D5_WRA;
      end
      D5_WRP: if (!b[10]) c.kind = D5_WRPA;
      D5_MRW: begin
        c.mra = a[12:5]; c.op = b[7:0]; c.bg = 0; c.ba = 0;
        if (c.mra == 0 && !b[10]) begin cl = ddr5_cl_of(c.op); cwl = cl - 2; end
      end
      D5_MRR: begin c.mra = a[12:5]; c.bg = 0; c.ba = 0; end
      default: ;
    endcase
    if (c.kind inside {D5_RD, D5_RDA, D5_WR, D5_WRA}) begin
      ddr5_transaction t = ddr5_transaction::type_id::create("tr");
      bit w = c.kind inside {D5_WR, D5_WRA};
      if (!open_[bn])
        `uvm_error("DDR5_MON", $sformatf("%s to bank %0d with no open row", c.kind.name(), bn))
      t.write = w; t.bg = a[8]; t.ba = a[7:6]; t.row = orow[bn]; t.burst = c.col[9:4];
      t.auto_pre = c.kind inside {D5_RDA, D5_WRA}; t.t_cmd = t1; t.tag = item_cnt++;
      t.wdata = '0; t.rdata = '0;
      xq.push_back(t); xbeat.push_back(0);
      // write beats are sampled CWL clocks after the device takes the WR;
      // read beats appear one clock after the device drives them
      xstart.push_back(w ? t1 + cfg.cmd_lat + cwl : t1 + cfg.cmd_lat + cl + 1);
      // auto precharge: the row closes; the next ACT may follow
      if (t.auto_pre) ap_at[bn] = cyc + 1;
    end
    cmd_ap.write(c);
  endfunction

  // ---------------------------------------------------------------- data
  protected function void sample_data();
    bit rd_seen = 0, wr_seen = 0;
    for (int i = 0; i < xq.size(); i++) begin
      int due = xstart[i] + xbeat[i];
      if (due != cyc) continue;
      if (xq[i].write) begin
        if (wr_seen) continue;
        wr_seen = 1;
        if (vif.mon_cb.wdq_valid !== 1'b1)
          `uvm_error("DDR5_MON", $sformatf("write data beat %0d of %s not valid when due", xbeat[i], xq[i].convert2string()))
        xq[i].wdata[32 * xbeat[i] +: 32] = vif.mon_cb.wdq;
      end else begin
        if (rd_seen) continue;
        rd_seen = 1;
        if (vif.mon_cb.rd_valid !== 1'b1)
          `uvm_error("DDR5_MON", $sformatf("read data beat %0d of %s missing at CL %0d", xbeat[i], xq[i].convert2string(), cl))
        xq[i].rdata[32 * xbeat[i] +: 32] = vif.mon_cb.rdq;
      end
      xbeat[i]++;
    end
    if (!rd_seen && vif.mon_cb.rd_valid === 1'b1)
      `uvm_error("DDR5_MON", "read data with no read due in this clock")
    while (xq.size() && xbeat[0] == 8) begin
      ddr5_transaction t = xq.pop_front();
      void'(xbeat.pop_front()); void'(xstart.pop_front());
      ap.write(t);
    end
  endfunction
endclass
