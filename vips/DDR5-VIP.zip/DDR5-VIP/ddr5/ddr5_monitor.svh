// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_monitor.svh -- DDR5 monitor: decodes RD/WR commands, pairs reads with rd_valid in order

class ddr5_monitor extends uvm_monitor;
  `uvm_component_utils(ddr5_monitor)

  virtual ddr5_if vif;
  uvm_analysis_port #(ddr5_transaction) ap;
  ddr5_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ddr5_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ddr5: virtual interface not set")
    if (!uvm_config_db#(ddr5_config)::get(this, "", "cfg", cfg))
      cfg = ddr5_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      ddr5_transaction pend[$];
      int unsigned age[$];
      forever begin
        @(vif.mon_cb);
        foreach (age[i]) age[i]++;
        if (vif.mon_cb.rd_valid) begin
          if (pend.size() == 0) `uvm_error("MON", "DDR5: rd_valid without an outstanding read")
          else begin
            ddr5_transaction t = pend.pop_front();
            t.rl = age.pop_front();
            t.rdata = vif.mon_cb.rd_data;
            publish(t);
          end
        end
        if (!vif.mon_cb.cs_n && vif.mon_cb.act_n) begin
          ddr5_transaction t = ddr5_transaction::type_id::create("t");
          t.write = !vif.mon_cb.addr[0];
          t.col   = vif.mon_cb.addr[13:1];
          t.bank = vif.mon_cb.bank;
          if (t.write) begin
            t.wdata = vif.mon_cb.wr_data;
            publish(t);
          end else begin
            pend.push_back(t);
            age.push_back(0);
          end
        end
      end
    end
  endtask

  function void publish(ddr5_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
