// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_config.svh -- DDR5 agent configuration

class ddr5_config extends uvm_object;
  `uvm_object_utils(ddr5_config)
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  bit coverage_enable = 1;
  bit checks_enable   = 1;
  int unsigned num_items      = 200;    // random items per base sequence
  int unsigned timeout_cycles = 4000;   // watchdog for one item
  ddr5_timing_t tm = ddr5_4800b();      // device timing in clocks
  // Clocks between a command's first cycle and the device acting on it (the
  // command pipeline of the device model; read / write latency are counted
  // from there): 2 for ddr5_ca_decoder.
  int unsigned cmd_lat = 2;
  int unsigned ref_margin = 400;        // refresh this many clocks before tREFI runs out
  int unsigned auto_pre_pct = 25;       // RDA / WRA instead of RD / WR (random sequence)
  int unsigned rows = 4;                // rows used per bank by the random sequence
  function new(string name = "ddr5_config"); super.new(name); endfunction
endclass
