// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_defs.sv -- DDR5 command set, CS_n / CA[13:0] encoding and decoding
// (JESD79-5 command truth table), DDR5-4800B timing in clocks.
//
// The agent drives and monitors the device pins: CS_n, CA[13:0] (SDR, one
// or two cycles per command), and a 32-bit data path standing for one x16
// device's BL16 burst (eight 32-bit beats of 256 bits per column access).

package ddr5_defs_pkg;

  typedef enum bit [1:0] {DDR5_OK, DDR5_ERR} ddr5_status_e;

  // Command kinds; numbering matches ddr5_ca_decoder (cmd output).
  typedef enum bit [4:0] {
    D5_NONE = 0, D5_ACT = 1, D5_RD = 2, D5_RDA = 3, D5_WR = 4, D5_WRA = 5,
    D5_PREPB = 6, D5_PREAB = 7, D5_REFAB = 8, D5_MRW = 9, D5_MRR = 10,
    D5_PRESB = 11, D5_REFSB = 12, D5_RFMAB = 13, D5_RFMSB = 14, D5_WRP = 15, D5_WRPA = 16,
    D5_VREFCA = 17, D5_VREFCS = 18, D5_SRE = 19, D5_SREF = 20, D5_PDE = 21, D5_MPC = 22,
    D5_NOP = 23, D5_RSVD = 31
  } ddr5_cmd_e;

  // Timing set in clocks (tCK 0.416 ns, DDR5-4800B, 16 Gb tRFC1).
  typedef struct {
    int tRCD, tRP, tRAS, tRRD_S, tRRD_L, tFAW, tCCD_S, tCCD_L, tRTP, tWR,
        tWTR_S, tWTR_L, tRFC, tMRD, tMRR, tREFI, CL, CWL;
  } ddr5_timing_t;

  function automatic ddr5_timing_t ddr5_4800b();
    ddr5_timing_t t;
    t.tRCD = 40; t.tRP = 40; t.tRAS = 77; t.tRRD_S = 8; t.tRRD_L = 13; t.tFAW = 40;
    t.tCCD_S = 8; t.tCCD_L = 12; t.tRTP = 19; t.tWR = 72; t.tWTR_S = 7; t.tWTR_L = 25;
    t.tRFC = 710; t.tMRD = 34; t.tMRR = 34; t.tREFI = 9375; t.CL = 40; t.CWL = 38;
    return t;
  endfunction

  // MR0 for a CAS latency (OP[6:2] = (CL - 22) / 2, OP[1:0] = 00 for BL16).
  function automatic bit [7:0] ddr5_mr0(int cl);
    return 8'(((cl - 22) / 2) << 2);
  endfunction
  function automatic int ddr5_cl_of(bit [7:0] mr0);
    return 22 + 2 * int'(mr0[6:2]);
  endfunction

  function automatic bit ddr5_two_cycle(ddr5_cmd_e k);
    return k inside {D5_ACT, D5_RD, D5_RDA, D5_WR, D5_WRA, D5_WRP, D5_WRPA, D5_MRW, D5_MRR};
  endfunction

  // CA0..CA4 opcode, listed CA0 first (the truth table's column order).
  function automatic bit [13:0] ddr5_op5(bit [13:0] w, bit [4:0] lst);
    w[0] = lst[4]; w[1] = lst[3]; w[2] = lst[2]; w[3] = lst[1]; w[4] = lst[0];
    return w;
  endfunction

  // Encode one command. Unused ("V") bits are 0. col is the 11-bit column
  // address (col[3:0] = 0 for BL16 accesses).
  function automatic void ddr5_encode(ddr5_cmd_e k, bit [2:0] bg, bit [1:0] ba, bit [17:0] row,
                                      bit [10:0] col, bit [7:0] mra, bit [7:0] op,
                                      output bit [13:0] w1, output bit [13:0] w2);
    w1 = '0; w2 = '0;
    case (k)
      D5_ACT: begin w1[5:2] = row[3:0]; w1[7:6] = ba; w1[10:8] = bg; w2 = row[17:4]; end
      D5_WR, D5_WRA: begin
        w1 = ddr5_op5(w1, 5'b10110); w1[5] = 1'b1; w1[7:6] = ba; w1[10:8] = bg;
        w2[8:1] = col[10:3]; w2[10] = (k == D5_WR); w2[11] = 1'b1;
      end
      D5_RD, D5_RDA: begin
        w1 = ddr5_op5(w1, 5'b10111); w1[5] = 1'b1; w1[7:6] = ba; w1[10:8] = bg;
        w2[8:0] = col[10:2]; w2[10] = (k == D5_RD);
      end
      D5_MRW: begin w1 = ddr5_op5(w1, 5'b10100); w1[12:5] = mra; w2[7:0] = op; end
      D5_MRR: begin w1 = ddr5_op5(w1, 5'b10101); w1[12:5] = mra; end
      D5_REFAB: begin w1 = ddr5_op5(w1, 5'b11001); w1[9] = 1'b1; end
      D5_PREAB: w1 = ddr5_op5(w1, 5'b11010);
      D5_PREPB: begin w1 = ddr5_op5(w1, 5'b11011); w1[7:6] = ba; w1[10:8] = bg; end
      default:  w1 = ddr5_op5(w1, 5'b11111);                       // NOP
    endcase
  endfunction

  // Kind of a command from its first cycle (and its second, for two-cycle
  // ones: AP bit). Returns D5_RSVD for reserved codes.
  function automatic ddr5_cmd_e ddr5_kind1(bit [13:0] a);
    if (!a[0] && !a[1]) return D5_ACT;
    if (!a[1]) begin
      case ({a[2], a[3], a[4]})
        3'b010: return D5_WRP;
        3'b100: return D5_MRW;
        3'b101: return D5_MRR;
        3'b110: return D5_WR;
        3'b111: return D5_RD;
        default: return D5_RSVD;
      endcase
    end
    case ({a[2], a[3], a[4]})
      3'b000: return a[5 + 7] ? D5_VREFCS : D5_VREFCA;
      3'b001: return a[9] ? (a[10] ? D5_REFSB : D5_REFAB) : (a[10] ? D5_RFMSB : D5_RFMAB);
      3'b010: return a[10] ? D5_PRESB : D5_PREAB;
      3'b011: return D5_PREPB;
      3'b101: return a[10] ? D5_PDE : (a[9] ? D5_SRE : D5_SREF);
      3'b110: return D5_MPC;
      3'b111: return D5_NOP;
      default: return D5_RSVD;
    endcase
  endfunction

  function automatic string ddr5_cmd_name(ddr5_cmd_e k);
    return k.name();
  endfunction
endpackage
