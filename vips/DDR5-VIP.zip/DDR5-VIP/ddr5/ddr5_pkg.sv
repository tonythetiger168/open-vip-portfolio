// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_pkg.sv -- DDR5 UVM VIP package

package ddr5_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ddr5_defs_pkg::*;
  export ddr5_defs_pkg::*;

  `include "ddr5_transaction.svh"
  `include "ddr5_config.svh"
  `include "ddr5_sequencer.svh"
  `include "ddr5_driver.svh"
  `include "ddr5_monitor.svh"
  `include "ddr5_agent.svh"
  `include "ddr5_sequences.svh"
  `include "ddr5_checker.svh"
  `include "ddr5_coverage.svh"
endpackage
