// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_sequences.svh -- DDR5 sequences

// Random traffic: cfg.num_items constrained-random items.
class ddr5_base_sequence extends uvm_sequence #(ddr5_transaction);
  `uvm_object_utils(ddr5_base_sequence)
  ddr5_config cfg;

  function new(string name = "ddr5_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ddr5_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ddr5_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ddr5_directed_sequence extends uvm_sequence #(ddr5_transaction);
  `uvm_object_utils(ddr5_directed_sequence)
  ddr5_config cfg;

  function new(string name = "ddr5_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ddr5_transaction item();
    item = ddr5_transaction::type_id::create("req");
  endfunction

  task send(ddr5_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ddr5_transaction t;
    // each bank: write then read back; an unwritten location reads 0
    for (int b = 0; b < 4; b++) begin
      t = item(); t.write = 1; t.bank = b; t.col = 13'h10 + b; t.wdata = {4{32'hD0D0_0000 | b}}; send(t);
      t = item(); t.bank = b; t.col = 13'h10 + b; send(t);
    end
    t = item(); t.col = 13'h1234; send(t);
    // overwrite, top column, back-to-back writes then reads
    t = item(); t.write = 1; t.col = 13'h1FFF; t.wdata = '1; send(t);
    t = item(); t.write = 1; t.col = 13'h1FFF; t.wdata = {4{32'h0123_4567}}; send(t);
    t = item(); t.col = 13'h1FFF; send(t);
    for (int i = 0; i < 4; i++) begin t = item(); t.write = 1; t.col = i; t.wdata = i + 1; send(t); end
    for (int i = 0; i < 4; i++) begin t = item(); t.col = i; send(t); end
  endtask
endclass
