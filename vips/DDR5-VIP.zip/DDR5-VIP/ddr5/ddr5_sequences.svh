// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_sequences.svh -- DDR5 sequences (one item = one BL16 column access).

class ddr5_seq_base extends uvm_sequence #(ddr5_transaction);
  `uvm_object_utils(ddr5_seq_base)
  ddr5_config cfg;
  function new(string name = "ddr5_seq_base"); super.new(name); endfunction

  task access(bit w, bit g, bit [1:0] b, bit [15:0] r, bit [5:0] c, bit ap = 0);
    req = ddr5_transaction::type_id::create("req");
    start_item(req);
    req.write = w; req.bg = g; req.ba = b; req.row = r; req.burst = c; req.auto_pre = ap;
    req.wdata = '0;
    if (w) for (int i = 0; i < 8; i++) req.wdata[32 * i +: 32] = $urandom;
    finish_item(req);
  endtask
endclass

// Random traffic: cfg.num_items accesses over cfg.rows rows per bank; half
// of the reads go to locations written before.
class ddr5_base_sequence extends ddr5_seq_base;
  `uvm_object_utils(ddr5_base_sequence)
  function new(string name = "ddr5_base_sequence"); super.new(name); endfunction

  task body();
    bit [24:0] written[$];
    int n = (cfg != null) ? cfg.num_items : 200;
    int rows = (cfg != null) ? cfg.rows : 4;
    int ap_pct = (cfg != null) ? cfg.auto_pre_pct : 25;
    repeat (n) begin
      bit w = ($urandom_range(99) < 55);
      bit ap = ($urandom_range(99) < ap_pct);
      bit [24:0] k = {1'($urandom), 2'($urandom), 16'($urandom_range(rows - 1)), 6'($urandom)};
      if (!w && written.size() && $urandom_range(1)) k = written[$urandom_range(written.size() - 1)];
      access(w, k[24], k[23:22], k[21:6], k[5:0], ap);
      if (w) written.push_back(k);
    end
  endtask
endclass

// Directed: page hit and miss, back-to-back column commands to the same and
// to the other bank group, read/write turnarounds, auto precharge, five
// activates in a row (tFAW), every bank.
class ddr5_directed_sequence extends ddr5_seq_base;
  `uvm_object_utils(ddr5_directed_sequence)
  function new(string name = "ddr5_directed_sequence"); super.new(name); endfunction

  task body();
    // write / read back, page hit
    access(1, 0, 0, 16'h0010, 6'd0);
    access(0, 0, 0, 16'h0010, 6'd0);
    // row miss in the same bank: PRE, ACT
    access(1, 0, 0, 16'h0011, 6'd1);
    access(0, 0, 0, 16'h0010, 6'd0);
    access(0, 0, 0, 16'h0011, 6'd1);
    // same bank group back to back (tCCD_L), then the other group (tCCD_S)
    access(1, 1, 2, 16'h0020, 6'd2);
    access(1, 1, 2, 16'h0020, 6'd3);
    access(1, 0, 2, 16'h0020, 6'd4);
    access(0, 1, 2, 16'h0020, 6'd2);
    access(0, 1, 2, 16'h0020, 6'd3);
    access(0, 0, 2, 16'h0020, 6'd4);
    // read -> write -> read turnarounds on one row
    access(0, 1, 1, 16'h0030, 6'd5);
    access(1, 1, 1, 16'h0030, 6'd5);
    access(0, 1, 1, 16'h0030, 6'd5);
    // auto precharge, then the same bank again
    access(1, 0, 3, 16'h0040, 6'd6, 1);
    access(0, 0, 3, 16'h0040, 6'd6, 1);
    access(0, 0, 3, 16'h0041, 6'd7);
    // five activates to five banks (tRRD, tFAW), every bank written and read
    for (int i = 0; i < 8; i++) access(1, i[2], i[1:0], 16'h0100 + i, 6'(i));
    for (int i = 0; i < 8; i++) access(0, i[2], i[1:0], 16'h0100 + i, 6'(i));
    // never-written location reads back zero
    access(0, 1, 3, 16'h0FFF, 6'd63);
  endtask
endclass
