// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ddr5_if.sv -- DDR5 device pins as the agent sees them: CS_n, CA[13:0]
// (command/address, SDR), and the data path of one x16 device as eight
// 32-bit beats per BL16 burst (wdq / wdq_valid from the controller, rdq /
// rd_valid from the device).

interface ddr5_if (input logic clk);
  logic        rst_n;
  logic        cs_n;
  logic [13:0] ca;
  logic [31:0] wdq;
  logic        wdq_valid;
  logic [31:0] rdq;
  logic        rd_valid;

  modport DUT (input clk, rst_n, cs_n, ca, wdq, wdq_valid, output rdq, rd_valid);
  modport DRV (input clk, rst_n, rdq, rd_valid, output cs_n, ca, wdq, wdq_valid);
  modport MON (input clk, rst_n, cs_n, ca, wdq, wdq_valid, rdq, rd_valid);

  clocking drv_cb @(posedge clk);
    default input #1step output #1;
    input  rst_n, rdq, rd_valid;
    output cs_n, ca, wdq, wdq_valid;
  endclocking

  clocking mon_cb @(posedge clk);
    default input #1step;
    input rst_n, cs_n, ca, wdq, wdq_valid, rdq, rd_valid;
  endclocking
endinterface
