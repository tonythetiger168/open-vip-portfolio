# DDR5 UVM VIP (DDR5-VIP)

DDR5 UVM VIP: simplified JEDEC command/address decode (ACT/RD/WR), 128-bit datapath, fixed read latency. Targets controller smoke and data-integrity checks; complements the DDR4 RTL IP from the open-ip-portfolio sister project.

## Structure

- `ddr5/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `ddr5_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `ddr5_base_test` (constrained-random), `ddr5_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural DDR5 DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Device timing reference (`ddr5_dev/`, v1.9.0)

The agent above drives the simplified `ddr5_model` (fixed latency, no bank
state). `ddr5_dev/` adds a device model with the JESD79-5 bank state machine
and timing rules, at the decoded command level, and a controller-side test
written from those rules:

| File | Content |
|---|---|
| `ddr5_dev/tb/ddr5_dev_model.sv` | x16 device, 2 bank groups x 4 banks, BL16: ACT / RD / RDA / WR / WRA / PREpb / PREab / REFab / MRW / MRR; RL = CL from MR0, CWL = CL - 2; tRCD, tRAS, tRP, tRRD_S/L, tFAW, tCCD_S/L, tRTP, tWR, tWTR_S/L, RD->WR turnaround, tRFC, tMRD, tMRR; auto precharge at the earliest legal time; refresh postpone / pull-in limit; a rejected command is not executed and reports its cause |
| `ddr5_dev/tb/func_ddr5_dev_tb.sv` | every timing parameter at its boundary (one clock early rejected, on time accepted), bank-state errors, PREab causes, MRR spacing, reset with reads in flight, CL 22 and CL 28, MRR, missing write data, refresh limit, 300 random commands from a timing-legal scheduler against a reference memory: 80 checks (`python3 tools/run_func_tests.py DDR5-VIP`, Verilator) |

Timing values are parameters in clocks (the test uses small values). The
CA-bus encoding, data mask, ECS, the per-bank / same-bank refresh modes,
self refresh and power-down are not modelled.

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/DDR5-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh DDR5-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py DDR5-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
