# DDR5 UVM VIP (DDR5-VIP)

DDR5 UVM VIP: simplified JEDEC command/address decode (ACT/RD/WR), 128-bit datapath, fixed read latency. Targets controller smoke and data-integrity checks; complements the DDR4 RTL IP from the open-ip-portfolio sister project.

## Structure

- `ddr5/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `ddr5_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `ddr5_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural DDR5 DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/DDR5-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh DDR5-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
