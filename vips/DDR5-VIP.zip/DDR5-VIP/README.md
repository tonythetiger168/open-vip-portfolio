# DDR5 UVM VIP (DDR5-VIP)

DDR5 UVM VIP (JESD79-5): a UVM controller agent that drives the real CS_n / CA[13:0] command bus into a pin-level command decoder and a device model with the JESD79-5 bank state machine and DDR5-4800B timing. The agent schedules ACT / RD / RDA / WR / WRA / PREpb / PREab / REFab / MRW legally, the monitor decodes the pins on its own, and a scoreboard compares every read with a reference memory.

## Structure

- `ddr5/` -- VIP core:
  - `ddr5_defs.sv` -- command codes, the CA encoder for each command, DDR5-4800B
    timing in clocks (tRCD 40, tRP 40, tRAS 77, tCCD_S/L 8/12, tWTR_S/L 7/25,
    tWR 72, tRTP 19, tRFC 710, tREFI 9375, CL 40, CWL 38), MR0 helpers
  - `ddr5_if.sv` -- CS_n, CA[13:0], write / read data (a BL16 burst of the x16 device = eight 32-bit beats, two device beats per clock)
  - `ddr5_driver.svh` -- cycle-stepped controller: open-page scheduling, every
    timing rule above, MR0 = CL 40 after reset, PREab + REFab at tREFI
  - `ddr5_monitor.svh` -- decodes the pins on its own; one command item per
    command and one access item per RD / WR with its data
  - `ddr5_checker.svh` -- controller-side rule checker on the decoded commands
    (reserved codes, CS_n in cycle 2, bank state, tRCD / tCCD / tWTR / RD->WR,
    tRAS / tRTP / tWR before PRE, tRP, tRFC / tMRD, refresh interval, MR0 BL)
  - `ddr5_coverage.svh` -- commands x bank group, page hit / miss x read / write,
    back-to-back read / write pairs in the same / other bank group
  - `sva/ddr5_compliance_checker.sv` -- pin-level SVA (CS_n in reset, X on CA,
    CS_n in cycle 2 of ACT / MRW / WRP, X on read data, write burst length)
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference memory (every read is
  checked; the driver's accesses are matched against the monitor's), rule
  checker, functional coverage
- `tests/` -- `ddr5_base_test` (constrained-random), `ddr5_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top: the agent on the pins of
  `ddr5_dev/tb/ddr5_ca_decoder_model.sv` and `ddr5_dev/tb/ddr5_dev_model.sv`
  (DDR5-4800B parameters); any command the decoder or the device rejects is a
  UVM error
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

`ddr5_func_test` on msim: 542 commands, 0 rule violations, 468 reads compared,
coverage 100%. With tRCD shortened to 30 clocks in the agent, the device
rejects the early RD / WR and the scoreboard reports the bad reads.

## Device timing reference (`ddr5_dev/`, v1.9.0)

`ddr5_dev/` holds a device model with the JESD79-5 bank state machine
and timing rules, at the decoded command level, and a controller-side test
written from those rules:

| File | Content |
|---|---|
| `ddr5_dev/tb/ddr5_dev_model.sv` | x16 device, 2 bank groups x 4 banks, BL16: ACT / RD / RDA / WR / WRA / PREpb / PREab / REFab / MRW / MRR; RL = CL from MR0, CWL = CL - 2; tRCD, tRAS, tRP, tRRD_S/L, tFAW, tCCD_S/L, tRTP, tWR, tWTR_S/L, RD->WR turnaround, tRFC, tMRD, tMRR; auto precharge at the earliest legal time; refresh postpone / pull-in limit; a rejected command is not executed and reports its cause |
| `ddr5_dev/tb/func_ddr5_dev_tb.sv` | every timing parameter at its boundary (one clock early rejected, on time accepted), bank-state errors, PREab causes, MRR spacing, reset with reads in flight, CL 22 and CL 28, MRR, missing write data, refresh limit, 300 random commands from a timing-legal scheduler against a reference memory: 80 checks (`python3 tools/run_func_tests.py DDR5-VIP`, Verilator) |

Timing values are parameters in clocks (the test uses small values).

## Command bus (`ddr5_dev/`, v1.10.0)

| File | Content |
|---|---|
| `ddr5_dev/tb/ddr5_ca_decoder_model.sv` | pin-level CS_n / CA[13:0] decoder for the JESD79-5 command truth table (section 4.1): SDR CA bus on the CK_t rising edge, one- and two-cycle commands (CA1), every command with its fields (ACT, RD/RDA, WR/WRA with burst select and partial write, WRP/WRPA, MRW with CW, MRR, VrefCA/CS, REFab/sb, RFMab/sb, PREab/sb/pb, SRE/SREF/PDE, MPC, NOP); flags reserved codes, CS_n low in cycle 2 of ACT/MRW/WRP (not executed), X on CA or CS_n (four-state simulators). Hands each command to `ddr5_dev_model` a fixed two clocks after its first cycle |
| `ddr5_dev/tb/func_ddr5_ca_tb.sv` | the truth table encoded independently with random "valid" bits (276 commands, every field compared), reserved codes, CS_n in cycle 2, DES; MR0 = CL 40 / BL16 written and read back on the pins, MRW with CW high ignored; write / read data at CWL 38 / CL 40; DDR5-4800B timing in clocks of 0.416 ns at the boundary (tRCD, tRP, tRAS, tRRD_S/L, tCCD_L, tRTP, tWR, tRFC1 16 Gb): 77 checks |

Not modelled yet: data mask, write CRC / ALERT_n, DQS preamble and
postamble timing, ECS, same-bank refresh timing, self refresh and
power-down timing.

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/DDR5-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh DDR5-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py DDR5-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
