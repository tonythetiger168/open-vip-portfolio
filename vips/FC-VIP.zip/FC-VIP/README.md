# FC — Fibre Channel UVM VIP (shared net infrastructure, 1GFC–64GFC)

Open-source UVM verification IP for **Fibre Channel** (FC-2 framing:
SOF/header/payload/CRC/EOF, class 1/2/3 service, ELS, buffer-to-buffer
credit flow control), built on the shared `net_*` infrastructure that also
carries Ethernet/UEC sideband support.

## Contents

| Path | Description |
|------|-------------|
| `rtl/net_vip_if.sv` | Protocol interface (datapath + FC sideband: fc_d_id/s_id/class/seq/ox/rx, credit_rdy/r_rdy) |
| `vip/base/net_vip_pkg.sv` | Enums, configs, `net_txn_descriptor` (real CRC-32), coverage model, end-to-end scoreboard |
| `vip/base/net_driver.sv` | `drive_fc`: SOF/header/payload/CRC/EOF composition, credit wait, error injection |
| `vip/base/net_monitor.sv` | `collect_fc`: delimiter strip, 24-byte header decode, CRC-32 re-check |
| `vip/fc/fc_protocol_checker.sv` | FC SVA: SOF/EOF delimiters, credit, class-of-service |
| `rtl/sva/fc_compliance_checker.sv` | Tiered SVA compliance checker (L1=4, L2=6, L3=0, L4=5) |
| `env/net_env.sv` | Environment: agent + scoreboard + FC checkers |
| `sequences/` | base/random/regression + FC-directed sequences |
| `tests/` | base / FC / Ethernet-grade / UEC / regression tests |
| `tb/top_tb.sv` | Testbench top + functional DUT (FC port model + MAC models) |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Architecture

```
sequence -> net_sequencer -> net_driver --drv_ap--> net_scoreboard (expected)
                                    |
                                 net_vip_if <--> net_fc_model (link FSM,
                                    |            B2B credits, CRC check)
                                    v
                              net_monitor --ap--> net_scoreboard (observed)
                                    +-> net_coverage_model
                                    +-> fc_protocol_checker + SVA L1-L4
```

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `net_base_sequence` | constrained-random frames (protocol-selectable) |
| `net_fc_class3_sequence` | FC Class-3 device-data frames (SOFn3/EOFt) |
| `net_fc_els_sequence` | Extended Link Service control frames |
| `net_unicast_sequence` | directed normal traffic |
| `net_random_sequence` | random mix |
| `net_back_to_back_sequence` | minimum-gap stress |
| `net_max_frame_sequence` | corner: 2148-byte max FC frames |
| `net_error_inject_sequence` | bad CRC / bad FCS / truncated frames |
| `net_reset_sequence` | frame right after reset release |
| `net_stress_sequence` | long weighted-mix burst |
| `net_regression_sequence` | mix of all of the above (+FC seqs when FC) |

## SVA compliance checker

- **L1 (4)**: SOF delimiter legal, EOF delimiter legal, CRC valid at EOP,
  speed encoding legal
- **L2 (6)**: frame length 36–2148B, credit-based transmit, no-X on valid,
  link-up for traffic, R_RDY/credit consistency, VC id legal
- **L4 (5)**: SOF→EOF pairing, frame start requires B2B credit, R_RDY only
  with link up, fc_valid accompanies frames, CRC verdict resolution

## Functional coverage

- `cg_frame_type`: protocol × frame-type cross (incl. FC class 1/2/3, ELS)
- `cg_frame_size`: size corners × protocol cross
- `cg_link_fsm`: link-state bins + bring-up/fault transition sequences
- `cg_error`: error type × recovery cross
- interface `cg_interface_activity`: handshake/link/error/modulation + cross

## Quick start

```bash
cd scripts
make all                          # TEST=net_random_regression_test (FC)
make run TEST=net_fc_test
./coverage_regression.sh          # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Real FC frame composition**: SOF delimiter, 24-byte FC-2 header
  (R_CTL/D_ID/S_ID/TYPE/F_CTL/SEQ_ID/OX_ID/RX_ID), payload, **computed
  CRC-32**, EOF delimiter
- **Credit flow control**: driver waits for `credit_rdy`; DUT FC port model
  manages 4 B2B credits and returns them with `r_rdy` pulses
- **Decoding monitor**: SOF/EOF strip, full header decode, CRC-32
  re-computation, truncated-frame classification
- **End-to-end scoreboard**: expected-vs-observed pairing, payload compare,
  error-injection detection accounting (`n_matches`/`n_mismatches`)
- **Functional DUT**: FC port model (link FSM, credits, CRC check) + per-port
  MAC models for the shared Ethernet interfaces
- **Directed sequences**: class-3 data, ELS, back-to-back, max-frame,
  error-inject, reset, stress + regression mix
- **SVA L4**: five FC-specific rules on top of the tiered L1/L2 set
