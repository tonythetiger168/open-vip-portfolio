// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_env.sv -- Network protocol verification environment (Fibre Channel)
// Agent + end-to-end scoreboard + FC protocol checker + tiered SVA compliance
// checker. Driver-issued transactions are the expected stream; monitor-
// decoded transactions are the observed stream.

`ifndef NET_ENV_SV
`define NET_ENV_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

// Tiered L1/L2/L3 + L4 SVA compliance checker (compiled via include path rtl/)
`include "sva/fc_compliance_checker.sv"

class net_env extends uvm_env;
  `uvm_component_utils(net_env)

  net_agent             agt;
  net_scoreboard        sb;
  fc_protocol_checker   fc_chk;
  fc_compliance_checker sva_chk;

  function new(string name = "net_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agt     = net_agent::type_id::create("agt", this);
    sb      = net_scoreboard::type_id::create("sb", this);
    fc_chk  = fc_protocol_checker::type_id::create("fc_chk", this);
    sva_chk = fc_compliance_checker::type_id::create("sva_chk", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    // end-to-end: expected (driver) vs observed (monitor)
    agt.drv.drv_ap.connect(sb.exp_ap);
    agt.mon.analysis_port.connect(sb.obs_ap);
  endfunction

  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("ENV_RPT", $sformatf("net_env done, coverage = %0.2f%%",
              agt.cov.get_coverage()), UVM_LOW)
  endfunction
endclass
`endif
