// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_base_test.sv -- Network protocol base test
// Builds net_env, wires the virtual interface / protocol / config selected
// by the derived test, and provides a helper to run a sequence.

`ifndef NET_BASE_TEST_SV
`define NET_BASE_TEST_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_base_test extends uvm_test;
  `uvm_component_utils(net_base_test)

  net_env          env;
  net_protocol_e   protocol;
  string           vif_name;
  int              bytes_per_beat;
  int              num_frames;

  function new(string name = "net_base_test", uvm_component parent = null);
    super.new(name, parent);
    protocol       = NET_ETH_1G;
    vif_name       = "eth_1g_vif";
    bytes_per_beat = 64;
    num_frames     = 20;
  endfunction

  virtual function void build_phase(uvm_phase phase);
    virtual net_vip_if vif;
    net_protocol_config pcfg;
    super.build_phase(phase);

    if (!uvm_config_db#(virtual net_vip_if)::get(this, "", vif_name, vif))
      `uvm_fatal("NOVIF", $sformatf("virtual interface %s not found", vif_name))

    pcfg = new("pcfg", protocol);

    uvm_config_db#(virtual net_vip_if)::set(this, "env.agt.*", "vif", vif);
    uvm_config_db#(virtual net_vip_if)::set(this, "env.fc_chk", "vif", vif);
    uvm_config_db#(virtual net_vip_if)::set(this, "env.sva_chk", "vif", vif);
    uvm_config_db#(net_protocol_e)::set(this, "env.agt.*", "protocol", protocol);
    uvm_config_db#(net_protocol_e)::set(this, "env.fc_chk", "protocol", protocol);
    uvm_config_db#(net_protocol_cfg_t)::set(this, "env.agt.*", "cfg", pcfg.cfg);
    uvm_config_db#(int)::set(this, "env.agt.*", "bytes_per_beat", bytes_per_beat);

    env = net_env::type_id::create("env", this);
  endfunction

  // Default stimulus: base random sequence on the selected protocol
  virtual task run_phase(uvm_phase phase);
    net_base_sequence seq;
    phase.raise_objection(this);
    seq = net_base_sequence::type_id::create("seq");
    seq.num_frames = num_frames;
    seq.target_protocol = protocol;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
