// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// FC Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 19
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
`ifndef FC_COMPLIANCE_CHECKER_SV
`define FC_COMPLIANCE_CHECKER_SV



import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// fc_compliance_checker_sva -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module fc_compliance_checker_sva (net_vip_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; l4_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_fc_sof; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sop |-> vif.data[31:0] inside {32'hFFFFFFF6,32'hFFFFFFF7,32'hFFFFFFF5,32'hFFFFFFF4,32'hFFFFFFF2,32'hFFFFFFF3,32'hFFFFFFF1,32'hFFFFFFF0}; endproperty
  assert_p_fc_sof: assert property(p_fc_sof) l1_pass[0]++; else begin `uvm_warning("FC_L1", "SOF delimiter failed"); l1_fail[0]++; end
  cover_p_fc_sof: cover property(p_fc_sof);
  property p_fc_eof; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.data[31:0] inside {32'hFFFFFFF7,32'hFFFFFFF5,32'hFFFFFFF4,32'hFFFFFFF2,32'hFFFFFFF3,32'hFFFFFFF1,32'hFFFFFFF0}; endproperty
  assert_p_fc_eof: assert property(p_fc_eof) l1_pass[1]++; else begin `uvm_warning("FC_L1", "EOF delimiter failed"); l1_fail[1]++; end
  cover_p_fc_eof: cover property(p_fc_eof);
  property p_fc_crc_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.crc_ok; endproperty
  assert_p_fc_crc_valid: assert property(p_fc_crc_valid) l1_pass[2]++; else begin `uvm_warning("FC_L1", "CRC on EOF failed"); l1_fail[2]++; end
  cover_p_fc_crc_valid: cover property(p_fc_crc_valid);
  property p_fc_speed; @(posedge vif.clk) disable iff (!vif.rst_n) vif.speed inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110}; endproperty
  assert_p_fc_speed: assert property(p_fc_speed) l1_pass[3]++; else begin `uvm_warning("FC_L1", "Speed valid failed"); l1_fail[3]++; end
  cover_p_fc_speed: cover property(p_fc_speed);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_fc_frame_len; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.frame_len >= 11'd36 && vif.frame_len <= 11'd2148; endproperty
  assert_p_fc_frame_len: assert property(p_fc_frame_len) l2_pass[0]++; else begin `uvm_warning("FC_L2", "36-2148 bytes failed"); l2_fail[0]++; end
  cover_p_fc_frame_len: cover property(p_fc_frame_len);
  property p_fc_credit_rdy; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.credit_rdy; endproperty
  assert_p_fc_credit_rdy: assert property(p_fc_credit_rdy) l2_pass[1]++; else begin `uvm_warning("FC_L2", "Credit FC failed"); l2_fail[1]++; end
  cover_p_fc_credit_rdy: cover property(p_fc_credit_rdy);
  property p_fc_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_fc_no_x: assert property(p_fc_no_x) l2_pass[2]++; else begin `uvm_warning("FC_L2", "No X when valid failed"); l2_fail[2]++; end
  cover_p_fc_no_x: cover property(p_fc_no_x);
  property p_fc_link_up; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.link_up; endproperty
  assert_p_fc_link_up: assert property(p_fc_link_up) l2_pass[3]++; else begin `uvm_warning("FC_L2", "Link up for traffic failed"); l2_fail[3]++; end
  cover_p_fc_link_up: cover property(p_fc_link_up);
  property p_fc_r_rdy; @(posedge vif.clk) disable iff (!vif.rst_n) vif.r_rdy |-> vif.credit_rdy; endproperty
  assert_p_fc_r_rdy: assert property(p_fc_r_rdy) l2_pass[4]++; else begin `uvm_warning("FC_L2", "R_RDY valid failed"); l2_fail[4]++; end
  cover_p_fc_r_rdy: cover property(p_fc_r_rdy);
  property p_fc_vc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vc_id <= 8'd255; endproperty
  assert_p_fc_vc: assert property(p_fc_vc) l2_pass[5]++; else begin `uvm_warning("FC_L2", "Virtual channel valid failed"); l2_fail[5]++; end
  cover_p_fc_vc: cover property(p_fc_vc);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: FC class of service must be a defined class (1/2/3/4/F)
  property p_fc_l3_class; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fc_valid |-> vif.fc_class inside {4'd1,4'd2,4'd3,4'd4,4'd6}; endproperty
  assert_p_fc_l3_class: assert property(p_fc_l3_class) l3_pass[0]++; else begin `uvm_warning("FC_L3", "Invalid FC class of service failed"); l3_fail[0]++; end
  cover_p_fc_l3_class: cover property(p_fc_l3_class);
  // L3-2: SEQ_ID must stay constant for all words inside a sequence frame
  property p_fc_l3_seqid_stable; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && !vif.sop && !vif.eop) |-> $stable(vif.fc_seq_id); endproperty
  assert_p_fc_l3_seqid_stable: assert property(p_fc_l3_seqid_stable) l3_pass[1]++; else begin `uvm_warning("FC_L3", "SEQ_ID changed mid-frame failed"); l3_fail[1]++; end
  cover_p_fc_l3_seqid_stable: cover property(p_fc_l3_seqid_stable);
  // L3-3: originator exchange ID must be assigned (not 0xFFFF) at frame start
  property p_fc_l3_oxid; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.fc_valid && vif.sop) |-> vif.fc_ox_id != 16'hFFFF; endproperty
  assert_p_fc_l3_oxid: assert property(p_fc_l3_oxid) l3_pass[2]++; else begin `uvm_warning("FC_L3", "Unassigned OX_ID at SOF failed"); l3_fail[2]++; end
  cover_p_fc_l3_oxid: cover property(p_fc_l3_oxid);
  // L3-4: D_ID/S_ID must be known and non-zero when a frame starts
  property p_fc_l3_addr_known; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.fc_valid && vif.sop) |-> (vif.fc_d_id != 24'h0 && !$isunknown({vif.fc_d_id, vif.fc_s_id})); endproperty
  assert_p_fc_l3_addr_known: assert property(p_fc_l3_addr_known) l3_pass[3]++; else begin `uvm_warning("FC_L3", "D_ID/S_ID unknown or zero failed"); l3_fail[3]++; end
  cover_p_fc_l3_addr_known: cover property(p_fc_l3_addr_known);

  // ---------------- L4: Fibre Channel protocol-specific rules (5) ----------------
  // L4-1: SOF and EOF delimiter pairing - every SOP is eventually terminated
  property p_fc_l4_sof_eof_pair; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.fc_valid && vif.sop) |-> s_eventually vif.eop; endproperty
  assert_p_fc_l4_sof_eof_pair: assert property(p_fc_l4_sof_eof_pair) l4_pass[0]++; else begin `uvm_warning("FC_L4", "SOF without eventual EOF"); l4_fail[0]++; end
  cover_p_fc_l4_sof_eof_pair: cover property(p_fc_l4_sof_eof_pair);
  // L4-2: frames may only start with transmit credit available (B2B credit)
  property p_fc_l4_credit; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.fc_valid && vif.sop) |-> vif.credit_rdy; endproperty
  assert_p_fc_l4_credit: assert property(p_fc_l4_credit) l4_pass[1]++; else begin `uvm_warning("FC_L4", "Frame started without B2B credit"); l4_fail[1]++; end
  cover_p_fc_l4_credit: cover property(p_fc_l4_credit);
  // L4-3: R_RDY primitive only when link is up
  property p_fc_l4_rrdy_link; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.r_rdy |-> vif.link_up; endproperty
  assert_p_fc_l4_rrdy_link: assert property(p_fc_l4_rrdy_link) l4_pass[2]++; else begin `uvm_warning("FC_L4", "R_RDY while link down"); l4_fail[2]++; end
  cover_p_fc_l4_rrdy_link: cover property(p_fc_l4_rrdy_link);
  // L4-4: FC traffic requires fc_valid accompanying the datapath valid
  property p_fc_l4_fcvalid; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop) |-> vif.fc_valid; endproperty
  assert_p_fc_l4_fcvalid: assert property(p_fc_l4_fcvalid) l4_pass[3]++; else begin `uvm_warning("FC_L4", "FC frame without fc_valid"); l4_fail[3]++; end
  cover_p_fc_l4_fcvalid: cover property(p_fc_l4_fcvalid);
  // L4-5: CRC verdict resolves at frame end (crc_ok or crc_error observed)
  property p_fc_l4_crc_verdict; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.fcs_valid |-> (vif.crc_ok || vif.crc_error || vif.len_error); endproperty
  assert_p_fc_l4_crc_verdict: assert property(p_fc_l4_crc_verdict) l4_pass[4]++; else begin `uvm_warning("FC_L4", "FCS valid without verdict"); l4_fail[4]++; end
  cover_p_fc_l4_crc_verdict: cover property(p_fc_l4_crc_verdict);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("FC_RPT", $sformatf("=== FC Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("FC_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("FC_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("FC_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("FC_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("FC_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule

// ============================================================================
// fc_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the fc_compliance_checker_sva module above)
// ============================================================================
class fc_compliance_checker extends uvm_component;
  `uvm_component_utils(fc_compliance_checker)
  function new(string name = "fc_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

`endif
