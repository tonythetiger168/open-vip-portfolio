// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_vip_if.sv -- Network protocol interface
// Supports: Ethernet 10M-1.6T, UEC, Fibre Channel
// Signals are driven/sampled through clocking blocks; sideband signals
// (header fields, status, errors) travel in parallel with the data bus.

`ifndef NET_VIP_IF_SV
`define NET_VIP_IF_SV

interface net_vip_if #(parameter int DATA_WIDTH = 512,
                       parameter int LANE_COUNT = 8,
                       parameter int PROTOCOL   = 0)
                      (input logic clk, input logic rst_n);

  //========================================================================
  // Common datapath signals
  //========================================================================
  logic                   valid;
  logic                   ready;
  logic [DATA_WIDTH-1:0]  data;
  logic [LANE_COUNT-1:0]  lane_valid;
  logic                   sop;      // Start of Packet
  logic                   eop;      // End of Packet
  logic [7:0]             be;       // Byte Enable

  //========================================================================
  // Ethernet-specific signals
  //========================================================================
  logic [47:0]            dst_mac;
  logic [47:0]            src_mac;
  logic [15:0]            ethertype;
  logic [11:0]            vlan_id;
  logic [2:0]             vlan_pcp;
  logic                   vlan_cfi;
  logic [31:0]            fcs;
  logic [7:0]             preamble;
  logic                   fcs_valid;
  logic                   crc_ok;

  // Protocol status / observability (driven by driver + DUT)
  logic [2:0]             speed;       // encoded speed grade
  logic [10:0]            frame_len;   // observed frame length in bytes
  logic                   vlan_tag;    // frame carries an 802.1Q tag
  logic                   jumbo_en;    // jumbo frames enabled
  logic [15:0]            length_dw;   // frame length in dwords

  //========================================================================
  // High-Speed Ethernet Signals (200G+)
  //========================================================================
  logic                   fec_valid;
  logic                   fec_error;
  logic [1:0]             modulation;   // NRZ=0, PAM4=1, PAM6=2, PAM8=3
  logic [LANE_COUNT-1:0]  pcs_lane_status;
  logic [7:0]             pcs_lane_number;

  //========================================================================
  // UEC-Specific Signals
  //========================================================================
  logic [3:0]             uec_vc;       // Virtual Channel
  logic [15:0]            uec_ai_tag;   // AI/ML tag
  logic                   uec_congestion;
  logic [7:0]             uec_priority;

  //========================================================================
  // Fibre Channel Signals
  //========================================================================
  logic [23:0]            fc_d_id;
  logic [23:0]            fc_s_id;
  logic [3:0]             fc_class;
  logic [7:0]             fc_seq_id;
  logic [15:0]            fc_ox_id;
  logic [15:0]            fc_rx_id;
  logic                   fc_valid;
  logic                   fc_rdy;
  // FC buffer-to-buffer credit / link service observability
  logic                   credit_rdy;   // transmit credit available
  logic                   r_rdy;        // R_RDY primitive received
  logic [7:0]             vc_id;        // FC virtual circuit id

  //========================================================================
  // Link State
  //========================================================================
  net_link_state_e        link_state;
  logic                   link_up;

  //========================================================================
  // Error Signals
  //========================================================================
  logic                   crc_error;
  logic                   fcs_error;
  logic                   len_error;
  logic                   framing_error;
  logic                   fec_uncorrectable;

  //========================================================================
  // Clocking Blocks
  //========================================================================
  clocking driver_cb @(posedge clk);
    output valid, data, lane_valid, sop, eop, be;
    output dst_mac, src_mac, ethertype, vlan_id, vlan_pcp, vlan_cfi, fcs;
    output preamble, speed, frame_len, vlan_tag, jumbo_en, length_dw;
    output fec_valid, fec_error, modulation, pcs_lane_status, pcs_lane_number;
    output uec_vc, uec_ai_tag, uec_congestion, uec_priority;
    output fc_d_id, fc_s_id, fc_class, fc_seq_id, fc_ox_id, fc_rx_id, fc_valid;
    input  ready, link_up, link_state, fc_rdy;
    input  credit_rdy, r_rdy, vc_id;
    input  crc_error, fcs_error, len_error, framing_error, fec_uncorrectable;
  endclocking

  clocking monitor_cb @(posedge clk);
    input  valid, ready, data, lane_valid, sop, eop, be;
    input  dst_mac, src_mac, ethertype, vlan_id, vlan_pcp, vlan_cfi, fcs, fcs_valid, crc_ok;
    input  preamble, speed, frame_len, vlan_tag, jumbo_en, length_dw;
    input  fec_valid, fec_error, modulation, pcs_lane_status, pcs_lane_number;
    input  uec_vc, uec_ai_tag, uec_congestion, uec_priority;
    input  fc_d_id, fc_s_id, fc_class, fc_seq_id, fc_ox_id, fc_rx_id, fc_valid, fc_rdy;
    input  credit_rdy, r_rdy, vc_id;
    input  link_up, link_state;
    input  crc_error, fcs_error, len_error, framing_error, fec_uncorrectable;
  endclocking

  //========================================================================
  // Modports
  //========================================================================
  modport driver_mp (clocking driver_cb, input clk, rst_n);
  modport monitor_mp (clocking monitor_cb, input clk, rst_n);

  //========================================================================
  // Assertion: Valid-Ready Handshake
  //========================================================================
  property p_valid_ready_handshake;
    @(posedge clk) disable iff (!rst_n)
      valid |-> ##[1:100] ready;
  endproperty
  assert_valid_ready: assert property (p_valid_ready_handshake)
    else $error("NET_IF: Valid-Ready handshake timeout");

  //========================================================================
  // Assertion: SOP-EOP Alignment
  //========================================================================
  property p_sop_eop_alignment;
    @(posedge clk) disable iff (!rst_n)
      sop |-> !eop ##[1:4096] eop;
  endproperty
  assert_sop_eop: assert property (p_sop_eop_alignment)
    else $error("NET_IF: SOP-EOP alignment violation");

  //========================================================================
  // Assertion: Link State Validity
  //========================================================================
  property p_link_state_valid;
    @(posedge clk) disable iff (!rst_n)
      link_state inside {LINK_DOWN, LINK_ANEG, LINK_TRAINING, LINK_UP,
                         LINK_LOCAL_FAULT, LINK_REMOTE_FAULT, LINK_TEST,
                         LINK_RECOVERY};
  endproperty
  assert_link_state: assert property (p_link_state_valid)
    else $error("NET_IF: Invalid link state detected");

  //========================================================================
  // Assertion: FCS Check (when fcs_valid asserted)
  //========================================================================
  property p_fcs_check;
    @(posedge clk) disable iff (!rst_n)
      fcs_valid |-> crc_ok;
  endproperty
  assert_fcs_check: assert property (p_fcs_check)
    else $error("NET_IF: FCS mismatch detected");

  //========================================================================
  // Coverage: Interface Activity
  //========================================================================
  covergroup cg_interface_activity @(posedge clk);
    option.per_instance = 1;

    cp_valid: coverpoint valid {
      bins inactive = {0};
      bins active   = {1};
    }
    cp_ready: coverpoint ready {
      bins inactive = {0};
      bins active   = {1};
    }
    cp_handshake: coverpoint {valid, ready} {
      bins idle       = {2'b00};
      bins wait_ready = {2'b10};
      bins transfer   = {2'b11};
      bins wait_valid = {2'b01};
    }
    cp_link_state: coverpoint link_state;
    cp_error: coverpoint {crc_error, fcs_error, len_error, framing_error, fec_uncorrectable} {
      bins no_error    = {5'b00000};
      bins crc_err     = {5'b10000};
      bins fcs_err     = {5'b01000};
      bins len_err     = {5'b00100};
      bins frame_err   = {5'b00010};
      bins fec_uncorr  = {5'b00001};
    }
    cp_modulation: coverpoint modulation {
      bins nrz  = {2'b00};
      bins pam4 = {2'b01};
      bins pam6 = {2'b10};
      bins pam8 = {2'b11};
    }
    cx_valid_ready: cross cp_valid, cp_ready;
  endgroup

  cg_interface_activity cg_if = new();

endinterface
`endif
