// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_regression_sequence.sv -- Regression mix of all directed sequences

`ifndef NET_REGRESSION_SEQUENCE_SV
`define NET_REGRESSION_SEQUENCE_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_regression_sequence extends net_base_sequence;
  `uvm_object_utils(net_regression_sequence)

  function new(string name = "net_regression_sequence");
    super.new(name);
  endfunction

  virtual task body();
    net_unicast_sequence      unicast_seq;
    net_vlan_sequence         vlan_seq;
    net_pause_sequence        pause_seq;
    net_back_to_back_sequence b2b_seq;
    net_max_frame_sequence    max_seq;
    net_error_inject_sequence err_seq;
    net_stress_sequence       stress_seq;
    net_fc_class3_sequence    fc_cls3_seq;
    net_fc_els_sequence       fc_els_seq;

    `uvm_info("SEQ", $sformatf("Regression mix for %s", target_protocol.name()), UVM_LOW)

    unicast_seq = net_unicast_sequence::type_id::create("unicast_seq");
    unicast_seq.num_frames = num_frames / 4 + 1;
    unicast_seq.target_protocol = target_protocol;
    unicast_seq.start(m_sequencer);

    vlan_seq = net_vlan_sequence::type_id::create("vlan_seq");
    vlan_seq.num_frames = num_frames / 8 + 1;
    vlan_seq.target_protocol = target_protocol;
    vlan_seq.start(m_sequencer);

    pause_seq = net_pause_sequence::type_id::create("pause_seq");
    pause_seq.num_frames = 2;
    pause_seq.target_protocol = target_protocol;
    pause_seq.start(m_sequencer);

    b2b_seq = net_back_to_back_sequence::type_id::create("b2b_seq");
    b2b_seq.num_frames = num_frames / 4 + 1;
    b2b_seq.target_protocol = target_protocol;
    b2b_seq.start(m_sequencer);

    max_seq = net_max_frame_sequence::type_id::create("max_seq");
    max_seq.num_frames = 2;
    max_seq.target_protocol = target_protocol;
    max_seq.start(m_sequencer);

    err_seq = net_error_inject_sequence::type_id::create("err_seq");
    err_seq.num_frames = 6;
    err_seq.target_protocol = target_protocol;
    err_seq.start(m_sequencer);

    stress_seq = net_stress_sequence::type_id::create("stress_seq");
    stress_seq.num_frames = num_frames / 4 + 1;
    stress_seq.target_protocol = target_protocol;
    stress_seq.start(m_sequencer);

    if (target_protocol == NET_FC) begin
      fc_cls3_seq = net_fc_class3_sequence::type_id::create("fc_cls3_seq");
      fc_cls3_seq.num_frames = num_frames / 4 + 1;
      fc_cls3_seq.start(m_sequencer);

      fc_els_seq = net_fc_els_sequence::type_id::create("fc_els_seq");
      fc_els_seq.num_frames = 4;
      fc_els_seq.start(m_sequencer);
    end
  endtask
endclass
`endif
