// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_fc_tb.sv -- self-checking functional test for the Fibre Channel port
// model (net_fc_model, flattened by smoke/flatten.py). The shared Ethernet
// MAC model (net_mac_model) is covered by Ethernet-VIP/tb/smoke_func_tb.sv.
// Run: python3 tools/run_func_tests.py FC-VIP
//
// Model contract (from tb/top_tb.sv):
//   link FSM DOWN (6 clk) -> ANEG (8) -> TRAINING (8) -> UP on link_state.
//   BB_Credit = 4: ready = fc_rdy = credit_rdy = (credits > 0) && link up.
//   An SOP beat with fc_valid consumes one credit; while credits < 4 one is
//   returned every 8 clocks with a one-clock r_rdy pulse.
//   Frames arrive 32 bytes per beat (last beat: 8 bytes per be bit) as
//   SOF(4) | header + payload | CRC-32 (LSB byte first) | EOF(4). At EOP
//   fcs_valid pulses; < 36 bytes -> len_error, CRC mismatch -> crc_error
//   (pulses); crc_ok holds the result of the last frame.
//
// Frames outside 36..2148 bytes raise len_error (CRC still checked above
// 36 bytes); a beat without a preceding SOP sets framing_error until the
// next SOP. A credit used in the clock one is returned leaves the count
// unchanged.

module func_fc_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic         clk = 1'b0, rst_n = 1'b0;
  logic         valid = 1'b0, sop = 1'b0, eop = 1'b0, fc_valid = 1'b0;
  logic [511:0] data = '0;
  logic [7:0]   be = 8'hFF;
  wire          ready, fcs_valid, crc_ok, fc_rdy, credit_rdy, r_rdy, link_up;
  wire          crc_error, fcs_error, len_error, framing_error, fec_unc;
  wire  [7:0]   vc_id;
  wire  [3:0]   link_state;

  always #5 clk = ~clk;

  net_fc_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_valid(valid), .vif_ready(ready),
    .vif_data(data), .vif_sop(sop), .vif_eop(eop), .vif_be(be),
    .vif_fcs_valid(fcs_valid), .vif_crc_ok(crc_ok), .vif_fc_valid(fc_valid),
    .vif_fc_rdy(fc_rdy), .vif_credit_rdy(credit_rdy), .vif_r_rdy(r_rdy),
    .vif_vc_id(vc_id), .vif_link_up(link_up), .vif_crc_error(crc_error),
    .vif_fcs_error(fcs_error), .vif_len_error(len_error),
    .vif_framing_error(framing_error), .vif_fec_uncorrectable(fec_unc),
    .vif_link_state(link_state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // ---- reference CRC-32 (IEEE 802.3 / FC-FS, reflected) ----
  logic [7:0] fr [0:4095];
  int         flen;
  function automatic logic [31:0] crc32(input int from, input int to);
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    for (int i = from; i < to; i++) begin
      c ^= fr[i];
      for (int b = 0; b < 8; b++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    return ~c;
  endfunction

  // SOF + 24-byte header + payload + CRC + EOF; total must be a multiple of 8
  task automatic build(input int payload, input bit bad_crc = 0);
    logic [31:0] c;
    flen = 0;
    fr[0] = 8'hBC; fr[1] = 8'hB5; fr[2] = 8'h56; fr[3] = 8'h56;     // SOFi3
    for (int i = 0; i < 24 + payload; i++) fr[4 + i] = 8'h30 + i[7:0];
    flen = 28 + payload;
    c = crc32(4, flen) ^ (bad_crc ? 32'h0000_0100 : 32'h0);
    for (int i = 0; i < 4; i++) fr[flen + i] = c[i*8 +: 8];
    flen += 4;
    fr[flen] = 8'hBC; fr[flen+1] = 8'h95; fr[flen+2] = 8'h75; fr[flen+3] = 8'h75;  // EOFt
    flen += 4;
  endtask

  int accepted_sops;
  always @(posedge clk) if (valid && sop && ready && fc_valid) accepted_sops++;

  // send the frame; gap inserts an idle clock between beats
  task automatic send(input bit with_fc = 1, input bit gap = 0, input bit with_sop = 1);
    int off;
    off = 0;
    while (off < flen) begin
      int nb;
      nb = (flen - off > 32) ? 32 : flen - off;
      @(negedge clk);
      data = '0;
      for (int j = 0; j < nb; j++) data[j*8 +: 8] = fr[off + j];
      sop = with_sop && (off == 0); eop = (off + nb == flen); fc_valid = with_fc && (off == 0);
      be = (nb == 32) ? 8'hFF : 8'((1 << (nb / 8)) - 1);
      valid = 1'b1;
      @(posedge clk);
      while (ready !== 1'b1) @(posedge clk);
      off += nb;
      if (gap && off < flen) begin @(negedge clk); valid = 1'b0; end
    end
    @(negedge clk);
    valid = 1'b0; sop = 1'b0; eop = 1'b0; fc_valid = 1'b0;
  endtask

  // flags seen in the clocks after a frame
  bit s_fv, s_ce, s_le;
  int n_fv;
  always @(posedge clk) begin
    if (fcs_valid) begin s_fv = 1; n_fv++; end
    if (crc_error) s_ce = 1;
    if (len_error) s_le = 1;
  end
  task automatic clr(); s_fv = 0; s_ce = 0; s_le = 0; n_fv = 0; endtask
  task automatic settle(); repeat (3) @(negedge clk); endtask

  // wait for all credits to come back
  task automatic refill();
    int k;
    k = 0;
    while (u_dut.credits != 4 && k < 100) begin @(negedge clk); k++; end
    @(negedge clk);
  endtask

  int  n_down, n_aneg, n_train, bad_seq, rr, rr_gap, last_rr, t;
  logic [3:0] prev_ls;

  initial begin
    // reference CRC self-check: "123456789"
    for (int i = 0; i < 9; i++) fr[i] = 8'h31 + i;
    chk(crc32(0, 9) == 32'hCBF4_3926, "reference CRC-32 check value 0xCBF43926");

    repeat (3) @(negedge clk);
    chk(link_state == 4'h0 && !link_up && !ready && !credit_rdy && !r_rdy,
        "reset: link down, no credit ready, no R_RDY");
    chk(vc_id == 8'h00, "virtual channel 0");

    // ---- link bring-up ----
    rst_n = 1'b1;
    prev_ls = 4'h0;
    for (int k = 0; k < 40; k++) begin
      @(negedge clk);
      case (link_state)
        4'h0: n_down++;
        4'h1: n_aneg++;
        4'h2: n_train++;
        4'h3: ;
        default: bad_seq++;
      endcase
      if (link_state < prev_ls || link_state > prev_ls + 1) bad_seq++;
      prev_ls = link_state;
    end
    chk(bad_seq == 0 && link_state == 4'h3 && link_up, "link state goes DOWN -> ANEG -> TRAINING -> UP");
    chk(n_aneg == 8 && n_train == 8, "auto-negotiation and training last 8 clocks each");
    chk(n_down == 5, "link leaves DOWN on the 6th clock after reset release");
    chk(ready && credit_rdy && fc_rdy, "ready / credit_rdy / fc_rdy high once the link is up");

    // ---- good frames ----
    clr();
    build(4);                                 // 40-byte frame
    send();
    settle();
    chk(n_fv == 1 && crc_ok && !s_ce && !s_le, "40-byte frame: one fcs_valid, crc_ok, no errors");
    refill();
    clr();
    build(4);
    send();
    settle();
    chk(crc_ok && !s_ce, "second identical frame with a correct CRC accepted");
    refill();
    clr();
    build(2048 + 4);                          // 2084 bytes, gaps between beats
    send(1, 1);
    settle();
    chk(n_fv == 1 && crc_ok && !s_ce && !s_le, "2084-byte frame with idle gaps: crc_ok");
    refill();
    clr();
    build(12);                                // 48 bytes = 32 + 16 (be = 0x03)
    send();
    settle();
    chk(n_fv == 1 && crc_ok, "partial last beat (be = 0x03) honoured");
    refill();

    // ---- errors ----
    clr();
    build(4, 1);
    send();
    settle();
    chk(s_ce && !crc_ok && !s_le, "corrupted CRC: crc_error pulse, crc_ok low");
    chk(fcs_valid === 1'b0 && crc_error === 1'b0, "fcs_valid / crc_error are single-clock pulses");
    refill();
    clr();
    build(0);                                 // 36 bytes: minimum ...
    flen = 32;                                // ... truncated to one 32-byte beat
    send();
    settle();
    chk(s_le && !crc_ok, "32-byte frame (< 36) raises len_error");
    refill();
    clr();
    build(4);
    send();
    settle();
    chk(crc_ok && !s_le, "crc_ok recovers on the next good frame");
    refill();
    clr();
    build(2112 + 4);                          // 2152 bytes > FC max frame 2148
    send(1, 0);
    settle();
    chk(crc_ok && !s_ce, "2152-byte frame: CRC still checked (good)");
    chk(s_le, "frame longer than 2148 bytes raises len_error");
    refill();
    clr();
    build(2108);                              // 2144 bytes (beats carry multiples of 8)
    send(1, 0);
    settle();
    chk(crc_ok && !s_le, "2144-byte frame (within 2148): no len_error");
    refill();
    clr();
    // EOP beat without a preceding SOP
    @(negedge clk);
    data = '1; sop = 0; eop = 1; be = 8'hFF; valid = 1;
    @(negedge clk);
    valid = 0; eop = 0;
    settle();
    chk(framing_error === 1'b1, "EOP without SOP raises framing_error");
    chk(!s_fv, "EOP without SOP is not evaluated as a frame");
    chk(fcs_error === 1'b0 && fec_unc === 1'b0, "fcs_error / fec_uncorrectable stay low");
    refill();
    clr();
    build(4);
    send();
    settle();
    chk(crc_ok && framing_error === 1'b0, "next frame (SOP) clears framing_error");

    // ---- BB_Credit ----
    refill();
    accepted_sops = 0;
    build(28);                                // 64 bytes = 2 beats
    for (int f = 0; f < 4; f++) send();
    chk(accepted_sops == 4 && u_dut.credits <= 4 - 4 + 2, "4 frames consume credits");
    refill();
    // 4 SOP beats back to back exhaust the credits
    rr = 0; last_rr = -1; rr_gap = 0;
    fork
      begin
        for (int k = 0; k < 60; k++) begin
          @(posedge clk);
          if (r_rdy) begin
            if (last_rr >= 0 && k - last_rr != 8) rr_gap++;
            last_rr = k; rr++;
          end
        end
      end
      begin
        accepted_sops = 0;
        @(negedge clk);
        data = '0; sop = 1; eop = 1; be = 8'hFF; fc_valid = 1; valid = 1;
        repeat (4) @(negedge clk);
        chk(!ready && !credit_rdy && !fc_rdy && accepted_sops == 4,
            "4 back-to-back SOPs exhaust BB_Credit: ready low");
        repeat (3) @(negedge clk);
        chk(accepted_sops == 4, "no SOP accepted with zero credit");
        valid = 0; sop = 0; eop = 0; fc_valid = 0;
      end
    join
    chk(rr == 4 && rr_gap == 0, "4 R_RDY pulses, 8 clocks apart, return the credits");
    chk(ready && u_dut.credits == 4, "all credits restored");

    // frames without fc_valid do not consume credit
    accepted_sops = 0;
    build(4);
    send(0);
    chk(u_dut.credits == 4, "frame without fc_valid consumes no credit");

    // SOP accepted in the clock a credit returns: both are counted
    @(negedge clk); data = '0; sop = 1; eop = 1; fc_valid = 1; valid = 1;
    @(negedge clk); valid = 0; sop = 0; eop = 0; fc_valid = 0;
    t = 0;
    while (t < 20) begin
      @(negedge clk); t++;
      if (u_dut.rtn_timer == 7) break;
    end
    // next posedge returns a credit; consume one in the same clock
    sop = 1; eop = 1; fc_valid = 1; valid = 1;
    @(negedge clk); valid = 0; sop = 0; eop = 0; fc_valid = 0;
    chk(u_dut.credits == 3, "credit consumed in the R_RDY clock is counted (3 left)");
    refill();

    // ---- reset ----
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(link_state == 4'h0 && !ready && !crc_ok && !r_rdy && u_dut.credits == 4,
        "reset drops the link, clears crc_ok and restores credits");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
