// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- Network protocol testbench top
// Instantiates one interface per protocol/speed grade and a functional DUT
// (net_dut) that models link bring-up, ready/flow-control, FCS checking and
// FC buffer-to-buffer credits, closing the loop with the UVM monitor.

`ifndef TOP_TB_SV
`define TOP_TB_SV

`include "uvm_macros.svh"
import uvm_pkg::*;
import net_vip_pkg::*;

module top_tb;

  // Clock and reset
  logic clk = 0;
  logic rst_n;
  always #2ns clk = ~clk;   // 250MHz

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  // Interfaces
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(1),  .PROTOCOL(0)) eth_1g_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(4),  .PROTOCOL(1)) eth_100g_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(2)) eth_400g_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(3)) eth_800g_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(4)) eth_1p6t_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(5)) uec_if(clk, rst_n);
  net_vip_if #(.DATA_WIDTH(256), .LANE_COUNT(1),  .PROTOCOL(6)) fc_if(clk, rst_n);

  // Functional DUT: MAC loopback + FC port model
  net_dut dut (
    .clk(clk), .rst_n(rst_n),
    .eth_1g_if(eth_1g_if),
    .eth_100g_if(eth_100g_if),
    .eth_400g_if(eth_400g_if),
    .eth_800g_if(eth_800g_if),
    .eth_1p6t_if(eth_1p6t_if),
    .uec_if(uec_if),
    .fc_if(fc_if)
  );

  // Tiered SVA compliance checker (module form), bound to the FC port
  fc_compliance_checker_sva u_fc_sva_chk (.vif(fc_if));

  // Protocol-specific SVA checkers (module form)
  eth_protocol_checker_sva #(.protocol(NET_ETH_1G)) u_eth_proto_sva (.vif(eth_1g_if));
  uec_protocol_checker_sva u_uec_proto_sva (.vif(uec_if));
  fc_protocol_checker_sva  u_fc_proto_sva  (.vif(fc_if));

  initial begin
    // Pass interfaces to UVM
    // NOTE: the virtual-interface type must match each instance's exact
    // parameter specialization (IEEE 1800 strong typing of virtual interfaces)
    uvm_config_db#(virtual net_vip_if#(.DATA_WIDTH(512), .LANE_COUNT(1),  .PROTOCOL(0)))::set(null, "*", "eth_1g_vif", eth_1g_if);
    uvm_config_db#(virtual net_vip_if#(.DATA_WIDTH(512), .LANE_COUNT(4),  .PROTOCOL(1)))::set(null, "*", "eth_100g_vif", eth_100g_if);
    uvm_config_db#(virtual net_vip_if#(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(2)))::set(null, "*", "eth_400g_vif", eth_400g_if);
    uvm_config_db#(virtual net_vip_if#(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(3)))::set(null, "*", "eth_800g_vif", eth_800g_if);
    uvm_config_db#(virtual net_vip_if#(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(4)))::set(null, "*", "eth_1p6t_vif", eth_1p6t_if);
    uvm_config_db#(virtual net_vip_if#(.DATA_WIDTH(512), .LANE_COUNT(8),  .PROTOCOL(5)))::set(null, "*", "uec_vif", uec_if);
    uvm_config_db#(virtual net_vip_if#(.DATA_WIDTH(256), .LANE_COUNT(1),  .PROTOCOL(6)))::set(null, "*", "fc_vif", fc_if);
    run_test();
  end
endmodule

//==========================================================================
// CRC-32 (IEEE 802.3) helper shared by the DUT models
//==========================================================================
package net_dut_crc_pkg;
  function automatic bit [31:0] crc32(ref bit [7:0] bytes[$]);
    bit [31:0] crc;
    crc = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 32'hEDB8_8320 : (crc >> 1);
    end
    return ~crc;
  endfunction
endpackage

//==========================================================================
// Functional Ethernet MAC model: link FSM, ready/flow control, FCS check.
// PAUSE frames (ethertype 0x8808) apply backpressure for a few cycles.
//==========================================================================
module net_mac_model #(parameter int BPB = 64) (net_vip_if vif);
  import net_dut_crc_pkg::crc32;

  typedef enum logic [1:0] {LS_DOWN, LS_ANEG, LS_TRAIN, LS_UP} ls_e;
  ls_e ls;
  int  ls_timer;
  int  pause_cnt;

  bit [7:0] frame_q[$];
  bit       in_frame;

  // Link bring-up FSM: DOWN -> ANEG -> TRAINING -> UP
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      ls <= LS_DOWN;
      ls_timer <= 0;
    end else begin
      case (ls)
        LS_DOWN:  begin if (ls_timer > 4)  begin ls <= LS_ANEG;  ls_timer <= 0; end else ls_timer <= ls_timer + 1; end
        LS_ANEG:  begin if (ls_timer > 8)  begin ls <= LS_TRAIN; ls_timer <= 0; end else ls_timer <= ls_timer + 1; end
        LS_TRAIN: begin if (ls_timer > 8)  begin ls <= LS_UP;    ls_timer <= 0; end else ls_timer <= ls_timer + 1; end
        LS_UP:    ls_timer <= 0;
        default:  ls <= LS_DOWN;
      endcase
    end
  end

  assign vif.link_state = (ls == LS_UP)    ? LINK_UP :
                          (ls == LS_ANEG)  ? LINK_ANEG :
                          (ls == LS_TRAIN) ? LINK_TRAINING : LINK_DOWN;
  assign vif.link_up    = (ls == LS_UP);

  // Ready / flow control: ready high in link-up unless a PAUSE frame
  // applied backpressure.
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      vif.ready <= 1'b0;
      pause_cnt <= 0;
    end else begin
      if (pause_cnt > 0) begin
        pause_cnt <= pause_cnt - 1;
        vif.ready <= 1'b0;
      end else begin
        vif.ready <= (ls == LS_UP);
      end
    end
  end

  // Frame capture + FCS check
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      frame_q.delete();
      in_frame <= 0;
      vif.fcs_valid <= 1'b0;
      vif.crc_ok    <= 1'b0;
      vif.crc_error <= 1'b0;
      vif.fcs_error <= 1'b0;
      vif.len_error <= 1'b0;
      vif.framing_error <= 1'b0;
      vif.fec_uncorrectable <= 1'b0;
    end else begin
      vif.fcs_valid <= 1'b0;
      vif.crc_error <= 1'b0;
      vif.fcs_error <= 1'b0;
      vif.len_error <= 1'b0;
      if (vif.valid && vif.ready) begin
        if (vif.sop) begin
          frame_q.delete();
          in_frame <= 1;
        end
        if (in_frame || vif.sop) begin
          int n;
          n = BPB;
          if (vif.eop && vif.be != 8'hFF && vif.be != 8'h00) begin
            n = 0;
            for (int j = 0; j < 8; j++) if (vif.be[j]) n += 8;
          end
          for (int j = 0; j < n; j++)
            frame_q.push_back(vif.data[j*8 +: 8]);
        end
        if (vif.eop) begin
          // evaluate: strip preamble+SFD (8B), FCS (4B)
          bit [7:0] body[$];
          bit [31:0] calc, rcv;
          in_frame <= 0;
          body.delete();
          for (int i = 8; i < frame_q.size() - 4; i++)
            body.push_back(frame_q[i]);
          calc = crc32(body);
          for (int i = 0; i < 4; i++)
            rcv[i*8 +: 8] = (frame_q.size() >= 4) ? frame_q[frame_q.size()-4+i] : 8'h00;
          vif.fcs_valid <= 1'b1;
          if (frame_q.size() < 64) begin
            vif.len_error <= 1'b1;
            vif.crc_ok    <= 1'b0;
          end else if (calc != rcv) begin
            vif.crc_error <= 1'b1;
            vif.crc_ok    <= 1'b0;
          end else begin
            vif.crc_ok    <= 1'b1;
          end
          // 802.3x PAUSE: backpressure for a few cycles
          if (frame_q.size() > 22 && frame_q[20] == 8'h88 && frame_q[21] == 8'h08)
            pause_cnt <= 4;
        end
      end
    end
  end
endmodule

//==========================================================================
// Functional Fibre Channel port model: link FSM, B2B credit management
// (credit_rdy / r_rdy), SOF/EOF framing and CRC checking.
//==========================================================================
module net_fc_model (net_vip_if vif);
  import net_dut_crc_pkg::crc32;

  typedef enum logic [1:0] {LS_DOWN, LS_ANEG, LS_TRAIN, LS_UP} ls_e;
  ls_e ls;
  int  ls_timer;
  int  credits;
  int  rtn_timer;

  bit [7:0] frame_q[$];
  bit       in_frame;

  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      ls <= LS_DOWN;
      ls_timer <= 0;
    end else begin
      case (ls)
        LS_DOWN:  begin if (ls_timer > 4)  begin ls <= LS_ANEG;  ls_timer <= 0; end else ls_timer <= ls_timer + 1; end
        LS_ANEG:  begin if (ls_timer > 6)  begin ls <= LS_TRAIN; ls_timer <= 0; end else ls_timer <= ls_timer + 1; end
        LS_TRAIN: begin if (ls_timer > 6)  begin ls <= LS_UP;    ls_timer <= 0; end else ls_timer <= ls_timer + 1; end
        LS_UP:    ls_timer <= 0;
        default:  ls <= LS_DOWN;
      endcase
    end
  end

  assign vif.link_state = (ls == LS_UP)    ? LINK_UP :
                          (ls == LS_ANEG)  ? LINK_ANEG :
                          (ls == LS_TRAIN) ? LINK_TRAINING : LINK_DOWN;
  assign vif.link_up    = (ls == LS_UP);
  assign vif.vc_id      = 8'h00;

  // Buffer-to-buffer credits: 4 initial credits, one returned every 8
  // cycles; r_rdy pulses when a credit is returned.
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      credits   <= 4;
      rtn_timer <= 0;
      vif.r_rdy <= 1'b0;
    end else begin
      vif.r_rdy <= 1'b0;
      if (vif.fc_valid && vif.sop && vif.ready && credits > 0)
        credits <= credits - 1;
      if (credits < 4) begin
        if (rtn_timer >= 7) begin
          credits   <= credits + 1;
          rtn_timer <= 0;
          vif.r_rdy <= 1'b1;
        end else begin
          rtn_timer <= rtn_timer + 1;
        end
      end else begin
        rtn_timer <= 0;
      end
    end
  end

  assign vif.credit_rdy = (credits > 0) && (ls == LS_UP);
  assign vif.fc_rdy     = vif.credit_rdy;
  assign vif.ready      = vif.credit_rdy;

  // Frame capture + CRC check (header+payload between SOF/EOF and CRC)
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      frame_q.delete();
      in_frame <= 0;
      vif.fcs_valid <= 1'b0;
      vif.crc_ok    <= 1'b0;
      vif.crc_error <= 1'b0;
      vif.fcs_error <= 1'b0;
      vif.len_error <= 1'b0;
      vif.framing_error <= 1'b0;
      vif.fec_uncorrectable <= 1'b0;
    end else begin
      vif.fcs_valid <= 1'b0;
      vif.crc_error <= 1'b0;
      vif.len_error <= 1'b0;
      if (vif.valid && vif.ready) begin
        if (vif.sop) begin
          frame_q.delete();
          in_frame <= 1;
        end
        if (in_frame || vif.sop) begin
          int n;
          n = 32;   // DATA_WIDTH=256 -> 32 bytes/beat
          if (vif.eop && vif.be != 8'hFF && vif.be != 8'h00) begin
            n = 0;
            for (int j = 0; j < 8; j++) if (vif.be[j]) n += 8;
          end
          for (int j = 0; j < n; j++)
            frame_q.push_back(vif.data[j*8 +: 8]);
        end
        if (vif.eop) begin
          bit [7:0] body[$];
          bit [31:0] calc, rcv;
          in_frame <= 0;
          // CRC covers header+payload: bytes[4 .. size-9] (excl SOF/CRC/EOF)
          for (int i = 4; i < frame_q.size() - 8; i++)
            body.push_back(frame_q[i]);
          calc = crc32(body);
          for (int i = 0; i < 4; i++)
            rcv[i*8 +: 8] = (frame_q.size() >= 8) ? frame_q[frame_q.size()-8+i] : 8'h00;
          vif.fcs_valid <= 1'b1;
          if (frame_q.size() < 36) begin
            vif.len_error <= 1'b1;
            vif.crc_ok    <= 1'b0;
          end else if (calc != rcv) begin
            vif.crc_error <= 1'b1;
            vif.crc_ok    <= 1'b0;
          end else begin
            vif.crc_ok    <= 1'b1;
          end
        end
      end
    end
  end
endmodule

//==========================================================================
// DUT wrapper: one MAC model per Ethernet/UEC port, one FC port model.
//==========================================================================
module net_dut (
  input logic clk,
  input logic rst_n,
  net_vip_if eth_1g_if,
  net_vip_if eth_100g_if,
  net_vip_if eth_400g_if,
  net_vip_if eth_800g_if,
  net_vip_if eth_1p6t_if,
  net_vip_if uec_if,
  net_vip_if fc_if
);
  net_mac_model #(.BPB(64)) m_eth_1g   (.vif(eth_1g_if));
  net_mac_model #(.BPB(64)) m_eth_100g (.vif(eth_100g_if));
  net_mac_model #(.BPB(64)) m_eth_400g (.vif(eth_400g_if));
  net_mac_model #(.BPB(64)) m_eth_800g (.vif(eth_800g_if));
  net_mac_model #(.BPB(64)) m_eth_1p6t (.vif(eth_1p6t_if));
  net_mac_model #(.BPB(64)) m_uec      (.vif(uec_if));
  net_fc_model              m_fc       (.vif(fc_if));
endmodule
`endif
