// AXI4_Manager_Port-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
common/axim_if.sv
common/ssv_apb_if.sv
common/ssv_pkg.sv
tests/axim_kit_pkg.sv
tb/top_tb.sv
