# Avalon-ST UVM VIP (Avalon_ST-UVM-VIP)

Avalon-ST source/sink UVM VIP: ready-valid packet streaming with SOP/EOP delimiters. Complements the Avalon-ST RTL IP from the open-ip-portfolio sister project.

## Structure

- `avalon_st/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `avalon_st_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `avalon_st_base_test` (constrained-random), `avalon_st_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural Avalon-ST DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/Avalon_ST-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh Avalon_ST-UVM-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py Avalon_ST-UVM-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
