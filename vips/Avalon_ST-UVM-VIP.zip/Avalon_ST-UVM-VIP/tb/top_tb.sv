// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- Avalon-ST testbench top with a functional Avalon-ST DUT model

`ifndef Avalon-ST_TB_SV
`define Avalon-ST_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import avalon_st_defs_pkg::*;
import avalon_st_pkg::*;
import avalon_st_env_pkg::*;
import avalon_st_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  avalon_st_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  avalon_st_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .asi_data(vif.asi_data),
    .asi_valid(vif.asi_valid),
    .asi_startofpacket(vif.asi_startofpacket),
    .asi_endofpacket(vif.asi_endofpacket),
    .asi_ready(vif.asi_ready),
    .aso_data(vif.aso_data),
    .aso_valid(vif.aso_valid),
    .aso_startofpacket(vif.aso_startofpacket),
    .aso_endofpacket(vif.aso_endofpacket),
    .aso_ready(vif.aso_ready)
  );

  // Concurrent protocol checks
  avalon_st_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .asi_data(vif.asi_data), .asi_valid(vif.asi_valid), .asi_startofpacket(vif.asi_startofpacket), .asi_endofpacket(vif.asi_endofpacket), .asi_ready(vif.asi_ready), .aso_data(vif.aso_data), .aso_valid(vif.aso_valid), .aso_startofpacket(vif.aso_startofpacket), .aso_endofpacket(vif.aso_endofpacket), .aso_ready(vif.aso_ready)
  );

  initial begin
    uvm_config_db#(virtual avalon_st_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module avalon_st_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [31:0] asi_data,
  input  logic        asi_valid,
  input  logic        asi_startofpacket,
  input  logic        asi_endofpacket,
  output logic        asi_ready,
  output logic [31:0] aso_data,
  output logic        aso_valid,
  output logic        aso_startofpacket,
  output logic        aso_endofpacket,
  input  logic        aso_ready
);
  logic [31:0] skid_data;
  logic        skid_valid, skid_sop, skid_eop;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      asi_ready         <= 1'b0;
      aso_data          <= '0;
      aso_valid         <= 1'b0;
      aso_startofpacket <= 1'b0;
      aso_endofpacket   <= 1'b0;
      skid_data         <= '0;
      skid_valid        <= 1'b0;
      skid_sop          <= 1'b0;
      skid_eop          <= 1'b0;
    end else begin
      asi_ready <= 1'b1;
      // registered passthrough: one beat per cycle, no skid contention
      aso_valid <= asi_valid && asi_ready;
      if (asi_valid && asi_ready) begin
        aso_data          <= asi_data;
        aso_startofpacket <= asi_startofpacket;
        aso_endofpacket   <= asi_endofpacket;
      end
    end
  end
endmodule
`endif
