// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (Avalon-ST packet passthrough)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened avalon_st_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [31:0] asi_data = '0;
  logic asi_valid = 1'b0;
  logic asi_startofpacket = 1'b0;
  logic asi_endofpacket = 1'b0;
  wire  asi_ready;
  wire  [31:0] aso_data;
  wire  aso_valid;
  wire  aso_startofpacket;
  wire  aso_endofpacket;
  logic aso_ready = 1'b1;

  always #5 clk = ~clk;

  avalon_st_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .asi_data(asi_data), .asi_valid(asi_valid),
    .asi_startofpacket(asi_startofpacket),
    .asi_endofpacket(asi_endofpacket), .asi_ready(asi_ready),
    .aso_data(aso_data), .aso_valid(aso_valid),
    .aso_startofpacket(aso_startofpacket),
    .aso_endofpacket(aso_endofpacket), .aso_ready(aso_ready)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [31:0] pkt [0:3];
  initial begin
    pkt[0] = 32'h11111111; pkt[1] = 32'h22222222;
    pkt[2] = 32'h33333333; pkt[3] = 32'h44444444;

    repeat (8) step();
    chk(aso_valid === 1'b0, "source valid reset low");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();
    chk(asi_ready === 1'b1, "sink ready asserted after reset");

    // send a 4-beat packet; check each beat inside its valid window (negedge)
    @(negedge clk);
    for (int i = 0; i < 4; i++) begin
      asi_data = pkt[i]; asi_valid = 1;
      asi_startofpacket = (i == 0);
      asi_endofpacket   = (i == 3);
      step();                       // P_i: sink accepts beat i
      @(negedge clk);               // inside beat-i valid window
      chk(aso_valid === 1'b1, "source valid during packet");
      chk(aso_data === pkt[i], "packet data integrity");
      chk(aso_startofpacket === (i == 0), "SOP only on first beat");
      chk(aso_endofpacket === (i == 3), "EOP only on last beat");
    end
    asi_valid = 0;
    asi_startofpacket = 0; asi_endofpacket = 0;
    step();                         // beat accepted at P_4 -> valid window ends
    chk(aso_valid === 1'b0, "source idle after packet");
    repeat (3) step();

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
