// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_avalon_st_tb.sv -- Avalon-ST streaming functional test for the
// pass-through model (avalon_st_model, flattened by smoke/flatten.py);
// complements smoke_func_tb.sv (one 4-beat packet).
// Run: python3 tools/run_func_tests.py Avalon_ST-UVM-VIP
//
// Model contract (from tb/top_tb.sv): sink ready (asi_ready) rises one
// clock after reset; every accepted beat (asi_valid && asi_ready) appears
// on the source one clock later with its startofpacket / endofpacket.
// Checked with 200 random packets (1..16 beats) and random valid gaps,
// and reset in the middle of a packet. Downstream back-pressure: the source
// holds a beat while aso_ready is low, a one-beat skid buffer absorbs the
// beat in flight, and asi_ready drops while it is full.
//
`timescale 1ns/1ps
module func_avalon_st_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [31:0] asi_data = '0;
  logic        asi_valid = 0, asi_sop = 0, asi_eop = 0, aso_ready = 1;
  wire         asi_ready, aso_valid, aso_sop, aso_eop;
  wire  [31:0] aso_data;

  always #5 clk = ~clk;

  avalon_st_model u_dut (
    .clk(clk), .rst_n(rst_n), .asi_data(asi_data), .asi_valid(asi_valid),
    .asi_startofpacket(asi_sop), .asi_endofpacket(asi_eop), .asi_ready(asi_ready),
    .aso_data(aso_data), .aso_valid(aso_valid), .aso_startofpacket(aso_sop),
    .aso_endofpacket(aso_eop), .aso_ready(aso_ready)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // expected beats {sop, eop, data} in order; source-side scoreboard
  logic [33:0] exp_q [0:8191];
  int          eh = 0, et = 0, bad = 0, extra = 0, lat_bad = 0;
  int          cyc = 0, acc_t [0:8191], rdy_low = 0;
  always @(posedge clk) if (rst_n && !asi_ready) rdy_low++;
  bit          bp_done;
  always @(posedge clk) begin
    cyc++;
    if (aso_valid && aso_ready) begin
      if (et == eh) extra++;
      else begin
        if ({aso_sop, aso_eop, aso_data} !== exp_q[et]) bad++;
        if (cyc - acc_t[et] != 1) lat_bad++;
        et++;
      end
    end
    if (asi_valid && asi_ready) begin
      exp_q[eh] = {asi_sop, asi_eop, asi_data}; acc_t[eh] = cyc; eh++;
    end
  end

  task automatic beat(input [31:0] d, input bit s, input bit e);
    asi_data = d; asi_sop = s; asi_eop = e; asi_valid = 1;
    @(negedge clk);
    while (!asi_ready) @(negedge clk);
    asi_valid = 0;
  endtask

  initial begin
    repeat (2) @(negedge clk);
    chk(!asi_ready && !aso_valid && !aso_sop && !aso_eop && aso_data === '0,
        "reset: sink not ready, source idle, SOP / EOP / data 0");
    rst_n = 1'b1;
    chk(!asi_ready, "asi_ready still low right after reset release");
    @(negedge clk);
    chk(asi_ready, "asi_ready one clock after reset release");

    // random packets with gaps
    for (int p = 0; p < 200; p++) begin
      int n;
      n = $urandom_range(1, 16);
      for (int i = 0; i < n; i++) begin
        if ($urandom_range(3) == 0) repeat ($urandom_range(1, 3)) @(negedge clk);
        beat($urandom, i == 0, i == n - 1);
      end
    end
    repeat (3) @(negedge clk);
    chk(et == eh && bad == 0, "200 random packets: every beat, SOP and EOP passed through in order");
    chk(lat_bad == 0 && extra == 0, "one clock latency, no beat while the sink is idle");
    chk(!aso_valid, "source valid low after the last beat");

    // single-beat packet, then reset while SOP / EOP are high on the source
    beat(32'hCAFE_F00D, 1, 1);
    chk(aso_valid && aso_sop && aso_eop && aso_data == 32'hCAFE_F00D, "single-beat packet: SOP and EOP together");
    rst_n = 1'b0;
    #1;
    chk(!aso_valid && !aso_sop && !aso_eop && aso_data === '0 && !asi_ready, "reset clears the source and sink ready");
    @(negedge clk); rst_n = 1'b1;
    @(negedge clk);

    // back-pressure from the downstream sink
    eh = 0; et = 0; bad = 0;
    rdy_low = 0;
    fork
      begin
        for (int i = 0; i < 8; i++) beat(32'h100 + i, i == 0, i == 7);
      end
      begin
        @(negedge clk); aso_ready = 0;
        repeat (4) @(negedge clk);
        aso_ready = 1;
      end
    join
    repeat (4) @(negedge clk);
    chk(et == 8 && bad == 0, "beats held while aso_ready is low (no data lost)");
    chk(rdy_low > 0, "asi_ready drops while the skid buffer is full");
    chk(!aso_valid && asi_ready, "pipeline drained and sink ready again after back-pressure");

    // random back-pressure with gaps in the input: no beat lost, none invented
    eh = 0; et = 0; bad = 0; extra = 0;
    bp_done = 0;
    fork
      begin
        for (int p = 0; p < 40; p++) begin
          int n;
          n = $urandom_range(1, 6);
          for (int i = 0; i < n; i++) begin
            if ($urandom_range(2) == 0) repeat ($urandom_range(1, 3)) @(negedge clk);
            beat($urandom, i == 0, i == n - 1);
          end
        end
        bp_done = 1;
      end
      while (!bp_done) begin
        @(negedge clk); aso_ready = ($urandom_range(2) != 0);
      end
    join
    aso_ready = 1;
    repeat (4) @(negedge clk);
    chk(et == eh && bad == 0 && extra == 0,
        $sformatf("random back-pressure with input gaps: %0d of %0d beats in order, none extra", et, eh));

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
