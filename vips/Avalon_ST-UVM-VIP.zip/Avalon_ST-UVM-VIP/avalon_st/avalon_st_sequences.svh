// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_sequences.svh -- Avalon-ST sequences

// Random traffic: cfg.num_items constrained-random items.
class avalon_st_base_sequence extends uvm_sequence #(avalon_st_transaction);
  `uvm_object_utils(avalon_st_base_sequence)
  avalon_st_config cfg;

  function new(string name = "avalon_st_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = avalon_st_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "avalon_st_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class avalon_st_directed_sequence extends uvm_sequence #(avalon_st_transaction);
  `uvm_object_utils(avalon_st_directed_sequence)
  avalon_st_config cfg;

  function new(string name = "avalon_st_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function avalon_st_transaction item();
    item = avalon_st_transaction::type_id::create("req");
  endfunction

  task send(avalon_st_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    avalon_st_transaction t;
    t = item(); t.seed = 32'h1; t.fill_data(1); send(t);                // single-beat packet (SOP+EOP)
    t = item(); t.seed = 32'h2; t.fill_data(12); send(t);               // long packet, back-to-back beats
    t = item(); t.seed = 32'h3; t.gap = 3; t.fill_data(5); send(t);     // idle clocks inside the packet
    t = item(); t.data = '{32'h0, 32'hFFFF_FFFF}; send(t);
    for (int i = 0; i < 4; i++) begin t = item(); t.seed = 100 + i; t.fill_data(2); send(t); end
  endtask
endclass
