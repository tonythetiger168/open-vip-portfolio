// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_if.sv -- Avalon-ST interface

interface avalon_st_if (input logic clk);
  logic rst_n;

  logic [31:0] asi_data;
  logic asi_valid;
  logic asi_startofpacket;
  logic asi_endofpacket;
  logic asi_ready;
  logic [31:0] aso_data;
  logic aso_valid;
  logic aso_startofpacket;
  logic aso_endofpacket;
  logic aso_ready;

  modport DUT (input clk, rst_n, asi_data, asi_valid, asi_startofpacket, asi_endofpacket, aso_ready, output asi_ready, aso_data, aso_valid, aso_startofpacket, aso_endofpacket);
  modport DRV (input clk, rst_n, asi_ready, aso_data, aso_valid, aso_startofpacket, aso_endofpacket, output asi_data, asi_valid, asi_startofpacket, asi_endofpacket, aso_ready);
  modport MON (input clk, rst_n, asi_data, asi_valid, asi_startofpacket, asi_endofpacket, asi_ready, aso_data, aso_valid, aso_startofpacket, aso_endofpacket, aso_ready);

  clocking drv_cb @(posedge clk);
    input rst_n, asi_data, asi_valid, asi_startofpacket, asi_endofpacket, asi_ready, aso_data, aso_valid, aso_startofpacket, aso_endofpacket, aso_ready;
    output asi_data, asi_valid, asi_startofpacket, asi_endofpacket, aso_ready;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, asi_data, asi_valid, asi_startofpacket, asi_endofpacket, asi_ready, aso_data, aso_valid, aso_startofpacket, aso_endofpacket, aso_ready;
  endclocking
endinterface
