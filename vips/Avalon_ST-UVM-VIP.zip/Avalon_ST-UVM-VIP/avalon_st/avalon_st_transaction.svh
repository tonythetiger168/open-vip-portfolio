// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_transaction.svh -- Avalon-ST transaction

class avalon_st_transaction extends uvm_sequence_item;
  `uvm_object_utils(avalon_st_transaction)

  // request (driven by the agent)
  bit [31:0] data[$];
  // response (returned by the DUT)
  bit [31:0] out_data[$];
  bit out_framing_ok;
  // bookkeeping (not compared)
  rand bit [3:0] nbeats;
  rand bit [1:0] gap;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len { nbeats inside {[1:12]}; gap dist { 0 := 3, [1:3] :/ 1 }; }

  function new(string name = "avalon_st_transaction"); super.new(name); endfunction

  function void fill_data(int unsigned nb);
    bit [31:0] x = seed | 32'h1;
    data.delete();
    for (int unsigned i = 0; i < nb; i++) begin
      bit [31:0] v;
      for (int k = 0; k < 1; k++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        v = (v << 32) | 32'(x);
      end
      data.push_back(v);
    end
  endfunction

  function void post_randomize();
    fill_data(nbeats);
  endfunction

  function void do_copy(uvm_object rhs);
    avalon_st_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    data = rhs_.data;
    out_data = rhs_.out_data;
    out_framing_ok = rhs_.out_framing_ok;
    nbeats = rhs_.nbeats;
    gap = rhs_.gap;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    avalon_st_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (out_data.size() != rhs_.out_data.size()) return 0;
    foreach (out_data[i]) if (out_data[i] != rhs_.out_data[i]) return 0;
    if (out_framing_ok != rhs_.out_framing_ok) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(avalon_st_transaction rhs_);
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    return 1;
  endfunction

  function string qstr_data();
    string s = $sformatf("[%0d]{", data.size());
    foreach (data[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", data[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_out_data();
    string s = $sformatf("[%0d]{", out_data.size());
    foreach (out_data[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", out_data[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("Avalon-ST{tag=%0d data=%s out_data=%s out_framing_ok=0x%0h}", tag, qstr_data(), qstr_out_data(), out_framing_ok);
  endfunction
endclass
