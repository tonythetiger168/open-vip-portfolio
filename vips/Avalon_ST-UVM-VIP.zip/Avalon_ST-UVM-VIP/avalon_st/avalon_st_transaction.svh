// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_transaction.svh -- Avalon-ST transaction

class avalon_st_transaction extends uvm_sequence_item;
  `uvm_object_utils(avalon_st_transaction)

  rand bit [31:0] asi_data;
  rand bit asi_valid;
  rand bit asi_startofpacket;
  rand bit asi_endofpacket;
  rand bit aso_ready;
  bit asi_ready_o;
  bit [31:0] aso_data_o;
  bit aso_valid_o;
  bit aso_startofpacket_o;
  bit aso_endofpacket_o;
  bit [31:0] tag;

  function new(string name = "avalon_st_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    avalon_st_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    asi_data = rhs_.asi_data;
    asi_valid = rhs_.asi_valid;
    asi_startofpacket = rhs_.asi_startofpacket;
    asi_endofpacket = rhs_.asi_endofpacket;
    aso_ready = rhs_.aso_ready;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    avalon_st_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           asi_data == rhs_.asi_data &&
           asi_valid == rhs_.asi_valid &&
           asi_startofpacket == rhs_.asi_startofpacket &&
           asi_endofpacket == rhs_.asi_endofpacket &&
           aso_ready == rhs_.aso_ready;
  endfunction

  function string convert2string();
    return $sformatf("Avalon-ST{tag=%0h asi_data=0x%0h asi_valid=0x%0h asi_startofpacket=0x%0h asi_endofpacket=0x%0h aso_ready=0x%0h}", tag, asi_data, asi_valid, asi_startofpacket, asi_endofpacket, aso_ready);
  endfunction
endclass
