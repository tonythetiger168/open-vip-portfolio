// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_driver.svh -- Avalon-ST driver: one packet per item, beat by beat on asi_valid/asi_ready; random aso_ready

class avalon_st_driver extends uvm_driver #(avalon_st_transaction);
  `uvm_component_utils(avalon_st_driver)

  uvm_analysis_port #(avalon_st_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual avalon_st_if vif;
  avalon_st_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual avalon_st_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avalon_st: virtual interface not set")
    if (!uvm_config_db#(avalon_st_config)::get(this, "", "cfg", cfg))
      cfg = avalon_st_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    avalon_st_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      forever begin
        @(vif.drv_cb);
        vif.drv_cb.aso_ready <= ($urandom_range(99) < cfg.aso_ready_pct);
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.asi_valid <= 1'b0; vif.drv_cb.asi_data <= '0;
    vif.drv_cb.asi_startofpacket <= 1'b0; vif.drv_cb.asi_endofpacket <= 1'b0;
    vif.drv_cb.aso_ready <= 1'b1;
  endtask

  task drive_item(avalon_st_transaction t);
    @(vif.drv_cb);
    foreach (t.data[i]) begin
      vif.drv_cb.asi_valid <= 1'b1;
      vif.drv_cb.asi_data  <= t.data[i];
      vif.drv_cb.asi_startofpacket <= (i == 0);
      vif.drv_cb.asi_endofpacket   <= (i == t.data.size() - 1);
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.asi_ready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.asi_ready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("Avalon-ST asi_ready: no response within %0d cycles", cfg.timeout_cycles))
      end
      if (t.gap != 0 && i != t.data.size() - 1) begin
        vif.drv_cb.asi_valid <= 1'b0;
        repeat (t.gap - 1) @(vif.drv_cb);
        @(vif.drv_cb);
      end
    end
    vif.drv_cb.asi_valid <= 1'b0;
    vif.drv_cb.asi_startofpacket <= 1'b0;
    vif.drv_cb.asi_endofpacket   <= 1'b0;
  endtask

endclass
