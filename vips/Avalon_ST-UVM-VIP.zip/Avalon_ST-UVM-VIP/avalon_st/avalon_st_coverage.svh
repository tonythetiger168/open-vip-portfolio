// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_coverage.svh -- Avalon-ST functional coverage

class avalon_st_coverage extends uvm_subscriber #(avalon_st_transaction);
  `uvm_component_utils(avalon_st_coverage)
  avalon_st_config cfg;
  avalon_st_transaction tr;

  covergroup avalon_st_cg;
    cp_len : coverpoint tr.data.size() { bins single = {1}; bins short_ = {[2:4]}; bins long_ = {[5:12]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    avalon_st_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(avalon_st_config)::get(this, "", "cfg", cfg))
      cfg = avalon_st_config::type_id::create("cfg");
  endfunction

  function void write(avalon_st_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    avalon_st_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("Avalon-ST coverage: %0.1f%%", avalon_st_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
