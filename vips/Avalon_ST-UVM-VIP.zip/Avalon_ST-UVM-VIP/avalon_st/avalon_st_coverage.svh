// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_coverage.svh -- Avalon-ST functional coverage

class avalon_st_coverage extends uvm_subscriber #(avalon_st_transaction);
  `uvm_component_utils(avalon_st_coverage)
  avalon_st_config cfg;
  avalon_st_transaction tr;

  covergroup avalon_st_cg;
    coverpoint tr.asi_data;
    coverpoint tr.asi_valid;
    coverpoint tr.asi_startofpacket;
    coverpoint tr.asi_endofpacket;
    coverpoint tr.aso_ready;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(avalon_st_config)::get(this, "*", "cfg", cfg));
    avalon_st_cg = new();
  endfunction

  function void write(avalon_st_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    avalon_st_cg.sample();
  endfunction
endclass
