// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_monitor.svh -- Avalon-ST monitor: input packets from asi_*, paired in order with output packets on aso_*

class avalon_st_monitor extends uvm_monitor;
  `uvm_component_utils(avalon_st_monitor)

  virtual avalon_st_if vif;
  uvm_analysis_port #(avalon_st_transaction) ap;
  avalon_st_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual avalon_st_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avalon_st: virtual interface not set")
    if (!uvm_config_db#(avalon_st_config)::get(this, "", "cfg", cfg))
      cfg = avalon_st_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      // in_q holds input packets in arrival order (including the one still being
      // received: the registered output starts one clock after its first beat)
      avalon_st_transaction in_q[$], cur_in, cur_out;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.asi_valid && vif.mon_cb.asi_ready) begin
          if (vif.mon_cb.asi_startofpacket || cur_in == null) begin
            cur_in = avalon_st_transaction::type_id::create("t");
            in_q.push_back(cur_in);
          end
          cur_in.data.push_back(vif.mon_cb.asi_data);
          if (vif.mon_cb.asi_endofpacket) cur_in = null;
        end
        if (vif.mon_cb.aso_valid && vif.mon_cb.aso_ready) begin
          if (cur_out == null) begin
            if (in_q.size() == 0) begin
              `uvm_error("MON", "Avalon-ST output beat with no input packet pending")
              continue;
            end
            cur_out = in_q.pop_front();
            cur_out.out_framing_ok = vif.mon_cb.aso_startofpacket;
          end else if (vif.mon_cb.aso_startofpacket) cur_out.out_framing_ok = 0;
          cur_out.out_data.push_back(vif.mon_cb.aso_data);
          if (vif.mon_cb.aso_endofpacket) begin
            if (cur_out.out_data.size() != cur_out.data.size()) cur_out.out_framing_ok = 0;
            publish(cur_out);
            cur_out = null;
          end
        end
      end
    end
  endtask

  function void publish(avalon_st_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
