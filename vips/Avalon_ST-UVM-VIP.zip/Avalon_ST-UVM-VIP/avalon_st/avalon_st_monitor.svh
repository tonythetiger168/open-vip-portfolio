// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_monitor.svh -- Avalon-ST monitor: decodes observed bus activity

class avalon_st_monitor extends uvm_monitor;
  `uvm_component_utils(avalon_st_monitor)

  virtual avalon_st_if vif;
  uvm_analysis_port #(avalon_st_transaction) ap;
  avalon_st_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual avalon_st_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "avalon_st: virtual interface not set")
    void'(uvm_config_db#(avalon_st_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    avalon_st_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = avalon_st_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.asi_data = vif.asi_data;
        t.asi_valid = vif.asi_valid;
        t.asi_startofpacket = vif.asi_startofpacket;
        t.asi_endofpacket = vif.asi_endofpacket;
        t.aso_ready = vif.aso_ready;
        t.asi_ready_o = vif.asi_ready;
        t.aso_data_o = vif.aso_data;
        t.aso_valid_o = vif.aso_valid;
        t.aso_startofpacket_o = vif.aso_startofpacket;
        t.aso_endofpacket_o = vif.aso_endofpacket;
        ap.write(t);
      end
    end
  endtask
endclass
