// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_compliance_checker.sv -- Avalon-ST concurrent assertion checks (bindable)

module avalon_st_compliance_checker
  (input logic clk, input logic rst_n, input [31:0] asi_data, input asi_valid, input asi_startofpacket, input asi_endofpacket, input asi_ready, input [31:0] aso_data, input aso_valid, input aso_startofpacket, input aso_endofpacket, input aso_ready);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({asi_ready, aso_data, aso_valid, aso_startofpacket, aso_endofpacket}))
    else $error("Avalon-ST: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> asi_ready == '0)
    else $error("Avalon-ST: output not in reset value");
  // no SOP in the middle of a packet
  assert property (@(posedge clk) disable iff (!rst_n) aso_valid && !aso_startofpacket |=> !aso_startofpacket || !aso_valid || $fell(aso_valid))
    else $error("AVST: SOP inside packet");
  cover property (@(posedge clk) disable iff (!rst_n) (asi_ready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (aso_endofpacket == 1'b1));
endmodule
