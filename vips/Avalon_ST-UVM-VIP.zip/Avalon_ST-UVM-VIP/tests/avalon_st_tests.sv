// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// avalon_st_tests.sv -- Avalon-ST test package

package avalon_st_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import avalon_st_defs_pkg::*;
  import avalon_st_pkg::*;
  import avalon_st_env_pkg::*;

  class avalon_st_base_test extends uvm_test;
    `uvm_component_utils(avalon_st_base_test)
    avalon_st_env env;
    avalon_st_config cfg;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      cfg = avalon_st_config::type_id::create("cfg", this);
      uvm_config_db#(avalon_st_config)::set(this, "*", "cfg", cfg);
      env = avalon_st_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
      avalon_st_base_sequence seq = avalon_st_base_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass
endpackage
