// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_jesd204_tb.sv -- self-checking functional test for the JESD204B ADC
// transmitter model (jesd204_adc_dut, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py JESD204-VIP
//
// Model contract (from jesd204_defs.sv), one 32-bit lane word per clock,
// lane_k marking control characters:
//   RESET (zeros) -> SYNC~ low: CGS /K/ = BCBCBCBC -> SYNC~ high: ILAS of
//   4 multiframes x 4 words: /R/ (1C), d1, d2, /A/ (7C); in the second
//   multiframe d1 = /Q/ (9C) and d2 = config {DID A5, 01, 0001}, else 0.
//   Then user data: a ramp from 0 with lane_k low. SYNC~ low during data
//   re-enters CGS; SYNC~ high replays ILAS and restarts the ramp.
//   inj_ilas_err (sampled at ILAS entry) swaps multiframes 1 and 2.

module func_jesd204_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [31:0] K = 32'hBCBC_BCBC, R = 32'h1C1C_1C1C, Q = 32'h9C9C_9C9C,
                        A = 32'h7C7C_7C7C, CFG = 32'hA501_0001;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, sync_n = 1'b1, inj = 1'b0;
  wire  [31:0] lane_data;
  wire         lane_k;

  always #5 clk = ~clk;

  jesd204_adc_dut u_dut (
    .vif_device_clk(clk), .vif_rst_n(rst_n), .vif_sync_n(sync_n),
    .vif_lane_data(lane_data), .vif_lane_k(lane_k), .vif_inj_ilas_err(inj)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // capture the lane, one word per clock (sampled at negedge)
  logic [31:0] wd [0:255];
  bit          wk [0:255];
  task automatic cap(input int n);
    for (int i = 0; i < n; i++) begin
      @(negedge clk);
      wd[i] = lane_data; wk[i] = lane_k;
    end
  endtask

  // after SYNC~ rises: skip the /K/ words, then check ILAS + n ramp words
  bit ilas_ok, ramp_ok;
  int nk, ilas_start;
  task automatic check_ilas(input bit swapped, input int nramp);
    cap(24 + nramp);
    nk = 0;
    while (nk < 4 && wd[nk] == K && wk[nk]) nk++;
    ilas_ok = 1;
    for (int m = 0; m < 4; m++) begin
      int b;
      bit cfg_mf;
      b = nk + 4 * m;
      cfg_mf = swapped ? (m == 2) : (m == 1);
      if (!(wd[b] == R && wk[b])) ilas_ok = 0;
      if (cfg_mf) begin
        if (!(wd[b+1] == Q && wk[b+1])) ilas_ok = 0;
        if (!(wd[b+2] == CFG && !wk[b+2])) ilas_ok = 0;
      end else begin
        if (wk[b+1] || wk[b+2] || wd[b+1] != 0 || wd[b+2] != 0) ilas_ok = 0;
      end
      if (!(wd[b+3] == A && wk[b+3])) ilas_ok = 0;
    end
    ramp_ok = 1;
    for (int i = 0; i < nramp; i++)
      if (wd[nk + 16 + i] != i || wk[nk + 16 + i]) ramp_ok = 0;
  endtask

  bit allk, allz;
  initial begin
    repeat (2) @(negedge clk);
    chk(lane_data == 0 && !lane_k, "reset: lane idle (zeros, no K)");
    rst_n = 1'b1;
    cap(8);
    allz = 1;
    for (int i = 0; i < 8; i++) if (wd[i] != 0 || wk[i]) allz = 0;
    chk(allz, "no CGS before SYNC~ is asserted");

    // ---- CGS ----
    @(negedge clk); sync_n = 1'b0;
    @(negedge clk);
    cap(12);
    allk = 1;
    for (int i = 0; i < 12; i++) if (wd[i] != K || !wk[i]) allk = 0;
    chk(allk, "SYNC~ low: continuous /K/ (K28.5) code group sync");

    // ---- ILAS + data ----
    @(negedge clk); sync_n = 1'b1;
    check_ilas(0, 40);
    chk(nk == 1, "ILAS /R/ follows one /K/ after SYNC~ release");
    chk(ilas_ok, "ILAS: 4 multiframes /R/ .. /A/, /Q/ + config in the second");
    chk(ramp_ok, "user data: ramp from 0, lane_k low");

    // ---- SYNC~ request during data ----
    @(negedge clk); sync_n = 1'b0;
    @(negedge clk);
    cap(6);
    allk = 1;
    for (int i = 0; i < 6; i++) if (wd[i] != K || !wk[i]) allk = 0;
    chk(allk, "SYNC~ low during data: back to /K/");
    @(negedge clk); sync_n = 1'b1;
    check_ilas(0, 8);
    chk(ilas_ok && ramp_ok && nk == 1, "re-sync replays ILAS and restarts the ramp at 0");

    // ---- ILAS error injection ----
    @(negedge clk); sync_n = 1'b0; inj = 1'b1;
    repeat (4) @(negedge clk);
    sync_n = 1'b1;
    check_ilas(1, 4);
    chk(ilas_ok && ramp_ok, "inj_ilas_err: /Q/ + config moved to the third multiframe");
    inj = 1'b0;
    @(negedge clk); sync_n = 1'b0;
    repeat (4) @(negedge clk);
    sync_n = 1'b1;
    check_ilas(0, 4);
    chk(ilas_ok, "injection is per ILAS: next ILAS is correct");

    // ---- long data run: ramp keeps counting ----
    cap(200);
    ramp_ok = 1;
    for (int i = 1; i < 200; i++) if (wd[i] != wd[i-1] + 1 || wk[i]) ramp_ok = 0;
    chk(ramp_ok, "200 further ramp words, consecutive");

    // ---- SYNC~ glitch of one clock ----
    @(negedge clk); sync_n = 1'b0;
    @(negedge clk); sync_n = 1'b1;
    check_ilas(0, 2);
    chk(ilas_ok, "one-clock SYNC~ pulse triggers a full re-initialisation");

    // ---- reset ----
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(lane_data == 0 && !lane_k, "reset clears the lane");
    rst_n = 1'b1;
    cap(4);
    chk(wd[3] == 0 && !wk[3], "after reset: idle until SYNC~");
    // injection on the initial CGS -> ILAS path
    @(negedge clk); sync_n = 1'b0; inj = 1'b1;
    repeat (4) @(negedge clk);
    sync_n = 1'b1;
    check_ilas(1, 2);
    chk(ilas_ok && ramp_ok, "inj_ilas_err also applies to the first ILAS after CGS");
    inj = 1'b0;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
