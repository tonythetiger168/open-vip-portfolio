// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- JESD204 testbench top with a functional ADC transmitter DUT

`ifndef JESD204_TB_SV
`define JESD204_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import jesd204_defs_pkg::*;
import jesd204_pkg::*;
import jesd204_test_pkg::*;

module top_tb;
  logic device_clk = 0;
  always #5ns device_clk = ~device_clk;

  jesd204_if vif(device_clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  jesd204_adc_dut dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual jesd204_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional JESD204 ADC transmitter: while sync_n is low it streams /K/
// (CGS); on sync_n release it emits the ILAS -- exactly 4 multiframes of
// 4 words (/R/ ... /A/, DID config behind /Q/ in the second multiframe) --
// then a deterministic 32-bit ramp as user data. Reasserting sync_n
// mid-stream returns the transmitter through SYNC_RE/CGS. When
// inj_ilas_err is latched during CGS, the ILAS multiframe order is
// scrambled once ({0,2,1,3}) to model a link configuration error.
module jesd204_adc_dut (jesd204_if vif);
  import jesd204_defs_pkg::*;

  jesd204_state_e st;
  int unsigned    mf_cnt;      // multiframe index 0..JESD_ILAS_MF-1
  int unsigned    wpos;        // word index within the multiframe
  bit [31:0]      ramp;
  bit             ilas_swap;   // latched ILAS-order error injection

  // Multiframe actually served at position idx (identity or {0,2,1,3})
  function automatic int unsigned eff_mf(int unsigned idx);
    if (!ilas_swap) return idx;
    case (idx)
      1: return 2;
      2: return 1;
      default: return idx;
    endcase
  endfunction

  // Config word carried in the ILAS (DID in bits [31:24])
  function automatic bit [31:0] cfg_word();
    return {JESD_DUT_DID, 8'h01, 16'h0001};   // DID, L=1 lane, cfg
  endfunction

  always_ff @(posedge vif.device_clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      st             <= RESET;
      mf_cnt         <= 0;
      wpos           <= 0;
      ramp           <= 32'h0;
      ilas_swap      <= 1'b0;
      vif.lane_data  <= 32'h0;
      vif.lane_k     <= 1'b0;
    end else begin
      case (st)
        RESET: begin
          vif.lane_data <= 32'h0;
          vif.lane_k    <= 1'b0;
          if (!vif.sync_n) st <= CGS;
        end

        CGS: begin
          vif.lane_data <= JESD_K_W;
          vif.lane_k    <= 1'b1;
          if (vif.sync_n) begin
            st        <= ILAS;
            mf_cnt    <= 0;
            wpos      <= 0;
            ilas_swap <= vif.inj_ilas_err;   // latch injection for this ILAS
          end
        end

        ILAS: begin
          case (wpos)
            0: begin
              vif.lane_data <= JESD_R_W;    // /R/ multiframe start
              vif.lane_k    <= 1'b1;
            end
            1: begin
              if (eff_mf(mf_cnt) == 1) begin
                vif.lane_data <= JESD_Q_W;  // /Q/ config marker (MF#2 only)
                vif.lane_k    <= 1'b1;
              end else begin
                vif.lane_data <= 32'h0;
                vif.lane_k    <= 1'b0;
              end
            end
            2: begin
              if (eff_mf(mf_cnt) == 1) begin
                vif.lane_data <= cfg_word(); // DID config behind /Q/
                vif.lane_k    <= 1'b0;
              end else begin
                vif.lane_data <= 32'h0;
                vif.lane_k    <= 1'b0;
              end
            end
            default: begin
              vif.lane_data <= JESD_A_W;    // /A/ multiframe end
              vif.lane_k    <= 1'b1;
            end
          endcase
          if (wpos == JESD_MF_WORDS-1) begin
            wpos <= 0;
            if (mf_cnt == JESD_ILAS_MF-1) begin
              st   <= USER_DATA;
              ramp <= 32'h0;                 // ramp restarts every link-up
            end else begin
              mf_cnt <= mf_cnt + 1;
            end
          end else begin
            wpos <= wpos + 1;
          end
        end

        USER_DATA: begin
          vif.lane_data <= ramp;
          vif.lane_k    <= 1'b0;
          ramp          <= ramp + 1;
          if (!vif.sync_n) st <= SYNC_RE;    // resync request mid-stream
        end

        SYNC_RE: begin
          vif.lane_data <= JESD_K_W;
          vif.lane_k    <= 1'b1;
          if (vif.sync_n) begin
            st        <= ILAS;
            mf_cnt    <= 0;
            wpos      <= 0;
            ilas_swap <= vif.inj_ilas_err;
          end
        end

        default: st <= RESET;
      endcase
    end
  end
endmodule
`endif
