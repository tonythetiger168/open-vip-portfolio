// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jesd204_env.sv -- JESD204C verification environment
// with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import jesd204_defs_pkg::*;
  import jesd204_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-expected sample words (the ADC
  // ramp is deterministic) against monitor-decoded sample words. The
  // observed ILAS-order-error flag must match the injected-error intent.
  class jesd204_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(jesd204_scoreboard)
    uvm_analysis_imp_exp #(jesd204_transaction, jesd204_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(jesd204_transaction, jesd204_scoreboard) obs_ap;

    jesd204_transaction exp_q[$], obs_q[$];
    int unsigned match_cnt = 0, mismat_cnt = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(jesd204_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(jesd204_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        jesd204_transaction e = exp_q.pop_front();
        jesd204_transaction o = obs_q.pop_front();
        if (e.did == o.did && e.lanes == o.lanes && e.k_char == o.k_char &&
            e.sample.size() == o.sample.size() &&
            (e.sample.size() == 0 || e.sample[0] === o.sample[0]) &&
            o.ilas_err_det == e.ilas_err)
          match_cnt++;
        else begin
          mismat_cnt++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("jesd204 scoreboard: matches=%0d mismatches=%0d leftover_exp=%0d leftover_obs=%0d",
                match_cnt, mismat_cnt, exp_q.size(), obs_q.size()), UVM_LOW)
      if (mismat_cnt) `uvm_error("SB", "end-to-end mismatches detected")
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", "unmatched transactions left in scoreboard queues")
    endfunction
  endclass

  class jesd204_env extends uvm_env;
    `uvm_component_utils(jesd204_env)
    jesd204_agent      agt;
    jesd204_scoreboard sb;
    jesd204_checker    chk;
    jesd204_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = jesd204_agent::type_id::create("agt", this);
      sb  = jesd204_scoreboard::type_id::create("sb", this);
      chk = jesd204_checker::type_id::create("chk", this);
      cov = jesd204_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
