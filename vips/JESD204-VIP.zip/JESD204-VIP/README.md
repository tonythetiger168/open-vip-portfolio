# JESD204 — JESD204C UVM VIP

Open-source UVM verification IP template for **JESD204C** (Data Converter).

## Contents

| Path | Description |
|------|-------------|
| `jesd204/jesd204_if.sv` | device_clk / sysref / sync_n / lane_data / lane_k interface + link FSM enum |
| `jesd204/jesd204_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `jesd204/sva/jesd204_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=5) |
| `jesd204/vip/jesd204/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/jesd204_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional JESD204 ADC transmitter DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Link layer bring-up**: VIP driver (logic-device side) controls sysref / sync_n and tracks CGS (/K/ = K28.5 stream) -> ILAS (exactly 4 multiframes, /R/ /Q/ /A/ markers) -> USER_DATA by watching the lane markers
- **Resync protocol**: reasserting sync_n mid-stream forces the ADC back through SYNC_RE/CGS -> ILAS -> USER_DATA; the tracked state and monitor both follow the /K/ stream
- **Waveform-decoding monitor**: decodes CGS / ILAS / USER_DATA directly from lane_data/lane_k, extracts the DID from the second ILAS multiframe (behind /Q/), detects ILAS multiframe order errors, publishes one transaction per sample word
- **Functional DUT model**: JESD204 ADC transmitter — CGS on sync_n low, 4-multiframe ILAS with DID config data, deterministic 32-bit ramp user data, ILAS-order scramble on inj_ilas_err
- **End-to-end scoreboard**: expected sample words (predictable ADC ramp) vs observed words; observed ILAS-order-error flag must equal the injected-error intent; leftover-queue detection
- **Directed sequence library**: link-startup / extended-CGS / ILAS-relink / user-data-stream / resync / error-inject (ILAS order) / reset + random + regression mix
- **Functional coverage**: DID x sample-corner cross, link FSM state + startup/resync transition sequences, link-restart x ILAS-order-error cross
- **Transaction checker**: DID match and ramp-continuity check on the decoded sample stream
- **SVA L4**: sync_n low enters CGS/SYNC_RE, ILAS carries exactly 4 multiframes (R/A marker counter), K-chars only in CGS/ILAS/SYNC_RE, no K-chars in USER_DATA, all K-char words are known 8B/10B control words
