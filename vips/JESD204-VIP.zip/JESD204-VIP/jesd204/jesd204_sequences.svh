// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// jesd204_sequences.svh -- JESD204 sequence library

`ifndef JESD204_SEQUENCES_SVH
`define JESD204_SEQUENCES_SVH

class jesd204_base_sequence extends uvm_sequence #(jesd204_transaction);
  `uvm_object_utils(jesd204_base_sequence)
  int num_txns = 20;
  function new(string name = "jesd204_base_sequence"); super.new(name); endfunction
  task body();
    jesd204_transaction tr;
    repeat (num_txns) begin
      tr = jesd204_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: clean link startup + short sample stream (no resync)
class jesd204_link_startup_seq extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_link_startup_seq)
  function new(string name = "jesd204_link_startup_seq"); super.new(name); num_txns = 8; endfunction
  task body();
    jesd204_transaction tr;
    repeat (num_txns) begin
      tr = jesd204_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { resync == 0; ilas_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: extended CGS phase (long sync_n hold) on every resync
class jesd204_cgs_seq extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_cgs_seq)
  function new(string name = "jesd204_cgs_seq"); super.new(name); num_txns = 3; endfunction
  task body();
    jesd204_transaction tr;
    repeat (num_txns) begin
      tr = jesd204_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { resync == 1; ilas_err == 0; cgs_cycles == 16; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: repeated legal re-links (ILAS focus, correct MF order)
class jesd204_ilas_seq extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_ilas_seq)
  function new(string name = "jesd204_ilas_seq"); super.new(name); num_txns = 4; endfunction
  task body();
    jesd204_transaction tr;
    repeat (num_txns) begin
      tr = jesd204_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { resync == 1; ilas_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: long uninterrupted user-data streaming
class jesd204_user_data_seq extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_user_data_seq)
  function new(string name = "jesd204_user_data_seq"); super.new(name); num_txns = 64; endfunction
  task body();
    jesd204_transaction tr;
    repeat (num_txns) begin
      tr = jesd204_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { resync == 0; ilas_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: sync_n reasserted mid-stream (resync recovery)
class jesd204_resync_seq extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_resync_seq)
  function new(string name = "jesd204_resync_seq"); super.new(name); num_txns = 5; endfunction
  task body();
    jesd204_transaction tr;
    repeat (num_txns) begin
      tr = jesd204_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { resync == 1; ilas_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: resync with scrambled ILAS multiframe order
class jesd204_error_inject_seq extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_error_inject_seq)
  function new(string name = "jesd204_error_inject_seq"); super.new(name); num_txns = 5; endfunction
  task body();
    jesd204_transaction tr;
    repeat (num_txns) begin
      tr = jesd204_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { resync == 1; ilas_err dist {0 := 1, 1 := 2}; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single sample word right after link startup
class jesd204_reset_seq extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_reset_seq)
  function new(string name = "jesd204_reset_seq"); super.new(name); endfunction
  task body();
    jesd204_transaction tr = jesd204_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { resync == 0; ilas_err == 0; });
    finish_item(tr);
  endtask
endclass

class jesd204_random_sequence extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_random_sequence)
  function new(string name = "jesd204_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class jesd204_regression_sequence extends jesd204_base_sequence;
  `uvm_object_utils(jesd204_regression_sequence)
  function new(string name = "jesd204_regression_sequence"); super.new(name); endfunction
  task body();
    jesd204_link_startup_seq  su  = jesd204_link_startup_seq::type_id::create("su");
    jesd204_cgs_seq           cgs = jesd204_cgs_seq::type_id::create("cgs");
    jesd204_ilas_seq          il  = jesd204_ilas_seq::type_id::create("il");
    jesd204_user_data_seq     ud  = jesd204_user_data_seq::type_id::create("ud");
    jesd204_resync_seq        rs  = jesd204_resync_seq::type_id::create("rs");
    jesd204_error_inject_seq  err = jesd204_error_inject_seq::type_id::create("err");
    su.start(m_sequencer);
    cgs.start(m_sequencer);
    il.start(m_sequencer);
    ud.start(m_sequencer);
    rs.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
