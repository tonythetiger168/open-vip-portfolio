// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// jesd204_transaction.svh -- JESD204 transaction: one received 32-bit
// sample word with its link context (DID, lane count), plus resync and
// ILAS-order error-injection knobs.

`ifndef JESD204_TRANSACTION_SVH
`define JESD204_TRANSACTION_SVH

class jesd204_transaction extends uvm_sequence_item;

  rand bit [7:0]  did;            // device ID (from ILAS config data)
  rand bit [3:0]  lanes;          // active lane count (1 in this model)
  rand bit [31:0] sample[$];      // sample words (one per transaction)
  rand bit        resync;         // error injection: reassert sync_n mid-stream
  rand bit        ilas_err;       // error injection: scramble ILAS MF order
  rand int unsigned cgs_cycles;   // sync_n hold time during resync

  bit        k_char;              // observed word was a K-char (monitor)
  bit        link_restart;        // monitor: first word after (re)sync
  bit        ilas_err_det;        // monitor: ILAS multiframe order error seen

  constraint c_did   { did == jesd204_defs_pkg::JESD_DUT_DID; }
  constraint c_lanes { lanes == 1; }
  constraint c_len   { sample.size() == 1; }
  constraint c_rsync { resync dist {0 := 7, 1 := 3};
                       cgs_cycles inside {[4:16]}; }
  constraint c_ilas  { ilas_err dist {0 := 7, 1 := 3};
                       solve resync before ilas_err;
                       (ilas_err == 1) -> (resync == 1); }

  `uvm_object_utils_begin(jesd204_transaction)
    `uvm_field_int(did, UVM_ALL_ON)
    `uvm_field_int(lanes, UVM_ALL_ON)
    `uvm_field_queue_int(sample, UVM_ALL_ON)
    `uvm_field_int(k_char, UVM_ALL_ON)
    `uvm_field_int(resync, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(ilas_err, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(link_restart, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(ilas_err_det, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "jesd204_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    jesd204_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= comparer.compare_field("did", did, t.did, 8);
    do_compare &= comparer.compare_field("lanes", lanes, t.lanes, 4);
    do_compare &= comparer.compare_field("slen", sample.size(), t.sample.size(), 32);
  endfunction

  function string convert2string();
    return $sformatf("JESD204 did=0x%02h lanes=%0d sample=0x%08h k=%0b resync=%0b ilas_err=%0b",
                     did, lanes, (sample.size() ? sample[0] : 32'h0),
                     k_char, resync, ilas_err);
  endfunction
endclass
`endif
