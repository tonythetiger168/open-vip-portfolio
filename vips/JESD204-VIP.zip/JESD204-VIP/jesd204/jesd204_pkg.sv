// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jesd204_pkg.sv -- JESD204C UVM VIP package

package jesd204_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import jesd204_defs_pkg::*;
  export jesd204_defs_pkg::*;

  `include "jesd204_transaction.svh"
  `include "jesd204_config.svh"
  `include "jesd204_sequencer.svh"
  `include "jesd204_driver.svh"
  `include "jesd204_monitor.svh"
  `include "jesd204_agent.svh"
  `include "jesd204_sequences.svh"
  `include "jesd204_checker.svh"
  `include "jesd204_coverage.svh"
endpackage
