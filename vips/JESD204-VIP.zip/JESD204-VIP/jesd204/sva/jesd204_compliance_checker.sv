// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jesd204_compliance_checker.sv -- JESD204 SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = JESD204 link-layer rules

`ifndef JESD204_COMPLIANCE_CHECKER_SV
`define JESD204_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import jesd204_defs_pkg::*;

module jesd204_compliance_checker
(
  input logic          device_clk,
  input logic          rst_n,
  input logic          sysref,
  input logic          sync_n,
  input logic [31:0]   lane_data,
  input logic          lane_k,
  input jesd204_state_e state
);

  // ---------------- L1: signal sanity (4) ----------------
  a_jesd204_l1_clk   : assert property (@(posedge device_clk) disable iff (!rst_n) !$isunknown(device_clk))
    else `uvm_error("SVA_L1", "jesd204: clock unknown")
  a_jesd204_l1_rst   : assert property (@(posedge device_clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "jesd204: reset unknown")
  a_jesd204_l1_state : assert property (@(posedge device_clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "jesd204: state unknown")
  a_jesd204_l1_valid : assert property (@(posedge device_clk) disable iff (!rst_n)
    state inside {RESET, CGS, ILAS, USER_DATA, SYNC_RE})
    else `uvm_error("SVA_L1", "jesd204: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from RESET
  a_jesd204_trans_reset : assert property (@(posedge device_clk) disable iff (!rst_n)
    state == RESET |=> state inside {RESET, CGS})
    else `uvm_error("SVA_L2", "jesd204: illegal transition from RESET")

  // L2-2: legal FSM transition from CGS
  a_jesd204_trans_cgs : assert property (@(posedge device_clk) disable iff (!rst_n)
    state == CGS |=> state inside {CGS, ILAS})
    else `uvm_error("SVA_L2", "jesd204: illegal transition from CGS")

  // L2-3: legal FSM transition from ILAS
  a_jesd204_trans_ilas : assert property (@(posedge device_clk) disable iff (!rst_n)
    state == ILAS |=> state inside {ILAS, USER_DATA})
    else `uvm_error("SVA_L2", "jesd204: illegal transition from ILAS")

  // L2-4: legal FSM transition from USER_DATA
  a_jesd204_trans_user : assert property (@(posedge device_clk) disable iff (!rst_n)
    state == USER_DATA |=> state inside {USER_DATA, SYNC_RE})
    else `uvm_error("SVA_L2", "jesd204: illegal transition from USER_DATA")

  // L2-5: legal FSM transition from SYNC_RE
  a_jesd204_trans_sync_re : assert property (@(posedge device_clk) disable iff (!rst_n)
    state == SYNC_RE |=> state inside {SYNC_RE, ILAS})
    else `uvm_error("SVA_L2", "jesd204: illegal transition from SYNC_RE")

  // ---------------- L3: protocol rules (4) ----------------
  a_jesd204_l3_reset_idle : assert property (@(posedge device_clk)
    $fell(rst_n) |-> ##[1:4] (state == RESET))
    else `uvm_error("SVA_L3", "jesd204: state not RESET during reset")
  a_jesd204_l3_sync_k     : assert property (@(posedge device_clk) disable iff (!rst_n)
    $fell(sync_n) |-> ##[1:6] (lane_k && lane_data == JESD_K_W))
    else `uvm_error("SVA_L3", "jesd204: sync_n request not answered with /K/ stream")
  a_jesd204_l3_full_cycle : cover property (@(posedge device_clk) disable iff (!rst_n)
    state == RESET ##[1:8] state == CGS ##[1:32] state == ILAS ##[1:32] state == USER_DATA);
  a_jesd204_l3_resync     : cover property (@(posedge device_clk) disable iff (!rst_n)
    state == USER_DATA ##1 state == SYNC_RE);

  // ---------------- L4: JESD204 link-layer rules (5) ----------------
  // L4-1: sync_n low forces the (re)sync states
  a_jesd204_l4_sync_cgs : assert property (@(posedge device_clk) disable iff (!rst_n)
    $fell(sync_n) |-> ##[0:3] (state inside {CGS, SYNC_RE}))
    else `uvm_error("SVA_L4", "jesd204: sync_n low did not enter CGS/SYNC_RE")

  // L4-2: ILAS carries exactly 4 multiframes (4 x /R/ start and 4 x /A/ end).
  // Markers are counted from the pre-ILAS state (CGS/SYNC_RE) because the
  // first /R/ appears one sample before the tracked state shows ILAS; the
  // check fires on the ILAS -> USER_DATA transition.
  int unsigned   r_cnt = 0, a_cnt = 0;
  jesd204_state_e prev_state = RESET;
  always @(posedge device_clk) begin
    if (!rst_n) begin
      r_cnt <= 0; a_cnt <= 0; prev_state <= RESET;
    end else begin
      if (lane_k && lane_data == JESD_R_W && state inside {CGS, ILAS, SYNC_RE})
        r_cnt <= r_cnt + 1;
      if (lane_k && lane_data == JESD_A_W && state inside {CGS, ILAS, SYNC_RE})
        a_cnt <= a_cnt + 1;
      if (state == USER_DATA && prev_state == ILAS) begin
        a_jesd204_l4_ilas_4mf : assert (r_cnt == JESD_ILAS_MF && a_cnt == JESD_ILAS_MF)
          else `uvm_error("SVA_L4", "jesd204: ILAS did not contain exactly 4 multiframes")
        r_cnt <= 0;
        a_cnt <= 0;
      end
      prev_state <= state;
    end
  end

  // L4-3: K-chars only appear during CGS / ILAS / SYNC_RE
  a_jesd204_l4_kchar_region : assert property (@(posedge device_clk) disable iff (!rst_n)
    lane_k |-> (state inside {CGS, ILAS, SYNC_RE}))
    else `uvm_error("SVA_L4", "jesd204: K-char outside CGS/ILAS/SYNC_RE")

  // L4-4: no K-chars during user data
  a_jesd204_l4_no_k_user : assert property (@(posedge device_clk) disable iff (!rst_n)
    state == USER_DATA |-> !lane_k)
    else `uvm_error("SVA_L4", "jesd204: K-char during USER_DATA")

  // L4-5: every K-char word is a known 8B/10B control word
  a_jesd204_l4_kchar_known : assert property (@(posedge device_clk) disable iff (!rst_n)
    lane_k |-> (lane_data inside {JESD_K_W, JESD_R_W, JESD_Q_W, JESD_A_W}))
    else `uvm_error("SVA_L4", "jesd204: unknown K-char word on the lane")

endmodule
`endif
