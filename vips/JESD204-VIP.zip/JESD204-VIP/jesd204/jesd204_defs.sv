// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jesd204_defs.sv -- JESD204C shared type definitions

package jesd204_defs_pkg;
  // Link layer state machine (transmitter side mirrored by the VIP):
  // RESET -> CGS -> ILAS -> USER_DATA; sync_n reassertion -> SYNC_RE -> ILAS
  typedef enum bit [2:0] {
    RESET,
    CGS,
    ILAS,
    USER_DATA,
    SYNC_RE
  } jesd204_state_e;

  // 8B/10B control words (4 octets per 32-bit lane word)
  localparam bit [31:0] JESD_K_W = {4{8'hBC}};  // /K/  = K28.5 (CGS)
  localparam bit [31:0] JESD_R_W = {4{8'h1C}};  // /R/  = K28.0 (multiframe start)
  localparam bit [31:0] JESD_Q_W = {4{8'h9C}};  // /Q/  = K28.4 (config marker)
  localparam bit [31:0] JESD_A_W = {4{8'h7C}};  // /A/  = K28.3 (multiframe end, lane align)

  localparam int unsigned JESD_MF_WORDS = 4;    // words per multiframe (sim scale)
  localparam int unsigned JESD_ILAS_MF  = 4;    // ILAS = exactly 4 multiframes
  localparam bit [7:0]    JESD_DUT_DID  = 8'hA5; // DUT (ADC) device ID
endpackage
