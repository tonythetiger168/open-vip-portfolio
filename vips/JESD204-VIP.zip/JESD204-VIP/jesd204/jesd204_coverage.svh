// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// jesd204_coverage.svh -- JESD204 functional coverage.
// cg_protocol samples decoded sample words (DID x sample-corner cross),
// cg_fsm samples the link FSM from the interface on state changes,
// cg_error covers resync and ILAS-order error scenarios.

`ifndef JESD204_COVERAGE_SVH
`define JESD204_COVERAGE_SVH

class jesd204_coverage extends uvm_subscriber #(jesd204_transaction);
  `uvm_component_utils(jesd204_coverage)

  virtual jesd204_if vif;
  jesd204_transaction tr;

  covergroup cg_protocol;
    cp_did    : coverpoint tr.did {
      bins dut = {jesd204_defs_pkg::JESD_DUT_DID};
    }
    cp_lanes  : coverpoint tr.lanes { bins one = {1}; }
    cp_sample : coverpoint tr.sample[0] iff (tr.sample.size() > 0) {
      bins zero = {32'h0000_0000};
      bins low  = {[32'h0000_0001 : 32'h0000_00FF]};
      bins mid  = {[32'h0000_0100 : 32'h0000_FFFF]};
      bins high = {[32'h0001_0000 : 32'hFFFF_FFFF]};
    }
    cp_k      : coverpoint tr.k_char { bins data = {0}; }
    cx_did_sample : cross cp_did, cp_sample;
  endgroup

  covergroup cg_fsm with function sample(jesd204_state_e s);
    cp_state : coverpoint s {
      bins states[] = {RESET, CGS, ILAS, USER_DATA, SYNC_RE};
    }
    cp_trans : coverpoint s {
      bins startup = (RESET => CGS => ILAS => USER_DATA);
      bins resync  = (USER_DATA => SYNC_RE => ILAS => USER_DATA);
    }
  endgroup

  covergroup cg_error;
    cp_resync   : coverpoint tr.link_restart { bins cont = {0}; bins restart = {1}; }
    cp_ilas_err : coverpoint tr.ilas_err_det { bins ok = {0}; bins err = {1}; }
    cx_err      : cross cp_resync, cp_ilas_err;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual jesd204_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "jesd204 virtual interface not set")
  endfunction

  function void write(jesd204_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction

  task run_phase(uvm_phase phase);
    jesd204_state_e prev;
    prev = jesd204_state_e'('x);
    forever begin
      @(posedge vif.device_clk);
      if (vif.rst_n === 1'b1) begin
        // sample FSM on state change so chained transition bins can hit
        if (vif.state !== prev) begin
          cg_fsm.sample(vif.state);
          prev = vif.state;
        end
      end
    end
  endtask
endclass
`endif
