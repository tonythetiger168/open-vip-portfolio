// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// jesd204_driver.svh -- JESD204 logic-device (receiver) driver.
// Controls sysref / sync_n and tracks the link state: CGS while sync_n is
// low, ILAS while the /R/-/A/ multiframe stream is observed, USER_DATA
// afterwards. Reasserting sync_n mid-stream forces the ADC (DUT) back
// through CGS/ILAS (resync error injection); inj_ilas_err asks the DUT to
// scramble the ILAS multiframe order once.
// Outputs are driven with blocking assignments on the negedge (the lane is
// sampled on the posedge through drv_cb) so the DUT never races the
// driver and no stray sample word is left in flight at a resync.
// The ADC transmits a deterministic ramp, so expected sample words are
// predictable; they are broadcast on drv_ap for the scoreboard.

`ifndef JESD204_DRIVER_SVH
`define JESD204_DRIVER_SVH

class jesd204_driver extends uvm_driver #(jesd204_transaction);
  `uvm_component_utils(jesd204_driver)
  virtual jesd204_if vif;
  jesd204_config cfg;
  uvm_analysis_port #(jesd204_transaction) drv_ap;  // expected items for scoreboard

  protected bit [31:0] ramp_idx;   // expected ramp value of the next sample word

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual jesd204_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "jesd204 virtual interface not set")
  endfunction

  // Release sync_n (negedge) and walk the tracked state through ILAS into
  // USER_DATA by observing the /R/ and /A/ markers on the lane (posedge).
  task release_and_link();
    int unsigned a_seen;
    bit ilas_marked;
    a_seen = 0; ilas_marked = 0;
    @(negedge vif.device_clk);
    vif.sync_n = 1'b1;
    forever begin
      @(vif.drv_cb);
      if (vif.drv_cb.lane_k && vif.drv_cb.lane_data == jesd204_defs_pkg::JESD_R_W &&
          !ilas_marked) begin
        ilas_marked = 1;
        // First /R/: ILAS starts. The DUT already latched inj_ilas_err at
        // the CGS->ILAS jump, so the injection pulse can end here. State
        // updates are blocking writes after the posedge sample -- all
        // readers sample the lane/state at the preponed region, so this
        // is race-free.
        vif.state        = jesd204_defs_pkg::ILAS;
        vif.inj_ilas_err = 1'b0;
      end
      if (vif.drv_cb.lane_k && vif.drv_cb.lane_data == jesd204_defs_pkg::JESD_A_W) begin
        a_seen++;
        if (a_seen == jesd204_defs_pkg::JESD_ILAS_MF) begin
          vif.state = jesd204_defs_pkg::USER_DATA;  // 4th /A/: ILAS done
          break;
        end
      end
    end
    ramp_idx = 0;                        // ADC ramp restarts after every link-up
  endtask

  // Wait for the ADC to present each expected ramp word and record it.
  task expect_words(jesd204_transaction tr);
    bit [31:0] exp;
    int unsigned guard;
    tr.did    = jesd204_defs_pkg::JESD_DUT_DID;
    tr.lanes  = 1;
    tr.k_char = 1'b0;
    foreach (tr.sample[j]) begin
      exp   = ramp_idx;
      guard = 0;
      @(vif.drv_cb);
      while (!(vif.drv_cb.lane_k === 1'b0 && vif.drv_cb.lane_data === exp)) begin
        @(vif.drv_cb);
        guard++;
        if (guard > 2000)
          `uvm_fatal("DRV", $sformatf("timeout waiting for sample 0x%08h", exp))
      end
      tr.sample[j] = exp;
      ramp_idx++;
    end
  endtask

  task run_phase(uvm_phase phase);
    jesd204_transaction tr;
    // Deterministic drives during reset so SVA never samples X.
    vif.sysref       = 1'b0;
    vif.sync_n       = 1'b0;
    vif.inj_ilas_err = 1'b0;
    vif.state        = jesd204_defs_pkg::RESET;
    wait (vif.rst_n === 1'b1);
    // Link start: CGS (sync_n low) + a sysref pulse
    @(negedge vif.device_clk);
    vif.state  = jesd204_defs_pkg::CGS;
    vif.sysref = 1'b1;
    repeat (2) @(negedge vif.device_clk);
    vif.sysref = 1'b0;
    repeat (8) @(negedge vif.device_clk);   // CGS phase: ADC streams /K/
    release_and_link();
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      if (tr.resync) begin
        // Reassert sync_n mid-stream (negedge): the single ramp word still
        // on the lane is dropped by the monitor before the /K/ stream
        // restarts, keeping expected and observed streams aligned.
        @(negedge vif.device_clk);
        vif.state        = jesd204_defs_pkg::SYNC_RE;
        vif.sync_n       = 1'b0;
        vif.inj_ilas_err = tr.ilas_err;
        repeat (tr.cgs_cycles) @(negedge vif.device_clk);
        release_and_link();
      end
      expect_words(tr);
      drv_ap.write(tr);                // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
