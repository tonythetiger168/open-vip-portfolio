// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jesd204_if.sv -- JESD204C interface
// device_clk / sysref / sync_n are driven by the VIP (logic-device side);
// lane_data/lane_k come from the DUT (ADC transmitter). inj_ilas_err asks
// the DUT to scramble the ILAS multiframe order once (error injection).

interface jesd204_if (input logic device_clk);
  import jesd204_defs_pkg::jesd204_state_e;

  logic        rst_n;
  logic        sysref;
  logic        sync_n;        // low = (re)sync request
  logic [31:0] lane_data;
  logic        lane_k;
  logic        inj_ilas_err;

  jesd204_state_e state;      // link state as tracked by the VIP driver

  modport DUT (input  device_clk, rst_n, sysref, sync_n, inj_ilas_err,
               output lane_data, lane_k);
  modport TB  (input  device_clk, lane_data, lane_k,
               output rst_n, sysref, sync_n, inj_ilas_err, state);
  modport MON (input  device_clk, rst_n, sysref, sync_n, lane_data, lane_k,
                      inj_ilas_err, state);

  clocking drv_cb @(posedge device_clk);
    output sysref, sync_n, inj_ilas_err, state;
    input  rst_n, lane_data, lane_k;
  endclocking

  clocking mon_cb @(posedge device_clk);
    input rst_n, sysref, sync_n, lane_data, lane_k, inj_ilas_err, state;
  endclocking
endinterface
