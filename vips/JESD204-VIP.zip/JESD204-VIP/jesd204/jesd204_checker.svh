// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// jesd204_checker.svh -- JESD204 transaction checker: verifies the decoded
// sample stream forms the expected ramp (restarting on link restart) and
// that the DID matches the ADC's device ID.

`ifndef JESD204_CHECKER_SVH
`define JESD204_CHECKER_SVH

class jesd204_checker extends uvm_component;
  `uvm_component_utils(jesd204_checker)
  uvm_analysis_imp #(jesd204_transaction, jesd204_checker) chk_ap;
  int unsigned checked = 0, errors = 0, restarts = 0;
  bit        have_prev = 0;
  bit [31:0] prev_sample = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    chk_ap = new("chk_ap", this);
  endfunction

  function void write(jesd204_transaction tr);
    checked++;
    if (tr.did != jesd204_defs_pkg::JESD_DUT_DID) begin
      errors++;
      `uvm_error("CHK", $sformatf("DID mismatch: got 0x%02h expected 0x%02h",
                 tr.did, jesd204_defs_pkg::JESD_DUT_DID))
    end
    if (tr.sample.size() != 1) begin
      errors++;
      `uvm_error("CHK", $sformatf("sample word count %0d != 1", tr.sample.size()))
      return;
    end
    if (tr.link_restart) begin
      restarts++;
      have_prev = 0;
      return;
    end
    if (have_prev && (tr.sample[0] != prev_sample + 1)) begin
      errors++;
      `uvm_error("CHK", $sformatf("ramp discontinuity 0x%08h -> 0x%08h",
                 prev_sample, tr.sample[0]))
    end
    prev_sample = tr.sample[0];
    have_prev   = 1;
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHECKER", $sformatf("jesd204: checked=%0d errors=%0d restarts=%0d",
              checked, errors, restarts), UVM_LOW)
  endfunction
endclass
`endif
