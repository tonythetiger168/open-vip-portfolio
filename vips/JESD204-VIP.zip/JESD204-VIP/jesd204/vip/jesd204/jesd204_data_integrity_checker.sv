// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jesd204_data_integrity_checker.sv -- JESD204C data integrity (CRC/E2E) checker

`ifndef JESD204_DATA_INTEGRITY_CHECKER_SV
`define JESD204_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import jesd204_defs_pkg::jesd204_state_e;

module jesd204_data_integrity_checker
(
  input logic device_clk,
  input logic rst_n,
  input jesd204_state_e state
);
  a_jesd204_data_integrity_state_known : assert property (@(posedge device_clk)
    disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("DATA_INTEGRITY", "jesd204 data_integrity: state unknown")
endmodule
`endif
