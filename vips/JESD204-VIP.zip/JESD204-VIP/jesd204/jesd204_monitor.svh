// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// jesd204_monitor.svh -- JESD204 monitor: decodes the lane waveform
// directly (CGS /K/ chars -> ILAS multiframes -> user data). Extracts the
// device ID from the second ILAS multiframe (after /Q/), verifies the
// ILAS multiframe order, and publishes one transaction per received
// 32-bit sample word during the user-data phase.

`ifndef JESD204_MONITOR_SVH
`define JESD204_MONITOR_SVH

class jesd204_monitor extends uvm_monitor;
  `uvm_component_utils(jesd204_monitor)

  typedef enum bit [1:0] {M_CGS, M_ILAS, M_DATA} mon_state_e;

  virtual jesd204_if vif;
  uvm_analysis_port #(jesd204_transaction) ap;
  int unsigned txn_count = 0;

  protected mon_state_e  mst;
  protected int unsigned ilas_cnt;    // words seen in the current ILAS
  protected int unsigned r_cnt;       // /R/ markers seen in the current ILAS
  protected bit          expect_did;  // next non-K word carries the DID
  protected bit [7:0]    did;
  protected bit          bad_ilas;    // ILAS multiframe order error
  protected bit          restart;     // link restarted since last data txn

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual jesd204_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "jesd204 virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    jesd204_transaction tr;
    mst = M_CGS; ilas_cnt = 0; r_cnt = 0; expect_did = 0;
    did = 0; bad_ilas = 0; restart = 0;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        mst = M_CGS; ilas_cnt = 0; r_cnt = 0; expect_did = 0;
        did = 0; bad_ilas = 0; restart = 0;
        continue;
      end
      case (mst)
        // CGS: /K/ stream; a /R/ marker opens the ILAS
        M_CGS: begin
          if (vif.mon_cb.lane_k && vif.mon_cb.lane_data == jesd204_defs_pkg::JESD_R_W) begin
            mst       = M_ILAS;
            ilas_cnt  = 1;
            r_cnt     = 1;
            bad_ilas  = 0;
          end
        end
        // ILAS: exactly JESD_ILAS_MF multiframes of JESD_MF_WORDS words
        M_ILAS: begin
          ilas_cnt++;
          if (vif.mon_cb.lane_k && vif.mon_cb.lane_data == jesd204_defs_pkg::JESD_R_W)
            r_cnt++;
          if (vif.mon_cb.lane_k && vif.mon_cb.lane_data == jesd204_defs_pkg::JESD_Q_W)
            expect_did = 1;
          else if (!vif.mon_cb.lane_k && expect_did) begin
            did        = vif.mon_cb.lane_data[31:24];
            expect_did = 0;
            // DID config word belongs to the second multiframe
            if (r_cnt != 2) begin
              bad_ilas = 1;
              `uvm_warning("MON", $sformatf("ILAS order error: DID in multiframe %0d", r_cnt))
            end
          end
          if (ilas_cnt == jesd204_defs_pkg::JESD_ILAS_MF * jesd204_defs_pkg::JESD_MF_WORDS) begin
            mst         = M_DATA;
            restart     = 1;
          end
        end
        // USER_DATA: one transaction per sample word.
        // sync_n reassertion takes effect before the /K/ stream reaches the
        // lane, so it is checked first: the stray word(s) still on the lane
        // while the transmitter reacts are dropped, keeping the observed
        // stream aligned with the driver's expected stream.
        M_DATA: begin
          if (!vif.mon_cb.sync_n) begin
            mst = M_CGS;                    // resync requested
          end else if (vif.mon_cb.lane_k && vif.mon_cb.lane_data == jesd204_defs_pkg::JESD_K_W) begin
            mst = M_CGS;                    // resync: /K/ stream restarts
          end else if (vif.mon_cb.lane_k &&
                       vif.mon_cb.lane_data == jesd204_defs_pkg::JESD_R_W) begin
            mst      = M_ILAS;              // straight back to ILAS
            ilas_cnt = 1;
            r_cnt    = 1;
            bad_ilas = 0;
          end else if (!vif.mon_cb.lane_k) begin
            tr = jesd204_transaction::type_id::create("tr");
            tr.did          = did;
            tr.lanes        = 1;
            tr.sample.push_back(vif.mon_cb.lane_data);
            tr.k_char       = 1'b0;
            tr.link_restart = restart;
            tr.ilas_err_det = bad_ilas;
            restart         = 0;
            bad_ilas        = 0;
            txn_count++;
            `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
            ap.write(tr);
          end
        end
        default: mst = M_CGS;
      endcase
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("jesd204 monitor observed %0d sample words", txn_count), UVM_LOW)
  endfunction
endclass
`endif
