# AXI4_Lite Open IP

AXI4-Lite protocol -- real AXI4-Lite slave IP: 5 channel handshakes,
single-beat transfers only (no awlen/wlast), byte strobes, true
valid/ready backpressure, SLVERR on out-of-range / misaligned access.
256x32 register file as the slave memory target.
Open IP design implementation v2.5.1 -- Apache-2.0

## Package contents

- `rtl/AXI4_Lite_top.sv` -- synthesizable RTL (top: `AXI4_Lite_top`)
- `tb/AXI4_Lite_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/AXI4_Lite_yosys.ys` -- Yosys synthesis script
- `syn/AXI4_Lite_dc.tcl` -- Synopsys Design Compiler script
- `syn/AXI4_Lite.sdc` -- timing constraints
- `sim/filelist_AXI4_Lite.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.5.1: constrained-random testbenches (portable `ifdef VERILATOR`); RTL fixes: echo-copy/MEMCH OOB bounds, RFFE/HSI/I3C/SPMI/QSPI/1-Wire serial bugs, USB2.0 run_cnt, USB3 give-up, CXL-family STP/LEN=8, WTB tok_irq, NVMe TX replay bound. Verified: iverilog sim PASS.
