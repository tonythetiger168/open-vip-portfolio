// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm3e_agent.sv -- HBM3E UVM agent (sequencer + driver + monitor)

`ifndef HBM3E_AGENT_SV
`define HBM3E_AGENT_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
typedef class hbm3e_driver;
typedef class hbm3e_monitor;

class hbm3e_agent extends uvm_agent;
  `uvm_component_utils(hbm3e_agent)
  uvm_sequencer #(hbm3e_transaction) sqr;
  hbm3e_driver  drv;
  hbm3e_monitor mon;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    sqr = uvm_sequencer #(hbm3e_transaction)::type_id::create("sqr", this);
    drv = hbm3e_driver::type_id::create("drv", this);
    mon = hbm3e_monitor::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
