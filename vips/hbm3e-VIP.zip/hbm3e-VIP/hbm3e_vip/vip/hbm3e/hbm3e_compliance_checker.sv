// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm3e_compliance_checker.sv -- HBM3E SVA compliance checker
// L1 = signal sanity, L2 = timing & data integrity, L3 = error handling,
// L4 = HBM3E protocol-specific rules (timing parameters, bank-state
// legality, refresh servicing). Instantiated in tb_top.
// HBM3E extended stacked DRAM: higher pin rate than HBM3, 16 pseudo-channels per stack.

`ifndef HBM3E_COMPLIANCE_CHECKER_SV
`define HBM3E_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module hbm3e_compliance_checker (hbm3e_if vif);

  // ---------------- L1: signal sanity (4) ----------------
  property p_hbm3e_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_hbm3e_cmd_valid: assert property(p_hbm3e_cmd_valid) else `uvm_warning("HBM3E", "Command valid failed");
  cover_p_hbm3e_cmd_valid: cover property(p_hbm3e_cmd_valid);
  property p_hbm3e_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_hbm3e_addr_valid: assert property(p_hbm3e_addr_valid) else `uvm_warning("HBM3E", "Address valid failed");
  cover_p_hbm3e_addr_valid: cover property(p_hbm3e_addr_valid);
  property p_hbm3e_pseudo_ch; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pseudo_ch <= 1'b1; endproperty
  assert_p_hbm3e_pseudo_ch: assert property(p_hbm3e_pseudo_ch) else `uvm_warning("HBM3E", "Pseudo channel 0-1 failed");
  cover_p_hbm3e_pseudo_ch: cover property(p_hbm3e_pseudo_ch);
  property p_hbm3e_stack_id; @(posedge vif.ck) disable iff (!vif.rst_n) vif.stack_id <= 3'd7; endproperty
  assert_p_hbm3e_stack_id: assert property(p_hbm3e_stack_id) else `uvm_warning("HBM3E", "Stack ID 0-7 failed");
  cover_p_hbm3e_stack_id: cover property(p_hbm3e_stack_id);

  // ---------------- L2: timing & data integrity (10) ----------------
  property p_hbm3e_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cs_n) |-> ##[10:14] vif.ca[4] == 0; endproperty
  assert_p_hbm3e_tRCD: assert property(p_hbm3e_tRCD) else `uvm_warning("HBM3E", "tRCD 10-14 cycles failed");
  cover_p_hbm3e_tRCD: cover property(p_hbm3e_tRCD);
  property p_hbm3e_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.cs_n) |-> ##[10:14] $fell(vif.cs_n); endproperty
  assert_p_hbm3e_tRP: assert property(p_hbm3e_tRP) else `uvm_warning("HBM3E", "tRP 10-14 cycles failed");
  cover_p_hbm3e_tRP: cover property(p_hbm3e_tRP);
  property p_hbm3e_bl; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {3'b001,3'b010,3'b011,3'b100}; endproperty
  assert_p_hbm3e_bl: assert property(p_hbm3e_bl) else `uvm_warning("HBM3E", "Burst length 2/4/8/16 failed");
  cover_p_hbm3e_bl: cover property(p_hbm3e_bl);
  property p_hbm3e_data_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dqs_t == 1 |-> !$isunknown(vif.dq); endproperty
  assert_p_hbm3e_data_valid: assert property(p_hbm3e_data_valid) else `uvm_warning("HBM3E", "Data valid failed");
  cover_p_hbm3e_data_valid: cover property(p_hbm3e_data_valid);
  property p_hbm3e_dbis; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dbis == 1 |-> vif.dqs_t == 1; endproperty
  assert_p_hbm3e_dbis: assert property(p_hbm3e_dbis) else `uvm_warning("HBM3E", "DBI valid failed");
  cover_p_hbm3e_dbis: cover property(p_hbm3e_dbis);
  property p_hbm3e_temp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp <= 8'd127; endproperty
  assert_p_hbm3e_temp: assert property(p_hbm3e_temp) else `uvm_warning("HBM3E", "Temperature failed");
  cover_p_hbm3e_temp: cover property(p_hbm3e_temp);
  property p_hbm3e_no_x; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_hbm3e_no_x: assert property(p_hbm3e_no_x) else `uvm_warning("HBM3E", "No X when active failed");
  cover_p_hbm3e_no_x: cover property(p_hbm3e_no_x);
  property p_hbm3e_reset; @(posedge vif.ck) disable iff (!vif.rst_n) vif.rst_n == 0 |-> ##[100:200] vif.rst_n == 1; endproperty
  assert_p_hbm3e_reset: assert property(p_hbm3e_reset) else `uvm_warning("HBM3E", "Reset stable failed");
  cover_p_hbm3e_reset: cover property(p_hbm3e_reset);
  property p_hbm3e_speed; @(posedge vif.ck) disable iff (!vif.rst_n) vif.speed_grade >= 4'd12; endproperty
  assert_p_hbm3e_speed: assert property(p_hbm3e_speed) else `uvm_warning("HBM3E", "Speed grade 9.6Gbps+ failed");
  cover_p_hbm3e_speed: cover property(p_hbm3e_speed);
  property p_hbm3e_wck; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_hbm3e_wck: assert property(p_hbm3e_wck) else `uvm_warning("HBM3E", "WCK ratio failed");
  cover_p_hbm3e_wck: cover property(p_hbm3e_wck);

  // ---------------- L3: error handling (6) ----------------
  property p_hbm3e_pm; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_hbm3e_pm: assert property(p_hbm3e_pm) else `uvm_warning("HBM3E", "Power management failed");
  cover_p_hbm3e_pm: cover property(p_hbm3e_pm);
  property p_hbm3e_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.refresh |-> ##[1:3900] vif.cs_n == 0; endproperty
  assert_p_hbm3e_refresh: assert property(p_hbm3e_refresh) else `uvm_warning("HBM3E", "Refresh interval failed");
  cover_p_hbm3e_refresh: cover property(p_hbm3e_refresh);
  property p_hbm3e_overtemp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp > 8'd85 |-> vif.cs_n == 1; endproperty
  assert_p_hbm3e_overtemp: assert property(p_hbm3e_overtemp) else `uvm_warning("HBM3E", "Overtemp failed");
  cover_p_hbm3e_overtemp: cover property(p_hbm3e_overtemp);
  property p_hbm3e_dfe; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dfe_tap <= 4'd15; endproperty
  assert_p_hbm3e_dfe: assert property(p_hbm3e_dfe) else `uvm_warning("HBM3E", "DFE tap failed");
  cover_p_hbm3e_dfe: cover property(p_hbm3e_dfe);
  property p_hbm3e_ecc; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ecc_en |-> vif.data_width >= 5'b01000; endproperty
  assert_p_hbm3e_ecc: assert property(p_hbm3e_ecc) else `uvm_warning("HBM3E", "On-die ECC failed");
  cover_p_hbm3e_ecc: cover property(p_hbm3e_ecc);
  property p_hbm3e_bw; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bandwidth <= 32'hFFFFFFFF; endproperty
  assert_p_hbm3e_bw: assert property(p_hbm3e_bw) else `uvm_warning("HBM3E", "Bandwidth failed");
  cover_p_hbm3e_bw: cover property(p_hbm3e_bw);

  // ---------------- L4: HBM3E protocol-specific rules (10) ----------------
  localparam int L4_TRCD  = 12;
  localparam int L4_TRP   = 12;
  localparam int L4_TRAS  = 16;
  localparam int L4_TRFC  = 48;
  localparam int L4_TREFI = 3900;

  // Command decode (mirrors the driver/monitor truth table)
  wire l4_act = (!vif.cs_n) && (!vif.act_n);
  wire l4_rd  = (!vif.cs_n) && vif.act_n && vif.ras_n && (!vif.cas_n) && vif.we_n;
  wire l4_wr  = (!vif.cs_n) && vif.act_n && vif.ras_n && (!vif.cas_n) && (!vif.we_n);
  wire l4_col = l4_rd || l4_wr;
  wire l4_pre = (!vif.cs_n) && vif.act_n && (!vif.ras_n) && vif.cas_n && (!vif.we_n);
  wire l4_ref = (!vif.cs_n) && vif.act_n && (!vif.ras_n) && (!vif.cas_n) && vif.we_n;
  wire [4:0] l4_bidx = {vif.bg, vif.ba};

  // Bank open/close state used by the legality rules below
  bit [31:0] l4_open;
  always @(posedge vif.ck or negedge vif.rst_n) begin
    if (!vif.rst_n) l4_open <= '0;
    else begin
      if (l4_act) l4_open[l4_bidx] <= 1'b1;
      if (l4_pre) l4_open[l4_bidx] <= 1'b0;
      if (l4_ref) l4_open <= '0;
    end
  end

  // L4-1: ACT may only target a closed (precharged) bank
  a_hbm3e_l4_act_closed : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> !l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "hbm3e: ACT issued to an already-active bank")
  // L4-2: RD/WR may only target an activated bank
  a_hbm3e_l4_col_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_col |-> l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "hbm3e: RD/WR to a non-activated bank")
  // L4-3: PRE may only target an activated bank
  a_hbm3e_l4_pre_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_pre |-> l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "hbm3e: PRE to a non-activated bank")
  // L4-4: tRCD -- no column command within tRCD cycles after ACT
  a_hbm3e_l4_trcd : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> ##1 (!l4_col)[*(L4_TRCD-1)])
    else `uvm_error("SVA_L4", "hbm3e: tRCD violation (column command too soon after ACT)")
  // L4-5: tRP -- no ACT within tRP cycles after PRE
  a_hbm3e_l4_trp : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_pre |-> ##1 (!l4_act)[*(L4_TRP-1)])
    else `uvm_error("SVA_L4", "hbm3e: tRP violation (ACT too soon after PRE)")
  // L4-6: tRAS -- no PRE within tRAS cycles after ACT
  a_hbm3e_l4_tras : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> ##1 (!l4_pre)[*(L4_TRAS-1)])
    else `uvm_error("SVA_L4", "hbm3e: tRAS violation (PRE too soon after ACT)")
  // L4-7: refresh pulse must complete within tRFC (+2) cycles
  a_hbm3e_l4_ref_pulse : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    $rose(vif.refresh) |-> ##[1:(L4_TRFC+2)] $fell(vif.refresh))
    else `uvm_error("SVA_L4", "hbm3e: refresh pulse wider than tRFC")
  // L4-8: commands require CKE high
  a_hbm3e_l4_cke : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    (!vif.cs_n && !vif.act_n) |-> vif.cke)
    else `uvm_error("SVA_L4", "hbm3e: command issued while CKE low")

  // L4-9 (HBM): pseudo-channel select must be stable during a command cycle
  a_hbm3e_l4_pseudo_ch : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    (!vif.cs_n) |-> $stable(vif.pseudo_ch))
    else `uvm_error("SVA_L4", "hbm3e: pseudo-channel switched mid-command")
  // L4-10 (HBM): stack select must be known on any activate
  a_hbm3e_l4_stack : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> !$isunknown(vif.stack_id))
    else `uvm_error("SVA_L4", "hbm3e: stack_id unknown on ACT")

  // Refresh must be serviced again within tREFI after each REF command
  c_hbm3e_l4_ref_interval : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_ref ##[1:(L4_TREFI)] l4_ref);
  // Full ACT -> column -> PRE bank cycle observed
  c_hbm3e_l4_rw_cycle : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act ##[1:64] l4_col ##[1:64] l4_pre);

endmodule
`endif
