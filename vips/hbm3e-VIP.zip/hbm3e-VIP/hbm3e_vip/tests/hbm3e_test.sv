// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm3e_test.sv -- HBM3E UVM tests

`ifndef HBM3E_TEST_SV
`define HBM3E_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class hbm3e_base_test extends uvm_test;
  `uvm_component_utils(hbm3e_base_test)
  hbm3e_env env;
  function new(string name="hbm3e_base_test", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = hbm3e_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    hbm3e_regression_sequence seq;
    phase.raise_objection(this);
    seq = hbm3e_regression_sequence::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: write flow only
class hbm3e_write_test extends hbm3e_base_test;
  `uvm_component_utils(hbm3e_write_test)
  function new(string name="hbm3e_write_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    hbm3e_write_seq seq;
    phase.raise_objection(this);
    seq = hbm3e_write_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: read flow + refresh flow
class hbm3e_read_test extends hbm3e_base_test;
  `uvm_component_utils(hbm3e_read_test)
  function new(string name="hbm3e_read_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    hbm3e_read_seq    rd;
    hbm3e_refresh_seq rf;
    phase.raise_objection(this);
    rd = hbm3e_read_seq::type_id::create("rd");
    rf = hbm3e_refresh_seq::type_id::create("rf");
    rd.start(env.agt.sqr);
    rf.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress test: long protocol-legal random stream
class hbm3e_stress_test extends hbm3e_base_test;
  `uvm_component_utils(hbm3e_stress_test)
  function new(string name="hbm3e_stress_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    hbm3e_stress_seq seq;
    phase.raise_objection(this);
    seq = hbm3e_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
