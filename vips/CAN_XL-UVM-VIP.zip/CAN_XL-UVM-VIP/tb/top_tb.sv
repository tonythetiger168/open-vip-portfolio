// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CAN XL testbench top with a functional CAN XL DUT model

`ifndef CAN_XL_UVM_VIP_TB_SV
`define CAN_XL_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import can_xl_defs_pkg::*;
import can_xl_pkg::*;
import can_xl_env_pkg::*;
import can_xl_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  can_xl_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  can_xl_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx(vif.rx),
    .vcid_flt(vif.vcid_flt),
    .tx(vif.tx),
    .rx_ok(vif.rx_ok),
    .rx_err(vif.rx_err),
    .err_code(vif.err_code),
    .rec(vif.rec),
    .out_id(vif.out_id),
    .out_sdt(vif.out_sdt),
    .out_vcid(vif.out_vcid),
    .out_af(vif.out_af),
    .out_dlc(vif.out_dlc),
    .out_sum(vif.out_sum)
  );

  // Concurrent protocol checks
  can_xl_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .rx(vif.rx),
    .vcid_flt(vif.vcid_flt),
    .tx(vif.tx),
    .rx_ok(vif.rx_ok),
    .rx_err(vif.rx_err),
    .err_code(vif.err_code),
    .rec(vif.rec),
    .out_id(vif.out_id),
    .out_sdt(vif.out_sdt),
    .out_vcid(vif.out_vcid),
    .out_af(vif.out_af),
    .out_dlc(vif.out_dlc),
    .out_sum(vif.out_sum)
  );

  initial begin
    uvm_config_db#(virtual can_xl_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module can_xl_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rx,
  input  logic [7:0]  vcid_flt,
  output logic        tx,
  output logic        rx_ok,
  output logic        rx_err,
  output logic [2:0]  err_code,
  output logic [7:0]  rec,
  output logic [10:0] out_id,
  output logic [7:0]  out_sdt,
  output logic [7:0]  out_vcid,
  output logic [31:0] out_af,
  output logic [10:0] out_dlc,
  output logic [31:0] out_sum
);
  localparam logic [12:0] P_POLY = 13'h1CC5, P_INIT = 13'h1FFF;
  localparam logic [31:0] F_POLY = 32'hF4ACFB13, F_INIT = 32'hFFFFFFFF;
  localparam int FSB = 10;

  typedef enum logic [2:0] {IDLE, ARB, ADS, DATA, FCP, ACK, EOFR, ERRW} st_t;
  st_t st;
  logic        last;
  logic [3:0]  run, fcnt;
  logic [3:0]  ones;            // recessive run (saturates at 11)
  logic [2:0]  nsb;
  logic [4:0]  apos;            // arbitration bits taken
  logic [15:0] k;               // data-phase field bits taken
  logic [1:0]  spos;            // ADS / FCP bit
  logic [12:0] pc, rpc;
  logic [31:0] fc, rfc;
  logic [3:0]  sbc;
  logic [10:0] id, dlc;
  logic [7:0]  sdt, vcid, cur;
  logic [31:0] af, sum;
  logic [2:0]  eflag;           // error-flag bits still to send
  logic [3:0]  eofc;

  function automatic logic [12:0] f_pc(input logic [12:0] c, input logic b);
    f_pc = (b ^ c[12]) ? ((c << 1) ^ P_POLY) : (c << 1);
  endfunction
  function automatic logic [31:0] f_fc(input logic [31:0] c, input logic b);
    f_fc = (b ^ c[31]) ? ((c << 1) ^ F_POLY) : (c << 1);
  endfunction
  function automatic logic [3:0] f_sbc(input logic [2:0] n);
    logic [2:0] g;
    g = n ^ (n >> 1);
    f_sbc = {g, ^g};
  endfunction

  wire [15:0] dend = 16'd77 + (({5'b0, dlc} + 16'd1) << 3);   // first FCRC bit (DLC 2047: 2048 bytes)

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= IDLE; last <= 1'b1; run <= '0; fcnt <= '0; ones <= '0; nsb <= '0; apos <= '0; k <= '0;
      spos <= '0; pc <= P_INIT; fc <= F_INIT; rpc <= '0; rfc <= '0; sbc <= '0; id <= '0; dlc <= '0;
      sdt <= '0; vcid <= '0; cur <= '0; af <= '0; sum <= '0; eflag <= '0; eofc <= '0;
      tx <= 1'b1; rx_ok <= 1'b0; rx_err <= 1'b0; err_code <= '0; rec <= '0;
      out_id <= '0; out_sdt <= '0; out_vcid <= '0; out_af <= '0; out_dlc <= '0; out_sum <= '0;
    end else begin : step
      logic       fe;               // error found on this bit
      logic [2:0] ec;
      fe = 1'b0; ec = 3'd0;
      rx_ok <= 1'b0; rx_err <= 1'b0;
      ones <= rx ? ((ones == 4'd11) ? ones : ones + 4'd1) : 4'd0;
      // error flag: six dominant bits
      if (eflag != 0) begin tx <= 1'b0; eflag <= eflag - 3'd1; end
      else tx <= 1'b1;
      case (st)
        IDLE:
          if (!rx && ones == 4'd11) begin            // SOF
            st <= ARB; last <= 1'b0; run <= 4'd1; nsb <= '0; apos <= 5'd1;
            pc <= f_pc(P_INIT, 1'b0); fc <= f_fc(F_INIT, 1'b0);
          end
        ARB: begin
          pc <= f_pc(pc, rx); fc <= f_fc(fc, rx);
          if (run == 4'd5) begin                     // dynamic stuff bit
            if (rx == last) begin fe = 1'b1; ec = 3'd1; end
            nsb <= nsb + 3'd1; last <= rx; run <= 4'd1;
            if (apos == 5'd17) begin st <= ADS; spos <= '0; end
          end else if (apos == 5'd17) begin          // ADH (no stuff bit pending)
            if (!rx) begin fe = 1'b1; ec = 3'd3; end
            st <= ADS; spos <= 2'd1;
          end else begin
            if (apos >= 5'd1 && apos <= 5'd11) id <= {id[9:0], rx};
            if ((apos == 5'd14 && !rx) || (apos == 5'd15 && !rx) || (apos == 5'd16 && rx)) begin fe = 1'b1; ec = 3'd3; end
            run <= (rx == last) ? run + 4'd1 : 4'd1;
            last <= rx; apos <= apos + 5'd1;
          end
        end
        ADS: begin
          pc <= f_pc(pc, rx); fc <= f_fc(fc, rx);
          if (spos == 2'd0) begin
            if (!rx) begin fe = 1'b1; ec = 3'd3; end
            spos <= 2'd1;
          end else begin
            if (rx) begin fe = 1'b1; ec = 3'd3; end
            st <= DATA; k <= '0; fcnt <= '0; last <= rx; sum <= '0;
          end
        end
        DATA: begin
          if (fcnt == FSB[3:0]) begin                // fixed stuff bit
            if (rx == last) begin fe = 1'b1; ec = 3'd2; end
            fcnt <= '0;
          end else begin
            fcnt <= fcnt + 4'd1; last <= rx; k <= k + 16'd1;
            if (k < 16'd24) pc <= f_pc(pc, rx);
            if (k < dend) fc <= f_fc(fc, rx);
            if (k < 16'd8) sdt <= {sdt[6:0], rx};
            else if (k >= 16'd9 && k < 16'd20) dlc <= {dlc[9:0], rx};
            else if (k >= 16'd20 && k < 16'd24) begin
              sbc <= {sbc[2:0], rx};
              if (k == 16'd23 && {sbc[2:0], rx} != f_sbc(nsb)) begin fe = 1'b1; ec = 3'd4; end
            end else if (k >= 16'd24 && k < 16'd37) begin
              rpc <= {rpc[11:0], rx};
              if (k == 16'd36 && {rpc[11:0], rx} != pc) begin fe = 1'b1; ec = 3'd5; end
            end else if (k >= 16'd37 && k < 16'd45) vcid <= {vcid[6:0], rx};
            else if (k >= 16'd45 && k < 16'd77) af <= {af[30:0], rx};
            else if (k < dend) begin
              cur <= {cur[6:0], rx};
              if (k[2:0] == 3'd4) sum <= sum + {24'h0, cur[6:0], rx};   // (k - 77) % 8 == 7
            end else begin
              rfc <= {rfc[30:0], rx};
              if (k == dend + 16'd31) begin
                if ({rfc[30:0], rx} != fc) begin fe = 1'b1; ec = 3'd6; end
                st <= FCP; spos <= '0;
              end
            end
          end
        end
        FCP: begin
          if (rx != ((spos < 2'd2) ? 1'b1 : 1'b0)) begin fe = 1'b1; ec = 3'd3; end
          spos <= spos + 2'd1;
          if (spos == 2'd3) begin
            st <= ACK;
            if (!fe) tx <= 1'b0;                     // dominant ACK in the slot
          end
        end
        ACK: begin st <= EOFR; eofc <= '0; end      // ACK slot
        EOFR: begin                                  // ACK delimiter + EOF
          eofc <= eofc + 4'd1;
          if (eofc == 4'd7) begin
            st <= IDLE;
            if (rec != 0) rec <= rec - 8'd1;
            if (vcid_flt == 0 || vcid == vcid_flt) begin
              rx_ok <= 1'b1;
              out_id <= id; out_sdt <= sdt; out_vcid <= vcid; out_af <= af; out_dlc <= dlc; out_sum <= sum;
            end
          end
        end
        default: if (ones == 4'd11) st <= IDLE;      // ERRW: wait for bus idle
      endcase
      if (fe) begin
        st <= ERRW; eflag <= 3'd6; err_code <= ec; rx_err <= 1'b1;
        if (rec != 8'hFF) rec <= rec + 8'd1;
      end
    end
  end
endmodule
`endif
