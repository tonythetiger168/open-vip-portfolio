// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (CAN XL DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened can_xl_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic rx = 1'b1;
  logic [7:0] vcid_flt = 8'h00;
  wire tx, rx_ok, rx_err;
  wire [2:0] err_code;
  wire [7:0] rec, out_sdt, out_vcid;
  wire [10:0] out_id, out_dlc;
  wire [31:0] out_af, out_sum;

  always #5 clk = ~clk;

  can_xl_model u_dut (.clk(clk), .rst_n(rst_n), .rx(rx), .vcid_flt(vcid_flt), .tx(tx), .rx_ok(rx_ok),
                      .rx_err(rx_err), .err_code(err_code), .rec(rec), .out_id(out_id), .out_sdt(out_sdt),
                      .out_vcid(out_vcid), .out_af(out_af), .out_dlc(out_dlc), .out_sum(out_sum));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [12:0] f_pc(input logic [12:0] c, input logic b);
    f_pc = (b ^ c[12]) ? ((c << 1) ^ 13'h1CC5) : (c << 1);
  endfunction
  function automatic logic [31:0] f_fc(input logic [31:0] c, input logic b);
    f_fc = (b ^ c[31]) ? ((c << 1) ^ 32'hF4ACFB13) : (c << 1);
  endfunction

  // build and send one frame (two data bytes); flip = data-phase field bit to invert (-1 none)
  logic lb [0:511];
  int nl;
  logic saw_ack, saw_ok, saw_err;
  int lflip = -1;                 // raw (stuffed) bit index to invert before sending, -1 none
  int ntxlow, t_ack, t_ok, cyc;
  task automatic send(input logic [10:0] id, input logic [7:0] vc, input logic [7:0] d0, input logic [7:0] d1,
                      input int flip);
    logic a [0:16];
    logic d [0:200];
    int nd, run, nsb, fcnt;
    logic last;
    logic [12:0] pc; logic [31:0] fc;
    logic [2:0] g;
    pc = 13'h1FFF; fc = 32'hFFFFFFFF; nl = 0; run = 0; nsb = 0; last = 1;
    a[0] = 0; for (int i = 0; i < 11; i++) a[1 + i] = id[10 - i];
    a[12] = 0; a[13] = 0; a[14] = 1; a[15] = 1; a[16] = 0;
    for (int i = 0; i <= 17; i++) begin
      if (run == 5) begin lb[nl] = !last; pc = f_pc(pc, !last); fc = f_fc(fc, !last); nl++; nsb++; last = !last; run = 1; end
      if (i == 17) break;
      lb[nl] = a[i]; nl++; pc = f_pc(pc, a[i]); fc = f_fc(fc, a[i]);
      if (a[i] == last) run++; else begin last = a[i]; run = 1; end
    end
    lb[nl] = 1; nl++; pc = f_pc(pc, 1); fc = f_fc(fc, 1);
    lb[nl] = 0; nl++; pc = f_pc(pc, 0); fc = f_fc(fc, 0);
    nd = 0;
    for (int i = 7; i >= 0; i--) begin d[nd] = (8'h03 >> i) & 1; nd++; end       // SDT 0x03
    d[nd] = 0; nd++;                                                            // SEC
    for (int i = 10; i >= 0; i--) begin d[nd] = (11'd1 >> i) & 1; nd++; end      // DLC 1 = 2 bytes
    g = nsb[2:0] ^ (nsb[2:0] >> 1);
    d[nd] = g[2]; d[nd + 1] = g[1]; d[nd + 2] = g[0]; d[nd + 3] = ^g; nd += 4;
    for (int i = 0; i < nd; i++) begin pc = f_pc(pc, d[i]); fc = f_fc(fc, d[i]); end
    for (int i = 12; i >= 0; i--) begin d[nd] = pc[i]; fc = f_fc(fc, pc[i]); nd++; end
    for (int i = 7; i >= 0; i--) begin d[nd] = vc[i]; fc = f_fc(fc, vc[i]); nd++; end
    for (int i = 31; i >= 0; i--) begin d[nd] = (32'h0BAD_F00D >> i) & 1; fc = f_fc(fc, d[nd]); nd++; end
    for (int i = 7; i >= 0; i--) begin d[nd] = d0[i]; fc = f_fc(fc, d0[i]); nd++; end
    for (int i = 7; i >= 0; i--) begin d[nd] = d1[i]; fc = f_fc(fc, d1[i]); nd++; end
    for (int i = 31; i >= 0; i--) begin d[nd] = fc[i]; nd++; end
    if (flip >= 0) d[flip] = !d[flip];
    last = 0; fcnt = 0;
    for (int i = 0; i < nd; i++) begin
      if (fcnt == 10) begin lb[nl] = !last; nl++; fcnt = 0; end
      lb[nl] = d[i]; nl++; last = d[i]; fcnt++;
    end
    lb[nl] = 1; lb[nl + 1] = 1; lb[nl + 2] = 0; lb[nl + 3] = 0; nl += 4;
    if (lflip >= 0) lb[lflip] = !lb[lflip];
    saw_ack = 0; saw_ok = 0; saw_err = 0; ntxlow = 0; t_ack = -1; t_ok = -1; cyc = 0;
    begin
      int bad = 0;
      repeat (12) begin @(negedge clk); rx = 1; if (tx !== 1'b1) bad++; end
      chk(bad == 0, "tx recessive while idle");
    end
    for (int i = 0; i < nl; i++) begin
      @(negedge clk); rx = lb[i]; cyc++;
      if (rx_err) saw_err = 1;
      if (!tx) ntxlow++;
    end
    repeat (14) begin
      @(negedge clk); rx = 1; cyc++;
      if (!tx && !saw_err) begin saw_ack = 1; if (t_ack < 0) t_ack = cyc; end
      if (!tx) ntxlow++;
      if (rx_ok) begin saw_ok = 1; if (t_ok < 0) t_ok = cyc; end
      if (rx_err) saw_err = 1;
    end
  endtask

  initial begin
    repeat (3) @(posedge clk);
    chk(tx === 1'b1, "tx recessive in reset");
    rst_n = 1;

    send(11'h123, 8'h05, 8'h11, 8'h22, -1);
    chk(saw_ack && saw_ok && !saw_err, "good frame ACKed and reported");
    chk(out_id === 11'h123 && out_vcid === 8'h05 && out_af === 32'h0BAD_F00D && out_dlc === 11'd1, "fields reported");
    chk(out_sum === 32'h33 && out_sdt === 8'h03, "data sum and SDT reported");
    chk(ntxlow == 1, "a good frame drives exactly one dominant bit (ACK)");
    chk(t_ok - t_ack == 9, $sformatf("frame reported after ACK delimiter and 7-bit EOF (%0d)", t_ok - t_ack));
    send(11'h0F0, 8'h07, 8'hAA, 8'h55, 50);       // flip an AF bit: only the FCRC covers it
    chk(!saw_ack && saw_err && err_code === 3'd6, "FCRC error flagged, no ACK");
    chk(ntxlow == 6, $sformatf("six-bit error flag (%0d dominant bits)", ntxlow));
    chk(rec === 8'd1, "receive error counter +1");
    send(11'h0F0, 8'h07, 8'hAA, 8'h55, 30);       // flip a PCRC bit
    chk(saw_err && err_code === 3'd5 && rec === 8'd2, "PCRC error flagged");
    send(11'h123, 8'h06, 8'h01, 8'h02, -1);
    chk(saw_ack && !saw_err && rec === 8'd1, "good frame after errors, counter -1");
    chk(out_vcid === 8'h06, "VCID field boundary (PCRC ends at bit 37)");
    send(11'h123, 8'h06, 8'h01, 8'h02, 21);       // flip the SBC parity bit
    chk(saw_err && err_code === 3'd4, "SBC error flagged");
    // arbitration-phase errors (ID 0x123 has no stuff bits before ADH: raw index = field bit)
    begin : arb
      int r0;
      for (int b = 14; b <= 17; b++) begin
        r0 = rec;
        lflip = b; send(11'h123, 8'h06, 8'h01, 8'h02, -1); lflip = -1;
        chk(saw_err && !saw_ok && err_code === 3'd3 && rec == r0 + 1,
            $sformatf("form error on %s", b == 14 ? "FDF" : b == 15 ? "XLF" : b == 16 ? "resXL" : "ADH"));
      end
      lflip = 5; send(11'h000, 8'h06, 8'h01, 8'h02, -1); lflip = -1;   // the stuff bit after SOF + 4 zeros
      chk(saw_err && err_code === 3'd1, "dynamic stuff error in arbitration");
      repeat (8) begin send(11'h123, 8'h06, 8'h01, 8'h02, -1); end
    end
    vcid_flt = 8'h05;
    send(11'h124, 8'h06, 8'h01, 8'h02, -1);
    chk(saw_ack && !saw_ok, "VCID filtered: ACKed, not reported");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
