// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_xl_env.sv -- CAN XL environment: reference-model scoreboard, checker, coverage

package can_xl_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import can_xl_defs_pkg::*;
  import can_xl_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class can_xl_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(can_xl_scoreboard)
    uvm_analysis_imp_exp #(can_xl_transaction, can_xl_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(can_xl_transaction, can_xl_scoreboard) obs_ap;

    can_xl_config cfg;
    can_xl_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [7:0] rec = 0;
    bit [2:0] last_err = 0;
    bit [10:0] l_id = 0; bit [7:0] l_sdt = 0, l_vcid = 0; bit [31:0] l_af = 0; bit [10:0] l_dlc = 0;
    bit [31:0] l_sum = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(can_xl_config)::get(this, "", "cfg", cfg))
        cfg = can_xl_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(can_xl_transaction t);
      bit err = (t.err_kind != XL_OK);
      t.acked = !err;
      t.eflag = err;
      if (err) begin
        last_err = t.err_kind;
        if (rec != 8'hFF) rec++;
      end else if (rec != 0) rec--;
      t.err_code = last_err;
      t.rec = rec;
      t.rx_ok = !err && (cfg.vcid_flt == 0 || t.vcid == cfg.vcid_flt);
      if (t.rx_ok) begin
        l_id = t.id; l_sdt = t.sdt; l_vcid = t.vcid; l_af = t.af; l_dlc = t.dlc;
        l_sum = 0;
        foreach (t.data[i]) l_sum += t.data[i];
      end
      t.out_id = l_id; t.out_sdt = l_sdt; t.out_vcid = l_vcid; t.out_af = l_af; t.out_dlc = l_dlc; t.out_sum = l_sum;
    endfunction

    function void write_exp(can_xl_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(can_xl_transaction t);
      can_xl_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        can_xl_transaction e = exp_q.pop_front();
        can_xl_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("can_xl scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class can_xl_env extends uvm_env;
    `uvm_component_utils(can_xl_env)
    can_xl_agent      agt;
    can_xl_scoreboard sb;
    can_xl_checker    chk;
    can_xl_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = can_xl_agent     ::type_id::create("agt", this);
      sb  = can_xl_scoreboard::type_id::create("sb",  this);
      chk = can_xl_checker   ::type_id::create("chk", this);
      cov = can_xl_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
