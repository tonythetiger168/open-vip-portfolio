// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_xl_if.sv -- CAN XL interface

interface can_xl_if (input logic clk);
  logic rst_n;

  logic rx;
  logic [7:0] vcid_flt;
  logic tx;
  logic rx_ok;
  logic rx_err;
  logic [2:0] err_code;
  logic [7:0] rec;
  logic [10:0] out_id;
  logic [7:0] out_sdt;
  logic [7:0] out_vcid;
  logic [31:0] out_af;
  logic [10:0] out_dlc;
  logic [31:0] out_sum;

  modport DUT (input clk, rst_n, input rx, input vcid_flt, output tx, output rx_ok, output rx_err, output err_code, output rec, output out_id, output out_sdt, output out_vcid, output out_af, output out_dlc, output out_sum);
  modport MON (input clk, rst_n, rx, vcid_flt, tx, rx_ok, rx_err, err_code, rec, out_id, out_sdt, out_vcid, out_af, out_dlc, out_sum);

  clocking drv_cb @(posedge clk);
    input rst_n, tx, rx_ok, rx_err, err_code, rec, out_id, out_sdt, out_vcid, out_af, out_dlc, out_sum;
    inout rx, vcid_flt;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, rx, vcid_flt, tx, rx_ok, rx_err, err_code, rec, out_id, out_sdt, out_vcid, out_af, out_dlc, out_sum;
  endclocking
endinterface
