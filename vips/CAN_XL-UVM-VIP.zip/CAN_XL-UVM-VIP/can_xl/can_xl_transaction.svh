// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_xl_transaction.svh -- CAN XL transaction

class can_xl_transaction extends uvm_sequence_item;
  `uvm_object_utils(can_xl_transaction)

  // request (driven by the agent)
  rand bit [10:0] id;
  rand bit [7:0] sdt;
  rand bit sec;
  rand bit [7:0] vcid;
  rand bit [31:0] af;
  rand bit [10:0] dlc;
  bit [7:0] data[$];
  rand canxl_err_e err_kind;
  // response (returned by the DUT)
  bit acked;
  bit eflag;
  bit rx_ok;
  bit [2:0] err_code;
  bit [7:0] rec;
  bit [10:0] out_id;
  bit [7:0] out_sdt;
  bit [7:0] out_vcid;
  bit [31:0] out_af;
  bit [10:0] out_dlc;
  bit [31:0] out_sum;
  // bookkeeping (not compared)
  rand bit [31:0] seed;
  bit bits[$];
  int unsigned ack_pos;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len  { dlc inside {[0:63]}; }
  constraint c_vcid { vcid dist { 8'h05 := 3, 8'h00 := 1, [8'h01:8'hFF] :/ 2 }; }
  constraint c_err  { err_kind dist { XL_OK := 10, XL_STUFF_DYN := 1, XL_STUFF_FIX := 1, XL_FORM := 1,
                                      XL_SBC := 1, XL_PCRC := 1, XL_FCRC := 1 }; }

  function new(string name = "can_xl_transaction"); super.new(name); endfunction

  function void post_randomize();
    bit [31:0] x = seed | 1;
    data.delete();
    for (int i = 0; i <= dlc; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      data.push_back(x[7:0]);
    end
    build();
  endfunction

  // line bits for the frame, with err_kind injected
  function void build();
    bit a[$], d[$];
    bit last = 1, s;
    int run = 0, nsb = 0, fcnt = 0;
    bit dyn_done = 0, fix_done = 0;
    bit [12:0] pc = CANXL_PCRC_INIT;
    bit [31:0] fc = CANXL_FCRC_INIT;
    bit [12:0] pcrc;
    bit [31:0] fcrc;
    if (err_kind == XL_STUFF_DYN) id[10:7] = 4'h0;     // SOF + four zeros force a stuff bit
    bits.delete();
    // arbitration phase
    a.push_back(1'b0);
    for (int i = 10; i >= 0; i--) a.push_back(id[i]);
    a.push_back(1'b0); a.push_back(1'b0); a.push_back(1'b1); a.push_back(1'b1); a.push_back(1'b0);
    for (int i = 0; i <= a.size(); i++) begin
      if (run == 5) begin                          // dynamic stuff bit
        s = !last;
        if (err_kind == XL_STUFF_DYN && !dyn_done) begin s = last; dyn_done = 1; end
        bits.push_back(s); pc = canxl_crc13(pc, s); fc = canxl_crc32(fc, s);
        nsb++; last = s; run = 1;
      end
      if (i == a.size()) break;
      bits.push_back(a[i]); pc = canxl_crc13(pc, a[i]); fc = canxl_crc32(fc, a[i]);
      if (a[i] == last) run++; else begin last = a[i]; run = 1; end
    end
    // ADS
    bits.push_back(1'b1); pc = canxl_crc13(pc, 1'b1); fc = canxl_crc32(fc, 1'b1);
    bits.push_back(1'b0); pc = canxl_crc13(pc, 1'b0); fc = canxl_crc32(fc, 1'b0);
    // data phase fields
    for (int i = 7; i >= 0; i--) d.push_back(sdt[i]);
    d.push_back(sec);
    for (int i = 10; i >= 0; i--) d.push_back(dlc[i]);
    begin
      bit [3:0] sbc = canxl_sbc(nsb);
      for (int i = 3; i >= 0; i--) d.push_back(sbc[i]);
    end
    foreach (d[i]) begin pc = canxl_crc13(pc, d[i]); fc = canxl_crc32(fc, d[i]); end
    pcrc = pc;
    for (int i = 12; i >= 0; i--) begin d.push_back(pcrc[i]); fc = canxl_crc32(fc, pcrc[i]); end
    begin
      int n0 = d.size();
      for (int i = 7; i >= 0; i--) d.push_back(vcid[i]);
      for (int i = 31; i >= 0; i--) d.push_back(af[i]);
      foreach (data[j]) for (int i = 7; i >= 0; i--) d.push_back(data[j][i]);
      for (int i = n0; i < d.size(); i++) fc = canxl_crc32(fc, d[i]);
    end
    fcrc = fc;
    for (int i = 31; i >= 0; i--) d.push_back(fcrc[i]);
    // line errors after the transmitter
    case (err_kind)
      XL_SBC:  d[23] = !d[23];                          // SBC parity
      XL_PCRC: d[36] = !d[36];                          // PCRC LSB
      XL_FCRC: d[d.size() - 1] = !d[d.size() - 1];      // FCRC LSB
      default: ;
    endcase
    // fixed stuffing: a complement bit before every (CANXL_FSB + 1)th bit
    last = 1'b0;                                        // ADL
    foreach (d[i]) begin
      if (fcnt == CANXL_FSB) begin
        s = !last;
        if (err_kind == XL_STUFF_FIX && !fix_done) begin s = last; fix_done = 1; end
        bits.push_back(s); fcnt = 0;
      end
      bits.push_back(d[i]); last = d[i]; fcnt++;
    end
    // FCP
    bits.push_back(1'b1); bits.push_back(1'b1); bits.push_back(1'b0);
    bits.push_back(err_kind == XL_FORM ? 1'b1 : 1'b0);
    ack_pos = bits.size();
  endfunction

  function void do_copy(uvm_object rhs);
    can_xl_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    id = rhs_.id;
    sdt = rhs_.sdt;
    sec = rhs_.sec;
    vcid = rhs_.vcid;
    af = rhs_.af;
    dlc = rhs_.dlc;
    data = rhs_.data;
    err_kind = rhs_.err_kind;
    acked = rhs_.acked;
    eflag = rhs_.eflag;
    rx_ok = rhs_.rx_ok;
    err_code = rhs_.err_code;
    rec = rhs_.rec;
    out_id = rhs_.out_id;
    out_sdt = rhs_.out_sdt;
    out_vcid = rhs_.out_vcid;
    out_af = rhs_.out_af;
    out_dlc = rhs_.out_dlc;
    out_sum = rhs_.out_sum;
    seed = rhs_.seed;
    bits = rhs_.bits;
    ack_pos = rhs_.ack_pos;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    can_xl_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (id != rhs_.id) return 0;
    if (sdt != rhs_.sdt) return 0;
    if (sec != rhs_.sec) return 0;
    if (vcid != rhs_.vcid) return 0;
    if (af != rhs_.af) return 0;
    if (dlc != rhs_.dlc) return 0;
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (err_kind != rhs_.err_kind) return 0;
    if (acked != rhs_.acked) return 0;
    if (eflag != rhs_.eflag) return 0;
    if (rx_ok != rhs_.rx_ok) return 0;
    if (err_code != rhs_.err_code) return 0;
    if (rec != rhs_.rec) return 0;
    if (out_id != rhs_.out_id) return 0;
    if (out_sdt != rhs_.out_sdt) return 0;
    if (out_vcid != rhs_.out_vcid) return 0;
    if (out_af != rhs_.out_af) return 0;
    if (out_dlc != rhs_.out_dlc) return 0;
    if (out_sum != rhs_.out_sum) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(can_xl_transaction rhs_);
    if (id != rhs_.id) return 0;
    if (sdt != rhs_.sdt) return 0;
    if (sec != rhs_.sec) return 0;
    if (vcid != rhs_.vcid) return 0;
    if (af != rhs_.af) return 0;
    if (dlc != rhs_.dlc) return 0;
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (err_kind != rhs_.err_kind) return 0;
    return 1;
  endfunction

  function string qstr_data();
    string s = $sformatf("[%0d]{", data.size());
    foreach (data[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", data[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_bits();
    string s = $sformatf("[%0d]{", bits.size());
    foreach (bits[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bits[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("CAN XL{tag=%0d id=0x%0h sdt=0x%0h sec=0x%0h vcid=0x%0h af=0x%0h dlc=0x%0h data=%s err_kind=0x%0h acked=0x%0h eflag=0x%0h rx_ok=0x%0h err_code=0x%0h rec=0x%0h out_id=0x%0h out_sdt=0x%0h out_vcid=0x%0h out_af=0x%0h out_dlc=0x%0h out_sum=0x%0h}", tag, id, sdt, sec, vcid, af, dlc, qstr_data(), err_kind, acked, eflag, rx_ok, err_code, rec, out_id, out_sdt, out_vcid, out_af, out_dlc, out_sum);
  endfunction
endclass
