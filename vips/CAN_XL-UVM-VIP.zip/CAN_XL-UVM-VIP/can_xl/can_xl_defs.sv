// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_xl_defs.sv -- CAN XL shared type definitions

package can_xl_defs_pkg;

  typedef enum bit [1:0] {CAN_XL_OK, CAN_XL_ERR} can_xl_status_e;

  // serial CRCs, MSB first: c = (c << 1) ^ poly when (bit ^ c[msb])
  localparam bit [12:0] CANXL_PCRC_POLY = 13'h1CC5;
  localparam bit [12:0] CANXL_PCRC_INIT = 13'h1FFF;
  localparam bit [31:0] CANXL_FCRC_POLY = 32'hF4AC_FB13;
  localparam bit [31:0] CANXL_FCRC_INIT = 32'hFFFF_FFFF;
  localparam int        CANXL_FSB       = 10;    // data bits between fixed stuff bits

  typedef enum bit [2:0] {XL_OK, XL_STUFF_DYN, XL_STUFF_FIX, XL_FORM, XL_SBC, XL_PCRC, XL_FCRC} canxl_err_e;

  function automatic bit [12:0] canxl_crc13(bit [12:0] c, bit b);
    bit fb = b ^ c[12];
    c = c << 1;
    return fb ? c ^ CANXL_PCRC_POLY : c;
  endfunction

  function automatic bit [31:0] canxl_crc32(bit [31:0] c, bit b);
    bit fb = b ^ c[31];
    c = c << 1;
    return fb ? c ^ CANXL_FCRC_POLY : c;
  endfunction

  function automatic bit [3:0] canxl_sbc(int unsigned nsb);
    bit [2:0] b = nsb % 8;
    bit [2:0] g = b ^ (b >> 1);
    return {g, ^g};
  endfunction

endpackage
