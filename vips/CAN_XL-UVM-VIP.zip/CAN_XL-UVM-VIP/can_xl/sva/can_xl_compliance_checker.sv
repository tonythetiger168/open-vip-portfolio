// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_xl_compliance_checker.sv -- CAN XL concurrent assertion checks (bindable)

module can_xl_compliance_checker
  (input logic clk, input logic rst_n, input logic rx, input logic [7:0] vcid_flt, input logic tx, input logic rx_ok, input logic rx_err, input logic [2:0] err_code, input logic [7:0] rec, input logic [10:0] out_id, input logic [7:0] out_sdt, input logic [7:0] out_vcid, input logic [31:0] out_af, input logic [10:0] out_dlc, input logic [31:0] out_sum);

  // outputs never X out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tx, rx_ok, rx_err, err_code, rec}))
    else $error("CAN XL: X on outputs");
  // recessive in reset
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |=> tx)
    else $error("CAN XL: tx not recessive in reset");
  // an error flag is six dominant bits after rx_err
  assert property (@(posedge clk) disable iff (!rst_n) rx_err |=> !tx [*6] ##1 tx)
    else $error("CAN XL: error flag is not six dominant bits");
  // the ACK is a single dominant bit
  assert property (@(posedge clk) disable iff (!rst_n) !tx && $past(tx) && !$past(rx_err) |=> tx)
    else $error("CAN XL: ACK longer than one bit");
  // a good frame and an error are never reported together
  assert property (@(posedge clk) disable iff (!rst_n) !(rx_ok && rx_err))
    else $error("CAN XL: rx_ok and rx_err together");
  cover property (@(posedge clk) disable iff (!rst_n) rx_ok);
  cover property (@(posedge clk) disable iff (!rst_n) rx_err && err_code == 3'd6);
endmodule
