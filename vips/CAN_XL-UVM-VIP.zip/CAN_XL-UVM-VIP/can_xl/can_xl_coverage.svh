// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_xl_coverage.svh -- CAN XL functional coverage

class can_xl_coverage extends uvm_subscriber #(can_xl_transaction);
  `uvm_component_utils(can_xl_coverage)
  can_xl_config cfg;
  can_xl_transaction tr;

  covergroup can_xl_cg;
    cp_err  : coverpoint tr.err_kind;
    cp_len  : coverpoint tr.dlc { bins one = {0}; bins short_ = {[1:15]}; bins mid = {[16:63]}; bins long_ = {[64:2047]}; }
    cp_flt  : coverpoint tr.rx_ok;
    cp_sec  : coverpoint tr.sec;
    x_err_len : cross cp_err, cp_len { ignore_bins big = binsof(cp_len.long_); }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    can_xl_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(can_xl_config)::get(this, "", "cfg", cfg))
      cfg = can_xl_config::type_id::create("cfg");
  endfunction

  function void write(can_xl_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    can_xl_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CAN XL coverage: %0.1f%%", can_xl_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
