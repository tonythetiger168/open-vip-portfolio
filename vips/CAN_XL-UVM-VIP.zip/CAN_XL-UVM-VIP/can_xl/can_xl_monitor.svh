// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_xl_monitor.svh -- CAN XL monitor: frames from SOF to 11 recessive bits; independent de-stuffer, field decoder and CRC / SBC / FCP checks; DUT ACK, error flag and outputs

class can_xl_monitor extends uvm_monitor;
  `uvm_component_utils(can_xl_monitor)

  virtual can_xl_if vif;
  uvm_analysis_port #(can_xl_transaction) ap;
  can_xl_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual can_xl_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "can_xl: virtual interface not set")
    if (!uvm_config_db#(can_xl_config)::get(this, "", "cfg", cfg))
      cfg = can_xl_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit rxq[$], txq[$];
      int unsigned ones = 0;
      bit in_frame = 0, okp = 0, errp = 0;
      forever begin
        bit rx;
        @(vif.mon_cb);
        rx = vif.mon_cb.rx;
        if (!in_frame) begin
          if (rx == 1'b0 && ones >= 11) begin
            in_frame = 1; rxq.delete(); txq.delete(); okp = 0; errp = 0;
          end
        end
        if (in_frame) begin
          rxq.push_back(rx); txq.push_back(vif.mon_cb.tx);
          if (vif.mon_cb.rx_ok) okp = 1;
          if (vif.mon_cb.rx_err) errp = 1;
          // 11 recessive bits end the frame once the decoded frame (up to its ACK
          // slot) lies before them; a run inside the data phase does not
          if (ones >= 10 && rx) begin
            can_xl_transaction t = can_xl_transaction::type_id::create("t");
            if (decode(t, rxq) && t.ack_pos + 11 <= rxq.size()) begin
            // the DUT's tx answers rx one clock later: tx sampled with rx bit i
            // is the response to bit i - 1, so the ACK appears at ack_pos
            t.eflag = errp;
            t.acked = !txq[t.ack_pos] && !errp;
            t.rx_ok = okp;
            t.err_code = vif.mon_cb.err_code; t.rec = vif.mon_cb.rec;
            t.out_id = vif.mon_cb.out_id; t.out_sdt = vif.mon_cb.out_sdt; t.out_vcid = vif.mon_cb.out_vcid;
            t.out_af = vif.mon_cb.out_af; t.out_dlc = vif.mon_cb.out_dlc; t.out_sum = vif.mon_cb.out_sum;
            for (int i = 0; i < t.ack_pos; i++) t.bits.push_back(rxq[i]);
            publish(t);
            in_frame = 0;
            end
          end
        end
        ones = rx ? ones + 1 : 0;
      end
    end
  endtask

  function void publish(can_xl_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // independent decoder: de-stuff, rebuild the fields, report the first error
  // returns 0 while the frame is incomplete
  function bit decode(can_xl_transaction t, bit lb[$]);
    bit f[$];                       // data-phase field bits (fixed stuff removed)
    bit last = 1;
    int run = 0, nsb = 0, i = 0, fcnt = 0, k;
    bit [12:0] pc = CANXL_PCRC_INIT, rpc;
    bit [31:0] fc = CANXL_FCRC_INIT, rfc;
    bit [3:0] sbc;
    bit a[$];
    canxl_err_e e = XL_OK;
    // arbitration phase: 17 bits after de-stuffing (+ a trailing stuff bit)
    if (lb.size() < 40) return 0;
    while (a.size() <= 17 && i < lb.size()) begin
      if (run == 5) begin
        if (lb[i] == last && e == XL_OK) e = XL_STUFF_DYN;
        pc = canxl_crc13(pc, lb[i]); fc = canxl_crc32(fc, lb[i]);
        nsb++; last = lb[i]; run = 1; i++;
        continue;
      end
      if (a.size() == 17) break;
      a.push_back(lb[i]); pc = canxl_crc13(pc, lb[i]); fc = canxl_crc32(fc, lb[i]);
      if (lb[i] == last) run++; else begin last = lb[i]; run = 1; end
      i++;
    end
    for (int j = 0; j < 11; j++) t.id[10 - j] = a[1 + j];
    if ((a[14] != 1 || a[15] != 1 || a[16] != 0) && e == XL_OK) e = XL_FORM;
    // ADS
    if ((lb[i] != 1 || lb[i + 1] != 0) && e == XL_OK) e = XL_FORM;
    pc = canxl_crc13(pc, lb[i]); fc = canxl_crc32(fc, lb[i]);
    pc = canxl_crc13(pc, lb[i + 1]); fc = canxl_crc32(fc, lb[i + 1]);
    last = lb[i + 1]; i += 2;
    // data phase up to the end of DLC, to know the length
    k = 77 + 8 * 64 + 32;                       // upper bound until DLC is known
    while (f.size() < k && i < lb.size()) begin
      if (fcnt == CANXL_FSB) begin
        if (lb[i] == last && e == XL_OK) e = XL_STUFF_FIX;
        fcnt = 0; i++;
        continue;
      end
      f.push_back(lb[i]); last = lb[i]; fcnt++; i++;
      if (f.size() == 20) begin
        for (int j = 0; j < 11; j++) t.dlc[10 - j] = f[9 + j];
        k = 77 + 8 * (t.dlc + 1) + 32;
      end
    end
    if (f.size() < k || i + 4 > lb.size()) return 0;
    for (int j = 0; j < 8; j++) t.sdt[7 - j] = f[j];
    t.sec = f[8];
    for (int j = 0; j < 24; j++) begin pc = canxl_crc13(pc, f[j]); fc = canxl_crc32(fc, f[j]); end
    for (int j = 0; j < 4; j++) sbc[3 - j] = f[20 + j];
    if (sbc != canxl_sbc(nsb) && e == XL_OK) e = XL_SBC;
    for (int j = 0; j < 13; j++) rpc[12 - j] = f[24 + j];
    if (rpc != pc && e == XL_OK) e = XL_PCRC;
    for (int j = 24; j < k - 32; j++) fc = canxl_crc32(fc, f[j]);
    for (int j = 0; j < 8; j++) t.vcid[7 - j] = f[37 + j];
    for (int j = 0; j < 32; j++) t.af[31 - j] = f[45 + j];
    t.data.delete();
    for (int b = 0; b <= t.dlc; b++) begin
      bit [7:0] v;
      for (int j = 0; j < 8; j++) v[7 - j] = f[77 + 8 * b + j];
      t.data.push_back(v);
    end
    for (int j = 0; j < 32; j++) rfc[31 - j] = f[k - 32 + j];
    if (rfc != fc && e == XL_OK) e = XL_FCRC;
    if ({lb[i], lb[i + 1], lb[i + 2], lb[i + 3]} != 4'b1100 && e == XL_OK) e = XL_FORM;
    t.ack_pos = i + 4;
    t.err_kind = e;
    return 1;
  endfunction
endclass
