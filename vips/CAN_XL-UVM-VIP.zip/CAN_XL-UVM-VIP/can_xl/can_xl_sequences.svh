// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// can_xl_sequences.svh -- CAN XL sequences

// Random traffic: cfg.num_items constrained-random items.
class can_xl_base_sequence extends uvm_sequence #(can_xl_transaction);
  `uvm_object_utils(can_xl_base_sequence)
  can_xl_config cfg;

  function new(string name = "can_xl_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = can_xl_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "can_xl_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class can_xl_directed_sequence extends uvm_sequence #(can_xl_transaction);
  `uvm_object_utils(can_xl_directed_sequence)
  can_xl_config cfg;

  function new(string name = "can_xl_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function can_xl_transaction item();
    item = can_xl_transaction::type_id::create("req");
  endfunction

  task send(can_xl_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    can_xl_transaction t;
    // one good frame of every length class, the longest frame, and every error kind
    t = item(); t.id = 11'h123; t.sdt = 8'h03; t.vcid = 8'h05; t.af = 32'hCAFE_0001; t.dlc = 0; t.seed = 1;
    t.post_randomize(); send(t);
    t = item(); t.id = 11'h7FF; t.sdt = 8'h05; t.sec = 1; t.vcid = 8'h05; t.af = 32'hFFFF_FFFF; t.dlc = 63; t.seed = 2;
    t.post_randomize(); send(t);
    t = item(); t.id = 11'h000; t.sdt = 8'h00; t.vcid = 8'h00; t.af = 32'h0; t.dlc = 7; t.seed = 3;
    t.post_randomize(); send(t);
    t = item(); t.id = 11'h2AA; t.sdt = 8'h07; t.vcid = 8'h09; t.af = 32'h1234_5678; t.dlc = 15; t.seed = 4;
    t.post_randomize(); send(t);                  // filtered: ACKed, not reported
    t = item(); t.id = 11'h055; t.sdt = 8'h01; t.vcid = 8'h05; t.af = 32'hA5A5_5A5A; t.dlc = 2047; t.seed = 5;
    t.post_randomize(); send(t);                  // 2048 data bytes
    for (int k = 1; k < 7; k++) begin
      t = item(); t.id = 11'h100 + k; t.sdt = k; t.vcid = 8'h05; t.af = k; t.dlc = 3 + k; t.seed = 10 + k;
      t.err_kind = canxl_err_e'(k);
      t.post_randomize(); send(t);
    end
    // recovery: good frames bring the receive error counter back down
    repeat (3) begin
      t = item(); t.id = 11'h321; t.vcid = 8'h05; t.dlc = 1; t.seed = 99; t.post_randomize(); send(t);
    end
  endtask
endclass
