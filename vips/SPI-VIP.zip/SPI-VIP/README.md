# SPI — SPI UVM VIP

Open-source UVM verification IP template for **SPI** (Serial).

## Contents

| Path | Description |
|------|-------------|
| `spi/spi_if.sv` | Protocol interface + FSM state enum |
| `spi/spi_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `spi/sva/spi_compliance_checker.sv` | SVA compliance checker (L1=4, L2=4, L3=4) |
| `spi/vip/spi/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/spi_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with FSM-walking DUT stub |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged master driver**: SPI modes 0-3 (CPOL/CPHA), CS-framed full-duplex shift, MISO sampled into `rx_data`, `drv_ap` broadcasts expected transactions before `item_done()`
- **Protocol-decoding monitor**: reconstructs mode/MOSI/MISO transactions from sclk/cs_n/mosi/miso waveforms (CPOL from idle level, CPHA from MOSI pre-load), flags mid-byte CS aborts
- **End-to-end scoreboard**: compares driver-issued vs monitor-decoded transactions (mode/width/data/abort) and checks the loopback property (MISO returns previous frame's MOSI bytes)
- **Functional DUT model**: SPI slave with waveform mode decode + byte loopback, aborted frames discarded, MISO released while CS high
- **Directed sequence library**: write / read / burst (16/24/32-bit) / back-to-back / mode-sweep / error-inject (CS abort) / reset + regression mix
- **Functional coverage**: mode x frame-width cross, MOSI data corners, FSM state + frame transition sequence, CS-abort x mode error bins
- **SVA L4**: sclk only toggles while CS low, MOSI changes only on clock/CS edges, no frame state while CS high, frame clock count is 8N
