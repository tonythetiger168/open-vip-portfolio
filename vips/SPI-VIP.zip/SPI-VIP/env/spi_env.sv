// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// spi_env.sv -- SPI verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import spi_defs_pkg::*;
  import spi_pkg::*;

  // End-to-end scoreboard: compares driver-issued (expected) transactions
  // against monitor-decoded (observed) transactions, and checks the DUT
  // loopback property (MISO returns the previous good frame's MOSI bytes).
    `uvm_analysis_imp_decl(_exp)
    `uvm_analysis_imp_decl(_obs)

  class spi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(spi_scoreboard)
    uvm_analysis_imp_exp #(spi_transaction, spi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(spi_transaction, spi_scoreboard) obs_ap;

    spi_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    // loopback tracking: first MOSI byte of the previous complete frame
    bit [7:0]    prev_first_byte = 8'h00;
    bit          prev_valid      = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(spi_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(spi_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        spi_transaction e = exp_q.pop_front();
        spi_transaction o = obs_q.pop_front();
        bit ok;
        bit [7:0] exp_lb;
        ok = (e.mode == o.mode) && (e.num_bits == o.num_bits) &&
             (e.cs_aborted == o.cs_aborted) && (e.tx_data == o.tx_data) &&
             (e.rx_data == o.rx_data);
        if (!ok) begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end else begin
          n_matches++;
        end
        // loopback property: first MISO byte of a complete frame must be the
        // first MOSI byte of the previous complete frame (0x00 initially)
        if (!o.cs_aborted) begin
          exp_lb = prev_valid ? prev_first_byte : 8'h00;
          if (o.rx_data[o.num_bits-1 -: 8] !== exp_lb) begin
            n_mismatches++;
            `uvm_error("SB", $sformatf(
              "loopback violation: first rx byte 0x%02h != expected 0x%02h obs{%s}",
              o.rx_data[o.num_bits-1 -: 8], exp_lb, o.convert2string()))
          end
          prev_first_byte = o.tx_data[o.num_bits-1 -: 8];
          prev_valid      = 1;
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("spi scoreboard: matches=%0d mismatches=%0d",
                n_matches, n_mismatches), UVM_LOW)
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("unpaired transactions: exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
      if (n_mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class spi_env extends uvm_env;
    `uvm_component_utils(spi_env)
    spi_agent      agt;
    spi_scoreboard sb;
    spi_checker    chk;
    spi_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = spi_agent::type_id::create("agt", this);
      sb  = spi_scoreboard::type_id::create("sb", this);
      chk = spi_checker::type_id::create("chk", this);
      cov = spi_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
