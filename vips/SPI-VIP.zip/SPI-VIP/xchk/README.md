# Independent cross-check model (`xchk/`)

`spi_xchk_tb.sv` checks the open-ip-portfolio `SPI` RTL (`rtl/SPI_top.sv`, `rtl/SPI_apb.sv`)
against a mode-0 SPI controller (MSB first, MISO setup before each SCLK rise). The model is written from SPI mode 0 (CPOL = 0, CPHA = 0), not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/spi_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s spi_xchk_tb -o xchk.vvp $OIP/rtl/SPI_top.sv $OIP/rtl/SPI_apb.sv xchk/spi_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
