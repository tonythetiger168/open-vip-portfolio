// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spi_monitor.svh -- SPI monitor: decodes mode, MOSI and MISO bit streams
// from the pin waveforms and publishes reconstructed transactions.
//
// Mode decode (per frame):
//   CPOL = sclk level sampled just after CS assert (before the first edge)
//   CPHA = 1 if MOSI is still released ('z) after CS assert, else 0
// A frame whose bit count is not a multiple of 8 is reported as a
// CS-aborted frame (cs_aborted=1), matching the driver's error injection.

`ifndef SPI_MONITOR_SVH
`define SPI_MONITOR_SVH

class spi_monitor extends uvm_monitor;
  `uvm_component_utils(spi_monitor)
  virtual spi_if vif;
  uvm_analysis_port #(spi_transaction) ap;
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual spi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spi virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    forever begin
      spi_transaction tr;
      bit             cpol, cpha;
      bit [31:0]      tx, rx;
      int unsigned    nbits;

      @(negedge vif.cs_n);
      if (vif.rst_n !== 1'b1) continue;

      // let the pre-load settle, then decode CPOL/CPHA from the pins
      repeat (2) @(vif.mon_cb);
      cpol = vif.sclk;
      cpha = (vif.mosi === 1'bz);

      tr = spi_transaction::type_id::create("tr");
      tr.mode = {cpol, cpha};
      tx = 32'h0; rx = 32'h0; nbits = 0;

      fork
        begin : sample_bits
          forever begin
            bit leading;
            @(vif.sclk);
            leading = (vif.sclk !== cpol);
            if (leading == !cpha) begin      // sample edge for this mode
              tx = {tx[30:0], vif.mosi};
              rx = {rx[30:0], vif.miso};
              nbits++;
            end
          end
        end
        begin : fsm_track
          spi_state_e last = vif.state;
          tr.fsm_states.push_back(last);
          forever begin
            @(vif.mon_cb);
            if (vif.mon_cb.state !== last) begin
              tr.fsm_states.push_back(vif.mon_cb.state);
              last = vif.mon_cb.state;
            end
          end
        end
        begin : cs_watch
          @(posedge vif.cs_n);
        end
      join_any
      disable fork;

      tr.tx_data    = tx;
      tr.rx_data    = rx;
      tr.num_bits   = nbits;
      tr.cs_aborted = (nbits % 8 != 0);
      txn_count++;
      `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
      ap.write(tr);
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("spi monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
