// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spi_sequences.svh -- SPI sequence library

`ifndef SPI_SEQUENCES_SVH
`define SPI_SEQUENCES_SVH

class spi_base_sequence extends uvm_sequence #(spi_transaction);
  `uvm_object_utils(spi_base_sequence)
  int num_txns = 20;
  function new(string name = "spi_base_sequence"); super.new(name); endfunction
  task body();
    spi_transaction tr;
    repeat (num_txns) begin
      tr = spi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: mode-0 single-byte writes with corner MOSI patterns
class spi_write_seq extends spi_base_sequence;
  function new(string name = "spi_write_seq"); super.new(name); endfunction
  `uvm_object_utils(spi_write_seq)
  task body();
    spi_transaction tr;
    bit [7:0] corners[$] = '{8'h00, 8'hFF, 8'hAA, 8'h55, 8'h01, 8'h80};
    foreach (corners[i]) begin
      tr = spi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { mode == 2'b00; num_bits == 8;
                                  tx_data == corners[i]; abort_cs == 0; });
      finish_item(tr);
    end
    repeat (num_txns) begin
      tr = spi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { mode == 2'b00; num_bits == 8; abort_cs == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: MOSI held at 0x00 to clock out the MISO loopback (read)
class spi_read_seq extends spi_base_sequence;
  function new(string name = "spi_read_seq"); super.new(name); endfunction
  `uvm_object_utils(spi_read_seq)
  task body();
    spi_transaction tr;
    repeat (num_txns) begin
      tr = spi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { num_bits == 8; tx_data == 32'h0; abort_cs == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: multi-byte burst frames (16/24/32-bit)
class spi_burst_seq extends spi_base_sequence;
  function new(string name = "spi_burst_seq"); super.new(name); endfunction
  `uvm_object_utils(spi_burst_seq)
  task body();
    spi_transaction tr;
    repeat (num_txns) begin
      tr = spi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { num_bits inside {16, 24, 32}; abort_cs == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back frames with minimal CS gap
class spi_back_to_back_seq extends spi_base_sequence;
  function new(string name = "spi_back_to_back_seq"); super.new(name); endfunction
  `uvm_object_utils(spi_back_to_back_seq)
  task body();
    spi_transaction tr;
    repeat (num_txns) begin
      tr = spi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { num_bits == 8; gap_cycles == 0; abort_cs == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: sweep all four SPI modes (CPOL/CPHA)
class spi_mode_sweep_seq extends spi_base_sequence;
  function new(string name = "spi_mode_sweep_seq"); super.new(name); endfunction
  `uvm_object_utils(spi_mode_sweep_seq)
  task body();
    spi_transaction tr;
    for (int m = 0; m < 4; m++) begin
      repeat (num_txns / 2 + 1) begin
        tr = spi_transaction::type_id::create("tr");
        start_item(tr);
        void'(tr.randomize() with { mode == m[1:0]; num_bits == 8; abort_cs == 0; });
        finish_item(tr);
      end
    end
  endtask
endclass

// Error injection: mid-frame CS abort
class spi_error_inject_seq extends spi_base_sequence;
  function new(string name = "spi_error_inject_seq"); super.new(name); endfunction
  `uvm_object_utils(spi_error_inject_seq)
  task body();
    spi_transaction tr;
    repeat (num_txns) begin
      tr = spi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { abort_cs == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single transfer attempted right after reset release
class spi_reset_seq extends spi_base_sequence;
  function new(string name = "spi_reset_seq"); super.new(name); endfunction
  `uvm_object_utils(spi_reset_seq)
  task body();
    spi_transaction tr = spi_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { num_bits == 8; abort_cs == 0; });
    finish_item(tr);
  endtask
endclass

class spi_random_sequence extends spi_base_sequence;
  `uvm_object_utils(spi_random_sequence)
  function new(string name = "spi_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class spi_regression_sequence extends spi_base_sequence;
  `uvm_object_utils(spi_regression_sequence)
  function new(string name = "spi_regression_sequence"); super.new(name); endfunction
  task body();
    spi_write_seq        wr  = spi_write_seq::type_id::create("wr");
    spi_read_seq         rd  = spi_read_seq::type_id::create("rd");
    spi_burst_seq        br  = spi_burst_seq::type_id::create("br");
    spi_back_to_back_seq b2b = spi_back_to_back_seq::type_id::create("b2b");
    spi_mode_sweep_seq   ms  = spi_mode_sweep_seq::type_id::create("ms");
    spi_error_inject_seq err = spi_error_inject_seq::type_id::create("err");
    spi_random_sequence  rnd = spi_random_sequence::type_id::create("rnd");
    wr.num_txns = 10; rd.num_txns = 10; br.num_txns = 10; b2b.num_txns = 10;
    ms.num_txns = 8;  err.num_txns = 10; rnd.num_txns = 30;
    wr.start(m_sequencer);  rd.start(m_sequencer);
    br.start(m_sequencer);  b2b.start(m_sequencer);
    ms.start(m_sequencer);  err.start(m_sequencer);
    rnd.start(m_sequencer);
  endtask
endclass
`endif
