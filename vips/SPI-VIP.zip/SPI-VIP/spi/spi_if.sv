// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// spi_if.sv -- SPI interface (master/slave modports, mode 0-3 capable)
//
// The VIP driver acts as the SPI master and drives sclk/cs_n/mosi.
// The DUT (SPI slave model in tb/top_tb.sv) drives miso while CS is low
// and releases it to 'z between frames. mosi is released to 'z while CS
// is high so that CPHA can be decoded unambiguously from the waveform.

interface spi_if (input logic clk);
  import spi_defs_pkg::spi_state_e;

  logic rst_n;

  logic sclk = 1'b0;
  logic cs_n = 1'b1;
  logic mosi = 1'bz;
  logic miso = 1'bz;

  spi_state_e state;

  modport MASTER (input  clk, rst_n, miso,
                  output sclk, cs_n, mosi, state);
  modport SLAVE  (input  clk, rst_n, sclk, cs_n, mosi,
                  output miso);
  modport MON    (input  clk, rst_n, sclk, cs_n, mosi, miso, state);

  clocking drv_cb @(posedge clk);
    input  miso, rst_n;
    output sclk, cs_n, mosi;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, sclk, cs_n, mosi, miso, state;
  endclocking
endinterface
