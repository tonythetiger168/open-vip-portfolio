// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spi_driver.svh -- SPI master driver (bit-banged, modes 0-3)
//
// Drives one CS-framed full-duplex transfer per sequence item:
//   - sclk idle level = CPOL, re-leveled at CS assert so the clock never
//     moves while CS is high
//   - CPHA=0: MOSI pre-loaded before the first edge, sampled on leading
//     edges, shifted on trailing edges
//   - CPHA=1: MOSI shifted on leading edges, sampled on trailing edges
//   - MISO is sampled into tr.rx_data at every sample edge (full duplex)
//   - abort_cs raises CS mid-frame (CS abort error injection)
// The expected transaction is broadcast on drv_ap before item_done().

`ifndef SPI_DRIVER_SVH
`define SPI_DRIVER_SVH

class spi_driver extends uvm_driver #(spi_transaction);
  `uvm_component_utils(spi_driver)
  virtual spi_if vif;
  spi_config cfg;
  uvm_analysis_port #(spi_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual spi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spi virtual interface not set")
  endfunction

  // One full CS frame: shift tx_data out MSB-first, sample MISO into rx_data.
  task automatic drive_frame(spi_transaction tr);
    bit          cpol  = tr.mode[1];
    bit          cpha  = tr.mode[0];
    int unsigned th    = tr.t_half;
    int unsigned nbits = tr.num_bits;
    bit [31:0]   rx    = 32'h0;
    int unsigned done  = 0;

    // inter-frame gap: sclk stays parked (never moves while CS is high);
    // it is re-leveled to the new CPOL only at the CS-assert boundary
    repeat (tr.gap_cycles) @(vif.drv_cb);

    // CS assert; pre-load MOSI msb for CPHA=0
    vif.state = spi_defs_pkg::CS_ASSERT;
    vif.drv_cb.cs_n <= 1'b0;
    vif.drv_cb.sclk <= cpol;                 // re-level at CS boundary only
    if (!cpha) vif.drv_cb.mosi <= tr.tx_data[nbits-1];
    repeat (th) @(vif.drv_cb);

    vif.state = spi_defs_pkg::SHIFT;
    for (int i = nbits-1; i >= 0; i--) begin
      if (cpha) begin
        // leading edge: shift data out; trailing edge: sample
        vif.drv_cb.mosi <= tr.tx_data[i];
        vif.drv_cb.sclk <= ~cpol;
        repeat (th) @(vif.drv_cb);
        vif.drv_cb.sclk <= cpol;
        repeat (th) @(vif.drv_cb);
        rx[i] = vif.miso;
      end else begin
        // leading edge: sample; trailing edge: shift next bit out
        vif.drv_cb.sclk <= ~cpol;
        repeat (th) @(vif.drv_cb);
        rx[i] = vif.miso;
        vif.drv_cb.sclk <= cpol;
        if (i > 0) vif.drv_cb.mosi <= tr.tx_data[i-1];
        repeat (th) @(vif.drv_cb);
      end
      done++;
      if (tr.abort_cs && done == tr.abort_after) begin
        `uvm_warning("DRV", $sformatf("injecting CS abort after %0d bits", done))
        break;
      end
    end

    tr.rx_data     = rx;
    tr.cs_aborted  = (tr.abort_cs && done < nbits);
    if (tr.cs_aborted) begin
      // re-align observed payloads to the bits actually transferred
      tr.tx_data  = tr.tx_data >> (nbits - done);
      tr.rx_data  = (done == 0) ? 32'h0 : (rx >> (nbits - done));
      tr.num_bits = done;
    end

    // CS deassert; release MOSI so CPHA is decodable on the next frame
    vif.drv_cb.sclk <= cpol;
    vif.drv_cb.cs_n <= 1'b1;
    vif.drv_cb.mosi <= 1'bz;
    vif.state = spi_defs_pkg::CS_DEASSERT;
    repeat (th) @(vif.drv_cb);
    vif.state = spi_defs_pkg::IDLE;
  endtask

  task run_phase(uvm_phase phase);
    spi_transaction tr;
    vif.drv_cb.sclk <= 1'b0;
    vif.drv_cb.cs_n <= 1'b1;
    vif.drv_cb.mosi <= 1'bz;
    vif.state = spi_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      drive_frame(tr);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
