// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spi_coverage.svh -- SPI functional coverage

`ifndef SPI_COVERAGE_SVH
`define SPI_COVERAGE_SVH

class spi_coverage extends uvm_subscriber #(spi_transaction);
  `uvm_component_utils(spi_coverage)

  spi_transaction tr;

  covergroup cg_protocol;
    cp_mode : coverpoint tr.mode {
      bins mode0 = {2'b00};
      bins mode1 = {2'b01};
      bins mode2 = {2'b10};
      bins mode3 = {2'b11};
    }
    cp_nbits : coverpoint tr.num_bits {
      bins w8  = {8};
      bins w16 = {16};
      bins w24 = {24};
      bins w32 = {32};
    }
    cp_tx : coverpoint tr.tx_data[7:0] {
      bins zero   = {8'h00};
      bins ones   = {8'hFF};
      bins alt10  = {8'hAA};
      bins alt01  = {8'h55};
      bins others = default;
    }
    cx_mode_nbits : cross cp_mode, cp_nbits;
  endgroup

  covergroup cg_fsm with function sample(spi_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, CS_ASSERT, SHIFT, CS_DEASSERT};
    }
    cp_trans : coverpoint s {
      bins frame_seq = (IDLE => CS_ASSERT => SHIFT => CS_DEASSERT => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_abort : coverpoint tr.cs_aborted {
      bins complete = {0};
      bins aborted  = {1};
    }
    cp_mode : coverpoint tr.mode { bins m[] = {[0:3]}; }
    cx_abort_mode : cross cp_abort, cp_mode;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(spi_transaction t);
    tr = t;
    cg_protocol.sample();
    foreach (t.fsm_states[i]) cg_fsm.sample(t.fsm_states[i]);
    cg_error.sample();
  endfunction
endclass
`endif
