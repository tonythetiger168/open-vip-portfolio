// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spi_transaction.svh -- SPI transaction (one CS frame, MSB-first full duplex)
//
// One transaction = one CS-low frame of num_bits sclk clocks.
//   mode        : {CPOL, CPHA} -- SPI modes 0..3
//   tx_data     : MOSI bits, right-aligned (bit[num_bits-1] shifted first)
//   rx_data     : MISO bits sampled by the driver, right-aligned
//   num_bits    : frame width in sclk clocks (multiple of 8)
//   abort_cs    : error injection -- raise CS after abort_after bits
//   cs_aborted  : set by driver/monitor when the frame ended mid-byte

`ifndef SPI_TRANSACTION_SVH
`define SPI_TRANSACTION_SVH

class spi_transaction extends uvm_sequence_item;

  rand bit [1:0]      mode;         // mode[1]=CPOL, mode[0]=CPHA
  rand bit [31:0]     tx_data;      // MOSI payload (right-aligned)
  rand int unsigned   num_bits;     // frame width: 8N sclk clocks
  rand int unsigned   t_half;       // half sclk period, in ref-clk cycles
  rand int unsigned   gap_cycles;   // idle cycles before CS assert
  rand bit            abort_cs;     // error injection: mid-frame CS abort
  rand int unsigned   abort_after;  // abort after this many shifted bits

  bit [31:0]          rx_data;      // MISO payload (driver/monitor sampled)
  bit                 cs_aborted;   // frame was aborted mid-byte
  spi_state_e         fsm_states[$];// FSM states observed during the frame

  constraint c_nbits { num_bits inside {8, 16, 24, 32}; }
  constraint c_tx    { (num_bits == 32) || (tx_data < (1 << num_bits)); }
  constraint c_thalf { t_half inside {[4:8]}; }
  constraint c_gap   { gap_cycles inside {[0:16]}; }
  constraint c_abort {
    abort_cs dist {0 := 9, 1 := 1};
    abort_after inside {[1:7]};
    abort_cs -> num_bits == 8;
  }

  `uvm_object_utils_begin(spi_transaction)
    `uvm_field_int(mode, UVM_ALL_ON)
    `uvm_field_int(tx_data, UVM_ALL_ON)
    `uvm_field_int(rx_data, UVM_ALL_ON)
    `uvm_field_int(num_bits, UVM_ALL_ON)
    `uvm_field_int(t_half, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(gap_cycles, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(abort_cs, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(cs_aborted, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "spi_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    spi_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= (comparer.compare_field("mode",       mode,       t.mode,       2) == 1);
    do_compare &= (comparer.compare_field("num_bits",   num_bits,   t.num_bits,   32) == 1);
    do_compare &= (comparer.compare_field("tx_data",    tx_data,    t.tx_data,    32) == 1);
    do_compare &= (comparer.compare_field("cs_aborted", cs_aborted, t.cs_aborted, 1) == 1);
  endfunction

  function string convert2string();
    return $sformatf("SPI mode=%0d(CPOL=%0b,CPHA=%0b) nbits=%0d tx=0x%08h rx=0x%08h%s",
                     mode, mode[1], mode[0], num_bits, tx_data, rx_data,
                     cs_aborted ? " CS-ABORT" : "");
  endfunction
endclass
`endif
