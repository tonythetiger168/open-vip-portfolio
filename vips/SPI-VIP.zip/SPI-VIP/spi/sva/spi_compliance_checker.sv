// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// spi_compliance_checker.sv -- SPI SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = SPI-specific pin-level rules (sclk/cs_n/mosi)

`ifndef SPI_COMPLIANCE_CHECKER_SV
`define SPI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import spi_defs_pkg::*;

module spi_compliance_checker
(
  input logic clk,
  input logic rst_n,
  input spi_state_e state,
  input logic sclk,
  input logic cs_n,
  input logic mosi,
  input logic miso
);

  // ---------------- L1: signal sanity (4) ----------------
  a_spi_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "spi: clock unknown")
  a_spi_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "spi: reset unknown")
  a_spi_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "spi: state unknown")
  a_spi_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, CS_ASSERT, SHIFT, CS_DEASSERT})
    else `uvm_error("SVA_L1", "spi: state outside legal encoding")

  // ---------------- L2: FSM legality (4) ----------------
  // L2-1: legal FSM transition from IDLE
  a_spi_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, CS_ASSERT})
    else `uvm_error("SVA_L2", "spi: illegal transition from IDLE")

  // L2-2: legal FSM transition from CS_ASSERT
  a_spi_trans_cs_assert : assert property (@(posedge clk) disable iff (!rst_n)
    state == CS_ASSERT |=> state inside {CS_ASSERT, SHIFT})
    else `uvm_error("SVA_L2", "spi: illegal transition from CS_ASSERT")

  // L2-3: legal FSM transition from SHIFT
  a_spi_trans_shift : assert property (@(posedge clk) disable iff (!rst_n)
    state == SHIFT |=> state inside {SHIFT, CS_DEASSERT})
    else `uvm_error("SVA_L2", "spi: illegal transition from SHIFT")

  // L2-4: legal FSM transition from CS_DEASSERT
  a_spi_trans_cs_deassert : assert property (@(posedge clk) disable iff (!rst_n)
    state == CS_DEASSERT |=> state inside {CS_DEASSERT, IDLE})
    else `uvm_error("SVA_L2", "spi: illegal transition from CS_DEASSERT")

  // ---------------- L3: protocol rules (4) ----------------
  a_spi_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "spi: state not IDLE during reset")
  a_spi_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == CS_DEASSERT |-> ##[1:8] (state != CS_DEASSERT))
    else `uvm_error("SVA_L3", "spi: stuck in CS_DEASSERT")
  a_spi_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == CS_ASSERT);
  a_spi_l3_back_idle  : cover property (@(posedge clk) disable iff (!rst_n)
    state == CS_DEASSERT ##1 state == IDLE);

  // ---------------- L4: SPI protocol-specific rules (4) ----------------
  // L4-1: sclk only toggles while CS is low (parked at idle level otherwise)
  a_spi_l4_clk_in_frame : assert property (@(posedge clk) disable iff (!rst_n)
    cs_n |-> $stable(sclk))
    else `uvm_error("SVA_L4", "spi: sclk moved while CS high")

  // L4-2: MOSI changes only on an sclk edge or a CS boundary (never mid-bit)
  a_spi_l4_mosi_edge : assert property (@(posedge clk) disable iff (!rst_n)
    $changed(mosi) |-> ($changed(sclk) || $changed(cs_n)))
    else `uvm_error("SVA_L4", "spi: MOSI changed away from a clock/CS edge")

  // L4-3: while CS is high no frame is in progress (MOSI activity is not a frame)
  a_spi_l4_cs_high_no_frame : assert property (@(posedge clk) disable iff (!rst_n)
    cs_n |-> state inside {IDLE, CS_DEASSERT})
    else `uvm_error("SVA_L4", "spi: frame state active while CS high")

  // L4-4: every frame contains a multiple of 8 sclk clocks (16N edges)
  int unsigned sclk_edges = 0;
  logic        sclk_q = 1'b0, cs_n_q = 1'b1;
  always @(sclk or cs_n) begin
    if (cs_n === 1'b1) sclk_edges <= 0;              // idle / frame end: reset
    else if (cs_n_q === 1'b1) ;                      // CS just fell: sync only
    else if (sclk !== sclk_q) sclk_edges <= sclk_edges + 1;
    sclk_q <= sclk;
    cs_n_q <= cs_n;
  end
  a_spi_l4_frame_8n : assert property (@(posedge cs_n) disable iff (!rst_n)
    (sclk_edges % 16) == 0)
    else `uvm_error("SVA_L4", "spi: frame clock count is not a multiple of 8")

endmodule
`endif
