// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- SPI testbench top with a functional SPI slave DUT model

`ifndef SPI_TB_SV
`define SPI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import spi_defs_pkg::*;
import spi_pkg::*;
import spi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  spi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  spi_slave_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual spi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional SPI slave (modes 0-3): decodes CPOL/CPHA from the waveform,
// receives MOSI bytes during each CS frame and returns them on MISO during
// the next complete frame (byte loopback). Aborted (mid-byte) frames are
// discarded and do not disturb the loopback queue. MISO is released to 'z
// while CS is high.
module spi_slave_model (spi_if vif);
  bit [7:0]    lb_q[$];     // bytes received in the previous complete frame
  bit [7:0]    cur_q[$];    // bytes received in the current frame
  bit [7:0]    tx_q[$];     // snapshot of lb_q being shifted out this frame
  bit [7:0]    tx_byte;     // current shift-out byte
  int unsigned obit;        // shift-out bit index
  bit [7:0]    rx_shift;    // current receive byte assembly
  int unsigned ibit;        // received bit count this frame
  bit          miso_drv;    // MISO data driven while CS is low
  bit          miso_oe = 0; // MISO output enable (released to 'z when 0)

  // tri-state MISO via continuous assign (procedural drive of 'z is not
  // portable across simulators)
  assign vif.miso = miso_oe ? miso_drv : 1'bz;

  // iverilog cannot index queues with a variable: pop from a per-frame
  // snapshot copy instead of indexing lb_q[byte_idx].
  function automatic bit next_miso_bit();
    bit r;
    if (obit % 8 == 0)
      tx_byte = (tx_q.size() > 0) ? tx_q.pop_front() : 8'h00;
    r = tx_byte[7 - (obit % 8)];
    obit++;
    return r;
  endfunction

  initial forever begin
    bit cpol, cpha;
    @(negedge vif.cs_n);
    if (vif.rst_n === 1'b1) begin

    // decode CPOL/CPHA: CPOL = idle sclk level; CPHA=1 if MOSI not pre-loaded
    repeat (2) @(posedge vif.clk);
    cpol = vif.sclk;
    cpha = (vif.mosi === 1'bz);

    obit = 0; ibit = 0; rx_shift = 8'h00; cur_q.delete();
    // snapshot lb_q into tx_q by rotation (iverilog cannot copy queues)
    tx_q.delete();
    for (int n = lb_q.size(); n > 0; n--) begin
      bit [7:0] b;
      b = lb_q.pop_front();
      lb_q.push_back(b);
      tx_q.push_back(b);
    end
    if (!cpha) begin miso_oe = 1; miso_drv = next_miso_bit(); end   // pre-load msb for CPHA=0

    // shift loop runs until CS rises (no fork/disable fork: single thread
    // waits on sclk edges or CS deassertion)
    while (vif.cs_n === 1'b0) begin
      bit leading;
      @(vif.sclk or posedge vif.cs_n);
      if (vif.cs_n === 1'b0) begin
        leading = (vif.sclk !== cpol);
        if (leading == !cpha) begin        // sample edge: shift MOSI in
          rx_shift = {rx_shift[6:0], vif.mosi};
          ibit++;
          if (ibit % 8 == 0) begin
            cur_q.push_back(rx_shift);
            rx_shift = 8'h00;
          end
        end else begin                     // shift edge: drive next MISO bit
          miso_oe  = 1;
          miso_drv = next_miso_bit();
        end
      end
    end

    miso_oe = 1'b0;                    // release MISO to 'z
    // only complete (byte-aligned) frames update the loopback queue
    if (ibit > 0 && ibit % 8 == 0) lb_q = cur_q;
    end
  end
endmodule
`endif
