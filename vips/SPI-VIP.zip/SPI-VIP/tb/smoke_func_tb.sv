// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2025 Functional smoke testbench (SPI mode-0 loopback frames)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened spi_slave_model.
// DUT behaviour (from dut_spi_slave_model.sv):
//   - frame = CS low; CPOL/CPHA decoded from idle sclk / mosi preload
//   - MOSI sampled on leading edge, MISO shifted on trailing edge
//   - MISO shifts out the bytes received during the *previous* complete
//     frame (one-frame loopback delay); short/empty snapshots pad 8'h00
//   - MISO is released to 'z when CS is high
// This tb is a mode-0 (CPOL=0, CPHA=0) master: MOSI is always driven
// (never 'z), so the slave detects CPHA=0 and pre-loads the MISO MSB.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic vif_clk   = 1'b0;
  logic vif_rst_n = 1'b0;
  logic vif_sclk  = 1'b0;   // CPOL=0 idle
  logic vif_cs_n  = 1'b1;
  logic vif_mosi  = 1'b0;
  wire  vif_miso;           // tri-stated by slave when CS high

  always #5 vif_clk = ~vif_clk;

  spi_slave_model u_dut (
    .vif_clk(vif_clk), .vif_rst_n(vif_rst_n), .vif_sclk(vif_sclk),
    .vif_cs_n(vif_cs_n), .vif_mosi(vif_mosi), .vif_miso(vif_miso)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic cs_assert();
    vif_cs_n = 1'b0;
    repeat (4) @(posedge vif_clk);   // slave decodes CPOL/CPHA in 2 clk
  endtask

  task automatic cs_release();
    repeat (4) @(posedge vif_clk);
    vif_cs_n = 1'b1;
    repeat (4) @(posedge vif_clk);
  endtask

  // mode-0 byte transfer: MOSI set up before rising edge, MISO sampled
  // just before the rising edge (stable since the last falling edge)
  task automatic spi_byte(input bit [7:0] mosi_b, output bit [7:0] miso_b);
    for (int i = 7; i >= 0; i--) begin
      vif_mosi = mosi_b[i];
      repeat (4) @(posedge vif_clk);
      miso_b[i] = vif_miso;
      vif_sclk = 1'b1;
      repeat (4) @(posedge vif_clk);
      vif_sclk = 1'b0;
    end
  endtask

  bit [7:0] r0, r1;

  initial begin
    repeat (8) @(posedge vif_clk);
    vif_rst_n = 1'b1;
    repeat (4) @(posedge vif_clk);

    chk(vif_miso === 1'bz, "MISO tri-stated while CS high (idle)");

    // frame 1: loopback queue empty -> MISO returns 0x00
    cs_assert();
    spi_byte(8'hA5, r0);
    cs_release();
    chk(r0 === 8'h00, "frame 1 MISO = 0x00 (empty loopback)");
    chk(vif_miso === 1'bz, "MISO released after frame 1");

    // frame 2: MISO echoes frame 1's byte
    cs_assert();
    spi_byte(8'h3C, r0);
    cs_release();
    chk(r0 === 8'hA5, "frame 2 MISO = 0xA5 (echo of frame 1)");

    // frame 3: two bytes; only one byte queued from frame 2 -> 0x3C, 0x00
    cs_assert();
    spi_byte(8'h11, r0);
    spi_byte(8'h22, r1);
    cs_release();
    chk(r0 === 8'h3C, "frame 3 byte 0 = 0x3C (echo of frame 2)");
    chk(r1 === 8'h00, "frame 3 byte 1 = 0x00 (queue drained)");

    // frame 4: two-byte echo of frame 3, in order
    cs_assert();
    spi_byte(8'h99, r0);
    spi_byte(8'h88, r1);
    cs_release();
    chk(r0 === 8'h11 && r1 === 8'h22, "frame 4 echoes both bytes of frame 3");
    chk(vif_miso === 1'bz, "MISO released after final frame");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  // safety timeout
  initial begin
    #300000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
