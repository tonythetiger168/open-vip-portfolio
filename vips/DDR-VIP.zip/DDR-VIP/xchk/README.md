# Independent cross-check model (`xchk/`)

`ddr_xchk_tb.sv` checks the open-ip-portfolio `DDR4_Lite` RTL (`rtl/DDR4_Lite_top.sv`)
against ddr_pin_mon.sv on the DRAM pins: the JESD79-4 command truth table, timing rules, burst latency, data against a shadow array, refresh intervals. The model is written from JEDEC JESD79-4 (DDR4), not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/ddr_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s ddr_xchk_tb -o xchk.vvp $OIP/rtl/DDR4_Lite_top.sv xchk/ddr_pin_mon.sv xchk/ddr_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
