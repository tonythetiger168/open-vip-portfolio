# DDR UVM VIP

**Protocol:** DDR4/DDR5 SDRAM
**License:** Apache-2.0

## 1. Protocol Overview

DDR4/DDR5 SDRAM VIP. Commands are encoded on cs_n/act_n/ras_n/cas_n/we_n with bank-group/bank addressing; the driver issues ACT/RD/WR/PRE/REF/MRS/ZQC with JEDEC-style timing.

Timing parameters (cycles): tRCD=15, tRP=15, tRAS=35,
tCL=15, tCWL=14, tFAW=20, tRFC=50.

## 2. Architecture

```
interfaces/memory_interfaces.sv   9 memory protocol interfaces (ddr_if is the DUT-side bus)
ddr/ddr_pkg.sv                    DDR VIP package:
    ddr_seq_item                  transaction (cmd/addr/bank/data + page_hit/bstate)
    ddr_cfg                       timing + mode configuration
    ddr_sequencer / ddr_driver    command driver (timing-accurate, drv_ap broadcast)
    ddr_monitor                   CA-bus command decoder (analysis port)
    ddr_agent                     sequencer + driver + monitor
    sequences                     directed library (below)
coverage/memory_coverage_pkg.sv   DDR functional coverage (3 covergroups + crosses)
env/memory_env_pkg.sv             memory_env_cfg / memory_scoreboard / memory_env
                                  end-to-end: driver drv_ap (expected) vs
                                  monitor item_collected_port (observed),
                                  n_matches/n_mismatches, UVM_ERROR on mismatch
env/vip/ddr/ddr_*_checker.sv      legacy L1/L2/L3 SVA checkers (module-based)
env/sva/ddr_compliance_checker.sv consolidated L1-L4 compliance checker
test/memory_test_pkg.sv           memory_base_test / memory_directed_test /
                                  memory_coverage_regression_test
tb_top.sv                         testbench top: 9 protocol interfaces, DDR DRAM
                                  memory model (bank/row/col storage + refresh
                                  counter), SVA checker instantiation
```

The `tb_top.sv` DRAM model tracks bank/row state, stores write data in a
sparse `{bank,row,col}` array, returns it on reads after tCL, and counts
refreshes -- closing the end-to-end data loop.

## 3. Sequence Library

| `ddr_base_seq`          | randomized legal ACT->RD/WR->PRE rounds |
| `ddr_rw_seq`            | legacy random R/W mix (kept API) |
| `ddr_write_seq`         | directed write rounds |
| `ddr_read_seq`          | directed read rounds |
| `ddr_refresh_seq`       | refresh traffic |
| `ddr_bank_conflict_seq` | same-bank ACT/PRE turnaround (tRP/tRCD pressure) |
| `ddr_back_to_back_seq`  | inter-bank back-to-back accesses |
| `ddr_page_hit_seq`      | corner: multiple accesses to one open row |
| `ddr_page_miss_seq`     | corner: every access forces PRE+ACT |
| `ddr_stress_seq`        | long randomized legal mix |
| `ddr_regression_seq`    | weighted mix of all directed sequences |

Legacy coverage sequences: `ddr_cov_cmd_seq`, `ddr_cov_bank_seq`, `{p}_cov_bl_seq`.

## 4. SVA Checkers (L1-L4)

Legacy tiered checkers (module-based, `env/vip/ddr/`):
- `ddr_protocol_checker` (L1: basic compliance)
- `ddr_timing_checker` (L2: timing windows)
- `ddr_data_integrity_checker` (L2/L3: data rules)
- `ddr_error_checker` (L3: error conditions)

Consolidated `ddr_compliance_checker` keeps the tiered L1/L2/L3 rule sets with
pass/fail counters and adds:
- **L4 (6):** tRCD (ACT->CAS), tRAS (ACT->PRE), tFAW (<=4 ACT/window),
  RD/WR only to open bank, no ACT to an already-open bank,
  refresh interval (tREFI) -- plus ACT->CAS / full-cycle covers.

## 5. Functional Coverage

- `ddr_cmd_cg`        : command distribution x bank geometry (crosses)
- `ddr_bank_state_cg` : bank state transitions (IDLE/ACTIVE) x command (cross)
- `ddr_addr_cg`       : row regions, page hit/miss x command (cross)

## 6. Quick Start

```bash
# Portable multi-simulator flow (VCS / Xcelium / Questa)
make -C scripts SIMULATOR=vcs TEST=memory_directed_test
# or use the wrapper
./run.sh TESTNAME=memory_directed_test
```

Tests: `memory_base_test` (default), `memory_directed_test`,
`memory_coverage_regression_test`.
