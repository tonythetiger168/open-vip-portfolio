// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// DDR4/DDR5 UVM VIP Package
// Deepened: timing-accurate command driver (tRCD/tRP/tRAS/tFAW), bus-decoding
// monitor with bank/page tracking, directed sequence library.
//------------------------------------------------------------------------------
package ddr_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // Bank state tracked by the monitor, sampled by functional coverage
  typedef enum {B_IDLE, B_ACTIVE} bank_state_e;

  //==========================================================================
  // DDR Sequence Item
  //==========================================================================
  class ddr_seq_item extends uvm_sequence_item;
    `uvm_object_utils(ddr_seq_item)
    typedef enum {ACT, READ, WRITE, PRE, REF, NOP, MRS, ZQC} cmd_type_e;
    rand cmd_type_e cmd_type;
    rand bit [16:0] addr;
    rand bit [2:0]  bank;
    rand bit [1:0]  bank_group;
    rand bit [63:0] data[];
    rand bit [7:0]  dm;
    rand bit [7:0]  burst_len;
    bit [63:0]      rdata[];
    bit             ready;
    // DDR5 specific
    rand bit        ca_par;   // Command/Address parity
    rand bit        dm_dbi;   // Data mask / Data bus inversion
    // filled in by the monitor
    bit             page_hit;
    bank_state_e    bstate;

    constraint c_addr_align { addr[2:0] == 3'b000; }
    constraint c_burst_len { burst_len inside {8, 16}; }
    constraint c_data_size { data.size() == burst_len; rdata.size() == burst_len; }
    constraint c_cmd_dist { cmd_type dist {ACT := 10, READ := 30, WRITE := 30,
                                           PRE := 10, REF := 5, NOP := 10,
                                           MRS := 3, ZQC := 2}; }
    function new(string name = "ddr_seq_item");
      super.new(name);
    endfunction
    function string convert2string();
      return $sformatf("DDR %s: bank=%0d bg=%0d addr=0x%0h bl=%0d",
                       cmd_type.name(), bank, bank_group, addr, burst_len);
    endfunction
  endclass : ddr_seq_item

  //==========================================================================
  // DDR Configuration
  //==========================================================================
  class ddr_cfg extends uvm_object;
    `uvm_object_utils(ddr_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1;
    int tRCD = 15;
    int tRP  = 15;
    int tRAS = 35;
    int tRC  = 50;
    int tCL  = 15;
    int tCWL = 14;
    int tRRD = 4;
    int tFAW = 20;
    int tWR  = 15;
    int tRTP = 8;
    int tWTR = 8;
    function new(string name = "ddr_cfg");
      super.new(name);
    endfunction
  endclass : ddr_cfg

  //==========================================================================
  // DDR Sequencer
  //==========================================================================
  class ddr_sequencer extends uvm_sequencer #(ddr_seq_item);
    `uvm_component_utils(ddr_sequencer)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
  endclass : ddr_sequencer

  //==========================================================================
  // DDR Driver -- drives real DRAM command sequences on ddr_if:
  // ACT (row), RD/WR (column), PRE, REF with tRCD/tRP/tRAS/tFAW timing,
  // plus expected-transaction broadcast for the scoreboard.
  //==========================================================================
  class ddr_driver extends uvm_driver #(ddr_seq_item);
    `uvm_component_utils(ddr_driver)
    virtual ddr_if vif;
    ddr_cfg cfg;
    uvm_analysis_port #(ddr_seq_item) drv_ap;  // expected items for scoreboard

    bit [16:0]   active_row [32];   // open row per flattened {bg,bank}
    bit          bank_active[32];
    int unsigned act_cycle  [32];
    int unsigned act_hist   [4];    // last 4 ACT cycles (tFAW window)
    int          act_hist_idx = 0;
    int unsigned cyc = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      drv_ap = new("drv_ap", this);
      foreach (bank_active[i]) bank_active[i] = 0;
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "DDR virtual interface not found")
      if (!uvm_config_db#(ddr_cfg)::get(this, "", "cfg", cfg))
        cfg = ddr_cfg::type_id::create("cfg");
    endfunction

    function int bank_id(bit [1:0] bg, bit [2:0] b);
      return bg * 8 + b;
    endfunction

    // One command cycle on the CA bus
    task drive_cmd(bit cs_n, bit act_n, bit ras_n, bit cas_n, bit we_n,
                   bit [16:0] a, bit [2:0] b, bit [1:0] g);
      vif.drv_cb.cs_n  <= cs_n;
      vif.drv_cb.act_n <= act_n;
      vif.drv_cb.ras_n <= ras_n;
      vif.drv_cb.cas_n <= cas_n;
      vif.drv_cb.we_n  <= we_n;
      vif.drv_cb.addr  <= a;
      vif.drv_cb.ba    <= b;
      vif.drv_cb.bg    <= g;
      @(vif.drv_cb);
      cyc++;
    endtask

    task idle(int n);
      vif.drv_cb.cs_n  <= 1'b1;
      vif.drv_cb.act_n <= 1'b1;
      vif.drv_cb.ras_n <= 1'b1;
      vif.drv_cb.cas_n <= 1'b1;
      vif.drv_cb.we_n  <= 1'b1;
      repeat (n) begin
        @(vif.drv_cb);
        cyc++;
      end
    endtask

    task drive_activate(ddr_seq_item item);
      int id = bank_id(item.bank_group, item.bank);
      while (cyc - act_hist[act_hist_idx] <= cfg.tFAW && act_hist[act_hist_idx] != 0)
        idle(1);                        // tFAW window
      drive_cmd(0, 0, 0, 1, 1, item.addr, item.bank, item.bank_group);
      active_row[id]  = item.addr;
      bank_active[id] = 1;
      act_cycle[id]   = cyc;
      act_hist[act_hist_idx] = cyc;
      act_hist_idx = (act_hist_idx + 1) % 4;
      idle(cfg.tRCD - 1);               // tRCD before any CAS to this bank
    endtask

    task drive_read(ddr_seq_item item);
      int id = bank_id(item.bank_group, item.bank);
      if (!bank_active[id])
        `uvm_warning(get_type_name(),
          $sformatf("RD to closed bank bg=%0d ba=%0d", item.bank_group, item.bank))
      drive_cmd(0, 1, 1, 0, 1, item.addr, item.bank, item.bank_group);
      idle(cfg.tCL);                    // CAS latency
      item.rdata = new[item.burst_len];
      for (int i = 0; i < item.burst_len; i++) begin
        @(vif.drv_cb);
        cyc++;
        item.rdata[i] = vif.drv_cb.dq;  // sample read data burst
      end
    endtask

    task drive_write(ddr_seq_item item);
      int id = bank_id(item.bank_group, item.bank);
      if (!bank_active[id])
        `uvm_warning(get_type_name(),
          $sformatf("WR to closed bank bg=%0d ba=%0d", item.bank_group, item.bank))
      drive_cmd(0, 1, 1, 0, 0, item.addr, item.bank, item.bank_group);
      idle(cfg.tCWL - 1);               // CAS write latency
      for (int i = 0; i < item.burst_len; i++) begin
        vif.drv_cb.dq <= item.data[i];
        vif.drv_cb.dm <= item.dm;
        @(vif.drv_cb);
        cyc++;
      end
    endtask

    task drive_precharge(ddr_seq_item item);
      int id = bank_id(item.bank_group, item.bank);
      while (cyc - act_cycle[id] < cfg.tRAS)
        idle(1);                        // tRAS: earliest legal PRE after ACT
      drive_cmd(0, 1, 0, 1, 0, item.addr, item.bank, item.bank_group);
      bank_active[id] = 0;
      idle(cfg.tRP - 1);                // tRP before re-activation
    endtask

    task drive_refresh(ddr_seq_item item);
      foreach (bank_active[i])
        if (bank_active[i])
          `uvm_warning(get_type_name(), "REF issued with open banks")
      drive_cmd(0, 1, 0, 0, 1, item.addr, item.bank, item.bank_group);
      idle(cfg.tRC - 1);                // tRFC/tRC refresh recovery
    endtask

    task drive_mrs(ddr_seq_item item);
      drive_cmd(0, 1, 0, 0, 0, item.addr, item.bank, item.bank_group);
      idle(4);                          // tMOD
    endtask

    task drive_zqcal(ddr_seq_item item);
      drive_cmd(0, 1, 1, 1, 0, item.addr, item.bank, item.bank_group);
      idle(8);
    endtask

    task drive_nop(ddr_seq_item item);
      idle(1);
    endtask

    task run_phase(uvm_phase phase);
      idle(1);
      wait (vif.rst_n === 1'b1);
      idle(5);
      forever begin
        seq_item_port.get_next_item(req);
        `uvm_info(get_type_name(), $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
        case (req.cmd_type)
          ddr_seq_item::ACT:   drive_activate(req);
          ddr_seq_item::READ:  drive_read(req);
          ddr_seq_item::WRITE: drive_write(req);
          ddr_seq_item::PRE:   drive_precharge(req);
          ddr_seq_item::REF:   drive_refresh(req);
          ddr_seq_item::MRS:   drive_mrs(req);
          ddr_seq_item::ZQC:   drive_zqcal(req);
          ddr_seq_item::NOP:   drive_nop(req);
        endcase
        if (req.cmd_type != ddr_seq_item::NOP)
          drv_ap.write(req);            // broadcast expected transaction
        seq_item_port.item_done();
      end
    endtask
  endclass : ddr_driver

  //==========================================================================
  // DDR Monitor -- decodes commands from the CA bus waveform, tracks per-bank
  // state and page hit/miss, publishes reconstructed transactions.
  //==========================================================================
  class ddr_monitor extends uvm_monitor;
    `uvm_component_utils(ddr_monitor)
    virtual ddr_if vif;
    ddr_cfg cfg;
    uvm_analysis_port #(ddr_seq_item) item_collected_port;
    int unsigned txn_count = 0;

    protected bit        bank_active [32];
    protected bit [16:0] active_row  [32];

    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "DDR virtual interface not found")
    endfunction

    function int bank_id(bit [1:0] g, bit [2:0] b);
      return g * 8 + b;
    endfunction

    task run_phase(uvm_phase phase);
      ddr_seq_item item;
      int id;
      forever begin
        @(vif.mon_cb);
        if (vif.rst_n !== 1'b1) begin
          foreach (bank_active[i]) bank_active[i] = 0;
          continue;
        end
        if (vif.mon_cb.cs_n) continue;  // deselect
        item = ddr_seq_item::type_id::create("item");
        // Decode command
        if (!vif.mon_cb.act_n ||
            (!vif.mon_cb.ras_n && vif.mon_cb.cas_n && vif.mon_cb.we_n))
          item.cmd_type = ddr_seq_item::ACT;
        else if (vif.mon_cb.ras_n && !vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::READ;
        else if (vif.mon_cb.ras_n && !vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::WRITE;
        else if (!vif.mon_cb.ras_n && vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::PRE;
        else if (!vif.mon_cb.ras_n && !vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::REF;
        else if (!vif.mon_cb.ras_n && !vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::MRS;
        else
          item.cmd_type = ddr_seq_item::ZQC;
        item.addr       = vif.mon_cb.addr;
        item.bank       = vif.mon_cb.ba;
        item.bank_group = vif.mon_cb.bg;
        item.page_hit   = 1'b0;
        id = bank_id(vif.mon_cb.bg, vif.mon_cb.ba);
        case (item.cmd_type)
          ddr_seq_item::ACT: begin
            item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
            bank_active[id] = 1;
            active_row[id]  = vif.mon_cb.addr;
          end
          ddr_seq_item::READ, ddr_seq_item::WRITE: begin
            item.bstate   = bank_active[id] ? B_ACTIVE : B_IDLE;
            item.page_hit = bank_active[id];
          end
          ddr_seq_item::PRE: begin
            item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
            bank_active[id] = 0;
          end
          ddr_seq_item::REF: begin
            item.bstate = B_IDLE;
            foreach (bank_active[i]) bank_active[i] = 0;
          end
          default: item.bstate = B_IDLE;
        endcase
        txn_count++;
        item_collected_port.write(item);
        `uvm_info(get_type_name(), $sformatf("Monitored: %s", item.convert2string()), UVM_MEDIUM)
      end
    endtask

    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(),
        $sformatf("DDR monitor observed %0d transactions", txn_count), UVM_LOW)
    endfunction
  endclass : ddr_monitor

  //==========================================================================
  // DDR Agent
  //==========================================================================
  class ddr_agent extends uvm_agent;
    `uvm_component_utils(ddr_agent)
    ddr_sequencer sqr;
    ddr_driver    drv;
    ddr_monitor   mon;
    ddr_cfg       cfg;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(ddr_cfg)::get(this, "", "cfg", cfg))
        cfg = ddr_cfg::type_id::create("cfg");
      mon = ddr_monitor::type_id::create("mon", this);
      if (cfg.is_active == UVM_ACTIVE) begin
        sqr = ddr_sequencer::type_id::create("sqr", this);
        drv = ddr_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.is_active == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass : ddr_agent

  //==========================================================================
  // Directed sequence library (normal R/W, refresh, bank conflict,
  // back-to-back, page hit/miss corner cases, stress, regression)
  //==========================================================================
  class ddr_base_seq extends uvm_sequence #(ddr_seq_item);
    `uvm_object_utils(ddr_base_seq)
    rand int num_trans = 20;
    rand bit [15:0] row;
    rand bit [15:0] col;
    rand bit [2:0]  chan_n;
    rand bit [2:0]  bank_n;
    rand bit        rd_not_wr;
    constraint c_col { col[2:0] == 3'b000; }
    constraint c_chan { chan_n <= 3; }
    function new(string name = "ddr_base_seq");
      super.new(name);
    endfunction
    // issue one command item with explicit geometry
    task issue(ddr_seq_item::cmd_type_e c, bit [15:0] a, bit [2:0] ch, bit [2:0] b);
      ddr_seq_item item = ddr_seq_item::type_id::create("item");
      start_item(item);
      void'(item.randomize() with { cmd_type == c; addr == a; bank_group == ch[1:0]; bank == b; });
      finish_item(item);
    endtask
    // random-but-legal ACT -> RD/WR -> PRE rounds, REF every 8th round
    task body();
      for (int i = 0; i < num_trans; i++) begin
        void'(this.randomize(row, col, chan_n, bank_n, rd_not_wr));
        if (i % 8 == 7) issue(ddr_seq_item::REF, 16'h0, 3'h0, 3'h0);
        issue(ddr_seq_item::ACT, row, chan_n, bank_n);
        issue(rd_not_wr ? ddr_seq_item::READ : ddr_seq_item::WRITE, col, chan_n, bank_n);
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // Legacy random read/write mix (kept API): legal rounds
  class ddr_rw_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_rw_seq)
    function new(string name = "ddr_rw_seq");
      super.new(name);
      num_trans = 30;
    endfunction
  endclass

  // 1) Directed: write rounds (normal write traffic)
  class ddr_write_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_write_seq)
    function new(string name = "ddr_write_seq");
      super.new(name);
    endfunction
    constraint c_wr { rd_not_wr == 0; }
  endclass

  // 2) Directed: read rounds (normal read traffic)
  class ddr_read_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_read_seq)
    function new(string name = "ddr_read_seq");
      super.new(name);
    endfunction
    constraint c_rd { rd_not_wr == 1; }
  endclass

  // 3) Directed: refresh traffic
  class ddr_refresh_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_refresh_seq)
    function new(string name = "ddr_refresh_seq");
      super.new(name);
    endfunction
    task body();
      for (int i = 0; i < num_trans; i++)
        issue(ddr_seq_item::REF, 16'h0, 3'h0, 3'h0);
    endtask
  endclass

  // 4) Directed: bank conflict -- repeated ACT to the SAME bank forces
  //    PRE/ACT turnaround (tRP + tRCD pressure)
  class ddr_bank_conflict_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_bank_conflict_seq)
    function new(string name = "ddr_bank_conflict_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h0100;
      void'(ddr_base_seq'(this).randomize(chan_n, bank_n));
      for (int i = 0; i < num_trans; i++) begin
        issue(ddr_seq_item::ACT, crow, chan_n, bank_n);
        issue(ddr_seq_item::WRITE, 16'h0, chan_n, bank_n);
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h100;
      end
    endtask
  endclass

  // 5) Directed: back-to-back accesses across 4 banks (no PRE between)
  class ddr_back_to_back_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_back_to_back_seq)
    function new(string name = "ddr_back_to_back_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h2000;
      for (int i = 0; i < num_trans; i++) begin
        for (int b = 0; b < 4; b++)
          issue(ddr_seq_item::ACT, crow, chan_n, b[2:0]);
        for (int b = 0; b < 4; b++) begin
          issue(ddr_seq_item::WRITE, 16'h0, chan_n, b[2:0]);
          issue(ddr_seq_item::READ, 16'h0, chan_n, b[2:0]);
        end
        for (int b = 0; b < 4; b++)
          issue(ddr_seq_item::PRE, 16'h0, chan_n, b[2:0]);
        crow = crow + 16'h400;
      end
    endtask
  endclass

  // 6) Corner case: page hit -- one ACT, many RD/WR to the SAME open row
  class ddr_page_hit_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_page_hit_seq)
    function new(string name = "ddr_page_hit_seq");
      super.new(name);
    endfunction
    task body();
      for (int i = 0; i < num_trans; i++) begin
        void'(ddr_base_seq'(this).randomize(row, chan_n, bank_n));
        issue(ddr_seq_item::ACT, row, chan_n, bank_n);
        for (int k = 0; k < 4; k++) begin
          void'(ddr_base_seq'(this).randomize(col, rd_not_wr));
          issue(rd_not_wr ? ddr_seq_item::READ : ddr_seq_item::WRITE, col, chan_n, bank_n);
        end
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // 7) Corner case: page miss -- every access targets a different row
  class ddr_page_miss_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_page_miss_seq)
    function new(string name = "ddr_page_miss_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h0;
      void'(ddr_base_seq'(this).randomize(chan_n, bank_n));
      for (int i = 0; i < num_trans; i++) begin
        void'(ddr_base_seq'(this).randomize(col, rd_not_wr));
        issue(ddr_seq_item::ACT, crow, chan_n, bank_n);
        issue(rd_not_wr ? ddr_seq_item::READ : ddr_seq_item::WRITE, col, chan_n, bank_n);
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h311;
      end
    endtask
  endclass

  // 8) Stress: long legal mix of rounds
  class ddr_stress_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_stress_seq)
    function new(string name = "ddr_stress_seq");
      super.new(name);
      num_trans = 200;
    endfunction
  endclass

  // Regression: weighted mix of every directed sequence
  class ddr_regression_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_regression_seq)
    function new(string name = "ddr_regression_seq");
      super.new(name);
    endfunction
    task body();
      ddr_write_seq         wr   = ddr_write_seq::type_id::create("wr");
      ddr_read_seq          rd   = ddr_read_seq::type_id::create("rd");
      ddr_refresh_seq       refs = ddr_refresh_seq::type_id::create("refs");
      ddr_bank_conflict_seq bc   = ddr_bank_conflict_seq::type_id::create("bc");
      ddr_back_to_back_seq  b2b  = ddr_back_to_back_seq::type_id::create("b2b");
      ddr_page_hit_seq      hit  = ddr_page_hit_seq::type_id::create("hit");
      ddr_page_miss_seq     miss = ddr_page_miss_seq::type_id::create("miss");
      wr.num_trans   = 10; rd.num_trans   = 10;
      refs.num_trans = 4;  bc.num_trans   = 5;
      b2b.num_trans  = 4;  hit.num_trans  = 4;
      miss.num_trans = 5;
      wr.start(m_sequencer);
      rd.start(m_sequencer);
      hit.start(m_sequencer);
      miss.start(m_sequencer);
      bc.start(m_sequencer);
      b2b.start(m_sequencer);
      refs.start(m_sequencer);
    endtask
  endclass

  //==========================================================================
  // Legacy directed coverage sequences (kept API)
  //==========================================================================
  class ddr_cov_cmd_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_cmd_seq)
    function new(string name = "ddr_cov_cmd_seq");
      super.new(name);
    endfunction
    task body();
      ddr_seq_item item;
      ddr_seq_item::cmd_type_e cmds[8] = '{ddr_seq_item::ACT, ddr_seq_item::READ, ddr_seq_item::WRITE, ddr_seq_item::PRE, ddr_seq_item::REF, ddr_seq_item::NOP, ddr_seq_item::MRS, ddr_seq_item::ZQC};
      foreach (cmds[i]) begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == cmds[i]; })
          `uvm_error(get_type_name(), "Rand failed")
        finish_item(item);
      end
    endtask
  endclass : ddr_cov_cmd_seq

  class ddr_cov_bank_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_bank_seq)
    function new(string name = "ddr_cov_bank_seq");
      super.new(name);
    endfunction
    task body();
      ddr_seq_item item;
      for (int b = 0; b < 8; b++) begin
        for (int g = 0; g < 4; g++) begin
          issue(ddr_seq_item::ACT, 16'h100 * (b + 1), g[2:0], b[2:0]);
          issue(ddr_seq_item::WRITE, 16'h0, g[2:0], b[2:0]);
          issue(ddr_seq_item::PRE, 16'h0, g[2:0], b[2:0]);
        end
      end
    endtask
  endclass : ddr_cov_bank_seq

  class ddr_cov_bl_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_bl_seq)
    function new(string name = "ddr_cov_bl_seq");
      super.new(name);
    endfunction
    task body();
      ddr_seq_item item;
      bit [7:0] bls[2] = '{8, 16};
      foreach (bls[i]) begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == ddr_seq_item::WRITE; burst_len == bls[i]; })
          `uvm_error(get_type_name(), "Rand failed")
        finish_item(item);
      end
    endtask
  endclass : ddr_cov_bl_seq
endpackage : ddr_pkg
