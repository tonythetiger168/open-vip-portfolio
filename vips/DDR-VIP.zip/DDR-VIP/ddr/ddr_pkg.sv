// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// DDR4/DDR5 UVM VIP Package
// Deepened: timing-accurate command driver (tRCD/tRP/tRAS/tFAW), bus-decoding
// monitor with bank/page tracking, directed sequence library.
//------------------------------------------------------------------------------
package ddr_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // Bank state tracked by the monitor, sampled by functional coverage
  typedef enum {B_IDLE, B_ACTIVE} bank_state_e;

  //==========================================================================
  // DDR Sequence Item
  //==========================================================================
  class ddr_seq_item extends uvm_sequence_item;
    `uvm_object_utils(ddr_seq_item)
    typedef enum {ACT, READ, WRITE, PRE, REF, NOP, MRS, ZQC} cmd_type_e;
    rand cmd_type_e cmd_type;
    rand bit [16:0] addr;
    rand bit [2:0]  bank;
    rand bit [1:0]  bank_group;
    rand bit [63:0] data[];
    rand bit [7:0]  dm;
    rand bit [7:0]  burst_len;
    bit [63:0]      rdata[];
    bit             ready;
    // DDR5 specific
    rand bit        ca_par;   // Command/Address parity
    rand bit        dm_dbi;   // Data mask / Data bus inversion
    // filled in by the monitor
    bit             page_hit;
    bank_state_e    bstate;
    bit [15:0]      row;      // data bursts: row open in the bank at the RD / WR

    constraint c_addr_align { cmd_type inside {READ, WRITE} -> addr[2:0] == 3'b000; }
    constraint c_burst_len { burst_len inside {8, 16}; }
    constraint c_data_size { data.size() == burst_len; }
    constraint c_cmd_dist { cmd_type dist {ACT := 10, READ := 30, WRITE := 30,
                                           PRE := 10, REF := 5, NOP := 10,
                                           MRS := 3, ZQC := 2}; }
    function new(string name = "ddr_seq_item");
      super.new(name);
    endfunction
    // rdata is not rand: a size constraint on it would pin burst_len to its
    // current size (0), so it is sized here instead
    function void post_randomize();
      rdata = new[burst_len];
      // A rand dynamic array is left unsized on Verilator even with the
      // data.size() == burst_len constraint: every write then drove zeros
      // and a read-data check could not fail. Size and fill it here.
      if (data.size() != burst_len) begin
        data = new[burst_len];
        foreach (data[i]) data[i] = {$urandom() , $urandom()};
      end
    endfunction
    function string convert2string();
      return $sformatf("DDR %s: bank=%0d bg=%0d addr=0x%0h bl=%0d",
                       cmd_type.name(), bank, bank_group, addr, burst_len);
    endfunction
  endclass : ddr_seq_item

  //==========================================================================
  // DDR Configuration
  //==========================================================================
  class ddr_cfg extends uvm_object;
    `uvm_object_utils(ddr_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1;
    int tRCD = 15;
    int tRP  = 15;
    int tRAS = 35;
    int tRC  = 50;
    int tCL  = 15;
    int tCWL = 14;
    int tRRD = 4;
    int tFAW = 20;
    int tWR  = 15;
    int tRTP = 8;
    int tWTR = 8;
    int tREFI = 3900;   // average refresh interval, in clocks
    function new(string name = "ddr_cfg");
      super.new(name);
    endfunction
  endclass : ddr_cfg

  //==========================================================================
  // DDR Sequencer
  //==========================================================================
  class ddr_sequencer extends uvm_sequencer #(ddr_seq_item);
    `uvm_component_utils(ddr_sequencer)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
  endclass : ddr_sequencer

  //==========================================================================
  // DDR Driver -- drives real DRAM command sequences on ddr_if:
  // ACT (row), RD/WR (column), PRE, REF with tRCD/tRP/tRAS/tFAW timing,
  // plus expected-transaction broadcast for the scoreboard.
  //==========================================================================
  class ddr_driver extends uvm_driver #(ddr_seq_item);
    `uvm_component_utils(ddr_driver)
    virtual ddr_if vif;
    ddr_cfg cfg;
    uvm_analysis_port #(ddr_seq_item) drv_ap;  // expected items for scoreboard

    bit [16:0]   active_row [32];   // open row per flattened {bg,bank}
    bit          bank_active[32];
    int unsigned act_cycle  [32];
    int unsigned act_hist   [4];    // last 4 ACT cycles (tFAW window)
    int          act_hist_idx = 0;
    int unsigned cyc = 0;
    int unsigned last_act_cyc = 0;   // latest ACT to any bank
    int unsigned last_ref_cyc = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      drv_ap = new("drv_ap", this);
      foreach (bank_active[i]) bank_active[i] = 0;
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "DDR virtual interface not found")
      if (!uvm_config_db#(ddr_cfg)::get(this, "", "cfg", cfg))
        cfg = ddr_cfg::type_id::create("cfg");
    endfunction

    function int bank_id(bit [1:0] bg, bit [2:0] b);
      return bg * 8 + b;
    endfunction

    // One command cycle on the CA bus
    task drive_cmd(bit cs_n, bit act_n, bit ras_n, bit cas_n, bit we_n,
                   bit [16:0] a, bit [2:0] b, bit [1:0] g);
      vif.drv_cb.cs_n  <= cs_n;
      vif.drv_cb.act_n <= act_n;
      vif.drv_cb.ras_n <= ras_n;
      vif.drv_cb.cas_n <= cas_n;
      vif.drv_cb.we_n  <= we_n;
      vif.drv_cb.addr  <= a;
      vif.drv_cb.ba    <= b;
      vif.drv_cb.bg    <= g;
      @(vif.drv_cb);
      cyc++;
    endtask

    task idle(int n);
      vif.drv_cb.cs_n  <= 1'b1;
      vif.drv_cb.act_n <= 1'b1;
      vif.drv_cb.ras_n <= 1'b1;
      vif.drv_cb.cas_n <= 1'b1;
      vif.drv_cb.we_n  <= 1'b1;
      repeat (n) begin
        @(vif.drv_cb);
        cyc++;
      end
    endtask

    // A command the driver adds on its own, as a memory controller does
    // (open a closed bank, close an open one, refresh in time): it goes on
    // the expected stream like any sequence item.
    function void expect_cmd(ddr_seq_item::cmd_type_e c, bit [16:0] a, bit [2:0] b, bit [1:0] g);
      ddr_seq_item e = ddr_seq_item::type_id::create("auto");
      e.cmd_type = c; e.addr = a; e.bank = b; e.bank_group = g;
      `uvm_info(get_type_name(), $sformatf("Controller adds: %s", e.convert2string()), UVM_HIGH)
      drv_ap.write(e);
    endfunction

    task activate(bit [16:0] row, bit [2:0] b, bit [1:0] g);
      int id = bank_id(g, b);
      if (bank_active[id]) begin        // ACT to an open bank: close it first
        precharge(b, g, 16'h0);
        expect_cmd(ddr_seq_item::PRE, 17'h0, b, g);
      end
      while (cyc - act_hist[act_hist_idx] <= cfg.tFAW && act_hist[act_hist_idx] != 0)
        idle(1);                        // tFAW window
      drive_cmd(0, 0, 0, 1, 1, row, b, g);
      active_row[id]  = row;
      bank_active[id] = 1;
      act_cycle[id]   = cyc;
      last_act_cyc    = cyc;
      act_hist[act_hist_idx] = cyc;
      act_hist_idx = (act_hist_idx + 1) % 4;
      idle(cfg.tRCD - 1);               // tRCD before any CAS to this bank
    endtask

    task precharge(bit [2:0] b, bit [1:0] g, bit [16:0] a);
      int id = bank_id(g, b);
      while (cyc - last_act_cyc < cfg.tRAS)
        idle(1);                        // tRAS: earliest legal PRE after ACT
      drive_cmd(0, 1, 0, 1, 0, a, b, g);
      bank_active[id] = 0;
      idle(cfg.tRP - 1);                // tRP before re-activation
    endtask

    // RD/WR to a closed bank: open its row first
    task ensure_open(ddr_seq_item item);
      int id = bank_id(item.bank_group, item.bank);
      if (!bank_active[id]) begin
        activate(17'h0, item.bank, item.bank_group);
        expect_cmd(ddr_seq_item::ACT, 17'h0, item.bank, item.bank_group);
      end
    endtask

    // Close every open bank (before REF), all after tRAS of the latest ACT
    task precharge_all();
      bit any = 0;
      while (cyc - last_act_cyc < cfg.tRAS)
        idle(1);
      foreach (bank_active[i])
        if (bank_active[i]) begin
          drive_cmd(0, 1, 0, 1, 0, 17'h0, i % 8, i / 8);
          bank_active[i] = 0;
          expect_cmd(ddr_seq_item::PRE, 17'h0, i % 8, i / 8);
          any = 1;
        end
      if (any) idle(cfg.tRP - 1);
    endtask

    // Refresh before tREFI runs out, then reopen the rows that were open
    task refresh_if_due();
      bit        was_open[32];
      bit [16:0] rows[32];
      if (cyc - last_ref_cyc + 300 < cfg.tREFI) return;
      foreach (bank_active[i]) begin was_open[i] = bank_active[i]; rows[i] = active_row[i]; end
      precharge_all();
      drive_cmd(0, 1, 0, 0, 1, 17'h0, 3'h0, 2'h0);
      last_ref_cyc = cyc;
      expect_cmd(ddr_seq_item::REF, 17'h0, 3'h0, 2'h0);
      idle(cfg.tRC - 1);
      foreach (was_open[i])
        if (was_open[i]) begin
          activate(rows[i], i % 8, i / 8);
          expect_cmd(ddr_seq_item::ACT, rows[i], i % 8, i / 8);
        end
    endtask

    task drive_activate(ddr_seq_item item);
      activate(item.addr, item.bank, item.bank_group);
    endtask

    task drive_read(ddr_seq_item item);
      int id = bank_id(item.bank_group, item.bank);
      ensure_open(item);
      item.addr[10] = 1'b0;                     // A10: no auto-precharge
      item.addr[12] = (item.burst_len == 16);   // A12: BL16, else burst chop 8
      drive_cmd(0, 1, 1, 0, 1, item.addr, item.bank, item.bank_group);
      idle(cfg.tCL);                    // CAS latency
      item.rdata = new[item.burst_len];
      for (int i = 0; i < item.burst_len; i++) begin
        @(vif.drv_cb);
        cyc++;
        item.rdata[i] = vif.drv_cb.dq;  // sample read data burst
      end
    endtask

    task drive_write(ddr_seq_item item);
      int id = bank_id(item.bank_group, item.bank);
      ensure_open(item);
      item.addr[10] = 1'b0;                     // A10: no auto-precharge
      item.addr[12] = (item.burst_len == 16);   // A12: BL16, else burst chop 8
      vif.drv_cb.odt <= 1'b1;                   // termination on for the write
      drive_cmd(0, 1, 1, 0, 0, item.addr, item.bank, item.bank_group);
      idle(cfg.tCWL - 1);               // CAS write latency
      for (int i = 0; i < item.burst_len; i++) begin
        vif.drv_cb.dq <= item.data[i];
        vif.drv_cb.dm <= item.dm;
        @(vif.drv_cb);
        cyc++;
      end
      vif.drv_cb.odt <= 1'b0;
    endtask

    task drive_precharge(ddr_seq_item item);
      precharge(item.bank, item.bank_group, item.addr);
    endtask

    task drive_refresh(ddr_seq_item item);
      precharge_all();                  // REF needs every bank idle
      drive_cmd(0, 1, 0, 0, 1, item.addr, item.bank, item.bank_group);
      last_ref_cyc = cyc;
      idle(cfg.tRC - 1);                // tRFC/tRC refresh recovery
    endtask

    task drive_mrs(ddr_seq_item item);
      drive_cmd(0, 1, 0, 0, 0, item.addr, item.bank, item.bank_group);
      idle(4);                          // tMOD
    endtask

    task drive_zqcal(ddr_seq_item item);
      drive_cmd(0, 1, 1, 1, 0, item.addr, item.bank, item.bank_group);
      idle(8);
    endtask

    task drive_nop(ddr_seq_item item);
      idle(1);
    endtask

    task run_phase(uvm_phase phase);
      vif.drv_cb.cke  <= 1'b1;
      vif.drv_cb.odt  <= 1'b0;
      vif.drv_cb.addr <= '0;   // a known address while CKE is high
      vif.drv_cb.ba   <= '0;
      vif.drv_cb.bg   <= '0;
      idle(1);
      wait (vif.rst_n === 1'b1);
      idle(5);
      forever begin
        seq_item_port.get_next_item(req);
        `uvm_info(get_type_name(), $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
        refresh_if_due();
        case (req.cmd_type)
          ddr_seq_item::ACT:   drive_activate(req);
          ddr_seq_item::READ:  drive_read(req);
          ddr_seq_item::WRITE: drive_write(req);
          ddr_seq_item::PRE:   drive_precharge(req);
          ddr_seq_item::REF:   drive_refresh(req);
          ddr_seq_item::MRS:   drive_mrs(req);
          ddr_seq_item::ZQC:   drive_zqcal(req);
          ddr_seq_item::NOP:   drive_nop(req);
        endcase
        if (req.cmd_type != ddr_seq_item::NOP)
          drv_ap.write(req);            // broadcast expected transaction
        seq_item_port.item_done();
      end
    endtask
  endclass : ddr_driver

  //==========================================================================
  // DDR Monitor -- decodes commands from the CA bus waveform, tracks per-bank
  // state and page hit/miss, publishes reconstructed transactions.
  //==========================================================================
  class ddr_monitor extends uvm_monitor;
    `uvm_component_utils(ddr_monitor)
    virtual ddr_if vif;
    ddr_cfg cfg;
    uvm_analysis_port #(ddr_seq_item) item_collected_port;
    // RD / WR bursts with the data seen on DQ (write: tCWL after WR, read:
    // tCL + 1 after RD, one beat per clock), for the scoreboard's
    // read-data check; row = the row the bank had open at the command
    uvm_analysis_port #(ddr_seq_item) data_port;
    int unsigned txn_count = 0;
    int unsigned rd_lat = 16, wr_lat = 14;   // from ddr_cfg (tCL + 1, tCWL)

    protected bit        bank_active [32];
    protected bit [16:0] active_row  [32];
    protected bit        accessed    [32];   // row read/written since its ACT

    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
      data_port = new("data_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual ddr_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "DDR virtual interface not found")
      if (uvm_config_db#(ddr_cfg)::get(this, "", "cfg", cfg)) begin
        rd_lat = cfg.tCL + 1;
        wr_lat = cfg.tCWL;
      end
    endfunction

    function int bank_id(bit [1:0] g, bit [2:0] b);
      return g * 8 + b;
    endfunction

    // Capture one burst: lat clocks after the command, bl beats
    task capture(ddr_seq_item it, int unsigned lat, int unsigned bl);
      bit [63:0] beats[];
      beats = new[bl];
      repeat (lat) @(vif.mon_cb);
      for (int i = 0; i < bl; i++) begin
        beats[i] = vif.mon_cb.dq;
        if (i < bl - 1) @(vif.mon_cb);
      end
      if (it.cmd_type == ddr_seq_item::WRITE) it.data = beats;
      else                                    it.rdata = beats;
      data_port.write(it);
    endtask

    task run_phase(uvm_phase phase);
      ddr_seq_item item;
      int id;
      forever begin
        @(vif.mon_cb);
        if (vif.rst_n !== 1'b1) begin
          foreach (bank_active[i]) bank_active[i] = 0;
          continue;
        end
        if (vif.mon_cb.cs_n) continue;  // deselect
        item = ddr_seq_item::type_id::create("item");
        // Decode command
        if (!vif.mon_cb.act_n ||
            (!vif.mon_cb.ras_n && vif.mon_cb.cas_n && vif.mon_cb.we_n))
          item.cmd_type = ddr_seq_item::ACT;
        else if (vif.mon_cb.ras_n && !vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::READ;
        else if (vif.mon_cb.ras_n && !vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::WRITE;
        else if (!vif.mon_cb.ras_n && vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::PRE;
        else if (!vif.mon_cb.ras_n && !vif.mon_cb.cas_n && vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::REF;
        else if (!vif.mon_cb.ras_n && !vif.mon_cb.cas_n && !vif.mon_cb.we_n)
          item.cmd_type = ddr_seq_item::MRS;
        else
          item.cmd_type = ddr_seq_item::ZQC;
        item.addr       = vif.mon_cb.addr;
        item.bank       = vif.mon_cb.ba;
        item.bank_group = vif.mon_cb.bg;
        item.page_hit   = 1'b0;
        id = bank_id(vif.mon_cb.bg, vif.mon_cb.ba);
        case (item.cmd_type)
          ddr_seq_item::ACT: begin
            item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
            bank_active[id] = 1;
            active_row[id]  = vif.mon_cb.addr;
            accessed[id]    = 0;
          end
          ddr_seq_item::READ, ddr_seq_item::WRITE: begin
            ddr_seq_item d;
            item.bstate    = bank_active[id] ? B_ACTIVE : B_IDLE;
            // page hit: the open row was accessed before; miss: first access after ACT
            item.page_hit  = bank_active[id] && accessed[id];
            accessed[id]   = 1;
            item.burst_len = vif.mon_cb.addr[12] ? 16 : 8;   // A12 (BL16 / chop 8)
            // data burst: a copy, since item goes to the command stream now
            d = ddr_seq_item::type_id::create("burst");
            d.cmd_type = item.cmd_type; d.bank = item.bank; d.bank_group = item.bank_group;
            d.addr = item.addr; d.burst_len = item.burst_len;
            d.row = active_row[id][15:0];
            fork
              capture(d, (d.cmd_type == ddr_seq_item::WRITE) ? wr_lat : rd_lat, d.burst_len);
            join_none
          end
          ddr_seq_item::PRE: begin
            item.bstate = bank_active[id] ? B_ACTIVE : B_IDLE;
            bank_active[id] = 0;
          end
          ddr_seq_item::REF: begin
            item.bstate = B_IDLE;
            foreach (bank_active[i]) bank_active[i] = 0;
          end
          default: item.bstate = B_IDLE;
        endcase
        txn_count++;
        item_collected_port.write(item);
        `uvm_info(get_type_name(), $sformatf("Monitored: %s", item.convert2string()), UVM_MEDIUM)
      end
    endtask

    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(),
        $sformatf("DDR monitor observed %0d transactions", txn_count), UVM_LOW)
    endfunction
  endclass : ddr_monitor

  //==========================================================================
  // DDR Agent
  //==========================================================================
  class ddr_agent extends uvm_agent;
    `uvm_component_utils(ddr_agent)
    ddr_sequencer sqr;
    ddr_driver    drv;
    ddr_monitor   mon;
    ddr_cfg       cfg;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(ddr_cfg)::get(this, "", "cfg", cfg))
        cfg = ddr_cfg::type_id::create("cfg");
      mon = ddr_monitor::type_id::create("mon", this);
      if (cfg.is_active == UVM_ACTIVE) begin
        sqr = ddr_sequencer::type_id::create("sqr", this);
        drv = ddr_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.is_active == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass : ddr_agent

  //==========================================================================
  // Directed sequence library (normal R/W, refresh, bank conflict,
  // back-to-back, page hit/miss corner cases, stress, regression)
  //==========================================================================
  class ddr_base_seq extends uvm_sequence #(ddr_seq_item);
    `uvm_object_utils(ddr_base_seq)
    rand int num_trans = 20;
    rand bit [15:0] row;
    rand bit [15:0] col;
    rand bit [2:0]  chan_n;
    rand bit [2:0]  bank_n;
    rand bit        rd_not_wr;
    constraint c_col { col[2:0] == 3'b000; }
    constraint c_chan { chan_n <= 3; }
    function new(string name = "ddr_base_seq");
      super.new(name);
    endfunction
    // issue one command item with explicit geometry
    task issue(ddr_seq_item::cmd_type_e c, bit [15:0] a, bit [2:0] ch, bit [2:0] b);
      ddr_seq_item item = ddr_seq_item::type_id::create("item");
      start_item(item);
      // the command is fixed: drop the dist (Verilator 5.052 reports a dist
      // plus an inline == on the same variable as unsatisfiable)
      item.c_cmd_dist.constraint_mode(0);
      if (!(item.randomize() with { cmd_type == c; addr == a; bank_group == ch[1:0]; bank == b; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    endtask
    // RD / WR with a fixed burst length (8, or 16 via A12)
    task issue_bl(ddr_seq_item::cmd_type_e c, bit [15:0] a, bit [2:0] ch, bit [2:0] b, int bl);
      ddr_seq_item item = ddr_seq_item::type_id::create("item");
      start_item(item);
      item.c_cmd_dist.constraint_mode(0);
      if (!(item.randomize() with { cmd_type == c; addr == a; bank_group == ch[1:0]; bank == b;
                                    burst_len == bl; })) `uvm_error("RANDFAIL", "randomize() failed");
      finish_item(item);
    endtask
    // random-but-legal ACT -> RD/WR -> PRE rounds, REF every 8th round
    task body();
      for (int i = 0; i < num_trans; i++) begin
        if (!(randomize(row, col, chan_n, bank_n, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
        if (i % 8 == 7) issue(ddr_seq_item::REF, 16'h0, 3'h0, 3'h0);
        issue(ddr_seq_item::ACT, row, chan_n, bank_n);
        issue(rd_not_wr ? ddr_seq_item::READ : ddr_seq_item::WRITE, col, chan_n, bank_n);
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // Legacy random read/write mix (kept API): legal rounds
  class ddr_rw_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_rw_seq)
    function new(string name = "ddr_rw_seq");
      super.new(name);
      num_trans = 30;
    endfunction
  endclass

  // 1) Directed: write rounds (normal write traffic)
  class ddr_write_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_write_seq)
    function new(string name = "ddr_write_seq");
      super.new(name);
    endfunction
    constraint c_wr { rd_not_wr == 0; }
  endclass

  // 2) Directed: read rounds (normal read traffic)
  class ddr_read_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_read_seq)
    function new(string name = "ddr_read_seq");
      super.new(name);
    endfunction
    constraint c_rd { rd_not_wr == 1; }
  endclass

  // 3) Directed: refresh traffic
  class ddr_refresh_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_refresh_seq)
    function new(string name = "ddr_refresh_seq");
      super.new(name);
    endfunction
    task body();
      for (int i = 0; i < num_trans; i++)
        issue(ddr_seq_item::REF, 16'h0, 3'h0, 3'h0);
    endtask
  endclass

  // 4) Directed: bank conflict -- repeated ACT to the SAME bank forces
  //    PRE/ACT turnaround (tRP + tRCD pressure)
  class ddr_bank_conflict_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_bank_conflict_seq)
    function new(string name = "ddr_bank_conflict_seq");
      super.new(name);
    endfunction
    task body();
      ddr_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a ddr_base_seq handle
      bit [15:0] crow = 16'h0100;
      if (!(rnd_h.randomize(chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
      for (int i = 0; i < num_trans; i++) begin
        issue(ddr_seq_item::ACT, crow, chan_n, bank_n);
        issue(ddr_seq_item::WRITE, 16'h0, chan_n, bank_n);
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h100;
      end
    endtask
  endclass

  // 5) Directed: back-to-back accesses across 4 banks (no PRE between)
  class ddr_back_to_back_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_back_to_back_seq)
    function new(string name = "ddr_back_to_back_seq");
      super.new(name);
    endfunction
    task body();
      bit [15:0] crow = 16'h2000;
      for (int i = 0; i < num_trans; i++) begin
        for (int b = 0; b < 4; b++)
          issue(ddr_seq_item::ACT, crow, chan_n, b[2:0]);
        for (int b = 0; b < 4; b++) begin
          issue(ddr_seq_item::WRITE, 16'h0, chan_n, b[2:0]);
          issue(ddr_seq_item::READ, 16'h0, chan_n, b[2:0]);
        end
        for (int b = 0; b < 4; b++)
          issue(ddr_seq_item::PRE, 16'h0, chan_n, b[2:0]);
        crow = crow + 16'h400;
      end
    endtask
  endclass

  // 6) Corner case: page hit -- one ACT, many RD/WR to the SAME open row
  class ddr_page_hit_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_page_hit_seq)
    function new(string name = "ddr_page_hit_seq");
      super.new(name);
    endfunction
    task body();
      ddr_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a ddr_base_seq handle
      for (int i = 0; i < num_trans; i++) begin
        if (!(rnd_h.randomize(row, chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
        issue(ddr_seq_item::ACT, row, chan_n, bank_n);
        for (int k = 0; k < 4; k++) begin
          if (!(rnd_h.randomize(col, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
          issue(rd_not_wr ? ddr_seq_item::READ : ddr_seq_item::WRITE, col, chan_n, bank_n);
        end
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
      end
    endtask
  endclass

  // 7) Corner case: page miss -- every access targets a different row
  class ddr_page_miss_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_page_miss_seq)
    function new(string name = "ddr_page_miss_seq");
      super.new(name);
    endfunction
    task body();
      ddr_base_seq rnd_h = this;   // randomize(<inherited vars>) needs a ddr_base_seq handle
      bit [15:0] crow = 16'h0;
      if (!(rnd_h.randomize(chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
      for (int i = 0; i < num_trans; i++) begin
        if (!(rnd_h.randomize(col, rd_not_wr))) `uvm_error("RANDFAIL", "randomize() failed");
        issue(ddr_seq_item::ACT, crow, chan_n, bank_n);
        issue(rd_not_wr ? ddr_seq_item::READ : ddr_seq_item::WRITE, col, chan_n, bank_n);
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        crow = crow + 16'h311;
      end
    endtask
  endclass

  // 8) Stress: long legal mix of rounds
  class ddr_stress_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_stress_seq)
    function new(string name = "ddr_stress_seq");
      super.new(name);
      num_trans = 200;
    endfunction
  endclass

  // Data integrity: every read targets written columns, so the scoreboard's
  // shadow-memory check has something to compare. Per round, in one bank:
  // two adjacent BL8 bursts, a BL16 burst, read-back of each, a BL16 read
  // spanning both BL8 bursts, then the same columns in a second row (row
  // isolation) and the first row reopened and read again.
  class ddr_data_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_data_seq)
    // beats the scoreboard must have checked (72 per round), summed over
    // every run of this sequence
    static int unsigned exp_checks = 0;
    static int unsigned exp_reads = 0;     // read bursts issued
    function new(string name = "ddr_data_seq");
      super.new(name);
      num_trans = 6;
    endfunction
    task body();
      ddr_base_seq rnd_h = this;
      bit [15:0] r1, r2, c;
      for (int i = 0; i < num_trans; i++) begin
        if (!(rnd_h.randomize(row, col, chan_n, bank_n))) `uvm_error("RANDFAIL", "randomize() failed");
        r1 = row; r2 = row ^ 16'h0421;
        c = 16'((col[9:5] % 30) * 32);   // 32-column aligned: c + 47 stays below column 1024
        issue(ddr_seq_item::ACT, r1, chan_n, bank_n);
        issue_bl(ddr_seq_item::WRITE, c,         chan_n, bank_n, 8);
        issue_bl(ddr_seq_item::WRITE, c + 8,     chan_n, bank_n, 8);
        issue_bl(ddr_seq_item::WRITE, c + 32,    chan_n, bank_n, 16);
        issue_bl(ddr_seq_item::READ,  c,         chan_n, bank_n, 8);
        issue_bl(ddr_seq_item::READ,  c + 8,     chan_n, bank_n, 8);
        issue_bl(ddr_seq_item::READ,  c + 32,    chan_n, bank_n, 16);
        issue_bl(ddr_seq_item::READ,  c,         chan_n, bank_n, 16);   // both BL8 bursts
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        issue(ddr_seq_item::ACT, r2, chan_n, bank_n);
        issue_bl(ddr_seq_item::WRITE, c,         chan_n, bank_n, 8);
        issue_bl(ddr_seq_item::READ,  c,         chan_n, bank_n, 8);
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        issue(ddr_seq_item::ACT, r1, chan_n, bank_n);
        issue_bl(ddr_seq_item::READ,  c,         chan_n, bank_n, 16);   // row 1 kept its data
        issue(ddr_seq_item::PRE, 16'h0, chan_n, bank_n);
        exp_checks += 8 + 8 + 16 + 16 + 8 + 16;
        exp_reads  += 6;
      end
    endtask
  endclass

  // Regression: weighted mix of every directed sequence
  class ddr_regression_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_regression_seq)
    function new(string name = "ddr_regression_seq");
      super.new(name);
    endfunction
    task body();
      ddr_write_seq         wr   = ddr_write_seq::type_id::create("wr");
      ddr_read_seq          rd   = ddr_read_seq::type_id::create("rd");
      ddr_refresh_seq       refs = ddr_refresh_seq::type_id::create("refs");
      ddr_bank_conflict_seq bc   = ddr_bank_conflict_seq::type_id::create("bc");
      ddr_back_to_back_seq  b2b  = ddr_back_to_back_seq::type_id::create("b2b");
      ddr_page_hit_seq      hit  = ddr_page_hit_seq::type_id::create("hit");
      ddr_page_miss_seq     miss = ddr_page_miss_seq::type_id::create("miss");
      wr.num_trans   = 10; rd.num_trans   = 10;
      refs.num_trans = 4;  bc.num_trans   = 5;
      b2b.num_trans  = 4;  hit.num_trans  = 4;
      miss.num_trans = 5;
      begin
        ddr_data_seq data = ddr_data_seq::type_id::create("data");
        data.start(m_sequencer);
      end
      wr.start(m_sequencer);
      rd.start(m_sequencer);
      hit.start(m_sequencer);
      miss.start(m_sequencer);
      bc.start(m_sequencer);
      b2b.start(m_sequencer);
      refs.start(m_sequencer);
    endtask
  endclass

  //==========================================================================
  // Legacy directed coverage sequences (kept API)
  //==========================================================================
  class ddr_cov_cmd_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_cmd_seq)
    function new(string name = "ddr_cov_cmd_seq");
      super.new(name);
    endfunction
    task body();
      ddr_seq_item item;
      ddr_seq_item::cmd_type_e cmds[8] = '{ddr_seq_item::ACT, ddr_seq_item::READ, ddr_seq_item::WRITE, ddr_seq_item::PRE, ddr_seq_item::REF, ddr_seq_item::NOP, ddr_seq_item::MRS, ddr_seq_item::ZQC};
      foreach (cmds[i]) begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        item.c_cmd_dist.constraint_mode(0);
        if (!item.randomize() with { cmd_type == cmds[i]; })
          `uvm_error(get_type_name(), "Rand failed")
        finish_item(item);
      end
    endtask
  endclass : ddr_cov_cmd_seq

  class ddr_cov_bank_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_bank_seq)
    function new(string name = "ddr_cov_bank_seq");
      super.new(name);
    endfunction
    task body();
      ddr_seq_item item;
      for (int b = 0; b < 8; b++) begin
        for (int g = 0; g < 4; g++) begin
          issue(ddr_seq_item::ACT, 16'h100 * (b + 1), g[2:0], b[2:0]);
          issue(ddr_seq_item::WRITE, 16'h0, g[2:0], b[2:0]);
          issue(ddr_seq_item::READ, 16'h0, g[2:0], b[2:0]);
          issue(ddr_seq_item::PRE, 16'h0, g[2:0], b[2:0]);
        end
      end
    endtask
  endclass : ddr_cov_bank_seq

  class ddr_cov_bl_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_bl_seq)
    function new(string name = "ddr_cov_bl_seq");
      super.new(name);
    endfunction
    task body();
      ddr_seq_item item;
      bit [7:0] bls[2] = '{8, 16};
      foreach (bls[i]) begin
        item = ddr_seq_item::type_id::create("item");
        start_item(item);
        item.c_cmd_dist.constraint_mode(0);
        if (!item.randomize() with { cmd_type == ddr_seq_item::WRITE; burst_len == bls[i]; })
          `uvm_error(get_type_name(), "Rand failed")
        finish_item(item);
      end
    endtask
  endclass : ddr_cov_bl_seq
endpackage : ddr_pkg
