// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR Tiered Compliance SVA Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.
// L1=4 | L2=4 | L3=4 retained below; L4 DDR protocol-specific rules added

`ifndef DDR_COMPLIANCE_CHECKER_SV
`define DDR_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr_compliance_checker (ddr_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  real l1_cov, l2_cov, l3_cov, total_cov;

  // ---------------- L1: signal sanity (4) ----------------
  property p_ddr_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_ddr_cmd_valid: assert property(p_ddr_cmd_valid) l1_pass[0]++; else begin `uvm_warning("DDR_L1", "Command valid failed"); l1_fail[0]++; end
  cover_p_ddr_cmd_valid: cover property(p_ddr_cmd_valid);
  property p_ddr_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cke == 1 |-> !$isunknown(vif.addr); endproperty
  assert_p_ddr_addr_valid: assert property(p_ddr_addr_valid) l1_pass[1]++; else begin `uvm_warning("DDR_L1", "Address valid failed"); l1_fail[1]++; end
  cover_p_ddr_addr_valid: cover property(p_ddr_addr_valid);
  property p_ddr_data_valid; @(posedge vif.ck) disable iff (!vif.rst_n) (|vif.dqs) == 1'b1 |-> !$isunknown(vif.dq); endproperty
  assert_p_ddr_data_valid: assert property(p_ddr_data_valid) l1_pass[2]++; else begin `uvm_warning("DDR_L1", "Data valid failed"); l1_fail[2]++; end
  cover_p_ddr_data_valid: cover property(p_ddr_data_valid);
  property p_ddr_no_x; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_ddr_no_x: assert property(p_ddr_no_x) l1_pass[3]++; else begin `uvm_warning("DDR_L1", "No X when active failed"); l1_fail[3]++; end
  cover_p_ddr_no_x: cover property(p_ddr_no_x);
  // ---------------- L2: FSM legality (4) ----------------
  property p_ddr_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.ras_n) |-> ##[2:6] $fell(vif.cas_n); endproperty
  assert_p_ddr_tRCD: assert property(p_ddr_tRCD) l2_pass[0]++; else begin `uvm_warning("DDR_L2", "tRCD 2-6 cycles failed"); l2_fail[0]++; end
  cover_p_ddr_tRCD: cover property(p_ddr_tRCD);
  property p_ddr_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.ras_n) |-> ##[2:6] $fell(vif.ras_n); endproperty
  assert_p_ddr_tRP: assert property(p_ddr_tRP) l2_pass[1]++; else begin `uvm_warning("DDR_L2", "tRP 2-6 cycles failed"); l2_fail[1]++; end
  cover_p_ddr_tRP: cover property(p_ddr_tRP);
  property p_ddr_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.ras_n) |-> ##[5:12] $rose(vif.ras_n); endproperty
  assert_p_ddr_tRAS: assert property(p_ddr_tRAS) l2_pass[2]++; else begin `uvm_warning("DDR_L2", "tRAS 5-12 cycles failed"); l2_fail[2]++; end
  cover_p_ddr_tRAS: cover property(p_ddr_tRAS);
  property p_ddr_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cas_n) && vif.we_n == 1 |-> ##[2:6] vif.dqs == 1; endproperty
  assert_p_ddr_tCL: assert property(p_ddr_tCL) l2_pass[3]++; else begin `uvm_warning("DDR_L2", "tCL 2-6 cycles failed"); l2_fail[3]++; end
  cover_p_ddr_tCL: cover property(p_ddr_tCL);
  // ---------------- L3: protocol rules (4) ----------------
  property p_ddr_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> ##[1:7812] vif.cs_n == 0; endproperty
  assert_p_ddr_refresh: assert property(p_ddr_refresh) l3_pass[0]++; else begin `uvm_warning("DDR_L3", "Refresh interval failed"); l3_fail[0]++; end
  cover_p_ddr_refresh: cover property(p_ddr_refresh);
  property p_ddr_reset; @(posedge vif.ck) disable iff (!vif.rst_n) vif.rst_n == 0 |-> ##[100:300] vif.rst_n == 1; endproperty
  assert_p_ddr_reset: assert property(p_ddr_reset) l3_pass[1]++; else begin `uvm_warning("DDR_L3", "Reset timing failed"); l3_fail[1]++; end
  cover_p_ddr_reset: cover property(p_ddr_reset);
  property p_ddr_odt; @(posedge vif.ck) disable iff (!vif.rst_n) vif.we_n == 0 |-> vif.odt == 1; endproperty
  assert_p_ddr_odt: assert property(p_ddr_odt) l3_pass[2]++; else begin `uvm_warning("DDR_L3", "ODT active failed"); l3_fail[2]++; end
  cover_p_ddr_odt: cover property(p_ddr_odt);
  property p_ddr_cke; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ras_n == 0 |-> vif.cke == 1; endproperty
  assert_p_ddr_cke: assert property(p_ddr_cke) l3_pass[3]++; else begin `uvm_warning("DDR_L3", "CKE active failed"); l3_fail[3]++; end
  cover_p_ddr_cke: cover property(p_ddr_cke);

  // ---------------- L4: DDR protocol-specific rules (6) ----------------
  // Command decode helpers
  wire is_act = !vif.cs_n && !vif.act_n;
  wire is_rd  = !vif.cs_n && vif.act_n &&  vif.ras_n && !vif.cas_n &&  vif.we_n;
  wire is_wr  = !vif.cs_n && vif.act_n &&  vif.ras_n && !vif.cas_n && !vif.we_n;
  wire is_cas = is_rd || is_wr;
  wire is_pre = !vif.cs_n && vif.act_n && !vif.ras_n &&  vif.cas_n && !vif.we_n;
  wire is_ref = !vif.cs_n && vif.act_n && !vif.ras_n && !vif.cas_n &&  vif.we_n;
  wire [4:0] cur_bank = vif.bg * 8 + vif.ba;

  // Protocol state tracked for L4 rules
  int unsigned cyc = 0;
  bit          bank_open [32];
  int unsigned act_hist [4];
  int          act_hist_idx = 0;
  int unsigned last_ref_cyc = 0;
  bit          seen_ref = 0;

  always @(posedge vif.ck) begin
    if (!vif.rst_n) begin
      cyc <= 0;
      for (int b = 0; b < 32; b++) bank_open[b] <= 1'b0;
      for (int i = 0; i < 4; i++) act_hist[i] <= 0;
      act_hist_idx <= 0;
      last_ref_cyc <= 0;
      seen_ref <= 1'b0;
    end
    else begin
      cyc <= cyc + 1;
      if (is_act) begin
        bank_open[cur_bank] <= 1'b1;
        act_hist[act_hist_idx] <= cyc;
        act_hist_idx <= (act_hist_idx + 1) % 4;
      end
      if (is_pre) bank_open[cur_bank] <= 1'b0;
      if (is_ref) begin
        for (int b = 0; b < 32; b++) bank_open[b] <= 1'b0;
        last_ref_cyc <= cyc;
        seen_ref <= 1'b1;
      end
    end
  end

  // L4-1: tRCD -- no CAS within tRCD cycles after ACT
  a_ddr_l4_trcd : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act |=> !is_cas[*14])
    else `uvm_error("SVA_L4", "DDR: tRCD violated (CAS too soon after ACT)")

  // L4-2: tRAS -- no PRE within tRAS cycles after ACT
  a_ddr_l4_tras : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act |=> !is_pre[*34])
    else `uvm_error("SVA_L4", "DDR: tRAS violated (PRE too soon after ACT)")

  // L4-3: tFAW -- no more than 4 ACTs inside the rolling tFAW window
  a_ddr_l4_tfaw : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act |-> (act_hist[act_hist_idx] == 0) ||
               (cyc - act_hist[act_hist_idx] > 20))
    else `uvm_error("SVA_L4", "DDR: tFAW violated (5th ACT inside window)")

  // L4-4: bank state legality -- RD/WR only to an open bank
  a_ddr_l4_rdwr_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_cas |-> bank_open[cur_bank])
    else `uvm_error("SVA_L4", "DDR: RD/WR to a closed bank")

  // L4-5: ACT to an already-open bank is illegal (missing PRE)
  a_ddr_l4_act_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act |-> !bank_open[cur_bank])
    else `uvm_error("SVA_L4", "DDR: ACT to an already-open bank")

  // L4-6: refresh interval -- REF at least every tREFI cycles
  a_ddr_l4_trefi : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    seen_ref |-> (cyc - last_ref_cyc <= 3900))
    else `uvm_error("SVA_L4", "DDR: refresh interval exceeded")

  c_ddr_l4_act_to_cas : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act ##[15:19] is_cas);
  c_ddr_l4_full_cycle : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    is_act ##[1:64] is_pre);

  // SVA tier coverage report (was report_phase in the class-based version)
  final begin
    int l1_total = 0, l2_total = 0, l3_total = 0;
    int l1_hit = 0, l2_hit = 0, l3_hit = 0;
    foreach (l1_pass[i]) begin l1_total++; if (l1_pass[i] > 0) l1_hit++; end
    foreach (l2_pass[i]) begin l2_total++; if (l2_pass[i] > 0) l2_hit++; end
    foreach (l3_pass[i]) begin l3_total++; if (l3_pass[i] > 0) l3_hit++; end
    l1_cov = (l1_total > 0) ? (l1_hit * 100.0 / l1_total) : 0;
    l2_cov = (l2_total > 0) ? (l2_hit * 100.0 / l2_total) : 0;
    l3_cov = (l3_total > 0) ? (l3_hit * 100.0 / l3_total) : 0;
    total_cov = (l1_total + l2_total + l3_total > 0)
                ? ((l1_hit + l2_hit + l3_hit) * 100.0 / (l1_total + l2_total + l3_total)) : 0;
    `uvm_info("DDR_RPT", "=== DDR Tiered SVA Report ===", UVM_LOW)
    `uvm_info("DDR_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)",
              l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("DDR_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)",
              l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("DDR_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)",
              l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("DDR_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%%",
              total_cov), UVM_LOW)
  end

endmodule : ddr_compliance_checker
`endif
