// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR Data Integrity Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR_DATA_INTEGRITY_CHECKER_SV
`define DDR_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr_data_integrity_checker (ddr_if vif);

  property p_ddr_dm_mask; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dm == 1 |-> vif.dq == 8'hZZ; endproperty
  assert_p_ddr_dm_mask: assert property(p_ddr_dm_mask) else `uvm_warning("DDR_DI", "DM masks data correctly failed");
  cover_p_ddr_dm_mask: cover property(p_ddr_dm_mask);
  property p_ddr_dqs_edge; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.dqs) |-> !$isunknown(vif.dq); endproperty
  assert_p_ddr_dqs_edge: assert property(p_ddr_dqs_edge) else `uvm_warning("DDR_DI", "DQS edge-aligned with DQ failed");
  cover_p_ddr_dqs_edge: cover property(p_ddr_dqs_edge);
  property p_ddr_burst_len; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 && vif.ras_n == 0 |-> vif.addr[12] inside {0,1}; endproperty
  assert_p_ddr_burst_len: assert property(p_ddr_burst_len) else `uvm_warning("DDR_DI", "Burst length 4 or 8 failed");
  cover_p_ddr_burst_len: cover property(p_ddr_burst_len);

endmodule : ddr_data_integrity_checker
`endif
