// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR Error Handling Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR_ERROR_CHECKER_SV
`define DDR_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr_error_checker (ddr_if vif);

  property p_ddr_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 && vif.ras_n == 0 && vif.cas_n == 0 && vif.we_n == 0 |-> ##[1:7812] vif.cs_n == 0; endproperty
  assert_p_ddr_refresh: assert property(p_ddr_refresh) else `uvm_warning("DDR_ERR", "Refresh interval valid failed");
  cover_p_ddr_refresh: cover property(p_ddr_refresh);
  property p_ddr_nop; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 1 |-> vif.ras_n == 1 && vif.cas_n == 1 && vif.we_n == 1; endproperty
  assert_p_ddr_nop: assert property(p_ddr_nop) else `uvm_warning("DDR_ERR", "NOP when idle failed");
  cover_p_ddr_nop: cover property(p_ddr_nop);

endmodule : ddr_error_checker
`endif
