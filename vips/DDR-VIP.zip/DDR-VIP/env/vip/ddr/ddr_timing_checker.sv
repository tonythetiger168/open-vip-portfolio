// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR Timing & Performance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR_TIMING_CHECKER_SV
`define DDR_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr_timing_checker (ddr_if vif);

  property p_ddr_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.ras_n) |-> ##[2:6] $fell(vif.cas_n); endproperty
  assert_p_ddr_tRCD: assert property(p_ddr_tRCD) else `uvm_warning("DDR_TIM", "tRCD: RAS to CAS delay violated");
  cover_p_ddr_tRCD: cover property(p_ddr_tRCD);
  property p_ddr_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.ras_n) |-> ##[2:6] $fell(vif.ras_n); endproperty
  assert_p_ddr_tRP: assert property(p_ddr_tRP) else `uvm_warning("DDR_TIM", "tRP: Precharge to active violated");
  cover_p_ddr_tRP: cover property(p_ddr_tRP);
  property p_ddr_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.ras_n) |-> ##[5:12] $rose(vif.ras_n); endproperty
  assert_p_ddr_tRAS: assert property(p_ddr_tRAS) else `uvm_warning("DDR_TIM", "tRAS: Active to precharge violated");
  cover_p_ddr_tRAS: cover property(p_ddr_tRAS);
  property p_ddr_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cas_n) && vif.we_n == 1 |-> ##[2:6] vif.dqs == 1; endproperty
  assert_p_ddr_tCL: assert property(p_ddr_tCL) else `uvm_warning("DDR_TIM", "tCL: CAS latency violated");
  cover_p_ddr_tCL: cover property(p_ddr_tCL);

endmodule : ddr_timing_checker
`endif
