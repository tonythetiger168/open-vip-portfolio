// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR Timing & Performance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR_TIMING_CHECKER_SV
`define DDR_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr_timing_checker (ddr_if vif);
  // DDR4 command decode (ACT_n low: ACT; else RAS_n/CAS_n/WE_n)
  wire is_act = !vif.cs_n && !vif.act_n;
  wire is_rd  = !vif.cs_n && vif.act_n &&  vif.ras_n && !vif.cas_n &&  vif.we_n;
  wire is_wr  = !vif.cs_n && vif.act_n &&  vif.ras_n && !vif.cas_n && !vif.we_n;
  wire is_cas = is_rd || is_wr;
  wire is_pre = !vif.cs_n && vif.act_n && !vif.ras_n &&  vif.cas_n && !vif.we_n;
  localparam int TRCD = 15, TRP = 15, TRAS = 35, TCL = 15;   // ddr_cfg defaults

  property p_ddr_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) is_rd |-> ##(TCL+1) !$isunknown(vif.dq); endproperty
  assert_p_ddr_tCL: assert property(p_ddr_tCL) else `uvm_warning("DDR_TIM", "tCL: CAS latency violated");
  cover_p_ddr_tCL: cover property(p_ddr_tCL);

  // Per-bank timing. tRCD, tRP and tRAS hold between commands to the same
  // bank: an ACT to one bank does not hold off a CAS to another, which the
  // old any-bank properties wrongly flagged. Each bank keeps the clock of its
  // latest ACT and PRE (the properties sample them, so the difference is the
  // distance in clocks; the action block runs after the clock count moved
  // on, hence the - 1 in the messages).
  wire [4:0] bank = 5'(vif.bg * 8 + vif.ba);
  int unsigned cyc = 0;
  int unsigned act_at [32], pre_at [32];
  bit          seen_act [32], seen_pre [32];
  always @(posedge vif.ck) begin
    cyc <= cyc + 1;
    if (!vif.rst_n) begin
      foreach (seen_act[i]) begin seen_act[i] <= 1'b0; seen_pre[i] <= 1'b0; end
    end else begin
      if (is_act) begin act_at[bank] <= cyc; seen_act[bank] <= 1'b1; end
      if (is_pre) begin pre_at[bank] <= cyc; seen_pre[bank] <= 1'b1; end
    end
  end
  wire rcd_bad = is_cas && seen_act[bank] && (cyc - act_at[bank] < TRCD);
  wire ras_bad = is_pre && seen_act[bank] && (cyc - act_at[bank] < TRAS);
  wire rp_bad  = is_act && seen_pre[bank] && (cyc - pre_at[bank] < TRP);

  property p_ddr_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) is_cas |-> !rcd_bad; endproperty
  assert_p_ddr_tRCD: assert property(p_ddr_tRCD) else `uvm_error("DDR_TIM", $sformatf("tRCD: bank %0d CAS %0d clocks after its ACT, needs %0d", bank, cyc - act_at[bank] - 1, TRCD));
  cover_p_ddr_tRCD: cover property(@(posedge vif.ck) disable iff (!vif.rst_n) is_cas && seen_act[bank]);
  property p_ddr_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) is_pre |-> !ras_bad; endproperty
  assert_p_ddr_tRAS: assert property(p_ddr_tRAS) else `uvm_error("DDR_TIM", $sformatf("tRAS: bank %0d PRE %0d clocks after its ACT, needs %0d", bank, cyc - act_at[bank] - 1, TRAS));
  cover_p_ddr_tRAS: cover property(@(posedge vif.ck) disable iff (!vif.rst_n) is_pre && seen_act[bank]);
  property p_ddr_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) is_act |-> !rp_bad; endproperty
  assert_p_ddr_tRP: assert property(p_ddr_tRP) else `uvm_error("DDR_TIM", $sformatf("tRP: bank %0d ACT %0d clocks after its PRE, needs %0d", bank, cyc - pre_at[bank] - 1, TRP));
  cover_p_ddr_tRP: cover property(@(posedge vif.ck) disable iff (!vif.rst_n) is_act && seen_pre[bank]);

endmodule : ddr_timing_checker
`endif
