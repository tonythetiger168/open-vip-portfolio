// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR Timing & Performance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR_TIMING_CHECKER_SV
`define DDR_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr_timing_checker (ddr_if vif);
  // DDR4 command decode (ACT_n low: ACT; else RAS_n/CAS_n/WE_n)
  wire is_act = !vif.cs_n && !vif.act_n;
  wire is_rd  = !vif.cs_n && vif.act_n &&  vif.ras_n && !vif.cas_n &&  vif.we_n;
  wire is_wr  = !vif.cs_n && vif.act_n &&  vif.ras_n && !vif.cas_n && !vif.we_n;
  wire is_cas = is_rd || is_wr;
  wire is_pre = !vif.cs_n && vif.act_n && !vif.ras_n &&  vif.cas_n && !vif.we_n;
  localparam int TRCD = 15, TRP = 15, TRAS = 35, TCL = 15;   // ddr_cfg defaults

  property p_ddr_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) is_act |=> !is_cas [*TRCD-1]; endproperty
  assert_p_ddr_tRCD: assert property(p_ddr_tRCD) else `uvm_warning("DDR_TIM", "tRCD: RAS to CAS delay violated");
  cover_p_ddr_tRCD: cover property(p_ddr_tRCD);
  property p_ddr_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) is_pre |=> !is_act [*TRP-1]; endproperty
  assert_p_ddr_tRP: assert property(p_ddr_tRP) else `uvm_warning("DDR_TIM", "tRP: Precharge to active violated");
  cover_p_ddr_tRP: cover property(p_ddr_tRP);
  property p_ddr_tRAS; @(posedge vif.ck) disable iff (!vif.rst_n) is_act |=> !is_pre [*TRAS-1]; endproperty
  assert_p_ddr_tRAS: assert property(p_ddr_tRAS) else `uvm_warning("DDR_TIM", "tRAS: Active to precharge violated");
  cover_p_ddr_tRAS: cover property(p_ddr_tRAS);
  property p_ddr_tCL; @(posedge vif.ck) disable iff (!vif.rst_n) is_rd |-> ##(TCL+1) !$isunknown(vif.dq); endproperty
  assert_p_ddr_tCL: assert property(p_ddr_tCL) else `uvm_warning("DDR_TIM", "tCL: CAS latency violated");
  cover_p_ddr_tCL: cover property(p_ddr_tCL);

endmodule : ddr_timing_checker
`endif
