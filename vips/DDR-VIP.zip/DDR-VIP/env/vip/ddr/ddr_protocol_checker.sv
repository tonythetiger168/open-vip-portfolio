// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// DDR Protocol Compliance Checker
// NOTE: deepened to a module-based SVA checker (concurrent assertions are
// module items); the interface port keeps the original vif.* references.

`ifndef DDR_PROTOCOL_CHECKER_SV
`define DDR_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ddr_protocol_checker (ddr_if vif);

  property p_ddr_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> vif.ras_n != vif.cas_n || vif.we_n != 1'b1; endproperty
  assert_p_ddr_cmd_valid: assert property(p_ddr_cmd_valid) else `uvm_warning("DDR_CHK", "Command valid when CS active failed");
  cover_p_ddr_cmd_valid: cover property(p_ddr_cmd_valid);
  property p_ddr_cke_active; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ras_n == 0 |-> vif.cke == 1; endproperty
  assert_p_ddr_cke_active: assert property(p_ddr_cke_active) else `uvm_warning("DDR_CHK", "CKE high for active commands failed");
  cover_p_ddr_cke_active: cover property(p_ddr_cke_active);
  property p_ddr_odt_write; @(posedge vif.ck) disable iff (!vif.rst_n) vif.we_n == 0 && vif.cs_n == 0 |-> vif.odt == 1; endproperty
  assert_p_ddr_odt_write: assert property(p_ddr_odt_write) else `uvm_warning("DDR_CHK", "ODT active during write failed");
  cover_p_ddr_odt_write: cover property(p_ddr_odt_write);
  property p_ddr_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_ddr_addr_valid: assert property(p_ddr_addr_valid) else `uvm_warning("DDR_CHK", "Address valid when CS active failed");
  cover_p_ddr_addr_valid: cover property(p_ddr_addr_valid);
  property p_ddr_ba_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ba); endproperty
  assert_p_ddr_ba_valid: assert property(p_ddr_ba_valid) else `uvm_warning("DDR_CHK", "Bank address valid failed");
  cover_p_ddr_ba_valid: cover property(p_ddr_ba_valid);
  property p_ddr_dq_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dqs == 1 |-> !$isunknown(vif.dq); endproperty
  assert_p_ddr_dq_valid: assert property(p_ddr_dq_valid) else `uvm_warning("DDR_CHK", "DQ valid during data phase failed");
  cover_p_ddr_dq_valid: cover property(p_ddr_dq_valid);

endmodule : ddr_protocol_checker
`endif
