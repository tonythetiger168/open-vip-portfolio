// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// Memory UVM Environment Package (DDR deepened with end-to-end scoreboard)
//------------------------------------------------------------------------------
package memory_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import ddr_pkg::*;
  import lpddr_pkg::*;
  import hbm_pkg::*;
  import ufs_pkg::*;
  import unipro_pkg::*;
  import emmc_pkg::*;
  import onfi_pkg::*;
  import sd_pkg::*;
  import memory_coverage_pkg::*;

  `uvm_analysis_imp_decl(_ddr_exp)
  `uvm_analysis_imp_decl(_lpddr)
  `uvm_analysis_imp_decl(_hbm)
  `uvm_analysis_imp_decl(_ufs)
  `uvm_analysis_imp_decl(_unipro)
  `uvm_analysis_imp_decl(_emmc)
  `uvm_analysis_imp_decl(_onfi)
  `uvm_analysis_imp_decl(_sd)

  class memory_env_cfg extends uvm_object;
    `uvm_object_utils(memory_env_cfg)
    ddr_cfg ddr_cfg_h;
    lpddr_cfg lpddr_cfg_h;
    hbm_cfg hbm_cfg_h;
    ufs_cfg ufs_cfg_h;
    unipro_cfg unipro_cfg_h;
    emmc_cfg emmc_cfg_h;
    onfi_cfg onfi_cfg_h;
    sd_cfg sd_cfg_h;
    bit scoreboard_enable = 1;
    bit coverage_enable = 1;
    int num_ddr = 30;
    int num_lpddr = 30;
    int num_hbm = 30;
    int num_ufs = 20;
    int num_unipro = 20;
    int num_emmc = 20;
    int num_onfi = 20;
    int num_sd = 20;
    function new(string name = "memory_env_cfg");
      super.new(name);
      ddr_cfg_h = ddr_cfg::type_id::create("ddr_cfg_h");
      lpddr_cfg_h = lpddr_cfg::type_id::create("lpddr_cfg_h");
      hbm_cfg_h = hbm_cfg::type_id::create("hbm_cfg_h");
      ufs_cfg_h = ufs_cfg::type_id::create("ufs_cfg_h");
      unipro_cfg_h = unipro_cfg::type_id::create("unipro_cfg_h");
      emmc_cfg_h = emmc_cfg::type_id::create("emmc_cfg_h");
      onfi_cfg_h = onfi_cfg::type_id::create("onfi_cfg_h");
      sd_cfg_h = sd_cfg::type_id::create("sd_cfg_h");
    endfunction
  endclass

  // End-to-end scoreboard. For DDR the driver-issued (expected) stream is
  // compared against the monitor-decoded (observed) stream; other protocol
  // exports keep their observation counters.
  class memory_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(memory_scoreboard)
    uvm_analysis_imp #(ddr_seq_item, memory_scoreboard) ddr_export;
    uvm_analysis_imp_lpddr #(lpddr_seq_item, memory_scoreboard) lpddr_export;
    uvm_analysis_imp_hbm #(hbm_seq_item, memory_scoreboard) hbm_export;
    uvm_analysis_imp_ufs #(ufs_seq_item, memory_scoreboard) ufs_export;
    uvm_analysis_imp_unipro #(unipro_seq_item, memory_scoreboard) unipro_export;
    uvm_analysis_imp_emmc #(emmc_seq_item, memory_scoreboard) emmc_export;
    uvm_analysis_imp_onfi #(onfi_seq_item, memory_scoreboard) onfi_export;
    uvm_analysis_imp_sd #(sd_seq_item, memory_scoreboard) sd_export;
    // DDR expected (driver) stream
    uvm_analysis_imp_ddr_exp #(ddr_seq_item, memory_scoreboard) ddr_exp_export;

    int ddr_count = 0, lpddr_count = 0, hbm_count = 0, ufs_count = 0;
    int unipro_count = 0, emmc_count = 0, onfi_count = 0, sd_count = 0;

    // DDR end-to-end comparison state
    ddr_seq_item exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      ddr_export = new("ddr_export", this);
      lpddr_export = new("lpddr_export", this);
      hbm_export = new("hbm_export", this);
      ufs_export = new("ufs_export", this);
      unipro_export = new("unipro_export", this);
      emmc_export = new("emmc_export", this);
      onfi_export = new("onfi_export", this);
      sd_export = new("sd_export", this);
      ddr_exp_export = new("ddr_exp_export", this);
    endfunction

    virtual function void write(ddr_seq_item item);
      ddr_count++;
      obs_q.push_back(item); check();
    endfunction
    virtual function void write_lpddr(lpddr_seq_item item);
      lpddr_count++;
      
    endfunction
    virtual function void write_hbm(hbm_seq_item item);
      hbm_count++;
      
    endfunction
    virtual function void write_ufs(ufs_seq_item item);    ufs_count++;    endfunction
    virtual function void write_unipro(unipro_seq_item item); unipro_count++; endfunction
    virtual function void write_emmc(emmc_seq_item item);   emmc_count++;   endfunction
    virtual function void write_onfi(onfi_seq_item item);   onfi_count++;   endfunction
    virtual function void write_sd(sd_seq_item item);     sd_count++;     endfunction

    // DDR expected stream (from ddr_driver.drv_ap)
    function void write_ddr_exp(ddr_seq_item item);
      exp_q.push_back(item);
      check();
    endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        ddr_seq_item e = exp_q.pop_front();
        ddr_seq_item o = obs_q.pop_front();
        if (compare_ddr(e, o))
          n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("DDR mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function bit compare_ddr(ddr_seq_item e, ddr_seq_item o);
      return (e.cmd_type == o.cmd_type) && (e.addr == o.addr) && (e.bank == o.bank) && (e.bank_group == o.bank_group);
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
      `uvm_info(get_type_name(), "  MEMORY SCOREBOARD REPORT", UVM_LOW)
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("DDR:    %0d", ddr_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("LPDDR:  %0d", lpddr_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("HBM:    %0d", hbm_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("UFS:    %0d", ufs_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("UniPro: %0d", unipro_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("eMMC:   %0d", emmc_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("ONFI:   %0d", onfi_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("SD:     %0d", sd_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf(
        "DDR end-to-end: n_matches=%0d n_mismatches=%0d",
        n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches)
        `uvm_error(get_type_name(), "DDR end-to-end n_mismatches detected")
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
    endfunction
  endclass

  class memory_env extends uvm_env;
    `uvm_component_utils(memory_env)
    ddr_agent ddr_ag;
    lpddr_agent lpddr_ag;
    hbm_agent hbm_ag;
    ufs_agent ufs_ag;
    unipro_agent unipro_ag;
    emmc_agent emmc_ag;
    onfi_agent onfi_ag;
    sd_agent sd_ag;
    ddr_coverage ddr_cov;
    lpddr_coverage lpddr_cov;
    hbm_coverage hbm_cov;
    ufs_coverage ufs_cov;
    unipro_coverage unipro_cov;
    emmc_coverage emmc_cov;
    onfi_coverage onfi_cov;
    sd_coverage sd_cov;
    memory_coverage_report_checker cov_chk;
    memory_scoreboard sb;
    memory_env_cfg cfg;

    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(memory_env_cfg)::get(this, "", "cfg", cfg))
        cfg = memory_env_cfg::type_id::create("cfg");
      ddr_ag = ddr_agent::type_id::create("ddr_ag", this);
      if (cfg.coverage_enable) begin
        ddr_cov = ddr_coverage::type_id::create("ddr_cov", this);
        cov_chk = memory_coverage_report_checker::type_id::create("cov_chk", this);
      end
      if (cfg.scoreboard_enable)
        sb = memory_scoreboard::type_id::create("sb", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.scoreboard_enable) begin
        // DDR end-to-end: driver (expected) + monitor (observed)
        ddr_ag.drv.drv_ap.connect(sb.ddr_exp_export);
        ddr_ag.mon.item_collected_port.connect(sb.ddr_export);
      end
      if (cfg.coverage_enable) begin
        ddr_ag.mon.item_collected_port.connect(ddr_cov.analysis_export);
        cov_chk.ddr_cov_h = ddr_cov;
      end
    endfunction
  endclass
endpackage : memory_env_pkg
