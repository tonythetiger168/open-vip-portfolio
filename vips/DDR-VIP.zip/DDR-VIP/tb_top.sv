// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
//------------------------------------------------------------------------------
// DDR UVM Testbench Top
// Closed loop: VIP driver -> ddr_if -> DRAM functional memory model
// (bank/row/col storage + refresh counter); module-based SVA checkers.
//------------------------------------------------------------------------------
`timescale 1ns/1ps
import uvm_pkg::*;
`include "uvm_macros.svh"
import memory_test_pkg::*;

module tb_top;
  // Clocks / resets for all memory protocols (structure preserved)
  logic ddr_ck = 0, ddr_rst_n = 0;
  logic lpddr_ck = 0, lpddr_rst_n = 0;
  logic hbm_ck = 0, hbm_rst_n = 0;
  logic ufs_clk = 0, ufs_rst_n = 0;
  logic unipro_clk = 0, unipro_rst_n = 0;
  logic emmc_clk = 0, emmc_rst_n = 0;
  logic onfi_clk = 0, onfi_rst_n = 0;
  logic sd_clk = 0, sd_rst_n = 0;
  always #5  ddr_ck = ~ddr_ck;
  always #5  lpddr_ck = ~lpddr_ck;
  always #5  hbm_ck = ~hbm_ck;
  always #10 ufs_clk = ~ufs_clk;
  always #10 unipro_clk = ~unipro_clk;
  always #20 emmc_clk = ~emmc_clk;
  always #50 onfi_clk = ~onfi_clk;
  always #20 sd_clk = ~sd_clk;
  initial begin
    #100;
    ddr_rst_n = 1;
    lpddr_rst_n = 1;
    hbm_rst_n = 1;
    ufs_rst_n = 1;
    unipro_rst_n = 1;
    emmc_rst_n = 1;
    onfi_rst_n = 1;
    sd_rst_n = 1;
  end

  ddr_if ddr_if_inst (.ck(ddr_ck), .ck_n(~ddr_ck), .rst_n(ddr_rst_n));
  lpddr_if lpddr_if_inst (.ck(lpddr_ck), .ck_n(~lpddr_ck), .cke(1'b1),
                          .rst_n(lpddr_rst_n));
  hbm_if hbm_if_inst (.ck(hbm_ck), .ck_n(~hbm_ck), .rst_n(hbm_rst_n));
  ufs_if ufs_if_inst (.ref_clk(ufs_clk), .rst_n(ufs_rst_n));
  unipro_if unipro_if_inst (.clk(unipro_clk), .rst_n(unipro_rst_n));
  emmc_if emmc_if_inst (.clk(emmc_clk), .rst_n(emmc_rst_n));
  onfi_if onfi_if_inst (.clk(onfi_clk), .rst_n(onfi_rst_n));
  sd_if sd_if_inst (.clk(sd_clk), .rst_n(sd_rst_n));

  // DRAM functional model: closes the read/write data loop
  ddr_mem_model #(.TCL(15), .TCWL(14)) dut (.vif(ddr_if_inst));

  // Fault injection, off unless a test sets ddr_corrupt_reads (the
  // memory_ddr_data_err_test): at each RD the word stored at the burst's
  // start column gets bit 0 flipped (once per column) before the model
  // reads it out, like a cell that lost its charge. The scoreboard must
  // report the bad beats.
  bit ddr_corrupt = 0;
  bit ddr_flipped [bit [63:0]];
  initial begin
    #1;
    void'(uvm_config_db#(bit)::get(null, "", "ddr_corrupt_reads", ddr_corrupt));
  end
  always @(posedge ddr_ck)
    if (ddr_corrupt && ddr_rst_n && !ddr_if_inst.cs_n && ddr_if_inst.act_n &&
        ddr_if_inst.ras_n && !ddr_if_inst.cas_n && ddr_if_inst.we_n) begin
      int b;
      bit [63:0] k;
      b = ddr_if_inst.bg * 8 + ddr_if_inst.ba;
      k = dut.key(b, dut.open_row[b], 16'(ddr_if_inst.addr[9:0]));
      if (dut.mem.exists(k) && !ddr_flipped.exists(k)) begin
        dut.mem[k] = dut.mem[k] ^ 64'h1;
        ddr_flipped[k] = 1;
      end
    end

  // SVA checkers (module-based; L1/L2/L3 legacy + L1-L4 consolidated)
  ddr_protocol_checker       u_protocol_chk (.vif(ddr_if_inst));
  ddr_data_integrity_checker u_di_chk       (.vif(ddr_if_inst));
  ddr_timing_checker         u_timing_chk   (.vif(ddr_if_inst));
  ddr_error_checker          u_error_chk    (.vif(ddr_if_inst));
  ddr_compliance_checker     u_compliance   (.vif(ddr_if_inst));

  initial begin
    uvm_config_db#(virtual ddr_if)::set(null, "*.ddr_*", "vif", ddr_if_inst);
    uvm_config_db#(virtual lpddr_if)::set(null, "*.lpddr_*", "vif", lpddr_if_inst);
    uvm_config_db#(virtual hbm_if)::set(null, "*.hbm_*", "vif", hbm_if_inst);
    uvm_config_db#(virtual ufs_if)::set(null, "*.ufs_*", "vif", ufs_if_inst);
    uvm_config_db#(virtual unipro_if)::set(null, "*.unipro_*", "vif", unipro_if_inst);
    uvm_config_db#(virtual emmc_if)::set(null, "*.emmc_*", "vif", emmc_if_inst);
    uvm_config_db#(virtual onfi_if)::set(null, "*.onfi_*", "vif", onfi_if_inst);
    uvm_config_db#(virtual sd_if)::set(null, "*.sd_*", "vif", sd_if_inst);
    run_test();
  end

  initial begin
    $dumpfile("memory_tb.vcd");
    $dumpvars(0, tb_top);
  end
endmodule

//------------------------------------------------------------------------------
// DDR DRAM functional model
// - bank/row tracking: ACT opens a row, PRE closes it
// - column storage in an associative array keyed by {bank,row,col};
//   beat i of a burst is column col[9:0] + i, BL16 when A12 is set, else 8
// - write data captured tCWL after WR; read data driven tCL after RD
// - refresh command counter
//------------------------------------------------------------------------------
module ddr_mem_model #(parameter int TCL = 15, parameter int TCWL = 14)
  (ddr_if vif);

  localparam int NB = 32;

  bit        bank_open [NB];
  bit [15:0] open_row  [NB];
  bit [63:0] mem [bit [63:0]];   // sparse column storage
  int unsigned refresh_count = 0;
  int unsigned write_count = 0, read_count = 0;

  function automatic bit [63:0] key(input int bank, input bit [15:0] row,
                                    input bit [15:0] col);
    return {16'h0, bank[7:0], row, col};
  endfunction

  // a burst covers BL consecutive columns from its start column (A9:A0);
  // A12 selects BL16, else burst chop 8
  task automatic do_write(input int bank, input bit [15:0] col, input int bl);
    bit [15:0] row;
    repeat (TCWL) @(posedge vif.ck);
    row = open_row[bank];
    for (int i = 0; i < bl; i++) begin
      mem[key(bank, row, 16'(col[9:0] + i))] = vif.dq;
      write_count++;
      @(posedge vif.ck);
    end
  endtask

  task automatic do_read(input int bank, input bit [15:0] col, input int bl);
    bit [15:0] row;
    repeat (TCL) @(posedge vif.ck);
    row = open_row[bank];
    for (int i = 0; i < bl; i++) begin
      vif.dq <= mem.exists(key(bank, row, 16'(col[9:0] + i)))
                ? mem[key(bank, row, 16'(col[9:0] + i))] : 64'h0;
      read_count++;
      @(posedge vif.ck);
    end
  endtask

  always @(posedge vif.ck) begin
    if (vif.rst_n && !vif.cs_n) begin
      if (!vif.act_n || (!vif.ras_n && vif.cas_n && vif.we_n)) begin // ACT
        bank_open[vif.bg * 8 + vif.ba] <= 1'b1;
        open_row[vif.bg * 8 + vif.ba]  <= vif.addr[15:0];
      end
      else if (vif.ras_n && !vif.cas_n && !vif.we_n)     // WR
        fork do_write(vif.bg * 8 + vif.ba, vif.addr[15:0], vif.addr[12] ? 16 : 8); join_none
      else if (vif.ras_n && !vif.cas_n && vif.we_n)      // RD
        fork do_read(vif.bg * 8 + vif.ba, vif.addr[15:0], vif.addr[12] ? 16 : 8); join_none
      else if (!vif.ras_n && vif.cas_n && !vif.we_n)     // PRE
        bank_open[vif.bg * 8 + vif.ba] <= 1'b0;
      else if (!vif.ras_n && !vif.cas_n && vif.we_n) begin // REF
        refresh_count++;
        for (int b = 0; b < NB; b++) bank_open[b] <= 1'b0;
      end
    end
  end

  final
    $display("DDR_mem_model: reads=%0d writes=%0d refreshes=%0d",
             read_count, write_count, refresh_count);
endmodule
