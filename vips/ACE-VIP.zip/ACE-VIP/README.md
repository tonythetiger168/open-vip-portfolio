# ACE Open IP

ACE (AXI Coherency Extension) -- synthesizable ACE cached-master/slave model
Scope: AXI4 main channels (AW/W/B/AR/R, INCR burst) + ACE snoop channels
(AC/CR/CD) with an internal 64-line cache model (valid/dirty/tag/data).
Dirty-hit snoops return data on CD; MakeUnique/CleanInvalid invalidate.
Open IP design implementation v2.5.1 -- Apache-2.0

## Package contents

- `rtl/ACE_top.sv` -- synthesizable RTL (top: `ACE_top`)
- `tb/ACE_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/ACE_yosys.ys` -- Yosys synthesis script
- `syn/ACE_dc.tcl` -- Synopsys Design Compiler script
- `syn/ACE.sdc` -- timing constraints
- `sim/filelist_ACE.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.5.1: constrained-random testbenches (portable `ifdef VERILATOR`); RTL fixes: echo-copy/MEMCH OOB bounds, RFFE/HSI/I3C/SPMI/QSPI/1-Wire serial bugs, USB2.0 run_cnt, USB3 give-up, CXL-family STP/LEN=8, WTB tok_irq, NVMe TX replay bound. Verified: iverilog sim PASS.
