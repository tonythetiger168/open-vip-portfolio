// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- I2C testbench top with a functional I2C slave DUT model

`ifndef I2C_TB_SV
`define I2C_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import i2c_defs_pkg::*;
import i2c_pkg::*;
import i2c_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  i2c_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  i2c_slave_model #(.SLAVE_ADDR(7'h50)) dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual i2c_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional I2C slave: ACKs its address, stores write data into a
// small memory, returns memory contents on read. Pulls SDA low via
// slv_sda_oe (wired-AND resolved in the interface).
module i2c_slave_model #(parameter bit [6:0] SLAVE_ADDR = 7'h50)
  (i2c_if vif);

  bit [7:0] mem [0:127];
  bit [6:0] cur_addr;
  bit [3:0] bit_cnt;

  initial begin
    vif.slv_sda_o  = 0;
    vif.slv_sda_oe = 0;
  end

  // ACK drive: pull SDA low during the 9th clock when addressed.
  // sample_byte() returns just after the 8th bit's falling edge, so the
  // slave pulls low immediately (ACK valid through the 9th high phase)
  // and releases at the 9th falling edge -- standard I2C ACK timing.
  task automatic drive_ack();
    vif.slv_sda_oe = 1; vif.slv_sda_o = 0;      // ACK
    @(negedge vif.scl_i);
    vif.slv_sda_oe = 0;                          // release
  endtask

  task automatic sample_byte(output bit [7:0] d);
    for (int i = 7; i >= 0; i--) begin
      @(posedge vif.scl_i);
      d[i] = vif.sda_i;
      @(negedge vif.scl_i);
    end
  endtask

  // send_byte is entered just after a falling edge (address-ACK release or
  // the previous byte's NACK window), so the first data bit is driven
  // immediately; each following bit is driven at the next falling edge.
  task automatic send_byte(input bit [7:0] d, output bit master_nack);
    vif.slv_sda_oe = 1; vif.slv_sda_o = d[7];
    for (int i = 6; i >= 0; i--) begin
      @(negedge vif.scl_i);
      vif.slv_sda_oe = 1; vif.slv_sda_o = d[i];
    end
    @(negedge vif.scl_i);
    vif.slv_sda_oe = 0;
    @(posedge vif.scl_i);
    master_nack = vif.sda_i;
    @(negedge vif.scl_i);          // leave synchronised at a falling edge
  endtask

  initial forever begin
    bit [7:0] d;
    bit rw;
    bit stop;
    // Wait for START (SDA falls while SCL high) -- @(negedge sda iff scl)
    // rewritten as a polling loop (iff event control is not portable)
    stop = 0;
    while (!stop) begin
      @(negedge vif.sda_i);
      if (vif.scl_i === 1'b1) stop = 1;
    end
    sample_byte(d);
    {cur_addr, rw} = d;
    if (cur_addr == SLAVE_ADDR) begin
      drive_ack();
      if (!rw) begin                       // master writes to slave
        sample_byte(d);
        mem[cur_addr] = d;
        drive_ack();
        // wait for STOP (SDA rises while SCL high); SDA is held low by the
        // slave during the ACK window, so STOP can only follow the release
        stop = 0;
        while (!stop) begin
          @(posedge vif.sda_i);
          if (vif.scl_i === 1'b1) stop = 1;
        end
      end else begin                       // master reads from slave
        bit nack;
        send_byte(mem[cur_addr], nack);
        while (!nack) send_byte(mem[cur_addr], nack);
      end
    end
  end
endmodule
`endif
