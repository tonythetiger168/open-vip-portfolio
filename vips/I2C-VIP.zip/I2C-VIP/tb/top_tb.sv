// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- I2C testbench top with a functional I2C slave DUT model

`ifndef I2C_TB_SV
`define I2C_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import i2c_defs_pkg::*;
import i2c_pkg::*;
import i2c_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  i2c_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  i2c_slave_model #(.SLAVE_ADDR(7'h50)) dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual i2c_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional I2C slave: ACKs its address, stores write data into a
// small memory, returns memory contents on read. Pulls SDA low via
// slv_sda_oe (wired-AND resolved in the interface).
module i2c_slave_model #(parameter bit [6:0] SLAVE_ADDR = 7'h50)
  (i2c_if vif);

  bit [7:0] mem [0:127];
  bit [6:0] cur_addr;
  bit [3:0] bit_cnt;

  initial begin
    vif.slv_sda_o  = 0;
    vif.slv_sda_oe = 0;
  end

  // ACK drive: pull SDA low during the 9th clock when addressed.
  // sample_byte() returns just after the 8th bit's falling edge, so the
  // slave pulls low immediately (ACK valid through the 9th high phase)
  // and releases at the 9th falling edge -- standard I2C ACK timing.
  task automatic drive_ack();
    vif.slv_sda_oe = 1; vif.slv_sda_o = 0;      // ACK
    @(negedge vif.scl_i);
    vif.slv_sda_oe = 0;                          // release
  endtask

  task automatic sample_byte(output bit [7:0] d);
    for (int i = 7; i >= 0; i--) begin
      @(posedge vif.scl_i);
      d[i] = vif.sda_i;
      @(negedge vif.scl_i);
    end
  endtask

  // Like sample_byte, but ends early with stop=1 when SDA changes while
  // SCL is high: a rise is a STOP, a fall a repeated START (rs=1). The loops
  // end on the stop flag rather than a return statement: some simulators
  // (Icarus Verilog 13) skip the copy-out of output arguments on return.
  task automatic sample_byte_or_stop(output bit [7:0] d, output bit stop, output bit rs);
    bit s = 0, r = 0;
    for (int i = 7; i >= 0 && !s; i--) begin
      @(posedge vif.scl_i);
      d[i] = vif.sda_i;
      forever begin
        @(vif.sda_i or vif.scl_i);
        if (vif.scl_i !== 1'b1) break;            // SCL fell: next bit
        if (vif.sda_i !== d[i]) begin             // SDA moved while SCL high
          s = 1;
          r = (vif.sda_i === 1'b0);
          break;
        end
      end
    end
    stop = s; rs = r;
  endtask

  // send_byte is entered just after a falling edge (address-ACK release or
  // the previous byte's NACK window), so the first data bit is driven
  // immediately; each following bit is driven at the next falling edge.
  task automatic send_byte(input bit [7:0] d, output bit master_nack);
    vif.slv_sda_oe = 1; vif.slv_sda_o = d[7];
    for (int i = 6; i >= 0; i--) begin
      @(negedge vif.scl_i);
      vif.slv_sda_oe = 1; vif.slv_sda_o = d[i];
    end
    @(negedge vif.scl_i);
    vif.slv_sda_oe = 0;
    @(posedge vif.scl_i);
    master_nack = vif.sda_i;
    @(negedge vif.scl_i);          // leave synchronised at a falling edge
  endtask

  bit restart = 0;                         // repeated START already seen
  initial forever begin
    bit [7:0] d;
    bit rw;
    bit stop;
    bit rs;
    // Wait for START (SDA falls while SCL high) -- @(negedge sda iff scl)
    // rewritten as a polling loop (iff event control is not portable); a
    // repeated START seen after a write skips the wait
    if (!restart) begin
      stop = 0;
      while (!stop) begin
        @(negedge vif.sda_i);
        if (vif.scl_i === 1'b1) stop = 1;
      end
    end
    restart = 0;
    sample_byte(d);
    {cur_addr, rw} = d;
    if (cur_addr == SLAVE_ADDR) begin
      drive_ack();
      if (!rw) begin                       // master writes to slave
        // ACK every data byte (each one replaces the register, like a
        // single-port I/O expander) until STOP or a repeated START. The
        // loop ends on the stop flag, not break: Icarus Verilog 13 does not
        // leave a forever loop on a break from a block that declares a
        // variable.
        stop = 0;
        while (!stop) begin
          sample_byte_or_stop(d, stop, rs);
          if (stop) restart = rs;
          else begin
            mem[cur_addr] = d;
            drive_ack();
          end
        end
      end else begin                       // master reads from slave
        bit nack;
        send_byte(mem[cur_addr], nack);
        while (!nack) send_byte(mem[cur_addr], nack);
      end
    end
  end
endmodule
`endif
