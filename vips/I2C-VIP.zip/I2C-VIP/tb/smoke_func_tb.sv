// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2025 Functional smoke testbench (I2C slave memory write/read)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened i2c_slave_model.
// DUT behaviour (from dut_i2c_slave_model.sv):
//   - 7-bit slave address 7'h50, byte memory mem[0:127]
//   - START = SDA falling while SCL high; STOP = SDA rising while SCL high
//   - write transfer: addr+W, ACK, one data byte -> mem[0x50], ACK
//   - read transfer:  addr+R, ACK, slave shifts out mem[0x50] until NACK
//   - slave ACK = slv_sda_oe && !slv_sda_o during the 9th clock
// The model drives a separate output pair (slv_sda_o/oe), so the tb
// computes the effective SDA line as slv_sda_oe ? slv_sda_o : sda_i.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic vif_sda_i = 1'b1;   // master-driven SDA (released = 1)
  logic vif_scl_i = 1'b1;
  wire  vif_slv_sda_o;
  wire  vif_slv_sda_oe;

  wire sda_line = vif_slv_sda_oe ? vif_slv_sda_o : vif_sda_i;

  i2c_slave_model #(.SLAVE_ADDR(7'h50)) u_dut (
    .vif_sda_i(vif_sda_i), .vif_scl_i(vif_scl_i),
    .vif_slv_sda_o(vif_slv_sda_o), .vif_slv_sda_oe(vif_slv_sda_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic i2c_start();
    vif_sda_i = 1'b1; vif_scl_i = 1'b1; #200;
    vif_sda_i = 1'b0; #200;            // START: SDA falls while SCL high
    vif_scl_i = 1'b0; #200;
  endtask

  task automatic i2c_stop();
    vif_sda_i = 1'b0; #200;
    vif_scl_i = 1'b1; #200;
    vif_sda_i = 1'b1; #400;            // STOP: SDA rises while SCL high
  endtask

  // returns 1 if the slave ACKed (pulled SDA low in the 9th clock)
  task automatic i2c_send_byte(input bit [7:0] d, output bit ack);
    for (int i = 7; i >= 0; i--) begin
      vif_sda_i = d[i]; #100;
      vif_scl_i = 1'b1; #200;
      vif_scl_i = 1'b0; #100;
    end
    vif_sda_i = 1'b1; #100;            // release for ACK window
    vif_scl_i = 1'b1; #100;
    ack = (vif_slv_sda_oe === 1'b1) && (vif_slv_sda_o === 1'b0);
    #100;
    vif_scl_i = 1'b0; #100;
  endtask

  task automatic i2c_recv_byte(output bit [7:0] d, input bit nack);
    for (int i = 7; i >= 0; i--) begin
      vif_scl_i = 1'b0; #100;
      vif_scl_i = 1'b1; #100;
      d[i] = sda_line;                 // sample slave-driven data mid-high
      #100;
    end
    vif_scl_i = 1'b0; #100;
    vif_sda_i = nack;                  // NACK=1 ends the read
    vif_scl_i = 1'b1; #200;
    vif_scl_i = 1'b0; #100;
  endtask

  bit ack;
  bit [7:0] rb;

  initial begin
    #1000;

    // 1. write 0xA6 to the addressed slave
    i2c_start();
    i2c_send_byte({7'h50, 1'b0}, ack);
    chk(ack, "write: addr 0x50+W ACKed");
    i2c_send_byte(8'hA6, ack);
    chk(ack, "write: data byte ACKed");
    i2c_stop();

    // 2. read it back
    i2c_start();
    i2c_send_byte({7'h50, 1'b1}, ack);
    chk(ack, "read: addr 0x50+R ACKed");
    i2c_recv_byte(rb, 1'b1);           // master NACKs to end the read
    chk(rb === 8'hA6, "read: data == 0xA6 (write/read consistency)");
    i2c_stop();

    // 3. wrong address must not be ACKed
    i2c_start();
    i2c_send_byte({7'h51, 1'b0}, ack);
    chk(!ack, "wrong address 0x51 not ACKed");
    i2c_stop();

    // 4. overwrite with 0x5A and confirm the new value
    i2c_start();
    i2c_send_byte({7'h50, 1'b0}, ack);
    i2c_send_byte(8'h5A, ack);
    i2c_stop();
    i2c_start();
    i2c_send_byte({7'h50, 1'b1}, ack);
    i2c_recv_byte(rb, 1'b1);
    chk(rb === 8'h5A, "read: data == 0x5A after overwrite");
    i2c_stop();

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  // safety timeout
  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
