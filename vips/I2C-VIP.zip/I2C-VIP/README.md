# I2C — I2C UVM VIP

Open-source UVM verification IP template for **I2C** (Serial).

## Contents

| Path | Description |
|------|-------------|
| `i2c/i2c_if.sv` | Protocol interface + FSM state enum |
| `i2c/i2c_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `i2c/sva/i2c_compliance_checker.sv` | SVA compliance checker (L1=4, L2=7, L3=4) |
| `i2c/vip/i2c/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/i2c_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with FSM-walking DUT stub |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged master driver**: START/STOP conditions, byte-level ACK/NACK handling, open-drain SDA/SCL control
- **Protocol-decoding monitor**: reconstructs address + data transactions from SDA/SCL waveforms
- **End-to-end scoreboard**: compares driver-issued vs monitor-decoded transactions
- **Functional DUT model**: I2C slave with address ACK + memory read/write
- **Directed sequence library**: write / read / burst / back-to-back / error-inject (NACK probing) / reset + regression mix
- **Functional coverage**: dir x len cross, addr ranges, data corners (0x00/0xFF), FSM state + transition sequences, NACK error bins
- **SVA L4**: START/STOP condition legality, SDA stable while SCL high, START eventually STOP
