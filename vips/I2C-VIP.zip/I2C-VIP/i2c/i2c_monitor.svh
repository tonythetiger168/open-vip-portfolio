// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2c_monitor.svh -- I2C monitor: decodes START/STOP, address and data bytes
// from SDA/SCL waveforms and publishes reconstructed transactions.

`ifndef I2C_MONITOR_SVH
`define I2C_MONITOR_SVH

class i2c_monitor extends uvm_monitor;
  `uvm_component_utils(i2c_monitor)
  virtual i2c_if vif;
  uvm_analysis_port #(i2c_transaction) ap;
  int unsigned txn_count = 0;

  protected bit sda_d, scl_d;   // delayed samples for edge detect

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual i2c_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "i2c virtual interface not set")
  endfunction

  task sample_byte(output bit [7:0] d, output bit ack_bit);
    for (int i = 7; i >= 0; i--) begin
      @(posedge vif.scl_i);           // data valid while SCL high
      d[i] = vif.sda_i;
      @(negedge vif.scl_i);
    end
    @(posedge vif.scl_i);             // ACK slot
    ack_bit = vif.sda_i;
    @(negedge vif.scl_i);
  endtask

  task run_phase(uvm_phase phase);
    i2c_transaction tr;
    bit [7:0] d;
    bit       ack_bit;
    sda_d = 1; scl_d = 1;
    forever begin
      @(vif.mon_cb);
      if (!vif.mon_cb.rst_n) begin sda_d = 1; scl_d = 1; continue; end

      // START: SDA falls while SCL high
      if (scl_d && sda_d && !vif.mon_cb.sda_i && vif.mon_cb.scl_i) begin
        tr = i2c_transaction::type_id::create("tr");
        // address byte
        sample_byte(d, ack_bit);
        tr.addr     = d[7:1];
        tr.dir      = i2c_transaction::i2c_dir_e'(d[0]);
        tr.addr_nack = ack_bit;
        if (!ack_bit) begin
          // data bytes until STOP (SDA rises while SCL high)
          forever begin
            fork
              begin : data_byte
                sample_byte(d, ack_bit);
                if (tr.dir == i2c_transaction::I2C_READ) tr.rdata.push_back(d);
                else tr.data.push_back(d);
              end
              begin : stop_watch
                @(posedge vif.sda_i);
                if (vif.scl_i) disable data_byte;
              end
            join_any
            disable fork;
            if (vif.scl_i && vif.sda_i) break;   // STOP seen
          end
        end
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
      sda_d = vif.mon_cb.sda_i;
      scl_d = vif.mon_cb.scl_i;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("i2c monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
