// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2c_sequences.svh -- I2C sequence library

`ifndef I2C_SEQUENCES_SVH
`define I2C_SEQUENCES_SVH

class i2c_base_sequence extends uvm_sequence #(i2c_transaction);
  `uvm_object_utils(i2c_base_sequence)
  int num_txns = 20;
  function new(string name = "i2c_base_sequence"); super.new(name); endfunction
  task body();
    i2c_transaction tr;
    repeat (num_txns) begin
      tr = i2c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: single-byte write to a fixed address
class i2c_write_seq extends i2c_base_sequence;
  function new(string name = "i2c_write_seq"); super.new(name); endfunction
  `uvm_object_utils(i2c_write_seq)
  rand bit [6:0] target = 7'h50;
  task body();
    i2c_transaction tr;
    repeat (num_txns) begin
      tr = i2c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { addr == target; dir == I2C_WRITE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: reads of varying length
class i2c_read_seq extends i2c_base_sequence;
  function new(string name = "i2c_read_seq"); super.new(name); endfunction
  `uvm_object_utils(i2c_read_seq)
  rand bit [6:0] target = 7'h50;
  task body();
    i2c_transaction tr;
    repeat (num_txns) begin
      tr = i2c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { addr == target; dir == I2C_READ;
                                  data.size() inside {[1:8]}; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: maximum-length burst transfers
class i2c_burst_seq extends i2c_base_sequence;
  function new(string name = "i2c_burst_seq"); super.new(name); endfunction
  `uvm_object_utils(i2c_burst_seq)
  task body();
    i2c_transaction tr;
    repeat (num_txns) begin
      tr = i2c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { data.size() == 16; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back transfers with minimal bus-idle gap
class i2c_back_to_back_seq extends i2c_base_sequence;
  function new(string name = "i2c_back_to_back_seq"); super.new(name); endfunction
  `uvm_object_utils(i2c_back_to_back_seq)
  task body();
    i2c_transaction tr;
    repeat (num_txns) begin
      tr = i2c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { data.size() == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: address phase NACK probing (reserved/broadcast addrs)
class i2c_error_inject_seq extends i2c_base_sequence;
  function new(string name = "i2c_error_inject_seq"); super.new(name); endfunction
  `uvm_object_utils(i2c_error_inject_seq)
  task body();
    i2c_transaction tr;
    bit [6:0] bad_addrs[$] = '{7'h00, 7'h01, 7'h7F};
    foreach (bad_addrs[i]) begin
      tr = i2c_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { addr == bad_addrs[i]; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: transfer attempted right after reset release
class i2c_reset_seq extends i2c_base_sequence;
  function new(string name = "i2c_reset_seq"); super.new(name); endfunction
  `uvm_object_utils(i2c_reset_seq)
  task body();
    i2c_transaction tr = i2c_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { data.size() == 1; });
    finish_item(tr);
  endtask
endclass

class i2c_random_sequence extends i2c_base_sequence;
  `uvm_object_utils(i2c_random_sequence)
  function new(string name = "i2c_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class i2c_regression_sequence extends i2c_base_sequence;
  `uvm_object_utils(i2c_regression_sequence)
  function new(string name = "i2c_regression_sequence"); super.new(name); endfunction
  task body();
    i2c_write_seq       wr  = i2c_write_seq::type_id::create("wr");
    i2c_read_seq        rd  = i2c_read_seq::type_id::create("rd");
    i2c_burst_seq       br  = i2c_burst_seq::type_id::create("br");
    i2c_back_to_back_seq b2b = i2c_back_to_back_seq::type_id::create("b2b");
    i2c_error_inject_seq err = i2c_error_inject_seq::type_id::create("err");
    wr.num_txns = 20; rd.num_txns = 20; br.num_txns = 10; b2b.num_txns = 20;
    wr.start(m_sequencer); rd.start(m_sequencer);
    br.start(m_sequencer); b2b.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
`endif
