// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2c_driver.svh -- I2C master driver (bit-banged, open-drain)

`ifndef I2C_DRIVER_SVH
`define I2C_DRIVER_SVH

class i2c_driver extends uvm_driver #(i2c_transaction);
  `uvm_component_utils(i2c_driver)
  virtual i2c_if vif;
  i2c_config cfg;
  uvm_analysis_port #(i2c_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual i2c_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "i2c virtual interface not set")
  endfunction

  // ---- low-level line control (open-drain: oe=0 releases the line) ----
  task set_sda(bit v); vif.drv_cb.sda_o  <= v; vif.drv_cb.sda_oe <= 1; endtask
  task rel_sda();    vif.drv_cb.sda_oe <= 0; endtask
  task set_scl(bit v); vif.drv_cb.scl_o  <= v; vif.drv_cb.scl_oe <= 1; endtask
  task rel_scl();    vif.drv_cb.scl_oe <= 0; endtask

  task i2c_start();
    rel_sda(); rel_scl(); repeat (4) @(vif.drv_cb);
    set_sda(0);            repeat (4) @(vif.drv_cb);   // SDA falls while SCL high
    set_scl(0);            repeat (4) @(vif.drv_cb);
  endtask

  task i2c_stop();
    set_sda(0); rel_scl(); repeat (4) @(vif.drv_cb);
    rel_sda();             repeat (4) @(vif.drv_cb);   // SDA rises while SCL high
  endtask

  task i2c_write_bit(bit b);
    if (b) rel_sda(); else set_sda(0);
    rel_scl(); repeat (4) @(vif.drv_cb);               // data valid during high
    set_scl(0); repeat (4) @(vif.drv_cb);
  endtask

  task i2c_read_bit(output bit b);
    rel_sda();
    rel_scl(); repeat (2) @(vif.drv_cb);
    b = vif.drv_cb.sda_i;
    repeat (2) @(vif.drv_cb);
    set_scl(0); repeat (4) @(vif.drv_cb);
  endtask

  task i2c_write_byte(bit [7:0] d, output bit nack);
    for (int i = 7; i >= 0; i--) i2c_write_bit(d[i]);
    i2c_read_bit(nack);                                 // ACK slot driven by slave
  endtask

  task i2c_read_byte(output bit [7:0] d, input bit master_nack);
    for (int i = 7; i >= 0; i--) i2c_read_bit(d[i]);
    i2c_write_bit(master_nack);                         // ACK=0 / NACK=1
  endtask

  task run_phase(uvm_phase phase);
    i2c_transaction tr;
    vif.drv_cb.sda_oe <= 0; vif.drv_cb.scl_oe <= 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      bit nack;
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)

      i2c_start();
      vif.state = i2c_defs_pkg::START;
      i2c_write_byte({tr.addr, tr.dir}, nack);
      vif.state = i2c_defs_pkg::ADDR;
      if (nack) begin
        `uvm_warning("DRV", $sformatf("addr 0x%02h NACKed", tr.addr))
        vif.state = i2c_defs_pkg::ACK;
        i2c_stop();
        vif.state = i2c_defs_pkg::STOP;
        seq_item_port.item_done();
        continue;
      end
      vif.state = i2c_defs_pkg::ACK;

      if (tr.dir == i2c_transaction::I2C_WRITE) begin
        vif.state = i2c_defs_pkg::WRITE;
        foreach (tr.data[i]) begin
          i2c_write_byte(tr.data[i], nack);
          if (nack) begin `uvm_warning("DRV", "data NACKed"); break; end
        end
      end else begin
        vif.state = i2c_defs_pkg::READ;
        for (int i = 0; i < tr.data.size(); i++) begin
          bit [7:0] d;
          i2c_read_byte(d, tr.nack_last && (i == tr.data.size()-1));
        end
      end

      i2c_stop();
      vif.state = i2c_defs_pkg::STOP;
      repeat (8) @(vif.drv_cb);
      vif.state = i2c_defs_pkg::IDLE;
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
