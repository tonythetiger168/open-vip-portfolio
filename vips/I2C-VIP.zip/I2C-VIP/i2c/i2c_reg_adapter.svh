// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2c_reg_adapter.svh -- UVM RAL adapter for the I2C master agent
//   reg2bus: UVM_WRITE -> START, slave address + W, one data byte, STOP
//            UVM_READ  -> START, slave address + R, one data byte (master NACK), STOP
//   bus2reg: i2c_transaction (driver-completed or monitor-observed) -> uvm_reg_bus_op
// The driver writes addr_nack and the read bytes (rdata) back into the request
// item and sends no separate response, so provides_responses = 0. An address
// NACK is UVM_NOT_OK.

`ifndef I2C_REG_ADAPTER_SVH
`define I2C_REG_ADAPTER_SVH

class i2c_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(i2c_reg_adapter)

  bit [6:0] slave_addr = 7'h50;   // 7-bit address of the slave the model maps

  function new(string name = "i2c_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 0;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    i2c_transaction tr = i2c_transaction::type_id::create("ral_item");
    tr.addr      = slave_addr;
    tr.dir       = (rw.kind == UVM_WRITE) ? i2c_transaction::I2C_WRITE : i2c_transaction::I2C_READ;
    tr.data.delete();
    tr.data.push_back((rw.kind == UVM_WRITE) ? rw.data[7:0] : 8'h00);
    tr.nack_last      = 1'b1;    // a read ends with a master NACK
    tr.stretch_cycles = 0;
    tr.t_low          = 8;
    tr.t_high         = 8;
    return tr;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    i2c_transaction tr;
    bit rd;
    if (!$cast(tr, bus_item)) begin
      `uvm_fatal("I2C_RAL", "bus2reg: item is not an i2c_transaction")
      return;
    end
    rd         = (tr.dir == i2c_transaction::I2C_READ);
    rw.kind    = rd ? UVM_READ : UVM_WRITE;
    rw.addr    = 0;
    rw.data    = rd ? (tr.rdata.size() ? tr.rdata[0] : 8'h00)
                    : (tr.data.size()  ? tr.data[0]  : 8'h00);
    rw.n_bits  = 8;
    rw.byte_en = '1;
    rw.status  = (tr.addr_nack || tr.addr != slave_addr ||
                  (rd ? tr.rdata.size() == 0 : tr.data.size() == 0)) ? UVM_NOT_OK : UVM_IS_OK;
    // other slaves, NACKed or empty transfers: unmapped, the predictor skips them
    if (rw.status != UVM_IS_OK) rw.addr = 'h100;
  endfunction
endclass
`endif
