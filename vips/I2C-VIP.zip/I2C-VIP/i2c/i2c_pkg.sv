// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i2c_pkg.sv -- I2C UVM VIP package

package i2c_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import i2c_defs_pkg::*;
  export i2c_defs_pkg::*;

  `include "i2c_transaction.svh"
  `include "i2c_config.svh"
  `include "i2c_sequencer.svh"
  `include "i2c_driver.svh"
  `include "i2c_monitor.svh"
  `include "i2c_agent.svh"
  `include "i2c_sequences.svh"
  `include "i2c_checker.svh"
  `include "i2c_coverage.svh"
endpackage
