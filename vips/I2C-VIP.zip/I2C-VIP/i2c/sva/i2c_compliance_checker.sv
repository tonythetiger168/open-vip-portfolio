// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i2c_compliance_checker.sv -- I2C SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules

`ifndef I2C_COMPLIANCE_CHECKER_SV
`define I2C_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import i2c_defs_pkg::*;

module i2c_compliance_checker
(
  input logic clk,
  input logic rst_n,
  input i2c_state_e state,
  input logic sda_i,
  input logic scl_i
);

  // ---------------- L1: signal sanity (4) ----------------
  a_i2c_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "i2c: clock unknown")
  a_i2c_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "i2c: reset unknown")
  a_i2c_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "i2c: state unknown")
  a_i2c_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, START, ADDR, ACK, WRITE, READ, STOP})
    else `uvm_error("SVA_L1", "i2c: state outside legal encoding")

  // ---------------- L2: FSM legality (7) ----------------
  // L2-1: legal FSM transition from IDLE
  a_i2c_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, START})
    else `uvm_error("SVA_L2", "i2c: illegal transition from IDLE")

  // L2-2: legal FSM transition from START
  a_i2c_trans_start : assert property (@(posedge clk) disable iff (!rst_n)
    state == START |=> state inside {START, ADDR})
    else `uvm_error("SVA_L2", "i2c: illegal transition from START")

  // L2-3: legal FSM transition from ADDR
  a_i2c_trans_addr : assert property (@(posedge clk) disable iff (!rst_n)
    state == ADDR |=> state inside {ADDR, ACK})
    else `uvm_error("SVA_L2", "i2c: illegal transition from ADDR")

  // L2-4: legal FSM transition from ACK
  a_i2c_trans_ack : assert property (@(posedge clk) disable iff (!rst_n)
    state == ACK |=> state inside {ACK, WRITE})
    else `uvm_error("SVA_L2", "i2c: illegal transition from ACK")

  // L2-5: legal FSM transition from WRITE
  a_i2c_trans_write : assert property (@(posedge clk) disable iff (!rst_n)
    state == WRITE |=> state inside {WRITE, READ})
    else `uvm_error("SVA_L2", "i2c: illegal transition from WRITE")

  // L2-6: legal FSM transition from READ
  a_i2c_trans_read : assert property (@(posedge clk) disable iff (!rst_n)
    state == READ |=> state inside {READ, STOP})
    else `uvm_error("SVA_L2", "i2c: illegal transition from READ")

  // L2-7: legal FSM transition from STOP
  a_i2c_trans_stop : assert property (@(posedge clk) disable iff (!rst_n)
    state == STOP |=> state inside {STOP, IDLE})
    else `uvm_error("SVA_L2", "i2c: illegal transition from STOP")

  // ---------------- L3: protocol rules (4) ----------------
  a_i2c_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "i2c: state not IDLE during reset")
  a_i2c_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == STOP |-> ##[1:8] (state != STOP))
    else `uvm_error("SVA_L3", "i2c: stuck in STOP")
  a_i2c_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == START);
  a_i2c_l3_back_idle  : cover property (@(posedge clk) disable iff (!rst_n)
    state == STOP ##1 state == IDLE);

  // ---------------- L4: I2C protocol-specific rules (4) ----------------
  a_i2c_l4_start_cond : assert property (@(posedge clk) disable iff (!rst_n)
    ($fell(sda_i) && scl_i) |-> (state inside {IDLE, START}))
    else `uvm_error("SVA_L4", "i2c: unexpected START condition")
  a_i2c_l4_stop_cond  : assert property (@(posedge clk) disable iff (!rst_n)
    ($rose(sda_i) && scl_i) |-> (state inside {WRITE, READ, ACK, STOP}))
    else `uvm_error("SVA_L4", "i2c: STOP outside data phase")
  a_i2c_l4_sda_stable : assert property (@(posedge scl_i) disable iff (!rst_n)
    state inside {WRITE, READ, ADDR} |-> $stable(sda_i))
    else `uvm_error("SVA_L4", "i2c: SDA changed while SCL high")
  a_i2c_l4_start_stop : assert property (@(posedge clk) disable iff (!rst_n)
    state == START |-> s_eventually (state == STOP))
    else `uvm_error("SVA_L4", "i2c: START without eventual STOP")

endmodule
`endif
