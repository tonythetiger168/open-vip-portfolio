// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2c_transaction.svh -- I2C transaction (address phase + data phase)

`ifndef I2C_TRANSACTION_SVH
`define I2C_TRANSACTION_SVH

class i2c_transaction extends uvm_sequence_item;

  typedef enum bit {I2C_WRITE = 1'b0, I2C_READ = 1'b1} i2c_dir_e;

  rand bit [6:0]  addr;
  rand i2c_dir_e  dir;
  rand bit [7:0]  data[$];
  rand bit        nack_last;     // master NACKs last read byte
  rand int        stretch_cycles;// slave clock-stretch tolerance

  // Timing knobs (in reference-clock cycles)
  rand int unsigned t_low;
  rand int unsigned t_high;

  bit        addr_nack;          // set by monitor: slave NACKed address
  bit [7:0]  rdata[$];           // monitor: observed read data

  constraint c_addr    { addr != 7'h00; addr != 7'h78; }        // skip general-call / reserved
  constraint c_len     { data.size() inside {[1:16]}; }
  constraint c_timing  { t_low inside {[4:16]}; t_high inside {[4:16]}; }
  constraint c_stretch { stretch_cycles inside {[0:8]}; }
  constraint c_nack    { nack_last dist {0 := 7, 1 := 3}; }

  `uvm_object_utils_begin(i2c_transaction)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_enum(i2c_dir_e, dir, UVM_ALL_ON)
    `uvm_field_queue_int(data, UVM_ALL_ON)
    `uvm_field_int(nack_last, UVM_ALL_ON)
    `uvm_field_queue_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "i2c_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    i2c_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    if (dir == I2C_WRITE)
      do_compare &= (comparer.compare_field("data", data.size(), t.data.size(), 32) == 1);
  endfunction

  function string convert2string();
    string s = $sformatf("I2C %s addr=0x%02h len=%0d",
                         dir == I2C_READ ? "RD" : "WR", addr, data.size());
    foreach (data[i]) s = {s, $sformatf(" %02h", data[i])};
    return s;
  endfunction
endclass
`endif
