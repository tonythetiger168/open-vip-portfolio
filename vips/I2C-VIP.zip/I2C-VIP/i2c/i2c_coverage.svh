// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2c_coverage.svh -- I2C functional coverage

`ifndef I2C_COVERAGE_SVH
`define I2C_COVERAGE_SVH

class i2c_coverage extends uvm_subscriber #(i2c_transaction);
  `uvm_component_utils(i2c_coverage)

  i2c_transaction tr;
  i2c_defs_pkg::i2c_state_e cur_state;

  covergroup cg_protocol;
    cp_dir  : coverpoint tr.dir {
      bins wr = {i2c_transaction::I2C_WRITE};
      bins rd = {i2c_transaction::I2C_READ};
    }
    cp_addr : coverpoint tr.addr {
      bins low  = {[7'h08 : 7'h3F]};
      bins high = {[7'h40 : 7'h77]};
    }
    cp_len  : coverpoint tr.data.size() {
      bins single = {1};
      bins short  = {[2:4]};
      bins mid    = {[5:15]};
      bins burst  = {16};
    }
    cp_data : coverpoint tr.data[0] iff (tr.data.size() > 0) {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins walk = {[8'h01 : 8'hFE]};
    }
    cx_dir_len : cross cp_dir, cp_len;
  endgroup

  covergroup cg_fsm with function sample(i2c_defs_pkg::i2c_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {i2c_defs_pkg::IDLE, i2c_defs_pkg::START, i2c_defs_pkg::ADDR,
                           i2c_defs_pkg::ACK, i2c_defs_pkg::WRITE, i2c_defs_pkg::READ,
                           i2c_defs_pkg::STOP};
    }
    cp_trans : coverpoint s {
      bins start_seq = (i2c_defs_pkg::IDLE => i2c_defs_pkg::START => i2c_defs_pkg::ADDR);
      bins wr_seq    = (i2c_defs_pkg::ACK  => i2c_defs_pkg::WRITE => i2c_defs_pkg::STOP);
      bins rd_seq    = (i2c_defs_pkg::ACK  => i2c_defs_pkg::READ  => i2c_defs_pkg::STOP);
    }
  endgroup

  covergroup cg_error;
    cp_addr_nack : coverpoint tr.addr_nack { bins ack = {0}; bins nack = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(i2c_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_fsm.sample(cur_state);
    cg_error.sample();
  endfunction
endclass
`endif
