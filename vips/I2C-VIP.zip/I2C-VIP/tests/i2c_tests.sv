// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i2c_tests.sv -- I2C UVM tests

package i2c_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import i2c_pkg::*;
  import env_pkg::*;

  class i2c_base_test extends uvm_test;
    `uvm_component_utils(i2c_base_test)
    i2c_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = i2c_env::type_id::create("env", this);
    endfunction
  endclass

  class i2c_random_test extends i2c_base_test;
    `uvm_component_utils(i2c_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      i2c_random_sequence seq = i2c_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class i2c_regression_test extends i2c_base_test;
    `uvm_component_utils(i2c_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      i2c_regression_sequence seq = i2c_regression_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  // UVM RAL on the slave's data register (env/i2c_reg_model.svh):
  //   1. uvm_reg_hw_reset_seq  -- DATA reads its reset value
  //   2. uvm_reg_bit_bash_seq  -- every bit writes 0/1 and reads back
  //   3. 64 pseudo-random writes, each followed by mirror(UVM_CHECK) and a read
  // Uses no randomize(). Prints "RAL_PASS checks=<n>" when no UVM_ERROR or
  // UVM_FATAL was reported.
  class i2c_ral_test extends i2c_base_test;
    `uvm_component_utils(i2c_ral_test)
    int unsigned checks;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task run_phase(uvm_phase phase);
      uvm_reg_hw_reset_seq rst_seq;
      uvm_reg_bit_bash_seq bb_seq;
      uvm_status_e         status;
      uvm_reg_data_t       val, exp;
      i2c_reg_block        rm = env.regmodel;
      phase.raise_objection(this);

      rst_seq = uvm_reg_hw_reset_seq::type_id::create("rst_seq");
      rst_seq.model = rm;
      rst_seq.start(null);
      checks++;

      bb_seq = uvm_reg_bit_bash_seq::type_id::create("bb_seq");
      bb_seq.model = rm;
      bb_seq.start(null);
      checks += 8;

      repeat (64) begin
        exp = $urandom_range(255);
        rm.DATA.write(status, exp);
        if (status != UVM_IS_OK) `uvm_error("RAL", $sformatf("DATA write status %s", status.name()))
        rm.DATA.mirror(status, UVM_CHECK);
        rm.DATA.read(status, val);
        if (status != UVM_IS_OK || val != exp)
          `uvm_error("RAL", $sformatf("DATA read 0x%02h status %s, expected 0x%02h",
                     val, status.name(), exp))
        checks += 2;
      end

      #1us;
      phase.drop_objection(this);
    endtask

    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      super.report_phase(phase);
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0)
        $display("RAL_PASS checks=%0d", checks);
      else
        $display("RAL_FAIL errors=%0d", rs.get_severity_count(UVM_ERROR));
    endfunction
  endclass
endpackage
