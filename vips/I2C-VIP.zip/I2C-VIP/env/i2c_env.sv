// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2c_env.sv -- I2C verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import i2c_defs_pkg::*;
  import i2c_pkg::*;

  `include "i2c_reg_model.svh"

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) transactions
  // against monitor-decoded (observed) transactions.
  class i2c_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(i2c_scoreboard)
    uvm_analysis_imp_exp #(i2c_transaction, i2c_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(i2c_transaction, i2c_scoreboard) obs_ap;

    i2c_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(i2c_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(i2c_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        i2c_transaction e = exp_q.pop_front();
        i2c_transaction o = obs_q.pop_front();
        if (e.addr == o.addr && e.dir == o.dir &&
            (e.dir == i2c_transaction::I2C_READ || e.data.size() == o.data.size()))
          n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("i2c scoreboard: n_matches=%0d n_mismatches=%0d",
                n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  class i2c_env extends uvm_env;
    `uvm_component_utils(i2c_env)
    i2c_agent      agt;
    i2c_scoreboard sb;
    i2c_checker    chk;
    i2c_coverage   cov;
    // UVM RAL: register model of the DUT model in tb/top_tb.sv, frontdoor
    // through the agent, mirror kept by an explicit predictor fed by the
    // monitor (which publishes each item before the driver completes it)
    i2c_reg_block                        regmodel;
    i2c_reg_adapter                      reg_adapter;
    uvm_reg_predictor #(i2c_transaction)  reg_predictor;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = i2c_agent::type_id::create("agt", this);
      sb  = i2c_scoreboard::type_id::create("sb", this);
      chk = i2c_checker::type_id::create("chk", this);
      cov = i2c_coverage::type_id::create("cov", this);
      if (!uvm_config_db#(i2c_reg_block)::get(this, "", "regmodel", regmodel)) begin
        regmodel = i2c_reg_block::type_id::create("regmodel");
        regmodel.configure(null, "");
        regmodel.build();
        regmodel.lock_model();
      end
      reg_adapter   = i2c_reg_adapter::type_id::create("reg_adapter");
      reg_predictor = uvm_reg_predictor#(i2c_transaction)::type_id::create("reg_predictor", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
      regmodel.default_map.set_sequencer(agt.sqr, reg_adapter);
      regmodel.default_map.set_auto_predict(0);
      reg_predictor.map     = regmodel.default_map;
      reg_predictor.adapter = reg_adapter;
      agt.mon.ap.connect(reg_predictor.bus_in);
    endfunction
  endclass
endpackage
