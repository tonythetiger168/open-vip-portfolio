// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2c_reg_model.svh -- UVM register model of the I2C slave in tb/top_tb.sv
// (i2c_slave_model, address 0x50). The model keeps one data byte per slave
// address and has no register pointer, so the device is a single 8-bit RW
// register (like a one-port I/O expander):
//   DATA @ 0x0  8-bit RW, reset 0

`ifndef I2C_REG_MODEL_SVH
`define I2C_REG_MODEL_SVH

class i2c_data_reg extends uvm_reg;
  `uvm_object_utils(i2c_data_reg)
  rand uvm_reg_field DATA;

  function new(string name = "i2c_data_reg");
    super.new(name, 8, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    DATA = uvm_reg_field::type_id::create("DATA");
    //            parent size lsb access volatile reset has_reset rand individually_accessible
    DATA.configure(this, 8,   0,  "RW",  0,       8'h0, 1,        1,   1);
  endfunction
endclass

class i2c_reg_block extends uvm_reg_block;
  `uvm_object_utils(i2c_reg_block)
  rand i2c_data_reg DATA;
  uvm_reg_map       i2c_map;

  function new(string name = "i2c_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    i2c_map = create_map("i2c_map", 'h0, 1, UVM_LITTLE_ENDIAN, 1);
    default_map = i2c_map;
    DATA = i2c_data_reg::type_id::create("DATA");
    DATA.configure(this, null, "");
    DATA.build();
    i2c_map.add_reg(DATA, 'h0, "RW");
  endfunction
endclass
`endif
