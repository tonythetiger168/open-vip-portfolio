// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3e_pkg.sv -- HBM3E UVM VIP package

package hbm3e_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import hbm3e_defs_pkg::*;
  export hbm3e_defs_pkg::*;

  `include "hbm3e_transaction.svh"
  `include "hbm3e_config.svh"
  `include "hbm3e_sequencer.svh"
  `include "hbm3e_driver.svh"
  `include "hbm3e_monitor.svh"
  `include "hbm3e_agent.svh"
  `include "hbm3e_sequences.svh"
  `include "hbm3e_checker.svh"
  `include "hbm3e_coverage.svh"
endpackage
