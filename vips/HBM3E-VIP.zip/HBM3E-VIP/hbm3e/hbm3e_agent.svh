// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3e_agent.svh -- HBM3E agent

class hbm3e_agent extends uvm_agent;
  `uvm_component_utils(hbm3e_agent)

  hbm3e_sequencer sqr;
  hbm3e_driver    drv;
  hbm3e_monitor   mon;
  hbm3e_config    cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    cfg = hbm3e_config::type_id::create("cfg", this);
    uvm_config_db#(hbm3e_config)::set(this, "*", "cfg", cfg);
    sqr = hbm3e_sequencer::type_id::create("sqr", this);
    drv = hbm3e_driver   ::type_id::create("drv", this);
    mon = hbm3e_monitor  ::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
