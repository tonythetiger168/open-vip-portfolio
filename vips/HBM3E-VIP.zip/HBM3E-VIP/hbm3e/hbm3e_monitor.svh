// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3e_monitor.svh -- HBM3E monitor: decodes RD/WR commands, pairs reads with rd_valid in order

class hbm3e_monitor extends uvm_monitor;
  `uvm_component_utils(hbm3e_monitor)

  virtual hbm3e_if vif;
  uvm_analysis_port #(hbm3e_transaction) ap;
  hbm3e_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual hbm3e_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hbm3e: virtual interface not set")
    if (!uvm_config_db#(hbm3e_config)::get(this, "", "cfg", cfg))
      cfg = hbm3e_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      hbm3e_transaction pend[$];
      int unsigned age[$];
      forever begin
        @(vif.mon_cb);
        foreach (age[i]) age[i]++;
        if (vif.mon_cb.rd_valid) begin
          if (pend.size() == 0) `uvm_error("MON", "HBM3E: rd_valid without an outstanding read")
          else begin
            hbm3e_transaction t = pend.pop_front();
            t.rl = age.pop_front();
            t.rdata = vif.mon_cb.rd_data;
            publish(t);
          end
        end
        if (!vif.mon_cb.cs_n && vif.mon_cb.act_n) begin
          hbm3e_transaction t = hbm3e_transaction::type_id::create("t");
          t.write = !vif.mon_cb.addr[0];
          t.col   = vif.mon_cb.addr[13:1];
          t.stack = vif.mon_cb.stack;
          t.pchan = vif.mon_cb.pchan;
          if (t.write) begin
            t.wdata = vif.mon_cb.wr_data;
            publish(t);
          end else begin
            pend.push_back(t);
            age.push_back(0);
          end
        end
      end
    end
  endtask

  function void publish(hbm3e_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
