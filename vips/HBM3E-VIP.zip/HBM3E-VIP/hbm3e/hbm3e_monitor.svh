// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3e_monitor.svh -- HBM3E monitor: decodes observed bus activity

class hbm3e_monitor extends uvm_monitor;
  `uvm_component_utils(hbm3e_monitor)

  virtual hbm3e_if vif;
  uvm_analysis_port #(hbm3e_transaction) ap;
  hbm3e_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual hbm3e_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hbm3e: virtual interface not set")
    void'(uvm_config_db#(hbm3e_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    hbm3e_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = hbm3e_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.cs_n = vif.cs_n;
        t.act_n = vif.act_n;
        t.stack = vif.stack;
        t.pchan = vif.pchan;
        t.addr = vif.addr;
        t.wr_data = vif.wr_data;
        t.rd_data_o = vif.rd_data;
        t.rd_valid_o = vif.rd_valid;
        ap.write(t);
      end
    end
  endtask
endclass
