// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3e_if.sv -- HBM3E interface

interface hbm3e_if (input logic clk);
  logic rst_n;

  logic cs_n;
  logic act_n;
  logic [1:0] stack;
  logic pchan;
  logic [13:0] addr;
  logic [255:0] wr_data;
  logic [255:0] rd_data;
  logic rd_valid;

  modport DUT (input clk, rst_n, cs_n, act_n, stack, pchan, addr, wr_data, output rd_data, rd_valid);
  modport DRV (input clk, rst_n, rd_data, rd_valid, output cs_n, act_n, stack, pchan, addr, wr_data);
  modport MON (input clk, rst_n, cs_n, act_n, stack, pchan, addr, wr_data, rd_data, rd_valid);

  clocking drv_cb @(posedge clk);
    input rst_n, cs_n, act_n, stack, pchan, addr, wr_data, rd_data, rd_valid;
    output cs_n, act_n, stack, pchan, addr, wr_data;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, cs_n, act_n, stack, pchan, addr, wr_data, rd_data, rd_valid;
  endclocking
endinterface
