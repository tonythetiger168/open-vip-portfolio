// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3e_transaction.svh -- HBM3E transaction

class hbm3e_transaction extends uvm_sequence_item;
  `uvm_object_utils(hbm3e_transaction)

  rand bit cs_n;
  rand bit act_n;
  rand bit [1:0] stack;
  rand bit pchan;
  rand bit [13:0] addr;
  rand bit [255:0] wr_data;
  bit [255:0] rd_data_o;
  bit rd_valid_o;
  bit [31:0] tag;

  function new(string name = "hbm3e_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    hbm3e_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    cs_n = rhs_.cs_n;
    act_n = rhs_.act_n;
    stack = rhs_.stack;
    pchan = rhs_.pchan;
    addr = rhs_.addr;
    wr_data = rhs_.wr_data;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    hbm3e_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           cs_n == rhs_.cs_n &&
           act_n == rhs_.act_n &&
           stack == rhs_.stack &&
           pchan == rhs_.pchan &&
           addr == rhs_.addr &&
           wr_data == rhs_.wr_data;
  endfunction

  function string convert2string();
    return $sformatf("HBM3E{tag=%0h cs_n=0x%0h act_n=0x%0h stack=0x%0h pchan=0x%0h addr=0x%0h wr_data=0x%0h}", tag, cs_n, act_n, stack, pchan, addr, wr_data);
  endfunction
endclass
