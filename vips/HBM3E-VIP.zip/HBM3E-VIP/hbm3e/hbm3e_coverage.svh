// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3e_coverage.svh -- HBM3E functional coverage

class hbm3e_coverage extends uvm_subscriber #(hbm3e_transaction);
  `uvm_component_utils(hbm3e_coverage)
  hbm3e_config cfg;
  hbm3e_transaction tr;

  covergroup hbm3e_cg;
    cp_write : coverpoint tr.write;
    cp_stack  : coverpoint tr.stack;
    cp_col   : coverpoint tr.col { bins low = {[0:15]}; bins mid = {[16:8190]}; bins top = {8191}; }
    x_wr_stack : cross cp_write, cp_stack;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    hbm3e_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(hbm3e_config)::get(this, "", "cfg", cfg))
      cfg = hbm3e_config::type_id::create("cfg");
  endfunction

  function void write(hbm3e_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    hbm3e_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("HBM3E coverage: %0.1f%%", hbm3e_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
