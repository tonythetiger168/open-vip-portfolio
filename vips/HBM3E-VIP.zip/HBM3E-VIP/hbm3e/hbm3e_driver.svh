// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3e_driver.svh -- HBM3E driver: ACT then one RD/WR command; reads wait for rd_valid

class hbm3e_driver extends uvm_driver #(hbm3e_transaction);
  `uvm_component_utils(hbm3e_driver)

  uvm_analysis_port #(hbm3e_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual hbm3e_if vif;
  hbm3e_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hbm3e_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hbm3e: virtual interface not set")
    if (!uvm_config_db#(hbm3e_config)::get(this, "", "cfg", cfg))
      cfg = hbm3e_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    hbm3e_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.cs_n <= 1'b1; vif.drv_cb.act_n <= 1'b1; vif.drv_cb.addr <= '0; vif.drv_cb.wr_data <= '0; vif.drv_cb.stack <= '0; vif.drv_cb.pchan <= '0;
  endtask

  task drive_item(hbm3e_transaction t);
    // ACTIVATE (ignored by the model; keeps the command stream realistic)
    @(vif.drv_cb);
    vif.drv_cb.cs_n <= 1'b0; vif.drv_cb.act_n <= 1'b0; vif.drv_cb.stack <= t.stack; vif.drv_cb.pchan <= t.pchan; vif.drv_cb.addr <= t.row;
    // READ (addr[0] = 1) / WRITE (addr[0] = 0) to column addr[13:1]
    @(vif.drv_cb);
    vif.drv_cb.act_n <= 1'b1;
    vif.drv_cb.addr  <= {t.col, !t.write};
    vif.drv_cb.wr_data <= t.write ? t.wdata : '0;
    @(vif.drv_cb);
    vif.drv_cb.cs_n <= 1'b1;
    vif.drv_cb.wr_data <= '0;
    if (!t.write) begin
      int unsigned n = 0;
      do begin @(vif.drv_cb); n++; end while (vif.drv_cb.rd_valid !== 1'b1 && n < cfg.timeout_cycles);
      if (vif.drv_cb.rd_valid !== 1'b1) `uvm_error("TIMEOUT", "HBM3E: no rd_valid for read")
      t.rdata = vif.drv_cb.rd_data;
      t.rl = n;
    end
  endtask

endclass
