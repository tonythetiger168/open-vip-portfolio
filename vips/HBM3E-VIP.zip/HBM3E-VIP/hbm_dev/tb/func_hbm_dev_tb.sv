// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator
//
// func_hbm_dev_tb.sv -- memory controller for hbm_dev_model, written from
// the JESD238 pseudo-channel rules rather than from the model:
//   * timing boundaries, one clock early rejected with the matching cause
//     and no effect, on time accepted: tRCDRD, tRCDWR, tRAS, tRP, tRRD_S/L,
//     tFAW, tCCD_S/L, tRTP, tWR, tWTR_S/L, RD->WR turnaround, tRFCab,
//     tRFCpb, tRREFD, tMOD
//   * row and column commands in the same clock; pseudo channels with
//     their own banks, tFAW, refresh and latencies
//   * REFpb (bank must be idle, only that bank busy), REFab, PREab,
//     RDA / WRA auto precharge, MRS rules, missing write data
//   * refresh credit: REFab or 16 REFpb per tREFI, postponed limit
//   * 400 random commands on both buses from a timing-legal scheduler
//     against a reference memory
// Run: python3 tools/run_func_tests.py HBM3E-VIP
module func_hbm_dev_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int tRCDRD = 10, tRCDWR = 7, tRAS = 24, tRP = 10, tRRD_S = 2, tRRD_L = 3;
  localparam int tFAW = 12, tCCD_S = 4, tCCD_L = 6, tRTP = 5, tWR = 10, tWTR_S = 3, tWTR_L = 6;
  localparam int tRFCab = 60, tRFCpb = 20, tRREFD = 4, tMOD = 8, tREFI = 800, REF_POSTPONE = 8;
  localparam logic [2:0] ACT = 1, PREPB = 2, PREAB = 3, REFAB = 4, REFPB = 5;
  localparam logic [2:0] RD = 1, RDA = 2, WR = 3, WRA = 4, MRS = 5;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic [2:0] r_cmd = 0, c_cmd = 0;
  logic r_pc = 0, c_pc = 0;
  logic [1:0] r_bg = 0, r_ba = 0, c_bg = 0, c_ba = 0;
  logic [13:0] r_row = 0;
  logic [5:0] c_col = 0;
  logic [3:0] c_mra = 0;
  logic [7:0] c_mrd = 0;
  logic [127:0] wdq = 0;
  logic [1:0] wdq_valid = 0;
  wire [127:0] rdq;
  wire [1:0] rd_valid, derr, rerr;
  wire [31:0] bank_open;
  wire [13:0] err, cerr;
  always #5 clk = ~clk;

  hbm_dev_model #(.tRCDRD(tRCDRD), .tRCDWR(tRCDWR), .tRAS(tRAS), .tRP(tRP), .tRRD_S(tRRD_S),
    .tRRD_L(tRRD_L), .tFAW(tFAW), .tCCD_S(tCCD_S), .tCCD_L(tCCD_L), .tRTP(tRTP), .tWR(tWR),
    .tWTR_S(tWTR_S), .tWTR_L(tWTR_L), .tRFCab(tRFCab), .tRFCpb(tRFCpb), .tRREFD(tRREFD),
    .tMOD(tMOD), .tREFI(tREFI), .REF_POSTPONE(REF_POSTPONE)) u_dut (.clk, .rst_n, .r_cmd, .r_pc,
    .r_bg, .r_ba, .r_row, .c_cmd, .c_pc, .c_bg, .c_ba, .c_col, .c_mra, .c_mrd, .wdq, .wdq_valid,
    .rdq, .rd_valid, .bank_open, .err, .cerr, .derr, .rerr);

  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int mnow = 0;                          // clocks since reset release (the channel's time base)
  always @(posedge clk) mnow <= rst_n ? mnow + 1 : 0;
  logic [1:0] derr_acc = 0;
  always @(posedge clk) derr_acc <= derr_acc | derr;
  int last_t = 0;
  int rl [0:1], wl [0:1];
  logic [13:0] e_seen;

  // write data plan / read expectations per pseudo channel, by edge number
  logic        wp_v [int];
  logic [63:0] wp_d [int];
  logic        ex_v [int];
  logic [63:0] ex_d [int];
  int rd_bad = 0, rd_extra = 0, rd_cnt = 0;
  function automatic int slot(input int p, input int t); return 2 * t + p; endfunction
  always @(negedge clk) begin
    for (int p = 0; p < 2; p++) begin
      if (wp_v.exists(slot(p, cyc + 1))) begin wdq_valid[p] <= 1'b1; wdq[64 * p +: 64] <= wp_d[slot(p, cyc + 1)]; end
      else begin wdq_valid[p] <= 1'b0; wdq[64 * p +: 64] <= 64'hDEAD_BEEF_DEAD_BEEF; end
    end
  end
  always @(posedge clk) begin
    #1;
    for (int p = 0; p < 2; p++) begin
      if (rd_valid[p]) begin
        rd_cnt++;
        if (!ex_v.exists(slot(p, cyc))) rd_extra++;
        else if (rdq[64 * p +: 64] !== ex_d[slot(p, cyc)]) rd_bad++;
      end else if (ex_v.exists(slot(p, cyc))) rd_bad++;
    end
  end

  logic [255:0] ref_m [logic [24:0]];
  function automatic logic [24:0] key(input logic p, input logic [1:0] g, input logic [1:0] b,
                                      input logic [13:0] r, input logic [5:0] c);
    return {p, g, b, r, c};
  endfunction

  // one command on a bus, n clocks after the previous command on either bus
  task automatic rcmd(input int n, input logic [2:0] c, input logic p = 0, input logic [1:0] g = 0,
                      input logic [1:0] b = 0, input logic [13:0] r = 0);
    while (cyc + 1 < last_t + n) @(negedge clk);
    r_cmd = c; r_pc = p; r_bg = g; r_ba = b; r_row = r;
    last_t = cyc + 1;
    @(negedge clk);
    r_cmd = 0;
    e_seen = err;
  endtask
  task automatic ccmd(input int n, input logic [2:0] c, input logic p = 0, input logic [1:0] g = 0,
                      input logic [1:0] b = 0, input logic [5:0] co = 0,
                      input logic [3:0] a = 0, input logic [7:0] d = 0);
    while (cyc + 1 < last_t + n) @(negedge clk);
    c_cmd = c; c_pc = p; c_bg = g; c_ba = b; c_col = co; c_mra = a; c_mrd = d;
    last_t = cyc + 1;
    @(negedge clk);
    c_cmd = 0;
    e_seen = cerr;
  endtask
  task automatic wait_clk(input int n); repeat (n) @(negedge clk); endtask

  task automatic plan_wr(input logic p, input logic [1:0] g, input logic [1:0] b, input logic [13:0] r,
                         input logic [5:0] c, input logic [255:0] d);
    for (int i = 0; i < 4; i++) begin
      wp_v[slot(p, last_t + wl[p] + i)] = 1'b1; wp_d[slot(p, last_t + wl[p] + i)] = d[64 * i +: 64];
    end
    ref_m[key(p, g, b, r, c)] = d;
  endtask
  task automatic plan_rd(input logic p, input logic [1:0] g, input logic [1:0] b, input logic [13:0] r,
                         input logic [5:0] c);
    logic [255:0] d;
    d = ref_m.exists(key(p, g, b, r, c)) ? ref_m[key(p, g, b, r, c)] : '0;
    for (int i = 0; i < 4; i++) begin
      ex_v[slot(p, last_t + rl[p] + i)] = 1'b1; ex_d[slot(p, last_t + rl[p] + i)] = d[64 * i +: 64];
    end
  endtask
  function automatic logic [255:0] rnd256();
    logic [255:0] v;
    for (int i = 0; i < 256; i += 32) v[i +: 32] = $urandom;
    return v;
  endfunction
  function automatic int bit_of(input logic p, input logic [1:0] g, input logic [1:0] b);
    return 16 * p + 4 * g + b;
  endfunction

  initial begin
    logic [255:0] d0, d1, d2;
    int t_a, t_w, t_r, tp0;
    rl[0] = 20; rl[1] = 20; wl[0] = 8; wl[1] = 8;
    wait_clk(3); rst_n = 1; wait_clk(2);
    last_t = cyc;

    // -------------------------------------------- pc0: tRCD, turnaround, tWTR
    rcmd(1, ACT, 0, 0, 0, 14'h111);
    chk(e_seen == 0 && bank_open == 32'h1, "ACT pc0 bank 0");
    t_a = last_t;
    ccmd(tRCDRD - 1, RD, 0, 0, 0, 6'd3);
    chk(e_seen == 14'h2, "RD inside tRCDRD rejected");
    ccmd(1, RD, 0, 0, 0, 6'd3);
    chk(e_seen == 0, "RD at tRCDRD accepted");
    plan_rd(0, 0, 0, 14'h111, 6'd3);
    t_r = last_t;
    d0 = rnd256();
    ccmd(rl[0] + 4 + 2 - wl[0] - 1, WR, 0, 0, 0, 6'd3);
    chk(e_seen == 14'h200, "WR inside the RD->WR turnaround rejected");
    ccmd(1, WR, 0, 0, 0, 6'd3);
    chk(e_seen == 0 && last_t - t_r == 18, "WR at RL + 4 + 2 - WL accepted");
    plan_wr(0, 0, 0, 14'h111, 6'd3, d0);
    t_w = last_t;
    ccmd(wl[0] + 4 + tWTR_L - 1, RD, 0, 0, 0, 6'd3);
    chk(e_seen == 14'h200, "RD inside tWTR_L rejected");
    ccmd(1, RD, 0, 0, 0, 6'd3);
    chk(e_seen == 0, "RD at tWTR_L accepted");
    plan_rd(0, 0, 0, 14'h111, 6'd3);
    t_r = last_t;
    rcmd(12, ACT, 0, 1, 0, 14'h222);
    chk(e_seen == 0, "ACT pc0 bank group 1");
    ccmd(tRCDWR - 1, WR, 0, 1, 0, 6'd0);
    chk(e_seen == 14'h2, "WR inside tRCDWR rejected");
    ccmd(1, WR, 0, 1, 0, 6'd0);
    chk(e_seen == 0, "WR at tRCDWR accepted");
    d1 = rnd256();
    plan_wr(0, 1, 0, 14'h222, 6'd0, d1);
    ccmd(tCCD_S - 1, WR, 0, 0, 0, 6'd5);
    chk(e_seen == 14'h40, "WR other bank group inside tCCD_S rejected");
    ccmd(1, WR, 0, 0, 0, 6'd5);
    chk(e_seen == 0, "WR other bank group at tCCD_S accepted");
    d2 = rnd256();
    plan_wr(0, 0, 0, 14'h111, 6'd5, d2);
    ccmd(tCCD_L - 1, WR, 0, 0, 0, 6'd6);
    chk(e_seen == 14'h40, "WR same bank group inside tCCD_L rejected");
    ccmd(1, WR, 0, 0, 0, 6'd6);
    chk(e_seen == 0, "WR same bank group at tCCD_L accepted");
    plan_wr(0, 0, 0, 14'h111, 6'd6, rnd256());
    t_w = last_t;
    rcmd(wl[0] + 4 + tWR - 1, PREPB, 0, 0, 0);
    chk(e_seen == 14'h80 && bank_open[0], "PRE inside tWR rejected");
    rcmd(1, PREPB, 0, 0, 0);
    chk(e_seen == 0 && !bank_open[0], "PRE at tWR closes the bank");
    rcmd(tRP - 1, ACT, 0, 0, 0, 14'h111);
    chk(e_seen == 14'h8, "ACT inside tRP rejected");
    rcmd(1, ACT, 0, 0, 0, 14'h111);
    chk(e_seen == 0, "ACT at tRP accepted");
    t_a = last_t;
    ccmd(tRCDRD, RD, 0, 0, 0, 6'd5);
    plan_rd(0, 0, 0, 14'h111, 6'd5);
    rcmd(t_a + tRAS - 1 - last_t, PREPB, 0, 0, 0);
    chk(e_seen == 14'h4, "PRE inside tRAS rejected");
    rcmd(1, PREPB, 0, 0, 0);
    chk(e_seen == 0, "PRE at tRAS accepted");
    ccmd(1, RD, 0, 1, 0, 6'd0);
    plan_rd(0, 1, 0, 14'h222, 6'd0);
    chk(e_seen == 0, "RD bank group 1");
    rcmd(tRTP - 1, PREPB, 0, 1, 0);
    chk(e_seen == 14'h100, "PRE inside tRTP rejected");
    rcmd(1, PREPB, 0, 1, 0);
    chk(e_seen == 0 && bank_open == 32'h0, "PRE at tRTP accepted");
    rcmd(1, PREPB, 0, 1, 0);
    chk(e_seen == 0, "PRE to an idle bank is a no-op");
    ccmd(1, RD, 0, 2, 0, 6'd0);
    chk(e_seen == 14'h1, "RD to an idle bank rejected");
    wait_clk(40);
    chk(derr_acc == 0, "no write data missing so far");
    chk(rd_cnt == 16 && rd_bad == 0 && rd_extra == 0, $sformatf("read data and latency RL 20 (cnt %0d bad %0d extra %0d)", rd_cnt, rd_bad, rd_extra));

    // -------------------------------------------- row and column in one clock
    rcmd(tRP, ACT, 0, 2, 0, 14'h0333);
    t_a = last_t;
    while (cyc + 1 < t_a + tRCDWR) @(negedge clk);
    r_cmd = ACT; r_pc = 0; r_bg = 3; r_ba = 1; r_row = 14'h0444;
    c_cmd = WR; c_pc = 0; c_bg = 2; c_ba = 0; c_col = 6'd9;
    last_t = cyc + 1;
    @(negedge clk);
    r_cmd = 0; c_cmd = 0;
    chk(err == 0 && cerr == 0 && bank_open == 32'h0000_2100, "ACT and WR in the same clock both accepted");
    plan_wr(0, 2, 0, 14'h0333, 6'd9, rnd256());
    rcmd(1, ACT, 0, 3, 1, 14'h0555);
    chk(e_seen == 14'h1, "ACT to the bank opened on the row bus rejected");

    // -------------------------------------------- pc1: tRRD, tFAW per pseudo channel
    rcmd(tRRD_S, ACT, 1, 0, 0, 14'h0010);
    t_a = last_t;
    rcmd(tRRD_L - 1, ACT, 1, 0, 1, 14'h0011);
    chk(e_seen == 14'h10, "pc1 ACT same bank group inside tRRD_L rejected");
    rcmd(1, ACT, 1, 0, 1, 14'h0011);
    chk(e_seen == 0, "pc1 ACT at tRRD_L");
    rcmd(tRRD_S - 1, ACT, 1, 1, 0, 14'h0012);
    chk(e_seen == 14'h10, "pc1 ACT other bank group inside tRRD_S rejected");
    rcmd(1, ACT, 1, 1, 0, 14'h0012);
    rcmd(tRRD_S, ACT, 1, 2, 0, 14'h0013);
    chk(e_seen == 0 && bank_open[31:16] == 16'h0113, "four ACTs on pc1");
    rcmd(tRRD_S, ACT, 0, 1, 2, 14'h0099);
    chk(e_seen == 0, "pc0 ACT not limited by pc1's tFAW window");
    rcmd(t_a + tFAW - 1 - last_t, ACT, 1, 3, 0, 14'h0014);
    chk(e_seen == 14'h20, "fifth pc1 ACT inside tFAW rejected");
    rcmd(1, ACT, 1, 3, 0, 14'h0014);
    chk(e_seen == 0 && last_t - t_a == tFAW, "fifth pc1 ACT at tFAW accepted");

    // -------------------------------------------- REFpb / REFab / tRREFD
    rcmd(tRRD_S, REFPB, 1, 0, 0);
    chk(e_seen == 14'h800, "REFpb to an open bank rejected");
    rcmd(1, REFPB, 1, 1, 1);
    chk(e_seen == 0, "REFpb to an idle bank accepted");
    tp0 = last_t;
    rcmd(1, REFPB, 1, 2, 2);
    chk(e_seen == 14'h10, "REFpb inside tRREFD of the previous REFpb rejected");
    rcmd(tRREFD - 2, ACT, 1, 2, 3, 14'h0015);
    chk(e_seen == 14'h10, "ACT to another bank inside tRREFD rejected");
    rcmd(1, ACT, 1, 2, 3, 14'h0015);
    chk(e_seen == 0 && last_t - tp0 == tRREFD, "ACT to another bank at tRREFD accepted");
    rcmd(tp0 + tRFCpb - 1 - last_t, ACT, 1, 1, 1, 14'h0016);
    chk(e_seen == 14'h400, "ACT to the refreshing bank inside tRFCpb rejected");
    rcmd(1, ACT, 1, 1, 1, 14'h0016);
    chk(e_seen == 0, "ACT to the refreshed bank at tRFCpb accepted");
    rcmd(1, REFAB, 1);
    chk(e_seen == 14'h800, "REFab with pc1 banks open rejected");
    ccmd(1, MRS, 1, 0, 0, 0, 4'd0, 8'd30);
    chk(e_seen == 14'h800, "MRS with pc1 banks open rejected");
    rcmd(tRAS, PREAB, 1);
    chk(e_seen == 0 && bank_open[31:16] == 16'h0, "PREab closes every pc1 bank");
    chk(bank_open[15:0] == 16'h2140, "PREab pc1 leaves pc0 banks open");
    rcmd(tRP - 1, REFAB, 1);
    chk(e_seen == 14'h8, "REFab inside tRP rejected");
    rcmd(1, REFAB, 1);
    chk(e_seen == 0, "REFab pc1 accepted");
    t_r = last_t;
    ccmd(tRCDWR, WR, 0, 3, 1, 6'd1);
    chk(e_seen == 0, "pc0 column command during pc1 refresh accepted");
    plan_wr(0, 3, 1, 14'h0444, 6'd1, rnd256());
    rcmd(t_r + tRFCab - 1 - last_t, ACT, 1, 0, 0, 14'h0020);
    chk(e_seen == 14'h400, "pc1 ACT inside tRFCab rejected");
    rcmd(1, ACT, 1, 0, 0, 14'h0020);
    chk(e_seen == 0, "pc1 ACT at tRFCab accepted");

    // -------------------------------------------- auto precharge
    ccmd(tRCDRD, RDA, 1, 0, 0, 6'd2);
    plan_rd(1, 0, 0, 14'h0020, 6'd2);
    t_a = last_t - tRCDRD;
    ccmd(1, RD, 1, 0, 0, 6'd3);
    chk(e_seen == 14'h1, "column command to a bank with auto precharge pending rejected");
    while (cyc < t_a + tRAS - 1) @(negedge clk);
    chk(bank_open[16], "RDA: bank open until ACT + tRAS");
    wait_clk(1);
    chk(!bank_open[16], "RDA: auto precharge at ACT + tRAS");
    rcmd(t_a + tRAS + tRP - 1 - last_t, ACT, 1, 0, 0, 14'h0021);
    chk(e_seen == 14'h8, "ACT inside tRP of the auto precharge rejected");
    rcmd(1, ACT, 1, 0, 0, 14'h0021);
    ccmd(tRCDWR, WRA, 1, 0, 0, 6'd7);
    plan_wr(1, 0, 0, 14'h0021, 6'd7, rnd256());
    t_w = last_t;
    while (cyc < t_w + wl[1] + 4 + tWR - 1) @(negedge clk);
    chk(bank_open[16], "WRA: bank open until write recovery ends");
    wait_clk(1);
    chk(!bank_open[16], "WRA: auto precharge at WRA + WL + 4 + tWR");

    // -------------------------------------------- MRS: latencies per pseudo channel
    rcmd(1, PREAB, 0);
    chk(e_seen == 0 && bank_open == 0, "PREab pc0");
    ccmd(tRP, MRS, 0, 0, 0, 0, 4'd0, 8'd4);
    chk(e_seen == 14'h2000, "MRS RL 4 (below the supported range) rejected");
    ccmd(1, MRS, 0, 0, 0, 0, 4'd0, 8'd30);
    chk(e_seen == 0, "MRS pc0 RL 30");
    ccmd(tMOD - 1, MRS, 0, 0, 0, 0, 4'd1, 8'd12);
    chk(e_seen == 14'h400, "command inside tMOD rejected");
    ccmd(1, MRS, 0, 0, 0, 0, 4'd1, 8'd12);
    chk(e_seen == 0, "MRS pc0 WL 12");
    rl[0] = 30; wl[0] = 12;
    rcmd(tMOD, ACT, 0, 0, 2, 14'h0777);
    rcmd(1, ACT, 1, 0, 2, 14'h0777);
    ccmd(tRCDWR, WR, 0, 0, 2, 6'd4);
    plan_wr(0, 0, 2, 14'h0777, 6'd4, rnd256());
    ccmd(1, WR, 1, 0, 2, 6'd4);
    plan_wr(1, 0, 2, 14'h0777, 6'd4, rnd256());
    chk(e_seen == 0, "pc1 column command one clock after pc0's (no shared tCCD)");
    ccmd(wl[0] + 4 + tWTR_L, RD, 0, 0, 2, 6'd4);
    plan_rd(0, 0, 2, 14'h0777, 6'd4);
    ccmd(1, RD, 1, 0, 2, 6'd4);
    plan_rd(1, 0, 2, 14'h0777, 6'd4);
    wait_clk(50);
    chk(rd_bad == 0 && rd_extra == 0, $sformatf("pc0 at RL 30 / WL 12 and pc1 at RL 20 / WL 8 (bad %0d extra %0d)", rd_bad, rd_extra));
    // missing write data
    derr_acc = 0;
    ccmd(rl[1] + 4 + 2 - wl[1], WR, 1, 0, 2, 6'd8);
    chk(e_seen == 0, "pc1 WR at its own turnaround");
    t_w = last_t;
    while (cyc < t_w + wl[1]) @(negedge clk);
    chk(derr == 2'b10, "write data missing on pc1 flagged");
    wait_clk(6);
    chk(derr_acc == 2'b10, "only pc1 reports missing write data");
    rcmd(1, 3'd6);
    chk(e_seen == 14'h2000, "reserved row command rejected");
    ccmd(1, 3'd7);
    chk(e_seen == 14'h2000, "reserved column command rejected");
    wait_clk(40);
    rcmd(1, PREAB, 0);
    rcmd(1, PREAB, 1);
    rcmd(tRP, REFAB, 0);
    rcmd(1, REFAB, 1);

    // -------------------------------------------- random legal traffic, both buses
    begin : rnd
      int ta [0:31], tp [0:31], trd [0:31], twe [0:31];
      int tag [0:7], tcg [0:7], tweg [0:7], tf [0:1][0:3];
      int tas [0:1], tcs [0:1], trs [0:1], tws [0:1];
      logic op [0:31];
      logic [13:0] orw [0:31];
      int n, nerr, t;
      nerr = 0; n = 0;
      for (int i = 0; i < 32; i++) begin op[i] = 0; ta[i] = -1000; tp[i] = cyc + tRFCab; trd[i] = -1000; twe[i] = -1000; end
      for (int i = 0; i < 8; i++) begin tag[i] = -1000; tcg[i] = -1000; tweg[i] = -1000; end
      for (int p = 0; p < 2; p++) begin
        tas[p] = -1000; tcs[p] = -1000; trs[p] = -1000; tws[p] = -1000;
        for (int i = 0; i < 4; i++) tf[p][i] = -1000;
      end
      while (n < 400) begin : one
        int rb, cb, rp, cp, rg, cg, k;
        logic [5:0] co;
        t = cyc + 1;
        r_cmd = 0; c_cmd = 0;
        // row bus
        rb = $urandom_range(31); rp = rb / 16; rg = rb / 4;
        if (!op[rb]) begin
          if (t - tp[rb] >= tRP && t - tag[rg] >= tRRD_L && t - tas[rp] >= tRRD_S && t - tf[rp][0] >= tFAW) begin
            r_cmd = ACT; r_pc = rp; r_bg = 2'(rg % 4); r_ba = 2'(rb % 4); r_row = 14'($urandom_range(3));
            op[rb] = 1; orw[rb] = r_row; ta[rb] = t; tag[rg] = t; tas[rp] = t;
            tf[rp][0] = tf[rp][1]; tf[rp][1] = tf[rp][2]; tf[rp][2] = tf[rp][3]; tf[rp][3] = t;
          end
        end else if ($urandom_range(4) == 0 && t - ta[rb] >= tRAS && t - trd[rb] >= tRTP && t - twe[rb] >= tWR) begin
          r_cmd = PREPB; r_pc = rp; r_bg = 2'(rg % 4); r_ba = 2'(rb % 4);
          op[rb] = 0; tp[rb] = t;
        end
        // column bus (a bank not touched by the row command this clock)
        cb = $urandom_range(31); cp = cb / 16; cg = cb / 4;
        co = 6'($urandom_range(3));
        k = $urandom_range(1);
        if (op[cb] && !(r_cmd != 0 && rb == cb) && t - ta[cb] >= (k ? tRCDWR : tRCDRD) &&
            t - tcg[cg] >= tCCD_L && t - tcs[cp] >= tCCD_S) begin
          if (k == 0 && t - tweg[cg] >= tWTR_L && t - tws[cp] >= tWTR_S) begin
            c_cmd = RD; c_pc = cp; c_bg = 2'(cg % 4); c_ba = 2'(cb % 4); c_col = co;
            trd[cb] = t; trs[cp] = t; tcg[cg] = t; tcs[cp] = t;
          end else if (k == 1 && t - trs[cp] >= rl[cp] + 4 + 2 - wl[cp]) begin
            c_cmd = WR; c_pc = cp; c_bg = 2'(cg % 4); c_ba = 2'(cb % 4); c_col = co;
            twe[cb] = t + wl[cp] + 4; tweg[cg] = twe[cb]; tws[cp] = twe[cb]; tcg[cg] = t; tcs[cp] = t;
          end
        end
        last_t = t;
        if (c_cmd == RD) plan_rd(c_pc, c_bg, c_ba, orw[cb], co);
        if (c_cmd == WR) plan_wr(c_pc, c_bg, c_ba, orw[cb], co, rnd256());
        if (r_cmd != 0) n++;
        if (c_cmd != 0) n++;
        @(negedge clk);
        r_cmd = 0; c_cmd = 0;
        if (err != 0 || cerr != 0) nerr++;
      end
      chk(nerr == 0, $sformatf("400 legal random commands raise no error (%0d)", nerr));
    end
    wait_clk(60);
    chk(rd_bad == 0 && rd_extra == 0 && derr == 0, $sformatf("random traffic read data and latency (reads %0d bad %0d extra %0d)", rd_cnt, rd_bad, rd_extra));

    // -------------------------------------------- refresh credit
    // both pseudo channels pulled in to the limit, then one interval later
    // pc1 pays one refresh with 16 REFpb: pc0 is flagged one tREFI earlier
    rcmd(1, PREAB, 0);
    rcmd(1, PREAB, 1);
    rcmd(tRP, REFAB, 0);
    rcmd(1, REFAB, 1);
    for (int i = 0; i < 2 * REF_POSTPONE + 3; i++) begin rcmd(tRFCab, REFAB, 0); rcmd(1, REFAB, 1); end
    begin : refc
      int t0, f0, f1, n0, n1;
      t0 = cyc; f0 = -1; f1 = -1; n0 = 0; n1 = 0;
      wait_clk(tREFI + 10);
      for (int i = 0; i < 16; i++) rcmd(tRREFD, REFPB, 1, 2'(i / 4), 2'(i % 4));
      chk(e_seen == 0, "16 REFpb on pc1 accepted");
      while (cyc - t0 < (2 * REF_POSTPONE + 3) * tREFI) begin
        @(negedge clk);
        if (rerr[0]) begin n0++; if (f0 < 0) f0 = cyc; end
        if (rerr[1]) begin n1++; if (f1 < 0) f1 = cyc; end
      end
      chk(n0 == 1 && n1 == 1, $sformatf("postponed refresh limit flagged once per pseudo channel (%0d, %0d)", n0, n1));
      chk(f0 > 0 && f1 - f0 == tREFI, $sformatf("16 REFpb count as one refresh (pc1 flagged %0d clocks after pc0)", f1 - f0));
    end

    // -------------------------------------------- per-pseudo-channel scope, PREab causes
    begin : scope
      int ta, tr, tw;
      rcmd(1, ACT, 1, 0, 0, 14'h0030);
      rcmd(tRRD_S, ACT, 0, 0, 0, 14'h0031);
      rcmd(tRAS - 1, PREAB, 0);
      chk(e_seen == 14'h4 && bank_open == 32'h0001_0001, "PREab inside tRAS rejected");
      rcmd(1, PREAB, 0);
      chk(e_seen == 0 && bank_open == 32'h0001_0000, "PREab pc0 leaves the open pc1 bank 0");
      rcmd(1, REFAB, 1);
      chk(e_seen == 14'h800, "REFab pc1 with only its bank 0 open rejected");
      ccmd(1, MRS, 1, 0, 0, 0, 4'd0, 8'd20);
      chk(e_seen == 14'h800, "MRS pc1 with only its bank 0 open rejected");
      rcmd(tRP, REFAB, 0);
      chk(e_seen == 0, "REFab pc0 with a pc1 bank open");
      ccmd(tRFCab, MRS, 0, 0, 0, 0, 4'd1, 8'd30);
      chk(e_seen == 14'h2000, "MRS WL 30 (above the range) rejected");
      ccmd(1, MRS, 0, 0, 0, 0, 4'd1, 8'd1);
      chk(e_seen == 14'h2000, "MRS WL 1 (below the range) rejected");
      ccmd(1, MRS, 0, 0, 0, 0, 4'd1, 8'd12);
      chk(e_seen == 0, "MRS pc0 with a pc1 bank open");
      rcmd(tMOD, REFPB, 0, 1, 1);
      chk(e_seen == 0, "REFpb pc0 bank 5");
      rcmd(tRREFD, REFPB, 0, 1, 1);
      chk(e_seen == 14'h400, "REFpb to a bank still inside tRFCpb rejected");
      // PREab reports the first violating bank's cause and does nothing
      rcmd(tRFCpb, ACT, 0, 2, 0, 14'h0040);
      ta = last_t;
      ccmd(tRAS, RD, 0, 2, 0, 6'd0);
      plan_rd(0, 2, 0, 14'h0040, 6'd0);
      tr = last_t;
      rcmd(1, ACT, 0, 3, 0, 14'h0041);
      rcmd(tRTP - 2, PREAB, 0);
      chk(e_seen == 14'h100 && bank_open == 32'h0001_1100, "PREab inside tRTP of bank 8 (bank 12 inside tRAS): only tRTP reported");
      ccmd(tr + rl[0] + 6 - wl[0] - last_t, WR, 0, 3, 0, 6'd0);
      plan_wr(0, 3, 0, 14'h0041, 6'd0, rnd256());
      tw = last_t;
      chk(e_seen == 0, "WR bank 12 after the turnaround");
      rcmd(wl[0] + 4 + tWR - 1, PREAB, 0);
      chk(e_seen == 14'h80 && bank_open == 32'h0001_1100, "PREab inside tWR of bank 12 rejected");
      ccmd(1, RDA, 0, 2, 0, 6'd1);
      plan_rd(0, 2, 0, 14'h0040, 6'd1);
      chk(e_seen == 0, "RDA bank 8");
      rcmd(1, PREAB, 0);
      chk(e_seen == 14'h1 && bank_open == 32'h0001_1100, "PREab with an auto precharge pending rejected");
      wait_clk(40);
      rcmd(1, PREAB, 0);
      chk(e_seen == 0 && bank_open == 32'h0001_0000, "PREab pc0 after the auto precharge");
      rcmd(1, PREAB, 1);
      wait_clk(40);
      chk(rd_bad == 0 && rd_extra == 0 && bank_open == 0, "reads around the PREab checks");
    end

    // -------------------------------------------- reset: no timing or data carried over
    begin : rst
      int f0, n0;
      rcmd(tRP, ACT, 0, 0, 0, 14'h0050);
      ccmd(tRCDWR, WR, 0, 0, 0, 6'd0);
      plan_wr(0, 0, 0, 14'h0050, 6'd0, rnd256());
      rst_n = 0;
      wait_clk(3);
      ex_v.delete(); ex_d.delete(); wp_v.delete(); wp_d.delete(); ref_m.delete();
      rl[0] = 20; rl[1] = 20; wl[0] = 8; wl[1] = 8;
      rst_n = 1;
      last_t = cyc;
      rcmd(1, ACT, 0, 0, 0, 14'h0050);
      chk(e_seen == 0 && bank_open == 32'h1, "first ACT after reset accepted");
      ccmd(tRCDRD, RD, 0, 0, 0, 6'd0);
      plan_rd(0, 0, 0, 14'h0050, 6'd0);
      chk(e_seen == 0, "RD after reset accepted");
      n0 = rd_cnt;
      wait_clk(30);
      chk(rd_cnt == n0 + 4 && rd_bad == 0 && rd_extra == 0, "memory reads zero after reset, at the reset RL 20");
      f0 = -1;
      while (mnow < (REF_POSTPONE + 2) * tREFI) begin
        @(negedge clk);
        if (rerr[0] && f0 < 0) f0 = mnow;
      end
      chk(f0 == (REF_POSTPONE + 1) * tREFI, $sformatf("no refresh after reset: flagged at exactly (REF_POSTPONE + 1) * tREFI (%0d)", f0));
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #50ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
