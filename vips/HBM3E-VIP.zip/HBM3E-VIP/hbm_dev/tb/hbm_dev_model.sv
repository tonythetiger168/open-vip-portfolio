// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm_dev_model.sv -- HBM3 / HBM3E channel reference model at the decoded
// command level (JESD238 pseudo-channel mode): one channel, two pseudo
// channels, each with 4 bank groups x 4 banks, 16k rows, 64 columns of 32
// bytes (BL8: 4 clocks of two 32-bit beats per pseudo channel on
// wdq / rdq[64 * pc +: 64]; beat 2i in [31:0], beat 2i+1 in [63:32]).
// Separate row and column command buses, both usable in the same clock
// (the row command is applied first):
//   row:    1 ACT  2 PREpb  3 PREab  4 REFab  5 REFpb
//   column: 1 RD   2 RDA    3 WR     4 WRA    5 MRS
// The CA pin encoding is not modelled. Latencies come from two mode
// registers in this model's own layout: MR0[5:0] = RL (reset 20),
// MR1[4:0] = WL (reset 8); MRS needs every bank of the pseudo channel idle.
// Timing (clocks, per pseudo channel): tRCDRD / tRCDWR ACT->RD / WR,
// tRAS, tRP, tRRD_S / tRRD_L, tFAW, tCCD_S / tCCD_L, tRTP, tWR and
// tWTR_S / tWTR_L from the end of write data, RD->WR turnaround
// RL + 4 + 2 - WL, tRFCab, tRFCpb (that bank), tRREFD REFpb->ACT of another
// bank, tMOD MRS->any. RDA / WRA precharge at the earliest legal time.
// Refresh: one REFab, or REFpb to all 16 banks, is owed per tREFI per
// pseudo channel; more than REF_POSTPONE owed pulses rerr[pc].
// A rejected command is not executed; err (row bus) / cerr (column bus)
// pulse one clock later with the cause:
//   [0] state  [1] tRCD  [2] tRAS  [3] tRP  [4] tRRD / tRREFD  [5] tFAW
//   [6] tCCD  [7] tWR  [8] tRTP  [9] tWTR / turnaround  [10] tRFCab / tMOD
//   pseudo channel busy, or tRFCpb bank busy  [11] REFab / REFpb / MRS
//   with a needed bank open  [12] (unused)  [13] illegal command
// derr[pc] pulses when wdq_valid[pc] is low in a write data clock.
module hbm_dev_model #(
  parameter int tRCDRD = 10, tRCDWR = 7, tRAS = 24, tRP = 10, tRRD_S = 2, tRRD_L = 3,
  parameter int tFAW = 12, tCCD_S = 4, tCCD_L = 6, tRTP = 5, tWR = 10,
  parameter int tWTR_S = 3, tWTR_L = 6, tRFCab = 60, tRFCpb = 20, tRREFD = 4,
  parameter int tMOD = 8, tREFI = 800, REF_POSTPONE = 8
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [2:0]  r_cmd,
  input  logic        r_pc,
  input  logic [1:0]  r_bg,
  input  logic [1:0]  r_ba,
  input  logic [13:0] r_row,
  input  logic [2:0]  c_cmd,
  input  logic        c_pc,
  input  logic [1:0]  c_bg,
  input  logic [1:0]  c_ba,
  input  logic [5:0]  c_col,
  input  logic [3:0]  c_mra,
  input  logic [7:0]  c_mrd,
  input  logic [127:0] wdq,       // {pc1, pc0}
  input  logic [1:0]  wdq_valid,
  output logic [127:0] rdq,       // {pc1, pc0}
  output logic [1:0]  rd_valid,
  output logic [31:0] bank_open,   // {pc1 banks, pc0 banks}, bank = bg * 4 + ba
  output logic [13:0] err,
  output logic [13:0] cerr,
  output logic [1:0]  derr,
  output logic [1:0]  rerr
);
  localparam logic [2:0] ACT = 1, PREPB = 2, PREAB = 3, REFAB = 4, REFPB = 5;
  localparam logic [2:0] RD = 1, RDA = 2, WR = 3, WRA = 4, MRS = 5;
  localparam int RS = 64;

  logic [255:0] mem [logic [24:0]];  // {pc, bank, row, col} -> 32-byte burst
  logic [7:0]   mr [0:1][0:15];
  int           now;
  logic         open_ [0:31];
  logic [13:0]  orow [0:31];
  int           t_act [0:31], t_pre [0:31], t_rd [0:31], t_wre [0:31], ap_at [0:31], t_bbusy [0:31];
  int           t_act_bg [0:7], t_col_bg [0:7], t_wre_bg [0:7];
  int           t_act_any [0:1], t_col_any [0:1], t_rd_any [0:1], t_wre_any [0:1], t_busy [0:1], t_refpb [0:1];
  int           faw [0:1][0:3];
  int           ref_owed [0:1], ref_t [0:1];
  logic [15:0]  pb_done [0:1];
  logic         rs_v [0:1][0:RS-1];
  logic [63:0]  rs_d [0:1][0:RS-1];
  logic         ws_v [0:1][0:RS-1];
  logic [24:0]  ws_k [0:1][0:RS-1];
  logic [1:0]   ws_b [0:1][0:RS-1];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mem.delete();
      for (int p = 0; p < 2; p++) begin
        for (int i = 0; i < 16; i++) mr[p][i] = 8'h00;
        mr[p][0] = 8'd20; mr[p][1] = 8'd8;
        t_act_any[p] = -100000; t_col_any[p] = -100000; t_rd_any[p] = -100000; t_wre_any[p] = -100000;
        t_busy[p] = 0; t_refpb[p] = -100000; ref_owed[p] = 0; ref_t[p] = 0; pb_done[p] = '0;
        for (int i = 0; i < 4; i++) faw[p][i] = -100000;
        for (int i = 0; i < RS; i++) begin rs_v[p][i] = 1'b0; ws_v[p][i] = 1'b0; end
      end
      for (int i = 0; i < 32; i++) begin
        open_[i] = 1'b0; orow[i] = '0; ap_at[i] = -1; t_bbusy[i] = 0;
        t_act[i] = -100000; t_pre[i] = -100000; t_rd[i] = -100000; t_wre[i] = -100000;
      end
      for (int i = 0; i < 8; i++) begin t_act_bg[i] = -100000; t_col_bg[i] = -100000; t_wre_bg[i] = -100000; end
      now = 0;
      rdq <= '0; rd_valid <= '0; bank_open <= '0;
      err <= '0; cerr <= '0; derr <= '0; rerr <= '0;
    end else begin : step
      logic [13:0] e, ce;
      logic [1:0] de, re;
      int b, g, p, rl, wl, s;
      logic [24:0] key;
      logic [255:0] line;
      e = '0; ce = '0; de = '0; re = '0;
      now = now + 1;
      s = now % RS;

      for (int q = 0; q < 2; q++) begin
        // write data capture
        if (ws_v[q][s]) begin
          ws_v[q][s] = 1'b0;
          if (!wdq_valid[q]) de[q] = 1'b1;
          else begin
            line = mem.exists(ws_k[q][s]) ? mem[ws_k[q][s]] : '0;
            line[64 * ws_b[q][s] +: 64] = wdq[64 * q +: 64];
            mem[ws_k[q][s]] = line;
          end
        end
        // read data out
        rd_valid[q] <= rs_v[q][s];
        rdq[64 * q +: 64] <= rs_v[q][s] ? rs_d[q][s] : 64'h0;
        rs_v[q][s] = 1'b0;
        // refresh bookkeeping
        if (now - ref_t[q] >= tREFI) begin
          ref_t[q] = ref_t[q] + tREFI;
          ref_owed[q] = ref_owed[q] + 1;
          if (ref_owed[q] == REF_POSTPONE + 1) re[q] = 1'b1;
        end
      end
      for (int i = 0; i < 32; i++)
        if (open_[i] && ap_at[i] >= 0 && now >= ap_at[i]) begin
          open_[i] = 1'b0; t_pre[i] = ap_at[i]; ap_at[i] = -1;
        end

      // ---------------- row command
      p = int'(r_pc); g = int'({r_pc, r_bg}); b = int'({r_pc, r_bg, r_ba});
      if (r_cmd != 3'd0) begin
        if (now - t_busy[p] < 0) e[10] = 1'b1;
        else case (r_cmd)
          ACT: begin
            if (open_[b]) e[0] = 1'b1;
            else if (now - t_bbusy[b] < 0) e[10] = 1'b1;
            else if (now - t_pre[b] < tRP) e[3] = 1'b1;
            else if (now - t_act_bg[g] < tRRD_L || now - t_act_any[p] < tRRD_S || now - t_refpb[p] < tRREFD) e[4] = 1'b1;
            else if (now - faw[p][0] < tFAW) e[5] = 1'b1;
            else begin
              open_[b] = 1'b1; orow[b] = r_row; t_act[b] = now;
              t_act_bg[g] = now; t_act_any[p] = now;
              faw[p][0] = faw[p][1]; faw[p][1] = faw[p][2]; faw[p][2] = faw[p][3]; faw[p][3] = now;
            end
          end
          PREPB: begin
            if (!open_[b]) begin end
            else if (ap_at[b] >= 0) e[0] = 1'b1;
            else if (now - t_act[b] < tRAS) e[2] = 1'b1;
            else if (now - t_rd[b] < tRTP) e[8] = 1'b1;
            else if (now - t_wre[b] < tWR) e[7] = 1'b1;
            else begin open_[b] = 1'b0; t_pre[b] = now; end
          end
          PREAB: begin : pa
            logic ok;
            ok = 1'b1;
            for (int i = 16 * p; i < 16 * p + 16; i++)
              if (open_[i] && ok) begin
                if (ap_at[i] >= 0) begin e[0] = 1'b1; ok = 1'b0; end
                else if (now - t_act[i] < tRAS) begin e[2] = 1'b1; ok = 1'b0; end
                else if (now - t_rd[i] < tRTP) begin e[8] = 1'b1; ok = 1'b0; end
                else if (now - t_wre[i] < tWR) begin e[7] = 1'b1; ok = 1'b0; end
              end
            if (ok)
              for (int i = 16 * p; i < 16 * p + 16; i++)
                if (open_[i]) begin open_[i] = 1'b0; t_pre[i] = now; end
          end
          REFAB: begin : ra
            logic any_open, prp, bb;
            any_open = 1'b0; prp = 1'b0; bb = 1'b0;
            for (int i = 16 * p; i < 16 * p + 16; i++) begin
              if (open_[i]) any_open = 1'b1;
              if (now - t_pre[i] < tRP) prp = 1'b1;
              if (now - t_bbusy[i] < 0) bb = 1'b1;
            end
            if (any_open) e[11] = 1'b1;
            else if (bb) e[10] = 1'b1;
            else if (prp) e[3] = 1'b1;
            else begin
              t_busy[p] = now + tRFCab;
              if (ref_owed[p] > -REF_POSTPONE) ref_owed[p] = ref_owed[p] - 1;
              pb_done[p] = '0;
            end
          end
          REFPB: begin
            if (open_[b]) e[11] = 1'b1;
            else if (now - t_bbusy[b] < 0) e[10] = 1'b1;
            else if (now - t_pre[b] < tRP) e[3] = 1'b1;
            else if (now - t_refpb[p] < tRREFD) e[4] = 1'b1;
            else begin
              t_bbusy[b] = now + tRFCpb; t_refpb[p] = now;
              pb_done[p][b % 16] = 1'b1;
              if (&pb_done[p]) begin
                pb_done[p] = '0;
                if (ref_owed[p] > -REF_POSTPONE) ref_owed[p] = ref_owed[p] - 1;
              end
            end
          end
          default: e[13] = 1'b1;
        endcase
      end

      // ---------------- column command
      p = int'(c_pc); g = int'({c_pc, c_bg}); b = int'({c_pc, c_bg, c_ba});
      rl = int'(mr[p][0][5:0]); wl = int'(mr[p][1][4:0]);
      if (c_cmd != 3'd0) begin
        if (now - t_busy[p] < 0) ce[10] = 1'b1;
        else case (c_cmd)
          RD, RDA, WR, WRA: begin
            logic w;
            w = (c_cmd == WR || c_cmd == WRA);
            if (!open_[b] || ap_at[b] >= 0) ce[0] = 1'b1;
            else if (now - t_act[b] < (w ? tRCDWR : tRCDRD)) ce[1] = 1'b1;
            else if (now - t_col_bg[g] < tCCD_L || now - t_col_any[p] < tCCD_S) ce[6] = 1'b1;
            else if (!w && (now - t_wre_bg[g] < tWTR_L || now - t_wre_any[p] < tWTR_S)) ce[9] = 1'b1;
            else if (w && now - t_rd_any[p] < rl + 4 + 2 - wl) ce[9] = 1'b1;
            else begin
              key = {c_pc, 4'(b % 16), orow[b], c_col};
              t_col_bg[g] = now; t_col_any[p] = now;
              if (w) begin
                for (int i = 0; i < 4; i++) begin
                  ws_v[p][(now + wl + i) % RS] = 1'b1;
                  ws_k[p][(now + wl + i) % RS] = key;
                  ws_b[p][(now + wl + i) % RS] = 2'(i);
                end
                t_wre[b] = now + wl + 4; t_wre_bg[g] = now + wl + 4; t_wre_any[p] = now + wl + 4;
                if (c_cmd == WRA) ap_at[b] = (now + wl + 4 + tWR > t_act[b] + tRAS) ? now + wl + 4 + tWR : t_act[b] + tRAS;
              end else begin
                line = mem.exists(key) ? mem[key] : '0;
                for (int i = 0; i < 4; i++) begin
                  rs_v[p][(now + rl + i) % RS] = 1'b1;
                  rs_d[p][(now + rl + i) % RS] = line[64 * i +: 64];
                end
                t_rd[b] = now; t_rd_any[p] = now;
                if (c_cmd == RDA) ap_at[b] = (now + tRTP > t_act[b] + tRAS) ? now + tRTP : t_act[b] + tRAS;
              end
            end
          end
          MRS: begin : ms
            logic any_open, prp;
            any_open = 1'b0; prp = 1'b0;
            for (int i = 16 * p; i < 16 * p + 16; i++) begin
              if (open_[i]) any_open = 1'b1;
              if (now - t_pre[i] < tRP) prp = 1'b1;
            end
            if (any_open) ce[11] = 1'b1;
            else if (prp) ce[3] = 1'b1;
            else if ((c_mra == 4'd0 && (c_mrd[5:0] < 6'd8 || c_mrd[5:0] > 6'd48)) ||
                     (c_mra == 4'd1 && (c_mrd[4:0] < 5'd2 || c_mrd[4:0] > 5'd24))) ce[13] = 1'b1;
            else begin
              mr[p][c_mra] = c_mrd;
              t_busy[p] = now + tMOD;
            end
          end
          default: ce[13] = 1'b1;
        endcase
      end

      for (int i = 0; i < 32; i++) bank_open[i] <= open_[i];
      err <= e; cerr <= ce; derr <= de; rerr <= re;
    end
  end
endmodule
