// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- HBM3E testbench top with a functional HBM3E DUT model

`ifndef HBM3E_TB_SV
`define HBM3E_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import hbm3e_defs_pkg::*;
import hbm3e_pkg::*;
import hbm3e_env_pkg::*;
import hbm3e_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  hbm3e_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  hbm3e_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cs_n(vif.cs_n),
    .act_n(vif.act_n),
    .stack(vif.stack),
    .pchan(vif.pchan),
    .addr(vif.addr),
    .wr_data(vif.wr_data),
    .rd_data(vif.rd_data),
    .rd_valid(vif.rd_valid)
  );

  // Concurrent protocol checks
  hbm3e_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .cs_n(vif.cs_n), .act_n(vif.act_n), .stack(vif.stack), .pchan(vif.pchan), .addr(vif.addr), .wr_data(vif.wr_data), .rd_data(vif.rd_data), .rd_valid(vif.rd_valid)
  );

  initial begin
    uvm_config_db#(virtual hbm3e_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module hbm3e_model (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         cs_n,
  input  logic         act_n,
  input  logic [1:0]   stack,
  input  logic         pchan,
  input  logic [13:0]  addr,
  input  logic [255:0] wr_data,
  output logic [255:0] rd_data,
  output logic         rd_valid
);
  // simplified HBM3E: 4 stacks x 2 pchan x 16k x 256b, RL=3
  logic [255:0] mem [0:3][0:1][0:16383];
  logic [255:0] pipe [0:2];
  logic         rd_pending [0:2];
  integer i, j, k;
  initial for (i = 0; i < 4; i = i + 1)
            for (j = 0; j < 2; j = j + 1)
              for (k = 0; k < 16384; k = k + 1) mem[i][j][k] = '0;
  initial rd_valid = 1'b0;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_data <= '0;
      rd_valid <= 1'b0;
      for (i = 0; i < 3; i = i + 1) rd_pending[i] <= 1'b0;
    end else begin
      if (!cs_n && act_n && !addr[0])
        mem[stack][pchan][addr[13:1]] <= wr_data;
      rd_valid <= rd_pending[2];
      if (rd_pending[2]) rd_data <= pipe[2];
      rd_pending[2] <= rd_pending[1];
      rd_pending[1] <= rd_pending[0];
      rd_pending[0] <= (!cs_n && act_n && addr[0]);
      pipe[0] <= mem[stack][pchan][addr[13:1]];
      pipe[1] <= pipe[0];
      pipe[2] <= pipe[1];
    end
  end
endmodule
`endif
