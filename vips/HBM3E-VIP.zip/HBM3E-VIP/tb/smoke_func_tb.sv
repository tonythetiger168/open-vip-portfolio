// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (HBM3E pseudo-channel independence)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened hbm3e_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic cs_n = 1'b1;
  logic act_n = 1'b1;
  logic [1:0] stack = '0;
  logic pchan = 1'b0;
  logic [13:0] addr = '0;
  logic [255:0] wr_data = '0;
  wire  [255:0] rd_data;
  wire  rd_valid;

  always #5 clk = ~clk;

  hbm3e_model u_dut (
    .clk(clk), .rst_n(rst_n), .cs_n(cs_n),
    .act_n(act_n), .stack(stack), .pchan(pchan),
    .addr(addr), .wr_data(wr_data),
    .rd_data(rd_data), .rd_valid(rd_valid)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(rd_valid === 1'b0, "rd_valid quiet in reset");
    @(negedge clk); rst_n = 1'b1;

    // write stack0 pchan0 col0 = 0F0F
    @(negedge clk); cs_n = 1'b0; addr = 14'd0;
    wr_data = 256'h0F0F;
    step();
    @(negedge clk); cs_n = 1'b1;
    step();

    // write stack1 pchan1 col0 = F0F0
    @(negedge clk); cs_n = 1'b0; stack = 2'd1; pchan = 1'b1;
    addr = 14'd0; wr_data = 256'hF0F0;
    step();
    @(negedge clk); cs_n = 1'b1; stack = 2'd0; pchan = 1'b0;
    step();

    // read stack0 pchan0: RL=4 total
    @(negedge clk); cs_n = 1'b0; addr = 14'd1;
    step();
    @(negedge clk); cs_n = 1'b1;
    repeat (2) begin step(); chk(rd_valid === 1'b0, "read latency respected"); end
    step();
    chk(rd_valid === 1'b1 && rd_data === 256'h0F0F, "pchan0 data");
    step();

    // read stack1 pchan1
    @(negedge clk); cs_n = 1'b0; stack = 2'd1; pchan = 1'b1;
    addr = 14'd1;
    step();
    @(negedge clk); cs_n = 1'b1; stack = 2'd0; pchan = 1'b0;
    repeat (2) step();
    step();
    chk(rd_valid === 1'b1 && rd_data === 256'hF0F0, "pchan1 data independent");
    step();
    chk(rd_valid === 1'b0, "rd_valid is a pulse");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
