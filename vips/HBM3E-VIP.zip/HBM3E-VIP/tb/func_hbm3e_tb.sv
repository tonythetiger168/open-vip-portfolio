// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_hbm3e_tb.sv -- pipelined-read memory functional test for the HBM3E
// model (hbm3e_model, flattened by smoke/flatten.py); complements smoke_func_tb.sv
// (single write / read per stack / pseudo channel).
// Run: python3 tools/run_func_tests.py HBM3E-VIP
//
// Model contract (from tb/top_tb.sv): a command is issued when cs_n = 0 and
// act_n = 1; addr[0] = 0 writes wr_data to word addr[13:1] of stack[1:0] / pseudo channel pchan,
// addr[0] = 1 reads it. Read data return with a one-clock rd_valid pulse
// 4 clocks after the command (fully pipelined, one read per clock);
// rd_data holds the last read value. Unwritten words read 0.
// Checked against a reference memory with 600 random commands.
//
// Not modelled (limitations, not tested): ACT/PRE/REF timing, bank
// state, burst length and the real HBM3E command encoding.

module func_hbm3e_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int W = 256, LAT = 4, NSEL = 8;
  int checks = 0, fails = 0;

  logic           clk = 1'b0, rst_n = 1'b0, cs_n = 1'b1, act_n = 1'b0;
  logic [$clog2(NSEL)-1:0] sel = '0;
  logic [13:0]    addr = '0;
  logic [W-1:0]   wr_data = '0;
  wire  [W-1:0]   rd_data;
  wire            rd_valid;
  logic           self_ref = 1'b0;

  always #5 clk = ~clk;

  hbm3e_model u_dut (
    .clk(clk), .rst_n(rst_n), .cs_n(cs_n), .act_n(act_n), .stack(sel[2:1]), .pchan(sel[0]),
    .addr(addr), .wr_data(wr_data), .rd_data(rd_data), .rd_valid(rd_valid)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic [W-1:0] ref_m [0:NSEL*8192-1];
  function automatic logic [W-1:0] rnd();
    logic [W-1:0] v;
    for (int i = 0; i < W; i += 32) v[i +: 32] = $urandom;
    return v;
  endfunction

  // expected read results, in issue order, with their issue clock
  logic [W-1:0] exp_q [0:4095];
  int           exp_t [0:4095];
  int           eh = 0, et = 0, cyc = 0, bad_data = 0, bad_lat = 0, extra = 0;
  always @(posedge clk) begin
    cyc++;
    if (rd_valid) begin
      if (et == eh) extra++;
      else begin
        if (rd_data !== exp_q[et]) bad_data++;
        if (cyc - exp_t[et] != LAT) bad_lat++;
        et++;
      end
    end
  end

  // one command in the next clock
  task automatic cmd(input bit rd, input int s, input int word, input [W-1:0] d = '0,
                     input bit csn = 0, input bit actn = 1);
    @(negedge clk);
    cs_n = csn; act_n = actn; sel = s; addr = {word[12:0], rd}; wr_data = d;
    if (!csn && actn && !self_ref) begin
      if (rd) begin exp_q[eh] = ref_m[s * 8192 + word]; exp_t[eh] = cyc + 1; eh++; end
      else ref_m[s * 8192 + word] = d;
    end
  endtask
  task automatic idle(input int n);
    @(negedge clk); cs_n = 1'b1;
    repeat (n - 1) @(negedge clk);
  endtask
  task automatic drain();
    idle(LAT + 2);
  endtask

  logic [W-1:0] held;
  int           v0;
  initial begin
    for (int i = 0; i < NSEL * 8192; i++) ref_m[i] = '0;
    repeat (2) @(negedge clk);
    chk(rd_valid === 1'b0 && rd_data === '0, "reset: rd_valid low, rd_data 0");
    rst_n = 1'b1;
    idle(12);
    chk(extra == 0, "no rd_valid after reset release without a read");

    // unwritten corners
    cmd(1, 0, 0); cmd(1, NSEL - 1, 8191); cmd(1, 0, 1); cmd(1, NSEL / 2, 4096);
    drain();
    chk(et == 4 && bad_data == 0, "unwritten words read 0 (first, last, odd words of each stack / pseudo channel)");
    chk(bad_lat == 0, "read data valid exactly 4 clocks after the read command");

    // write then read in the next clock; read in the same clock as data
    cmd(0, 1, 100, rnd());
    cmd(1, 1, 100);
    cmd(0, 1, 100, rnd());
    cmd(1, 1, 100);
    drain();
    chk(bad_data == 0 && et == eh, "read right after a write returns the new data");

    // every stack / pseudo channel holds its own data
    for (int s = 0; s < NSEL; s++) cmd(0, s, 777, rnd());
    for (int s = 0; s < NSEL; s++) cmd(1, s, 777);
    drain();
    chk(bad_data == 0, "same word in each stack / pseudo channel is independent");

    // back-to-back reads: one rd_valid per clock, in order
    v0 = et;
    for (int k = 0; k < 24; k++) cmd(1, k % NSEL, 777 + (k / NSEL));
    drain();
    chk(et - v0 == 24 && bad_data == 0 && bad_lat == 0, "24 back-to-back reads: data in order, fixed latency");

    // rd_data holds between reads
    held = rd_data;
    idle(6);
    chk(rd_data === held && !rd_valid, "rd_data holds the last read value while idle");

    // commands ignored with cs_n high or act_n low
    cmd(0, 2, 50, rnd(), 1, 1);
    cmd(0, 2, 50, rnd(), 0, 0);
    cmd(1, 2, 50, '0, 1, 1);
    cmd(1, 2, 50, '0, 0, 0);
    drain();
    chk(extra == 0, "read with cs_n high or act_n low returns nothing");
    cmd(1, 2, 50);
    drain();
    chk(bad_data == 0, "write with cs_n high or act_n low is ignored");

    // random traffic
    for (int k = 0; k < 600; k++) begin
      if ($urandom_range(3) == 0) idle($urandom_range(1, 3));
      cmd($urandom_range(1), $urandom_range(NSEL - 1), $urandom_range(63) * 129 % 8192, rnd());
    end
    drain();
    chk(bad_data == 0 && bad_lat == 0 && extra == 0 && et == eh,
        "600 random writes / reads match the reference memory");

    // reset with reads in flight
    cmd(1, 1, 100); cmd(1, 1, 100);
    @(negedge clk); cs_n = 1'b1; rst_n = 1'b0;
    @(negedge clk);
    chk(rd_valid === 1'b0 && rd_data === '0, "reset clears rd_valid and rd_data");
    eh = et;                                  // reads in flight are dropped
    rst_n = 1'b1;
    idle(LAT + 4);
    chk(extra == 0, "reads in flight at reset return nothing");
    cmd(1, 1, 100);
    drain();
    chk(bad_data == 0 && et == eh, "memory contents survive reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
