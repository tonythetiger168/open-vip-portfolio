# HBM3E UVM VIP (HBM3E-VIP)

HBM3E UVM VIP: 256-bit pseudo-channel memory with 4-deep stack select, fixed RL=3. Models per-channel independence for AI accelerator bandwidth smoke checks.

## Structure

- `hbm3e/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `hbm3e_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `hbm3e_base_test` (constrained-random), `hbm3e_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural HBM3E DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Pseudo-channel timing reference (`hbm_dev/`, v1.9.0)

The agent above drives the simplified `hbm3e_model` (fixed latency, no bank
state). `hbm_dev/` adds a channel model with the JESD238 pseudo-channel
rules at the decoded command level, and a controller-side test:

| File | Content |
|---|---|
| `hbm_dev/tb/hbm_dev_model.sv` | one channel, two pseudo channels, 4 bank groups x 4 banks each, BL8; separate row (ACT / PREpb / PREab / REFab / REFpb) and column (RD / RDA / WR / WRA / MRS) command buses usable in the same clock; tRCDRD / tRCDWR, tRAS, tRP, tRRD_S/L, tFAW, tCCD_S/L, tRTP, tWR, tWTR_S/L, RD->WR turnaround, tRFCab, tRFCpb (that bank only), tRREFD, tMOD; RL / WL per pseudo channel; refresh credit by REFab or 16 REFpb |
| `hbm_dev/tb/func_hbm_dev_tb.sv` | timing boundaries, row and column commands in one clock, pseudo-channel independence (banks, tFAW, refresh, latencies), REFpb rules, auto precharge, MRS rules, missing write data, refresh limit, 400 random commands on both buses against a reference memory, per-pseudo-channel scope of PREab / REFab / MRS, reset: 96 checks (`python3 tools/run_func_tests.py HBM3E-VIP`, Verilator) |

RL / WL sit in two mode registers in this model's own layout (MR0[5:0],
MR1[4:0]), not the JESD238 register map. Command / address parity, DBI, ECC,
severity reporting and the IEEE 1500 test port are not modelled.

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/HBM3E-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh HBM3E-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py HBM3E-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
