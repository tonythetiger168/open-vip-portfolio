# HBM3E UVM VIP (HBM3E-VIP)

HBM3E UVM VIP: 256-bit pseudo-channel memory with 4-deep stack select, fixed RL=3. Models per-channel independence for AI accelerator bandwidth smoke checks.

## Structure

- `hbm3e/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `hbm3e_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `hbm3e_base_test` (constrained-random), `hbm3e_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural HBM3E DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/HBM3E-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh HBM3E-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py HBM3E-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
