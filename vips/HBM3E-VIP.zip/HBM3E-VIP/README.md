# HBM3E UVM VIP (HBM3E-VIP)

HBM3E UVM VIP: 256-bit pseudo-channel memory with 4-deep stack select, fixed RL=3. Models per-channel independence for AI accelerator bandwidth smoke checks.

## Structure

- `hbm3e/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `hbm3e_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `hbm3e_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural HBM3E DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/HBM3E-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh HBM3E-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
