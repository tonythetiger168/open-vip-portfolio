// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_compliance_checker.sv -- CHI concurrent assertion checks (bindable)

module chi_compliance_checker
  (input logic clk, input logic rst_n, input logic req_flitv, input logic [6:0] req_opcode, input logic [11:0] req_txnid, input logic [43:0] req_addr, input logic [2:0] req_size, input logic req_allowretry, input logic [3:0] req_pcrdtype, input logic req_expcompack, input logic req_lcrdv, input logic wdat_flitv, input logic [3:0] wdat_opcode, input logic [11:0] wdat_txnid, input logic [2:0] wdat_resp, input logic [1:0] wdat_dataid, input logic [15:0] wdat_be, input logic [127:0] wdat_data, input logic wdat_lcrdv, input logic srsp_flitv, input logic [4:0] srsp_opcode, input logic [11:0] srsp_txnid, input logic srsp_lcrdv, input logic crsp_flitv, input logic [4:0] crsp_opcode, input logic [11:0] crsp_txnid, input logic [11:0] crsp_dbid, input logic [2:0] crsp_resp, input logic [1:0] crsp_resperr, input logic [3:0] crsp_pcrdtype, input logic crsp_lcrdv, input logic rdat_flitv, input logic [3:0] rdat_opcode, input logic [11:0] rdat_txnid, input logic [11:0] rdat_dbid, input logic [2:0] rdat_resp, input logic [1:0] rdat_resperr, input logic [1:0] rdat_dataid, input logic [127:0] rdat_data, input logic rdat_lcrdv, input logic proto_err, input logic [2:0] proto_code);

  // flits only with a link credit: count the credits each side holds
  int unsigned cr_crsp = 0, cr_rdat = 0;
  always @(posedge clk or negedge rst_n)
    if (!rst_n) begin cr_crsp <= 0; cr_rdat <= 0; end
    else begin
      cr_crsp <= cr_crsp + crsp_lcrdv - crsp_flitv;
      cr_rdat <= cr_rdat + rdat_lcrdv - rdat_flitv;
    end
  assert property (@(posedge clk) disable iff (!rst_n) crsp_flitv |-> cr_crsp != 0)
    else $error("CHI: RXRSP flit without an L-credit");
  assert property (@(posedge clk) disable iff (!rst_n) rdat_flitv |-> cr_rdat != 0)
    else $error("CHI: RXDAT flit without an L-credit");
  assert property (@(posedge clk) disable iff (!rst_n) rdat_flitv |-> rdat_opcode == 4'h4)
    else $error("CHI: RXDAT opcode other than CompData");
  assert property (@(posedge clk) disable iff (!rst_n) rdat_flitv && rdat_resperr == 2'b10 |-> rdat_data == 128'h0)
    else $error("CHI: CompData with DERR carries data");
  assert property (@(posedge clk) disable iff (!rst_n)
                   crsp_flitv && crsp_opcode inside {5'h3, 5'h7} |-> crsp_pcrdtype == 4'd1)
    else $error("CHI: RetryAck / PCrdGrant with an unexpected PCrdType");
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({crsp_flitv, rdat_flitv, req_lcrdv, wdat_lcrdv, srsp_lcrdv, proto_err}))
    else $error("CHI: X on Home Node outputs");
  cover property (@(posedge clk) disable iff (!rst_n) crsp_flitv && crsp_opcode == 5'h3);
  cover property (@(posedge clk) disable iff (!rst_n) crsp_flitv && crsp_opcode == 5'h7);
  cover property (@(posedge clk) disable iff (!rst_n) rdat_flitv && rdat_resperr == 2'b10);
endmodule
