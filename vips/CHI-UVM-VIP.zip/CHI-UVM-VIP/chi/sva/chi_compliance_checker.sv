// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_compliance_checker.sv -- CHI concurrent assertion checks (bindable)

module chi_compliance_checker
  (input logic clk, input logic rst_n, input req_valid, input [31:0] req_addr, input [4:0] req_opcode, input dat_valid, input [63:0] dat_data, input rsp_ready, input req_ready, input dat_ready, input rsp_valid, input [4:0] rsp_resp);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({req_ready, dat_ready, rsp_valid, rsp_resp}))
    else $error("CHI: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> req_ready == '0)
    else $error("CHI: output not in reset value");
  // response only after a request
  assert property (@(posedge clk) disable iff (!rst_n) $rose(rsp_valid) |-> $past(req_valid, 2))
    else $error("CHI: response without request");
  cover property (@(posedge clk) disable iff (!rst_n) (req_ready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (rsp_valid == 1'b1 && rsp_ready == 1'b1));
endmodule
