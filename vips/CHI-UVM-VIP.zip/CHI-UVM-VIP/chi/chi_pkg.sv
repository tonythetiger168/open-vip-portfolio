// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_pkg.sv -- CHI UVM VIP package

package chi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import chi_defs_pkg::*;
  export chi_defs_pkg::*;

  `include "chi_transaction.svh"
  `include "chi_config.svh"
  `include "chi_sequencer.svh"
  `include "chi_driver.svh"
  `include "chi_monitor.svh"
  `include "chi_agent.svh"
  `include "chi_sequences.svh"
  `include "chi_checker.svh"
  `include "chi_coverage.svh"
endpackage
