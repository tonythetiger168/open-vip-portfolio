// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_defs.sv -- CHI shared type definitions

package chi_defs_pkg;

  typedef enum bit [1:0] {CHI_OK, CHI_ERR} chi_status_e;

  // REQ opcodes used by the agent (CHI-B encodings, low 5 bits)
  localparam bit [4:0] CHI_READ_ONCE    = 5'h03;
  localparam bit [4:0] CHI_READ_NOSNP   = 5'h04;
  localparam bit [4:0] CHI_WRITE_UNIQUE = 5'h19;   // WriteUniqueFull
  localparam bit [4:0] CHI_WRITE_NOSNP  = 5'h1D;   // WriteNoSnpFull
  function automatic bit chi_is_write(bit [4:0] op);
    return op == CHI_WRITE_UNIQUE || op == CHI_WRITE_NOSNP;
  endfunction

endpackage
