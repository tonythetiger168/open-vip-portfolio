// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_defs.sv -- CHI shared type definitions

package chi_defs_pkg;

  typedef enum bit [1:0] {CHI_OK, CHI_ERR} chi_status_e;

  // REQ opcodes (CHI Issue E)
  localparam bit [6:0] CHI_READ_SHARED   = 7'h01;
  localparam bit [6:0] CHI_READ_CLEAN    = 7'h02;
  localparam bit [6:0] CHI_READ_ONCE     = 7'h03;
  localparam bit [6:0] CHI_READ_NOSNP    = 7'h04;
  localparam bit [6:0] CHI_READ_UNIQUE   = 7'h07;
  localparam bit [6:0] CHI_CLEAN_SHARED  = 7'h08;
  localparam bit [6:0] CHI_CLEAN_INVALID = 7'h09;
  localparam bit [6:0] CHI_MAKE_INVALID  = 7'h0A;
  localparam bit [6:0] CHI_CLEAN_UNIQUE  = 7'h0B;
  localparam bit [6:0] CHI_MAKE_UNIQUE   = 7'h0C;
  localparam bit [6:0] CHI_EVICT         = 7'h0D;
  localparam bit [6:0] CHI_WRITE_EVICT_FULL = 7'h15;
  localparam bit [6:0] CHI_WRITE_CLEAN_FULL = 7'h17;
  localparam bit [6:0] CHI_WRITE_UNIQUE_PTL = 7'h18;
  localparam bit [6:0] CHI_WRITE_UNIQUE_FULL = 7'h19;
  localparam bit [6:0] CHI_WRITE_BACK_FULL  = 7'h1B;
  localparam bit [6:0] CHI_WRITE_NOSNP_PTL  = 7'h1C;
  localparam bit [6:0] CHI_WRITE_NOSNP_FULL = 7'h1D;
  // RSP opcodes
  localparam bit [4:0] CHI_COMP_ACK = 5'h2, CHI_RETRY_ACK = 5'h3, CHI_COMP = 5'h4, CHI_COMP_DBID = 5'h5,
                       CHI_PCRD_GRANT = 5'h7;
  // DAT opcodes
  localparam bit [3:0] CHI_COPYBACK_WR = 4'h2, CHI_NONCOPYBACK_WR = 4'h3, CHI_COMP_DATA = 4'h4;
  // Resp (cache state) and RespErr
  localparam bit [2:0] CHI_I = 3'b000, CHI_SC = 3'b001, CHI_UC = 3'b010, CHI_UD_PD = 3'b110;
  localparam bit [1:0] CHI_RE_OK = 2'b00, CHI_RE_DERR = 2'b10, CHI_RE_NDERR = 2'b11;

  typedef enum bit [2:0] {CHI_X_NONE, CHI_X_SIZE, CHI_X_ALIGN, CHI_X_NOACK, CHI_X_OP, CHI_X_OOR} chi_inj_e;

  function automatic bit chi_is_read(bit [6:0] op);
    return op inside {CHI_READ_SHARED, CHI_READ_CLEAN, CHI_READ_ONCE, CHI_READ_NOSNP, CHI_READ_UNIQUE};
  endfunction
  function automatic bit chi_is_dataless(bit [6:0] op);
    return op inside {CHI_CLEAN_SHARED, CHI_CLEAN_INVALID, CHI_MAKE_INVALID, CHI_CLEAN_UNIQUE, CHI_MAKE_UNIQUE, CHI_EVICT};
  endfunction
  function automatic bit chi_is_copyback(bit [6:0] op);
    return op inside {CHI_WRITE_EVICT_FULL, CHI_WRITE_CLEAN_FULL, CHI_WRITE_BACK_FULL};
  endfunction
  function automatic bit chi_is_write(bit [6:0] op);
    return chi_is_copyback(op) || op inside {CHI_WRITE_UNIQUE_PTL, CHI_WRITE_UNIQUE_FULL, CHI_WRITE_NOSNP_PTL,
                                             CHI_WRITE_NOSNP_FULL};
  endfunction
  function automatic bit chi_is_ptl(bit [6:0] op);
    return op inside {CHI_WRITE_UNIQUE_PTL, CHI_WRITE_NOSNP_PTL};
  endfunction
  // requests that must set ExpCompAck
  function automatic bit chi_needs_ack(bit [6:0] op);
    return op inside {CHI_READ_SHARED, CHI_READ_CLEAN, CHI_READ_UNIQUE, CHI_CLEAN_UNIQUE, CHI_MAKE_UNIQUE};
  endfunction
  function automatic bit chi_known(bit [6:0] op);
    return chi_is_read(op) || chi_is_dataless(op) || chi_is_write(op);
  endfunction
  // default memory contents of line l
  function automatic bit [511:0] chi_mem_init(int unsigned l);
    bit [511:0] v;
    for (int j = 0; j < 16; j++) v[32*j +: 32] = 32'hC0DE_0000 | (l * 16 + j);
    return v;
  endfunction

endpackage
