// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_if.sv -- CHI interface

interface chi_if (input logic clk);
  logic rst_n;

  logic req_valid;
  logic [31:0] req_addr;
  logic [4:0] req_opcode;
  logic dat_valid;
  logic [63:0] dat_data;
  logic rsp_ready;
  logic req_ready;
  logic dat_ready;
  logic rsp_valid;
  logic [4:0] rsp_resp;

  modport DUT (input clk, rst_n, req_valid, req_addr, req_opcode, dat_valid, dat_data, rsp_ready, output req_ready, dat_ready, rsp_valid, rsp_resp);
  modport DRV (input clk, rst_n, req_ready, dat_ready, rsp_valid, rsp_resp, output req_valid, req_addr, req_opcode, dat_valid, dat_data, rsp_ready);
  modport MON (input clk, rst_n, req_valid, req_addr, req_opcode, dat_valid, dat_data, rsp_ready, req_ready, dat_ready, rsp_valid, rsp_resp);

  clocking drv_cb @(posedge clk);
    input rst_n, req_valid, req_addr, req_opcode, dat_valid, dat_data, rsp_ready, req_ready, dat_ready, rsp_valid, rsp_resp;
    output req_valid, req_addr, req_opcode, dat_valid, dat_data, rsp_ready;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, req_valid, req_addr, req_opcode, dat_valid, dat_data, rsp_ready, req_ready, dat_ready, rsp_valid, rsp_resp;
  endclocking
endinterface
