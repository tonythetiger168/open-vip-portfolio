// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_if.sv -- CHI interface

interface chi_if (input logic clk);
  logic rst_n;

  logic req_flitv;
  logic [6:0] req_opcode;
  logic [11:0] req_txnid;
  logic [43:0] req_addr;
  logic [2:0] req_size;
  logic req_allowretry;
  logic [3:0] req_pcrdtype;
  logic req_expcompack;
  logic req_lcrdv;
  logic wdat_flitv;
  logic [3:0] wdat_opcode;
  logic [11:0] wdat_txnid;
  logic [2:0] wdat_resp;
  logic [1:0] wdat_dataid;
  logic [15:0] wdat_be;
  logic [127:0] wdat_data;
  logic wdat_lcrdv;
  logic srsp_flitv;
  logic [4:0] srsp_opcode;
  logic [11:0] srsp_txnid;
  logic srsp_lcrdv;
  logic crsp_flitv;
  logic [4:0] crsp_opcode;
  logic [11:0] crsp_txnid;
  logic [11:0] crsp_dbid;
  logic [2:0] crsp_resp;
  logic [1:0] crsp_resperr;
  logic [3:0] crsp_pcrdtype;
  logic crsp_lcrdv;
  logic rdat_flitv;
  logic [3:0] rdat_opcode;
  logic [11:0] rdat_txnid;
  logic [11:0] rdat_dbid;
  logic [2:0] rdat_resp;
  logic [1:0] rdat_resperr;
  logic [1:0] rdat_dataid;
  logic [127:0] rdat_data;
  logic rdat_lcrdv;
  logic proto_err;
  logic [2:0] proto_code;

  modport DUT (input clk, rst_n, input req_flitv, input req_opcode, input req_txnid, input req_addr, input req_size, input req_allowretry, input req_pcrdtype, input req_expcompack, input wdat_flitv, input wdat_opcode, input wdat_txnid, input wdat_resp, input wdat_dataid, input wdat_be, input wdat_data, input srsp_flitv, input srsp_opcode, input srsp_txnid, input crsp_lcrdv, input rdat_lcrdv, output req_lcrdv, output wdat_lcrdv, output srsp_lcrdv, output crsp_flitv, output crsp_opcode, output crsp_txnid, output crsp_dbid, output crsp_resp, output crsp_resperr, output crsp_pcrdtype, output rdat_flitv, output rdat_opcode, output rdat_txnid, output rdat_dbid, output rdat_resp, output rdat_resperr, output rdat_dataid, output rdat_data, output proto_err, output proto_code);
  modport MON (input clk, rst_n, req_flitv, req_opcode, req_txnid, req_addr, req_size, req_allowretry, req_pcrdtype, req_expcompack, req_lcrdv, wdat_flitv, wdat_opcode, wdat_txnid, wdat_resp, wdat_dataid, wdat_be, wdat_data, wdat_lcrdv, srsp_flitv, srsp_opcode, srsp_txnid, srsp_lcrdv, crsp_flitv, crsp_opcode, crsp_txnid, crsp_dbid, crsp_resp, crsp_resperr, crsp_pcrdtype, crsp_lcrdv, rdat_flitv, rdat_opcode, rdat_txnid, rdat_dbid, rdat_resp, rdat_resperr, rdat_dataid, rdat_data, rdat_lcrdv, proto_err, proto_code);

  clocking drv_cb @(posedge clk);
    input rst_n, req_lcrdv, wdat_lcrdv, srsp_lcrdv, crsp_flitv, crsp_opcode, crsp_txnid, crsp_dbid, crsp_resp, crsp_resperr, crsp_pcrdtype, rdat_flitv, rdat_opcode, rdat_txnid, rdat_dbid, rdat_resp, rdat_resperr, rdat_dataid, rdat_data, proto_err, proto_code;
    inout req_flitv, req_opcode, req_txnid, req_addr, req_size, req_allowretry, req_pcrdtype, req_expcompack, wdat_flitv, wdat_opcode, wdat_txnid, wdat_resp, wdat_dataid, wdat_be, wdat_data, srsp_flitv, srsp_opcode, srsp_txnid, crsp_lcrdv, rdat_lcrdv;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, req_flitv, req_opcode, req_txnid, req_addr, req_size, req_allowretry, req_pcrdtype, req_expcompack, req_lcrdv, wdat_flitv, wdat_opcode, wdat_txnid, wdat_resp, wdat_dataid, wdat_be, wdat_data, wdat_lcrdv, srsp_flitv, srsp_opcode, srsp_txnid, srsp_lcrdv, crsp_flitv, crsp_opcode, crsp_txnid, crsp_dbid, crsp_resp, crsp_resperr, crsp_pcrdtype, crsp_lcrdv, rdat_flitv, rdat_opcode, rdat_txnid, rdat_dbid, rdat_resp, rdat_resperr, rdat_dataid, rdat_data, rdat_lcrdv, proto_err, proto_code;
  endclocking
endinterface
