// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_transaction.svh -- CHI transaction

class chi_transaction extends uvm_sequence_item;
  `uvm_object_utils(chi_transaction)

  // request (driven by the agent)
  rand bit [4:0] opcode;
  rand bit [31:0] addr;
  rand bit [63:0] data;
  // response (returned by the DUT)
  bit dat_acc;
  bit [4:0] resp;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_op   { opcode inside {CHI_READ_ONCE, CHI_READ_NOSNP, CHI_WRITE_UNIQUE, CHI_WRITE_NOSNP}; }
  constraint c_addr { addr[5:0] == 6'h0; }   // cache-line aligned
  constraint c_data { !(opcode inside {CHI_WRITE_UNIQUE, CHI_WRITE_NOSNP}) -> data == 0; }

  function new(string name = "chi_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    chi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    opcode = rhs_.opcode;
    addr = rhs_.addr;
    data = rhs_.data;
    dat_acc = rhs_.dat_acc;
    resp = rhs_.resp;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    chi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (opcode != rhs_.opcode) return 0;
    if (addr != rhs_.addr) return 0;
    if (data != rhs_.data) return 0;
    if (dat_acc != rhs_.dat_acc) return 0;
    if (resp != rhs_.resp) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(chi_transaction rhs_);
    if (opcode != rhs_.opcode) return 0;
    if (addr != rhs_.addr) return 0;
    if (data != rhs_.data) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("CHI{tag=%0d opcode=0x%0h addr=0x%0h data=0x%0h dat_acc=0x%0h resp=0x%0h}", tag, opcode, addr, data, dat_acc, resp);
  endfunction
endclass
