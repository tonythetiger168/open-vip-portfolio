// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_transaction.svh -- CHI transaction

class chi_transaction extends uvm_sequence_item;
  `uvm_object_utils(chi_transaction)

  // request (driven by the agent)
  rand bit [6:0] opcode;
  bit [11:0] txnid;
  bit [43:0] addr;
  bit [2:0] size;
  bit allowretry;
  bit [3:0] pcrdtype;
  bit expcompack;
  rand bit [511:0] wdata;
  bit [63:0] be;
  bit [2:0] cb_resp;
  // response (returned by the DUT)
  bit retried;
  bit [2:0] resp;
  bit [1:0] resperr;
  bit [511:0] rdata;
  bit [2:0] perr;
  // bookkeeping (not compared)
  rand chi_inj_e inj;
  rand bit [5:0] line;
  rand bit ackopt;
  rand bit cbi;
  rand bit [63:0] pbe;
  rand bit [3:0] gap;
  bit [11:0] dbid;
  bit [2:0] nbeat;
  bit mdone;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_op  { opcode inside {CHI_READ_SHARED, CHI_READ_CLEAN, CHI_READ_ONCE, CHI_READ_NOSNP, CHI_READ_UNIQUE,
                                    CHI_CLEAN_SHARED, CHI_CLEAN_INVALID, CHI_MAKE_INVALID, CHI_CLEAN_UNIQUE, CHI_MAKE_UNIQUE,
                                    CHI_EVICT, CHI_WRITE_EVICT_FULL, CHI_WRITE_CLEAN_FULL, CHI_WRITE_UNIQUE_PTL,
                                    CHI_WRITE_UNIQUE_FULL, CHI_WRITE_BACK_FULL, CHI_WRITE_NOSNP_PTL, CHI_WRITE_NOSNP_FULL}; }
  constraint c_inj { inj dist { CHI_X_NONE := 24, [CHI_X_SIZE : CHI_X_OOR] :/ 6 }; }
  constraint c_dat { !chi_is_write(opcode) -> wdata == 0; line inside {[0:15]}; gap inside {[0:3]}; }

  function new(string name = "chi_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    chi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    opcode = rhs_.opcode;
    txnid = rhs_.txnid;
    addr = rhs_.addr;
    size = rhs_.size;
    allowretry = rhs_.allowretry;
    pcrdtype = rhs_.pcrdtype;
    expcompack = rhs_.expcompack;
    wdata = rhs_.wdata;
    be = rhs_.be;
    cb_resp = rhs_.cb_resp;
    retried = rhs_.retried;
    resp = rhs_.resp;
    resperr = rhs_.resperr;
    rdata = rhs_.rdata;
    perr = rhs_.perr;
    inj = rhs_.inj;
    line = rhs_.line;
    ackopt = rhs_.ackopt;
    cbi = rhs_.cbi;
    pbe = rhs_.pbe;
    gap = rhs_.gap;
    dbid = rhs_.dbid;
    nbeat = rhs_.nbeat;
    mdone = rhs_.mdone;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    chi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (opcode != rhs_.opcode) return 0;
    if (txnid != rhs_.txnid) return 0;
    if (addr != rhs_.addr) return 0;
    if (size != rhs_.size) return 0;
    if (allowretry != rhs_.allowretry) return 0;
    if (pcrdtype != rhs_.pcrdtype) return 0;
    if (expcompack != rhs_.expcompack) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (be != rhs_.be) return 0;
    if (cb_resp != rhs_.cb_resp) return 0;
    if (retried != rhs_.retried) return 0;
    if (resp != rhs_.resp) return 0;
    if (resperr != rhs_.resperr) return 0;
    if (rdata != rhs_.rdata) return 0;
    if (perr != rhs_.perr) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(chi_transaction rhs_);
    if (opcode != rhs_.opcode) return 0;
    if (txnid != rhs_.txnid) return 0;
    if (addr != rhs_.addr) return 0;
    if (size != rhs_.size) return 0;
    if (allowretry != rhs_.allowretry) return 0;
    if (pcrdtype != rhs_.pcrdtype) return 0;
    if (expcompack != rhs_.expcompack) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (be != rhs_.be) return 0;
    if (cb_resp != rhs_.cb_resp) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("CHI{tag=%0d opcode=0x%0h txnid=0x%0h addr=0x%0h size=0x%0h allowretry=0x%0h pcrdtype=0x%0h expcompack=0x%0h wdata=0x%0h be=0x%0h cb_resp=0x%0h retried=0x%0h resp=0x%0h resperr=0x%0h rdata=0x%0h perr=0x%0h}", tag, opcode, txnid, addr, size, allowretry, pcrdtype, expcompack, wdata, be, cb_resp, retried, resp, resperr, rdata, perr);
  endfunction
endclass
