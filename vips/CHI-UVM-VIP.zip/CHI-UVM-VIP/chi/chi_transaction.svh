// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_transaction.svh -- CHI transaction

class chi_transaction extends uvm_sequence_item;
  `uvm_object_utils(chi_transaction)

  rand bit req_valid;
  rand bit [31:0] req_addr;
  rand bit [4:0] req_opcode;
  rand bit dat_valid;
  rand bit [63:0] dat_data;
  rand bit rsp_ready;
  bit req_ready_o;
  bit dat_ready_o;
  bit rsp_valid_o;
  bit [4:0] rsp_resp_o;
  bit [31:0] tag;

  function new(string name = "chi_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    chi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    req_valid = rhs_.req_valid;
    req_addr = rhs_.req_addr;
    req_opcode = rhs_.req_opcode;
    dat_valid = rhs_.dat_valid;
    dat_data = rhs_.dat_data;
    rsp_ready = rhs_.rsp_ready;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    chi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           req_valid == rhs_.req_valid &&
           req_addr == rhs_.req_addr &&
           req_opcode == rhs_.req_opcode &&
           dat_valid == rhs_.dat_valid &&
           dat_data == rhs_.dat_data &&
           rsp_ready == rhs_.rsp_ready;
  endfunction

  function string convert2string();
    return $sformatf("CHI{tag=%0h req_valid=0x%0h req_addr=0x%0h req_opcode=0x%0h dat_valid=0x%0h dat_data=0x%0h rsp_ready=0x%0h}", tag, req_valid, req_addr, req_opcode, dat_valid, dat_data, rsp_ready);
  endfunction
endclass
