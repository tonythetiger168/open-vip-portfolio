// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_sequences.svh -- CHI sequences

// Random traffic: cfg.num_items constrained-random items.
class chi_base_sequence extends uvm_sequence #(chi_transaction);
  `uvm_object_utils(chi_base_sequence)
  chi_config cfg;

  function new(string name = "chi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = chi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "chi_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class chi_directed_sequence extends uvm_sequence #(chi_transaction);
  `uvm_object_utils(chi_directed_sequence)
  chi_config cfg;

  function new(string name = "chi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function chi_transaction item();
    item = chi_transaction::type_id::create("req");
  endfunction

  task send(chi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    chi_transaction t;
    bit [6:0] ops [18] = '{CHI_READ_SHARED, CHI_READ_CLEAN, CHI_READ_ONCE, CHI_READ_NOSNP, CHI_READ_UNIQUE, CHI_CLEAN_SHARED,
                           CHI_CLEAN_INVALID, CHI_MAKE_INVALID, CHI_CLEAN_UNIQUE, CHI_MAKE_UNIQUE, CHI_EVICT,
                           CHI_WRITE_EVICT_FULL, CHI_WRITE_CLEAN_FULL, CHI_WRITE_UNIQUE_PTL, CHI_WRITE_UNIQUE_FULL,
                           CHI_WRITE_BACK_FULL, CHI_WRITE_NOSNP_PTL, CHI_WRITE_NOSNP_FULL};
    // every opcode, one at a time and then back to back (four outstanding: retries)
    foreach (ops[i]) begin t = item(); t.opcode = ops[i]; t.inj = CHI_X_NONE; t.line = i % 16; t.gap = 0; send(t); end
    for (int r = 0; r < 2; r++)
      foreach (ops[i]) begin t = item(); t.opcode = ops[i]; t.inj = CHI_X_NONE; t.line = (i + r) % 16; t.gap = 0; t.cbi = r; t.ackopt = r; send(t); end
    // four of one opcode back to back: two trackers, so each opcode also gets retried
    foreach (ops[i]) for (int k = 0; k < 4; k++) begin t = item(); t.opcode = ops[i]; t.inj = CHI_X_NONE; t.line = 8 + 2 * k; t.gap = 0; send(t); end
    // write then read back, partial write, lost copy-back
    t = item(); t.opcode = CHI_WRITE_NOSNP_FULL; t.inj = CHI_X_NONE; t.line = 3; t.wdata = {16{32'h1234_5678}}; send(t);
    t = item(); t.opcode = CHI_READ_NOSNP; t.inj = CHI_X_NONE; t.line = 3; send(t);
    t = item(); t.opcode = CHI_WRITE_UNIQUE_PTL; t.inj = CHI_X_NONE; t.line = 3; t.pbe = 64'h00FF_0000_F0F0_0001; t.wdata = '1; send(t);
    t = item(); t.opcode = CHI_READ_ONCE; t.inj = CHI_X_NONE; t.line = 3; send(t);
    t = item(); t.opcode = CHI_WRITE_BACK_FULL; t.inj = CHI_X_NONE; t.line = 3; t.cbi = 1; send(t);
    t = item(); t.opcode = CHI_READ_SHARED; t.inj = CHI_X_NONE; t.line = 3; send(t);
    // every injected error on a read, a dataless request and a write
    for (int i = 1; i < 6; i++) begin
      t = item(); t.opcode = CHI_READ_UNIQUE; t.inj = chi_inj_e'(i); t.line = 4; send(t);
      t = item(); t.opcode = CHI_CLEAN_UNIQUE; t.inj = chi_inj_e'(i); t.line = 5; send(t);
      t = item(); t.opcode = CHI_WRITE_NOSNP_FULL; t.inj = chi_inj_e'(i); t.line = 6; send(t);
    end
  endtask
endclass
