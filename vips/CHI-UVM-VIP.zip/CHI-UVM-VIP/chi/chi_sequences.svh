// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_sequences.svh -- CHI sequences

// Random traffic: cfg.num_items constrained-random items.
class chi_base_sequence extends uvm_sequence #(chi_transaction);
  `uvm_object_utils(chi_base_sequence)
  chi_config cfg;

  function new(string name = "chi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = chi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "chi_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class chi_directed_sequence extends uvm_sequence #(chi_transaction);
  `uvm_object_utils(chi_directed_sequence)
  chi_config cfg;

  function new(string name = "chi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function chi_transaction item();
    item = chi_transaction::type_id::create("req");
  endfunction

  task send(chi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    chi_transaction t;
    bit [4:0] ops [4] = '{CHI_READ_ONCE, CHI_READ_NOSNP, CHI_WRITE_UNIQUE, CHI_WRITE_NOSNP};
    foreach (ops[i]) begin
      t = item(); t.opcode = ops[i]; t.addr = 32'h1000 + i * 64;
      if (chi_is_write(ops[i])) t.data = 64'hFEED_FACE_0000_0000 | i;
      send(t);
    end
    t = item(); t.opcode = CHI_WRITE_NOSNP; t.addr = 32'hFFFF_FFC0; t.data = '1; send(t);
    t = item(); t.opcode = CHI_READ_NOSNP; t.addr = 32'hFFFF_FFC0; send(t);
  endtask
endclass
