// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_monitor.svh -- CHI monitor: every transaction followed by TxnID / DBID over the five channels, published in request order

class chi_monitor extends uvm_monitor;
  `uvm_component_utils(chi_monitor)

  virtual chi_if vif;
  uvm_analysis_port #(chi_transaction) ap;
  chi_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual chi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "chi: virtual interface not set")
    if (!uvm_config_db#(chi_config)::get(this, "", "cfg", cfg))
      cfg = chi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      chi_transaction rob[$];
      chi_transaction byid [bit [11:0]];
      chi_transaction bydw [bit [11:0]];
      chi_transaction byda [bit [11:0]];
      chi_transaction pend_perr;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rst_n !== 1'b1) begin rob.delete(); byid.delete(); bydw.delete(); byda.delete(); pend_perr = null; continue; end
        if (pend_perr != null) begin pend_perr.perr = vif.mon_cb.proto_err ? vif.mon_cb.proto_code : 3'd0; pend_perr = null; end
        if (vif.mon_cb.req_flitv) begin
          chi_transaction t = chi_transaction::type_id::create("t");
          t.opcode = vif.mon_cb.req_opcode; t.txnid = vif.mon_cb.req_txnid; t.addr = vif.mon_cb.req_addr;
          t.size = vif.mon_cb.req_size; t.allowretry = vif.mon_cb.req_allowretry; t.pcrdtype = vif.mon_cb.req_pcrdtype;
          t.expcompack = vif.mon_cb.req_expcompack; t.cb_resp = CHI_I;
          if (byid.exists(t.txnid)) `uvm_error("MON", $sformatf("CHI TxnID %0d reused while outstanding", t.txnid))
          rob.push_back(t); byid[t.txnid] = t; pend_perr = t;
        end
        if (vif.mon_cb.crsp_flitv) begin
          bit [11:0] id = vif.mon_cb.crsp_txnid, db = vif.mon_cb.crsp_dbid;
          if (vif.mon_cb.crsp_opcode == CHI_PCRD_GRANT) begin
            if (vif.mon_cb.crsp_pcrdtype != 4'd1) `uvm_error("MON", "CHI PCrdGrant with an unexpected PCrdType")
          end else if (!byid.exists(id)) `uvm_error("MON", $sformatf("CHI RXRSP for TxnID %0d not outstanding", id))
          else begin
            chi_transaction t = byid[id];
            byid.delete(id);
            t.dbid = db;
            case (vif.mon_cb.crsp_opcode)
              CHI_RETRY_ACK: begin
                t.retried = 1; t.mdone = 1;
                if (vif.mon_cb.crsp_pcrdtype != 4'd1) `uvm_error("MON", "CHI RetryAck with an unexpected PCrdType")
              end
              CHI_COMP: begin
                t.resp = vif.mon_cb.crsp_resp; t.resperr = vif.mon_cb.crsp_resperr;
                if (t.expcompack && db != 12'hFFF) byda[db] = t; else t.mdone = 1;
              end
              CHI_COMP_DBID: begin t.resperr = vif.mon_cb.crsp_resperr; bydw[db] = t; end
              default: `uvm_error("MON", "CHI unexpected RXRSP opcode")
            endcase
          end
        end
        if (vif.mon_cb.rdat_flitv) begin
          bit [11:0] id = vif.mon_cb.rdat_txnid;
          if (vif.mon_cb.rdat_opcode != CHI_COMP_DATA || !byid.exists(id))
            `uvm_error("MON", $sformatf("CHI RXDAT for TxnID %0d not outstanding", id))
          else begin
            chi_transaction t = byid[id];
            t.rdata[128 * vif.mon_cb.rdat_dataid +: 128] = vif.mon_cb.rdat_data;
            t.resp = vif.mon_cb.rdat_resp; t.resperr = vif.mon_cb.rdat_resperr; t.dbid = vif.mon_cb.rdat_dbid;
            if (++t.nbeat == 4) begin
              byid.delete(id);
              if (t.expcompack) byda[t.dbid] = t; else t.mdone = 1;
            end
          end
        end
        if (vif.mon_cb.wdat_flitv) begin
          bit [11:0] db = vif.mon_cb.wdat_txnid;
          if (!bydw.exists(db)) `uvm_error("MON", $sformatf("CHI write data for DBID %0d not expected", db))
          else begin
            chi_transaction t = bydw[db];
            t.wdata[128 * vif.mon_cb.wdat_dataid +: 128] = vif.mon_cb.wdat_data;
            t.be[16 * vif.mon_cb.wdat_dataid +: 16] = vif.mon_cb.wdat_be;
            t.cb_resp = vif.mon_cb.wdat_resp;
            if (++t.nbeat == 4) begin bydw.delete(db); t.mdone = 1; end
          end
        end
        if (vif.mon_cb.srsp_flitv) begin
          bit [11:0] db = vif.mon_cb.srsp_txnid;
          if (vif.mon_cb.srsp_opcode != CHI_COMP_ACK || !byda.exists(db)) `uvm_error("MON", $sformatf("CHI CompAck for DBID %0d not expected", db))
          else begin byda[db].mdone = 1; byda.delete(db); end
        end
        while (rob.size() != 0 && rob[0].mdone && rob[0] != pend_perr) publish(rob.pop_front());
      end
    end
  endtask

  function void publish(chi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
