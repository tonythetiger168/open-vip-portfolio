// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_monitor.svh -- CHI monitor: REQ/DAT handshake, completed by the RSP handshake

class chi_monitor extends uvm_monitor;
  `uvm_component_utils(chi_monitor)

  virtual chi_if vif;
  uvm_analysis_port #(chi_transaction) ap;
  chi_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual chi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "chi: virtual interface not set")
    if (!uvm_config_db#(chi_config)::get(this, "", "cfg", cfg))
      cfg = chi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      chi_transaction t;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.req_valid && vif.mon_cb.req_ready) begin
          if (t != null) `uvm_error("MON", "CHI request accepted with a response outstanding")
          t = chi_transaction::type_id::create("t");
          t.opcode  = vif.mon_cb.req_opcode;
          t.addr    = vif.mon_cb.req_addr;
          t.dat_acc = vif.mon_cb.dat_valid && vif.mon_cb.dat_ready;
          t.data    = vif.mon_cb.dat_valid ? vif.mon_cb.dat_data : 64'h0;
        end
        if (vif.mon_cb.rsp_valid && vif.mon_cb.rsp_ready) begin
          if (t == null) `uvm_error("MON", "CHI response without a request")
          else begin
            t.resp = vif.mon_cb.rsp_resp;
            publish(t);
            t = null;
          end
        end
      end
    end
  endtask

  function void publish(chi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
