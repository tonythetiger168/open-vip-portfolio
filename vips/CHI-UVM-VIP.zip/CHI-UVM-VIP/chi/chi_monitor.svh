// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_monitor.svh -- CHI monitor: decodes observed bus activity

class chi_monitor extends uvm_monitor;
  `uvm_component_utils(chi_monitor)

  virtual chi_if vif;
  uvm_analysis_port #(chi_transaction) ap;
  chi_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual chi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "chi: virtual interface not set")
    void'(uvm_config_db#(chi_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    chi_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = chi_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.req_valid = vif.req_valid;
        t.req_addr = vif.req_addr;
        t.req_opcode = vif.req_opcode;
        t.dat_valid = vif.dat_valid;
        t.dat_data = vif.dat_data;
        t.rsp_ready = vif.rsp_ready;
        t.req_ready_o = vif.req_ready;
        t.dat_ready_o = vif.dat_ready;
        t.rsp_valid_o = vif.rsp_valid;
        t.rsp_resp_o = vif.rsp_resp;
        ap.write(t);
      end
    end
  endtask
endclass
