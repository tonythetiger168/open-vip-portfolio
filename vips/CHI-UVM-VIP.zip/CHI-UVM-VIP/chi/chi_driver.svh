// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_driver.svh -- CHI driver: REQ (+DAT for writes) until req_ready, then accepts the RSP

class chi_driver extends uvm_driver #(chi_transaction);
  `uvm_component_utils(chi_driver)

  uvm_analysis_port #(chi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual chi_if vif;
  chi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual chi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "chi: virtual interface not set")
    if (!uvm_config_db#(chi_config)::get(this, "", "cfg", cfg))
      cfg = chi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    chi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.req_valid <= 1'b0; vif.drv_cb.req_addr <= '0; vif.drv_cb.req_opcode <= '0;
    vif.drv_cb.dat_valid <= 1'b0; vif.drv_cb.dat_data <= '0;
    vif.drv_cb.rsp_ready <= 1'b0;
  endtask

  task drive_item(chi_transaction t);
    @(vif.drv_cb);
    vif.drv_cb.req_valid  <= 1'b1;
    vif.drv_cb.req_addr   <= t.addr;
    vif.drv_cb.req_opcode <= t.opcode;
    vif.drv_cb.dat_valid  <= chi_is_write(t.opcode);
    vif.drv_cb.dat_data   <= t.data;
    begin
      int unsigned to = 0;
      do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.req_ready === 1'b1) && to < cfg.timeout_cycles);
      if (!(vif.drv_cb.req_ready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("CHI req_ready: no response within %0d cycles", cfg.timeout_cycles))
    end
    t.dat_acc = (vif.drv_cb.dat_ready === 1'b1);
    vif.drv_cb.req_valid <= 1'b0;
    vif.drv_cb.dat_valid <= 1'b0;
    // the model drops rsp_valid if rsp_ready is already high: accept after valid
    begin
      int unsigned to = 0;
      do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.rsp_valid === 1'b1) && to < cfg.timeout_cycles);
      if (!(vif.drv_cb.rsp_valid === 1'b1)) `uvm_error("TIMEOUT", $sformatf("CHI rsp_valid: no response within %0d cycles", cfg.timeout_cycles))
    end
    vif.drv_cb.rsp_ready <= 1'b1;
    @(vif.drv_cb);
    t.resp = vif.drv_cb.rsp_resp;
    vif.drv_cb.rsp_ready <= 1'b0;
  endtask

endclass
