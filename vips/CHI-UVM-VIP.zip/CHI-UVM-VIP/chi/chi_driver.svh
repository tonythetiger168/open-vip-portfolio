// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_driver.svh -- CHI driver: one request per item, up to cfg.max_out outstanding; background threads hold the link credits, send write data and CompAck and re-send retried requests

class chi_driver extends uvm_driver #(chi_transaction);
  `uvm_component_utils(chi_driver)

  uvm_analysis_port #(chi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual chi_if vif;
  chi_config cfg;

  int unsigned cr_req = 0, cr_wdat = 0, cr_srsp = 0;   // L-credits granted by the Home Node
  int unsigned owe_crsp = 0, owe_rdat = 0;            // L-credits we still have to grant
  chi_transaction outq [bit [11:0]];                  // by TxnID, waiting for the first response
  chi_transaction retryq [$];
  bit [3:0]    rbeats [bit [11:0]];
  bit          busy_line [64];
  bit          inuse [16];
  int unsigned n_out = 0;
  bit [3:0]    next_id = 0;
  bit          lk_req, lk_wdat, lk_srsp;   // channel locks (Verilator's semaphore spins in zero time)

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual chi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "chi: virtual interface not set")
    if (!uvm_config_db#(chi_config)::get(this, "", "cfg", cfg))
      cfg = chi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    chi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    fork
      begin
        lk_req = 0; lk_wdat = 0; lk_srsp = 0;
        owe_crsp = 4; owe_rdat = 4;
        fork
          forever begin
            @(vif.drv_cb);
            if (vif.drv_cb.req_lcrdv === 1'b1) cr_req++;
            if (vif.drv_cb.wdat_lcrdv === 1'b1) cr_wdat++;
            if (vif.drv_cb.srsp_lcrdv === 1'b1) cr_srsp++;
          end
          forever begin
            vif.drv_cb.crsp_lcrdv <= (owe_crsp != 0);
            vif.drv_cb.rdat_lcrdv <= (owe_rdat != 0);
            if (owe_crsp != 0) owe_crsp--;
            if (owe_rdat != 0) owe_rdat--;
            @(vif.drv_cb);
            if (vif.drv_cb.crsp_flitv === 1'b1) begin owe_crsp++; on_rsp(); end
            if (vif.drv_cb.rdat_flitv === 1'b1) begin owe_rdat++; on_dat(); end
          end
        join_none
      end
    join_none
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.req_flitv <= 1'b0; vif.drv_cb.req_opcode <= '0; vif.drv_cb.req_txnid <= '0; vif.drv_cb.req_addr <= '0;
    vif.drv_cb.req_size <= '0; vif.drv_cb.req_allowretry <= 1'b0; vif.drv_cb.req_pcrdtype <= '0; vif.drv_cb.req_expcompack <= 1'b0;
    vif.drv_cb.wdat_flitv <= 1'b0; vif.drv_cb.wdat_opcode <= '0; vif.drv_cb.wdat_txnid <= '0; vif.drv_cb.wdat_resp <= '0;
    vif.drv_cb.wdat_dataid <= '0; vif.drv_cb.wdat_be <= '0; vif.drv_cb.wdat_data <= '0;
    vif.drv_cb.srsp_flitv <= 1'b0; vif.drv_cb.srsp_opcode <= '0; vif.drv_cb.srsp_txnid <= '0;
    vif.drv_cb.crsp_lcrdv <= 1'b0; vif.drv_cb.rdat_lcrdv <= 1'b0;
  endtask

  task drive_item(chi_transaction t);
    repeat (t.gap) @(vif.drv_cb);
    while (n_out >= cfg.max_out || busy_line[t.line]) @(vif.drv_cb);
    while (inuse[next_id]) next_id++;
    t.txnid = next_id; inuse[next_id] = 1; next_id++;
    if (t.inj == CHI_X_OP) t.opcode = 7'h05 + t.pbe[0];
    t.size = (t.inj == CHI_X_SIZE) ? 3'd5 : 3'd6;
    t.addr = {(t.inj == CHI_X_OOR) ? 32'h1 : 32'h0, t.line, (t.inj == CHI_X_ALIGN) ? 6'h20 : 6'h00};
    if (t.inj inside {CHI_X_NONE, CHI_X_OOR})
      t.expcompack = chi_needs_ack(t.opcode) || (chi_is_read(t.opcode) && t.ackopt);
    else t.expcompack = 0;
    t.allowretry = 1; t.pcrdtype = 0;
    t.be = !chi_is_write(t.opcode) ? 64'h0 : chi_is_ptl(t.opcode) ? t.pbe : '1;
    t.cb_resp = chi_is_copyback(t.opcode) ? (t.cbi ? CHI_I : CHI_UD_PD) : CHI_I;
    if (!chi_is_write(t.opcode)) t.wdata = 0;
    outq[t.txnid] = t; rbeats[t.txnid] = 0;
    n_out++; busy_line[t.line] = 1;
    send_req(t);
  endtask

  task send_req(chi_transaction t);
    while (lk_req) @(vif.drv_cb); lk_req = 1;
    while (cr_req == 0) @(vif.drv_cb);
    cr_req--;
    vif.drv_cb.req_flitv <= 1'b1; vif.drv_cb.req_opcode <= t.opcode; vif.drv_cb.req_txnid <= t.txnid;
    vif.drv_cb.req_addr <= t.addr; vif.drv_cb.req_size <= t.size; vif.drv_cb.req_allowretry <= t.allowretry;
    vif.drv_cb.req_pcrdtype <= t.pcrdtype; vif.drv_cb.req_expcompack <= t.expcompack;
    @(vif.drv_cb);
    vif.drv_cb.req_flitv <= 1'b0;
    lk_req = 0;
  endtask

  // a retried request goes again with the granted P-credit
  task resend(chi_transaction t);
    chi_transaction c;
    t.allowretry = 0; t.pcrdtype = 4'd1;
    outq[t.txnid] = t; rbeats[t.txnid] = 0;
    send_req(t);
    $cast(c, t.clone());
    ap.write(c);
  endtask

  task send_wdata(chi_transaction t, bit [11:0] dbid);
    while (lk_wdat) @(vif.drv_cb); lk_wdat = 1;
    for (int b = 0; b < 4; b++) begin
      while (cr_wdat == 0) begin vif.drv_cb.wdat_flitv <= 1'b0; @(vif.drv_cb); end   // no flit while out of credits
      cr_wdat--;
      vif.drv_cb.wdat_flitv <= 1'b1;
      vif.drv_cb.wdat_opcode <= chi_is_copyback(t.opcode) ? CHI_COPYBACK_WR : CHI_NONCOPYBACK_WR;
      vif.drv_cb.wdat_txnid <= dbid; vif.drv_cb.wdat_resp <= t.cb_resp; vif.drv_cb.wdat_dataid <= b;
      vif.drv_cb.wdat_be <= t.be[16*b +: 16]; vif.drv_cb.wdat_data <= t.wdata[128*b +: 128];
      @(vif.drv_cb);
    end
    vif.drv_cb.wdat_flitv <= 1'b0;
    lk_wdat = 0;
    done(t);
  endtask

  task send_ack(bit [11:0] dbid);
    while (lk_srsp) @(vif.drv_cb); lk_srsp = 1;
    while (cr_srsp == 0) @(vif.drv_cb);
    cr_srsp--;
    vif.drv_cb.srsp_flitv <= 1'b1; vif.drv_cb.srsp_opcode <= CHI_COMP_ACK; vif.drv_cb.srsp_txnid <= dbid;
    @(vif.drv_cb);
    vif.drv_cb.srsp_flitv <= 1'b0;
    lk_srsp = 0;
  endtask

  function void done(chi_transaction t);
    inuse[t.txnid[3:0]] = 0; busy_line[t.line] = 0; n_out--;
  endfunction

  // RXRSP flit (sampled this clock)
  function void on_rsp();
    bit [11:0] id = vif.drv_cb.crsp_txnid, db = vif.drv_cb.crsp_dbid;
    chi_transaction t;
    case (vif.drv_cb.crsp_opcode)
      CHI_PCRD_GRANT:
        if (retryq.size() == 0) `uvm_error("DRV", "CHI PCrdGrant with no retried request")
        else begin
          chi_transaction r = retryq.pop_front();
          fork resend(r); join_none
        end
      CHI_RETRY_ACK, CHI_COMP, CHI_COMP_DBID: begin
        if (!outq.exists(id)) begin `uvm_error("DRV", $sformatf("CHI response for TxnID %0d not outstanding", id)) return; end
        t = outq[id]; outq.delete(id);
        if (vif.drv_cb.crsp_opcode == CHI_RETRY_ACK) retryq.push_back(t);
        else if (vif.drv_cb.crsp_opcode == CHI_COMP_DBID) fork send_wdata(t, db); join_none
        else begin
          if (t.expcompack && db != 12'hFFF) fork send_ack(db); join_none
          done(t);
        end
      end
      default: `uvm_error("DRV", "CHI unexpected RXRSP opcode")
    endcase
  endfunction

  // RXDAT flit: CompData beat
  function void on_dat();
    bit [11:0] id = vif.drv_cb.rdat_txnid, db = vif.drv_cb.rdat_dbid;
    chi_transaction t;
    if (!outq.exists(id)) begin `uvm_error("DRV", $sformatf("CHI CompData for TxnID %0d not outstanding", id)) return; end
    t = outq[id];
    rbeats[id]++;
    if (rbeats[id] == 4) begin
      outq.delete(id);
      if (t.expcompack) fork send_ack(db); join_none
      done(t);
    end
  endfunction
endclass
