// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_coverage.svh -- CHI functional coverage

class chi_coverage extends uvm_subscriber #(chi_transaction);
  `uvm_component_utils(chi_coverage)
  chi_config cfg;
  chi_transaction tr;

  covergroup chi_cg;
    coverpoint tr.req_valid;
    coverpoint tr.req_addr;
    coverpoint tr.req_opcode;
    coverpoint tr.dat_valid;
    coverpoint tr.dat_data;
    coverpoint tr.rsp_ready;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(chi_config)::get(this, "*", "cfg", cfg));
    chi_cg = new();
  endfunction

  function void write(chi_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    chi_cg.sample();
  endfunction
endclass
