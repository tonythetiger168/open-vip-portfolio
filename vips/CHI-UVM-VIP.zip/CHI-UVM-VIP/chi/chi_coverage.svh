// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_coverage.svh -- CHI functional coverage

class chi_coverage extends uvm_subscriber #(chi_transaction);
  `uvm_component_utils(chi_coverage)
  chi_config cfg;
  chi_transaction tr;

  covergroup chi_cg;
    cp_op    : coverpoint tr.opcode { bins rd_shared = {CHI_READ_SHARED}; bins rd_clean = {CHI_READ_CLEAN}; bins rd_once = {CHI_READ_ONCE};
                                      bins rd_nosnp = {CHI_READ_NOSNP}; bins rd_unique = {CHI_READ_UNIQUE};
                                      bins cl_shared = {CHI_CLEAN_SHARED}; bins cl_inval = {CHI_CLEAN_INVALID};
                                      bins mk_inval = {CHI_MAKE_INVALID}; bins cl_unique = {CHI_CLEAN_UNIQUE};
                                      bins mk_unique = {CHI_MAKE_UNIQUE}; bins evict = {CHI_EVICT};
                                      bins wr_evict = {CHI_WRITE_EVICT_FULL}; bins wr_clean = {CHI_WRITE_CLEAN_FULL};
                                      bins wr_uptl = {CHI_WRITE_UNIQUE_PTL}; bins wr_ufull = {CHI_WRITE_UNIQUE_FULL};
                                      bins wr_back = {CHI_WRITE_BACK_FULL}; bins wr_nptl = {CHI_WRITE_NOSNP_PTL};
                                      bins wr_nfull = {CHI_WRITE_NOSNP_FULL}; bins bad = {7'h05, 7'h06}; }
    cp_retry : coverpoint tr.retried;
    cp_ar    : coverpoint tr.allowretry;
    cp_err   : coverpoint tr.resperr { bins ok = {CHI_RE_OK}; bins derr = {CHI_RE_DERR}; bins nderr = {CHI_RE_NDERR}; }
    cp_perr  : coverpoint tr.perr { bins none = {0}; bins size = {3}; bins ack = {4}; bins op = {7}; }
    cp_resp  : coverpoint tr.resp iff (!tr.retried && tr.perr == 0) { bins i = {CHI_I}; bins sc = {CHI_SC}; bins uc = {CHI_UC}; }
    cp_ack   : coverpoint tr.expcompack iff (chi_is_read(tr.opcode) && !chi_needs_ack(tr.opcode));
    cp_cb    : coverpoint tr.cb_resp iff (chi_is_copyback(tr.opcode) && !tr.retried && tr.perr == 0) { bins i = {CHI_I}; bins ud = {CHI_UD_PD}; }
    cp_rop   : coverpoint tr.opcode { bins rd_shared = {CHI_READ_SHARED}; bins rd_clean = {CHI_READ_CLEAN}; bins rd_once = {CHI_READ_ONCE};
                                      bins rd_nosnp = {CHI_READ_NOSNP}; bins rd_unique = {CHI_READ_UNIQUE};
                                      bins cl_shared = {CHI_CLEAN_SHARED}; bins cl_inval = {CHI_CLEAN_INVALID};
                                      bins mk_inval = {CHI_MAKE_INVALID}; bins cl_unique = {CHI_CLEAN_UNIQUE};
                                      bins mk_unique = {CHI_MAKE_UNIQUE}; bins evict = {CHI_EVICT};
                                      bins wr_evict = {CHI_WRITE_EVICT_FULL}; bins wr_clean = {CHI_WRITE_CLEAN_FULL};
                                      bins wr_uptl = {CHI_WRITE_UNIQUE_PTL}; bins wr_ufull = {CHI_WRITE_UNIQUE_FULL};
                                      bins wr_back = {CHI_WRITE_BACK_FULL}; bins wr_nptl = {CHI_WRITE_NOSNP_PTL};
                                      bins wr_nfull = {CHI_WRITE_NOSNP_FULL}; }   // legal opcodes only (Verilator counts cross ignore_bins as bins)
    x_retry  : cross cp_rop, cp_retry;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    chi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(chi_config)::get(this, "", "cfg", cfg))
      cfg = chi_config::type_id::create("cfg");
  endfunction

  function void write(chi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    chi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CHI coverage: %0.1f%%", chi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
