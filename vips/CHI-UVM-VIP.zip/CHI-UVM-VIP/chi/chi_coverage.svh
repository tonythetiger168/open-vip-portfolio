// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_coverage.svh -- CHI functional coverage

class chi_coverage extends uvm_subscriber #(chi_transaction);
  `uvm_component_utils(chi_coverage)
  chi_config cfg;
  chi_transaction tr;

  covergroup chi_cg;
    cp_op : coverpoint tr.opcode { bins rd_once = {CHI_READ_ONCE}; bins rd_nosnp = {CHI_READ_NOSNP};
                                   bins wr_unique = {CHI_WRITE_UNIQUE}; bins wr_nosnp = {CHI_WRITE_NOSNP}; }
    cp_dat : coverpoint tr.dat_acc;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    chi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(chi_config)::get(this, "", "cfg", cfg))
      cfg = chi_config::type_id::create("cfg");
  endfunction

  function void write(chi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    chi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CHI coverage: %0.1f%%", chi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
