// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (CHI DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened chi_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic req_flitv = 0, req_allowretry = 0, req_expcompack = 0;
  logic [6:0] req_opcode = 0;
  logic [11:0] req_txnid = 0;
  logic [43:0] req_addr = 0;
  logic [2:0] req_size = 0;
  logic [3:0] req_pcrdtype = 0;
  logic wdat_flitv = 0;
  logic [3:0] wdat_opcode = 0;
  logic [11:0] wdat_txnid = 0;
  logic [2:0] wdat_resp = 0;
  logic [1:0] wdat_dataid = 0;
  logic [15:0] wdat_be = 0;
  logic [127:0] wdat_data = 0;
  logic srsp_flitv = 0;
  logic [4:0] srsp_opcode = 0;
  logic [11:0] srsp_txnid = 0;
  logic crsp_lcrdv = 0, rdat_lcrdv = 0;
  wire req_lcrdv, wdat_lcrdv, srsp_lcrdv, crsp_flitv, rdat_flitv, proto_err;
  wire [4:0] crsp_opcode;
  wire [11:0] crsp_txnid, crsp_dbid, rdat_txnid, rdat_dbid;
  wire [2:0] crsp_resp, rdat_resp, proto_code;
  wire [1:0] crsp_resperr, rdat_resperr, rdat_dataid;
  wire [3:0] crsp_pcrdtype, rdat_opcode;
  wire [127:0] rdat_data;

  always #5 clk = ~clk;

  chi_model u_dut (.clk(clk), .rst_n(rst_n), .req_flitv(req_flitv), .req_opcode(req_opcode), .req_txnid(req_txnid),
                   .req_addr(req_addr), .req_size(req_size), .req_allowretry(req_allowretry), .req_pcrdtype(req_pcrdtype),
                   .req_expcompack(req_expcompack), .req_lcrdv(req_lcrdv), .wdat_flitv(wdat_flitv),
                   .wdat_opcode(wdat_opcode), .wdat_txnid(wdat_txnid), .wdat_resp(wdat_resp), .wdat_dataid(wdat_dataid),
                   .wdat_be(wdat_be), .wdat_data(wdat_data), .wdat_lcrdv(wdat_lcrdv), .srsp_flitv(srsp_flitv),
                   .srsp_opcode(srsp_opcode), .srsp_txnid(srsp_txnid), .srsp_lcrdv(srsp_lcrdv), .crsp_flitv(crsp_flitv),
                   .crsp_opcode(crsp_opcode), .crsp_txnid(crsp_txnid), .crsp_dbid(crsp_dbid), .crsp_resp(crsp_resp),
                   .crsp_resperr(crsp_resperr), .crsp_pcrdtype(crsp_pcrdtype), .crsp_lcrdv(crsp_lcrdv),
                   .rdat_flitv(rdat_flitv), .rdat_opcode(rdat_opcode), .rdat_txnid(rdat_txnid), .rdat_dbid(rdat_dbid),
                   .rdat_resp(rdat_resp), .rdat_resperr(rdat_resperr), .rdat_dataid(rdat_dataid), .rdat_data(rdat_data),
                   .rdat_lcrdv(rdat_lcrdv), .proto_err(proto_err), .proto_code(proto_code));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // credits the Home Node granted us, and the ones we grant it (auto: one back per flit unless held)
  int g_req = 0, g_wdat = 0, g_srsp = 0;
  int owe_crsp = 0, owe_rdat = 0;
  bit hold = 0;
  // RXRSP flits and RXDAT beats seen
  logic [4:0]  r_op [0:63];
  logic [11:0] r_txn [0:63], r_db [0:63];
  logic [2:0]  r_rs [0:63];
  logic [1:0]  r_er [0:63];
  logic [3:0]  r_pt [0:63];
  int nr = 0;
  logic [11:0] d_txn [0:255], d_db [0:255];
  logic [2:0]  d_rs [0:255];
  logic [1:0]  d_er [0:255], d_id [0:255];
  logic [127:0] d_dat [0:255];
  int nd = 0, nperr = 0, gave_crsp = 0, cr0 = 0, nacc = 0;
  logic [2:0] lcode = 0;
  always @(negedge clk) begin
    if (req_lcrdv) g_req++;
    if (wdat_lcrdv) g_wdat++;
    if (srsp_lcrdv) g_srsp++;
    if (crsp_flitv) begin
      r_op[nr % 64] = crsp_opcode; r_txn[nr % 64] = crsp_txnid; r_db[nr % 64] = crsp_dbid; r_rs[nr % 64] = crsp_resp;
      r_er[nr % 64] = crsp_resperr; r_pt[nr % 64] = crsp_pcrdtype; nr++;
      if (!hold) owe_crsp++;
    end
    if (rdat_flitv) begin
      d_txn[nd % 256] = rdat_txnid; d_db[nd % 256] = rdat_dbid; d_rs[nd % 256] = rdat_resp; d_er[nd % 256] = rdat_resperr;
      d_id[nd % 256] = rdat_dataid; d_dat[nd % 256] = rdat_data; nd++;
      if (!hold) owe_rdat++;
    end
    if (proto_err) begin nperr++; lcode = proto_code; end
    crsp_lcrdv = (owe_crsp != 0); if (owe_crsp != 0) begin owe_crsp--; gave_crsp++; end
    rdat_lcrdv = (owe_rdat != 0); if (owe_rdat != 0) owe_rdat--;
  end

  task automatic idle(input int n);
    repeat (n) @(negedge clk);
    #1;
  endtask

  // one flit each; they use the credit (the count may go negative when sent without one on purpose)
  task automatic req(input logic [6:0] op, input logic [11:0] txn, input logic [43:0] a, input bit ack,
                     input bit ar = 1, input logic [3:0] pt = 0, input logic [2:0] sz = 6);
    @(negedge clk); #1;
    req_flitv = 1; req_opcode = op; req_txnid = txn; req_addr = a; req_size = sz; req_allowretry = ar;
    req_pcrdtype = pt; req_expcompack = ack; g_req--;
    @(negedge clk); #1 req_flitv = 0;
  endtask
  task automatic wd(input logic [3:0] op, input logic [11:0] db, input logic [2:0] rs, input logic [1:0] id,
                    input logic [15:0] be, input logic [127:0] d);
    @(negedge clk); #1;
    wdat_flitv = 1; wdat_opcode = op; wdat_txnid = db; wdat_resp = rs; wdat_dataid = id; wdat_be = be; wdat_data = d;
    g_wdat--;
    @(negedge clk); #1 wdat_flitv = 0;
  endtask
  task automatic line_wr(input logic [3:0] op, input logic [11:0] db, input logic [2:0] rs, input logic [63:0] be,
                         input logic [511:0] d);
    for (int b = 0; b < 4; b++) wd(op, db, rs, b, be[16*b +: 16], d[128*b +: 128]);
  endtask
  task automatic ack(input logic [11:0] db);
    @(negedge clk); #1;
    srsp_flitv = 1; srsp_opcode = 5'h2; srsp_txnid = db; g_srsp--;
    @(negedge clk); #1 srsp_flitv = 0;
  endtask

  function automatic logic [511:0] init_line(input int l);
    logic [511:0] v;
    for (int j = 0; j < 16; j++) v[32*j +: 32] = 32'hC0DE_0000 | (l * 16 + j);
    return v;
  endfunction

  // the last four CompData beats as one line
  function automatic logic [511:0] last_line();
    logic [511:0] v;
    for (int b = 0; b < 4; b++) v[128 * d_id[(nd - 4 + b) % 256] +: 128] = d_dat[(nd - 4 + b) % 256];
    return v;
  endfunction

  int r0, d0, p0;
  task automatic mark(); r0 = nr; d0 = nd; p0 = nperr; endtask
  // a read: four beats with TxnID txn, resp rs, err er, then (if ack) CompAck with the DBID
  task automatic rd(input logic [6:0] op, input logic [11:0] txn, input logic [43:0] a, input bit ak,
                    input logic [2:0] rs, input logic [1:0] er, input logic [511:0] exp, input string msg);
    bit ok;
    mark();
    req(op, txn, a, ak);
    idle(10);
    ok = (nd == d0 + 4) && (nr == r0) && (nperr == p0);
    for (int b = 0; b < 4; b++)
      ok &= d_txn[(d0 + b) % 256] == txn && d_rs[(d0 + b) % 256] == rs && d_er[(d0 + b) % 256] == er &&
            d_id[(d0 + b) % 256] == b;
    chk(ok && last_line() == exp, $sformatf("%s: four CompData beats (%0d beats, %0d rsp, %0d errors)", msg,
        nd - d0, nr - r0, nperr - p0));
    if (ak) ack(d_db[(nd - 1) % 256]);
    idle(2);
  endtask
  // a dataless request: one Comp
  task automatic dl(input logic [6:0] op, input logic [11:0] txn, input logic [43:0] a, input bit ak,
                    input logic [2:0] rs, input logic [1:0] er, input string msg);
    mark();
    req(op, txn, a, ak);
    idle(6);
    chk(nr == r0 + 1 && r_op[r0 % 64] == 5'h4 && r_txn[r0 % 64] == txn && r_rs[r0 % 64] == rs && r_er[r0 % 64] == er &&
        nperr == p0 && nd == d0, $sformatf("%s: Comp (op %0h rs %0d er %0d)", msg, r_op[r0 % 64], r_rs[r0 % 64], r_er[r0 % 64]));
    if (ak) ack(r_db[r0 % 64]);
    idle(2);
  endtask
  // a write: CompDBIDResp, then the line
  task automatic wr(input logic [6:0] op, input logic [11:0] txn, input logic [43:0] a, input logic [3:0] dop,
                    input logic [2:0] rs, input logic [63:0] be, input logic [511:0] d, input logic [1:0] er,
                    input string msg);
    mark();
    req(op, txn, a, 0);
    idle(6);
    chk(nr == r0 + 1 && r_op[r0 % 64] == 5'h5 && r_txn[r0 % 64] == txn && r_er[r0 % 64] == er && r_db[r0 % 64] < 2 &&
        nperr == p0, $sformatf("%s: CompDBIDResp (op %0h er %0d)", msg, r_op[r0 % 64], r_er[r0 % 64]));
    line_wr(dop, r_db[r0 % 64], rs, be, d);
    idle(2);
    chk(nperr == p0, $sformatf("%s: data accepted", msg));
  endtask
  // a request refused as a protocol error: Comp NDERR with DBID FFF
  task automatic bad(input logic [6:0] op, input logic [11:0] txn, input logic [43:0] a, input bit ak, input bit ar,
                     input logic [3:0] pt, input logic [2:0] sz, input logic [2:0] code, input string msg);
    mark();
    req(op, txn, a, ak, ar, pt, sz);
    idle(6);
    chk(nperr == p0 + 1 && lcode == code && nr == r0 + 1 && r_op[r0 % 64] == 5'h4 && r_er[r0 % 64] == 2'b11 &&
        r_db[r0 % 64] == 12'hFFF && r_txn[r0 % 64] == txn && nd == d0,
        $sformatf("%s: protocol error %0d (got %0d, %0d errors)", msg, code, lcode, nperr - p0));
  endtask

  logic [511:0] pat, exp_l;
  int db0, db1;
  initial begin
    idle(3);
    chk(!crsp_flitv && !rdat_flitv && !req_lcrdv && !proto_err, "reset values");
    // a flit on the first clock out of reset, before any credit
    rst_n = 1; req_flitv = 1; req_opcode = 7'h04; req_txnid = 1; req_size = 6; req_allowretry = 1; @(posedge clk); #1;
    req_flitv = 0;
    idle(1);
    chk(nperr == 1 && lcode == 1, "REQ flit before an L-credit: error 1");
    idle(6);
    chk(g_req == 2 && g_wdat == 2 && g_srsp == 2, $sformatf("two L-credits per inbound channel (%0d %0d %0d)", g_req, g_wdat, g_srsp));
    chk(nr == 0 && nd == 0, "the flit without credit was dropped");

    // no RXDAT credit yet: the data waits
    mark();
    hold = 1;
    req(7'h04, 12'd2, 44'h0, 0);
    idle(8);
    chk(nd == d0 && g_req == 2, "no CompData before we grant RXDAT credits; REQ credit returned");
    owe_rdat = 2; owe_crsp = 4; idle(8);
    chk(nd == d0 + 2, $sformatf("two RXDAT credits: two beats (%0d)", nd - d0));
    owe_rdat = 6; idle(6);
    chk(nd == d0 + 4 && last_line() == init_line(0), "ReadNoSnp: the rest of the line");
    chk(d_db[d0 % 256] == 0 && d_rs[d0 % 256] == 3'b000 && d_er[d0 % 256] == 2'b00, "ReadNoSnp: DBID 0, I, OK");
    hold = 0;

    // reads
    rd(7'h04, 12'd3, 44'h040, 0, 3'b000, 2'b00, init_line(1), "ReadNoSnp line 1");
    rd(7'h03, 12'd4, 44'h080, 0, 3'b000, 2'b00, init_line(2), "ReadOnce");
    rd(7'h03, 12'd5, 44'h0C0, 1, 3'b000, 2'b00, init_line(3), "ReadOnce with CompAck");
    rd(7'h01, 12'd6, 44'h100, 1, 3'b001, 2'b00, init_line(4), "ReadShared: SC");
    rd(7'h02, 12'd7, 44'h140, 1, 3'b001, 2'b00, init_line(5), "ReadClean: SC");
    rd(7'h07, 12'd8, 44'hFC0, 1, 3'b010, 2'b00, init_line(63), "ReadUnique line 63: UC");
    rd(7'h04, 12'd9, 44'h1000, 0, 3'b000, 2'b10, 512'h0, "ReadNoSnp above 4 KB: DERR, no data");
    rd(7'h07, 12'd10, 44'h0800_0000_1040, 1, 3'b010, 2'b10, 512'h0, "ReadUnique far above 4 KB: DERR");

    // dataless
    dl(7'h08, 12'd11, 44'h040, 0, 3'b000, 2'b00, "CleanShared");
    dl(7'h09, 12'd12, 44'h040, 0, 3'b000, 2'b00, "CleanInvalid");
    dl(7'h0A, 12'd13, 44'h040, 0, 3'b000, 2'b00, "MakeInvalid");
    dl(7'h0D, 12'd14, 44'h040, 0, 3'b000, 2'b00, "Evict");
    dl(7'h0B, 12'd15, 44'h040, 1, 3'b010, 2'b00, "CleanUnique: UC");
    dl(7'h0C, 12'd16, 44'h040, 1, 3'b010, 2'b00, "MakeUnique: UC");
    dl(7'h08, 12'd17, 44'h2040, 0, 3'b000, 2'b11, "CleanShared above 4 KB: NDERR");
    dl(7'h0B, 12'd18, 44'h2040, 1, 3'b010, 2'b11, "CleanUnique above 4 KB: NDERR, still waits for CompAck");
    dl(7'h08, 12'd17, 44'h040, 1, 3'b000, 2'b00, "CleanShared with ExpCompAck waits for CompAck");

    // writes
    for (int j = 0; j < 16; j++) pat[32*j +: 32] = 32'hA5A5_0000 + j * 32'h0101;
    wr(7'h1D, 12'd20, 44'h200, 4'h3, 3'b000, '1, pat, 2'b00, "WriteNoSnpFull line 8");
    rd(7'h04, 12'd21, 44'h200, 0, 3'b000, 2'b00, pat, "read back line 8");
    wr(7'h1C, 12'd22, 44'h200, 4'h3, 3'b000, 64'h8000_0001_0000_00F0, '1, 2'b00, "WriteNoSnpPtl");
    exp_l = pat;
    for (int k = 0; k < 64; k++) if (k inside {4, 5, 6, 7, 32, 63}) exp_l[8*k +: 8] = 8'hFF;
    rd(7'h04, 12'd23, 44'h200, 0, 3'b000, 2'b00, exp_l, "partial write merged by byte enable");
    wr(7'h19, 12'd24, 44'h240, 4'h3, 3'b000, '1, ~pat, 2'b00, "WriteUniqueFull line 9");
    wr(7'h18, 12'd25, 44'h240, 4'h3, 3'b000, 64'h0, pat, 2'b00, "WriteUniquePtl with no byte enabled");
    rd(7'h03, 12'd26, 44'h240, 0, 3'b000, 2'b00, ~pat, "line 9 unchanged by the empty partial write");
    wr(7'h1B, 12'd27, 44'h280, 4'h2, 3'b110, '1, pat ^ 1, 2'b00, "WriteBackFull UD_PD line 10");
    rd(7'h04, 12'd28, 44'h280, 0, 3'b000, 2'b00, pat ^ 1, "copy-back written");
    wr(7'h1B, 12'd29, 44'h280, 4'h2, 3'b000, '1, 512'h0, 2'b00, "WriteBackFull with resp I");
    rd(7'h04, 12'd30, 44'h280, 0, 3'b000, 2'b00, pat ^ 1, "lost copy-back writes nothing");
    wr(7'h17, 12'd31, 44'h2C0, 4'h2, 3'b001, '1, pat ^ 2, 2'b00, "WriteCleanFull SC");
    wr(7'h15, 12'd32, 44'h300, 4'h2, 3'b010, '1, pat ^ 3, 2'b00, "WriteEvictFull UC");
    rd(7'h04, 12'd33, 44'h2C0, 0, 3'b000, 2'b00, pat ^ 2, "WriteCleanFull written");
    rd(7'h04, 12'd34, 44'h300, 0, 3'b000, 2'b00, pat ^ 3, "WriteEvictFull written");
    wr(7'h1D, 12'd35, 44'h1300, 4'h3, 3'b000, '1, pat, 2'b11, "WriteNoSnpFull above 4 KB: NDERR");
    rd(7'h04, 12'd36, 44'h300, 0, 3'b000, 2'b00, pat ^ 3, "out-of-range write does not alias line 12");

    // write data errors
    mark();
    req(7'h1D, 12'd37, 44'h340, 0); idle(6);
    db0 = r_db[r0 % 64];
    wd(4'h2, db0, 3'b110, 0, '1, '1); idle(2);
    chk(nperr == p0 + 1 && lcode == 6, "CopyBackWrData for a WriteNoSnp: error 6");
    wd(4'h3, db0 ^ 1, 3'b000, 0, '1, '1); idle(2);
    chk(nperr == p0 + 2 && lcode == 6, "write data for a DBID not waiting: error 6");
    wd(4'h3, 12'h800, 3'b000, 0, '1, '1); idle(2);
    chk(nperr == p0 + 3 && lcode == 6, "write data for DBID 800: error 6");
    line_wr(4'h3, db0, 3'b000, '1, pat); idle(2);
    chk(nperr == p0 + 3, "then the right data completes the write");
    mark();
    req(7'h1B, 12'd38, 44'h340, 0); idle(6);
    wd(4'h3, r_db[r0 % 64], 3'b000, 0, '1, '1); idle(2);
    chk(nperr == p0 + 1 && lcode == 6, "NonCopyBackWrData for a WriteBack: error 6");
    line_wr(4'h2, r_db[r0 % 64], 3'b110, '1, ~pat); idle(2);
    rd(7'h04, 12'd39, 44'h340, 0, 3'b000, 2'b00, ~pat, "beats in any order");
    ack(12'd0); idle(2);
    chk(nperr == p0 + 1 && lcode == 6, "CompAck with no tracker waiting: error 6");
    mark();
    @(negedge clk); #1 srsp_flitv = 1; srsp_opcode = 5'h1; srsp_txnid = 0; g_srsp--; @(negedge clk); #1 srsp_flitv = 0; idle(2);
    chk(nperr == p0 + 1 && lcode == 6, "TXRSP opcode other than CompAck: error 6");

    // request errors
    bad(7'h04, 12'd40, 44'h040, 0, 1, 0, 3'd5, 3'd3, "Size 32 bytes");
    bad(7'h1D, 12'd41, 44'h060, 0, 1, 0, 3'd6, 3'd3, "address not line aligned");
    bad(7'h04, 12'd42, 44'h041, 0, 1, 0, 3'd6, 3'd3, "address bit 0 set");
    bad(7'h01, 12'd43, 44'h040, 0, 1, 0, 3'd6, 3'd4, "ReadShared without ExpCompAck");
    bad(7'h02, 12'd44, 44'h040, 0, 1, 0, 3'd6, 3'd4, "ReadClean without ExpCompAck");
    bad(7'h07, 12'd45, 44'h040, 0, 1, 0, 3'd6, 3'd4, "ReadUnique without ExpCompAck");
    bad(7'h0B, 12'd46, 44'h040, 0, 1, 0, 3'd6, 3'd4, "CleanUnique without ExpCompAck");
    bad(7'h0C, 12'd47, 44'h040, 0, 1, 0, 3'd6, 3'd4, "MakeUnique without ExpCompAck");
    bad(7'h04, 12'd48, 44'h040, 0, 0, 1, 3'd6, 3'd5, "AllowRetry 0 without a P-credit");
    bad(7'h00, 12'd49, 44'h040, 0, 1, 0, 3'd6, 3'd7, "opcode 00");
    bad(7'h05, 12'd49, 44'h040, 0, 1, 0, 3'd6, 3'd7, "opcode 05");
    bad(7'h06, 12'd49, 44'h040, 0, 1, 0, 3'd6, 3'd7, "opcode 06");
    bad(7'h0E, 12'd49, 44'h040, 0, 1, 0, 3'd6, 3'd7, "opcode 0E");
    bad(7'h14, 12'd49, 44'h040, 0, 1, 0, 3'd6, 3'd7, "opcode 14");
    bad(7'h16, 12'd49, 44'h040, 0, 1, 0, 3'd6, 3'd7, "opcode 16");
    bad(7'h1A, 12'd49, 44'h040, 0, 1, 0, 3'd6, 3'd7, "opcode 1A");
    bad(7'h1E, 12'd49, 44'h040, 0, 1, 0, 3'd6, 3'd7, "opcode 1E");
    bad(7'h7F, 12'd49, 44'h040, 0, 1, 0, 3'd5, 3'd7, "opcode 7F before the size check");
    bad(7'h01, 12'd49, 44'h041, 0, 1, 0, 3'd6, 3'd3, "size before ExpCompAck");

    // trackers, TxnID, retry and P-credits
    mark();
    req(7'h07, 12'd50, 44'h000, 1); req(7'h07, 12'd51, 44'h040, 1); idle(14);
    chk(nd == d0 + 8 && nperr == p0, "two ReadUniques hold both trackers");
    db0 = d_db[d0 % 256]; db1 = d_db[(d0 + 4) % 256];
    chk(db0 != db1 && db0 < 2 && db1 < 2, "distinct DBIDs");
    bad(7'h04, 12'd50, 44'h080, 0, 1, 0, 3'd6, 3'd2, "TxnID 50 still outstanding");
    mark();
    req(7'h04, 12'd52, 44'h080, 0); idle(6);
    chk(nr == r0 + 1 && r_op[r0 % 64] == 5'h3 && r_txn[r0 % 64] == 12'd52 && r_pt[r0 % 64] == 4'd1 && nd == d0,
        "no tracker: RetryAck with PCrdType 1");
    req(7'h04, 12'd53, 44'h0C0, 0); idle(6);
    chk(nr == r0 + 2 && r_op[(r0 + 1) % 64] == 5'h3, "a second RetryAck");
    bad(7'h04, 12'd52, 44'h080, 0, 0, 1, 3'd6, 3'd5, "re-sent before the grant");
    mark();
    ack(db0); idle(6);
    chk(nr == r0 + 1 && r_op[r0 % 64] == 5'h7 && r_pt[r0 % 64] == 4'd1, "CompAck frees a tracker: PCrdGrant");
    req(7'h04, 12'd54, 44'h100, 0); idle(6);
    chk(nr == r0 + 2 && r_op[(r0 + 1) % 64] == 5'h3 && nd == d0, "the freed tracker is reserved: RetryAck");
    bad(7'h04, 12'd52, 44'h080, 0, 0, 2, 3'd6, 3'd5, "PCrdType 2 does not match the grant");
    mark();
    req(7'h04, 12'd52, 44'h080, 0, 0, 1); idle(10);
    chk(nd == d0 + 4 && d_txn[d0 % 256] == 12'd52 && last_line() == init_line(2) && nperr == p0,
        "re-sent with AllowRetry 0: served on the reserved tracker");
    mark();
    ack(db1); idle(4);
    chk(nr == r0 + 1 && r_op[r0 % 64] == 5'h7, "next free tracker: grant for the second retry");
    req(7'h04, 12'd53, 44'h0C0, 0, 0, 1); idle(10);
    chk(nd == d0 + 4 && d_txn[d0 % 256] == 12'd53, "second retried request served");
    mark();
    ack(12'd0); idle(2);
    chk(nperr == p0 + 1, "no tracker left waiting for CompAck");
    // the third grant came when the first re-sent read finished
    idle(4);
    chk(nr == r0, "three retries, three grants: none left");
    req(7'h04, 12'd54, 44'h100, 0, 0, 1); idle(10);
    chk(nd == d0 + 4 && d_txn[d0 % 256] == 12'd54, "third retried request served");
    bad(7'h04, 12'd55, 44'h100, 0, 0, 1, 3'd6, 3'd5, "no P-credit left");
    // both trackers free again: a write and a read in flight together
    mark();
    req(7'h1D, 12'd56, 44'h380, 0); req(7'h04, 12'd57, 44'h3C0, 0); idle(12);
    chk(nr == r0 + 1 && nd == d0 + 4 && d_txn[d0 % 256] == 12'd57, "write waiting for data while a read completes");
    line_wr(4'h3, r_db[r0 % 64], 3'b000, '1, pat); idle(2);
    rd(7'h04, 12'd58, 44'h380, 0, 3'b000, 2'b00, pat, "write with a read in flight");
    // a dataless request without CompAck does not hold a tracker
    mark();
    req(7'h07, 12'd59, 44'h000, 1); req(7'h07, 12'd60, 44'h040, 1); idle(12);
    db0 = d_db[d0 % 256]; db1 = d_db[(d0 + 4) % 256];
    mark();
    req(7'h0D, 12'd61, 44'h080, 0); idle(6);
    chk(nr == r0 + 1 && r_op[r0 % 64] == 5'h3, "Evict while both trackers wait: RetryAck");
    ack(db0); ack(db1); idle(8);
    chk(nr == r0 + 2 && r_op[(r0 + 1) % 64] == 5'h7, "one grant for one retry");
    mark();
    req(7'h0D, 12'd61, 44'h080, 0, 0, 1); idle(6);
    chk(nr == r0 + 1 && r_op[r0 % 64] == 5'h4 && nperr == p0, "retried Evict completes");
    mark();
    req(7'h0D, 12'd62, 44'h080, 0); req(7'h0D, 12'd63, 44'h080, 0); req(7'h0D, 12'd64, 44'h080, 0); idle(8);
    chk(nr == r0 + 3 && r_op[r0 % 64] == 5'h4 && r_op[(r0 + 2) % 64] == 5'h4, "back-to-back Evicts need no tracker");

    // RXRSP queue while we hold the credits back: REQ credits stop before it can overflow
    hold = 1;
    idle(10);
    mark();
    cr0 = gave_crsp - nr;      // RXRSP credits the Home Node still holds
    for (int i = 0; i < 16; i++) if (g_req > 0) begin req(7'h08, 12'd70 + i, 44'h000, 0); nacc++; idle(2); end
    idle(10);
    chk(nr == r0 + cr0 && g_req == 0 && nperr == p0 && nacc == cr0 + 6,
        $sformatf("no RXRSP credit: six Comps queued, REQ credits withheld (%0d sent, %0d accepted)", nr - r0, nacc));
    hold = 0; owe_crsp = 8; idle(20);
    chk(nr == r0 + nacc, $sformatf("queued Comps delivered (%0d)", nr - r0));
    for (int i = 0; i < nacc; i++) chk(r_txn[(r0 + i) % 64] == 12'd70 + i, $sformatf("Comp %0d in order", i));
    chk(g_req == 2, $sformatf("REQ credits granted again (%0d)", g_req));

    // reset clears trackers and credits
    mark();
    req(7'h07, 12'd80, 44'h000, 1); idle(10);
    rst_n = 0; idle(2);
    chk(!crsp_flitv && !rdat_flitv && !req_lcrdv, "reset");
    g_req = 0; g_wdat = 0; g_srsp = 0; owe_crsp = 0; owe_rdat = 0;
    rst_n = 1; idle(8);
    chk(g_req == 2, "credits granted again after reset");
    owe_crsp = 4; owe_rdat = 4; idle(4);
    mark();
    req(7'h04, 12'd80, 44'h380, 0); idle(10);
    chk(nd == d0 + 4 && last_line() == pat && nperr == p0, "after reset: TxnID 80 is free, memory kept");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #4000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
