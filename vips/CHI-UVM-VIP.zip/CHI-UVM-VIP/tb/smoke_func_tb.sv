// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (CHI request/response handshake)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened chi_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic req_valid = 1'b0;
  logic [31:0] req_addr = '0;
  logic [4:0]  req_opcode = '0;
  logic dat_valid = 1'b0;
  logic [63:0] dat_data = '0;
  logic rsp_ready = 1'b0;
  wire  req_ready;
  wire  dat_ready;
  wire  rsp_valid;
  wire  [4:0]  rsp_resp;

  always #5 clk = ~clk;

  chi_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_addr(req_addr),
    .req_opcode(req_opcode), .dat_valid(dat_valid),
    .dat_data(dat_data), .rsp_ready(rsp_ready),
    .req_ready(req_ready), .dat_ready(dat_ready),
    .rsp_valid(rsp_valid), .rsp_resp(rsp_resp)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(req_ready === 1'b0 && rsp_valid === 1'b0, "channels reset quiet");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    repeat (3) begin step(); chk(rsp_valid === 1'b0, "no response without request"); end

    // issue a write request with data
    @(negedge clk);
    req_valid = 1; req_addr = 32'h1000; req_opcode = 5'b00011;
    dat_valid = 1; dat_data = 64'hCAFEBABE_DEADBEEF;
    step();
    chk(req_ready === 1'b1, "REQ accepted");
    chk(dat_ready === 1'b1, "DAT accepted");
    step();                            // data accept cycle (valid still held)
    @(negedge clk); req_valid = 0; dat_valid = 0;

    // RSP with OK status (rsp_ready held low so the pulse is observable)
    begin : rsp
      int to = 0;
      while (rsp_valid !== 1'b1 && to < 12) begin step(); to++; end
      chk(rsp_valid === 1'b1, "RSPVALID after request");
      chk(rsp_resp === 5'b00001, "RSP OK status");
      @(negedge clk); rsp_ready = 1'b1;
      step();
      chk(rsp_valid === 1'b0, "RSP completes");
    end

    // second transaction still works (state machine returns to IDLE)
    @(negedge clk); rsp_ready = 1'b0;   // re-arm: hold RSP observable
    @(negedge clk);
    req_valid = 1; req_addr = 32'h2000; req_opcode = 5'b00010;
    step();
    chk(req_ready === 1'b1, "second REQ accepted");
    step();
    @(negedge clk); req_valid = 0;
    begin : rsp2
      int to = 0;
      while (rsp_valid !== 1'b1 && to < 12) begin step(); to++; end
      chk(rsp_valid === 1'b1, "second RSP received");
      @(negedge clk); rsp_ready = 1'b1;
      step();
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
