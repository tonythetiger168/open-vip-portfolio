// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CHI testbench top with a functional CHI DUT model

`ifndef CHI_UVM_VIP_TB_SV
`define CHI_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import chi_defs_pkg::*;
import chi_pkg::*;
import chi_env_pkg::*;
import chi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  chi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  chi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .req_flitv(vif.req_flitv),
    .req_opcode(vif.req_opcode),
    .req_txnid(vif.req_txnid),
    .req_addr(vif.req_addr),
    .req_size(vif.req_size),
    .req_allowretry(vif.req_allowretry),
    .req_pcrdtype(vif.req_pcrdtype),
    .req_expcompack(vif.req_expcompack),
    .req_lcrdv(vif.req_lcrdv),
    .wdat_flitv(vif.wdat_flitv),
    .wdat_opcode(vif.wdat_opcode),
    .wdat_txnid(vif.wdat_txnid),
    .wdat_resp(vif.wdat_resp),
    .wdat_dataid(vif.wdat_dataid),
    .wdat_be(vif.wdat_be),
    .wdat_data(vif.wdat_data),
    .wdat_lcrdv(vif.wdat_lcrdv),
    .srsp_flitv(vif.srsp_flitv),
    .srsp_opcode(vif.srsp_opcode),
    .srsp_txnid(vif.srsp_txnid),
    .srsp_lcrdv(vif.srsp_lcrdv),
    .crsp_flitv(vif.crsp_flitv),
    .crsp_opcode(vif.crsp_opcode),
    .crsp_txnid(vif.crsp_txnid),
    .crsp_dbid(vif.crsp_dbid),
    .crsp_resp(vif.crsp_resp),
    .crsp_resperr(vif.crsp_resperr),
    .crsp_pcrdtype(vif.crsp_pcrdtype),
    .crsp_lcrdv(vif.crsp_lcrdv),
    .rdat_flitv(vif.rdat_flitv),
    .rdat_opcode(vif.rdat_opcode),
    .rdat_txnid(vif.rdat_txnid),
    .rdat_dbid(vif.rdat_dbid),
    .rdat_resp(vif.rdat_resp),
    .rdat_resperr(vif.rdat_resperr),
    .rdat_dataid(vif.rdat_dataid),
    .rdat_data(vif.rdat_data),
    .rdat_lcrdv(vif.rdat_lcrdv),
    .proto_err(vif.proto_err),
    .proto_code(vif.proto_code)
  );

  // Concurrent protocol checks
  chi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .req_flitv(vif.req_flitv),
    .req_opcode(vif.req_opcode),
    .req_txnid(vif.req_txnid),
    .req_addr(vif.req_addr),
    .req_size(vif.req_size),
    .req_allowretry(vif.req_allowretry),
    .req_pcrdtype(vif.req_pcrdtype),
    .req_expcompack(vif.req_expcompack),
    .req_lcrdv(vif.req_lcrdv),
    .wdat_flitv(vif.wdat_flitv),
    .wdat_opcode(vif.wdat_opcode),
    .wdat_txnid(vif.wdat_txnid),
    .wdat_resp(vif.wdat_resp),
    .wdat_dataid(vif.wdat_dataid),
    .wdat_be(vif.wdat_be),
    .wdat_data(vif.wdat_data),
    .wdat_lcrdv(vif.wdat_lcrdv),
    .srsp_flitv(vif.srsp_flitv),
    .srsp_opcode(vif.srsp_opcode),
    .srsp_txnid(vif.srsp_txnid),
    .srsp_lcrdv(vif.srsp_lcrdv),
    .crsp_flitv(vif.crsp_flitv),
    .crsp_opcode(vif.crsp_opcode),
    .crsp_txnid(vif.crsp_txnid),
    .crsp_dbid(vif.crsp_dbid),
    .crsp_resp(vif.crsp_resp),
    .crsp_resperr(vif.crsp_resperr),
    .crsp_pcrdtype(vif.crsp_pcrdtype),
    .crsp_lcrdv(vif.crsp_lcrdv),
    .rdat_flitv(vif.rdat_flitv),
    .rdat_opcode(vif.rdat_opcode),
    .rdat_txnid(vif.rdat_txnid),
    .rdat_dbid(vif.rdat_dbid),
    .rdat_resp(vif.rdat_resp),
    .rdat_resperr(vif.rdat_resperr),
    .rdat_dataid(vif.rdat_dataid),
    .rdat_data(vif.rdat_data),
    .rdat_lcrdv(vif.rdat_lcrdv),
    .proto_err(vif.proto_err),
    .proto_code(vif.proto_code)
  );

  initial begin
    uvm_config_db#(virtual chi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module chi_model (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         req_flitv,
  input  logic [6:0]   req_opcode,
  input  logic [11:0]  req_txnid,
  input  logic [43:0]  req_addr,
  input  logic [2:0]   req_size,
  input  logic         req_allowretry,
  input  logic [3:0]   req_pcrdtype,
  input  logic         req_expcompack,
  output logic         req_lcrdv,
  input  logic         wdat_flitv,
  input  logic [3:0]   wdat_opcode,
  input  logic [11:0]  wdat_txnid,
  input  logic [2:0]   wdat_resp,
  input  logic [1:0]   wdat_dataid,
  input  logic [15:0]  wdat_be,
  input  logic [127:0] wdat_data,
  output logic         wdat_lcrdv,
  input  logic         srsp_flitv,
  input  logic [4:0]   srsp_opcode,
  input  logic [11:0]  srsp_txnid,
  output logic         srsp_lcrdv,
  output logic         crsp_flitv,
  output logic [4:0]   crsp_opcode,
  output logic [11:0]  crsp_txnid,
  output logic [11:0]  crsp_dbid,
  output logic [2:0]   crsp_resp,
  output logic [1:0]   crsp_resperr,
  output logic [3:0]   crsp_pcrdtype,
  input  logic         crsp_lcrdv,
  output logic         rdat_flitv,
  output logic [3:0]   rdat_opcode,
  output logic [11:0]  rdat_txnid,
  output logic [11:0]  rdat_dbid,
  output logic [2:0]   rdat_resp,
  output logic [1:0]   rdat_resperr,
  output logic [1:0]   rdat_dataid,
  output logic [127:0] rdat_data,
  input  logic         rdat_lcrdv,
  output logic         proto_err,
  output logic [2:0]   proto_code
);
  localparam int TRK = 2, NCR = 2, QD = 8;
  localparam logic [2:0] T_FREE = 3'd0, T_RD = 3'd1, T_RACK = 3'd2, T_WD = 3'd3, T_DACK = 3'd4;

  logic [511:0] mem [0:63];
  initial for (int l = 0; l < 64; l++) for (int j = 0; j < 16; j++) mem[l][32*j +: 32] = 32'hC0DE_0000 | (l * 16 + j);

  // trackers
  logic [2:0]  t_st   [0:TRK-1];
  logic [11:0] t_txn  [0:TRK-1];
  logic [5:0]  t_line [0:TRK-1];
  logic        t_oor  [0:TRK-1];
  logic        t_ack  [0:TRK-1];
  logic [2:0]  t_resp [0:TRK-1];
  logic [6:0]  t_op   [0:TRK-1];
  logic [1:0]  t_beat [0:TRK-1];
  logic [3:0]  t_mask [0:TRK-1];
  // L-credits: held by the RN on our inbound channels, to grant, held by us on the outbound ones
  logic [2:0]  rn_req, rn_wdat, rn_srsp, g_req, g_wdat, g_srsp;
  logic [3:0]  cr_crsp, cr_rdat;
  // P-credits
  logic [2:0]  pend_grant, resv;
  // RXRSP queue
  logic [4:0]  q_op  [0:QD-1];
  logic [11:0] q_txn [0:QD-1];
  logic [11:0] q_dbid[0:QD-1];
  logic [2:0]  q_resp[0:QD-1];
  logic [1:0]  q_err [0:QD-1];
  logic [3:0]  q_pt  [0:QD-1];
  logic [3:0]  q_n;

  // working copies (blocking)
  logic [3:0]  n;
  logic [2:0]  ec, nfree, rd_i, pg, rv, fc;
  logic        found, sent, gr_req, gr_wdat, gr_srsp, req_ok, wdat_ok, srsp_ok;
  logic [11:0] di;
  integer      i, k;

  task automatic push(input logic [4:0] op, input logic [11:0] txn, input logic [11:0] dbid, input logic [2:0] rs,
                      input logic [1:0] er, input logic [3:0] pt);
    q_op[n] <= op; q_txn[n] <= txn; q_dbid[n] <= dbid; q_resp[n] <= rs; q_err[n] <= er; q_pt[n] <= pt;
    n = n + 4'd1;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (i = 0; i < TRK; i++) begin
        t_st[i] <= T_FREE; t_txn[i] <= 12'h0; t_line[i] <= 6'h0; t_oor[i] <= 1'b0; t_ack[i] <= 1'b0;
        t_resp[i] <= 3'h0; t_op[i] <= 7'h0; t_beat[i] <= 2'h0; t_mask[i] <= 4'h0;
      end
      rn_req <= 3'd0; rn_wdat <= 3'd0; rn_srsp <= 3'd0; g_req <= NCR; g_wdat <= NCR; g_srsp <= NCR;
      cr_crsp <= 4'd0; cr_rdat <= 4'd0; pend_grant <= 3'd0; resv <= 3'd0; q_n <= 4'd0;
      req_lcrdv <= 1'b0; wdat_lcrdv <= 1'b0; srsp_lcrdv <= 1'b0;
      crsp_flitv <= 1'b0; crsp_opcode <= 5'h0; crsp_txnid <= 12'h0; crsp_dbid <= 12'h0; crsp_resp <= 3'h0;
      crsp_resperr <= 2'h0; crsp_pcrdtype <= 4'h0;
      rdat_flitv <= 1'b0; rdat_opcode <= 4'h0; rdat_txnid <= 12'h0; rdat_dbid <= 12'h0; rdat_resp <= 3'h0;
      rdat_resperr <= 2'h0; rdat_dataid <= 2'h0; rdat_data <= 128'h0;
      proto_err <= 1'b0; proto_code <= 3'h0;
    end else begin
      proto_err <= 1'b0;
      n = q_n; pg = pend_grant; rv = resv; nfree = 3'd0;
      fc = 3'd0;
      for (i = 0; i < TRK; i++) if (t_st[i] == T_FREE) fc = fc + 3'd1;

      // ---- RXRSP: the queue head, when we hold a credit
      crsp_flitv <= 1'b0;
      if (n != 0 && cr_crsp != 0) begin
        crsp_flitv <= 1'b1; crsp_opcode <= q_op[0]; crsp_txnid <= q_txn[0]; crsp_dbid <= q_dbid[0];
        crsp_resp <= q_resp[0]; crsp_resperr <= q_err[0]; crsp_pcrdtype <= q_pt[0];
        for (k = 0; k < QD - 1; k++) begin
          q_op[k] <= q_op[k+1]; q_txn[k] <= q_txn[k+1]; q_dbid[k] <= q_dbid[k+1]; q_resp[k] <= q_resp[k+1];
          q_err[k] <= q_err[k+1]; q_pt[k] <= q_pt[k+1];
        end
        n = n - 4'd1;
        cr_crsp <= cr_crsp - 4'd1 + crsp_lcrdv;
      end else cr_crsp <= cr_crsp + crsp_lcrdv;

      // ---- RXDAT: one CompData beat, lowest tracker first
      rdat_flitv <= 1'b0;
      sent = 1'b0;
      for (i = 0; i < TRK; i++) begin
        if (!sent && t_st[i] == T_RD && cr_rdat != 0) begin
          sent = 1'b1;
          rdat_flitv <= 1'b1; rdat_opcode <= 4'h4; rdat_txnid <= t_txn[i]; rdat_dbid <= i;
          rdat_resp <= t_resp[i]; rdat_resperr <= t_oor[i] ? 2'b10 : 2'b00; rdat_dataid <= t_beat[i];
          rdat_data <= t_oor[i] ? 128'h0 : mem[t_line[i]][128 * t_beat[i] +: 128];
          t_beat[i] <= t_beat[i] + 2'd1;
          if (t_beat[i] == 2'd3) begin
            if (t_ack[i]) t_st[i] <= T_RACK;
            else begin t_st[i] <= T_FREE; nfree = nfree + 3'd1; end
          end
        end
      end
      cr_rdat <= cr_rdat - sent + rdat_lcrdv;

      // ---- L-credits we grant on the inbound channels, one per clock each; a REQ credit only while
      //      the RXRSP queue has room for every REQ the RN may still send plus the P-credit grants
      gr_req = (g_req != 0) && (q_n + rn_req < QD - TRK); gr_wdat = (g_wdat != 0); gr_srsp = (g_srsp != 0);
      req_lcrdv <= gr_req; wdat_lcrdv <= gr_wdat; srsp_lcrdv <= gr_srsp;
      req_ok  = req_flitv && rn_req != 0;
      wdat_ok = wdat_flitv && rn_wdat != 0;
      srsp_ok = srsp_flitv && rn_srsp != 0;
      rn_req  <= rn_req + gr_req - req_ok;    g_req  <= g_req - gr_req + req_ok;
      rn_wdat <= rn_wdat + gr_wdat - wdat_ok; g_wdat <= g_wdat - gr_wdat + wdat_ok;
      rn_srsp <= rn_srsp + gr_srsp - srsp_ok; g_srsp <= g_srsp - gr_srsp + srsp_ok;
      if ((req_flitv && !req_ok) || (wdat_flitv && !wdat_ok) || (srsp_flitv && !srsp_ok)) begin
        proto_err <= 1'b1; proto_code <= 3'd1;
      end

      // ---- TXRSP: CompAck, TxnID = DBID
      if (srsp_ok) begin
        di = srsp_txnid;
        if (srsp_opcode == 5'h2 && di < TRK && (t_st[di] == T_RACK || t_st[di] == T_DACK)) begin
          t_st[di] <= T_FREE; nfree = nfree + 3'd1;
        end else begin proto_err <= 1'b1; proto_code <= 3'd6; end
      end

      // ---- TXDAT: write data, TxnID = DBID
      if (wdat_ok) begin
        di = wdat_txnid;
        if (di < TRK && t_st[di] == T_WD &&
            wdat_opcode == ((t_op[di] == 7'h15 || t_op[di] == 7'h17 || t_op[di] == 7'h1B) ? 4'h2 : 4'h3)) begin
          if (!t_oor[di] && !(wdat_opcode == 4'h2 && wdat_resp == 3'b000))
            for (k = 0; k < 16; k++)
              if (wdat_be[k]) mem[t_line[di]][128 * wdat_dataid + 8 * k +: 8] <= wdat_data[8 * k +: 8];
          t_mask[di] <= t_mask[di] | (4'h1 << wdat_dataid);
          if ((t_mask[di] | (4'h1 << wdat_dataid)) == 4'hF) begin t_st[di] <= T_FREE; nfree = nfree + 3'd1; end
        end else begin proto_err <= 1'b1; proto_code <= 3'd6; end
      end

      // ---- TXREQ
      if (req_ok) begin
        ec = 3'd0;
        found = 1'b0;
        for (i = 0; i < TRK; i++) if (t_st[i] != T_FREE && t_txn[i] == req_txnid) found = 1'b1;
        if (!((req_opcode >= 7'h01 && req_opcode <= 7'h04) || (req_opcode >= 7'h07 && req_opcode <= 7'h0D) ||
              req_opcode == 7'h15 || (req_opcode >= 7'h17 && req_opcode <= 7'h19) ||
              (req_opcode >= 7'h1B && req_opcode <= 7'h1D))) ec = 3'd7;
        else if (found) ec = 3'd2;
        else if (req_size != 3'd6 || req_addr[5:0] != 6'h0) ec = 3'd3;
        else if (!req_expcompack && (req_opcode == 7'h01 || req_opcode == 7'h02 || req_opcode == 7'h07 ||
                                     req_opcode == 7'h0B || req_opcode == 7'h0C)) ec = 3'd4;
        else if (!req_allowretry && (rv == 0 || req_pcrdtype != 4'd1)) ec = 3'd5;
        if (ec != 3'd0) begin
          proto_err <= 1'b1; proto_code <= ec;
          push(5'h4, req_txnid, 12'hFFF, 3'b000, 2'b11, 4'h0);
        end else if (req_allowretry && fc <= rv) begin
          // no unreserved tracker: retry, and grant a P-credit when one frees
          push(5'h3, req_txnid, 12'h0, 3'b000, 2'b00, 4'h1);
          pg = pg + 3'd1;
        end else begin
          if (!req_allowretry) rv = rv - 3'd1;
          rd_i = 3'd0;
          for (i = TRK - 1; i >= 0; i--) if (t_st[i] == T_FREE) rd_i = i;
          t_txn[rd_i] <= req_txnid; t_line[rd_i] <= req_addr[11:6]; t_oor[rd_i] <= (req_addr[43:12] != 0);
          t_op[rd_i] <= req_opcode; t_beat[rd_i] <= 2'd0; t_mask[rd_i] <= 4'h0; t_ack[rd_i] <= req_expcompack;
          if (req_opcode <= 7'h07) begin
            t_st[rd_i] <= T_RD;
            t_resp[rd_i] <= (req_opcode == 7'h07) ? 3'b010 : (req_opcode <= 7'h02) ? 3'b001 : 3'b000;
          end else if (req_opcode <= 7'h0D) begin
            push(5'h4, req_txnid, rd_i, (req_opcode == 7'h0B || req_opcode == 7'h0C) ? 3'b010 : 3'b000,
                 (req_addr[43:12] != 0) ? 2'b11 : 2'b00, 4'h0);
            if (req_expcompack) t_st[rd_i] <= T_DACK;
            else begin t_st[rd_i] <= T_FREE; nfree = nfree + 3'd1; end
          end else begin
            push(5'h5, req_txnid, rd_i, 3'b000, (req_addr[43:12] != 0) ? 2'b11 : 2'b00, 4'h0);
            t_st[rd_i] <= T_WD;
          end
        end
      end

      // ---- every tracker freed while requests wait for a retry: PCrdGrant, reserving it
      for (i = 0; i < TRK; i++)
        if (nfree != 0 && pg != 0) begin
          push(5'h7, 12'h0, 12'h0, 3'b000, 2'b00, 4'h1);
          pg = pg - 3'd1; rv = rv + 3'd1; nfree = nfree - 3'd1;
        end
      pend_grant <= pg; resv <= rv; q_n <= n;
    end
  end
endmodule
`endif
