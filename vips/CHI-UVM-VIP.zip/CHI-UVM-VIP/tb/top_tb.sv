// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CHI testbench top with a functional CHI DUT model

`ifndef CHI_TB_SV
`define CHI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import chi_defs_pkg::*;
import chi_pkg::*;
import chi_env_pkg::*;
import chi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  chi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  chi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .req_valid(vif.req_valid),
    .req_addr(vif.req_addr),
    .req_opcode(vif.req_opcode),
    .dat_valid(vif.dat_valid),
    .dat_data(vif.dat_data),
    .rsp_ready(vif.rsp_ready),
    .req_ready(vif.req_ready),
    .dat_ready(vif.dat_ready),
    .rsp_valid(vif.rsp_valid),
    .rsp_resp(vif.rsp_resp)
  );

  // Concurrent protocol checks
  chi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .req_valid(vif.req_valid), .req_addr(vif.req_addr), .req_opcode(vif.req_opcode), .dat_valid(vif.dat_valid), .dat_data(vif.dat_data), .rsp_ready(vif.rsp_ready), .req_ready(vif.req_ready), .dat_ready(vif.dat_ready), .rsp_valid(vif.rsp_valid), .rsp_resp(vif.rsp_resp)
  );

  initial begin
    uvm_config_db#(virtual chi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module chi_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        req_valid,
  input  logic [31:0] req_addr,
  input  logic [4:0]  req_opcode,
  input  logic        dat_valid,
  input  logic [63:0] dat_data,
  input  logic        rsp_ready,
  output logic        req_ready,
  output logic        dat_ready,
  output logic        rsp_valid,
  output logic [4:0]  rsp_resp
);
  typedef enum bit [1:0] {IDLE, RSP} state_e;
  state_e st;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st        <= IDLE;
      req_ready <= 1'b0;
      dat_ready <= 1'b0;
      rsp_valid <= 1'b0;
      rsp_resp  <= 5'b0;
    end else begin
      req_ready <= 1'b0;
      dat_ready <= 1'b0;
      case (st)
        IDLE: begin
          if (req_valid) begin
            req_ready <= 1'b1;
            if (dat_valid) dat_ready <= 1'b1;
            st        <= RSP;
            rsp_resp  <= 5'b00001; // OK
          end
        end
        RSP: begin
          rsp_valid <= 1'b1;
          if (rsp_ready) begin
            rsp_valid <= 1'b0;
            st        <= IDLE;
          end
        end
        default: st <= IDLE;
      endcase
    end
  end
endmodule
`endif
