// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// FUNC_SIM: iverilog
//
// func_chi_hn_tb.sv -- two caching request nodes for chi_hn_model, each with
// its own cache (I / SC / UC / UD and data) and snoop responder, and the
// expected home behaviour written out independently of the model:
//   * every request type with and without a copy in the other node, the
//     snoop it needs (none, SnpShared, SnpOnce, SnpUnique), the granted
//     state and the data (always the latest value written by either node)
//   * dirty data from SnpShared reaches memory, from SnpOnce it does not
//   * CompAck: required by ReadShared / ReadUnique / CleanUnique /
//     MakeUnique, the home blocks until it arrives
//   * error bits: write-back without ownership, CleanUnique without a
//     copy, illegal / misrouted snoop responses, stray CompAck, bad opcode,
//     line out of range
//   * 2500 random transactions on 6 shared lines with random snoop and
//     CompAck delays and back-pressure; single-writer / multiple-reader and
//     data checked after every transaction
// Run: python3 tools/run_func_tests.py CHI-UVM-VIP
`timescale 1ns/1ps
module func_chi_hn_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int I = 0, SC = 1, UC = 2, UD = 3;
  localparam int RS = 0, RU = 1, RO = 2, CU = 3, MU = 4, WB = 5, EV = 6;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic req_valid = 0, req_rn = 0, rsp_ready = 1, ack_valid = 0, ack_rn = 0;
  logic [2:0] req_op = 0;
  logic [7:0] req_addr = 0;
  logic [63:0] req_data = 0;
  logic snp_rsp_valid = 0, snp_rsp_rn = 0, snp_rsp_dirty = 0;
  logic [1:0] snp_rsp_state = 0;
  logic [63:0] snp_rsp_data = 0;
  wire req_ready, snp_valid, snp_rn, rsp_valid, rsp_rn, rsp_op;
  wire [1:0] snp_op, rsp_state;
  wire [7:0] snp_addr;
  wire [63:0] rsp_data;
  wire [5:0] err;
  always #5 clk = ~clk;

  chi_hn_model u_dut (.clk, .rst_n, .req_valid, .req_ready, .req_rn, .req_op, .req_addr, .req_data,
    .snp_valid, .snp_rn, .snp_op, .snp_addr, .snp_rsp_valid, .snp_rsp_rn, .snp_rsp_state, .snp_rsp_dirty,
    .snp_rsp_data, .rsp_valid, .rsp_ready, .rsp_rn, .rsp_op, .rsp_state, .rsp_data, .ack_valid, .ack_rn, .err);

  task automatic wait_clk(input int n); repeat (n) @(negedge clk); #1; endtask

  // ------------------------------------------------------------ caches
  int          cst [2][64];
  logic [63:0] cdat [2][64];
  logic [63:0] gold [64];          // latest value written to each line
  int snp_delay_max = 2;
  bit snp_auto = 1;                // the responder answers snoops
  bit shared_keep = 1;             // SnpShared: keep SC (else go to I)
  int n_snp = 0, last_snp_op = -1, last_snp_rn = -1;
  // snoop seen at a posedge, answered after a delay
  always @(posedge clk) if (snp_valid && snp_auto) begin
    int r, l, o;
    r = snp_rn; l = snp_addr; o = snp_op;
    n_snp++; last_snp_op = o; last_snp_rn = r;
    fork begin
      int dly;
      dly = $urandom_range(0, snp_delay_max);
      repeat (dly) @(negedge clk);
      @(negedge clk);
      snp_rsp_valid = 1; snp_rsp_rn = r; snp_rsp_dirty = cst[r][l] == UD; snp_rsp_data = cdat[r][l];
      case (o)
        0: cst[r][l] = I;
        1: cst[r][l] = (cst[r][l] == I) ? I : shared_keep ? SC : I;
        default: ;
      endcase
      snp_rsp_state = cst[r][l];
      @(negedge clk); snp_rsp_valid = 0; snp_rsp_dirty = 0;
    end join_none
  end

  // ------------------------------------------------------------ transactions
  int blocked_bad = 0;
  task automatic chk_blocked(); if (req_ready) blocked_bad++; endtask
  int bad = 0;
  int exp_snp, e_state, e_op;
  task automatic txn(input int r, input int op, input int l, input logic [63:0] wdat = 0, input int ackd = 0,
                     input bit rdy_random = 0);
    int o, s0;
    o = 1 - r;
    n_snp = 0;
    // expectation
    exp_snp = -1;
    if (op == RS && cst[o][l] >= UC) exp_snp = 1;
    if (op == RO && cst[o][l] >= UC) exp_snp = 2;
    if ((op == RU || op == CU || op == MU) && cst[o][l] != I) exp_snp = 0;
    @(negedge clk);
    req_valid = 1; req_rn = r; req_op = op; req_addr = l; req_data = wdat;
    @(posedge clk); while (!req_ready) @(posedge clk);
    @(negedge clk); req_valid = 0;
    // response
    while (!rsp_valid) @(negedge clk);
    if (rdy_random) while ($urandom_range(0, 2) != 0) begin rsp_ready = 0; @(negedge clk); end
    rsp_ready = 1;
    if (exp_snp < 0 ? n_snp != 0 : (n_snp != 1 || last_snp_op != exp_snp || last_snp_rn != o)) begin
      bad++; $display("  snoop: rn %0d op %0d line %0d: %0d snoops, op %0d, exp %0d", r, op, l, n_snp, last_snp_op, exp_snp);
    end
    case (op)
      RS: begin e_op = 0; e_state = (cst[o][l] != I) ? SC : UC; end
      RU: begin e_op = 0; e_state = UC; end
      RO: begin e_op = 0; e_state = I; end
      CU: begin e_op = 1; e_state = UC; end
      MU: begin e_op = 1; e_state = UD; end
      default: begin e_op = 1; e_state = I; end
    endcase
    if (rsp_rn != r || rsp_op != e_op || rsp_state != e_state || (e_op == 0 && rsp_data !== gold[l])) begin
      bad++; $display("  rsp: rn %0d op %0d line %0d: rsp op %0d state %0d data %h, exp %0d %0d %h", r, op, l,
                      rsp_op, rsp_state, rsp_data, e_op, e_state, gold[l]);
    end
    // apply to the cache
    case (op)
      RS, RU: begin cst[r][l] = e_state; cdat[r][l] = rsp_data; end
      RO: ;
      CU: cst[r][l] = UC;
      MU: cst[r][l] = UD;
      default: cst[r][l] = I;
    endcase
    @(negedge clk);
    if (op <= MU && op != RO) begin
      if (ackd > 0) begin
        repeat (ackd) begin
          chk_blocked();
          @(negedge clk);
        end
      end
      ack_valid = 1; ack_rn = r;
      @(negedge clk); ack_valid = 0;
    end
    #1;
  endtask
  // a local store: the line must be UC or UD
  task automatic store(input int r, input int l, input logic [63:0] v);
    if (cst[r][l] < UC) begin bad++; $display("  tb: store without ownership"); end
    cst[r][l] = UD; cdat[r][l] = v; gold[l] = v;
  endtask
  function automatic bit swmr();
    for (int l = 0; l < 64; l++)
      if ((cst[0][l] >= UC && cst[1][l] != I) || (cst[1][l] >= UC && cst[0][l] != I)) return 0;
    return 1;
  endfunction

  task automatic raw_req(input int r, input int op, input int l);
    @(negedge clk); req_valid = 1; req_rn = r; req_op = op; req_addr = l;
    @(posedge clk); while (!req_ready) @(posedge clk);
    @(negedge clk); req_valid = 0; #1;
  endtask
  task automatic snp_answer(input int r, input int st);
    @(negedge clk); snp_rsp_valid = 1; snp_rsp_rn = r; snp_rsp_state = st; snp_rsp_dirty = 0;
    @(negedge clk); snp_rsp_valid = 0; #1;
  endtask
  task automatic ack(input int r);
    @(negedge clk); ack_valid = 1; ack_rn = r;
    @(negedge clk); ack_valid = 0; #1;
  endtask
  task automatic clean_reset();
    rst_n = 0; wait_clk(2); rst_n = 1; wait_clk(2);
    for (int l = 0; l < 64; l++) begin cst[0][l] = I; cst[1][l] = I; gold[l] = 0; end
  endtask

  int n0;
  initial begin
    for (int l = 0; l < 64; l++) begin cst[0][l] = I; cst[1][l] = I; gold[l] = 0; cdat[0][l] = 0; cdat[1][l] = 0; end
    wait_clk(3); rst_n = 1; wait_clk(2);

    // ---- unshared read, write, write-back
    txn(0, RS, 1);
    chk(cst[0][1] == UC && bad == 0, "ReadShared with no other copy: CompData UC, no snoop");
    store(0, 1, 64'h1111);
    txn(0, WB, 1, cdat[0][1]);
    chk(cst[0][1] == I && bad == 0, "WriteBackFull: Comp I");
    txn(1, RS, 1);
    chk(cdat[1][1] == 64'h1111 && cst[1][1] == UC && bad == 0, "written-back data read from memory");
    // ---- shared read of a clean unique line
    txn(0, RS, 1);
    chk(cst[0][1] == SC && cst[1][1] == SC && bad == 0, "ReadShared of a UC line: SnpShared, both SC");
    txn(1, RS, 2); txn(0, RS, 2);
    chk(bad == 0, "second sharer of a line held SC: no snoop");
    // ---- upgrade with CleanUnique
    txn(1, CU, 1);
    chk(cst[1][1] == UC && cst[0][1] == I && bad == 0, "CleanUnique from SC: SnpUnique to the sharer, Comp UC");
    store(1, 1, 64'h2222);
    // ---- ReadUnique of a dirty line
    txn(0, RU, 1);
    chk(cst[0][1] == UC && cst[1][1] == I && cdat[0][1] == 64'h2222 && bad == 0, "ReadUnique of a UD line: dirty data passed, UC");
    // ---- SnpShared dirty data reaches memory
    store(0, 1, 64'h3333);
    txn(1, RS, 1);
    chk(cdat[1][1] == 64'h3333 && bad == 0, "ReadShared of a UD line: data from the snoop");
    txn(0, EV, 1); txn(1, EV, 1);
    txn(1, RS, 1);
    chk(cdat[1][1] == 64'h3333 && cst[1][1] == UC && bad == 0, "SnpShared dirty data was written to memory");
    // ---- SnpOnce dirty data does not reach memory
    store(1, 1, 64'h4444);
    txn(0, RO, 1);
    chk(cst[0][1] == I && cst[1][1] == UD && bad == 0, "ReadOnce of a UD line: SnpOnce, data 4444, owner keeps UD");
    cst[1][1] = I; gold[1] = 64'h3333;               // owner drops its dirty line without writing back
    txn(1, EV, 1);
    txn(0, RS, 1);
    chk(cdat[0][1] == 64'h3333 && bad == 0, "SnpOnce data was not written to memory");
    // ---- ReadOnce without snoop, of a shared line
    txn(1, RS, 1);
    txn(1, CU, 1);                                   // 0 is SC: SnpUnique
    txn(0, RO, 1);
    chk(cst[0][1] == I && bad == 0, "ReadOnce of a UC (clean) line: SnpOnce, memory data");
    // ---- MakeUnique
    txn(0, RS, 3); txn(1, RS, 3);
    txn(0, MU, 3);
    chk(cst[0][3] == UD && cst[1][3] == I && bad == 0, "MakeUnique: SnpUnique, Comp UD");
    store(0, 3, 64'h5555);
    txn(1, RU, 3);
    chk(cdat[1][3] == 64'h5555 && bad == 0, "line written after MakeUnique read back by the other node");
    // ---- CompAck blocks the home
    blocked_bad = 0;
    txn(0, RS, 4, 0, 5);
    chk(blocked_bad == 0, "no new request accepted before CompAck");
    txn(0, RO, 5, 0, 0);
    wait_clk(1);
    chk(bad == 0 && req_ready, "ReadOnce needs no CompAck");
    // ---- snoop SnpShared with the owner going to I
    txn(1, RU, 6);
    shared_keep = 0;
    txn(0, RS, 6);
    shared_keep = 1;
    chk(cst[1][6] == I && cst[0][6] == UC && bad == 0, "SnpShared answered with I: requester gets UC");
    chk(err == 0, "no error in legal flows");

    // ---- errors
    txn(1, WB, 7, 64'hBAD);
    chk(err[0] && bad == 0, "WriteBackFull without ownership: err 0, Comp I");
    txn(1, RS, 7);
    chk(cdat[1][7] == 0, "memory not written by it");
    txn(1, EV, 7);
    txn(0, CU, 7);
    chk(err[1] && cst[0][7] == UC, "CleanUnique without a copy: err 1, still Comp UC");
    txn(0, EV, 7);
    // stray CompAck
    @(negedge clk); ack_valid = 1; ack_rn = 0;
    @(negedge clk); ack_valid = 0; #1;
    chk(err[3], "CompAck with nothing outstanding: err 3");
    // misrouted and illegal snoop responses
    txn(1, RU, 8);
    snp_auto = 0;
    @(negedge clk); req_valid = 1; req_rn = 0; req_op = RU; req_addr = 8;
    @(posedge clk); while (!req_ready) @(posedge clk);
    @(negedge clk); req_valid = 0;
    wait_clk(2);
    chk(!err[2], "no snoop response yet");
    @(negedge clk); snp_rsp_valid = 1; snp_rsp_rn = 0; snp_rsp_state = 0;
    @(negedge clk); snp_rsp_valid = 0; #1;
    chk(err[2] && !rsp_valid, "snoop response from the requester: ignored (err 2)");
    @(negedge clk); snp_rsp_valid = 1; snp_rsp_rn = 1; snp_rsp_state = SC; snp_rsp_dirty = 0;
    @(negedge clk); snp_rsp_valid = 0; #1;
    while (!rsp_valid) @(negedge clk);
    chk(rsp_state == UC, "SnpUnique answered SC: completes");
    @(negedge clk); ack_valid = 1; ack_rn = 0;
    @(negedge clk); ack_valid = 0; #1;
    cst[0][8] = UC; cst[1][8] = SC;
    snp_auto = 1;
    txn(0, RU, 8);
    chk(n_snp == 1 && last_snp_op == 0, "filter follows the (illegal) SC answer: the node is snooped again");
    cst[1][8] = I;
    // bad opcode and line
    n_snp = 0;
    @(negedge clk); req_valid = 1; req_rn = 0; req_op = 7; req_addr = 2;
    @(posedge clk); while (!req_ready) @(posedge clk);
    @(negedge clk); req_valid = 0;
    while (!rsp_valid) @(negedge clk);
    chk(err[4] && rsp_op == 1 && rsp_state == I, "opcode 7: err 4, Comp I");
    wait_clk(2);
    @(negedge clk); req_valid = 1; req_rn = 1; req_op = RU; req_addr = 64;
    @(posedge clk); while (!req_ready) @(posedge clk);
    @(negedge clk); req_valid = 0;
    while (!rsp_valid) @(negedge clk);
    chk(err[5] && rsp_op == 0 && rsp_state == I && rsp_data == 0 && n_snp == 0, "line 64: err 5, CompData I of zero, no snoop");
    wait_clk(2);
    raw_req(0, RO, 65);
    while (!rsp_valid) @(negedge clk);
    chk(rsp_op == 0 && rsp_state == I, "ReadOnce to line 65: CompData I");
    wait_clk(2);
    raw_req(0, WB, 66);
    while (!rsp_valid) @(negedge clk);
    chk(rsp_op == 1, "WriteBackFull to line 66: Comp");
    wait_clk(2);
    chk(req_ready, "bad requests need no CompAck");
    chk(bad == 0, "directed: every snoop, state and data as expected");

    // ---- random
    begin
      int sent;
      sent = 0;
      bad = 0;
      for (int i = 0; i < 2500; i++) begin
        int r, l, s, op;
        r = $urandom_range(0, 1); l = 10 + $urandom_range(0, 5);
        s = cst[r][l];
        snp_delay_max = $urandom_range(0, 3);
        shared_keep = $urandom_range(0, 3) != 0;
        case (s)
          I:  op = $urandom_range(0, 3) == 0 ? RO : $urandom_range(0, 2) == 0 ? MU : $urandom_range(0, 1) ? RS : RU;
          SC: op = $urandom_range(0, 2) == 0 ? EV : $urandom_range(0, 1) ? CU : RU;
          UC: op = $urandom_range(0, 1) ? -1 : EV;
          default: op = $urandom_range(0, 1) ? -1 : WB;
        endcase
        if (op < 0) store(r, l, {$urandom, $urandom});
        else begin
          txn(r, op, l, cdat[r][l], $urandom_range(0, 2), 1);
          if (op == MU) store(r, l, {$urandom, $urandom});
          sent++;
        end
        if (!swmr()) begin bad++; $display("  single-writer rule broken on line %0d", l); end
      end
      chk(bad == 0, $sformatf("%0d random transactions: snoops, states, data and single-writer rule as expected", sent));
    end
    chk(err == 6'b111111, "error bits only from the error tests");

    // ---- illegal snoop answers (from a clean error state)
    clean_reset();
    chk(err == 0 && !rsp_valid, "reset clears errors");
    txn(1, RU, 8);
    snp_auto = 0;
    raw_req(0, RU, 8);
    snp_answer(1, SC);
    while (!rsp_valid) @(negedge clk);
    chk(err == 6'b000100 && rsp_state == UC, "SnpUnique answered SC: err 2 only, completes");
    ack(0);
    clean_reset();
    txn(1, RU, 9);
    raw_req(0, RS, 9);
    snp_answer(1, UC);
    while (!rsp_valid) @(negedge clk);
    chk(err == 6'b000100 && rsp_state == SC, "SnpShared answered UC: err 2 only; the node still holds the line, CompData SC");
    ack(0);
    snp_auto = 1;

    // ---- reset: memory zero, filter empty
    clean_reset();
    bad = 0;
    txn(0, RS, 0);
    chk(bad == 0 && rsp_data == 0 && cst[0][0] == UC, "after reset line 0 reads zero and the filter is empty");
    txn(1, RS, 63);
    chk(bad == 0 && rsp_data == 0, "line 63 reads zero");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #20ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
