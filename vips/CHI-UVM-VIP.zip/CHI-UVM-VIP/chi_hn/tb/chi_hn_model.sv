// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// chi_hn_model.sv -- CHI fully-coherent Home Node (HN-F) for two request
// nodes: a snoop filter per line, snoops to the other node, completions
// with the granted cache state, and CompAck. One transaction at a time
// (the home is the point of serialization). The transaction flows follow
// the CHI specification; the port layout, the 64-bit line, the opcode and
// state numbering and the error bits are this model's own.
//
// Request (req_valid / req_ready, req_rn 0 or 1, req_addr = line 0..63):
//   0 ReadShared  1 ReadUnique  2 ReadOnce  3 CleanUnique  4 MakeUnique
//   5 WriteBackFull (req_data = the dirty line)  6 Evict; others: err[4]
//   and Comp with state I. A line >= 64: err[5], no snoop, no change,
//   CompData of zero / Comp with state I.
// Snoop filter: per line and node I / S / U (U covers UC and UD).
// Snoop (snp_valid one clock to the other node, when it holds the line):
//   ReadShared, ReadOnce  when the other node is U: SnpShared (1) for
//                         ReadShared, SnpOnce (2) for ReadOnce
//   ReadUnique, CleanUnique, MakeUnique  when the other node is S or U:
//                         SnpUnique (0)
// Snoop response (snp_rsp_valid, snp_rsp_rn, snp_rsp_state I 0 / SC 1 /
//   UC 2 / UD 3, snp_rsp_dirty with snp_rsp_data): a response from the
//   wrong node is ignored (err[2]). The snooped node's filter entry follows
//   snp_rsp_state; a state the snoop does not allow (SnpUnique: not I,
//   SnpShared: UC or UD) sets err[2]. Dirty data from SnpShared / SnpUnique
//   is written to memory; from SnpOnce it is returned but not written.
// Response (rsp_valid until rsp_ready, rsp_rn = requester, rsp_op 0
//   CompData / 1 Comp, rsp_state as above):
//   ReadShared  CompData SC when the other node still holds the line, else UC
//   ReadUnique  CompData UC          ReadOnce  CompData I (data from the
//   CleanUnique Comp UC               snoop when dirty, else memory)
//   MakeUnique  Comp UD               WriteBackFull, Evict  Comp I
//   CleanUnique from a node that is not S or U sets err[1] (completes).
//   WriteBackFull writes memory only from a node that is U, else err[0].
//   ReadShared / ReadUnique / CleanUnique / MakeUnique then wait for CompAck
//   (ack_valid, ack_rn = requester); a CompAck at any other time or from
//   the other node is ignored (err[3]).
module chi_hn_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        req_valid,
  output logic        req_ready,
  input  logic        req_rn,
  input  logic [2:0]  req_op,
  input  logic [7:0]  req_addr,
  input  logic [63:0] req_data,
  output logic        snp_valid,
  output logic        snp_rn,
  output logic [1:0]  snp_op,
  output logic [7:0]  snp_addr,
  input  logic        snp_rsp_valid,
  input  logic        snp_rsp_rn,
  input  logic [1:0]  snp_rsp_state,
  input  logic        snp_rsp_dirty,
  input  logic [63:0] snp_rsp_data,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output logic        rsp_rn,
  output logic        rsp_op,
  output logic [1:0]  rsp_state,
  output logic [63:0] rsp_data,
  input  logic        ack_valid,
  input  logic        ack_rn,
  output logic [5:0]  err
);
  typedef enum logic [2:0] {IDLE, SNP, WSNP, RSP, WACK} st_t;
  st_t         st;
  logic [63:0] mem [0:63];
  logic [1:0]  sf [0:63][0:1];        // 0 I, 1 S, 2 U
  logic        rn;
  logic [2:0]  op;
  logic [5:0]  ln;
  logic        bad;
  logic [63:0] d, wd;
  logic [1:0]  so;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 64; i++) begin mem[i] = '0; sf[i][0] = 2'd0; sf[i][1] = 2'd0; end
      st <= IDLE; rn = 1'b0; op = '0; ln = '0; bad = 1'b0; d = '0; wd = '0; so = '0;
      req_ready <= 1'b0; snp_valid <= 1'b0; snp_rn <= 1'b0; snp_op <= '0; snp_addr <= '0;
      rsp_valid <= 1'b0; rsp_rn <= 1'b0; rsp_op <= 1'b0; rsp_state <= '0; rsp_data <= '0; err <= '0;
    end else begin : step
      logic [5:0] e;
      logic       o;
      e = '0; o = ~rn;
      snp_valid <= 1'b0;
      if (ack_valid && !(st == WACK && ack_rn == rn)) e[3] = 1'b1;
      if (snp_rsp_valid && !(st == WSNP && snp_rsp_rn == o)) e[2] = 1'b1;

      case (st)
        IDLE: if (req_valid && req_ready) begin
          rn = req_rn; op = req_op; ln = req_addr[5:0]; o = ~req_rn; wd = req_data;
          bad = (req_addr >= 8'd64) || (req_op > 3'd6);
          if (req_addr >= 8'd64) e[5] = 1'b1;
          if (req_op > 3'd6) e[4] = 1'b1;
          d = bad ? 64'h0 : mem[ln];
          if (!bad && ((op == 3'd0 && sf[ln][o] == 2'd2) || (op == 3'd2 && sf[ln][o] == 2'd2) ||
                       ((op == 3'd1 || op == 3'd3 || op == 3'd4) && sf[ln][o] != 2'd0))) begin
            so = (op == 3'd0) ? 2'd1 : (op == 3'd2) ? 2'd2 : 2'd0;
            snp_valid <= 1'b1; snp_rn <= o; snp_op <= so; snp_addr <= {2'b00, ln};
            st <= WSNP;
          end else st <= RSP;
          req_ready <= 1'b0;
        end else req_ready <= 1'b1;
        WSNP: if (snp_rsp_valid && snp_rsp_rn == o) begin
          if ((so == 2'd0 && snp_rsp_state != 2'd0) || (so == 2'd1 && snp_rsp_state >= 2'd2)) e[2] = 1'b1;
          if (snp_rsp_dirty) begin
            d = snp_rsp_data;
            if (so != 2'd2) mem[ln] = snp_rsp_data;
          end
          sf[ln][o] = (snp_rsp_state == 2'd0) ? 2'd0 : (snp_rsp_state == 2'd1) ? 2'd1 : 2'd2;
          st <= RSP;
        end
        RSP: if (!rsp_valid) begin
          rsp_valid <= 1'b1; rsp_rn <= rn; rsp_data <= '0; rsp_op <= 1'b1; rsp_state <= 2'd0;
          if (!bad)
            case (op)
              3'd0: begin
                rsp_op <= 1'b0; rsp_data <= d;
                rsp_state <= (sf[ln][o] != 2'd0) ? 2'd1 : 2'd2;
                sf[ln][rn] = (sf[ln][o] != 2'd0) ? 2'd1 : 2'd2;
              end
              3'd1: begin rsp_op <= 1'b0; rsp_data <= d; rsp_state <= 2'd2; sf[ln][rn] = 2'd2; end
              3'd2: begin rsp_op <= 1'b0; rsp_data <= d; end
              3'd3: begin
                if (sf[ln][rn] == 2'd0) e[1] = 1'b1;
                rsp_state <= 2'd2; sf[ln][rn] = 2'd2;
              end
              3'd4: begin rsp_state <= 2'd3; sf[ln][rn] = 2'd2; end
              3'd5: begin
                if (sf[ln][rn] == 2'd2) mem[ln] = wd;
                else e[0] = 1'b1;
                sf[ln][rn] = 2'd0;
              end
              default: sf[ln][rn] = 2'd0;
            endcase
          else if (op <= 3'd2) rsp_op <= 1'b0;
        end else if (rsp_ready) begin
          rsp_valid <= 1'b0;
          if (!bad && (op == 3'd0 || op == 3'd1 || op == 3'd3 || op == 3'd4)) st <= WACK;
          else st <= IDLE;
        end
        WACK: if (ack_valid && ack_rn == rn) st <= IDLE;
        default: st <= IDLE;
      endcase
      err <= err | e;
    end
  end

endmodule
