// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// chi_env.sv -- CHI environment: reference-model scoreboard, checker, coverage

package chi_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import chi_defs_pkg::*;
  import chi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class chi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(chi_scoreboard)
    uvm_analysis_imp_exp #(chi_transaction, chi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(chi_transaction, chi_scoreboard) obs_ap;

    chi_config cfg;
    chi_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [511:0] mir [int];   // memory mirror, by line
    // a retried or rejected (protocol error) request carries no data: compare the request flit only
    function bit agree(chi_transaction e, chi_transaction o);
      if (!o.retried && o.perr == 0) return e.req_equal(o);
      return e.opcode == o.opcode && e.txnid == o.txnid && e.addr == o.addr && e.size == o.size &&
             e.allowretry == o.allowretry && e.pcrdtype == o.pcrdtype && e.expcompack == o.expcompack;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(chi_config)::get(this, "", "cfg", cfg))
        cfg = chi_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(chi_transaction t);
      bit oor;
      bit [5:0] l = t.addr[11:6];
      bit [511:0] m;
      t.perr = 0; t.resp = 0; t.resperr = CHI_RE_OK; t.rdata = 0;
      if (!chi_known(t.opcode)) t.perr = 7;
      else if (t.size != 3'd6 || t.addr[5:0] != 0) t.perr = 3;
      else if (chi_needs_ack(t.opcode) && !t.expcompack) t.perr = 4;
      else if (!t.allowretry && t.pcrdtype != 4'd1) t.perr = 5;
      if (t.perr != 0) begin t.resperr = CHI_RE_NDERR; t.retried = 0; end
      else if (!(t.retried && t.allowretry)) begin
        t.retried = 0;
        oor = (t.addr[43:12] != 0);
        m = mir.exists(l) ? mir[l] : chi_mem_init(l);
        if (chi_is_read(t.opcode)) begin
          t.resp = (t.opcode == CHI_READ_UNIQUE) ? CHI_UC : (t.opcode inside {CHI_READ_SHARED, CHI_READ_CLEAN}) ? CHI_SC : CHI_I;
          t.resperr = oor ? CHI_RE_DERR : CHI_RE_OK;
          t.rdata = oor ? 512'h0 : m;
        end else if (chi_is_dataless(t.opcode)) begin
          t.resp = (t.opcode inside {CHI_CLEAN_UNIQUE, CHI_MAKE_UNIQUE}) ? CHI_UC : CHI_I;
          t.resperr = oor ? CHI_RE_NDERR : CHI_RE_OK;
        end else begin
          t.resperr = oor ? CHI_RE_NDERR : CHI_RE_OK;
          if (!oor && !(chi_is_copyback(t.opcode) && t.cb_resp == CHI_I)) begin
            for (int k = 0; k < 64; k++) if (t.be[k]) m[8*k +: 8] = t.wdata[8*k +: 8];
            mir[l] = m;
          end
        end
      end
    endfunction

    function void write_exp(chi_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(chi_transaction t);
      chi_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        chi_transaction e = exp_q.pop_front();
        chi_transaction o = obs_q.pop_front();
        n_checks++;
        if (agree(e, o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("chi scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class chi_env extends uvm_env;
    `uvm_component_utils(chi_env)
    chi_agent      agt;
    chi_scoreboard sb;
    chi_checker    chk;
    chi_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = chi_agent     ::type_id::create("agt", this);
      sb  = chi_scoreboard::type_id::create("sb",  this);
      chk = chi_checker   ::type_id::create("chk", this);
      cov = chi_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
