# CHI UVM VIP (CHI-UVM-VIP)

AMBA CHI request/response/data channel UVM VIP with a minimal RN-F acceptance model (REQ-ACCEPT / RSP-ACK handshake). Complements the CHI RTL IP from the open-ip-portfolio sister project.

## Structure

- `chi/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `chi_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `chi_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural CHI DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/CHI-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh CHI-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
