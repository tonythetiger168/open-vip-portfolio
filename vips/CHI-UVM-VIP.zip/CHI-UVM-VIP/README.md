# CHI UVM VIP (CHI-UVM-VIP)

AMBA CHI request/response/data channel UVM VIP with a minimal RN-F acceptance model (REQ-ACCEPT / RSP-ACK handshake). Complements the CHI RTL IP from the open-ip-portfolio sister project.

## Structure

- `chi/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `chi_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `chi_base_test` (constrained-random), `chi_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural CHI DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Coherent Home Node reference (`chi_hn/`, v1.11.0)

The agent above talks to a request-node model without coherence.
`chi_hn/` adds a fully-coherent Home Node (HN-F) for two caching request
nodes, tested by two request nodes with real caches:

| File | Content |
|---|---|
| `chi_hn/tb/chi_hn_model.sv` | snoop filter per line and node; ReadShared, ReadUnique, ReadOnce, CleanUnique, MakeUnique, WriteBackFull, Evict; SnpShared / SnpOnce / SnpUnique to the other node only when its copy requires it; granted states SC / UC / UD; dirty snoop data written to memory (SnpShared, SnpUnique) or only forwarded (SnpOnce); CompAck blocking the home; error bits for write-back without ownership, CleanUnique without a copy, misrouted or illegal snoop responses, stray CompAck, bad opcode and line |
| `chi_hn/tb/func_chi_hn_tb.sv` | two caches (I / SC / UC / UD with data) and snoop responders; every flow with its expected snoop, state and data, every error bit and 2500 random transactions on shared lines with random delays, the single-writer rule and data checked after each one: 39 checks (`python3 tools/run_func_tests.py CHI-UVM-VIP`, Icarus) |

The flows follow the CHI specification; the port layout, the 64-bit line,
opcode and state numbering and the error bits are this model's own. Issue
H additions (and CHI C2C) are not modelled.

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/CHI-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh CHI-UVM-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py CHI-UVM-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
