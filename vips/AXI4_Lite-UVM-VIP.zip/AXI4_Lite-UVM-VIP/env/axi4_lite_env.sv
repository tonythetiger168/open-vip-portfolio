// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_env.sv -- AXI4-Lite environment: reference-model scoreboard, checker, coverage

package axi4_lite_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import axi4_lite_defs_pkg::*;
  import axi4_lite_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class axi4_lite_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(axi4_lite_scoreboard)
    uvm_analysis_imp_exp #(axi4_lite_transaction, axi4_lite_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(axi4_lite_transaction, axi4_lite_scoreboard) obs_ap;

    axi4_lite_config cfg;
    axi4_lite_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [31:0] mem [256];   // reset value 0

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(axi4_lite_config)::get(this, "", "cfg", cfg))
        cfg = axi4_lite_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(axi4_lite_transaction t);
      t.rdata = 32'h0;
      if (t.addr >= 32'h800)      t.resp = AXIL_DECERR;
      else if (t.addr >= 32'h400) t.resp = AXIL_SLVERR;
      else if (t.we && t.addr >= 32'h3C0 && !t.prot[0]) t.resp = AXIL_SLVERR;
      else begin
        t.resp = AXIL_OKAY;
        if (t.we) begin
          for (int b = 0; b < 4; b++)
            if (t.wstrb[b]) mem[t.addr[9:2]][b*8 +: 8] = t.wdata[b*8 +: 8];
        end else
          t.rdata = mem[t.addr[9:2]];
      end
    endfunction

    function void write_exp(axi4_lite_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(axi4_lite_transaction t);
      axi4_lite_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        axi4_lite_transaction e = exp_q.pop_front();
        axi4_lite_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("axi4_lite scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class axi4_lite_env extends uvm_env;
    `uvm_component_utils(axi4_lite_env)
    axi4_lite_agent      agt;
    axi4_lite_scoreboard sb;
    axi4_lite_checker    chk;
    axi4_lite_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = axi4_lite_agent     ::type_id::create("agt", this);
      sb  = axi4_lite_scoreboard::type_id::create("sb",  this);
      chk = axi4_lite_checker   ::type_id::create("chk", this);
      cov = axi4_lite_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
