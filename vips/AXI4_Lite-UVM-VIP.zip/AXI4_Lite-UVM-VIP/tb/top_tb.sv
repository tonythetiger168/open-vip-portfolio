// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- AXI4-Lite testbench top with a functional AXI4-Lite DUT model

`ifndef AXI4_LITE_UVM_VIP_TB_SV
`define AXI4_LITE_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import axi4_lite_defs_pkg::*;
import axi4_lite_pkg::*;
import axi4_lite_env_pkg::*;
import axi4_lite_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  axi4_lite_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  axi4_lite_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .awvalid(vif.awvalid),
    .awready(vif.awready),
    .awaddr(vif.awaddr),
    .awprot(vif.awprot),
    .wvalid(vif.wvalid),
    .wready(vif.wready),
    .wdata(vif.wdata),
    .wstrb(vif.wstrb),
    .bvalid(vif.bvalid),
    .bready(vif.bready),
    .bresp(vif.bresp),
    .arvalid(vif.arvalid),
    .arready(vif.arready),
    .araddr(vif.araddr),
    .arprot(vif.arprot),
    .rvalid(vif.rvalid),
    .rready(vif.rready),
    .rdata(vif.rdata),
    .rresp(vif.rresp)
  );

  // Concurrent protocol checks
  axi4_lite_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .awvalid(vif.awvalid),
    .awready(vif.awready),
    .awaddr(vif.awaddr),
    .awprot(vif.awprot),
    .wvalid(vif.wvalid),
    .wready(vif.wready),
    .wdata(vif.wdata),
    .wstrb(vif.wstrb),
    .bvalid(vif.bvalid),
    .bready(vif.bready),
    .bresp(vif.bresp),
    .arvalid(vif.arvalid),
    .arready(vif.arready),
    .araddr(vif.araddr),
    .arprot(vif.arprot),
    .rvalid(vif.rvalid),
    .rready(vif.rready),
    .rdata(vif.rdata),
    .rresp(vif.rresp)
  );

  initial begin
    uvm_config_db#(virtual axi4_lite_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module axi4_lite_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        awvalid,
  output logic        awready,
  input  logic [31:0] awaddr,
  input  logic [2:0]  awprot,
  input  logic        wvalid,
  output logic        wready,
  input  logic [31:0] wdata,
  input  logic [3:0]  wstrb,
  output logic        bvalid,
  input  logic        bready,
  output logic [1:0]  bresp,
  input  logic        arvalid,
  output logic        arready,
  input  logic [31:0] araddr,
  input  logic [2:0]  arprot,
  output logic        rvalid,
  input  logic        rready,
  output logic [31:0] rdata,
  output logic [1:0]  rresp
);
  logic [31:0] mem [0:255];
  logic        aw_full, w_full;
  logic [31:0] aw_a, w_d;
  logic [2:0]  aw_p;
  logic [3:0]  w_s;
  logic [7:0]  lfsr;
  logic [1:0]  wr_resp, rd_resp;

  // READY from the LFSR; no new write while B is pending, no read while R is
  assign awready = !aw_full && !bvalid && lfsr[0];
  assign wready  = !w_full  && !bvalid && lfsr[2];
  assign arready = !rvalid && lfsr[4];

  assign wr_resp = (aw_a >= 32'h800) ? 2'b11 :
                   (aw_a >= 32'h400) ? 2'b10 :
                   (aw_a >= 32'h3C0 && !aw_p[0]) ? 2'b10 : 2'b00;
  assign rd_resp = (araddr >= 32'h800) ? 2'b11 : (araddr >= 32'h400) ? 2'b10 : 2'b00;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      aw_full <= 1'b0; w_full <= 1'b0; aw_a <= '0; aw_p <= '0; w_d <= '0; w_s <= '0;
      bvalid <= 1'b0; bresp <= 2'b00; rvalid <= 1'b0; rdata <= '0; rresp <= 2'b00;
      lfsr <= 8'h5B;
      for (int i = 0; i < 256; i++) mem[i] <= 32'h0;
    end else begin
      lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};
      if (awvalid && awready) begin aw_full <= 1'b1; aw_a <= awaddr; aw_p <= awprot; end
      if (wvalid && wready) begin w_full <= 1'b1; w_d <= wdata; w_s <= wstrb; end
      // the write is done once both AW and W are in
      if (aw_full && w_full && !bvalid) begin
        if (wr_resp == 2'b00)
          for (int b = 0; b < 4; b++)
            if (w_s[b]) mem[aw_a[9:2]][b*8 +: 8] <= w_d[b*8 +: 8];
        bvalid <= 1'b1; bresp <= wr_resp;
        aw_full <= 1'b0; w_full <= 1'b0;
      end
      if (bvalid && bready) bvalid <= 1'b0;
      if (arvalid && arready) begin
        rvalid <= 1'b1; rresp <= rd_resp;
        rdata <= (rd_resp == 2'b00) ? mem[araddr[9:2]] : 32'h0;
      end
      if (rvalid && rready) rvalid <= 1'b0;
    end
  end
endmodule
`endif
