// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (AXI4-Lite DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened axi4_lite_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic awvalid = 0, wvalid = 0, arvalid = 0, bready = 1, rready = 1;
  logic [31:0] awaddr = 0, wdata = 0, araddr = 0;
  logic [2:0] awprot = 0, arprot = 0;
  logic [3:0] wstrb = 0;
  wire awready, wready, arready, bvalid, rvalid;
  wire [1:0] bresp, rresp;
  wire [31:0] rdata;

  always #5 clk = ~clk;

  axi4_lite_model u_dut (.clk(clk), .rst_n(rst_n), .awvalid(awvalid), .awready(awready), .awaddr(awaddr),
                         .awprot(awprot), .wvalid(wvalid), .wready(wready), .wdata(wdata), .wstrb(wstrb),
                         .bvalid(bvalid), .bready(bready), .bresp(bresp), .arvalid(arvalid),
                         .arready(arready), .araddr(araddr), .arprot(arprot), .rvalid(rvalid),
                         .rready(rready), .rdata(rdata), .rresp(rresp));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // write: order 0 AW + W together, 1 AW first (W after skew clocks), 2 W first
  task automatic wr(input logic [31:0] a, input logic [31:0] d, input logic [3:0] s, input logic [2:0] p,
                    input int order, input int skew, output logic [1:0] r);
    int n;
    bit aw_done, w_done;
    aw_done = 0; w_done = 0;
    @(negedge clk);
    if (order != 2) begin awvalid = 1; awaddr = a; awprot = p; end
    if (order != 1) begin wvalid = 1; wdata = d; wstrb = s; end
    n = 0;
    while (!(aw_done && w_done) && n < 100) begin
      @(posedge clk);
      if (awvalid && awready) aw_done = 1;
      if (wvalid && wready) w_done = 1;
      @(negedge clk); n++;
      if (aw_done) awvalid = 0;
      if (w_done) wvalid = 0;
      if (!aw_done && !awvalid && n >= skew) begin awvalid = 1; awaddr = a; awprot = p; end
      if (!w_done && !wvalid && n >= skew) begin wvalid = 1; wdata = d; wstrb = s; end
    end
    chk(aw_done && w_done, "AW and W accepted");
    n = 0;
    while (!bvalid && n < 50) begin @(negedge clk); n++; end
    chk(bvalid === 1'b1, "B response returned");
    r = bresp;
    @(posedge clk); #1;
  endtask

  task automatic rd(input logic [31:0] a, input logic [2:0] p, output logic [31:0] q, output logic [1:0] r);
    int n;
    @(negedge clk);
    arvalid = 1; araddr = a; arprot = p;
    n = 0;
    while (!arready && n < 50) begin @(negedge clk); n++; end
    chk(arready === 1'b1, "AR accepted");
    @(negedge clk);
    arvalid = 0;
    n = 0;
    while (!rvalid && n < 50) begin @(negedge clk); n++; end
    chk(rvalid === 1'b1, "R response returned");
    q = rdata; r = rresp;
    @(posedge clk); #1;
  endtask

  initial begin
    logic [31:0] q; logic [1:0] r;
    repeat (3) @(posedge clk);
    chk(bvalid === 1'b0 && rvalid === 1'b0, "BVALID / RVALID low in reset");
    rst_n = 1;
    repeat (2) @(posedge clk);
    begin : idle
      int spur = 0;
      repeat (20) begin @(negedge clk); if (bvalid || rvalid) spur++; end
      chk(spur == 0, "no response while the bus is idle (READY high without VALID)");
    end

    rd(32'h0, 3'b000, q, r);
    chk(q === 32'h0 && r === 2'b00, "word 0 reads 0 after reset, OKAY");
    rd(32'h3FC, 3'b000, q, r);
    chk(q === 32'h0 && r === 2'b00, "0x3FC: last word, OKAY");
    rd(32'h400, 3'b000, q, r);
    chk(r === 2'b10 && q === 32'h0, "0x400: first SLVERR address, rdata 0");
    rd(32'h7FC, 3'b000, q, r);
    chk(r === 2'b10, "0x7FC: last SLVERR address");
    rd(32'h800, 3'b000, q, r);
    chk(r === 2'b11 && q === 32'h0, "0x800: DECERR, rdata 0");

    // AW + W in each order
    wr(32'h20, 32'hCAFE_F00D, 4'hF, 3'b000, 0, 0, r);
    chk(r === 2'b00, "write AW + W together: OKAY");
    rd(32'h20, 3'b000, q, r);
    chk(q === 32'hCAFE_F00D, "read back full word");
    wr(32'h24, 32'h1234_5678, 4'hF, 3'b000, 1, 3, r);
    rd(32'h24, 3'b000, q, r);
    chk(q === 32'h1234_5678 && r === 2'b00, "AW first, W 3 clocks later");
    wr(32'h28, 32'h8765_4321, 4'hF, 3'b000, 2, 3, r);
    rd(32'h28, 3'b000, q, r);
    chk(q === 32'h8765_4321 && r === 2'b00, "W first, AW 3 clocks later");
    wr(32'h20, 32'h0000_AB00, 4'h2, 3'b000, 0, 0, r);
    rd(32'h20, 3'b000, q, r);
    chk(q === 32'hCAFE_AB0D, "byte strobe merge on lane 1");
    wr(32'h20, 32'h7700_0000, 4'h8, 3'b000, 0, 0, r);
    wr(32'h20, 32'h0000_0011, 4'h1, 3'b000, 2, 1, r);
    rd(32'h20, 3'b000, q, r);
    chk(q === 32'h77FE_AB11, "byte strobe merge on lanes 3 and 0");
    wr(32'h2C, 32'hFFFF_FFFF, 4'h0, 3'b000, 0, 0, r);
    rd(32'h2C, 3'b000, q, r);
    chk(q === 32'h0 && r === 2'b00, "write with no strobe: OKAY, nothing written");

    // privileged region 0x3C0-0x3FF
    wr(32'h3C0, 32'h1111_1111, 4'hF, 3'b000, 0, 0, r);
    chk(r === 2'b10, "unprivileged write to 0x3C0: SLVERR");
    rd(32'h3C0, 3'b000, q, r);
    chk(q === 32'h0 && r === 2'b00, "unprivileged write did not land; reads are not restricted");
    wr(32'h3C0, 32'h2222_2222, 4'hF, 3'b001, 0, 0, r);
    chk(r === 2'b00, "privileged write to 0x3C0: OKAY");
    rd(32'h3C0, 3'b000, q, r);
    chk(q === 32'h2222_2222, "privileged write landed");
    wr(32'h3BC, 32'h3333_3333, 4'hF, 3'b110, 0, 0, r);
    rd(32'h3BC, 3'b000, q, r);
    chk(r === 2'b00 && q === 32'h3333_3333, "0x3BC is below the privileged region");
    wr(32'h3FC, 32'h4444_4444, 4'hF, 3'b110, 0, 0, r);
    chk(r === 2'b10, "0x3FC is in the privileged region (AWPROT[0] = 0, others set)");

    // error regions: no write lands anywhere
    wr(32'h400, 32'hDEAD_BEEF, 4'hF, 3'b001, 0, 0, r);
    chk(r === 2'b10, "write to 0x400: SLVERR");
    wr(32'h800, 32'hDEAD_BEEF, 4'hF, 3'b001, 1, 1, r);
    chk(r === 2'b11, "write to 0x800: DECERR");
    wr(32'h7FC, 32'hDEAD_BEEF, 4'hF, 3'b001, 0, 0, r);
    chk(r === 2'b10, "write to 0x7FC: SLVERR");
    rd(32'h0, 3'b000, q, r);
    chk(q === 32'h0, "error writes did not alias onto word 0");
    rd(32'h3FC, 3'b000, q, r);
    chk(q === 32'h0, "error writes did not alias onto word 0xFF");

    // B held under back-pressure, no new AW / W while it is pending
    begin : bp
      int acc = 0, accw = 0, held = 0;
      @(negedge clk); bready = 0;
      awvalid = 1; awaddr = 32'h30; awprot = 0; wvalid = 1; wdata = 32'h5A5A_5A5A; wstrb = 4'hF;
      repeat (24) begin
        @(posedge clk);
        if (awvalid && awready) acc++;
        if (wvalid && wready) accw++;
        if (bvalid && bresp === 2'b00) held++;
        @(negedge clk);
        if (acc > 0) awvalid = 0;
        if (accw > 0) wvalid = 0;
      end
      chk(acc == 1 && accw == 1, "one AW and one W accepted");
      chk(awready === 1'b0 && wready === 1'b0, "AWREADY / WREADY low while B is pending");
      chk(held >= 8 && bvalid === 1'b1, "B held while BREADY is low");
      bready = 1;
      @(negedge clk);
      @(negedge clk);
      chk(bvalid === 1'b0, "B dropped after BREADY");
    end

    // one AW (or W) held at a time: a second AW offered while the first waits
    // for its W is not accepted until the write is done (same for W first)
    begin : one_aw
      int naw = 0, nw = 0;
      @(negedge clk);
      awvalid = 1; awaddr = 32'h50; awprot = 0;
      repeat (12) begin
        @(posedge clk);
        if (awvalid && awready) naw++;
        @(negedge clk);
        if (naw == 1) awaddr = 32'h54;               // the next AW, pipelined
      end
      chk(naw == 1, "second AW not accepted while the first waits for W");
      wvalid = 1; wdata = 32'h0000_5050; wstrb = 4'hF;
      repeat (12) begin
        @(posedge clk);
        if (awvalid && awready) naw++;
        if (wvalid && wready) nw++;
        @(negedge clk);
        if (naw == 2) awvalid = 0;
        if (nw == 1) wdata = 32'h0000_5454;
        if (nw == 2) wvalid = 0;
      end
      chk(naw == 2 && nw == 2, "both writes completed in order");
      awvalid = 0; wvalid = 0;
      repeat (4) @(negedge clk);
      rd(32'h50, 3'b000, q, r);
      chk(q === 32'h0000_5050, "first AW took the first W");
      rd(32'h54, 3'b000, q, r);
      chk(q === 32'h0000_5454, "second AW took the second W");
      // W first: a second W waits for the first write
      @(negedge clk);
      wvalid = 1; wdata = 32'h0000_6060; wstrb = 4'hF; nw = 0; naw = 0;
      repeat (12) begin
        @(posedge clk);
        if (wvalid && wready) nw++;
        @(negedge clk);
        if (nw == 1) wdata = 32'h0000_6464;
      end
      chk(nw == 1, "second W not accepted while the first waits for AW");
      awvalid = 1; awaddr = 32'h60;
      repeat (12) begin
        @(posedge clk);
        if (awvalid && awready) naw++;
        if (wvalid && wready) nw++;
        @(negedge clk);
        if (naw == 1) awaddr = 32'h64;
        if (naw == 2) awvalid = 0;
        if (nw == 2) wvalid = 0;
      end
      awvalid = 0; wvalid = 0;
      repeat (4) @(negedge clk);
      rd(32'h60, 3'b000, q, r);
      chk(q === 32'h0000_6060, "W-first: first W to the first AW");
      rd(32'h64, 3'b000, q, r);
      chk(q === 32'h0000_6464, "W-first: second W to the second AW");
    end

    // R held under back-pressure, no new AR while it is pending
    begin : rbp
      int acc = 0;
      @(negedge clk); rready = 0;
      arvalid = 1; araddr = 32'h30;
      repeat (12) begin
        @(posedge clk);
        if (arvalid && arready) acc++;
        @(negedge clk);
      end
      chk(acc == 1, "one AR accepted while R is pending");
      chk(rvalid === 1'b1 && rdata === 32'h5A5A_5A5A, "R held while RREADY is low");
      arvalid = 0; rready = 1;
      repeat (2) @(negedge clk);
      chk(rvalid === 1'b0, "R dropped after RREADY");
    end

    // the whole array is addressable
    begin : fill
      int bad = 0;
      for (int i = 0; i < 256; i += 17) wr(i * 4, 32'h0BAD_0000 + i, 4'hF, 3'b001, i % 3, i % 4, r);
      for (int i = 0; i < 256; i += 17) begin rd(i * 4, 3'b000, q, r); if (q !== 32'h0BAD_0000 + i) bad++; end
      chk(bad == 0, "every 17th word written and read back");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #400000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
