// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_compliance_checker.sv -- AXI4-Lite concurrent assertion checks (bindable)

module axi4_lite_compliance_checker
  (input logic clk, input logic rst_n, input logic awvalid, input logic awready, input logic [31:0] awaddr, input logic [2:0] awprot, input logic wvalid, input logic wready, input logic [31:0] wdata, input logic [3:0] wstrb, input logic bvalid, input logic bready, input logic [1:0] bresp, input logic arvalid, input logic arready, input logic [31:0] araddr, input logic [2:0] arprot, input logic rvalid, input logic rready, input logic [31:0] rdata, input logic [1:0] rresp);

  // outstanding counts: a response only answers an accepted request
  int unsigned n_aw = 0, n_w = 0, n_b = 0, n_ar = 0, n_r = 0;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin n_aw <= 0; n_w <= 0; n_b <= 0; n_ar <= 0; n_r <= 0; end
    else begin
      if (awvalid && awready) n_aw <= n_aw + 1;
      if (wvalid && wready)   n_w  <= n_w + 1;
      if (bvalid && bready)   n_b  <= n_b + 1;
      if (arvalid && arready) n_ar <= n_ar + 1;
      if (rvalid && rready)   n_r  <= n_r + 1;
    end
  // subordinate VALID low in reset, no X out of reset
  assert property (@(posedge clk) !rst_n |-> !bvalid && !rvalid)
    else $error("AXI4-Lite: BVALID / RVALID high in reset");
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({awready, wready, arready, bvalid, rvalid}))
    else $error("AXI4-Lite: X on READY / VALID");
  assert property (@(posedge clk) disable iff (!rst_n) bvalid |-> !$isunknown(bresp))
    else $error("AXI4-Lite: X on BRESP");
  assert property (@(posedge clk) disable iff (!rst_n) rvalid |-> !$isunknown({rdata, rresp}))
    else $error("AXI4-Lite: X on the R channel");
  // VALID held and payload stable until READY, on every channel
  assert property (@(posedge clk) disable iff (!rst_n) awvalid && !awready |=> awvalid && $stable({awaddr, awprot}))
    else $error("AXI4-Lite: AW changed before AWREADY");
  assert property (@(posedge clk) disable iff (!rst_n) wvalid && !wready |=> wvalid && $stable({wdata, wstrb}))
    else $error("AXI4-Lite: W changed before WREADY");
  assert property (@(posedge clk) disable iff (!rst_n) arvalid && !arready |=> arvalid && $stable({araddr, arprot}))
    else $error("AXI4-Lite: AR changed before ARREADY");
  assert property (@(posedge clk) disable iff (!rst_n) bvalid && !bready |=> bvalid && $stable(bresp))
    else $error("AXI4-Lite: B changed before BREADY");
  assert property (@(posedge clk) disable iff (!rst_n) rvalid && !rready |=> rvalid && $stable({rdata, rresp}))
    else $error("AXI4-Lite: R changed before RREADY");
  // a write response needs both the address and the data accepted
  assert property (@(posedge clk) disable iff (!rst_n) bvalid |-> n_aw > n_b && n_w > n_b)
    else $error("AXI4-Lite: BVALID before AW and W were both accepted");
  assert property (@(posedge clk) disable iff (!rst_n) rvalid |-> n_ar > n_r)
    else $error("AXI4-Lite: RVALID without an accepted AR");
  assert property (@(posedge clk) disable iff (!rst_n) (bvalid |-> bresp != 2'b01) and (rvalid |-> rresp != 2'b01))
    else $error("AXI4-Lite: EXOKAY response");
  cover property (@(posedge clk) disable iff (!rst_n) wvalid && wready && !awvalid && n_aw == n_b);
  cover property (@(posedge clk) disable iff (!rst_n) awvalid && !awready ##1 awvalid && awready);
  cover property (@(posedge clk) disable iff (!rst_n) bvalid && !bready ##1 bvalid && bready);
  cover property (@(posedge clk) disable iff (!rst_n) rvalid && rresp == 2'b11);
endmodule
