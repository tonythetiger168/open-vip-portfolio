// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_sequences.svh -- AXI4-Lite sequences

// Random traffic: cfg.num_items constrained-random items.
class axi4_lite_base_sequence extends uvm_sequence #(axi4_lite_transaction);
  `uvm_object_utils(axi4_lite_base_sequence)
  axi4_lite_config cfg;

  function new(string name = "axi4_lite_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = axi4_lite_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "axi4_lite_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class axi4_lite_directed_sequence extends uvm_sequence #(axi4_lite_transaction);
  `uvm_object_utils(axi4_lite_directed_sequence)
  axi4_lite_config cfg;

  function new(string name = "axi4_lite_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function axi4_lite_transaction item();
    item = axi4_lite_transaction::type_id::create("req");
  endfunction

  task send(axi4_lite_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    axi4_lite_transaction t;
    // AW and W together, AW first, W first, with and without skew
    for (int i = 0; i < 6; i++) begin
      t = item(); t.we = 1; t.addr = 32'h40 + 4 * i; t.wdata = 32'hA000_0000 | i; t.wstrb = 4'hF;
      t.order = i % 3; t.skew = i / 3 * 3; send(t);
    end
    for (int i = 0; i < 6; i++) begin t = item(); t.addr = 32'h40 + 4 * i; send(t); end
    // byte lanes, half words
    for (int b = 0; b < 4; b++) begin
      t = item(); t.we = 1; t.addr = 32'h80; t.wdata = 32'h1122_3344; t.wstrb = 4'h1 << b; t.order = b % 3; send(t);
    end
    t = item(); t.we = 1; t.addr = 32'h84; t.wdata = 32'hFFFF_FFFF; t.wstrb = 4'h3; send(t);
    t = item(); t.we = 1; t.addr = 32'h84; t.wdata = 32'h5555_AAAA; t.wstrb = 4'hC; send(t);
    t = item(); t.addr = 32'h80; send(t);
    t = item(); t.addr = 32'h84; send(t);
    // privileged region: unprivileged write refused, privileged write done
    t = item(); t.we = 1; t.addr = 32'h3C0; t.wdata = 32'h1111_1111; t.wstrb = 4'hF; t.prot = 3'b000; send(t);
    t = item(); t.addr = 32'h3C0; send(t);
    t = item(); t.we = 1; t.addr = 32'h3FC; t.wdata = 32'h2222_2222; t.wstrb = 4'hF; t.prot = 3'b001; send(t);
    t = item(); t.addr = 32'h3FC; t.prot = 3'b010; send(t);
    t = item(); t.we = 1; t.addr = 32'h3BC; t.wdata = 32'h3333_3333; t.wstrb = 4'hF; t.prot = 3'b110; send(t);
    t = item(); t.addr = 32'h3BC; send(t);
    // error regions: no write lands, reads return 0
    t = item(); t.we = 1; t.addr = 32'h400; t.wdata = 32'hDEAD_BEEF; t.wstrb = 4'hF; t.prot = 3'b001; send(t);
    t = item(); t.addr = 32'h7FC; send(t);
    t = item(); t.we = 1; t.addr = 32'h800; t.wdata = 32'hDEAD_BEEF; t.wstrb = 4'hF; t.order = 2; send(t);
    t = item(); t.addr = 32'hFFC; send(t);
    t = item(); t.addr = 32'h0; send(t);
    // back to back, no gaps
    for (int i = 0; i < 8; i++) begin
      t = item(); t.we = !i[0]; t.addr = 32'h100 + 4 * (i / 2); t.wstrb = t.we ? 4'hF : 4'h0;
      t.wdata = t.we ? 32'hC0DE_0000 + i : 0; send(t);
    end
  endtask
endclass
