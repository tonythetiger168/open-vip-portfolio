// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_transaction.svh -- AXI4-Lite transaction

class axi4_lite_transaction extends uvm_sequence_item;
  `uvm_object_utils(axi4_lite_transaction)

  // request (driven by the agent)
  rand bit we;
  rand bit [31:0] addr;
  rand bit [2:0] prot;
  rand bit [31:0] wdata;
  rand bit [3:0] wstrb;
  // response (returned by the DUT)
  bit [31:0] rdata;
  bit [1:0] resp;
  // bookkeeping (not compared)
  rand bit [2:0] gap;
  rand bit [1:0] order;
  rand bit [1:0] skew;
  rand bit [1:0] region;
  int unsigned tag;   // sequence number (driver/monitor order)


  // the region is chosen first (a dist over address ranges would make
  // the simulator pick a value before the alignment)
  constraint c_region { region dist { 0 := 6, 1 := 2, 2 := 1, 3 := 1 }; }
  constraint c_addr   { addr[1:0] == 2'b00; addr[31:12] == 0;
                        region == 0 -> addr < 32'h3C0;
                        region == 1 -> addr inside {[32'h3C0:32'h3FC]};
                        region == 2 -> addr inside {[32'h400:32'h7FC]};
                        region == 3 -> addr >= 32'h800; }
  constraint c_wr     { we -> wstrb != 4'h0; !we -> (wstrb == 4'h0 && wdata == 0); }
  constraint c_order  { order != 2'd3; !we -> (order == 0 && skew == 0); }
  constraint c_gap    { gap dist { 0 := 6, [1:7] :/ 2 }; }

  function new(string name = "axi4_lite_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    axi4_lite_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    we = rhs_.we;
    addr = rhs_.addr;
    prot = rhs_.prot;
    wdata = rhs_.wdata;
    wstrb = rhs_.wstrb;
    rdata = rhs_.rdata;
    resp = rhs_.resp;
    gap = rhs_.gap;
    order = rhs_.order;
    skew = rhs_.skew;
    region = rhs_.region;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    axi4_lite_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (we != rhs_.we) return 0;
    if (addr != rhs_.addr) return 0;
    if (prot != rhs_.prot) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (wstrb != rhs_.wstrb) return 0;
    if (rdata != rhs_.rdata) return 0;
    if (resp != rhs_.resp) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(axi4_lite_transaction rhs_);
    if (we != rhs_.we) return 0;
    if (addr != rhs_.addr) return 0;
    if (prot != rhs_.prot) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (wstrb != rhs_.wstrb) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("AXI4-Lite{tag=%0d we=0x%0h addr=0x%0h prot=0x%0h wdata=0x%0h wstrb=0x%0h rdata=0x%0h resp=0x%0h}", tag, we, addr, prot, wdata, wstrb, rdata, resp);
  endfunction
endclass
