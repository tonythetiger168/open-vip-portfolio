// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_if.sv -- AXI4-Lite interface

interface axi4_lite_if (input logic clk);
  logic rst_n;

  logic awvalid;
  logic awready;
  logic [31:0] awaddr;
  logic [2:0] awprot;
  logic wvalid;
  logic wready;
  logic [31:0] wdata;
  logic [3:0] wstrb;
  logic bvalid;
  logic bready;
  logic [1:0] bresp;
  logic arvalid;
  logic arready;
  logic [31:0] araddr;
  logic [2:0] arprot;
  logic rvalid;
  logic rready;
  logic [31:0] rdata;
  logic [1:0] rresp;

  modport DUT (input clk, rst_n, input awvalid, input awaddr, input awprot, input wvalid, input wdata, input wstrb, input bready, input arvalid, input araddr, input arprot, input rready, output awready, output wready, output bvalid, output bresp, output arready, output rvalid, output rdata, output rresp);
  modport MON (input clk, rst_n, awvalid, awready, awaddr, awprot, wvalid, wready, wdata, wstrb, bvalid, bready, bresp, arvalid, arready, araddr, arprot, rvalid, rready, rdata, rresp);

  clocking drv_cb @(posedge clk);
    input rst_n, awready, wready, bvalid, bresp, arready, rvalid, rdata, rresp;
    inout awvalid, awaddr, awprot, wvalid, wdata, wstrb, bready, arvalid, araddr, arprot, rready;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, awvalid, awready, awaddr, awprot, wvalid, wready, wdata, wstrb, bvalid, bready, bresp, arvalid, arready, araddr, arprot, rvalid, rready, rdata, rresp;
  endclocking
endinterface
