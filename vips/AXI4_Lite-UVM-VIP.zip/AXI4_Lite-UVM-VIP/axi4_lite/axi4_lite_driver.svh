// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_driver.svh -- AXI4-Lite driver: AW and W in the item's order and skew, each held until READY, then B; AR then R

class axi4_lite_driver extends uvm_driver #(axi4_lite_transaction);
  `uvm_component_utils(axi4_lite_driver)

  uvm_analysis_port #(axi4_lite_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual axi4_lite_if vif;
  axi4_lite_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual axi4_lite_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "axi4_lite: virtual interface not set")
    if (!uvm_config_db#(axi4_lite_config)::get(this, "", "cfg", cfg))
      cfg = axi4_lite_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    axi4_lite_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    fork
      forever begin
        @(vif.drv_cb);
        vif.drv_cb.bready <= ($urandom_range(99) < cfg.ready_pct);
        vif.drv_cb.rready <= ($urandom_range(99) < cfg.ready_pct);
      end
    join_none
    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.awvalid <= 1'b0; vif.drv_cb.awaddr <= '0; vif.drv_cb.awprot <= '0;
    vif.drv_cb.wvalid  <= 1'b0; vif.drv_cb.wdata  <= '0; vif.drv_cb.wstrb  <= '0;
    vif.drv_cb.arvalid <= 1'b0; vif.drv_cb.araddr <= '0; vif.drv_cb.arprot <= '0;
    vif.drv_cb.bready  <= 1'b0; vif.drv_cb.rready <= 1'b0;
  endtask

  task drive_item(axi4_lite_transaction t);
    repeat (t.gap) @(vif.drv_cb);
    if (t.we) begin
      bit aw_on = 0, w_on = 0, aw_done = 0, w_done = 0;
      int unsigned to = 0;
      // AW first (order 1), W first (order 2) or both together; the other
      // channel follows skew clocks later
      if (t.order != 2) begin
        vif.drv_cb.awvalid <= 1'b1; vif.drv_cb.awaddr <= t.addr; vif.drv_cb.awprot <= t.prot; aw_on = 1;
      end
      if (t.order != 1) begin
        vif.drv_cb.wvalid <= 1'b1; vif.drv_cb.wdata <= t.wdata; vif.drv_cb.wstrb <= t.wstrb; w_on = 1;
      end
      while (!(aw_done && w_done) && to < cfg.timeout_cycles) begin
        @(vif.drv_cb); to++;
        if (aw_on && vif.drv_cb.awready === 1'b1) begin aw_on = 0; aw_done = 1; vif.drv_cb.awvalid <= 1'b0; end
        if (w_on  && vif.drv_cb.wready  === 1'b1) begin w_on  = 0; w_done  = 1; vif.drv_cb.wvalid  <= 1'b0; end
        if (!aw_on && !aw_done && to >= t.skew) begin
          vif.drv_cb.awvalid <= 1'b1; vif.drv_cb.awaddr <= t.addr; vif.drv_cb.awprot <= t.prot; aw_on = 1;
        end
        if (!w_on && !w_done && to >= t.skew) begin
          vif.drv_cb.wvalid <= 1'b1; vif.drv_cb.wdata <= t.wdata; vif.drv_cb.wstrb <= t.wstrb; w_on = 1;
        end
      end
      if (!(aw_done && w_done)) `uvm_error("TIMEOUT", "AXI4-Lite: AWREADY / WREADY not seen")
      begin
        int unsigned tb = 0;
        do begin @(vif.drv_cb); tb++; end
        while (!(vif.drv_cb.bvalid === 1'b1 && vif.drv_cb.bready === 1'b1) && tb < cfg.timeout_cycles);
        if (vif.drv_cb.bvalid !== 1'b1) `uvm_error("TIMEOUT", "AXI4-Lite: no B response")
        t.resp = vif.drv_cb.bresp;
        t.rdata = 32'h0;
      end
    end else begin
      int unsigned to = 0;
      vif.drv_cb.arvalid <= 1'b1; vif.drv_cb.araddr <= t.addr; vif.drv_cb.arprot <= t.prot;
      do begin @(vif.drv_cb); to++; end while (vif.drv_cb.arready !== 1'b1 && to < cfg.timeout_cycles);
      if (vif.drv_cb.arready !== 1'b1) `uvm_error("TIMEOUT", "AXI4-Lite: no ARREADY")
      vif.drv_cb.arvalid <= 1'b0;
      to = 0;
      do begin @(vif.drv_cb); to++; end
      while (!(vif.drv_cb.rvalid === 1'b1 && vif.drv_cb.rready === 1'b1) && to < cfg.timeout_cycles);
      if (vif.drv_cb.rvalid !== 1'b1) `uvm_error("TIMEOUT", "AXI4-Lite: no R response")
      t.rdata = vif.drv_cb.rdata;
      t.resp  = vif.drv_cb.rresp;
    end
  endtask

endclass
