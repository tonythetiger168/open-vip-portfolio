// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_coverage.svh -- AXI4-Lite functional coverage

class axi4_lite_coverage extends uvm_subscriber #(axi4_lite_transaction);
  `uvm_component_utils(axi4_lite_coverage)
  axi4_lite_config cfg;
  axi4_lite_transaction tr;

  covergroup axi4_lite_cg;
    cp_we     : coverpoint tr.we;
    cp_resp   : coverpoint tr.resp { bins okay = {AXIL_OKAY}; bins slverr = {AXIL_SLVERR}; bins decerr = {AXIL_DECERR};
                                     illegal_bins exokay = {AXIL_EXOKAY}; }
    cp_strb   : coverpoint tr.wstrb iff (tr.we) { bins full = {4'hF}; bins byte_[] = {4'h1, 4'h2, 4'h4, 4'h8};
                                                  bins half[] = {4'h3, 4'hC}; bins other = default; }
    cp_priv   : coverpoint tr.prot[0];
    cp_region : coverpoint tr.addr[11:6] { bins mem = {[0:14]}; bins priv = {15}; bins slverr = {[16:31]}; bins decerr = {[32:63]}; }
    x_we_resp : cross cp_we, cp_resp;
    x_priv    : cross cp_we, cp_priv, cp_region;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    axi4_lite_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(axi4_lite_config)::get(this, "", "cfg", cfg))
      cfg = axi4_lite_config::type_id::create("cfg");
  endfunction

  function void write(axi4_lite_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    axi4_lite_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("AXI4-Lite coverage: %0.1f%%", axi4_lite_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
