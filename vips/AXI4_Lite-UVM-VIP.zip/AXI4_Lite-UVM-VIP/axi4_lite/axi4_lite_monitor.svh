// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_monitor.svh -- AXI4-Lite monitor: AW and W handshakes queued separately and completed by B; AR completed by R

class axi4_lite_monitor extends uvm_monitor;
  `uvm_component_utils(axi4_lite_monitor)

  virtual axi4_lite_if vif;
  uvm_analysis_port #(axi4_lite_transaction) ap;
  axi4_lite_config cfg;
  int unsigned n_obs = 0;

  bit [34:0] aw_q[$];   // {awprot, awaddr}
  bit [35:0] w_q[$];    // {wstrb, wdata}
  bit [34:0] ar_q[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual axi4_lite_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "axi4_lite: virtual interface not set")
    if (!uvm_config_db#(axi4_lite_config)::get(this, "", "cfg", cfg))
      cfg = axi4_lite_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.awvalid && vif.mon_cb.awready) aw_q.push_back({vif.mon_cb.awprot, vif.mon_cb.awaddr});
        if (vif.mon_cb.wvalid  && vif.mon_cb.wready)  w_q.push_back({vif.mon_cb.wstrb, vif.mon_cb.wdata});
        if (vif.mon_cb.arvalid && vif.mon_cb.arready) ar_q.push_back({vif.mon_cb.arprot, vif.mon_cb.araddr});
        if (vif.mon_cb.bvalid && vif.mon_cb.bready) begin
          if (aw_q.size() == 0 || w_q.size() == 0)
            `uvm_error("MON", "AXI4-Lite: B response before both AW and W handshakes")
          else begin
            axi4_lite_transaction t = axi4_lite_transaction::type_id::create("t");
            bit [34:0] a = aw_q.pop_front();
            bit [35:0] w = w_q.pop_front();
            t.we = 1; {t.prot, t.addr} = a; {t.wstrb, t.wdata} = w;
            t.resp = vif.mon_cb.bresp; t.rdata = 32'h0;
            publish(t);
          end
        end
        if (vif.mon_cb.rvalid && vif.mon_cb.rready) begin
          if (ar_q.size() == 0)
            `uvm_error("MON", "AXI4-Lite: R response without an AR handshake")
          else begin
            axi4_lite_transaction t = axi4_lite_transaction::type_id::create("t");
            bit [34:0] a = ar_q.pop_front();
            t.we = 0; {t.prot, t.addr} = a; t.wstrb = 0; t.wdata = 0;
            t.rdata = vif.mon_cb.rdata; t.resp = vif.mon_cb.rresp;
            publish(t);
          end
        end
      end
    end
  endtask

  function void publish(axi4_lite_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
