// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// axi4_lite_pkg.sv -- AXI4-Lite UVM VIP package

package axi4_lite_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import axi4_lite_defs_pkg::*;
  export axi4_lite_defs_pkg::*;

  `include "axi4_lite_transaction.svh"
  `include "axi4_lite_config.svh"
  `include "axi4_lite_sequencer.svh"
  `include "axi4_lite_driver.svh"
  `include "axi4_lite_monitor.svh"
  `include "axi4_lite_agent.svh"
  `include "axi4_lite_sequences.svh"
  `include "axi4_lite_checker.svh"
  `include "axi4_lite_coverage.svh"
endpackage
