# GDDR6 UVM VIP

**Protocol Level:** Complex
**Checkers:** 4 UVM components (Protocol L1, Data Integrity L2, Timing L2, Error L3) + module-based SVA compliance checker (L1-L4)
**License:** Apache-2.0

## Protocol Overview
GDDR6 graphics DRAM: dual pseudo-channel operation, WCK clocking, DBI, optional CRC/ECC.

The VIP drives and monitors a DDR-style command/address bus
(`cs_n/act_n/ras_n/cas_n/we_n` + `{bg,ba}` bank + `addr` row/column):

| Command | cs_n | act_n | ras_n | cas_n | we_n | Address |
|---------|------|-------|-------|-------|------|---------|
| ACT     | 0    | 0     | -     | -     | -    | row     |
| RD      | 0    | 1     | 1     | 0     | 1    | column  |
| WR      | 0    | 1     | 1     | 0     | 0    | column  |
| PRE     | 0    | 1     | 0     | 1     | 0    | -       |
| REF     | 0    | 1     | 0     | 0     | 1    | -       |
| NOP     | 0    | 1     | 1     | 1     | 1    | -       |

Core timing parameters (cycles): tRCD=10, tRP=10, tRAS=14, tCL=10, tCWL=2, tRFC=40, tREFI=3900.

## Architecture
```
gddr6_vip/
|-- rtl/gddr6_if.sv                    # signal interface (+ clocking block)
|-- sequences/gddr6_sequence.sv        # transaction + directed sequence library
|-- vip/gddr6/
|   |-- gddr6_driver.sv                # protocol driver (cmd encoding, timing, DQ)
|   |-- gddr6_monitor.sv               # bus monitor (command/DQ decode -> analysis port)
|   |-- gddr6_agent.sv                 # sequencer + driver + monitor
|   |-- gddr6_coverage.sv              # 3 covergroups with crosses
|   |-- gddr6_compliance_checker.sv    # SVA module, L1-L4 (instanced in tb_top)
|   |-- gddr6_protocol_checker.sv      # L1 component (procedural sampling)
|   |-- gddr6_timing_checker.sv        # L2 component (tRCD/tRP/tRAS measurement)
|   |-- gddr6_data_integrity_checker.sv# L2 component (DQ/DBI/BL sampling)
|   |-- gddr6_error_checker.sv         # L3 component (temp/refresh/DFE monitoring)
|-- env/gddr6_env.sv                   # env + end-to-end scoreboard
|-- tests/gddr6_test.sv                # base/write/read/stress tests
|-- tb/tb_top.sv                     # TB top + DRAM memory-array functional model
|-- Makefile
```

Closed loop: sequences -> driver -> `gddr6_if` -> `gddr6_mem_model` (bank/row/col
storage in tb_top) drives read data back -> monitor decodes -> scoreboard
compares expected (driver) vs observed (monitor) end-to-end.

## Sequence Library
| Sequence | Purpose |
|----------|---------|
| `gddr6_base_sequence` | legacy fully-random items (API compatibility) |
| `gddr6_write_seq` | normal write flow: ACT, WR burst, PRE |
| `gddr6_read_seq` | normal read flow: ACT, RD burst, PRE |
| `gddr6_refresh_seq` | traffic punctuated by REF (tRFC apart) |
| `gddr6_bank_conflict_seq` | same bank, alternating rows (page misses) |
| `gddr6_back_to_back_seq` | one ACT, long alternating RD/WR stream (page hits) |
| `gddr6_stress_seq` | long protocol-legal random stream (bank-state model) |
| `gddr6_corner_seq` | all-zero/all-one row/col, boundary banks/stacks |
| `gddr6_random_sequence` | 50 random items |
| `gddr6_regression_sequence` | weighted mix of all directed sequences |

Tests: `gddr6_base_test` (regression seq), `gddr6_write_test`, `gddr6_read_test`, `gddr6_stress_test`.

## SVA Compliance Checker (vip/gddr6/gddr6_compliance_checker.sv)
- **L1 signal sanity (4):** command/address known when selected, bank group/address encoding bounds.
- **L2 timing & data integrity (10):** tRCD/tRP windows, burst length, data valid with DQS, DBI/WCK settings.
- **L3 error handling (6):** power-management state, refresh interval, over-temperature, DFE/bandwidth/latency bounds.
- **L4 GDDR6-specific (10):** ACT/RD-WR/PRE bank-state legality (3), tRCD/tRP/tRAS timing rules (3), refresh pulse width, CKE gating, family rules (WCK ratio + DBI status), refresh-interval + ACT->col->PRE covers.

## Functional Coverage (vip/gddr6/gddr6_coverage.sv)
- `cg_command`    : command distribution x bank cross (`cx_cmd_bank`)
- `cg_bank_state` : bank state transitions (ACT=>RD/WR, RD/WR=>PRE, PRE/REF=>ACT, RD<=>WR)
- `cg_addr`       : row/col/stack address patterns with `cx_row_col` cross

## Quick Start
```bash
make comp                                   # compile (VCS + UVM 1.2)
make sim                                    # run default test
make regress                                # run regression test
./simv +UVM_TESTNAME=gddr6_stress_test        # run a directed test
```
