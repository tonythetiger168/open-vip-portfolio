// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// gddr6_test.sv -- GDDR6 UVM tests

`ifndef GDDR6_TEST_SV
`define GDDR6_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class gddr6_base_test extends uvm_test;
  `uvm_component_utils(gddr6_base_test)
  gddr6_env env;
  function new(string name="gddr6_base_test", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = gddr6_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    gddr6_regression_sequence seq;
    phase.raise_objection(this);
    seq = gddr6_regression_sequence::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: write flow only
class gddr6_write_test extends gddr6_base_test;
  `uvm_component_utils(gddr6_write_test)
  function new(string name="gddr6_write_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr6_write_seq seq;
    phase.raise_objection(this);
    seq = gddr6_write_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: read flow + refresh flow
class gddr6_read_test extends gddr6_base_test;
  `uvm_component_utils(gddr6_read_test)
  function new(string name="gddr6_read_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr6_read_seq    rd;
    gddr6_refresh_seq rf;
    phase.raise_objection(this);
    rd = gddr6_read_seq::type_id::create("rd");
    rf = gddr6_refresh_seq::type_id::create("rf");
    rd.start(env.agt.sqr);
    rf.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress test: long protocol-legal random stream
class gddr6_stress_test extends gddr6_base_test;
  `uvm_component_utils(gddr6_stress_test)
  function new(string name="gddr6_stress_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    gddr6_stress_seq seq;
    phase.raise_objection(this);
    seq = gddr6_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
