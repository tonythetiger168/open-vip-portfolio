// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// gddr6_compliance_checker.sv -- GDDR6 SVA compliance checker
// L1 = signal sanity, L2 = timing & data integrity, L3 = error handling,
// L4 = GDDR6 protocol-specific rules (timing parameters, bank-state
// legality, refresh servicing). Instantiated in tb_top.
// GDDR6 graphics DRAM: dual pseudo-channel operation, WCK clocking, DBI, optional CRC/ECC.

`ifndef GDDR6_COMPLIANCE_CHECKER_SV
`define GDDR6_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module gddr6_compliance_checker (gddr6_if vif);

  // ---------------- L1: signal sanity (4) ----------------
  property p_gddr6_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_gddr6_cmd_valid: assert property(p_gddr6_cmd_valid) else `uvm_warning("GDDR6", "Command valid failed");
  cover_p_gddr6_cmd_valid: cover property(p_gddr6_cmd_valid);
  property p_gddr6_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_gddr6_addr_valid: assert property(p_gddr6_addr_valid) else `uvm_warning("GDDR6", "Address valid failed");
  cover_p_gddr6_addr_valid: cover property(p_gddr6_addr_valid);
  property p_gddr6_bg; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bg <= 2'd3; endproperty
  assert_p_gddr6_bg: assert property(p_gddr6_bg) else `uvm_warning("GDDR6", "Bank group 0-3 failed");
  cover_p_gddr6_bg: cover property(p_gddr6_bg);
  property p_gddr6_ba; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ba <= 2'd3; endproperty
  assert_p_gddr6_ba: assert property(p_gddr6_ba) else `uvm_warning("GDDR6", "Bank address 0-3 failed");
  cover_p_gddr6_ba: cover property(p_gddr6_ba);

  // ---------------- L2: timing & data integrity (10) ----------------
  property p_gddr6_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cs_n) |-> ##[8:12] vif.ca[4] == 0; endproperty
  assert_p_gddr6_tRCD: assert property(p_gddr6_tRCD) else `uvm_warning("GDDR6", "tRCD 8-12 cycles failed");
  cover_p_gddr6_tRCD: cover property(p_gddr6_tRCD);
  property p_gddr6_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.cs_n) |-> ##[8:12] $fell(vif.cs_n); endproperty
  assert_p_gddr6_tRP: assert property(p_gddr6_tRP) else `uvm_warning("GDDR6", "tRP 8-12 cycles failed");
  cover_p_gddr6_tRP: cover property(p_gddr6_tRP);
  property p_gddr6_bl; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {3'b001,3'b010,3'b011,3'b100}; endproperty
  assert_p_gddr6_bl: assert property(p_gddr6_bl) else `uvm_warning("GDDR6", "Burst length 2/4/8/16 failed");
  cover_p_gddr6_bl: cover property(p_gddr6_bl);
  property p_gddr6_data_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dqs_t == 1 |-> !$isunknown(vif.dq); endproperty
  assert_p_gddr6_data_valid: assert property(p_gddr6_data_valid) else `uvm_warning("GDDR6", "Data valid failed");
  cover_p_gddr6_data_valid: cover property(p_gddr6_data_valid);
  property p_gddr6_dbis; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dbis == 1 |-> vif.dqs_t == 1; endproperty
  assert_p_gddr6_dbis: assert property(p_gddr6_dbis) else `uvm_warning("GDDR6", "DBI valid failed");
  cover_p_gddr6_dbis: cover property(p_gddr6_dbis);
  property p_gddr6_wck; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_gddr6_wck: assert property(p_gddr6_wck) else `uvm_warning("GDDR6", "WCK ratio failed");
  cover_p_gddr6_wck: cover property(p_gddr6_wck);
  property p_gddr6_speed; @(posedge vif.ck) disable iff (!vif.rst_n) vif.speed_grade >= 4'd12; endproperty
  assert_p_gddr6_speed: assert property(p_gddr6_speed) else `uvm_warning("GDDR6", "Speed grade 16Gbps+ failed");
  cover_p_gddr6_speed: cover property(p_gddr6_speed);
  property p_gddr6_no_x; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_gddr6_no_x: assert property(p_gddr6_no_x) else `uvm_warning("GDDR6", "No X when active failed");
  cover_p_gddr6_no_x: cover property(p_gddr6_no_x);
  property p_gddr6_crc; @(posedge vif.ck) disable iff (!vif.rst_n) vif.crc_en == 1 && vif.we_n == 0 |-> vif.crc != 8'h00; endproperty
  assert_p_gddr6_crc: assert property(p_gddr6_crc) else `uvm_warning("GDDR6", "CRC on write failed");
  cover_p_gddr6_crc: cover property(p_gddr6_crc);
  property p_gddr6_ecc; @(posedge vif.ck) disable iff (!vif.rst_n) vif.ecc_en |-> vif.data_width >= 5'b01000; endproperty
  assert_p_gddr6_ecc: assert property(p_gddr6_ecc) else `uvm_warning("GDDR6", "On-die ECC failed");
  cover_p_gddr6_ecc: cover property(p_gddr6_ecc);

  // ---------------- L3: error handling (6) ----------------
  property p_gddr6_pm; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_gddr6_pm: assert property(p_gddr6_pm) else `uvm_warning("GDDR6", "Power management failed");
  cover_p_gddr6_pm: cover property(p_gddr6_pm);
  property p_gddr6_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.refresh |-> ##[1:3900] vif.cs_n == 0; endproperty
  assert_p_gddr6_refresh: assert property(p_gddr6_refresh) else `uvm_warning("GDDR6", "Refresh interval failed");
  cover_p_gddr6_refresh: cover property(p_gddr6_refresh);
  property p_gddr6_overtemp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp > 8'd85 |-> vif.cs_n == 1; endproperty
  assert_p_gddr6_overtemp: assert property(p_gddr6_overtemp) else `uvm_warning("GDDR6", "Overtemp failed");
  cover_p_gddr6_overtemp: cover property(p_gddr6_overtemp);
  property p_gddr6_dfe; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dfe_tap <= 4'd15; endproperty
  assert_p_gddr6_dfe: assert property(p_gddr6_dfe) else `uvm_warning("GDDR6", "DFE tap failed");
  cover_p_gddr6_dfe: cover property(p_gddr6_dfe);
  property p_gddr6_bw; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bandwidth <= 32'hFFFFFFFF; endproperty
  assert_p_gddr6_bw: assert property(p_gddr6_bw) else `uvm_warning("GDDR6", "Bandwidth failed");
  cover_p_gddr6_bw: cover property(p_gddr6_bw);
  property p_gddr6_latency; @(posedge vif.ck) disable iff (!vif.rst_n) vif.latency_target <= 8'd127; endproperty
  assert_p_gddr6_latency: assert property(p_gddr6_latency) else `uvm_warning("GDDR6", "Latency target failed");
  cover_p_gddr6_latency: cover property(p_gddr6_latency);

  // ---------------- L4: GDDR6 protocol-specific rules (10) ----------------
  localparam int L4_TRCD  = 10;
  localparam int L4_TRP   = 10;
  localparam int L4_TRAS  = 14;
  localparam int L4_TRFC  = 40;
  localparam int L4_TREFI = 3900;

  // Command decode (mirrors the driver/monitor truth table)
  wire l4_act = (!vif.cs_n) && (!vif.act_n);
  wire l4_rd  = (!vif.cs_n) && vif.act_n && vif.ras_n && (!vif.cas_n) && vif.we_n;
  wire l4_wr  = (!vif.cs_n) && vif.act_n && vif.ras_n && (!vif.cas_n) && (!vif.we_n);
  wire l4_col = l4_rd || l4_wr;
  wire l4_pre = (!vif.cs_n) && vif.act_n && (!vif.ras_n) && vif.cas_n && (!vif.we_n);
  wire l4_ref = (!vif.cs_n) && vif.act_n && (!vif.ras_n) && (!vif.cas_n) && vif.we_n;
  wire [4:0] l4_bidx = {vif.bg, vif.ba};

  // Bank open/close state used by the legality rules below
  bit [31:0] l4_open;
  always @(posedge vif.ck or negedge vif.rst_n) begin
    if (!vif.rst_n) l4_open <= '0;
    else begin
      if (l4_act) l4_open[l4_bidx] <= 1'b1;
      if (l4_pre) l4_open[l4_bidx] <= 1'b0;
      if (l4_ref) l4_open <= '0;
    end
  end

  // L4-1: ACT may only target a closed (precharged) bank
  a_gddr6_l4_act_closed : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> !l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "gddr6: ACT issued to an already-active bank")
  // L4-2: RD/WR may only target an activated bank
  a_gddr6_l4_col_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_col |-> l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "gddr6: RD/WR to a non-activated bank")
  // L4-3: PRE may only target an activated bank
  a_gddr6_l4_pre_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_pre |-> l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "gddr6: PRE to a non-activated bank")
  // L4-4: tRCD -- no column command within tRCD cycles after ACT
  a_gddr6_l4_trcd : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> ##1 (!l4_col)[*(L4_TRCD-1)])
    else `uvm_error("SVA_L4", "gddr6: tRCD violation (column command too soon after ACT)")
  // L4-5: tRP -- no ACT within tRP cycles after PRE
  a_gddr6_l4_trp : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_pre |-> ##1 (!l4_act)[*(L4_TRP-1)])
    else `uvm_error("SVA_L4", "gddr6: tRP violation (ACT too soon after PRE)")
  // L4-6: tRAS -- no PRE within tRAS cycles after ACT
  a_gddr6_l4_tras : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> ##1 (!l4_pre)[*(L4_TRAS-1)])
    else `uvm_error("SVA_L4", "gddr6: tRAS violation (PRE too soon after ACT)")
  // L4-7: refresh pulse must complete within tRFC (+2) cycles
  a_gddr6_l4_ref_pulse : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    $rose(vif.refresh) |-> ##[1:(L4_TRFC+2)] $fell(vif.refresh))
    else `uvm_error("SVA_L4", "gddr6: refresh pulse wider than tRFC")
  // L4-8: commands require CKE high
  a_gddr6_l4_cke : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    (!vif.cs_n && !vif.act_n) |-> vif.cke)
    else `uvm_error("SVA_L4", "gddr6: command issued while CKE low")

  // L4-9 (GDDR): WCK2CK training only in a legal WCK:CK ratio
  a_gddr6_l4_wck : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    vif.wck2ck_train |-> (vif.wck_ratio inside {2'b00, 2'b01}))
    else `uvm_error("SVA_L4", "gddr6: illegal WCK ratio during WCK2CK training")
  // L4-10 (GDDR): DBI status line must be known when a DBI mode is enabled
  a_gddr6_l4_dbi : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    (vif.dbim != 2'b00) |-> !$isunknown(vif.dbis))
    else `uvm_error("SVA_L4", "gddr6: DBI status unknown while DBI mode enabled")

  // Refresh must be serviced again within tREFI after each REF command
  c_gddr6_l4_ref_interval : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_ref ##[1:(L4_TREFI)] l4_ref);
  // Full ACT -> column -> PRE bank cycle observed
  c_gddr6_l4_rw_cycle : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act ##[1:64] l4_col ##[1:64] l4_pre);

endmodule
`endif
