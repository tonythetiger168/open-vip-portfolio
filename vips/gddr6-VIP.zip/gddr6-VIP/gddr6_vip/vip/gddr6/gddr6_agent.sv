// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// gddr6_agent.sv -- GDDR6 UVM agent (sequencer + driver + monitor)

`ifndef GDDR6_AGENT_SV
`define GDDR6_AGENT_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
typedef class gddr6_driver;
typedef class gddr6_monitor;

class gddr6_agent extends uvm_agent;
  `uvm_component_utils(gddr6_agent)
  uvm_sequencer #(gddr6_transaction) sqr;
  gddr6_driver  drv;
  gddr6_monitor mon;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    sqr = uvm_sequencer #(gddr6_transaction)::type_id::create("sqr", this);
    drv = gddr6_driver::type_id::create("drv", this);
    mon = gddr6_monitor::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
