// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// pcie_dl_model.sv -- PCIe endpoint reference model below the transaction
// interface: LTSSM (training ordered-set level), Data Link Layer and a small
// Transaction Layer completer. Non-flit mode (8b/10b / 128b/130b era DLL).
//
// Link side (byte streams, one byte per clock, no back-pressure):
//   rx_* / tx_*        TLPs as {4'b0, seq[11:8]}, seq[7:0], TLP bytes, LCRC
//                      (CRC-32 of the sequence number and TLP, IEEE 802.3
//                      form: init '1, reflected, inverted, LSB byte first;
//                      a good TLP leaves the residue 32'hDEBB20E3)
//   rx_dllp / tx_dllp  one DLLP per clock: {type, b1, b2, b3, crc[15:8], crc[7:0]}
//                      CRC-16 0x100B over the 4 bytes (see dllp_crc)
//   rx_os / tx_os      training ordered sets: 0 TS1, 1 TS2, 2 idle data, 3 EIOS
//
// LTSSM: Detect.Quiet -> (rx_det) Polling.Active (TS1; 8 TS1/TS2 received
// and 16 sent) -> Polling.Configuration (TS2; 8 TS2 received, 16 sent after
// the first) -> Configuration.Idle (idle; 8 received, 16 sent) -> L0.
// L0 -> Recovery on a received TS1 or a REPLAY_NUM rollover: RcvrLock (TS1;
// 8 TS1/TS2) -> RcvrCfg (TS2; 8 TS2) -> Recovery.Idle (8 idle) -> L0. A
// training state that does not finish in 2000 clocks returns to Detect.
// EIOS in L0 -> Detect (link down: Data Link Layer reset).
//
// Data Link Layer: FC initialisation (InitFC1 P/NP/Cpl until all three are
// received, then InitFC2 until an InitFC2, UpdateFC or TLP arrives; then
// dl_up). Receive: LCRC and sequence check, ACK (coalesced) / NAK (once per
// NAK_SCHEDULED), duplicates ACKed and dropped. Transmit: sequence numbers,
// replay buffer purged by ACK, replay on NAK or REPLAY_TIMEOUT, REPLAY_NUM
// rollover after the 4th replay -> Recovery. Credits: advertised
// PH/PD/NPH/NPD (Cpl infinite); credits of a TLP return CRED_LAT clocks
// after receipt as UpdateFC; receiver overflow is checked; completions are
// gated by the partner's Cpl credits (0 = infinite).
//
// Transaction Layer (completer): MRd/MWr (3DW) to a 4 KB BAR0, CfgRd0/
// CfgWr0 (64 DW config space: IDs, Command, BAR0), UR for other requests
// and for memory requests outside BAR0 or with Memory Space disabled,
// poisoned writes dropped, length/payload mismatch = malformed (dropped).
// Read completions are split at every 64-byte (RCB) boundary with Byte
// Count / Lower Address per the base specification.
//
// err (sticky): [0] bad TLP (LCRC) [1] bad DLLP [2] REPLAY_NUM rollover
// [3] replay timer timeout [4] receiver overflow [5] malformed TLP
// [6] poisoned TLP [7] unsupported request [8] DLLP protocol error
// (ACK/NAK sequence out of range) [9] TLP received out of sequence (NAK sent)
module pcie_dl_model #(
  parameter int PH = 4, parameter int PD = 32, parameter int NPH = 4, parameter int NPD = 4,
  parameter int CRED_LAT = 40, parameter int REPLAY_TIMEOUT = 700
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        rx_det,
  input  logic        rx_os_valid,
  input  logic [1:0]  rx_os,
  output logic        tx_os_valid,
  output logic [1:0]  tx_os,
  input  logic        rx_valid,
  input  logic        rx_sop,
  input  logic        rx_eop,
  input  logic [7:0]  rx_data,
  input  logic        rx_dllp_valid,
  input  logic [47:0] rx_dllp,
  output logic        tx_valid,
  output logic        tx_sop,
  output logic        tx_eop,
  output logic [7:0]  tx_data,
  output logic        tx_dllp_valid,
  output logic [47:0] tx_dllp,
  output logic [3:0]  ltssm,
  output logic        link_up,
  output logic        dl_up,
  output logic [9:0]  err
);
  // ------------------------------------------------------------------ encodings
  localparam logic [3:0] L_DETECT = 4'd0, L_POLL_ACT = 4'd1, L_POLL_CFG = 4'd2, L_CFG_IDLE = 4'd3,
                         L_L0 = 4'd4, L_REC_LOCK = 4'd5, L_REC_CFG = 4'd6, L_REC_IDLE = 4'd7;
  localparam logic [1:0] OS_TS1 = 2'd0, OS_TS2 = 2'd1, OS_IDLE = 2'd2, OS_EIOS = 2'd3;
  localparam logic [7:0] D_ACK = 8'h00, D_NAK = 8'h10,
                         D_FC1_P = 8'h40, D_FC1_NP = 8'h50, D_FC1_CPL = 8'h60,
                         D_FC2_P = 8'hC0, D_FC2_NP = 8'hD0, D_FC2_CPL = 8'hE0,
                         D_UFC_P = 8'h80, D_UFC_NP = 8'h90, D_UFC_CPL = 8'hA0;
  localparam logic [31:0] RESIDUE = 32'hDEBB20E3;
  localparam int TRAIN_TO = 2000;

  function automatic logic [31:0] crc32_byte(input logic [31:0] c, input logic [7:0] d);
    for (int i = 0; i < 8; i++) c = (c[0] ^ d[i]) ? (c >> 1) ^ 32'hEDB88320 : (c >> 1);
    return c;
  endfunction
  // DLLP CRC: x^16+x^12+x^3+x+1 (0x100B), init '1, bit 0 of each byte first, inverted
  function automatic logic [15:0] dllp_crc(input logic [31:0] b);
    logic [15:0] c;
    logic [7:0] d;
    c = 16'hFFFF;
    for (int k = 0; k < 4; k++) begin
      d = b[31 - 8 * k -: 8];
      for (int i = 0; i < 8; i++) c = (c[15] ^ d[i]) ? ((c << 1) ^ 16'h100B) : (c << 1);
    end
    return ~c;
  endfunction
  function automatic logic [47:0] mk_dllp(input logic [31:0] b);
    return {b, dllp_crc(b)};
  endfunction
  function automatic logic [47:0] mk_fc(input logic [7:0] t, input logic [7:0] h, input logic [11:0] d);
    return mk_dllp({t, 2'b00, h[7:2], h[1:0], 2'b00, d[11:8], d[7:0]});
  endfunction
  // (a - b) mod 4096 / 256 treated as "a is not before b"
  function automatic logic seq_le(input logic [11:0] a, input logic [11:0] b);   // a <= b (mod 4096)
    return 12'(b - a) < 12'd2048;
  endfunction

  // ------------------------------------------------------------------ LTSSM
  logic [3:0]  ls;
  logic [4:0]  os_rx_cnt, os_tx_cnt;
  logic        first_rx;
  logic [11:0] t_train;
  logic        go_recovery;          // set by the DLL (replay rollover)
  assign ltssm   = ls;
  assign link_up = (ls == L_L0) || (ls == L_REC_LOCK) || (ls == L_REC_CFG) || (ls == L_REC_IDLE);
  wire   train   = (ls != L_DETECT) && (ls != L_L0);

  // ------------------------------------------------------------------ DLL state
  logic        dl_init1, dl_init2, dl_active;
  logic [2:0]  fc1_seen;             // InitFC P/NP/Cpl received
  logic [1:0]  fc_tx_idx;            // InitFC type to send next
  logic [7:0]  cpl_lim_h;  logic [11:0] cpl_lim_d;    // partner Cpl credit limit (0 = infinite)
  logic        cpl_inf_h, cpl_inf_d;
  logic [7:0]  cpl_cons_h; logic [11:0] cpl_cons_d;
  logic [11:0] next_rcv_seq, next_tx_seq, ackd_seq;
  logic        nak_sched, ack_pend;
  logic [1:0]  replay_num;
  logic [11:0] replay_timer;
  // receive buffer
  logic [7:0]  rb [0:4199];
  logic [12:0] rn;
  logic [31:0] rcrc;
  logic        rx_in;
  // credits received / allocated (P, NP)
  logic [7:0]  rcv_ph, rcv_nph, alc_ph, alc_nph;
  logic [11:0] rcv_pd, rcv_npd, alc_pd, alc_npd;
  logic        ufc_p, ufc_np;
  // credit release FIFO
  logic        rel_np [0:15];
  logic [11:0] rel_d  [0:15];
  logic [15:0] rel_t  [0:15];
  logic [3:0]  rel_wr, rel_rd;
  logic [15:0] now;
  // transaction layer
  logic [31:0] cfg [0:63];
  logic [7:0]  mem [0:4095];
  logic [15:0] my_id;
  // outgoing TLP queue (bodies without sequence number / LCRC)
  logic [7:0]  qb [0:16383];
  logic [13:0] qwr, qrd;
  logic [12:0] ql [0:255];
  logic [7:0]  qlw, qlr;
  // replay buffer: bytes as transmitted, with per-TLP start / length / seq
  logic [7:0]  pb [0:16383];
  logic [13:0] pwr;
  logic [13:0] ps [0:63];
  logic [12:0] pl [0:63];
  logic [11:0] pseq [0:63];
  logic [5:0]  pfirst, pcount;       // oldest entry, entries held
  // transmitter
  logic        tx_busy, tx_replay;
  logic [12:0] tx_pos, tx_len;
  logic [13:0] tx_src;
  logic [5:0]  rp_idx, rp_left;
  logic        replay_req;

  // ------------------------------------------------------------------ TL helpers
  // push one byte to the outgoing queue
  task automatic q_byte(input logic [7:0] b);
    qb[qwr] = b;
    qwr = qwr + 14'd1;
  endtask
  // completion header (3DW) + optional data
  task automatic q_cpl(input logic [15:0] req_id, input logic [7:0] tag, input logic [2:0] st,
                       input logic [11:0] bc, input logic [6:0] la, input int ndw, input logic [11:0] daddr,
                       input logic is_cfg_data, input logic [31:0] cfgdw);
    int n;
    n = 12 + 4 * ndw;
    q_byte(ndw > 0 ? 8'h4A : 8'h0A);
    q_byte(8'h00);
    q_byte({6'h0, 2'(ndw >> 8)});
    q_byte(8'(ndw));
    q_byte(my_id[15:8]); q_byte(my_id[7:0]);
    q_byte({st, 1'b0, bc[11:8]}); q_byte(bc[7:0]);
    q_byte(req_id[15:8]); q_byte(req_id[7:0]);
    q_byte(tag); q_byte({1'b0, la});
    if (is_cfg_data) begin
      q_byte(cfgdw[7:0]); q_byte(cfgdw[15:8]); q_byte(cfgdw[23:16]); q_byte(cfgdw[31:24]);
    end else
      for (int i = 0; i < 4 * ndw; i++) q_byte(mem[12'(daddr + 12'(i))]);
    ql[qlw] = 13'(n);
    qlw = qlw + 8'd1;
  endtask

  // ------------------------------------------------------------------ main
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ls <= L_DETECT; os_rx_cnt <= '0; os_tx_cnt <= '0; first_rx <= 1'b0; t_train <= '0;
      tx_os_valid <= 1'b0; tx_os <= OS_TS1;
      dl_init1 <= 1'b0; dl_init2 <= 1'b0; dl_active <= 1'b0; fc1_seen <= '0; fc_tx_idx <= '0;
      cpl_lim_h <= '0; cpl_lim_d <= '0; cpl_inf_h <= 1'b1; cpl_inf_d <= 1'b1; cpl_cons_h <= '0; cpl_cons_d <= '0;
      next_rcv_seq <= '0; next_tx_seq <= '0; ackd_seq <= 12'hFFF; nak_sched <= 1'b0; ack_pend <= 1'b0;
      replay_num <= '0; replay_timer <= '0; go_recovery <= 1'b0;
      rn <= '0; rcrc <= '1; rx_in <= 1'b0;
      rcv_ph <= '0; rcv_nph <= '0; rcv_pd <= '0; rcv_npd <= '0;
      alc_ph <= 8'(PH); alc_nph <= 8'(NPH); alc_pd <= 12'(PD); alc_npd <= 12'(NPD);
      ufc_p <= 1'b0; ufc_np <= 1'b0; rel_wr <= '0; rel_rd <= '0; now <= '0;
      for (int i = 0; i < 64; i++) cfg[i] = 32'h0;
      for (int i = 0; i < 4096; i++) mem[i] = 8'h00;
      my_id = '0;
      qwr = '0; qrd <= '0; qlw = '0; qlr <= '0;
      pwr <= '0; pfirst <= '0; pcount <= '0;
      tx_busy <= 1'b0; tx_replay <= 1'b0; tx_pos <= '0; tx_len <= '0; tx_src <= '0; 
      rp_idx <= '0; rp_left <= '0; replay_req <= 1'b0;
      tx_valid <= 1'b0; tx_sop <= 1'b0; tx_eop <= 1'b0; tx_data <= '0;
      tx_dllp_valid <= 1'b0; tx_dllp <= '0;
      dl_up <= 1'b0; err <= '0;
    end else begin : step
      logic dllp_sent;
      logic [31:0] c;
      dllp_sent = 1'b0;
      now <= now + 16'd1;
      tx_dllp_valid <= 1'b0;

      // ================= LTSSM =================
      tx_os_valid <= train;
      t_train <= train ? t_train + 12'd1 : '0;
      case (ls)
        L_DETECT: if (rx_det) begin ls <= L_POLL_ACT; os_rx_cnt <= '0; os_tx_cnt <= '0; tx_os <= OS_TS1; end
        L_POLL_ACT, L_REC_LOCK: begin
          tx_os <= OS_TS1;
          if (os_tx_cnt != 5'd31) os_tx_cnt <= os_tx_cnt + 5'd1;
          if (rx_os_valid) os_rx_cnt <= (rx_os == OS_TS1 || rx_os == OS_TS2) ? (os_rx_cnt == 5'd31 ? os_rx_cnt : os_rx_cnt + 5'd1) : '0;
          if (os_rx_cnt >= 5'd8 && os_tx_cnt >= 5'd16) begin
            ls <= (ls == L_POLL_ACT) ? L_POLL_CFG : L_REC_CFG;
            os_rx_cnt <= '0; os_tx_cnt <= '0; first_rx <= 1'b0; tx_os <= OS_TS2; t_train <= '0;
          end
        end
        L_POLL_CFG, L_REC_CFG: begin
          tx_os <= OS_TS2;
          if (first_rx && os_tx_cnt != 5'd31) os_tx_cnt <= os_tx_cnt + 5'd1;
          if (rx_os_valid) begin
            if (rx_os == OS_TS2) begin
              first_rx <= 1'b1;
              if (os_rx_cnt != 5'd31) os_rx_cnt <= os_rx_cnt + 5'd1;
            end else os_rx_cnt <= '0;
          end
          if (os_rx_cnt >= 5'd8 && os_tx_cnt >= 5'd16) begin
            ls <= (ls == L_POLL_CFG) ? L_CFG_IDLE : L_REC_IDLE;
            os_rx_cnt <= '0; os_tx_cnt <= '0; tx_os <= OS_IDLE; t_train <= '0;
          end
        end
        L_CFG_IDLE, L_REC_IDLE: begin
          tx_os <= OS_IDLE;
          if (os_tx_cnt != 5'd31) os_tx_cnt <= os_tx_cnt + 5'd1;
          if (rx_os_valid) os_rx_cnt <= (rx_os == OS_IDLE) ? (os_rx_cnt == 5'd31 ? os_rx_cnt : os_rx_cnt + 5'd1) : '0;
          if (os_rx_cnt >= 5'd8 && os_tx_cnt >= 5'd16) begin
            ls <= L_L0; t_train <= '0;
            if (ls == L_CFG_IDLE) begin dl_init1 <= 1'b1; fc_tx_idx <= '0; end
          end
        end
        default: begin                                        // L0
          if (go_recovery || (rx_os_valid && rx_os == OS_TS1)) begin
            ls <= L_REC_LOCK; os_rx_cnt <= '0; os_tx_cnt <= '0; tx_os <= OS_TS1; go_recovery <= 1'b0;
          end else if (rx_os_valid && rx_os == OS_EIOS)
            ls <= L_DETECT;
        end
      endcase
      if (train && t_train == 12'(TRAIN_TO)) ls <= L_DETECT;
      // link down: reset the Data Link Layer
      if (ls == L_DETECT && (dl_init1 || dl_init2 || dl_active)) begin
        dl_init1 <= 1'b0; dl_init2 <= 1'b0; dl_active <= 1'b0; dl_up <= 1'b0; fc1_seen <= '0;
        next_rcv_seq <= '0; next_tx_seq <= '0; ackd_seq <= 12'hFFF; pcount <= '0; pfirst <= '0;
        nak_sched <= 1'b0; ack_pend <= 1'b0; replay_num <= '0; tx_busy <= 1'b0; replay_req <= 1'b0;
        tx_replay <= 1'b0; qrd <= qwr; qlr <= qlw; rel_rd <= rel_wr; ufc_p <= 1'b0; ufc_np <= 1'b0;
        rcv_ph <= '0; rcv_nph <= '0; rcv_pd <= '0; rcv_npd <= '0;
        alc_ph <= 8'(PH); alc_nph <= 8'(NPH); alc_pd <= 12'(PD); alc_npd <= 12'(NPD);
        cpl_inf_h <= 1'b1; cpl_inf_d <= 1'b1; cpl_cons_h <= '0; cpl_cons_d <= '0;
      end

      // ================= received DLLPs =================
      if (rx_dllp_valid && link_up) begin
        if (dllp_crc(rx_dllp[47:16]) != rx_dllp[15:0]) err[1] <= 1'b1;
        else begin : dl
          logic [7:0] t;
          logic [11:0] s;
          logic [7:0] hf;
          logic [11:0] df;
          t  = rx_dllp[47:40];
          s  = rx_dllp[27:16];
          hf = {rx_dllp[37:32], rx_dllp[31:30]};
          df = rx_dllp[27:16];
          case (t & 8'hF0)
            D_FC1_P, D_FC1_NP, D_FC1_CPL, D_FC2_P, D_FC2_NP, D_FC2_CPL: if (dl_init1 || dl_init2) begin
              if ((t & 8'h70) == 8'h60 && !fc1_seen[2]) begin           // Cpl credits
                cpl_inf_h <= hf == 8'h0; cpl_inf_d <= df == 12'h0; cpl_lim_h <= hf; cpl_lim_d <= df;
              end
              fc1_seen[((t & 8'h70) == 8'h40) ? 0 : ((t & 8'h70) == 8'h50) ? 1 : 2] <= 1'b1;
              if (dl_init2 && t[7]) begin dl_init2 <= 1'b0; dl_active <= 1'b1; dl_up <= 1'b1; end
            end
            D_UFC_P, D_UFC_NP, D_UFC_CPL: begin
              if (dl_init2) begin dl_init2 <= 1'b0; dl_active <= 1'b1; dl_up <= 1'b1; end
              if ((t & 8'hF0) == D_UFC_CPL) begin
                if (!cpl_inf_h) cpl_lim_h <= hf;
                if (!cpl_inf_d) cpl_lim_d <= df;
              end
            end
            D_ACK, D_NAK: if (dl_active) begin
              // valid when ackd_seq < s < next_tx_seq (mod 4096)
              if (s != ackd_seq && !(seq_le(12'(ackd_seq + 12'd1), s) && seq_le(s, 12'(next_tx_seq - 12'd1)))) begin
                err[8] <= 1'b1;
              end else begin
                if (s != ackd_seq) begin
                  // purge acknowledged entries
                  logic [5:0] f, n;
                  f = pfirst; n = pcount;
                  while (n != 0 && seq_le(pseq[f], s)) begin f = f + 6'd1; n = n - 6'd1; end
                  pfirst <= f; pcount <= n;
                  ackd_seq <= s; replay_num <= '0; replay_timer <= '0;
                end
                if (t == D_NAK) replay_req <= 1'b1;
              end
            end
            default: ;
          endcase
        end
      end
      if (dl_init1 && fc1_seen == 3'b111) begin dl_init1 <= 1'b0; dl_init2 <= 1'b1; fc_tx_idx <= '0; end

      // ================= received TLPs =================
      if (rx_valid && rx_sop) begin rn <= '0; rcrc <= '1; rx_in <= 1'b1; end
      if (rx_valid && (rx_sop || rx_in)) begin : rcv
        logic [12:0] n;
        logic [31:0] cr;
        n  = rx_sop ? 13'd0 : rn;
        cr = crc32_byte(rx_sop ? 32'hFFFFFFFF : rcrc, rx_data);
        if (n < 13'd4200) rb[n] = rx_data;
        rn <= n + 13'd1;
        rcrc <= cr;
        if (rx_eop) begin
          rx_in <= 1'b0;
          if (dl_init2 && link_up) begin dl_init2 <= 1'b0; dl_active <= 1'b1; dl_up <= 1'b1; end
          if ((dl_active || dl_init2) && link_up) begin
            logic [11:0] sq;
            sq = {rb[0][3:0], rb[1]};
            if (cr != RESIDUE || n < 13'd17) begin
              err[0] <= 1'b1;
              if (!nak_sched) begin nak_sched <= 1'b1; ack_pend <= 1'b0; end
            end else if (sq == next_rcv_seq) begin
              next_rcv_seq <= next_rcv_seq + 12'd1;
              nak_sched <= 1'b0; ack_pend <= 1'b1;
              tl_receive(n + 13'd1 - 13'd6);
            end else if (seq_le(sq, 12'(next_rcv_seq - 12'd1))) begin
              ack_pend <= 1'b1;                              // duplicate: ACK, drop
            end else begin
              err[9] <= 1'b1;
              if (!nak_sched) begin nak_sched <= 1'b1; ack_pend <= 1'b0; end
            end
          end
        end
      end

      // ================= credit release / UpdateFC =================
      if (rel_rd != rel_wr && 16'(now - rel_t[rel_rd]) < 16'h8000) begin
        if (rel_np[rel_rd]) begin alc_nph <= alc_nph + 8'd1; alc_npd <= alc_npd + rel_d[rel_rd]; ufc_np <= 1'b1; end
        else begin alc_ph <= alc_ph + 8'd1; alc_pd <= alc_pd + rel_d[rel_rd]; ufc_p <= 1'b1; end
        rel_rd <= rel_rd + 4'd1;
      end

      // ================= DLLP transmit (one per clock) =================
      if (link_up) begin
        if (nak_sched && !dllp_sent && dl_active) begin : snak
          if (ack_pend == 1'b0) begin
            tx_dllp <= mk_dllp({D_NAK, 8'h00, 4'h0, 12'(next_rcv_seq - 12'd1)});
            tx_dllp_valid <= 1'b1; dllp_sent = 1'b1; ack_pend <= 1'b1;   // once per NAK_SCHEDULED
          end
        end
        if (ack_pend && !nak_sched && !dllp_sent && dl_active) begin
          tx_dllp <= mk_dllp({D_ACK, 8'h00, 4'h0, 12'(next_rcv_seq - 12'd1)});
          tx_dllp_valid <= 1'b1; dllp_sent = 1'b1; ack_pend <= 1'b0;
        end
        if (!dllp_sent && dl_active && ufc_p) begin
          tx_dllp <= mk_fc(D_UFC_P, alc_ph, alc_pd); tx_dllp_valid <= 1'b1; dllp_sent = 1'b1; ufc_p <= 1'b0;
        end
        if (!dllp_sent && dl_active && ufc_np) begin
          tx_dllp <= mk_fc(D_UFC_NP, alc_nph, alc_npd); tx_dllp_valid <= 1'b1; dllp_sent = 1'b1; ufc_np <= 1'b0;
        end
        if (!dllp_sent && (dl_init1 || dl_init2) && now[1:0] == 2'b00) begin
          logic [7:0] tb;
          tb = (fc_tx_idx == 2'd0) ? D_FC1_P : (fc_tx_idx == 2'd1) ? D_FC1_NP : D_FC1_CPL;
          if (dl_init2) tb = tb | 8'h80;
          tx_dllp <= (fc_tx_idx == 2'd0) ? mk_fc(tb, 8'(PH), 12'(PD)) :
                     (fc_tx_idx == 2'd1) ? mk_fc(tb, 8'(NPH), 12'(NPD)) : mk_fc(tb, 8'h00, 12'h000);
          tx_dllp_valid <= 1'b1; dllp_sent = 1'b1;
          fc_tx_idx <= (fc_tx_idx == 2'd2) ? 2'd0 : fc_tx_idx + 2'd1;
        end
      end

      // ================= replay timer =================
      if (pcount != 0 && !tx_replay && dl_active) begin
        replay_timer <= replay_timer + 12'd1;
        if (replay_timer == 12'(REPLAY_TIMEOUT)) begin err[3] <= 1'b1; replay_req <= 1'b1; replay_timer <= '0; end
      end else if (pcount == 0) replay_timer <= '0;

      // ================= TLP transmit =================
      tx_valid <= 1'b0; tx_sop <= 1'b0; tx_eop <= 1'b0;
      if (!tx_busy && replay_req && link_up && ls == L_L0) begin
        replay_req <= 1'b0;
        if (pcount != 0) begin
          if (replay_num == 2'd3) begin err[2] <= 1'b1; go_recovery <= 1'b1; end
          replay_num <= replay_num + 2'd1;
          rp_idx <= pfirst; rp_left <= pcount; tx_replay <= 1'b1; replay_timer <= '0;
        end
      end else if (!tx_busy && tx_replay) begin
        if (rp_left == 0) tx_replay <= 1'b0;
        else begin
          tx_busy <= 1'b1; tx_pos <= '0; tx_len <= pl[rp_idx]; tx_src <= ps[rp_idx];
          rp_idx <= rp_idx + 6'd1; rp_left <= rp_left - 6'd1;
        end
      end else if (!tx_busy && dl_active && ls == L_L0 && qlr != qlw && pcount < 6'd60 &&
                   seq_le(12'(next_tx_seq - ackd_seq), 12'd2047)) begin : newtlp
        logic [12:0] blen;
        logic [9:0]  dw;
        logic        hok, dok;
        blen = ql[qlr];
        dw   = {qb[14'(qrd + 14'd2)][1:0], qb[14'(qrd + 14'd3)]};
        hok  = cpl_inf_h || 8'(cpl_lim_h - cpl_cons_h - 8'd1) < 8'd128;
        dok  = cpl_inf_d || (blen == 13'd12) || 12'(cpl_lim_d - cpl_cons_d - 12'((12'(dw) + 12'd3) >> 2)) < 12'd2048;
        if (hok && dok) begin
          cpl_cons_h <= cpl_cons_h + 8'd1;
          if (blen != 13'd12) cpl_cons_d <= cpl_cons_d + 12'((12'(dw) + 12'd3) >> 2);
          // record in the replay buffer: seq bytes, body, LCRC (written while sending)
          ps[6'(pfirst + pcount)] <= pwr; pl[6'(pfirst + pcount)] <= blen + 13'd6;
          pseq[6'(pfirst + pcount)] <= next_tx_seq;
          pcount <= pcount + 6'd1;
          tx_busy <= 1'b1; tx_replay <= 1'b0; tx_pos <= '0; tx_len <= blen + 13'd6; tx_src <= pwr;
          next_tx_seq <= next_tx_seq + 12'd1;
          // build the framed TLP into the replay buffer now
          c = 32'hFFFFFFFF;
          pb[pwr] <= {4'h0, next_tx_seq[11:8]};               c = crc32_byte(c, {4'h0, next_tx_seq[11:8]});
          pb[14'(pwr + 14'd1)] <= next_tx_seq[7:0];          c = crc32_byte(c, next_tx_seq[7:0]);
          for (int i = 0; i < blen; i++) begin
            pb[14'(pwr + 14'd2 + 14'(i))] <= qb[14'(qrd + 14'(i))];
            c = crc32_byte(c, qb[14'(qrd + 14'(i))]);
          end
          c = ~c;
          for (int i = 0; i < 4; i++) pb[14'(pwr + 14'd2 + 14'(blen) + 14'(i))] <= c[8 * i +: 8];
          pwr <= 14'(pwr + 14'(blen) + 14'd6);
          qrd <= 14'(qrd + 14'(blen)); qlr <= qlr + 8'd1;
        end
      end
      if (tx_busy) begin
        tx_valid <= 1'b1; tx_sop <= tx_pos == 13'd0; tx_eop <= tx_pos == tx_len - 13'd1;
        tx_data <= pb[14'(tx_src + 14'(tx_pos))];
        tx_pos <= tx_pos + 13'd1;
        if (tx_pos == tx_len - 13'd1) tx_busy <= 1'b0;
      end
    end
  end

  // ------------------------------------------------------------------ TL receive
  // n = TLP length in bytes (sequence number and LCRC removed); TLP at rb[2..]
  task automatic tl_receive(input logic [12:0] n);
    logic [2:0]  fmt;
    logic [4:0]  typ;
    logic [9:0]  len;
    int          ldw, hdr, plen;
    logic        ep_, posted, np, malformed;
    logic [15:0] rid;
    logic [7:0]  tag;
    logic [3:0]  fbe, lbe;
    logic [31:0] addr;
    logic [11:0] dcred;
    fmt = rb[2][7:5]; typ = rb[2][4:0];
    len = {rb[4][1:0], rb[5]};
    ldw = (len == 10'd0) ? 1024 : len;
    ep_ = rb[4][6];
    hdr = fmt[0] ? 16 : 12;
    plen = int'(n) - hdr;
    rid = {rb[6], rb[7]}; tag = rb[8]; lbe = rb[9][7:4]; fbe = rb[9][3:0];
    addr = fmt[0] ? {rb[14], rb[15], rb[16], rb[17][7:2], 2'b00} : {rb[10], rb[11], rb[12], rb[13][7:2], 2'b00};
    posted = (fmt[1] && typ == 5'b00000) || typ[4:3] == 2'b10;
    np = !posted && (typ != 5'b01010);
    dcred = fmt[1] ? 12'((ldw + 3) / 4) : 12'd0;
    malformed = fmt[1] ? (plen != 4 * ldw) : (plen != 0);
    // receiver overflow (credits the partner was not given)
    if (posted) begin
      if (8'(rcv_ph + 8'd1 - alc_ph) != 8'd0 && 8'(rcv_ph + 8'd1 - alc_ph) < 8'd128) begin err[4] <= 1'b1; return; end
      if (12'(rcv_pd + dcred - alc_pd) != 12'd0 && 12'(rcv_pd + dcred - alc_pd) < 12'd2048) begin err[4] <= 1'b1; return; end
      rcv_ph <= rcv_ph + 8'd1; rcv_pd <= rcv_pd + dcred;
    end else if (np) begin
      if (8'(rcv_nph + 8'd1 - alc_nph) != 8'd0 && 8'(rcv_nph + 8'd1 - alc_nph) < 8'd128) begin err[4] <= 1'b1; return; end
      if (12'(rcv_npd + dcred - alc_npd) != 12'd0 && 12'(rcv_npd + dcred - alc_npd) < 12'd2048) begin err[4] <= 1'b1; return; end
      rcv_nph <= rcv_nph + 8'd1; rcv_npd <= rcv_npd + dcred;
    end
    if (posted || np) begin
      rel_np[rel_wr] <= np; rel_d[rel_wr] <= dcred; rel_t[rel_wr] <= now + 16'(CRED_LAT); rel_wr <= rel_wr + 4'd1;
    end
    if (malformed) begin err[5] <= 1'b1; return; end
    if (ep_ && fmt[1]) begin err[6] <= 1'b1; if (posted) return; end
    // ---------------- requests
    if (typ == 5'b00000 && !fmt[0]) begin                      // MRd32 / MWr32
      logic hit;
      hit = cfg[1][1] && addr[31:12] == cfg[4][31:12];
      if (fmt[1]) begin
        if (!hit) begin err[7] <= 1'b1; return; end
        for (int i = 0; i < 4 * ldw; i++) begin
          logic [3:0] be;
          be = (i < 4) ? fbe : (i >= 4 * ldw - 4) ? lbe : 4'hF;
          if (ldw == 1) be = fbe;
          if (be[i % 4]) mem[12'(addr[11:0] + 12'(i))] = rb[hdr + 2 + i];
        end
      end else if (!hit) begin
        err[7] <= 1'b1;
        q_cpl(rid, tag, 3'b001, 12'd0, addr[6:0], 0, 12'd0, 1'b0, 32'h0);
      end else begin
        // byte count from the byte enables; completions split at 64-byte boundaries
        int first_off, last_off, total, sent, a, e;
        first_off = 0;
        if (fbe != 0) while (!fbe[first_off]) first_off++;
        last_off = 3;
        if (ldw == 1) begin
          if (fbe != 0) while (!fbe[last_off]) last_off--;
          total = (fbe == 0) ? 1 : last_off - first_off + 1;
        end else begin
          while (!lbe[last_off] && last_off > 0) last_off--;
          total = 4 * ldw - first_off - (3 - last_off);
        end
        a = addr[11:0]; e = addr[11:0] + 4 * ldw; sent = 0;
        while (a < e) begin
          int nb, ndw;
          nb = ((a / 64) + 1) * 64;
          if (nb > e) nb = e;
          ndw = (nb - a) / 4;
          q_cpl(rid, tag, 3'b000, 12'(total - sent), (sent == 0) ? 7'(a + first_off) : 7'(a), ndw, 12'(a), 1'b0, 32'h0);
          sent = (sent == 0) ? (nb - a - first_off) : sent + (nb - a);
          a = nb;
        end
      end
    end else if (typ == 5'b00100 && !fmt[0]) begin             // CfgRd0 / CfgWr0
      logic [5:0] r;
      r = rb[13][7:2];
      if (rb[12][3:0] != 4'h0) r = 6'h3F;                        // extended space reads as zero
      if (fmt[1]) begin
        logic [31:0] w, d;
        d = {rb[hdr + 5], rb[hdr + 4], rb[hdr + 3], rb[hdr + 2]};
        w = cfg[r];
        for (int b = 0; b < 4; b++) if (fbe[b]) w[8 * b +: 8] = d[8 * b +: 8];
        if (r == 6'd0) w = cfg[0];                                // IDs read-only
        else if (r == 6'd1) w = {16'h0, 13'h0, w[2:0]};           // Command: IO/Mem/BusMaster
        else if (r == 6'd4) w = {w[31:12], 12'h000};              // BAR0: 4 KB, 32-bit memory
        else if (r == 6'h3F) w = 32'h0;
        cfg[r] = w;
        my_id = {rb[10], rb[11][7:3], 3'b000};                    // bus / device captured
        q_cpl(rid, tag, 3'b000, 12'd0, 7'd0, 0, 12'd0, 1'b0, 32'h0);
      end else begin
        my_id = (my_id == 16'h0) ? {rb[10], rb[11][7:3], 3'b000} : my_id;
        q_cpl(rid, tag, 3'b000, 12'd4, 7'd0, 1, 12'd0, 1'b1, (r == 6'd0) ? 32'h5678_1234 : cfg[r]);
      end
    end else if (np) begin                                        // other non-posted: UR
      err[7] <= 1'b1;
      q_cpl(rid, tag, 3'b001, 12'd0, 7'd0, 0, 12'd0, 1'b0, 32'h0);
    end else if (typ[4:3] != 2'b10) begin
      err[7] <= 1'b1;                                             // other posted (messages are ignored)
    end
  endtask
endmodule
