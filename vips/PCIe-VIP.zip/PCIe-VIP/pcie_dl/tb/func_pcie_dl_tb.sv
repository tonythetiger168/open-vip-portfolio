// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator
//
// func_pcie_dl_tb.sv -- link partner (root port) for pcie_dl_model, written
// from the PCIe base specification rules, not from the model:
//   * LTSSM: Detect -> Polling.Active -> Polling.Configuration ->
//     Configuration -> L0 with the ordered-set counts, Polling timeout,
//     Recovery entered from L0 by TS1 and by a REPLAY_NUM rollover, EIOS
//   * DLL: InitFC1/InitFC2 handshake and advertised credits, ACK / NAK of
//     good, corrupted, out-of-sequence and duplicate TLPs, NAK_SCHEDULED,
//     replay on NAK and on replay-timer expiry, REPLAY_NUM rollover, ACK
//     purge, bad DLLP CRC, out-of-range ACK
//   * FC: UpdateFC after credits are freed, receiver overflow, completion
//     gating by finite Cpl credits
//   * TL: config space (IDs, Command, BAR0 masks, completer ID capture),
//     memory writes with byte enables, reads split at 64-byte RCB
//     boundaries with Byte Count / Lower Address, UR / poisoned / malformed
module func_pcie_dl_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0, rx_det = 0;
  logic rx_os_valid = 0;
  logic [1:0] rx_os = 0;
  logic rx_valid = 0, rx_sop = 0, rx_eop = 0;
  logic [7:0] rx_data = 0;
  logic rx_dllp_valid = 0;
  logic [47:0] rx_dllp = 0;
  wire tx_os_valid, tx_valid, tx_sop, tx_eop, tx_dllp_valid, link_up, dl_up;
  wire [1:0] tx_os;
  wire [7:0] tx_data;
  wire [47:0] tx_dllp;
  wire [3:0] ltssm;
  wire [9:0] err;
  always #5 clk = ~clk;

  pcie_dl_model #(.CRED_LAT(200)) u_dut (.clk, .rst_n, .rx_det, .rx_os_valid, .rx_os, .tx_os_valid, .tx_os,
                       .rx_valid, .rx_sop, .rx_eop, .rx_data, .rx_dllp_valid, .rx_dllp,
                       .tx_valid, .tx_sop, .tx_eop, .tx_data, .tx_dllp_valid, .tx_dllp,
                       .ltssm, .link_up, .dl_up, .err);

  // ------------------------------------------------------------ references
  // LCRC: CRC-32 (x^32+x^26+...+1), MSB-first register on bit-reversed data,
  // equivalent to the IEEE 802.3 FCS computation
  function automatic logic [31:0] crc32_msb(input logic [31:0] c, input logic [7:0] d);
    for (int i = 0; i < 8; i++) c = (c[31] ^ d[i]) ? ((c << 1) ^ 32'h04C11DB7) : (c << 1);
    return c;
  endfunction
  function automatic logic [31:0] bitrev32(input logic [31:0] x);
    for (int i = 0; i < 32; i++) bitrev32[i] = x[31 - i];
  endfunction
  // DLLP CRC-16, polynomial 100Bh
  function automatic logic [15:0] crc16(input logic [31:0] b);
    logic [15:0] c;
    c = '1;
    for (int k = 3; k >= 0; k--)
      for (int i = 0; i < 8; i++) begin
        logic fb;
        fb = c[15] ^ b[8 * k + i];
        c = {c[14:0], 1'b0};
        if (fb) c = c ^ 16'h100B;
      end
    return ~c;
  endfunction
  function automatic logic [47:0] dllp(input logic [7:0] t, input logic [23:0] body);
    return {t, body, crc16({t, body})};
  endfunction
  function automatic logic [47:0] fc(input logic [7:0] t, input int h, input int d);
    logic [7:0] hh; logic [11:0] dd;
    hh = h; dd = d;
    return dllp(t, {2'b00, hh, 2'b00, dd});
  endfunction

  // ------------------------------------------------------------ partner link layer
  // ordered sets: follow the model with one clock of delay (a cooperative partner),
  // or force a pattern
  int os_mode = 0;                 // 0 silent, 1 follow, 2 force os_force
  logic [1:0] os_force = 0;
  always @(posedge clk) begin
    rx_os_valid <= (os_mode == 1) ? tx_os_valid : (os_mode == 2);
    rx_os       <= (os_mode == 1) ? tx_os : os_force;
  end
  // LTSSM trace
  logic [3:0] ls_p = 0;
  logic [3:0] ls_trace [0:63];
  int nls = 0, ts1_sent = 0, ts2_sent = 0, idle_sent = 0;
  int ts1_at_exit = -1, ts2_at_exit = -1;
  always @(posedge clk) begin
    if (tx_os_valid && tx_os == 2'd0) ts1_sent++;
    if (tx_os_valid && tx_os == 2'd1) ts2_sent++;
    if (tx_os_valid && tx_os == 2'd2) idle_sent++;
    if (ltssm != ls_p) begin
      if (nls < 64) ls_trace[nls] = ltssm;
      nls++;
      if (ls_p == 4'd1) ts1_at_exit = ts1_sent;
      if (ls_p == 4'd2) ts2_at_exit = ts2_sent;
    end
    ls_p <= ltssm;
  end

  // DLLPs from the model
  logic [47:0] dq [0:8191];
  int nd = 0, bad_dcrc = 0;
  always @(posedge clk) if (tx_dllp_valid) begin
    if (crc16(tx_dllp[47:16]) != tx_dllp[15:0]) bad_dcrc++;
    dq[nd % 8192] = tx_dllp; nd++;
  end
  // DLLPs to the model: one per clock from a queue
  logic [47:0] dout [$];
  always @(negedge clk) begin
    rx_dllp_valid <= 1'b0;
    if (dout.size() > 0) begin rx_dllp <= dout.pop_front(); rx_dllp_valid <= 1'b1; end
  end

  // TLPs from the model: framing, LCRC, sequence, auto-ACK
  logic [7:0] mb [0:131071];
  int mstart [0:2047], mlen [0:2047];
  bit mcrc_ok [0:2047];
  int nm = 0, mw = 0, cur = 0;
  bit auto_ack = 1;
  logic [31:0] mcrc;
  bit in_frame = 0;
  int stray_tx = 0;
  always @(posedge clk) begin
    if (tx_valid && !tx_sop && !in_frame) stray_tx++;
    if (tx_valid && tx_sop) in_frame = 1;
    if (tx_valid && tx_eop) in_frame = 0;
  end
  always @(posedge clk) if (tx_valid) begin
    if (tx_sop) begin cur = mw; mcrc = '1; end
    mb[mw % 131072] = tx_data; mw++;
    if (tx_eop) begin
      // LCRC check over seq + TLP; the transmitted LCRC is the complement, LSB byte first
      logic [31:0] c, l;
      c = '1;
      for (int i = cur; i < mw - 4; i++) c = crc32_msb(c, mb[i % 131072]);
      l = {mb[(mw - 1) % 131072], mb[(mw - 2) % 131072], mb[(mw - 3) % 131072], mb[(mw - 4) % 131072]};
      mstart[nm % 2048] = cur; mlen[nm % 2048] = mw - cur;
      mcrc_ok[nm % 2048] = (l == ~bitrev32(c));
      if (auto_ack) dout.push_back(dllp(8'h00, {12'h0, mb[cur % 131072][3:0], mb[(cur + 1) % 131072]}));
      nm++;
    end
  end
  function automatic logic [7:0] mbyte(input int t, input int i); return mb[(mstart[t] + i) % 131072]; endfunction
  function automatic logic [11:0] mseq(input int t);
    logic [7:0] b0;
    b0 = mbyte(t, 0);
    return {b0[3:0], mbyte(t, 1)};
  endfunction

  // TLPs to the model
  logic [7:0] tb_tlp [0:4199];
  int tb_n;
  logic [11:0] pseq = 0;
  task automatic hdr3(input logic [7:0] fmt_type, input int len, input logic ep, input logic [15:0] rid,
                      input logic [7:0] tag, input logic [3:0] lbe, input logic [3:0] fbe, input logic [31:0] dw2);
    logic [9:0] l;
    l = len;
    tb_tlp[0] = fmt_type; tb_tlp[1] = 8'h00; tb_tlp[2] = {1'b0, ep, 4'h0, l[9:8]}; tb_tlp[3] = l[7:0];
    tb_tlp[4] = rid[15:8]; tb_tlp[5] = rid[7:0]; tb_tlp[6] = tag; tb_tlp[7] = {lbe, fbe};
    tb_tlp[8] = dw2[31:24]; tb_tlp[9] = dw2[23:16]; tb_tlp[10] = dw2[15:8]; tb_tlp[11] = dw2[7:0];
    tb_n = 12;
  endtask
  // frame and send tb_tlp[0..tb_n-1]; corrupt flips an LCRC bit
  task automatic send(input logic [11:0] seq, input bit corrupt = 0);
    logic [7:0] f [0:4205];
    logic [31:0] c, l;
    int n;
    f[0] = {4'h0, seq[11:8]}; f[1] = seq[7:0];
    for (int i = 0; i < tb_n; i++) f[2 + i] = tb_tlp[i];
    c = '1;
    for (int i = 0; i < tb_n + 2; i++) c = crc32_msb(c, f[i]);
    l = ~bitrev32(c);
    if (corrupt) l[5] = !l[5];
    for (int i = 0; i < 4; i++) f[tb_n + 2 + i] = l[8 * i +: 8];
    n = tb_n + 6;
    for (int i = 0; i < n; i++) begin
      @(negedge clk);
      rx_valid = 1; rx_sop = (i == 0); rx_eop = (i == n - 1); rx_data = f[i];
    end
    @(negedge clk); rx_valid = 0; rx_sop = 0; rx_eop = 0;
  endtask
  task automatic send_next(input bit corrupt = 0);
    send(pseq, corrupt);
    if (!corrupt) pseq++;
  endtask
  localparam logic [15:0] RID = 16'h0100;
  task automatic cfgwr(input int reg_, input logic [31:0] d, input logic [3:0] be, input logic [7:0] tag);
    hdr3(8'h44, 1, 0, RID, tag, 4'h0, be, {8'h03, 5'd2, 3'd0, 4'h0, 4'h0, 6'(reg_), 2'b00});
    tb_tlp[12] = d[7:0]; tb_tlp[13] = d[15:8]; tb_tlp[14] = d[23:16]; tb_tlp[15] = d[31:24]; tb_n = 16;
    send_next();
  endtask
  task automatic cfgrd(input int reg_, input logic [7:0] tag);
    hdr3(8'h04, 1, 0, RID, tag, 4'h0, 4'hF, {8'h03, 5'd2, 3'd0, 4'h0, 4'h0, 6'(reg_), 2'b00});
    send_next();
  endtask
  task automatic mwr(input logic [31:0] a, input int len, input logic [3:0] fbe, input logic [3:0] lbe,
                     input logic [7:0] seed, input bit ep = 0, input int extra = 0);
    hdr3(8'h40, len, ep, RID, 8'h00, (len == 1) ? 4'h0 : lbe, fbe, a);
    for (int i = 0; i < 4 * len + extra; i++) tb_tlp[12 + i] = 8'(seed + i);
    tb_n = 12 + 4 * len + extra;
  endtask
  task automatic mrd(input logic [31:0] a, input int len, input logic [3:0] fbe, input logic [3:0] lbe,
                     input logic [7:0] tag);
    hdr3(8'h00, len, 0, RID, tag, (len == 1) ? 4'h0 : lbe, fbe, a);
  endtask

  // shadow memory of the partner's own writes (expected memory contents)
  logic [7:0] shadow [0:4095];
  task automatic shadow_wr(input logic [31:0] a, input int len, input logic [3:0] fbe, input logic [3:0] lbe,
                           input logic [7:0] seed);
    for (int i = 0; i < 4 * len; i++) begin
      logic [3:0] be;
      be = (len == 1 || i < 4) ? fbe : (i >= 4 * len - 4) ? lbe : 4'hF;
      if (be[i % 4]) shadow[(a[11:0] + i) % 4096] = 8'(seed + i);
    end
  endtask

  task automatic wait_clk(input int n); repeat (n) @(negedge clk); endtask
  // let the model free the credits of everything sent so far (CRED_LAT 200)
  task automatic settle(); wait_clk(230); endtask
  task automatic wait_tlps(input int n, input int maxc = 400);
    int c;
    c = 0;
    while (nm < n && c < maxc) begin @(negedge clk); c++; end
  endtask
  // index of the last DLLP of type t (masked) since index from, -1 if none
  function automatic int find_dllp(input logic [7:0] t, input logic [7:0] m, input int from);
    for (int i = nd - 1; i >= from; i--) if ((dq[i % 8192][47:40] & m) == t) return i;
    return -1;
  endfunction
  function automatic int count_dllp(input logic [7:0] t, input logic [7:0] m, input int from);
    int n;
    n = 0;
    for (int i = from; i < nd; i++) if ((dq[i % 8192][47:40] & m) == t) n++;
    return n;
  endfunction

  // link up and FC init with the given partner Cpl credits
  task automatic bring_up(input int cplh, input int cpld);
    int d0, ds;
    ds = nd;
    rx_det = 1; os_mode = 1;
    begin
      int c;
      c = 0;
      while (ltssm != 4'd4 && c < 600) begin @(negedge clk); c++; end
    end
    d0 = nd;
    wait_clk(40);
    chk(count_dllp(8'h40, 8'hF8, d0) > 0 && count_dllp(8'h50, 8'hF8, d0) > 0 && count_dllp(8'h60, 8'hF8, d0) > 0,
        "InitFC1 P, NP and Cpl sent in DL_Init");
    chk(!dl_up, "DL not up before the partner's InitFC");
    begin
      int i;
      i = find_dllp(8'h40, 8'hF8, d0);
      chk(i >= 0 && dq[i % 8192][39:16] == {2'b00, 8'd4, 2'b00, 12'd32}, "InitFC1-P advertises PH 4 / PD 32");
      i = find_dllp(8'h50, 8'hF8, d0);
      chk(i >= 0 && dq[i % 8192][39:16] == {2'b00, 8'd4, 2'b00, 12'd4}, "InitFC1-NP advertises NPH 4 / NPD 4");
      i = find_dllp(8'h60, 8'hF8, d0);
      chk(i >= 0 && dq[i % 8192][39:16] == 24'h0, "InitFC1-Cpl advertises infinite completion credits");
    end
    dout.push_back(fc(8'h40, 16, 256)); dout.push_back(fc(8'h50, 16, 16)); dout.push_back(fc(8'h60, cplh, cpld));
    d0 = nd;
    wait_clk(40);
    chk(count_dllp(8'hC0, 8'hF8, d0) > 0 && count_dllp(8'hE0, 8'hF8, d0) > 0, "InitFC2 sent after all InitFC1 received");
    chk(count_dllp(8'h40, 8'hF8, d0 + 3) == 0, "no InitFC1 after FC_INIT2 starts");
    chk(!dl_up, "DL not up until an InitFC2 is received");
    dout.push_back(fc(8'hC0, 16, 256)); dout.push_back(fc(8'hD0, 16, 16)); dout.push_back(fc(8'hE0, cplh, cpld));
    wait_clk(10);
    chk(dl_up === 1'b1, "DL_Active after the partner's InitFC2");
    wait_clk(20);
    chk(count_dllp(8'h00, 8'hEF, ds) == 0, "no ACK / NAK before any TLP");
  endtask
  // bring-up variant: the partner sends InitFC2 already in FC_INIT1 (recorded
  // like InitFC1), then InitFC1 again (ignored for FI2), then a TLP, which
  // completes FC_INIT2
  task automatic bring_up_tlp(input int cplh, input int cpld);
    int d0, n0;
    rx_det = 1; os_mode = 1;
    begin
      int c;
      c = 0;
      while (ltssm != 4'd4 && c < 600) begin @(negedge clk); c++; end
    end
    wait_clk(20);
    d0 = nd;
    dout.push_back(fc(8'hC0, 16, 256)); dout.push_back(fc(8'hD0, 16, 16)); dout.push_back(fc(8'hE0, cplh, cpld));
    wait_clk(40);
    chk(count_dllp(8'hC0, 8'hF8, d0) > 0 && !dl_up, "InitFC2 received in FC_INIT1: model moves to FC_INIT2, DL not up yet");
    dout.push_back(fc(8'h40, 16, 256)); dout.push_back(fc(8'h50, 16, 16));
    wait_clk(20);
    chk(!dl_up, "InitFC1 received in FC_INIT2 does not complete it");
    chk(count_dllp(8'h00, 8'hEF, d0) == 0, "no ACK / NAK after the link-down reset");
    d0 = nd;
    mwr(32'h8000_0800, 1, 4'hF, 4'h0, 8'h77); send_next();
    wait_clk(10);
    chk(dl_up === 1'b1 && find_dllp(8'h00, 8'hFF, d0) >= 0 && dq[find_dllp(8'h00, 8'hFF, d0) % 8192][27:16] == 12'd0,
        "a TLP received in FC_INIT2 completes it and is ACKed");
  endtask

  // completion field checks for model TLP t
  function automatic bit is_cpl(input int t, input logic [2:0] st, input logic [11:0] bc, input logic [6:0] la,
                                input int ndw, input logic [7:0] tag);
    logic [9:0] l;
    logic [7:0] b4, b8, b13;
    b4 = mbyte(t, 4); b8 = mbyte(t, 8); b13 = mbyte(t, 13);
    l = {b4[1:0], mbyte(t, 5)};
    return mbyte(t, 2) == (ndw ? 8'h4A : 8'h0A) && l == 10'(ndw) && b8[7:5] == st &&
           {b8[3:0], mbyte(t, 9)} == bc && b13[6:0] == la && mbyte(t, 12) == tag &&
           {mbyte(t, 10), mbyte(t, 11)} == RID && mlen[t % 2048] == 2 + 12 + 4 * ndw + 4;
  endfunction

  // ------------------------------------------------------------ test
  initial begin
    int t0, d0, n0;
    logic [11:0] s0;
    for (int i = 0; i < 4096; i++) shadow[i] = 8'h00;
    repeat (3) @(negedge clk);
    rst_n = 1;

    // ---- Polling timeout without a partner
    rx_det = 1; os_mode = 0;
    wait_clk(10);
    chk(ltssm == 4'd1 && tx_os_valid && tx_os == 2'd0, "Polling.Active sends TS1 after receiver detect");
    wait_clk(2100);
    chk(ltssm == 4'd0 || ltssm == 4'd1, "Polling times out to Detect without a partner");
    chk(nls >= 3 && ls_trace[1] == 4'd0, "LTSSM left Polling.Active for Detect on timeout");
    rx_det = 0;
    t0 = 0;
    while (ltssm != 4'd0 && t0 < 2100) begin @(negedge clk); t0++; end
    wait_clk(20);
    chk(ltssm == 4'd0 && !link_up, "Detect.Quiet holds without receiver detect");

    // ---- training to L0
    nls = 0; ts1_sent = 0; ts2_sent = 0;
    bring_up(0, 0);
    chk(nls >= 4 && ls_trace[0] == 4'd1 && ls_trace[1] == 4'd2 && ls_trace[2] == 4'd3 && ls_trace[3] == 4'd4,
        "LTSSM Detect -> Polling.Active -> Polling.Configuration -> Configuration -> L0");
    chk(ts1_at_exit >= 16, $sformatf("at least 16 TS1 sent before Polling.Configuration (%0d)", ts1_at_exit));
    chk(ts2_at_exit >= 16, $sformatf("at least 16 TS2 sent in Polling.Configuration (%0d)", ts2_at_exit));
    chk(link_up && !tx_os_valid, "L0: link up, no training ordered sets");

    // ---- configuration
    cfgrd(0, 8'h01);
    wait_tlps(1);
    chk(nm == 1 && mcrc_ok[0] && mseq(0) == 12'd0, "first TLP from the model: seq 0, good LCRC");
    chk(is_cpl(0, 3'b000, 12'd4, 7'd0, 1, 8'h01), "CfgRd0 completes with 1 DW, byte count 4");
    chk({mbyte(0, 6), mbyte(0, 7)} == {8'h03, 5'd2, 3'd0}, "completer ID captured from the configuration request");
    chk({mbyte(0, 17), mbyte(0, 16), mbyte(0, 15), mbyte(0, 14)} == 32'h5678_1234, "Vendor / Device ID");
    cfgwr(4, 32'h8000_0FFF, 4'hF, 8'h02);
    cfgwr(1, 32'hFFFF_FFFF, 4'hF, 8'h03);
    cfgwr(16, 32'hA5A5_5A5A, 4'b0101, 8'h04);
    settle();
    cfgrd(4, 8'h05); cfgrd(1, 8'h06); cfgrd(16, 8'h07);
    wait_tlps(7);
    chk(is_cpl(1, 3'b000, 12'd0, 7'd0, 0, 8'h02) && is_cpl(2, 3'b000, 12'd0, 7'd0, 0, 8'h03), "CfgWr0 completes without data");
    chk({mbyte(4, 17), mbyte(4, 16), mbyte(4, 15), mbyte(4, 14)} == 32'h8000_0000, "BAR0: 4 KB, low 12 bits read-only zero");
    chk({mbyte(5, 17), mbyte(5, 16), mbyte(5, 15), mbyte(5, 14)} == 32'h0000_0007, "Command: only IO / Memory / Bus Master writable");
    chk({mbyte(6, 17), mbyte(6, 16), mbyte(6, 15), mbyte(6, 14)} == 32'h00A5_005A, "CfgWr0 byte enables");
    chk(mseq(6) == 12'd6 && mcrc_ok[6], "completion sequence numbers increment");
    chk(count_dllp(8'h00, 8'hFF, 0) > 0 && dq[find_dllp(8'h00, 8'hFF, 0) % 8192][27:16] == 12'd6,
        "ACK carries the last received sequence number");

    // ---- memory write / read with byte enables and RCB splitting
    mwr(32'h8000_0020, 24, 4'hF, 4'hF, 8'h10); shadow_wr(32'h8000_0020, 24, 4'hF, 4'hF, 8'h10); send_next();
    mwr(32'h8000_0024, 1, 4'b0110, 4'h0, 8'hC0); shadow_wr(32'h8000_0024, 1, 4'b0110, 4'h0, 8'hC0); send_next();
    mwr(32'h8000_0074, 3, 4'b1000, 4'b0001, 8'h70); shadow_wr(32'h8000_0074, 3, 4'b1000, 4'b0001, 8'h70); send_next();
    settle();
    n0 = nm;
    mrd(32'h8000_0020, 24, 4'b1110, 4'b0011, 8'h20); send_next();
    wait_tlps(n0 + 2);
    chk(nm == n0 + 2, "96-byte read starting at 0x20 returns two completions (64-byte RCB)");
    chk(is_cpl(n0, 3'b000, 12'd93, 7'h21, 8, 8'h20), "first completion: 8 DW, byte count 93, lower address 0x21");
    chk(is_cpl(n0 + 1, 3'b000, 12'd62, 7'h40, 16, 8'h20), "second completion: 16 DW, remaining byte count 62, lower address 0x40");
    begin
      int bad;
      bad = 0;
      for (int i = 0; i < 32; i++) if (mbyte(n0, 14 + i) != shadow[12'h020 + i]) bad++;
      for (int i = 0; i < 64; i++) if (mbyte(n0 + 1, 14 + i) != shadow[12'h040 + i]) bad++;
      chk(bad == 0, $sformatf("read data matches the written bytes and byte enables (%0d bad)", bad));
    end
    hdr3(8'h34, 0, 0, RID, 8'h00, 4'h0, 4'h0, 32'h0); tb_tlp[12] = 0; tb_tlp[13] = 0; tb_tlp[14] = 0; tb_tlp[15] = 0;
    tb_n = 16; send_next();                                        // Msg (no data, local)
    wait_clk(8);
    chk(!err[7], "a Message TLP is accepted without error");
    begin                                                          // bytes outside a frame (no SOP)
      int d1;
      d1 = nd;
      for (int i = 0; i < 20; i++) begin
        @(negedge clk); rx_valid = 1; rx_sop = 0; rx_eop = (i == 19); rx_data = 8'(8'h3C + 7 * i);
      end
      @(negedge clk); rx_valid = 0; rx_eop = 0;
      wait_clk(8);
      chk(!err[0] && !err[9] && count_dllp(8'h10, 8'hFF, d1) == 0, "bytes without a start of TLP are ignored");
    end
    n0 = nm;
    mrd(32'h8000_0040, 1, 4'h0, 4'h0, 8'h23); send_next();
    wait_tlps(n0 + 1);
    chk(is_cpl(n0, 3'b000, 12'd1, 7'h40, 1, 8'h23), "zero-length read: one DW, byte count 1");
    n0 = nm;
    mrd(32'h8000_007C, 1, 4'b0100, 4'h0, 8'h21); send_next();
    wait_tlps(n0 + 1);
    chk(is_cpl(n0, 3'b000, 12'd1, 7'h7E, 1, 8'h21), "1-DW read with one byte enabled: byte count 1, lower address 0x7E");
    n0 = nm;
    mrd(32'h8000_0F80, 8, 4'hF, 4'hF, 8'h22); send_next();
    wait_tlps(n0 + 1);
    wait_clk(30);
    chk(nm == n0 + 1 && is_cpl(n0, 3'b000, 12'd32, 7'h00, 8, 8'h22), "read crossing no RCB boundary: one completion");
    settle();
    n0 = nm;
    wait_clk(800);
    chk(!err[3] && nm == n0, "everything ACKed: the replay timer does not expire while idle");
    begin
      int u;
      u = find_dllp(8'h90, 8'hF8, 0);
      chk(u >= 0 && {dq[u % 8192][37:32], dq[u % 8192][31:30]} == 8'd4 + 8'd11,
          "UpdateFC-NP returns the headers of the 11 non-posted requests so far");
    end

    // ---- unsupported and erroneous requests
    n0 = nm;
    mrd(32'h9000_0000, 1, 4'hF, 4'h0, 8'h30); send_next();
    wait_tlps(n0 + 1);
    chk(is_cpl(n0, 3'b001, 12'd0, 7'd0, 0, 8'h30) && err[7], "read outside BAR0: UR completion");
    hdr3(8'h42, 1, 0, RID, 8'h31, 4'h0, 4'hF, 32'h0000_0010); tb_tlp[12] = 0; tb_tlp[13] = 0; tb_tlp[14] = 0; tb_tlp[15] = 0;
    tb_n = 16; send_next();                                        // IOWr: non-posted, unsupported
    wait_tlps(n0 + 2);
    chk(is_cpl(n0 + 1, 3'b001, 12'd0, 7'd0, 0, 8'h31), "IOWr: UR completion");
    mwr(32'h8000_0100, 2, 4'hF, 4'hF, 8'h55, 1); send_next();       // poisoned
    mwr(32'h8000_0108, 2, 4'hF, 4'hF, 8'h66, 0, 4); send_next();    // payload longer than Length
    hdr3(8'h30, 0, 0, RID, 8'h00, 4'h0, 4'h0, 32'h0); tb_tlp[12] = 0; tb_tlp[13] = 0; tb_tlp[14] = 0; tb_tlp[15] = 0;
    tb_n = 16; send_next();                                        // Msg (no data): ignored
    n0 = nm;
    mrd(32'h8000_0100, 4, 4'hF, 4'hF, 8'h32); send_next();
    wait_tlps(n0 + 1);
    chk(err[6] && err[5], "poisoned and malformed TLPs flagged");
    chk(mbyte(n0, 14) == 8'h00 && mbyte(n0, 22) == 8'h00, "poisoned and malformed writes are dropped");
    settle();

    // ---- DLL receive: corrupted, out-of-sequence, duplicate
    d0 = nd; s0 = pseq;
    mwr(32'h8000_0200, 1, 4'hF, 4'h0, 8'hAA); send_next(1);         // bad LCRC
    wait_clk(8);
    chk(err[0], "bad LCRC flagged");
    chk(count_dllp(8'h10, 8'hFF, d0) == 1 && dq[find_dllp(8'h10, 8'hFF, d0) % 8192][27:16] == 12'(s0 - 1),
        "NAK with the last good sequence number");
    send(12'(s0 + 1));                                             // skips s0
    wait_clk(8);
    chk(count_dllp(8'h10, 8'hFF, d0) == 1 && err[9], "out-of-sequence TLP dropped, no second NAK while NAK_SCHEDULED");
    send(s0); pseq = s0 + 1;                                       // the replay
    wait_clk(8);
    chk(dq[find_dllp(8'h00, 8'hFF, d0) % 8192][27:16] == s0, "replayed TLP accepted and ACKed");
    mwr(32'h8000_0200, 1, 4'hF, 4'h0, 8'hBB); send(s0);             // duplicate sequence number, other data
    wait_clk(8);
    n0 = nm;
    mrd(32'h8000_0200, 1, 4'hF, 4'h0, 8'h33); send_next();
    wait_tlps(n0 + 1);
    chk(mbyte(n0, 14) == 8'hAA, "duplicate TLP ACKed but not executed");
    chk(dq[find_dllp(8'h00, 8'hFF, d0) % 8192][27:16] == pseq - 1, "ACK after the duplicate");
    settle();

    d0 = nd;
    send(12'(pseq + 2));                                           // ahead of sequence, no NAK pending
    wait_clk(8);
    chk(count_dllp(8'h10, 8'hFF, d0) == 1 && dq[find_dllp(8'h10, 8'hFF, d0) % 8192][27:16] == 12'(pseq - 1),
        "out-of-sequence TLP alone schedules a NAK");
    mwr(32'h8000_0204, 1, 4'hF, 4'h0, 8'hCC); send_next();
    wait_clk(8);
    chk(dq[find_dllp(8'h00, 8'hFF, d0) % 8192][27:16] == 12'(pseq - 1), "next in-sequence TLP clears NAK_SCHEDULED and is ACKed");
    settle();

    // ---- DLLP errors
    dout.push_back(dllp(8'h00, 24'h000123) ^ 48'h1);                // bad CRC
    dout.push_back(dllp(8'h00, 24'h000800));                        // ACK far outside the window
    wait_clk(6);
    chk(err[1] && err[8], "bad DLLP CRC and out-of-range ACK flagged");

    // ---- flow control: UpdateFC, receiver overflow
    d0 = nd;
    for (int i = 0; i < 3; i++) begin mwr(32'h8000_0300 + 4 * i, 1, 4'hF, 4'h0, 8'h01); send_next(); end
    wait_clk(40);
    chk(find_dllp(8'h80, 8'hF8, d0) < 0, "no UpdateFC-P before the credits are freed");
    wait_clk(220);
    begin
      int i;
      i = find_dllp(8'h80, 8'hF8, d0);
      chk(i >= 0, "UpdateFC-P after posted credits are freed");
    end
    // the model's credit limit is 4 + every freed header so far; send a burst
    // without waiting: one more header than the limit allows
    begin
      int u, lim, used;
      u = find_dllp(8'h80, 8'hF8, 0);
      lim = {dq[u % 8192][37:32], dq[u % 8192][31:30]};
      used = 0;
      // posted headers sent so far (all writes and the message above)
      used = 3 + 1 + 3 + 1 + 1 + 3;      // memory test, Msg, poisoned/malformed/Msg, replayed write, write after NAK, 3 above
      chk(lim == 4 + used, $sformatf("UpdateFC-P header limit %0d = initial 4 + %0d freed", lim, used));
      n0 = err[4];
      for (int i = 0; i < 5; i++) begin mwr(32'h8000_0400 + 4 * i, 1, 4'hF, 4'h0, 8'(8'h40 + i)); send_next(); end
      wait_clk(4);
      chk(err[4] && !n0, "a fifth posted TLP within the credit window: receiver overflow");
      n0 = nm;
      mrd(32'h8000_0400, 5, 4'hF, 4'hF, 8'h34); send_next();
      wait_tlps(n0 + 1);
      chk(mbyte(n0, 14 + 12) == 8'h43 && mbyte(n0, 14 + 16) == 8'h00, "the overflowing TLP is not executed");
    end
    settle();

    // ---- DLL transmit: NAK replay, timeout replay, rollover -> Recovery
    auto_ack = 0;
    n0 = nm;
    cfgrd(0, 8'h40);
    wait_tlps(n0 + 1);
    s0 = mseq(n0);
    dout.push_back(dllp(8'h10, {12'h0, 12'(s0 - 1)}));              // NAK: nothing acknowledged
    wait_tlps(n0 + 2);
    chk(nm == n0 + 2 && mseq(n0 + 1) == s0 && mlen[(n0 + 1) % 2048] == mlen[n0 % 2048], "NAK: TLP replayed with its sequence number");
    begin
      bit same;
      same = 1;
      for (int i = 0; i < mlen[n0 % 2048]; i++) if (mbyte(n0, i) != mbyte(n0 + 1, i)) same = 0;
      chk(same, "replayed TLP is bit-identical, LCRC included");
    end
    t0 = 0;
    while (nm < n0 + 3 && t0 < 1000) begin @(negedge clk); t0++; end
    chk(nm == n0 + 3 && err[3] && t0 > 600, $sformatf("replay timer expiry replays (after %0d clocks)", t0));
    nls = 0;
    wait_tlps(n0 + 5, 2500);
    chk(err[2], "REPLAY_NUM rollover on the fourth replay");
    wait_clk(5);
    chk(nls >= 1 && ls_trace[0] == 4'd5, "rollover sends the LTSSM to Recovery");
    begin
      int c;
      c = 0;
      while (ltssm != 4'd4 && c < 400) begin @(negedge clk); c++; end
    end
    chk(ltssm == 4'd4 && dl_up, "Recovery returns to L0 with the Data Link Layer up");
    dout.push_back(dllp(8'h00, {12'h0, s0}));                        // ACK
    wait_clk(10);
    n0 = nm;
    wait_clk(900);
    chk(nm == n0, "ACK purges the replay buffer: no further replays");
    auto_ack = 1;

    // ---- Recovery by TS1 from the partner, state kept
    os_mode = 2; os_force = 2'd0;
    wait_clk(4);
    chk(ltssm == 4'd5, "TS1 in L0 enters Recovery.RcvrLock");
    os_mode = 1;
    begin
      int c;
      c = 0;
      while (ltssm != 4'd4 && c < 400) begin @(negedge clk); c++; end
    end
    n0 = nm;
    cfgrd(16, 8'h41);
    wait_tlps(n0 + 1);
    chk(ltssm == 4'd4 && mseq(n0) == 12'(s0 + 1) && is_cpl(n0, 3'b000, 12'd4, 7'd0, 1, 8'h41),
        "after Recovery: sequence numbers continue, config state kept");

    // ---- link down (EIOS), retrain with finite Cpl credits
    os_mode = 2; os_force = 2'd3; rx_det = 0;
    wait_clk(4);
    chk(ltssm == 4'd0 && !dl_up, "EIOS in L0: Detect, Data Link Layer down");
    os_mode = 0; pseq = 0; nls = 0;
    bring_up_tlp(1, 2);
    n0 = nm;
    mrd(32'h8000_0020, 16, 4'hF, 4'hF, 8'h50); send_next();         // 64 B at 0x20: two completions
    wait_clk(200);
    chk(nm == n0 + 1 && mseq(n0) == 12'd0, "Cpl credits 1 header / 2 data: one completion, then the transmitter waits");
    dout.push_back(fc(8'hA0, 2, 2));                                 // UpdateFC-Cpl: header only
    wait_clk(100);
    chk(nm == n0 + 1, "a header credit alone does not release an 8-DW completion");
    dout.push_back(fc(8'hA0, 2, 4));                                 // and the data credits
    wait_tlps(n0 + 2);
    chk(nm == n0 + 2 && is_cpl(n0 + 1, 3'b000, 12'd32, 7'h40, 8, 8'h50), "UpdateFC-Cpl releases the next completion");
    // second link down, standard FC initialisation
    os_mode = 2; os_force = 2'd3; rx_det = 0;
    wait_clk(4);
    os_mode = 0; pseq = 0;
    bring_up(0, 0);
    n0 = nm;
    cfgrd(0, 8'h60);
    wait_tlps(n0 + 1);
    chk(mseq(n0) == 12'd0 && is_cpl(n0, 3'b000, 12'd4, 7'd0, 1, 8'h60), "second retrain: sequence numbers restart, config read completes");
    chk(bad_dcrc == 0, "every DLLP from the model has a good CRC");
    chk(stray_tx == 0, "tx_valid only inside TLP frames");
    begin
      int bad;
      bad = 0;
      for (int i = 0; i < nm; i++) if (!mcrc_ok[i % 2048]) bad++;
      chk(bad == 0, "every TLP from the model has a good LCRC");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
