// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// FUNC_SIM: iverilog
//
// func_pcie_flit_tb.sv -- flit transmitter for pcie_flit_model with its own
// encoder (table-driven CRC-64, log / antilog GF(2^8) tables) and a
// reference receiver written out independently of the model:
//   * payload flits delivered in sequence, NOP flits, sequence wrap
//   * FEC: one bad byte in each interleave (data and parity bytes)
//     corrected; two in one interleave, or a syndrome that points past the
//     codeword, make the flit bad
//   * flit CRC failure with consistent FEC, bad flit type
//   * Nak once per scheduled Nak, cleared by the replayed flit; duplicates
//     dropped and Acked at once; Ack after ACK_N flits and after ACK_TMO
//   * Ack field of good flits passed on, of bad flits ignored
//   * 1000 random flits with random errors, checked clock by clock
// Run: python3 tools/run_func_tests.py PCIe-VIP
`timescale 1ns/1ps
module func_pcie_flit_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int ACK_N = 4, ACK_TMO = 16;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic rx_valid = 0;
  logic [2047:0] rx_flit = 0;
  wire tlp_valid, rx_ack_valid, tx_valid;
  wire [9:0] tlp_seq, rx_ack_seq, tx_seq;
  wire [1887:0] tlp_data;
  wire [1:0] rx_ack_type, tx_type;
  wire [15:0] corr_cnt;
  wire [4:0] err;
  always #5 clk = ~clk;

  pcie_flit_model #(.ACK_N(ACK_N), .ACK_TMO(ACK_TMO)) u_dut (.clk, .rst_n, .rx_valid, .rx_flit, .tlp_valid,
    .tlp_seq, .tlp_data, .rx_ack_valid, .rx_ack_type, .rx_ack_seq, .tx_valid, .tx_type, .tx_seq, .corr_cnt, .err);

  task automatic wait_clk(input int n); repeat (n) @(negedge clk); #1; endtask   // #1: after the checker
  task automatic drain(input int n); wait_clk(n); endtask

  // ------------------------------------------------------------ encoder
  logic [63:0] ctab [256];
  logic [7:0]  alog [512];
  int          glog [256];
  initial begin
    logic [7:0] x;
    for (int i = 0; i < 256; i++) begin
      logic [63:0] c;
      c = 64'(i) << 56;
      for (int b = 0; b < 8; b++) c = c[63] ? ((c << 1) ^ 64'h42F0_E1EB_A9EA_3693) : (c << 1);
      ctab[i] = c;
    end
    x = 8'h01;
    for (int i = 0; i < 512; i++) begin
      alog[i] = x;
      if (i < 255) glog[x] = i;
      x = x[7] ? ((x << 1) ^ 8'h1D) : (x << 1);
    end
  end
  function automatic logic [7:0] mul(input logic [7:0] a, input logic [7:0] b);
    if (a == 0 || b == 0) return 8'h00;
    return alog[glog[a] + glog[b]];
  endfunction
  function automatic logic [7:0] dv(input logic [7:0] a, input logic [7:0] b);  // a / b, b != 0
    if (a == 0) return 8'h00;
    return alog[glog[a] + 255 - glog[b]];
  endfunction
  function automatic logic [63:0] crc(input logic [2047:0] f);
    logic [63:0] c;
    c = 0;
    for (int i = 0; i < 242; i++) c = (c << 8) ^ ctab[c[63:56] ^ f[8 * i +: 8]];
    return c;
  endfunction
  function automatic int ndat(input int k); return (250 - k + 2) / 3; endfunction
  // byte address of codeword position j in interleave k
  function automatic int addr(input int k, input int j);
    return (j < ndat(k)) ? 3 * j + k : 250 + 2 * k + j - ndat(k);
  endfunction
  function automatic logic [2047:0] fec(input logic [2047:0] f);
    for (int k = 0; k < 3; k++) begin
      logic [7:0] a, b, p0, p1;
      int n;
      n = ndat(k);
      a = 0; b = 0;
      for (int j = 0; j < n; j++) begin a ^= f[8 * addr(k, j) +: 8]; b ^= mul(f[8 * addr(k, j) +: 8], alog[j]); end
      // p0 + p1 = a, p0 a^n + p1 a^(n+1) = b
      p1 = dv(b ^ mul(a, alog[n]), alog[n] ^ alog[n + 1]);
      p0 = a ^ p1;
      f[8 * addr(k, n) +: 8] = p0; f[8 * addr(k, n + 1) +: 8] = p1;
    end
    return f;
  endfunction
  function automatic logic [2047:0] mk(input int typ, input int seq, input logic [1887:0] tlp,
                                       input int at = 0, input int aseq = 0);
    logic [2047:0] f;
    logic [63:0] c;
    f = '0; f[1887:0] = tlp;
    f[8*236 +: 8] = typ; f[8*237 +: 8] = seq >> 8; f[8*238 +: 8] = seq & 255;
    f[8*239 +: 8] = at; f[8*240 +: 8] = aseq >> 8; f[8*241 +: 8] = aseq & 255;
    c = crc(f);
    for (int i = 0; i < 8; i++) f[8 * (242 + i) +: 8] = c[63 - 8 * i -: 8];
    return fec(f);
  endfunction
  function automatic logic [1887:0] rtlp();
    logic [1887:0] t;
    for (int i = 0; i < 59; i++) t[32 * i +: 32] = $urandom;
    return t;
  endfunction

  // ------------------------------------------------------------ reference
  int r_exp = 0, r_ua = 0, r_tmr = 0, r_corr = 0;
  bit r_nak = 0;
  bit [4:0] r_err = 0;
  // expected registered outputs (compared at the next negedge)
  bit e_tlp, e_rack, e_tx;
  int e_tseq, e_rat, e_rseq, e_txt, e_txs;
  logic [1887:0] e_td;
  int bad_out = 0, n_tlp = 0, n_ack = 0, n_nak = 0;
  bit check_on = 1;
  always @(posedge clk) if (rst_n && check_on) begin
    bit bad, acc, dup, nak;
    int nx;
    logic [2047:0] f;
    bad = 0; acc = 0; dup = 0; nak = 0; nx = r_exp;
    e_tlp = 0; e_rack = 0; e_tx = 0;
    if (rx_valid) begin
      f = rx_flit;
      for (int k = 0; k < 3; k++) begin
        logic [7:0] s0, s1;
        s0 = 0; s1 = 0;
        for (int j = 0; j < ndat(k) + 2; j++) begin s0 ^= f[8 * addr(k, j) +: 8]; s1 ^= mul(f[8 * addr(k, j) +: 8], alog[j]); end
        if (s0 != 0 || s1 != 0) begin
          int j;
          j = (s0 != 0 && s1 != 0) ? glog[dv(s1, s0)] : 999;
          if (j >= ndat(k) + 2) begin bad = 1; r_err[0] = 1; end
          else begin f[8 * addr(k, j) +: 8] ^= s0; r_corr++; end
        end
      end
      if (!bad) begin
        logic [63:0] c;
        c = crc(f);
        for (int i = 0; i < 8; i++) if (f[8 * (242 + i) +: 8] != c[63 - 8 * i -: 8]) bad = 1;
        if (bad) r_err[1] = 1;
      end
      if (bad) nak = 1;
      else if (f[8*236 +: 8] > 1) r_err[4] = 1;
      else begin
        int at;
        at = f[8*239 +: 8];
        if (at == 1 || at == 2) begin e_rack = 1; e_rat = at; e_rseq = (f[8*240 +: 8] & 3) * 256 + f[8*241 +: 8]; end
        if (f[8*236 +: 8] == 1) begin
          int s, dd;
          s = (f[8*237 +: 8] & 3) * 256 + f[8*238 +: 8];
          dd = (s - r_exp + 1024) % 1024;
          if (dd == 0) begin acc = 1; e_tlp = 1; e_tseq = r_exp; e_td = f[1887:0]; nx = (r_exp + 1) % 1024; end
          else if (dd >= 512) begin dup = 1; r_err[3] = 1; end
          else begin nak = 1; r_err[2] = 1; end
        end
      end
    end
    if (acc) begin
      if (r_ua == 0) r_tmr = 0;
      r_ua++;
    end else if (r_ua > 0) r_tmr++;
    if (nak && !r_nak) begin
      e_tx = 1; e_txt = 2; e_txs = (nx + 1023) % 1024; r_ua = 0;
    end else if (dup || r_ua >= ACK_N || (r_ua > 0 && r_tmr >= ACK_TMO)) begin
      e_tx = 1; e_txt = 1; e_txs = (nx + 1023) % 1024; r_ua = 0;
    end
    if (acc) r_nak = 0;
    if (nak && !r_nak) r_nak = 1;
    r_exp = nx;
  end
  always @(negedge clk) if (rst_n && check_on) begin
    bit ok;
    ok = 1;
    if (tlp_valid !== e_tlp || (e_tlp && (tlp_seq != e_tseq || tlp_data !== e_td))) ok = 0;
    if (rx_ack_valid !== e_rack || (e_rack && (rx_ack_type != e_rat || rx_ack_seq != e_rseq))) ok = 0;
    if (tx_valid !== e_tx || (e_tx && (tx_type != e_txt || tx_seq != e_txs))) ok = 0;
    if (corr_cnt != r_corr[15:0] || err !== r_err) ok = 0;
    if (!ok) begin
      bad_out++;
      if (bad_out < 6) $display("  @%0t tlp %b/%b ack %b/%b tx %b(%0d,%0d)/%b(%0d,%0d) corr %0d/%0d err %b/%b", $time,
        tlp_valid, e_tlp, rx_ack_valid, e_rack, tx_valid, tx_type, tx_seq, e_tx, e_txt, e_txs, corr_cnt, r_corr, err, r_err);
    end
    n_tlp += tlp_valid; n_ack += tx_valid && tx_type == 1; n_nak += tx_valid && tx_type == 2;
  end

  task automatic send(input logic [2047:0] f);
    @(negedge clk); rx_valid = 1; rx_flit = f;
    @(negedge clk); rx_valid = 0; #1;
  endtask
  // flips byte addr by x
  function automatic logic [2047:0] hit(input logic [2047:0] f, input int a, input logic [7:0] x);
    f[8 * a +: 8] ^= x;
    return f;
  endfunction

  int seqn = 0;
  logic [1887:0] t0;
  int b0, a0, k0, c0;
  bit seen;

  initial begin
    wait_clk(3); rst_n = 1; wait_clk(2);

    // ---- in-sequence payload flits, Ack after ACK_N
    t0 = rtlp();
    @(negedge clk); rx_valid = 1; rx_flit = mk(1, 0, t0);
    @(negedge clk); rx_valid = 0;
    chk(tlp_valid && tlp_seq == 0 && tlp_data == t0 && !tx_valid, "payload flit 0 delivered, no Ack yet");
    a0 = n_ack;
    for (int i = 1; i < 4; i++) send(mk(1, i, rtlp()));
    chk(n_ack == a0 + 1, "Ack after 4 unacknowledged flits");
    seqn = 4;
    b0 = bad_out;
    chk(bad_out == 0 && n_tlp == 4, "flits 0-3 delivered in order");

    // ---- Ack timer
    send(mk(1, seqn, rtlp())); seqn++;
    a0 = n_ack;
    wait_clk(ACK_TMO - 1);
    chk(n_ack == a0, "no Ack before the Ack timer");
    seen = 0;
    @(negedge clk); seen = tx_valid && tx_type == 1 && tx_seq == seqn - 1;
    chk(seen, "Ack for the single flit after ACK_TMO clocks");

    // ---- NOP flit, Ack field passthrough
    send(mk(0, 77, rtlp(), 1, 10'h2A5));
    chk(rx_ack_valid && rx_ack_type == 1 && rx_ack_seq == 10'h2A5 && !tlp_valid, "NOP flit: Ack field passed on, no TLP");
    send(mk(1, seqn, rtlp(), 2, 10'h0FE)); seqn++;
    chk(rx_ack_valid && rx_ack_type == 2 && rx_ack_seq == 10'h0FE && tlp_valid, "Nak field on a payload flit passed on");
    send(mk(0, 0, rtlp(), 3, 5));
    chk(!rx_ack_valid, "Ack field type 3 ignored");

    // ---- FEC: one byte per interleave, data and parity
    c0 = corr_cnt;
    t0 = rtlp();
    send(hit(hit(hit(mk(1, seqn, t0), 0, 8'h5A), 101, 8'h01), 238, 8'hFF)); seqn++;
    chk(tlp_valid && tlp_data == t0 && corr_cnt == c0 + 3 && err == 0, "one bad byte in each interleave: corrected (3)");
    t0 = rtlp();
    send(hit(hit(hit(mk(1, seqn, t0), 250, 8'h80), 253, 8'h11), 255, 8'h02)); seqn++;
    chk(tlp_valid && tlp_data == t0 && corr_cnt == c0 + 6, "bad parity bytes corrected");
    t0 = rtlp();
    send(hit(hit(mk(1, seqn, t0), 245, 8'h40), 237, 8'h01)); seqn++;
    chk(tlp_valid && tlp_data == t0 && corr_cnt == c0 + 8, "bad CRC and sequence bytes corrected");
    drain(ACK_TMO + 2);

    // ---- uncorrectable: two bytes in one interleave
    b0 = n_nak;
    send(hit(hit(mk(1, seqn, rtlp()), 3, 8'h01), 6, 8'h01));
    chk(!tlp_valid && n_nak == b0 + 1 && tx_seq == seqn - 1 && (err[0] || err[1]), "two bad bytes in one interleave: dropped, Nak");
    send(hit(mk(1, seqn + 1, rtlp(), 1, 9), 1, 8'h10));
    chk(n_nak == b0 + 1 && err[2], "next flit out of sequence: no second Nak while one is scheduled");
    t0 = rtlp();
    send(mk(1, seqn, t0, 1, 9)); seqn++;
    chk(tlp_valid && tlp_data == t0 && rx_ack_valid && rx_ack_seq == 9, "replayed flit accepted, its Ack field passed on");
    send(mk(1, seqn + 2, rtlp()));
    chk(n_nak == b0 + 2 && tx_seq == seqn - 1, "a new gap sends a new Nak");
    send(mk(1, seqn, rtlp())); seqn++;
    drain(ACK_TMO + 2);

    // ---- two equal bad bytes in one interleave (S0 = 0): uncorrectable
    begin
      logic [2047:0] f;
      f = mk(1, seqn, rtlp(), 2, 3);
      f = hit(f, 1, 8'h33); f = hit(f, 4, 8'h33);   // interleave 1, positions 0 and 1
      b0 = n_nak;
      send(f);
      chk(!tlp_valid && !rx_ack_valid && n_nak == b0 + 1, "bad flit: dropped, Ack field ignored, Nak");
      send(mk(1, seqn, rtlp())); seqn++;
    end

    // ---- CRC error with consistent FEC
    begin
      logic [2047:0] f;
      f = mk(1, seqn, rtlp());
      f[8*50 +: 8] ^= 8'h01;
      f = fec(f);
      b0 = n_nak;
      send(f);
      chk(!tlp_valid && err[1] && n_nak == b0 + 1, "flit CRC failure: dropped, Nak");
      send(mk(1, seqn, rtlp())); seqn++;
    end

    // ---- duplicate, bad type
    a0 = n_ack;
    send(mk(1, seqn - 1, rtlp()));
    chk(!tlp_valid && err[3] && n_ack == a0 + 1 && tx_seq == seqn - 1, "duplicate: dropped, Ack at once");
    send(mk(1, (seqn + 512) % 1024, rtlp()));
    chk(!tlp_valid && n_ack == a0 + 2, "512 behind is a duplicate");
    send(mk(1, (seqn + 511) % 1024, rtlp()));
    chk(!tlp_valid && n_nak > b0 + 1, "511 ahead is a gap");
    send(mk(1, seqn, rtlp())); seqn++;
    send(mk(2, seqn, rtlp()));
    chk(!tlp_valid && err[4], "flit type 2 dropped");
    drain(ACK_TMO + 2);

    // ---- sequence wrap
    while (seqn != 1022) begin
      @(negedge clk); rx_valid = 1; rx_flit = mk(1, seqn, rtlp()); seqn = (seqn + 1) % 1024;
    end
    @(negedge clk); rx_valid = 0;
    for (int i = 0; i < 4; i++) begin send(mk(1, seqn, rtlp())); seqn = (seqn + 1) % 1024; end
    chk(seqn == 2 && tlp_seq == 1, "sequence wraps 1023 -> 0");
    drain(ACK_TMO + 2);
    chk(bad_out == 0, "directed flits: every output as the reference");

    // ---- random
    begin
      int sent;
      sent = 0;
      for (int i = 0; i < 1000; i++) begin
        logic [2047:0] f;
        int r, s;
        r = $urandom_range(0, 99);
        s = (r < 8) ? (r_exp + $urandom_range(1, 3)) % 1024 : (r < 14) ? (r_exp + 1023) % 1024 : r_exp;
        f = mk(($urandom_range(0, 19) == 0) ? 0 : ($urandom_range(0, 60) == 0) ? 3 : 1, s, rtlp(),
               $urandom_range(0, 3), $urandom_range(0, 1023));
        r = $urandom_range(0, 99);
        if (r < 25) f = hit(f, $urandom_range(0, 255), 8'($urandom_range(1, 255)));
        else if (r < 30) begin f = hit(f, $urandom_range(0, 255), 8'($urandom_range(1, 255))); f = hit(f, $urandom_range(0, 255), 8'($urandom_range(1, 255))); end
        else if (r < 33) begin f[8 * $urandom_range(0, 241) +: 8] ^= 8'($urandom_range(1, 255)); f = fec(f); end
        @(negedge clk);
        rx_valid = $urandom_range(0, 3) != 0; rx_flit = f;
        sent += rx_valid;
      end
      @(negedge clk); rx_valid = 0;
      drain(ACK_TMO + 4);
      chk(bad_out == 0, $sformatf("%0d random flits: deliveries, Ack / Nak, corrections and errors as the reference (%0d TLPs, %0d Acks, %0d Naks)",
          sent, n_tlp, n_ack, n_nak));
      chk(n_nak > 10 && corr_cnt > 150, "random flits exercised Naks and corrections");
    end

    // ---- reset
    check_on = 0;
    rst_n = 0; wait_clk(2);
    chk(!tlp_valid && !tx_valid && !rx_ack_valid && corr_cnt == 0 && err == 0, "reset clears outputs, counter and errors");
    rst_n = 1;
    send(mk(1, 3, rtlp()));
    chk(tx_valid && tx_type == 2 && tx_seq == 10'h3FF, "after reset no Nak is scheduled: a gap sends one");
    send(mk(1, 0, rtlp()));
    chk(tlp_valid && tlp_seq == 0, "after reset the expected sequence is 0");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #20ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
