// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// pcie_flit_model.sv -- PCIe Flit Mode receiver (the 256-byte flit that
// PCIe 6.0 introduced and 7.0 / 8.0 keep): FEC correction, flit CRC,
// flit sequence numbers and the Ack / Nak it sends back. The flit shape
// (236 TLP bytes, 6 DLP bytes, 8 CRC bytes, 6 FEC bytes in 3 interleaves)
// follows the base specification; the byte layout inside the DLP, the CRC
// polynomial and the FEC code are this model's own.
//
// Flit (rx_flit, byte i = bits [8*i +: 8], one flit per clock on rx_valid):
//   0..235   TLP bytes
//   236      flit type: 0 NOP (no sequence number), 1 payload
//   237..238 flit sequence number, {6'b0, seq[9:8]}, seq[7:0]
//   239      Ack field type 0 none, 1 Ack, 2 Nak; 240..241 its sequence
//   242..249 CRC-64 (poly 42F0E1EBA9EA3693, init 0, MSB first) of bytes
//            0..241, most significant byte first
//   250..255 FEC: interleave k (k = 0, 1, 2) holds data bytes i = k, k+3,
//            ... < 250 (positions 0..n-3) and parity bytes 250+2k, 251+2k
//            (positions n-2, n-1). Each interleave is a GF(2^8) code
//            (poly 0x11D, alpha 2) with syndromes S0 = sum c_j and
//            S1 = sum c_j alpha^j both 0: one bad byte per interleave is
//            corrected (corr_cnt counts every corrected byte, also in a flit
//            then found bad); anything else that the
//            syndromes cannot place is uncorrectable.
// Receive: a flit is bad when an interleave is uncorrectable (err[0]) or
//   the CRC fails after correction (err[1]); a bad flit is dropped and its
//   Ack field ignored. A good flit with type > 1 is dropped (err[4]).
//   A good flit's Ack field (type 1 or 2) is passed on (rx_ack_*).
//   Payload flit with seq = next expected: TLP bytes on tlp_* and the
//   expected seq advances (mod 1024). seq behind (by 1..512): duplicate,
//   dropped (err[3]), Ack sent at once. seq ahead: dropped, treated like a
//   bad flit (err[2]).
// Ack / Nak (tx_valid one clock, tx_type 1 Ack / 2 Nak, tx_seq = last
//   accepted seq): a bad or out-of-sequence flit sends a Nak unless one is
//   already scheduled (cleared by the next accepted payload flit). Otherwise
//   an Ack goes out when ACK_N payload flits are unacknowledged, when the
//   oldest unacknowledged one was accepted ACK_TMO clocks ago, or for a
//   duplicate. A Nak acknowledges like an Ack.
module pcie_flit_model #(parameter int ACK_N = 4, parameter int ACK_TMO = 16) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          rx_valid,
  input  logic [2047:0] rx_flit,
  output logic          tlp_valid,
  output logic [9:0]    tlp_seq,
  output logic [1887:0] tlp_data,
  output logic          rx_ack_valid,
  output logic [1:0]    rx_ack_type,
  output logic [9:0]    rx_ack_seq,
  output logic          tx_valid,
  output logic [1:0]    tx_type,
  output logic [9:0]    tx_seq,
  output logic [15:0]   corr_cnt,
  output logic [4:0]    err
);
  logic [9:0] exp_seq;
  logic       nak_sch;
  int         ua, tmr;

  function automatic logic [7:0] gmul(input logic [7:0] a, input logic [7:0] b);
    logic [7:0] p, x;
    p = 8'h00; x = a;
    for (int i = 0; i < 8; i++) begin
      if (b[i]) p = p ^ x;
      x = x[7] ? ((x << 1) ^ 8'h1D) : (x << 1);
    end
    return p;
  endfunction

  function automatic logic [63:0] crc64(input logic [2047:0] f);
    logic [63:0] c;
    c = 64'h0;
    for (int i = 0; i < 242; i++)
      for (int b = 7; b >= 0; b--)
        c = (c[63] ^ f[8 * i + b]) ? ((c << 1) ^ 64'h42F0_E1EB_A9EA_3693) : (c << 1);
    return c;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      exp_seq <= '0; nak_sch <= 1'b0; ua = 0; tmr = 0;
      tlp_valid <= 1'b0; tlp_seq <= '0; tlp_data <= '0;
      rx_ack_valid <= 1'b0; rx_ack_type <= '0; rx_ack_seq <= '0;
      tx_valid <= 1'b0; tx_type <= '0; tx_seq <= '0;
      corr_cnt <= '0; err <= '0;
    end else begin : step
      logic [2047:0] f;
      logic          bad, acc, dup, nak, ack;
      logic [4:0]    e;
      logic [9:0]    nx, d;
      int            nc;
      f = rx_flit; bad = 1'b0; acc = 1'b0; dup = 1'b0; nak = 1'b0; ack = 1'b0; e = '0; nx = exp_seq; nc = 0;
      tlp_valid <= 1'b0; rx_ack_valid <= 1'b0; tx_valid <= 1'b0;

      if (rx_valid) begin
        // FEC
        for (int k = 0; k < 3; k++) begin : fec
          logic [7:0] s0, s1, ap;
          int n, pos, at;
          n = (252 - k) / 3 + 2;
          s0 = 8'h00; s1 = 8'h00; ap = 8'h01;
          for (int j = 0; j < n; j++) begin
            pos = (j < n - 2) ? (3 * j + k) : (250 + 2 * k + (j - (n - 2)));
            s0 = s0 ^ f[8 * pos +: 8];
            s1 = s1 ^ gmul(f[8 * pos +: 8], ap);
            ap = gmul(ap, 8'h02);
          end
          if (s0 != 8'h00 || s1 != 8'h00) begin
            at = -1; ap = 8'h01;
            if (s0 != 8'h00 && s1 != 8'h00)
              for (int j = 0; j < n; j++) begin
                if (at < 0 && gmul(s0, ap) == s1) at = j;
                ap = gmul(ap, 8'h02);
              end
            if (at < 0) begin bad = 1'b1; e[0] = 1'b1; end
            else begin
              pos = (at < n - 2) ? (3 * at + k) : (250 + 2 * k + (at - (n - 2)));
              f[8 * pos +: 8] = f[8 * pos +: 8] ^ s0;
              nc = nc + 1;
            end
          end
        end
        // CRC
        if (!bad && crc64(f) != {f[8*242 +: 8], f[8*243 +: 8], f[8*244 +: 8], f[8*245 +: 8],
                                 f[8*246 +: 8], f[8*247 +: 8], f[8*248 +: 8], f[8*249 +: 8]}) begin
          bad = 1'b1; e[1] = 1'b1;
        end
        if (bad) nak = 1'b1;
        else if (f[8*236 +: 8] > 8'd1) e[4] = 1'b1;
        else begin
          if (f[8*239 +: 8] == 8'd1 || f[8*239 +: 8] == 8'd2) begin
            rx_ack_valid <= 1'b1; rx_ack_type <= f[8*239 +: 2];
            rx_ack_seq <= {f[8*240 +: 2], f[8*241 +: 8]};
          end
          if (f[8*236 +: 8] == 8'd1) begin
            d = {f[8*237 +: 2], f[8*238 +: 8]} - exp_seq;
            if (d == 10'd0) begin
              acc = 1'b1;
              tlp_valid <= 1'b1; tlp_seq <= exp_seq; tlp_data <= f[1887:0];
              nx = exp_seq + 10'd1;
            end else if (d >= 10'd512) begin dup = 1'b1; e[3] = 1'b1; end
            else begin nak = 1'b1; e[2] = 1'b1; end
          end
        end
      end

      // Ack / Nak
      if (acc) begin
        nak_sch <= 1'b0;
        if (ua == 0) tmr = 0;
        ua = ua + 1;
      end else if (ua > 0) tmr = tmr + 1;
      if (nak && !nak_sch) begin
        tx_valid <= 1'b1; tx_type <= 2'd2; tx_seq <= nx - 10'd1;
        nak_sch <= 1'b1; ua = 0;
      end else if (dup || ua >= ACK_N || (ua > 0 && tmr >= ACK_TMO)) begin
        tx_valid <= 1'b1; tx_type <= 2'd1; tx_seq <= nx - 10'd1;
        ua = 0;
      end
      exp_seq <= nx;
      corr_cnt <= corr_cnt + 16'(nc);
      err <= err | e;
    end
  end
endmodule
