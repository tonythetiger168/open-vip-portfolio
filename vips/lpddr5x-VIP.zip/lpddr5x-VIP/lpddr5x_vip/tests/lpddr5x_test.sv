// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// LPDDR5X UVM Tests
`ifndef LPDDR5X_TEST_SV
`define LPDDR5X_TEST_SV

class lpddr5x_base_test extends uvm_test;
  `uvm_component_utils(lpddr5x_base_test)
  lpddr5x_env env;
  int num_transactions = 100;
  function new(string name="lpddr5x_base_test", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase); env = lpddr5x_env::type_id::create("env", this); endfunction
  task run_phase(uvm_phase phase);
    lpddr5x_base_sequence seq;
    phase.raise_objection(this);
    seq = lpddr5x_base_sequence::type_id::create("seq");
    seq.num_transactions = num_transactions;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed write/read traffic
class lpddr5x_rw_test extends lpddr5x_base_test;
  `uvm_component_utils(lpddr5x_rw_test)
  function new(string name="lpddr5x_rw_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    lpddr5x_write_seq wr;
    lpddr5x_read_seq  rd;
    phase.raise_objection(this);
    wr = lpddr5x_write_seq::type_id::create("wr");
    rd = lpddr5x_read_seq::type_id::create("rd");
    wr.start(env.agt.sqr);
    rd.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Back-to-back same-bank stress
class lpddr5x_back_to_back_test extends lpddr5x_base_test;
  `uvm_component_utils(lpddr5x_back_to_back_test)
  function new(string name="lpddr5x_back_to_back_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    lpddr5x_back_to_back_seq seq;
    phase.raise_objection(this);
    seq = lpddr5x_back_to_back_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// The error test drives RD/WR with no ACT on purpose. The checker must flag
// every one of them (SVA_L4 "no open row"): those reports are expected, so
// they are demoted to UVM_INFO and counted, and the test fails if the checker
// stays silent or anything else is reported.
class lpddr5x_expected_error_catcher extends uvm_report_catcher;
  int unsigned n_caught;
  function new(string name="lpddr5x_expected_error_catcher"); super.new(name); endfunction
  function action_e catch();
    if (get_severity() == UVM_ERROR && get_id() == "SVA_L4" &&
        uvm_is_match("*RD/WR to a bank with no open row*", get_message())) begin
      n_caught++;
      set_severity(UVM_INFO);
    end
    return THROW;
  endfunction
endclass

// Error injection (RD/WR without ACT)
class lpddr5x_error_test extends lpddr5x_base_test;
  `uvm_component_utils(lpddr5x_error_test)
  lpddr5x_expected_error_catcher catcher;
  int unsigned n_injected;
  function new(string name="lpddr5x_error_test", uvm_component parent=null); super.new(name, parent); endfunction
  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    catcher = new();
    uvm_report_cb::add(null, catcher);
  endfunction
  task run_phase(uvm_phase phase);
    lpddr5x_error_seq seq;
    phase.raise_objection(this);
    seq = lpddr5x_error_seq::type_id::create("seq");
    n_injected = seq.num_transactions;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
  function void check_phase(uvm_phase phase);
    super.check_phase(phase);
    if (catcher.n_caught != n_injected)
      `uvm_error("ERR_TEST", $sformatf("expected %0d no-open-row violations, checker flagged %0d",
                 n_injected, catcher.n_caught))
    else
      `uvm_info("ERR_TEST", $sformatf("checker flagged all %0d injected RD/WR without ACT",
                n_injected), UVM_LOW)
  endfunction
endclass

// Full regression mix
class lpddr5x_regression_test extends lpddr5x_base_test;
  `uvm_component_utils(lpddr5x_regression_test)
  function new(string name="lpddr5x_regression_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    lpddr5x_regression_sequence seq;
    phase.raise_objection(this);
    seq = lpddr5x_regression_sequence::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
