// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// LPDDR5X Timing Performance Checker (L2)
// UVM component handle (env hookup) + companion SVA module lpddr5x_timing_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef LPDDR5X_TIMING_CHECKER_SV
`define LPDDR5X_TIMING_CHECKER_SV
class lpddr5x_timing_checker extends uvm_component;
  `uvm_component_utils(lpddr5x_timing_checker)
  virtual lpddr5x_if vif;
  function new(string name="lpddr5x_timing_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual lpddr5x_if)::get(this, "", "vif", vif)) `uvm_fatal("CONFIG", "LPDDR5X: vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/tb_top.sv
module lpddr5x_timing_sva(lpddr5x_if vif);
`include "uvm_macros.svh"
  property p_lpddr5x_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cs_n) |-> ##[8:12] vif.ca[4] == 0; endproperty
  assert_p_lpddr5x_tRCD: assert property(p_lpddr5x_tRCD) else `uvm_warning("LPDDR5X_TIM", "tRCD 8-12 cycles violated");
  cover_p_lpddr5x_tRCD: cover property(p_lpddr5x_tRCD);
  property p_lpddr5x_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.cs_n) |-> ##[8:12] $fell(vif.cs_n); endproperty
  assert_p_lpddr5x_tRP: assert property(p_lpddr5x_tRP) else `uvm_warning("LPDDR5X_TIM", "tRP 8-12 cycles violated");
  cover_p_lpddr5x_tRP: cover property(p_lpddr5x_tRP);
endmodule
`endif
