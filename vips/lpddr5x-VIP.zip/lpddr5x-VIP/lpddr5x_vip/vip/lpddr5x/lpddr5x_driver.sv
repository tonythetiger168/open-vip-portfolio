// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// LPDDR5X Driver -- issues DRAM command encodings (ACT/RD/WR/PRE/REF/NOP)
// with bank/row/column addressing and tRCD/tRP/tRAS/tCL timing concepts.
`ifndef LPDDR5X_DRIVER_SV
`define LPDDR5X_DRIVER_SV

class lpddr5x_driver extends uvm_driver #(lpddr5x_transaction);
  `uvm_component_utils(lpddr5x_driver)
  virtual lpddr5x_if vif;
  uvm_analysis_port #(lpddr5x_transaction) drv_ap;  // expected items for scoreboard

  // timing (clock cycles); seeded into the interface for the DUT/monitors
  int tRCD = 4;
  int tRP  = 4;
  int tRAS = 8;
  int tCL  = 6;
  bit bank_open[32];                                   // {bg,ba} -> row open

  function new(string name="lpddr5x_driver", uvm_component parent=null);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if(!uvm_config_db#(virtual lpddr5x_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "LPDDR5X driver: vif not found")
  endfunction

  // ---- command encodings on {cs_n, act_n, ras_n, cas_n, we_n} ----
  task drive_nop();
    vif.cb.cs_n <= 1'b1; vif.cb.act_n <= 1'b1; vif.cb.ras_n <= 1'b1;
    vif.cb.cas_n <= 1'b1; vif.cb.we_n  <= 1'b1;
    @(vif.cb);
  endtask

  task drive_act(input bit [2:0] bg, input bit [1:0] ba, input bit [15:0] row);
    vif.cb.cs_n <= 1'b0; vif.cb.act_n <= 1'b0;         // ACT
    vif.cb.ras_n <= 1'b0; vif.cb.cas_n <= 1'b1; vif.cb.we_n <= 1'b1;
    vif.cb.bg <= bg; vif.cb.ba <= ba; vif.cb.addr <= row; vif.cb.ca <= row[6:0];
    @(vif.cb);
    bank_open[{bg, ba}] = 1;
    drive_nop();
  endtask

  task drive_pre(input bit [2:0] bg, input bit [1:0] ba);
    vif.cb.cs_n <= 1'b0; vif.cb.act_n <= 1'b1;         // PRE
    vif.cb.ras_n <= 1'b0; vif.cb.cas_n <= 1'b1; vif.cb.we_n <= 1'b0;
    vif.cb.bg <= bg; vif.cb.ba <= ba;
    @(vif.cb);
    bank_open[{bg, ba}] = 0;
    drive_nop();
    repeat (tRP) @(vif.cb);                            // tRP
  endtask

  task drive_ref();
    vif.cb.cs_n <= 1'b0; vif.cb.act_n <= 1'b1;         // REF
    vif.cb.ras_n <= 1'b0; vif.cb.cas_n <= 1'b0; vif.cb.we_n <= 1'b1;
    @(vif.cb);
    foreach (bank_open[i]) bank_open[i] = 0;
    drive_nop();
    repeat (tRP + 2) @(vif.cb);                        // tRFC (abbreviated)
  endtask

  task drive_write(lpddr5x_transaction tr);
    vif.cb.cs_n <= 1'b0; vif.cb.act_n <= 1'b1;         // WR
    vif.cb.ras_n <= 1'b1; vif.cb.cas_n <= 1'b0; vif.cb.we_n <= 1'b0;
    vif.cb.bg <= tr.bg; vif.cb.ba <= tr.ba;
    vif.cb.addr <= {6'b0, tr.col}; vif.cb.ca <= tr.col[6:0];
    @(vif.cb);
    vif.cb.cs_n <= 1'b1; vif.cb.cas_n <= 1'b1; vif.cb.we_n <= 1'b1;  // NOP
    vif.cb.dq <= tr.data; vif.cb.dm <= 8'h00;          // burst beat 0 (cycle after WR)
    vif.cb.dqs_t <= 8'hFF; vif.cb.dmi_t <= 8'h00;
    @(vif.cb);
    vif.cb.dq <= tr.data2;                             // burst beat 1
    vif.cb.dqs_t <= 8'h00;
    @(vif.cb);
    drive_nop();
    vif.cb.dqs_t <= 8'h00;
  endtask

  task drive_read(lpddr5x_transaction tr);
    vif.cb.cs_n <= 1'b0; vif.cb.act_n <= 1'b1;         // RD
    vif.cb.ras_n <= 1'b1; vif.cb.cas_n <= 1'b0; vif.cb.we_n <= 1'b1;
    vif.cb.bg <= tr.bg; vif.cb.ba <= tr.ba;
    vif.cb.addr <= {6'b0, tr.col}; vif.cb.ca <= tr.col[6:0];
    @(vif.cb);
    drive_nop();
    repeat (tCL) @(vif.cb);                            // CAS latency
  endtask

  // Expected item for a command the driver issues on its own (the ACT
  // opening the row of a RD/WR, the PRE closing it): every bus command
  // the monitor will see has one expected item, in bus order.
  function void publish(lpddr5x_cmd_e cmd, lpddr5x_transaction tr);
    lpddr5x_transaction e = lpddr5x_transaction::type_id::create("e");
    e.cmd = cmd; e.bg = tr.bg; e.ba = tr.ba; e.row = tr.row;
    drv_ap.write(e);
  endfunction

  task run_phase(uvm_phase phase);
    lpddr5x_transaction tr;
    vif.cb.cs_n <= 1'b1; vif.cb.act_n <= 1'b1; vif.cb.ras_n <= 1'b1;
    vif.cb.cas_n <= 1'b1; vif.cb.we_n  <= 1'b1; vif.cb.cke   <= 1'b1;
    vif.cb.bg <= '0; vif.cb.ba <= '0; vif.cb.addr <= '0; vif.cb.ca <= '0;   // known while idle
    // mode-register configuration, published on the sideband like bl and tCL
    vif.wck_ratio = 2'd2; vif.dbim = 2'd0; vif.crc_en = 1'b0; vif.ecc_en = 1'b0; vif.pam4_en = 1'b0;
    vif.fgr_mode = 2'd0; vif.same_bank_ref = 1'b0; vif.refresh = 1'b0;
    vif.vrefca_train = 1'b0; vif.wck2ck_train = 1'b0; vif.inject_no_act = 1'b0;
    vif.tRCD = tRCD; vif.tRP = tRP; vif.tRAS = tRAS; vif.tCL = tCL;
    vif.bl = 5'd16;                                    // BL16 default until first RD/WR
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.cb);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      case (tr.cmd)
        LPDDR5X_CMD_ACT: begin
          drive_act(tr.bg, tr.ba, tr.row);
          publish(LPDDR5X_CMD_ACT, tr);
          repeat (tRAS) @(vif.cb);
          drive_pre(tr.bg, tr.ba);
          publish(LPDDR5X_CMD_PRE, tr);
        end
        LPDDR5X_CMD_WR, LPDDR5X_CMD_RD: begin
          if (!tr.no_act) begin
            drive_act(tr.bg, tr.ba, tr.row);
            publish(LPDDR5X_CMD_ACT, tr);
            repeat (tRCD) @(vif.cb);
          end
          if (tr.no_act) vif.inject_no_act = 1'b1;     // the checker reports the injected violation as info
          if (tr.cmd == LPDDR5X_CMD_WR) drive_write(tr);
          else                          drive_read(tr);
          vif.inject_no_act = 1'b0;
          drv_ap.write(tr);
          if (bank_open[{tr.bg, tr.ba}]) begin     // an injected no-ACT access leaves the bank idle
            repeat (tRP) @(vif.cb);
            drive_pre(tr.bg, tr.ba);
            publish(LPDDR5X_CMD_PRE, tr);
          end
        end
        LPDDR5X_CMD_PRE: begin
          if (!bank_open[{tr.bg, tr.ba}]) begin     // PRE needs an open row: open one first
            drive_act(tr.bg, tr.ba, tr.row);
            publish(LPDDR5X_CMD_ACT, tr);
            repeat (tRAS) @(vif.cb);
          end
          drive_pre(tr.bg, tr.ba);
          drv_ap.write(tr);
        end
        LPDDR5X_CMD_REF: begin drive_ref(); drv_ap.write(tr); end
        default:         drive_nop();
      endcase
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
