// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// LPDDR5X Top-Level Testbench with functional memory DUT model (closed loop)
`timescale 1ns/1ps
module tb_top;
  logic ck = 0;
  logic rst_n;
  always #5 ck = ~ck;

  lpddr5x_if lpddr5x_if(ck, rst_n);

  // Functional DRAM memory model: ACT/RD/WR/PRE/REF with open-row tracking
  lpddr5x_mem_model dut (
    .ck    (lpddr5x_if.ck),
    .rst_n (lpddr5x_if.rst_n),
    .cs_n  (lpddr5x_if.cs_n),
    .act_n (lpddr5x_if.act_n),
    .ras_n (lpddr5x_if.ras_n),
    .cas_n (lpddr5x_if.cas_n),
    .we_n  (lpddr5x_if.we_n),
    .addr  (lpddr5x_if.addr),
    .bg    (lpddr5x_if.bg),
    .ba    (lpddr5x_if.ba),
    .dq    (lpddr5x_if.dq),
    .tRCD  (lpddr5x_if.tRCD),
    .tRP   (lpddr5x_if.tRP),
    .tRAS  (lpddr5x_if.tRAS),
    .tCL   (lpddr5x_if.tCL)
  );

  // L1/L2/L3 SVA rule modules (companions of the class checkers)
  lpddr5x_protocol_sva      protocol_sva (lpddr5x_if);
  lpddr5x_data_integrity_sva di_sva      (lpddr5x_if);
  lpddr5x_timing_sva        timing_sva   (lpddr5x_if);
  lpddr5x_error_sva         error_sva    (lpddr5x_if);

  // SVA compliance checker (L4 protocol-specific rules)
  lpddr5x_compliance_checker sva_chk (
    .ck    (lpddr5x_if.ck),
    .rst_n (lpddr5x_if.rst_n),
    .cs_n  (lpddr5x_if.cs_n),
    .act_n (lpddr5x_if.act_n),
    .ras_n (lpddr5x_if.ras_n),
    .cas_n (lpddr5x_if.cas_n),
    .we_n  (lpddr5x_if.we_n),
    .addr  (lpddr5x_if.addr),
    .bg    (lpddr5x_if.bg),
    .ba    (lpddr5x_if.ba),
    .dq    (lpddr5x_if.dq)
  );

  initial begin
    rst_n = 0;
    #100 rst_n = 1;
  end

  initial begin
    uvm_config_db#(virtual lpddr5x_if)::set(null, "*", "vif", lpddr5x_if);
    run_test("lpddr5x_base_test");
  end

  initial begin
    #1000000 $finish;
  end
endmodule
