# Independent cross-check model (`xchk/`)

`ddr_xchk_tb.sv` checks the open-ip-portfolio `LPDDR5X_Lite` RTL (`rtl/LPDDR5X_Lite_top.sv`)
against ddr_pin_mon.sv on the DRAM pins: command rules, per-bank refresh, the two FSP sets, WCK only through writes, data against a shadow array. The model is written from the JESD79-4 pin rules as the IP documents them for its LPDDR5X slice, not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/ddr_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -DLPDDR -I xchk -s ddr_xchk_tb -o xchk.vvp $OIP/rtl/LPDDR5X_Lite_top.sv xchk/ddr_pin_mon.sv xchk/ddr_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
