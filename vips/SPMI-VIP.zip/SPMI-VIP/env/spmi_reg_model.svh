// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spmi_reg_model.svh -- UVM register model of the SPMI slave in tb/top_tb.sv
// (spmi_slave_model, slave address 0x2, 256 x 8-bit register map):
//   REG0..REG31 @ 0x00-0x1F  8-bit RW registers (reset, bit-bash, mirror tests)
//   MEM         @ 0x20-0xFF  the other 224 registers as a uvm_mem (walk test)
// Every location is RW, reset 0 (the model's array is 2-state).

`ifndef SPMI_REG_MODEL_SVH
`define SPMI_REG_MODEL_SVH

class spmi_data_reg extends uvm_reg;
  `uvm_object_utils(spmi_data_reg)
  rand uvm_reg_field DATA;

  function new(string name = "spmi_data_reg");
    super.new(name, 8, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    DATA = uvm_reg_field::type_id::create("DATA");
    //            parent size lsb access volatile reset has_reset rand individually_accessible
    DATA.configure(this, 8,   0,  "RW",  0,       8'h0, 1,        1,   1);
  endfunction
endclass

class spmi_reg_block extends uvm_reg_block;
  `uvm_object_utils(spmi_reg_block)
  localparam int N_REGS  = 32;
  localparam int N_WORDS = 256;
  rand spmi_data_reg REG[N_REGS];
  uvm_mem            MEM;
  uvm_reg_map        spmi_map;

  function new(string name = "spmi_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    spmi_map = create_map("spmi_map", 'h0, 1, UVM_LITTLE_ENDIAN, 1);
    default_map = spmi_map;
    foreach (REG[i]) begin
      REG[i] = spmi_data_reg::type_id::create($sformatf("REG%0d", i));
      REG[i].configure(this, null, "");
      REG[i].build();
      spmi_map.add_reg(REG[i], i, "RW");
    end
    MEM = new("MEM", N_WORDS - N_REGS, 8, "RW", UVM_NO_COVERAGE);
    MEM.configure(this, "");
    spmi_map.add_mem(MEM, N_REGS, "RW");
  endfunction
endclass
`endif
