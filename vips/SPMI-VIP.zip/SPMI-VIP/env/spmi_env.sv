// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// env_pkg.sv -- MIPI SPMI verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import spmi_defs_pkg::*;
  import spmi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) transactions
  // against monitor-decoded (observed) transactions, including NACK status
  // and write/read data contents.
  class spmi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(spmi_scoreboard)
    uvm_analysis_imp_exp #(spmi_transaction, spmi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(spmi_transaction, spmi_scoreboard) obs_ap;

    spmi_transaction exp_q[$], obs_q[$];
    int unsigned match_cnt = 0, mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(spmi_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(spmi_transaction t); obs_q.push_back(t); check(); endfunction

    function bit txn_match(spmi_transaction e, spmi_transaction o);
      if (e.sa != o.sa) return 0;
      if (e.rnw != o.rnw) return 0;
      if (e.reg_addr != o.reg_addr) return 0;
      if (e.nack != o.nack) return 0;           // injected NACK observed?
      if (o.parity_err) return 0;
      if (e.nack) return 1;                     // frame aborted after command
      if (e.rnw) return e.rdata == o.rdata;
      return e.data == o.data;
    endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        spmi_transaction e = exp_q.pop_front();
        spmi_transaction o = obs_q.pop_front();
        if (txn_match(e, o)) match_cnt++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("spmi scoreboard: matches=%0d mismatches=%0d",
                match_cnt, mismatches), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class spmi_env extends uvm_env;
    `uvm_component_utils(spmi_env)
    spmi_agent      agt;
    spmi_scoreboard sb;
    spmi_checker    chk;
    spmi_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = spmi_agent::type_id::create("agt", this);
      sb  = spmi_scoreboard::type_id::create("sb", this);
      chk = spmi_checker::type_id::create("chk", this);
      cov = spmi_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
