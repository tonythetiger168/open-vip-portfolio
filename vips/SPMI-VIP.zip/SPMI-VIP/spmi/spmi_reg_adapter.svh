// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spmi_reg_adapter.svh -- UVM RAL adapter for the SPMI master agent
//   reg2bus: one uvm_reg_bus_op -> one spmi_transaction
//            UVM_WRITE -> Register Write, UVM_READ -> Register Read (ADDR[7:0])
//   bus2reg: spmi_transaction (driver-completed or monitor-observed) -> uvm_reg_bus_op
// The driver writes the ACK result (nack) and the read data frame (rdata)
// back into the request item and sends no separate response, so
// provides_responses = 0. A NACK or a parity error is UVM_NOT_OK.

`ifndef SPMI_REG_ADAPTER_SVH
`define SPMI_REG_ADAPTER_SVH

class spmi_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(spmi_reg_adapter)

  bit [3:0] slave_addr = 4'h2;   // slave address the register model maps

  function new(string name = "spmi_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 0;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    spmi_transaction tr = spmi_transaction::type_id::create("ral_item");
    tr.sa       = slave_addr;
    tr.rnw      = (rw.kind == UVM_READ);
    tr.reg_addr = rw.addr[7:0];
    tr.data     = (rw.kind == UVM_WRITE) ? rw.data[7:0] : 8'h0;
    return tr;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    spmi_transaction tr;
    if (!$cast(tr, bus_item)) begin
      `uvm_fatal("SPMI_RAL", "bus2reg: item is not an spmi_transaction")
      return;
    end
    rw.kind    = tr.rnw ? UVM_READ : UVM_WRITE;
    rw.addr    = tr.reg_addr;
    rw.data    = tr.rnw ? tr.rdata : tr.data;
    rw.n_bits  = 8;
    rw.byte_en = '1;
    rw.status  = (tr.nack || tr.parity_err || tr.sa != slave_addr) ? UVM_NOT_OK : UVM_IS_OK;
    // other slaves and NACKed frames: unmapped, the predictor skips them
    if (rw.status != UVM_IS_OK) rw.addr = 'h100;
  endfunction
endclass
`endif
