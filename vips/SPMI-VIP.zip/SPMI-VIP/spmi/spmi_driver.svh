// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spmi_driver.svh -- MIPI SPMI master driver (bit-banged)
// Frame sequence per transfer: SSC (SDATA pulse while SCLK stopped) ->
// command frame (SA + CMD + ADDR + parity) -> ACK bit (slave driven) ->
// data frame (8 bits + parity) -> bus park (SDATA low). A NACK aborts the
// transfer right after the command frame. SCLK idles low.

`ifndef SPMI_DRIVER_SVH
`define SPMI_DRIVER_SVH

class spmi_driver extends uvm_driver #(spmi_transaction);
  `uvm_component_utils(spmi_driver)
  virtual spmi_if vif;
  spmi_config cfg;
  uvm_analysis_port #(spmi_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual spmi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spmi virtual interface not set")
  endfunction

  // ---- low-level line control ----
  task drv_sdata(bit v); vif.drv_cb.sdata_o <= v; vif.drv_cb.sdata_oe <= 1; endtask
  task rel_sdata();    vif.drv_cb.sdata_oe <= 0; endtask
  task drv_sclk(bit v);  vif.drv_cb.sclk_o  <= v; vif.drv_cb.sclk_oe  <= 1; endtask

  // SSC: SDATA pulse while SCLK is stopped (low)
  task spmi_ssc();
    drv_sdata(1); repeat (4) @(vif.drv_cb);
    drv_sdata(0); repeat (2) @(vif.drv_cb);
  endtask

  // Data changes while SCLK low, sampled on the rising edge
  task send_bit(bit b);
    drv_sdata(b);
    repeat (2) @(vif.drv_cb);
    drv_sclk(1); repeat (2) @(vif.drv_cb);
    drv_sclk(0); repeat (2) @(vif.drv_cb);
  endtask

  task recv_bit(output bit b);
    repeat (2) @(vif.drv_cb);
    drv_sclk(1); repeat (2) @(vif.drv_cb);
    b = vif.drv_cb.sdata_i;
    drv_sclk(0); repeat (2) @(vif.drv_cb);
  endtask

  task send_bits(bit [16:0] v, int n);
    for (int i = n - 1; i >= 0; i--) send_bit(v[i]);
  endtask

  task bus_park();
    vif.state = spmi_defs_pkg::ACK_PARK;
    drv_sdata(0);
    repeat (4) @(vif.drv_cb);
    rel_sdata();
    repeat (2) @(vif.drv_cb);
    vif.state = spmi_defs_pkg::IDLE;
    repeat (2) @(vif.drv_cb);
  endtask

  task drive_item(spmi_transaction tr);
    bit [16:0] cbits;
    bit        p;

    // ---- SSC ----
    vif.state = spmi_defs_pkg::SSC;
    spmi_ssc();

    // ---- command frame: SA + CMD + ADDR + parity ----
    vif.state = spmi_defs_pkg::COMMAND;
    cbits = {tr.sa, tr.cmd_code(), tr.reg_addr};
    send_bits(cbits, 16);
    send_bit(^cbits[15:0]);

    // ---- ACK bit (slave driven; undriven = NACK) ----
    rel_sdata();
    recv_bit(p);
    tr.nack = !p;
    if (tr.nack) begin
      `uvm_warning("DRV", $sformatf("sa 0x%01h NACKed command frame", tr.sa))
      vif.state = spmi_defs_pkg::DATA;       // chain pass-through (no data)
      @(vif.drv_cb);
      bus_park();
      return;
    end

    // ---- data frame ----
    vif.state = spmi_defs_pkg::DATA;
    if (!tr.rnw) begin
      send_bits({9'h000, tr.data}, 8);
      send_bit(^tr.data);
    end else begin
      bit [7:0] d;
      for (int i = 7; i >= 0; i--) recv_bit(d[i]);
      tr.rdata = d;
      recv_bit(p);                           // slave parity bit
    end

    bus_park();
  endtask

  task run_phase(uvm_phase phase);
    spmi_transaction tr;
    vif.drv_cb.sdata_oe <= 0;
    vif.drv_cb.sclk_o   <= 0; vif.drv_cb.sclk_oe <= 1;   // SCLK idle low
    vif.state = spmi_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      drive_item(tr);
      drv_ap.write(tr);                        // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
