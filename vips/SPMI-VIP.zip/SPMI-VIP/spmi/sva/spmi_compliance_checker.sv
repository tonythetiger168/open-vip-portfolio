// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// spmi_compliance_checker.sv -- MIPI SPMI SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = SPMI protocol-specific rules (SSC format, ACK bit, frame length,
//      bus park). The `sclk` port is the reference clock; `sclk_i`/
//      `sdata_i` are the resolved bus signals.

`ifndef SPMI_COMPLIANCE_CHECKER_SV
`define SPMI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import spmi_defs_pkg::spmi_state_e;
import spmi_defs_pkg::*;   // enum literals (IDLE, SSC, ...)

module spmi_compliance_checker
(
  input logic sclk,
  input logic rst_n,
  input spmi_state_e state,
  input logic sdata_i,
  input logic sclk_i
);

  // ---------------- L1: signal sanity (4) ----------------
  a_spmi_l1_clk   : assert property (@(posedge sclk) disable iff (!rst_n) !$isunknown(sclk))
    else `uvm_error("SVA_L1", "spmi: clock unknown")
  a_spmi_l1_rst   : assert property (@(posedge sclk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "spmi: reset unknown")
  a_spmi_l1_state : assert property (@(posedge sclk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "spmi: state unknown")
  a_spmi_l1_valid : assert property (@(posedge sclk) disable iff (!rst_n)
    state inside {IDLE, SSC, COMMAND, DATA, ACK_PARK})
    else `uvm_error("SVA_L1", "spmi: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_spmi_trans_idle : assert property (@(posedge sclk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, SSC})
    else `uvm_error("SVA_L2", "spmi: illegal transition from IDLE")

  // L2-2: legal FSM transition from SSC
  a_spmi_trans_ssc : assert property (@(posedge sclk) disable iff (!rst_n)
    state == SSC |=> state inside {SSC, COMMAND})
    else `uvm_error("SVA_L2", "spmi: illegal transition from SSC")

  // L2-3: legal FSM transition from COMMAND
  a_spmi_trans_command : assert property (@(posedge sclk) disable iff (!rst_n)
    state == COMMAND |=> state inside {COMMAND, DATA})
    else `uvm_error("SVA_L2", "spmi: illegal transition from COMMAND")

  // L2-4: legal FSM transition from DATA
  a_spmi_trans_data : assert property (@(posedge sclk) disable iff (!rst_n)
    state == DATA |=> state inside {DATA, ACK_PARK})
    else `uvm_error("SVA_L2", "spmi: illegal transition from DATA")

  // L2-5: legal FSM transition from ACK_PARK
  a_spmi_trans_ack_park : assert property (@(posedge sclk) disable iff (!rst_n)
    state == ACK_PARK |=> state inside {ACK_PARK, IDLE})
    else `uvm_error("SVA_L2", "spmi: illegal transition from ACK_PARK")

  // ---------------- L3: protocol rules (4) ----------------
  a_spmi_l3_reset_idle : assert property (@(posedge sclk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "spmi: state not IDLE during reset")
  a_spmi_l3_no_stuck   : assert property (@(posedge sclk) disable iff (!rst_n)
    state == ACK_PARK |-> ##[1:8] (state != ACK_PARK))
    else `uvm_error("SVA_L3", "spmi: stuck in ACK_PARK")
  a_spmi_l3_full_cycle : cover property (@(posedge sclk) disable iff (!rst_n)
    state == IDLE ##1 state == SSC);
  a_spmi_l3_back_idle  : cover property (@(posedge sclk) disable iff (!rst_n)
    state == ACK_PARK ##1 state == IDLE);

  // ---------------- L4: SPMI protocol-specific rules (5) ----------------
  // Count bus SCLK edges inside the command frame and capture the ACK bit
  // (18th edge: 16 command bits + parity + ACK slot)
  int cmd_bits;
  bit sclk_d;
  bit last_ack;
  initial begin cmd_bits = 0; sclk_d = 0; last_ack = 0; end
  always @(posedge sclk) begin
    sclk_d <= sclk_i;
    if (state != COMMAND) cmd_bits <= 0;
    else if (sclk_i && !sclk_d) begin
      cmd_bits <= cmd_bits + 1;
      if (cmd_bits == 17) last_ack <= sdata_i;
    end
  end

  // L4-1: SSC format: SCLK must be stopped (low) during the SSC
  a_spmi_l4_ssc_sclk_low : assert property (@(posedge sclk) disable iff (!rst_n)
    state == SSC |-> (sclk_i == 1'b0))
    else `uvm_error("SVA_L4", "spmi: SSC attempted while SCLK running")

  // L4-2: SSC format: the SSC must contain the SDATA request pulse
  a_spmi_l4_ssc_pulse : assert property (@(posedge sclk) disable iff (!rst_n)
    state == SSC |-> ##[0:6] $rose(sdata_i))
    else `uvm_error("SVA_L4", "spmi: SSC without SDATA pulse")

  // L4-3: a data phase may only follow an acknowledged command frame
  a_spmi_l4_ack_bit : assert property (@(posedge sclk) disable iff (!rst_n)
    (state == DATA && $past(state == DATA)) |-> last_ack)
    else `uvm_error("SVA_L4", "spmi: data phase entered without ACK")

  // L4-4: command frame length: at most 20 bit clocks (SA+CMD+ADDR+P+ACK)
  a_spmi_l4_frame_len : assert property (@(posedge sclk) disable iff (!rst_n)
    cmd_bits <= 20)
    else `uvm_error("SVA_L4", "spmi: command frame exceeds legal length")

  // L4-5: bus park: SDATA driven low while SCLK stays low at frame end
  a_spmi_l4_bus_park : assert property (@(posedge sclk) disable iff (!rst_n)
    state == ACK_PARK |-> ##[0:3] (!sdata_i && !sclk_i))
    else `uvm_error("SVA_L4", "spmi: bus park violation (SDATA not low)")

endmodule
`endif
