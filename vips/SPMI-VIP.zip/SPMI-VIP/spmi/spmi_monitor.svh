// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spmi_monitor.svh -- MIPI SPMI monitor
// Detects the SSC (SDATA pulse while SCLK is stopped), then decodes the
// command frame (SA + CMD + ADDR + parity), the slave-driven ACK bit,
// and the data frame (8 bits + parity). A NACK aborts the frame; the
// transaction is published with `nack` set.

`ifndef SPMI_MONITOR_SVH
`define SPMI_MONITOR_SVH

class spmi_monitor extends uvm_monitor;
  `uvm_component_utils(spmi_monitor)
  virtual spmi_if vif;
  uvm_analysis_port #(spmi_transaction) ap;
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual spmi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spmi virtual interface not set")
  endfunction

  task automatic sample_bit(output bit b);
    @(posedge vif.sclk_i);
    b = vif.sdata_i;
  endtask

  // Decode one frame sequence starting right after the SSC pulse.
  task automatic decode_frame();
    spmi_transaction tr;
    bit [15:0] cbits = '0;
    bit [3:0]  cmd;
    bit        b, p, dp, ack;

    tr = spmi_transaction::type_id::create("tr");

    // ---- command frame: SA + CMD + ADDR + parity ----
    for (int i = 3; i >= 0; i--) begin sample_bit(b); tr.sa[i] = b;       cbits = {cbits[14:0], b}; end
    for (int i = 3; i >= 0; i--) begin sample_bit(b); cmd[i] = b;         cbits = {cbits[14:0], b}; end
    for (int i = 7; i >= 0; i--) begin sample_bit(b); tr.reg_addr[i] = b; cbits = {cbits[14:0], b}; end
    sample_bit(p);
    if (p !== ^cbits) tr.parity_err = 1;
    tr.rnw = (cmd == spmi_transaction::SPMI_CMD_REG_READ);
    if (!(cmd inside {spmi_transaction::SPMI_CMD_REG_WRITE,
                      spmi_transaction::SPMI_CMD_REG_READ}))
      `uvm_warning("MON", $sformatf("unsupported command code 0x%0h decoded", cmd))

    // ---- ACK bit (slave driven high = ACK) ----
    sample_bit(ack);
    tr.nack = !ack;
    if (tr.nack) begin
      txn_count++;
      `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
      ap.write(tr);
      return;
    end

    // ---- data frame ----
    if (tr.rnw) begin
      for (int i = 7; i >= 0; i--) begin sample_bit(b); tr.rdata[i] = b; end
      sample_bit(dp);
      if (dp !== ^tr.rdata) tr.parity_err = 1;
    end else begin
      for (int i = 7; i >= 0; i--) begin sample_bit(b); tr.data[i] = b; end
      sample_bit(dp);
      if (dp !== ^tr.data) tr.parity_err = 1;
    end
    @(negedge vif.sclk_i);

    txn_count++;
    `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
    ap.write(tr);
  endtask

  task run_phase(uvm_phase phase);
    forever begin
      @(posedge vif.sdata_i);              // SSC pulse candidate
      if (!vif.rst_n) continue;
      if (vif.sclk_i) continue;            // SSC only while SCLK stopped
      if (vif.state != spmi_defs_pkg::SSC) continue;  // mid-frame transition
      decode_frame();
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("spmi monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
