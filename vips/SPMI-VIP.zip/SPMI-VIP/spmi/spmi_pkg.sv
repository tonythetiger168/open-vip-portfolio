// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// spmi_pkg.sv -- MIPI SPMI UVM VIP package

package spmi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import spmi_defs_pkg::*;
  export spmi_defs_pkg::*;

  `include "spmi_transaction.svh"
  `include "spmi_config.svh"
  `include "spmi_sequencer.svh"
  `include "spmi_driver.svh"
  `include "spmi_monitor.svh"
  `include "spmi_agent.svh"
  `include "spmi_sequences.svh"
  `include "spmi_checker.svh"
  `include "spmi_coverage.svh"
endpackage
