// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spmi_coverage.svh -- MIPI SPMI functional coverage
// cg_protocol : slave address / direction / register address / data (+ cross)
// cg_fsm      : protocol FSM states and frame-sequence transitions,
//               sampled from the interface sideband on every state change
// cg_error    : NACK / parity error bins (with direction cross)

`ifndef SPMI_COVERAGE_SVH
`define SPMI_COVERAGE_SVH

class spmi_coverage extends uvm_subscriber #(spmi_transaction);
  `uvm_component_utils(spmi_coverage)

  virtual spmi_if vif;
  spmi_transaction tr;
  spmi_state_e cur_state;

  covergroup cg_protocol;
    cp_sa : coverpoint tr.sa {
      bins dut    = {4'h2};
      bins others = {[4'h0 : 4'hF]};
    }
    cp_rnw : coverpoint tr.rnw { bins wr = {0}; bins rd = {1}; }
    cp_reg : coverpoint tr.reg_addr {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins low  = {[8'h01 : 8'h7F]};
      bins high = {[8'h80 : 8'hFE]};
    }
    cp_data : coverpoint tr.data iff (!tr.rnw) {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins walk = {[8'h01 : 8'hFE]};
    }
    cx_rnw_sa : cross cp_rnw, cp_sa;
  endgroup

  covergroup cg_fsm with function sample(spmi_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {spmi_defs_pkg::IDLE, spmi_defs_pkg::SSC,
                           spmi_defs_pkg::COMMAND, spmi_defs_pkg::DATA,
                           spmi_defs_pkg::ACK_PARK};
    }
    cp_trans : coverpoint s {
      bins frame_seq = (spmi_defs_pkg::IDLE    => spmi_defs_pkg::SSC     =>
                        spmi_defs_pkg::COMMAND);
      bins data_seq  = (spmi_defs_pkg::COMMAND => spmi_defs_pkg::DATA    =>
                        spmi_defs_pkg::ACK_PARK);
      bins park_seq  = (spmi_defs_pkg::ACK_PARK => spmi_defs_pkg::IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_rnw        : coverpoint tr.rnw        { bins wr = {0}; bins rd = {1}; }
    cp_nack       : coverpoint tr.nack       { bins ack = {0}; bins nack = {1}; }
    cp_parity_err : coverpoint tr.parity_err { bins ok = {0}; bins err = {1}; }
    cx_nack_dir   : cross cp_nack, cp_rnw;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual spmi_if)::get(this, "", "vif", vif));
  endfunction

  // Sample the FSM covergroup on every interface state change
  task run_phase(uvm_phase phase);
    spmi_state_e prev = spmi_defs_pkg::IDLE;
    if (vif == null) return;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n === 1'b1 && vif.mon_cb.state !== prev) begin
        cur_state = vif.mon_cb.state;
        cg_fsm.sample(cur_state);
        prev = cur_state;
      end
    end
  endtask

  function void write(spmi_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction
endclass
`endif
