// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spmi_transaction.svh -- MIPI SPMI transaction
// One item = one SPMI frame sequence: SSC + command frame + ACK + data
// frame + bus park. Command frame: SA[3:0] CMD[3:0] ADDR[7:0] P (17 bits),
// followed by a slave-driven ACK bit. Data frame: D[7:0] P (even parity).
// A NACK (no slave drives the ACK bit) aborts the frame after the command.

`ifndef SPMI_TRANSACTION_SVH
`define SPMI_TRANSACTION_SVH

class spmi_transaction extends uvm_sequence_item;

  localparam bit [3:0] SPMI_CMD_REG_WRITE = 4'h2;
  localparam bit [3:0] SPMI_CMD_REG_READ  = 4'h3;

  rand bit [3:0]  sa;            // slave address
  rand bit        rnw;           // 1 = read, 0 = write
  rand bit [7:0]  reg_addr;      // register address
  rand bit [7:0]  data;          // write data

  // Observed / status fields (driver + monitor)
  bit [7:0]       rdata;         // read data frame contents
  bit             nack;          // ACK bit not driven (no/unsupported slave)
  bit             parity_err;    // monitor: command/data parity mismatch

  constraint c_sa   { sa inside {[4'h0:4'h3]}; }          // implemented slaves (DUT = 0x2)
  constraint c_rnw  { rnw dist {0 := 6, 1 := 4}; }
  // REACHABILITY: the DUT register map is a full 256-entry associative array
  // (top_tb.sv), so the whole 8-bit address space is legal; widen the domain so
  // cg_protocol cp_reg ones/high bins are generatable.
  constraint c_addr { reg_addr inside {[8'h00:8'hFF]}; }  // full register map

  `uvm_object_utils_begin(spmi_transaction)
    `uvm_field_int(sa, UVM_ALL_ON)
    `uvm_field_int(rnw, UVM_ALL_ON)
    `uvm_field_int(reg_addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(nack, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(parity_err, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "spmi_transaction");
    super.new(name);
  endfunction

  function bit [3:0] cmd_code();
    return rnw ? SPMI_CMD_REG_READ : SPMI_CMD_REG_WRITE;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    spmi_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    ok &= comparer.compare_field("sa", sa, t.sa, 4);
    ok &= comparer.compare_field("rnw", rnw, t.rnw, 1);
    ok &= comparer.compare_field("reg_addr", reg_addr, t.reg_addr, 8);
    if (!rnw) ok &= comparer.compare_field("data", data, t.data, 8);
    return ok;
  endfunction

  function string convert2string();
    string s = $sformatf("SPMI %s sa=0x%01h reg=0x%02h",
                         rnw ? "RD" : "WR", sa, reg_addr);
    if (rnw) s = {s, $sformatf(" rdata=0x%02h", rdata)};
    else     s = {s, $sformatf(" data=0x%02h", data)};
    if (nack) s = {s, " NACK"};
    if (parity_err) s = {s, " PARITY_ERR"};
    return s;
  endfunction
endclass
`endif
