// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// spmi_sequences.svh -- MIPI SPMI sequence library
// Directed sequences: register write / register read / address corners /
// all-slave-address sweep / back-to-back / NACK error injection, plus
// random and regression mix. The PMIC slave DUT sits at address 0x2.

`ifndef SPMI_SEQUENCES_SVH
`define SPMI_SEQUENCES_SVH

class spmi_base_sequence extends uvm_sequence #(spmi_transaction);
  `uvm_object_utils(spmi_base_sequence)
  int num_txns = 20;
  bit [3:0] dut_addr = 4'h2;
  function new(string name = "spmi_base_sequence"); super.new(name); endfunction
  task body();
    spmi_transaction tr;
    repeat (num_txns) begin
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: register writes with walking register addresses
class spmi_reg_write_seq extends spmi_base_sequence;
  `uvm_object_utils(spmi_reg_write_seq)

  function new(string name = "spmi_reg_write_seq"); super.new(name); endfunction

  bit [7:0] reg_start = 8'h00;
  task body();
    spmi_transaction tr;
    repeat (num_txns) begin
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { sa == dut_addr; rnw == 0;
                                  reg_addr == reg_start; });
      finish_item(tr);
      reg_start = reg_start + 8'h11;
    end
  endtask
endclass

// Directed: register reads (read back locations written earlier)
class spmi_reg_read_seq extends spmi_base_sequence;
  `uvm_object_utils(spmi_reg_read_seq)

  function new(string name = "spmi_reg_read_seq"); super.new(name); endfunction

  task body();
    spmi_transaction tr;
    repeat (num_txns) begin
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { sa == dut_addr; rnw == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: register address corners (0x00 / 0xFF / alternating patterns)
class spmi_addr_corner_seq extends spmi_base_sequence;
  `uvm_object_utils(spmi_addr_corner_seq)

  function new(string name = "spmi_addr_corner_seq"); super.new(name); endfunction

  task body();
    spmi_transaction tr;
    bit [7:0] corners[$] = '{8'h00, 8'hFF, 8'h55, 8'hAA};
    foreach (corners[i]) begin
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { sa == dut_addr; reg_addr == corners[i]; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: sweep all 16 slave addresses (only 0x2 ACKs; others NACK)
class spmi_all_sa_seq extends spmi_base_sequence;
  `uvm_object_utils(spmi_all_sa_seq)

  function new(string name = "spmi_all_sa_seq"); super.new(name); endfunction

  task body();
    spmi_transaction tr;
    for (int sa_i = 0; sa_i < 16; sa_i++) begin
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { sa == sa_i[3:0]; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back single-register writes with minimal bus-idle gap
class spmi_back_to_back_seq extends spmi_base_sequence;
  `uvm_object_utils(spmi_back_to_back_seq)

  function new(string name = "spmi_back_to_back_seq"); super.new(name); endfunction

  task body();
    spmi_transaction tr;
    repeat (num_txns) begin
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { sa == dut_addr; rnw == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: NACK probing (writes and reads to unimplemented SAs)
class spmi_error_inject_seq extends spmi_base_sequence;
  `uvm_object_utils(spmi_error_inject_seq)

  function new(string name = "spmi_error_inject_seq"); super.new(name); endfunction

  task body();
    spmi_transaction tr;
    bit [3:0] bad_sa[$] = '{4'h5, 4'h9};
    foreach (bad_sa[i]) begin
      // write to an unimplemented slave address -> NACK
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { sa == bad_sa[i]; rnw == 0; });
      finish_item(tr);
      // read from an unimplemented slave address -> NACK
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { sa == bad_sa[i]; rnw == 1; });
      finish_item(tr);
    end
  endtask
endclass

class spmi_random_sequence extends spmi_base_sequence;
  `uvm_object_utils(spmi_random_sequence)
  function new(string name = "spmi_random_sequence"); super.new(name); num_txns = 50; endfunction
  task body();
    spmi_transaction tr;
    repeat (num_txns) begin
      tr = spmi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { sa dist {4'h2 := 7, [4'h0 : 4'hF] := 3}; });
      finish_item(tr);
    end
  endtask
endclass

// Regression: weighted mix of all directed sequences
class spmi_regression_sequence extends spmi_base_sequence;
  `uvm_object_utils(spmi_regression_sequence)
  function new(string name = "spmi_regression_sequence"); super.new(name); endfunction
  task body();
    spmi_reg_write_seq    wr  = spmi_reg_write_seq::type_id::create("wr");
    spmi_reg_read_seq     rd  = spmi_reg_read_seq::type_id::create("rd");
    spmi_addr_corner_seq  ac  = spmi_addr_corner_seq::type_id::create("ac");
    spmi_all_sa_seq       all = spmi_all_sa_seq::type_id::create("all");
    spmi_back_to_back_seq b2b = spmi_back_to_back_seq::type_id::create("b2b");
    spmi_error_inject_seq err = spmi_error_inject_seq::type_id::create("err");
    wr.num_txns = 16; rd.num_txns = 16; b2b.num_txns = 12;
    wr.start(m_sequencer);
    rd.start(m_sequencer);            // read back written registers
    ac.start(m_sequencer);
    all.start(m_sequencer);
    b2b.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
