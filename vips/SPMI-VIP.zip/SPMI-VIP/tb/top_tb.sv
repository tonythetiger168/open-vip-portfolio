// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- MIPI SPMI testbench top with a functional PMIC slave DUT
// The DUT is a PMIC slave at address 0x2 with a 256-entry register map.
// It decodes the SSC and command frame, drives the ACK bit when addressed
// (staying silent produces the NACK used for error injection), and serves
// register writes and reads with parity.

`ifndef SPMI_TB_SV
`define SPMI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import spmi_defs_pkg::*;
import spmi_pkg::*;
import spmi_test_pkg::*;

module top_tb;
  logic sclk = 0;
  always #5ns sclk = ~sclk;

  spmi_if vif(sclk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  spmi_slave_model #(.SLAVE_ADDR(4'h2)) dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual spmi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional MIPI SPMI (PMIC) slave: SSC-qualified command decoder, ACK
// generation and a 256-entry register map
module spmi_slave_model #(parameter bit [3:0] SLAVE_ADDR = 4'h2)
  (spmi_if vif);

  localparam bit [3:0] CMD_REG_WRITE = 4'h2;
  localparam bit [3:0] CMD_REG_READ  = 4'h3;

  bit [7:0] regs [0:255];        // register map (2-state, reads 0)

  initial begin
    vif.slv_sdata_o  = 0;
    vif.slv_sdata_oe = 0;
  end

  task automatic recv_bit(output bit b);
    @(posedge vif.sclk_i);
    b = vif.sdata_i;
  endtask

  // Qualify a real SSC: SDATA rose while SCLK stopped AND no SCLK edge
  // follows within the pulse window (rules out mid-frame transitions)
  task automatic wait_ssc();
    bit real_ssc;
    int unsigned n;
    real_ssc = 0;
    while (!real_ssc) begin
      @(posedge vif.sdata_i);
      if (vif.rst_n && !vif.sclk_i) begin
        // quiet window (no fork/disable fork): count system clocks while
        // sclk_i stays low; a data bit (sclk_i high) rules out the SSC
        n = 0;
        while (n < 3 && vif.sclk_i === 1'b0) begin
          @(posedge vif.sclk);
          if (vif.sclk_i === 1'b0) n = n + 1;
        end
        if (n >= 3) real_ssc = 1;
      end
    end
  endtask

  // Drive a read data frame: MSB during the current low phase, shift on
  // falling edges, append the parity bit, then release before bus park.
  task automatic send_byte(input bit [7:0] d);
    vif.slv_sdata_o = d[7];                  // oe still 1 from the ACK bit
    for (int i = 7; i >= 0; i--) begin
      @(posedge vif.sclk_i);
      @(negedge vif.sclk_i);
      if (i > 0) vif.slv_sdata_o = d[i-1];
    end
    vif.slv_sdata_o = ^d;                    // parity bit
    @(posedge vif.sclk_i);
    @(negedge vif.sclk_i);
    vif.slv_sdata_oe = 0;
  endtask

  initial forever begin
    bit [3:0] sa, cmd;
    bit [7:0] addr, d;
    bit       b, p;

    wait_ssc();

    // ---- command frame ----
    for (int i = 3; i >= 0; i--) recv_bit(sa[i]);
    for (int i = 3; i >= 0; i--) recv_bit(cmd[i]);
    // not for us / not a register command: silent NACK, resync on next SSC
    if (sa == SLAVE_ADDR &&
        (cmd == CMD_REG_WRITE || cmd == CMD_REG_READ)) begin
      for (int i = 7; i >= 0; i--) recv_bit(addr[i]);
      recv_bit(p);                           // command parity (not checked)

      // ---- ACK bit ----
      @(negedge vif.sclk_i);
      vif.slv_sdata_oe = 1; vif.slv_sdata_o = 1;   // ACK
      @(posedge vif.sclk_i);
      @(negedge vif.sclk_i);

      // ---- data frame ----
      if (cmd == CMD_REG_READ) begin
        send_byte(regs[addr]);               // keeps oe through the frame
      end else begin
        vif.slv_sdata_oe = 0;                // release after ACK
        for (int i = 7; i >= 0; i--) recv_bit(d[i]);
        recv_bit(b);                         // data parity (not checked)
        @(negedge vif.sclk_i);
        regs[addr] = d;
      end
    end
    // bus park is master driven; resync on next SSC
  end
endmodule
`endif
