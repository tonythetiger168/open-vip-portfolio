// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_spmi_tb.sv -- self-checking functional test for the MIPI SPMI slave
// model (spmi_slave_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py SPMI-VIP
//
// Model contract (from tb/top_tb.sv):
//   a Sequence Start Condition (SDATA pulses high while SCLK stays low for at
//   least 3 system clocks) starts a frame. Bits are sampled on SCLK rising
//   edges: slave address[3:0], command[3:0], register address[7:0], parity.
//   For a matching address and Register Write (2) / Register Read (3) the
//   slave drives an ACK bit (1); a read then returns data[7:0] + parity
//   (^data) from the slave, a write takes data[7:0] + parity from the
//   master. SLAVE_ADDR = 2. Other addresses / commands get no response.

module func_spmi_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [3:0] SA = 4'h2, WR = 4'h2, RD = 4'h3;
  int checks = 0, fails = 0;

  logic sys = 1'b0, rst_n = 1'b0, sclk = 1'b0, sdata = 1'b0;
  wire  sd_o, sd_oe;

  always #5 sys = ~sys;

  spmi_slave_model u_dut (
    .vif_sclk(sys), .vif_rst_n(rst_n), .vif_sdata_i(sdata), .vif_sclk_i(sclk),
    .vif_slv_sdata_o(sd_o), .vif_slv_sdata_oe(sd_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one SCLK period (4 system clocks); master data changes while SCLK is low.
  // Returns the slave's SDATA/OE sampled on the rising edge.
  bit s_o, s_oe;
  task automatic cyc(input bit d);
    sdata = d;
    repeat (2) @(posedge sys);
    sclk = 1'b1; #1 s_o = sd_o; s_oe = sd_oe;
    repeat (2) @(posedge sys);
    sclk = 1'b0;
  endtask

  task automatic ssc(input int low_clks = 4);
    @(posedge sys); sdata = 1'b1;
    repeat (2) @(posedge sys); sdata = 1'b0;
    repeat (low_clks) @(posedge sys);
  endtask

  // header; returns ack seen
  bit ack;
  task automatic header(input [3:0] sa, input [3:0] cmd, input [7:0] addr);
    logic [16:0] h = {sa, cmd, addr, ^{sa, cmd, addr}};
    for (int i = 16; i >= 0; i--) cyc(h[i]);
    cyc(1'b0);                       // ACK cell: slave drives
    ack = s_oe && s_o;
  endtask

  task automatic reg_write(input [3:0] sa, input [7:0] addr, input [7:0] d, input [3:0] cmd = WR);
    ssc();
    header(sa, cmd, addr);
    if (ack) begin
      for (int i = 7; i >= 0; i--) cyc(d[i]);
      cyc(^d);
    end
    repeat (4) @(posedge sys);
  endtask

  logic [7:0] rd_d;
  bit         rd_par, rd_oe_ok;
  task automatic reg_read(input [3:0] sa, input [7:0] addr);
    ssc();
    header(sa, RD, addr);
    rd_d = 'x; rd_oe_ok = 1;
    if (ack) begin
      for (int i = 7; i >= 0; i--) begin cyc(1'b0); rd_d[i] = s_o; rd_oe_ok &= s_oe; end
      cyc(1'b0); rd_par = s_o; rd_oe_ok &= s_oe;
    end
    repeat (4) @(posedge sys);
  endtask

  initial begin
    repeat (3) @(posedge sys);
    rst_n = 1'b1;
    repeat (3) @(posedge sys);

    reg_write(SA, 8'h10, 8'h5C);
    chk(ack, "Register Write to own address is ACKed");
    chk(u_dut.regs[8'h10] === 8'h5C, "Register Write stores the data byte");

    reg_read(SA, 8'h10);
    chk(ack && rd_d === 8'h5C, "Register Read returns the written byte");
    chk(rd_oe_ok, "slave drives SDATA for all 8 data cells and the parity cell");
    chk(rd_par === ^8'h5C, "read data parity bit is ^data");
    chk(sd_oe === 1'b0, "slave releases SDATA after the read");

    reg_write(SA, 8'h11, 8'hA3);
    reg_read(SA, 8'h10);
    chk(rd_d === 8'h5C, "registers are independent");
    reg_read(SA, 8'h11);
    chk(rd_d === 8'hA3 && rd_par === ^8'hA3, "second register reads back with parity");
    reg_read(SA, 8'h40);
    chk(ack && rd_d === 8'h00, "unwritten register reads 0");

    // not addressed / unsupported command
    reg_write(4'h5, 8'h10, 8'hFF);
    chk(!ack && u_dut.regs[8'h10] === 8'h5C, "frame for another slave address is ignored (no ACK)");
    reg_write(SA, 8'h10, 8'hFF, 4'h7);
    chk(!ack && u_dut.regs[8'h10] === 8'h5C, "unsupported command is ignored (no ACK)");

    // an SDATA glitch with SCLK low for fewer than 3 clocks is not an SSC
    @(posedge sys); sdata = 1'b1;
    @(posedge sys); sdata = 1'b0;
    @(posedge sys); sclk = 1'b1;
    repeat (2) @(posedge sys); sclk = 1'b0;
    repeat (2) @(posedge sys);
    chk(sd_oe === 1'b0, "short SDATA pulse is not taken as a start condition");
    reg_read(SA, 8'h11);
    chk(ack && rd_d === 8'hA3, "a proper frame after the glitch still works");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
