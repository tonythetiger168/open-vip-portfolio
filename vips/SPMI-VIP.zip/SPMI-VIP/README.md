# SPMI — MIPI SPMI UVM VIP

Open-source UVM verification IP template for **MIPI SPMI** (MIPI).

## Contents

| Path | Description |
|------|-------------|
| `spmi/spmi_if.sv` | Protocol interface (master-driven SCLK idle-low + turnaround SDATA) + FSM state enum |
| `spmi/spmi_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `spmi/sva/spmi_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=5) |
| `spmi/vip/spmi/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/spmi_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with a functional PMIC slave DUT (register map) |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged SPMI master driver**: SSC (SDATA pulse while SCLK stopped),
  command frame (SA + CMD + 8-bit ADDR + even parity), slave-driven ACK bit,
  data frame (8 bits + parity), bus park; SCLK idles low
- **ACK/NACK handling**: the addressed slave drives SDATA high during the ACK
  slot; an unimplemented slave address leaves it undriven (NACK) and the
  master aborts the frame cleanly before the data phase
- **Protocol-decoding monitor**: SSC-qualified decode of command frame, ACK
  bit and data frame with parity checking; NACKed frames published with the
  `nack` flag
- **End-to-end scoreboard**: expected (driver) vs observed (monitor) compare of
  slave address / direction / register / NACK status and full write/read data
- **Functional DUT model**: PMIC slave at 0x2 with a 256-entry register map;
  ACK generation, turnaround read data with parity, SSC qualification that
  rejects mid-frame SDATA transitions
- **Directed sequence library**: reg-write / reg-read / address corners /
  all-slave-address sweep / back-to-back / NACK error injection + random +
  regression mix
- **Functional coverage**: direction x slave-address cross, register address
  corners, data corners, FSM states + frame transitions, NACK/parity error
  bins (with direction cross)
- **SVA L4**: SSC requires stopped SCLK, SSC contains the SDATA pulse, data
  phase only after an ACK (bus-snooper captured), command frame length
  limit, bus park drives SDATA low
