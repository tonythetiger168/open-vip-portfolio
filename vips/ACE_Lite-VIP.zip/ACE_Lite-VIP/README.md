# ACE_Lite Open IP

ACE-Lite (AXI Coherency Extension, I/O-coherent subset) -- synthesizable slave
Scope: full AXI4 channels (AW/W/B/AR/R, INCR burst) + ACE-Lite fields
ARSNOOP/ARDOMAIN/ARBAR/AWSNOOP/AWDOMAIN/AWBAR (accepted; barrier
ordering guaranteed by strict in-order completion). No snoop channels.
Internal 256x32 word memory; out-of-range access -> SLVERR + irq.
Open IP design implementation v2.5.1 -- Apache-2.0

## Package contents

- `rtl/ACE_Lite_top.sv` -- synthesizable RTL (top: `ACE_Lite_top`)
- `tb/ACE_Lite_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/ACE_Lite_yosys.ys` -- Yosys synthesis script
- `syn/ACE_Lite_dc.tcl` -- Synopsys Design Compiler script
- `syn/ACE_Lite.sdc` -- timing constraints
- `sim/filelist_ACE_Lite.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.5.1: constrained-random testbenches (portable `ifdef VERILATOR`); RTL fixes: echo-copy/MEMCH OOB bounds, RFFE/HSI/I3C/SPMI/QSPI/1-Wire serial bugs, USB2.0 run_cnt, USB3 give-up, CXL-family STP/LEN=8, WTB tok_irq, NVMe TX replay bound. Verified: iverilog sim PASS.
