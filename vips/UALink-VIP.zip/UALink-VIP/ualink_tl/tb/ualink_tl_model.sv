// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ualink_tl_model.sv -- UALink accelerator endpoint at the transaction
// level (the completer side of the protocol interface): reads, writes with
// byte enables and atomics on a 16 KB memory window, tags matched across
// out-of-order responses, request credits, poison, and accelerator IDs.
// The structure follows the UALink 1.0 transaction rules; opcode
// encodings, field widths and status codes are this model's own.
//
// Request (one per clock, req_valid):
//   op 0 READ 64 B  1 WRITE 64 B (req_be)  2 ATOMIC ADD (returns old)
//      3 ATOMIC SWAP  4 ATOMIC CAS (req_wdata[63:0] compare,
//      [127:64] swap)  5 ATOMIC ADD, no response; other opcodes: status UR
//   READ / WRITE need a 64-byte aligned address, atomics 8-byte aligned
//   (otherwise status UR); atomics work on the 64-bit word at req_addr.
//   req_dst must equal my_id, else the request is dropped (err[2]); the
//   response goes to req_src (rsp_dst).
// Response (rsp_valid until rsp_ready): rsp_tag, rsp_status 0 OK,
//   1 UR, 2 address outside [win_base, win_base + 16 KB), 3 poisoned data;
//   rsp_data: READ the line, atomics the old value in [63:0].
// Requests execute in arrival order (a later read sees an earlier write)
// and respond 3 + 5 * addr[7:6] clocks later, so responses are reordered;
// equal due times leave in arrival order.
// A write with req_poison marks the line poisoned (a READ returns status 3,
// an atomic on it returns status 3 and leaves memory unchanged); a full
// write (all 64 byte enables) without poison clears it.
// Credits: REQ_CRD request credits, returned on crd_ret (a count per
// clock) when the response is accepted (op 5 with status OK: on arrival;
// op 5 with an error status responds like the others). A request
// without a credit is dropped (err[0]). A tag already outstanding is
// dropped (err[1]).
module ualink_tl_model #(parameter int REQ_CRD = 8, parameter logic [9:0] MY_ID = 10'h021) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [39:0]  win_base,
  input  logic         req_valid,
  input  logic [3:0]   req_op,
  input  logic [9:0]   req_tag,
  input  logic [9:0]   req_src,
  input  logic [9:0]   req_dst,
  input  logic [39:0]  req_addr,
  input  logic [511:0] req_wdata,
  input  logic [63:0]  req_be,
  input  logic         req_poison,
  output logic         rsp_valid,
  input  logic         rsp_ready,
  output logic [9:0]   rsp_tag,
  output logic [9:0]   rsp_dst,
  output logic [1:0]   rsp_status,
  output logic [511:0] rsp_data,
  output logic [1:0]   crd_ret,           // credits returned this clock
  output logic [2:0]   err
);
  localparam int NP = 16;
  logic [511:0] mem [0:255];
  logic         pois [0:255];
  logic         p_v [0:NP-1];
  logic [9:0]   p_tag [0:NP-1], p_dst [0:NP-1];
  logic [1:0]   p_st [0:NP-1];
  logic [511:0] p_d [0:NP-1];
  int           p_due [0:NP-1], p_ord [0:NP-1];
  int           now, ord, used, cur;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 256; i++) begin mem[i] = '0; pois[i] = 1'b0; end
      for (int i = 0; i < NP; i++) p_v[i] = 1'b0;
      now = 0; ord = 0; used = 0; cur = -1;
      rsp_valid <= 1'b0; rsp_tag <= '0; rsp_dst <= '0; rsp_status <= '0; rsp_data <= '0;
      crd_ret <= '0; err <= '0;
    end else begin : step
      logic [2:0] e;
      logic [1:0] ret;
      e = '0; ret = 2'd0;
      now = now + 1;

      // response handshake
      if (cur >= 0 && rsp_ready) begin
        p_v[cur] = 1'b0; cur = -1; used = used - 1; ret = ret + 2'd1;
      end

      // request
      if (req_valid) begin
        if (used == REQ_CRD) e[0] = 1'b1;
        else if (req_dst != MY_ID) e[2] = 1'b1;
        else begin : rq
          logic dup;
          int k;
          logic [39:0] off;
          logic [7:0] l;
          logic [1:0] st;
          logic [511:0] d;
          dup = 1'b0; k = -1;
          for (int i = 0; i < NP; i++) if (p_v[i] && p_tag[i] == req_tag && p_dst[i] == req_src) dup = 1'b1;
          for (int i = NP - 1; i >= 0; i--) if (!p_v[i]) k = i;
          if (dup) e[1] = 1'b1;
          else if (k < 0) e[0] = 1'b1;
          else begin
            off = req_addr - win_base;
            l = off[13:6];
            st = 2'd0; d = '0;
            if (req_op > 4'd5) st = 2'd1;
            else if ((req_op <= 4'd1 && req_addr[5:0] != 0) || (req_op >= 4'd2 && req_addr[2:0] != 0)) st = 2'd1;
            else if (req_addr < win_base || off >= 40'h4000) st = 2'd2;
            else case (req_op)
              4'd0: begin d = mem[l]; if (pois[l]) st = 2'd3; end
              4'd1: begin
                for (int b = 0; b < 64; b++) if (req_be[b]) mem[l][8 * b +: 8] = req_wdata[8 * b +: 8];
                if (req_poison) pois[l] = 1'b1;
                else if (&req_be) pois[l] = 1'b0;
              end
              default: begin : at
                logic [63:0] o, n;
                o = mem[l][64 * int'(req_addr[5:3]) +: 64];
                d[63:0] = o;
                if (pois[l]) st = 2'd3;
                else begin
                  case (req_op)
                    4'd2, 4'd5: n = o + req_wdata[63:0];
                    4'd3:       n = req_wdata[63:0];
                    default:    n = (o == req_wdata[63:0]) ? req_wdata[127:64] : o;
                  endcase
                  mem[l][64 * int'(req_addr[5:3]) +: 64] = n;
                end
              end
            endcase
            if (req_op == 4'd5 && st == 2'd0) ret = ret + 2'd1;          // no response
            else begin
              used = used + 1;
              p_v[k] = 1'b1; p_tag[k] = req_tag; p_dst[k] = req_src; p_st[k] = st; p_d[k] = d;
              p_due[k] = now + 3 + 5 * int'(req_addr[7:6]); p_ord[k] = ord; ord = ord + 1;
            end
          end
        end
      end

      // next response: earliest due, then arrival order
      if (cur < 0) begin
        for (int i = 0; i < NP; i++)
          if (p_v[i] && p_due[i] <= now &&
              (cur < 0 || p_due[i] < p_due[cur] || (p_due[i] == p_due[cur] && p_ord[i] < p_ord[cur]))) cur = i;
        if (cur >= 0) begin
          rsp_tag <= p_tag[cur]; rsp_dst <= p_dst[cur]; rsp_status <= p_st[cur]; rsp_data <= p_d[cur];
        end
      end
      rsp_valid <= (cur >= 0);
      crd_ret <= ret;
      err <= e;
    end
  end
endmodule
