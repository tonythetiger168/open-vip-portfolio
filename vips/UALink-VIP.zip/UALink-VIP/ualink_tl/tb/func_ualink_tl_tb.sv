// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator
//
// func_ualink_tl_tb.sv -- requesting accelerator for ualink_tl_model, with
// its own reference memory and the transaction rules written out
// independently of the model:
//   * READ / WRITE with byte enables, responses routed to the requester
//   * out-of-order responses matched by tag; arrival-order execution
//     (a read right after a slower write sees the write)
//   * atomics ADD / SWAP / CAS (hit and miss) returning the old value,
//     ADD without response (credit back on arrival)
//   * status UR (opcode, alignment), address outside the window, poison
//     set by a write, kept by a partial write, cleared by a full write
//   * misrouted request, duplicate outstanding tag, credit overflow,
//     response held stable under back-pressure
//   * 600 random requests with random back-pressure
// Run: python3 tools/run_func_tests.py UALink-VIP
module func_ualink_tl_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int REQ_CRD = 8;
  localparam logic [9:0] MY_ID = 10'h021, SRC = 10'h105;
  localparam logic [39:0] BASE = 40'h00_1234_0000;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic req_valid = 0, req_poison = 0, rsp_ready = 1;
  logic [3:0] req_op = 0;
  logic [9:0] req_tag = 0, req_src = SRC, req_dst = MY_ID;
  logic [39:0] req_addr = 0;
  logic [511:0] req_wdata = 0;
  logic [63:0] req_be = 0;
  wire rsp_valid;
  wire [9:0] rsp_tag, rsp_dst;
  wire [1:0] rsp_status, crd_ret;
  wire [511:0] rsp_data;
  wire [2:0] err;
  always #5 clk = ~clk;

  ualink_tl_model #(.REQ_CRD(REQ_CRD), .MY_ID(MY_ID)) u_dut (.clk, .rst_n, .win_base(BASE), .req_valid,
    .req_op, .req_tag, .req_src, .req_dst, .req_addr, .req_wdata, .req_be, .req_poison, .rsp_valid,
    .rsp_ready, .rsp_tag, .rsp_dst, .rsp_status, .rsp_data, .crd_ret, .err);

  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  logic [2:0] err_acc = 0;
  always @(posedge clk) err_acc <= err_acc | err;
  int credits_back = 0;
  always @(posedge clk) credits_back <= credits_back + int'(crd_ret);
  task automatic wait_clk(input int n); repeat (n) @(negedge clk); endtask

  // ------------------------------------------------------------ reference
  logic [511:0] rm [0:255];
  bit           rp [0:255];
  typedef struct { bit v; bit noresp; logic [1:0] st; logic [511:0] d; logic [9:0] dst; int t; } exp_t;
  exp_t ex [logic [19:0]];                // {src, tag}
  // apply a request to the reference; returns the expected response
  function automatic exp_t ref_req(input logic [3:0] op, input logic [39:0] a, input logic [511:0] w,
                                   input logic [63:0] be, input bit pz, input logic [9:0] src);
    exp_t r;
    logic [39:0] off;
    int l, wd;
    r.v = 1; r.noresp = 0; r.st = 0; r.d = '0; r.dst = src; r.t = cyc;
    off = a - BASE; l = int'(off[13:6]); wd = int'(a[5:3]);
    if (op > 5 || (op <= 1 && a[5:0] != 0) || (op >= 2 && a[2:0] != 0)) r.st = 1;
    else if (a < BASE || a >= BASE + 40'h4000) r.st = 2;
    else if (op == 0) begin r.d = rm[l]; if (rp[l]) r.st = 3; end
    else if (op == 1) begin
      for (int b = 0; b < 64; b++) if (be[b]) rm[l][8 * b +: 8] = w[8 * b +: 8];
      if (pz) rp[l] = 1; else if (be == '1) rp[l] = 0;
    end else begin
      logic [63:0] o;
      o = rm[l][64 * wd +: 64];
      r.d[63:0] = o;
      if (rp[l]) r.st = 3;
      else if (op == 2 || op == 5) rm[l][64 * wd +: 64] = o + w[63:0];
      else if (op == 3) rm[l][64 * wd +: 64] = w[63:0];
      else if (o == w[63:0]) rm[l][64 * wd +: 64] = w[127:64];
    end
    if (op == 5 && r.st == 0) r.noresp = 1;
    return r;
  endfunction

  // ------------------------------------------------------------ requester
  int got = 0, bad = 0, unexp = 0;
  int rq_t [logic [19:0]], rs_t [logic [19:0]];
  always @(posedge clk) if (req_valid) rq_t[{req_src, req_tag}] = cyc;
  always @(posedge clk) if (rsp_valid && rsp_ready) rs_t[{rsp_dst, rsp_tag}] = cyc;
  logic [9:0] order [0:4095];
  bit check_ex = 1;
  always @(posedge clk) begin
    if (rsp_valid && rsp_ready) begin
      logic [19:0] k;
      k = {rsp_dst, rsp_tag};
      order[got % 4096] = rsp_tag; got++;
      if (check_ex) begin
        if (!ex.exists(k) || ex[k].noresp) unexp++;
        else begin
          if (rsp_status !== ex[k].st || (ex[k].st != 2'd1 && ex[k].st != 2'd2 && rsp_data !== ex[k].d)) begin
            bad++;
            $display("  resp tag %h st %0d exp %0d", rsp_tag, rsp_status, ex[k].st);
          end
          ex.delete(k);
        end
      end
    end
  end

  task automatic req(input logic [3:0] op, input logic [9:0] tag, input logic [39:0] a,
                     input logic [511:0] w = '0, input logic [63:0] be = '1, input bit pz = 0,
                     input logic [9:0] src = SRC, input logic [9:0] dst = MY_ID, input bit record = 1);
    @(negedge clk);
    req_valid = 1; req_op = op; req_tag = tag; req_addr = a; req_wdata = w; req_be = be;
    req_poison = pz; req_src = src; req_dst = dst;
    if (record) begin
      exp_t r;
      r = ref_req(op, a, w, be, pz, src);
      if (!r.noresp) ex[{src, tag}] = r;
    end
    @(negedge clk);
    req_valid = 0;
  endtask
  task automatic drain(input int n = 60); wait_clk(n); endtask
  function automatic logic [511:0] rnd512();
    logic [511:0] v;
    for (int i = 0; i < 512; i += 32) v[i +: 32] = $urandom;
    return v;
  endfunction
  function automatic logic [63:0] rnd64(); return {$urandom, $urandom}; endfunction

  initial begin
    logic [511:0] d0, d1;
    int g0, c0;
    for (int i = 0; i < 256; i++) begin rm[i] = '0; rp[i] = 0; end
    wait_clk(3); rst_n = 1; wait_clk(2);

    // ---- write / read, byte enables, routing
    d0 = rnd512(); d1 = rnd512();
    req(1, 10'h001, BASE + 40'h0100, d0);
    req(1, 10'h002, BASE + 40'h0100, d1, 64'h00FF_0000_F0F0_0001);
    req(0, 10'h003, BASE + 40'h0100);
    drain();
    chk(got == 3 && bad == 0 && unexp == 0 && ex.size() == 0, $sformatf("write, partial write, read back (%0d responses, %0d bad)", got, bad));
    chk(credits_back == 3 && err_acc == 0, "one credit back per accepted response");

    // ---- out-of-order responses
    g0 = got;
    req(0, 10'h010, BASE + 40'h01C0);          // addr[7:6] = 3: slowest
    req(0, 10'h011, BASE + 40'h0180);
    req(0, 10'h012, BASE + 40'h0140);
    req(0, 10'h013, BASE + 40'h0100);          // fastest
    drain();
    chk(got == g0 + 4 && order[g0] == 10'h013 && order[g0 + 1] == 10'h012 && order[g0 + 2] == 10'h011 &&
        order[g0 + 3] == 10'h010, "responses reordered by latency, matched by tag");
    // a slow write, then a fast read of the same line: the read sees the write
    g0 = got;
    req(1, 10'h020, BASE + 40'h03C0, rnd512());
    req(0, 10'h021, BASE + 40'h03C0);
    drain();
    chk(got == g0 + 2 && bad == 0 && order[g0] == 10'h020, "read after write to the same line sees the write; arrival order kept at equal latency");

    // ---- atomics
    g0 = got;
    req(1, 10'h030, BASE + 40'h0200, {448'h0, 64'd100});
    req(2, 10'h031, BASE + 40'h0200, {448'h0, 64'd23});                  // ADD -> old 100
    req(3, 10'h032, BASE + 40'h0200, {448'h0, 64'hDEAD});                // SWAP -> old 123
    req(4, 10'h033, BASE + 40'h0200, {384'h0, 64'h5555, 64'hDEAD});      // CAS hit -> old DEAD, new 5555
    req(4, 10'h034, BASE + 40'h0200, {384'h0, 64'h7777, 64'hDEAD});      // CAS miss -> old 5555
    req(2, 10'h035, BASE + 40'h0218, {448'h0, 64'd7});                   // ADD in word 3 of the line
    drain();
    c0 = credits_back;
    req(5, 10'h036, BASE + 40'h0200, {448'h0, 64'd1});                   // ADD, no response
    wait_clk(1);
    chk(credits_back == c0 + 1, "ADD without response returns its credit on arrival");
    req(0, 10'h037, BASE + 40'h0200);
    drain();
    chk(got == g0 + 7 && bad == 0 && unexp == 0 && ex.size() == 0,
        $sformatf("ADD / SWAP / CAS hit / CAS miss return the old value; no-response ADD applied (%0d bad)", bad));

    // ---- UR and window errors
    g0 = got;
    req(9, 10'h040, BASE + 40'h0300);
    req(0, 10'h041, BASE + 40'h0308);
    req(1, 10'h048, BASE + 40'h0320, rnd512());                          // misaligned WRITE
    req(2, 10'h042, BASE + 40'h0304, {448'h0, 64'd1});
    req(5, 10'h047, BASE + 40'h0304, {448'h0, 64'd1});                   // no-response op with an error responds
    req(0, 10'h043, BASE - 40'h40);
    req(1, 10'h044, BASE + 40'h4000, rnd512());
    req(0, 10'h045, BASE + 40'h3FC0);
    req(0, 10'h046, BASE + 40'h0300);
    drain();
    chk(got == g0 + 9 && bad == 0 && unexp == 0 && ex.size() == 0,
        "opcode / alignment: UR; outside the window: address error; last line inside the window OK");

    // ---- latency 3 + 5 * addr[7:6] clocks, then one clock to the handshake
    begin
      bit ok;
      ok = 1;
      for (int k = 0; k < 4; k++) begin
        req(0, 10'(10'h0A0 + k), BASE + 40'(64 * k));
        drain(30);
        if (rs_t[{SRC, 10'(10'h0A0 + k)}] - rq_t[{SRC, 10'(10'h0A0 + k)}] != 4 + 5 * k) ok = 0;
      end
      chk(ok && bad == 0, "response latency 3 + 5 * addr[7:6] for each latency class");
      // equal due times: arrival order wins
      g0 = got;
      req(0, 10'h0B0, BASE + 40'h0040);                                  // due +8
      wait_clk(3);
      req(0, 10'h0B1, BASE + 40'h0000);                                  // 5 clocks later, due +3: same clock
      drain(30);
      chk(got == g0 + 2 && order[g0] == 10'h0B0 && order[g0 + 1] == 10'h0B1 &&
          rq_t[{SRC, 10'h0B1}] - rq_t[{SRC, 10'h0B0}] == 5, "equal due times leave in arrival order");
      // the same with the later request in a lower response slot
      g0 = got;
      req(0, 10'h0C0, BASE + 40'h0000);                                  // slot 0, due +3
      req(0, 10'h0C1, BASE + 40'h0040);                                  // slot 1, due +8
      wait_clk(3);
      req(0, 10'h0C2, BASE + 40'h0000);                                  // slot 0 again, due +3: same clock
      drain(30);
      chk(got == g0 + 3 && order[g0] == 10'h0C0 && order[g0 + 1] == 10'h0C1 && order[g0 + 2] == 10'h0C2 &&
          rq_t[{SRC, 10'h0C2}] - rq_t[{SRC, 10'h0C1}] == 5 && rs_t[{SRC, 10'h0C0}] < rq_t[{SRC, 10'h0C2}],
          "equal due times: arrival order, not response-slot order");
    end

    // ---- poison
    g0 = got;
    req(1, 10'h050, BASE + 40'h0400, rnd512(), '1, 1);
    req(0, 10'h051, BASE + 40'h0400);
    req(2, 10'h052, BASE + 40'h0408, {448'h0, 64'd5});
    req(1, 10'h053, BASE + 40'h0400, rnd512(), 64'h0000_0000_0000_FFFF);   // partial: stays poisoned
    req(0, 10'h054, BASE + 40'h0400);
    req(1, 10'h055, BASE + 40'h0400, rnd512());                           // full: clears
    req(0, 10'h056, BASE + 40'h0400);
    drain();
    chk(got == g0 + 7 && bad == 0 && ex.size() == 0,
        "poisoned line: reads and atomics report poison, atomic leaves it, partial write keeps it, full write clears it");

    // ---- misrouted, duplicate tag, other source with the same tag
    g0 = got; err_acc = 0;
    req(0, 10'h060, BASE + 40'h01C0, '0, '1, 0, SRC, 10'h022, 0);
    wait_clk(2);
    chk(err_acc == 3'b100, "request for another accelerator ID dropped");
    req(0, 10'h061, BASE + 40'h01C0);
    req(0, 10'h061, BASE + 40'h0100, '0, '1, 0, SRC, MY_ID, 0);
    wait_clk(2);
    chk(err_acc == 3'b110, "second request with an outstanding tag dropped");
    req(0, 10'h061, BASE + 40'h0100, '0, '1, 0, 10'h106);
    drain();
    chk(got == g0 + 2 && bad == 0 && unexp == 0 && ex.size() == 0, "same tag from another source accepted; responses routed to each source");

    // ---- credits and back-pressure
    g0 = got; err_acc = 0; c0 = credits_back;
    rsp_ready = 0;
    for (int i = 0; i < REQ_CRD; i++) req(0, 10'(10'h070 + i), BASE + 40'(64 * i));
    req(0, 10'h07F, BASE, '0, '1, 0, SRC, MY_ID, 0);
    wait_clk(2);
    chk(err_acc == 3'b001, "request beyond the credits dropped");
    wait_clk(30);
    begin
      logic [9:0] t0;
      bit stable;
      t0 = rsp_tag; stable = rsp_valid;
      for (int i = 0; i < 10; i++) begin @(negedge clk); if (!rsp_valid || rsp_tag != t0) stable = 0; end
      chk(stable && got == g0 && credits_back == c0, "response held stable while not accepted, no credit back");
    end
    rsp_ready = 1;
    drain();
    chk(got == g0 + REQ_CRD && credits_back == c0 + REQ_CRD && bad == 0 && ex.size() == 0, "all credits back once the responses are taken");

    // ---- random traffic
    begin : rnd
      int sent, cred, outst;
      logic [9:0] nt;
      err_acc = 0; g0 = got;
      sent = 0; cred = REQ_CRD; nt = 10'h100; c0 = credits_back;
      fork
        begin
          while (sent < 600) begin
            logic [3:0] op;
            logic [39:0] a;
            int r;
            // credits come back on crd_ret
            cred = REQ_CRD - (sent - (credits_back - c0));
            rsp_ready = ($urandom_range(9) < 7);
            r = $urandom_range(99);
            op = (r < 35) ? 4'd0 : (r < 70) ? 4'd1 : (r < 78) ? 4'd2 : (r < 84) ? 4'd3 : (r < 90) ? 4'd4 :
                 (r < 95) ? 4'd5 : (r < 97) ? 4'd8 : 4'd0;
            a = BASE + 40'($urandom_range(15) * 64);
            if (op >= 2) a = a + 40'(8 * $urandom_range(7));
            if (r >= 97) a = BASE + 40'h4000 + 40'($urandom_range(3) * 64);
            if (cred > 0 && !ex.exists({SRC, nt})) begin
              logic [511:0] w;
              w = rnd512();
              if (op == 4) w[63:0] = ($urandom_range(1) == 0) ? rm[int'(a[13:6])][64 * int'(a[5:3]) +: 64] : rnd64();
              req(op, nt, a, w, ($urandom_range(3) == 0) ? rnd64() : '1, ($urandom_range(19) == 0));
              sent++;
              nt = (nt == 10'h3FF) ? 10'h100 : nt + 10'd1;
            end else wait_clk(1);
          end
        end
      join
      rsp_ready = 1;
      drain(120);
      chk(err_acc == 0, "600 random requests within credits: no error");
      chk(bad == 0 && unexp == 0 && ex.size() == 0, $sformatf("every random request answered once with the expected status and data (%0d bad, %0d missing)", bad, ex.size()));
      chk(credits_back - c0 == sent, $sformatf("every credit returned (%0d of %0d)", credits_back - c0, sent));
    end

    // ---- reset clears memory and poison
    req(1, 10'h0C0, BASE + 40'h0000, rnd512(), '1, 1);
    drain();
    rst_n = 0; wait_clk(3); rst_n = 1;
    for (int i = 0; i < 256; i++) begin rm[i] = '0; rp[i] = 0; end
    ex.delete();
    g0 = got;
    req(0, 10'h0C1, BASE + 40'h0000);
    drain();
    chk(got == g0 + 1 && bad == 0 && ex.size() == 0, "after reset line 0 reads zero, not poisoned");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #5ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
