// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ualink_inc_model.sv -- UALink 2.0 In-Network Compute (INC) engine in a
// switch: accelerators on up to 4 switch ports contribute a vector to a
// collective (all-reduce) group, the switch reduces the contributions and
// multicasts the result to every member port. The structure follows the
// UALink 2.0 In-Network Compute description; opcode encodings, field
// widths, status and error codes are this model's own.
//
// Groups (16): cfg_we writes cfg_mask (member ports) for cfg_grp. A write
//   resets the group: round sequence 0, no contribution, no result held.
//   Mask 0 disables the group.
// Contribution (one per clock, in_valid): in_port, in_grp, in_seq, in_op,
//   in_data = 4 signed 32-bit lanes. in_op: 0 SUM (saturating, status 1
//   when any lane saturated in the round), 1 MIN, 2 MAX (signed), 3 AND,
//   4 OR, 5 XOR. The next clock in_ack pulses with in_err:
//     0 accepted
//     1 group disabled or port not a member
//     6 group busy (its previous result not yet delivered)
//     3 in_seq is not the group's current round
//     2 the port already contributed in this round
//     5 opcode > 5
//     4 opcode differs from the round's first contribution
//   (checked in this order; a rejected contribution changes nothing).
// Result: when every member port has contributed, the round's result is
//   held for delivery and the group's round advances (seq + 1). A round
//   with at least one contribution that does not complete within TMO
//   clocks of its first contribution is aborted: status 2, data 0,
//   out_mask = the ports that contributed, round advances.
// Delivery: out_valid until out_ready, with out_grp, out_seq, out_mask
//   (ports the multicast goes to), out_status 0 OK / 1 saturated /
//   2 timeout, out_data. Several held results leave lowest group first.
module ualink_inc_model #(parameter int TMO = 40) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         cfg_we,
  input  logic [3:0]   cfg_grp,
  input  logic [3:0]   cfg_mask,
  input  logic         in_valid,
  input  logic [1:0]   in_port,
  input  logic [3:0]   in_grp,
  input  logic [7:0]   in_seq,
  input  logic [2:0]   in_op,
  input  logic [127:0] in_data,
  output logic         in_ack,
  output logic [2:0]   in_err,
  output logic         out_valid,
  input  logic         out_ready,
  output logic [3:0]   out_grp,
  output logic [7:0]   out_seq,
  output logic [3:0]   out_mask,
  output logic [1:0]   out_status,
  output logic [127:0] out_data
);
  logic [3:0]   g_mask [0:15], g_arr [0:15], r_mask [0:15];
  logic [7:0]   g_seq [0:15], r_seq [0:15];
  logic [2:0]   g_op [0:15];
  logic [127:0] g_acc [0:15], r_data [0:15];
  logic         g_sat [0:15], r_v [0:15];
  logic [1:0]   r_st [0:15];
  int           g_age [0:15];
  int           cur;

  // {saturated, lane result}
  function automatic logic [32:0] lane(input logic [2:0] op, input logic [31:0] a, input logic [31:0] b);
    logic [32:0] s;
    case (op)
      3'd0: begin
        s = {a[31], a} + {b[31], b};
        if (s[32] != s[31]) return s[32] ? 33'h1_8000_0000 : 33'h1_7FFF_FFFF;
        return {1'b0, s[31:0]};
      end
      3'd1: return {1'b0, ($signed(a) < $signed(b)) ? a : b};
      3'd2: return {1'b0, ($signed(a) > $signed(b)) ? a : b};
      3'd3: return {1'b0, a & b};
      3'd4: return {1'b0, a | b};
      default: return {1'b0, a ^ b};
    endcase
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int g = 0; g < 16; g++) begin
        g_mask[g] = '0; g_arr[g] = '0; g_seq[g] = '0; g_op[g] = '0; g_acc[g] = '0; g_sat[g] = 1'b0;
        g_age[g] = 0; r_v[g] = 1'b0; r_mask[g] = '0; r_seq[g] = '0; r_data[g] = '0; r_st[g] = '0;
      end
      cur = -1;
      in_ack <= 1'b0; in_err <= '0;
      out_valid <= 1'b0; out_grp <= '0; out_seq <= '0; out_mask <= '0; out_status <= '0; out_data <= '0;
    end else begin : step
      logic [2:0] e;
      e = 3'd0;

      // delivery handshake
      if (cur >= 0 && out_ready) begin r_v[cur] = 1'b0; cur = -1; end

      // configuration
      if (cfg_we) begin
        g_mask[cfg_grp] = cfg_mask; g_arr[cfg_grp] = '0; g_seq[cfg_grp] = '0; g_sat[cfg_grp] = 1'b0;
        g_age[cfg_grp] = 0; r_v[cfg_grp] = 1'b0;
        if (cur == int'(cfg_grp)) cur = -1;
      end

      // contribution
      if (in_valid) begin
        if (!g_mask[in_grp][in_port]) e = 3'd1;
        else if (r_v[in_grp]) e = 3'd6;
        else if (in_seq != g_seq[in_grp]) e = 3'd3;
        else if (g_arr[in_grp][in_port]) e = 3'd2;
        else if (in_op > 3'd5) e = 3'd5;
        else if (g_arr[in_grp] != 0 && in_op != g_op[in_grp]) e = 3'd4;
        else begin
          if (g_arr[in_grp] == 0) begin
            g_acc[in_grp] = in_data; g_op[in_grp] = in_op; g_sat[in_grp] = 1'b0; g_age[in_grp] = 0;
          end else begin : red
            logic [32:0] r;
            for (int i = 0; i < 4; i++) begin
              r = lane(in_op, g_acc[in_grp][32 * i +: 32], in_data[32 * i +: 32]);
              g_acc[in_grp][32 * i +: 32] = r[31:0];
              if (r[32]) g_sat[in_grp] = 1'b1;
            end
          end
          g_arr[in_grp][in_port] = 1'b1;
          if (g_arr[in_grp] == g_mask[in_grp]) begin
            r_v[in_grp] = 1'b1; r_mask[in_grp] = g_mask[in_grp]; r_seq[in_grp] = g_seq[in_grp];
            r_data[in_grp] = g_acc[in_grp]; r_st[in_grp] = g_sat[in_grp] ? 2'd1 : 2'd0;
            g_arr[in_grp] = '0; g_seq[in_grp] = g_seq[in_grp] + 8'd1;
          end
        end
      end

      // round timeout
      for (int g = 0; g < 16; g++)
        if (g_arr[g] != 0) begin
          g_age[g] = g_age[g] + 1;
          if (g_age[g] >= TMO) begin
            r_v[g] = 1'b1; r_mask[g] = g_arr[g]; r_seq[g] = g_seq[g]; r_data[g] = '0; r_st[g] = 2'd2;
            g_arr[g] = '0; g_seq[g] = g_seq[g] + 8'd1;
          end
        end

      // next delivery: lowest group with a held result
      if (cur < 0) begin
        for (int g = 15; g >= 0; g--) if (r_v[g]) cur = g;
        if (cur >= 0) begin
          out_grp <= 4'(cur); out_seq <= r_seq[cur]; out_mask <= r_mask[cur];
          out_status <= r_st[cur]; out_data <= r_data[cur];
        end
      end
      out_valid <= (cur >= 0);
      in_ack <= in_valid;
      in_err <= e;
    end
  end
endmodule
