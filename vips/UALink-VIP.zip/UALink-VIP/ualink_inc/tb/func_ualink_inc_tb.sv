// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// FUNC_SIM: iverilog
//
// func_ualink_inc_tb.sv -- accelerator ports and a host for
// ualink_inc_model (UALink 2.0 In-Network Compute), with a reference of the
// collective rules written out independently of the model:
//   * all-reduce SUM / MIN / MAX / AND / OR / XOR over 4 signed lanes,
//     hand-computed results, multicast mask and round sequence
//   * SUM saturation (both signs) and the saturated status, reset per round
//   * every rejection code (non-member, disabled group, busy, wrong round,
//     duplicate, bad opcode, opcode mismatch) with no effect on the round
//   * round timeout and its exact boundary, partial multicast mask
//   * held results under back-pressure, lowest group first, reconfiguration
//   * 1500 random contributions on 4 groups with random back-pressure,
//     checked clock by clock against the reference
// Run: python3 tools/run_func_tests.py UALink-VIP
`timescale 1ns/1ps
module func_ualink_inc_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int TMO = 40;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic cfg_we = 0, in_valid = 0, out_ready = 1;
  logic [3:0] cfg_grp = 0, cfg_mask = 0, in_grp = 0;
  logic [1:0] in_port = 0;
  logic [7:0] in_seq = 0;
  logic [2:0] in_op = 0;
  logic [127:0] in_data = 0;
  wire in_ack, out_valid;
  wire [2:0] in_err;
  wire [3:0] out_grp, out_mask;
  wire [7:0] out_seq;
  wire [1:0] out_status;
  wire [127:0] out_data;
  always #5 clk = ~clk;

  ualink_inc_model #(.TMO(TMO)) u_dut (.clk, .rst_n, .cfg_we, .cfg_grp, .cfg_mask, .in_valid, .in_port,
    .in_grp, .in_seq, .in_op, .in_data, .in_ack, .in_err, .out_valid, .out_ready, .out_grp, .out_seq,
    .out_mask, .out_status, .out_data);

  task automatic wait_clk(input int n); repeat (n) @(negedge clk); endtask

  // ------------------------------------------------------------ reference
  bit [3:0]   m_mask [16], m_arr [16];
  int         m_seq [16], m_op [16], m_age [16];
  longint     m_acc [16][4];
  bit         m_sat [16];
  bit         h_v [16];
  bit [3:0]   h_mask [16];
  int         h_seq [16], h_st [16];
  longint     h_d [16][4];

  function automatic longint s32(input logic [31:0] x); return longint'($signed(x)); endfunction
  // reduction of one lane; SUM is left unclamped (clamped by the caller)
  function automatic longint red(input int op, input longint a, input longint b);
    longint r;
    case (op)
      0: r = a + b;
      1: r = (a < b) ? a : b;
      2: r = (a > b) ? a : b;
      3: r = s32(a[31:0] & b[31:0]);
      4: r = s32(a[31:0] | b[31:0]);
      default: r = s32(a[31:0] ^ b[31:0]);
    endcase
    return r;
  endfunction

  int exp_err = -1;          // expected in_err for the contribution of the last clock
  int ack_bad = 0, del_bad = 0, del_unexp = 0, delivered = 0;
  int del_grp [$];
  bit check_on = 1;
  always @(posedge clk) if (rst_n && check_on) begin
    int e;
    // delivery handshake
    if (out_valid && out_ready) begin
      int g;
      g = int'(out_grp);
      delivered++; del_grp.push_back(g);
      if (!h_v[g]) del_unexp++;
      else begin
        bit ok;
        ok = out_mask == h_mask[g] && int'(out_seq) == (h_seq[g] & 255) && int'(out_status) == h_st[g];
        for (int i = 0; i < 4; i++) if (s32(out_data[32 * i +: 32]) != h_d[g][i]) ok = 0;
        if (!ok) begin
          del_bad++;
          $display("  delivery g%0d seq %0d st %0d mask %b exp seq %0d st %0d mask %b", g, out_seq, out_status,
                   out_mask, h_seq[g] & 255, h_st[g], h_mask[g]);
        end
        h_v[g] = 0;
      end
    end
    if (cfg_we) begin
      m_mask[cfg_grp] = cfg_mask; m_arr[cfg_grp] = 0; m_seq[cfg_grp] = 0; h_v[cfg_grp] = 0; m_age[cfg_grp] = 0;
    end
    e = -1;
    if (in_valid) begin
      int g, p;
      g = int'(in_grp); p = int'(in_port);
      if (m_mask[g][p] == 0) e = 1;
      else if (h_v[g]) e = 6;
      else if (int'(in_seq) != (m_seq[g] & 255)) e = 3;
      else if (m_arr[g][p]) e = 2;
      else if (in_op > 5) e = 5;
      else if (m_arr[g] != 0 && int'(in_op) != m_op[g]) e = 4;
      else begin
        e = 0;
        if (m_arr[g] == 0) begin
          m_op[g] = in_op; m_sat[g] = 0; m_age[g] = 0;
          for (int i = 0; i < 4; i++) m_acc[g][i] = s32(in_data[32 * i +: 32]);
        end else
          for (int i = 0; i < 4; i++) begin
            m_acc[g][i] = red(m_op[g], m_acc[g][i], s32(in_data[32 * i +: 32]));
            if (m_acc[g][i] > 64'sd2147483647) begin m_acc[g][i] = 64'sd2147483647; m_sat[g] = 1; end
            if (m_acc[g][i] < -64'sd2147483648) begin m_acc[g][i] = -64'sd2147483648; m_sat[g] = 1; end
          end
        m_arr[g][p] = 1;
        if (m_arr[g] == m_mask[g]) begin
          h_v[g] = 1; h_mask[g] = m_mask[g]; h_seq[g] = m_seq[g]; h_st[g] = m_sat[g] ? 1 : 0;
          for (int i = 0; i < 4; i++) h_d[g][i] = m_acc[g][i];
          m_arr[g] = 0; m_seq[g]++;
        end
      end
    end
    for (int g = 0; g < 16; g++) if (m_arr[g] != 0) begin
      m_age[g]++;
      if (m_age[g] == TMO) begin
        h_v[g] = 1; h_mask[g] = m_arr[g]; h_seq[g] = m_seq[g]; h_st[g] = 2;
        for (int i = 0; i < 4; i++) h_d[g][i] = 0;
        m_arr[g] = 0; m_seq[g]++;
      end
    end
    exp_err = e;
  end
  // in_ack / in_err one clock after the contribution
  always @(negedge clk) if (rst_n && check_on) begin
    if (in_ack !== (exp_err >= 0) || (exp_err >= 0 && int'(in_err) != exp_err)) begin
      ack_bad++;
      $display("  ack %b err %0d exp %0d", in_ack, in_err, exp_err);
    end
  end

  function automatic logic [127:0] v4(input int a, input int b, input int c, input int d);
    return {d[31:0], c[31:0], b[31:0], a[31:0]};
  endfunction
  task automatic cfg(input int g, input logic [3:0] m);
    @(negedge clk); cfg_we = 1; cfg_grp = g; cfg_mask = m;
    @(negedge clk); cfg_we = 0;
  endtask
  task automatic put(input int port, input int g, input int seq, input int op, input logic [127:0] d);
    @(negedge clk);
    in_valid = 1; in_port = port; in_grp = g; in_seq = seq; in_op = op; in_data = d;
    @(negedge clk); in_valid = 0;
  endtask
  task automatic drain(input int n = 4); wait_clk(n); endtask
  bit hold_ok = 1;

  initial begin
    int d0, sum_ok;
    wait_clk(3); rst_n = 1; wait_clk(2);

    // ---- SUM over 4 ports, hand-computed
    cfg(1, 4'b1111);
    d0 = delivered; del_grp.delete();
    put(0, 1, 0, 0, v4(1, -5, 100, 7));
    put(1, 1, 0, 0, v4(2, -6, 200, 0));
    put(2, 1, 0, 0, v4(3, 10, -50, 0));
    chk(in_ack && in_err == 0 && !out_valid && delivered == d0, "3 of 4 contributions accepted, no result yet");
    put(3, 1, 0, 0, v4(4, 1, 0, -7));
    chk(out_valid && out_grp == 1 && out_seq == 0 && out_mask == 4'b1111 && out_status == 0 &&
        out_data == v4(10, 0, 250, 0), "SUM all-reduce: (10, 0, 250, 0) multicast to ports 0-3, round 0");
    drain();
    chk(delivered == d0 + 1 && del_bad == 0 && del_unexp == 0, "result delivered exactly once");

    // ---- MIN / MAX / AND / OR / XOR in following rounds
    begin
      int r [5];
      int seqn;
      logic [127:0] a, b, c, d;
      a = v4(-3, 8, 32'h0F0F, 5); b = v4(4, -9, 32'h00FF, 5); c = v4(0, 7, 32'hF00F, -1); d = v4(-1, 8, 32'h0FF0, 2);
      seqn = 1;
      for (int op = 1; op <= 5; op++) begin
        put(2, 1, seqn, op, a); put(0, 1, seqn, op, b); put(3, 1, seqn, op, c); put(1, 1, seqn, op, d);
        case (op)
          1: chk(out_valid && out_data == v4(-3, -9, 32'h00FF, -1), "MIN is signed per lane");
          2: chk(out_valid && out_data == v4(4, 8, 32'hF00F, 5), "MAX is signed per lane");
          3: chk(out_valid && out_data == v4(-3 & 4 & 0 & -1, 8 & -9 & 7 & 8, 32'h0000, 5 & 5 & -1 & 2), "AND per lane");
          4: chk(out_valid && out_data == v4(-3 | 4 | 0 | -1, 8 | -9 | 7 | 8, 32'hFFFF, 5 | 5 | -1 | 2), "OR per lane");
          5: chk(out_valid && out_data == v4(-3 ^ 4 ^ 0 ^ -1, 8 ^ -9 ^ 7 ^ 8, 32'h0F0F ^ 32'h00FF ^ 32'hF00F ^ 32'h0FF0, 5 ^ 5 ^ -1 ^ 2), "XOR per lane");
        endcase
        chk(out_seq == seqn && out_status == 0, $sformatf("op %0d: round %0d, status OK", op, seqn));
        drain(2);
        seqn++;
      end
    end

    // ---- saturation
    cfg(2, 4'b0011);
    put(0, 2, 0, 0, v4(32'h7FFF_FFF0, 32'h8000_0010, -100, 1));
    put(1, 2, 0, 0, v4(32'h20, -32'h20, 50, 1));
    chk(out_valid && out_grp == 2 && out_status == 1 &&
        out_data == v4(32'h7FFF_FFFF, 32'h8000_0000, -50, 2), "SUM saturates at both ends, status saturated");
    drain(2);
    put(1, 2, 1, 0, v4(32'h7FFF_FFFE, 0, 0, 0));
    put(0, 2, 1, 0, v4(1, 0, 0, 0));
    chk(out_valid && out_status == 0 && out_data == v4(32'h7FFF_FFFF, 0, 0, 0), "exact max is not saturated; flag reset per round");
    drain(2);
    put(0, 2, 2, 0, v4(32'h8000_0001, 0, 0, 0));
    put(1, 2, 2, 0, v4(-1, 0, 0, 0));
    chk(out_valid && out_status == 0 && out_data == v4(32'h8000_0000, 0, 0, 0), "exact min is not saturated");
    drain(2);

    // ---- rejections
    cfg(3, 4'b0101);
    put(1, 3, 0, 0, v4(9, 9, 9, 9));
    chk(in_ack && in_err == 1, "port not in the group: rejected (1)");
    put(0, 4, 0, 0, v4(9, 9, 9, 9));
    chk(in_ack && in_err == 1, "disabled group: rejected (1)");
    put(0, 3, 1, 0, v4(9, 9, 9, 9));
    chk(in_ack && in_err == 3, "wrong round: rejected (3)");
    put(0, 3, 0, 0, v4(1, 2, 3, 4));
    chk(in_ack && in_err == 0, "first contribution accepted");
    put(0, 3, 0, 0, v4(9, 9, 9, 9));
    chk(in_ack && in_err == 2, "second contribution from the same port: rejected (2)");
    put(2, 3, 0, 6, v4(9, 9, 9, 9));
    chk(in_ack && in_err == 5, "opcode 6: rejected (5)");
    put(2, 3, 0, 7, v4(9, 9, 9, 9));
    chk(in_ack && in_err == 5, "opcode 7: rejected (5)");
    put(2, 3, 0, 2, v4(9, 9, 9, 9));
    chk(in_ack && in_err == 4, "opcode differs from the round: rejected (4)");
    chk(!out_valid, "rejections do not complete the round");
    put(2, 3, 0, 0, v4(10, 20, 30, 40));
    chk(out_valid && out_grp == 3 && out_mask == 4'b0101 && out_data == v4(11, 22, 33, 44),
        "rejected data left out of the result");
    drain(2);
    // busy: hold the next result
    out_ready = 0;
    put(0, 3, 1, 0, v4(5, 5, 5, 5));
    put(2, 3, 1, 0, v4(6, 6, 6, 6));
    chk(out_valid && out_seq == 1 && out_data == v4(11, 11, 11, 11), "round 1 completes and is held");
    put(0, 3, 2, 0, v4(5, 5, 5, 5));
    chk(in_ack && in_err == 6, "contribution while the result is held: busy (6)");
    chk(out_valid && out_seq == 1, "round 1 result still held under back-pressure");
    out_ready = 1; drain(2);
    put(0, 3, 1, 0, v4(5, 5, 5, 5));
    chk(in_ack && in_err == 3, "round advanced to 2 on completion, not on the busy contribution");
    put(0, 3, 2, 0, v4(5, 5, 5, 5));
    chk(in_ack && in_err == 0, "round 2 accepts after delivery");
    drain(TMO + 2);

    // ---- timeout and its boundary
    cfg(5, 4'b1110);
    d0 = delivered;
    @(negedge clk); in_valid = 1; in_port = 1; in_grp = 5; in_seq = 0; in_op = 4; in_data = v4(1, 1, 1, 1);
    @(negedge clk); in_port = 3; in_data = v4(2, 2, 2, 2);
    @(negedge clk); in_valid = 0;
    wait_clk(TMO - 3);
    chk(!out_valid && delivered == d0, "no abort before the timeout");
    wait_clk(1);
    chk(out_valid && out_grp == 5 && out_status == 2 && out_mask == 4'b1010 && out_data == 0 && out_seq == 0,
        "timeout: status 2, data 0, multicast to the ports that contributed");
    drain(2);
    // last contribution on the last clock of the window completes
    @(negedge clk); in_valid = 1; in_port = 1; in_grp = 5; in_seq = 1; in_op = 0; in_data = v4(1, 2, 3, 4);
    @(negedge clk); in_port = 2;
    @(negedge clk); in_valid = 0;
    wait_clk(TMO - 4);
    put(3, 5, 1, 0, v4(1, 1, 1, 1));
    chk(in_ack && in_err == 0 && out_valid && out_status == 0 && out_data == v4(3, 5, 7, 9), "completion on the last clock of the window");
    drain(2);
    // one clock later the round is gone
    @(negedge clk); in_valid = 1; in_port = 1; in_grp = 5; in_seq = 2; in_op = 0; in_data = v4(1, 2, 3, 4);
    @(negedge clk); in_valid = 0;
    wait_clk(TMO - 2);
    chk(!out_valid, "single contribution: no abort one clock early");
    wait_clk(1);
    chk(out_valid && out_status == 2 && out_mask == 4'b0010, "single contribution times out");
    drain(2);
    put(3, 5, 2, 0, v4(1, 1, 1, 1));
    chk(in_ack && in_err == 3, "late contribution after delivery: round has advanced (3)");

    // ---- back-pressure, lowest group first
    cfg(7, 4'b0001); cfg(6, 4'b0001);
    del_grp.delete();
    out_ready = 0;
    put(0, 7, 0, 0, v4(7, 7, 7, 7));
    wait_clk(1);
    chk(out_valid && out_grp == 7, "single-member group completes on its own contribution");
    put(0, 6, 0, 0, v4(6, 6, 6, 6));
    for (int i = 0; i < 5; i++) begin
      @(negedge clk);
      if (!(out_valid && out_grp == 7 && out_data == v4(7, 7, 7, 7))) hold_ok = 0;
    end
    chk(hold_ok, "delivery held stable under back-pressure");
    out_ready = 1; drain(4);
    chk(del_grp.size() == 2 && del_grp[0] == 7 && del_grp[1] == 6, "group 7 (on the bus first) then group 6");
    out_ready = 0;
    put(0, 7, 1, 0, v4(1, 0, 0, 0)); put(0, 6, 1, 0, v4(2, 0, 0, 0));
    cfg(7, 4'b0001); wait_clk(1);
    del_grp.delete();
    out_ready = 1; drain(4);
    chk(del_grp.size() == 1 && del_grp[0] == 6, "reconfiguring a group drops its held result");
    cfg(4, 4'b0001);
    out_ready = 0;
    put(0, 4, 0, 0, v4(4, 0, 0, 0)); put(0, 7, 0, 0, v4(1, 0, 0, 0)); put(0, 6, 2, 0, v4(2, 0, 0, 0));
    del_grp.delete();
    out_ready = 1; drain(5);
    chk(del_grp.size() == 3 && del_grp[0] == 4 && del_grp[1] == 6 && del_grp[2] == 7,
        "results held behind a delivery leave lowest group first");

    // ---- reconfiguration mid-round
    cfg(8, 4'b0011);
    put(0, 8, 0, 0, v4(1, 1, 1, 1));
    cfg(8, 4'b0011);
    put(1, 8, 0, 0, v4(2, 2, 2, 2));
    chk(in_ack && in_err == 0 && !out_valid, "reconfiguration clears the partial round");
    put(0, 8, 0, 0, v4(3, 3, 3, 3));
    chk(out_valid && out_data == v4(5, 5, 5, 5), "round restarts from the reconfiguration");
    drain(2);
    cfg(8, 4'b0000);
    put(0, 8, 1, 0, v4(3, 3, 3, 3));
    chk(in_ack && in_err == 1, "mask 0 disables the group");

    // ---- random
    begin
      int sent;
      sent = 0;
      for (int g = 9; g < 13; g++) cfg(g, 4'($urandom_range(1, 15)));
      fork
        begin
          for (int i = 0; i < 1500; i++) begin
            int g, p;
            g = $urandom_range(9, 12);
            p = $urandom_range(0, 3);
            @(negedge clk);
            if ($urandom_range(0, 99) < 3) begin cfg_we = 1; cfg_grp = g; cfg_mask = $urandom_range(0, 15); end
            else cfg_we = 0;
            in_valid = $urandom_range(0, 3) != 0;
            in_grp = ($urandom_range(0, 30) == 0) ? 4'd13 : 4'(g);
            in_port = p;
            in_seq = ($urandom_range(0, 15) == 0) ? 8'(m_seq[g] + 1) : 8'(m_seq[g]);
            in_op = ($urandom_range(0, 25) == 0) ? 3'($urandom_range(6, 7)) : 3'($urandom_range(0, 1) ? m_op[g] : $urandom_range(0, 5));
            if ($urandom_range(0, 9) == 0)
              in_data = {1'b0, {31{1'b1}}, 1'b1, 31'h0, 32'($urandom), 32'($urandom_range(0, 9))};
            else
              in_data = {32'($urandom), 32'($urandom), 32'($urandom_range(0, 1000)) - 32'd500, 32'($urandom)};
            sent += in_valid;
          end
          @(negedge clk); in_valid = 0; cfg_we = 0;
        end
        begin
          for (int i = 0; i < 1500; i++) begin @(negedge clk); out_ready = $urandom_range(0, 2) != 0; end
        end
      join
      out_ready = 1;
      drain(TMO + 10);
      chk(ack_bad == 0, $sformatf("%0d random contributions: every acknowledge and code as expected", sent));
      chk(del_bad == 0 && del_unexp == 0, $sformatf("random rounds: every delivered result as expected (%0d delivered)", delivered));
      sum_ok = 1;
      for (int g = 0; g < 16; g++) if (h_v[g]) sum_ok = 0;
      chk(sum_ok && !out_valid, "every held result delivered");
    end

    // ---- group 0: rounds, delivery under back-pressure, timeout
    cfg(0, 4'b0011);
    out_ready = 0;
    put(0, 0, 0, 2, v4(5, -5, 0, 1)); put(1, 0, 0, 2, v4(3, -2, 0, 9));
    wait_clk(3);
    chk(out_valid && out_grp == 0 && out_data == v4(5, -2, 0, 9), "group 0: MAX result held under back-pressure");
    out_ready = 1; drain(2);
    chk(!out_valid, "group 0 result delivered");
    out_ready = 0;
    put(1, 0, 1, 0, v4(1, 1, 1, 1));
    wait_clk(TMO);
    chk(out_valid && out_grp == 0 && out_status == 2 && out_mask == 4'b0010, "group 0 round times out");
    out_ready = 1; drain(2);
    chk(ack_bad == 0 && del_bad == 0 && del_unexp == 0, "group 0 as the reference");

    // ---- reset
    out_ready = 0;
    cfg(1, 4'b0001); put(0, 1, 0, 0, v4(1, 1, 1, 1));
    check_on = 0;
    rst_n = 0; wait_clk(2);
    chk(!out_valid && !in_ack, "reset clears the delivery");
    rst_n = 1; out_ready = 1;
    put(0, 1, 0, 0, v4(1, 1, 1, 1));
    chk(in_ack && in_err == 1 && !out_valid, "after reset every group is disabled");
    put(1, 0, 0, 0, v4(1, 1, 1, 1));
    chk(in_ack && in_err == 1 && !out_valid, "after reset group 0 is disabled too");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #2ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
