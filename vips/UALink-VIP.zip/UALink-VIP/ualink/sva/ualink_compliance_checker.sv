// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_compliance_checker.sv -- UALink concurrent assertion checks (bindable)

module ualink_compliance_checker
  (input logic clk, input logic rst_n, input req_valid, input req_ready, input [3:0] req_opcode, input [31:0] req_addr, input [63:0] req_wdata, input rsp_valid, input rsp_ready, input [1:0] rsp_status, input [63:0] rsp_rdata);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({req_ready, rsp_valid, rsp_status, rsp_rdata}))
    else $error("UALink: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> req_ready == '0)
    else $error("UALink: output not in reset value");
  assert property (@(posedge clk) disable iff (!rst_n) rsp_valid |-> !req_ready)
    else $error("UALink: accepted request while responding");
  assert property (@(posedge clk) disable iff (!rst_n) rsp_status == 2'd1 |=> !rsp_valid || rsp_status == 2'd0)
    else $error("UALink: error status latched");
  cover property (@(posedge clk) disable iff (!rst_n) (req_ready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (rsp_valid && rsp_status == 2'd1));
endmodule
