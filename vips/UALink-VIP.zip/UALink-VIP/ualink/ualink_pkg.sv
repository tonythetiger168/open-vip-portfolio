// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_pkg.sv -- UALink UVM VIP package

package ualink_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ualink_defs_pkg::*;
  export ualink_defs_pkg::*;

  `include "ualink_transaction.svh"
  `include "ualink_config.svh"
  `include "ualink_sequencer.svh"
  `include "ualink_driver.svh"
  `include "ualink_monitor.svh"
  `include "ualink_agent.svh"
  `include "ualink_sequences.svh"
  `include "ualink_checker.svh"
  `include "ualink_coverage.svh"
endpackage
