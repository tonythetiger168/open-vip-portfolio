// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_defs.sv -- UALink shared type definitions

package ualink_defs_pkg;

  typedef enum bit [1:0] {UALINK_OK, UALINK_ERR} ualink_status_e;

  localparam bit [3:0] UAL_OP_RD = 4'd4, UAL_OP_WR = 4'd5;

endpackage
