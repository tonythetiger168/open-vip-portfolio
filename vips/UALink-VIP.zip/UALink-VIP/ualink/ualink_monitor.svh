// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_monitor.svh -- UALink monitor: request handshake, completed by the response handshake

class ualink_monitor extends uvm_monitor;
  `uvm_component_utils(ualink_monitor)

  virtual ualink_if vif;
  uvm_analysis_port #(ualink_transaction) ap;
  ualink_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ualink_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ualink: virtual interface not set")
    if (!uvm_config_db#(ualink_config)::get(this, "", "cfg", cfg))
      cfg = ualink_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      ualink_transaction t;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rsp_valid && vif.mon_cb.rsp_ready) begin
          if (t == null) `uvm_error("MON", "UALink response without a request")
          else begin
            t.status = vif.mon_cb.rsp_status;
            t.rdata  = vif.mon_cb.rsp_rdata;
            publish(t);
            t = null;
          end
        end
        if (vif.mon_cb.req_valid && vif.mon_cb.req_ready) begin
          if (t != null) `uvm_error("MON", "UALink second request while one is outstanding")
          t = ualink_transaction::type_id::create("t");
          t.opcode = vif.mon_cb.req_opcode;
          t.addr   = vif.mon_cb.req_addr;
          t.wdata  = vif.mon_cb.req_opcode == UAL_OP_WR ? vif.mon_cb.req_wdata : 64'h0;
        end
      end
    end
  endtask

  function void publish(ualink_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
