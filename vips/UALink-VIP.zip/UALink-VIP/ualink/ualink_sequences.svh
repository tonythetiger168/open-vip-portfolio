// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_sequences.svh -- UALink sequences

// Random traffic: cfg.num_items constrained-random items.
class ualink_base_sequence extends uvm_sequence #(ualink_transaction);
  `uvm_object_utils(ualink_base_sequence)
  ualink_config cfg;

  function new(string name = "ualink_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ualink_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ualink_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ualink_directed_sequence extends uvm_sequence #(ualink_transaction);
  `uvm_object_utils(ualink_directed_sequence)
  ualink_config cfg;

  function new(string name = "ualink_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ualink_transaction item();
    item = ualink_transaction::type_id::create("req");
  endfunction

  task send(ualink_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ualink_transaction t;
    for (int i = 0; i < 64; i += 9) begin
      t = item(); t.opcode = UAL_OP_WR; t.addr = i * 8; t.wdata = {32'hA11C_E000 | i, 32'h0BAD_C0DE}; send(t);
      t = item(); t.opcode = UAL_OP_RD; t.addr = i * 8; t.rsp_wait = 3; send(t);
    end
    t = item(); t.opcode = UAL_OP_RD; t.addr = 32'h1F8; send(t);   // unwritten: 0
    t = item(); t.opcode = 4'd0; t.addr = 32'h8; send(t);           // unsupported opcodes
    t = item(); t.opcode = 4'd15; t.addr = 32'h10; t.rsp_wait = 2; send(t);
    t = item(); t.opcode = UAL_OP_WR; t.addr = 32'h1F8; t.wdata = '1; send(t);
    t = item(); t.opcode = UAL_OP_RD; t.addr = 32'h1F8; send(t);
  endtask
endclass
