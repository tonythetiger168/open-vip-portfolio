// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_transaction.svh -- UALink transaction

class ualink_transaction extends uvm_sequence_item;
  `uvm_object_utils(ualink_transaction)

  // request (driven by the agent)
  rand bit [3:0] opcode;
  rand bit [31:0] addr;
  rand bit [63:0] wdata;
  // response (returned by the DUT)
  bit [1:0] status;
  bit [63:0] rdata;
  // bookkeeping (not compared)
  rand bit [1:0] rsp_wait;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_op   { opcode dist { UAL_OP_RD := 4, UAL_OP_WR := 4, [0:3] :/ 1, [6:15] :/ 1 }; }
  constraint c_addr { addr[2:0] == 3'b000; addr < 32'h200; }
  constraint c_data { opcode != UAL_OP_WR -> wdata == 0; }

  function new(string name = "ualink_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    ualink_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    opcode = rhs_.opcode;
    addr = rhs_.addr;
    wdata = rhs_.wdata;
    status = rhs_.status;
    rdata = rhs_.rdata;
    rsp_wait = rhs_.rsp_wait;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ualink_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (opcode != rhs_.opcode) return 0;
    if (addr != rhs_.addr) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (status != rhs_.status) return 0;
    if (rdata != rhs_.rdata) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ualink_transaction rhs_);
    if (opcode != rhs_.opcode) return 0;
    if (addr != rhs_.addr) return 0;
    if (wdata != rhs_.wdata) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("UALink{tag=%0d opcode=0x%0h addr=0x%0h wdata=0x%0h status=0x%0h rdata=0x%0h}", tag, opcode, addr, wdata, status, rdata);
  endfunction
endclass
