// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_driver.svh -- UALink driver: request until req_ready, response accepted after rsp_wait clocks of back-pressure

class ualink_driver extends uvm_driver #(ualink_transaction);
  `uvm_component_utils(ualink_driver)

  uvm_analysis_port #(ualink_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ualink_if vif;
  ualink_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ualink_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ualink: virtual interface not set")
    if (!uvm_config_db#(ualink_config)::get(this, "", "cfg", cfg))
      cfg = ualink_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ualink_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.req_valid <= 1'b0; vif.drv_cb.req_opcode <= '0;
    vif.drv_cb.req_addr <= '0; vif.drv_cb.req_wdata <= '0;
    vif.drv_cb.rsp_ready <= 1'b1;
  endtask

  task drive_item(ualink_transaction t);
    @(vif.drv_cb);
    vif.drv_cb.req_valid  <= 1'b1;
    vif.drv_cb.req_opcode <= t.opcode;
    vif.drv_cb.req_addr   <= t.addr;
    vif.drv_cb.req_wdata  <= t.wdata;
    vif.drv_cb.rsp_ready  <= (t.rsp_wait == 0);
    begin
      int unsigned to = 0;
      do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.req_ready === 1'b1) && to < cfg.timeout_cycles);
      if (!(vif.drv_cb.req_ready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("UALink req_ready: no response within %0d cycles", cfg.timeout_cycles))
    end
    vif.drv_cb.req_valid <= 1'b0;
    if (t.rsp_wait != 0) begin
      repeat (t.rsp_wait) @(vif.drv_cb);
      vif.drv_cb.rsp_ready <= 1'b1;
    end
    begin
      int unsigned to = 0;
      do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.rsp_valid === 1'b1 && vif.drv_cb.rsp_ready === 1'b1) && to < cfg.timeout_cycles);
      if (!(vif.drv_cb.rsp_valid === 1'b1 && vif.drv_cb.rsp_ready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("UALink response: no response within %0d cycles", cfg.timeout_cycles))
    end
    t.status = vif.drv_cb.rsp_status;
    t.rdata  = vif.drv_cb.rsp_rdata;
  endtask

endclass
