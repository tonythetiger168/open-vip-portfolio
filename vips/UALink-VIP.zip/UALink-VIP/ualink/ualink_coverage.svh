// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_coverage.svh -- UALink functional coverage

class ualink_coverage extends uvm_subscriber #(ualink_transaction);
  `uvm_component_utils(ualink_coverage)
  ualink_config cfg;
  ualink_transaction tr;

  covergroup ualink_cg;
    coverpoint tr.req_valid;
    coverpoint tr.req_opcode;
    coverpoint tr.req_addr;
    coverpoint tr.req_wdata;
    coverpoint tr.rsp_ready;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(ualink_config)::get(this, "*", "cfg", cfg));
    ualink_cg = new();
  endfunction

  function void write(ualink_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    ualink_cg.sample();
  endfunction
endclass
