// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_coverage.svh -- UALink functional coverage

class ualink_coverage extends uvm_subscriber #(ualink_transaction);
  `uvm_component_utils(ualink_coverage)
  ualink_config cfg;
  ualink_transaction tr;

  covergroup ualink_cg;
    cp_op     : coverpoint tr.opcode { bins rd = {UAL_OP_RD}; bins wr = {UAL_OP_WR}; bins bad = default; }
    cp_status : coverpoint tr.status { bins ok = {0}; bins err = {1}; }
    cp_word   : coverpoint tr.addr[8:3] { bins first = {0}; bins last = {63}; bins mid = {[1:62]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ualink_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ualink_config)::get(this, "", "cfg", cfg))
      cfg = ualink_config::type_id::create("cfg");
  endfunction

  function void write(ualink_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ualink_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("UALink coverage: %0.1f%%", ualink_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
