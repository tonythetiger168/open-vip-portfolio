// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ualink_if.sv -- UALink interface

interface ualink_if (input logic clk);
  logic rst_n;

  logic req_valid;
  logic req_ready;
  logic [3:0] req_opcode;
  logic [31:0] req_addr;
  logic [63:0] req_wdata;
  logic rsp_valid;
  logic rsp_ready;
  logic [1:0] rsp_status;
  logic [63:0] rsp_rdata;

  modport DUT (input clk, rst_n, req_valid, req_opcode, req_addr, req_wdata, rsp_ready, output req_ready, rsp_valid, rsp_status, rsp_rdata);
  modport DRV (input clk, rst_n, req_ready, rsp_valid, rsp_status, rsp_rdata, output req_valid, req_opcode, req_addr, req_wdata, rsp_ready);
  modport MON (input clk, rst_n, req_valid, req_ready, req_opcode, req_addr, req_wdata, rsp_valid, rsp_ready, rsp_status, rsp_rdata);

  clocking drv_cb @(posedge clk);
    input rst_n, req_valid, req_ready, req_opcode, req_addr, req_wdata, rsp_valid, rsp_ready, rsp_status, rsp_rdata;
    output req_valid, req_opcode, req_addr, req_wdata, rsp_ready;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, req_valid, req_ready, req_opcode, req_addr, req_wdata, rsp_valid, rsp_ready, rsp_status, rsp_rdata;
  endclocking
endinterface
