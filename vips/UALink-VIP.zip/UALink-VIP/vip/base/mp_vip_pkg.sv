// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol VIP Package
// Protocols: PCIe Gen5/Gen6, CXL 2.0/3.0, UCIe, UALink
//============================================================================
`ifndef MP_VIP_PKG_SV
`define MP_VIP_PKG_SV

// Tiered SVA compliance checker and protocol checkers: the SVA content lives
// in modules (class-scope concurrent assertions are illegal per IEEE 1800);
// thin class shells remain. Included at compilation-unit scope, outside and
// before the package, so mp_env / top_tb can see them.
`include "sva/ualink_compliance_checker.sv"
`include "pcie_protocol_checker.sv"
`include "cxl_protocol_checker.sv"
`include "ucie_protocol_checker.sv"
`include "ualink_protocol_checker.sv"

package mp_vip_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef enum int { PROTO_PCIE_GEN5=0, PROTO_PCIE_GEN6=1, PROTO_CXL_20=2,
                     PROTO_CXL_30=3, PROTO_UCIE=4, PROTO_UALINK=5, PROTO_MAX=6 } protocol_e;
  typedef enum int { SPEED_GEN5=0, SPEED_GEN6=1, SPEED_CXL20=2, SPEED_CXL30=3,
                     SPEED_UCIE=4, SPEED_UALINK=5 } speed_e;
  typedef enum int { LINK_RESET=0, LINK_DETECT=1, LINK_POLLING=2, LINK_CONFIG=3,
                     LINK_L0=4, LINK_L0S=5, LINK_L1=6, LINK_L2=7, LINK_RECOVERY=8,
                     LINK_DISABLED=9, LINK_LOOPBACK=10, LINK_HOT_RESET=11 } link_state_e;
  typedef enum int { TLP_MEM_RD=0, TLP_MEM_WR=1, TLP_CFG_RD=2, TLP_CFG_WR=3,
                     TLP_CPL=4, TLP_CPL_D=5, TLP_MSG=6, TLP_IO_RD=7, TLP_IO_WR=8,
                     CXL_MEM_RD=9, CXL_MEM_WR=10, CXL_IO_RD=11, CXL_IO_WR=12,
                     CXL_CACHE_RD=13, CXL_CACHE_WR=14, CXL_BIAS_RD=15, CXL_BIAS_WR=16,
                     UCIE_DATA_RD=17, UCIE_DATA_WR=18, UCIE_REG_RD=19, UCIE_REG_WR=20,
                     UCIE_SIDEBAND=21, UALINK_DATA=22, UALINK_CTRL=23, UALINK_FLIT=24,
                     TLP_UNKNOWN=25 } tlp_type_e;
  typedef enum int { TXN_IDLE=0, TXN_PENDING=1, TXN_ACTIVE=2, TXN_COMPLETE=3,
                     TXN_ERROR=4, TXN_TIMEOUT=5 } txn_status_e;

  typedef struct packed {
    protocol_e protocol;
    speed_e    speed;
    int        num_lanes;
    int        max_payload_size;
    bit        ecrc_enabled;
    bit        ltr_enabled;
    bit        ten_bit_tag;
    bit        pasid_enabled;
    int        credit_timeout;
    int        replay_timeout;
  } protocol_cfg_t;

  typedef struct packed {
    bit cov_txn_types;
    bit cov_addresses;
    bit cov_data_patterns;
    bit cov_link_states;
    bit cov_error_injection;
    bit cov_power_states;
    bit cov_bandwidth;
    bit cov_latency;
    bit cov_cross_protocol;
  } coverage_cfg_t;

  //==========================================================================
  // Common Transaction Descriptor
  //==========================================================================
  class mp_txn_descriptor extends uvm_object;
    `uvm_object_utils(mp_txn_descriptor)
    rand protocol_e    protocol;
    rand tlp_type_e    txn_type;
    rand logic [63:0]  address;
    rand int           length;
    rand logic [31:0]  data[];
    rand logic [15:0]  requester_id;
    rand logic [15:0]  completer_id;
    rand logic [7:0]   tag;
    rand logic [2:0]   tc;
    rand logic         ep;
    rand logic         td;
    rand logic [1:0]   attr;
    rand logic [9:0]   length_dw;
    rand txn_status_e  status;
    rand int           delay_cycles;
    rand bit           inject_error;
    rand bit           trigger_irq;
    // Protocol-specific fields
    rand logic [15:0]  cxl_meta;
    rand logic [7:0]   ucie_credits;
    rand logic [3:0]   ucie_vc;
    rand logic [3:0]   ualink_vc;
    // Timestamp
    time start_time;
    time end_time;

    constraint c_length { length inside {[4:4096]}; length % 4 == 0; }
    constraint c_length_dw { length_dw == (length / 4); length_dw inside {[1:1024]}; }
    constraint c_address_align { address[1:0] == 2'b00; }
    constraint c_pcie_addr {
      if (protocol inside {PROTO_PCIE_GEN5, PROTO_PCIE_GEN6}) address[63:32] == 32'h0000_0000;
    }
    constraint c_cxl_addr {
      if (protocol inside {PROTO_CXL_20, PROTO_CXL_30})
        address inside {[64'h0 : 64'h000F_FFFF_FFFF_FFFF]};
    }
    constraint c_ucie_addr {
      if (protocol == PROTO_UCIE) address inside {[64'h0 : 64'hFFFF]};
    }
    constraint c_ucie_len {
      if (protocol == PROTO_UCIE) length inside {[4:256]};
    }
    constraint c_ualink_len {
      if (protocol == PROTO_UALINK) length inside {[4:512]};   // 512B flit
    }
    constraint c_ualink_addr {
      if (protocol == PROTO_UALINK) address[5:0] == 6'b0;      // 64B aligned
    }
    constraint c_credits { ucie_credits inside {[8'h01:8'hFF]}; }
    constraint c_data_size { data.size() == length_dw; }
    constraint c_delay { delay_cycles inside {[0:1000]}; }
    constraint c_error_rate { inject_error dist { 0 := 95, 1 := 5 }; }
    constraint c_status { status == TXN_PENDING; }

    function new(string name = "mp_txn_descriptor");
      super.new(name);
    endfunction

    function void post_randomize();
      start_time = $time;
    endfunction

    function void set_complete(txn_status_e s);
      status = s;
      end_time = $time;
    endfunction

    function int get_latency_ns();
      if (end_time > start_time) return int'((end_time - start_time) / 1ns);
      else return 0;
    endfunction

    virtual function string convert2string();
      return $sformatf("protocol=%s type=%s addr=0x%016X len=%0d status=%s lat=%0dns",
                       protocol.name(), txn_type.name(), address, length,
                       status.name(), get_latency_ns());
    endfunction
  endclass

  //==========================================================================
  // Base Sequence Item
  //==========================================================================
  class mp_sequence_item extends uvm_sequence_item;
    `uvm_object_utils(mp_sequence_item)
    rand mp_txn_descriptor txn;
    constraint c_default { txn.protocol != PROTO_MAX; }
    function new(string name = "mp_sequence_item");
      super.new(name);
      txn = mp_txn_descriptor::type_id::create("txn");
    endfunction
    virtual function string convert2string();
      return txn.convert2string();
    endfunction
  endclass

  //==========================================================================
  // Protocol Configuration Object
  //==========================================================================
  class mp_protocol_config extends uvm_object;
    `uvm_object_utils(mp_protocol_config)
    protocol_e     protocol;
    protocol_cfg_t cfg;
    coverage_cfg_t cov_cfg;

    function new(string name = "mp_protocol_config", protocol_e p = PROTO_PCIE_GEN5);
      super.new(name);
      protocol = p;
      set_default_cfg();
    endfunction

    function void set_default_cfg();
      case (protocol)
        PROTO_PCIE_GEN5: begin
          cfg.protocol = PROTO_PCIE_GEN5; cfg.speed = SPEED_GEN5;
          cfg.num_lanes = 16; cfg.max_payload_size = 512;
          cfg.ecrc_enabled = 1; cfg.ltr_enabled = 1;
        end
        PROTO_PCIE_GEN6: begin
          cfg.protocol = PROTO_PCIE_GEN6; cfg.speed = SPEED_GEN6;
          cfg.num_lanes = 16; cfg.max_payload_size = 1024;
          cfg.ecrc_enabled = 1; cfg.ltr_enabled = 1; cfg.ten_bit_tag = 1;
        end
        PROTO_CXL_20: begin
          cfg.protocol = PROTO_CXL_20; cfg.speed = SPEED_CXL20;
          cfg.num_lanes = 16; cfg.max_payload_size = 512; cfg.ecrc_enabled = 1;
        end
        PROTO_CXL_30: begin
          cfg.protocol = PROTO_CXL_30; cfg.speed = SPEED_CXL30;
          cfg.num_lanes = 16; cfg.max_payload_size = 1024;
          cfg.ecrc_enabled = 1; cfg.pasid_enabled = 1;
        end
        PROTO_UCIE: begin
          cfg.protocol = PROTO_UCIE; cfg.speed = SPEED_UCIE;
          cfg.num_lanes = 64; cfg.max_payload_size = 256; cfg.ecrc_enabled = 0;
        end
        PROTO_UALINK: begin
          cfg.protocol = PROTO_UALINK; cfg.speed = SPEED_UALINK;
          cfg.num_lanes = 16; cfg.max_payload_size = 2048; cfg.ecrc_enabled = 1;
        end
        default: begin
          cfg.protocol = PROTO_PCIE_GEN5; cfg.speed = SPEED_GEN5;
          cfg.num_lanes = 16; cfg.max_payload_size = 256;
        end
      endcase
      cfg.credit_timeout = 10000;
      cfg.replay_timeout = 50000;
      // Default coverage enable
      cov_cfg.cov_txn_types = 1;
      cov_cfg.cov_addresses = 1;
      cov_cfg.cov_data_patterns = 1;
      cov_cfg.cov_link_states = 1;
      cov_cfg.cov_error_injection = 1;
      cov_cfg.cov_power_states = 1;
      cov_cfg.cov_bandwidth = 1;
      cov_cfg.cov_latency = 1;
      cov_cfg.cov_cross_protocol = 1;
    endfunction
  endclass

  //==========================================================================
  // Coverage Model Base Class (5 protocol covergroups + link-state FSM)
  //==========================================================================
  class mp_coverage_model extends uvm_component;
    `uvm_component_utils(mp_coverage_model)
    uvm_analysis_imp #(mp_sequence_item, mp_coverage_model) analysis_imp;

    // Coverage variables
    protocol_e    txn_protocol;
    tlp_type_e    txn_type;
    logic [63:0]  address;
    bit all_zeros, all_ones, walking_ones, walking_zeros, is_random;
    int           latency_ns;
    int           error_type;
    bit           recovery_triggered;
    link_state_e  cur_link_state;

    covergroup cg_txn_type;
      option.per_instance = 1;
      cp_protocol: coverpoint txn_protocol {
        bins pcie_gen5 = {PROTO_PCIE_GEN5}; bins pcie_gen6 = {PROTO_PCIE_GEN6};
        bins cxl20 = {PROTO_CXL_20}; bins cxl30 = {PROTO_CXL_30};
        bins ucie = {PROTO_UCIE}; bins ualink = {PROTO_UALINK};
      }
      cp_txn_type: coverpoint txn_type {
        bins mem_rd = {TLP_MEM_RD, CXL_MEM_RD, UCIE_DATA_RD, UALINK_DATA};
        bins mem_wr = {TLP_MEM_WR, CXL_MEM_WR, UCIE_DATA_WR};
        bins cfg_rd = {TLP_CFG_RD, UCIE_REG_RD};
        bins cfg_wr = {TLP_CFG_WR, UCIE_REG_WR};
        bins cpl    = {TLP_CPL, TLP_CPL_D};
        bins msg    = {TLP_MSG, UALINK_CTRL, UCIE_SIDEBAND};
        bins io     = {TLP_IO_RD, TLP_IO_WR, CXL_IO_RD, CXL_IO_WR};
        bins cache  = {CXL_CACHE_RD, CXL_CACHE_WR};
        bins bias   = {CXL_BIAS_RD, CXL_BIAS_WR};
        bins flit   = {UALINK_FLIT};
      }
      cross_protocol_txn: cross cp_protocol, cp_txn_type;
    endgroup

    covergroup cg_address_map;
      option.per_instance = 1;
      cp_address_range: coverpoint address[63:40] {
        bins low_mem  = {[24'h000000 : 24'h00000F]};
        bins mid_mem  = {[24'h000010 : 24'h0000FF]};
        bins high_mem = {[24'h000100 : 24'hFFFFFF]};
      }
      cp_address_align: coverpoint address[3:0] {
        bins dword_aligned = {4'h0};
        bins other_align   = {[4'h1 : 4'hF]};
      }
    endgroup

    covergroup cg_data_patterns;
      option.per_instance = 1;
      cp_all_zeros:     coverpoint all_zeros     { bins yes = {1}; bins no = {0}; }
      cp_all_ones:      coverpoint all_ones      { bins yes = {1}; bins no = {0}; }
      cp_walking_ones:  coverpoint walking_ones  { bins yes = {1}; bins no = {0}; }
      cp_walking_zeros: coverpoint walking_zeros { bins yes = {1}; bins no = {0}; }
      cp_random:        coverpoint is_random     { bins yes = {1}; bins no = {0}; }
      cross_pat: cross cp_all_zeros, cp_all_ones, cp_walking_ones;
    endgroup

    covergroup cg_latency;
      option.per_instance = 1;
      cp_latency_ns: coverpoint latency_ns {
        bins lat_low = {[0:100]}; bins lat_medium = {[101:500]};
        bins high = {[501:1000]}; bins extreme = {[1001:$]};
      }
      cp_protocol: coverpoint txn_protocol {
        bins pcie = {PROTO_PCIE_GEN5, PROTO_PCIE_GEN6};
        bins cxl  = {PROTO_CXL_20, PROTO_CXL_30};
        bins ucie = {PROTO_UCIE}; bins ualink = {PROTO_UALINK};
      }
      cross_lat_prot: cross cp_latency_ns, cp_protocol;
    endgroup

    covergroup cg_error_injection;
      option.per_instance = 1;
      cp_error_type: coverpoint error_type {
        bins ecrc_error = {0}; bins lcrc_error = {1}; bins framing_error = {2};
        bins timeout_error = {3}; bins protocol_error = {4};
      }
      cp_recovery: coverpoint recovery_triggered { bins yes = {1}; bins no = {0}; }
      cross_err_rec: cross cp_error_type, cp_recovery;
    endgroup

    // Link-state (LTSSM-style) FSM transition coverage
    covergroup cg_link_state;
      option.per_instance = 1;
      cp_state: coverpoint cur_link_state {
        bins reset = {LINK_RESET}; bins detect = {LINK_DETECT};
        bins polling = {LINK_POLLING}; bins link_config = {LINK_CONFIG};
        bins l0 = {LINK_L0}; bins l0s = {LINK_L0S}; bins l1 = {LINK_L1};
        bins l2 = {LINK_L2}; bins recovery = {LINK_RECOVERY};
      }
      cp_trans: coverpoint cur_link_state {
        bins link_up_flow = (LINK_RESET => LINK_DETECT => LINK_POLLING => LINK_CONFIG => LINK_L0);
        bins l0_l0s    = (LINK_L0 => LINK_L0S);
        bins l0s_l0    = (LINK_L0S => LINK_L0);
        bins l0_l1     = (LINK_L0 => LINK_L1);
        bins l1_rec    = (LINK_L1 => LINK_RECOVERY);
        bins rec_l0    = (LINK_RECOVERY => LINK_L0);
        bins l0_l2     = (LINK_L0 => LINK_L2);
      }
    endgroup

    function new(string name = "mp_coverage_model", uvm_component parent = null);
      super.new(name, parent);
      analysis_imp = new("analysis_imp", this);
      cg_txn_type = new();
      cg_address_map = new();
      cg_data_patterns = new();
      cg_latency = new();
      cg_error_injection = new();
      cg_link_state = new();
    endfunction

    virtual function void write(mp_sequence_item item);
      sample_transaction(item.txn);
    endfunction

    virtual function void sample_transaction(mp_txn_descriptor txn);
      txn_protocol = txn.protocol;
      txn_type     = txn.txn_type;
      address      = txn.address;
      latency_ns   = txn.get_latency_ns();
      // Data pattern analysis
      if (txn.data.size() > 0) begin
        all_zeros = 1; all_ones = 1;
        walking_ones = 0; walking_zeros = 0; is_random = 1;
        foreach (txn.data[i]) begin
          if (txn.data[i] != 32'h0000_0000) all_zeros = 0;
          if (txn.data[i] != 32'hFFFF_FFFF) all_ones = 0;
        end
        begin
          logic [31:0] d = txn.data[0];
          if ($countones(d) == 1)  walking_ones = 1;
          if ($countones(~d) == 1) walking_zeros = 1;
        end
        if (all_zeros || all_ones || walking_ones || walking_zeros) is_random = 0;
      end
      cg_txn_type.sample();
      cg_address_map.sample();
      cg_data_patterns.sample();
      cg_latency.sample();
    endfunction

    virtual function void sample_error(int err_type, bit recovery);
      error_type = err_type;
      recovery_triggered = recovery;
      cg_error_injection.sample();
    endfunction

    virtual function void sample_link_state(link_state_e s);
      cur_link_state = s;
      cg_link_state.sample();
    endfunction

    virtual function real get_coverage();
      real cov = 0;
      cov += cg_txn_type.get_coverage();
      cov += cg_address_map.get_coverage();
      cov += cg_data_patterns.get_coverage();
      cov += cg_latency.get_coverage();
      cov += cg_error_injection.get_coverage();
      cov += cg_link_state.get_coverage();
      return cov / 6.0;
    endfunction
  endclass

  //==========================================================================
  // End-to-end Scoreboard: compares driver-issued (expected) transactions
  // against monitor-decoded (observed) transactions.
  //==========================================================================
  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  class mp_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(mp_scoreboard)
    uvm_analysis_imp     #(mp_sequence_item, mp_scoreboard) analysis_imp;  // legacy
    uvm_analysis_imp_exp #(mp_sequence_item, mp_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(mp_sequence_item, mp_scoreboard) obs_ap;

    // Transaction queues
    mp_sequence_item expected_queue[$];
    mp_sequence_item received_queue[$];

    // Statistics
    int txn_count;
    int error_count;
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name = "mp_scoreboard", uvm_component parent = null);
      super.new(name, parent);
      analysis_imp = new("analysis_imp", this);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
      txn_count = 0; error_count = 0;
    endfunction

    virtual function void write(mp_sequence_item item);
      txn_count++;
      if (item.txn.status == TXN_ERROR) error_count++;
    endfunction

    virtual function void write_exp(mp_sequence_item item);
      expected_queue.push_back(item);
      compare();
    endfunction

    virtual function void write_obs(mp_sequence_item item);
      received_queue.push_back(item);
      compare();
    endfunction

    virtual function void compare();
      while (expected_queue.size() && received_queue.size()) begin
        mp_sequence_item e = expected_queue.pop_front();
        mp_sequence_item o = received_queue.pop_front();
        bit ok = (e.txn.protocol == o.txn.protocol) &&
                 (e.txn.address  == o.txn.address) &&
                 (e.txn.length_dw == o.txn.length_dw);
        if (ok) begin
          int n = (e.txn.data.size() < o.txn.data.size()) ?
                  e.txn.data.size() : o.txn.data.size();
          for (int i = 0; i < n; i++)
            if (e.txn.data[i] !== o.txn.data[i]) ok = 0;
        end
        if (ok) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    virtual function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("mp scoreboard: txn=%0d err=%0d n_matches=%0d n_mismatches=%0d",
                txn_count, error_count, n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  // UVC components (sequencer/driver/monitor/agent)
  `include "mp_sequencer.sv"
  `include "mp_driver.sv"
  `include "mp_monitor.sv"
  `include "mp_agent.sv"

endpackage
`endif
