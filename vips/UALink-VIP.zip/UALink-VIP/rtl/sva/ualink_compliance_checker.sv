// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// UALink Tiered Compliance SVA Checker
// Level: Complex | Total SVAs: 18
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=Protocol-Specific Rules
`ifndef UALINK_COMPLIANCE_CHECKER_SV
`define UALINK_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

// ============================================================================
// ualink_compliance_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters, coverage and report output are preserved verbatim)
// ============================================================================
module ualink_compliance_checker_sva (mp_vip_if vif);

    int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

    initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
    end


  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_ualink_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> ##[1:16] vif.ready; endproperty
  assert_p_ualink_valid: assert property(p_ualink_valid) l1_pass[0]++; else begin `uvm_warning("UALINK_L1", "Valid implies ready failed"); l1_fail[0]++; end
  cover_p_ualink_valid: cover property(p_ualink_valid);
  property p_ualink_vc_range; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ualink_vc <= 4'd15; endproperty
  assert_p_ualink_vc_range: assert property(p_ualink_vc_range) l1_pass[1]++; else begin `uvm_warning("UALINK_L1", "VC 0-15 failed"); l1_fail[1]++; end
  cover_p_ualink_vc_range: cover property(p_ualink_vc_range);
  property p_ualink_qos_range; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ualink_qos <= 2'd3; endproperty
  assert_p_ualink_qos_range: assert property(p_ualink_qos_range) l1_pass[2]++; else begin `uvm_warning("UALINK_L1", "QoS 0-3 failed"); l1_fail[2]++; end
  cover_p_ualink_qos_range: cover property(p_ualink_qos_range);
  property p_ualink_flit_mode; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> $stable(vif.ualink_flit_mode); endproperty
  assert_p_ualink_flit_mode: assert property(p_ualink_flit_mode) l1_pass[3]++; else begin `uvm_warning("UALINK_L1", "Flit mode stable failed"); l1_fail[3]++; end
  cover_p_ualink_flit_mode: cover property(p_ualink_flit_mode);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_ualink_sop_eop; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> $past(vif.sop,1) || vif.sop; endproperty
  assert_p_ualink_sop_eop: assert property(p_ualink_sop_eop) l2_pass[0]++; else begin `uvm_warning("UALINK_L2", "SOP before EOP failed"); l2_fail[0]++; end
  cover_p_ualink_sop_eop: cover property(p_ualink_sop_eop);
  property p_ualink_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_ualink_no_x: assert property(p_ualink_no_x) l2_pass[1]++; else begin `uvm_warning("UALINK_L2", "No X when valid failed"); l2_fail[1]++; end
  cover_p_ualink_no_x: cover property(p_ualink_no_x);
  property p_ualink_link_up; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.link_up; endproperty
  assert_p_ualink_link_up: assert property(p_ualink_link_up) l2_pass[2]++; else begin `uvm_warning("UALINK_L2", "Link up for traffic failed"); l2_fail[2]++; end
  cover_p_ualink_link_up: cover property(p_ualink_link_up);
  property p_ualink_lane_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> |vif.lane_valid; endproperty
  assert_p_ualink_lane_valid: assert property(p_ualink_lane_valid) l2_pass[3]++; else begin `uvm_warning("UALINK_L2", "Lane valid failed"); l2_fail[3]++; end
  cover_p_ualink_lane_valid: cover property(p_ualink_lane_valid);
  property p_ualink_retry; @(posedge vif.clk) disable iff (!vif.rst_n) vif.retry_req |-> ##[1:16] vif.retry_ack; endproperty
  assert_p_ualink_retry: assert property(p_ualink_retry) l2_pass[4]++; else begin `uvm_warning("UALINK_L2", "Retry mechanism failed"); l2_fail[4]++; end
  cover_p_ualink_retry: cover property(p_ualink_retry);
  property p_ualink_credit; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.credit > 0; endproperty
  assert_p_ualink_credit: assert property(p_ualink_credit) l2_pass[5]++; else begin `uvm_warning("UALINK_L2", "Credit-based FC failed"); l2_fail[5]++; end
  cover_p_ualink_credit: cover property(p_ualink_credit);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_ualink_pm; @(posedge vif.clk) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ualink_pm: assert property(p_ualink_pm) l3_pass[0]++; else begin `uvm_warning("UALINK_L3", "Power management failed"); l3_fail[0]++; end
  cover_p_ualink_pm: cover property(p_ualink_pm);
  property p_ualink_multihost; @(posedge vif.clk) disable iff (!vif.rst_n) vif.host_id <= 4'd15; endproperty
  assert_p_ualink_multihost: assert property(p_ualink_multihost) l3_pass[1]++; else begin `uvm_warning("UALINK_L3", "Multi-host valid failed"); l3_fail[1]++; end
  cover_p_ualink_multihost: cover property(p_ualink_multihost);
  property p_ualink_qos_shaper; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ualink_qos > 0 |-> vif.shaper_en == 1; endproperty
  assert_p_ualink_qos_shaper: assert property(p_ualink_qos_shaper) l3_pass[2]++; else begin `uvm_warning("UALINK_L3", "QoS shaper failed"); l3_fail[2]++; end
  cover_p_ualink_qos_shaper: cover property(p_ualink_qos_shaper);
  property p_ualink_err_inject; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err_inject |-> vif.link_up == 1; endproperty
  assert_p_ualink_err_inject: assert property(p_ualink_err_inject) l3_pass[3]++; else begin `uvm_warning("UALINK_L3", "Error injection failed"); l3_fail[3]++; end
  cover_p_ualink_err_inject: cover property(p_ualink_err_inject);

  // ---------------- L4: UALink protocol-specific rules (4) ----------------
  // L4-1: flit mode stays constant from SOP to EOP of a burst
  property p_ualink_l4_flit_mode_burst;
    bit m;
    @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && vif.sop, m = vif.ualink_flit_mode) |-> (vif.ualink_flit_mode == m) until_with (vif.valid && vif.eop);
  endproperty
  assert_p_ualink_l4_flit_mode_burst: assert property(p_ualink_l4_flit_mode_burst) l4_pass[0]++; else begin `uvm_warning("UALINK_L4", "Flit mode changed inside a burst"); l4_fail[0]++; end
  cover_p_ualink_l4_flit_mode_burst: cover property(p_ualink_l4_flit_mode_burst);
  // L4-2: virtual channel stays constant within a burst
  property p_ualink_l4_vc_stable_burst;
    logic [3:0] v;
    @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && vif.sop, v = vif.ualink_vc) |-> (vif.ualink_vc == v) until_with (vif.valid && vif.eop);
  endproperty
  assert_p_ualink_l4_vc_stable_burst: assert property(p_ualink_l4_vc_stable_burst) l4_pass[1]++; else begin `uvm_warning("UALINK_L4", "VC changed inside a burst"); l4_fail[1]++; end
  cover_p_ualink_l4_vc_stable_burst: cover property(p_ualink_l4_vc_stable_burst);
  // L4-3: SOP may only be issued while the link is in L0
  property p_ualink_l4_sop_in_l0; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid && vif.sop |-> vif.link_state == LINK_L0; endproperty
  assert_p_ualink_l4_sop_in_l0: assert property(p_ualink_l4_sop_in_l0) l4_pass[2]++; else begin `uvm_warning("UALINK_L4", "SOP issued outside L0"); l4_fail[2]++; end
  cover_p_ualink_l4_sop_in_l0: cover property(p_ualink_l4_sop_in_l0);
  // L4-4: burst completes: EOP arrives within 64 cycles of SOP
  property p_ualink_l4_sop_eop_window; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid && vif.sop && !vif.eop |-> ##[1:64] (vif.valid && vif.eop); endproperty
  assert_p_ualink_l4_sop_eop_window: assert property(p_ualink_l4_sop_eop_window) l4_pass[3]++; else begin `uvm_warning("UALINK_L4", "SOP-to-EOP exceeds 64 cycles"); l4_fail[3]++; end
  cover_p_ualink_l4_sop_eop_window: cover property(p_ualink_l4_sop_eop_window);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("UALINK_RPT", $sformatf("=== UALink Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("UALINK_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("UALINK_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("UALINK_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("UALINK_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("UALINK_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
    end

endmodule

// ============================================================================
// ualink_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the ualink_compliance_checker_sva module above)
// ============================================================================
class ualink_compliance_checker extends uvm_component;
  `uvm_component_utils(ualink_compliance_checker)
  function new(string name = "ualink_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
