// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Top-Level Testbench
// Instantiates all protocol interfaces and the functional DUT model
//============================================================================
`ifndef TOP_TB_SV
`define TOP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

module top_tb;
  // Clock and reset
  logic clk = 0;
  logic rst_n;
  always #2ns clk = ~clk;   // 250MHz

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  // Interfaces
  mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(0)) pcie5_if(clk, rst_n);
  mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(1)) pcie6_if(clk, rst_n);
  mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(2)) cxl20_if(clk, rst_n);
  mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(3)) cxl30_if(clk, rst_n);
  mp_vip_if #(.DATA_WIDTH(256), .LANE_COUNT(64), .PROTOCOL(4)) ucie_if(clk, rst_n);
  mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(5)) ualink_if(clk, rst_n);

  // Functional DUT model (responder)
  mp_dut dut (
    .clk(clk), .rst_n(rst_n),
    .pcie5_if(pcie5_if), .pcie6_if(pcie6_if),
    .cxl20_if(cxl20_if), .cxl30_if(cxl30_if),
    .ucie_if(ucie_if),   .ualink_if(ualink_if)
  );

  // Tiered SVA compliance checker + protocol checkers (module form)
  ualink_compliance_checker_sva u_ualink_sva_chk (.vif(ualink_if));
  pcie_protocol_checker_sva     u_pcie_proto_sva (.vif(pcie5_if));
  cxl_protocol_checker_sva      u_cxl_proto_sva  (.vif(cxl20_if));
  ucie_protocol_checker_sva     u_ucie_proto_sva (.vif(ucie_if));
  ualink_protocol_checker_sva   u_ualink_proto_sva (.vif(ualink_if));

  initial begin
    // Pass interfaces to UVM (config-db type must match each interface's
    // parameterization exactly)
    uvm_config_db#(virtual mp_vip_if)::set(null, "*", "pcie5_vif", pcie5_if);
    uvm_config_db#(virtual mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(1)))::set(null, "*", "pcie6_vif", pcie6_if);
    uvm_config_db#(virtual mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(2)))::set(null, "*", "cxl20_vif", cxl20_if);
    uvm_config_db#(virtual mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(3)))::set(null, "*", "cxl30_vif", cxl30_if);
    uvm_config_db#(virtual mp_vip_if #(.DATA_WIDTH(256), .LANE_COUNT(64), .PROTOCOL(4)))::set(null, "*", "ucie_vif", ucie_if);
    uvm_config_db#(virtual mp_vip_if #(.DATA_WIDTH(512), .LANE_COUNT(16), .PROTOCOL(5)))::set(null, "*", "ualink_vif", ualink_if);
    run_test();
  end
endmodule

//----------------------------------------------------------------------------
// Functional DUT model: one responder channel per protocol interface.
// Each channel: link brought up after reset, READY follows VALID with a
// 1-cycle loopback delay plus periodic 2-cycle wait-state stalls, and an
// ECRC error pulse is injected for transfers into the error region
// (header address[63:56] == 8'hEE).
//----------------------------------------------------------------------------
module mp_dut (
  input logic clk,
  input logic rst_n,
  mp_vip_if pcie5_if,
  mp_vip_if pcie6_if,
  mp_vip_if cxl20_if,
  mp_vip_if cxl30_if,
  mp_vip_if ucie_if,
  mp_vip_if ualink_if
);
  mp_dut_channel ch_pcie5 (.clk(clk), .rst_n(rst_n),
    .valid(pcie5_if.valid), .sop(pcie5_if.sop), .eop(pcie5_if.eop),
    .hdr(pcie5_if.data), .ready(pcie5_if.ready),
    .link_up(pcie5_if.link_up), .link_state(pcie5_if.link_state),
    .ecrc_error(pcie5_if.ecrc_error), .lcrc_error(pcie5_if.lcrc_error),
    .framing_error(pcie5_if.framing_error), .protocol_error(pcie5_if.protocol_error));

  mp_dut_channel ch_pcie6 (.clk(clk), .rst_n(rst_n),
    .valid(pcie6_if.valid), .sop(pcie6_if.sop), .eop(pcie6_if.eop),
    .hdr(pcie6_if.data), .ready(pcie6_if.ready),
    .link_up(pcie6_if.link_up), .link_state(pcie6_if.link_state),
    .ecrc_error(pcie6_if.ecrc_error), .lcrc_error(pcie6_if.lcrc_error),
    .framing_error(pcie6_if.framing_error), .protocol_error(pcie6_if.protocol_error));

  mp_dut_channel ch_cxl20 (.clk(clk), .rst_n(rst_n),
    .valid(cxl20_if.valid), .sop(cxl20_if.sop), .eop(cxl20_if.eop),
    .hdr(cxl20_if.data), .ready(cxl20_if.ready),
    .link_up(cxl20_if.link_up), .link_state(cxl20_if.link_state),
    .ecrc_error(cxl20_if.ecrc_error), .lcrc_error(cxl20_if.lcrc_error),
    .framing_error(cxl20_if.framing_error), .protocol_error(cxl20_if.protocol_error));

  mp_dut_channel ch_cxl30 (.clk(clk), .rst_n(rst_n),
    .valid(cxl30_if.valid), .sop(cxl30_if.sop), .eop(cxl30_if.eop),
    .hdr(cxl30_if.data), .ready(cxl30_if.ready),
    .link_up(cxl30_if.link_up), .link_state(cxl30_if.link_state),
    .ecrc_error(cxl30_if.ecrc_error), .lcrc_error(cxl30_if.lcrc_error),
    .framing_error(cxl30_if.framing_error), .protocol_error(cxl30_if.protocol_error));

  mp_dut_channel #(.HDR_WIDTH(256)) ch_ucie (.clk(clk), .rst_n(rst_n),
    .valid(ucie_if.valid), .sop(ucie_if.sop), .eop(ucie_if.eop),
    .hdr(ucie_if.data), .ready(ucie_if.ready),
    .link_up(ucie_if.link_up), .link_state(ucie_if.link_state),
    .ecrc_error(ucie_if.ecrc_error), .lcrc_error(ucie_if.lcrc_error),
    .framing_error(ucie_if.framing_error), .protocol_error(ucie_if.protocol_error));

  mp_dut_channel ch_ualink (.clk(clk), .rst_n(rst_n),
    .valid(ualink_if.valid), .sop(ualink_if.sop), .eop(ualink_if.eop),
    .hdr(ualink_if.data), .ready(ualink_if.ready),
    .link_up(ualink_if.link_up), .link_state(ualink_if.link_state),
    .ecrc_error(ualink_if.ecrc_error), .lcrc_error(ualink_if.lcrc_error),
    .framing_error(ualink_if.framing_error), .protocol_error(ualink_if.protocol_error));
endmodule

//----------------------------------------------------------------------------
// Single responder channel (iverilog-checkable, no interface ports)
//----------------------------------------------------------------------------
module mp_dut_channel #(parameter int HDR_WIDTH = 512) (
  input  logic clk,
  input  logic rst_n,
  input  logic valid,
  input  logic sop,
  input  logic eop,
  input  logic [HDR_WIDTH-1:0] hdr,
  output logic ready,
  output logic link_up,
  output mp_vip_pkg::link_state_e link_state,
  output logic ecrc_error,
  output logic lcrc_error,
  output logic framing_error,
  output logic protocol_error
);
  import mp_vip_pkg::*;

  logic [3:0] beat_cnt;
  logic [1:0] stall_cnt;
  logic       err_burst;

  wire error_region = (hdr[HDR_WIDTH-1 -: 8] == 8'hEE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ready          <= 1'b0;
      link_up        <= 1'b0;
      link_state     <= LINK_RESET;
      ecrc_error     <= 1'b0;
      lcrc_error     <= 1'b0;
      framing_error  <= 1'b0;
      protocol_error <= 1'b0;
      beat_cnt       <= 4'h0;
      stall_cnt      <= 2'h0;
      err_burst      <= 1'b0;
    end
    else begin
      link_up    <= 1'b1;
      link_state <= LINK_L0;
      // error pulses are single-cycle
      ecrc_error     <= 1'b0;
      lcrc_error     <= 1'b0;
      framing_error  <= 1'b0;
      protocol_error <= 1'b0;

      // track bursts; inject ECRC error for error-region transfers
      if (valid && sop) begin
        beat_cnt  <= 4'h0;
        err_burst <= error_region;
      end
      else if (valid && ready) begin
        beat_cnt <= beat_cnt + 4'h1;
        if (err_burst && eop) begin
          ecrc_error <= 1'b1;
          err_burst  <= 1'b0;
        end
      end

      // periodic 2-cycle wait-state stall every 8 beats
      if (stall_cnt != 2'h0) begin
        stall_cnt <= stall_cnt - 2'h1;
        ready     <= 1'b0;
      end
      else begin
        ready <= valid;
        if (valid && ready && (beat_cnt == 4'h7)) begin
          stall_cnt <= 2'h2;
          ready     <= 1'b0;
        end
      end
    end
  end
endmodule
`endif
