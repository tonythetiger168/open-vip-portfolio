// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- UALink testbench top with a functional UALink DUT model

`ifndef UALink_TB_SV
`define UALink_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ualink_defs_pkg::*;
import ualink_pkg::*;
import ualink_env_pkg::*;
import ualink_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ualink_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ualink_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .req_valid(vif.req_valid),
    .req_ready(vif.req_ready),
    .req_opcode(vif.req_opcode),
    .req_addr(vif.req_addr),
    .req_wdata(vif.req_wdata),
    .rsp_valid(vif.rsp_valid),
    .rsp_ready(vif.rsp_ready),
    .rsp_status(vif.rsp_status),
    .rsp_rdata(vif.rsp_rdata)
  );

  // Concurrent protocol checks
  ualink_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .req_valid(vif.req_valid), .req_ready(vif.req_ready), .req_opcode(vif.req_opcode), .req_addr(vif.req_addr), .req_wdata(vif.req_wdata), .rsp_valid(vif.rsp_valid), .rsp_ready(vif.rsp_ready), .rsp_status(vif.rsp_status), .rsp_rdata(vif.rsp_rdata)
  );

  initial begin
    uvm_config_db#(virtual ualink_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ualink_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        req_valid,
  output logic        req_ready,
  input  logic [3:0]  req_opcode,
  input  logic [31:0] req_addr,
  input  logic [63:0] req_wdata,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output logic [1:0]  rsp_status,
  output logic [63:0] rsp_rdata
);
  // 4=read, 5=write; status 0=OK 1=ERR; single outstanding
  localparam OP_RD = 4'd4, OP_WR = 4'd5;
  logic [63:0] mem [0:63];
  logic        busy;
  integer i;
  initial begin rsp_valid = 1'b0; req_ready = 1'b1; rsp_status = 2'd0; rsp_rdata = '0; end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= 1'b0; req_ready <= 1'b1;
      rsp_valid <= 1'b0; rsp_status <= 2'd0; rsp_rdata <= '0;
    end else begin
      if (req_valid && req_ready) begin
        busy <= 1'b1;
        req_ready <= 1'b0;
        rsp_valid <= 1'b1;
        if (req_opcode == OP_RD) begin
          rsp_status <= 2'd0;
          rsp_rdata <= mem[req_addr[8:3]];
        end else if (req_opcode == OP_WR) begin
          mem[req_addr[8:3]] <= req_wdata;
          rsp_status <= 2'd0;
          rsp_rdata <= 64'h0;
        end else begin
          rsp_status <= 2'd1;
          rsp_rdata <= 64'h0;
        end
      end else if (rsp_valid && rsp_ready) begin
        rsp_valid <= 1'b0;
        busy <= 1'b0;
        req_ready <= 1'b1;
      end
    end
  end
endmodule
`endif
