// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (UALink request/response integrity)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened ualink_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic req_valid = 1'b0;
  logic [3:0] req_opcode = '0;
  logic [31:0] req_addr = '0;
  logic [63:0] req_wdata = '0;
  logic rsp_ready = 1'b0;
  wire  req_ready;
  wire  rsp_valid;
  wire  [1:0] rsp_status;
  wire  [63:0] rsp_rdata;

  always #5 clk = ~clk;

  ualink_model u_dut (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid),
    .req_ready(req_ready), .req_opcode(req_opcode),
    .req_addr(req_addr), .req_wdata(req_wdata),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready),
    .rsp_status(rsp_status), .rsp_rdata(rsp_rdata)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(req_ready === 1'b1, "ready high when idle");
    chk(rsp_valid === 1'b0, "rsp quiet in reset");
    @(negedge clk); rst_n = 1'b1;

    // write reg at addr 0x28 = index 5
    @(negedge clk); req_valid = 1'b1; req_opcode = 4'd5;
    req_addr = 32'h28; req_wdata = 64'hCAFE;
    step();
    chk(req_ready === 1'b0, "ready drops after accept");
    chk(rsp_valid === 1'b1 && rsp_status === 2'd0, "write rsp OK");
    @(negedge clk); req_valid = 1'b0; rsp_ready = 1'b1;
    step();
    chk(rsp_valid === 1'b0, "rsp completes");
    chk(req_ready === 1'b1, "ready returns");

    // read back
    @(negedge clk); req_valid = 1'b1; req_opcode = 4'd4;
    req_addr = 32'h28;
    step();
    @(negedge clk); req_valid = 1'b0;
    chk(rsp_valid === 1'b1 && rsp_status === 2'd0, "read rsp OK");
    chk(rsp_rdata === 64'hCAFE, "read data matches write");
    step();

    // illegal opcode -> ERR status
    @(negedge clk); rsp_ready = 1'b0;
    @(negedge clk); req_valid = 1'b1; req_opcode = 4'd7;
    req_addr = 32'h0;
    step();
    @(negedge clk); req_valid = 1'b0;
    chk(rsp_valid === 1'b1 && rsp_status === 2'd1, "illegal opcode ERR");
    step();
    chk(rsp_valid === 1'b1, "rsp held until ready");
    @(negedge clk); rsp_ready = 1'b1;
    step();
    chk(rsp_valid === 1'b0, "rsp clears after ready");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
