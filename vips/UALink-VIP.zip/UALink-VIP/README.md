# UALink UVM VIP (UALink-VIP)

UALink UVM VIP: scale-up accelerator interconnect request/response channel with 64-entry register space, single outstanding request, and status-coded responses for AI pod fabric smoke.

## Structure

- `ualink/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `ualink_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `ualink_base_test` (constrained-random), `ualink_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural UALink DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Accelerator endpoint reference (`ualink_tl/`, v1.9.0)

The agent above drives a one-outstanding request / response model.
`ualink_tl/` adds an endpoint at the transaction level and a requester
test with its own reference memory:

| File | Content |
|---|---|
| `ualink_tl/tb/ualink_tl_model.sv` | 16 KB memory window; READ / WRITE 64 B with byte enables; atomics ADD / SWAP / CAS returning the old value and ADD without response; arrival-order execution with out-of-order responses matched by tag; status UR (opcode, alignment), address error, poison (set, kept by a partial write, cleared by a full write); accelerator IDs (misrouted requests dropped, responses routed to the source); request credits with overflow detection; duplicate outstanding tags; responses held under back-pressure |
| `ualink_tl/tb/func_ualink_tl_tb.sv` | directed checks of every rule above plus 600 random requests with random back-pressure, every response checked for status and data: 21 checks (`python3 tools/run_func_tests.py UALink-VIP`, Verilator) |

The transaction rules follow the UALink 1.0 structure; opcode encodings,
field widths and status codes are this model's own. The data link layer
(640-byte flits, CRC, replay) and the physical layer are not modelled.

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/UALink-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh UALink-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py UALink-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
