// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// Multi-Protocol Verification Environment
// Instantiates agents for all supported protocols
//============================================================================
`ifndef MP_ENV_SV
`define MP_ENV_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import mp_vip_pkg::*;

class mp_env extends uvm_env;
  `uvm_component_utils(mp_env)
  // Protocol agents
  mp_agent pcie_gen5_agent;
  mp_agent pcie_gen6_agent;
  mp_agent cxl20_agent;
  mp_agent cxl30_agent;
  mp_agent ucie_agent;
  mp_agent ualink_agent;
  // Scoreboard
  mp_scoreboard sb;
  // Protocol checkers
  pcie_protocol_checker   pcie_chk;
  cxl_protocol_checker    cxl_chk;
  ucie_protocol_checker   ucie_chk;
  ualink_protocol_checker ualink_chk;
  // Coverage
  mp_coverage_model pcie_cov;
  mp_coverage_model cxl_cov;
  mp_coverage_model ucie_cov;
  mp_coverage_model ualink_cov;

  // Configuration
  bit enable_pcie_gen5 = 1;
  bit enable_pcie_gen6 = 1;
  bit enable_cxl20 = 1;
  bit enable_cxl30 = 1;
  bit enable_ucie = 1;
  bit enable_ualink = 1;

  function new(string name = "mp_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  // Create one agent, configure protocol/vif/cfg for it
  function automatic mp_agent make_agent(string name, protocol_e p, string vif_name);
    mp_agent a = mp_agent::type_id::create(name, this);
    mp_protocol_config pc = new($sformatf("%s_cfg", name), p);
    virtual mp_vip_if v;
    uvm_config_db#(protocol_e)::set(a, "", "protocol", p);
    uvm_config_db#(protocol_cfg_t)::set(a, "", "cfg", pc.cfg);
    if (uvm_config_db#(virtual mp_vip_if)::get(this, "", vif_name, v))
      uvm_config_db#(virtual mp_vip_if)::set(a, "*", "vif", v);
    else
      `uvm_fatal("CONFIG", $sformatf("env: %s not found", vif_name))
    return a;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    // Get configuration
    void'(uvm_config_db#(bit)::get(this, "", "enable_pcie_gen5", enable_pcie_gen5));
    void'(uvm_config_db#(bit)::get(this, "", "enable_pcie_gen6", enable_pcie_gen6));
    void'(uvm_config_db#(bit)::get(this, "", "enable_cxl20", enable_cxl20));
    void'(uvm_config_db#(bit)::get(this, "", "enable_cxl30", enable_cxl30));
    void'(uvm_config_db#(bit)::get(this, "", "enable_ucie", enable_ucie));
    void'(uvm_config_db#(bit)::get(this, "", "enable_ualink", enable_ualink));

    // Create agents
    if (enable_pcie_gen5) pcie_gen5_agent = make_agent("pcie_gen5_agent", PROTO_PCIE_GEN5, "pcie5_vif");
    if (enable_pcie_gen6) pcie_gen6_agent = make_agent("pcie_gen6_agent", PROTO_PCIE_GEN6, "pcie6_vif");
    if (enable_cxl20)     cxl20_agent     = make_agent("cxl20_agent", PROTO_CXL_20, "cxl20_vif");
    if (enable_cxl30)     cxl30_agent     = make_agent("cxl30_agent", PROTO_CXL_30, "cxl30_vif");
    if (enable_ucie)      ucie_agent      = make_agent("ucie_agent", PROTO_UCIE, "ucie_vif");
    if (enable_ualink)    ualink_agent    = make_agent("ualink_agent", PROTO_UALINK, "ualink_vif");

    // Scoreboard
    sb = mp_scoreboard::type_id::create("sb", this);

    // Protocol checkers (each grabs its protocol vif from config_db)
    pcie_chk   = pcie_protocol_checker::type_id::create("pcie_chk", this);
    cxl_chk    = cxl_protocol_checker::type_id::create("cxl_chk", this);
    ucie_chk   = ucie_protocol_checker::type_id::create("ucie_chk", this);
    ualink_chk = ualink_protocol_checker::type_id::create("ualink_chk", this);

    // Coverage
    pcie_cov   = mp_coverage_model::type_id::create("pcie_cov", this);
    cxl_cov    = mp_coverage_model::type_id::create("cxl_cov", this);
    ucie_cov   = mp_coverage_model::type_id::create("ucie_cov", this);
    ualink_cov = mp_coverage_model::type_id::create("ualink_cov", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (pcie_gen5_agent != null) begin
      pcie_gen5_agent.mon.ap.connect(pcie_cov.analysis_imp);
      pcie_gen5_agent.mon.ap.connect(sb.obs_ap);
      if (pcie_gen5_agent.drv != null) pcie_gen5_agent.drv.drv_ap.connect(sb.exp_ap);
    end
    if (pcie_gen6_agent != null)
      pcie_gen6_agent.mon.ap.connect(pcie_cov.analysis_imp);
    if (cxl20_agent != null)
      cxl20_agent.mon.ap.connect(cxl_cov.analysis_imp);
    if (cxl30_agent != null)
      cxl30_agent.mon.ap.connect(cxl_cov.analysis_imp);
    if (ucie_agent != null)
      ucie_agent.mon.ap.connect(ucie_cov.analysis_imp);
    if (ualink_agent != null) begin
      ualink_agent.mon.ap.connect(ualink_cov.analysis_imp);
      // UALink end-to-end: driver-issued (expected) vs monitor-decoded (observed)
      ualink_agent.mon.ap.connect(sb.obs_ap);
      if (ualink_agent.drv != null) ualink_agent.drv.drv_ap.connect(sb.exp_ap);
    end
  endfunction

  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("ENV", "MP Environment Done", UVM_LOW)
    if (ualink_cov != null)
      `uvm_info("COV", $sformatf("UALink coverage = %0.2f%%", ualink_cov.get_coverage()), UVM_LOW)
  endfunction
endclass
`endif
