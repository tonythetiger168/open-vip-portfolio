// Modem-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+modem
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/Modem_top.sv
rtl/Modem_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
modem/modem_pins_if.sv
common/ssv_pkg.sv
modem/modem_pkg.sv
tb/top_tb.sv
