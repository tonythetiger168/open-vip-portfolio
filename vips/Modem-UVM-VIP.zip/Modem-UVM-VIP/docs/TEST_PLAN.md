# Modem-UVM-VIP test plan

## Register test (`modem_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `modem_scramble_test`: 36 jobs: SEED 0 (becomes 1), 1, 0xFFFFFFFF and
  random; lengths 0, 1, 16, 17 and random up to 700 words; crc_sel 0 and 1;
  four back-pressure settings; addresses near 4 KB boundaries. Checks every
  output word, CRC, STATUS, DONE / ERR, the read and write word counts and
  windows, AXI ID 6.
- `modem_roundtrip_test`: scramble a block, descramble the output with the
  same seed: the result equals the original block and both CRCs (input of
  the first job, output of the second) match the CRC of the original.
- `modem_bypass_test`: CTRL.bypass = 1: output = input and CRC = CRC of the
  input; known answer: CRC-32 of the bytes "1234" (one little-endian word
  0x34333231) = 0x9BE3E0A3.
- `modem_err_test`: SLVERR in the source (output words = key there, since the
  input reads as 0), DECERR in the destination (words untouched): DONE + ERR,
  STATUS.err; the next clean job clears it.
