# Modem UVM VIP (Modem-UVM-VIP)

UVM verification IP for the open-ip-portfolio **Modem** subsystem: Modem baseband data path: LFSR scrambler / descrambler and CRC-32 of transport blocks over AXI4.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`b1cfc02463bd`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 6) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What Modem does (from the spec)

- out word = in word ^ key (key = 0 when BYPASS is 1); LEN words from SRC to DST.
- key: 32-bit Galois LFSR loaded with SEED at start (0 becomes 1); for i = 0..31: key[i] = s[0]; s = s[0] ? (s >> 1) ^ 0x80200003 : s >> 1. The state carries on to the next word.
- CRC = CRC-32 (IEEE 802.3: reflected, 0xEDB88320, init and final XOR 0xFFFFFFFF, bytes little-endian) of the input words (CRC_SEL 0) or of the output words (CRC_SEL 1).

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `modem/` -- `modem_ral.svh` register model (generated from the spec, same
  offsets as `Modem_apb`), `modem_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `modem_pins_if.sv`
- `rtl/` -- `Modem_apb.sv`, `Modem_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/modem.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | SRC_ADDR | rw |
| 0x018 | DST_ADDR | rw |
| 0x01C | LEN | rw |
| 0x020 | SEED | rw |
| 0x024 | CTRL | rw |
| 0x028 | CMD | cmd |
| 0x02C | STATUS | ro |
| 0x030 | CRC | ro |
| 0x034 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR.

## Tests

| Test | Seeds |
|---|---|
| `modem_ral_test` | 1 |
| `modem_scramble_test` | 3 |
| `modem_roundtrip_test` | 2 |
| `modem_bypass_test` | 1 |
| `modem_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT Modem mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/modem.f
./obj_dir/Vtop_tb +UVM_TESTNAME=modem_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py Modem-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
