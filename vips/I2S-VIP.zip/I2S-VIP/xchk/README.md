# Independent cross-check model (`xchk/`)

`i2s_xchk_tb.sv` checks the open-ip-portfolio `I2S` RTL (`rtl/I2S_top.sv`, `rtl/I2S_apb.sv`)
against an I2S bus master (WS on the BCLK falling edge, MSB one BCLK after it). The model is written from the Philips I2S bus specification, not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/i2s_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s i2s_xchk_tb -o xchk.vvp $OIP/rtl/I2S_top.sv $OIP/rtl/I2S_apb.sv xchk/i2s_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
