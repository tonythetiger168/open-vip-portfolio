// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2s_sequences.svh -- I2S sequence library

`ifndef I2S_SEQUENCES_SVH
`define I2S_SEQUENCES_SVH

class i2s_base_sequence extends uvm_sequence #(i2s_transaction);
  `uvm_object_utils(i2s_base_sequence)
  int num_txns = 20;
  function new(string name = "i2s_base_sequence"); super.new(name); endfunction
  task body();
    i2s_transaction tr;
    repeat (num_txns) begin
      tr = i2s_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: data corners (silence / full-scale) on both channels
class i2s_corner_seq extends i2s_base_sequence;
  function new(string name = "i2s_corner_seq"); super.new(name); endfunction
  `uvm_object_utils(i2s_corner_seq)
  task body();
    i2s_transaction tr;
    bit [23:0] corners[$] = '{24'h000000, 24'hFFFFFF, 24'h800000, 24'h7FFFFF};
    foreach (corners[i]) begin
      tr = i2s_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { left_data  == corners[i];
                                  right_data == corners[(i+1) % 4];
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: walking-1 pattern across the 24-bit sample
class i2s_walking_one_seq extends i2s_base_sequence;
  function new(string name = "i2s_walking_one_seq"); super.new(name); endfunction
  `uvm_object_utils(i2s_walking_one_seq)
  task body();
    i2s_transaction tr;
    for (int i = 0; i < 24; i++) begin
      tr = i2s_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { left_data  == (24'h1 << i);
                                  right_data == ~(24'h1 << i);
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: ramp samples (left ascends, right descends)
class i2s_ramp_seq extends i2s_base_sequence;
  function new(string name = "i2s_ramp_seq"); super.new(name); endfunction
  `uvm_object_utils(i2s_ramp_seq)
  rand bit [23:0] base = 24'h001000;
  task body();
    i2s_transaction tr;
    repeat (num_txns) begin
      tr = i2s_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 0; });
      tr.left_data  = base;
      tr.right_data = 24'hFFFFFF - base;
      base += 24'h000101;
      finish_item(tr);
    end
  endtask
endclass

// Directed: stereo complement frames (right = ~left)
class i2s_stereo_complement_seq extends i2s_base_sequence;
  function new(string name = "i2s_stereo_complement_seq"); super.new(name); endfunction
  `uvm_object_utils(i2s_stereo_complement_seq)
  task body();
    i2s_transaction tr;
    repeat (num_txns) begin
      tr = i2s_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { right_data == ~left_data; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back frames with no idle gap
class i2s_back_to_back_seq extends i2s_base_sequence;
  function new(string name = "i2s_back_to_back_seq"); super.new(name); endfunction
  `uvm_object_utils(i2s_back_to_back_seq)
  task body();
    i2s_transaction tr;
    repeat (num_txns) begin
      tr = i2s_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { idle_cycles == 0; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: long idle gaps between frames
class i2s_idle_gap_seq extends i2s_base_sequence;
  function new(string name = "i2s_idle_gap_seq"); super.new(name); endfunction
  `uvm_object_utils(i2s_idle_gap_seq)
  task body();
    i2s_transaction tr;
    repeat (num_txns) begin
      tr = i2s_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { idle_cycles inside {[4:8]}; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: ws misalignment (early ws toggle on the left slot)
class i2s_error_inject_seq extends i2s_base_sequence;
  function new(string name = "i2s_error_inject_seq"); super.new(name); endfunction
  `uvm_object_utils(i2s_error_inject_seq)
  task body();
    i2s_transaction tr;
    repeat (num_txns) begin
      tr = i2s_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 1; });
      finish_item(tr);
    end
  endtask
endclass

class i2s_random_sequence extends i2s_base_sequence;
  `uvm_object_utils(i2s_random_sequence)
  function new(string name = "i2s_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class i2s_regression_sequence extends i2s_base_sequence;
  `uvm_object_utils(i2s_regression_sequence)
  function new(string name = "i2s_regression_sequence"); super.new(name); endfunction
  task body();
    i2s_corner_seq            corner = i2s_corner_seq::type_id::create("corner");
    i2s_walking_one_seq       walk   = i2s_walking_one_seq::type_id::create("walk");
    i2s_ramp_seq              ramp   = i2s_ramp_seq::type_id::create("ramp");
    i2s_stereo_complement_seq comp   = i2s_stereo_complement_seq::type_id::create("comp");
    i2s_back_to_back_seq      b2b    = i2s_back_to_back_seq::type_id::create("b2b");
    i2s_idle_gap_seq          gap    = i2s_idle_gap_seq::type_id::create("gap");
    i2s_error_inject_seq      err    = i2s_error_inject_seq::type_id::create("err");
    i2s_random_sequence       rnd    = i2s_random_sequence::type_id::create("rnd");
    ramp.num_txns = 10; comp.num_txns = 10; b2b.num_txns = 15;
    gap.num_txns  = 10; err.num_txns  = 10; rnd.num_txns  = 20;
    corner.start(m_sequencer); walk.start(m_sequencer); ramp.start(m_sequencer);
    comp.start(m_sequencer);   b2b.start(m_sequencer);  gap.start(m_sequencer);
    err.start(m_sequencer);    rnd.start(m_sequencer);
  endtask
endclass
`endif
