// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i2s_compliance_checker.sv -- I2S Audio SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = I2S protocol-specific rules

`ifndef I2S_COMPLIANCE_CHECKER_SV
`define I2S_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import i2s_defs_pkg::*;

module i2s_compliance_checker
(
  input logic sck,
  input logic rst_n,
  input i2s_state_e state,
  input logic ws,
  input logic sd_o,
  input logic sd_i
);

  // ---------------- L1: signal sanity (4) ----------------
  a_i2s_l1_clk   : assert property (@(posedge sck) disable iff (!rst_n) !$isunknown(sck))
    else `uvm_error("SVA_L1", "i2s: clock unknown")
  a_i2s_l1_rst   : assert property (@(posedge sck) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "i2s: reset unknown")
  a_i2s_l1_state : assert property (@(posedge sck) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "i2s: state unknown")
  a_i2s_l1_valid : assert property (@(posedge sck) disable iff (!rst_n)
    state inside {IDLE, LEFT_CHANNEL, RIGHT_CHANNEL})
    else `uvm_error("SVA_L1", "i2s: state outside legal encoding")

  // ---------------- L2: FSM legality (3) ----------------
  // L2-1: legal FSM transition from IDLE
  a_i2s_trans_idle : assert property (@(posedge sck) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, LEFT_CHANNEL})
    else `uvm_error("SVA_L2", "i2s: illegal transition from IDLE")

  // L2-2: legal FSM transition from LEFT_CHANNEL
  a_i2s_trans_left_channel : assert property (@(posedge sck) disable iff (!rst_n)
    state == LEFT_CHANNEL |=> state inside {LEFT_CHANNEL, RIGHT_CHANNEL})
    else `uvm_error("SVA_L2", "i2s: illegal transition from LEFT_CHANNEL")

  // L2-3: legal FSM transition from RIGHT_CHANNEL
  a_i2s_trans_right_channel : assert property (@(posedge sck) disable iff (!rst_n)
    state == RIGHT_CHANNEL |=> state inside {RIGHT_CHANNEL, IDLE})
    else `uvm_error("SVA_L2", "i2s: illegal transition from RIGHT_CHANNEL")

  // ---------------- L3: protocol rules (4) ----------------
  a_i2s_l3_reset_idle : assert property (@(posedge sck)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "i2s: state not IDLE during reset")
  // a full channel slot is 24 sck cycles; allow margin above that
  a_i2s_l3_no_stuck   : assert property (@(posedge sck) disable iff (!rst_n)
    state == RIGHT_CHANNEL |-> ##[1:40] (state != RIGHT_CHANNEL))
    else `uvm_error("SVA_L3", "i2s: stuck in RIGHT_CHANNEL")
  a_i2s_l3_full_cycle : cover property (@(posedge sck) disable iff (!rst_n)
    state == IDLE ##1 state == LEFT_CHANNEL);
  a_i2s_l3_back_idle  : cover property (@(posedge sck) disable iff (!rst_n)
    state == RIGHT_CHANNEL ##1 state == IDLE);

  // ---------------- L4: I2S protocol-specific rules (6) ----------------
  // L4-1: ws may only change while sck is low (ws toggles on the sck falling edge)
  a_i2s_l4_ws_edge : assert property (@(ws) disable iff (!rst_n) sck == 1'b0)
    else `uvm_error("SVA_L4", "i2s: ws changed while sck high")

  // L4-2: left-channel slot width is fixed at 24 sck cycles
  a_i2s_l4_left_width : assert property (@(posedge sck) disable iff (!rst_n)
    $rose(state == LEFT_CHANNEL) |->
      (state == LEFT_CHANNEL) [*24] ##1 (state != LEFT_CHANNEL))
    else `uvm_error("SVA_L4", "i2s: left slot not exactly 24 sck cycles")

  // L4-3: right-channel slot width is fixed at 24 sck cycles
  a_i2s_l4_right_width : assert property (@(posedge sck) disable iff (!rst_n)
    $rose(state == RIGHT_CHANNEL) |->
      (state == RIGHT_CHANNEL) [*24] ##1 (state != RIGHT_CHANNEL))
    else `uvm_error("SVA_L4", "i2s: right slot not exactly 24 sck cycles")

  // L4-4: left/right alternation: ws polarity must match the channel state
  a_i2s_l4_lr_alternate : assert property (@(posedge sck) disable iff (!rst_n)
    ((state == LEFT_CHANNEL)  |-> (ws == 1'b0)) and
    ((state == RIGHT_CHANNEL) |-> (ws == 1'b1)))
    else `uvm_error("SVA_L4", "i2s: ws polarity does not match channel state")

  // L4-5: serial data is held low while in reset
  a_i2s_l4_reset_sd : assert property (@(posedge sck) !rst_n |-> (sd_o == 1'b0))
    else `uvm_error("SVA_L4", "i2s: sd_o not low during reset")

  // L4-6: idle line state (settled IDLE with ws parked high): sd low
  a_i2s_l4_idle_line : assert property (@(posedge sck) disable iff (!rst_n)
    (state == IDLE && $past(state) == IDLE && ws == 1'b1) |-> (sd_o == 1'b0))
    else `uvm_error("SVA_L4", "i2s: idle line state violated")

endmodule
`endif
