// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2s_transaction.svh -- I2S stereo audio frame transaction
//
// One transaction = one stereo frame: a left-channel slot (ws=0) carrying
// left_data MSB-first, followed by a right-channel slot (ws=1) carrying
// right_data MSB-first. Each slot is DATA_W sck cycles wide.

`ifndef I2S_TRANSACTION_SVH
`define I2S_TRANSACTION_SVH

class i2s_transaction extends uvm_sequence_item;

  localparam int DATA_W = 24;    // fixed channel data width

  rand bit [23:0] left_data;     // left-channel audio sample (MSB-first on sd)
  rand bit [23:0] right_data;    // right-channel audio sample (MSB-first on sd)
  rand bit        error_inject;  // ws misalignment: ws toggles after short_len bits
  rand int unsigned idle_cycles; // sck cycles of idle (ws=1, sd=0) after the frame
  rand int unsigned short_len;   // left-slot length when error_inject=1

  // Observed by the monitor (not driven)
  bit              ws_error;     // monitor detected a slot != DATA_W sck cycles
  bit [5:0]        obs_left_len; // monitor: measured left-slot length in sck cycles

  constraint c_err   { error_inject dist {0 := 9, 1 := 1}; }
  constraint c_idle  { idle_cycles inside {[0:8]}; }
  constraint c_short { short_len inside {[8:DATA_W-4]}; }

  `uvm_object_utils_begin(i2s_transaction)
    `uvm_field_int(left_data, UVM_ALL_ON)
    `uvm_field_int(right_data, UVM_ALL_ON)
    `uvm_field_int(error_inject, UVM_ALL_ON)
    `uvm_field_int(ws_error, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(obs_left_len, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "i2s_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    i2s_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= (comparer.compare_field("error_inject", error_inject, t.error_inject, 1) == 1);
    if (!error_inject) begin
      do_compare &= (comparer.compare_field("left_data",  left_data,  t.left_data,  24) == 1);
      do_compare &= (comparer.compare_field("right_data", right_data, t.right_data, 24) == 1);
    end else begin
      // misaligned frames: only the error detection result is compared
      do_compare &= (comparer.compare_field("ws_error", ws_error, t.ws_error, 1) == 1);
    end
  endfunction

  function string convert2string();
    return $sformatf("I2S frame L=0x%06h R=0x%06h%s (idle=%0d, ws_err=%0b, llen=%0d)",
                     left_data, right_data, error_inject ? " [WS_MISALIGN]" : "",
                     idle_cycles, ws_error, obs_left_len);
  endfunction
endclass
`endif
