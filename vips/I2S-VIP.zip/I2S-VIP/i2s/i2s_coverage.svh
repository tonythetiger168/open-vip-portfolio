// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2s_coverage.svh -- I2S functional coverage

`ifndef I2S_COVERAGE_SVH
`define I2S_COVERAGE_SVH

class i2s_coverage extends uvm_subscriber #(i2s_transaction);
  `uvm_component_utils(i2s_coverage)

  i2s_transaction tr;
  i2s_defs_pkg::i2s_state_e cur_state;
  virtual i2s_if vif;

  covergroup cg_protocol;
    cp_left : coverpoint tr.left_data {
      bins zero  = {24'h000000};
      bins ones  = {24'hFFFFFF};
      bins posfs = {24'h7FFFFF};            // positive full-scale
      bins negfs = {24'h800000};            // negative full-scale
      bins walk  = {[24'h000001 : 24'h7FFFFE]};
    }
    cp_right : coverpoint tr.right_data {
      bins zero  = {24'h000000};
      bins ones  = {24'hFFFFFF};
      bins posfs = {24'h7FFFFF};
      bins negfs = {24'h800000};
      bins walk  = {[24'h000001 : 24'h7FFFFE]};
    }
    cp_idle : coverpoint tr.idle_cycles {
      bins b2b   = {0};
      bins short = {[1:3]};
      bins long  = {[4:16]};
    }
    cx_lr : cross cp_left, cp_right {
      // corner x corner combinations are the interesting ones
      bins corners = binsof(cp_left) intersect {24'h000000, 24'hFFFFFF} &&
                     binsof(cp_right) intersect {24'h000000, 24'hFFFFFF};
    }
  endgroup

  covergroup cg_fsm with function sample(i2s_defs_pkg::i2s_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {i2s_defs_pkg::IDLE, i2s_defs_pkg::LEFT_CHANNEL,
                           i2s_defs_pkg::RIGHT_CHANNEL};
    }
    cp_trans : coverpoint s {
      bins frame_seq = (i2s_defs_pkg::IDLE => i2s_defs_pkg::LEFT_CHANNEL =>
                        i2s_defs_pkg::RIGHT_CHANNEL => i2s_defs_pkg::IDLE);
      bins lr_swap   = (i2s_defs_pkg::LEFT_CHANNEL => i2s_defs_pkg::RIGHT_CHANNEL);
    }
  endgroup

  covergroup cg_error;
    cp_ws_error : coverpoint tr.ws_error { bins ok = {0}; bins misalign = {1}; }
    cp_left_len : coverpoint tr.obs_left_len {
      bins legal = {24};
      bins short = {[8:20]};
    }
    cx_err_len : cross cp_ws_error, cp_left_len;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual i2s_if)::get(this, "", "vif", vif));
  endfunction

  function void write(i2s_transaction t);
    tr = t;
    if (vif != null) cur_state = vif.state;
    cg_protocol.sample();
    cg_fsm.sample(cur_state);
    cg_error.sample();
  endfunction
endclass
`endif
