// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2s_monitor.svh -- I2S monitor: decodes stereo frames from the ws/sd_o
// waveforms. A left slot is delimited by a falling then a rising edge of ws
// and must be exactly 24 sck cycles wide; the first 24 bits after the rising
// edge form the right slot. A slot-length mismatch is flagged as ws_error
// (ws misalignment). Transactions are published once the right slot completes.

`ifndef I2S_MONITOR_SVH
`define I2S_MONITOR_SVH

class i2s_monitor extends uvm_monitor;
  `uvm_component_utils(i2s_monitor)
  virtual i2s_if vif;
  uvm_analysis_port #(i2s_transaction) ap;
  int unsigned txn_count = 0;

  protected bit        ws_d;
  protected bit        in_left, in_right, have_left;
  protected bit [23:0] lshift, rshift, left_data;
  protected bit        l_err;
  protected int unsigned lcnt, rcnt;
  protected int unsigned idle_cnt, prev_idle;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual i2s_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "i2s virtual interface not set")
  endfunction

  function void clear_slots();
    in_left   = 0;
    in_right  = 0;
    have_left = 0;
    l_err     = 0;
    lcnt      = 0;
    rcnt      = 0;
    idle_cnt  = 0;
    prev_idle = 0;
    lshift    = '0;
    rshift    = '0;
    ws_d      = 1'b1;          // idle polarity: ws parked high
  endfunction

  task run_phase(uvm_phase phase);
    i2s_transaction tr;
    bit ws, sd;
    clear_slots();
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        clear_slots();
        continue;
      end
      ws = vif.mon_cb.ws;
      sd = vif.mon_cb.sd_o;

      if (ws_d === 1'b0 && ws === 1'b1) begin
        // rising edge of ws: left slot just closed, right slot opens
        if (in_left) begin
          left_data = lshift;
          l_err     = (lcnt != 24);
          have_left = 1;
          in_left   = 0;
        end
        in_right = 1;
        rcnt     = 0;
        rshift   = '0;
      end
      else if (ws_d === 1'b1 && ws === 1'b0) begin
        // falling edge of ws: a new left slot opens
        in_left   = 1;
        lcnt      = 0;
        lshift    = '0;
        l_err     = 0;
        in_right  = 0;
        prev_idle = idle_cnt;   // idle gap that preceded this frame
        idle_cnt  = 0;
      end

      if (in_left) begin
        lcnt++;
        if (lcnt <= 24) lshift = {lshift[22:0], sd};
      end
      else if (!in_right) begin
        idle_cnt++;             // settled idle cycle (ws parked, no slot open)
      end
      if (in_right) begin
        rcnt++;
        if (rcnt <= 24) rshift = {rshift[22:0], sd};
        if (rcnt == 24 && have_left) begin
          // stereo frame complete
          tr = i2s_transaction::type_id::create("tr");
          tr.left_data    = left_data;
          tr.right_data   = rshift;
          tr.ws_error     = l_err;
          tr.obs_left_len = lcnt[5:0];
          tr.error_inject = l_err;
          tr.idle_cycles  = prev_idle;
          txn_count++;
          `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
          ap.write(tr);
          in_right  = 0;
          have_left = 0;
        end
      end
      ws_d = ws;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("i2s monitor observed %0d frames", txn_count), UVM_LOW)
  endfunction
endclass
`endif
