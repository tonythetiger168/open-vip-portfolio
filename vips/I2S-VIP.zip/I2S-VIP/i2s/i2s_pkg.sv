// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i2s_pkg.sv -- I2S Audio UVM VIP package

package i2s_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import i2s_defs_pkg::*;
  export i2s_defs_pkg::*;

  `include "i2s_transaction.svh"
  `include "i2s_config.svh"
  `include "i2s_sequencer.svh"
  `include "i2s_driver.svh"
  `include "i2s_monitor.svh"
  `include "i2s_agent.svh"
  `include "i2s_sequences.svh"
  `include "i2s_checker.svh"
  `include "i2s_coverage.svh"
endpackage
