// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// i2s_driver.svh -- I2S transmitter driver (bit-banged, MSB-first 24-bit slots)
//
// Timing model (standard I2S flavour):
//   * ws / sd_o change on the falling edge of sck, sampled on the rising edge.
//   * A frame = left slot (ws=0, 24 bits) + right slot (ws=1, 24 bits).
//   * Between frames the line idles with ws=1, sd_o=0 for idle_cycles sck.
//   * error_inject frames toggle ws early (after short_len bits) and keep
//     vif.state == IDLE to mark the frame as non-compliant.

`ifndef I2S_DRIVER_SVH
`define I2S_DRIVER_SVH

class i2s_driver extends uvm_driver #(i2s_transaction);
  `uvm_component_utils(i2s_driver)
  virtual i2s_if vif;
  i2s_config cfg;
  uvm_analysis_port #(i2s_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual i2s_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "i2s virtual interface not set")
  endfunction

  // Drive one 24-bit channel slot, MSB first. ws_level is applied together
  // with the first data bit (both change on the same falling edge of sck).
  task automatic send_slot(bit [23:0] data, bit ws_level, i2s_defs_pkg::i2s_state_e st,
                           int nbits = 24);
    vif.drv_cb.ws   <= ws_level;
    vif.drv_cb.sd_o <= data[23];
    @(vif.drv_cb);                       // first falling edge: ws edge + bit 23
    vif.state = st;                      // slot marker valid from here (24 posedges)
    for (int i = 22; i >= 24 - nbits; i--) begin
      vif.drv_cb.sd_o <= data[i];
      @(vif.drv_cb);
    end
  endtask

  task automatic drive_frame(i2s_transaction tr);
    int llen = tr.error_inject ? tr.short_len : 24;
    i2s_defs_pkg::i2s_state_e lst = tr.error_inject ? i2s_defs_pkg::IDLE
                                                    : i2s_defs_pkg::LEFT_CHANNEL;
    i2s_defs_pkg::i2s_state_e rst = tr.error_inject ? i2s_defs_pkg::IDLE
                                                    : i2s_defs_pkg::RIGHT_CHANNEL;
    // LEFT slot: ws falls (misaligned frames toggle ws back early)
    send_slot(tr.left_data, 1'b0, lst, llen);
    // RIGHT slot: ws rises (misaligned frames send a muted right slot)
    send_slot(tr.error_inject ? 24'h0 : tr.right_data, 1'b1, rst, 24);
    // idle gap: ws parked high, sd low
    vif.state = i2s_defs_pkg::IDLE;
    vif.drv_cb.sd_o <= 1'b0;
    repeat (tr.idle_cycles) @(vif.drv_cb);
  endtask

  task run_phase(uvm_phase phase);
    i2s_transaction tr;
    vif.drv_cb.ws   <= 1'b1;
    vif.drv_cb.sd_o <= 1'b0;
    vif.state = i2s_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);            // idle preamble: ws high, sd low
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      drive_frame(tr);
      drv_ap.write(tr);                  // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
