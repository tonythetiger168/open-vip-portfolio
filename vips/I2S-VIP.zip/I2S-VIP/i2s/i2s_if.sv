// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i2s_if.sv -- I2S Audio interface (sck / ws / sd, transmitter & receiver modports)
//
// Signal roles:
//   sck  : bit clock (interface input, free-running)
//   ws   : word select, 0 = left channel slot, 1 = right channel slot.
//          Driven by the transmitter (VIP driver). Changes only while sck low.
//   sd_o : serial data, MSB-first 24-bit audio, driven by the transmitter.
//          Data changes on the falling edge of sck, sampled on the rising edge.
//   sd_i : loopback serial data driven by the DUT (received-frame mirror).

interface i2s_if (input logic sck);
  import i2s_defs_pkg::i2s_state_e;

  logic rst_n;
  logic ws   = 1'b1;   // idle: parked high (right-slot polarity)
  logic sd_o = 1'b0;   // idle: serial data low
  logic sd_i = 1'b0;

  i2s_state_e state;   // protocol bookkeeping (driven by the VIP driver):
                       // LEFT_CHANNEL/RIGHT_CHANNEL mark compliant channel slots,
                       // IDLE marks idle gaps and non-compliant (error-injected) frames.

  modport MASTER (input  sck, rst_n,
                  output ws, sd_o, state);
  modport DUT    (input  sck, rst_n, ws, sd_o,
                  output sd_i);
  modport MON    (input  sck, rst_n, ws, sd_o, sd_i, state);

  // Transmitter drives on the falling edge of sck.
  clocking drv_cb @(negedge sck);
    input  rst_n;
    output ws, sd_o;
  endclocking

  // Monitor / receiver sample on the rising edge of sck.
  clocking mon_cb @(posedge sck);
    input rst_n, ws, sd_o, sd_i, state;
  endclocking
endinterface
