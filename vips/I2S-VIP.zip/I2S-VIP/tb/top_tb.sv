// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- I2S Audio testbench top with a functional I2S receiver
//              loopback DUT model

`ifndef I2S_TB_SV
`define I2S_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import i2s_defs_pkg::*;
import i2s_pkg::*;
import i2s_test_pkg::*;

module top_tb;
  logic sck = 0;
  always #5ns sck = ~sck;

  i2s_if vif(sck);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  i2s_receiver_loopback dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual i2s_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional I2S receiver with loopback: samples sd_o on the rising edge of
// sck, splits the stream into left/right slots using ws, stores each received
// 24-bit sample into channel memories (readable via read_left()/read_right()),
// and mirrors the received bit stream onto sd_i with a one-sck delay
// (loopback) so the received stream can be observed on the way out.
module i2s_receiver_loopback (i2s_if vif);

  bit [23:0] left_mem  [int unsigned];
  bit [23:0] right_mem [int unsigned];
  int unsigned wr_idx = 0;

  bit [23:0] lshift, rshift;
  int unsigned lcnt, rcnt;
  bit in_left, in_right;
  bit ws_d;

  // Readback helpers (hierarchical access from tests/sequences if needed)
  function bit [23:0] read_left(int unsigned idx);
    return left_mem.exists(idx) ? left_mem[idx] : 24'hX;
  endfunction
  function bit [23:0] read_right(int unsigned idx);
    return right_mem.exists(idx) ? right_mem[idx] : 24'hX;
  endfunction
  function int unsigned num_frames();
    return wr_idx;
  endfunction

  initial begin
    ws_d     = 1'b1;
    in_left  = 0;
    in_right = 0;
    lcnt     = 0;
    rcnt     = 0;
    vif.sd_i = 1'b0;
  end

  // Receive path: decode left/right slots on the rising edge of sck
  always @(posedge vif.sck or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      ws_d     <= 1'b1;
      in_left  <= 0;
      in_right <= 0;
      lcnt     <= 0;
      rcnt     <= 0;
      wr_idx   <= 0;
    end else begin
      if (ws_d && !vif.ws) begin          // falling edge of ws: left slot opens
        in_left  <= 1;
        in_right <= 0;
        lcnt     <= 1;
        lshift   <= {23'h0, vif.sd_o};
      end else if (!ws_d && vif.ws) begin // rising edge of ws: right slot opens
        if (in_left && lcnt == 24) left_mem[wr_idx] = lshift;
        in_left  <= 0;
        in_right <= 1;
        rcnt     <= 1;
        rshift   <= {23'h0, vif.sd_o};
      end else if (in_left) begin
        lcnt   <= lcnt + 1;
        if (lcnt < 24) lshift <= {lshift[22:0], vif.sd_o};
      end else if (in_right) begin
        if (rcnt == 23) begin
          // current sd carries the last right bit (R0); complete the sample now
          // so b2b frames (ws falls on the next posedge) are never missed.
          right_mem[wr_idx] = {rshift[22:0], vif.sd_o};
          wr_idx   <= wr_idx + 1;
          in_right <= 0;
          rcnt     <= 0;
        end else begin
          rshift <= {rshift[22:0], vif.sd_o};
          rcnt   <= rcnt + 1;
        end
      end
      ws_d <= vif.ws;
    end
  end

  // Loopback path: mirror the received stream onto sd_i with 1 sck delay
  always @(negedge vif.sck or negedge vif.rst_n) begin
    if (!vif.rst_n) vif.sd_i <= 1'b0;
    else            vif.sd_i <= vif.sd_o;
  end
endmodule
`endif
