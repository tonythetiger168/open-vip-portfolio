// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_i2s_tb.sv -- self-checking functional test for the I2S receiver /
// loopback model (i2s_receiver_loopback, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py I2S-VIP
//
// Model contract (from tb/top_tb.sv and i2s_driver.svh):
//   the transmitter changes WS and SD on the falling edge of SCK, the
//   receiver samples on the rising edge. WS low = left slot, WS high = right
//   slot, 24-bit samples MSB first. The MSB is sent in the same SCK cycle as
//   the WS transition (left-justified alignment, no Philips one-bit delay).
//   A left sample is stored only if all 24 bits arrived before WS rose; each
//   complete right sample closes a frame (frame index wr_idx). SD is looped
//   back on sd_i half a cycle later (falling edge).

module func_i2s_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic sck = 1'b0, rst_n = 1'b0, ws = 1'b1, sd = 1'b0;
  wire  sd_i;

  always #5 sck = ~sck;

  i2s_receiver_loopback u_dut (
    .vif_sck(sck), .vif_rst_n(rst_n), .vif_ws(ws), .vif_sd_o(sd), .vif_sd_i(sd_i)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic slot(input [23:0] d, input bit lvl, input int nbits = 24);
    for (int i = 23; i >= 24 - nbits; i--) begin
      @(negedge sck);
      ws = lvl; sd = d[i];
    end
  endtask

  task automatic frame(input [23:0] l, input [23:0] r, input int lbits = 24, input int gap = 2);
    slot(l, 1'b0, lbits);
    slot(r, 1'b1);
    repeat (gap) begin @(negedge sck); sd = 1'b0; end
  endtask

  // loopback monitor: sd_i must equal sd as sampled on the previous falling edge
  int lb_err = 0, lb_n = 0;
  logic sd_prev;
  always @(negedge sck) sd_prev <= sd;
  always @(posedge sck) if (rst_n) begin lb_n++; if (sd_i !== sd_prev) lb_err++; end

  initial begin
    repeat (2) @(negedge sck);
    rst_n = 1'b1;
    repeat (2) @(negedge sck);

    frame(24'hA5_1234, 24'h5A_ABCD);
    @(posedge sck); #1;
    chk(u_dut.wr_idx == 1, "a left+right pair closes one frame");
    chk(u_dut.left_mem[0] === 24'hA5_1234, "left 24-bit sample captured MSB first");
    chk(u_dut.right_mem[0] === 24'h5A_ABCD, "right 24-bit sample captured MSB first");

    frame(24'hFFFFFF, 24'h000000);
    frame(24'h800001, 24'h7FFFFE, 24, 0);       // back-to-back, no idle gap
    frame(24'h000001, 24'h800000);
    @(posedge sck); #1;
    chk(u_dut.wr_idx == 4, "frame counter advances per frame (incl. back-to-back frames)");
    chk(u_dut.left_mem[1] === 24'hFFFFFF && u_dut.right_mem[1] === 24'h000000, "all-ones / all-zeros samples");
    chk(u_dut.left_mem[2] === 24'h800001 && u_dut.right_mem[2] === 24'h7FFFFE, "MSB/LSB extremes without an idle gap");
    chk(u_dut.left_mem[3] === 24'h000001 && u_dut.right_mem[3] === 24'h800000, "single-bit samples keep bit order");

    // WS toggles early: a short left slot is dropped, the right sample is kept
    frame(24'hDEAD00, 24'h00BEEF, 16);
    @(posedge sck); #1;
    chk(!u_dut.left_mem.exists(4), "short (16-bit) left slot is not stored");
    chk(u_dut.right_mem[4] === 24'h00BEEF && u_dut.wr_idx == 5, "right sample after a short left slot still stored");

    // backdoor readback helpers (top_tb.sv)
    chk(u_dut.num_frames() == 5, "num_frames() returns the frame count");
    chk(u_dut.read_left(2) === 24'h800001 && u_dut.read_right(2) === 24'h7FFFFE,
        "read_left()/read_right() return the stored samples");
    // (a slot never stored reads X on 4-state simulators; Verilator turns X
    // into a random value, so only stored slots are checked here)

    chk(lb_n > 100 && lb_err == 0, "SD looped back on sd_i half an SCK cycle later");

    @(negedge sck); rst_n = 1'b0;
    @(negedge sck);
    chk(u_dut.wr_idx == 0 && sd_i === 1'b0, "reset clears the frame index and sd_i");
    @(negedge sck); rst_n = 1'b1;
    repeat (2) @(negedge sck);
    frame(24'h13579B, 24'h2468AC);
    @(posedge sck); #1;
    chk(u_dut.num_frames() == 1 && u_dut.read_left(0) === 24'h13579B && u_dut.read_right(0) === 24'h2468AC,
        "first frame after reset is stored at index 0 again");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
