# I2S — I2S Audio UVM VIP

Open-source UVM verification IP template for **I2S Audio** (Audio).

## Contents

| Path | Description |
|------|-------------|
| `i2s/i2s_if.sv` | Protocol interface + FSM state enum |
| `i2s/i2s_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `i2s/sva/i2s_compliance_checker.sv` | SVA compliance checker (L1=4, L2=3, L3=4, L4=6) |
| `i2s/vip/i2s/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/i2s_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with FSM-walking DUT stub |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Bit-banged transmitter driver**: ws/sd_o change on the sck falling edge, left slot (ws=0) + right slot (ws=1), 24-bit MSB-first audio per channel, programmable idle gaps
- **Protocol-decoding monitor**: reconstructs stereo frames from ws edge delimiters, measures left-slot width, flags ws misalignment (`ws_error`)
- **End-to-end scoreboard**: driver-issued vs monitor-decoded frames; misaligned frames checked via the error flag instead of data
- **Functional DUT model**: I2S receiver loopback — decodes both channel slots into per-channel sample memories (readback via `read_left()/read_right()`) and mirrors the received stream onto `sd_i`
- **Directed sequence library**: corner / walking-one / ramp / stereo-complement / back-to-back / idle-gap / error-inject (ws misalignment) + regression mix
- **Functional coverage**: left x right corner cross, idle-gap bins, FSM state + frame-sequence transitions, ws-error and slot-length error bins
- **SVA L4**: ws changes only while sck low, left/right slot width fixed at 24 sck, ws/channel-state alternation, sd low during reset, idle line state
