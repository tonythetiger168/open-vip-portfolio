// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// i2s_env.sv -- I2S Audio verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import i2s_defs_pkg::*;
  import i2s_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) stereo frames
  // against monitor-decoded (observed) frames. For ws-misalignment frames the
  // expected outcome is the monitor's ws_error flag instead of data.
  class i2s_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(i2s_scoreboard)
    uvm_analysis_imp_exp #(i2s_transaction, i2s_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(i2s_transaction, i2s_scoreboard) obs_ap;

    i2s_transaction exp_q[$], obs_q[$];
    int unsigned matched = 0, mismatched = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(i2s_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(i2s_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        i2s_transaction e = exp_q.pop_front();
        i2s_transaction o = obs_q.pop_front();
        bit ok;
        if (e.error_inject)
          ok = o.ws_error;                       // misalignment must be detected
        else
          ok = !o.ws_error &&
               (e.left_data == o.left_data) &&
               (e.right_data == o.right_data);
        if (ok) matched++;
        else begin
          mismatched++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("i2s scoreboard: matched=%0d mismatched=%0d",
                matched, mismatched), UVM_LOW)
      if (mismatched) `uvm_error("SB", "end-to-end mismatched detected")
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("unmatched transactions: exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
    endfunction
  endclass

  class i2s_env extends uvm_env;
    `uvm_component_utils(i2s_env)
    i2s_agent      agt;
    i2s_scoreboard sb;
    i2s_checker    chk;
    i2s_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = i2s_agent::type_id::create("agt", this);
      sb  = i2s_scoreboard::type_id::create("sb", this);
      chk = i2s_checker::type_id::create("chk", this);
      cov = i2s_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
