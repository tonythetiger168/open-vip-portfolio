// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// can_env.sv -- CAN verification environment with end-to-end scoreboard

package can_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import can_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) frames
  // against monitor-decoded (observed) frames.
  class can_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(can_scoreboard)
    uvm_analysis_imp_exp #(can_transaction, can_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(can_transaction, can_scoreboard) obs_ap;

    can_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(can_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(can_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        can_transaction e = exp_q.pop_front();
        can_transaction o = obs_q.pop_front();
        bit ok;
        if (e.with_error) begin
          // error-injected frames must surface as errors on the bus
          ok = o.with_error || (o.frame_type == can_transaction::ERROR_FRAME);
        end else begin
          ok = (e.id == o.id) && (e.ide == o.ide) && (e.rtr == o.rtr) &&
               (e.dlc == o.dlc) && (e.fdf == o.fdf) &&
               (e.rtr || (e.data == o.data));
        end
        if (ok) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("can scoreboard: n_matches=%0d n_mismatches=%0d",
                n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  class can_env extends uvm_env;
    `uvm_component_utils(can_env)
    can_agent      agt;
    can_scoreboard sb;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = can_agent::type_id::create("agt", this);
      sb  = can_scoreboard::type_id::create("sb", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
    endfunction
  endclass
endpackage
