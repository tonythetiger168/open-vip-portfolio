# CAN Test Plan（CAN-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | CAN |
| 家族 | Automotive |
| 類型 | UVM VIP |
| 交付目錄 | `CAN-VIP/` |
| 目前 L1b 狀態 | PASS |

## 2. DUT / 待測對象

- `can_node_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke

- 狀態：**尚未導入**（目前為 model smoke / directed-tb smoke）
- 導入方式：比照 `gen_func_tb.py` 產出的 self-checking tb，對展平後的 behavioral model 做 directed 檢查

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Agent reset and first-transaction bring-up |
| PT-02 | Constrained-random sequence sweep (base sequence extended) |
| PT-03 | Error injection and protocol-violation response |
| PT-04 | Backpressure / wait-state interaction |
| PT-05 | End-to-end scoreboard matching (exp vs obs streams) |
| PT-06 | Coverage closure toward the self-served COV_GOAL=100 checklist |

## 5. 覆蓋與檢查

**Coverpoints（功能覆蓋取樣點）：**

- `tx.ack_error`
- `tx.brs`
- `tx.crc_error`
- `tx.esi`
- `tx.form_error`
- `tx.ide`
- `tx.stuff_error`
- `tx.with_error`

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/CAN-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py CAN-VIP && python3 smoke/smoke_run.py CAN-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- functional smoke 調查中（`tb/smoke_func_tb.sv.investigate`）：已證實 reset 後 ~13.5us bus integration、std 幀格式無 r0 槽、simplified stuff checker 與 6-recessive EOF 偵測互斥；好幀取樣分歧待查。
- model smoke 正常 PASS。

---
*文件版本：v1.7.5 自動產生*
