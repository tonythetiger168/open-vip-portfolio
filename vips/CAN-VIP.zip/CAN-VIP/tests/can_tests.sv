// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// can_tests.sv -- CAN UVM tests

package can_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import can_pkg::*;
  import can_env_pkg::*;

  class base_test extends uvm_test;
    `uvm_component_utils(base_test)
    can_env env;
    function new(string name = "base_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = can_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      can_random_sequence seq;
      phase.raise_objection(this);
      seq = can_random_sequence::type_id::create("seq");
      seq.num_txns = 20;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class random_test extends base_test;
    `uvm_component_utils(random_test)
    function new(string name = "random_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    task run_phase(uvm_phase phase);
      can_random_sequence seq;
      phase.raise_objection(this);
      seq = can_random_sequence::type_id::create("seq");
      seq.num_txns = 50;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class can_2_0_test extends base_test;
    `uvm_component_utils(can_2_0_test)
    function new(string name = "can_2_0_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    task run_phase(uvm_phase phase);
      can_2_0_sequence seq;
      phase.raise_objection(this);
      seq = can_2_0_sequence::type_id::create("seq");
      seq.num_txns = 20;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class error_inject_test extends base_test;
    `uvm_component_utils(error_inject_test)
    function new(string name = "error_inject_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    task run_phase(uvm_phase phase);
      can_error_inject_sequence seq;
      phase.raise_objection(this);
      seq = can_error_inject_sequence::type_id::create("seq");
      seq.num_txns = 10;
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass

  class regression_test extends base_test;
    `uvm_component_utils(regression_test)
    function new(string name = "regression_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    task run_phase(uvm_phase phase);
      can_regression_sequence seq;
      phase.raise_objection(this);
      seq = can_regression_sequence::type_id::create("seq");
      seq.start(env.agt.sqr);
      phase.drop_objection(this);
    endtask
  endclass
endpackage
