// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_can_tb.sv -- self-checking functional test for the CAN node model
// (tb/top_tb.sv can_node_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py CAN-VIP
//
// The frames are built here from ISO 11898-1: SOF, identifier (11 bits, or
// 11 + SRR + IDE + 18 for extended), RTR, IDE/r0, r0/FDF, DLC, data, CRC-15
// (x^15+x^14+x^10+x^8+x^7+x^4+x^3+1 over SOF..data), bit stuffing after 5
// equal bits over SOF..CRC (a stuff bit starts the next run), then CRC
// delimiter, ACK slot, ACK delimiter, 7-bit EOF and 3-bit intermission, all
// recessive. 8 clocks per bit.
// Model contract (from tb/top_tb.sv): the node receives a frame while
// can_en, checks the CRC (crc_ok), latches id/ide/rtr/dlc/fdf, pulses sof
// and re-transmits the frame on can_tx; a CRC or stuff error sends a 6-bit
// dominant error flag (error_frame, error_count_rx++). The error counters
// are not cleared by reset.
// The receiver destuffs SOF..CRC only (a stuff bit starts the next run),
// then takes CRC delimiter, ACK slot, ACK delimiter and EOF unstuffed; a
// dominant delimiter/EOF bit is a form error.

module func_can_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int BT = 8;
  int checks = 0, fails = 0, xfails = 0;

  logic clk = 1'b0, rst_n = 1'b0, rx = 1'b1, en = 1'b1;
  wire  tx, sof, crc_ok, ovl, ide, rtr, crc_delim, ack_slot, ack_delim, fdf, brs, esi;
  wire  tt_trig, err_frame, bus_off;
  wire  [10:0] id_std;
  wire  [28:0] id_ext;
  wire  [3:0]  dlc;
  wire  [14:0] crc;
  wire  [15:0] tt_cycle;
  wire  [7:0]  tt_slot;
  wire  [2:0]  ec_tx, ec_rx;

  always #5 clk = ~clk;

  can_node_model u_dut (
    .clk(clk), .rst_n(rst_n), .can_rx(rx), .can_en(en), .can_tx(tx), .sof(sof), .crc_ok(crc_ok),
    .overload_frame(ovl), .id_std(id_std), .id_ext(id_ext), .ide(ide), .rtr(rtr), .dlc(dlc),
    .crc(crc), .crc_delim(crc_delim), .ack_slot(ack_slot), .ack_delim(ack_delim), .fdf(fdf),
    .brs(brs), .esi(esi), .tt_trigger(tt_trig), .tt_cycle(tt_cycle), .tt_slot(tt_slot),
    .error_frame(err_frame), .error_count_tx(ec_tx), .error_count_rx(ec_rx), .bus_off(bus_off)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // ---- frame encoder ----
  bit raw[$], wire_bits[$];
  function automatic logic [14:0] crc15(input bit b[$]);
    logic [14:0] c = 0;
    foreach (b[i]) begin
      bit nxt = b[i] ^ c[14];
      c = c << 1;
      if (nxt) c ^= 15'h4599;
    end
    return c;
  endfunction

  task automatic encode(input bit ext, input [28:0] id, input bit r, input [3:0] n,
                        input logic [7:0] d[$], input bit bad_crc = 0, input bit no_stuff_at = 0);
    logic [14:0] c;
    bit last; int run;
    raw.delete(); wire_bits.delete();
    raw.push_back(0);                                        // SOF
    if (!ext) begin
      for (int i = 10; i >= 0; i--) raw.push_back(id[i]);
      raw.push_back(r); raw.push_back(0); raw.push_back(0);  // RTR, IDE, r0
    end else begin
      for (int i = 28; i >= 18; i--) raw.push_back(id[i]);
      raw.push_back(1); raw.push_back(1);                    // SRR, IDE
      for (int i = 17; i >= 0; i--) raw.push_back(id[i]);
      raw.push_back(r); raw.push_back(0); raw.push_back(0);  // RTR, r1, r0
    end
    for (int i = 3; i >= 0; i--) raw.push_back(n[i]);
    if (!r) foreach (d[k]) for (int i = 7; i >= 0; i--) raw.push_back(d[k][i]);
    c = crc15(raw) ^ (bad_crc ? 15'h0001 : 15'h0);
    for (int i = 14; i >= 0; i--) raw.push_back(c[i]);
    // stuffing, SOF..CRC
    run = 0;
    foreach (raw[i]) begin
      wire_bits.push_back(raw[i]);
      if (i > 0 && raw[i] == last) run++; else begin last = raw[i]; run = 1; end
      if (run == 5) begin
        wire_bits.push_back(!last);
        last = !last; run = 1;
      end
    end
  endtask

  task automatic send(input int extra_ones = 13);
    foreach (wire_bits[i]) begin rx = wire_bits[i]; repeat (BT) @(negedge clk); end
    rx = 1; repeat (extra_ones * BT) @(negedge clk);        // delimiters, EOF, intermission
  endtask

  // observe the node's transmission (sampled mid-bit), and error flags
  bit txq[$];
  int sof_seen, err_seen, flag_len;
  always @(posedge clk) begin
    if (sof === 1'b1) sof_seen++;
    if (err_frame === 1'b1) err_seen = 1;
    if (err_frame === 1'b1 && tx === 1'b0) flag_len++;
  end

  logic [7:0] data[$];
  bit rx_ok;

  task automatic clear();
    sof_seen = 0; err_seen = 0;
  endtask

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1;
    repeat (4 * BT) @(negedge clk);

    // standard data frame
    data = '{8'hA5, 8'h3C};
    encode(0, 29'h123, 0, 4'd2, data);
    clear();
    send();
    repeat (100 * BT) @(negedge clk);                         // past the node's re-transmission
    chk(!err_seen && sof_seen == 1, "compliant standard frame received without error");
    rx_ok = !err_seen && sof_seen == 1;
    chk(rx_ok || ec_rx == 1, "a frame the model rejects is counted as a receive error");

    if (rx_ok) begin
      chk(crc_ok && id_std == 11'h123 && !ide && !rtr && dlc == 2 && !fdf, "ID, IDE, RTR, DLC decoded, CRC good");
      // extended remote frame
      encode(1, 29'h1ABC_DEF, 1, 4'd4, data);
      clear(); send(); repeat (120 * BT) @(negedge clk);
      chk(sof_seen == 1 && crc_ok && ide && rtr && id_ext == 29'h1ABC_DEF && dlc == 4, "extended remote frame decoded");
      // CRC error
      encode(0, 29'h7FF, 0, 4'd1, '{8'h00}, 1);
      clear(); send(); repeat (40 * BT) @(negedge clk);
      chk(err_seen && sof_seen == 0, "CRC error answered with an error flag, no re-transmission");
      // stuffing that follows a stuff bit: 0x0F0 identifier, data 0x00
      encode(0, 29'h0F0, 0, 4'd1, '{8'h00});
      clear(); send(); repeat (120 * BT) @(negedge clk);
      chk(!err_seen && sof_seen == 1, "stuff bit counted as the first bit of the next run");
    end

    // stuff error: six dominant bits after SOF
    rst_n = 0; @(negedge clk); rst_n = 1;
    repeat (12 * BT) @(negedge clk);
    clear();
    begin
      int ec0;
      ec0 = ec_rx;
      flag_len = 0;
      rx = 0; repeat (7 * BT) @(negedge clk); rx = 1;
      repeat (8 * BT) @(negedge clk);
      chk(err_seen && ec_rx == ec0 + 1, "six equal bits: stuff error, error flag, error_count_rx++");
    end
    chk(flag_len == 6 * BT, $sformatf("error flag is 6 dominant bits (%0d clocks)", flag_len));
    repeat (12 * BT) @(negedge clk);
    chk(!err_frame, "error frame ends after the delimiter");

    // can_en low: bus activity ignored
    en = 0; clear();
    rx = 0; repeat (7 * BT) @(negedge clk); rx = 1;
    repeat (10 * BT) @(negedge clk);
    chk(!err_seen && u_dut.state == 0, "node disabled: bus activity ignored");
    en = 1;

    // reset
    rx = 0; repeat (8 * BT) @(negedge clk);
    rst_n = 0; @(negedge clk);
    chk(!err_frame && tx === 1'b1 && u_dut.state == 0, "reset: idle, recessive");
    rst_n = 1; rx = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #3000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
