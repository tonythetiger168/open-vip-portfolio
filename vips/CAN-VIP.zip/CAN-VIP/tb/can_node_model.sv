// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// can_node_model.sv -- functional CAN node DUT (pure RTL, no UVM).
// Receives a CAN 2.0/FD frame on can_rx (bit timing = 8 clks/bit,
// bit stuffing), verifies CRC-15, then echoes the frame on can_tx with
// a freshly computed CRC.  On stuff/CRC violation it transmits an
// active error flag (6 dominant bits) and raises error_frame.

`ifndef CAN_NODE_MODEL_SV
`define CAN_NODE_MODEL_SV

module can_node_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        can_rx,
  input  logic        can_en,
  output logic        can_tx,
  output logic        sof,
  output logic        crc_ok,
  output logic        overload_frame,
  output logic [10:0] id_std,
  output logic [28:0] id_ext,
  output logic        ide,
  output logic        rtr,
  output logic [3:0]  dlc,
  output logic [14:0] crc,
  output logic        crc_delim,
  output logic        ack_slot,
  output logic        ack_delim,
  output logic        fdf,
  output logic        brs,
  output logic        esi,
  output logic        tt_trigger,
  output logic [15:0] tt_cycle,
  output logic [7:0]  tt_slot,
  output logic        error_frame,
  output logic [2:0]  error_count_tx,
  output logic [2:0]  error_count_rx,
  output logic        bus_off
);
  localparam int BIT_CLKS  = 8;
  localparam int MAX_BITS  = 160;   // max destuffed frame bits handled

  typedef enum logic [2:0] {IDLE, RX_BITS, PARSE, TX_BITS, ERR_FLAG} state_e;
  state_e state;

  logic [MAX_BITS-1:0] shift;       // destuffed received bits (MSB-first fill)
  int   rcnt;                       // number of destuffed bits captured
  int   sclk;                       // sampling clock divider
  logic last_bit;
  int   run_len;
  int   rec_run;                    // consecutive recessive bits (EOF detect)

  // parsed fields
  logic [28:0] p_id;
  logic        p_ide, p_rtr, p_fdf, p_brs, p_esi;
  logic [3:0]  p_dlc;
  logic [63:0] p_data;
  logic [14:0] p_crc_rx, p_crc_calc;
  int          p_nbits;             // body bits (SOF..data) for CRC
  logic        p_valid;

  // tx serializer
  logic [MAX_BITS+32:0] tx_shift;
  int   tx_len, tx_idx, tx_clk;
  int   err_len;

  // CRC-15 over shift[0 .. n-1]
  function automatic logic [14:0] crc15(input int n);
    logic [14:0] c;
    logic        nxt;
    c = 15'h0;
    for (int i = 0; i < n; i++) begin
      nxt = shift[MAX_BITS-1-i] ^ c[14];
      c = {c[13:0], 1'b0};
      if (nxt) c = c ^ 15'h4599;
    end
    return c;
  endfunction

  // parse captured destuffed bits (shift[MAX_BITS-1] = SOF)
  task automatic parse_bits();
    int idx;
    int nb;
    idx = 0;
    p_id = '0; p_data = '0;
    // idx walks from SOF; bit i is shift[MAX_BITS-1-i]
    idx = 1;                                     // skip SOF
    for (int i = 28; i >= 18; i--) begin p_id[i] = shift[MAX_BITS-1-idx]; idx++; end
    if (shift[MAX_BITS-1-(idx+1)] == 1'b1) begin // IDE bit position +1
      // extended: SRR, IDE already peeked
      idx++;                                     // SRR
      idx++;                                     // IDE
      for (int i = 17; i >= 0; i--) begin p_id[i] = shift[MAX_BITS-1-idx]; idx++; end
      p_rtr = shift[MAX_BITS-1-idx]; idx++;
      idx++;                                     // r1
      p_ide = 1'b1;
    end else begin
      p_id = {18'b0, p_id[28:18]};
      p_rtr = shift[MAX_BITS-1-idx]; idx++;
      idx++;                                     // IDE
      p_ide = 1'b0;
    end
    p_fdf = shift[MAX_BITS-1-idx];
    if (p_fdf) begin
      idx++;                                     // EDL
      idx++;                                     // r0
      p_brs = shift[MAX_BITS-1-idx]; idx++;
      p_esi = shift[MAX_BITS-1-idx]; idx++;
    end else begin
      idx++;                                     // r0
      p_brs = 1'b0; p_esi = 1'b0;
    end
    p_dlc = {shift[MAX_BITS-1-idx], shift[MAX_BITS-1-(idx+1)],
             shift[MAX_BITS-1-(idx+2)], shift[MAX_BITS-1-(idx+3)]};
    idx += 4;
    nb = (p_dlc > 8) ? 8 : p_dlc;
    if (!p_rtr) begin
      for (int b = 0; b < nb; b++)
        for (int i = 7; i >= 0; i--) begin p_data[b*8+i] = shift[MAX_BITS-1-idx]; idx++; end
    end
    p_nbits = idx;                               // SOF .. end of data
    for (int i = 14; i >= 0; i--) begin p_crc_rx[i] = shift[MAX_BITS-1-idx]; idx++; end
    p_crc_calc = crc15(p_nbits);
  endtask

  // build stuffed tx bit stream from parsed fields (recomputed CRC)
  task automatic build_tx();
    logic [MAX_BITS+32:0] raw;
    int  n, m, run;
    logic lastb;
    logic nxt;
    logic [14:0] c;
    int nb;
    n = 0;
    raw[n] = 1'b0; n++;                          // SOF
    if (!p_ide) begin
      for (int i = 10; i >= 0; i--) begin raw[n] = p_id[i]; n++; end
      raw[n] = p_rtr; n++;
      raw[n] = 1'b0; n++;                        // IDE
    end else begin
      for (int i = 28; i >= 18; i--) begin raw[n] = p_id[i]; n++; end
      raw[n] = 1'b1; n++;                        // SRR
      raw[n] = 1'b1; n++;                        // IDE
      for (int i = 17; i >= 0; i--) begin raw[n] = p_id[i]; n++; end
      raw[n] = p_rtr; n++;
      raw[n] = 1'b0; n++;                        // r1
    end
    if (p_fdf) begin
      raw[n] = 1'b1; n++;                        // EDL
      raw[n] = 1'b0; n++;                        // r0
      raw[n] = p_brs; n++;
      raw[n] = p_esi; n++;
    end else begin
      raw[n] = 1'b0; n++;                        // r0
    end
    for (int i = 3; i >= 0; i--) begin raw[n] = p_dlc[i]; n++; end
    nb = (p_dlc > 8) ? 8 : p_dlc;
    if (!p_rtr) begin
      for (int b = 0; b < nb; b++)
        for (int i = 7; i >= 0; i--) begin raw[n] = p_data[b*8+i]; n++; end
    end
    // CRC over raw[0..n-1]
    c = 15'h0;
    for (int i = 0; i < n; i++) begin
      nxt = raw[i] ^ c[14];
      c = {c[13:0], 1'b0};
      if (nxt) c = c ^ 15'h4599;
    end
    crc <= c;
    for (int i = 14; i >= 0; i--) begin raw[n] = c[i]; n++; end
    // stuff
    tx_len = 0; run = 1; lastb = raw[0];
    for (int i = 0; i < n; i++) begin
      tx_shift[tx_len] = raw[i]; tx_len++;
      if (i == 0) begin lastb = raw[i]; run = 1; end
      else if (raw[i] == lastb) begin
        run++;
        if (run == 5) begin
          tx_shift[tx_len] = !lastb; tx_len++;
          run = 0;
        end
      end else begin lastb = raw[i]; run = 1; end
    end
    // CRC delim + ACK slot + ACK delim + EOF + IFS
    tx_shift[tx_len] = 1'b1; tx_len++;
    tx_shift[tx_len] = 1'b1; tx_len++;
    tx_shift[tx_len] = 1'b1; tx_len++;
    for (int i = 0; i < 10; i++) begin tx_shift[tx_len] = 1'b1; tx_len++; end
  endtask

  integer k;
  initial begin
    can_tx = 1'b1; sof = 0; crc_ok = 0; overload_frame = 0;
    id_std = '0; id_ext = '0; ide = 0; rtr = 0; dlc = '0; crc = '0;
    crc_delim = 0; ack_slot = 0; ack_delim = 0; fdf = 0; brs = 0; esi = 0;
    tt_trigger = 0; tt_cycle = '0; tt_slot = '0; error_frame = 0;
    error_count_tx = '0; error_count_rx = '0; bus_off = 0;
    state = IDLE; rcnt = 0; sclk = 0; last_bit = 1'b1; run_len = 1; rec_run = 0;
    tx_len = 0; tx_idx = 0; tx_clk = 0; err_len = 0;
  end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= IDLE; can_tx <= 1'b1; sof <= 0; error_frame <= 0;
      rcnt <= 0; sclk <= 0; last_bit <= 1'b1; run_len <= 1; rec_run <= 0;
      tx_idx <= 0; tx_clk <= 0; crc_ok <= 0;
    end else begin
      sof <= 0;
      case (state)
        // ------------------------------------------------ receiver
        IDLE: begin
          crc_delim <= 0; ack_slot <= 0; ack_delim <= 0;
          if (can_en && can_rx === 1'b0) begin   // SOF falling edge
            state <= RX_BITS;
            shift <= '0;
            shift[MAX_BITS-1] <= 1'b0;           // SOF captured
            rcnt <= 1;
            sclk <= BIT_CLKS/2;                  // align to bit center
            last_bit <= 1'b0; run_len <= 1; rec_run <= 0;
          end
        end
        RX_BITS: begin
          if (sclk > 0) begin
            sclk <= sclk - 1;
          end else begin
            sclk <= BIT_CLKS - 1;
            // destuff: after 5 equal bits, the next bit is a stuff bit
            if (run_len == 5) begin
              if (can_rx === last_bit) begin
                state <= ERR_FLAG;               // stuff violation
                err_len <= 6*BIT_CLKS;
                error_count_rx <= error_count_rx + 1;
              end
              run_len <= 1;                      // skip stuff bit
            end else begin
              shift[MAX_BITS-1-rcnt] <= can_rx;
              rcnt <= rcnt + 1;
              if (can_rx === last_bit) run_len <= run_len + 1;
              else begin last_bit <= can_rx; run_len <= 1; end
              // EOF: 7 recessive bits after CRC delimiter
              if (can_rx === 1'b1) rec_run <= rec_run + 1;
              else rec_run <= 0;
              if (rec_run >= 6) begin
                state <= PARSE;
              end
            end
          end
        end
        PARSE: begin
          parse_bits();
          crc_ok <= (p_crc_rx == p_crc_calc);
          if (p_crc_rx != p_crc_calc) begin
            state <= ERR_FLAG;
            err_len <= 6*BIT_CLKS;
            error_count_rx <= error_count_rx + 1;
          end else begin
            // echo metadata for SVA/monitors
            id_std <= p_ide ? id_std : p_id[10:0];
            id_ext <= p_ide ? p_id : id_ext;
            ide    <= p_ide;
            rtr    <= p_rtr;
            dlc    <= p_dlc;
            fdf    <= p_fdf;
            brs    <= p_brs;
            esi    <= p_esi;
            build_tx();
            state  <= TX_BITS;
            tx_idx <= 0; tx_clk <= 0;
            sof    <= 1'b1;
          end
        end
        // ------------------------------------------------ transmitter
        TX_BITS: begin
          if (tx_clk == 0) can_tx <= tx_shift[tx_idx];
          if (tx_clk == BIT_CLKS-1) begin
            tx_clk <= 0;
            if (tx_idx == tx_len-1) begin
              state <= IDLE;
              can_tx <= 1'b1;
            end else begin
              tx_idx <= tx_idx + 1;
            end
          end else begin
            tx_clk <= tx_clk + 1;
          end
          crc_delim <= (tx_idx > tx_len-13);
          ack_slot  <= (tx_idx == tx_len-12);
          ack_delim <= (tx_idx == tx_len-11);
        end
        // ------------------------------------------------ error flag
        ERR_FLAG: begin
          if (err_len > 0) begin
            can_tx <= 1'b0;                      // dominant error flag
            error_frame <= 1'b1;
            err_len <= err_len - 1;
            tx_clk <= 0;
          end else if (tx_clk < 8*BIT_CLKS) begin
            can_tx <= 1'b1;                      // error delimiter + resync
            tx_clk <= tx_clk + 1;
          end else begin
            error_frame <= 1'b0;
            state <= IDLE;
          end
        end
        default: state <= IDLE;
      endcase
    end
  end
endmodule
`endif
