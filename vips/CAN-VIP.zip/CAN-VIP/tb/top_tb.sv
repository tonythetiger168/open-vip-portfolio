// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- CAN testbench top with a functional CAN node DUT (closed loop)

`ifndef CAN_TB_SV
`define CAN_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import can_pkg::*;
import can_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  logic rst_n;
  can_if vif(clk, rst_n);

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  // Functional CAN node: receives VIP frames, CRC-checks, echoes on can_tx
  can_node_model dut (
    .clk           (vif.clk),
    .rst_n         (vif.rst_n),
    .can_rx        (vif.can_rx),
    .can_en        (vif.can_en),
    .can_tx        (vif.can_tx),
    .sof           (vif.sof),
    .crc_ok        (vif.crc_ok),
    .overload_frame(vif.overload_frame),
    .id_std        (vif.id_std),
    .id_ext        (vif.id_ext),
    .ide           (vif.ide),
    .rtr           (vif.rtr),
    .dlc           (vif.dlc),
    .crc           (vif.crc),
    .crc_delim     (vif.crc_delim),
    .ack_slot      (vif.ack_slot),
    .ack_delim     (vif.ack_delim),
    .fdf           (vif.fdf),
    .brs           (vif.brs),
    .esi           (vif.esi),
    .tt_trigger    (vif.tt_trigger),
    .tt_cycle      (vif.tt_cycle),
    .tt_slot       (vif.tt_slot),
    .error_frame   (vif.error_frame),
    .error_count_tx(vif.error_count_tx),
    .error_count_rx(vif.error_count_rx),
    .bus_off       (vif.bus_off)
  );

  // SVA tiered compliance checker (L1-L4)
  can_compliance_checker sva_chk (vif);

  // L1/L2/L3 SVA rule modules (companions of the class checkers)
  can_protocol_compliance_sva protocol_sva (vif);
  can_data_integrity_sva      di_sva       (vif);
  can_timing_performance_sva  timing_sva   (vif);
  can_error_handling_sva      error_sva    (vif);

  initial begin
    uvm_config_db#(virtual can_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule
`endif
