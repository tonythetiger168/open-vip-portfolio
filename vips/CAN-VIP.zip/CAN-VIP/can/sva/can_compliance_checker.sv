// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// CAN Tiered Compliance SVA Checker (module; instantiated from tb/top_tb.sv)
// Level: Complex | Total SVAs: 14 (L1-L3) + 5 L4 protocol-specific
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=CAN protocol
`ifndef CAN_COMPLIANCE_CHECKER_SV
`define CAN_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module can_compliance_checker (can_if vif);

  // ---------------- L1: signal sanity / basic compliance (4) ----------------
  property p_can_sof; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sof |-> vif.can_tx == 0; endproperty
  assert_p_can_sof: assert property(p_can_sof) else `uvm_warning("CAN_L1", "SOF dominant failed");
  cover_p_can_sof: cover property(p_can_sof);
  property p_can_id_std; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ide == 0 |-> vif.id_std <= 11'h7FF; endproperty
  assert_p_can_id_std: assert property(p_can_id_std) else `uvm_warning("CAN_L1", "Std ID 0-2047 failed");
  cover_p_can_id_std: cover property(p_can_id_std);
  property p_can_id_ext; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ide == 1 |-> vif.id_ext <= 29'h1FFFFFFF; endproperty
  assert_p_can_id_ext: assert property(p_can_id_ext) else `uvm_warning("CAN_L1", "Ext ID 0-536M failed");
  cover_p_can_id_ext: cover property(p_can_id_ext);
  property p_can_dlc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.dlc <= 4'd15; endproperty
  assert_p_can_dlc: assert property(p_can_dlc) else `uvm_warning("CAN_L1", "DLC range failed");
  cover_p_can_dlc: cover property(p_can_dlc);

  // ---------------- L2: full protocol (6) ----------------
  property p_can_crc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.crc_delim == 1 |-> vif.crc_ok; endproperty
  assert_p_can_crc: assert property(p_can_crc) else `uvm_warning("CAN_L2", "CRC valid failed");
  cover_p_can_crc: cover property(p_can_crc);
  property p_can_ack; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ack_slot == 0 |-> vif.ack_delim == 1 || vif.ack_slot == 1; endproperty
  assert_p_can_ack: assert property(p_can_ack) else `uvm_warning("CAN_L2", "ACK slot failed");
  cover_p_can_ack: cover property(p_can_ack);
  property p_can_fd_fdf; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fdf == 1 |-> vif.brs inside {0,1}; endproperty
  assert_p_can_fd_fdf: assert property(p_can_fd_fdf) else `uvm_warning("CAN_L2", "FDF valid failed");
  cover_p_can_fd_fdf: cover property(p_can_fd_fdf);
  property p_can_fd_esi; @(posedge vif.clk) disable iff (!vif.rst_n) vif.esi == 1 |-> vif.error_count_tx > 0 || vif.error_count_rx >= 0; endproperty
  assert_p_can_fd_esi: assert property(p_can_fd_esi) else `uvm_warning("CAN_L2", "ESI on error failed");
  cover_p_can_fd_esi: cover property(p_can_fd_esi);
  property p_can_bit_time; @(posedge vif.clk) disable iff (!vif.rst_n) $stable(vif.can_tx) |-> ##[1:64] $changed(vif.can_tx); endproperty
  assert_p_can_bit_time: assert property(p_can_bit_time) else `uvm_warning("CAN_L2", "Bit time failed");
  cover_p_can_bit_time: cover property(p_can_bit_time);
  property p_can_bus_off; @(posedge vif.clk) disable iff (!vif.rst_n) vif.error_count_tx >= 3'd7 |-> vif.bus_off == 1; endproperty
  assert_p_can_bus_off: assert property(p_can_bus_off) else `uvm_warning("CAN_L2", "Bus off failed");
  cover_p_can_bus_off: cover property(p_can_bus_off);

  // ---------------- L3: advanced features (4) ----------------
  property p_can_tt_trigger; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tt_trigger == 1 |-> vif.tt_slot <= 8'd255; endproperty
  assert_p_can_tt_trigger: assert property(p_can_tt_trigger) else `uvm_warning("CAN_L3", "TT trigger failed");
  cover_p_can_tt_trigger: cover property(p_can_tt_trigger);
  property p_can_error_frame; @(posedge vif.clk) disable iff (!vif.rst_n) vif.error_frame == 1 |-> vif.error_count_tx > 0 || vif.error_count_rx > 0; endproperty
  assert_p_can_error_frame: assert property(p_can_error_frame) else `uvm_warning("CAN_L3", "Error frame failed");
  cover_p_can_error_frame: cover property(p_can_error_frame);
  property p_can_bus_off_recovery; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bus_off == 1 |-> ##[128:256] vif.bus_off == 0; endproperty
  assert_p_can_bus_off_recovery: assert property(p_can_bus_off_recovery) else `uvm_warning("CAN_L3", "Recovery failed");
  cover_p_can_bus_off_recovery: cover property(p_can_bus_off_recovery);
  property p_can_overload; @(posedge vif.clk) disable iff (!vif.rst_n) vif.overload_frame == 1 |-> vif.error_count_tx < 3'd7; endproperty
  assert_p_can_overload: assert property(p_can_overload) else `uvm_warning("CAN_L3", "Overload frame failed");
  cover_p_can_overload: cover property(p_can_overload);

  // ---------------- L4: CAN protocol-specific rules (5) ----------------
  // L4-1: a node may only drive the bus dominant while its transmitter is enabled
  a_can_l4_drive_when_enabled : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.can_rx == 1'b0) |-> vif.can_en)
    else `uvm_error("SVA_L4", "can: dominant drive on can_rx while transmitter disabled")

  // L4-2: SOF is a single dominant bit after at least 3 recessive (IFS)
  a_can_l4_sof_after_ifs : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $fell(vif.can_tx) |-> ($past(vif.can_tx, 1) && $past(vif.can_tx, 2) && $past(vif.can_tx, 3)))
    else `uvm_error("SVA_L4", "can: SOF not preceded by interframe space")

  // L4-3: bit stuffing - 6 consecutive dominant bit-times (49 clks at 8 clks/bit)
  //        are only legal as an active error flag
  a_can_l4_bit_stuffing : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    (!vif.can_tx) [*49] |-> vif.error_frame)
    else `uvm_error("SVA_L4", "can: bit stuffing violation (6 dominant bits outside error flag)")

  // L4-4: error frame is an active flag: dominant then recessive delimiter
  a_can_l4_error_flag_recovery : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.error_frame) |-> s_eventually (vif.can_tx == 1'b1 && !vif.error_frame))
    else `uvm_error("SVA_L4", "can: error flag not terminated by recessive delimiter")

  // L4-5: CRC delimiter / ACK field bits are recessive on this node
  a_can_l4_crc_delim : assert property (@(posedge vif.clk) disable iff (!vif.rst_n)
    vif.crc_delim |-> (vif.can_tx == 1'b1))
    else `uvm_error("SVA_L4", "can: CRC delimiter not recessive")

  // ---------------- L4: protocol coverage ----------------
  c_can_l4_frame   : cover property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $fell(vif.can_tx) ##[1:200] $rose(vif.sof) ##[1:1500] (vif.can_tx == 1'b1));
  c_can_l4_errfrm  : cover property (@(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.error_frame) ##[1:200] $fell(vif.error_frame));

endmodule
`endif
