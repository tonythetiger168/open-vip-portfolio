// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// CAN checker
// UVM component handle + companion SVA module can_timing_performance_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef CAN_TIMING_CHECKER_SV
`define CAN_TIMING_CHECKER_SV
class can_timing_performance_checker extends uvm_component;
  `uvm_component_utils(can_timing_performance_checker)
  virtual can_if vif;
  function new(string name="can_timing_performance_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual can_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "can: vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module can_timing_performance_sva(can_if vif);
`include "uvm_macros.svh"
  property p_can_bit_time; @(posedge vif.clk) disable iff (!vif.rst_n) $stable(vif.can_tx) |-> ##[1:20] $changed(vif.can_tx); endproperty
  assert_p_can_bit_time: assert property(p_can_bit_time) else `uvm_warning("CAN", "Bit time stable failed");
  cover_p_can_bit_time: cover property(p_can_bit_time);
  property p_can_bus_off; @(posedge vif.clk) disable iff (!vif.rst_n) vif.error_count_tx >= 3'd7 |-> vif.bus_off == 1; endproperty
  assert_p_can_bus_off: assert property(p_can_bus_off) else `uvm_warning("CAN", "Bus off after 255 errors failed");
  cover_p_can_bus_off: cover property(p_can_bus_off);
  property p_can_tt_trigger; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tt_trigger == 1 |-> vif.tt_slot <= 8'd255; endproperty
  assert_p_can_tt_trigger: assert property(p_can_tt_trigger) else `uvm_warning("CAN", "TT trigger valid failed");
  cover_p_can_tt_trigger: cover property(p_can_tt_trigger);
endmodule
`endif
