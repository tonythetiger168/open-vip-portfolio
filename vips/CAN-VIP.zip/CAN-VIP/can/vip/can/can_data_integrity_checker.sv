// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// CAN checker
// UVM component handle + companion SVA module can_data_integrity_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef CAN_DATA_INTEGRITY_CHECKER_SV
`define CAN_DATA_INTEGRITY_CHECKER_SV
class can_data_integrity_checker extends uvm_component;
  `uvm_component_utils(can_data_integrity_checker)
  virtual can_if vif;
  function new(string name="can_data_integrity_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual can_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "can: vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module can_data_integrity_sva(can_if vif);
`include "uvm_macros.svh"
  property p_can_crc_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.crc != 15'h0000 |-> vif.crc_delim == 1; endproperty
  assert_p_can_crc_valid: assert property(p_can_crc_valid) else `uvm_warning("CAN", "CRC valid failed");
  cover_p_can_crc_valid: cover property(p_can_crc_valid);
  property p_can_ack; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ack_slot == 0 |-> vif.ack_delim == 1; endproperty
  assert_p_can_ack: assert property(p_can_ack) else `uvm_warning("CAN", "ACK slot failed");
  cover_p_can_ack: cover property(p_can_ack);
  property p_can_esi; @(posedge vif.clk) disable iff (!vif.rst_n) vif.esi == 1 |-> vif.error_count_tx > 0; endproperty
  assert_p_can_esi: assert property(p_can_esi) else `uvm_warning("CAN", "ESI on error failed");
  cover_p_can_esi: cover property(p_can_esi);
endmodule
`endif
