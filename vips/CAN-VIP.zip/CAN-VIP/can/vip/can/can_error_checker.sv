// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// CAN checker
// UVM component handle + companion SVA module can_error_handling_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef CAN_ERROR_CHECKER_SV
`define CAN_ERROR_CHECKER_SV
class can_error_handling_checker extends uvm_component;
  `uvm_component_utils(can_error_handling_checker)
  virtual can_if vif;
  function new(string name="can_error_handling_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual can_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "can: vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module can_error_handling_sva(can_if vif);
`include "uvm_macros.svh"
  property p_can_error_frame; @(posedge vif.clk) disable iff (!vif.rst_n) vif.error_frame == 1 |-> vif.error_count_tx > 0 || vif.error_count_rx > 0; endproperty
  assert_p_can_error_frame: assert property(p_can_error_frame) else `uvm_warning("CAN", "Error frame valid failed");
  cover_p_can_error_frame: cover property(p_can_error_frame);
  property p_can_bus_off_recovery; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bus_off == 1 |-> ##[128:256] vif.bus_off == 0; endproperty
  assert_p_can_bus_off_recovery: assert property(p_can_bus_off_recovery) else `uvm_warning("CAN", "Bus off recovery failed");
  cover_p_can_bus_off_recovery: cover property(p_can_bus_off_recovery);
  property p_can_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.can_en == 1 |-> !$isunknown(vif.can_tx); endproperty
  assert_p_can_no_x: assert property(p_can_no_x) else `uvm_warning("CAN", "No X when valid failed");
  cover_p_can_no_x: cover property(p_can_no_x);
endmodule
`endif
