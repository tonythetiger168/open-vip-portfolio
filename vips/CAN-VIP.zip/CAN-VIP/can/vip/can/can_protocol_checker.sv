// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// CAN checker
// UVM component handle + companion SVA module can_protocol_compliance_sva
// (concurrent assertions live in the module; LRM does not allow
//  property declarations inside classes).
`ifndef CAN_PROTOCOL_CHECKER_SV
`define CAN_PROTOCOL_CHECKER_SV
class can_protocol_compliance_checker extends uvm_component;
  `uvm_component_utils(can_protocol_compliance_checker)
  virtual can_if vif;
  function new(string name="can_protocol_compliance_checker", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase); super.build_phase(phase);
    if(!uvm_config_db#(virtual can_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "can: vif not found"); endfunction
endclass

// SVA rule module -- instantiated from tb/top_tb.sv
module can_protocol_compliance_sva(can_if vif);
`include "uvm_macros.svh"
  property p_can_sof; @(posedge vif.clk) disable iff (!vif.rst_n) vif.can_tx == 0 |-> vif.id_std <= 11'h7FF || vif.ide == 1; endproperty
  assert_p_can_sof: assert property(p_can_sof) else `uvm_warning("CAN", "SOF dominant failed");
  cover_p_can_sof: cover property(p_can_sof);
  property p_can_id_std; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ide == 0 |-> vif.id_std <= 11'h7FF; endproperty
  assert_p_can_id_std: assert property(p_can_id_std) else `uvm_warning("CAN", "Standard ID range failed");
  cover_p_can_id_std: cover property(p_can_id_std);
  property p_can_id_ext; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ide == 1 |-> vif.id_ext <= 29'h1FFFFFFF; endproperty
  assert_p_can_id_ext: assert property(p_can_id_ext) else `uvm_warning("CAN", "Extended ID range failed");
  cover_p_can_id_ext: cover property(p_can_id_ext);
  property p_can_dlc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.dlc <= 4'd8; endproperty
  assert_p_can_dlc: assert property(p_can_dlc) else `uvm_warning("CAN", "DLC 0-8 failed");
  cover_p_can_dlc: cover property(p_can_dlc);
  property p_can_fd_fdf; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fdf == 1 |-> vif.brs inside {0,1}; endproperty
  assert_p_can_fd_fdf: assert property(p_can_fd_fdf) else `uvm_warning("CAN", "FDF valid failed");
  cover_p_can_fd_fdf: cover property(p_can_fd_fdf);
  property p_can_crc_delim; @(posedge vif.clk) disable iff (!vif.rst_n) vif.crc_delim == 1; endproperty
  assert_p_can_crc_delim: assert property(p_can_crc_delim) else `uvm_warning("CAN", "CRC delimiter recessive failed");
  cover_p_can_crc_delim: cover property(p_can_crc_delim);
endmodule
`endif
