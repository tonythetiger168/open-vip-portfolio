# DMA UVM VIP (DMA-UVM-VIP)

UVM verification IP for the open-ip-portfolio **DMA** subsystem: System DMA: 4 channels of copy and fill jobs served round robin over AXI4.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`b1cfc02463bd`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 7) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What DMA does (from the spec)

- Per channel n: SRCn, DSTn, LENn (32-bit words), MODE.moden (0 COPY, 1 FILL with FILLn), CMD.startn queues the channel.
- Queued channels are served one job at a time in round-robin order (the first queued channel after the last one served).
- COPY: DST word i = SRC word i. FILL: DST word i = FILLn (no reads).
- CHECKSUM: 32-bit sum of the words written by the last job; STATUS.active_ch the channel being (last) served.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `dma/` -- `dma_ral.svh` register model (generated from the spec, same
  offsets as `DMA_apb`), `dma_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `dma_pins_if.sv`
- `rtl/` -- `DMA_apb.sv`, `DMA_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/dma.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | SRC0 | rw |
| 0x018 | DST0 | rw |
| 0x01C | LEN0 | rw |
| 0x020 | FILL0 | rw |
| 0x024 | SRC1 | rw |
| 0x028 | DST1 | rw |
| 0x02C | LEN1 | rw |
| 0x030 | FILL1 | rw |
| 0x034 | SRC2 | rw |
| 0x038 | DST2 | rw |
| 0x03C | LEN2 | rw |
| 0x040 | FILL2 | rw |
| 0x044 | SRC3 | rw |
| 0x048 | DST3 | rw |
| 0x04C | LEN3 | rw |
| 0x050 | FILL3 | rw |
| 0x054 | MODE | rw |
| 0x058 | CMD | cmd |
| 0x05C | STATUS | ro |
| 0x060 | CHECKSUM | ro |
| 0x064 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE0, 1 DONE1, 2 DONE2, 3 DONE3, 4 ERR.

## Tests

| Test | Seeds |
|---|---|
| `dma_ral_test` | 1 |
| `dma_copy_test` | 3 |
| `dma_fill_test` | 2 |
| `dma_rr_test` | 2 |
| `dma_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT DMA mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/dma.f
./obj_dir/Vtop_tb +UVM_TESTNAME=dma_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py DMA-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
