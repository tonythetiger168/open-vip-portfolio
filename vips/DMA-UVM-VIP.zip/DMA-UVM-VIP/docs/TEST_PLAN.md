# DMA-UVM-VIP test plan

## Register test (`dma_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `dma_copy_test`: 40 COPY jobs on random channels: lengths 0, 1, 15, 16, 17,
  255 and random up to 600 words, addresses that start just below a 4 KB
  boundary or at random, four back-pressure settings. Checks every DST word,
  no write outside DST and no read outside SRC (address windows), CHECKSUM,
  STATUS.err = 0, the channel's DONE bit and nothing else, AXI ID 7, the
  burst rules, and that the IP read exactly LEN words and wrote LEN words.
- `dma_fill_test`: 24 FILL jobs: DST = FILL word, no read burst at all,
  CHECKSUM = LEN * FILL.
- `dma_rr_test`: all four channels queued with one CMD write (mixed COPY /
  FILL): served in the order 0, 1, 2, 3 (round robin after reset); then
  channels 1 and 3 queued after 3 was served: order 1, 3; then a channel queued
  while another runs. Order is taken from the AXI writes. STATUS.pending /
  busy seen while queued.
- `dma_err_test`: COPY from a SLVERR region (DST gets 0 for those words),
  COPY into a DECERR region (those words untouched), FILL across a SLVERR
  region: DONE + ERR, STATUS.err = 1, data as predicted; the next clean job
  clears STATUS.err.
