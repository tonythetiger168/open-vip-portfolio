// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// security_compliance_checker.sv -- Crypto / Security Engine SVA checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = crypto-engine-specific rules

`ifndef SECURITY_COMPLIANCE_CHECKER_SV
`define SECURITY_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import security_defs_pkg::*;

module security_compliance_checker
(
  input logic clk,
  input logic rst_n,
  input security_state_e state,
  input logic [63:0] key,
  input logic key_valid,
  input logic start,
  input logic busy,
  input logic out_valid,
  input logic err,
  input logic key_loaded
);

  // ---------------- L1: signal sanity (4) ----------------
  a_security_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "security: clock unknown")
  a_security_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "security: reset unknown")
  a_security_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "security: state unknown")
  a_security_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, LOAD_KEY, ENCRYPT, DECRYPT, DONE, ERROR})
    else `uvm_error("SVA_L1", "security: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from IDLE
  a_security_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, LOAD_KEY, ENCRYPT, DECRYPT, ERROR})
    else `uvm_error("SVA_L2", "security: illegal transition from IDLE")

  // L2-2: legal FSM transition from LOAD_KEY
  a_security_trans_load_key : assert property (@(posedge clk) disable iff (!rst_n)
    state == LOAD_KEY |=> state inside {LOAD_KEY, IDLE})
    else `uvm_error("SVA_L2", "security: illegal transition from LOAD_KEY")

  // L2-3: legal FSM transition from ENCRYPT
  a_security_trans_encrypt : assert property (@(posedge clk) disable iff (!rst_n)
    state == ENCRYPT |=> state inside {ENCRYPT, DONE, ERROR})
    else `uvm_error("SVA_L2", "security: illegal transition from ENCRYPT")

  // L2-4: legal FSM transition from DECRYPT
  a_security_trans_decrypt : assert property (@(posedge clk) disable iff (!rst_n)
    state == DECRYPT |=> state inside {DECRYPT, DONE, ERROR})
    else `uvm_error("SVA_L2", "security: illegal transition from DECRYPT")

  // L2-5: legal FSM transition from DONE
  a_security_trans_done : assert property (@(posedge clk) disable iff (!rst_n)
    state == DONE |=> state inside {DONE, IDLE})
    else `uvm_error("SVA_L2", "security: illegal transition from DONE")

  // L2-6: legal FSM transition from ERROR
  a_security_trans_error : assert property (@(posedge clk) disable iff (!rst_n)
    state == ERROR |=> state inside {ERROR, IDLE})
    else `uvm_error("SVA_L2", "security: illegal transition from ERROR")

  // ---------------- L3: protocol rules (4) ----------------
  a_security_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "security: state not IDLE during reset")
  a_security_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == ERROR |-> ##[1:8] (state != ERROR))
    else `uvm_error("SVA_L3", "security: stuck in ERROR")
  a_security_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == LOAD_KEY);
  a_security_l3_back_idle  : cover property (@(posedge clk) disable iff (!rst_n)
    state == ERROR ##1 state == IDLE);

  // ---------------- L4: crypto-engine rules (5) ----------------
  // L4-1: an operation only completes (DONE) when a key was loaded first
  a_security_l4_done_needs_key : assert property (@(posedge clk) disable iff (!rst_n)
    state == DONE |-> key_loaded)
    else `uvm_error("SVA_L4", "security: operation completed without LOAD_KEY")

  // L4-2: out_valid is asserted only in DONE
  a_security_l4_valid_in_done : assert property (@(posedge clk) disable iff (!rst_n)
    out_valid |-> state == DONE)
    else `uvm_error("SVA_L4", "security: out_valid outside DONE")

  // L4-3: the key bus must not change while the engine is busy
  a_security_l4_key_stable : assert property (@(posedge clk) disable iff (!rst_n)
    busy |-> $stable(key))
    else `uvm_error("SVA_L4", "security: key changed while engine busy")

  // L4-4: err is only raised through the ERROR state
  a_security_l4_err_state : assert property (@(posedge clk) disable iff (!rst_n)
    $rose(err) |-> state == ERROR)
    else `uvm_error("SVA_L4", "security: err raised outside ERROR")

  // L4-5: ENCRYPT followed by DECRYPT (inverse-operation roundtrip)
  a_security_l4_roundtrip : cover property (@(posedge clk) disable iff (!rst_n)
    state == ENCRYPT ##[1:8] state == DONE ##[1:8]
    state == DECRYPT ##[1:8] state == DONE);

endmodule
`endif
