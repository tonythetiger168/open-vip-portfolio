// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// security_driver.svh -- Security engine host driver: LOAD_KEY handshake,
// block operation start, busy-wait, optional error injection (start without
// a loaded key, mode flip while busy).

`ifndef SECURITY_DRIVER_SVH
`define SECURITY_DRIVER_SVH

class security_driver extends uvm_driver #(security_transaction);
  `uvm_component_utils(security_driver)
  virtual security_if vif;
  security_config cfg;
  uvm_analysis_port #(security_transaction) drv_ap;  // expected items

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual security_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "security virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    security_transaction tr;
    vif.drv_cb.key_valid <= 0;
    vif.drv_cb.start     <= 0;
    vif.drv_cb.key_clear <= 0;
    vif.drv_cb.mode      <= 0;
    vif.drv_cb.key       <= '0;
    vif.drv_cb.data_in   <= '0;
    wait (vif.rst_n === 1'b1);
    wait (vif.drv_cb.state == security_defs_pkg::IDLE);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)

      if (tr.err_inject == SEC_ERR_NO_KEY) begin
        // zeroize the engine key, then start without LOAD_KEY
        vif.drv_cb.key_clear <= 1;
        @(vif.drv_cb);
        vif.drv_cb.key_clear <= 0;
      end else begin
        // ---- LOAD_KEY handshake (pulse key_valid for a single cycle so
        // the engine latches the key exactly once) ----
        vif.drv_cb.key       <= tr.key;
        vif.drv_cb.key_valid <= 1;
        @(vif.drv_cb);
        vif.drv_cb.key_valid <= 0;
        wait (vif.drv_cb.state == security_defs_pkg::LOAD_KEY);
        wait (vif.drv_cb.state == security_defs_pkg::IDLE);
      end

      // ---- start the block operation ----
      vif.drv_cb.mode    <= tr.enc_dec;
      vif.drv_cb.data_in <= tr.data;
      vif.drv_cb.start   <= 1;
      @(vif.drv_cb);
      vif.drv_cb.start   <= 0;

      if (tr.err_inject == SEC_ERR_MODE_FLIP) begin
        @(vif.drv_cb);                       // engine is busy now
        vif.drv_cb.mode <= ~tr.enc_dec;      // illegal: toggle mode mid-op
        @(vif.drv_cb);
        vif.drv_cb.mode <= tr.enc_dec;
      end

      // ---- wait for completion (DONE/out_valid or ERROR/err) ----
      fork
        begin wait (vif.drv_cb.out_valid === 1'b1); end
        begin wait (vif.drv_cb.err === 1'b1); end
        begin repeat (32) @(vif.drv_cb); end
      join_any
      disable fork;
      tr.result   = vif.drv_cb.data_out;
      tr.err_seen = (vif.drv_cb.err === 1'b1) ||
                    (vif.drv_cb.state == security_defs_pkg::ERROR);

      wait (vif.drv_cb.state == security_defs_pkg::IDLE);
      repeat (2) @(vif.drv_cb);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
