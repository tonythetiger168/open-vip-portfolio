// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// security_defs.sv -- Crypto / Security Engine shared type definitions
// Reversible AES-like cipher model shared by VIP, DUT and scoreboard.

package security_defs_pkg;
  typedef enum bit [2:0] {
    IDLE,
    LOAD_KEY,
    ENCRYPT,
    DECRYPT,
    DONE,
    ERROR
  } security_state_e;

  // mode encoding
  typedef enum bit {
    SEC_ENC = 1'b0,
    SEC_DEC = 1'b1
  } security_mode_e;

  // Error-injection classes
  typedef enum bit [1:0] {
    SEC_ERR_NONE,       // clean block operation
    SEC_ERR_NO_KEY,     // start requested before any LOAD_KEY
    SEC_ERR_MODE_FLIP   // mode toggled while the engine is busy
  } security_err_e;

  // Reversible AES-like round abstraction:
  //   encrypt: e = rol8(d) ^ k
  //   decrypt: d = ror8(e ^ k)        (exact inverse of encrypt)
  function automatic bit [63:0] cipher_enc(bit [63:0] d, bit [63:0] k);
    return {d[55:0], d[63:56]} ^ k;
  endfunction

  function automatic bit [63:0] cipher_dec(bit [63:0] e, bit [63:0] k);
    bit [63:0] x = e ^ k;
    return {x[7:0], x[63:8]};
  endfunction

  function automatic bit [63:0] cipher_apply(bit [63:0] d, bit [63:0] k,
                                             security_mode_e m);
    return (m == SEC_ENC) ? cipher_enc(d, k) : cipher_dec(d, k);
  endfunction
endpackage
