// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// security_coverage.svh -- Security engine functional coverage: block
// protocol (with crosses), engine FSM (sampled from the interface) and
// error injection.

`ifndef SECURITY_COVERAGE_SVH
`define SECURITY_COVERAGE_SVH

class security_coverage extends uvm_subscriber #(security_transaction);
  `uvm_component_utils(security_coverage)

  security_transaction tr;
  virtual security_if vif;

  covergroup cg_protocol;
    cp_mode : coverpoint tr.enc_dec { bins enc = {0}; bins dec = {1}; }
    cp_data : coverpoint tr.data {
      bins zero = {64'h0};
      bins ones = {{64{1'b1}}};
      bins alt_a = {64'hAAAA_AAAA_AAAA_AAAA};
      bins alt_5 = {64'h5555_5555_5555_5555};
      bins other = default;
    }
    cp_key  : coverpoint tr.key {
      bins zero = {64'h0};
      bins ones = {{64{1'b1}}};
      bins other = default;
    }
    cx_mode_data : cross cp_mode, cp_data;
    cx_mode_key  : cross cp_mode, cp_key;
  endgroup

  covergroup cg_fsm with function sample(security_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, LOAD_KEY, ENCRYPT, DECRYPT, DONE, ERROR};
    }
    cp_trans : coverpoint s {
      bins enc_seq  = (IDLE => LOAD_KEY => IDLE => ENCRYPT => DONE => IDLE);
      bins dec_seq  = (IDLE => LOAD_KEY => IDLE => DECRYPT => DONE => IDLE);
      bins err_seq  = (ENCRYPT => ERROR => IDLE);
      bins err_dec  = (DECRYPT => ERROR => IDLE);
      bins err_idle = (IDLE => ERROR => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.err_inject {
      bins clean     = {SEC_ERR_NONE};
      bins no_key    = {SEC_ERR_NO_KEY};
      bins mode_flip = {SEC_ERR_MODE_FLIP};
    }
    cp_seen : coverpoint tr.err_seen { bins ok = {0}; bins flagged = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual security_if)::get(this, "", "vif", vif));
  endfunction

  // Engine FSM coverage straight from the interface; sampled only on state
  // changes so multi-cycle holds do not break transition chains
  task run_phase(uvm_phase phase);
    security_state_e prev = security_defs_pkg::IDLE;
    if (vif == null) return;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n === 1'b1 && vif.mon_cb.state != prev)
        cg_fsm.sample(vif.mon_cb.state);
      prev = vif.mon_cb.state;
    end
  endtask

  function void write(security_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction
endclass
`endif
