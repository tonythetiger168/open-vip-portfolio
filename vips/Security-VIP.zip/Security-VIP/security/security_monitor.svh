// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// security_monitor.svh -- Security engine monitor: tracks LOAD_KEY updates,
// captures each block operation (mode/data/key), and reconstructs the
// transaction on out_valid (DONE) or err (ERROR).

`ifndef SECURITY_MONITOR_SVH
`define SECURITY_MONITOR_SVH

class security_monitor extends uvm_monitor;
  `uvm_component_utils(security_monitor)
  virtual security_if vif;
  uvm_analysis_port #(security_transaction) ap;
  int unsigned txn_count = 0;

  protected bit [63:0] cur_key;
  protected bit        op_active;
  protected bit        start_key_loaded;
  protected security_transaction tr;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual security_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "security virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    op_active = 0;
    cur_key = '0;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        op_active = 0;
        cur_key = '0;
        continue;
      end

      // key load updates the engine key
      if (vif.mon_cb.key_valid) cur_key = vif.mon_cb.key;

      // operation launch
      if (vif.mon_cb.start && !op_active) begin
        op_active = 1;
        start_key_loaded = vif.mon_cb.key_loaded;
        tr = security_transaction::type_id::create("tr");
        tr.enc_dec  = vif.mon_cb.mode;
        tr.data     = vif.mon_cb.data_in;
        tr.key      = cur_key;
        tr.load_key = start_key_loaded;
        tr.expected = security_defs_pkg::cipher_apply(
                        vif.mon_cb.data_in, cur_key,
                        security_defs_pkg::security_mode_e'(vif.mon_cb.mode));
      end

      // successful completion
      if (op_active && vif.mon_cb.out_valid) begin
        tr.result      = vif.mon_cb.data_out;
        tr.err_seen    = 0;
        tr.err_inject  = SEC_ERR_NONE;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
        op_active = 0;
      end
      // aborted operation
      else if (op_active &&
               (vif.mon_cb.err || vif.mon_cb.state == security_defs_pkg::ERROR)) begin
        tr.result      = vif.mon_cb.data_out;
        tr.err_seen    = 1;
        tr.err_inject  = start_key_loaded ? SEC_ERR_MODE_FLIP : SEC_ERR_NO_KEY;
        txn_count++;
        `uvm_info("MON", {"mon (aborted): ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
        op_active = 0;
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("security monitor observed %0d block operations",
              txn_count), UVM_LOW)
  endfunction
endclass
`endif
