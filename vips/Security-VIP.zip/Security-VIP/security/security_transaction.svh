// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// security_transaction.svh -- Security engine transaction: one block
// operation (LOAD_KEY -> ENCRYPT/DECRYPT -> DONE) with golden reference.

`ifndef SECURITY_TRANSACTION_SVH
`define SECURITY_TRANSACTION_SVH

class security_transaction extends uvm_sequence_item;

  rand bit           enc_dec;       // 0 = encrypt, 1 = decrypt
  rand bit [63:0]    key;
  rand bit [63:0]    data;
  rand security_err_e err_inject;   // error class for this operation
  rand bit           load_key;      // perform LOAD_KEY before the operation

  bit [63:0]         expected;      // golden cipher result (post_randomize)
  bit [63:0]         result;        // observed data_out (monitor / driver)
  bit                err_seen;      // engine asserted err / entered ERROR

  constraint c_err  { err_inject dist {SEC_ERR_NONE := 8,
                                       SEC_ERR_NO_KEY := 1,
                                       SEC_ERR_MODE_FLIP := 1}; }
  constraint c_load { err_inject == SEC_ERR_NO_KEY -> load_key == 0;
                      err_inject != SEC_ERR_NO_KEY -> load_key == 1; }

  `uvm_object_utils_begin(security_transaction)
    `uvm_field_int(enc_dec, UVM_ALL_ON)
    `uvm_field_int(key, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_enum(security_err_e, err_inject, UVM_ALL_ON)
    `uvm_field_int(load_key, UVM_ALL_ON)
    `uvm_field_int(expected, UVM_ALL_ON)
    `uvm_field_int(result, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(err_seen, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "security_transaction");
    super.new(name);
  endfunction

  function void post_randomize();
    expected = security_defs_pkg::cipher_apply(
                 data, key,
                 security_defs_pkg::security_mode_e'(enc_dec));
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    security_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    // Aborted operations produce no result: compare error class instead
    if (err_inject != SEC_ERR_NONE || t.err_inject != SEC_ERR_NONE)
      do_compare &= comparer.compare_field("err_inject", err_inject, t.err_inject, 2);
  endfunction

  function string convert2string();
    return $sformatf("SEC %s key=%016h data=%016h exp=%016h res=%016h err=%s",
                     enc_dec ? "DEC" : "ENC", key, data, expected, result,
                     err_inject.name());
  endfunction
endclass
`endif
