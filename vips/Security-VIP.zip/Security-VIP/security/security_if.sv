// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// security_if.sv -- Crypto / Security Engine interface
// Host-side stimulus (key/data/mode/start) and engine-side status
// (busy/out_valid/err/key_loaded) with the block-flow FSM state.

interface security_if (input logic clk);
  import security_defs_pkg::security_state_e;

  logic rst_n;

  // Host (driver) -> engine
  logic        key_valid;
  logic [63:0] key;
  logic [63:0] data_in;
  logic        mode;        // 0 = encrypt, 1 = decrypt
  logic        start;
  logic        key_clear;   // secure key zeroization (host knob)

  // Engine (DUT) -> host
  logic [63:0] data_out;
  logic        out_valid;
  logic        busy;
  logic        err;
  logic        key_loaded;

  security_state_e state;

  modport DRV (input  clk, rst_n, data_out, out_valid, busy, err,
                      key_loaded, state,
               output key_valid, key, data_in, mode, start);
  modport DUT (input  clk, rst_n, key_valid, key, data_in, mode, start,
               output data_out, out_valid, busy, err, key_loaded, state);
  modport MON (input  clk, rst_n, key_valid, key, data_in, mode, start,
                      data_out, out_valid, busy, err, key_loaded, state);

  clocking drv_cb @(posedge clk);
    input  rst_n, data_out, out_valid, busy, err, key_loaded, state;
    output key_valid, key, data_in, mode, start, key_clear;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, key_valid, key, data_in, mode, start,
          data_out, out_valid, busy, err, key_loaded, state;
  endclocking
endinterface
