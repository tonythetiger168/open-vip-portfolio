// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// security_pkg.sv -- Crypto / Security Engine UVM VIP package

package security_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import security_defs_pkg::*;
  export security_defs_pkg::*;

  `include "security_transaction.svh"
  `include "security_config.svh"
  `include "security_sequencer.svh"
  `include "security_driver.svh"
  `include "security_monitor.svh"
  `include "security_agent.svh"
  `include "security_sequences.svh"
  `include "security_checker.svh"
  `include "security_coverage.svh"
endpackage
