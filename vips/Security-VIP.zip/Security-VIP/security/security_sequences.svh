// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// security_sequences.svh -- Security engine sequence library

`ifndef SECURITY_SEQUENCES_SVH
`define SECURITY_SEQUENCES_SVH

class security_base_sequence extends uvm_sequence #(security_transaction);
  `uvm_object_utils(security_base_sequence)
  int num_txns = 20;
  function new(string name = "security_base_sequence"); super.new(name); endfunction
  task body();
    security_transaction tr;
    repeat (num_txns) begin
      tr = security_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: encrypt-only blocks
class security_encrypt_seq extends security_base_sequence;
  `uvm_object_utils(security_encrypt_seq)
  function new(string name = "security_encrypt_seq"); super.new(name); endfunction
  task body();
    security_transaction tr;
    repeat (num_txns) begin
      tr = security_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { enc_dec == 0; err_inject == SEC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: decrypt-only blocks
class security_decrypt_seq extends security_base_sequence;
  `uvm_object_utils(security_decrypt_seq)
  function new(string name = "security_decrypt_seq"); super.new(name); endfunction
  task body();
    security_transaction tr;
    repeat (num_txns) begin
      tr = security_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { enc_dec == 1; err_inject == SEC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: encrypt-then-decrypt roundtrip with the same key/data
// (dec input is the golden cipher output, so dec output == original data)
class security_roundtrip_seq extends security_base_sequence;
  `uvm_object_utils(security_roundtrip_seq)
  function new(string name = "security_roundtrip_seq"); super.new(name); endfunction
  task body();
    security_transaction enc, dec;
    repeat (num_txns) begin
      enc = security_transaction::type_id::create("enc");
      start_item(enc);
      void'(enc.randomize() with { enc_dec == 0; err_inject == SEC_ERR_NONE; });
      finish_item(enc);
      dec = security_transaction::type_id::create("dec");
      start_item(dec);
      void'(dec.randomize() with { enc_dec == 1; err_inject == SEC_ERR_NONE;
                                   key == enc.key; data == enc.expected; });
      finish_item(dec);
    end
  endtask
endclass

// Directed: data corner patterns (all-0 / all-1 / alternating)
class security_corner_seq extends security_base_sequence;
  `uvm_object_utils(security_corner_seq)
  function new(string name = "security_corner_seq"); super.new(name); endfunction
  task body();
    security_transaction tr;
    bit [63:0] corners[$] = '{64'h0, {64{1'b1}}, 64'hAAAA_AAAA_AAAA_AAAA,
                              64'h5555_5555_5555_5555};
    foreach (corners[i]) begin
      tr = security_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { data == corners[i];
                                  err_inject == SEC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back operations under the same key
class security_same_key_seq extends security_base_sequence;
  `uvm_object_utils(security_same_key_seq)
  function new(string name = "security_same_key_seq"); super.new(name); endfunction
  rand bit [63:0] fixed_key;
  task body();
    security_transaction tr;
    void'(this.randomize());
    repeat (num_txns) begin
      tr = security_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { key == fixed_key; err_inject == SEC_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: start encrypt without loading a key (after zeroization)
class security_no_key_seq extends security_base_sequence;
  `uvm_object_utils(security_no_key_seq)
  function new(string name = "security_no_key_seq"); super.new(name); endfunction
  task body();
    security_transaction tr;
    repeat (num_txns) begin
      tr = security_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { err_inject == SEC_ERR_NO_KEY; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: toggle mode while the engine is busy
class security_mode_flip_seq extends security_base_sequence;
  `uvm_object_utils(security_mode_flip_seq)
  function new(string name = "security_mode_flip_seq"); super.new(name); endfunction
  task body();
    security_transaction tr;
    repeat (num_txns) begin
      tr = security_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { err_inject == SEC_ERR_MODE_FLIP; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single clean encrypt right after reset release
class security_reset_seq extends security_base_sequence;
  `uvm_object_utils(security_reset_seq)
  function new(string name = "security_reset_seq"); super.new(name); endfunction
  task body();
    security_transaction tr = security_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { enc_dec == 0; err_inject == SEC_ERR_NONE; });
    finish_item(tr);
  endtask
endclass

class security_random_sequence extends security_base_sequence;
  `uvm_object_utils(security_random_sequence)
  function new(string name = "security_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class security_regression_sequence extends security_base_sequence;
  `uvm_object_utils(security_regression_sequence)
  function new(string name = "security_regression_sequence"); super.new(name); endfunction
  task body();
    security_encrypt_seq   enc  = security_encrypt_seq::type_id::create("enc");
    security_decrypt_seq   dec  = security_decrypt_seq::type_id::create("dec");
    security_roundtrip_seq rt   = security_roundtrip_seq::type_id::create("rt");
    security_corner_seq    cor  = security_corner_seq::type_id::create("cor");
    security_same_key_seq  sk   = security_same_key_seq::type_id::create("sk");
    security_no_key_seq    nke  = security_no_key_seq::type_id::create("nke");
    security_mode_flip_seq mfe  = security_mode_flip_seq::type_id::create("mfe");
    enc.num_txns = 15; dec.num_txns = 15; rt.num_txns = 10; sk.num_txns = 10;
    nke.num_txns = 2; mfe.num_txns = 2;
    enc.start(m_sequencer); dec.start(m_sequencer); rt.start(m_sequencer);
    cor.start(m_sequencer); sk.start(m_sequencer);
    nke.start(m_sequencer); mfe.start(m_sequencer);
  endtask
endclass
`endif
