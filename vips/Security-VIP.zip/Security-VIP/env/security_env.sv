// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// security_env.sv -- Security engine verification environment with
// end-to-end (and golden-reference) scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import security_defs_pkg::*;
  import security_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) block
  // operations against monitor-observed ones, and validates the observed
  // result against the golden cipher reference. Aborted operations are
  // checked by error class.
  class security_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(security_scoreboard)
    uvm_analysis_imp_exp #(security_transaction, security_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(security_transaction, security_scoreboard) obs_ap;

    security_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, mismatches = 0, error_hits = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(security_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(security_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        security_transaction e = exp_q.pop_front();
        security_transaction o = obs_q.pop_front();
        if (e.err_inject != SEC_ERR_NONE || o.err_inject != SEC_ERR_NONE) begin
          if (e.err_inject == o.err_inject && o.err_seen) error_hits++;
          else begin
            mismatches++;
            `uvm_error("SB", $sformatf("error-class mismatch exp{%s} obs{%s}",
                       e.convert2string(), o.convert2string()))
          end
        end
        else if (e.enc_dec == o.enc_dec && e.key == o.key && e.data == o.data &&
                 o.result == o.expected && o.expected == e.expected)
          n_matches++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("security scoreboard: n_matches=%0d error_hits=%0d mismatches=%0d",
                n_matches, error_hits, mismatches), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class security_env extends uvm_env;
    `uvm_component_utils(security_env)
    security_agent      agt;
    security_scoreboard sb;
    security_checker    chk;
    security_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = security_agent::type_id::create("agt", this);
      sb  = security_scoreboard::type_id::create("sb", this);
      chk = security_checker::type_id::create("chk", this);
      cov = security_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
