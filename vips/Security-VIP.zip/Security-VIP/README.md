# Security — Crypto / Security Engine UVM VIP

Open-source UVM verification IP template for **Crypto / Security Engine** (Security).

## Contents

| Path | Description |
|------|-------------|
| `security/security_if.sv` | Engine interface (key/data/mode/start + busy/out_valid/err) + modports/clocking |
| `security/security_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `security/sva/security_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=5) |
| `security/vip/security/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard (golden reference) |
| `tests/security_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional AES-like engine DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Block-flow host driver**: LOAD_KEY handshake, start pulse, busy-wait with
  out_valid/err completion detect; error injection for start-without-key
  (via secure zeroization knob) and mode-flip-while-busy
- **Reversible AES-like cipher model** (`security_defs_pkg`):
  `enc = rol8(d)^k`, `dec = ror8(e^k)` — exact inverses, shared by driver,
  monitor, DUT and scoreboard so encrypt/decrypt roundtrips are verifiable
- **Operation-tracking monitor**: follows LOAD_KEY updates, captures each
  block operation at start, reconstructs the transaction on out_valid
  (DONE) or err (ERROR) with error classification
- **End-to-end + golden-reference scoreboard**: driver expected vs monitor
  observed (mode/key/data), plus observed result checked against the golden
  cipher reference; aborted operations compared by error class
- **Functional DUT model**: crypto engine with IDLE/LOAD_KEY/ENCRYPT/DECRYPT/
  DONE/ERROR FSM, 2-cycle block latency, illegal-request detection
  (no key, mode flip) raising err through ERROR
- **Directed sequence library**: encrypt / decrypt / roundtrip (enc->dec
  chaining on golden values) / data corners / same-key stress / no-key /
  mode-flip / reset + random + regression mix
- **Functional coverage**: mode x data-corner and mode x key-corner crosses,
  engine FSM chains (enc/dec/error paths), error-class bins
- **SVA L4**: DONE requires a loaded key, out_valid only in DONE, key stable
  while busy, err only via ERROR, ENCRYPT->DECRYPT roundtrip cover
