// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- Security engine testbench top with a functional
// AES-like (reversible) crypto engine DUT model

`ifndef SECURITY_TB_SV
`define SECURITY_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import security_defs_pkg::*;
import security_pkg::*;
import security_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  security_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  security_engine_model dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual security_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional crypto engine: LOAD_KEY -> ENCRYPT/DECRYPT -> DONE block flow.
// Cipher model is reversible (rol8+XOR / XOR+ror8) so ENC and DEC are exact
// inverses and the scoreboard can verify roundtrips. Illegal requests
// (start without a loaded key, mode change while busy) raise err and enter
// ERROR for two cycles.
module security_engine_model (security_if vif);

  bit [63:0] key_reg, data_reg;
  bit        mode_reg;
  int        latency;
  int unsigned op_count = 0, err_count = 0;

  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      vif.state      <= IDLE;
      vif.data_out   <= '0;
      vif.out_valid  <= 1'b0;
      vif.busy       <= 1'b0;
      vif.err        <= 1'b0;
      vif.key_loaded <= 1'b0;
      key_reg        <= '0;
      latency        <= 0;
    end else begin
      unique case (vif.state)
        IDLE: begin
          vif.out_valid <= 1'b0;
          vif.err       <= 1'b0;
          if (vif.key_clear) begin
            vif.key_loaded <= 1'b0;             // secure zeroization
            key_reg        <= '0;
          end else if (vif.key_valid) begin
            key_reg        <= vif.key;
            vif.key_loaded <= 1'b1;
            vif.state      <= LOAD_KEY;
          end else if (vif.start) begin
            if (!vif.key_loaded) begin
              vif.state <= ERROR;               // encrypt with no key
              vif.err   <= 1'b1;
              err_count++;
              latency   <= 2;
            end else begin
              data_reg   <= vif.data_in;
              mode_reg   <= vif.mode;
              vif.busy   <= 1'b1;
              vif.state  <= vif.mode ? DECRYPT : ENCRYPT;
              latency    <= 2;
            end
          end
        end

        LOAD_KEY: begin
          vif.state <= IDLE;                    // key accepted
        end

        ENCRYPT, DECRYPT: begin
          if (vif.mode != mode_reg) begin
            vif.state <= ERROR;                 // mode flipped while busy
            vif.err   <= 1'b1;
            vif.busy  <= 1'b0;
            err_count++;
            latency   <= 2;
          end else if (latency > 1) begin
            latency <= latency - 1;
          end else begin
            vif.data_out <= cipher_apply(data_reg, key_reg,
                                         security_mode_e'(mode_reg));
            vif.busy     <= 1'b0;
            vif.state    <= DONE;
            op_count++;
          end
        end

        DONE: begin
          if (!vif.out_valid) begin
            vif.out_valid <= 1'b1;              // result valid in DONE
          end else begin
            vif.out_valid <= 1'b0;
            vif.state     <= IDLE;
          end
        end

        ERROR: begin
          if (latency > 1) begin
            latency <= latency - 1;
            vif.err <= 1'b1;
          end else begin
            vif.err   <= 1'b0;
            vif.state <= IDLE;
          end
        end

        default: vif.state <= IDLE;
      endcase
    end
  end
endmodule
`endif
