// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_security_tb.sv -- self-checking functional test for the security
// (block cipher) engine model (security_engine_model, flattened by
// smoke/flatten.py). Run: python3 tools/run_func_tests.py Security-VIP
//
// Model contract (from tb/top_tb.sv and security_defs_pkg):
//   key_valid loads a 64-bit key (key_loaded=1, IDLE->LOAD_KEY->IDLE);
//   key_clear zeroises it. start runs one 64-bit block: ENCRYPT
//   (rotl8(d) ^ k) for mode=0, DECRYPT (rotr8(e ^ k)) for mode=1; busy is high
//   while the block is processed and data_out is presented with a one-clock
//   out_valid. start without a key, or a mode change while busy, enters
//   ERROR with err high for 2 clocks; no output is produced.

module func_security_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [2:0] S_IDLE = 3'd0, S_LOAD = 3'd1, S_ENC = 3'd2, S_DEC = 3'd3, S_DONE = 3'd4, S_ERR = 3'd5;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, key_valid = 1'b0, mode = 1'b0, start = 1'b0, key_clear = 1'b0;
  logic [63:0] key = '0, din = '0;
  wire  [63:0] dout;
  wire         out_valid, busy, err, key_loaded;
  wire  [2:0]  state;

  always #5 clk = ~clk;

  security_engine_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_key_valid(key_valid), .vif_key(key),
    .vif_data_in(din), .vif_mode(mode), .vif_start(start), .vif_key_clear(key_clear),
    .vif_data_out(dout), .vif_out_valid(out_valid), .vif_busy(busy), .vif_err(err),
    .vif_key_loaded(key_loaded), .vif_state(state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic [63:0] enc(input [63:0] d, input [63:0] k); return {d[55:0], d[63:56]} ^ k; endfunction
  function automatic [63:0] dec(input [63:0] e, input [63:0] k);
    logic [63:0] x = e ^ k;
    return {x[7:0], x[63:8]};
  endfunction

  task automatic load_key(input [63:0] k);
    @(negedge clk); key_valid = 1'b1; key = k;
    @(negedge clk); key_valid = 1'b0;
    @(negedge clk);                       // LOAD_KEY -> IDLE
  endtask

  // run one block; flip=1 toggles mode while busy. Returns output (if any),
  // the clocks to out_valid, out_valid width, whether err was seen and
  // whether busy was observed during the operation.
  logic [63:0] q;
  int          lat, vwidth, errw;
  bit          saw_busy;
  task automatic block(input bit m, input [63:0] d, input bit flip = 0);
    @(negedge clk); start = 1'b1; mode = m; din = d;
    @(negedge clk); start = 1'b0; din = '1;
    lat = -1; vwidth = 0; errw = 0; saw_busy = 0; q = 'x;
    for (int k = 1; k <= 12; k++) begin
      if (flip && k == 1) mode = !m;
      if (busy) saw_busy = 1;
      if (err) errw++;
      if (out_valid) begin vwidth++; if (lat < 0) begin lat = k; q = dout; end end
      @(negedge clk);
    end
    mode = m;
  endtask

  localparam [63:0] K1 = 64'h0F1E_2D3C_4B5A_6978, K2 = 64'hA5A5_A5A5_5A5A_5A5A,
                    P1 = 64'h0011_2233_4455_6677;
  logic [63:0] ct;

  initial begin
    repeat (2) @(negedge clk);
    chk(state === S_IDLE && !key_loaded && !busy && !out_valid && !err && dout === '0, "outputs cleared in reset");
    rst_n = 1'b1;
    @(negedge clk);
    chk(state === S_IDLE && !key_loaded && !busy && !out_valid && !err, "idle, no key after reset");

    // start without a key
    block(0, P1);
    chk(errw == 2 && lat < 0, "start without a key: err for 2 clocks, no output");
    chk(state === S_IDLE, "engine returns to IDLE after the error");

    load_key(K1);
    chk(key_loaded === 1'b1, "key_valid loads the key");

    block(0, P1);
    chk(lat > 0 && q === enc(P1, K1), "encrypt matches the reference cipher");
    chk(vwidth == 1, "out_valid is a single-clock pulse");
    chk(saw_busy, "busy asserted while the block is processed");
    chk(lat == 4, "fixed block latency: out_valid 4 clocks after start");
    chk(!busy, "busy cleared once the block is done");
    ct = q;

    block(1, ct);
    chk(q === P1, "decrypt(encrypt(P)) round-trips to the plaintext");
    block(1, 64'hDEAD_BEEF_CAFE_F00D);
    chk(q === dec(64'hDEAD_BEEF_CAFE_F00D, K1), "decrypt matches the reference cipher");

    // key change takes effect
    load_key(K2);
    block(0, P1);
    chk(q === enc(P1, K2) && q !== ct, "new key changes the ciphertext");

    // mode flip while busy
    block(0, P1, 1);
    chk(errw == 2 && lat < 0 && !busy, "mode change while busy aborts with err for 2 clocks, no output");

    // key clear (zeroise)
    @(negedge clk); key_clear = 1'b1;
    @(negedge clk); key_clear = 1'b0;
    chk(key_loaded === 1'b0, "key_clear zeroises the key");
    block(0, P1);
    chk(errw == 2 && lat < 0, "start after key_clear is rejected");

    // reset drops the key
    load_key(K1);
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk); rst_n = 1'b1;
    chk(key_loaded === 1'b0 && state === S_IDLE, "reset clears the key and state");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
