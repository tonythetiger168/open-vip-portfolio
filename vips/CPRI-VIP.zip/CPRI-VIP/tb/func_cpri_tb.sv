// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_cpri_tb.sv -- self-checking functional test for the CPRI slave model
// (cpri_slave_dut, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py CPRI-VIP
//
// Model contract (from tb/top_tb.sv and cpri_defs_pkg):
//   K28.5 comma words (tx_k=1, tx_data=0xBCBCBCBC) advance a comma counter;
//   slv_state leaves RESET for L1_SYNC on the first comma and the slave
//   becomes synchronised after 4 commas, after which slv_state follows the
//   master's state. In LINK_ACTIVE, tx data/k are looped back on rx one clock
//   later; otherwise rx is 0. LOS returns the slave to RESET.

module func_cpri_tb;
`ifdef VIP_SMOKE_FLATTENED
  // cpri_state_e encoding (cpri_defs_pkg)
  localparam bit [2:0] S_RESET = 3'd0, S_L1_SYNC = 3'd1, S_PROTO = 3'd2, S_CMI = 3'd3,
                       S_PASSIVE = 3'd4, S_ACTIVE = 3'd5;
  localparam bit [31:0] K28_5 = 32'hBCBC_BCBC;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, tx_k = 1'b0, los = 1'b0;
  logic [31:0] tx_data = '0;
  logic [2:0]  state = S_RESET;
  wire  [31:0] rx_data;
  wire         rx_k;
  wire  [2:0]  slv_state;

  always #5 clk = ~clk;

  cpri_slave_dut u_dut (
    .vif_tx_clk(clk), .vif_rst_n(rst_n), .vif_tx_data(tx_data), .vif_tx_k(tx_k),
    .vif_rx_data(rx_data), .vif_rx_k(rx_k), .vif_los(los), .vif_state(state),
    .vif_slv_state(slv_state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic word(input [31:0] d, input bit k);
    @(negedge clk);
    tx_data = d; tx_k = k;
  endtask

  task automatic commas(input int n);
    repeat (n) word(K28_5, 1'b1);
  endtask

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1'b1;
    @(negedge clk);
    chk(slv_state === S_RESET, "slave in RESET before any comma");

    // non-comma K or data words do not start sync
    word(32'h1234_5678, 1'b0);
    word(32'hBCBC_BCBC, 1'b0);
    @(negedge clk);
    chk(slv_state === S_RESET, "K28.5 pattern without K flag does not count as comma");

    state = S_L1_SYNC;
    commas(1);
    word(32'h0, 1'b0);       // a data word in L1_SYNC clears the comma count
    @(negedge clk);
    chk(slv_state === S_L1_SYNC, "first comma moves slave to L1_SYNC");
    commas(4);
    word(32'h0, 1'b0);
    @(negedge clk);
    chk(u_dut.synced === 1'b1, "slave synchronised after 4 commas");

    // after sync the slave follows the master's state machine
    state = S_PROTO;   @(negedge clk); @(negedge clk);
    chk(slv_state === S_PROTO, "slave follows master into PROTOCOL_SETUP");
    state = S_PASSIVE; @(negedge clk); @(negedge clk);
    chk(slv_state === S_PASSIVE, "slave follows master into LINK_PASSIVE");
    word(32'hAAAA_5555, 1'b0);
    @(negedge clk); @(negedge clk);
    chk(rx_data === 32'h0 && rx_k === 1'b0, "no data loopback before LINK_ACTIVE");

    state = S_ACTIVE; @(negedge clk); @(negedge clk);
    chk(slv_state === S_ACTIVE, "slave reaches LINK_ACTIVE");
    word(32'hCAFE_F00D, 1'b0);
    @(negedge clk);
    chk(rx_data === 32'hCAFE_F00D && rx_k === 1'b0, "data word looped back in LINK_ACTIVE");
    word(K28_5, 1'b1);
    @(negedge clk);
    chk(rx_data === K28_5 && rx_k === 1'b1, "K character and K flag looped back");

    // loss of signal drops the link
    @(negedge clk); los = 1'b1;
    @(negedge clk);
    chk(slv_state === S_RESET && u_dut.synced === 1'b0, "LOS returns the slave to RESET, unsynced");
    @(negedge clk);
    chk(rx_data === 32'h0, "no loopback after LOS");
    los = 1'b0;

    // re-sync needs 4 fresh commas
    state = S_L1_SYNC;
    commas(2);
    word(32'h0, 1'b0);
    @(negedge clk);
    chk(u_dut.synced === 1'b0, "2 commas are not enough to re-sync");
    // a K flag on a non-comma word is not a comma; 3 commas after a data
    // word are still one short
    word(32'h0000_00F7, 1'b1);
    commas(3);
    word(32'h0, 1'b0);
    @(negedge clk);
    chk(u_dut.synced === 1'b0, "data word restarts the count: 3 commas after it are not enough");
    commas(4);
    word(32'h0, 1'b0);
    @(negedge clk);
    chk(u_dut.synced === 1'b1, "re-sync after 4 commas following LOS");

    // reset
    state = S_ACTIVE; @(negedge clk); @(negedge clk);
    word(K28_5, 1'b1);
    @(negedge clk);
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(slv_state === S_RESET && rx_data === 32'h0 && u_dut.synced === 1'b0, "reset clears state");
    chk(rx_k === 1'b0, "reset clears the looped-back K flag");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
