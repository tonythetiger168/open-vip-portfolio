// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- CPRI testbench top with a functional CPRI slave (RE) DUT model

`ifndef CPRI_TB_SV
`define CPRI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import cpri_defs_pkg::*;
import cpri_pkg::*;
import cpri_test_pkg::*;

module top_tb;
  logic tx_clk = 0;
  always #5ns tx_clk = ~tx_clk;

  cpri_if vif(tx_clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  cpri_slave_dut dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual cpri_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional CPRI slave port (RE): acquires sync by counting K28.5 commas
// on the master stream, follows the master's link state once synced, drops
// to RESET on LOS, and loops IQ words back onto rx_data/rx_k with one
// cycle of latency while its link is ACTIVE.
module cpri_slave_dut (cpri_if vif);
  import cpri_defs_pkg::*;

  bit          synced;
  int unsigned comma_cnt;

  always_ff @(posedge vif.tx_clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      synced          <= 1'b0;
      comma_cnt       <= 0;
      vif.slv_state   <= RESET;
      vif.rx_data     <= 32'h0;
      vif.rx_k        <= 1'b0;
    end else begin
      // LOS: immediate loss of sync, back to RESET
      if (vif.los) begin
        synced        <= 1'b0;
        comma_cnt     <= 0;
        vif.slv_state <= RESET;
      end else begin
        // Sync acquisition: 4 consecutive comma words
        if (vif.tx_k && vif.tx_data == CPRI_K28_5) begin
          if (comma_cnt < 15) comma_cnt <= comma_cnt + 1;
          if (comma_cnt >= 3) synced <= 1'b1;
        end else if (vif.state == L1_SYNC) begin
          comma_cnt <= 0;   // gap in the comma burst: restart acquisition
        end
        // Follow the master's link state once sync is acquired
        if (!synced)
          vif.slv_state <= (comma_cnt > 0) ? L1_SYNC : RESET;
        else
          vif.slv_state <= vif.state;
      end
      // IQ loopback while the slave link is ACTIVE
      if (vif.slv_state == LINK_ACTIVE) begin
        vif.rx_data <= vif.tx_data;
        vif.rx_k    <= vif.tx_k;
      end else begin
        vif.rx_data <= 32'h0;
        vif.rx_k    <= 1'b0;
      end
    end
  end
endmodule
`endif
