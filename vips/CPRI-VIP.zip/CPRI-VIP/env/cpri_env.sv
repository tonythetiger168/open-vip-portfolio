// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cpri_env.sv -- CPRI v8.0 (eCPRI over CPR) verification environment
// with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import cpri_defs_pkg::*;
  import cpri_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) IQ words
  // against monitor-decoded (observed) IQ words, including hyperframe
  // numbering tracked from K28.5 commas.
  class cpri_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(cpri_scoreboard)
    uvm_analysis_imp_exp #(cpri_transaction, cpri_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(cpri_transaction, cpri_scoreboard) obs_ap;

    cpri_transaction exp_q[$], obs_q[$];
    int unsigned match_cnt = 0, mismat_cnt = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(cpri_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(cpri_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        cpri_transaction e = exp_q.pop_front();
        cpri_transaction o = obs_q.pop_front();
        if (e.hyperframe == o.hyperframe && e.iq_data == o.iq_data &&
            e.k_char == o.k_char)
          match_cnt++;
        else begin
          mismat_cnt++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("cpri scoreboard: matches=%0d mismatches=%0d leftover_exp=%0d leftover_obs=%0d",
                match_cnt, mismat_cnt, exp_q.size(), obs_q.size()), UVM_LOW)
      if (mismat_cnt) `uvm_error("SB", "end-to-end mismatches detected")
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", "unmatched transactions left in scoreboard queues")
    endfunction
  endclass

  class cpri_env extends uvm_env;
    `uvm_component_utils(cpri_env)
    cpri_agent      agt;
    cpri_scoreboard sb;
    cpri_checker    chk;
    cpri_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = cpri_agent::type_id::create("agt", this);
      sb  = cpri_scoreboard::type_id::create("sb", this);
      chk = cpri_checker::type_id::create("chk", this);
      cov = cpri_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
