// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cpri_compliance_checker.sv -- CPRI SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = CPRI link-layer rules

`ifndef CPRI_COMPLIANCE_CHECKER_SV
`define CPRI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import cpri_defs_pkg::*;

module cpri_compliance_checker
(
  input logic        tx_clk,
  input logic        rst_n,
  input cpri_state_e state,
  input logic [31:0] tx_data,
  input logic        tx_k,
  input logic        los
);

  // ---------------- L1: signal sanity (4) ----------------
  a_cpri_l1_clk   : assert property (@(posedge tx_clk) disable iff (!rst_n) !$isunknown(tx_clk))
    else `uvm_error("SVA_L1", "cpri: clock unknown")
  a_cpri_l1_rst   : assert property (@(posedge tx_clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "cpri: reset unknown")
  a_cpri_l1_state : assert property (@(posedge tx_clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "cpri: state unknown")
  a_cpri_l1_valid : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state inside {RESET, L1_SYNC, PROTO_SETUP, CMI_SETUP, LINK_PASSIVE, LINK_ACTIVE})
    else `uvm_error("SVA_L1", "cpri: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from RESET
  a_cpri_trans_reset : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == RESET |=> state inside {RESET, L1_SYNC})
    else `uvm_error("SVA_L2", "cpri: illegal transition from RESET")

  // L2-2: legal FSM transition from L1_SYNC
  a_cpri_trans_l1_sync : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == L1_SYNC |=> state inside {L1_SYNC, PROTO_SETUP})
    else `uvm_error("SVA_L2", "cpri: illegal transition from L1_SYNC")

  // L2-3: legal FSM transition from PROTO_SETUP
  a_cpri_trans_proto_setup : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == PROTO_SETUP |=> state inside {PROTO_SETUP, CMI_SETUP})
    else `uvm_error("SVA_L2", "cpri: illegal transition from PROTO_SETUP")

  // L2-4: legal FSM transition from CMI_SETUP
  a_cpri_trans_cmi_setup : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == CMI_SETUP |=> state inside {CMI_SETUP, LINK_PASSIVE})
    else `uvm_error("SVA_L2", "cpri: illegal transition from CMI_SETUP")

  // L2-5: legal FSM transition from LINK_PASSIVE
  a_cpri_trans_link_passive : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == LINK_PASSIVE |=> state inside {LINK_PASSIVE, LINK_ACTIVE})
    else `uvm_error("SVA_L2", "cpri: illegal transition from LINK_PASSIVE")

  // L2-6: legal FSM transition from LINK_ACTIVE (LOS -> RESET, sync loss -> L1_SYNC)
  a_cpri_trans_link_active : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == LINK_ACTIVE |=> state inside {LINK_ACTIVE, RESET, L1_SYNC})
    else `uvm_error("SVA_L2", "cpri: illegal transition from LINK_ACTIVE")

  // ---------------- L3: protocol rules (4) ----------------
  a_cpri_l3_reset_idle : assert property (@(posedge tx_clk)
    $fell(rst_n) |-> ##[1:4] (state == RESET))
    else `uvm_error("SVA_L3", "cpri: state not RESET during reset")
  a_cpri_l3_startup    : assert property (@(posedge tx_clk) disable iff (!rst_n || los)
    state == RESET |-> ##[1:16] (state == L1_SYNC))
    else `uvm_error("SVA_L3", "cpri: link did not leave RESET towards L1_SYNC")
  a_cpri_l3_full_cycle : cover property (@(posedge tx_clk) disable iff (!rst_n)
    state == RESET ##[1:4] state == L1_SYNC ##[1:8] state == PROTO_SETUP
    ##[1:8] state == CMI_SETUP ##[1:8] state == LINK_PASSIVE ##[1:8] state == LINK_ACTIVE);
  a_cpri_l3_back_idle  : cover property (@(posedge tx_clk) disable iff (!rst_n)
    state == LINK_ACTIVE ##1 state == RESET);

  // ---------------- L4: CPRI link-layer rules (5) ----------------
  // L4-1: no IQ data before LINK_ACTIVE (only idle / control / K-char words)
  a_cpri_l4_no_iq_before_active : assert property (@(posedge tx_clk) disable iff (!rst_n)
    (state != LINK_ACTIVE && !tx_k) |->
    (tx_data inside {32'h0, CPRI_PROTO_WORD, CPRI_CMI_WORD}))
    else `uvm_error("SVA_L4", "cpri: IQ data transmitted before LINK_ACTIVE")

  // L4-2: hyperframe numbering increments -- exactly CPRI_HFR_WORDS IQ words
  // between consecutive K28.5 commas while in LINK_ACTIVE.
  int unsigned hfr_dcnt = 0;
  bit          hfr_started = 0;
  always @(posedge tx_clk) begin
    if (!rst_n || state != LINK_ACTIVE) begin
      hfr_dcnt    <= 0;
      hfr_started <= 0;
    end else begin
      if (tx_k && tx_data == CPRI_K28_5) begin
        if (hfr_started) begin
          a_cpri_l4_hfr_increment : assert (hfr_dcnt == CPRI_HFR_WORDS)
            else `uvm_error("SVA_L4", "cpri: hyperframe length violation (comma spacing)")
        end
        hfr_dcnt    <= 0;
        hfr_started <= 1;
      end else if (!tx_k) begin
        hfr_dcnt <= hfr_dcnt + 1;
      end
    end
  end

  // L4-3: K28.5 commas only during L1_SYNC or at hyperframe boundaries in LINK_ACTIVE
  a_cpri_l4_comma_region : assert property (@(posedge tx_clk) disable iff (!rst_n)
    (tx_k && tx_data == CPRI_K28_5) |-> (state inside {L1_SYNC, LINK_ACTIVE}))
    else `uvm_error("SVA_L4", "cpri: K28.5 comma outside sync/hyperframe boundary")

  // L4-4: any K-char word must be the K28.5 comma
  a_cpri_l4_kchar_is_comma : assert property (@(posedge tx_clk) disable iff (!rst_n)
    tx_k |-> (tx_data == CPRI_K28_5))
    else `uvm_error("SVA_L4", "cpri: K-char word is not K28.5")

  // L4-5: LOS forces the link back to RESET
  a_cpri_l4_los_reset : assert property (@(posedge tx_clk) disable iff (!rst_n)
    $rose(los) |-> ##[0:2] (state == RESET))
    else `uvm_error("SVA_L4", "cpri: LOS did not return link to RESET")

endmodule
`endif
