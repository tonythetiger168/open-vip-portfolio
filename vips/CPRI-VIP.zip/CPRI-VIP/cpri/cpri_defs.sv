// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cpri_defs.sv -- CPRI v8.0 (eCPRI over CPR) shared type definitions

package cpri_defs_pkg;
  // Link startup state machine: RESET -> L1_SYNC -> PROTO_SETUP ->
  // CMI_SETUP -> LINK_PASSIVE -> LINK_ACTIVE (LOS / resync -> RESET)
  typedef enum bit [2:0] {
    RESET,
    L1_SYNC,
    PROTO_SETUP,
    CMI_SETUP,
    LINK_PASSIVE,
    LINK_ACTIVE
  } cpri_state_e;

  // Line coding constants (simulation scale, 32-bit basic-frame words)
  localparam bit [31:0] CPRI_K28_5      = {4{8'hBC}};   // comma / sync K-char
  localparam bit [31:0] CPRI_PROTO_WORD = 32'h0001_0001; // protocol-negotiation control word
  localparam bit [31:0] CPRI_CMI_WORD   = 32'hCA11_CA11; // C&M channel control word
  localparam int unsigned CPRI_HFR_WORDS = 4;            // IQ words per hyperframe (sim scale)
endpackage
