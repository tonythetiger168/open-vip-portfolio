// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cpri_protocol_checker.sv -- CPRI v8.0 (eCPRI over CPR) protocol rule checker

`ifndef CPRI_PROTOCOL_CHECKER_SV
`define CPRI_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import cpri_defs_pkg::cpri_state_e;

module cpri_protocol_checker
(
  input logic tx_clk,
  input logic rst_n,
  input cpri_state_e state
);
  a_cpri_protocol_state_known : assert property (@(posedge tx_clk)
    disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("PROTOCOL", "cpri protocol: state unknown")
endmodule
`endif
