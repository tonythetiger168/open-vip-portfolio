// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cpri_driver.svh -- CPRI master (REC) driver.
// Runs the link startup state machine (RESET -> L1_SYNC -> PROTO_SETUP ->
// CMI_SETUP -> LINK_PASSIVE -> LINK_ACTIVE), sends K28.5 commas during
// L1_SYNC and at every hyperframe boundary, streams 32-bit IQ words, and
// handles LOS / resync error injection. Expected words are broadcast on
// drv_ap for the end-to-end scoreboard.

`ifndef CPRI_DRIVER_SVH
`define CPRI_DRIVER_SVH

class cpri_driver extends uvm_driver #(cpri_transaction);
  `uvm_component_utils(cpri_driver)
  virtual cpri_if vif;
  cpri_config cfg;
  uvm_analysis_port #(cpri_transaction) drv_ap;  // expected items for scoreboard

  protected bit [7:0] hfn;       // current hyperframe number
  protected int unsigned wpos;   // IQ word position within the hyperframe

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual cpri_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cpri virtual interface not set")
  endfunction

  // One K28.5 comma word
  task drive_comma();
    vif.drv_cb.tx_data <= cpri_defs_pkg::CPRI_K28_5;
    vif.drv_cb.tx_k    <= 1'b1;
    @(vif.drv_cb);
  endtask

  // One control word (protocol setup / C&M channel)
  task drive_ctrl(bit [31:0] w);
    vif.drv_cb.tx_data <= w;
    vif.drv_cb.tx_k    <= 1'b0;
    @(vif.drv_cb);
  endtask

  // Full link startup: RESET -> L1_SYNC -> PROTO_SETUP -> CMI_SETUP ->
  // LINK_PASSIVE -> LINK_ACTIVE. Hyperframe numbering restarts at 0.
  task link_startup();
    hfn  = 0;
    wpos = 0;
    vif.drv_cb.state <= cpri_defs_pkg::RESET;
    repeat (2) drive_ctrl(32'h0);
    vif.drv_cb.state <= cpri_defs_pkg::L1_SYNC;
    repeat (4) drive_comma();
    vif.drv_cb.state <= cpri_defs_pkg::PROTO_SETUP;
    repeat (2) drive_ctrl(cpri_defs_pkg::CPRI_PROTO_WORD);
    vif.drv_cb.state <= cpri_defs_pkg::CMI_SETUP;
    repeat (2) drive_ctrl(cpri_defs_pkg::CPRI_CMI_WORD);
    vif.drv_cb.state <= cpri_defs_pkg::LINK_PASSIVE;
    repeat (2) drive_ctrl(cpri_defs_pkg::CPRI_CMI_WORD);
    vif.drv_cb.state <= cpri_defs_pkg::LINK_ACTIVE;
  endtask

  // Error injection: raise LOS. The link drops to RESET and starts up again.
  task inject_los(int unsigned cycles);
    vif.drv_cb.state <= cpri_defs_pkg::RESET;   // master reacts to LOS
    vif.drv_cb.los   <= 1'b1;
    vif.drv_cb.tx_data <= 32'h0;
    vif.drv_cb.tx_k    <= 1'b0;
    repeat (cycles) @(vif.drv_cb);
    vif.drv_cb.los   <= 1'b0;
    link_startup();
  endtask

  // Error injection: sync loss -- master falls back to L1_SYNC, re-sends the
  // K28.5 comma burst and re-negotiates before returning to LINK_ACTIVE.
  task resync_link();
    hfn  = 0;
    wpos = 0;
    vif.drv_cb.state <= cpri_defs_pkg::L1_SYNC;
    repeat (4) drive_comma();
    vif.drv_cb.state <= cpri_defs_pkg::PROTO_SETUP;
    repeat (2) drive_ctrl(cpri_defs_pkg::CPRI_PROTO_WORD);
    vif.drv_cb.state <= cpri_defs_pkg::CMI_SETUP;
    repeat (2) drive_ctrl(cpri_defs_pkg::CPRI_CMI_WORD);
    vif.drv_cb.state <= cpri_defs_pkg::LINK_PASSIVE;
    repeat (2) drive_ctrl(cpri_defs_pkg::CPRI_CMI_WORD);
    vif.drv_cb.state <= cpri_defs_pkg::LINK_ACTIVE;
  endtask

  task run_phase(uvm_phase phase);
    cpri_transaction tr;
    // Drive deterministic values during reset so SVA never samples X.
    vif.drv_cb.tx_data <= 32'h0;
    vif.drv_cb.tx_k    <= 1'b0;
    vif.drv_cb.los     <= 1'b0;
    vif.drv_cb.state   <= cpri_defs_pkg::RESET;
    wait (vif.rst_n === 1'b1);
    link_startup();
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      if (tr.inject_los)      inject_los(tr.los_cycles);
      else if (tr.resync)     resync_link();
      // Hyperframe boundary: emit the periodic K28.5 comma first
      if (wpos == 0) drive_comma();
      tr.hyperframe = hfn;
      tr.k_char     = 1'b0;
      vif.drv_cb.tx_data <= tr.iq_data;
      vif.drv_cb.tx_k    <= 1'b0;
      @(vif.drv_cb);
      wpos++;
      if (wpos == cpri_defs_pkg::CPRI_HFR_WORDS) begin
        wpos = 0;
        hfn++;                       // hyperframe number increments (mod 256)
      end
      drv_ap.write(tr);              // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
