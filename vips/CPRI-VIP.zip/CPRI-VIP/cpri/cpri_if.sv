// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cpri_if.sv -- CPRI v8.0 (eCPRI over CPR) interface
// 32-bit basic-frame words; tx_k marks K-chars (K28.5 comma).
// tx_* is the master (REC) direction driven by the VIP driver;
// rx_* is the slave (RE) loopback direction driven by the DUT.

interface cpri_if (input logic tx_clk);
  import cpri_defs_pkg::cpri_state_e;

  logic        rst_n;
  logic [31:0] tx_data;
  logic        tx_k;
  logic [31:0] rx_data;
  logic        rx_k;
  logic        los;          // loss-of-signal indication towards the master

  cpri_state_e state;        // master link state (driven by VIP driver)
  cpri_state_e slv_state;    // slave link state (driven by DUT)

  modport DUT (input  tx_clk, rst_n, tx_data, tx_k, los,
               output rx_data, rx_k, slv_state);
  modport TB  (input  tx_clk, rx_data, rx_k, slv_state,
               output rst_n, tx_data, tx_k, los, state);
  modport MON (input  tx_clk, rst_n, tx_data, tx_k, rx_data, rx_k, los,
                      state, slv_state);

  clocking drv_cb @(posedge tx_clk);
    output tx_data, tx_k, los, state;
    input  rst_n, rx_data, rx_k;
  endclocking

  clocking mon_cb @(posedge tx_clk);
    input rst_n, tx_data, tx_k, rx_data, rx_k, los, state, slv_state;
  endclocking
endinterface
