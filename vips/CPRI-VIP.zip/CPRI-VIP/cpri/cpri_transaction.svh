// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cpri_transaction.svh -- CPRI transaction: one 32-bit IQ basic-frame word
// carrying its hyperframe number, plus link-level error-injection knobs.

`ifndef CPRI_TRANSACTION_SVH
`define CPRI_TRANSACTION_SVH

class cpri_transaction extends uvm_sequence_item;

  rand bit [31:0] iq_data;        // one 32-bit IQ data word
  rand bit        inject_los;     // error injection: raise LOS, link restarts
  rand int unsigned los_cycles;   // LOS hold time in tx_clk cycles
  rand bit        resync;         // error injection: drop to L1_SYNC and re-acquire

  bit [7:0]  hyperframe;          // hyperframe number tracked from K28.5 commas
  bit        k_char;              // observed word was a K-char (monitor)
  bit        link_restart;        // monitor: first word after a link (re)start

  constraint c_iq    { iq_data dist {32'h0 := 1, 32'hFFFF_FFFF := 1, [32'h1:32'hFFFF_FFFE] := 6}; }
  constraint c_los   { inject_los dist {0 := 9, 1 := 1};
                       los_cycles inside {[2:8]}; }
  constraint c_rsync { resync dist {0 := 9, 1 := 1};
                       solve inject_los before resync;
                       (inject_los == 1) -> (resync == 0); }

  `uvm_object_utils_begin(cpri_transaction)
    `uvm_field_int(iq_data, UVM_ALL_ON)
    `uvm_field_int(hyperframe, UVM_ALL_ON)
    `uvm_field_int(k_char, UVM_ALL_ON)
    `uvm_field_int(inject_los, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(resync, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(link_restart, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "cpri_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    cpri_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= comparer.compare_field("hyperframe", hyperframe, t.hyperframe, 8);
    do_compare &= comparer.compare_field("iq_data",    iq_data,    t.iq_data,    32);
    do_compare &= comparer.compare_field("k_char",     k_char,     t.k_char,     1);
  endfunction

  function string convert2string();
    return $sformatf("CPRI hfn=%0d k=%0b iq=0x%08h los=%0b rsync=%0b",
                     hyperframe, k_char, iq_data, inject_los, resync);
  endfunction
endclass
`endif
