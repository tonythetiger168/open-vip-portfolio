// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cpri_sequences.svh -- CPRI sequence library

`ifndef CPRI_SEQUENCES_SVH
`define CPRI_SEQUENCES_SVH

class cpri_base_sequence extends uvm_sequence #(cpri_transaction);
  `uvm_object_utils(cpri_base_sequence)
  int num_txns = 20;
  function new(string name = "cpri_base_sequence"); super.new(name); endfunction
  task body();
    cpri_transaction tr;
    repeat (num_txns) begin
      tr = cpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: clean link startup + short IQ stream (no error injection)
class cpri_link_startup_seq extends cpri_base_sequence;
  `uvm_object_utils(cpri_link_startup_seq)
  function new(string name = "cpri_link_startup_seq"); super.new(name); num_txns = 8; endfunction
  task body();
    cpri_transaction tr;
    repeat (num_txns) begin
      tr = cpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inject_los == 0; resync == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: sustained IQ data streaming (no errors)
class cpri_iq_data_seq extends cpri_base_sequence;
  `uvm_object_utils(cpri_iq_data_seq)
  function new(string name = "cpri_iq_data_seq"); super.new(name); num_txns = 40; endfunction
  task body();
    cpri_transaction tr;
    repeat (num_txns) begin
      tr = cpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inject_los == 0; resync == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: walk several hyperframe boundaries (K28.5 comma insertion)
class cpri_hyperframe_seq extends cpri_base_sequence;
  `uvm_object_utils(cpri_hyperframe_seq)
  function new(string name = "cpri_hyperframe_seq"); super.new(name); endfunction
  task body();
    cpri_transaction tr;
    num_txns = 3 * cpri_defs_pkg::CPRI_HFR_WORDS;
    repeat (num_txns) begin
      tr = cpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inject_los == 0; resync == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: corner IQ patterns (all-zeros / all-ones)
class cpri_iq_corner_seq extends cpri_base_sequence;
  `uvm_object_utils(cpri_iq_corner_seq)
  function new(string name = "cpri_iq_corner_seq"); super.new(name); endfunction
  task body();
    cpri_transaction tr;
    bit [31:0] corners[$] = '{32'h0000_0000, 32'hFFFF_FFFF, 32'hAAAA_AAAA, 32'h5555_5555};
    foreach (corners[i]) begin
      tr = cpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { iq_data == corners[i]; inject_los == 0; resync == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: LOS assertion -- link must drop to RESET and start up again
class cpri_los_inject_seq extends cpri_base_sequence;
  `uvm_object_utils(cpri_los_inject_seq)
  function new(string name = "cpri_los_inject_seq"); super.new(name); num_txns = 3; endfunction
  task body();
    cpri_transaction tr;
    repeat (num_txns) begin
      tr = cpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inject_los == 1; resync == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: sync loss -- master re-acquires via a fresh K28.5 comma burst
class cpri_resync_seq extends cpri_base_sequence;
  `uvm_object_utils(cpri_resync_seq)
  function new(string name = "cpri_resync_seq"); super.new(name); num_txns = 3; endfunction
  task body();
    cpri_transaction tr;
    repeat (num_txns) begin
      tr = cpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inject_los == 0; resync == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: weighted mix of LOS and sync-loss events with IQ traffic
class cpri_error_inject_seq extends cpri_base_sequence;
  `uvm_object_utils(cpri_error_inject_seq)
  function new(string name = "cpri_error_inject_seq"); super.new(name); num_txns = 12; endfunction
  task body();
    cpri_transaction tr;
    repeat (num_txns) begin
      tr = cpri_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inject_los dist {0 := 1, 1 := 1};
                                  resync     dist {0 := 1, 1 := 1}; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single transfer right after reset release / link startup
class cpri_reset_seq extends cpri_base_sequence;
  `uvm_object_utils(cpri_reset_seq)
  function new(string name = "cpri_reset_seq"); super.new(name); endfunction
  task body();
    cpri_transaction tr = cpri_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { inject_los == 0; resync == 0; });
    finish_item(tr);
  endtask
endclass

class cpri_random_sequence extends cpri_base_sequence;
  `uvm_object_utils(cpri_random_sequence)
  function new(string name = "cpri_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class cpri_regression_sequence extends cpri_base_sequence;
  `uvm_object_utils(cpri_regression_sequence)
  function new(string name = "cpri_regression_sequence"); super.new(name); endfunction
  task body();
    cpri_link_startup_seq su   = cpri_link_startup_seq::type_id::create("su");
    cpri_iq_data_seq      iq   = cpri_iq_data_seq::type_id::create("iq");
    cpri_hyperframe_seq   hfr  = cpri_hyperframe_seq::type_id::create("hfr");
    cpri_iq_corner_seq    cor  = cpri_iq_corner_seq::type_id::create("cor");
    cpri_los_inject_seq   los  = cpri_los_inject_seq::type_id::create("los");
    cpri_resync_seq       rsy  = cpri_resync_seq::type_id::create("rsy");
    cpri_error_inject_seq err  = cpri_error_inject_seq::type_id::create("err");
    su.start(m_sequencer);
    iq.start(m_sequencer);
    hfr.start(m_sequencer);
    cor.start(m_sequencer);
    los.start(m_sequencer);
    rsy.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
