// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cpri_checker.svh -- CPRI transaction checker: verifies hyperframe
// continuity of the decoded IQ word stream (restart on link recovery is
// legal and counted separately).

`ifndef CPRI_CHECKER_SVH
`define CPRI_CHECKER_SVH

class cpri_checker extends uvm_component;
  `uvm_component_utils(cpri_checker)
  uvm_analysis_imp #(cpri_transaction, cpri_checker) chk_ap;
  int unsigned checked = 0, errors = 0, restarts = 0;
  bit        have_prev = 0;
  bit [7:0]  prev_hfn  = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    chk_ap = new("chk_ap", this);
  endfunction

  function void write(cpri_transaction tr);
    checked++;
    if (tr.link_restart) begin
      restarts++;
      have_prev = 0;
      return;
    end
    if (have_prev) begin
      bit [7:0] diff = tr.hyperframe - prev_hfn;  // 8-bit: 255->0 wrap gives +1
      if (diff > 1) begin
        errors++;
        `uvm_error("CHK", $sformatf("hyperframe jump %0d -> %0d (diff %0d)",
                   prev_hfn, tr.hyperframe, diff))
      end
    end
    prev_hfn  = tr.hyperframe;
    have_prev = 1;
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHECKER", $sformatf("cpri: checked=%0d errors=%0d restarts=%0d",
              checked, errors, restarts), UVM_LOW)
  endfunction
endclass
`endif
