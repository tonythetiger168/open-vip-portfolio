// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cpri_coverage.svh -- CPRI functional coverage.
// cg_protocol samples decoded IQ words (hyperframe x data corners cross),
// cg_fsm / cg_error sample the link FSM and LOS events directly from the
// interface every clock.

`ifndef CPRI_COVERAGE_SVH
`define CPRI_COVERAGE_SVH

class cpri_coverage extends uvm_subscriber #(cpri_transaction);
  `uvm_component_utils(cpri_coverage)

  virtual cpri_if vif;
  cpri_transaction tr;

  covergroup cg_protocol;
    cp_hfn : coverpoint tr.hyperframe {
      bins zero = {0};
      bins low  = {[1:7]};
      bins high = {[8:254]};
      bins wrap = {255};
    }
    cp_iq  : coverpoint tr.iq_data {
      bins zero = {32'h0000_0000};
      bins ones = {32'hFFFF_FFFF};
      bins low  = {[32'h0000_0001 : 32'h0000_FFFF]};
      bins high = {[32'h0001_0000 : 32'hFFFF_FFFE]};
    }
    cp_k   : coverpoint tr.k_char { bins data = {0}; }
    cx_hfn_iq : cross cp_hfn, cp_iq;
  endgroup

  covergroup cg_fsm with function sample(cpri_state_e s);
    cp_state : coverpoint s {
      bins states[] = {RESET, L1_SYNC, PROTO_SETUP, CMI_SETUP, LINK_PASSIVE, LINK_ACTIVE};
    }
    cp_trans : coverpoint s {
      bins startup = (RESET => L1_SYNC => PROTO_SETUP => CMI_SETUP =>
                      LINK_PASSIVE => LINK_ACTIVE);
      bins los_rst = (LINK_ACTIVE => RESET);
      bins resync  = (LINK_ACTIVE => L1_SYNC);
    }
  endgroup

  covergroup cg_error with function sample(bit los, cpri_state_e s);
    cp_los   : coverpoint los { bins ok = {0}; bins los = {1}; }
    cp_state : coverpoint s {
      bins states[] = {RESET, L1_SYNC, PROTO_SETUP, CMI_SETUP, LINK_PASSIVE, LINK_ACTIVE};
    }
    cx_los_state : cross cp_los, cp_state {
      // LOS is only ever raised while streaming or idling pre-startup;
      // ignore cross bins that cannot legally occur.
      illegal_bins los_in_setup = binsof(cp_los.los) &&
                                  (binsof(cp_state.states) intersect {PROTO_SETUP, CMI_SETUP, LINK_PASSIVE});
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual cpri_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cpri virtual interface not set")
  endfunction

  function void write(cpri_transaction t);
    tr = t;
    cg_protocol.sample();
  endfunction

  task run_phase(uvm_phase phase);
    cpri_state_e prev;
    prev = cpri_state_e'('x);
    forever begin
      @(posedge vif.tx_clk);
      if (vif.rst_n === 1'b1) begin
        // sample FSM on state change so chained transition bins can hit
        if (vif.state !== prev) begin
          cg_fsm.sample(vif.state);
          prev = vif.state;
        end
        cg_error.sample(vif.los, vif.state);
      end
    end
  endtask
endclass
`endif
