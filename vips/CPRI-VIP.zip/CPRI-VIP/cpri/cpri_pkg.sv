// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cpri_pkg.sv -- CPRI v8.0 (eCPRI over CPR) UVM VIP package

package cpri_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import cpri_defs_pkg::*;
  export cpri_defs_pkg::*;

  `include "cpri_transaction.svh"
  `include "cpri_config.svh"
  `include "cpri_sequencer.svh"
  `include "cpri_driver.svh"
  `include "cpri_monitor.svh"
  `include "cpri_agent.svh"
  `include "cpri_sequences.svh"
  `include "cpri_checker.svh"
  `include "cpri_coverage.svh"
endpackage
