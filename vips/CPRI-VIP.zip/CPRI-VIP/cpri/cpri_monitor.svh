// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cpri_monitor.svh -- CPRI monitor: decodes the master's 32-bit word stream.
// Tracks K28.5 commas to maintain hyperframe numbering (one comma per
// hyperframe boundary) and publishes one transaction per IQ data word
// observed while the link is in LINK_ACTIVE.

`ifndef CPRI_MONITOR_SVH
`define CPRI_MONITOR_SVH

class cpri_monitor extends uvm_monitor;
  `uvm_component_utils(cpri_monitor)
  virtual cpri_if vif;
  uvm_analysis_port #(cpri_transaction) ap;
  int unsigned txn_count = 0;

  protected bit        in_active;     // currently observing LINK_ACTIVE
  protected bit        seen_active;   // a LINK_ACTIVE session existed before
  protected bit        first_comma;   // waiting for the first comma of a session
  protected bit        restart;       // link restarted (LOS / resync recovery)
  protected bit [7:0]  hfn;           // decoded hyperframe number

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual cpri_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cpri virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    cpri_transaction tr;
    in_active = 0; seen_active = 0; first_comma = 1; restart = 0; hfn = 0;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        in_active = 0; first_comma = 1; hfn = 0;
        continue;
      end
      if (vif.mon_cb.state == cpri_defs_pkg::LINK_ACTIVE) begin
        if (!in_active) begin
          // (re)entry into LINK_ACTIVE: restart hyperframe tracking
          in_active   = 1;
          first_comma = 1;
          hfn         = 0;
          restart     = seen_active;
          seen_active = 1;
        end
        if (vif.mon_cb.tx_k && vif.mon_cb.tx_data == cpri_defs_pkg::CPRI_K28_5) begin
          // hyperframe boundary comma
          if (first_comma) first_comma = 0;
          else             hfn++;
        end else if (!vif.mon_cb.tx_k) begin
          tr = cpri_transaction::type_id::create("tr");
          tr.hyperframe   = hfn;
          tr.iq_data      = vif.mon_cb.tx_data;
          tr.k_char       = 1'b0;
          tr.link_restart = restart;
          restart         = 0;
          txn_count++;
          `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
          ap.write(tr);
        end
      end else begin
        in_active = 0;
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("cpri monitor observed %0d IQ words", txn_count), UVM_LOW)
  endfunction
endclass
`endif
