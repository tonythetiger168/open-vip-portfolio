# CPRI — CPRI v8.0 (eCPRI over CPR) UVM VIP

Open-source UVM verification IP template for **CPRI v8.0 (eCPRI over CPR)** (Telecom).

## Contents

| Path | Description |
|------|-------------|
| `cpri/cpri_if.sv` | Protocol interface (32-bit words, tx_k, LOS) + link FSM state enum |
| `cpri/cpri_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `cpri/sva/cpri_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=5) |
| `cpri/vip/cpri/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/cpri_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional CPRI slave (RE) DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Link startup state machine**: driver walks RESET -> L1_SYNC -> PROTO_SETUP -> CMI_SETUP -> LINK_PASSIVE -> LINK_ACTIVE, sending K28.5 comma bursts during L1_SYNC and protocol/C&M control words during setup
- **Hyperframe numbering**: periodic K28.5 comma at every hyperframe boundary; monitor tracks the comma stream and tags each 32-bit IQ word with its hyperframe number (mod 256)
- **Protocol-level driver**: drives IQ words with tx_k control, handles LOS assertion and sync-loss re-acquisition; broadcasts expected words on `drv_ap`
- **Waveform-decoding monitor**: reconstructs IQ-word transactions (hyperframe / iq_data / k_char) directly from the tx_data/tx_k stream
- **Functional DUT model**: CPRI slave port (RE) that acquires sync by counting K28.5 commas, follows the master link state, drops to RESET on LOS, and loops IQ words back on rx_data/rx_k
- **End-to-end scoreboard**: expected (driver) vs observed (monitor) IQ words with hyperframe numbers; leftover-queue detection at end of test
- **Directed sequence library**: link-startup / iq-data / hyperframe-walk / iq-corner / los-inject / resync / error-inject / reset + random + regression mix
- **Functional coverage**: hyperframe x IQ-corner cross, K-char bins, link FSM state + startup/LOS/resync transition sequences, LOS x state error cross
- **Transaction checker**: hyperframe continuity check on the decoded stream (legal restarts counted separately)
- **SVA L4**: no IQ before LINK_ACTIVE, hyperframe comma spacing (increment), K28.5 restricted to sync/boundary, K-char words are K28.5, LOS returns link to RESET
