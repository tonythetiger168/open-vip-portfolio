// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sd_data_integrity_checker.sv -- SD Data-Integrity Compliance Checker (module form)
// Validates command framing, payload integrity, and write-block termination
`ifndef SD_DATA_INTEGRITY_CHECKER_SV
`define SD_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module sd_data_integrity_checker (sd_if vif);
  property p_sd_cmd_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_valid == 1 |-> vif.cmd_index <= 6'd63; endproperty
  assert_p_sd_cmd_valid: assert property(p_sd_cmd_valid) else `uvm_warning("SD_DI", "Command valid failed");
  cover_p_sd_cmd_valid: cover property(p_sd_cmd_valid);
  property p_sd_wdata_known; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_valid == 1 |-> !$isunknown(vif.dat); endproperty
  assert_p_sd_wdata_known: assert property(p_sd_wdata_known) else `uvm_warning("SD_DI", "Write payload has X failed");
  cover_p_sd_wdata_known: cover property(p_sd_wdata_known);
  property p_sd_rdata_known; @(posedge vif.clk) disable iff (!vif.rst_n) vif.rd_valid == 1 |-> !$isunknown(vif.rd_dat); endproperty
  assert_p_sd_rdata_known: assert property(p_sd_rdata_known) else `uvm_warning("SD_DI", "Read payload has X failed");
  cover_p_sd_rdata_known: cover property(p_sd_rdata_known);
  property p_sd_wdata_term; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.data_valid) |-> ##[1:8192] vif.data_end == 1; endproperty
  assert_p_sd_wdata_term: assert property(p_sd_wdata_term) else `uvm_warning("SD_DI", "Write block not terminated failed");
  cover_p_sd_wdata_term: cover property(p_sd_wdata_term);
endmodule
`endif
