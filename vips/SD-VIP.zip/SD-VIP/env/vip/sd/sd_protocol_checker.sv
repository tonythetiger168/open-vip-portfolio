// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sd_protocol_checker.sv -- SD Protocol Compliance Checker (module form)
// Validates command indices, bus/speed configuration, and data CRC handling
`ifndef SD_PROTOCOL_CHECKER_SV
`define SD_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module sd_protocol_checker (sd_if vif);
  property p_sd_cmd_idx; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_index <= 6'd63; endproperty
  assert_p_sd_cmd_idx: assert property(p_sd_cmd_idx) else `uvm_warning("SD_CHK", "Command index valid failed");
  cover_p_sd_cmd_idx: cover property(p_sd_cmd_idx);
  property p_sd_speed_mode; @(posedge vif.clk) disable iff (!vif.rst_n) vif.speed_mode inside {3'b000,3'b001,3'b010}; endproperty
  assert_p_sd_speed_mode: assert property(p_sd_speed_mode) else `uvm_warning("SD_CHK", "Speed mode valid failed");
  cover_p_sd_speed_mode: cover property(p_sd_speed_mode);
  property p_sd_bus_width; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bus_width inside {3'b001,3'b010,3'b111}; endproperty
  assert_p_sd_bus_width: assert property(p_sd_bus_width) else `uvm_warning("SD_CHK", "Bus width valid failed");
  cover_p_sd_bus_width: cover property(p_sd_bus_width);
  property p_sd_data_crc; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.data_end) |-> ##[1:8] vif.data_crc_ok == 1; endproperty
  assert_p_sd_data_crc: assert property(p_sd_data_crc) else `uvm_warning("SD_CHK", "Data CRC check failed");
  cover_p_sd_data_crc: cover property(p_sd_data_crc);
endmodule
`endif
