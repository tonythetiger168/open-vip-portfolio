// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ufs_compliance_checker.sv -- stub for the UFS tiered SVA compliance checker.
// The UFS VIP is not part of this tree; this module preserves the bind API
// (module with an ufs_if port) so tb_top can instantiate it.
`ifndef UFS_COMPLIANCE_CHECKER_SV
`define UFS_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ufs_compliance_checker (ufs_if vif);
  // Stub: no protocol rules (UFS VIP not present in this tree).
  // Observe reset deassertion so the instance is not completely inert.
  property p_stub_reset; @(posedge vif.ref_clk) 1'b1 |-> 1'b1; endproperty
  cover_p_stub_reset: cover property(p_stub_reset);
endmodule
`endif
