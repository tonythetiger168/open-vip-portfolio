// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// emmc_compliance_checker.sv -- stub for the eMMC tiered SVA compliance
// checker. The eMMC VIP is not part of this tree; this module preserves the
// bind API (module with an emmc_if port) so tb_top can instantiate it.
`ifndef EMMC_COMPLIANCE_CHECKER_SV
`define EMMC_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module emmc_compliance_checker (emmc_if vif);
  // Stub: no protocol rules (eMMC VIP not present in this tree).
  property p_stub_reset; @(posedge vif.clk) 1'b1 |-> 1'b1; endproperty
  cover_p_stub_reset: cover property(p_stub_reset);
endmodule
`endif
