// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sd_compliance_checker.sv -- SD tiered compliance SVA checker (module form)
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=Protocol-Specific
`ifndef SD_COMPLIANCE_CHECKER_SV
`define SD_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module sd_compliance_checker (sd_if vif);
  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[6], l4_fail[6];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_sd_cmd_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_valid == 1 |-> !$isunknown(vif.cmd_arg); endproperty
  assert_p_sd_cmd_valid: assert property(p_sd_cmd_valid) l1_pass[0]++; else begin `uvm_warning("SD_L1", "Command valid failed"); l1_fail[0]++; end
  cover_p_sd_cmd_valid: cover property(p_sd_cmd_valid);
  property p_sd_addr_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid == 1 |-> !$isunknown(vif.cmd_index); endproperty
  assert_p_sd_addr_valid: assert property(p_sd_addr_valid) l1_pass[1]++; else begin `uvm_warning("SD_L1", "Address valid failed"); l1_fail[1]++; end
  cover_p_sd_addr_valid: cover property(p_sd_addr_valid);
  property p_sd_data_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.rd_valid == 1 |-> !$isunknown(vif.rd_dat); endproperty
  assert_p_sd_data_valid: assert property(p_sd_data_valid) l1_pass[2]++; else begin `uvm_warning("SD_L1", "Data valid failed"); l1_fail[2]++; end
  cover_p_sd_data_valid: cover property(p_sd_data_valid);
  property p_sd_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_valid == 1 |-> !$isunknown(vif.cmd); endproperty
  assert_p_sd_no_x: assert property(p_sd_no_x) l1_pass[3]++; else begin `uvm_warning("SD_L1", "No X when active failed"); l1_fail[3]++; end
  cover_p_sd_no_x: cover property(p_sd_no_x);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_sd_card_busy; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.data_end) |-> ##[1:256] vif.busy == 0; endproperty
  assert_p_sd_card_busy: assert property(p_sd_card_busy) l2_pass[0]++; else begin `uvm_warning("SD_L2", "Card busy failed"); l2_fail[0]++; end
  cover_p_sd_card_busy: cover property(p_sd_card_busy);
  property p_sd_resp_latency; @(posedge vif.clk) disable iff (!vif.rst_n) ($fell(vif.cmd_valid) && vif.cmd_index != 6'd0) |-> ##[1:64] vif.resp_valid == 1; endproperty
  assert_p_sd_resp_latency: assert property(p_sd_resp_latency) l2_pass[1]++; else begin `uvm_warning("SD_L2", "Response latency failed"); l2_fail[1]++; end
  cover_p_sd_resp_latency: cover property(p_sd_resp_latency);
  property p_sd_cmd_index; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_index <= 6'd63; endproperty
  assert_p_sd_cmd_index: assert property(p_sd_cmd_index) l2_pass[2]++; else begin `uvm_warning("SD_L2", "Command index 0-63 failed"); l2_fail[2]++; end
  cover_p_sd_cmd_index: cover property(p_sd_cmd_index);
  property p_sd_bus_width; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bus_width inside {3'b001, 3'b010}; endproperty
  assert_p_sd_bus_width: assert property(p_sd_bus_width) l2_pass[3]++; else begin `uvm_warning("SD_L2", "Bus width legal failed"); l2_fail[3]++; end
  cover_p_sd_bus_width: cover property(p_sd_bus_width);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_sd_error; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err == 1 |-> ##[1:16] vif.err == 0; endproperty
  assert_p_sd_error: assert property(p_sd_error) l3_pass[0]++; else begin `uvm_warning("SD_L3", "Error handling failed"); l3_fail[0]++; end
  cover_p_sd_error: cover property(p_sd_error);
  property p_sd_timeout; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.cmd_valid) |-> ##[1:1000] vif.ready == 0; endproperty
  assert_p_sd_timeout: assert property(p_sd_timeout) l3_pass[1]++; else begin `uvm_warning("SD_L3", "Timeout failed"); l3_fail[1]++; end
  cover_p_sd_timeout: cover property(p_sd_timeout);
  property p_sd_status; @(posedge vif.clk) disable iff (!vif.rst_n) vif.status inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_sd_status: assert property(p_sd_status) l3_pass[2]++; else begin `uvm_warning("SD_L3", "Status valid failed"); l3_fail[2]++; end
  cover_p_sd_status: cover property(p_sd_status);
  property p_sd_power; @(posedge vif.clk) disable iff (!vif.rst_n) vif.power_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_sd_power: assert property(p_sd_power) l3_pass[3]++; else begin `uvm_warning("SD_L3", "Power state failed"); l3_fail[3]++; end
  cover_p_sd_power: cover property(p_sd_power);

  // ---------------- L4: SD protocol-specific rules (6) ----------------
  property p_sd_l4_start_bit; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.cmd_valid) |-> vif.cmd == 1'b0; endproperty
  assert_p_sd_l4_start_bit: assert property(p_sd_l4_start_bit) l4_pass[0]++; else begin `uvm_warning("SD_L4", "Command start bit not 0 failed"); l4_fail[0]++; end
  cover_p_sd_l4_start_bit: cover property(p_sd_l4_start_bit);
  property p_sd_l4_resp_after_cmd; @(posedge vif.clk) disable iff (!vif.rst_n) ($fell(vif.cmd_valid) && vif.cmd_index != 6'd0) |-> ##[1:64] vif.resp_valid == 1; endproperty
  assert_p_sd_l4_resp_after_cmd: assert property(p_sd_l4_resp_after_cmd) l4_pass[1]++; else begin `uvm_warning("SD_L4", "Command without response failed"); l4_fail[1]++; end
  cover_p_sd_l4_resp_after_cmd: cover property(p_sd_l4_resp_after_cmd);
  property p_sd_l4_busy_in_prg; @(posedge vif.clk) disable iff (!vif.rst_n) vif.busy == 1 |-> vif.card_state == 4'd7; endproperty
  assert_p_sd_l4_busy_in_prg: assert property(p_sd_l4_busy_in_prg) l4_pass[2]++; else begin `uvm_warning("SD_L4", "Busy outside PRG state failed"); l4_fail[2]++; end
  cover_p_sd_l4_busy_in_prg: cover property(p_sd_l4_busy_in_prg);
  property p_sd_l4_go_idle; @(posedge vif.clk) disable iff (!vif.rst_n) ($fell(vif.cmd_valid) && vif.cmd_index == 6'd0) |-> ##[1:8] vif.card_state == 4'd0; endproperty
  assert_p_sd_l4_go_idle: assert property(p_sd_l4_go_idle) l4_pass[3]++; else begin `uvm_warning("SD_L4", "GO_IDLE did not reset card state failed"); l4_fail[3]++; end
  cover_p_sd_l4_go_idle: cover property(p_sd_l4_go_idle);
  property p_sd_l4_acmd_prefix; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.cmd_valid == 1 && vif.cmd_index == 6'd41) |-> vif.app_cmd == 1; endproperty
  assert_p_sd_l4_acmd_prefix: assert property(p_sd_l4_acmd_prefix) l4_pass[4]++; else begin `uvm_warning("SD_L4", "ACMD41 without CMD55 prefix failed"); l4_fail[4]++; end
  cover_p_sd_l4_acmd_prefix: cover property(p_sd_l4_acmd_prefix);
  property p_sd_l4_r7_echo; @(posedge vif.clk) disable iff (!vif.rst_n) ($fell(vif.cmd_valid) && vif.cmd_index == 6'd8) |-> ##[1:64] (vif.resp_valid == 1 && vif.resp_type == 3'd7); endproperty
  assert_p_sd_l4_r7_echo: assert property(p_sd_l4_r7_echo) l4_pass[5]++; else begin `uvm_warning("SD_L4", "CMD8 without R7 response failed"); l4_fail[5]++; end
  cover_p_sd_l4_r7_echo: cover property(p_sd_l4_r7_echo);

  final begin : sva_report
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("SD_RPT", "=== SD Tiered SVA Report ===", UVM_LOW)
    `uvm_info("SD_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("SD_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("SD_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("SD_RPT", $sformatf("  L4 Protocol Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("SD_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
