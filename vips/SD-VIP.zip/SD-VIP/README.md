# SD UVM Verification IP (VIP)

SD (SDSC/SDHC) host-side UVM VIP with a functional SD card DUT model,
end-to-end scoreboard, tiered SVA compliance checkers, and functional
coverage. Part of the memory/storage protocol VIP framework
(`memory_*_pkg` shared environment, 8 protocols).

## Protocol Overview

Modeled after the SD Physical Layer Specification:

- **CMD line**: 48-bit command frame `{start=0, host=1, idx[5:0], arg[31:0],
  CRC7, end=1}` serialized MSB-first; CRC7 (x^7+x^3+1) checked by the card.
- **RESP line**: R1/R1b/R3/R6/R7 (48-bit) and R2 (136-bit CID/CSD) responses.
- **DAT lines**: nibble-serial 512-byte block read (card->host `rd_dat`) and
  block write (host->card `dat` + trailing XOR CRC byte); busy handshake after
  write/erase/stop (DAT0 low).
- Command set: CMD0/2/3/6/7/8/9/12/13/16/17/18/24/25/32/33/38/41(ACMD)/52/55,
  SD init chain CMD0 -> CMD8 -> ACMD41 -> CMD2 -> CMD3(R6 RCA) -> CMD7,
  CMD55/ACMD prefix tracking.
- Card registers: CID, CSD, OCR, RCA, SWITCH_FUNC 64-byte status block.

## Architecture

```
memory_test_pkg (tests)
  -> memory_env_pkg (memory_env + memory_scoreboard: SD exp/obs e2e compare)
    -> sd_pkg: sd_agent { sd_sequencer, sd_driver (drv_ap), sd_monitor }
    -> memory_coverage_pkg: sd_coverage (3 covergroups)
sd_if (interfaces/memory_interfaces.sv) -- CMD/RESP/DAT + sideband/status
sd_card_dut (tb_top.sv) -- 1 MiB block memory + card FSM (functional DUT)
env/sva/sd_compliance_checker.sv + env/vip/sd/*.sv -- SVA checker modules
```

Closed loop: driver publishes expected commands on `drv_ap`; the monitor
decodes command frames, response frames, and both data directions from the
waveform; `memory_scoreboard` compares host commands (`sd_n_matches` /
`sd_n_mismatches`, mismatch -> `UVM_ERROR`). APP_CMD prefix frames are
protocol overhead and excluded from the compare on both sides.

## Sequence List (sd_pkg)

| Sequence | Kind | Description |
|---|---|---|
| `sd_base_seq` | base | helpers (`send`, `send_t`) |
| `sd_rw_seq` | normal | random CMD17/CMD24 mix |
| `sd_init_seq` | directed | CMD0/CMD8/ACMD41/CMD2/CMD3/CMD7/CMD16 |
| `sd_read_seq` | directed | CMD17/18 block reads |
| `sd_write_seq` | directed | CMD24/25 block writes |
| `sd_config_seq` | directed | SWITCH_FUNC + ACMD6 bus width + CSD |
| `sd_erase_seq` | directed | CMD32/33/38 erase |
| `sd_error_seq` | error | out-of-range address + command CRC error |
| `sd_reset_seq` | reset | CMD0 mid-traffic + re-init |
| `sd_b2b_seq` | back-to-back | zero idle cycles between commands |
| `sd_stress_seq` | stress | heavy randomized traffic |
| `sd_corner_seq` | corner | first/last block, SET_BLOCKLEN extremes, CMD12 |
| `sd_cov_cmd_seq` | coverage | all 21 command types |
| `sd_cov_bw_seq` | coverage | 1-bit / 4-bit bus widths |
| `sd_regression_mix_seq` | regression | runs all directed sequences in order |

Tests (`memory_test_pkg`): `memory_base_test`,
`memory_coverage_regression_test`, `memory_random_test`, `sd_regression_test`,
`sd_init_test`, `sd_read_write_test`, `sd_erase_test`, `sd_error_test`,
`sd_reset_test`, `sd_b2b_test`, `sd_corner_test`, `sd_stress_test`.

## SVA Compliance (env/sva/sd_compliance_checker.sv)

- **L1 Basic (4)**: cmd/addr/data valid, no-X when active
- **L2 Full Protocol (4)**: busy window, response latency, cmd index, bus width
- **L3 Advanced (4)**: error recovery, timeout, status class, power state
- **L4 SD-specific (6)**: command start bit, response-after-command,
  busy-only-in-PRG, GO_IDLE resets card state, ACMD41 requires CMD55 prefix,
  CMD8 answered by R7

Additional checker modules in `env/vip/sd/`: `sd_protocol_checker`,
`sd_error_checker`, `sd_timing_checker`, `sd_data_integrity_checker`
(all instantiated in `tb_top.sv`).

## Functional Coverage (memory_coverage_pkg::sd_coverage)

1. `sd_cg` — protocol config: command type x bus width (cross), ACMD flag
2. `sd_fsm_cg` — command-sequence FSM transitions (init chain, ACMD,
   multiple-block stop, write->status) x bus width (cross)
3. `sd_data_cg` — block length x address region (cross), R1 error status

## Quick Start

```sh
cd scripts
make compile elaborate run TEST=sd_regression_test SIMULATOR=vcs
make regression
# or directly:
./run.sh                              # TESTNAME=sd_regression_test ...
```

Note: block data transfers are one 512-byte block per data command in this
model; `block_len` is randomized for coverage / SET_BLOCKLEN arguments.
All VIP sources parse with 0 syntax errors under pyslang 11.
