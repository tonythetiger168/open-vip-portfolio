# Independent cross-check model (`xchk/`)

`sd_xchk_tb.sv` checks the open-ip-portfolio `SD` RTL (`rtl/SD_top.sv`, `rtl/SD_apb.sv`)
against an SD memory card: CRC7 / CRC16, R1 / R2 / R3 / R6 / R7, identification, injected card faults (add -DSC for a standard-capacity card). The model is written from the SD Physical Layer Simplified Specification, not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/sd_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s sd_xchk_tb -o xchk.vvp $OIP/rtl/SD_top.sv $OIP/rtl/SD_apb.sv xchk/sd_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
