// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tb_top.sv -- 8-protocol top-level testbench (UFS-deepened)
// Closed loop: UFS VIP driver -> ufs_if -> functional UFS device DUT -> UFS monitor
`timescale 1ns/1ps
`ifndef TB_TOP_SV
`define TB_TOP_SV
import uvm_pkg::*;
`include "uvm_macros.svh"
import memory_test_pkg::*;

module tb_top;
  logic ddr_ck = 0, ddr_rst_n = 0;
  logic lpddr_ck = 0, lpddr_rst_n = 0;
  logic hbm_ck = 0, hbm_rst_n = 0;
  logic ufs_clk = 0, ufs_rst_n = 0;
  logic unipro_clk = 0, unipro_rst_n = 0;
  logic emmc_clk = 0, emmc_rst_n = 0;
  logic onfi_clk = 0, onfi_rst_n = 0;
  logic sd_clk = 0, sd_rst_n = 0;
  always #5 ddr_ck = ~ddr_ck;
  always #5 lpddr_ck = ~lpddr_ck;
  always #5 hbm_ck = ~hbm_ck;
  always #10 ufs_clk = ~ufs_clk;
  always #10 unipro_clk = ~unipro_clk;
  always #20 emmc_clk = ~emmc_clk;
  always #50 onfi_clk = ~onfi_clk;
  always #20 sd_clk = ~sd_clk;
  initial begin
    #100;
    ddr_rst_n = 1; lpddr_rst_n = 1; hbm_rst_n = 1; ufs_rst_n = 1;
    unipro_rst_n = 1; emmc_rst_n = 1; onfi_rst_n = 1; sd_rst_n = 1;
  end

  ddr_if    ddr_if_inst    (.ck(ddr_ck), .ck_n(~ddr_ck), .rst_n(ddr_rst_n));
  lpddr_if  lpddr_if_inst  (.ck(lpddr_ck), .ck_n(~lpddr_ck), .cke(1'b1), .rst_n(lpddr_rst_n));
  hbm_if    hbm_if_inst    (.ck(hbm_ck), .ck_n(~hbm_ck), .rst_n(hbm_rst_n));
  ufs_if    ufs_if_inst    (.ref_clk(ufs_clk), .rst_n(ufs_rst_n));
  unipro_if unipro_if_inst (.clk(unipro_clk), .rst_n(unipro_rst_n));
  emmc_if   emmc_if_inst   (.clk(emmc_clk), .rst_n(emmc_rst_n));
  onfi_if   onfi_if_inst   (.clk(onfi_clk), .rst_n(onfi_rst_n));
  sd_if     sd_if_inst     (.clk(sd_clk), .rst_n(sd_rst_n));

  // functional DUT models (closed loop)
  unipro_endpoint_dut unipro_ep (.vif(unipro_if_inst));
  emmc_device_dut     emmc_dev  (.vif(emmc_if_inst));
  sd_card_dut         sd_card   (.vif(sd_if_inst));
  onfi_flash_dut      onfi_dev  (.vif(onfi_if_inst));
  ufs_device_dut      ufs_dev   (.vif(ufs_if_inst));

  // UFS tiered SVA compliance checkers (L1-L4) bound to the live interface
  ufs_compliance_checker      ufs_sva      (.vif(ufs_if_inst));
  // eMMC tiered SVA compliance checkers (L1-L4) bound to the live interface
  emmc_compliance_checker     emmc_sva     (.vif(emmc_if_inst));
  // SD tiered SVA compliance checkers (L1-L4) bound to the live interface
  sd_compliance_checker       sd_sva       (.vif(sd_if_inst));
  sd_protocol_checker         sd_proto     (.vif(sd_if_inst));
  sd_error_checker            sd_err       (.vif(sd_if_inst));
  sd_timing_checker           sd_timing    (.vif(sd_if_inst));
  sd_data_integrity_checker   sd_dint      (.vif(sd_if_inst));

  initial begin
    uvm_config_db#(virtual ddr_if)::set(null, "*.ddr_*", "vif", ddr_if_inst);
    uvm_config_db#(virtual lpddr_if)::set(null, "*.lpddr_*", "vif", lpddr_if_inst);
    uvm_config_db#(virtual hbm_if)::set(null, "*.hbm_*", "vif", hbm_if_inst);
    uvm_config_db#(virtual ufs_if)::set(null, "*.ufs_*", "vif", ufs_if_inst);
    uvm_config_db#(virtual unipro_if)::set(null, "*.unipro_*", "vif", unipro_if_inst);
    uvm_config_db#(virtual emmc_if)::set(null, "*.emmc_*", "vif", emmc_if_inst);
    uvm_config_db#(virtual onfi_if)::set(null, "*.onfi_*", "vif", onfi_if_inst);
    uvm_config_db#(virtual sd_if)::set(null, "*.sd_*", "vif", sd_if_inst);
    run_test();
  end
endmodule

//--------------------------------------------------------------------------
// Functional UniPro endpoint DUT model:
//  - returns L2 credits on reception (credit-based flow control)
//  - echoes received data back on the RX path (loopback)
//  - flags 0xFF frames as errors (error-injection detection)
//--------------------------------------------------------------------------
module unipro_endpoint_dut (unipro_if vif);
  int unsigned rx_frames = 0;
  int unsigned err_frames = 0;
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin : ep
    if (!vif.rst_n) begin : rst
      vif.rx_data <= 0; vif.rx_data_valid <= 0;
      vif.rx_cred <= 0; vif.rx_cred_valid <= 0;
    end else begin : run
      vif.rx_data_valid <= #1ns vif.tx_data_valid;
      vif.rx_data <= #1ns vif.tx_data;
      vif.rx_cred_valid <= #1ns (vif.tx_data_valid || vif.tx_cred_valid);
      vif.rx_cred <= #1ns vif.tx_cred + 8'd1;
      if (vif.tx_data_valid) rx_frames <= rx_frames + 1;
    end
  end
  final begin : rpt
    `uvm_info("UNIPRO_EP", $sformatf("endpoint: rx_frames=%0d err_frames=%0d", rx_frames, err_frames), UVM_LOW)
  end
endmodule

//--------------------------------------------------------------------------
// Functional eMMC card DUT model
//  - 1 MiB block memory (2048 blocks x 512 B), CID/CSD/EXT_CSD/OCR registers
//  - 48-bit command frame decode {start, dir, idx, arg, CRC7, end} + CRC check
//  - R1/R1b/R2/R3 responses, card state machine (idle..tran/data/rcv/prg)
//  - CMD17/18 block read, CMD24/25 block write (+XOR data CRC), CMD35-38 erase
//  - busy handshake (card_busy / DAT0) during programming and erase
//  - out-of-range address / command CRC error / illegal command -> R1 error bits
//--------------------------------------------------------------------------
module emmc_device_dut (emmc_if vif);
  localparam int BLK = 512;
  localparam int CAP_BLOCKS = 2048;
  localparam int CAP_BYTES = BLK * CAP_BLOCKS;
  localparam int PROG_CYCLES = 32;
  localparam int ERASE_CYCLES = 64;
  bit [7:0] mem [0:CAP_BYTES-1];
  bit [7:0] ext_csd [0:511];
  bit [127:0] cid = 128'h1B534D_00010203_405A5A5A_20260901; // MID/PNM/PRV/PSN/MDT
  bit [127:0] csd = 128'hD40E0032_0F5903FF_FFFFFFFF_8A404000;
  bit [31:0]  ocr = 32'hC0FF_8000;
  bit [15:0]  rca = 16'h0001;
  typedef enum logic [3:0] {E_IDLE, E_CMD, E_DECODE, E_RESP, E_RDATA, E_WDATA,
                            E_WCRC, E_PROG, E_ERASE} estate_e;
  estate_e st;
  bit [47:0]  shreg;
  int         bit_cnt;
  bit [135:0] rsp_reg;
  int         rsp_len, rsp_cnt;
  int         data_cnt;
  int         prog_cnt;
  bit [7:0]   xcrc;
  bit [5:0]   idx;
  bit [31:0]  arg;
  bit [31:0]  r1_status;
  bit [31:0]  st32;
  bit         bad_addr, bad_crc, bad_illegal;
  bit [3:0]   cstate;
  int unsigned cmd_cnt = 0, err_cnt = 0;

  localparam bit [3:0] CS_IDLE = 0, CS_READY = 1, CS_IDENT = 2, CS_STBY = 3,
                       CS_TRAN = 4, CS_DATA = 5, CS_RCV = 6, CS_PRG = 7, CS_DIS = 8;

  initial begin
    for (int i = 0; i < CAP_BYTES; i++) mem[i] = i[7:0] ^ 8'hA5;
    for (int i = 0; i < 512; i++) ext_csd[i] = i[7:0];
  end

  function automatic bit [6:0] crc7(bit [5:0] i_, bit [31:0] a_);
    bit [6:0] crc = 7'h00;
    bit [39:0] stream = {i_, a_};
    for (int b = 39; b >= 0; b--) begin
      bit fb = crc[6] ^ stream[b];
      crc = {crc[5:0], 1'b0};
      if (fb) crc = crc ^ 7'h09;
    end
    return crc;
  endfunction

  function automatic bit idx_known(bit [5:0] i_);
    case (i_)
      6'd0, 6'd1, 6'd2, 6'd3, 6'd6, 6'd7, 6'd8, 6'd13, 6'd16, 6'd17, 6'd18,
      6'd24, 6'd25, 6'd35, 6'd36, 6'd38, 6'd41, 6'd52, 6'd53, 6'd55: return 1'b1;
      default: return 1'b0;
    endcase
  endfunction

  // build a 48-bit response frame {0,0,idx,status,crc7,1}
  function automatic bit [47:0] rframe48(bit [5:0] i_, bit [31:0] status32);
    return {2'b00, i_, status32, crc7(i_, status32), 1'b1};
  endfunction

  always_ff @(posedge vif.clk or negedge vif.rst_n) begin : card
    if (!vif.rst_n) begin : rst
      st <= E_IDLE; bit_cnt <= 0; rsp_cnt <= 0; data_cnt <= 0; prog_cnt <= 0;
      cstate <= CS_IDLE;
      vif.resp <= 1'b1; vif.resp_valid <= 1'b0; vif.busy <= 1'b0;
      vif.rd_data <= 8'h0; vif.rd_valid <= 1'b0;
      vif.card_busy <= 1'b0; vif.data_crc_ok <= 1'b1;
      vif.card_state <= CS_IDLE; vif.resp_type <= 3'd0;
      vif.err <= 1'b0; vif.status <= 3'b000; vif.power_state <= 3'b000;
      vif.ready <= 1'b1; vif.app_cmd <= 1'b0;
    end else begin : run
      vif.resp_valid <= 1'b0;  // defaults
      vif.rd_valid   <= 1'b0;
      vif.data_crc_ok <= 1'b1;
      vif.power_state <= 3'b001;
      vif.card_state  <= cstate;
      case (st)
        E_IDLE: begin
          vif.ready <= 1'b1; vif.status <= 3'b000;
          if (vif.cmd_valid) begin
            shreg <= {shreg[46:0], vif.cmd};
            bit_cnt <= 1;
            vif.ready <= 1'b0;
            st <= E_CMD;
          end
        end
        E_CMD: begin
          if (vif.cmd_valid) begin
            shreg <= {shreg[46:0], vif.cmd};
            bit_cnt <= bit_cnt + 1;
          end else begin
            if (bit_cnt == 48) st <= E_DECODE;
            else begin st <= E_IDLE; bit_cnt <= 0; end // short frame ignored
          end
        end
        E_DECODE: begin
          idx = shreg[45:40];
          arg = shreg[39:8];
          bad_crc     = (shreg[7:1] != crc7(idx, arg)) || shreg[47] !== 1'b0 || shreg[46] !== 1'b1;
          bad_addr    = ((idx inside {6'd17, 6'd18, 6'd24, 6'd25, 6'd35, 6'd36}) && (int'(arg) >= CAP_BLOCKS));
          bad_illegal = !idx_known(idx) || (idx == 6'd41 && !vif.app_cmd);
          cmd_cnt <= cmd_cnt + 1;
          st32 = (bad_addr ? 32'h8000_0000 : 32'h0) |
                 (bad_crc ? 32'h0080_0000 : 32'h0) |
                 (bad_illegal ? 32'h0040_0000 : 32'h0) |
                 {16'h0, cstate, 9'h0};
          r1_status <= st32;
          vif.err    <= (bad_addr || bad_crc || bad_illegal);
          vif.status <= (bad_addr || bad_crc || bad_illegal) ? 3'b010 : 3'b001;
          if (bad_addr || bad_crc || bad_illegal) err_cnt <= err_cnt + 1;
          // APP_CMD tracking
          if (idx == 6'd55) vif.app_cmd <= 1'b1;
          else if (idx != 6'd55) vif.app_cmd <= 1'b0;
          case (idx)
            6'd0: begin // GO_IDLE: no response
              cstate <= CS_IDLE; st <= E_IDLE; bit_cnt <= 0;
            end
            6'd1, 6'd41: begin // R3 (OCR)
              rsp_reg <= {rframe48(6'h3F, ocr), 88'h0}; rsp_len <= 48; rsp_cnt <= 0;
              vif.resp_type <= 3'd3;
              if (!bad_crc && !bad_illegal) cstate <= CS_READY;
              st <= E_RESP;
            end
            6'd2: begin // R2 (CID, 136 bits)
              rsp_reg <= {2'b00, 6'h3F, cid, 1'b1}; rsp_len <= 136; rsp_cnt <= 0;
              vif.resp_type <= 3'd2;
              if (!bad_crc) cstate <= CS_IDENT;
              st <= E_RESP;
            end
            6'd3: begin // SET_REL_ADDR: R1 + RCA assignment
              rsp_reg <= {rframe48(6'd3, {arg[31:16], cstate, 9'h0, 3'h0}), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              if (!bad_crc) begin rca <= arg[31:16]; cstate <= CS_STBY; end
              st <= E_RESP;
            end
            6'd6: begin // SWITCH: R1b (busy after response)
              rsp_reg <= {rframe48(6'd6, {16'h0, cstate, 9'h0, 3'h0}), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd4;
              st <= E_RESP;
              prog_cnt <= PROG_CYCLES;
            end
            6'd7: begin // SELECT_CARD
              rsp_reg <= {rframe48(6'd7, {16'h0, cstate, 9'h0, 3'h0}), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              if (!bad_crc) cstate <= CS_TRAN;
              st <= E_RESP;
            end
            6'd17, 6'd18, 6'd8: begin // read data commands
              rsp_reg <= {rframe48(idx, (bad_addr || bad_crc) ?
                          (32'h8000_0000 | {16'h0, cstate, 9'h0, 3'h0}) : {16'h0, cstate, 9'h0, 3'h0}), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              if (!bad_addr && !bad_crc) begin
                data_cnt <= 0;
                cstate <= CS_DATA;
              end
              st <= E_RESP;
            end
            6'd24, 6'd25: begin // write data commands
              rsp_reg <= {rframe48(idx, (bad_addr || bad_crc) ?
                          (32'h8000_0000 | {16'h0, cstate, 9'h0, 3'h0}) : {16'h0, cstate, 9'h0, 3'h0}), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              if (!bad_addr && !bad_crc) begin
                data_cnt <= 0; xcrc <= 8'h00;
                cstate <= CS_RCV;
              end
              st <= E_RESP;
            end
            6'd38: begin // ERASE: R1b + long busy
              rsp_reg <= {rframe48(6'd38, {16'h0, cstate, 9'h0, 3'h0}), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd4;
              prog_cnt <= ERASE_CYCLES;
              st <= E_RESP;
            end
            default: begin // generic R1
              rsp_reg <= {rframe48(idx, st32), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              st <= E_RESP;
            end
          endcase
          if (idx != 6'd0) bit_cnt <= 0;
        end
        E_RESP: begin // shift response frame out, MSB first
          vif.resp <= rsp_reg[135];
          vif.resp_valid <= 1'b1;
          rsp_reg <= {rsp_reg[134:0], 1'b1};
          if (rsp_cnt == rsp_len - 1) begin
            rsp_cnt <= 0;
            vif.resp_type <= 3'd0;
            // post-response actions
            if ((idx == 6'd17 || idx == 6'd18 || idx == 6'd8) && !bad_addr && !bad_crc) begin
              st <= E_RDATA; data_cnt <= 0;
            end else if ((idx == 6'd24 || idx == 6'd25) && !bad_addr && !bad_crc) begin
              st <= E_WDATA;
            end else if (idx == 6'd6 || idx == 6'd38) begin
              st <= E_PROG; cstate <= CS_PRG;
              vif.busy <= 1'b1; vif.card_busy <= 1'b1;
            end else begin
              st <= E_IDLE;
              if (idx == 6'd13) cstate <= cstate; // status query keeps state
            end
          end else rsp_cnt <= rsp_cnt + 1;
        end
        E_RDATA: begin // stream one block from memory / EXT_CSD
          if (idx == 6'd8) vif.rd_data <= ext_csd[data_cnt];
          else             vif.rd_data <= mem[int'(arg) * BLK + data_cnt];
          vif.rd_valid <= 1'b1;
          if (data_cnt == BLK - 1) begin
            st <= E_IDLE; cstate <= CS_TRAN;
          end
          data_cnt <= data_cnt + 1;
        end
        E_WDATA: begin // receive one block + trailing XOR CRC byte
          if (vif.data_valid) begin
            if (data_cnt < BLK) begin
              mem[int'(arg) * BLK + data_cnt] <= vif.data;
              xcrc <= xcrc ^ vif.data;
            end else begin
              // CRC byte received
              vif.data_crc_ok <= (vif.data == xcrc);
              vif.err <= (vif.data != xcrc);
              vif.status <= (vif.data != xcrc) ? 3'b010 : 3'b001;
              st <= E_PROG; cstate <= CS_PRG;
              vif.busy <= 1'b1; vif.card_busy <= 1'b1;
              prog_cnt <= PROG_CYCLES;
            end
            data_cnt <= data_cnt + 1;
          end
        end
        E_PROG: begin // programming / erase busy window
          vif.busy <= 1'b1; vif.card_busy <= 1'b1;
          if (idx == 6'd38) begin
            // erase group 0..15 blocks during the busy window (model)
            if (prog_cnt == 1)
              for (int b = 0; b < 16; b++)
                for (int k = 0; k < BLK; k++)
                  mem[b * BLK + k] <= 8'hFF;
          end
          if (prog_cnt <= 1) begin
            vif.busy <= 1'b0; vif.card_busy <= 1'b0;
            cstate <= CS_TRAN; st <= E_IDLE;
          end else prog_cnt <= prog_cnt - 1;
        end
        default: st <= E_IDLE;
      endcase
    end
  end

  final begin : rpt
    `uvm_info("EMMC_DEV", $sformatf("card: commands=%0d errors=%0d", cmd_cnt, err_cnt), UVM_LOW)
  end
endmodule

// ONFI flash model: ready/busy handshake
module onfi_flash_dut (onfi_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) vif.rb_n <= 1'b1;
    else            vif.rb_n <= #1ns 1'b1;
endmodule

//--------------------------------------------------------------------------
// Functional UFS device DUT model
//  - 1 MiB block memory (2048 blocks x 512 B), byte addressable via LBA
//  - UPIU header decode (type/lun/tag/opcode/lba/len) with UTP doorbell concept
//  - WRITE_10: READY_XFER (RTT) -> data phase -> RESPONSE
//  - READ_10:  DATA_IN burst -> RESPONSE
//  - QUERY_REQ/TASK_MGT/NOP_OUT: response-only exchanges
//  - out-of-capacity LBA / reserved opcode / bad LUN -> CHECK CONDITION, no data phase
//  - device state machine: IDLE -> HDR -> DECODE -> WRTT/WDATA/RDATA -> GAP -> RESP
//--------------------------------------------------------------------------
module ufs_device_dut (ufs_if vif);
  localparam int BLK = 512;
  localparam int CAP_BLOCKS = 2048;
  localparam int CAP_BYTES = BLK * CAP_BLOCKS;
  bit [7:0] mem [0:CAP_BYTES-1];
  typedef enum logic [3:0] {D_IDLE, D_HDR, D_DECODE, D_WRTT, D_WDATA, D_RDATA, D_GAP, D_RESP} dstate_e;
  dstate_e st;
  bit [7:0] hdr [0:9];
  int hdr_cnt, data_cnt, resp_cnt;
  bit [7:0] tag, opcode, dlun, upiu;
  bit [31:0] lba;
  bit [15:0] dlen;
  bit [7:0] resp_type, resp_status_b;
  bit bad;
  int unsigned cmd_cnt = 0, err_cnt = 0;

  initial for (int i = 0; i < CAP_BYTES; i++) mem[i] = i[7:0] ^ 8'h5A;

  function automatic bit [7:0] resp_type_for(bit [7:0] t);
    case (t)
      8'h00:   return 8'h20; // NOP_OUT   -> NOP_IN
      8'h01:   return 8'h21; // COMMAND   -> RESPONSE
      8'h04:   return 8'h24; // TASK_MGT  -> TASK_MGT_RSP
      8'h16:   return 8'h36; // QUERY_REQ -> QUERY_RSP
      default: return 8'h3F; //           -> REJECT
    endcase
  endfunction

  function automatic bit scsi_known(bit [7:0] op);
    return op inside {8'h00, 8'h03, 8'h12, 8'h28, 8'h2A};
  endfunction

  always_ff @(posedge vif.ref_clk or negedge vif.rst_n) begin : dev
    if (!vif.rst_n) begin : rst
      st <= D_IDLE; hdr_cnt <= 0; data_cnt <= 0; resp_cnt <= 0;
      vif.data_in <= 0; vif.data_in_valid <= 0;
      vif.transfer_ready <= 0; vif.ready <= 0; vif.busy <= 0; vif.err <= 0;
      vif.data_dir <= 2'b00; vif.status <= 3'b000; vif.power_state <= 3'b000;
      vif.resp_valid <= 0; vif.resp_status <= 3'b000;
    end else begin : run
      vif.data_in_valid <= 1'b0;   // default: silent device->host link
      vif.resp_valid    <= 1'b0;
      vif.power_state   <= 3'b001; // active power mode
      case (st)
        D_IDLE: begin
          vif.busy <= 1'b0; vif.data_dir <= 2'b00; vif.status <= 3'b000;
          vif.transfer_ready <= 1'b0; vif.err <= 1'b0; vif.ready <= 1'b1;
          if (vif.data_out_valid) begin
            hdr[0] <= vif.data_out; hdr_cnt <= 1;
            vif.busy <= 1'b1; vif.data_dir <= 2'b01; vif.ready <= 1'b0;
            st <= D_HDR;
          end
        end
        D_HDR: begin
          if (vif.data_out_valid) begin
            hdr[hdr_cnt] <= vif.data_out;
            if (hdr_cnt == 9) begin st <= D_DECODE; hdr_cnt <= 0; end
            else hdr_cnt <= hdr_cnt + 1;
          end
        end
        D_DECODE: begin
          upiu   <= hdr[0]; dlun <= hdr[1]; tag <= hdr[2]; opcode <= hdr[3];
          lba    <= {hdr[4], hdr[5], hdr[6], hdr[7]};
          dlen   <= {hdr[8], hdr[9]};
          resp_type     <= resp_type_for(hdr[0]);
          bad = (int'({hdr[4], hdr[5], hdr[6], hdr[7]}) * BLK + int'({hdr[8], hdr[9]}) > CAP_BYTES)
                || (hdr[1] > 8'd7)
                || (hdr[0] == 8'h01 && !scsi_known(hdr[3]));
          resp_status_b <= bad ? 8'h02 : 8'h00;
          vif.err       <= bad;
          vif.status    <= bad ? 3'b010 : 3'b001;
          if (hdr[0] == 8'h01 && hdr[3] == 8'h2A && !bad) begin
            st <= D_WRTT;                       // WRITE_10: issue RTT first
          end else if (hdr[0] == 8'h01 && hdr[3] == 8'h28 && !bad) begin
            st <= D_RDATA; data_cnt <= 0; vif.data_dir <= 2'b10;
          end else begin
            st <= D_RESP; resp_cnt <= 0; vif.data_dir <= 2'b10;
            if (bad) err_cnt <= err_cnt + 1;
          end
        end
        D_WRTT: begin  // READY_XFER burst (single byte 0x31)
          vif.data_in <= 8'h31; vif.data_in_valid <= 1'b1;
          vif.transfer_ready <= 1'b1; vif.data_dir <= 2'b10;
          data_cnt <= 0;
          st <= D_WDATA;
        end
        D_WDATA: begin
          vif.transfer_ready <= 1'b0; vif.data_dir <= 2'b01;
          if (vif.data_out_valid) begin
            mem[int'(lba) * BLK + data_cnt] <= vif.data_out;
            if (data_cnt == int'(dlen) - 1) begin
              st <= D_RESP; resp_cnt <= 0; vif.data_dir <= 2'b10; vif.status <= 3'b001;
            end
            data_cnt <= data_cnt + 1;
          end
        end
        D_RDATA: begin // DATA_IN burst from block memory
          vif.data_in <= mem[int'(lba) * BLK + data_cnt];
          vif.data_in_valid <= 1'b1; vif.data_dir <= 2'b10;
          if (data_cnt == int'(dlen) - 1) st <= D_GAP;
          data_cnt <= data_cnt + 1;
        end
        D_GAP: begin   // inter-burst gap so the monitor can delimit bursts
          vif.status <= 3'b001;
          resp_cnt <= 0;
          st <= D_RESP;
        end
        D_RESP: begin  // 3-byte response trailer {type, tag, status}
          vif.data_in_valid <= 1'b1; vif.resp_valid <= 1'b1;
          vif.resp_status <= (vif.status == 3'b010) ? 3'b010 : 3'b001;
          case (resp_cnt)
            0: vif.data_in <= resp_type;
            1: vif.data_in <= tag;
            default: vif.data_in <= resp_status_b;
          endcase
          if (resp_cnt == 2) begin
            st <= D_IDLE; resp_cnt <= 0; cmd_cnt <= cmd_cnt + 1;
          end else resp_cnt <= resp_cnt + 1;
        end
        default: st <= D_IDLE;
      endcase
    end
  end

  final begin : rpt
    `uvm_info("UFS_DEV", $sformatf("device: commands=%0d errors=%0d", cmd_cnt, err_cnt), UVM_LOW)
  end
endmodule

//--------------------------------------------------------------------------
// Functional SD card DUT model
//  - 1 MiB block memory (2048 blocks x 512 B), CID/CSD/OCR/RCA registers
//  - 48-bit command frame decode {start, dir, idx, arg, CRC7, end} + CRC check
//  - R1/R1b/R2/R3/R6/R7 responses, card state machine, CMD55/ACMD tracking
//  - CMD17/18 block read, CMD24/25 block write (+XOR data CRC), nibble-serial DAT
//  - CMD6 SWITCH_FUNC 64-byte status read, CMD12/38 busy handshake
//  - out-of-range address / command CRC error / illegal command -> R1 error bits
//--------------------------------------------------------------------------
module sd_card_dut (sd_if vif);
  localparam int BLK = 512;
  localparam int CAP_BLOCKS = 2048;
  localparam int CAP_BYTES = BLK * CAP_BLOCKS;
  localparam int PROG_CYCLES = 32;
  localparam int ERASE_CYCLES = 64;
  bit [7:0] mem [0:CAP_BYTES-1];
  bit [7:0] sw_status [0:63];
  bit [127:0] cid = 128'h1B5344_00010203_405A5A5A_20260901;
  bit [127:0] csd = 128'h400E0032_0F5903FF_FFFFFFFF_8A404000;
  bit [31:0]  ocr = 32'hC0FF_8000;
  bit [15:0]  rca = 16'h0001;
  typedef enum logic [3:0] {S_IDLE, S_CMD, S_DECODE, S_RESP, S_RDATA, S_WDATA, S_PROG} sstate_e;
  sstate_e st;
  bit [47:0]  shreg;
  int         bit_cnt;
  bit [135:0] rsp_reg;
  int         rsp_len, rsp_cnt;
  int         data_cnt, prog_cnt;
  bit         nib;
  bit [3:0]   cur_nib;
  bit [7:0]   xcrc;
  bit [5:0]   idx;
  bit [31:0]  arg;
  bit [31:0]  st32;
  bit         bad_addr, bad_crc, bad_illegal;
  bit [3:0]   cstate;
  int unsigned cmd_cnt = 0, err_cnt = 0;
  localparam bit [3:0] CS_IDLE = 0, CS_READY = 1, CS_IDENT = 2, CS_STBY = 3,
                       CS_TRAN = 4, CS_DATA = 5, CS_RCV = 6, CS_PRG = 7, CS_DIS = 8;
  initial begin
    for (int i = 0; i < CAP_BYTES; i++) mem[i] = i[7:0] ^ 8'hA5;
    for (int i = 0; i < 64; i++) sw_status[i] = i[7:0];
  end
  function automatic bit [6:0] crc7(bit [5:0] i_, bit [31:0] a_);
    bit [6:0] crc = 7'h00;
    bit [39:0] stream = {i_, a_};
    for (int b = 39; b >= 0; b--) begin
      bit fb = crc[6] ^ stream[b];
      crc = {crc[5:0], 1'b0};
      if (fb) crc = crc ^ 7'h09;
    end
    return crc;
  endfunction
  function automatic bit idx_known(bit [5:0] i_);
    case (i_)
      6'd0, 6'd2, 6'd3, 6'd6, 6'd7, 6'd8, 6'd9, 6'd12, 6'd13, 6'd16, 6'd17, 6'd18,
      6'd24, 6'd25, 6'd32, 6'd33, 6'd38, 6'd41, 6'd52, 6'd55: return 1'b1;
      default: return 1'b0;
    endcase
  endfunction
  function automatic bit [47:0] rframe48(bit [5:0] i_, bit [31:0] status32);
    return {2'b00, i_, status32, crc7(i_, status32), 1'b1};
  endfunction
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin : card
    if (!vif.rst_n) begin : rst
      st <= S_IDLE; bit_cnt <= 0; rsp_cnt <= 0; data_cnt <= 0; prog_cnt <= 0; nib <= 0;
      cstate <= CS_IDLE;
      vif.resp <= 1'b1; vif.resp_valid <= 1'b0; vif.busy <= 1'b0;
      vif.rd_dat <= 4'h0; vif.rd_valid <= 1'b0; vif.data_crc_ok <= 1'b1;
      vif.card_state <= CS_IDLE; vif.resp_type <= 3'd0;
      vif.err <= 1'b0; vif.status <= 3'b000; vif.power_state <= 3'b000;
      vif.ready <= 1'b1; vif.app_cmd <= 1'b0;
    end else begin : run
      vif.resp_valid <= 1'b0;
      vif.rd_valid   <= 1'b0;
      vif.data_crc_ok <= 1'b1;
      vif.power_state <= 3'b001;
      vif.card_state  <= cstate;
      case (st)
        S_IDLE: begin
          vif.ready <= 1'b1; vif.status <= 3'b000;
          if (vif.cmd_valid) begin
            shreg <= {shreg[46:0], vif.cmd};
            bit_cnt <= 1;
            vif.ready <= 1'b0;
            st <= S_CMD;
          end
        end
        S_CMD: begin
          if (vif.cmd_valid) begin
            shreg <= {shreg[46:0], vif.cmd};
            bit_cnt <= bit_cnt + 1;
          end else begin
            if (bit_cnt == 48) st <= S_DECODE;
            else begin st <= S_IDLE; bit_cnt <= 0; end
          end
        end
        S_DECODE: begin
          idx = shreg[45:40];
          arg = shreg[39:8];
          bad_crc     = (shreg[7:1] != crc7(idx, arg)) || shreg[47] !== 1'b0 || shreg[46] !== 1'b1;
          bad_addr    = ((idx==6'd17||idx==6'd18||idx==6'd24||idx==6'd25||idx==6'd32||idx==6'd33) && (int'(arg) >= CAP_BLOCKS));
          bad_illegal = !idx_known(idx) || (idx == 6'd41 && !vif.app_cmd);
          cmd_cnt <= cmd_cnt + 1;
          st32 = (bad_addr ? 32'h8000_0000 : 32'h0) |
                 (bad_crc ? 32'h0080_0000 : 32'h0) |
                 (bad_illegal ? 32'h0040_0000 : 32'h0) |
                 {16'h0, cstate, 9'h0};
          vif.err    <= (bad_addr || bad_crc || bad_illegal);
          vif.status <= (bad_addr || bad_crc || bad_illegal) ? 3'b010 : 3'b001;
          if (bad_addr || bad_crc || bad_illegal) err_cnt <= err_cnt + 1;
          if (idx == 6'd55) vif.app_cmd <= 1'b1;
          else vif.app_cmd <= 1'b0;
          case (idx)
            6'd0: begin // GO_IDLE: no response
              cstate <= CS_IDLE; st <= S_IDLE; bit_cnt <= 0;
            end
            6'd41: begin // ACMD41: R3 (OCR, busy bit set = ready)
              rsp_reg <= {rframe48(6'h3F, ocr), 88'h0}; rsp_len <= 48; rsp_cnt <= 0;
              vif.resp_type <= 3'd3;
              if (!bad_crc && !bad_illegal) cstate <= CS_READY;
              st <= S_RESP;
            end
            6'd2: begin // ALL_SEND_CID: R2 (CID, 136 bits)
              rsp_reg <= {2'b00, 6'h3F, cid, 1'b1}; rsp_len <= 136; rsp_cnt <= 0;
              vif.resp_type <= 3'd2;
              if (!bad_crc) cstate <= CS_IDENT;
              st <= S_RESP;
            end
            6'd9: begin // SEND_CSD: R2 (CSD, 136 bits)
              rsp_reg <= {2'b00, 6'h3F, csd, 1'b1}; rsp_len <= 136; rsp_cnt <= 0;
              vif.resp_type <= 3'd2;
              st <= S_RESP;
            end
            6'd3: begin // SEND_REL_ADDR: R6 ({new RCA, card status})
              rsp_reg <= {rframe48(6'd3, {rca, cstate, 9'h0, 3'h0}), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd6;
              if (!bad_crc) cstate <= CS_STBY;
              st <= S_RESP;
            end
            6'd8: begin // SEND_IF_COND: R7 (echo voltage + check pattern)
              rsp_reg <= {rframe48(6'd8, {20'h0, shreg[19:8]}), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd7;
              st <= S_RESP;
            end
            6'd6: begin // SWITCH_FUNC: R1 + 64-byte status block
              rsp_reg <= {rframe48(6'd6, st32), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              if (!bad_crc) begin data_cnt <= 0; nib <= 0; cstate <= CS_DATA; end
              st <= S_RESP;
            end
            6'd7: begin // SELECT_CARD
              rsp_reg <= {rframe48(6'd7, st32), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              if (!bad_crc) cstate <= CS_TRAN;
              st <= S_RESP;
            end
            6'd17, 6'd18: begin // block read
              rsp_reg <= {rframe48(idx, st32), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              if (!bad_addr && !bad_crc) begin data_cnt <= 0; nib <= 0; cstate <= CS_DATA; end
              st <= S_RESP;
            end
            6'd24, 6'd25: begin // block write
              rsp_reg <= {rframe48(idx, st32), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              if (!bad_addr && !bad_crc) begin data_cnt <= 0; xcrc <= 8'h00; nib <= 0; cstate <= CS_RCV; end
              st <= S_RESP;
            end
            6'd12, 6'd38: begin // STOP_TRANSMISSION / ERASE: R1b + busy
              rsp_reg <= {rframe48(idx, st32), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd4;
              prog_cnt <= (idx == 6'd38) ? ERASE_CYCLES : PROG_CYCLES;
              st <= S_RESP;
            end
            default: begin // generic R1
              rsp_reg <= {rframe48(idx, st32), 88'h0};
              rsp_len <= 48; rsp_cnt <= 0; vif.resp_type <= 3'd1;
              st <= S_RESP;
            end
          endcase
          if (idx != 6'd0) bit_cnt <= 0;
        end
        S_RESP: begin // shift response frame out, MSB first
          vif.resp <= rsp_reg[135];
          vif.resp_valid <= 1'b1;
          rsp_reg <= {rsp_reg[134:0], 1'b1};
          if (rsp_cnt == rsp_len - 1) begin
            rsp_cnt <= 0;
            vif.resp_type <= 3'd0;
            if ((idx == 6'd17 || idx == 6'd18 || idx == 6'd6) && !bad_addr && !bad_crc) begin
              st <= S_RDATA; data_cnt <= 0; nib <= 0;
            end else if ((idx == 6'd24 || idx == 6'd25) && !bad_addr && !bad_crc) begin
              st <= S_WDATA;
            end else if (idx == 6'd12 || idx == 6'd38) begin
              st <= S_PROG; cstate <= CS_PRG;
              vif.busy <= 1'b1;
            end else begin
              st <= S_IDLE;
            end
          end else rsp_cnt <= rsp_cnt + 1;
        end
        S_RDATA: begin // stream one block, nibble-serial (high nibble first)
          vif.rd_valid <= 1'b1;
          if (!nib) begin
            vif.rd_dat <= (idx == 6'd6) ? sw_status[data_cnt][7:4]
                                        : mem[int'(arg) * BLK + data_cnt][7:4];
            nib <= 1'b1;
          end else begin
            vif.rd_dat <= (idx == 6'd6) ? sw_status[data_cnt][3:0]
                                        : mem[int'(arg) * BLK + data_cnt][3:0];
            nib <= 1'b0;
            if (data_cnt == ((idx == 6'd6) ? 63 : BLK - 1)) begin
              st <= S_IDLE; cstate <= CS_TRAN;
            end
            data_cnt <= data_cnt + 1;
          end
        end
        S_WDATA: begin // receive one block + trailing XOR CRC byte, nibble-serial
          if (vif.data_valid) begin
            if (!nib) begin
              cur_nib <= vif.dat;
              nib <= 1'b1;
            end else begin
              nib <= 1'b0;
              if (data_cnt < BLK) begin
                mem[int'(arg) * BLK + data_cnt] <= {cur_nib, vif.dat};
                xcrc <= xcrc ^ {cur_nib, vif.dat};
              end else begin
                vif.data_crc_ok <= ({cur_nib, vif.dat} == xcrc);
                vif.err <= ({cur_nib, vif.dat} != xcrc);
                vif.status <= ({cur_nib, vif.dat} != xcrc) ? 3'b010 : 3'b001;
                st <= S_PROG; cstate <= CS_PRG;
                vif.busy <= 1'b1;
                prog_cnt <= PROG_CYCLES;
              end
              data_cnt <= data_cnt + 1;
            end
          end
        end
        S_PROG: begin // programming / erase busy window
          vif.busy <= 1'b1;
          if (idx == 6'd38 && prog_cnt == 1)
            for (int b = 0; b < 16; b++)
              for (int k = 0; k < BLK; k++)
                mem[b * BLK + k] <= 8'hFF;
          if (prog_cnt <= 1) begin
            vif.busy <= 1'b0;
            cstate <= CS_TRAN; st <= S_IDLE;
          end else prog_cnt <= prog_cnt - 1;
        end
        default: st <= S_IDLE;
      endcase
    end
  end
  final begin : rpt
    `uvm_info("SD_DEV", $sformatf("card: commands=%0d errors=%0d", cmd_cnt, err_cnt), UVM_LOW)
  end
endmodule
`endif
