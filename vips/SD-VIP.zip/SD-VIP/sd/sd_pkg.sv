// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sd_pkg.sv -- SD (SDSC/SDHC) UVM VIP package
// Real SD protocol behavior over sd_if:
//   CMD line : 48-bit command frame {start=0, host=1, idx[5:0], arg[31:0], CRC7, end=1}
//   RESP line: R1/R1b/R3/R6/R7 (48-bit) / R2 (136-bit CID/CSD) responses
//   DAT lines: nibble-serial block read (card->host rd_dat) / write (host->card dat + XOR CRC)
//   busy handshake after write/erase/stop; CMD55 prefix for application commands (ACMD)
`ifndef SD_PKG_SV
`define SD_PKG_SV
package sd_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  `uvm_analysis_imp_decl(_sd_exp)
  `uvm_analysis_imp_decl(_sd_obs)

  // Device model geometry (must match sd_card_dut in tb_top.sv)
  localparam int SD_BLOCK_SIZE = 512;
  localparam int SD_CAP_BLOCKS = 2048; // 1 MiB card
  // R1 status error bits
  localparam bit [31:0] R1_ADDR_OUT_OF_RANGE = 32'h8000_0000;
  localparam bit [31:0] R1_COM_CRC_ERROR     = 32'h0080_0000;
  localparam bit [31:0] R1_ILLEGAL_COMMAND   = 32'h0040_0000;
  // Card states
  localparam bit [3:0] ST_IDLE = 0, ST_READY = 1, ST_IDENT = 2, ST_STBY = 3,
                       ST_TRAN = 4, ST_DATA = 5, ST_RCV = 6, ST_PRG = 7, ST_DIS = 8;

  //============================================================================
  // SD Sequence Item
  //============================================================================
  class sd_seq_item extends uvm_sequence_item;
    `uvm_object_utils(sd_seq_item)
    typedef enum {GO_IDLE, ALL_SEND_CID, SEND_REL_ADDR, SWITCH_FUNC, SELECT_CARD,
                  SEND_IF_COND, SEND_CSD, SEND_STATUS, SET_BLOCKLEN, READ_SINGLE,
                  READ_MULTIPLE, WRITE_SINGLE, WRITE_MULTIPLE, STOP_TRANSMISSION,
                  ERASE_WR_START, ERASE_WR_END, ERASE, APP_CMD, SET_BUS_WIDTH,
                  SD_SEND_OP, IO_RW_DIRECT} cmd_type_e;
    rand cmd_type_e cmd_type;
    rand bit [5:0]  cmd_index;
    rand bit [31:0] cmd_arg;
    rand bit [7:0]  data[];        // write payload bytes (nibble-serialized on DAT)
    rand bit [15:0] block_len;
    rand bit [1:0]  bus_width;     // 0=1-bit, 1=4-bit
    rand bit        is_acmd;       // application command (CMD55 prefix)
    bit        inject_crc_err;     // corrupt command CRC7 (error injection)
    bit        from_host;          // monitor tag: 1=command, 0=response/data
    bit [7:0]  rdata[];            // read payload bytes
    bit [31:0] resp;               // R1/R3/R6/R7 status argument
    bit        resp_valid;
    rand int unsigned delay;
    // Constraints
    // REACHABILITY: dist must list every command the directed sequences send
    // (unlisted dist values get weight 0, which makes send_t(cmd==X) fail for
    // them) and every sd_fsm_cg transition endpoint. Add the init/ACMD/erase/
    // stop commands with a low weight so those bins are generatable.
    constraint c_cmd_dist { cmd_type dist {READ_SINGLE := 20, READ_MULTIPLE := 15,
      WRITE_SINGLE := 20, WRITE_MULTIPLE := 15, SEND_STATUS := 10, SWITCH_FUNC := 5,
      ERASE := 5, GO_IDLE := 2, SELECT_CARD := 3, SET_BLOCKLEN := 3, APP_CMD := 5,
      IO_RW_DIRECT := 2,
      SEND_IF_COND := 1, SEND_CSD := 1, ALL_SEND_CID := 1, SEND_REL_ADDR := 1,
      SET_BUS_WIDTH := 1, SD_SEND_OP := 1, STOP_TRANSMISSION := 1,
      ERASE_WR_START := 1, ERASE_WR_END := 1}; }
    constraint c_bus_width { bus_width inside {0, 1}; } // 1-bit or 4-bit
    constraint c_block_len { block_len inside {512, 1024, 2048, 4096}; }
    constraint c_data_size { data.size() == block_len; }
    constraint c_idx { cmd_index == cmd_index_of(cmd_type); }
    constraint c_acmd { is_acmd == (cmd_type inside {SD_SEND_OP, SET_BUS_WIDTH}); }
    constraint c_data_bl { (cmd_type inside {READ_SINGLE, READ_MULTIPLE, WRITE_SINGLE, WRITE_MULTIPLE}) -> block_len == 512; }
    constraint c_arg_range { (cmd_type inside {READ_SINGLE, READ_MULTIPLE, WRITE_SINGLE, WRITE_MULTIPLE,
                                               ERASE_WR_START, ERASE_WR_END}) -> cmd_arg < SD_CAP_BLOCKS; }
    constraint c_delay { delay inside {[0:10]}; }
    function new(string name = "sd_seq_item"); super.new(name); endfunction

    static function bit [5:0] cmd_index_of(cmd_type_e t);
      case (t)
        GO_IDLE:         return 6'd0;
        ALL_SEND_CID:    return 6'd2;
        SEND_REL_ADDR:   return 6'd3;
        SWITCH_FUNC:     return 6'd6;
        SELECT_CARD:     return 6'd7;
        SEND_IF_COND:    return 6'd8;
        SEND_CSD:        return 6'd9;
        STOP_TRANSMISSION: return 6'd12;
        SEND_STATUS:     return 6'd13;
        SET_BLOCKLEN:    return 6'd16;
        READ_SINGLE:     return 6'd17;
        READ_MULTIPLE:   return 6'd18;
        WRITE_SINGLE:    return 6'd24;
        WRITE_MULTIPLE:  return 6'd25;
        ERASE_WR_START:  return 6'd32;
        ERASE_WR_END:    return 6'd33;
        ERASE:           return 6'd38;
        SD_SEND_OP:      return 6'd41; // ACMD41
        IO_RW_DIRECT:    return 6'd52;
        APP_CMD:         return 6'd55;
        SET_BUS_WIDTH:   return 6'd6;  // ACMD6
        default:         return 6'd0;
      endcase
    endfunction

    function bit is_read_data_cmd();
      return cmd_type inside {READ_SINGLE, READ_MULTIPLE, SWITCH_FUNC};
    endfunction
    function bit is_write_data_cmd();
      return cmd_type inside {WRITE_SINGLE, WRITE_MULTIPLE};
    endfunction
    function bit is_r1b_cmd();
      return cmd_type inside {STOP_TRANSMISSION, ERASE};
    endfunction

    virtual function string convert2string();
      return $sformatf("SD %s: idx=%0d arg=0x%0h bl=%0d bw=%0d acmd=%0b resp=0x%0h",
                       cmd_type.name(), cmd_index, cmd_arg, block_len, bus_width, is_acmd, resp);
    endfunction
    virtual function bit do_compare(uvm_object rhs, uvm_comparer comparer);
      sd_seq_item o;
      if (!$cast(o, rhs)) return 0;
      if (cmd_type != o.cmd_type) return 0;
      if (cmd_index != o.cmd_index || cmd_arg != o.cmd_arg) return 0;
      if (block_len != o.block_len) return 0;
      if (data.size() != o.data.size()) return 0;
      foreach (data[i]) if (data[i] != o.data[i]) return 0;
      return 1;
    endfunction
  endclass : sd_seq_item

  //============================================================================
  // SD Configuration
  //============================================================================
  class sd_cfg extends uvm_object;
    `uvm_object_utils(sd_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1;
    int tCmd = 8;
    int tRead = 50;
    int tWrite = 100;
    int tErase = 500;
    int rsp_timeout = 100000;
    function new(string name = "sd_cfg"); super.new(name); endfunction
  endclass : sd_cfg

  //============================================================================
  // SD Sequencer/Driver/Monitor/Agent
  //============================================================================
  class sd_sequencer extends uvm_sequencer #(sd_seq_item);
    `uvm_component_utils(sd_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass : sd_sequencer

  class sd_driver extends uvm_driver #(sd_seq_item);
    `uvm_component_utils(sd_driver)
    virtual sd_if vif;
    sd_cfg cfg;
    uvm_analysis_port #(sd_seq_item) drv_ap; // expected transactions (e2e scoreboard)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual sd_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "SD virtual interface not found")
      if (!uvm_config_db#(sd_cfg)::get(this, "", "cfg", cfg))
        cfg = sd_cfg::type_id::create("cfg");
      drv_ap = new("drv_ap", this);
    endfunction

    // SD CRC7 (x^7 + x^3 + 1) over the 40-bit {idx, arg} field
    function automatic bit [6:0] crc7(bit [5:0] idx, bit [31:0] arg);
      bit [6:0] crc = 7'h00;
      bit [39:0] stream = {idx, arg};
      for (int i = 39; i >= 0; i--) begin
        bit fb = crc[6] ^ stream[i];
        crc = {crc[5:0], 1'b0};
        if (fb) crc = crc ^ 7'h09;
      end
      return crc;
    endfunction

    task run_phase(uvm_phase phase);
      sd_seq_item req;
      vif.drv_cb.cmd <= 1'b1; // CMD line idle high
      vif.drv_cb.cmd_dir <= 1'b0;
      vif.drv_cb.dat_dir <= 1'b0;
      vif.drv_cb.cmd_valid <= 1'b0;
      vif.drv_cb.data_valid <= 1'b0;
      vif.drv_cb.data_end <= 1'b0;
      vif.drv_cb.valid <= 1'b0;
      vif.drv_cb.speed_mode <= 3'b000;
      vif.drv_cb.bus_width <= 3'b001;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        `uvm_info(get_type_name(), $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
        repeat (req.delay) @(vif.drv_cb);
        drive_cmd(req);
        drv_ap.write(req);
        seq_item_port.item_done();
      end
    endtask

    // Send one 48-bit command frame on the CMD line
    task automatic send_frame(bit [5:0] idx, bit [31:0] arg, bit corrupt);
      bit [47:0] frame;
      bit [6:0]  crc;
      crc = crc7(idx, arg);
      if (corrupt) crc = crc ^ 7'h55;
      frame = {1'b0, 1'b1, idx, arg, crc, 1'b1};
      vif.drv_cb.cmd_index <= idx;
      vif.drv_cb.cmd_arg   <= arg;
      vif.drv_cb.valid     <= 1'b1;
      for (int i = 47; i >= 0; i--) begin
        @(vif.drv_cb);
        vif.drv_cb.cmd <= frame[i];
        vif.drv_cb.cmd_dir <= 1'b0;
        vif.drv_cb.cmd_valid <= 1'b1;
      end
      @(vif.drv_cb);
      vif.drv_cb.cmd <= 1'b1;
      vif.drv_cb.cmd_valid <= 1'b0;
      vif.drv_cb.valid <= 1'b0;
    endtask

    // Full command/response (+optional data) exchange
    task automatic drive_cmd(sd_seq_item req);
      vif.drv_cb.bus_width <= (req.bus_width == 2'd0) ? 3'b001 : 3'b010;
      // ACMD commands need the CMD55 prefix first
      if (req.is_acmd && req.cmd_type != sd_seq_item::APP_CMD) begin
        send_frame(6'd55, 32'h0001_0000, 1'b0);
        collect_response(req);
      end
      send_frame(req.cmd_index, req.cmd_arg, req.inject_crc_err);
      // CMD0 has no response
      if (req.cmd_type == sd_seq_item::GO_IDLE) begin
        req.resp = 32'h0; req.resp_valid = 1'b0;
        req.data = new[0];
        repeat (cfg.tCmd) @(vif.drv_cb);
        return;
      end
      collect_response(req);
      if (req.is_r1b_cmd()) wait_busy(req);
      if (req.is_read_data_cmd()) begin
        collect_read_data(req);
        req.data = new[0];
      end else if (req.is_write_data_cmd()) begin
        send_write_data(req);
        wait_busy(req);
      end else begin
        req.data = new[0];
      end
    endtask

    // Collect a response frame from the RESP line (48 or 136 bits)
    task automatic collect_response(sd_seq_item req);
      bit [135:0] rframe = 136'h0;
      int nbits = 0;
      int guard = 0;
      while (vif.drv_cb.resp_valid !== 1'b1 && guard < cfg.rsp_timeout) begin
        @(vif.drv_cb); guard++;
      end
      if (guard >= cfg.rsp_timeout) begin
        `uvm_error(get_type_name(), "Timeout waiting for SD response")
        req.resp = 32'hFFFF_FFFF; req.resp_valid = 1'b0;
        return;
      end
      while (vif.drv_cb.resp_valid === 1'b1 && guard < cfg.rsp_timeout) begin
        rframe = {rframe[134:0], vif.drv_cb.resp};
        nbits++;
        @(vif.drv_cb); guard++;
      end
      if (nbits >= 48) begin
        rframe = rframe >> (nbits - 48);
        req.resp = rframe[39:8];
        req.resp_valid = 1'b1;
      end else begin
        req.resp = 32'hFFFF_FFFF; req.resp_valid = 1'b0;
      end
    endtask

    // Collect a read data block from the DAT lines (card->host, nibble-serial)
    task automatic collect_read_data(sd_seq_item req);
      int nbytes = (req.cmd_type == sd_seq_item::SWITCH_FUNC) ? 64 : SD_BLOCK_SIZE;
      bit [7:0] rd_q[$];
      bit [3:0] hi_nib;
      bit have_hi = 0;
      int guard = 0;
      while (rd_q.size() < nbytes && guard < cfg.rsp_timeout) begin
        @(vif.drv_cb); guard++;
        if (vif.drv_cb.rd_valid === 1'b1) begin
          if (!have_hi) begin hi_nib = vif.drv_cb.rd_dat; have_hi = 1; end
          else begin rd_q.push_back({hi_nib, vif.drv_cb.rd_dat}); have_hi = 0; end
        end
      end
      if (guard >= cfg.rsp_timeout)
        `uvm_error(get_type_name(), "Timeout waiting for SD read data")
      req.rdata = new[rd_q.size()];
      foreach (rd_q[i]) req.rdata[i] = rd_q[i];
    endtask

    // Stream a write data block + XOR CRC byte on the DAT lines (nibble-serial)
    task automatic send_write_data(sd_seq_item req);
      bit [7:0] xcrc = 8'h00;
      bit [7:0] payload[$];
      foreach (req.data[i]) begin xcrc = xcrc ^ req.data[i]; payload.push_back(req.data[i]); end
      payload.push_back(req.inject_crc_err ? (xcrc ^ 8'hFF) : xcrc);
      vif.drv_cb.dat_dir <= 1'b0;
      vif.drv_cb.valid <= 1'b1;
      foreach (payload[i]) begin
        @(vif.drv_cb);
        vif.drv_cb.dat <= payload[i][7:4];
        vif.drv_cb.data_valid <= 1'b1;
        if (i == payload.size() - 1) vif.drv_cb.data_end <= 1'b0;
        @(vif.drv_cb);
        vif.drv_cb.dat <= payload[i][3:0];
        vif.drv_cb.data_valid <= 1'b1;
        if (i == payload.size() - 1) vif.drv_cb.data_end <= 1'b1;
      end
      @(vif.drv_cb);
      vif.drv_cb.data_valid <= 1'b0;
      vif.drv_cb.data_end <= 1'b0;
      vif.drv_cb.valid <= 1'b0;
    endtask

    // Busy handshake: wait for programming to start, then for release
    task automatic wait_busy(sd_seq_item req);
      int guard = 0;
      while (guard < 64) begin
        @(vif.drv_cb); guard++;
        if (vif.drv_cb.card_state === ST_PRG || vif.drv_cb.busy === 1'b1) break;
      end
      guard = 0;
      while (guard < cfg.rsp_timeout) begin
        @(vif.drv_cb); guard++;
        if (vif.drv_cb.busy === 1'b0 && vif.drv_cb.card_state !== ST_PRG) return;
      end
      `uvm_error(get_type_name(), "Timeout waiting for card busy release")
    endtask
  endclass : sd_driver

  class sd_monitor extends uvm_monitor;
    `uvm_component_utils(sd_monitor)
    virtual sd_if vif;
    uvm_analysis_port #(sd_seq_item) item_collected_port;
    int unsigned txn_count = 0;
    sd_seq_item pending_wr = null;
    bit saw_cmd55 = 0;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual sd_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "SD virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      fork
        collect_cmd();
        collect_resp();
        collect_wdata();
        collect_rdata();
      join
    endtask

    // Decode 48-bit command frames from the CMD line
    task automatic collect_cmd();
      bit [47:0] frame = 48'h0;
      int nbits = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) begin nbits = 0; pending_wr = null; saw_cmd55 = 0; continue; end
        if (vif.mon_cb.cmd_valid === 1'b1) begin
          frame = {frame[46:0], vif.mon_cb.cmd};
          nbits++;
        end else if (nbits > 0) begin
          decode_cmd(frame, nbits);
          nbits = 0; frame = 48'h0;
        end
      end
    endtask

    function automatic void decode_cmd(bit [47:0] frame, int nbits);
      sd_seq_item item;
      bit [5:0] idx;
      if (nbits < 48) begin
        `uvm_warning(get_type_name(), $sformatf("Short command frame (%0d bits) ignored", nbits))
        return;
      end
      frame = frame >> (nbits - 48);
      idx = frame[45:40];
      item = sd_seq_item::type_id::create("cmd_item");
      item.cmd_index = idx;
      item.cmd_arg   = frame[39:8];
      item.from_host = 1'b1;
      item.block_len = 16'd512;
      // map index back to command type (idx 6 is CMD6 or ACMD6 depending on CMD55 prefix)
      begin
        sd_seq_item::cmd_type_e t = sd_seq_item::GO_IDLE;
        sd_seq_item::cmd_type_e cand[21] = '{
          sd_seq_item::GO_IDLE, sd_seq_item::ALL_SEND_CID, sd_seq_item::SEND_REL_ADDR,
          sd_seq_item::SWITCH_FUNC, sd_seq_item::SELECT_CARD, sd_seq_item::SEND_IF_COND,
          sd_seq_item::SEND_CSD, sd_seq_item::SEND_STATUS, sd_seq_item::SET_BLOCKLEN,
          sd_seq_item::READ_SINGLE, sd_seq_item::READ_MULTIPLE, sd_seq_item::WRITE_SINGLE,
          sd_seq_item::WRITE_MULTIPLE, sd_seq_item::STOP_TRANSMISSION, sd_seq_item::ERASE_WR_START,
          sd_seq_item::ERASE_WR_END, sd_seq_item::ERASE, sd_seq_item::APP_CMD,
          sd_seq_item::SET_BUS_WIDTH, sd_seq_item::SD_SEND_OP, sd_seq_item::IO_RW_DIRECT};
        foreach (cand[i])
          if (sd_seq_item::cmd_index_of(cand[i]) == idx) t = cand[i];
        if (idx == 6'd6 && saw_cmd55) t = sd_seq_item::SET_BUS_WIDTH;
        item.cmd_type = t;
        item.is_acmd  = saw_cmd55;
      end
      saw_cmd55 = (idx == 6'd55);
      if (item.is_write_data_cmd())
        pending_wr = item; // publish after the write data burst
      else begin
        item_collected_port.write(item);
        txn_count++;
      end
      `uvm_info(get_type_name(), $sformatf("Monitored CMD: %s", item.convert2string()), UVM_HIGH)
    endfunction

    // Collect write data bursts (nibble-serial) and complete the pending write item
    task automatic collect_wdata();
      bit [3:0] hi_nib;
      bit have_hi = 0;
      bit [7:0] burst[$];
      bit in_burst = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) begin burst.delete(); in_burst = 0; have_hi = 0; continue; end
        if (vif.mon_cb.data_valid === 1'b1) begin
          if (!have_hi) begin hi_nib = vif.mon_cb.dat; have_hi = 1; end
          else begin burst.push_back({hi_nib, vif.mon_cb.dat}); have_hi = 0; end
          in_burst = 1;
        end else if (in_burst && !have_hi) begin
          in_burst = 0;
          if (pending_wr != null) begin
            int n = (burst.size() > 0) ? burst.size() - 1 : 0; // drop trailing CRC byte
            pending_wr.data = new[n];
            for (int i = 0; i < n; i++) pending_wr.data[i] = burst[i];
            pending_wr.block_len = n;
            item_collected_port.write(pending_wr);
            txn_count++;
            pending_wr = null;
          end
          burst.delete();
        end
      end
    endtask

    // Decode response frames from the RESP line
    task automatic collect_resp();
      bit [135:0] rframe = 136'h0;
      int nbits = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) begin nbits = 0; rframe = 136'h0; continue; end
        if (vif.mon_cb.resp_valid === 1'b1) begin
          rframe = {rframe[134:0], vif.mon_cb.resp};
          nbits++;
        end else if (nbits > 0) begin
          sd_seq_item item = sd_seq_item::type_id::create("rsp_item");
          bit [135:0] f = rframe >> ((nbits >= 48) ? nbits - 48 : 0);
          item.from_host = 1'b0;
          item.cmd_index = f[45:40];
          item.resp      = f[39:8];
          item.resp_valid = 1'b1;
          item_collected_port.write(item);
          txn_count++;
          nbits = 0; rframe = 136'h0;
        end
      end
    endtask

    // Decode read data bursts from the DAT lines (card->host, nibble-serial)
    task automatic collect_rdata();
      bit [3:0] hi_nib;
      bit have_hi = 0;
      bit [7:0] burst[$];
      bit in_burst = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) begin burst.delete(); in_burst = 0; have_hi = 0; continue; end
        if (vif.mon_cb.rd_valid === 1'b1) begin
          if (!have_hi) begin hi_nib = vif.mon_cb.rd_dat; have_hi = 1; end
          else begin burst.push_back({hi_nib, vif.mon_cb.rd_dat}); have_hi = 0; end
          in_burst = 1;
        end else if (in_burst && !have_hi) begin
          sd_seq_item item = sd_seq_item::type_id::create("rd_item");
          in_burst = 0;
          item.from_host = 1'b0;
          item.block_len = burst.size();
          item.rdata = new[burst.size()];
          foreach (burst[i]) item.rdata[i] = burst[i];
          item_collected_port.write(item);
          txn_count++;
          burst.delete();
        end
      end
    endtask
  endclass : sd_monitor

  class sd_agent extends uvm_agent;
    `uvm_component_utils(sd_agent)
    sd_sequencer sqr;
    sd_driver    drv;
    sd_monitor   mon;
    sd_cfg       cfg;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(sd_cfg)::get(this, "", "cfg", cfg))
        cfg = sd_cfg::type_id::create("cfg");
      uvm_config_db#(sd_cfg)::set(this, "*", "cfg", cfg);
      mon = sd_monitor::type_id::create("mon", this);
      if (cfg.is_active == UVM_ACTIVE) begin
        sqr = sd_sequencer::type_id::create("sqr", this);
        drv = sd_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.is_active == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass : sd_agent

  //============================================================================
  // SD Sequences
  //============================================================================
  class sd_base_seq extends uvm_sequence #(sd_seq_item);
    `uvm_object_utils(sd_base_seq)
    function new(string name = "sd_base_seq"); super.new(name); endfunction
    task automatic send(sd_seq_item item);
      start_item(item);
      finish_item(item);
    endtask
    task automatic send_t(sd_seq_item::cmd_type_e t, bit [31:0] arg = 32'h0);
      sd_seq_item item = sd_seq_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { cmd_type == t; cmd_arg == arg; })
        `uvm_error(get_type_name(), "Rand failed");
      finish_item(item);
    endtask
  endclass : sd_base_seq

  // Random read/write mix (normal traffic)
  class sd_rw_seq extends sd_base_seq;
    `uvm_object_utils(sd_rw_seq)
    rand int num_trans = 20;
    function new(string name = "sd_rw_seq"); super.new(name); endfunction
    task body();
      sd_seq_item item;
      repeat (num_trans) begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {sd_seq_item::READ_SINGLE, sd_seq_item::WRITE_SINGLE};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : sd_rw_seq

  // Directed: SD initialization chain CMD0 -> CMD8 -> ACMD41 -> CMD2 -> CMD3 -> CMD7
  class sd_init_seq extends sd_base_seq;
    `uvm_object_utils(sd_init_seq)
    function new(string name = "sd_init_seq"); super.new(name); endfunction
    task body();
      send_t(sd_seq_item::GO_IDLE, 32'h0);
      send_t(sd_seq_item::SEND_IF_COND, 32'h0000_01AA); // CMD8: 2.7-3.6V + check pattern
      send_t(sd_seq_item::SD_SEND_OP, 32'h40FF_8000);   // ACMD41: HCS + OCR window
      send_t(sd_seq_item::ALL_SEND_CID, 32'h0);         // CMD2
      send_t(sd_seq_item::SEND_REL_ADDR, 32'h0);        // CMD3: R6 RCA
      send_t(sd_seq_item::SELECT_CARD, 32'h0001_0000);  // CMD7
      send_t(sd_seq_item::SET_BLOCKLEN, 32'd512);       // CMD16
    endtask
  endclass : sd_init_seq

  // Directed: block reads (CMD17/CMD18)
  class sd_read_seq extends sd_base_seq;
    `uvm_object_utils(sd_read_seq)
    rand int num_trans = 8;
    function new(string name = "sd_read_seq"); super.new(name); endfunction
    task body();
      repeat (num_trans) begin
        sd_seq_item item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {sd_seq_item::READ_SINGLE, sd_seq_item::READ_MULTIPLE};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : sd_read_seq

  // Directed: block writes (CMD24/CMD25)
  class sd_write_seq extends sd_base_seq;
    `uvm_object_utils(sd_write_seq)
    rand int num_trans = 8;
    function new(string name = "sd_write_seq"); super.new(name); endfunction
    task body();
      repeat (num_trans) begin
        sd_seq_item item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {sd_seq_item::WRITE_SINGLE, sd_seq_item::WRITE_MULTIPLE};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : sd_write_seq

  // Directed: SWITCH_FUNC status read + ACMD6 bus-width switch + CSD/CID dump
  class sd_config_seq extends sd_base_seq;
    `uvm_object_utils(sd_config_seq)
    function new(string name = "sd_config_seq"); super.new(name); endfunction
    task body();
      send_t(sd_seq_item::SWITCH_FUNC, 32'h00FF_FFF0); // CMD6 mode 0: query
      send_t(sd_seq_item::SET_BUS_WIDTH, 32'd2);       // ACMD6: 4-bit bus
      send_t(sd_seq_item::SEND_CSD, 32'h0001_0000);    // CMD9: R2 CSD
      send_t(sd_seq_item::SEND_STATUS, 32'h0001_0000); // CMD13
    endtask
  endclass : sd_config_seq

  // Directed erase: CMD32/CMD33 range + CMD38
  class sd_erase_seq extends sd_base_seq;
    `uvm_object_utils(sd_erase_seq)
    function new(string name = "sd_erase_seq"); super.new(name); endfunction
    task body();
      send_t(sd_seq_item::ERASE_WR_START, 32'd0);
      send_t(sd_seq_item::ERASE_WR_END, 32'd15);
      send_t(sd_seq_item::ERASE, 32'h0);
    endtask
  endclass : sd_erase_seq

  // Directed error: out-of-range address, illegal command, command CRC error
  class sd_error_seq extends sd_base_seq;
    `uvm_object_utils(sd_error_seq)
    rand int num_trans = 4;
    function new(string name = "sd_error_seq"); super.new(name); endfunction
    task body();
      repeat (num_trans) begin
        sd_seq_item item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {sd_seq_item::READ_SINGLE, sd_seq_item::WRITE_SINGLE};
          cmd_arg inside {[SD_CAP_BLOCKS : SD_CAP_BLOCKS + 255]};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      // ACMD41 without CMD55 prefix is caught by the card (illegal-command bit)
      begin
        sd_seq_item item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == sd_seq_item::SEND_STATUS; })
          `uvm_error(get_type_name(), "Rand failed");
        item.inject_crc_err = 1'b1; // corrupted command CRC7
        finish_item(item);
      end
    endtask
  endclass : sd_error_seq

  // Directed reset: CMD0 mid-traffic then re-initialize
  class sd_reset_seq extends sd_base_seq;
    `uvm_object_utils(sd_reset_seq)
    function new(string name = "sd_reset_seq"); super.new(name); endfunction
    task body();
      sd_init_seq init = sd_init_seq::type_id::create("init");
      send_t(sd_seq_item::READ_SINGLE, 32'd0);
      send_t(sd_seq_item::GO_IDLE, 32'h0);
      init.start(m_sequencer);
      send_t(sd_seq_item::READ_SINGLE, 32'd0); // traffic after re-init
    endtask
  endclass : sd_reset_seq

  // Back-to-back: zero idle cycles between commands
  class sd_b2b_seq extends sd_base_seq;
    `uvm_object_utils(sd_b2b_seq)
    rand int num_trans = 16;
    function new(string name = "sd_b2b_seq"); super.new(name); endfunction
    task body();
      repeat (num_trans) begin
        sd_seq_item item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {sd_seq_item::READ_SINGLE, sd_seq_item::WRITE_SINGLE,
                           sd_seq_item::SEND_STATUS};
          delay == 0;
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : sd_b2b_seq

  // Stress: heavy randomized traffic
  class sd_stress_seq extends sd_base_seq;
    `uvm_object_utils(sd_stress_seq)
    rand int num_trans = 48;
    function new(string name = "sd_stress_seq"); super.new(name); endfunction
    task body();
      sd_seq_item item;
      repeat (num_trans) begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {sd_seq_item::READ_SINGLE, sd_seq_item::WRITE_SINGLE,
                           sd_seq_item::SEND_STATUS, sd_seq_item::READ_MULTIPLE,
                           sd_seq_item::WRITE_MULTIPLE};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : sd_stress_seq

  // Corner: first/last block, SET_BLOCKLEN extremes, multiple-block + STOP_TRANSMISSION
  class sd_corner_seq extends sd_base_seq;
    `uvm_object_utils(sd_corner_seq)
    function new(string name = "sd_corner_seq"); super.new(name); endfunction
    task body();
      send_t(sd_seq_item::WRITE_SINGLE, 32'd0);                // first block
      send_t(sd_seq_item::READ_SINGLE, 32'd0);
      send_t(sd_seq_item::WRITE_SINGLE, SD_CAP_BLOCKS - 1);    // last block
      send_t(sd_seq_item::READ_SINGLE, SD_CAP_BLOCKS - 1);
      send_t(sd_seq_item::SET_BLOCKLEN, 32'd4096);             // max length register
      send_t(sd_seq_item::SET_BLOCKLEN, 32'd512);              // restore
      send_t(sd_seq_item::READ_MULTIPLE, SD_CAP_BLOCKS - 4);
      send_t(sd_seq_item::STOP_TRANSMISSION, 32'h0);           // CMD12
      send_t(sd_seq_item::IO_RW_DIRECT, 32'h0);                // CMD52 (SDIO)
    endtask
  endclass : sd_corner_seq

  // Coverage: every command type (preserved API)
  class sd_cov_cmd_seq extends sd_base_seq;
    `uvm_object_utils(sd_cov_cmd_seq)
    function new(string name = "sd_cov_cmd_seq"); super.new(name); endfunction
    task body();
      sd_seq_item item;
      sd_seq_item::cmd_type_e cmds[21] = '{
        sd_seq_item::GO_IDLE, sd_seq_item::ALL_SEND_CID, sd_seq_item::SEND_REL_ADDR,
        sd_seq_item::SWITCH_FUNC, sd_seq_item::SELECT_CARD, sd_seq_item::SEND_IF_COND,
        sd_seq_item::SEND_CSD, sd_seq_item::SEND_STATUS, sd_seq_item::SET_BLOCKLEN,
        sd_seq_item::READ_SINGLE, sd_seq_item::READ_MULTIPLE, sd_seq_item::WRITE_SINGLE,
        sd_seq_item::WRITE_MULTIPLE, sd_seq_item::STOP_TRANSMISSION, sd_seq_item::ERASE_WR_START,
        sd_seq_item::ERASE_WR_END, sd_seq_item::ERASE, sd_seq_item::APP_CMD,
        sd_seq_item::SET_BUS_WIDTH, sd_seq_item::SD_SEND_OP, sd_seq_item::IO_RW_DIRECT};
      foreach (cmds[i]) begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == cmds[i]; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : sd_cov_cmd_seq

  // Coverage: 1-bit and 4-bit bus widths
  class sd_cov_bw_seq extends sd_base_seq;
    `uvm_object_utils(sd_cov_bw_seq)
    function new(string name = "sd_cov_bw_seq"); super.new(name); endfunction
    task body();
      sd_seq_item item;
      for (int bw = 0; bw < 2; bw++) begin
        item = sd_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bus_width == bw; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : sd_cov_bw_seq

  // REACHABILITY: deterministic command chain hitting every sd_fsm_cg
  // transition bin (init_chain / acmd / ident / wr_status / rd_wr / mult_stop).
  // The ACMD pair is driven as an explicit CMD55 item followed by ACMD41 so
  // the monitor observes APP_CMD => SD_SEND_OP back to back.
  class sd_fsm_seq extends sd_base_seq;
    `uvm_object_utils(sd_fsm_seq)
    function new(string name = "sd_fsm_seq"); super.new(name); endfunction
    task body();
      send_t(sd_seq_item::GO_IDLE, 32'h0);
      send_t(sd_seq_item::SEND_IF_COND, 32'h0000_01AA);      // init_chain
      send_t(sd_seq_item::APP_CMD, 32'h0001_0000);
      send_t(sd_seq_item::SD_SEND_OP, 32'h40FF_8000);        // acmd
      send_t(sd_seq_item::ALL_SEND_CID, 32'h0);
      send_t(sd_seq_item::SEND_REL_ADDR, 32'h0);             // ident
      send_t(sd_seq_item::WRITE_SINGLE, 32'd0);
      send_t(sd_seq_item::SEND_STATUS, 32'h0001_0000);       // wr_status
      send_t(sd_seq_item::READ_SINGLE, 32'd0);
      send_t(sd_seq_item::WRITE_SINGLE, 32'd0);              // rd_wr
      send_t(sd_seq_item::READ_MULTIPLE, 32'd0);
      send_t(sd_seq_item::STOP_TRANSMISSION, 32'h0);         // mult_stop
    endtask
  endclass : sd_fsm_seq

  // Regression mix: init + every directed sequence in order
  class sd_regression_mix_seq extends sd_base_seq;
    `uvm_object_utils(sd_regression_mix_seq)
    function new(string name = "sd_regression_mix_seq"); super.new(name); endfunction
    task body();
      sd_init_seq   i  = sd_init_seq::type_id::create("i");
      sd_config_seq cf = sd_config_seq::type_id::create("cf");
      sd_read_seq   r  = sd_read_seq::type_id::create("r");
      sd_write_seq  w  = sd_write_seq::type_id::create("w");
      sd_erase_seq  e  = sd_erase_seq::type_id::create("e");
      sd_error_seq  er = sd_error_seq::type_id::create("er");
      sd_reset_seq  rs = sd_reset_seq::type_id::create("rs");
      sd_b2b_seq    b  = sd_b2b_seq::type_id::create("b");
      sd_corner_seq c  = sd_corner_seq::type_id::create("c");
      sd_stress_seq s  = sd_stress_seq::type_id::create("s");
      sd_fsm_seq    f  = sd_fsm_seq::type_id::create("f");
      `uvm_info(get_type_name(), "=== SD regression mix: init/config/rw/erase/error/reset/b2b/corner/stress ===", UVM_LOW)
      i.start(m_sequencer);
      cf.start(m_sequencer);
      r.num_trans = 4;  r.start(m_sequencer);
      w.num_trans = 4;  w.start(m_sequencer);
      e.start(m_sequencer);
      er.num_trans = 2; er.start(m_sequencer);
      rs.start(m_sequencer);
      b.num_trans = 8;  b.start(m_sequencer);
      c.start(m_sequencer);
      f.start(m_sequencer);
      s.num_trans = 16; s.start(m_sequencer);
    endtask
  endclass : sd_regression_mix_seq
endpackage : sd_pkg
`endif
