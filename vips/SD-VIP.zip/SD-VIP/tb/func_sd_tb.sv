// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_sd_tb.sv -- self-checking functional test for the SD card model
// (sd_card_dut in tb_top.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py SD-VIP
//
// Model contract (from tb_top.sv):
//   * commands: 48 bits on cmd, MSB first, one per clock with cmd_valid
//     {0, 1, index, argument, CRC7, 1}; other lengths are ignored.
//   * responses on resp/resp_valid: R1 {0, 0, index, status, CRC7, 1}
//     (ADDRESS_OUT_OF_RANGE 31, COM_CRC_ERROR 23, ILLEGAL_COMMAND 22,
//     CURRENT_STATE 12:9), R2 (CID/CSD), R3 (OCR C0FF8000), R6 (RCA 0x0001),
//     R7 (CMD8 echoes argument[11:0]).
//   * identification: CMD0 -> idle, CMD8, CMD55 + ACMD41 -> ready, CMD2 ->
//     ident, CMD3 -> stby, CMD7 -> tran; CMD9 returns the CSD.
//   * 4-bit data, high nibble first: CMD17/18 read 512 bytes of block arg
//     (unwritten byte = address[7:0] ^ 0xA5), CMD6 returns 64 status bytes
//     (byte i = i). CMD24/25 take 512 bytes and one XOR checksum byte (bad
//     checksum -> err, data_crc_ok low), then busy 32 clocks. CMD38 erases
//     blocks 0-15 (busy 64), CMD12 busy 32. Block address >= 2048 is out of
//     range; unknown indices and ACMD41 without CMD55 are illegal.
// The command CRC7 covers {0, 1, index, argument}; R2 is {0, 0, 111111,
// register[127:1]} with the register's CRC7 over [127:8] in [7:1]; R6 puts
// CURRENT_STATE in bits 12:9 of its 16-bit status field.

module func_sd_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [3:0] CS_IDLE = 0, CS_READY = 1, CS_IDENT = 2, CS_STBY = 3, CS_TRAN = 4, CS_PRG = 7;
  int checks = 0, fails = 0, xfails = 0;

  logic       clk = 1'b0, rst_n = 1'b0, cmd = 1'b1, cmd_valid = 1'b0, dvalid = 1'b0;
  logic [3:0] dat = '0;
  wire        resp, resp_valid, rd_valid, busy, crc_ok, err, ready, app_cmd;
  wire  [3:0] rd_dat, card_state;
  wire  [2:0] resp_type, status, pwr;

  always #5 clk = ~clk;

  sd_card_dut u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_cmd(cmd), .vif_dat(dat), .vif_cmd_valid(cmd_valid),
    .vif_data_valid(dvalid), .vif_resp(resp), .vif_resp_valid(resp_valid), .vif_rd_dat(rd_dat),
    .vif_rd_valid(rd_valid), .vif_busy(busy), .vif_data_crc_ok(crc_ok), .vif_card_state(card_state),
    .vif_resp_type(resp_type), .vif_err(err), .vif_status(status), .vif_power_state(pwr),
    .vif_ready(ready), .vif_app_cmd(app_cmd)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic bit [6:0] crc7(input bit [39:0] s);
    bit [6:0] c = 0;
    for (int b = 39; b >= 0; b--) begin
      bit fb = c[6] ^ s[b];
      c = c << 1;
      if (fb) c ^= 7'h09;
    end
    return c;
  endfunction

  function automatic bit [6:0] crc7r2(input bit [119:0] s);
    bit [6:0] c = 0;
    for (int b = 119; b >= 0; b--) begin
      bit fb = c[6] ^ s[b];
      c = c << 1;
      if (fb) c ^= 7'h09;
    end
    return c;
  endfunction

  // card -> host capture; read data reassembled from nibbles, high first
  bit         rbits[$];
  logic [7:0] rd[$];
  logic [3:0] hi;
  bit         have_hi;
  int         err_seen, busy_len;
  always @(posedge clk) if (rst_n) begin
    if (resp_valid === 1'b1) rbits.push_back(resp);
    if (rd_valid === 1'b1) begin
      if (!have_hi) begin hi = rd_dat; have_hi = 1; end
      else begin rd.push_back({hi, rd_dat}); have_hi = 0; end
    end
    if (err === 1'b1) err_seen = 1;
    if (busy === 1'b1) busy_len++;
  end

  task automatic send_cmd(input [5:0] idx, input [31:0] arg, input int nbits = 48,
                          input [47:0] xor_mask = 0);
    bit [47:0] f;
    f = {2'b01, idx, arg, crc7({2'b01, idx, arg}), 1'b1} ^ xor_mask;
    rbits.delete(); rd.delete(); have_hi = 0; err_seen = 0; busy_len = 0;
    for (int i = 47; i >= 48 - nbits; i--) begin
      @(negedge clk); cmd_valid = 1; cmd = f[i];
    end
    @(negedge clk); cmd_valid = 0; cmd = 1;
  endtask

  task automatic wait_idle(input int max = 5000);
    int t = 0;
    @(negedge clk); @(negedge clk);
    while (!(u_dut.st == 0) && t < max) begin @(negedge clk); t++; end
    repeat (2) @(negedge clk);
  endtask

  task automatic cmd_wait(input [5:0] idx, input [31:0] arg);
    send_cmd(idx, arg); wait_idle();
  endtask

  function automatic bit [47:0] r48();
    bit [47:0] r = '0;
    for (int i = 0; i < 48 && i < rbits.size(); i++) r[47 - i] = rbits[i];
    return r;
  endfunction

  function automatic bit [135:0] r136();
    bit [135:0] r = '0;
    foreach (rbits[i]) if (i < 136) r[135 - i] = rbits[i];
    return r;
  endfunction

  bit [31:0] rstat;
  function automatic bit r1_ok(input [5:0] idx);
    bit [47:0] r = r48();
    rstat = r[39:8];
    return rbits.size() == 48 && r[47:46] == 2'b00 && r[45:40] == idx && r[0] == 1'b1 &&
           r[7:1] == crc7(r[47:8]);
  endfunction

  task automatic write_blk(input [5:0] idx, input [31:0] blkno, input logic [7:0] b[512], input bit bad = 0);
    logic [7:0] x = 0;
    send_cmd(idx, blkno);
    while (u_dut.st != 5) @(negedge clk);
    for (int i = 0; i < 513; i++) begin
      logic [7:0] v;
      v = (i < 512) ? b[i] : (x ^ bad);
      if (i < 512) x ^= b[i];
      @(negedge clk); dvalid = 1; dat = v[7:4];
      @(negedge clk); dvalid = 1; dat = v[3:0];
    end
    @(negedge clk); dvalid = 0;
    wait_idle();
  endtask

  bit ok;
  logic [7:0] blk[512];
  bit [135:0] r2;
  bit [47:0]  r;

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1;
    repeat (2) @(negedge clk);
    chk(ready && card_state == CS_IDLE, "ready, idle state after reset");

    cmd_wait(13, 0);
    chk(r1_ok(13), "CMD13 answered with R1");
    chk(!rstat[23], "command with the specified CRC7 is accepted");

    // identification
    cmd_wait(0, 0);
    chk(rbits.size() == 0 && card_state == CS_IDLE, "CMD0: no response, idle");
    cmd_wait(8, 32'h0000_01AA);
    chk(r1_ok(8) && rstat[11:0] == 12'h1AA, "CMD8: R7 echoes voltage and check pattern 0x1AA");
    cmd_wait(41, 32'h4030_0000);
    chk(card_state == CS_IDLE && err_seen, "ACMD41 without CMD55 is rejected (ILLEGAL_COMMAND)");
    cmd_wait(55, 0);
    chk(r1_ok(55) && app_cmd, "CMD55 sets APP_CMD");
    cmd_wait(41, 32'h4030_0000);
    r = r48();
    chk(rbits.size() == 48 && r[45:40] == 6'h3F && r[39:8] == 32'hC0FF_8000, "ACMD41: R3 with OCR");
    chk(card_state == CS_READY && !app_cmd, "ACMD41 moves to ready, APP_CMD cleared");
    cmd_wait(2, 0);
    r2 = r136();
    chk(rbits.size() == 136 && r2[127:8] == 120'h1B5344_00010203_405A5A5A_202609, "CMD2: R2 with the CID");
    chk(r2[7:1] == crc7r2(r2[127:8]) && r2[0], "R2 ends with the CID CRC7 and the end bit");
    chk(r2[135:128] == 8'b0011_1111, "R2 starts with 0, 0, 111111");
    chk(card_state == CS_IDENT, "CMD2 moves to ident");
    cmd_wait(3, 0);
    r = r48();
    chk(rbits.size() == 48 && r[45:40] == 6'd3 && r[39:24] == 16'h0001, "CMD3: R6 publishes RCA 0x0001");
    chk(r[8 + 9 +: 4] == CS_IDENT && r[8 + 13 +: 3] == 0, "R6 reports CURRENT_STATE (ident) in bits 12:9, no error bits");
    chk(card_state == CS_STBY, "CMD3 moves to stby");
    cmd_wait(9, 32'h0001_0000);
    r2 = r136();
    chk(rbits.size() == 136 && r2[127:8] == 120'h400E0032_0F5903FF_FFFFFFFF_8A4040 &&
        r2[7:1] == crc7r2(r2[127:8]) && r2[0], "CMD9: R2 with the CSD and its CRC7");
    cmd_wait(7, 32'h0001_0000);
    chk(r1_ok(7) && rstat[12:9] == CS_STBY && card_state == CS_TRAN, "CMD7: R1 from stby, card selected (tran)");

    // switch status
    cmd_wait(6, 32'h80FF_FFF1);
    ok = r1_ok(6) && rd.size() == 64;
    foreach (rd[i]) if (rd[i] != i[7:0]) ok = 0;
    chk(ok, "CMD6: 64-byte switch status on DAT, high nibble first");

    // read, write, read back
    cmd_wait(17, 32'd7);
    ok = r1_ok(17) && rd.size() == 512;
    foreach (rd[i]) if (rd[i] != (((7 * 512 + i) & 8'hFF) ^ 8'hA5)) ok = 0;
    chk(ok, "CMD17 reads block 7 (initial pattern)");
    cmd_wait(17, 32'd0);
    chk(r1_ok(17) && rd.size() == 512 && rd[0] == 8'hA5 && rd[1] == 8'hA4 && rd[511] == 8'h5A,
        "CMD17 reads block 0 (initial pattern from address 0)");
    for (int i = 0; i < 512; i++) blk[i] = (i * 29) ^ 8'h6B;
    write_blk(24, 32'd7, blk);
    chk(!err_seen && busy_len >= 30 && busy_len <= 34, $sformatf("CMD24: good checksum, busy ~32 clocks (%0d)", busy_len));
    chk(card_state == CS_TRAN, "back to tran after programming");
    cmd_wait(18, 32'd7);
    ok = rd.size() == 512;
    foreach (rd[i]) if (rd[i] != blk[i]) ok = 0;
    chk(ok, "written block read back through 4-bit DAT");
    write_blk(25, 32'd8, blk, 1);
    chk(err_seen, "bad data checksum flags err");

    // erase and stop
    cmd_wait(38, 0);
    chk(r1_ok(38) && busy_len >= 62 && busy_len <= 66, $sformatf("CMD38: busy ~64 clocks (%0d)", busy_len));
    cmd_wait(17, 32'd7);
    ok = rd.size() == 512;
    foreach (rd[i]) if (rd[i] != 8'hFF) ok = 0;
    chk(ok, "erased block reads 0xFF");
    cmd_wait(17, 32'd16);
    chk(rd.size() == 512 && rd[0] == ((16 * 512) & 8'hFF ^ 8'hA5), "erase stops at block 15");
    cmd_wait(12, 0);
    chk(r1_ok(12) && busy_len >= 30 && busy_len <= 34, "CMD12: R1b, busy ~32 clocks");

    // errors
    cmd_wait(17, 32'd2048);
    chk(r1_ok(17) && rstat[31] && rd.size() == 0 && err_seen, "read beyond capacity: ADDRESS_OUT_OF_RANGE");
    cmd_wait(32, 32'd4000);
    chk(r1_ok(32) && rstat[31], "erase start beyond capacity: ADDRESS_OUT_OF_RANGE");
    cmd_wait(1, 0);
    chk(r1_ok(1) && rstat[22], "CMD1 is illegal for SD");
    send_cmd(13, 0, 48, 48'h0000_0000_0010); wait_idle();
    chk(r1_ok(13) && rstat[23], "bad CRC: COM_CRC_ERROR");
    send_cmd(13, 0, 47); wait_idle();
    chk(rbits.size() == 0, "47-bit burst ignored");

    // reset in a read
    send_cmd(17, 0);
    repeat (100) @(negedge clk);
    rst_n = 0;
    @(negedge clk);
    chk(!rd_valid && !resp_valid && !busy && card_state == CS_IDLE && ready, "reset aborts the read");
    rst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
