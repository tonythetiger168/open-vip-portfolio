// Interrupt_Controller-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+interrupt_controller
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/Interrupt_Controller_top.sv
rtl/Interrupt_Controller_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
interrupt_controller/interrupt_controller_pins_if.sv
common/ssv_pkg.sv
interrupt_controller/interrupt_controller_pkg.sv
tb/top_tb.sv
