# Interrupt_Controller UVM VIP (Interrupt_Controller-UVM-VIP)

UVM verification IP for the open-ip-portfolio **Interrupt_Controller** subsystem: Interrupt controller: 32 level sources, enables, software set, priority claim and an AXI4 event log.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`b1cfc02463bd`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 10) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What Interrupt_Controller does (from the spec)

- PENDING = (irq_src | SW_SET) & ENABLE; cpu_irq = |PENDING (a pin, also STATE.cpu_irq).
- CLAIM = {valid (bit 31), id (bits 4:0)} of the lowest-numbered pending source.
- LOG_EN 1: each source that becomes pending (rising edge of its PENDING bit) is written as {timestamp[23:0], 3'b000, id[4:0]} at LOG_BASE + 4 * (n mod LOG_WORDS), n = the record number; LOG_WP counts records. The lowest-numbered waiting source is written first; edges of a source still waiting are merged.
- timestamp: a free-running 24-bit clock counter, read in the clock the record write starts.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `interrupt_controller/` -- `interrupt_controller_ral.svh` register model (generated from the spec, same
  offsets as `Interrupt_Controller_apb`), `interrupt_controller_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `interrupt_controller_pins_if.sv` (irq_src, cpu_irq)
- `rtl/` -- `Interrupt_Controller_apb.sv`, `Interrupt_Controller_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/interrupt_controller.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | ENABLE | rw |
| 0x018 | SW_SET | rw |
| 0x01C | LOG_CTRL | rw |
| 0x020 | LOG_BASE | rw |
| 0x024 | PENDING | ro |
| 0x028 | CLAIM | ro |
| 0x02C | STATE | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 CPU, 1 LOG_ERR.

## Tests

| Test | Seeds |
|---|---|
| `interrupt_controller_ral_test` | 1 |
| `interrupt_controller_pend_test` | 3 |
| `interrupt_controller_log_test` | 3 |
| `interrupt_controller_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT Interrupt_Controller mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/interrupt_controller.f
./obj_dir/Vtop_tb +UVM_TESTNAME=interrupt_controller_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py Interrupt_Controller-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
