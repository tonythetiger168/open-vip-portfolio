# Interrupt_Controller-UVM-VIP test plan

## Register test (`interrupt_controller_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `interrupt_controller_pend_test`: 3000 clocks of random level changes on
  all 32 sources with random ENABLE and SW_SET writes, PENDING / CLAIM /
  STATE read in between: cpu_irq checked every clock, every read checked.
  Then an interrupt service loop: 20 rounds of random sources raised, and
  on cpu_irq the handler reads CLAIM, acknowledges that source (device level
  or SW_SET bit) and repeats until CLAIM.valid = 0: ids come out lowest
  first, each exactly once, cpu_irq drops; IRQ_STATUS.CPU sets again while a
  source is pending.
- `interrupt_controller_log_test`: the event log on an 8- or 5-word ring,
  sources toggling with random hold times under four AXI back-pressure
  settings: every record (address, id, timestamp window, priority, merge),
  LOG_WP = records written, every edge recorded once quiet; several sources
  rising in the same clock are written lowest id first; LOG_WORDS lowered
  below the stored slot restarts the ring at slot 0; LOG_EN 0 writes
  nothing; no AXI read, AXI ID 10, single-beat writes.
- `interrupt_controller_err_test`: ring in a SLVERR region: LOG_ERR
  interrupt, the word stays untouched, LOG_WP still counts; a clean ring
  after it works.
