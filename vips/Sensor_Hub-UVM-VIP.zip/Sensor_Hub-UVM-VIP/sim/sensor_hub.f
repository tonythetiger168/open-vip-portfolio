// Sensor_Hub-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+sensor_hub
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/Sensor_Hub_top.sv
rtl/Sensor_Hub_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
sensor_hub/sensor_hub_pins_if.sv
common/ssv_pkg.sv
sensor_hub/sensor_hub_pkg.sv
tb/top_tb.sv
