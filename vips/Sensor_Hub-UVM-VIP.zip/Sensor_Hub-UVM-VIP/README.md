# Sensor_Hub UVM VIP (Sensor_Hub-UVM-VIP)

UVM verification IP for the open-ip-portfolio **Sensor_Hub** subsystem: Sensor hub: sample averaging, packing and batched AXI4 writes with a threshold wake-up.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`8e9722204875`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 9) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What Sensor_Hub does (from the spec)

- Samples (16-bit unsigned) arrive on sns_valid / sns_data and are taken only while a job still needs words.
- avg = (sum of 2^AVG_LOG2 consecutive samples) >> AVG_LOG2; two averages per word, the first in bits 15:0.
- LEN words are written at DST; a word that finds the write FIFO full is dropped and counted in DROPS.
- WAKE fires when an average > THRESHOLD and WAKE_EN is 1, at most once per job. LAST_AVG holds the latest average.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `sensor_hub/` -- `sensor_hub_ral.svh` register model (generated from the spec, same
  offsets as `Sensor_Hub_apb`), `sensor_hub_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `sensor_hub_pins_if.sv` (sns_valid, sns_data)
- `rtl/` -- `Sensor_Hub_apb.sv`, `Sensor_Hub_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/sensor_hub.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | DST_ADDR | rw |
| 0x018 | LEN | rw |
| 0x01C | CTRL | rw |
| 0x020 | CMD | cmd |
| 0x024 | STATUS | ro |
| 0x028 | SAMPLE | ro |
| 0x02C | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR, 2 WAKE.

## Tests

| Test | Seeds |
|---|---|
| `sensor_hub_ral_test` | 1 |
| `sensor_hub_avg_test` | 3 |
| `sensor_hub_wake_test` | 2 |
| `sensor_hub_drop_test` | 2 |
| `sensor_hub_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT Sensor_Hub mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/sensor_hub.f
./obj_dir/Vtop_tb +UVM_TESTNAME=sensor_hub_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py Sensor_Hub-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
