# Sensor_Hub-UVM-VIP test plan

## Register test (`sensor_hub_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `sensor_hub_avg_test`: 20 jobs: AVG_LOG2 0..7, samples random, full scale
  0xFFFF (the 23-bit sum must not overflow at 128 x 0xFFFF), ramps; sensor
  valid every clock and with 50 % gaps; LEN 1, 16, 17 and random up to 300;
  no AXI back-pressure (no drops): every word, last_avg, drops = 0, STATUS,
  DONE / ERR, no AXI read, AXI ID 9.
- `sensor_hub_wake_test`: WAKE_EN 0 never wakes; WAKE_EN 1 wakes exactly once
  per job when an average crosses THRESHOLD (and not when the averages stay
  at or below it, including an average exactly at THRESHOLD),
  IRQ_STATUS.WAKE against the model.
- `sensor_hub_drop_test`: heavy AXI back-pressure with a sample every clock:
  words that find the FIFO full are dropped; the words written are, in
  order, a subsequence of the words formed, formed = LEN + drops, and drops
  = SAMPLE.drops > 0.
- `sensor_hub_err_test`: words written into a SLVERR region (untouched):
  DONE + ERR, STATUS.err; a clean job clears it.
