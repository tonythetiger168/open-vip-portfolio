// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_if.sv -- one HBM3 channel at its pins: row bus R[9:0], column bus
// C[7:0], ARFU and APAR (CA parity), each sampled on both edges of CK;
// the data of each pseudo-channel, one clock (4 UI x 32 DQ = 128 bits) per
// slot, with a valid flag; AERR from the device.

`ifndef HBM3_IF_SV
`define HBM3_IF_SV
interface hbm3_if (input logic ck);
  logic         rst_n;
  logic [9:0]   r;
  logic [7:0]   c;
  logic         arfu;
  logic         apar;
  logic [127:0] wd0, wd1;
  logic         wd0_v, wd1_v;
  logic [127:0] rd0, rd1;
  logic         rd0_v, rd1_v;
  logic         aerr;
endinterface
`endif
