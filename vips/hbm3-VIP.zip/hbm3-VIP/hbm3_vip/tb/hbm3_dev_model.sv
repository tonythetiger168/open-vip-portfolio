// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm3_dev_model.sv -- one HBM3 channel (JESD238) at the pin level of its
// command buses: the row bus R[9:0] and the column bus C[7:0], both
// sampled on the rising AND the falling edge of CK. Two pseudo-channels
// (PC0, PC1) share the buses and keep their own bank state and timing.
//
// Row bus (R0 first; R = rising half, F = falling half):
//   ACT    R: L H H PC SID0 SID1 BA0..BA3   F: H H RA8..RA14 V
//          next R: H H RA0..RA7    (1.5 clocks; the row opens at the 2nd rising edge)
//   PREpb  H L L PC SID0 SID1 BA0..BA3     PREab  H L H PC V..
//   REFpb  L L L PC SID0 SID1 BA0..BA3     RFMpb  L L H PC SID0 SID1 BA0..BA3
//   REFab  H H L PC V V V V L V            RFMab  H H L PC V V V V H V
//   PDE    L H L H (both halves)           SRE    L H L L (both halves)
//   RNOP   H H H H
//   The falling half may carry RNOP, PREpb or PREab only.
// Column bus (one clock, C0 first):
//   RD/RDA R: H L H (L/H) PC SID0 SID1 BA0  F: BA1 BA2 BA3 CA0..CA4
//   WR/WRA R: H L L (L/H) PC SID0 SID1 BA0  F: BA1 BA2 BA3 CA0..CA4
//   MRS    R: L L L MA4 OP5 OP6 OP7 MA0     F: MA1 MA2 MA3 OP0..OP4
//   CNOP   R: H H H
// Data: BL8 is two clocks per pseudo-channel; wd / rd carry one clock of
// a pseudo-channel's data (4 UI x 32 DQ = 128 bits). Read data starts RL
// clocks after the RD, write data is taken WL clocks after the WR
// (RL = MR2, WL = MR1[4:0], both written by MRS, which is common to both
// pseudo-channels and needs every bank idle).
// CA parity (MR0 OP6): even parity over R, C, ARFU and APAR on every edge;
// a bad edge pulses AERR for one clock, PARAC clocks later, and the command
// still executes.
//
// Bank group = BA[3:2] (4 banks per group). SID selects a stack layer when
// SIDS > 1 (banks per pseudo-channel = 16 x SIDS); with SIDS = 1 it is
// not looked at.
// Timing parameters are in clocks. A command that breaks a rule is not
// executed and pulses its error bit (per pseudo-channel) for one clock:
//   [0] bank state  [1] tRCDRD / tRCDWR  [2] tRAS  [3] tRP  [4] tRRDL/S
//   [5] tFAW  [6] tCCDL/S  [7] tWR  [8] tRTP  [9] tWTRL/S or tRTW
//   [10] busy (tRFCab, tRFCpb, tRREFD, tMOD)  [11] REFab / MRS with a bank
//   open  [12] tPPD  [13] write data missing
// bus_err (one clock): [0] reserved row code  [1] reserved column code
//   [2] row command not allowed in the falling half  [3] ACT second or third
//   half without H H  [4] PDE / SRE halves differ  [5] CA parity error
//   [6] MRS to MA4 = 1 or a RL / WL value out of range  [7] SID out of range
module hbm3_dev_model #(
  parameter int SIDS = 1,
  parameter int tRCDRD = 14, tRCDWR = 10, tRAS = 28, tRP = 14, tRRDL = 6, tRRDS = 4,
  parameter int tFAW = 16, tCCDL = 4, tCCDS = 2, tRTP = 5, tWR = 16, tWTRL = 9, tWTRS = 4,
  parameter int tRTW = 18, tRFCab = 350, tRFCpb = 200, tRREFD = 8, tMOD = 15, tPPD = 2,
  parameter int RL_RST = 14, WL_RST = 4, PARAC = 4
) (
  input  logic         ck,
  input  logic         rst_n,
  input  logic [9:0]   r,
  input  logic [7:0]   c,
  input  logic         arfu,
  input  logic         apar,
  input  logic [127:0] wd0,
  input  logic         wd0_v,
  input  logic [127:0] wd1,
  input  logic         wd1_v,
  output logic [127:0] rd0,
  output logic         rd0_v,
  output logic [127:0] rd1,
  output logic         rd1_v,
  output logic         aerr,
  output logic [63:0]  open0,       // open banks of PC0 / PC1 (bit = {sid, ba})
  output logic [63:0]  open1,
  output logic [13:0]  err0,
  output logic [13:0]  err1,
  output logic [7:0]   bus_err
);
  localparam int NB = 16 * SIDS;     // banks per pseudo-channel
  localparam int RS = 128;           // data slot ring
  localparam int FAR = -100000;

  // ------------------------------------------------------------ state
  logic [255:0] mem [logic [25:0]];  // {pc, bank[5:0], row[14:0], ca[4:0]} -> burst
  logic [7:0]   mr [0:15];
  int now;
  logic [9:0] r_rise; logic [7:0] c_rise; logic p_rise;   // rising-half samples
  // ACT in flight: first half seen, waiting for the next rising half
  logic act_p; logic act_pc; int act_b; logic [14:0] act_row;
  // per pseudo-channel, per bank
  logic open_ [0:1][0:NB-1];
  logic [14:0] orow [0:1][0:NB-1];
  int t_act [0:1][0:NB-1], t_pre [0:1][0:NB-1], t_rd [0:1][0:NB-1], t_wre [0:1][0:NB-1];
  int t_ref [0:1][0:NB-1], ap_at [0:1][0:NB-1];
  // per pseudo-channel, per bank group, and global per pseudo-channel
  int t_act_g [0:1][0:4*SIDS-1], t_col_g [0:1][0:4*SIDS-1], t_wre_g [0:1][0:4*SIDS-1];
  int t_act_a [0:1], t_col_a [0:1], t_rd_a [0:1], t_wre_a [0:1], t_pre_a [0:1], t_busy [0:1], t_refpb [0:1];
  int faw [0:1][0:3];
  int t_mrs;
  // data slots
  logic rs_v [0:1][0:RS-1]; logic [127:0] rs_d [0:1][0:RS-1];
  logic ws_v [0:1][0:RS-1]; logic [25:0] ws_k [0:1][0:RS-1]; logic ws_h [0:1][0:RS-1];
  logic aerr_at [0:RS-1];

  function automatic int bank_of(input logic [1:0] sid, input logic [3:0] ba);
    return (SIDS > 1) ? int'({sid, ba}) : int'(ba);
  endfunction
  function automatic int bg_of(input int b);
    return b >> 2;                    // BA[3:2] (and SID above it)
  endfunction

  // capture the rising half
  always_ff @(posedge ck or negedge rst_n) begin
    if (!rst_n) begin r_rise <= '1; c_rise <= '1; p_rise <= 1'b0; end
    else begin r_rise <= r; c_rise <= c; p_rise <= ^{r, c, arfu, apar}; end
  end

  always_ff @(negedge ck or negedge rst_n) begin
    if (!rst_n) begin
      mem.delete();
      for (int i = 0; i < 16; i++) mr[i] = 8'h00;
      mr[1] = 8'(WL_RST); mr[2] = 8'(RL_RST);
      now = 0; t_mrs = FAR; act_p = 1'b0;
      for (int p = 0; p < 2; p++) begin
        for (int b = 0; b < NB; b++) begin
          open_[p][b] = 1'b0; orow[p][b] = '0; ap_at[p][b] = -1;
          t_act[p][b] = FAR; t_pre[p][b] = FAR; t_rd[p][b] = FAR; t_wre[p][b] = FAR; t_ref[p][b] = FAR;
        end
        for (int g = 0; g < 4 * SIDS; g++) begin t_act_g[p][g] = FAR; t_col_g[p][g] = FAR; t_wre_g[p][g] = FAR; end
        t_act_a[p] = FAR; t_col_a[p] = FAR; t_rd_a[p] = FAR; t_wre_a[p] = FAR; t_pre_a[p] = FAR;
        t_busy[p] = FAR; t_refpb[p] = FAR;
        for (int i = 0; i < 4; i++) faw[p][i] = FAR;
        for (int i = 0; i < RS; i++) begin rs_v[p][i] = 1'b0; ws_v[p][i] = 1'b0; end
      end
      for (int i = 0; i < RS; i++) aerr_at[i] = 1'b0;
      rd0 <= '0; rd1 <= '0; rd0_v <= 1'b0; rd1_v <= 1'b0; aerr <= 1'b0;
      open0 <= '0; open1 <= '0; err0 <= '0; err1 <= '0; bus_err <= '0;
    end else begin : step
      logic [13:0] e [0:1];
      logic [7:0]  be;
      int s, rl, wl;
      logic [9:0] rr, rf;
      logic [7:0] cr, cf;
      rr = r_rise; rf = r; cr = c_rise; cf = c;
      e[0] = '0; e[1] = '0; be = '0;
      now = now + 1;
      s = now % RS;
      // parity latency PL (MR1[7:5]) delays the data when data parity is on
      rl = int'(mr[2]) + (mr[0][4] ? int'(mr[1][7:5]) : 0);
      wl = int'(mr[1][4:0]) + (mr[0][5] ? int'(mr[1][7:5]) : 0);

      // ---------------- CA parity
      aerr <= aerr_at[s]; aerr_at[s] = 1'b0;
      if (mr[0][6] && (p_rise || ^{r, c, arfu, apar})) begin
        be[5] = 1'b1;
        aerr_at[(now + PARAC) % RS] = 1'b1;
      end

      // ---------------- data
      for (int p = 0; p < 2; p++) begin
        if (ws_v[p][s]) begin
          logic [255:0] line;
          ws_v[p][s] = 1'b0;
          if (!(p == 0 ? wd0_v : wd1_v)) e[p][13] = 1'b1;
          else begin
            line = mem.exists(ws_k[p][s]) ? mem[ws_k[p][s]] : '0;
            line[128 * ws_h[p][s] +: 128] = (p == 0) ? wd0 : wd1;
            mem[ws_k[p][s]] = line;
          end
        end
      end
      rd0_v <= rs_v[0][s]; rd0 <= rs_v[0][s] ? rs_d[0][s] : '0; rs_v[0][s] = 1'b0;
      rd1_v <= rs_v[1][s]; rd1 <= rs_v[1][s] ? rs_d[1][s] : '0; rs_v[1][s] = 1'b0;

      // ---------------- auto precharge
      for (int p = 0; p < 2; p++)
        for (int b = 0; b < NB; b++)
          if (open_[p][b] && ap_at[p][b] >= 0 && now >= ap_at[p][b]) begin
            open_[p][b] = 1'b0; t_pre[p][b] = ap_at[p][b]; ap_at[p][b] = -1;
          end

      // ---------------- row bus, rising half
      if (act_p) begin
        act_p = 1'b0;
        if (rr[1:0] != 2'b11) be[3] = 1'b1;
        else row_act(act_pc, act_b, {act_row[14:8], rr[9:2]}, e[act_pc]);
        row_fall(rf, e, be);
      end else begin
        case ({rr[0], rr[1], rr[2]})
          3'b011: begin                                            // ACT, first half
            if (rf[1:0] != 2'b11) be[3] = 1'b1;
            else if (SIDS > 1 && int'(rr[5:4]) >= SIDS) be[7] = 1'b1;
            else begin
              act_p = 1'b1; act_pc = rr[3]; act_b = bank_of(rr[5:4], rr[9:6]);
              act_row = {rf[8:2], 8'h00};
            end
          end
          3'b010: begin                                            // PDE / SRE
            if (rf[3:0] != rr[3:0]) be[4] = 1'b1;
          end
          3'b111: begin
            if (!rr[3]) be[0] = 1'b1;                                // H H H L: reserved
            row_fall(rf, e, be);
          end
          default: begin
            row_one(rr, e, be);
            row_fall(rf, e, be);
          end
        endcase
      end

      // ---------------- column bus
      case ({cr[0], cr[1], cr[2]})
        3'b111: ;                                                  // CNOP
        3'b101, 3'b100: begin                                      // RD(A) / WR(A)
          logic p, w, ap;
          int b;
          p = cr[4]; w = !cr[2]; ap = cr[3];
          if (SIDS > 1 && int'(cr[6:5]) >= SIDS) be[7] = 1'b1;
          else begin
            b = bank_of(cr[6:5], {cf[2:0], cr[7]});
            col_cmd(p, b, w, ap, cf[7:3], rl, wl, e[p]);
          end
        end
        3'b000: begin                                              // MRS
          logic [4:0] ma;
          logic [7:0] op;
          ma = {cr[3], cf[2], cf[1], cf[0], cr[7]};
          op = {cr[6], cr[5], cr[4], cf[7], cf[6], cf[5], cf[4], cf[3]};
          mrs(ma, op, e, be);
        end
        default: be[1] = 1'b1;
      endcase

      for (int b = 0; b < 64; b++) begin
        open0[b] <= (b < NB) ? open_[0][b] : 1'b0;
        open1[b] <= (b < NB) ? open_[1][b] : 1'b0;
      end
      err0 <= e[0]; err1 <= e[1]; bus_err <= be;
    end
  end

  // ------------------------------------------------------------ row commands
  function automatic bit pc_busy(input logic p);
    return now - t_busy[p] < 0 || now - t_mrs < tMOD;
  endfunction

  task automatic row_act(input logic p, input int b, input logic [14:0] row, inout logic [13:0] e);
    int g;
    g = bg_of(b);
    if (pc_busy(p) || now - t_ref[p][b] < tRFCpb || now - t_refpb[p] < tRREFD) e[10] = 1'b1;
    else if (open_[p][b]) e[0] = 1'b1;
    else if (now - t_pre[p][b] < tRP) e[3] = 1'b1;
    else if (now - t_act_g[p][g] < tRRDL || now - t_act_a[p] < tRRDS) e[4] = 1'b1;
    else if (now - faw[p][0] < tFAW) e[5] = 1'b1;
    else begin
      open_[p][b] = 1'b1; orow[p][b] = row; t_act[p][b] = now;
      t_act_g[p][g] = now; t_act_a[p] = now;
      faw[p][0] = faw[p][1]; faw[p][1] = faw[p][2]; faw[p][2] = faw[p][3]; faw[p][3] = now;
    end
  endtask

  task automatic pre(input logic p, input int b, inout logic [13:0] e);
    if (!open_[p][b]) return;                                // to an idle bank: no-op
    if (ap_at[p][b] >= 0) e[0] = 1'b1;
    else if (now - t_act[p][b] < tRAS) e[2] = 1'b1;
    else if (now - t_rd[p][b] < tRTP) e[8] = 1'b1;
    else if (now - t_wre[p][b] < tWR) e[7] = 1'b1;
    else begin open_[p][b] = 1'b0; t_pre[p][b] = now; end
  endtask

  task automatic pre_cmd(input logic all, input logic p, input int b, inout logic [13:0] e);
    if (now - t_pre_a[p] < tPPD) begin e[12] = 1'b1; return; end
    if (pc_busy(p)) begin e[10] = 1'b1; return; end
    if (!all) pre(p, b, e);
    else begin
      logic [13:0] e1;
      e1 = '0;
      for (int i = 0; i < NB; i++) if (open_[p][i] && e1 == 0) begin
        if (ap_at[p][i] >= 0) e1[0] = 1'b1;
        else if (now - t_act[p][i] < tRAS) e1[2] = 1'b1;
        else if (now - t_rd[p][i] < tRTP) e1[8] = 1'b1;
        else if (now - t_wre[p][i] < tWR) e1[7] = 1'b1;
      end
      e = e | e1;
      if (e1 == 0) for (int i = 0; i < NB; i++) if (open_[p][i]) begin open_[p][i] = 1'b0; t_pre[p][i] = now; end
    end
    if (e == 0) t_pre_a[p] = now;
  endtask

  // a one-half row command in the rising half
  task automatic row_one(input logic [9:0] x, inout logic [13:0] e [0:1], inout logic [7:0] be);
    logic p;
    int b;
    p = x[3];
    if (SIDS > 1 && int'(x[5:4]) >= SIDS && ({x[0], x[1], x[2]} == 3'b100 || x[0] == 1'b0)) begin
      be[7] = 1'b1; return;
    end
    b = bank_of(x[5:4], x[9:6]);
    case ({x[0], x[1], x[2]})
      3'b100: pre_cmd(1'b0, p, b, e[p]);                     // PREpb
      3'b101: pre_cmd(1'b1, p, b, e[p]);                     // PREab
      3'b000, 3'b001: begin                                  // REFpb / RFMpb
        if (pc_busy(p) || now - t_refpb[p] < tRREFD || now - t_ref[p][b] < tRFCpb) e[p][10] = 1'b1;
        else if (open_[p][b]) e[p][0] = 1'b1;
        else if (now - t_pre[p][b] < tRP) e[p][3] = 1'b1;
        else if (!x[2]) begin t_ref[p][b] = now; t_refpb[p] = now; end
      end
      3'b110: begin                                          // REFab / RFMab
        logic any_open, prp;
        any_open = 1'b0; prp = 1'b0;
        for (int i = 0; i < NB; i++) begin
          if (open_[p][i]) any_open = 1'b1;
          if (now - t_pre[p][i] < tRP) prp = 1'b1;
        end
        if (pc_busy(p)) e[p][10] = 1'b1;
        else if (any_open) e[p][11] = 1'b1;
        else if (prp) e[p][3] = 1'b1;
        else if (!x[8]) t_busy[p] = now + tRFCab;
      end
      default: be[0] = 1'b1;
    endcase
  endtask

  // the falling half: RNOP, PREpb or PREab
  task automatic row_fall(input logic [9:0] x, inout logic [13:0] e [0:1], inout logic [7:0] be);
    case ({x[0], x[1], x[2]})
      3'b111: if (!x[3]) be[2] = 1'b1;
      3'b100, 3'b101: row_one(x, e, be);
      default: be[2] = 1'b1;
    endcase
  endtask

  // ------------------------------------------------------------ column commands
  task automatic col_cmd(input logic p, input int b, input logic w, input logic ap, input logic [4:0] ca,
                         input int rl, input int wl, inout logic [13:0] e);
    int g;
    logic [25:0] key;
    g = bg_of(b);
    if (pc_busy(p)) e[10] = 1'b1;
    else if (!open_[p][b] || ap_at[p][b] >= 0) e[0] = 1'b1;
    else if (now - t_act[p][b] < (w ? tRCDWR : tRCDRD)) e[1] = 1'b1;
    else if (now - t_col_g[p][g] < tCCDL || now - t_col_a[p] < tCCDS) e[6] = 1'b1;
    else if (!w && (now - t_wre_g[p][g] < tWTRL || now - t_wre_a[p] < tWTRS)) e[9] = 1'b1;
    else if (w && now - t_rd_a[p] < tRTW) e[9] = 1'b1;
    else begin
      key = {p, 6'(b), orow[p][b], ca};
      t_col_g[p][g] = now; t_col_a[p] = now;
      if (w) begin
        for (int i = 0; i < 2; i++) begin
          ws_v[p][(now + wl + i) % RS] = 1'b1;
          ws_k[p][(now + wl + i) % RS] = key;
          ws_h[p][(now + wl + i) % RS] = 1'(i);
        end
        t_wre[p][b] = now + wl + 2; t_wre_g[p][g] = now + wl + 2; t_wre_a[p] = now + wl + 2;
        if (ap) ap_at[p][b] = (now + wl + 2 + tWR > t_act[p][b] + tRAS) ? now + wl + 2 + tWR : t_act[p][b] + tRAS;
      end else begin
        logic [255:0] line;
        line = mem.exists(key) ? mem[key] : '0;
        for (int i = 0; i < 2; i++) begin
          rs_v[p][(now + rl + i) % RS] = 1'b1;
          rs_d[p][(now + rl + i) % RS] = line[128 * i +: 128];
        end
        t_rd[p][b] = now; t_rd_a[p] = now;
        if (ap) ap_at[p][b] = (now + tRTP > t_act[p][b] + tRAS) ? now + tRTP : t_act[p][b] + tRAS;
      end
    end
  endtask

  task automatic mrs(input logic [4:0] ma, input logic [7:0] op, inout logic [13:0] e [0:1], inout logic [7:0] be);
    logic any_open;
    any_open = 1'b0;
    for (int p = 0; p < 2; p++) for (int i = 0; i < NB; i++) if (open_[p][i]) any_open = 1'b1;
    if (pc_busy(0) || pc_busy(1)) begin e[0][10] = 1'b1; e[1][10] = 1'b1; end
    else if (any_open) begin e[0][11] = 1'b1; e[1][11] = 1'b1; end
    else if (ma[4] || (ma == 5'd2 && (op < 8'd4 || op > 8'd63)) ||
             (ma == 5'd1 && (op[4:0] < 5'd4 || op[4:0] > 5'd16))) be[6] = 1'b1;
    else begin mr[ma[3:0]] = op; t_mrs = now; end
  endtask
endmodule
