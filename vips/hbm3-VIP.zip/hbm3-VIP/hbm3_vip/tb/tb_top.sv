// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// tb_top.sv -- HBM3 testbench top: the UVM controller agent on the row /
// column buses and data paths of tb/hbm3_dev_model.sv (one channel, two
// pseudo-channels, JESD238 command encoding and bank state machine). The
// device timing parameters are the ones in hbm3_default_timing(). Any
// command the device rejects, a bus error, or AERR is a UVM error.

`include "uvm_macros.svh"
import uvm_pkg::*;
import hbm3_defs_pkg::*;
import hbm3_pkg::*;
import hbm3_env_pkg::*;
import hbm3_test_pkg::*;

module tb_top;
  logic ck = 0;
  always #5ns ck = ~ck;

  hbm3_if vif(ck);

  initial begin
    vif.rst_n = 0;
    #102ns;
    vif.rst_n = 1;
  end

  wire [63:0] open0, open1;
  wire [13:0] err0, err1;
  wire [7:0]  bus_err;
  hbm3_dev_model #(.SIDS(1), .tRCDRD(14), .tRCDWR(10), .tRAS(28), .tRP(14), .tRRDL(6), .tRRDS(4),
    .tFAW(16), .tCCDL(4), .tCCDS(2), .tRTP(5), .tWR(16), .tWTRL(9), .tWTRS(4), .tRTW(18),
    .tRFCab(350), .tRFCpb(200), .tRREFD(8), .tMOD(15), .tPPD(2), .RL_RST(14), .WL_RST(4), .PARAC(4))
    u_dev (.ck(ck), .rst_n(vif.rst_n), .r(vif.r), .c(vif.c), .arfu(vif.arfu), .apar(vif.apar),
           .wd0(vif.wd0), .wd0_v(vif.wd0_v), .wd1(vif.wd1), .wd1_v(vif.wd1_v),
           .rd0(vif.rd0), .rd0_v(vif.rd0_v), .rd1(vif.rd1), .rd1_v(vif.rd1_v), .aerr(vif.aerr),
           .open0(open0), .open1(open1), .err0(err0), .err1(err1), .bus_err(bus_err));

  hbm3_compliance_checker u_chk (.ck(ck), .rst_n(vif.rst_n), .r(vif.r), .c(vif.c), .arfu(vif.arfu),
    .apar(vif.apar), .par_en(1'b1), .wd0_v(vif.wd0_v), .wd1_v(vif.wd1_v), .rd0_v(vif.rd0_v),
    .rd1_v(vif.rd1_v), .rd0(vif.rd0), .rd1(vif.rd1), .aerr(vif.aerr));

  always @(negedge ck) if (vif.rst_n === 1'b1) begin
    #3ns;
    if (err0 != 0) `uvm_error("HBM3_DEV", $sformatf("PC0 rejected a command: err %b", err0))
    if (err1 != 0) `uvm_error("HBM3_DEV", $sformatf("PC1 rejected a command: err %b", err1))
    if (bus_err != 0) `uvm_error("HBM3_DEV", $sformatf("bus error %b", bus_err))
    if (vif.aerr === 1'b1) `uvm_error("HBM3_DEV", "AERR: CA parity error")
  end

  initial begin
    uvm_config_db#(virtual hbm3_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule
