// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator
//
// func_hbm3_dev_tb.sv -- HBM3 row / column command buses (JESD238) driven
// pin by pin into hbm3_dev_model, with the commands encoded here from the
// command tables (rising and falling half of each clock, "valid" bits
// random):
//   * ACT over 1.5 clocks, RD / RDA / WR / WRA, PREpb / PREab (also in the
//     falling half), REFab / REFpb, RFMab / RFMpb, PDE / SRE, RNOP / CNOP
//   * two pseudo-channels on shared buses: independent bank state, data and
//     timing (PC1 works while PC0 refreshes)
//   * MRS: RL / WL from MR2 / MR1 (data latency follows), MRS with a bank
//     open, MA4 set, RL out of range, tMOD
//   * timing at the boundary (one clock early rejected, on time accepted):
//     tRCDRD, tRCDWR, tRAS, tRP, tRRDL / tRRDS, tFAW, tCCDL / tCCDS, tRTP,
//     tWR, tWTRL, tRTW, tPPD, tRFCab, tRREFD
//   * bus errors: reserved row and column codes, a row command other than
//     PRE in the falling half, broken ACT halves, PDE halves that differ
//   * CA parity (MR0 OP6): even parity on every edge, a bad edge pulses AERR
//     PARAC clocks later and the command still executes
//   * missing write data; 60 random bursts on both pseudo-channels against
//     a reference memory
// Run: python3 tools/run_func_tests.py hbm3-VIP
module func_hbm3_dev_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int tRCDRD = 14, tRCDWR = 10, tRAS = 28, tRP = 14, tRRDL = 6, tRRDS = 4;
  localparam int tFAW = 20, tCCDL = 4, tCCDS = 2, tRTP = 5, tWR = 16, tWTRL = 9, tWTRS = 4;
  localparam int tRTW = 18, tRFCab = 350, tRFCpb = 200, tRREFD = 8, tMOD = 15, tPPD = 2, PARAC = 4;

  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic ck = 0, rst_n = 0;
  logic [9:0] r = '1;
  logic [7:0] c = '1;
  logic arfu = 0, apar = 0;
  logic [127:0] wd0 = 0, wd1 = 0;
  logic wd0_v = 0, wd1_v = 0;
  wire [127:0] rd0, rd1;
  wire rd0_v, rd1_v, aerr;
  wire [63:0] open0, open1;
  wire [13:0] err0, err1;
  wire [7:0] bus_err;
  always #5 ck = ~ck;

  hbm3_dev_model #(.SIDS(1), .tRCDRD(tRCDRD), .tRCDWR(tRCDWR), .tRAS(tRAS), .tRP(tRP), .tRRDL(tRRDL),
    .tRRDS(tRRDS), .tFAW(tFAW), .tCCDL(tCCDL), .tCCDS(tCCDS), .tRTP(tRTP), .tWR(tWR), .tWTRL(tWTRL),
    .tWTRS(tWTRS), .tRTW(tRTW), .tRFCab(tRFCab), .tRFCpb(tRFCpb), .tRREFD(tRREFD), .tMOD(tMOD),
    .tPPD(tPPD), .RL_RST(14), .WL_RST(4), .PARAC(PARAC))
    u_dut (.ck, .rst_n, .r, .c, .arfu, .apar, .wd0, .wd0_v, .wd1, .wd1_v, .rd0, .rd0_v, .rd1, .rd1_v,
           .aerr, .open0, .open1, .err0, .err1, .bus_err);

  // ------------------------------------------------------------ bus schedule
  // Cycle n = the rising edge n and the falling edge after it; the device
  // counts the same cycles (n = 1 is the first clock after reset).
  int n = 0;
  always @(negedge ck) if (rst_n) n <= n + 1;
  logic [9:0] sr_r [int], sr_f [int];      // row bus, rising / falling half
  logic [7:0] sc_r [int], sc_f [int];      // column bus
  logic [127:0] sw [0:1][int];             // write data by cycle
  bit par_on = 0;
  int bad_par = -1;                        // cycle whose rising half gets a wrong APAR
  function automatic logic [9:0] rnop();
    return {6'($urandom), 4'b1111};
  endfunction
  function automatic logic [7:0] cnop();
    return {5'($urandom), 3'b111};
  endfunction
  // rising half of cycle n + 1, driven after falling edge n (after the
  // results of cycle n are recorded, so cycle n + 1 can still be planned)
  always @(negedge ck) begin
    #4;
    r = sr_r.exists(n + 1) ? sr_r[n + 1] : rnop();
    c = sc_r.exists(n + 1) ? sc_r[n + 1] : cnop();
    arfu = 1'($urandom);
    apar = par_on ? ^{r, c, arfu} ^ (bad_par == n + 1) : 1'($urandom);
  end
  // falling half of cycle n + 1 and its write data, driven after rising edge n + 1
  always @(posedge ck) begin
    #1;
    r = sr_f.exists(n + 1) ? sr_f[n + 1] : rnop();
    c = sc_f.exists(n + 1) ? sc_f[n + 1] : cnop();
    arfu = 1'($urandom);
    apar = par_on ? ^{r, c, arfu} : 1'($urandom);
    wd0_v = sw[0].exists(n + 1); wd0 = wd0_v ? sw[0][n + 1] : 128'($urandom);
    wd1_v = sw[1].exists(n + 1); wd1 = wd1_v ? sw[1][n + 1] : 128'($urandom);
  end
  // results by cycle
  logic [13:0] e_at [0:1][int];
  logic [7:0]  be_at [int];
  logic [127:0] rd_at [0:1][int];
  int aerr_at [$];
  always @(negedge ck) begin
    #2;
    if (err0 != 0) e_at[0][n] = err0;
    if (err1 != 0) e_at[1][n] = err1;
    if (bus_err != 0) be_at[n] = bus_err;
    if (rd0_v) rd_at[0][n] = rd0;
    if (rd1_v) rd_at[1][n] = rd1;
    if (aerr) aerr_at.push_back(n);
  end

  // ------------------------------------------------------------ encoders
  function automatic logic [9:0] row1(input logic [2:0] code, input logic pc, input logic [3:0] ba,
                                      input logic r8 = 0);
    logic [9:0] x;
    x = 10'($urandom);
    x[0] = code[2]; x[1] = code[1]; x[2] = code[0]; x[3] = pc;
    if (code == 3'b100 || code[2] == 1'b0) begin x[5:4] = 2'b00; x[9:6] = ba; end
    if (code == 3'b110) x[8] = r8;
    return x;
  endfunction
  localparam logic [2:0] R_PREPB = 3'b100, R_PREAB = 3'b101, R_REFPB = 3'b000, R_RFMPB = 3'b001,
                         R_REFAB = 3'b110;

  task automatic late(input int at);
    if (at <= n) begin fails++; $display("  [FAIL] bench: cycle %0d planned at cycle %0d", at, n); end
  endtask
  int busy_until = 0;                      // first cycle with a free row bus
  int at_free = 0;
  task automatic wait_cyc(input int k);
    while (n < k) @(negedge ck);
  endtask
  // place a row command; returns the cycle it executes at
  // ACT that opens the row at cycle t (first half in cycle t - 1)
  task automatic act(input int t, input logic pc, input logic [3:0] ba, input logic [14:0] row);
    logic [9:0] a, f, b;
    a = row1(3'b011, pc, ba); a[5:4] = 2'b00; a[9:6] = ba;
    f = 10'($urandom); f[1:0] = 2'b11; f[8:2] = row[14:8];
    b = {row[7:0], 2'b11};
    late(t - 1);
    sr_r[t - 1] = a; sr_f[t - 1] = f; sr_r[t] = b;
  endtask
  task automatic row_at(input int at, input logic [2:0] code, input logic pc, input logic [3:0] ba = 0,
                        input logic fall = 0, input logic r8 = 0);
    late(at);
    if (fall) sr_f[at] = row1(code, pc, ba, r8);
    else sr_r[at] = row1(code, pc, ba, r8);
  endtask
  task automatic col_at(input int at, input logic w, input logic ap, input logic pc, input logic [3:0] ba,
                        input logic [4:0] ca);
    logic [7:0] x, y;
    x = {ba[0], 2'b00, pc, ap, !w, 2'b01};             // C0 = H, C1 = L, C2 = RD H / WR L, C3 = AP
    y = {ca, ba[3:1]};
    late(at);
    sc_r[at] = x; sc_f[at] = y;
  endtask
  task automatic mrs_at(input int at, input logic [4:0] ma, input logic [7:0] op);
    logic [7:0] x, y;
    x = {ma[0], op[7], op[6], op[5], ma[4], 3'b000};
    y = {op[4:0], ma[3], ma[2], ma[1]};
    late(at);
    sc_r[at] = x; sc_f[at] = y;
  endtask

  int rl = 14, wl = 4;
  task automatic plan_wr(input int t, input logic pc, input logic [255:0] d);
    sw[pc][t + wl] = d[127:0]; sw[pc][t + wl + 1] = d[255:128];
  endtask
  function automatic bit rd_ok(input int t, input logic pc, input logic [255:0] d);
    return rd_at[pc].exists(t + rl) && rd_at[pc].exists(t + rl + 1) && !rd_at[pc].exists(t + rl - 1) &&
           rd_at[pc][t + rl] == d[127:0] && rd_at[pc][t + rl + 1] == d[255:128];
  endfunction
  function automatic logic [255:0] rnd256();
    logic [255:0] v;
    for (int i = 0; i < 256; i += 32) v[i +: 32] = $urandom;
    return v;
  endfunction
  function automatic logic [13:0] e_of(input logic pc, input int t);
    return e_at[pc].exists(t) ? e_at[pc][t] : 14'h0;
  endfunction
  function automatic logic [7:0] be_of(input int t);
    return be_at.exists(t) ? be_at[t] : 8'h0;
  endfunction
  // run the schedule up to cycle k and a little beyond
  task automatic run_to(input int k);
    wait_cyc(k + 1);
    #3;
  endtask
  // close every bank of a pseudo-channel from cycle `at` on; returns the
  // cycle after which it may be used again
  task automatic close_pc(input int at, input logic pc, output int t);
    if (at <= n) at = n + 1;
    row_at(at, R_PREAB, pc);
    run_to(at);
    chk(e_of(pc, at) == 0 && (pc ? open1 : open0) == 0, $sformatf("PREab closes PC%0d (err %h)", pc, e_of(pc, at)));
    t = at + tRP;
  endtask

  // boundary of one rule: `setup` cycles of preparation are done by the
  // caller; here only the result is checked
  task automatic expect_err(input logic pc, input int t, input int bitn, input string name);
    if (bitn < 0) chk(e_of(pc, t) == 0, $sformatf("%s: accepted (err %h)", name, e_of(pc, t)));
    else chk(e_of(pc, t) == (14'd1 << bitn), $sformatf("%s: rejected with bit %0d (err %h)", name, bitn, e_of(pc, t)));
  endtask

  initial begin
    int t, t0, t1, t2, t3, t4, s;
    logic [255:0] d0, d1, d2, d3;
    repeat (3) @(negedge ck);
    rst_n = 1;
    s = 5;

    // ======================================== basic traffic on both PCs
    d0 = rnd256(); d1 = rnd256(); d2 = rnd256(); d3 = rnd256();
    t0 = s + 1; act(t0, 0, 4'h3, 15'h1234);           // PC0 bank 3
    t1 = s + 3; act(t1, 1, 4'h3, 15'h1234);           // PC1 bank 3, same row and column (shared bus, other PC)
    col_at(t0 + tRCDWR, 1, 0, 0, 4'h3, 5'd7); plan_wr(t0 + tRCDWR, 0, d0);
    col_at(t1 + tRCDWR, 1, 0, 1, 4'h3, 5'd7); plan_wr(t1 + tRCDWR, 1, d1);
    t = t1 + tRCDWR + wl + 2 + tWTRL;
    col_at(t, 0, 0, 0, 4'h3, 5'd7);
    col_at(t + 1, 0, 0, 1, 4'h3, 5'd7);
    run_to(t + rl + 4);
    chk(e_at[0].size() == 0 && e_at[1].size() == 0 && be_at.size() == 0,
        $sformatf("ACT / WR / RD on both pseudo-channels accepted (%0d %0d %0d)", e_at[0].size(), e_at[1].size(), be_at.size()));
    chk(open0 == 64'h8 && open1 == 64'h8, "bank 3 open in each pseudo-channel");
    chk(rd_ok(t, 0, d0), "PC0 read data = written data (RL 14, WL 4, BL8 in two clocks)");
    chk(rd_ok(t + 1, 1, d1), "PC1 read data = written data, the PCs keep their own data at the same bank / row / column");
    close_pc(t + rl + 6, 0, t2);
    close_pc(t + rl + 7, 1, t3);

    // ======================================== MRS: RL 20, WL 6
    s = t3 + 2;
    mrs_at(s, 5'd2, 8'd20);
    mrs_at(s + tMOD, 5'd1, 8'd6);
    run_to(s + tMOD);
    chk(be_of(s) == 0 && be_of(s + tMOD) == 0 && e_of(0, s + tMOD) == 0, "MRS MR2 = 20 and MR1 = 6 accepted");
    mrs_at(s + tMOD + tMOD - 1, 5'd3, 8'd20);
    run_to(s + 2 * tMOD);
    chk(e_of(0, s + 2 * tMOD - 1) == 14'h400 && e_of(1, s + 2 * tMOD - 1) == 14'h400, "MRS inside tMOD rejected on both PCs");
    rl = 20; wl = 6;
    t0 = s + 3 * tMOD; act(t0, 0, 4'h5, 15'h0042);
    col_at(t0 + tRCDWR, 1, 0, 0, 4'h5, 5'd1); plan_wr(t0 + tRCDWR, 0, d2);
    mrs_at(t0 + tRCDWR + 1, 5'd2, 8'd14);         // a bank is open: rejected
    t = t0 + tRCDWR + wl + 2 + tWTRL;
    col_at(t, 0, 0, 0, 4'h5, 5'd1);
    run_to(t + rl + 3);
    chk(e_of(0, t0 + tRCDWR + 1) == 14'h800, "MRS with a bank open rejected");
    chk(rd_ok(t, 0, d2), "data at the new latencies (RL 20, WL 6)");
    close_pc(t + rl + 4, 0, t1);
    mrs_at(t1, 5'h12, 8'd14);                      // MA4 = 1
    mrs_at(t1 + tMOD, 5'd2, 8'd2);                 // RL out of range
    run_to(t1 + tMOD);
    chk(be_of(t1) == 8'h40 && be_of(t1 + tMOD) == 8'h40, "MRS with MA4 = 1 or RL = 2 flagged");

    // ======================================== timing boundaries, each PC
    // (an ACT executes at its second rising half; a rejected ACT holds the
    // row bus for 1.5 clocks, so the accepted retry is the next run)
    s = t1 + 2 * tMOD;
    for (int pc = 0; pc < 2; pc++) begin
      logic p;
      p = pc[0];
      // tRCDRD / tRCDWR
      t0 = s; act(t0, p, 4'h0, 15'h11);
      t1 = t0 + tRRDS; act(t1, p, 4'h4, 15'h22);
      col_at(t1 + tRCDRD - 1, 0, 0, p, 4'h4, 0);
      col_at(t1 + tRCDRD, 0, 0, p, 4'h4, 0);
      col_at(t1 + tRCDRD + tCCDL, 1, 0, p, 4'h0, 0);   // bank 0: well past tRCDWR
      run_to(t1 + tRCDRD + tCCDL);
      expect_err(p, t1, -1, "tRRDS (other bank group)");
      expect_err(p, t1 + tRCDRD - 1, 1, "tRCDRD - 1");
      expect_err(p, t1 + tRCDRD, -1, "tRCDRD");
      expect_err(p, t1 + tRCDRD + tCCDL, 9, "WR inside tRTW");
      t2 = t1 + tRCDRD + tRTW + 4; act(t2, p, 4'h8, 15'h33);
      col_at(t2 + tRCDWR - 1, 1, 0, p, 4'h8, 0);
      col_at(t2 + tRCDWR, 1, 0, p, 4'h8, 0); plan_wr(t2 + tRCDWR, p, rnd256());
      run_to(t2 + tRCDWR + wl + 2 + tWR + tRAS);
      expect_err(p, t2 + tRCDWR - 1, 1, "tRCDWR - 1");
      expect_err(p, t2 + tRCDWR, -1, "tRCDWR");
      close_pc(n + 1, p, s);
      // tRRDL: banks 4..7 share a group
      t0 = s + 1; act(t0, p, 4'h4, 15'h1);
      t1 = t0 + tRRDL - 1; act(t1, p, 4'h6, 15'h2);   // BA[3:2] = 01 like bank 4
      t2 = t1 + 2; act(t2, p, 4'h5, 15'h3);
      t3 = t2 + tRRDL; act(t3, p, 4'h7, 15'h4);
      run_to(t3);
      expect_err(p, t1, 4, "tRRDL - 1");
      expect_err(p, t3, -1, "tRRDL");
      run_to(t3 + tRAS);
      close_pc(n + 1, p, s);
      // tFAW: four ACTs tRRDS apart in four groups, the fifth one clock early, then on time
      for (int k = 0; k < 2; k++) begin
        t0 = s + 1;
        for (int g = 0; g < 4; g++) act(t0 + g * tRRDS, p, 4'(4 * g), 15'h5);
        t1 = t0 + tFAW - 1 + k;
        act(t1, p, 4'h1, 15'h6);
        run_to(t1);
        expect_err(p, t1, k ? -1 : 5, k ? "fifth ACT at tFAW" : "fifth ACT at tFAW - 1");
        run_to(t1 + tRAS);
        close_pc(n + 1, p, s);
      end
      // tCCDS / tCCDL, tRTP, tPPD
      t0 = s + 1; act(t0, p, 4'h0, 15'h9);
      t1 = t0 + tRRDS; act(t1, p, 4'h4, 15'hA);
      t = t1 + tRCDRD;
      col_at(t, 0, 0, p, 4'h0, 1);
      col_at(t + tCCDS, 0, 0, p, 4'h4, 1);              // other group: tCCDS
      col_at(t + tCCDS + tCCDL - 1, 0, 0, p, 4'h4, 2);  // same group: tCCDL - 1
      col_at(t + tCCDS + tCCDL, 0, 0, p, 4'h4, 3);
      t2 = t + tCCDS + tCCDL;
      t3 = t1 + tRAS;
      row_at(t3 - 1, R_PREPB, p, 4'h4);                  // bank 4: tRAS - 1
      row_at(t3, R_PREPB, p, 4'h4);
      row_at(t3 + 1, R_PREPB, p, 4'h0);                  // tPPD - 1 after the last PRE
      row_at(t3 + tPPD, R_PREPB, p, 4'h0);
      // tRP with REFpb (a one-half command), then an ACT at tRREFD
      t0 = t3 + tPPD;                                    // bank 0 closes here
      row_at(t0 + tRP - 1, R_REFPB, p, 4'h0);
      row_at(t0 + tRP, R_REFPB, p, 4'h4);                // bank 4 closed at t3
      t1 = t0 + tRP + tRREFD; act(t1, p, 4'h8, 15'h1);
      run_to(t1);
      expect_err(p, t + tCCDS, -1, "tCCDS");
      expect_err(p, t + tCCDS + tCCDL - 1, 6, "tCCDL - 1");
      expect_err(p, t2, -1, "tCCDL");
      expect_err(p, t3 - 1, 2, "tRAS - 1 (PREpb)");
      expect_err(p, t3, -1, "tRAS (PREpb)");
      expect_err(p, t3 + 1, 12, "tPPD - 1");
      expect_err(p, t3 + tPPD, -1, "tPPD");
      expect_err(p, t0 + tRP - 1, 3, "REFpb at tRP - 1");
      expect_err(p, t0 + tRP, -1, "REFpb at tRP");
      expect_err(p, t1, -1, "ACT at tRREFD after REFpb");
      chk((p ? open1 : open0) == 64'h100, "only bank 8 open");
      run_to(t1 + tRAS);
      close_pc(n + 1, p, s);
      // tRAS / tRP for ACT
      t0 = s + 1; act(t0, p, 4'h2, 15'h2);
      t3 = t0 + tRAS;
      row_at(t3 - 1, R_PREPB, p, 4'h2);
      row_at(t3, R_PREPB, p, 4'h2);
      t4 = t3 + tRP - 1; act(t4, p, 4'h2, 15'h2);
      t1 = t4 + 2; act(t1, p, 4'h2, 15'h2);
      run_to(t1);
      expect_err(p, t3 - 1, 2, "tRAS - 1");
      expect_err(p, t3, -1, "tRAS");
      expect_err(p, t4, 3, "ACT at tRP - 1");
      expect_err(p, t1, -1, "ACT at tRP + 1");
      // tRTP
      t = t1 + tRAS;
      col_at(t, 0, 0, p, 4'h2, 0);
      row_at(t + tRTP - 1, R_PREPB, p, 4'h2);
      row_at(t + tRTP, R_PREPB, p, 4'h2);
      run_to(t + tRTP);
      expect_err(p, t + tRTP - 1, 8, "tRTP - 1");
      expect_err(p, t + tRTP, -1, "tRTP");
      // tWTRL, tRTW, tWR
      s = t + tRTP + tRP;
      t0 = s + 1; act(t0, p, 4'h1, 15'h33);
      t = t0 + tRCDWR + 2;
      col_at(t, 1, 0, p, 4'h1, 4); plan_wr(t, p, rnd256());
      col_at(t + wl + 2 + tWTRL - 1, 0, 0, p, 4'h1, 4);
      col_at(t + wl + 2 + tWTRL, 0, 0, p, 4'h1, 4);
      t1 = t + wl + 2 + tWTRL;
      col_at(t1 + tRTW - 1, 1, 0, p, 4'h1, 5);
      col_at(t1 + tRTW, 1, 0, p, 4'h1, 5); plan_wr(t1 + tRTW, p, rnd256());
      t2 = t1 + tRTW;
      row_at(t2 + wl + 2 + tWR - 1, R_PREPB, p, 4'h1);
      row_at(t2 + wl + 2 + tWR, R_PREPB, p, 4'h1);
      run_to(t2 + wl + 2 + tWR);
      expect_err(p, t + wl + 2 + tWTRL - 1, 9, "tWTRL - 1");
      expect_err(p, t1, -1, "tWTRL");
      expect_err(p, t1 + tRTW - 1, 9, "tRTW - 1");
      expect_err(p, t2, -1, "tRTW");
      expect_err(p, t2 + wl + 2 + tWR - 1, 7, "tWR - 1");
      expect_err(p, t2 + wl + 2 + tWR, -1, "tWR");
      s = t2 + wl + 2 + tWR + tRP + 2;
    end

    // ======================================== refresh, pseudo-channel independence
    row_at(s, R_REFAB, 0);
    t1 = s + 2; act(t1, 1, 4'h2, 15'h77);           // PC1 is not refreshing
    t2 = s + tRFCab - 1; act(t2, 0, 4'h2, 15'h77);
    t3 = s + tRFCab + 1; act(t3, 0, 4'h3, 15'h77);
    run_to(t3);
    expect_err(0, s, -1, "REFab PC0");
    expect_err(1, t1, -1, "ACT on PC1 during PC0's tRFCab");
    expect_err(0, t2, 10, "ACT on PC0 at tRFCab - 1");
    expect_err(0, t3, -1, "ACT on PC0 after tRFCab");
    row_at(t3 + 3, R_REFAB, 0);                    // REFab with a bank open
    run_to(t3 + 3);
    expect_err(0, t3 + 3, 11, "REFab with a bank open");
    run_to(t3 + tRAS + 1);
    close_pc(n + 1, 0, t0);
    close_pc(n + 1, 1, t0);
    s = t0 + 2;
    row_at(s, R_REFPB, 1, 4'h6);
    row_at(s + tRREFD - 1, R_REFPB, 1, 4'h7);
    row_at(s + tRREFD, R_REFPB, 1, 4'h7);
    t1 = s + 2 * tRREFD; act(t1, 1, 4'h6, 15'h1);  // the refreshing bank: tRFCpb
    run_to(t1 + 1);
    expect_err(1, s, -1, "REFpb");
    expect_err(1, s + tRREFD - 1, 10, "REFpb inside tRREFD");
    expect_err(1, s + tRREFD, -1, "REFpb after tRREFD");
    expect_err(1, t1, 10, "ACT to a bank in tRFCpb");
    begin
      int b0;
      b0 = be_at.size();
      row_at(n + 2, R_RFMPB, 0, 4'h1);
      t = n + 4;
      row_at(t, R_REFAB, 0, 0, 0, 1'b1);           // RFMab (R8 = H)
      t1 = t + 3; act(t1, 0, 4'h1, 15'h1);        // RFM does not hold the PC like REFab
      run_to(t1);
      chk(be_at.size() == b0, "RFMpb / RFMab decoded without bus error");
      expect_err(0, t1, -1, "ACT right after RFMab");
      run_to(t1 + tRAS);
      close_pc(n + 1, 0, t0);
    end

    // ======================================== RDA / WRA, PREab in the falling half
    s = n + tRFCab + 2;
    t0 = s + 1; act(t0, 0, 4'h9, 15'h3A);
    col_at(t0 + tRCDWR, 1, 1, 0, 4'h9, 5'd9); plan_wr(t0 + tRCDWR, 0, d3);   // WRA
    t = t0 + tRCDWR;
    run_to(t + wl + 2 + tWR + tRAS);
    chk(open0 == 0 && e_of(0, t) == 0, "WRA closes the bank by itself");
    t1 = n + tRP + 3; act(t1, 0, 4'h9, 15'h3A);
    col_at(t1 + tRCDRD, 0, 1, 0, 4'h9, 5'd9);                                // RDA
    run_to(t1 + tRCDRD + rl + 2 + tRAS);
    chk(rd_ok(t1 + tRCDRD, 0, d3) && open0 == 0, "RDA returns the data and closes the bank");
    t2 = n + tRP + 3; act(t2, 1, 4'hA, 15'h1);
    row_at(t2 + tRAS, R_PREAB, 1, 0, 1'b1);         // PREab in the falling half
    run_to(t2 + tRAS + 1);
    chk(e_of(1, t2 + tRAS) == 0 && open1 == 0 && be_of(t2 + tRAS) == 0, "PREab in the falling half");

    // ======================================== bus errors
    begin
      int b0;
      b0 = be_at.size();
      t = n + 3;
      sr_r[t] = {6'h0, 4'b0111};                   // H H H L: reserved row code
      sr_f[t + 2] = row1(R_REFAB, 0, 0);           // REFab in the falling half
      sc_r[t + 4] = 8'b0000_0010;                  // C0..C2 = L H L: reserved column code
      act(t + 7, 0, 4'h1, 15'h1); sr_f[t + 6][1] = 1'b0; sr_r[t + 7] = rnop();  // ACT falling half not H H
      sr_r[t + 9] = {6'h0, 4'b1010}; sr_f[t + 9] = {6'h0, 4'b0010};   // PDE then SRE halves
      run_to(t + 10);
      chk(be_of(t) == 8'h01, $sformatf("reserved row code (be %h)", be_of(t)));
      chk(be_of(t + 2) == 8'h04, $sformatf("REFab in the falling half (be %h)", be_of(t + 2)));
      chk(be_of(t + 4) == 8'h02, $sformatf("reserved column code (be %h)", be_of(t + 4)));
      chk(be_of(t + 6) == 8'h08 && open0 == 0, $sformatf("ACT with a broken falling half not executed (be %h)", be_of(t + 6)));
      chk(be_of(t + 9) == 8'h10, $sformatf("PDE / SRE halves differ (be %h)", be_of(t + 9)));
      sr_r[t + 12] = {6'h0, 4'b1010}; sr_f[t + 12] = {6'h0, 4'b1010};  // PDE
      sr_r[t + 14] = {6'h0, 4'b0010}; sr_f[t + 14] = {6'h0, 4'b0010};  // SRE
      run_to(t + 15);
      chk(be_of(t + 12) == 0 && be_of(t + 14) == 0, "PDE and SRE decoded");
    end

    // ======================================== CA parity
    t = n + 3;
    mrs_at(t, 5'd0, 8'h40);                         // MR0 OP6: CA parity on
    par_on = 1;                                     // good parity from now on
    run_to(t);
    aerr_at.delete();
    t1 = t + tMOD + 3; act(t1, 1, 4'hB, 15'h5);
    bad_par = t1;                                   // the ACT's second rising half
    run_to(t1 + PARAC + 3);
    chk(be_of(t1) == 8'h20, $sformatf("bad CA parity flagged (be %h)", be_of(t1)));
    chk(aerr_at.size() == 1 && aerr_at[0] == t1 + PARAC, $sformatf("AERR one clock, PARAC after the bad edge (%0d)", aerr_at.size()));
    chk(open1 == 64'h800 && e_of(1, t1) == 0, "the command with bad parity still executes");
    run_to(t1 + tRAS);
    close_pc(n + 1, 1, t0);
    chk(aerr_at.size() == 1, "no AERR with good parity");
    par_on = 0;
    mrs_at(t0, 5'd0, 8'h00);
    run_to(t0 + tMOD);

    // ======================================== missing write data
    t = n + 2;
    t1 = t + 1; act(t1, 0, 4'h2, 15'h2);
    col_at(t1 + tRCDWR, 1, 1, 0, 4'h2, 0);          // WRA with no data planned
    run_to(t1 + tRCDWR + wl + 2);
    chk(e_of(0, t1 + tRCDWR + wl) == 14'h2000, "write data missing flagged");
    run_to(n + tRAS + tWR + tRP);

    // ======================================== random bursts on both PCs
    begin
      logic [255:0] ref_m [logic [26:0]];
      int bad, cnt;
      bad = 0; cnt = 0;
      t = n + 2;
      for (int i = 0; i < 30; i++) begin
        logic [3:0] ba [0:1];
        logic [14:0] rw [0:1];
        logic [4:0] cl [0:1];
        logic [255:0] x [0:1];
        logic [26:0] k [0:1];
        bit wr [0:1];
        int tc [0:1];
        for (int q = 0; q < 2; q++) begin
          ba[q] = 4'($urandom); rw[q] = 15'($urandom_range(3)); cl[q] = 5'($urandom_range(3));
          k[q] = {1'(q), 2'b00, ba[q], rw[q], cl[q]};
          wr[q] = 1'($urandom);
        end
        t0 = t + 1; act(t0, 0, ba[0], rw[0]); t1 = t + 3; act(t1, 1, ba[1], rw[1]);
        for (int q = 0; q < 2; q++) begin
          tc[q] = t1 + tRCDRD + q;
          col_at(tc[q], wr[q], 1, 1'(q), ba[q], cl[q]);
          if (wr[q]) begin x[q] = rnd256(); plan_wr(tc[q], 1'(q), x[q]); end
          else x[q] = ref_m.exists(k[q]) ? ref_m[k[q]] : '0;
        end
        run_to(t1 + tRCDRD + rl + wl + 4);
        for (int q = 0; q < 2; q++)
          if (wr[q]) ref_m[k[q]] = x[q];
          else begin cnt++; if (!rd_ok(tc[q], 1'(q), x[q])) bad++; end
        t = t1 + tRCDRD + rl + wl + tWR + tRAS + tRP + 4;
        run_to(t - 3);
      end
      chk(bad == 0 && cnt > 0, $sformatf("random traffic: %0d reads match the reference memory (%0d bad)", cnt, bad));
    end

    if (fails == 0) $display("FUNC_PASS func_hbm3_dev_tb checks=%0d", checks);
    else $display("FUNC_FAIL func_hbm3_dev_tb checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #5000000; $display("FUNC_FAIL func_hbm3_dev_tb timeout"); $finish; end
`else
  initial begin $display("FUNC_PASS func_hbm3_dev_tb checks=0 (needs VIP_SMOKE_FLATTENED)"); $finish; end
`endif
endmodule
