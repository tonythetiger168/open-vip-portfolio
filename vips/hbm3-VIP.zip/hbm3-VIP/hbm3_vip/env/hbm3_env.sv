// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_env.sv -- HBM3 environment: data scoreboard, command rule checker,
// coverage

package hbm3_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import hbm3_defs_pkg::*;
  import hbm3_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. A reference memory keyed by {pseudo-channel, bank, row, column}
  // follows every write seen on the pins; every read seen on the pins must
  // return what it holds (zero where never written). In an active agent the
  // driver's accesses are matched in order against the monitor's, so an
  // access that never reached the pins, or reached them with another
  // address, is reported.
  class hbm3_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(hbm3_scoreboard)
    uvm_analysis_imp_exp #(hbm3_transaction, hbm3_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(hbm3_transaction, hbm3_scoreboard) obs_ap;

    hbm3_config cfg;
    hbm3_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;
    bit [255:0] mem [bit [24:0]];

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(hbm3_config)::get(this, "", "cfg", cfg))
        cfg = hbm3_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    function void write_exp(hbm3_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(hbm3_transaction t);
      n_checks++;
      if (t.write) begin
        mem[t.key()] = t.wdata;
        n_matches++;
      end else begin
        bit [255:0] e = mem.exists(t.key()) ? mem[t.key()] : '0;
        if (e == t.rdata) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("read data mismatch\n  read:     %s\n  expected: %0h", t.convert2string(), e))
        end
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        hbm3_transaction e = exp_q.pop_front();
        hbm3_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed accesses left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("hbm3 scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class hbm3_env extends uvm_env;
    `uvm_component_utils(hbm3_env)
    hbm3_agent      agt;
    hbm3_scoreboard sb;
    hbm3_checker    chk;
    hbm3_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = hbm3_agent     ::type_id::create("agt", this);
      sb  = hbm3_scoreboard::type_id::create("sb",  this);
      chk = hbm3_checker   ::type_id::create("chk", this);
      cov = hbm3_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.cmd_ap.connect(chk.imp);
      agt.mon.cmd_ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
