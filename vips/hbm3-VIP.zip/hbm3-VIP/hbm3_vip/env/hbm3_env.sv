// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm3_env.sv -- HBM3 verification environment with end-to-end scoreboard

`ifndef HBM3_ENV_SV
`define HBM3_ENV_SV
`include "uvm_macros.svh"

`uvm_analysis_imp_decl(_exp)
`uvm_analysis_imp_decl(_obs)

// End-to-end scoreboard: compares driver-issued (expected) transactions
// against monitor-decoded (observed) transactions.
class hbm3_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(hbm3_scoreboard)
  uvm_analysis_imp_exp #(hbm3_transaction, hbm3_scoreboard) exp_ap;
  uvm_analysis_imp_obs #(hbm3_transaction, hbm3_scoreboard) obs_ap;

  hbm3_transaction exp_q[$], obs_q[$];
  int unsigned n_matches = 0, n_mismatches = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    exp_ap = new("exp_ap", this);
    obs_ap = new("obs_ap", this);
  endfunction

  function void write_exp(hbm3_transaction t); exp_q.push_back(t); check(); endfunction
  function void write_obs(hbm3_transaction t); obs_q.push_back(t); check(); endfunction

  function void check();
    while (exp_q.size() && obs_q.size()) begin
      hbm3_transaction e = exp_q.pop_front();
      hbm3_transaction o = obs_q.pop_front();
      bit ok = (e.cmd == o.cmd) && (e.bg == o.bg) && (e.ba == o.ba);
      case (e.cmd)
        HBM3_CMD_ACT: ok = ok && (e.row == o.row) && (e.stack_id == o.stack_id);
        HBM3_CMD_RD:  ok = ok && (e.col == o.col) && (e.rdata == o.rdata);
        HBM3_CMD_WR:  ok = ok && (e.col == o.col) && (e.data == o.data);
        default: ; // PRE/REF/NOP: command + bank comparison is sufficient
      endcase
      if (ok) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                   e.convert2string(), o.convert2string()))
      end
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("SB", $sformatf("hbm3 scoreboard: n_matches=%0d n_mismatches=%0d",
              n_matches, n_mismatches), UVM_LOW)
    if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
  endfunction
endclass

class hbm3_env extends uvm_env;
  `uvm_component_utils(hbm3_env)
  hbm3_protocol_checker       protocol_chk;
  hbm3_data_integrity_checker di_chk;
  hbm3_timing_checker         timing_chk;
  hbm3_error_checker          error_chk;
  hbm3_agent                  agt;
  hbm3_scoreboard             sb;
  hbm3_coverage               cov;
  function new(string name="hbm3_env", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    protocol_chk = hbm3_protocol_checker::type_id::create("protocol_chk", this);
    di_chk       = hbm3_data_integrity_checker::type_id::create("di_chk", this);
    timing_chk   = hbm3_timing_checker::type_id::create("timing_chk", this);
    error_chk    = hbm3_error_checker::type_id::create("error_chk", this);
    agt = hbm3_agent::type_id::create("agt", this);
    sb  = hbm3_scoreboard::type_id::create("sb", this);
    cov = hbm3_coverage::type_id::create("cov", this);
  endfunction
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    agt.mon.ap.connect(sb.obs_ap);
    agt.drv.drv_ap.connect(sb.exp_ap);
    agt.mon.ap.connect(cov.analysis_export);
  endfunction
endclass
`endif
