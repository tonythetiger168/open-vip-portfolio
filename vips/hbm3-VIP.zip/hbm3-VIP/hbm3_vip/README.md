# HBM3 UVM VIP

**Standard:** JESD238 (HBM3), one channel with two pseudo-channels
**License:** Apache-2.0

A UVM controller agent on the real HBM3 command buses of one channel: the
row bus R[9:0] and the column bus C[7:0], both carrying a half on each
edge of CK, with ARFU / APAR (CA parity), and the data path of each
pseudo-channel. The testbench drives the device model `tb/hbm3_dev_model.sv`
(JESD238 command encoding, per-pseudo-channel bank state machine and
timing); any command the device rejects, a bus error or AERR is a UVM error.

## Architecture
```
hbm3_vip/
|-- rtl/hbm3_if.sv                    # pins: R, C, ARFU, APAR, wd0/wd1, rd0/rd1, AERR
|-- vip/hbm3/
|   |-- hbm3_defs.sv                  # command codes, row / column bus encoders, device timing
|   |-- hbm3_pkg.sv                   # agent package (includes the .svh files below)
|   |-- hbm3_transaction.svh          # BL8 access item (PC, bank, row, column, 256-bit data); decoded command item
|   |-- hbm3_config.svh               # timing, RL / WL, CA parity, refresh interval, falling-half PRE rate
|   |-- hbm3_driver.svh               # cycle-stepped controller on both edges
|   |-- hbm3_monitor.svh              # decodes both buses on both edges; data per pseudo-channel
|   |-- hbm3_checker.svh              # controller-side rule checker (bus, bank state, timing)
|   |-- hbm3_coverage.svh             # 4 covergroups
|   |-- hbm3_sequences.svh            # random and directed sequences
|   |-- hbm3_agent.svh, hbm3_sequencer.svh
|   |-- sva/hbm3_compliance_checker.sv# pin-level SVA (instanced in tb_top)
|-- env/hbm3_env.sv                   # env + scoreboard with a reference memory
|-- tests/hbm3_test.sv                # hbm3_base_test (random), hbm3_func_test (directed + random)
|-- tb/tb_top.sv                      # TB top: agent on tb/hbm3_dev_model.sv
|-- tb/hbm3_dev_model.sv, tb/func_hbm3_dev_tb.sv
|-- Makefile
```

## Agent

- **Driver.** Each item is one BL8 access (256 bits in two clocks) of a
  pseudo-channel. The driver issues PREpb on a row miss, ACT over three
  row-bus halves, and RD / RDA / WR / WRA on the column bus, each at the
  first cycle the timing allows: tRCDRD, tRCDWR, tRP, tRAS, tRRDL / tRRDS,
  tFAW, tCCDL / tCCDS, tRTP, tWR, tWTRL / tWTRS, tRTW, tPPD, tRFCab,
  tRFCpb, tRREFD and tMOD. After reset it writes MR0 (CA parity on), MR2
  (RL 20) and MR1 (WL 6). It refreshes both pseudo-channels every
  `ref_interval` cycles, alternating REFab and a REFpb sweep of all banks.
  PREpb / PREab use the falling half when the rising half is taken, or at
  random. APAR is driven with even parity on every half.
- **Monitor.** Decodes both buses on both edges, as the device does, and
  publishes every command and every RD / WR with its data (WL / RL taken
  from MRS).
- **Checker** (`HBM3_RULE`). Reserved codes, illegal halves, MRS values,
  bank state (ACT to an open bank, RD / WR to an idle bank, PRE with an auto
  precharge pending, REF / MRS with a bank open) and every timing rule above.
- **Coverage.** Commands x pseudo-channel; page hit / miss x read / write;
  consecutive column pairs (RD/WR x RD/WR) in the same / another bank
  group; PRE in the rising / falling half; MRS to MR0 / MR1 / MR2.
- **Scoreboard.** A reference memory keyed by {PC, bank, row, column}
  checks every read, and the driver's accesses are matched against the
  monitor's.

`hbm3_func_test` on msim: 868 commands (299 ACT, 385 RD/WR, 73 PRE in the
falling half, REFab and a REFpb sweep, 3 MRS), 0 rule violations, 770
scoreboard checks, coverage 100%. With tRCDRD shortened to 9 in the agent,
the device rejects the early reads and the monitor reports the missing data.

The agent found a defect in the device model: the 27-bit address key
{pc, bank, row, column} was stored in 26 bits, so both pseudo-channels
shared one memory. Fixed; `func_hbm3_dev_tb` now writes both PCs at the
same bank / row / column.

## JESD238 command buses (`tb/hbm3_dev_model.sv`)

The device model is the DUT of the UVM testbench (`tb/tb_top.sv`).

| File | Content |
|---|---|
| `tb/hbm3_dev_model.sv` | one channel, two pseudo-channels on shared buses: row bus R[9:0] and column bus C[7:0] sampled on both CK edges; ACT over 1.5 clocks (row opens at the 2nd rising edge), PREpb / PREab (also in the falling half), REFab / REFpb, RFMab / RFMpb, PDE / SRE, RD / RDA / WR / WRA, MRS (common to both PCs); per-PC bank state and timing (tRCDRD, tRCDWR, tRAS, tRP, tRRDL/S, tFAW, tCCDL/S, tRTP, tWR, tWTRL/S, tRTW, tPPD, tRFCab, tRFCpb, tRREFD, tMOD); BL8 data in two clocks per PC at RL = MR2 / WL = MR1; CA parity (MR0 OP6) with AERR; bus errors for reserved codes and illegal half-cycle use |
| `tb/func_hbm3_dev_tb.sv` | commands encoded from the tables with random "valid" bits; both PCs interleaved; RL / WL changed by MRS; every timing parameter at its boundary; refresh with PC independence; RDA / WRA; bus errors; CA parity and AERR; missing write data; 30 random rounds against a reference memory, both PCs at the same bank / row / column: 118 checks (Verilator) |

Assumptions to confirm against the standard's tables: bank group =
BA[3:2]; MR1 / MR2 hold WL / RL in clocks; PL adds to RL / WL only with
data parity on. JEDEC leaves most row / column timing minimums to the
vendor datasheet, so the timing values are parameters (the test uses
small example values). Not modelled yet: data bus inversion, data parity
and DERR, ECC / SEV pins, IEEE 1500 port, power-down and self-refresh
exit timing, SID with 8/12/16-high stacks beyond the `SIDS` parameter.

## Sequences and tests

| Sequence | Purpose |
|----------|---------|
| `hbm3_base_sequence` | `num_items` random accesses on both PCs over `rows` rows per bank; half of the reads go to written locations |
| `hbm3_directed_sequence` | page hit / miss, same address on both PCs, same / other bank group, RD->WR->RD, auto precharge, every bank of both PCs, a never-written location |

Tests: `hbm3_base_test` (random), `hbm3_func_test` (directed, then random).

## SVA (vip/hbm3/sva/hbm3_compliance_checker.sv)
No X on the buses in either half; even CA parity in every half (when on);
ACT second and third halves carry H H; the falling half carries RNOP /
PREpb / PREab only; read and write data in two-clock bursts per PC; no X on
read data; AERR never rises. Covers: ACT, PRE in the falling half, read
and write data.

## Quick Start
```bash
python3 tools/run_uvm_tests.py hbm3-VIP      # Verilator + uvm-core (portfolio)
make comp sim                               # VCS: see Makefile
./simv +UVM_TESTNAME=hbm3_func_test
```
