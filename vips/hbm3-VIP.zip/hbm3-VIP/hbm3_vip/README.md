# HBM3 UVM VIP

**Protocol Level:** Complex
**Checkers:** 4 UVM components (Protocol L1, Data Integrity L2, Timing L2, Error L3) + module-based SVA compliance checker (L1-L4)
**License:** Apache-2.0

## Protocol Overview
HBM3 stacked DRAM: 16 pseudo-channels per stack, higher bank-group count, on-die ECC.

The VIP drives and monitors a DDR-style command/address bus
(`cs_n/act_n/ras_n/cas_n/we_n` + `{bg,ba}` bank + `addr` row/column):

| Command | cs_n | act_n | ras_n | cas_n | we_n | Address |
|---------|------|-------|-------|-------|------|---------|
| ACT     | 0    | 0     | -     | -     | -    | row     |
| RD      | 0    | 1     | 1     | 0     | 1    | column  |
| WR      | 0    | 1     | 1     | 0     | 0    | column  |
| PRE     | 0    | 1     | 0     | 1     | 0    | -       |
| REF     | 0    | 1     | 0     | 0     | 1    | -       |
| NOP     | 0    | 1     | 1     | 1     | 1    | -       |

Core timing parameters (cycles): tRCD=14, tRP=14, tRAS=18, tCL=14, tCWL=2, tRFC=48, tREFI=3900.

## Architecture
```
hbm3_vip/
|-- rtl/hbm3_if.sv                    # signal interface (+ clocking block)
|-- sequences/hbm3_sequence.sv        # transaction + directed sequence library
|-- vip/hbm3/
|   |-- hbm3_driver.sv                # protocol driver (cmd encoding, timing, DQ)
|   |-- hbm3_monitor.sv               # bus monitor (command/DQ decode -> analysis port)
|   |-- hbm3_agent.sv                 # sequencer + driver + monitor
|   |-- hbm3_coverage.sv              # 3 covergroups with crosses
|   |-- hbm3_compliance_checker.sv    # SVA module, L1-L4 (instanced in tb_top)
|   |-- hbm3_protocol_checker.sv      # L1 component (procedural sampling)
|   |-- hbm3_timing_checker.sv        # L2 component (tRCD/tRP/tRAS measurement)
|   |-- hbm3_data_integrity_checker.sv# L2 component (DQ/DBI/BL sampling)
|   |-- hbm3_error_checker.sv         # L3 component (temp/refresh/DFE monitoring)
|-- env/hbm3_env.sv                   # env + end-to-end scoreboard
|-- tests/hbm3_test.sv                # base/write/read/stress tests
|-- tb/tb_top.sv                     # TB top + DRAM memory-array functional model
|-- Makefile
```

Closed loop: sequences -> driver -> `hbm3_if` -> `hbm3_mem_model` (bank/row/col
storage in tb_top) drives read data back -> monitor decodes -> scoreboard
compares expected (driver) vs observed (monitor) end-to-end.

## Sequence Library
| Sequence | Purpose |
|----------|---------|
| `hbm3_base_sequence` | legacy fully-random items (API compatibility) |
| `hbm3_write_seq` | normal write flow: ACT, WR burst, PRE |
| `hbm3_read_seq` | normal read flow: ACT, RD burst, PRE |
| `hbm3_refresh_seq` | traffic punctuated by REF (tRFC apart) |
| `hbm3_bank_conflict_seq` | same bank, alternating rows (page misses) |
| `hbm3_back_to_back_seq` | one ACT, long alternating RD/WR stream (page hits) |
| `hbm3_stress_seq` | long protocol-legal random stream (bank-state model) |
| `hbm3_corner_seq` | all-zero/all-one row/col, boundary banks/stacks |
| `hbm3_random_sequence` | 50 random items |
| `hbm3_regression_sequence` | weighted mix of all directed sequences |

Tests: `hbm3_base_test` (regression seq), `hbm3_write_test`, `hbm3_read_test`, `hbm3_stress_test`.

## SVA Compliance Checker (vip/hbm3/hbm3_compliance_checker.sv)
- **L1 signal sanity (4):** command/address known when selected, bank group/address encoding bounds.
- **L2 timing & data integrity (10):** tRCD/tRP windows, burst length, data valid with DQS, DBI/WCK settings.
- **L3 error handling (6):** power-management state, refresh interval, over-temperature, DFE/bandwidth/latency bounds.
- **L4 HBM3-specific (10):** ACT/RD-WR/PRE bank-state legality (3), tRCD/tRP/tRAS timing rules (3), refresh pulse width, CKE gating, family rules (pseudo-channel stability + stack select), refresh-interval + ACT->col->PRE covers.

## Functional Coverage (vip/hbm3/hbm3_coverage.sv)
- `cg_command`    : command distribution x bank cross (`cx_cmd_bank`)
- `cg_bank_state` : bank state transitions (ACT=>RD/WR, RD/WR=>PRE, PRE/REF=>ACT, RD<=>WR)
- `cg_addr`       : row/col/stack address patterns with `cx_row_col` cross

## Quick Start
```bash
make comp                                   # compile (VCS + UVM 1.2)
make sim                                    # run default test
make regress                                # run regression test
./simv +UVM_TESTNAME=hbm3_stress_test        # run a directed test
```
