// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_driver.svh -- HBM3 controller on the row / column buses.
//
// Each item is one BL8 access of a pseudo-channel. The driver turns it into
// PREpb (row miss), ACT (three row-bus halves) and RD / RDA / WR / WRA on
// the column bus, issues each command at the first cycle the device timing
// allows (tRCDRD / tRCDWR, tRP, tRAS, tRRDL / tRRDS, tFAW, tCCDL / tCCDS,
// tRTP, tWR, tWTRL / tWTRS, tRTW, tPPD, tRFCab / tRFCpb / tRREFD, tMOD),
// puts the write data on the pseudo-channel's data path WL cycles after
// the WR, programs MR0 (CA parity), MR2 (RL) and MR1 (WL) after reset, and
// refreshes both pseudo-channels every cfg.ref_interval cycles, alternating
// REFab and a REFpb sweep of all banks. A row command may use the rising or
// the falling half (PREpb / PREab only). APAR is driven with even parity
// over R, C and ARFU on every half.
//
// Cycle n is the rising edge n and the falling edge after it, counted like
// the device (n = 1 is the first falling edge after reset). The rising half
// of cycle n + 1 is driven 4 ns after falling edge n, its falling half and
// its write data 1 ns after rising edge n + 1.

class hbm3_driver extends uvm_driver #(hbm3_transaction);
  `uvm_component_utils(hbm3_driver)

  uvm_analysis_port #(hbm3_transaction) ap;
  int unsigned item_cnt = 0;
  int unsigned n_cmds[hbm3_cmd_e];
  int unsigned n_fall = 0;

  virtual hbm3_if vif;
  hbm3_config cfg;

  typedef struct { hbm3_cmd_e k; bit pc; bit [3:0] ba; bit [14:0] row; bit [4:0] ca;
                   bit [4:0] ma; bit [7:0] op; } cmd_t;

  localparam int FAR = -100000;
  protected int n, rl, wl, t_mrs, ref_round, last_ref;
  protected bit open_ [2][16];
  protected bit [14:0] orow [2][16];
  protected int t_act [2][16], t_pre [2][16], t_rd [2][16], t_wre [2][16], t_ref [2][16], ap_at [2][16];
  protected int t_act_g [2][4], t_col_g [2][4], t_wre_g [2][4];
  protected int t_act_a [2], t_col_a [2], t_rd_a [2], t_wre_a [2], t_pre_a [2], t_busy [2], t_refpb [2];
  protected int faw [2][4];
  protected cmd_t pend[$];
  protected logic [9:0] row_r [int], row_f [int];
  protected logic [7:0] col_r [int], col_f [int];
  protected logic [127:0] wplan [2][int];
  protected hbm3_transaction cur;          // item whose column command is still pending
  protected hbm3_transaction nxt;          // item fetched by fetch_loop, not yet taken
  protected bit              done_ack;     // cur's item_done was called

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hbm3_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hbm3: virtual interface not set")
    if (!uvm_config_db#(hbm3_config)::get(this, "", "cfg", cfg))
      cfg = hbm3_config::type_id::create("cfg");
  endfunction

  protected function void reset_state();
    n = 0; rl = cfg.tm.RL_RST; wl = cfg.tm.WL_RST; t_mrs = FAR; ref_round = 0; last_ref = 0;
    for (int p = 0; p < 2; p++) begin
      for (int b = 0; b < 16; b++) begin
        open_[p][b] = 0; orow[p][b] = '0; ap_at[p][b] = -1;
        t_act[p][b] = FAR; t_pre[p][b] = FAR; t_rd[p][b] = FAR; t_wre[p][b] = FAR; t_ref[p][b] = FAR;
      end
      for (int g = 0; g < 4; g++) begin t_act_g[p][g] = FAR; t_col_g[p][g] = FAR; t_wre_g[p][g] = FAR; faw[p][g] = FAR; end
      t_act_a[p] = FAR; t_col_a[p] = FAR; t_rd_a[p] = FAR; t_wre_a[p] = FAR; t_pre_a[p] = FAR;
      t_busy[p] = FAR; t_refpb[p] = FAR;
      wplan[p].delete();
    end
    pend.delete(); row_r.delete(); row_f.delete(); col_r.delete(); col_f.delete();
  endfunction

  protected function void drive_half(logic [9:0] r, logic [7:0] c);
    vif.r = r; vif.c = c; vif.arfu = 1'b0; vif.apar = ^{r, c, 1'b0};
  endfunction

  task run_phase(uvm_phase phase);
    drive_half(hbm3_rnop(), hbm3_cnop());
    vif.wd0 = '0; vif.wd1 = '0; vif.wd0_v = 0; vif.wd1_v = 0;
    forever begin
      reset_state();
      wait (vif.rst_n === 1'b1);
      begin
        cmd_t m = '{k: H3_MRS, default: '0};
        m.ma = 0; m.op = cfg.parity ? 8'h40 : 8'h00; pend.push_back(m);
        m.ma = 2; m.op = 8'(cfg.rl); pend.push_back(m);
        m.ma = 1; m.op = 8'(cfg.wl); pend.push_back(m);
      end
      fork
        fetch_loop();
        cycle_loop();
        wait (vif.rst_n !== 1'b1);
      join_any
      disable fork;
      if (cur != null || nxt != null) seq_item_port.item_done();
      cur = null; nxt = null;
      drive_half(hbm3_rnop(), hbm3_cnop());
      vif.wd0_v = 0; vif.wd1_v = 0;
    end
  endtask

  // ---------------------------------------------------------------- timing
  protected function int bg(bit [3:0] b); return int'(b[3:2]); endfunction
  // bank state at cycle t, with auto precharges that completed by then
  protected function bit is_open(bit p, int b, int t);
    return open_[p][b] && !(ap_at[p][b] >= 0 && t >= ap_at[p][b]);
  endfunction
  protected function int tpre(bit p, int b, int t);
    return (open_[p][b] && ap_at[p][b] >= 0 && t >= ap_at[p][b]) ? ap_at[p][b] : t_pre[p][b];
  endfunction
  protected function bit busy(bit p, int t);
    return t < t_busy[p] || t - t_mrs < cfg.tm.tMOD;
  endfunction
  protected function bit can_close(bit p, int b, int t);
    return ap_at[p][b] < 0 && t - t_act[p][b] >= cfg.tm.tRAS && t - t_rd[p][b] >= cfg.tm.tRTP &&
           t - t_wre[p][b] >= cfg.tm.tWR;
  endfunction

  // may command c execute at cycle t (ACT: the cycle its row opens)
  protected function bit ready(cmd_t c, int t);
    bit p = c.pc;
    int b = int'(c.ba);
    case (c.k)
      H3_ACT:
        return !busy(p, t) && !is_open(p, b, t) && t - tpre(p, b, t) >= cfg.tm.tRP &&
               t - t_ref[p][b] >= cfg.tm.tRFCpb && t - t_refpb[p] >= cfg.tm.tRREFD &&
               t - t_act_g[p][bg(c.ba)] >= cfg.tm.tRRDL && t - t_act_a[p] >= cfg.tm.tRRDS &&
               t - faw[p][0] >= cfg.tm.tFAW;
      H3_PREPB:
        return !busy(p, t) && t - t_pre_a[p] >= cfg.tm.tPPD && (!is_open(p, b, t) || can_close(p, b, t));
      H3_PREAB: begin
        if (busy(p, t) || t - t_pre_a[p] < cfg.tm.tPPD) return 0;
        for (int i = 0; i < 16; i++) if (is_open(p, i, t) && !can_close(p, i, t)) return 0;
        return 1;
      end
      H3_REFAB: begin
        if (busy(p, t)) return 0;
        for (int i = 0; i < 16; i++) if (is_open(p, i, t) || t - tpre(p, i, t) < cfg.tm.tRP) return 0;
        return 1;
      end
      H3_REFPB:
        return !busy(p, t) && t - t_refpb[p] >= cfg.tm.tRREFD && t - t_ref[p][b] >= cfg.tm.tRFCpb &&
               !is_open(p, b, t) && t - tpre(p, b, t) >= cfg.tm.tRP;
      H3_RD, H3_RDA, H3_WR, H3_WRA: begin
        bit w = c.k inside {H3_WR, H3_WRA};
        if (busy(p, t) || !is_open(p, b, t) || ap_at[p][b] >= 0) return 0;
        if (t - t_act[p][b] < (w ? cfg.tm.tRCDWR : cfg.tm.tRCDRD)) return 0;
        if (t - t_col_g[p][bg(c.ba)] < cfg.tm.tCCDL || t - t_col_a[p] < cfg.tm.tCCDS) return 0;
        if (!w) return t - t_wre_g[p][bg(c.ba)] >= cfg.tm.tWTRL && t - t_wre_a[p] >= cfg.tm.tWTRS;
        return t - t_rd_a[p] >= cfg.tm.tRTW;
      end
      H3_MRS: begin
        if (busy(0, t) || busy(1, t)) return 0;
        for (int q = 0; q < 2; q++) for (int i = 0; i < 16; i++) if (is_open(q[0], i, t)) return 0;
        return 1;
      end
      default: return 1;
    endcase
  endfunction

  protected function void commit(cmd_t c, int t);
    bit p = c.pc;
    int b = int'(c.ba), g = bg(c.ba);
    case (c.k)
      H3_ACT: begin
        open_[p][b] = 1; orow[p][b] = c.row; t_act[p][b] = t; ap_at[p][b] = -1;
        t_act_g[p][g] = t; t_act_a[p] = t;
        faw[p][0] = faw[p][1]; faw[p][1] = faw[p][2]; faw[p][2] = faw[p][3]; faw[p][3] = t;
      end
      H3_PREPB: begin
        if (is_open(p, b, t)) begin open_[p][b] = 0; t_pre[p][b] = t; end
        t_pre_a[p] = t;
      end
      H3_PREAB: begin
        for (int i = 0; i < 16; i++) if (is_open(p, i, t)) begin open_[p][i] = 0; t_pre[p][i] = t; end
        t_pre_a[p] = t;
      end
      H3_REFAB: t_busy[p] = t + cfg.tm.tRFCab;
      H3_REFPB: begin t_ref[p][b] = t; t_refpb[p] = t; end
      H3_RD, H3_RDA: begin
        t_col_g[p][g] = t; t_col_a[p] = t; t_rd[p][b] = t; t_rd_a[p] = t;
        if (c.k == H3_RDA)
          ap_at[p][b] = (t + cfg.tm.tRTP > t_act[p][b] + cfg.tm.tRAS) ? t + cfg.tm.tRTP : t_act[p][b] + cfg.tm.tRAS;
      end
      H3_WR, H3_WRA: begin
        int e = t + wl + 2;
        t_col_g[p][g] = t; t_col_a[p] = t; t_wre[p][b] = e; t_wre_g[p][g] = e; t_wre_a[p] = e;
        if (c.k == H3_WRA)
          ap_at[p][b] = (e + cfg.tm.tWR > t_act[p][b] + cfg.tm.tRAS) ? e + cfg.tm.tWR : t_act[p][b] + cfg.tm.tRAS;
      end
      H3_MRS: begin
        t_mrs = t;
        if (c.ma == 2) rl = int'(c.op);
        if (c.ma == 1) wl = int'(c.op[4:0]);
      end
      default: ;
    endcase
    if (n_cmds.exists(c.k)) n_cmds[c.k]++; else n_cmds[c.k] = 1;
  endfunction

  // ---------------------------------------------------------------- items
  protected function void plan(hbm3_transaction t);
    int b = int'(t.ba);
    cmd_t c = '{k: H3_NONE, pc: t.pc, ba: t.ba, row: t.row, ca: t.ca, default: '0};
    bit hit = open_[t.pc][b] && ap_at[t.pc][b] < 0 && orow[t.pc][b] == t.row;
    if (open_[t.pc][b] && ap_at[t.pc][b] < 0 && !hit) begin c.k = H3_PREPB; pend.push_back(c); end
    if (!hit) begin c.k = H3_ACT; pend.push_back(c); end
    c.k = t.write ? (t.auto_pre ? H3_WRA : H3_WR) : (t.auto_pre ? H3_RDA : H3_RD);
    pend.push_back(c);
  endfunction

  protected function void plan_refresh();
    cmd_t c = '{k: H3_PREAB, default: '0};
    for (int p = 0; p < 2; p++) begin
      bit any = 0;
      for (int i = 0; i < 16; i++) any |= open_[p][i];
      c.pc = p[0];
      if (any) begin c.k = H3_PREAB; pend.push_back(c); end
    end
    for (int p = 0; p < 2; p++) begin
      c.pc = p[0];
      if (ref_round[0] == 0) begin c.k = H3_REFAB; pend.push_back(c); end
      else for (int i = 0; i < 16; i++) begin c.k = H3_REFPB; c.ba = i[3:0]; pend.push_back(c); end
    end
    ref_round++;
  endfunction

  // place the next commands of cycle m on the buses
  protected task schedule(int m);
    bit row_used = row_r.exists(m);             // the last half of an ACT started last cycle
    bit fall_used = 0, col_used = 0;
    // auto precharges that complete in cycle m
    for (int p = 0; p < 2; p++) for (int i = 0; i < 16; i++)
      if (ap_at[p][i] >= 0 && m >= ap_at[p][i]) begin open_[p][i] = 0; t_pre[p][i] = ap_at[p][i]; ap_at[p][i] = -1; end
    if (pend.size() == 0 && cur == null && m - last_ref >= int'(cfg.ref_interval)) begin
      plan_refresh(); last_ref = m;
    end
    if (pend.size() == 0 && cur == null) begin
      if (nxt != null) begin
        cur = nxt; nxt = null; cur.tag = item_cnt++;
        `uvm_info("DRV", {"drive: ", cur.convert2string()}, UVM_HIGH)
        plan(cur);
      end
    end
    // in order: the head command; then the next one too if it uses the other bus
    for (int k = 0; k < 2 && pend.size(); k++) begin
      cmd_t c = pend[0];
      bit col = hbm3_is_col(c.k);
      if (col) begin
        logic [7:0] cr, cf;
        if (col_used || !ready(c, m)) break;
        if (c.k == H3_MRS) hbm3_enc_mrs(c.ma, c.op, cr, cf);
        else hbm3_enc_col(c.k inside {H3_WR, H3_WRA}, c.k inside {H3_RDA, H3_WRA}, c.pc, c.ba, c.ca, cr, cf);
        col_r[m] = cr; col_f[m] = cf; col_used = 1;
        commit(c, m);
        void'(pend.pop_front());
        if (hbm3_is_rdwr(c.k)) begin
          hbm3_transaction d;
          if (c.k inside {H3_WR, H3_WRA}) begin
            wplan[c.pc][m + wl] = cur.wdata[127:0]; wplan[c.pc][m + wl + 1] = cur.wdata[255:128];
          end
          $cast(d, cur.clone());
          ap.write(d);
          seq_item_port.item_done();
          done_ack = 1;
          cur = null;
        end
      end else if (c.k == H3_ACT) begin
        logic [9:0] h0, h1, h2;
        if (row_used || fall_used || !ready(c, m + 1)) break;
        hbm3_enc_act(c.pc, c.ba, c.row, h0, h1, h2);
        row_r[m] = h0; row_f[m] = h1; row_r[m + 1] = h2; row_used = 1; fall_used = 1;
        commit(c, m + 1);
        void'(pend.pop_front());
      end else begin
        // PREpb / PREab may use the falling half; refresh uses the rising half
        bit fall_ok = !fall_used && c.k inside {H3_PREPB, H3_PREAB};
        bit use_fall;
        if (!ready(c, m)) break;
        if (row_used && !fall_ok) break;
        if (!row_used && fall_used) break;
        use_fall = fall_ok && (row_used || $urandom_range(99) < int'(cfg.fall_pre_pct));
        if (use_fall) begin row_f[m] = hbm3_enc_row(c.k, c.pc, c.ba); fall_used = 1; n_fall++; end
        else begin row_r[m] = hbm3_enc_row(c.k, c.pc, c.ba); row_used = 1; end
        commit(c, m);
        void'(pend.pop_front());
      end
    end
  endtask

  // Items are fetched in their own thread with the blocking get_next_item,
  // so the cycle loop never waits inside the sequencer and keeps its
  // half-cycle timing (try_next_item may take simulation time on some
  // simulators).
  protected task fetch_loop();
    forever begin
      hbm3_transaction t;
      seq_item_port.get_next_item(t);
      done_ack = 0;
      nxt = t;
      wait (done_ack);
    end
  endtask

  protected task cycle_loop();
    forever begin
      @(negedge vif.ck);
      n++;
      #4ns;
      schedule(n + 1);
      // rising half of cycle n + 1
      drive_half(row_r.exists(n + 1) ? row_r[n + 1] : hbm3_rnop(), col_r.exists(n + 1) ? col_r[n + 1] : hbm3_cnop());
      row_r.delete(n + 1); col_r.delete(n + 1);
      @(posedge vif.ck);
      #1ns;
      // falling half and write data of cycle n + 1
      drive_half(row_f.exists(n + 1) ? row_f[n + 1] : hbm3_rnop(), col_f.exists(n + 1) ? col_f[n + 1] : hbm3_cnop());
      row_f.delete(n + 1); col_f.delete(n + 1);
      vif.wd0_v = wplan[0].exists(n + 1); vif.wd0 = vif.wd0_v ? wplan[0][n + 1] : '0;
      vif.wd1_v = wplan[1].exists(n + 1); vif.wd1 = vif.wd1_v ? wplan[1][n + 1] : '0;
      wplan[0].delete(n + 1); wplan[1].delete(n + 1);
    end
  endtask

  function void report_phase(uvm_phase phase);
    string s = "";
    foreach (n_cmds[k]) s = {s, $sformatf(" %s=%0d", k.name(), n_cmds[k])};
    `uvm_info("DRV", $sformatf("commands:%s (PRE in the falling half: %0d)", s, n_fall), UVM_LOW)
  endfunction
endclass
