// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_checker.svh -- controller-side rule checker on the commands the
// monitor decodes from the pins (per pseudo-channel; the device model
// checks the same rules on its side):
//   bus    RESERVED row / column code; HALF (ACT halves not H H, a row
//          command other than PREpb / PREab in the falling half, PDE / SRE
//          halves differ); MRS_VALUE (MA4 = 1, RL or WL out of range)
//   state  ACT_OPEN; COL_IDLE (RD / WR to an idle bank or one with an auto
//          precharge pending); PRE_AP; REF_OPEN (REFab / REFpb / MRS with a
//          bank open)
//   timing tRCDRD, tRCDWR, tRP, tRAS, tRRDL, tRRDS, tFAW, tCCDL, tCCDS, tRTP,
//          tWR, tWTRL, tWTRS, tRTW, tPPD, BUSY (tRFCab, tRFCpb, tRREFD, tMOD)
// Errors are "HBM3_RULE" with the rule name in brackets.

class hbm3_checker extends uvm_component;
  `uvm_component_utils(hbm3_checker)
  uvm_analysis_imp #(hbm3_cmd_item, hbm3_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  int unsigned viol[string];
  hbm3_config cfg;

  localparam int FAR = -100000;
  protected bit open_ [2][16];
  protected int t_act [2][16], t_pre [2][16], t_rd [2][16], t_wre [2][16], t_ref [2][16], ap_at [2][16];
  protected int t_act_g [2][4], t_col_g [2][4], t_wre_g [2][4];
  protected int t_act_a [2], t_col_a [2], t_rd_a [2], t_wre_a [2], t_pre_a [2], t_busy [2], t_refpb [2];
  protected int faw [2][4];
  protected int t_mrs, wl;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(hbm3_config)::get(this, "", "cfg", cfg))
      cfg = hbm3_config::type_id::create("cfg");
    for (int p = 0; p < 2; p++) begin
      for (int b = 0; b < 16; b++) begin
        open_[p][b] = 0; ap_at[p][b] = -1;
        t_act[p][b] = FAR; t_pre[p][b] = FAR; t_rd[p][b] = FAR; t_wre[p][b] = FAR; t_ref[p][b] = FAR;
      end
      for (int g = 0; g < 4; g++) begin t_act_g[p][g] = FAR; t_col_g[p][g] = FAR; t_wre_g[p][g] = FAR; faw[p][g] = FAR; end
      t_act_a[p] = FAR; t_col_a[p] = FAR; t_rd_a[p] = FAR; t_wre_a[p] = FAR; t_pre_a[p] = FAR;
      t_busy[p] = FAR; t_refpb[p] = FAR;
    end
    t_mrs = FAR; wl = cfg.tm.WL_RST;
  endfunction

  protected function void bad(string rule, string msg);
    n_violations++;
    if (viol.exists(rule)) viol[rule]++; else viol[rule] = 1;
    `uvm_error("HBM3_RULE", $sformatf("[%s] %s", rule, msg))
  endfunction

  protected function void need(int have, int want, string rule, hbm3_cmd_item c);
    if (have < want) bad(rule, $sformatf("%s: %0d cycles, needs %0d", c.convert2string(), have, want));
  endfunction

  protected function void busy(bit p, hbm3_cmd_item c);
    if (c.t < t_busy[p]) bad("BUSY", $sformatf("%s %0d cycles before the pseudo-channel is free after REFab", c.convert2string(), t_busy[p] - c.t));
    need(c.t - t_mrs, cfg.tm.tMOD, "tMOD", c);
  endfunction

  protected function void close_check(bit p, int b, hbm3_cmd_item c);
    if (ap_at[p][b] >= 0) bad("PRE_AP", $sformatf("%s to bank %0d with an auto precharge pending", c.convert2string(), b));
    need(c.t - t_act[p][b], cfg.tm.tRAS, "tRAS", c);
    need(c.t - t_rd[p][b], cfg.tm.tRTP, "tRTP", c);
    need(c.t - t_wre[p][b], cfg.tm.tWR, "tWR", c);
  endfunction

  function void write(hbm3_cmd_item c);
    int t = c.t;
    bit p = c.pc;
    int b = int'(c.ba), g = int'(c.ba[3:2]);
    n_checked++;
    for (int q = 0; q < 2; q++) for (int i = 0; i < 16; i++)
      if (ap_at[q][i] >= 0 && t >= ap_at[q][i]) begin open_[q][i] = 0; t_pre[q][i] = ap_at[q][i]; ap_at[q][i] = -1; end
    if (c.kind == H3_RSVD) begin bad("RESERVED", $sformatf("reserved %s code", c.ma == 5'h1F ? "column" : "row")); return; end
    if (c.bad_half) begin bad("HALF", $sformatf("%s: illegal half", c.convert2string())); return; end
    case (c.kind)
      H3_ACT: begin
        busy(p, c);
        need(t - t_ref[p][b], cfg.tm.tRFCpb, "tRFCpb", c);
        need(t - t_refpb[p], cfg.tm.tRREFD, "tRREFD", c);
        if (open_[p][b]) bad("ACT_OPEN", c.convert2string());
        need(t - t_pre[p][b], cfg.tm.tRP, "tRP", c);
        need(t - t_act_g[p][g], cfg.tm.tRRDL, "tRRDL", c);
        need(t - t_act_a[p], cfg.tm.tRRDS, "tRRDS", c);
        need(t - faw[p][0], cfg.tm.tFAW, "tFAW", c);
        open_[p][b] = 1; t_act[p][b] = t; t_act_g[p][g] = t; t_act_a[p] = t;
        faw[p][0] = faw[p][1]; faw[p][1] = faw[p][2]; faw[p][2] = faw[p][3]; faw[p][3] = t;
      end
      H3_PREPB, H3_PREAB: begin
        need(t - t_pre_a[p], cfg.tm.tPPD, "tPPD", c);
        busy(p, c);
        for (int i = 0; i < 16; i++)
          if (open_[p][i] && (c.kind == H3_PREAB || i == b)) begin
            close_check(p, i, c);
            open_[p][i] = 0; ap_at[p][i] = -1; t_pre[p][i] = t;
          end
        t_pre_a[p] = t;
      end
      H3_REFAB, H3_RFMAB: begin
        busy(p, c);
        for (int i = 0; i < 16; i++) begin
          if (open_[p][i]) bad("REF_OPEN", $sformatf("%s with bank %0d open", c.convert2string(), i));
          need(t - t_pre[p][i], cfg.tm.tRP, "tRP", c);
        end
        if (c.kind == H3_REFAB) t_busy[p] = t + cfg.tm.tRFCab;
      end
      H3_REFPB, H3_RFMPB: begin
        busy(p, c);
        need(t - t_refpb[p], cfg.tm.tRREFD, "tRREFD", c);
        need(t - t_ref[p][b], cfg.tm.tRFCpb, "tRFCpb", c);
        if (open_[p][b]) bad("REF_OPEN", c.convert2string());
        need(t - t_pre[p][b], cfg.tm.tRP, "tRP", c);
        if (c.kind == H3_REFPB) begin t_ref[p][b] = t; t_refpb[p] = t; end
      end
      H3_RD, H3_RDA, H3_WR, H3_WRA: begin
        bit w = c.kind inside {H3_WR, H3_WRA};
        busy(p, c);
        if (!open_[p][b] || ap_at[p][b] >= 0) bad("COL_IDLE", c.convert2string());
        if (w) need(t - t_act[p][b], cfg.tm.tRCDWR, "tRCDWR", c);
        else   need(t - t_act[p][b], cfg.tm.tRCDRD, "tRCDRD", c);
        need(t - t_col_g[p][g], cfg.tm.tCCDL, "tCCDL", c);
        need(t - t_col_a[p], cfg.tm.tCCDS, "tCCDS", c);
        t_col_g[p][g] = t; t_col_a[p] = t;
        if (!w) begin
          need(t - t_wre_g[p][g], cfg.tm.tWTRL, "tWTRL", c);
          need(t - t_wre_a[p], cfg.tm.tWTRS, "tWTRS", c);
          t_rd[p][b] = t; t_rd_a[p] = t;
          if (c.kind == H3_RDA)
            ap_at[p][b] = (t + cfg.tm.tRTP > t_act[p][b] + cfg.tm.tRAS) ? t + cfg.tm.tRTP : t_act[p][b] + cfg.tm.tRAS;
        end else begin
          int e = t + wl + 2;
          need(t - t_rd_a[p], cfg.tm.tRTW, "tRTW", c);
          t_wre[p][b] = e; t_wre_g[p][g] = e; t_wre_a[p] = e;
          if (c.kind == H3_WRA)
            ap_at[p][b] = (e + cfg.tm.tWR > t_act[p][b] + cfg.tm.tRAS) ? e + cfg.tm.tWR : t_act[p][b] + cfg.tm.tRAS;
        end
      end
      H3_MRS: begin
        busy(0, c); busy(1, c);
        for (int q = 0; q < 2; q++) for (int i = 0; i < 16; i++)
          if (open_[q][i]) bad("REF_OPEN", $sformatf("MRS with PC%0d bank %0d open", q, i));
        if (c.ma[4] || (c.ma == 2 && (c.op < 4 || c.op > 63)) || (c.ma == 1 && (c.op[4:0] < 4 || c.op[4:0] > 16)))
          bad("MRS_VALUE", c.convert2string());
        if (c.ma == 1) wl = int'(c.op[4:0]);
        t_mrs = t;
      end
      default: ;
    endcase
  endfunction

  function void report_phase(uvm_phase phase);
    string s = "";
    foreach (viol[r]) s = {s, $sformatf(" %s=%0d", r, viol[r])};
    `uvm_info("HBM3_RULE", $sformatf("%0d commands checked, %0d violations%s", n_checked, n_violations, s), UVM_LOW)
  endfunction
endclass
