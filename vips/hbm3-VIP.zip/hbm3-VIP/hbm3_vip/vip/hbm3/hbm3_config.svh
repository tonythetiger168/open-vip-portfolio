// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

class hbm3_config extends uvm_object;
  `uvm_object_utils(hbm3_config)
  uvm_active_passive_enum is_active = UVM_ACTIVE;
  hbm3_timing_t tm = hbm3_default_timing();   // the device model's parameters
  int unsigned rl = 20;               // read latency written to MR2 after reset
  int unsigned wl = 6;                // write latency written to MR1 after reset
  bit          parity = 1;            // CA parity on (MR0 OP6); the agent drives APAR
  int unsigned ref_interval = 3000;   // clocks between refresh rounds (REFab / REFpb sweep)
  int unsigned fall_pre_pct = 50;     // PREpb / PREab in the falling half
  int unsigned num_items = 300;       // random items per base sequence
  int unsigned auto_pre_pct = 25;
  int unsigned rows = 4;              // rows per bank used by the random sequence
  function new(string name = "hbm3_config"); super.new(name); endfunction
endclass
