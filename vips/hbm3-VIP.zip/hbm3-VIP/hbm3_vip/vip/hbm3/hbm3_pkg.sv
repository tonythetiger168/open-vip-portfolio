// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_pkg.sv -- HBM3 agent: sequence item, config, driver, monitor,
// sequences, rule checker and coverage.

`ifndef HBM3_PKG_SV
`define HBM3_PKG_SV
package hbm3_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import hbm3_defs_pkg::*;

  `include "hbm3_transaction.svh"
  `include "hbm3_config.svh"
  `include "hbm3_sequencer.svh"
  `include "hbm3_driver.svh"
  `include "hbm3_monitor.svh"
  `include "hbm3_agent.svh"
  `include "hbm3_sequences.svh"
  `include "hbm3_checker.svh"
  `include "hbm3_coverage.svh"
endpackage
`endif
