// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_monitor.svh -- decodes the row and column buses on both edges of CK
// (JESD238 command encoding, as in tb/hbm3_dev_model.sv) and publishes every
// command on cmd_ap, with the cycle the device executes it (an ACT at the
// cycle its row opens). Tracks the open row of every bank and RL / WL from
// MRS, and publishes each RD / WR as an hbm3_transaction on ap once its two
// data clocks are in: write data WL cycles, read data RL cycles after the
// command. Write data not valid when due, read data missing when due, or
// read data with no read due, is an "HBM3_MON" error.

class hbm3_monitor extends uvm_monitor;
  `uvm_component_utils(hbm3_monitor)

  uvm_analysis_port #(hbm3_transaction) ap;
  uvm_analysis_port #(hbm3_cmd_item)    cmd_ap;
  int unsigned item_cnt = 0;

  virtual hbm3_if vif;
  hbm3_config cfg;

  protected int n, rl, wl;
  protected bit [14:0] orow [2][16];
  protected bit act_p, act_pc;
  protected bit [3:0] act_ba;
  protected bit [6:0] act_hi;
  protected hbm3_transaction xq[$];
  protected int xdue[$], xbeat[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
    cmd_ap = new("cmd_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual hbm3_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "hbm3: virtual interface not set")
    if (!uvm_config_db#(hbm3_config)::get(this, "", "cfg", cfg))
      cfg = hbm3_config::type_id::create("cfg");
  endfunction

  protected function void reset_state();
    n = 0; rl = cfg.tm.RL_RST; wl = cfg.tm.WL_RST; act_p = 0;
    foreach (orow[p, b]) orow[p][b] = '0;
    xq.delete(); xdue.delete(); xbeat.delete();
  endfunction

  task run_phase(uvm_phase phase);
    logic [9:0] rr, rf;
    logic [7:0] cr, cf;
    reset_state();
    forever begin
      @(posedge vif.ck);
      rr = vif.r; cr = vif.c;
      @(negedge vif.ck);
      rf = vif.r; cf = vif.c;
      if (vif.rst_n !== 1'b1) begin
        if (xq.size()) `uvm_info("MON", $sformatf("reset: %0d transfers dropped", xq.size()), UVM_LOW)
        reset_state();
        continue;
      end
      n++;
      decode_row(rr, rf);
      decode_col(cr, cf);
      sample_wd();
      #2ns;
      sample_rd();
      while (xq.size() && xbeat[0] == 2) begin
        void'(xdue.pop_front()); void'(xbeat.pop_front());
        ap.write(xq.pop_front());
      end
    end
  endtask

  // ---------------------------------------------------------------- commands
  protected function hbm3_cmd_item mk(hbm3_cmd_e k, bit pc = 0, bit [3:0] ba = 0);
    hbm3_cmd_item c = hbm3_cmd_item::type_id::create("cmd");
    c.kind = k; c.pc = pc; c.ba = ba; c.t = n;
    return c;
  endfunction

  protected function void one(logic [9:0] x, bit fall);
    hbm3_cmd_item c = mk(hbm3_row_kind(x), x[3], x[9:6]);
    c.fall = fall;
    if (fall && !(c.kind inside {H3_PREPB, H3_PREAB})) c.bad_half = 1;
    cmd_ap.write(c);
  endfunction

  protected function void decode_fall(logic [9:0] x);
    if ({x[0], x[1], x[2]} == 3'b111) begin
      if (!x[3]) begin hbm3_cmd_item c = mk(H3_RSVD); c.fall = 1; cmd_ap.write(c); end
    end else one(x, 1);
  endfunction

  protected function void decode_row(logic [9:0] rr, logic [9:0] rf);
    if (act_p) begin
      hbm3_cmd_item c = mk(H3_ACT, act_pc, act_ba);
      act_p = 0;
      c.row = {act_hi, rr[9:2]};
      if (rr[1:0] != 2'b11) c.bad_half = 1;
      else orow[act_pc][act_ba] = c.row;
      cmd_ap.write(c);
      decode_fall(rf);
      return;
    end
    case ({rr[0], rr[1], rr[2]})
      3'b011: begin
        if (rf[1:0] != 2'b11) begin
          hbm3_cmd_item c = mk(H3_ACT, rr[3], rr[9:6]);
          c.bad_half = 1; cmd_ap.write(c);
        end else begin
          act_p = 1; act_pc = rr[3]; act_ba = rr[9:6]; act_hi = rf[8:2];
        end
      end
      3'b010: begin
        hbm3_cmd_item c = mk(hbm3_row_kind(rr), rr[3]);
        if (rf[3:0] != rr[3:0]) c.bad_half = 1;
        cmd_ap.write(c);
      end
      3'b111: begin
        if (!rr[3]) cmd_ap.write(mk(H3_RSVD));
        decode_fall(rf);
      end
      default: begin
        one(rr, 0);
        decode_fall(rf);
      end
    endcase
  endfunction

  protected function void decode_col(logic [7:0] cr, logic [7:0] cf);
    hbm3_cmd_item c;
    case ({cr[0], cr[1], cr[2]})
      3'b111: return;
      3'b101, 3'b100: begin
        bit w = !cr[2], a = cr[3];
        hbm3_transaction t = hbm3_transaction::type_id::create("tr");
        c = mk(w ? (a ? H3_WRA : H3_WR) : (a ? H3_RDA : H3_RD), cr[4], {cf[2:0], cr[7]});
        c.ca = cf[7:3];
        c.row = orow[c.pc][c.ba];
        t.write = w; t.pc = c.pc; t.ba = c.ba; t.row = c.row; t.ca = c.ca; t.auto_pre = a;
        t.t_cmd = n; t.tag = item_cnt++; t.wdata = '0; t.rdata = '0;
        xq.push_back(t); xbeat.push_back(0); xdue.push_back(n + (w ? wl : rl));
      end
      3'b000: begin
        c = mk(H3_MRS);
        c.ma = {cr[3], cf[2], cf[1], cf[0], cr[7]};
        c.op = {cr[6], cr[5], cr[4], cf[7], cf[6], cf[5], cf[4], cf[3]};
        if (c.ma == 2) rl = int'(c.op);
        if (c.ma == 1) wl = int'(c.op[4:0]);
      end
      default: begin c = mk(H3_RSVD); c.ma = 5'h1F; end   // ma = 1F marks a column-bus code
    endcase
    cmd_ap.write(c);
  endfunction

  // ---------------------------------------------------------------- data
  protected function void sample_wd();
    for (int i = 0; i < xq.size(); i++) begin
      if (!xq[i].write || xbeat[i] >= 2 || xdue[i] + xbeat[i] != n) continue;
      if ((xq[i].pc ? vif.wd1_v : vif.wd0_v) !== 1'b1)
        `uvm_error("HBM3_MON", $sformatf("write data clock %0d of %s not valid when due", xbeat[i], xq[i].convert2string()))
      xq[i].wdata[128 * xbeat[i] +: 128] = xq[i].pc ? vif.wd1 : vif.wd0;
      xbeat[i]++;
    end
  endfunction

  protected function void sample_rd();
    bit seen [2] = '{0, 0};
    for (int i = 0; i < xq.size(); i++) begin
      bit p = xq[i].pc;
      if (xq[i].write || xbeat[i] >= 2 || xdue[i] + xbeat[i] != n) continue;
      seen[p] = 1;
      if ((p ? vif.rd1_v : vif.rd0_v) !== 1'b1)
        `uvm_error("HBM3_MON", $sformatf("read data clock %0d of %s missing at RL %0d", xbeat[i], xq[i].convert2string(), rl))
      xq[i].rdata[128 * xbeat[i] +: 128] = p ? vif.rd1 : vif.rd0;
      xbeat[i]++;
    end
    if (!seen[0] && vif.rd0_v === 1'b1) `uvm_error("HBM3_MON", "PC0 read data with no read due")
    if (!seen[1] && vif.rd1_v === 1'b1) `uvm_error("HBM3_MON", "PC1 read data with no read due")
  endfunction
endclass
