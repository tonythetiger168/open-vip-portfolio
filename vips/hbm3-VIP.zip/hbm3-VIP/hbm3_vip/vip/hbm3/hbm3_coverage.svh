// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_coverage.svh -- functional coverage of the commands on the pins:
// every command the controller uses on both pseudo-channels; page hit /
// miss for reads and writes; consecutive column commands of a
// pseudo-channel in the same / another bank group (tCCDL / tCCDS paths) and
// the read / write turnarounds; PREpb / PREab in the rising and the falling
// half; MRS to MR0 / MR1 / MR2.

class hbm3_coverage extends uvm_subscriber #(hbm3_cmd_item);
  `uvm_component_utils(hbm3_coverage)

  hbm3_cmd_e kind;
  bit        pc, page_hit, same_bg, fall;
  int        pair;          // 0 RD-RD, 1 RD-WR, 2 WR-RD, 3 WR-WR
  bit [4:0]  ma;
  protected hbm3_cmd_e last_bank_cmd [2][16];
  protected bit have_col [2], last_w [2];
  protected bit [1:0] last_bg [2];

  covergroup cg_cmd;
    option.per_instance = 1;
    cp_kind: coverpoint kind {
      bins act = {H3_ACT}; bins rd = {H3_RD}; bins rda = {H3_RDA}; bins wr = {H3_WR};
      bins wra = {H3_WRA}; bins prepb = {H3_PREPB}; bins preab = {H3_PREAB};
      bins refab = {H3_REFAB}; bins refpb = {H3_REFPB};
    }
    cp_pc: coverpoint pc;
    x_kind_pc: cross cp_kind, cp_pc;
  endgroup

  covergroup cg_col;
    option.per_instance = 1;
    cp_page: coverpoint page_hit { bins miss = {0}; bins hit = {1}; }
    cp_rw:   coverpoint kind { bins rd = {H3_RD, H3_RDA}; bins wr = {H3_WR, H3_WRA}; }
    x_page_rw: cross cp_page, cp_rw;
  endgroup

  covergroup cg_pair;
    option.per_instance = 1;
    cp_pair: coverpoint pair { bins rr = {0}; bins rw = {1}; bins wr = {2}; bins ww = {3}; }
    cp_bg:   coverpoint same_bg { bins other_bg = {0}; bins same_bg = {1}; }
    x_pair_bg: cross cp_pair, cp_bg;
  endgroup

  covergroup cg_misc;
    option.per_instance = 1;
    cp_pre_half: coverpoint fall iff (kind inside {H3_PREPB, H3_PREAB}) { bins rise = {0}; bins fall = {1}; }
    cp_mrs: coverpoint ma iff (kind == H3_MRS) { bins mr0 = {0}; bins mr1 = {1}; bins mr2 = {2}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_cmd = new(); cg_col = new(); cg_pair = new(); cg_misc = new();
    foreach (last_bank_cmd[p, b]) last_bank_cmd[p][b] = H3_NONE;
  endfunction

  function void write(hbm3_cmd_item t);
    int b = int'(t.ba);
    kind = t.kind; pc = t.pc; fall = t.fall; ma = t.ma;
    cg_cmd.sample();
    cg_misc.sample();
    if (hbm3_is_rdwr(t.kind)) begin
      bit w = t.kind inside {H3_WR, H3_WRA};
      page_hit = last_bank_cmd[t.pc][b] != H3_ACT;
      cg_col.sample();
      if (have_col[t.pc]) begin
        pair = {last_w[t.pc], w};
        same_bg = (last_bg[t.pc] == t.ba[3:2]);
        cg_pair.sample();
      end
      have_col[t.pc] = 1; last_w[t.pc] = w; last_bg[t.pc] = t.ba[3:2];
    end
    if (t.kind inside {H3_ACT, H3_RD, H3_RDA, H3_WR, H3_WRA, H3_PREPB}) last_bank_cmd[t.pc][b] = t.kind;
  endfunction

  function real total();
    return (cg_cmd.get_inst_coverage() + cg_col.get_inst_coverage() + cg_pair.get_inst_coverage() +
            cg_misc.get_inst_coverage()) / 4.0;
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("hbm3 coverage %0.1f%% (commands %0.1f, page %0.1f, column pairs %0.1f, halves / MRS %0.1f)",
              total(), cg_cmd.get_inst_coverage(), cg_col.get_inst_coverage(), cg_pair.get_inst_coverage(),
              cg_misc.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
