// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_compliance_checker.sv -- HBM3 pin-level assertions (bindable)
//   * no X on R / C / ARFU / APAR in either half after reset
//   * APAR gives even parity over R, C, ARFU and APAR in every half when CA
//     parity is on (par_en)
//   * ACT: the falling half of its first cycle and the rising half of the
//     next cycle carry H H on R0 / R1
//   * the falling half carries RNOP, PREpb or PREab only (outside ACT)
//   * read and write data come in bursts of two clocks per pseudo-channel;
//     no X on read data
//   * AERR never rises

module hbm3_compliance_checker
  (input logic ck, input logic rst_n, input logic [9:0] r, input logic [7:0] c, input logic arfu,
   input logic apar, input logic par_en, input logic wd0_v, input logic wd1_v, input logic rd0_v,
   input logic rd1_v, input logic [127:0] rd0, input logic [127:0] rd1, input logic aerr);

  // rising half of ACT's first cycle seen at this posedge (act1); the
  // following rising half is its last half (act3)
  wire act1 = !r[0] && r[1] && r[2];
  logic act3;
  always_ff @(posedge ck or negedge rst_n)
    if (!rst_n) act3 <= 1'b0;
    else act3 <= act1 && !act3;
  logic act_rise;                       // the rising half of this cycle started an ACT
  always_ff @(posedge ck or negedge rst_n)
    if (!rst_n) act_rise <= 1'b0;
    else act_rise <= act1 && !act3;
  wire fall_ok = (r[0] && r[1] && r[2] && r[3]) || (r[0] && !r[1] && !r[2]) || (r[0] && !r[1] && r[2]);

  a_x_rise: assert property (@(posedge ck) disable iff (!rst_n) !$isunknown({r, c, arfu, apar}))
    else $error("HBM3: X on the command buses (rising half)");
  a_x_fall: assert property (@(negedge ck) disable iff (!rst_n) !$isunknown({r, c, arfu, apar}))
    else $error("HBM3: X on the command buses (falling half)");
  a_par_rise: assert property (@(posedge ck) disable iff (!rst_n || !par_en) ^{r, c, arfu, apar} == 1'b0)
    else $error("HBM3: CA parity wrong (rising half)");
  a_par_fall: assert property (@(negedge ck) disable iff (!rst_n || !par_en) ^{r, c, arfu, apar} == 1'b0)
    else $error("HBM3: CA parity wrong (falling half)");
  a_act_half2: assert property (@(negedge ck) disable iff (!rst_n) act_rise |-> r[1:0] == 2'b11)
    else $error("HBM3: ACT second half without H H");
  a_act_half3: assert property (@(posedge ck) disable iff (!rst_n) act3 |-> r[1:0] == 2'b11)
    else $error("HBM3: ACT third half without H H");
  a_fall_cmd: assert property (@(negedge ck) disable iff (!rst_n) !act_rise |-> fall_ok)
    else $error("HBM3: falling half carries a command other than RNOP / PREpb / PREab");
  a_rd0_burst: assert property (@(negedge ck) disable iff (!rst_n) $rose(rd0_v) |=> rd0_v)
    else $error("HBM3: PC0 read data shorter than two clocks");
  a_rd1_burst: assert property (@(negedge ck) disable iff (!rst_n) $rose(rd1_v) |=> rd1_v)
    else $error("HBM3: PC1 read data shorter than two clocks");
  a_wd0_burst: assert property (@(negedge ck) disable iff (!rst_n) $rose(wd0_v) |=> wd0_v)
    else $error("HBM3: PC0 write data shorter than two clocks");
  a_wd1_burst: assert property (@(negedge ck) disable iff (!rst_n) $rose(wd1_v) |=> wd1_v)
    else $error("HBM3: PC1 write data shorter than two clocks");
  a_rd_x: assert property (@(negedge ck) disable iff (!rst_n) (rd0_v |-> !$isunknown(rd0)) and (rd1_v |-> !$isunknown(rd1)))
    else $error("HBM3: X on read data");
  a_no_aerr: assert property (@(posedge ck) disable iff (!rst_n) !aerr)
    else $error("HBM3: AERR (CA parity error reported by the device)");

  c_act: cover property (@(posedge ck) disable iff (!rst_n) act1 && !act3);
  c_fall_pre: cover property (@(negedge ck) disable iff (!rst_n) !act_rise && r[0] && !r[1]);
  c_rd: cover property (@(negedge ck) disable iff (!rst_n) rd0_v || rd1_v);
  c_wd: cover property (@(negedge ck) disable iff (!rst_n) wd0_v || wd1_v);
endmodule
