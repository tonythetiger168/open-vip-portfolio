// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_transaction.svh -- one BL8 column access of a pseudo-channel (256
// bits, two clocks of data), as driven by the agent or seen on the pins; and
// one command decoded from the row / column buses.

class hbm3_transaction extends uvm_sequence_item;
  `uvm_object_utils(hbm3_transaction)

  rand bit         write;
  rand bit         pc;            // pseudo-channel
  rand bit [3:0]   ba;            // bank (BA[3:2] = bank group)
  rand bit [14:0]  row;
  rand bit [4:0]   ca;            // column address (one BL8 burst)
  rand bit [255:0] wdata;
  rand bit         auto_pre;      // RDA / WRA
  bit [255:0]      rdata;
  int unsigned     tag;
  int              t_cmd;         // cycle of the RD / WR (monitor)

  constraint c_data { !write -> wdata == 0; }

  function new(string name = "hbm3_transaction"); super.new(name); endfunction

  function bit [24:0] key(); return {pc, ba, row, ca}; endfunction

  function void do_copy(uvm_object rhs);
    hbm3_transaction r;
    if (!$cast(r, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    write = r.write; pc = r.pc; ba = r.ba; row = r.row; ca = r.ca; wdata = r.wdata;
    auto_pre = r.auto_pre; rdata = r.rdata; tag = r.tag; t_cmd = r.t_cmd;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    hbm3_transaction r;
    if (!$cast(r, rhs)) return 0;
    return write == r.write && key() == r.key() && wdata == r.wdata && rdata == r.rdata;
  endfunction

  // request fields only (driver view vs monitor view)
  function bit req_equal(hbm3_transaction r);
    return write == r.write && key() == r.key() && auto_pre == r.auto_pre && (!write || wdata == r.wdata);
  endfunction

  function string convert2string();
    return $sformatf("HBM3{tag=%0d %s%s pc=%0d ba=%0d row=%0h ca=%0h wdata=%0h rdata=%0h}", tag,
                     write ? "WR" : "RD", auto_pre ? "A" : "", pc, ba, row, ca, wdata, rdata);
  endfunction
endclass

class hbm3_cmd_item extends uvm_sequence_item;
  `uvm_object_utils(hbm3_cmd_item)
  hbm3_cmd_e kind;
  bit        pc;
  bit [3:0]  ba;
  bit [14:0] row;
  bit [4:0]  ca;
  bit [4:0]  ma;
  bit [7:0]  op;
  bit        fall;          // row command in the falling half
  bit        bad_half;      // ACT halves not H H, or a falling-half command other than PRE / RNOP
  int        t;             // cycle the device executes it (ACT: the cycle the row opens)

  function new(string name = "hbm3_cmd_item"); super.new(name); endfunction

  function string convert2string();
    case (kind)
      H3_ACT: return $sformatf("ACT@%0d pc%0d ba%0d row %0h", t, pc, ba, row);
      H3_RD, H3_RDA, H3_WR, H3_WRA: return $sformatf("%s@%0d pc%0d ba%0d ca %0h", kind.name(), t, pc, ba, ca);
      H3_MRS: return $sformatf("MRS@%0d MR%0d = %0h", t, ma, op);
      default: return $sformatf("%s@%0d pc%0d ba%0d%s", kind.name(), t, pc, ba, fall ? " (falling half)" : "");
    endcase
  endfunction
endclass
