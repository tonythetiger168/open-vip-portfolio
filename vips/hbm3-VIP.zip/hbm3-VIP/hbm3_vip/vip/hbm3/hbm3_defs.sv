// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// hbm3_defs.sv -- HBM3 (JESD238) command codes, the row / column bus
// encoders and decoders, and the device timing used by the agent.
//
// One channel, two pseudo-channels (PC0 / PC1) sharing the row bus R[9:0]
// and the column bus C[7:0]; both buses carry a half on the rising and a
// half on the falling edge of CK. Bank group = BA[3:2].

`ifndef HBM3_DEFS_SV
`define HBM3_DEFS_SV
package hbm3_defs_pkg;

  typedef enum int {
    H3_NONE, H3_ACT, H3_PREPB, H3_PREAB, H3_REFPB, H3_RFMPB, H3_REFAB, H3_RFMAB,
    H3_PDE, H3_SRE, H3_RD, H3_RDA, H3_WR, H3_WRA, H3_MRS, H3_RSVD
  } hbm3_cmd_e;

  // Device timing in clocks (the values the testbench gives the device model;
  // JESD238 leaves most of them to the vendor data sheet).
  typedef struct {
    int tRCDRD, tRCDWR, tRAS, tRP, tRRDL, tRRDS, tFAW, tCCDL, tCCDS, tRTP, tWR;
    int tWTRL, tWTRS, tRTW, tRFCab, tRFCpb, tRREFD, tMOD, tPPD;
    int RL_RST, WL_RST;
  } hbm3_timing_t;

  function automatic hbm3_timing_t hbm3_default_timing();
    hbm3_timing_t t;
    t.tRCDRD = 14; t.tRCDWR = 10; t.tRAS = 28; t.tRP = 14; t.tRRDL = 6; t.tRRDS = 4;
    t.tFAW = 16; t.tCCDL = 4; t.tCCDS = 2; t.tRTP = 5; t.tWR = 16; t.tWTRL = 9; t.tWTRS = 4;
    t.tRTW = 18; t.tRFCab = 350; t.tRFCpb = 200; t.tRREFD = 8; t.tMOD = 15; t.tPPD = 2;
    t.RL_RST = 14; t.WL_RST = 4;
    return t;
  endfunction

  function automatic bit hbm3_is_col(hbm3_cmd_e k);
    return k inside {H3_RD, H3_RDA, H3_WR, H3_WRA, H3_MRS};
  endfunction
  function automatic bit hbm3_is_rdwr(hbm3_cmd_e k);
    return k inside {H3_RD, H3_RDA, H3_WR, H3_WRA};
  endfunction

  // ---------------------------------------------------------------- row bus
  // NOP halves: the don't-care bits are driven low
  function automatic logic [9:0] hbm3_rnop(); return 10'b00_0000_1111; endfunction
  function automatic logic [7:0] hbm3_cnop(); return 8'b0000_0111; endfunction

  // ACT: rising + falling half of cycle t-1, rising half of cycle t
  function automatic void hbm3_enc_act(input logic pc, input logic [3:0] ba, input logic [14:0] row,
                                       output logic [9:0] h0, output logic [9:0] h1, output logic [9:0] h2);
    h0 = {ba, 2'b00, pc, 3'b110};            // R0..R2 = L H H
    h1 = {1'b0, row[14:8], 2'b11};
    h2 = {row[7:0], 2'b11};
  endfunction

  // one-half row command: PREpb, PREab, REFpb, RFMpb, REFab, RFMab
  function automatic logic [9:0] hbm3_enc_row(input hbm3_cmd_e k, input logic pc, input logic [3:0] ba);
    logic [2:0] code;                        // {R0, R1, R2}
    case (k)
      H3_PREPB: code = 3'b100;  H3_PREAB: code = 3'b101;
      H3_REFPB: code = 3'b000;  H3_RFMPB: code = 3'b001;
      default:  code = 3'b110;               // REFab / RFMab
    endcase
    return {(k inside {H3_PREPB, H3_REFPB, H3_RFMPB}) ? ba : {1'b0, k == H3_RFMAB, 2'b00},
            2'b00, pc, code[0], code[1], code[2]};
  endfunction

  // ---------------------------------------------------------------- column bus
  function automatic void hbm3_enc_col(input logic w, input logic ap, input logic pc, input logic [3:0] ba,
                                       input logic [4:0] ca, output logic [7:0] cr, output logic [7:0] cf);
    cr = {ba[0], 2'b00, pc, ap, !w, 2'b01};  // C0 = H, C1 = L, C2 = H read / L write, C3 = AP
    cf = {ca, ba[3:1]};
  endfunction

  function automatic void hbm3_enc_mrs(input logic [4:0] ma, input logic [7:0] op,
                                       output logic [7:0] cr, output logic [7:0] cf);
    cr = {ma[0], op[7], op[6], op[5], ma[4], 3'b000};
    cf = {op[4:0], ma[3], ma[2], ma[1]};
  endfunction

  // decode a one-half row command (not ACT, not NOP)
  function automatic hbm3_cmd_e hbm3_row_kind(input logic [9:0] x);
    case ({x[0], x[1], x[2]})
      3'b100: return H3_PREPB;
      3'b101: return H3_PREAB;
      3'b000: return H3_REFPB;
      3'b001: return H3_RFMPB;
      3'b110: return x[8] ? H3_RFMAB : H3_REFAB;
      3'b010: return x[3] ? H3_PDE : H3_SRE;
      default: return H3_RSVD;
    endcase
  endfunction
endpackage
`endif
