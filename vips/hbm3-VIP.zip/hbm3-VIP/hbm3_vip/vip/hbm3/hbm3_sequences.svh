// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

class hbm3_seq_base extends uvm_sequence #(hbm3_transaction);
  `uvm_object_utils(hbm3_seq_base)
  hbm3_config cfg;
  function new(string name = "hbm3_seq_base"); super.new(name); endfunction

  task access(bit w, bit p, bit [3:0] b, bit [14:0] r, bit [4:0] c, bit ap = 0);
    req = hbm3_transaction::type_id::create("req");
    start_item(req);
    req.write = w; req.pc = p; req.ba = b; req.row = r; req.ca = c; req.auto_pre = ap;
    req.wdata = '0;
    if (w) for (int i = 0; i < 8; i++) req.wdata[32 * i +: 32] = $urandom;
    finish_item(req);
  endtask
endclass

// Random traffic over both pseudo-channels: cfg.num_items accesses over
// cfg.rows rows per bank; half of the reads go to locations written before.
class hbm3_base_sequence extends hbm3_seq_base;
  `uvm_object_utils(hbm3_base_sequence)
  function new(string name = "hbm3_base_sequence"); super.new(name); endfunction

  task body();
    bit [24:0] written[$];
    int n = (cfg != null) ? cfg.num_items : 300;
    int rows = (cfg != null) ? cfg.rows : 4;
    int ap_pct = (cfg != null) ? cfg.auto_pre_pct : 25;
    repeat (n) begin
      bit w = ($urandom_range(99) < 55);
      bit ap = ($urandom_range(99) < ap_pct);
      bit [24:0] k = {1'($urandom), 4'($urandom), 15'($urandom_range(rows - 1)), 5'($urandom)};
      if (!w && written.size() && $urandom_range(1)) k = written[$urandom_range(written.size() - 1)];
      access(w, k[24], k[23:20], k[19:5], k[4:0], ap);
      if (w) written.push_back(k);
    end
  endtask
endclass

// Directed: page hit and miss, both pseudo-channels, back-to-back column
// commands in the same and another bank group (tCCDL / tCCDS), read/write
// turnarounds (tWTRL / tWTRS / tRTW), auto precharge, five activates in a
// row (tRRDL / tRRDS / tFAW), every bank of both pseudo-channels.
class hbm3_directed_sequence extends hbm3_seq_base;
  `uvm_object_utils(hbm3_directed_sequence)
  function new(string name = "hbm3_directed_sequence"); super.new(name); endfunction

  task body();
    access(1, 0, 0, 15'h0010, 5'd0);
    access(0, 0, 0, 15'h0010, 5'd0);
    access(1, 1, 0, 15'h0010, 5'd0);            // same address, other pseudo-channel
    access(0, 1, 0, 15'h0010, 5'd0);
    access(0, 0, 0, 15'h0010, 5'd0);
    access(1, 0, 0, 15'h0011, 5'd1);            // row miss: PRE, ACT
    access(0, 0, 0, 15'h0010, 5'd0);
    access(0, 0, 0, 15'h0011, 5'd1);
    access(1, 0, 4'd5, 15'h0020, 5'd2);         // same bank group (BA[3:2] = 1)
    access(1, 0, 4'd5, 15'h0020, 5'd3);
    access(1, 0, 4'd9, 15'h0020, 5'd4);         // other bank group
    access(0, 0, 4'd5, 15'h0020, 5'd2);
    access(0, 0, 4'd5, 15'h0020, 5'd3);
    access(0, 0, 4'd9, 15'h0020, 5'd4);
    access(0, 1, 4'd3, 15'h0030, 5'd5);         // read -> write -> read
    access(1, 1, 4'd3, 15'h0030, 5'd5);
    access(0, 1, 4'd3, 15'h0030, 5'd5);
    access(1, 0, 4'd7, 15'h0040, 5'd6, 1);      // auto precharge, then the bank again
    access(0, 0, 4'd7, 15'h0040, 5'd6, 1);
    access(0, 0, 4'd7, 15'h0041, 5'd7);
    for (int p = 0; p < 2; p++) for (int b = 0; b < 16; b++) access(1, p[0], b[3:0], 15'h0100 + b, 5'(b));
    for (int p = 0; p < 2; p++) for (int b = 0; b < 16; b++) access(0, p[0], b[3:0], 15'h0100 + b, 5'(b));
    access(0, 1, 4'd15, 15'h7FFF, 5'd31);       // never written: zero
  endtask
endclass
