// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm3_test.sv -- HBM3 UVM tests

`ifndef HBM3_TEST_SV
`define HBM3_TEST_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

class hbm3_base_test extends uvm_test;
  `uvm_component_utils(hbm3_base_test)
  hbm3_env env;
  function new(string name="hbm3_base_test", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = hbm3_env::type_id::create("env", this);
  endfunction
  task run_phase(uvm_phase phase);
    hbm3_regression_sequence seq;
    phase.raise_objection(this);
    seq = hbm3_regression_sequence::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: write flow only
class hbm3_write_test extends hbm3_base_test;
  `uvm_component_utils(hbm3_write_test)
  function new(string name="hbm3_write_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    hbm3_write_seq seq;
    phase.raise_objection(this);
    seq = hbm3_write_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Directed smoke test: read flow + refresh flow
class hbm3_read_test extends hbm3_base_test;
  `uvm_component_utils(hbm3_read_test)
  function new(string name="hbm3_read_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    hbm3_read_seq    rd;
    hbm3_refresh_seq rf;
    phase.raise_objection(this);
    rd = hbm3_read_seq::type_id::create("rd");
    rf = hbm3_refresh_seq::type_id::create("rf");
    rd.start(env.agt.sqr);
    rf.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Stress test: long protocol-legal random stream
class hbm3_stress_test extends hbm3_base_test;
  `uvm_component_utils(hbm3_stress_test)
  function new(string name="hbm3_stress_test", uvm_component parent=null); super.new(name, parent); endfunction
  task run_phase(uvm_phase phase);
    hbm3_stress_seq seq;
    phase.raise_objection(this);
    seq = hbm3_stress_seq::type_id::create("seq");
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
`endif
