# HBM3 Test Plan（hbm3-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | HBM3 |
| 家族 | Memory |
| 類型 | UVM VIP |
| 交付目錄 | `hbm3-VIP/` |
| 目前 L1b 狀態 | PASS(verilator) |

## 2. DUT / 待測對象

- `hbm3_dev_model`（`hbm3_vip/tb/hbm3_dev_model.sv`）：一個 channel、兩個 pseudo-channel，JESD238 row bus R[9:0] / column bus C[7:0] 雙沿取樣，bank 狀態機與時序規則，CA parity / AERR

## 3. 驗證環境

- UVM agent：driver 以兩個時脈沿驅動 R / C / APAR 與每個 PC 的資料，依全部時序規則排程；monitor 自行解碼兩條 bus；sequencer
- env：scoreboard（參考記憶體 + driver/monitor 比對）、規則檢查器（`HBM3_RULE`）、coverage
- SVA：`vip/hbm3/sva/hbm3_compliance_checker.sv`（腳位層）
- 裝置模型拒絕任何指令、bus error 或 AERR 即為 UVM error

## 4. 測試項目

### 4.1 UVM 測試

| 測試 | 內容 |
|---|---|
| `hbm3_func_test` | directed（page hit / miss、兩個 PC 同位址、同 / 不同 bank group、RD->WR->RD、auto precharge、兩個 PC 的每個 bank）+ 300 筆隨機存取 |
| `hbm3_base_test` | 300 筆隨機存取 |

msim 結果：868 個指令、0 違規、770 個 scoreboard check、coverage 100%。

### 4.2 功能測試（裝置模型）

`tb/func_hbm3_dev_tb.sv`：118 個 check（Verilator），`python3 tools/run_func_tests.py hbm3-VIP`。

## 5. 覆蓋與檢查

- `cg_cmd`：指令 × PC
- `cg_col`：page hit / miss × 讀 / 寫
- `cg_pair`：連續 column 指令（RD/WR × RD/WR）× 同 / 不同 bank group
- `cg_misc`：PRE 在上升 / 下降半週期；MRS 到 MR0 / MR1 / MR2
- 規則檢查器：保留碼、半週期使用、MRS 值、bank 狀態、tRCDRD / tRCDWR / tRP / tRAS / tRRDL / tRRDS / tFAW / tCCDL / tCCDS / tRTP / tWR / tWTRL / tWTRS / tRTW / tPPD / tRFCab / tRFCpb / tRREFD / tMOD

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/hbm3-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py hbm3-VIP && python3 smoke/smoke_run.py hbm3-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`
- L1d：`python3 tools/run_uvm_tests.py hbm3-VIP` -> `UVM_PASS`

## 7. 已知限制與備註

- 未建模：data bus inversion、data parity / DERR、ECC / SEV、IEEE 1500 port、power-down / self-refresh exit timing。

---
*文件版本：v1.7.5 自動產生*
