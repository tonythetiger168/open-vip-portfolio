# SAS — SAS-4 (Serial Attached SCSI) UVM VIP

Open-source UVM verification IP template for **SAS-4 (Serial Attached SCSI)** (Storage).

## Contents

| Path | Description |
|------|-------------|
| `sas/sas_if.sv` | Protocol interface + FSM state enum |
| `sas/sas_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `sas/sva/sas_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4) |
| `sas/vip/sas/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/sas_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with FSM-walking DUT stub |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Link-layer initiator driver**: full connection flow per transaction — OOB_RESET (COMRESET analog) → SPEED_NEG (training toggles) → IDENTIFY (SAS address exchange) → OPEN_ADDRESS (SSP read/write) → DATA_XFER (credit-based DATA frames) → CLOSE, serialized as UART-style frames on the txp/rxp differential pairs
- **Frame-decoding monitor**: UART-decodes both serial streams, reconstructs connection transactions (OPEN → DATA frames → CLOSE), cross-checks target echo vs transmitted payload
- **End-to-end scoreboard**: compares driver-issued vs monitor-decoded connections (frame type, SAS address, payload, reject/NAK/echo flags)
- **Functional DUT model**: SAS target with OOB/speed-neg detection + `phy_ready`, IDENTIFY response with its own SAS address, OPEN accept/reject by address, DATA frame echo + CREDIT, CRC check with NAK
- **Directed sequence library**: SSP read / SSP write / max-payload (credit-bound multi-frame) / single-word back-to-back / OPEN-reject error injection / CRC-error injection / reset + regression mix
- **Functional coverage**: frame_type × payload-length cross, address bins, first-word corners, link FSM states + transitions, error-injection coverage (reject / CRC-NAK / echo mismatch)
- **SVA L4**: OPEN only after IDENTIFY, every OPEN eventually CLOSED, DATA payload length limit, no DATA frame with exhausted credit, credit pool bound

Note: each connection re-runs a fast OOB/speed-neg/IDENTIFY cycle so the
link FSM walks its full legal cycle per transaction; `state` is the
initiator link-phase marker (CLOSE phase is a brief teardown marker).
