// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- SAS-4 (Serial Attached SCSI) testbench top with a
// functional SAS target DUT model

`ifndef SAS_TB_SV
`define SAS_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sas_defs_pkg::*;
import sas_pkg::*;
import sas_test_pkg::*;

module top_tb;
  logic phy_clk = 0;
  always #5ns phy_clk = ~phy_clk;

  sas_if vif(phy_clk);

  initial begin
    vif.phy_reset_n = 0;
    vif.state       = OOB_RESET;
    #100ns;
    vif.phy_reset_n = 1;
  end

  sas_target_model #(.TARGET_ADDR(SAS_TARGET_ADDR)) dut (.vif(vif));

  initial begin
    uvm_config_db#(virtual sas_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional SAS target: detects OOB (COMRESET analog) and speed
// negotiation on txp, asserts phy_ready, answers IDENTIFY with its own
// SAS address, accepts/rejects OPEN_ADDRESS frames, echoes DATA frames
// and returns CREDIT, and NAKs CRC-corrupted frames.
module sas_target_model #(parameter bit [63:0] TARGET_ADDR = 64'h5A5A_0000_0000_0001)  // SAS_TARGET_ADDR
  (sas_if vif);
  import sas_defs_pkg::*;

  typedef enum bit [1:0] {LINK_DOWN, LINK_SN, LINK_UP} link_e;
  link_e link;

  int unsigned zero_cnt   = 0;
  int unsigned toggle_cnt = 0;
  bit          prev_txp   = 1;
  bit          conn_open  = 0;

  // ---------------- link training detection (clk-sampled) ----------------
  always @(posedge vif.phy_clk or negedge vif.phy_reset_n) begin
    if (!vif.phy_reset_n) begin
      link          <= LINK_DOWN;
      zero_cnt      <= 0;
      toggle_cnt    <= 0;
      prev_txp      <= 1;
      vif.phy_ready <= 0;
    end else begin
      prev_txp <= vif.txp;
      case (link)
        LINK_DOWN: begin
          zero_cnt <= (vif.txp == 1'b0) ? zero_cnt + 1 : 0;
          if (zero_cnt >= SAS_OOB_DETECT) begin
            link       <= LINK_SN;
            toggle_cnt <= 0;
          end
        end
        LINK_SN: begin
          if (vif.txp !== prev_txp) toggle_cnt <= toggle_cnt + 1;
          if (vif.txp == 1'b0)      zero_cnt   <= zero_cnt + 1;
          else                      zero_cnt   <= 0;
          if (zero_cnt >= SAS_OOB_DETECT) begin   // OOB restarted
            link     <= LINK_DOWN;
            zero_cnt <= 0;
          end else if (toggle_cnt >= SAS_SN_DETECT) begin
            link          <= LINK_UP;
            vif.phy_ready <= 1;
            zero_cnt      <= 0;
          end
        end
        LINK_UP: begin
          zero_cnt <= (vif.txp == 1'b0) ? zero_cnt + 1 : 0;
          if (zero_cnt >= SAS_OOB_DETECT) begin   // new OOB: link down
            link          <= LINK_DOWN;
            vif.phy_ready <= 0;
            zero_cnt      <= 0;
          end
        end
        default: link <= LINK_DOWN;
      endcase
    end
  end

  // ---------------- serial line primitives (2 clk per bit cell) ----------------
  task automatic tx_bit(input bit v);
    vif.rxp <= v;
    repeat (2) @(posedge vif.phy_clk);
  endtask

  task automatic tx_byte(input bit [7:0] b);
    tx_bit(1'b0);
    for (int i = 0; i < 8; i++) tx_bit(b[i]);
    tx_bit(1'b1);
  endtask

  // Frame buffers live at module level: iverilog does not support queues
  // as task/function arguments nor variable queue indexing.
  bit [31:0]   io_words [0:SAS_FRAME_WORDS-1];  // payload words (rx/echo)
  int unsigned io_nwords = 0;
  bit [7:0]    cb_bytes [0:80];                 // crc/tx byte buffer
  int unsigned cb_n = 0;

  function automatic bit [7:0] crc8_buf(input int n);
    bit [7:0] c = 8'h00;
    for (int i = 0; i < n; i++) c ^= cb_bytes[i];
    return c;
  endfunction

  task automatic buf_push(input bit [7:0] v);
    cb_bytes[cb_n] = v;
    cb_n = cb_n + 1;
  endtask

  task automatic tx_frame(input bit [7:0] ftype, input bit [63:0] addr);
    cb_n = 0;
    buf_push(ftype);
    for (int i = 0; i < 8; i++) buf_push(addr[8*i +: 8]);
    buf_push(8'(io_nwords));
    for (int w = 0; w < io_nwords; w++)
      for (int i = 0; i < 4; i++) buf_push(io_words[w][8*i +: 8]);
    buf_push(crc8_buf(cb_n));
    for (int i = 0; i < cb_n; i++) tx_byte(cb_bytes[i]);
    tx_bit(1'b1);
  endtask

  task automatic rx_byte(output bit [7:0] b, output bit ok);
    ok = 0;
    // wait for start bit or link loss (no fork/disable fork: single event wait)
    @(negedge vif.txp or negedge vif.phy_ready);
    if (vif.phy_ready === 1'b1) begin
      repeat (3) @(posedge vif.phy_clk);
      for (int i = 0; i < 8; i++) begin
        b[i] = vif.txp;
        if (i != 7) repeat (2) @(posedge vif.phy_clk);
      end
      repeat (2) @(posedge vif.phy_clk);
      ok = (vif.txp === 1'b1);
      if (vif.phy_ready !== 1'b1) ok = 0;
    end
  endtask

  // iverilog cannot `return` from tasks: structured with ok flag instead.
  task automatic rx_frame(output bit [7:0] ftype, output bit [63:0] addr,
                          output bit crc_ok, output bit frame_ok);
    bit [7:0] b, len, crc_rx;
    bit [31:0] word;
    bit ok = 1;
    frame_ok  = 0;
    crc_ok    = 0;
    io_nwords = 0;
    rx_byte(ftype, ok);
    if (ok) begin
      for (int i = 0; i < 8 && ok; i++) begin
        rx_byte(b, ok);
        if (ok) addr[8*i +: 8] = b;
      end
    end
    if (ok) rx_byte(len, ok);
    if (ok && len > SAS_FRAME_WORDS) ok = 0;
    if (ok) begin
      for (int w = 0; w < len && ok; w++) begin
        for (int i = 0; i < 4 && ok; i++) begin
          rx_byte(b, ok);
          if (ok) word[8*i +: 8] = b;
        end
        if (ok) io_words[w] = word;
      end
    end
    if (ok) rx_byte(crc_rx, ok);
    if (ok) begin
      io_nwords = len;
      cb_n = 0;
      buf_push(ftype);
      for (int i = 0; i < 8; i++) buf_push(addr[8*i +: 8]);
      buf_push(len);
      for (int w = 0; w < len; w++)
        for (int i = 0; i < 4; i++) buf_push(io_words[w][8*i +: 8]);
      crc_ok   = (crc8_buf(cb_n) == crc_rx);
      frame_ok = 1;
    end
  endtask

  // ---------------- frame server ----------------
  initial begin : server
    bit [7:0] ftype;
    bit [63:0] addr;
    bit cok, fok;
    vif.rxp               = 1'b1;
    vif.credit_cnt        = 0;
    vif.data_frame_active = 0;
    vif.last_payload_len  = 0;
    forever begin
      wait (vif.phy_ready === 1'b1);
      conn_open               = 0;
      vif.credit_cnt          = 0;
      vif.data_frame_active   = 0;
      fok = 1;
      while (vif.phy_ready === 1'b1 && fok) begin
        rx_frame(ftype, addr, cok, fok);
        if (fok) begin
        case (ftype)
          SAS_FT_IDENTIFY: begin
            `uvm_info("DUT", $sformatf("IDENTIFY from 0x%016h", addr), UVM_HIGH)
            io_nwords = 0;
            tx_frame(SAS_FT_IDENTIFY, TARGET_ADDR);
          end
          SAS_FT_OPEN_READ, SAS_FT_OPEN_WRITE: begin
            io_nwords = 0;
            if (addr == TARGET_ADDR && cok) begin
              conn_open       = 1;
              vif.credit_cnt  = SAS_INIT_CREDITS;
              tx_frame(SAS_FT_ACCEPT, TARGET_ADDR);
            end else begin
              conn_open = 0;
              tx_frame(SAS_FT_REJECT, TARGET_ADDR);
            end
          end
          SAS_FT_DATA: if (conn_open) begin
            vif.data_frame_active = 1;
            vif.last_payload_len  = io_nwords;
            if (!cok) begin
              io_nwords = 0;
              tx_frame(SAS_FT_NAK, TARGET_ADDR);       // CRC error
            end else begin
              if (vif.credit_cnt > 0) vif.credit_cnt = vif.credit_cnt - 1;
              tx_frame(SAS_FT_DATA, addr);           // echo payload (io_words/io_nwords)
              io_nwords = 0;
              tx_frame(SAS_FT_CREDIT, TARGET_ADDR);    // replenish credit
              if (vif.credit_cnt < SAS_INIT_CREDITS)
                vif.credit_cnt = vif.credit_cnt + 1;
            end
            vif.data_frame_active = 0;
          end
          SAS_FT_CLOSE: begin
            conn_open      = 0;
            vif.credit_cnt = 0;
          end
          default: ;
        endcase
        end
      end
    end
  end
endmodule
`endif
