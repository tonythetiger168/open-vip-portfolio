// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_sas_tb.sv -- self-checking functional test for the SAS target model
// (sas_target_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py SAS-VIP
//
// Model contract (from tb/top_tb.sv and sas_defs.sv), an abstracted SAS link:
//   OOB: a 32-clock zero run on txp, then 24+ toggles, raises phy_ready;
//   a 33-clock zero run while up drops it. Bytes are serial,
//   2 clocks per bit: start 0, 8 data bits LSB first, stop 1.
//   Frame: type, address (8 bytes LSB first), word count (<= 4), words
//   (4 bytes LSB first each), XOR checksum of all previous bytes.
//   Target address 0x5A5A_0000_0000_0001. IDENTIFY -> IDENTIFY;
//   OPEN_READ/WRITE to the target with a good checksum -> ACCEPT and
//   credit_cnt = 4, otherwise REJECT; DATA on an open connection -> echo of
//   the DATA frame then CREDIT (bad checksum -> NAK), last_payload_len =
//   word count; DATA without a connection is ignored; CLOSE closes.
//
// Model defect: the zero-run counter is not cleared on entering speed
// negotiation, so a zero run longer than 32 clocks bounces SN -> DOWN and
// the link only comes up when the run is 32 (mod 34) clocks long. The VIP
// driver's COMRESET (48 clocks low, then toggles) never brings it up (XFAIL).
// The target is single-threaded: it listens again only after the trailing
// idle bit of its own response, so a frame started right after the response
// (as sas_driver does) is missed; the test leaves an 8-clock gap and checks
// the back-to-back case as XFAIL.

`timescale 1ns/1ps
module func_sas_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [7:0] FT_IDENTIFY = 8'h01, FT_OPEN_READ = 8'h02, FT_OPEN_WRITE = 8'h03,
                       FT_ACCEPT = 8'h04, FT_REJECT = 8'h05, FT_DATA = 8'h06,
                       FT_CREDIT = 8'h07, FT_CLOSE = 8'h08, FT_NAK = 8'h09;
  localparam bit [63:0] TGT = 64'h5A5A_0000_0000_0001, INI = 64'h1234_5678_9ABC_DEF0;
  int checks = 0, fails = 0, xfails = 0;

  logic clk = 1'b0, rst_n = 1'b0, txp = 1'b1;
  wire  rxp, phy_ready, data_frame_active;
  wire  [31:0] credit_cnt, last_payload_len;

  always #5 clk = ~clk;

  sas_target_model u_dut (
    .vif_phy_clk(clk), .vif_phy_reset_n(rst_n), .vif_txp(txp), .vif_rxp(rxp),
    .vif_phy_ready(phy_ready), .vif_credit_cnt(credit_cnt),
    .vif_data_frame_active(data_frame_active), .vif_last_payload_len(last_payload_len)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // ---------------- initiator side (txp) ----------------
  task automatic tbit(input bit v);
    txp = v;
    repeat (2) @(negedge clk);
  endtask
  task automatic tbyte(input bit [7:0] b, input bit bad_stop = 0);
    tbit(1'b0);
    for (int i = 0; i < 8; i++) tbit(b[i]);
    tbit(!bad_stop);
  endtask

  logic [31:0] w [0:7];
  task automatic tframe(input bit [7:0] ft, input bit [63:0] a, input int n,
                        input bit bad_ck = 0, input int gap = 8);
    bit [7:0] ck;
    ck = 0;
    repeat (gap) @(negedge clk);              // inter-frame idle
    tbyte(ft); ck ^= ft;
    for (int i = 0; i < 8; i++) begin tbyte(a[8*i +: 8]); ck ^= a[8*i +: 8]; end
    tbyte(8'(n)); ck ^= 8'(n);
    for (int k = 0; k < n; k++)
      for (int i = 0; i < 4; i++) begin tbyte(w[k][8*i +: 8]); ck ^= w[k][8*i +: 8]; end
    tbyte(ck ^ (bad_ck ? 8'h01 : 8'h00));
    tbit(1'b1);
  endtask

  // until_ready: stop toggling as soon as phy_ready rises, so no falling
  // txp edge reaches the target's byte receiver
  task automatic oob(input int zeros = 32, input int toggles = 30, input bit drv = 0,
                     input bit until_ready = 1);
    txp = 1'b0;
    repeat (zeros) @(negedge clk);
    for (int i = 0; i < toggles && !(until_ready && phy_ready); i++) begin
      txp = drv ? bit'(i % 2) : ~txp;         // drv: sas_driver's toggle pattern
      @(negedge clk);
    end
    txp = 1'b1;
    repeat (4) @(negedge clk);
  endtask

  // ---------------- target side (rxp) ----------------
  logic [7:0] rb [0:1023];
  int         rn = 0, rptr = 0, stop_err = 0;
  initial begin
    forever begin
      bit [7:0] b;
      @(negedge rxp);
      #10;                                    // middle of the start bit
      for (int i = 0; i < 8; i++) begin #20; b[i] = rxp; end
      #20;
      if (rxp !== 1'b1) stop_err++;
      rb[rn] = b; rn++;
      #5;
    end
  end

  // next received frame (got = 0 if none starts within tmo clocks)
  bit [7:0]  f_type, f_len;
  bit [63:0] f_addr;
  bit [31:0] f_w [0:7];
  bit        f_ck, got;
  task automatic rframe(input int tmo = 400);
    int k;
    bit [7:0] ck;
    got = 0; k = 0;
    while (rn == rptr && k < tmo) begin @(negedge clk); k++; end
    if (rn == rptr) return;
    // a complete header: 10 bytes, then len*4 + 1
    k = 0;
    while (rn - rptr < 10 && k < 2000) begin @(negedge clk); k++; end
    f_len = rb[rptr + 9];
    while (rn - rptr < 11 + 4 * f_len && k < 4000) begin @(negedge clk); k++; end
    ck = 0;
    f_type = rb[rptr]; ck ^= f_type;
    for (int i = 0; i < 8; i++) begin f_addr[8*i +: 8] = rb[rptr + 1 + i]; ck ^= rb[rptr + 1 + i]; end
    ck ^= f_len;
    for (int j = 0; j < f_len; j++)
      for (int i = 0; i < 4; i++) begin
        f_w[j][8*i +: 8] = rb[rptr + 10 + 4*j + i]; ck ^= rb[rptr + 10 + 4*j + i];
      end
    f_ck = (ck == rb[rptr + 10 + 4 * f_len]);
    rptr += 11 + 4 * f_len;
    got = 1;
  endtask

  function automatic bit hdr(input bit [7:0] ft, input bit [63:0] a, input int n);
    return got && f_type == ft && f_addr == a && f_len == n && f_ck;
  endfunction

  task automatic quiet(input int clocks);
    repeat (clocks) @(negedge clk);
  endtask

  // drop the link (33+ zero clocks), flush, bring it back up
  task automatic resync();
    quiet(600);
    txp = 1'b0; quiet(40); txp = 1'b1; quiet(4);
    oob();
    quiet(20);
    rptr = rn;
  endtask

  bit active_seen, wbad;
  int min_credit;
  always @(posedge clk) begin
    if (data_frame_active) active_seen = 1;
    if (credit_cnt < min_credit) min_credit = credit_cnt;
  end

  initial begin
    quiet(3);
    chk(!phy_ready && rxp === 1'b1 && credit_cnt == 0 && !data_frame_active,
        "reset: PHY not ready, rxp idle high, no credits");
    rst_n = 1'b1;
    quiet(2);

    // ---- OOB ----
    oob(20, 30);
    chk(!phy_ready, "20-clock zero run is not an OOB signal");
    oob(48, 32, 1, 0);
    chk_xfail(phy_ready, "VIP driver OOB (48 zero clocks, 32 toggles) brings the PHY ready");
    quiet(40);
    oob(32, 16, 0, 0);
    chk(!phy_ready && u_dut.link == 1, "32-clock zero run enters speed negotiation; 16 toggles are not enough");
    oob(0, 14);
    chk(phy_ready, "30 toggles complete speed negotiation: PHY ready");

    // ---- IDENTIFY ----
    tframe(FT_IDENTIFY, INI, 0);
    rframe();
    chk(hdr(FT_IDENTIFY, TGT, 0), "IDENTIFY answered with IDENTIFY from the target address");
    chk(stop_err == 0, "response bytes have valid stop bits");
    tframe(FT_IDENTIFY, INI, 0, 0, 0);        // no idle after the response
    rframe(600);
    chk_xfail(hdr(FT_IDENTIFY, TGT, 0), "frame sent right after the response's stop bit is received");
    resync();

    // ---- DATA without a connection ----
    w[0] = 32'h1111_1111;
    tframe(FT_DATA, TGT, 1);
    rframe(300);
    chk(!got && last_payload_len == 0, "DATA without an open connection is ignored");

    // ---- OPEN ----
    tframe(FT_OPEN_WRITE, 64'h5A5A_0000_0000_0002, 0);
    rframe();
    chk(hdr(FT_REJECT, TGT, 0) && credit_cnt == 0, "OPEN to another address -> REJECT");
    tframe(FT_OPEN_READ, TGT, 0, 1);
    rframe();
    chk(hdr(FT_REJECT, TGT, 0) && credit_cnt == 0, "OPEN with a bad checksum -> REJECT");
    tframe(FT_OPEN_WRITE, TGT, 0);
    rframe();
    chk(hdr(FT_ACCEPT, TGT, 0), "OPEN_WRITE to the target -> ACCEPT");
    chk(credit_cnt == 4, "ACCEPT grants 4 credits");

    // ---- DATA ----
    for (int k = 0; k < 4; k++) w[k] = 32'hA5000000 + k * 32'h0101_0101;
    active_seen = 0; min_credit = 99;
    tframe(FT_DATA, 64'h0000_0000_0000_0042, 4);
    rframe();
    wbad = 0;
    for (int k = 0; k < 4; k++) if (f_w[k] != w[k]) wbad = 1;
    chk(hdr(FT_DATA, 64'h42, 4) && !wbad, "DATA (4 words) echoed with its address and payload");
    rframe();
    chk(hdr(FT_CREDIT, TGT, 0), "CREDIT frame follows the echo");
    quiet(6);
    chk(last_payload_len == 4 && active_seen && !data_frame_active, "last_payload_len = 4, data_frame_active pulsed");
    chk(min_credit == 3 && credit_cnt == 4, "one credit consumed by DATA, returned with CREDIT");

    w[0] = 32'hDEAD_BEEF;
    tframe(FT_DATA, 64'h43, 1);
    rframe();
    chk(hdr(FT_DATA, 64'h43, 1) && f_w[0] == 32'hDEAD_BEEF, "1-word DATA echoed");
    rframe();
    quiet(6);
    chk(hdr(FT_CREDIT, TGT, 0) && last_payload_len == 1, "CREDIT, last_payload_len = 1");
    tframe(FT_DATA, 64'h44, 0);
    rframe();
    chk(hdr(FT_DATA, 64'h44, 0), "empty DATA echoed");
    rframe();
    quiet(6);
    chk(hdr(FT_CREDIT, TGT, 0) && last_payload_len == 0, "CREDIT, last_payload_len = 0");

    w[0] = 32'h0BAD_0BAD;
    tframe(FT_DATA, 64'h45, 1, 1);
    rframe();
    chk(hdr(FT_NAK, TGT, 0) && credit_cnt == 4, "DATA with a bad checksum -> NAK, credits unchanged");
    rframe(200);
    chk(!got, "no echo / CREDIT after a NAK");

    // ---- oversize word count: the frame is dropped after its length byte,
    //      and the rest of it is parsed as new frames (here: an IDENTIFY,
    //      answered although its checksum is wrong)
    for (int k = 0; k < 5; k++) w[k] = 32'h0101_0101;
    tframe(FT_DATA, 64'h46, 5);
    rframe(600);
    chk(!(got && f_type == FT_DATA), "DATA with more than 4 words is not echoed");
    chk_xfail(!got, "remainder of an oversize DATA frame is not parsed as new frames");
    resync();
    tframe(FT_OPEN_READ, TGT, 0);
    rframe();
    chk(hdr(FT_ACCEPT, TGT, 0) && credit_cnt == 4, "link re-established: OPEN_READ accepted");

    // ---- framing error (stop bit 0) mid frame ----
    quiet(8);
    tbyte(FT_IDENTIFY, 1);
    txp = 1'b1;
    quiet(40);
    rframe(200);
    chk(!got, "byte with a bad stop bit is dropped (no response)");

    // ---- CLOSE ----
    tframe(FT_OPEN_WRITE, TGT, 0);
    rframe();
    chk(hdr(FT_ACCEPT, TGT, 0) && credit_cnt == 4, "connection open before CLOSE");
    tframe(FT_CLOSE, TGT, 0);
    quiet(20);
    chk(credit_cnt == 0, "CLOSE clears the credits");
    tframe(FT_DATA, 64'h47, 0);
    rframe(300);
    chk(!got, "DATA after CLOSE is ignored");
    tframe(FT_OPEN_READ, TGT, 0);
    rframe();
    chk(hdr(FT_ACCEPT, TGT, 0) && credit_cnt == 4, "OPEN_READ re-opens the connection");

    // ---- link loss ----
    txp = 1'b0;
    quiet(40);
    txp = 1'b1;
    quiet(4);
    chk(!phy_ready, "33+ zero clocks while up drop phy_ready");
    quiet(40);
    oob();
    chk(phy_ready && credit_cnt == 0, "OOB brings the link back; the connection is closed");
    tframe(FT_IDENTIFY, INI, 0);
    rframe();
    chk(hdr(FT_IDENTIFY, TGT, 0), "IDENTIFY after link recovery");

    // SN toggles that continue after phy_ready (the VIP driver sends 32, the
    // target needs 25) start the byte receiver mid-negotiation
    txp = 1'b0; quiet(40); txp = 1'b1; quiet(4);
    oob(32, 32, 0, 0);
    chk(phy_ready, "link up after a full 32-toggle speed negotiation");
    tframe(FT_IDENTIFY, INI, 0);
    rframe(600);
    chk_xfail(hdr(FT_IDENTIFY, TGT, 0), "first frame after 32 SN toggles is received correctly");

    // ---- reset ----
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(!phy_ready, "reset drops phy_ready");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #3000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
