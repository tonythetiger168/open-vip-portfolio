// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// env_pkg.sv -- SAS-4 (Serial Attached SCSI) verification environment
// with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import sas_defs_pkg::*;
  import sas_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) connection
  // transactions against monitor-decoded (observed) ones.
  class sas_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(sas_scoreboard)
    uvm_analysis_imp_exp #(sas_transaction, sas_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(sas_transaction, sas_scoreboard) obs_ap;

    sas_transaction exp_q[$], obs_q[$];
    int unsigned match_count = 0, mismatch_count = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(sas_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(sas_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        sas_transaction e = exp_q.pop_front();
        sas_transaction o = obs_q.pop_front();
        bit payload_ok = (e.open_rejected || e.crc_nak) ||
                         (e.payload == o.payload && e.rpayload == o.rpayload);
        if (e.frame_type == o.frame_type && e.sas_addr == o.sas_addr &&
            e.open_rejected == o.open_rejected && e.crc_nak == o.crc_nak &&
            e.echo_mismatch == o.echo_mismatch && payload_ok)
          match_count++;
        else begin
          mismatch_count++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("sas scoreboard: matches=%0d mismatches=%0d",
                match_count, mismatch_count), UVM_LOW)
      if (mismatch_count) `uvm_error("SB", "end-to-end mismatches detected")
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("unmatched transactions exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
    endfunction
  endclass

  class sas_env extends uvm_env;
    `uvm_component_utils(sas_env)
    sas_agent      agt;
    sas_scoreboard sb;
    sas_checker    chk;
    sas_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = sas_agent::type_id::create("agt", this);
      sb  = sas_scoreboard::type_id::create("sb", this);
      chk = sas_checker::type_id::create("chk", this);
      cov = sas_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
