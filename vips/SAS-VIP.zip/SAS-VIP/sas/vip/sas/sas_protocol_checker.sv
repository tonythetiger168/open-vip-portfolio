// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_protocol_checker.sv -- SAS-4 (Serial Attached SCSI) protocol rule checker

`ifndef SAS_PROTOCOL_CHECKER_SV
`define SAS_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import sas_defs_pkg::sas_state_e;

module sas_protocol_checker
(
  input logic phy_clk,
  input logic phy_reset_n,
  input sas_state_e state
);
  a_sas_protocol_state_known : assert property (@(posedge phy_clk)
    disable iff (!phy_reset_n) !$isunknown(state))
    else `uvm_error("PROTOCOL", "sas protocol: state unknown")
endmodule
`endif
