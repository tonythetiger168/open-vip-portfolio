// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_transaction.svh -- SAS connection transaction: one OPEN_ADDRESS
// (SSP read/write) + DATA_XFER + CLOSE exchange between initiator and target.

class sas_transaction extends uvm_sequence_item;

  // Error-injection knobs
  typedef enum bit [1:0] {
    SAS_ERR_NONE,        // normal connection
    SAS_ERR_OPEN_REJECT, // OPEN_ADDRESS sent to a non-existent SAS address
    SAS_ERR_CRC          // first DATA frame carries a corrupted CRC
  } sas_err_e;

  rand bit [7:0]  frame_type;    // SAS_FT_OPEN_READ / SAS_FT_OPEN_WRITE
  rand bit [63:0] sas_addr;      // destination SAS address (target)
  rand bit [31:0] payload[$];    // SSP data words for this connection
  rand sas_err_e  error_inject;

  // Observed by monitor / driver (not randomized)
  bit        open_rejected;      // target answered OPEN_REJECT
  bit        crc_nak;            // target NAKed a CRC-corrupted DATA frame
  bit        echo_mismatch;      // target echo != transmitted data
  bit [31:0] rpayload[$];        // echoed words observed on the return path

  constraint c_ftype  { frame_type inside {sas_defs_pkg::SAS_FT_OPEN_READ,
                                           sas_defs_pkg::SAS_FT_OPEN_WRITE}; }
  constraint c_addr   { soft sas_addr == sas_defs_pkg::SAS_TARGET_ADDR; }
  constraint c_len    { payload.size() inside {[1:sas_defs_pkg::SAS_MAX_PAYLOAD_WORDS]}; }
  constraint c_err    { error_inject dist {SAS_ERR_NONE        := 7,
                                           SAS_ERR_OPEN_REJECT := 2,
                                           SAS_ERR_CRC         := 1}; }

  `uvm_object_utils_begin(sas_transaction)
    `uvm_field_int(frame_type, UVM_ALL_ON)
    `uvm_field_int(sas_addr, UVM_ALL_ON)
    `uvm_field_queue_int(payload, UVM_ALL_ON)
    `uvm_field_enum(sas_err_e, error_inject, UVM_ALL_ON)
    `uvm_field_int(open_rejected, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(crc_nak, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(echo_mismatch, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_queue_int(rpayload, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "sas_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    sas_transaction t;
    bit ok = 1;
    ok &= super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    ok &= comparer.compare_field("frame_type", frame_type, t.frame_type, 8);
    ok &= comparer.compare_field("sas_addr", sas_addr, t.sas_addr, 64);
    if (!open_rejected && !crc_nak)
      ok &= comparer.compare_field("payload_size", payload.size(),
                                   t.payload.size(), 32);
    return ok;
  endfunction

  function string convert2string();
    string s = $sformatf("SAS %s addr=0x%016h words=%0d err=%s",
                         frame_type == sas_defs_pkg::SAS_FT_OPEN_READ ? "RD" : "WR",
                         sas_addr, payload.size(), error_inject.name());
    if (open_rejected) s = {s, " OPEN_REJECTED"};
    if (crc_nak)       s = {s, " CRC_NAK"};
    if (echo_mismatch) s = {s, " ECHO_MISMATCH"};
    return s;
  endfunction
endclass
