// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_monitor.svh -- SAS monitor: UART-decodes the serial frame streams on
// txp (initiator) and rxp (target), reconstructs one connection transaction
// per OPEN_ADDRESS..CLOSE exchange and publishes it on ap.

class sas_monitor extends uvm_monitor;
  `uvm_component_utils(sas_monitor)
  virtual sas_if vif;
  uvm_analysis_port #(sas_transaction) ap;
  int unsigned txn_count = 0;

  // Aggregation state (written by the txp decoder, also fed by rxp decoder)
  protected sas_transaction cur;
  protected bit           pending = 0;
  protected bit [31:0]    last_chunk[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sas_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sas virtual interface not set")
  endfunction

  function automatic bit [7:0] crc8(input bit [7:0] bytes[$]);
    bit [7:0] c = 8'h00;
    foreach (bytes[i]) c ^= bytes[i];
    return c;
  endfunction

  // Byte capture with abort on link loss (line is virtual: sel picks txp/rxp)
  task automatic rx_byte(input bit sel, output bit [7:0] b, output bit ok);
    // the forked branch writes locals (an automatic output may not be
    // written after a timing control); copied out once the fork is done
    bit [7:0] lb = '0;
    bit       lok = 0;
    fork
      begin : capture
        // bit cells are timed with raw clock edges and raw line values: the
        // line changes on a clock edge (target NBA or initiator clocking
        // drive) and the clocking-block event of that same edge fires in the
        // Observed region (14.13), so counting @(mon_cb) after the start
        // edge would be one cell early for the target's line
        if (sel) @(negedge vif.txp); else @(negedge vif.rxp);
        repeat (3) @(posedge vif.phy_clk);
        for (int i = 0; i < 8; i++) begin
          lb[i] = sel ? vif.txp : vif.rxp;
          if (i != 7) repeat (2) @(posedge vif.phy_clk);
        end
        repeat (2) @(posedge vif.phy_clk);
        lok = (sel ? vif.txp : vif.rxp) === 1'b1;
      end
      begin : link_loss
        @(negedge vif.phy_ready);
      end
    join_any
    disable fork;
    b = lb; ok = lok;
    if (vif.phy_ready !== 1'b1) ok = 0;
  endtask

  // Returns 0 when the link dropped mid-frame (partial frame discarded)
  task automatic rx_frame(input bit sel, output bit [7:0] ftype,
                          output bit [63:0] addr, output bit [31:0] words[$],
                          output bit crc_ok, output bit frame_ok);
    bit [7:0] b, len, crc_rx, bytes[$];
    bit ok = 1;
    words.delete();
    frame_ok = 0;
    crc_ok   = 0;
    rx_byte(sel, ftype, ok);        if (!ok) return;
    for (int i = 0; i < 8; i++) begin
      rx_byte(sel, b, ok);          if (!ok) return;
      addr[8*i +: 8] = b;
    end
    rx_byte(sel, len, ok);          if (!ok) return;
    if (len > sas_defs_pkg::SAS_FRAME_WORDS) return;   // implausible: desync
    for (int w = 0; w < len; w++) begin
      bit [31:0] word;
      for (int i = 0; i < 4; i++) begin
        rx_byte(sel, b, ok);        if (!ok) return;
        word[8*i +: 8] = b;
      end
      words.push_back(word);
    end
    rx_byte(sel, crc_rx, ok);       if (!ok) return;
    bytes.push_back(ftype);
    for (int i = 0; i < 8; i++) bytes.push_back(addr[8*i +: 8]);
    bytes.push_back(len);
    foreach (words[w])
      for (int i = 0; i < 4; i++) bytes.push_back(words[w][8*i +: 8]);
    crc_ok   = (crc8(bytes) == crc_rx);
    frame_ok = 1;
  endtask

  function void publish();
    if (!pending) return;
    if (cur.open_rejected)      cur.error_inject = sas_transaction::SAS_ERR_OPEN_REJECT;
    else if (cur.crc_nak)       cur.error_inject = sas_transaction::SAS_ERR_CRC;
    else                        cur.error_inject = sas_transaction::SAS_ERR_NONE;
    txn_count++;
    `uvm_info("MON", {"mon: ", cur.convert2string()}, UVM_HIGH)
    ap.write(cur);
    pending = 0;
  endfunction

  // Initiator (txp) frame stream: OPEN starts a transaction, DATA extends
  // it, CLOSE completes it.
  task automatic decode_txp();
    bit [7:0] ftype;
    bit [63:0] addr;
    bit [31:0] words[$];
    bit cok, fok;
    forever begin
      wait (vif.phy_ready === 1'b0);
      wait (vif.phy_ready === 1'b1);
      // speed-negotiation toggles go on for a while after phy_ready: arm
      // only once txp has idled high for 4 clocks (as the target does)
      begin
        int n = 0;
        while (n < 4 && vif.phy_ready === 1'b1) begin
          @(posedge vif.phy_clk);
          n = (vif.txp === 1'b1) ? n + 1 : 0;
        end
      end
      while (vif.phy_ready === 1'b1) begin
        rx_frame(1'b1, ftype, addr, words, cok, fok);
        if (!fok) break;
        case (ftype)
          sas_defs_pkg::SAS_FT_OPEN_READ,
          sas_defs_pkg::SAS_FT_OPEN_WRITE: begin
            publish();                       // finalize stale transaction
            cur = sas_transaction::type_id::create("cur");
            cur.frame_type = ftype;
            cur.sas_addr   = addr;
            pending  = 1;
          end
          sas_defs_pkg::SAS_FT_DATA: if (pending) begin
            foreach (words[i]) cur.payload.push_back(words[i]);
            last_chunk = words;
            if (!cok) cur.crc_nak = 1;       // corrupt CRC seen on the wire
          end
          sas_defs_pkg::SAS_FT_CLOSE: publish();
          default: ;                         // IDENTIFY etc.: link bookkeeping
        endcase
      end
      pending = 0;
    end
  endtask

  // Target (rxp) frame stream: REJECT completes a transaction early, NAK
  // flags a CRC error, DATA is the echo (data-integrity cross-check).
  task automatic decode_rxp();
    bit [7:0] ftype;
    bit [63:0] addr;
    bit [31:0] words[$];
    bit cok, fok;
    forever begin
      wait (vif.phy_ready === 1'b0);
      wait (vif.phy_ready === 1'b1);
      repeat (2) @(vif.mon_cb);
      while (vif.phy_ready === 1'b1) begin
        rx_frame(1'b0, ftype, addr, words, cok, fok);
        if (!fok) break;
        case (ftype)
          sas_defs_pkg::SAS_FT_REJECT: if (pending) begin
            cur.open_rejected = 1;
            publish();
          end
          sas_defs_pkg::SAS_FT_NAK: if (pending) cur.crc_nak = 1;
          sas_defs_pkg::SAS_FT_DATA: if (pending) begin
            foreach (words[i]) cur.rpayload.push_back(words[i]);
            if (words != last_chunk) cur.echo_mismatch = 1;
          end
          default: ;                         // ACCEPT / CREDIT / IDENTIFY rsp
        endcase
      end
    end
  endtask

  task run_phase(uvm_phase phase);
    wait (vif.phy_reset_n === 1'b1);
    fork
      decode_txp();
      decode_rxp();
    join
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("sas monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
