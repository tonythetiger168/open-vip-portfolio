// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_if.sv -- SAS-4 (Serial Attached SCSI) interface
//
// Simplified link model: txp/txn is the initiator->target differential
// pair, rxp/rxn the target->initiator pair. Frames are UART-style serial
// byte streams (start bit / 8 data bits LSB-first / stop bit, 2 phy_clk
// cycles per bit cell) riding on the positive leg of each pair.

interface sas_if (input logic phy_clk);
  import sas_defs_pkg::sas_state_e;

  logic phy_reset_n;
  logic txp;
  logic txn;
  logic rxp;
  logic rxn;
  logic phy_ready;             // target: link trained (OOB + speed-neg done)

  sas_state_e state;           // initiator link-layer FSM phase marker

  // Target-side link observability (SVA / debug)
  int unsigned credit_cnt;         // credits currently granted to initiator
  logic        data_frame_active;  // target is processing a received DATA frame
  int unsigned last_payload_len;   // word count of last received DATA frame

  // Differential complements
  assign txn = ~txp;
  assign rxn = ~rxp;

  modport INITIATOR (input  phy_clk, phy_reset_n, rxp, phy_ready, credit_cnt,
                     output txp, state);
  modport TARGET    (input  phy_clk, phy_reset_n, txp,
                     output rxp, phy_ready, credit_cnt, data_frame_active,
                     last_payload_len);
  modport MON       (input  phy_clk, phy_reset_n, txp, rxp, phy_ready, state,
                     credit_cnt, data_frame_active, last_payload_len);

  clocking drv_cb @(posedge phy_clk);
    input  phy_reset_n, rxp, phy_ready, credit_cnt;
    output txp;
  endclocking

  clocking mon_cb @(posedge phy_clk);
    input phy_reset_n, txp, rxp, phy_ready, state,
          credit_cnt, data_frame_active, last_payload_len;
  endclocking
endinterface
