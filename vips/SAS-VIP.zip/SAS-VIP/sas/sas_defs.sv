// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_defs.sv -- SAS-4 (Serial Attached SCSI) shared type definitions

package sas_defs_pkg;
  typedef enum bit [2:0] {
    OOB_RESET,
    SPEED_NEG,
    IDENTIFY,
    OPEN_ADDRESS,
    DATA_XFER,
    CLOSE
  } sas_state_e;

  // ---- Link-layer frame type encodings (simplified SSP link model) ----
  localparam bit [7:0] SAS_FT_IDENTIFY   = 8'h01;  // identify address frame
  localparam bit [7:0] SAS_FT_OPEN_READ  = 8'h02;  // OPEN_ADDRESS frame (SSP read)
  localparam bit [7:0] SAS_FT_OPEN_WRITE = 8'h03;  // OPEN_ADDRESS frame (SSP write)
  localparam bit [7:0] SAS_FT_ACCEPT     = 8'h04;  // OPEN_ACCEPT
  localparam bit [7:0] SAS_FT_REJECT     = 8'h05;  // OPEN_REJECT
  localparam bit [7:0] SAS_FT_DATA       = 8'h06;  // SSP data frame (also echo)
  localparam bit [7:0] SAS_FT_CREDIT     = 8'h07;  // credit grant
  localparam bit [7:0] SAS_FT_CLOSE      = 8'h08;  // CLOSE primitive frame
  localparam bit [7:0] SAS_FT_NAK        = 8'h09;  // CRC-error negative ack

  // ---- Link model parameters ----
  localparam bit [63:0]  SAS_INITIATOR_ADDR   = 64'h1111_0000_0000_0001;
  localparam bit [63:0]  SAS_TARGET_ADDR      = 64'h5A5A_0000_0000_0001;
  localparam int unsigned SAS_MAX_PAYLOAD_WORDS = 8;   // 32-bit words per connection
  localparam int unsigned SAS_FRAME_WORDS       = 4;   // 32-bit words per DATA frame
  localparam int unsigned SAS_INIT_CREDITS      = 4;   // credits granted on ACCEPT
  localparam int unsigned SAS_OOB_CYCLES        = 48;  // COMRESET analog: line held low
  localparam int unsigned SAS_OOB_DETECT        = 32;  // target zero-run detect threshold
  localparam int unsigned SAS_SN_CYCLES         = 32;  // speed-negotiation toggle count
  localparam int unsigned SAS_SN_DETECT         = 24;  // target toggle detect threshold
endpackage
