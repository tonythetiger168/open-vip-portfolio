// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_compliance_checker.sv -- SAS-4 (Serial Attached SCSI) SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = SAS link-layer specific rules

`ifndef SAS_COMPLIANCE_CHECKER_SV
`define SAS_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import sas_defs_pkg::*;

module sas_compliance_checker
(
  input logic phy_clk,
  input logic phy_reset_n,
  input sas_state_e state,
  input logic phy_ready,
  input int unsigned credit_cnt,
  input logic data_frame_active,
  input int unsigned last_payload_len
);

  // ---------------- L1: signal sanity (4) ----------------
  a_sas_l1_clk   : assert property (@(posedge phy_clk) disable iff (!phy_reset_n) !$isunknown(phy_clk))
    else `uvm_error("SVA_L1", "sas: clock unknown")
  a_sas_l1_rst   : assert property (@(posedge phy_clk) !$isunknown(phy_reset_n))
    else `uvm_error("SVA_L1", "sas: reset unknown")
  a_sas_l1_state : assert property (@(posedge phy_clk) disable iff (!phy_reset_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "sas: state unknown")
  a_sas_l1_valid : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state inside {OOB_RESET, SPEED_NEG, IDENTIFY, OPEN_ADDRESS, DATA_XFER, CLOSE})
    else `uvm_error("SVA_L1", "sas: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from OOB_RESET
  a_sas_trans_oob_reset : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == OOB_RESET |=> state inside {OOB_RESET, SPEED_NEG})
    else `uvm_error("SVA_L2", "sas: illegal transition from OOB_RESET")

  // L2-2: legal FSM transition from SPEED_NEG
  a_sas_trans_speed_neg : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == SPEED_NEG |=> state inside {SPEED_NEG, IDENTIFY})
    else `uvm_error("SVA_L2", "sas: illegal transition from SPEED_NEG")

  // L2-3: legal FSM transition from IDENTIFY
  a_sas_trans_identify : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == IDENTIFY |=> state inside {IDENTIFY, OPEN_ADDRESS})
    else `uvm_error("SVA_L2", "sas: illegal transition from IDENTIFY")

  // L2-4: legal FSM transition from OPEN_ADDRESS
  a_sas_trans_open_address : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == OPEN_ADDRESS |=> state inside {OPEN_ADDRESS, DATA_XFER})
    else `uvm_error("SVA_L2", "sas: illegal transition from OPEN_ADDRESS")

  // L2-5: legal FSM transition from DATA_XFER
  a_sas_trans_data_xfer : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == DATA_XFER |=> state inside {DATA_XFER, CLOSE})
    else `uvm_error("SVA_L2", "sas: illegal transition from DATA_XFER")

  // L2-6: legal FSM transition from CLOSE
  a_sas_trans_close : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == CLOSE |=> state inside {CLOSE, OOB_RESET})
    else `uvm_error("SVA_L2", "sas: illegal transition from CLOSE")

  // ---------------- L3: protocol rules (4) ----------------
  a_sas_l3_reset_idle : assert property (@(posedge phy_clk)
    $fell(phy_reset_n) |-> ##[1:4] (state == OOB_RESET))
    else `uvm_error("SVA_L3", "sas: state not OOB_RESET during reset")
  a_sas_l3_no_stuck   : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == CLOSE |-> ##[1:8] (state != CLOSE))
    else `uvm_error("SVA_L3", "sas: stuck in CLOSE")
  a_sas_l3_full_cycle : cover property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == OOB_RESET ##1 state == SPEED_NEG);
  a_sas_l3_back_idle  : cover property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == CLOSE ##1 state == OOB_RESET);

  // ---------------- L4: SAS link-layer specific rules (5) ----------------
  // Track IDENTIFY completion per link session
  bit identified;
  always @(posedge phy_clk or negedge phy_reset_n) begin
    if (!phy_reset_n)            identified <= 1'b0;
    else if (state == IDENTIFY)  identified <= 1'b1;
    else if (state == OOB_RESET) identified <= 1'b0;
  end

  // L4-1: OPEN_ADDRESS may only follow a completed IDENTIFY exchange
  a_sas_l4_open_after_identify : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    state == OPEN_ADDRESS |-> identified)
    else `uvm_error("SVA_L4", "sas: OPEN_ADDRESS before IDENTIFY")

  // L4-2: every OPEN_ADDRESS must eventually be closed
  a_sas_l4_open_close_pair : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    $rose(state == OPEN_ADDRESS) |-> s_eventually (state == CLOSE))
    else `uvm_error("SVA_L4", "sas: OPEN_ADDRESS without matching CLOSE")

  // L4-3: DATA frame payload length must not exceed the negotiated maximum
  a_sas_l4_payload_max : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    $fell(data_frame_active) |-> last_payload_len <= SAS_FRAME_WORDS)
    else `uvm_error("SVA_L4", "sas: DATA frame payload exceeds maximum")

  // L4-4: no DATA frame may be transmitted with exhausted credit
  a_sas_l4_credit_ok : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    $rose(data_frame_active) |-> credit_cnt > 0)
    else `uvm_error("SVA_L4", "sas: DATA frame sent with zero credit")

  // L4-5: granted credits never exceed the ACCEPT pool
  a_sas_l4_credit_max : assert property (@(posedge phy_clk) disable iff (!phy_reset_n)
    credit_cnt <= SAS_INIT_CREDITS)
    else `uvm_error("SVA_L4", "sas: credit count exceeds granted pool")

endmodule
`endif
