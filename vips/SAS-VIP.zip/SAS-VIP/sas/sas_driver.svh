// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_driver.svh -- SAS initiator driver. Per sequence item the driver
// walks the full link-layer flow on the serial txp/rxp pairs:
//   OOB_RESET -> SPEED_NEG -> IDENTIFY -> OPEN_ADDRESS -> DATA_XFER -> CLOSE
// and publishes the expected transaction on drv_ap for the scoreboard.

class sas_driver extends uvm_driver #(sas_transaction);
  `uvm_component_utils(sas_driver)
  virtual sas_if vif;
  sas_config cfg;
  uvm_analysis_port #(sas_transaction) drv_ap;  // expected items for scoreboard
  protected bit [31:0] EMPTY_WORDS[$];          // constant empty payload argument

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual sas_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "sas virtual interface not set")
  endfunction

  // ---------------- serial line primitives (2 clk per bit cell) ----------------
  task automatic tx_bit(input bit v);
    vif.drv_cb.txp <= v;
    repeat (2) @(vif.drv_cb);
  endtask

  task automatic tx_byte(input bit [7:0] b);
    tx_bit(1'b0);                          // start
    for (int i = 0; i < 8; i++) tx_bit(b[i]);
    tx_bit(1'b1);                          // stop
  endtask

  function automatic bit [7:0] crc8(input bit [7:0] bytes[$]);
    bit [7:0] c = 8'h00;
    foreach (bytes[i]) c ^= bytes[i];
    return c;
  endfunction

  // Frame = ftype | addr[7:0] x8 (LSB first) | len | payload bytes | crc
  task automatic tx_frame(input bit [7:0] ftype, input bit [63:0] addr,
                          input bit [31:0] words[$], input bit corrupt_crc = 0);
    bit [7:0] bytes[$];
    bytes.push_back(ftype);
    for (int i = 0; i < 8; i++) bytes.push_back(addr[8*i +: 8]);
    bytes.push_back(8'(words.size()));
    foreach (words[w])
      for (int i = 0; i < 4; i++) bytes.push_back(words[w][8*i +: 8]);
    bytes.push_back(crc8(bytes) ^ (corrupt_crc ? 8'hFF : 8'h00));
    foreach (bytes[i]) tx_byte(bytes[i]);
    tx_bit(1'b1);                          // inter-frame idle
  endtask

  task automatic rx_byte(output bit [7:0] b, output bit ok);
    @(negedge vif.rxp);                    // start-bit edge
    repeat (3) @(vif.drv_cb);              // centre of bit-0 cell
    for (int i = 0; i < 8; i++) begin
      b[i] = vif.drv_cb.rxp;
      if (i != 7) repeat (2) @(vif.drv_cb);
    end
    repeat (2) @(vif.drv_cb);              // centre of stop cell
    ok = (vif.drv_cb.rxp === 1'b1);
  endtask

  task automatic rx_frame(output bit [7:0] ftype, output bit [63:0] addr,
                          output bit [31:0] words[$], output bit crc_ok);
    bit [7:0] b, len, crc_rx, bytes[$];
    bit ok;
    words.delete();
    rx_byte(ftype, ok);
    for (int i = 0; i < 8; i++) begin
      rx_byte(b, ok);
      addr[8*i +: 8] = b;
    end
    rx_byte(len, ok);
    for (int w = 0; w < len; w++) begin
      bit [31:0] word;
      for (int i = 0; i < 4; i++) begin
        rx_byte(b, ok);
        word[8*i +: 8] = b;
      end
      words.push_back(word);
    end
    rx_byte(crc_rx, ok);
    bytes.push_back(ftype);
    for (int i = 0; i < 8; i++) bytes.push_back(addr[8*i +: 8]);
    bytes.push_back(len);
    foreach (words[w])
      for (int i = 0; i < 4; i++) bytes.push_back(words[w][8*i +: 8]);
    crc_ok = (crc8(bytes) == crc_rx);
  endtask

  // ---------------- link-layer phases ----------------
  task automatic do_oob();
    vif.state = sas_defs_pkg::OOB_RESET;
    vif.drv_cb.txp <= 1'b0;                          // COMRESET analog
    repeat (sas_defs_pkg::SAS_OOB_CYCLES) @(vif.drv_cb);
  endtask

  task automatic do_speed_neg();
    vif.state = sas_defs_pkg::SPEED_NEG;
    for (int i = 0; i < sas_defs_pkg::SAS_SN_CYCLES; i++) begin
      vif.drv_cb.txp <= bit'(i % 2);                 // training toggles
      @(vif.drv_cb);
    end
    vif.drv_cb.txp <= 1'b1;                          // back to idle
    wait (vif.phy_ready === 1'b1);
    repeat (2) @(vif.drv_cb);
  endtask

  task automatic do_identify();
    bit [7:0] ftype;
    bit [63:0] addr;
    bit [31:0] words[$];
    bit cok;
    vif.state = sas_defs_pkg::IDENTIFY;
    tx_frame(sas_defs_pkg::SAS_FT_IDENTIFY, sas_defs_pkg::SAS_INITIATOR_ADDR, EMPTY_WORDS);
    rx_frame(ftype, addr, words, cok);
    if (ftype != sas_defs_pkg::SAS_FT_IDENTIFY || !cok)
      `uvm_warning("DRV", "IDENTIFY response missing or corrupt")
    else
      `uvm_info("DRV", $sformatf("identified target 0x%016h", addr), UVM_HIGH)
  endtask

  // OPEN_ADDRESS -> DATA_XFER -> CLOSE for one connection
  task automatic do_connection(sas_transaction tr);
    bit [7:0] ftype;
    bit [63:0] addr;
    bit [31:0] words[$];
    bit cok;
    int credits = 0;
    int idx = 0;
    bit corrupted = 0;

    // ---- OPEN_ADDRESS ----
    vif.state = sas_defs_pkg::OPEN_ADDRESS;
    tx_frame(tr.frame_type, tr.sas_addr, EMPTY_WORDS);
    rx_frame(ftype, addr, words, cok);

    if (ftype == sas_defs_pkg::SAS_FT_REJECT) begin
      tr.open_rejected = 1;
      `uvm_warning("DRV", $sformatf("OPEN to 0x%016h rejected", tr.sas_addr))
      vif.state = sas_defs_pkg::DATA_XFER;           // pass-through, no frames
      repeat (2) @(vif.drv_cb);
    end else if (ftype == sas_defs_pkg::SAS_FT_ACCEPT && cok) begin
      credits = sas_defs_pkg::SAS_INIT_CREDITS;
      // ---- DATA_XFER: payload split into <= SAS_FRAME_WORDS chunks ----
      vif.state = sas_defs_pkg::DATA_XFER;
      while (idx < tr.payload.size()) begin
        bit [31:0] chunk[$];
        bit corrupt = 0;
        for (int k = 0; k < sas_defs_pkg::SAS_FRAME_WORDS && idx < tr.payload.size(); k++)
          chunk.push_back(tr.payload[idx++]);
        while (credits == 0) begin                   // credit exhausted: wait
          rx_frame(ftype, addr, words, cok);
          if (ftype == sas_defs_pkg::SAS_FT_CREDIT) credits++;
        end
        credits--;
        corrupt = (tr.error_inject == sas_transaction::SAS_ERR_CRC) && !corrupted;
        if (corrupt) corrupted = 1;
        tx_frame(sas_defs_pkg::SAS_FT_DATA, tr.sas_addr, chunk, corrupt);
        rx_frame(ftype, addr, words, cok);           // echo or NAK
        if (ftype == sas_defs_pkg::SAS_FT_NAK) begin
          tr.crc_nak = 1;
          `uvm_warning("DRV", "DATA frame NAKed (CRC error)")
          break;
        end
        if (ftype == sas_defs_pkg::SAS_FT_DATA) begin
          foreach (words[i]) tr.rpayload.push_back(words[i]);
          if (words != chunk) begin
            tr.echo_mismatch = 1;
            `uvm_warning("DRV", "target echo mismatch")
          end
        end
        rx_frame(ftype, addr, words, cok);           // CREDIT
        if (ftype == sas_defs_pkg::SAS_FT_CREDIT) credits++;
      end
    end else begin
      `uvm_warning("DRV", "no valid OPEN response")
      vif.state = sas_defs_pkg::DATA_XFER;
      repeat (2) @(vif.drv_cb);
    end

    // ---- CLOSE (CLOSE phase marker is brief by protocol convention) ----
    tx_frame(sas_defs_pkg::SAS_FT_CLOSE, tr.sas_addr, EMPTY_WORDS);
    vif.state = sas_defs_pkg::CLOSE;
    repeat (4) @(vif.drv_cb);
  endtask

  task run_phase(uvm_phase phase);
    sas_transaction tr;
    vif.drv_cb.txp <= 1'b1;                          // idle line
    vif.state = sas_defs_pkg::OOB_RESET;
    wait (vif.phy_reset_n === 1'b1);
    repeat (4) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      do_oob();
      do_speed_neg();
      do_identify();
      do_connection(tr);
      drv_ap.write(tr);                              // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask

endclass
