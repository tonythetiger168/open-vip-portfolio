// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_coverage.svh -- SAS functional coverage: protocol (frame type x
// payload length cross), link FSM, and error-injection coverage.

class sas_coverage extends uvm_subscriber #(sas_transaction);
  `uvm_component_utils(sas_coverage)

  sas_transaction tr;
  sas_state_e cur_state;

  covergroup cg_protocol;
    cp_ftype : coverpoint tr.frame_type {
      bins open_rd = {sas_defs_pkg::SAS_FT_OPEN_READ};
      bins open_wr = {sas_defs_pkg::SAS_FT_OPEN_WRITE};
    }
    cp_addr : coverpoint tr.sas_addr {
      bins target = {sas_defs_pkg::SAS_TARGET_ADDR};
      bins other  = default;
    }
    cp_len  : coverpoint tr.payload.size() {
      bins single = {1};
      bins short  = {[2:3]};
      bins frame  = {sas_defs_pkg::SAS_FRAME_WORDS};
      bins multi  = {[sas_defs_pkg::SAS_FRAME_WORDS+1 : sas_defs_pkg::SAS_MAX_PAYLOAD_WORDS-1]};
      bins max    = {sas_defs_pkg::SAS_MAX_PAYLOAD_WORDS};
    }
    cp_word0 : coverpoint tr.payload[0] iff (tr.payload.size() > 0) {
      bins zero = {32'h0000_0000};
      bins ones = {32'hFFFF_FFFF};
      bins data = default;
    }
    cx_ftype_len : cross cp_ftype, cp_len;
  endgroup

  covergroup cg_fsm with function sample(sas_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {OOB_RESET, SPEED_NEG, IDENTIFY, OPEN_ADDRESS, DATA_XFER, CLOSE};
    }
    cp_trans : coverpoint s {
      bins link_up  = (OOB_RESET => SPEED_NEG => IDENTIFY);
      bins conn     = (IDENTIFY => OPEN_ADDRESS => DATA_XFER);
      bins teardown = (DATA_XFER => CLOSE => OOB_RESET);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.error_inject {
      bins none   = {sas_transaction::SAS_ERR_NONE};
      bins reject = {sas_transaction::SAS_ERR_OPEN_REJECT};
      bins crc    = {sas_transaction::SAS_ERR_CRC};
    }
    cp_open_rejected : coverpoint tr.open_rejected { bins no = {0}; bins yes = {1}; }
    cp_crc_nak       : coverpoint tr.crc_nak       { bins no = {0}; bins yes = {1}; }
    cp_echo_mismatch : coverpoint tr.echo_mismatch { bins no = {0}; bins yes = {1}; }
    cx_err_ftype : cross cp_err, cp_open_rejected, cp_crc_nak;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(sas_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_fsm.sample(cur_state);
    cg_error.sample();
  endfunction
endclass
