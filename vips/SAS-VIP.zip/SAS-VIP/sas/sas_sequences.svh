// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// sas_sequences.svh -- SAS sequence library: each item is one full
// link connection (OOB -> IDENTIFY -> OPEN -> DATA -> CLOSE).

class sas_base_sequence extends uvm_sequence #(sas_transaction);
  `uvm_object_utils(sas_base_sequence)
  int num_txns = 20;
  function new(string name = "sas_base_sequence"); super.new(name); endfunction
  task body();
    sas_transaction tr;
    repeat (num_txns) begin
      tr = sas_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: SSP read connections (OPEN_READ frames)
class sas_ssp_read_seq extends sas_base_sequence;
  `uvm_object_utils(sas_ssp_read_seq)
  function new(string name = "sas_ssp_read_seq"); super.new(name); endfunction
  task body();
    sas_transaction tr;
    repeat (num_txns) begin
      tr = sas_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { frame_type == sas_defs_pkg::SAS_FT_OPEN_READ;
                                  error_inject == SAS_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: SSP write connections (OPEN_WRITE frames)
class sas_ssp_write_seq extends sas_base_sequence;
  `uvm_object_utils(sas_ssp_write_seq)
  function new(string name = "sas_ssp_write_seq"); super.new(name); endfunction
  task body();
    sas_transaction tr;
    repeat (num_txns) begin
      tr = sas_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { frame_type == sas_defs_pkg::SAS_FT_OPEN_WRITE;
                                  error_inject == SAS_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: maximum-payload connections (multi-frame, credit-bound)
class sas_max_payload_seq extends sas_base_sequence;
  `uvm_object_utils(sas_max_payload_seq)
  function new(string name = "sas_max_payload_seq"); super.new(name); endfunction
  task body();
    sas_transaction tr;
    repeat (num_txns) begin
      tr = sas_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { payload.size() == sas_defs_pkg::SAS_MAX_PAYLOAD_WORDS;
                                  error_inject == SAS_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: single-word back-to-back connections
class sas_single_word_seq extends sas_base_sequence;
  `uvm_object_utils(sas_single_word_seq)
  function new(string name = "sas_single_word_seq"); super.new(name); endfunction
  task body();
    sas_transaction tr;
    repeat (num_txns) begin
      tr = sas_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { payload.size() == 1;
                                  error_inject == SAS_ERR_NONE; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: OPEN_ADDRESS to a non-existent SAS address -> OPEN_REJECT
class sas_open_reject_seq extends sas_base_sequence;
  `uvm_object_utils(sas_open_reject_seq)
  function new(string name = "sas_open_reject_seq"); super.new(name); endfunction
  task body();
    sas_transaction tr;
    repeat (num_txns) begin
      tr = sas_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == SAS_ERR_OPEN_REJECT;
                                  sas_addr != sas_defs_pkg::SAS_TARGET_ADDR; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: CRC-corrupted DATA frame -> target NAK
class sas_crc_error_seq extends sas_base_sequence;
  `uvm_object_utils(sas_crc_error_seq)
  function new(string name = "sas_crc_error_seq"); super.new(name); endfunction
  task body();
    sas_transaction tr;
    repeat (num_txns) begin
      tr = sas_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == SAS_ERR_CRC;
                                  payload.size() inside {[2:sas_defs_pkg::SAS_MAX_PAYLOAD_WORDS]}; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: one connection attempted right after reset release
class sas_reset_seq extends sas_base_sequence;
  `uvm_object_utils(sas_reset_seq)
  function new(string name = "sas_reset_seq"); super.new(name); endfunction
  task body();
    sas_transaction tr = sas_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { payload.size() == 1; error_inject == SAS_ERR_NONE; });
    finish_item(tr);
  endtask
endclass

class sas_random_sequence extends sas_base_sequence;
  `uvm_object_utils(sas_random_sequence)
  function new(string name = "sas_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class sas_regression_sequence extends sas_base_sequence;
  `uvm_object_utils(sas_regression_sequence)
  function new(string name = "sas_regression_sequence"); super.new(name); endfunction
  task body();
    sas_ssp_read_seq    rd  = sas_ssp_read_seq::type_id::create("rd");
    sas_ssp_write_seq   wr  = sas_ssp_write_seq::type_id::create("wr");
    sas_max_payload_seq maxp = sas_max_payload_seq::type_id::create("maxp");
    sas_single_word_seq sw  = sas_single_word_seq::type_id::create("sw");
    sas_open_reject_seq rej = sas_open_reject_seq::type_id::create("rej");
    sas_crc_error_seq   crc = sas_crc_error_seq::type_id::create("crc");
    rd.num_txns = 15; wr.num_txns = 15; maxp.num_txns = 8;
    sw.num_txns = 10; rej.num_txns = 4; crc.num_txns = 4;
    rd.start(m_sequencer);  wr.start(m_sequencer);
    maxp.start(m_sequencer); sw.start(m_sequencer);
    rej.start(m_sequencer); crc.start(m_sequencer);
  endtask
endclass
