// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2025 Functional smoke testbench (CXL endpoint channel writes)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened mp_endpoint_mem_model
// (the CXL VIP's flattened endpoint/channel memory model).
// DUT behaviour (from dut_mp_endpoint_mem_model.sv):
//   - write-only channel sink: SOP beat carries address in data[127:64];
//     if EOP same beat, single-DW write of data[31:0] to mem[addr]
//   - continuation beats write data[31:0] to mem[cur_addr], cur_addr += 4,
//     until EOP; wr_count counts completed transactions
//   - while rst_n is low, incoming beats are ignored
// The model exposes no readback port, so the transaction roundtrip is
// verified white-box via hierarchical probe of the endpoint's memory
// (u_dut.mem[...]) and transaction counter (u_dut.wr_count).

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic         vif_clk   = 1'b0;
  logic         vif_rst_n = 1'b0;
  logic         vif_valid = 1'b0;
  logic [511:0] vif_data  = 512'h0;
  logic         vif_sop   = 1'b0;
  logic         vif_eop   = 1'b0;

  always #5 vif_clk = ~vif_clk;

  mp_endpoint_mem_model u_dut (
    .vif_clk(vif_clk), .vif_rst_n(vif_rst_n), .vif_valid(vif_valid),
    .vif_data(vif_data), .vif_sop(vif_sop), .vif_eop(vif_eop)
  );

  task automatic chk(input bit cond, input string name);
    begin
      checks++;
      if (!cond) begin
        fails++;
        $display("  [FAIL] %s", name);
      end
    end
  endtask

  // drive one 512-bit channel beat
  task automatic send_beat(input bit sop, input bit eop,
                           input [63:0] addr, input [31:0] payload);
    begin
      @(negedge vif_clk);
      vif_valid = 1'b1; vif_sop = sop; vif_eop = eop;
      vif_data = 512'h0;
      vif_data[127:64] = addr;
      vif_data[31:0]   = payload;
      @(negedge vif_clk);
      vif_valid = 1'b0; vif_sop = 1'b0; vif_eop = 1'b0;
    end
  endtask

  initial begin
    // a channel beat presented during reset must be ignored
    @(negedge vif_clk);
    vif_valid = 1'b1; vif_sop = 1'b1; vif_eop = 1'b1;
    vif_data[127:64] = 64'h7777; vif_data[31:0] = 32'hBAD0_BAD0;
    @(negedge vif_clk);
    vif_valid = 1'b0; vif_sop = 1'b0; vif_eop = 1'b0;
    chk(u_dut.wr_count == 0, "channel beat during reset is ignored");

    // release reset
    repeat (3) @(posedge vif_clk);
    @(negedge vif_clk);
    vif_rst_n = 1'b1;

    // single-beat transaction (SOP+EOP): addr 0x4000 <- 0xC0FFEE01
    send_beat(1'b1, 1'b1, 64'h4000, 32'hC0FF_EE01);
    chk(u_dut.wr_count == 1, "single-beat transaction counted once");
    chk(u_dut.mem[64'h4000] === 32'hC0FF_EE01,
        "single-beat transaction data stored at address");

    // multi-beat transaction roundtrip: header beat + 3 payload DWs
    send_beat(1'b1, 1'b0, 64'h5000, 32'h0);            // SOP, addr phase
    chk(u_dut.in_tlp === 1'b1, "channel busy between SOP and EOP");
    send_beat(1'b0, 1'b0, 64'h0, 32'hAAAA_0001);       // mem[0x5000]
    send_beat(1'b0, 1'b0, 64'h0, 32'hBBBB_0002);       // mem[0x5004]
    send_beat(1'b0, 1'b1, 64'h0, 32'hCCCC_0003);       // mem[0x5008], EOP
    chk(u_dut.wr_count == 2, "multi-beat transaction counted once at EOP");
    chk(u_dut.in_tlp === 1'b0, "channel idle after EOP");
    chk(u_dut.mem[64'h5000] === 32'hAAAA_0001, "payload DW0 at addr+0");
    chk(u_dut.mem[64'h5004] === 32'hBBBB_0002, "payload DW1 at addr+4");
    chk(u_dut.mem[64'h5008] === 32'hCCCC_0003, "payload DW2 at addr+8");

    // back-to-back single-beat transaction updates same address
    send_beat(1'b1, 1'b1, 64'h4000, 32'h5EED_5EED);
    chk(u_dut.wr_count == 3, "back-to-back transaction counted");
    chk(u_dut.mem[64'h4000] === 32'h5EED_5EED,
        "later transaction overwrites previous contents");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  // safety timeout (well below 100us budget)
  initial begin
    #80000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
