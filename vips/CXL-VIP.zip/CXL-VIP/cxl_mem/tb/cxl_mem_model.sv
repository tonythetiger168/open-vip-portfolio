// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cxl_mem_model.sv -- CXL.mem Type 3 memory device (HDM-H) reference model at
// the transaction-channel level (CXL 2.0 section 3.3):
//   M2S Req  MemInv 0000, MemRd 0001, MemRdData 0010, MemSpecRd 1000,
//            MemInvNT 1001 (MemRdFwd / MemWrFwd and reserved codes: err[2])
//   M2S RwD  MemWr 0001, MemWrPtl 0010 (64-bit byte enable), poison
//   S2M NDR  Cmp 000 (MemInv / MemInvNT / MemWr / MemWrPtl)
//   S2M DRS  MemData 000 (MemRd / MemRdData), poison
// Metadata: one 2-bit Meta0-State per 64-byte line. A request with
// MetaField = Meta0-State (2'b00) sets it to MetaValue, except MemRdData;
// MetaField = No-Op (2'b11) leaves it. Responses carry the state the line
// had when the request arrived. MemSpecRd has no response.
// Requests execute in arrival order (a read sees every earlier write) but
// complete out of order: a request to line L responds 4 + 6 * L[1:0]
// clocks after it arrives, so tags must be matched.
// HDM range [hdm_base, hdm_base + hdm_size): outside it reads return poisoned
// all-zero data and writes are completed and dropped (err[3]).
// Link credits: the device advertises REQ_CRD Req and RWD_CRD RwD credits
// and returns them (req_crd_ret count / rwd_crd_ret pulse) when the request has
// responded (MemSpecRd: on arrival); a request beyond the credits is
// dropped (err[0] / err[1]). The host's NDR / DRS credits are loaded from
// host_ndr_crd / host_drs_crd in reset and returned by ndr_crd_ret /
// drs_crd_ret pulses; a response waits for a credit.
module cxl_mem_model #(parameter int REQ_CRD = 8, parameter int RWD_CRD = 4) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [51:0]  hdm_base,
  input  logic [51:0]  hdm_size,
  input  logic         m2s_req_valid,
  input  logic [3:0]   m2s_req_opcode,
  input  logic [51:6]  m2s_req_addr,
  input  logic [15:0]  m2s_req_tag,
  input  logic [1:0]   m2s_req_metafield,
  input  logic [1:0]   m2s_req_metavalue,
  input  logic         m2s_rwd_valid,
  input  logic [3:0]   m2s_rwd_opcode,
  input  logic [51:6]  m2s_rwd_addr,
  input  logic [15:0]  m2s_rwd_tag,
  input  logic [1:0]   m2s_rwd_metafield,
  input  logic [1:0]   m2s_rwd_metavalue,
  input  logic [511:0] m2s_rwd_data,
  input  logic [63:0]  m2s_rwd_be,
  input  logic         m2s_rwd_poison,
  output logic         s2m_ndr_valid,
  output logic [2:0]   s2m_ndr_opcode,
  output logic [15:0]  s2m_ndr_tag,
  output logic [1:0]   s2m_ndr_metavalue,
  output logic         s2m_drs_valid,
  output logic [2:0]   s2m_drs_opcode,
  output logic [15:0]  s2m_drs_tag,
  output logic [1:0]   s2m_drs_metavalue,
  output logic [511:0] s2m_drs_data,
  output logic         s2m_drs_poison,
  input  logic [7:0]   host_ndr_crd,
  input  logic [7:0]   host_drs_crd,
  input  logic         ndr_crd_ret,
  input  logic         drs_crd_ret,
  output logic [1:0]   req_crd_ret,       // credits returned this clock
  output logic         rwd_crd_ret,
  output logic [3:0]   err
);
  localparam int NP = 16;
  logic [511:0] mem  [0:255];
  logic [1:0]   meta [0:255];
  logic         pois [0:255];
  // pending responses
  logic         p_v    [0:NP-1];
  logic         p_drs  [0:NP-1];     // 1: DRS MemData, 0: NDR Cmp
  logic         p_rwd  [0:NP-1];     // credit to return
  logic [15:0]  p_tag  [0:NP-1];
  logic [1:0]   p_meta [0:NP-1];
  logic [511:0] p_data [0:NP-1];
  logic         p_pois [0:NP-1];
  logic [15:0]  p_due  [0:NP-1];
  logic [15:0]  now;
  logic [7:0]   req_used, rwd_used, ndr_crd, drs_crd;

  function automatic logic in_hdm(input logic [51:6] a);
    logic [51:0] b;
    b = {a, 6'b0};
    return b >= hdm_base && b < hdm_base + hdm_size;
  endfunction
  function automatic logic [7:0] line_of(input logic [51:6] a);
    logic [51:0] b;
    b = {a, 6'b0} - hdm_base;
    return b[13:6];
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 256; i++) begin mem[i] = '0; meta[i] = 2'b00; pois[i] = 1'b0; end
      for (int i = 0; i < NP; i++) p_v[i] = 1'b0;
      now <= '0; req_used = '0; rwd_used = '0; ndr_crd = host_ndr_crd; drs_crd = host_drs_crd;
      s2m_ndr_valid <= 1'b0; s2m_ndr_opcode <= '0; s2m_ndr_tag <= '0; s2m_ndr_metavalue <= '0;
      s2m_drs_valid <= 1'b0; s2m_drs_opcode <= '0; s2m_drs_tag <= '0; s2m_drs_metavalue <= '0;
      s2m_drs_data <= '0; s2m_drs_poison <= 1'b0;
      req_crd_ret <= 2'd0; rwd_crd_ret <= 1'b0; err <= '0;
    end else begin : step
      logic [1:0] rq_ret;
      logic wd_ret;
      int bn, bd;
      rq_ret = 2'd0; wd_ret = 1'b0;
      now <= now + 16'd1;
      if (ndr_crd_ret) ndr_crd = ndr_crd + 8'd1;
      if (drs_crd_ret) drs_crd = drs_crd + 8'd1;

      // ---------------- M2S RwD (before Req: a same-clock read sees the write)
      if (m2s_rwd_valid) begin
        if (rwd_used == 8'(RWD_CRD)) err[1] <= 1'b1;
        else if (m2s_rwd_opcode != 4'b0001 && m2s_rwd_opcode != 4'b0010) err[2] <= 1'b1;
        else begin : wr
          logic [7:0] l;
          int k;
          l = line_of(m2s_rwd_addr);
          k = -1;
          for (int i = NP - 1; i >= 0; i--) if (!p_v[i]) k = i;
          if (k < 0) err[1] <= 1'b1;
          else begin
            rwd_used = rwd_used + 8'd1;
            p_v[k] = 1'b1; p_drs[k] = 1'b0; p_rwd[k] = 1'b1; p_tag[k] = m2s_rwd_tag; p_pois[k] = 1'b0;
            p_due[k] = now + 16'd4 + 16'd6 * {14'd0, m2s_rwd_addr[7:6]};
            p_data[k] = '0;
            if (in_hdm(m2s_rwd_addr)) begin
              p_meta[k] = meta[l];
              for (int b = 0; b < 64; b++)
                if (m2s_rwd_opcode == 4'b0001 || m2s_rwd_be[b]) mem[l][8 * b +: 8] = m2s_rwd_data[8 * b +: 8];
              if (m2s_rwd_opcode == 4'b0001) pois[l] = m2s_rwd_poison;
              else pois[l] = pois[l] | m2s_rwd_poison;
              if (m2s_rwd_metafield == 2'b00) meta[l] = m2s_rwd_metavalue;
            end else begin
              p_meta[k] = 2'b00;
              err[3] <= 1'b1;
            end
          end
        end
      end

      // ---------------- M2S Req
      if (m2s_req_valid) begin
        if (req_used == 8'(REQ_CRD)) err[0] <= 1'b1;
        else if (!(m2s_req_opcode inside {4'b0000, 4'b0001, 4'b0010, 4'b1000, 4'b1001})) err[2] <= 1'b1;
        else if (m2s_req_opcode == 4'b1000) rq_ret = rq_ret + 2'd1;        // MemSpecRd: no response
        else begin : rd
          logic [7:0] l;
          int k;
          l = line_of(m2s_req_addr);
          k = -1;
          for (int i = NP - 1; i >= 0; i--) if (!p_v[i]) k = i;
          if (k < 0) err[0] <= 1'b1;
          else begin
            req_used = req_used + 8'd1;
            p_v[k] = 1'b1; p_rwd[k] = 1'b0; p_tag[k] = m2s_req_tag;
            p_drs[k] = (m2s_req_opcode == 4'b0001 || m2s_req_opcode == 4'b0010);
            p_due[k] = now + 16'd4 + 16'd6 * {14'd0, m2s_req_addr[7:6]};
            if (in_hdm(m2s_req_addr)) begin
              p_data[k] = mem[l]; p_pois[k] = pois[l]; p_meta[k] = meta[l];
              if (m2s_req_metafield == 2'b00 && m2s_req_opcode != 4'b0010) meta[l] = m2s_req_metavalue;
            end else begin
              p_data[k] = '0; p_pois[k] = 1'b1; p_meta[k] = 2'b00;
              err[3] <= 1'b1;
            end
          end
        end
      end

      // ---------------- responses: the oldest due entry per channel
      s2m_ndr_valid <= 1'b0; s2m_drs_valid <= 1'b0;
      bn = -1; bd = -1;
      for (int i = 0; i < NP; i++)
        if (p_v[i] && 16'(now - p_due[i]) < 16'h8000) begin
          if (p_drs[i]) begin if (bd < 0 || 16'(p_due[bd] - p_due[i]) < 16'h8000 && p_due[bd] != p_due[i]) bd = i; end
          else          begin if (bn < 0 || 16'(p_due[bn] - p_due[i]) < 16'h8000 && p_due[bn] != p_due[i]) bn = i; end
        end
      if (bn >= 0 && ndr_crd != 0) begin
        ndr_crd = ndr_crd - 8'd1;
        s2m_ndr_valid <= 1'b1; s2m_ndr_opcode <= 3'b000; s2m_ndr_tag <= p_tag[bn]; s2m_ndr_metavalue <= p_meta[bn];
        p_v[bn] = 1'b0;
        if (p_rwd[bn]) begin rwd_used = rwd_used - 8'd1; wd_ret = 1'b1; end
        else begin req_used = req_used - 8'd1; rq_ret = rq_ret + 2'd1; end
      end
      if (bd >= 0 && drs_crd != 0) begin
        drs_crd = drs_crd - 8'd1;
        s2m_drs_valid <= 1'b1; s2m_drs_opcode <= 3'b000; s2m_drs_tag <= p_tag[bd]; s2m_drs_metavalue <= p_meta[bd];
        s2m_drs_data <= p_data[bd]; s2m_drs_poison <= p_pois[bd];
        p_v[bd] = 1'b0;
        req_used = req_used - 8'd1; rq_ret = rq_ret + 2'd1;
      end
      req_crd_ret <= rq_ret;
      rwd_crd_ret <= wd_ret;
    end
  end
endmodule
