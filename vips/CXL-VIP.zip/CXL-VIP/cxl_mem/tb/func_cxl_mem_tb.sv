// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
// FUNC_SIM: verilator
//
// func_cxl_mem_tb.sv -- CXL.mem host for cxl_mem_model. Expected responses
// come from the host's own shadow of every line (data, Meta0-State,
// poison) kept by the CXL 2.0 Type 3 rules, matched by tag:
//   * MemWr / MemWrPtl (byte enables) -> Cmp; MemRd / MemRdData -> MemData;
//     MemInv / MemInvNT -> Cmp; MemSpecRd -> nothing
//   * Meta0-State update by MetaField / MetaValue, reported old state,
//     MemRdData and No-Op leave it
//   * poison stored by MemWr, kept by an unpoisoned MemWrPtl, returned by reads
//   * arrival order execution (same-clock RwD before Req), out-of-order
//     completion by tag
//   * HDM range: outside reads are poisoned, writes dropped
//   * device Req / RwD credits returned on completion, overflow; host NDR /
//     DRS credits gate the responses
module func_cxl_mem_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  localparam logic [51:0] BASE = 52'h1_0000_0000, SIZE = 52'h4000;
  logic clk = 0, rst_n = 0;
  logic m2s_req_valid = 0, m2s_rwd_valid = 0, m2s_rwd_poison = 0;
  logic [3:0] m2s_req_opcode = 0, m2s_rwd_opcode = 0;
  logic [51:6] m2s_req_addr = 0, m2s_rwd_addr = 0;
  logic [15:0] m2s_req_tag = 0, m2s_rwd_tag = 0;
  logic [1:0] m2s_req_metafield = 3, m2s_req_metavalue = 0, m2s_rwd_metafield = 3, m2s_rwd_metavalue = 0;
  logic [511:0] m2s_rwd_data = 0;
  logic [63:0] m2s_rwd_be = 0;
  logic ndr_crd_ret = 0, drs_crd_ret = 0;
  wire s2m_ndr_valid, s2m_drs_valid, s2m_drs_poison, rwd_crd_ret;
  wire [1:0] req_crd_ret;
  wire [2:0] s2m_ndr_opcode, s2m_drs_opcode;
  wire [15:0] s2m_ndr_tag, s2m_drs_tag;
  wire [1:0] s2m_ndr_metavalue, s2m_drs_metavalue;
  wire [511:0] s2m_drs_data;
  wire [3:0] err;
  always #5 clk = ~clk;
  int mnow = 0;                          // clocks since reset release (the device's time base)
  always @(posedge clk) mnow <= rst_n ? mnow + 1 : 0;

  cxl_mem_model u_dut (.clk, .rst_n, .hdm_base(BASE), .hdm_size(SIZE),
    .m2s_req_valid, .m2s_req_opcode, .m2s_req_addr, .m2s_req_tag, .m2s_req_metafield, .m2s_req_metavalue,
    .m2s_rwd_valid, .m2s_rwd_opcode, .m2s_rwd_addr, .m2s_rwd_tag, .m2s_rwd_metafield, .m2s_rwd_metavalue,
    .m2s_rwd_data, .m2s_rwd_be, .m2s_rwd_poison,
    .s2m_ndr_valid, .s2m_ndr_opcode, .s2m_ndr_tag, .s2m_ndr_metavalue,
    .s2m_drs_valid, .s2m_drs_opcode, .s2m_drs_tag, .s2m_drs_metavalue, .s2m_drs_data, .s2m_drs_poison,
    .host_ndr_crd(8'd4), .host_drs_crd(8'd4), .ndr_crd_ret, .drs_crd_ret, .req_crd_ret, .rwd_crd_ret, .err);

  // ------------------------------------------------------------ host shadow
  logic [511:0] sh_data [0:255];
  logic [1:0]   sh_meta [0:255];
  logic         sh_pois [0:255];
  // expected response per tag
  bit           e_v    [0:65535];
  bit           e_drs  [0:65535];
  logic [1:0]   e_meta [0:65535];
  logic [511:0] e_data [0:65535];
  bit           e_pois [0:65535];
  int           e_seq  [0:65535];
  int issued = 0, n_ndr = 0, n_drs = 0, bad = 0, unexpected = 0, ooo = 0, last_seq = -1;
  int req_avail = 8, rwd_avail = 4;
  bit auto_crd = 1;
  int held_ndr = 0, ret_ndr = 0, ret_drs = 0;
  bit auto_drs = 1;
  int ndr_owe = 0, drs_owe = 0;
  int ndr_ord [$], drs_ord [$];

  function automatic logic [511:0] pattern(input logic [7:0] seed);
    logic [511:0] d;
    for (int i = 0; i < 64; i++) d[8 * i +: 8] = 8'(seed * 8'd7 + 8'(i));
    return d;
  endfunction
  function automatic logic [51:6] la(input int line); return 46'((BASE >> 6) + line); endfunction

  // responses
  always @(posedge clk) begin
    if (s2m_ndr_valid) begin
      n_ndr++;
      if (!e_v[s2m_ndr_tag] || e_drs[s2m_ndr_tag]) unexpected++;
      else begin
        if (s2m_ndr_opcode != 3'b000 || s2m_ndr_metavalue != e_meta[s2m_ndr_tag]) begin
          bad++;
          $display("  NDR tag %0d: opcode %0d meta %0d, expected meta %0d", s2m_ndr_tag, s2m_ndr_opcode,
                   s2m_ndr_metavalue, e_meta[s2m_ndr_tag]);
        end
        ndr_ord.push_back(s2m_ndr_tag);
        if (e_seq[s2m_ndr_tag] < last_seq) ooo++;
        last_seq = e_seq[s2m_ndr_tag];
        e_v[s2m_ndr_tag] = 0;
      end
      if (!auto_crd) held_ndr++;
    end
    // credits owed to the device, one pulse per clock
    if (s2m_ndr_valid && auto_crd) ndr_owe++;
    ndr_owe += ret_ndr; ret_ndr = 0;
    ndr_crd_ret <= ndr_owe > 0;
    if (ndr_owe > 0) ndr_owe--;
    if (s2m_drs_valid) begin
      n_drs++;
      if (!e_v[s2m_drs_tag] || !e_drs[s2m_drs_tag]) unexpected++;
      else begin
        if (s2m_drs_opcode != 3'b000 || s2m_drs_metavalue != e_meta[s2m_drs_tag] ||
            s2m_drs_poison != e_pois[s2m_drs_tag] || (!e_pois[s2m_drs_tag] && s2m_drs_data != e_data[s2m_drs_tag])) begin
          bad++;
          $display("  DRS tag %0d: meta %0d poison %0d data %h", s2m_drs_tag, s2m_drs_metavalue, s2m_drs_poison,
                   s2m_drs_data[63:0]);
        end
        drs_ord.push_back(s2m_drs_tag);
        if (e_seq[s2m_drs_tag] < last_seq) ooo++;
        last_seq = e_seq[s2m_drs_tag];
        e_v[s2m_drs_tag] = 0;
      end
    end
    if (s2m_drs_valid && auto_drs) drs_owe++;
    drs_owe += ret_drs; ret_drs = 0;
    drs_crd_ret <= drs_owe > 0;
    if (drs_owe > 0) drs_owe--;
    req_avail += req_crd_ret;
    rwd_avail += rwd_crd_ret;
  end

  // ------------------------------------------------------------ requests
  int tagc = 1;
  task automatic req(input logic [3:0] op, input int line, input logic [1:0] mf, input logic [1:0] mv,
                     output int tag, input bit hold = 0, input bit outside = 0);
    int l;
    l = line & 255;
    tag = tagc++;
    if (!hold) @(negedge clk);
    m2s_req_valid = 1; m2s_req_opcode = op; m2s_req_addr = outside ? la(line) + 46'(SIZE >> 6) : la(line);
    m2s_req_tag = 16'(tag); m2s_req_metafield = mf; m2s_req_metavalue = mv;
    req_avail--;
    if (op != 4'b1000 && op inside {4'b0000, 4'b0001, 4'b0010, 4'b1001}) begin
      e_v[tag] = 1; e_drs[tag] = (op == 4'b0001 || op == 4'b0010); e_seq[tag] = issued++;
      if (outside) begin e_meta[tag] = 0; e_pois[tag] = 1; e_data[tag] = '0; end
      else begin
        e_meta[tag] = sh_meta[l]; e_pois[tag] = sh_pois[l]; e_data[tag] = sh_data[l];
        if (mf == 2'b00 && op != 4'b0010) sh_meta[l] = mv;
      end
    end
    if (!hold) begin @(negedge clk); m2s_req_valid = 0; end
  endtask
  task automatic rwd(input logic [3:0] op, input int line, input logic [511:0] d, input logic [63:0] be,
                     input bit poison, input logic [1:0] mf, input logic [1:0] mv, output int tag,
                     input bit hold = 0, input bit outside = 0);
    tag = tagc++;
    if (!hold) @(negedge clk);
    m2s_rwd_valid = 1; m2s_rwd_opcode = op; m2s_rwd_addr = outside ? la(line) + 46'(SIZE >> 6) : la(line);
    m2s_rwd_tag = 16'(tag); m2s_rwd_data = d; m2s_rwd_be = be; m2s_rwd_poison = poison;
    m2s_rwd_metafield = mf; m2s_rwd_metavalue = mv;
    rwd_avail--;
    e_v[tag] = 1; e_drs[tag] = 0; e_seq[tag] = issued++;
    if (outside) e_meta[tag] = 0;
    else begin
      e_meta[tag] = sh_meta[line];
      for (int b = 0; b < 64; b++) if (op == 4'b0001 || be[b]) sh_data[line][8 * b +: 8] = d[8 * b +: 8];
      sh_pois[line] = (op == 4'b0001) ? poison : (sh_pois[line] | poison);
      if (mf == 2'b00) sh_meta[line] = mv;
    end
    if (!hold) begin @(negedge clk); m2s_rwd_valid = 0; end
  endtask
  task automatic idle_lines(); @(negedge clk); m2s_req_valid = 0; m2s_rwd_valid = 0; endtask
  task automatic drain(input int maxc = 300);
    int c, open_;
    c = 0;
    do begin
      @(negedge clk); c++;
      open_ = 0;
      for (int t = 0; t < tagc; t++) if (e_v[t]) open_++;
    end while (open_ > 0 && c < maxc);
    repeat (4) @(negedge clk);
  endtask
  function automatic int open_tags();
    int n;
    n = 0;
    for (int t = 0; t < tagc; t++) if (e_v[t]) n++;
    return n;
  endfunction

  initial begin
    int t, t2, n0, d0, ooo0;
    for (int i = 0; i < 256; i++) begin sh_data[i] = '0; sh_meta[i] = 0; sh_pois[i] = 0; end
    for (int i = 0; i < 65536; i++) e_v[i] = 0;
    repeat (3) @(negedge clk);
    rst_n = 1;
    repeat (2) @(negedge clk);

    // ---- full-line writes with Meta0-State, read back
    for (int l = 0; l < 4; l++) rwd(4'b0001, l, pattern(8'(l)), '1, 0, (l == 2) ? 2'b00 : 2'b11, 2'b10, t);
    drain();
    chk(n_ndr == 4 && bad == 0 && unexpected == 0, "MemWr: one Cmp per write, tag and old Meta0-State");
    for (int l = 3; l >= 0; l--) begin
      while (req_avail == 0) @(negedge clk);
      req(4'b0001, l, 2'b11, 2'b00, t);
    end
    drain();
    chk(n_drs == 4 && bad == 0 && unexpected == 0, "MemRd: MemData with the written line and Meta0-State");
    // out-of-order completion: line 3 (slow) then line 0 (fast)
    ooo0 = ooo;
    req(4'b0001, 3, 2'b11, 0, t, 1); idle_lines();
    req(4'b0001, 0, 2'b11, 0, t2, 1); idle_lines();
    drain();
    chk(ooo > ooo0 && bad == 0, "completions return out of order, matched by tag");

    // ---- partial write, poison
    rwd(4'b0010, 1, pattern(8'hA0), 64'h00FF_0000_0000_F00F, 0, 2'b11, 0, t);
    rwd(4'b0001, 2, pattern(8'hB0), '1, 1, 2'b11, 0, t);              // poisoned full write
    rwd(4'b0010, 2, pattern(8'hC0), 64'h1, 0, 2'b11, 0, t);           // unpoisoned partial: stays poisoned
    rwd(4'b0010, 3, pattern(8'hD0), 64'h2, 1, 2'b11, 0, t);           // poisoned partial
    drain();
    req(4'b0001, 1, 2'b11, 0, t); req(4'b0001, 2, 2'b11, 0, t); req(4'b0001, 3, 2'b11, 0, t);
    drain();
    chk(bad == 0 && unexpected == 0, "MemWrPtl merges by byte enable; poison stored, kept and returned");
    rwd(4'b0001, 2, pattern(8'hE0), '1, 0, 2'b11, 0, t);              // full write clears poison
    drain();
    req(4'b0001, 2, 2'b11, 0, t);
    drain();
    chk(bad == 0, "an unpoisoned MemWr clears the poison");

    // ---- read after write in the same clock (RwD before Req)
    rwd(4'b0001, 5, pattern(8'h55), '1, 0, 2'b11, 0, t, 1);
    req(4'b0001, 5, 2'b11, 0, t2, 1);
    idle_lines();
    drain();
    chk(bad == 0, "a read in the same clock as a write to the line sees the write");

    // ---- metadata
    req(4'b0001, 6, 2'b00, 2'b11, t);                                 // MemRd sets Shared
    req(4'b0010, 6, 2'b00, 2'b10, t);                                 // MemRdData: no update
    req(4'b0001, 6, 2'b11, 2'b00, t);                                 // No-Op
    req(4'b0000, 6, 2'b00, 2'b00, t);                                 // MemInv sets Invalid
    req(4'b1001, 6, 2'b11, 2'b00, t);                                 // MemInvNT reports it
    drain();
    chk(bad == 0 && unexpected == 0, "Meta0-State: MemRd / MemInv update it, MemRdData and No-Op do not");

    // ---- MemSpecRd and unsupported opcodes
    n0 = n_ndr + n_drs;
    req(4'b1000, 7, 2'b11, 0, t);
    drain();
    chk(n_ndr + n_drs == n0 && req_avail == 8, "MemSpecRd: no response, credit returned");
    chk(err == 4'b0000, "no error so far");
    req(4'b0011, 7, 2'b11, 0, t); req_avail++;                        // MemRdFwd: not a Type 3 request
    drain();
    chk(err[2] && n_ndr + n_drs == n0, "MemRdFwd rejected without a response");

    // ---- HDM range
    rwd(4'b0001, 0, pattern(8'h99), '1, 0, 2'b11, 0, t, 0, 1);        // aliases line 0 if undecoded
    req(4'b0001, 0, 2'b11, 0, t, 0, 1);
    req(4'b0001, 0, 2'b11, 0, t);
    drain();
    chk(err[3] && bad == 0 && unexpected == 0, "outside the HDM range: poisoned read, write dropped");

    // ---- device credits: nine Req without waiting for returns
    n0 = n_drs;
    for (int i = 0; i < 9; i++) begin req(4'b0001, 3, 2'b11, 0, t, 1); @(negedge clk); end
    m2s_req_valid = 0;
    e_v[t] = 0;                                                        // the ninth is dropped
    chk(err[0], "a ninth Req beyond 8 credits: overflow");
    drain();
    chk(n_drs == n0 + 8 && unexpected == 0, "the eight Req within the credits complete");
    chk(req_avail == 7, "every Req credit is returned (the dropped ninth took none)");
    req_avail = 8;

    // ---- host credits gate the responses
    auto_crd = 0; held_ndr = 0;
    for (int i = 0; i < 6; i++) req(4'b0000, 8 + i, 2'b11, 0, t);
    repeat (60) @(negedge clk);
    chk(held_ndr == 4 && open_tags() == 2, "four host NDR credits: four Cmp, two waiting");
    ret_ndr = 4;
    auto_crd = 1;
    drain();
    chk(open_tags() == 0 && bad == 0, "returned NDR credits release the waiting responses");
    chk(rwd_avail == 4, "every RwD credit is returned");

    // ---- device RwD credits: five MemWr without waiting
    begin
      logic [511:0] sd; logic [1:0] sm; logic sp;
      sd = sh_data[200]; sm = sh_meta[200]; sp = sh_pois[200];
      for (int i = 0; i < 5; i++) begin rwd(4'b0001, 196 + i, pattern(8'(i + 1)), '1, 0, 2'b11, 0, t, 1); @(negedge clk); end
      m2s_rwd_valid = 0;
      e_v[t] = 0; rwd_avail++;                                         // the fifth is dropped
      sh_data[200] = sd; sh_meta[200] = sm; sh_pois[200] = sp;
    end
    chk(err[1], "a fifth RwD beyond 4 credits: overflow");
    drain();
    req(4'b0001, 200, 2'b11, 0, t);
    drain();
    chk(bad == 0 && unexpected == 0 && rwd_avail == 4, "the dropped MemWr did not write; the other four completed");

    // ---- backlogged responses leave oldest-due first, one per host credit
    auto_drs = 0;
    for (int i = 0; i < 4; i++) req(4'b0001, 20 + i, 2'b11, 0, t);
    drain();                                                           // host DRS credits now 0
    begin
      int ta, tb, n1;
      drs_ord.delete();
      req(4'b0001, 24, 2'b11, 0, ta);                                  // due first
      req(4'b0001, 28, 2'b11, 0, tb);                                  // same latency, two clocks later
      repeat (30) @(negedge clk);
      chk(drs_ord.size() == 0 && open_tags() == 2, "no DRS credit: both reads wait");
      ret_drs = 1;
      repeat (10) @(negedge clk);
      chk(drs_ord.size() == 1 && drs_ord[0] == ta, "one DRS credit: the earliest-due read is sent");
      ret_drs = 1;
      repeat (10) @(negedge clk);
      chk(drs_ord.size() == 2 && drs_ord[1] == tb, "next credit: the second read");
      ret_drs = 4; auto_drs = 1;
      auto_crd = 0;
      for (int i = 0; i < 4; i++) req(4'b0000, 30 + i, 2'b11, 0, t);
      drain();
      ndr_ord.delete();
      req(4'b0000, 36, 2'b11, 0, ta);
      req(4'b0000, 40, 2'b11, 0, tb);
      repeat (30) @(negedge clk);
      chk(ndr_ord.size() == 0, "no NDR credit: both Cmp wait");
      ret_ndr = 1;
      repeat (10) @(negedge clk);
      chk(ndr_ord.size() == 1 && ndr_ord[0] == ta, "one NDR credit: the earliest-due Cmp is sent");
      ret_ndr = 1;
      repeat (10) @(negedge clk);
      chk(ndr_ord.size() == 2 && ndr_ord[1] == tb && bad == 0, "next credit: the second Cmp");
      ret_ndr = 4; auto_crd = 1;
      repeat (10) @(negedge clk);
    end
    chk(bad == 0 && unexpected == 0, $sformatf("all %0d NDR and %0d DRS responses as expected", n_ndr, n_drs));

    // ---- reset with requests in flight: nothing pending survives
    n0 = n_ndr + n_drs;
    req(4'b0001, 3, 2'b11, 0, t); req(4'b0000, 7, 2'b11, 0, t);
    t2 = mnow;                                                        // a stale entry would fall due near here again
    rst_n = 0;
    repeat (3) @(negedge clk);
    rst_n = 1;
    for (int i = 0; i < 65536; i++) e_v[i] = 0;
    for (int i = 0; i < 256; i++) begin sh_data[i] = '0; sh_meta[i] = 0; sh_pois[i] = 0; end
    req_avail = 8; rwd_avail = 4;
    while (mnow < t2 + 100) @(negedge clk);
    chk(n_ndr + n_drs == n0 && err == 4'b0000, "reset drops the pending responses and clears the errors");
    rwd(4'b0011, 9, pattern(8'h11), '1, 0, 2'b11, 0, t); e_v[t] = 0; rwd_avail++;
    repeat (4) @(negedge clk);
    chk(err == 4'b0100 && n_ndr + n_drs == n0, "RwD with a reserved opcode rejected without a response");
    req(4'b0001, 3, 2'b11, 0, t);
    drain();
    chk(bad == 0 && unexpected == 0 && n_drs + n_ndr == n0 + 1, "memory reads zero after reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
