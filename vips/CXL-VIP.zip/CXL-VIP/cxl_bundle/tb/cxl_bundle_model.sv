// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cxl_bundle_model.sv -- receive side of a CXL 4.0 bundled port: one
// logical port carried over up to 4 physical ports. Flits are striped
// over the active ports, can arrive skewed, and are put back in order;
// errors, gaps and a lost port trigger a go-back-N retry. The structure
// follows the CXL 4.0 bundled-port idea; the striping rule, window,
// timers and error codes are this model's own.
//
// cfg_we loads the bundle (cfg_mask: member ports) and resets the logical
//   port: next sequence 0, nothing buffered, no retry pending.
// Striping: the flit with bundle sequence s travels on active port
//   number (s mod N), counting the N active ports from port 0 up.
// Per port p (in_valid[p], in_seq, in_data, in_bad = the physical port
//   saw an uncorrectable flit), handled in port order each clock:
//   * port not active: dropped (err[0])
//   * in_bad: dropped (err[4]), retry
//   * a retry requested earlier this clock, or pending: dropped silently.
//     A pending retry ends first when any port carries s == next (not
//     bad, port active, no retry requested this clock).
//   * s behind next (by 1..2048): duplicate, dropped (err[3])
//   * s >= next + W: dropped (err[2]), retry
//   * s already buffered: duplicate, dropped (err[3])
//   * s on the wrong port: dropped (err[1]), retry
//   * else buffered
// A retry (retry_valid one clock, retry_seq = next) is requested only when
//   none is pending; it clears the buffer. A port_down on an active port
//   removes it from the bundle (err[6], width drops) and requests a retry.
// Gap: when flits are buffered but not the next one for GTMO clocks:
//   err[5] and a retry.
// Delivery: the next flit, when buffered, leaves on out_* (one per clock).
module cxl_bundle_model #(parameter int W = 8, parameter int GTMO = 12) (
  input  logic           clk,
  input  logic           rst_n,
  input  logic           cfg_we,
  input  logic [3:0]     cfg_mask,
  input  logic [3:0]     port_down,
  input  logic [3:0]     in_valid,
  input  logic [3:0]     in_bad,
  input  logic [47:0]    in_seq,       // port p: [12*p +: 12]
  input  logic [1023:0]  in_data,      // port p: [256*p +: 256]
  output logic           out_valid,
  output logic [11:0]    out_seq,
  output logic [255:0]   out_data,
  output logic           retry_valid,
  output logic [11:0]    retry_seq,
  output logic [2:0]     width,
  output logic [6:0]     err
);
  logic [3:0]   act;
  logic [11:0]  nxt;
  logic         rw;
  logic         b_v [0:W-1];
  logic [255:0] b_d [0:W-1];
  int           gt;

  function automatic int port_for(input logic [3:0] a, input logic [11:0] s);
    int n, k;
    n = 0;
    for (int p = 0; p < 4; p++) if (a[p]) n = n + 1;
    if (n == 0) return -1;
    k = int'(s) % n;
    for (int p = 0; p < 4; p++)
      if (a[p]) begin
        if (k == 0) return p;
        k = k - 1;
      end
    return -1;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      act = '0; nxt = '0; rw = 1'b0; gt = 0;
      for (int i = 0; i < W; i++) begin b_v[i] = 1'b0; b_d[i] = '0; end
      out_valid <= 1'b0; out_seq <= '0; out_data <= '0;
      retry_valid <= 1'b0; retry_seq <= '0; width <= '0; err <= '0;
    end else begin : step
      logic [6:0] e;
      logic       rq;
      e = '0; rq = 1'b0;
      out_valid <= 1'b0; retry_valid <= 1'b0;

      if (cfg_we) begin
        act = cfg_mask; nxt = '0; rw = 1'b0; gt = 0;
        for (int i = 0; i < W; i++) b_v[i] = 1'b0;
      end
      for (int p = 0; p < 4; p++)
        if (act[p] && port_down[p]) begin act[p] = 1'b0; e[6] = 1'b1; rq = 1'b1; end

      // the replay of the next flit ends a pending retry, on whichever port
      for (int p = 0; p < 4; p++)
        if (rw && !rq && in_valid[p] && act[p] && !in_bad[p] && in_seq[12 * p +: 12] == nxt) rw = 1'b0;

      for (int p = 0; p < 4; p++) begin : port
        logic [11:0] s, d;
        s = in_seq[12 * p +: 12];
        d = s - nxt;
        if (in_valid[p]) begin
          if (!act[p]) e[0] = 1'b1;
          else if (in_bad[p]) begin e[4] = 1'b1; rq = 1'b1; end
          else if (rq || (rw && s != nxt)) ;
          else if (d >= 12'd2048) e[3] = 1'b1;
          else if (d >= 12'(W)) begin e[2] = 1'b1; rq = 1'b1; end
          else if (b_v[int'(s) % W]) e[3] = 1'b1;
          else if (port_for(act, s) != p) begin e[1] = 1'b1; rq = 1'b1; end
          else begin
            b_v[int'(s) % W] = 1'b1; b_d[int'(s) % W] = in_data[256 * p +: 256];
          end
        end
      end

      // gap timer
      begin : gap
        logic any;
        any = 1'b0;
        for (int i = 0; i < W; i++) any = any | b_v[i];
        if (any && !b_v[int'(nxt) % W]) begin
          gt = gt + 1;
          if (gt >= GTMO) begin e[5] = 1'b1; rq = 1'b1; end
        end else gt = 0;
      end

      if (rq && !rw) begin
        for (int i = 0; i < W; i++) b_v[i] = 1'b0;
        rw = 1'b1; gt = 0;
        retry_valid <= 1'b1; retry_seq <= nxt;
      end

      if (b_v[int'(nxt) % W]) begin
        out_valid <= 1'b1; out_seq <= nxt; out_data <= b_d[int'(nxt) % W];
        b_v[int'(nxt) % W] = 1'b0; nxt = nxt + 12'd1;
      end
      width <= 3'(act[0]) + 3'(act[1]) + 3'(act[2]) + 3'(act[3]);
      err <= err | e;
    end
  end
endmodule
