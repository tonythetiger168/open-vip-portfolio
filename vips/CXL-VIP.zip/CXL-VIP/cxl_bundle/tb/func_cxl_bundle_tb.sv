// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// FUNC_SIM: iverilog
//
// func_cxl_bundle_tb.sv -- bundled-port transmitter for cxl_bundle_model
// with a reference receiver written out independently of the model:
//   * striping over 4, 3 (mask 1011) and 1 ports, in-order delivery of
//     flits that arrive 4 per clock or skewed between ports
//   * flit on a port outside the bundle, on the wrong port, beyond the
//     window, duplicate (behind and already buffered), bad flit
//   * go-back-N retry: one request, later flits dropped until the replay
//     of the requested flit, then delivery resumes
//   * gap timeout at exactly GTMO clocks, lost port (width drops, the
//     replay is striped over the remaining ports)
//   * 4000 clocks of random skew, errors and port loss with a go-back-N
//     transmitter, checked clock by clock against the reference
// Run: python3 tools/run_func_tests.py CXL-VIP
`timescale 1ns/1ps
module func_cxl_bundle_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int W = 8, GTMO = 12;
  int checks = 0, fails = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic clk = 0, rst_n = 0;
  logic cfg_we = 0;
  logic [3:0] cfg_mask = 0, port_down = 0, in_valid = 0, in_bad = 0;
  logic [47:0] in_seq = 0;
  logic [1023:0] in_data = 0;
  wire out_valid, retry_valid;
  wire [11:0] out_seq, retry_seq;
  wire [255:0] out_data;
  wire [2:0] width;
  wire [6:0] err;
  always #5 clk = ~clk;

  cxl_bundle_model #(.W(W), .GTMO(GTMO)) u_dut (.clk, .rst_n, .cfg_we, .cfg_mask, .port_down, .in_valid,
    .in_bad, .in_seq, .in_data, .out_valid, .out_seq, .out_data, .retry_valid, .retry_seq, .width, .err);

  task automatic wait_clk(input int n); repeat (n) @(negedge clk); #1; endtask

  // payload of flit s (so a replay carries the same data)
  function automatic logic [255:0] pay(input int s);
    return {8{32'(s) * 32'h9E37_79B9 ^ 32'h5A5A_0000}} ^ {224'h0, 32'(s)};
  endfunction

  // ------------------------------------------------------------ reference
  bit [3:0] r_act = 0;
  int r_nxt = 0, r_gt = 0;
  bit r_rw = 0;
  bit r_bv [W];
  int r_bs [W];
  bit [6:0] r_err = 0;
  bit e_out, e_rty;
  int e_os, e_rs, e_w;
  int bad_out = 0, n_out = 0, n_rty = 0;
  int got [$];
  bit check_on = 1;

  // the k-th active port carries flits s with s mod N == k
  function automatic int lane_of(input bit [3:0] a, input int s);
    int l [4];
    int n;
    n = 0;
    for (int p = 0; p < 4; p++) if (a[p]) begin l[n] = p; n++; end
    if (n == 0) return -1;
    return l[s % n];
  endfunction

  always @(posedge clk) if (rst_n && check_on) begin
    bit rq;
    bit [6:0] e;
    rq = 0; e = 0; e_out = 0; e_rty = 0;
    if (cfg_we) begin
      r_act = cfg_mask; r_nxt = 0; r_rw = 0; r_gt = 0;
      foreach (r_bv[i]) r_bv[i] = 0;
    end
    for (int p = 0; p < 4; p++) if (r_act[p] && port_down[p]) begin r_act[p] = 0; e[6] = 1; rq = 1; end
    if (r_rw && !rq)
      for (int p = 0; p < 4; p++) if (in_valid[p] && r_act[p] && !in_bad[p] && in_seq[12 * p +: 12] == r_nxt) r_rw = 0;
    for (int p = 0; p < 4; p++) if (in_valid[p]) begin
      int s, d;
      s = in_seq[12 * p +: 12];
      d = (s - r_nxt + 4096) % 4096;
      if (!r_act[p]) e[0] = 1;
      else if (in_bad[p]) begin e[4] = 1; rq = 1; end
      else if (rq) ;
      else if (r_rw && s != r_nxt) ;
      else if (d >= 2048) e[3] = 1;
      else if (d >= W) begin e[2] = 1; rq = 1; end
      else if (r_bv[s % W]) e[3] = 1;
      else if (lane_of(r_act, s) != p) begin e[1] = 1; rq = 1; end
      else begin
        r_bv[s % W] = 1; r_bs[s % W] = s;
        if (in_data[256 * p +: 256] !== pay(s)) $display("  tb: bad payload driven");
      end
    end
    begin
      bit any;
      any = 0;
      foreach (r_bv[i]) any |= r_bv[i];
      if (any && !r_bv[r_nxt % W]) begin
        r_gt++;
        if (r_gt >= GTMO) begin e[5] = 1; rq = 1; end
      end else r_gt = 0;
    end
    if (rq && !r_rw) begin
      foreach (r_bv[i]) r_bv[i] = 0;
      r_rw = 1; r_gt = 0; e_rty = 1; e_rs = r_nxt;
    end
    if (r_bv[r_nxt % W]) begin
      e_out = 1; e_os = r_nxt; r_bv[r_nxt % W] = 0; r_nxt = (r_nxt + 1) % 4096;
    end
    e_w = r_act[0] + r_act[1] + r_act[2] + r_act[3];
    r_err |= e;
  end
  always @(negedge clk) if (rst_n && check_on) begin
    bit ok;
    ok = out_valid === e_out && retry_valid === e_rty && width == e_w && err === r_err;
    if (e_out && (out_seq != e_os || out_data !== pay(e_os))) ok = 0;
    if (e_rty && retry_seq != e_rs) ok = 0;
    if (!ok) begin
      bad_out++;
      if (bad_out < 6) $display("  @%0t out %b/%b seq %0d/%0d retry %b/%b %0d/%0d width %0d/%0d err %b/%b", $time,
        out_valid, e_out, out_seq, e_os, retry_valid, e_rty, retry_seq, e_rs, width, e_w, err, r_err);
    end
    if (out_valid) begin n_out++; got.push_back(out_seq); end
    n_rty += retry_valid;
  end

  // ------------------------------------------------------------ drivers
  task automatic cfg(input logic [3:0] m);
    @(negedge clk); cfg_we = 1; cfg_mask = m;
    @(negedge clk); cfg_we = 0; #1;
  endtask
  // one clock: flit s on port p for each (p, s) pair given; -1 = idle
  task automatic beat(input int s0 = -1, input int s1 = -1, input int s2 = -1, input int s3 = -1);
    int s [4];
    s[0] = s0; s[1] = s1; s[2] = s2; s[3] = s3;
    @(negedge clk);
    for (int p = 0; p < 4; p++) begin
      in_valid[p] = s[p] >= 0;
      in_seq[12 * p +: 12] = (s[p] >= 0) ? 12'(s[p]) : 12'h0;
      in_data[256 * p +: 256] = (s[p] >= 0) ? pay(s[p]) : '0;
    end
    @(negedge clk); in_valid = 0; in_bad = 0; #1;
  endtask
  // flit s on its own lane
  task automatic one(input bit [3:0] a, input int s);
    case (lane_of(a, s))
      0: beat(s); 1: beat(-1, s); 2: beat(-1, -1, s); default: beat(-1, -1, -1, s);
    endcase
  endtask

  int r0, o0;
  bit stable;

  initial begin
    wait_clk(3); rst_n = 1; wait_clk(2);

    // ---- 4 ports, 4 flits per clock, one delivered per clock
    cfg(4'b1111);
    chk(width == 4, "bundle of 4 ports: width 4");
    got.delete();
    beat(0, 1, 2, 3); beat(4, 5, 6, 7);
    wait_clk(8);
    chk(got.size() == 8 && got[0] == 0 && got[7] == 7 && bad_out == 0, "8 flits striped over 4 ports delivered in order");
    // skew: port 2 late by 3 clocks
    got.delete();
    beat(8, 9, -1, 11); beat(12, 13, -1, 15); beat(-1, -1, 10, -1); beat(-1, -1, 14, -1);
    wait_clk(8);
    chk(got.size() == 8 && got[0] == 8 && got[2] == 10 && got[7] == 15 && n_rty == 0, "skewed port: flits wait for the late one, no retry");

    // ---- 3 ports (1011)
    cfg(4'b1011);
    chk(width == 3, "mask 1011: width 3");
    got.delete();
    beat(0, 1, -1, 2); beat(3, 4, -1, 5);
    wait_clk(6);
    chk(got.size() == 6 && got[5] == 5, "striping over ports 0, 1, 3");
    beat(-1, -1, 6, -1);
    chk(err[0] && n_rty == 0, "flit on a port outside the bundle: dropped (err 0), no retry");
    r0 = n_rty;
    beat(-1, 6, -1, -1);
    chk(err[1] && n_rty == r0 + 1 && retry_seq == 6, "flit on the wrong port: dropped, retry from 6");
    beat(-1, 7, -1, -1); beat(-1, -1, -1, 8);
    chk(n_rty == r0 + 1 && err[3:2] == 0, "while the retry is pending later flits are dropped silently");
    got.delete();
    beat(6, 7, -1, 8);
    wait_clk(4);
    chk(got.size() == 3 && got[0] == 6 && got[2] == 8, "replay from 6 delivered");

    // ---- duplicates and window
    beat(5, -1, -1, -1);
    chk(err[3] && n_rty == r0 + 1, "flit behind next: duplicate, dropped, no retry");
    cfg(4'b1111);
    beat(-1, 1, -1, -1);
    beat(-1, 1, -1, -1);
    chk(n_rty == r0 + 1, "duplicate of a buffered flit dropped");
    r0 = n_rty;
    beat(-1, -1, -1, 11);
    chk(n_rty == r0 + 1 && err[2] && retry_seq == 0, "flit beyond the window: retry from next");
    o0 = n_out;
    beat(0, 1, 2, 3); beat(4, 5, 6, 7);
    wait_clk(8);
    chk(n_out == o0 + 8, "replay fills the window");
    beat(-1, -1, -1, 15);
    beat(8, 9, 10, 11);
    chk(n_rty == r0 + 1, "flit at next + W - 1 is inside the window");
    wait_clk(GTMO);

    // ---- bad flit
    cfg(4'b1111);
    r0 = n_rty;
    @(negedge clk); in_bad = 4'b0100; in_valid = 4'b0111; in_seq = {12'd3, 12'd2, 12'd1, 12'd0};
    in_data = {pay(3), pay(2), pay(1), pay(0)};
    @(negedge clk); in_valid = 0; in_bad = 0; #1;
    chk(err[4] && n_rty == r0 + 1 && retry_seq == 0, "bad flit: retry from the next undelivered flit");
    chk(out_valid == 0, "flits buffered before the bad one in the same clock are cleared");
    got.delete();
    beat(0, 1, 2, 3);
    wait_clk(5);
    chk(got.size() == 4 && got[0] == 0, "replay delivered after a bad flit");

    // ---- gap timeout
    cfg(4'b1111);
    r0 = n_rty;
    beat(-1, 1, 2, 3);
    wait_clk(GTMO - 2);
    chk(n_rty == r0, "no retry before the gap timeout");
    wait_clk(1);
    chk(n_rty == r0 + 1 && err[5] && retry_seq == 0, "gap timeout after GTMO clocks: retry from 0");
    beat(0, 1, 2, 3);
    wait_clk(5);
    // gap filled one clock before the timeout
    cfg(4'b1111);
    r0 = n_rty; o0 = n_out;
    beat(-1, 1, -1, -1);
    wait_clk(GTMO - 3);
    beat(0, -1, -1, -1);
    wait_clk(3);
    chk(n_rty == r0 && n_out > o0, "gap filled on the last clock: no retry");

    // ---- lost port
    cfg(4'b1111);
    beat(0, 1, 2, 3);
    wait_clk(4);
    r0 = n_rty;
    @(negedge clk); port_down = 4'b0010;
    @(negedge clk); port_down = 0; #1;
    chk(width == 3 && err[6] && n_rty == r0 + 1 && retry_seq == 4, "port 1 lost: width 3, retry from 4");
    got.delete();
    beat(-1, -1, 4, 5); beat(6, -1, 7, 8); beat(9, -1, -1, -1);
    wait_clk(7);
    chk(got.size() == 6 && got[5] == 9, "replay striped over ports 0, 2, 3");
    beat(-1, 10, -1, -1);
    chk(n_rty == r0 + 1 && !out_valid, "flit on the lost port dropped");
    @(negedge clk); port_down = 4'b0010;
    @(negedge clk); port_down = 0; #1;
    chk(n_rty == r0 + 1, "port_down on a port already out: no effect");
    cfg(4'b0100);
    got.delete();
    for (int i = 0; i < 3; i++) beat(-1, -1, i, -1);
    wait_clk(2);
    chk(width == 1 && got.size() == 3, "bundle of one port");
    // ---- buffer slot 0, sequence distance 2048, port 0 lost
    cfg(4'b1111);
    beat(0, -1, -1, -1);
    r0 = n_rty;
    beat(8, -1, -1, -1);
    wait_clk(GTMO);
    chk(n_rty == r0 + 1 && retry_seq == 1, "only buffer slot 0 held (flit 8): gap timeout, retry from 1");
    cfg(4'b1111);
    beat(0, -1, -1, -1);
    beat(8, -1, -1, -1);
    cfg(4'b1111);
    o0 = n_out;
    wait_clk(3);
    chk(n_out == o0, "reconfiguration empties every buffer slot");
    r0 = n_rty;
    beat(-1, -1, -1, -1);
    @(negedge clk); in_valid = 4'b0001; in_seq[11:0] = 12'd2048; in_data[255:0] = pay(2048);
    @(negedge clk); in_valid = 0; #1;
    chk(n_rty == r0 && err[3], "flit 2048 ahead counts as behind: duplicate, no retry");
    r0 = n_rty;
    @(negedge clk); port_down = 4'b0001;
    @(negedge clk); port_down = 0; #1;
    chk(width == 3 && n_rty == r0 + 1, "port 0 lost: width 3, retry");
    chk(bad_out == 0, "directed: every output as the reference");

    // ---- random with a go-back-N transmitter
    begin
      int txn, sent;
      bit [3:0] tact;
      int qd [4][4];
      int qn [4];
      sent = 0;
      cfg(4'b1111);
      tact = 4'b1111; txn = 0;
      for (int p = 0; p < 4; p++) qn[p] = 0;
      for (int c = 0; c < 4000; c++) begin
        @(negedge clk);
        port_down = 0; in_bad = 0;
        if (retry_valid) begin txn = retry_seq; for (int p = 0; p < 4; p++) qn[p] = 0; end
        if ($urandom_range(0, 399) == 0 && tact != 0) begin
          int p;
          p = $urandom_range(0, 3);
          port_down[p] = 1; tact[p] = 0;
        end
        if ($urandom_range(0, 299) == 0) begin
          cfg_we = 1; cfg_mask = 4'($urandom_range(1, 15)); tact = cfg_mask; txn = 0;
          for (int p = 0; p < 4; p++) qn[p] = 0;
        end else cfg_we = 0;
        // queue up to 4 new flits on their lanes when there is room
        if (tact != 0 && !cfg_we && port_down == 0)
          for (int k = 0; k < 4; k++) begin
            int l;
            l = lane_of(tact, txn);
            if ($urandom_range(0, 2) != 0 && qn[l] < 3) begin qd[l][qn[l]] = txn; qn[l]++; txn = (txn + 1) % 4096; end
          end
        for (int p = 0; p < 4; p++) begin
          int r;
          r = $urandom_range(0, 99);
          if (qn[p] > 0 && r < 70) begin
            int s;
            s = qd[p][0];
            for (int i = 0; i < 3; i++) qd[p][i] = qd[p][i + 1];
            qn[p]--;
            if (r < 2) s = (s + 4096 - 1) % 4096;               // duplicate
            else if (r < 3) s = (s + 9) % 4096;                 // beyond the window
            in_valid[p] = 1; in_seq[12 * p +: 12] = s; in_data[256 * p +: 256] = pay(s);
            in_bad[p] = $urandom_range(0, 99) == 0;
            sent++;
          end else if (r > 98) begin                           // stray flit on any port
            in_valid[p] = 1; in_seq[12 * p +: 12] = $urandom; in_data[256 * p +: 256] = pay(in_seq[12 * p +: 12]);
          end else in_valid[p] = 0;
        end
      end
      @(negedge clk); in_valid = 0; in_bad = 0; cfg_we = 0; port_down = 0;
      wait_clk(GTMO + 12);
      chk(bad_out == 0, $sformatf("%0d random flits: deliveries, retries, width and errors as the reference (%0d delivered, %0d retries)",
          sent, n_out, n_rty));
      chk(n_rty > 30 && n_out > 800, "random run exercised retries and deliveries");
    end

    // ---- reset
    check_on = 0;
    rst_n = 0; wait_clk(2);
    chk(!out_valid && !retry_valid && width == 0 && err == 0, "reset clears the bundle");
    rst_n = 1;
    beat(0, -1, -1, -1);
    chk(err[0], "after reset no port is in the bundle");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end
  initial begin #20ms; $display("FUNC_FAIL timeout"); $finish; end
`endif
endmodule
