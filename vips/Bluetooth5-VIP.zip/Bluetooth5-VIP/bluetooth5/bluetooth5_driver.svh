// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// bluetooth5_driver.svh -- Bluetooth 5 LE driver
// Composes real BLE link-layer packets on the RX (DUT ingress) side:
// preamble / access address / PDU header (type, LLID, NESN, SN, MD,
// length) / payload / CRC-24, streamed byte-wise with rx_valid. Supports
// CRC error injection. Publishes every driven packet as the scoreboard's
// expected transaction.

`ifndef BLUETOOTH5_DRIVER_SVH
`define BLUETOOTH5_DRIVER_SVH

class bluetooth5_driver extends uvm_driver #(bluetooth5_transaction);
  `uvm_component_utils(bluetooth5_driver)
  virtual bluetooth5_if vif;
  bluetooth5_config cfg;

  // Expected-transaction port for the end-to-end scoreboard
  uvm_analysis_port #(bluetooth5_transaction) drv_ap;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual bluetooth5_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "BT5 virtual interface not found")
    if (!uvm_config_db#(bluetooth5_config)::get(this, "", "cfg", cfg))
      cfg = bluetooth5_config::type_id::create("cfg");
  endfunction

  // BLE CRC-24: poly 0x00065B reflected (0xDA6000), init 0x555555
  function automatic bit [23:0] bt5_crc24(ref bit [7:0] bytes[$]);
    bit [23:0] crc;
    crc = 24'h555555;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 24'hDA6000 : (crc >> 1);
    end
    return crc;
  endfunction

  // Build the on-air packet image:
  // preamble | access address (LSB first) | header(2) | payload | CRC24(3)
  virtual function void build_packet(bluetooth5_transaction tx, ref bit [7:0] bytes[$]);
    bit [7:0] body[$];
    bit [23:0] crc;
    bytes.delete();
    // LE advertising channels always use the advertising access address
    if (tx.channel inside {37, 38, 39})
      tx.access_addr = 32'h8E89_BED6;
    // preamble: 0xAA when AA lsb = 1, else 0x55 (1M/2M PHY)
    bytes.push_back(tx.access_addr[0] ? 8'hAA : 8'h55);
    // access address, LSB first
    for (int i = 0; i < 4; i++)
      bytes.push_back(tx.access_addr[i*8 +: 8]);
    // PDU header
    body.delete();
    if (tx.channel inside {37, 38, 39}) begin
      // advertising channel PDU: header[3:0]=PDU type, header[13:8]=length
      body.push_back({5'b00000, tx.adv_type});
      body.push_back(tx.length);
    end else begin
      // data channel PDU: LLID/NESN/SN/MD + length
      body.push_back({3'b000, tx.md, tx.sn, tx.nesn, 2'(tx.llid)});
      body.push_back(tx.length);
    end
    for (int i = 0; i < tx.length; i++)
      body.push_back(tx.data_payload[i]);
    crc = bt5_crc24(body);
    if (tx.crc_error || tx.with_error)
      crc = crc ^ 24'hA5A5A5;   // corrupt CRC
    foreach (body[i]) bytes.push_back(body[i]);
    for (int i = 0; i < 3; i++)
      bytes.push_back(crc[i*8 +: 8]);
  endfunction

  task run_phase(uvm_phase phase);
    vif.drv_cb.rx_valid  <= 1'b0;
    vif.drv_cb.rx_crc_ok <= 1'b0;
    vif.drv_cb.channel   <= 7'd37;
    wait (vif.rst_n === 1'b1);
    forever begin
      bluetooth5_transaction tx;
      seq_item_port.get_next_item(tx);
      drive_item(tx);
      seq_item_port.item_done();
    end
  endtask

  task drive_item(bluetooth5_transaction tx);
    bit [7:0] bytes[$];
    `uvm_info("BT5_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)
    build_packet(tx, bytes);
    // inter-frame space (T_IFS ~ 150us modeled as a few cycles)
    repeat (2) @(vif.drv_cb);
    vif.drv_cb.channel  <= tx.channel;
    vif.drv_cb.rx_valid <= 1'b1;
    foreach (bytes[i]) begin
      vif.drv_cb.rx_data <= bytes[i];
      @(vif.drv_cb);
    end
    vif.drv_cb.rx_valid  <= 1'b0;
    // receiver CRC verdict for the DUT receiver path
    vif.drv_cb.rx_crc_ok <= !(tx.crc_error || tx.with_error);
    @(vif.drv_cb);
    vif.drv_cb.rx_crc_ok <= 1'b0;
    drv_ap.write(tx);   // broadcast expected transaction
  endtask

  // Directed helpers used by protocol sequences
  task drive_adv_packet(bluetooth5_transaction tx);
    drive_item(tx);
  endtask

  task drive_data_packet(bluetooth5_transaction tx);
    drive_item(tx);
  endtask
endclass
`endif
