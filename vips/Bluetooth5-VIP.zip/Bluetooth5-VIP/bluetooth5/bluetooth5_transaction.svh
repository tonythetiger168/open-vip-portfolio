// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// bluetooth5_transaction.svh

class bluetooth5_transaction extends uvm_sequence_item;
  `uvm_object_utils(bluetooth5_transaction)

  typedef enum bit [2:0] {
    ADV_IND         = 3'd0,
    ADV_DIRECT_IND  = 3'd1,
    ADV_NONCONN_IND = 3'd2,
    SCAN_REQ        = 3'd3,
    SCAN_RSP        = 3'd4,
    CONNECT_IND     = 3'd5,
    ADV_SCAN_IND    = 3'd6,
    AUX_ADV_IND     = 3'd7
  } adv_type_e;

  typedef enum bit [1:0] {
    PHY_1M       = 2'd0,
    PHY_2M       = 2'd1,
    PHY_CODED_S2 = 2'd2,
    PHY_CODED_S8 = 2'd3
  } phy_mode_e;

  typedef enum bit [2:0] {
    LLID_RESERVED  = 3'd0,
    LLID_DATA_CONT = 3'd1,
    LLID_DATA_START= 3'd2,
    LLID_CTRL      = 3'd3
  } llid_e;

  typedef enum bit { ADV_PKT = 1'b0, DATA_PKT = 1'b1 } pkt_type_e;

  rand pkt_type_e    pkt_type;
  rand adv_type_e    adv_type;
  rand phy_mode_e    phy_mode;
  rand llid_e        llid;
  rand bit [47:0]    adv_addr;
  rand bit [47:0]    peer_addr;
  rand bit [31:0]    access_addr;
  rand bit [7:0]     data_payload[];
  rand bit [7:0]     length;
  rand bit [6:0]     channel;
  rand bit           encrypted;
  rand bit           nesn;
  rand bit           sn;
  rand bit           md;
  rand bit           with_error;
  rand bit           crc_error;
  rand bit [3:0]     cte_type;
  rand bit [5:0]     cte_time;

  constraint c_channel {
    channel inside {[0:39]};
    if (adv_type inside {ADV_IND, ADV_DIRECT_IND, ADV_NONCONN_IND, ADV_SCAN_IND, AUX_ADV_IND})
      channel inside {37, 38, 39};
  }
  constraint c_length { length inside {[0:251]}; data_payload.size() == length; }
  constraint c_access { access_addr != 32'h0; access_addr != 32'hFFFFFFFF; }
  constraint c_error { with_error dist {0:=95, 1:=5}; crc_error dist {0:=98, 1:=2}; }
  constraint c_cte { cte_time inside {[0:20]}; }

  function new(string name = "bluetooth5_transaction");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("BT5: adv=%s phy=%s llid=%s ch=%0d len=%0d enc=%b aa=0x%0x err=%b crc_err=%b",
      adv_type.name(), phy_mode.name(), llid.name(), channel, length, encrypted, access_addr, with_error, crc_error);
  endfunction
endclass
