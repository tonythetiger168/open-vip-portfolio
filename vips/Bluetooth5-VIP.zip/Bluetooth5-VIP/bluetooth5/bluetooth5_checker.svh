// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// bluetooth5_checker.svh

class bluetooth5_checker extends protocol_checker_base;
  `uvm_component_utils(bluetooth5_checker)
  uvm_analysis_imp #(bluetooth5_transaction, bluetooth5_checker) analysis_export;
  bluetooth5_config cfg;
  int tx_count = 0;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(bluetooth5_config)::get(this, "", "cfg", cfg))
      cfg = bluetooth5_config::type_id::create("cfg");
  endfunction
  function void write(bluetooth5_transaction tx);
    tx_count++;
    check_channel(tx);
    check_length(tx);
    check_phy_mode(tx);
    check_access_addr(tx);
    check_crc(tx);
    check_cte(tx);
  endfunction
  function void check_channel(bluetooth5_transaction tx);
    if (tx.channel > 39)
      check_protocol_error($sformatf("Invalid channel %0d", tx.channel));
    if (tx.adv_type inside {bluetooth5_transaction::ADV_IND, bluetooth5_transaction::ADV_DIRECT_IND,
                            bluetooth5_transaction::ADV_NONCONN_IND, bluetooth5_transaction::ADV_SCAN_IND,
                            bluetooth5_transaction::AUX_ADV_IND} &&
        !(tx.channel inside {37, 38, 39}))
      check_protocol_warning($sformatf("Advertising on data channel %0d", tx.channel));
  endfunction
  function void check_length(bluetooth5_transaction tx);
    if (tx.length > 251)
      check_protocol_error($sformatf("Length %0d exceeds BT5 max 251", tx.length));
  endfunction
  function void check_phy_mode(bluetooth5_transaction tx);
    if (tx.phy_mode == bluetooth5_transaction::PHY_2M && !cfg.le_2m_phy)
      check_protocol_warning("2M PHY used but not enabled in config");
    if (tx.phy_mode inside {bluetooth5_transaction::PHY_CODED_S2, bluetooth5_transaction::PHY_CODED_S8} && !cfg.le_coded_phy)
      check_protocol_warning("Coded PHY used but not enabled in config");
  endfunction
  function void check_access_addr(bluetooth5_transaction tx);
    if (tx.access_addr == 32'h0 || tx.access_addr == 32'hFFFFFFFF)
      check_protocol_error("Invalid access address");
  endfunction
  function void check_crc(bluetooth5_transaction tx);
    if (tx.crc_error)
      check_protocol_error("CRC error detected");
  endfunction
  function void check_cte(bluetooth5_transaction tx);
    if (tx.cte_time > 20)
      check_protocol_warning($sformatf("CTE time %0d > 20 (max 160us)", tx.cte_time));
  endfunction
  task run_phase(uvm_phase phase); endtask
  function void report_phase(uvm_phase phase);
    `uvm_info("BT5_CHK", $sformatf("Checked %0d transactions, %0d errors, %0d warnings",
      tx_count, error_count, warning_count), UVM_LOW)
  endfunction
endclass
