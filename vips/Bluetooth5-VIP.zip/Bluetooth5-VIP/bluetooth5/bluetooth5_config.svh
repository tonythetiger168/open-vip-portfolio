// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// bluetooth5_config.svh

class bluetooth5_config extends uvm_object;
  `uvm_object_utils(bluetooth5_config)
  bit enable_checker  = 1;
  bit enable_coverage = 1;
  bit le_coded_phy = 1;
  bit le_2m_phy = 1;
  bit extended_adv = 1;
  bit periodic_adv = 1;
  int max_data_len = 251;
  int num_channels = 40;
  function new(string name = "bluetooth5_config");
    super.new(name);
  endfunction
endclass
