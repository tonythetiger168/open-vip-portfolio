// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// bluetooth5_if.sv
// Bluetooth 5 LE Interface

interface bluetooth5_if (input logic clk, input logic rst_n);
  // PHY signals
  logic [1:0]  phy_mode;      // 0=1M, 1=2M, 2=CODED_S2, 3=CODED_S8
  logic        tx_en;
  logic        rx_en;
  logic [7:0]  tx_data;
  logic        tx_valid;
  logic [7:0]  rx_data;
  logic        rx_valid;
  logic        rx_crc_ok;
  logic [6:0]  channel;       // 0-39 for advertising, 0-36 for data
  logic [2:0]  adv_type;      // ADV_IND, ADV_DIRECT_IND, etc.
  logic [47:0] adv_addr;
  logic [47:0] init_addr;
  logic [31:0] access_addr;
  logic [2:0]  llid;          // LL Data PDU type
  logic        nesn;
  logic        sn;
  logic        md;
  logic [7:0]  length;
  logic        encrypted;
  logic [3:0]  cte_type;
  logic [5:0]  cte_time;

  modport DUT (
    input  clk, rst_n, rx_data, rx_valid, rx_crc_ok, channel,
    output tx_en, rx_en, tx_data, tx_valid, phy_mode, adv_type, adv_addr,
    output init_addr, access_addr, llid, nesn, sn, md, length, encrypted, cte_type, cte_time
  );

  modport TB (
    input  clk, rst_n, tx_en, rx_en, tx_data, tx_valid, phy_mode, adv_type,
    input  adv_addr, init_addr, access_addr, llid, nesn, sn, md, length, encrypted, cte_type, cte_time,
    output rx_data, rx_valid, rx_crc_ok, channel
  );

  clocking mon_cb @(posedge clk);
    input tx_en, rx_en, tx_data, tx_valid, phy_mode, adv_type, adv_addr;
    input init_addr, access_addr, llid, nesn, sn, md, length, encrypted;
    input rx_data, rx_valid, rx_crc_ok, channel, cte_type, cte_time;
  endclocking

  clocking drv_cb @(posedge clk);
    output rx_data, rx_valid, rx_crc_ok, channel;
    input  tx_en, tx_valid;
  endclocking
endinterface
