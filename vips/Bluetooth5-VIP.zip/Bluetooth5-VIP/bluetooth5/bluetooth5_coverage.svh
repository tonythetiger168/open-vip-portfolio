// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// bluetooth5_coverage.svh

class bluetooth5_coverage extends coverage_collector_base;
  `uvm_component_utils(bluetooth5_coverage)
  uvm_analysis_imp #(bluetooth5_transaction, bluetooth5_coverage) analysis_export;

  // Coverpoint sample variables (declared before the covergroups that
  // reference them, per IEEE 1800 declaration-before-use rules)
  bluetooth5_transaction tx;
  int sample_count = 0;

  covergroup bt5_adv_cg;
    option.per_instance = 1;
    adv_cp: coverpoint tx.adv_type {
      bins adv_ind  = {bluetooth5_transaction::ADV_IND};
      bins adv_dir  = {bluetooth5_transaction::ADV_DIRECT_IND};
      bins adv_nc   = {bluetooth5_transaction::ADV_NONCONN_IND};
      bins scan_req = {bluetooth5_transaction::SCAN_REQ};
      bins scan_rsp = {bluetooth5_transaction::SCAN_RSP};
      bins conn_ind = {bluetooth5_transaction::CONNECT_IND};
      bins adv_scan = {bluetooth5_transaction::ADV_SCAN_IND};
      bins aux_adv  = {bluetooth5_transaction::AUX_ADV_IND};
    }
    phy_cp: coverpoint tx.phy_mode {
      bins phy_1m = {bluetooth5_transaction::PHY_1M};
      bins phy_2m = {bluetooth5_transaction::PHY_2M};
      bins coded_s2 = {bluetooth5_transaction::PHY_CODED_S2};
      bins coded_s8 = {bluetooth5_transaction::PHY_CODED_S8};
    }
    channel_cp: coverpoint tx.channel {
      bins ch37 = {37}; bins ch38 = {38}; bins ch39 = {39};
      bins data_ch = {[0:36]};
    }
    llid_cp: coverpoint tx.llid {
      bins reserved = {bluetooth5_transaction::LLID_RESERVED};
      bins data_cont = {bluetooth5_transaction::LLID_DATA_CONT};
      bins data_start = {bluetooth5_transaction::LLID_DATA_START};
      bins ctrl = {bluetooth5_transaction::LLID_CTRL};
    }
    len_cp: coverpoint tx.length { bins empty = {0}; bins sm = {[1:31]}; bins med = {[32:127]}; bins lg = {[128:251]}; }
    enc_cp: coverpoint tx.encrypted;
    error_cp: coverpoint tx.with_error;
    cx_adv_phy: cross adv_cp, phy_cp;
    cx_channel_phy: cross channel_cp, phy_cp;
    cx_llid_len: cross llid_cp, len_cp;
  endgroup

  // Data-pattern coverage: payload length corners x LLID x encryption
  covergroup bt5_data_cg;
    option.per_instance = 1;
    len_cp: coverpoint tx.length {
      bins zero   = {0};
      bins min1   = {1};
      bins sm     = {[2:31]};
      bins med    = {[32:127]};
      bins lg     = {[128:250]};
      bins max251 = {251};
    }
    llid_cp: coverpoint tx.llid {
      bins cont  = {bluetooth5_transaction::LLID_DATA_CONT};
      bins start = {bluetooth5_transaction::LLID_DATA_START};
      bins ctrl  = {bluetooth5_transaction::LLID_CTRL};
    }
    enc_cp: coverpoint tx.encrypted { bins clear = {0}; bins enc = {1}; }
    cx_len_llid: cross len_cp, llid_cp;
    cx_len_enc:  cross len_cp, enc_cp;
  endgroup

  // Link-layer FSM coverage: NESN/SN/MD handshake bits and LLID transitions
  covergroup bt5_fsm_cg;
    option.per_instance = 1;
    llid_cp: coverpoint tx.llid {
      bins start = {bluetooth5_transaction::LLID_DATA_START};
      bins cont  = {bluetooth5_transaction::LLID_DATA_CONT};
      bins ctrl  = {bluetooth5_transaction::LLID_CTRL};
    }
    nesn_cp: coverpoint tx.nesn;
    sn_cp:   coverpoint tx.sn;
    md_cp:   coverpoint tx.md;
    trans_cp: coverpoint tx.llid {
      bins start_then_cont = (bluetooth5_transaction::LLID_DATA_START => bluetooth5_transaction::LLID_DATA_CONT);
      bins cont_then_ctrl  = (bluetooth5_transaction::LLID_DATA_CONT => bluetooth5_transaction::LLID_CTRL);
      bins ctrl_then_start = (bluetooth5_transaction::LLID_CTRL => bluetooth5_transaction::LLID_DATA_START);
    }
    cx_llid_md: cross llid_cp, md_cp;
    cx_sn_nesn: cross sn_cp, nesn_cp;
  endgroup


  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    bt5_adv_cg = new();
    bt5_data_cg = new();
    bt5_fsm_cg = new();
  endfunction
  function void write(bluetooth5_transaction tx_); begin tx = tx_; sample_coverage(tx); end endfunction
  virtual function void sample_coverage(uvm_sequence_item tx_);
    bluetooth5_transaction btx;
    if (!$cast(btx, tx_)) return;
    tx = btx;
    bt5_adv_cg.sample();
    bt5_data_cg.sample();
    bt5_fsm_cg.sample();
    sample_count++;
  endfunction
  function void report_phase(uvm_phase phase);
    `uvm_info("BT5_COV", $sformatf("Sampled %0d transactions", sample_count), UVM_LOW)
    `uvm_info("BT5_COV", $sformatf("Adv coverage = %0.2f%%", bt5_adv_cg.get_coverage()), UVM_LOW)
  endfunction
endclass
