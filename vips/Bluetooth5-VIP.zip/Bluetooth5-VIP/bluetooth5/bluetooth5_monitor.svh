// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// bluetooth5_monitor.svh -- Bluetooth 5 LE monitor
// Reassembles BLE link-layer packets from the TX (DUT egress) byte stream:
// preamble / access address / PDU header / payload / CRC-24, re-computes
// the CRC-24 and classifies the packet, then publishes the transaction on
// the analysis port.

`ifndef BLUETOOTH5_MONITOR_SVH
`define BLUETOOTH5_MONITOR_SVH

class bluetooth5_monitor extends uvm_monitor;
  `uvm_component_utils(bluetooth5_monitor)
  virtual bluetooth5_if vif;
  uvm_analysis_port #(bluetooth5_transaction) ap;
  bluetooth5_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual bluetooth5_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "BT5 virtual interface not found")
    if (!uvm_config_db#(bluetooth5_config)::get(this, "", "cfg", cfg))
      cfg = bluetooth5_config::type_id::create("cfg");
  endfunction

  // BLE CRC-24: poly 0x00065B reflected (0xDA6000), init 0x555555
  function automatic bit [23:0] bt5_crc24(ref bit [7:0] bytes[$]);
    bit [23:0] crc;
    crc = 24'h555555;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 24'hDA6000 : (crc >> 1);
    end
    return crc;
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    forever monitor_packet();
  endtask

  task monitor_packet();
    bluetooth5_transaction tx;
    bit [7:0] bytes[$];
    bit [7:0] body[$];
    bit [23:0] rcv_crc, calc_crc;

    // wait for the start of a TX burst
    @(vif.mon_cb);
    while (!(vif.mon_cb.tx_en && vif.mon_cb.tx_valid))
      @(vif.mon_cb);

    tx = bluetooth5_transaction::type_id::create("tx");
    // sideband captured at packet start
    tx.phy_mode    = bluetooth5_transaction::phy_mode_e'(vif.mon_cb.phy_mode);
    tx.channel     = vif.mon_cb.channel;
    tx.adv_addr    = vif.mon_cb.adv_addr;
    tx.peer_addr   = vif.mon_cb.init_addr;
    tx.encrypted   = vif.mon_cb.encrypted;
    tx.cte_type    = vif.mon_cb.cte_type;
    tx.cte_time    = vif.mon_cb.cte_time;

    // collect the whole burst (preamble .. CRC)
    bytes.delete();
    while (vif.mon_cb.tx_en && vif.mon_cb.tx_valid) begin
      bytes.push_back(vif.mon_cb.tx_data);
      @(vif.mon_cb);
    end

    if (bytes.size() < 10) begin
      // truncated packet: preamble + AA + header + crc is 10 bytes minimum
      tx.with_error = 1;
      tx.length = 0;
      `uvm_warning("BT5_MON", $sformatf("Truncated packet observed (%0d bytes)", bytes.size()))
      ap.write(tx);
      return;
    end

    // preamble (1) + access address (4, LSB first)
    void'(bytes.pop_front());
    for (int i = 0; i < 4; i++)
      tx.access_addr[i*8 +: 8] = bytes.pop_front();

    // CRC-24 re-computation over header + payload (exclude trailing 3)
    body = bytes;
    repeat (3) void'(body.pop_back());
    calc_crc = bt5_crc24(body);
    for (int i = 0; i < 3; i++)
      rcv_crc[i*8 +: 8] = bytes[bytes.size() - 3 + i];

    // PDU header
    if (tx.channel inside {37, 38, 39}) begin
      tx.adv_type = bluetooth5_transaction::adv_type_e'(bytes[0][3:0]);
      tx.length   = bytes[1];
    end else begin
      tx.llid = bluetooth5_transaction::llid_e'(bytes[0][1:0]);
      tx.nesn = bytes[0][2];
      tx.sn   = bytes[0][3];
      tx.md   = bytes[0][4];
      tx.length = bytes[1];
    end

    // payload
    tx.data_payload = new[tx.length];
    for (int i = 0; i < tx.length && (2 + i) < bytes.size() - 3; i++)
      tx.data_payload[i] = bytes[2 + i];

    // classification
    tx.crc_error  = (calc_crc != rcv_crc);
    tx.with_error = tx.crc_error;
    if (tx.with_error)
      `uvm_warning("BT5_MON", $sformatf("CRC-24 mismatch: rcv=0x%06h calc=0x%06h", rcv_crc, calc_crc))

    `uvm_info("BT5_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_MEDIUM)
    ap.write(tx);
  endtask
endclass
`endif
