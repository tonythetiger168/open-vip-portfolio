// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// bluetooth5_sequences.svh

class bluetooth5_base_sequence extends uvm_sequence #(bluetooth5_transaction);
  `uvm_object_utils(bluetooth5_base_sequence)
  function new(string name = "bluetooth5_base_sequence");
    super.new(name);
  endfunction
endclass

class bluetooth5_random_sequence extends bluetooth5_base_sequence;
  `uvm_object_utils(bluetooth5_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "bluetooth5_random_sequence");
    super.new(name);
  endfunction
  task body();
    bluetooth5_transaction tx;
    repeat (num_txns) begin
      tx = bluetooth5_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "BT5 tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class bluetooth5_adv_sequence extends bluetooth5_base_sequence;
  `uvm_object_utils(bluetooth5_adv_sequence)
  rand int num_txns = 50;
  function new(string name = "bluetooth5_adv_sequence");
    super.new(name);
  endfunction
  task body();
    bluetooth5_transaction tx;
    repeat (num_txns) begin
      tx = bluetooth5_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        adv_type inside {bluetooth5_transaction::ADV_IND, bluetooth5_transaction::ADV_SCAN_IND,
                         bluetooth5_transaction::ADV_NONCONN_IND, bluetooth5_transaction::AUX_ADV_IND};
        channel inside {37, 38, 39};
      }) `uvm_error("RANDFAIL", "BT5 adv randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class bluetooth5_data_sequence extends bluetooth5_base_sequence;
  `uvm_object_utils(bluetooth5_data_sequence)
  rand int num_txns = 50;
  function new(string name = "bluetooth5_data_sequence");
    super.new(name);
  endfunction
  task body();
    bluetooth5_transaction tx;
    repeat (num_txns) begin
      tx = bluetooth5_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        channel inside {[0:36]};
        llid inside {bluetooth5_transaction::LLID_DATA_START, bluetooth5_transaction::LLID_DATA_CONT};
        length inside {[1:251]};
      }) `uvm_error("RANDFAIL", "BT5 data randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class bluetooth5_phy_sequence extends bluetooth5_base_sequence;
  `uvm_object_utils(bluetooth5_phy_sequence)
  rand int num_txns = 30;
  function new(string name = "bluetooth5_phy_sequence");
    super.new(name);
  endfunction
  task body();
    bluetooth5_transaction tx;
    repeat (num_txns) begin
      tx = bluetooth5_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        phy_mode dist {bluetooth5_transaction::PHY_1M:=30, bluetooth5_transaction::PHY_2M:=40,
                       bluetooth5_transaction::PHY_CODED_S2:=15, bluetooth5_transaction::PHY_CODED_S8:=15};
      }) `uvm_error("RANDFAIL", "BT5 PHY randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// bt5_* sequence family (num_pkts naming) -- base + directed variants
// ---------------------------------------------------------------------------
class bt5_base_sequence extends bluetooth5_base_sequence;
  `uvm_object_utils(bt5_base_sequence)
  rand int num_pkts = 10;
  constraint c_num_pkts { num_pkts inside {[1:500]}; }
  function new(string name = "bt5_base_sequence");
    super.new(name);
  endfunction
  task body();
    bluetooth5_transaction pkt;
    repeat (num_pkts) begin
      pkt = bluetooth5_transaction::type_id::create("pkt");
      start_item(pkt);
      if (!pkt.randomize()) `uvm_error("RANDFAIL", "BT5 base randomization failed")
      finish_item(pkt);
    end
  endtask
endclass

class bt5_random_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_random_sequence)
  function new(string name = "bt5_random_sequence");
    super.new(name);
    num_pkts = 100;
  endfunction
endclass

class bt5_adv_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_adv_sequence)
  function new(string name = "bt5_adv_sequence");
    super.new(name);
    num_pkts = 50;
  endfunction
  task body();
    bluetooth5_transaction pkt;
    repeat (num_pkts) begin
      pkt = bluetooth5_transaction::type_id::create("pkt");
      start_item(pkt);
      if (!pkt.randomize() with {
        adv_type inside {bluetooth5_transaction::ADV_IND, bluetooth5_transaction::ADV_SCAN_IND,
                         bluetooth5_transaction::ADV_NONCONN_IND, bluetooth5_transaction::AUX_ADV_IND};
        channel inside {37, 38, 39};
      }) `uvm_error("RANDFAIL", "BT5 adv randomization failed")
      finish_item(pkt);
    end
  endtask
endclass

class bt5_data_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_data_sequence)
  function new(string name = "bt5_data_sequence");
    super.new(name);
    num_pkts = 50;
  endfunction
  task body();
    bluetooth5_transaction pkt;
    repeat (num_pkts) begin
      pkt = bluetooth5_transaction::type_id::create("pkt");
      start_item(pkt);
      if (!pkt.randomize() with {
        channel inside {[0:36]};
        llid inside {bluetooth5_transaction::LLID_DATA_START, bluetooth5_transaction::LLID_DATA_CONT};
        length inside {[1:251]};
      }) `uvm_error("RANDFAIL", "BT5 data randomization failed")
      finish_item(pkt);
    end
  endtask
endclass

class bt5_phy_update_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_phy_update_sequence)
  function new(string name = "bt5_phy_update_sequence");
    super.new(name);
    num_pkts = 30;
  endfunction
  task body();
    bluetooth5_transaction pkt;
    repeat (num_pkts) begin
      pkt = bluetooth5_transaction::type_id::create("pkt");
      start_item(pkt);
      if (!pkt.randomize() with {
        phy_mode dist {bluetooth5_transaction::PHY_1M:=30, bluetooth5_transaction::PHY_2M:=40,
                       bluetooth5_transaction::PHY_CODED_S2:=15, bluetooth5_transaction::PHY_CODED_S8:=15};
      }) `uvm_error("RANDFAIL", "BT5 PHY randomization failed")
      finish_item(pkt);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Directed: CRC error injection (must be detected by the monitor)
// ---------------------------------------------------------------------------
class bt5_error_inject_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_error_inject_sequence)
  rand int num_pkts = 8;
  function new(string name = "bt5_error_inject_sequence"); super.new(name); endfunction
  task body();
    bluetooth5_transaction pkt;
    repeat (num_pkts) begin
      pkt = bluetooth5_transaction::type_id::create("pkt");
      start_item(pkt);
      if (!pkt.randomize() with { crc_error == 1; }) `uvm_error("RANDFAIL", "BT5 err randomization failed")
      finish_item(pkt);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Directed: back-to-back packets (minimum inter-frame space, stress)
// ---------------------------------------------------------------------------
class bt5_back_to_back_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_back_to_back_sequence)
  rand int num_pkts = 20;
  function new(string name = "bt5_back_to_back_sequence"); super.new(name); endfunction
  task body();
    bluetooth5_transaction pkt;
    repeat (num_pkts) begin
      pkt = bluetooth5_transaction::type_id::create("pkt");
      start_item(pkt);
      if (!pkt.randomize() with {
        pkt_type == bluetooth5_transaction::DATA_PKT;
        length inside {[0:31]};
      }) `uvm_error("RANDFAIL", "BT5 b2b randomization failed")
      finish_item(pkt);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Corner: zero-length and maximum-length (251B) data PDUs
// ---------------------------------------------------------------------------
class bt5_corner_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_corner_sequence)
  function new(string name = "bt5_corner_sequence"); super.new(name); endfunction
  task body();
    bluetooth5_transaction pkt;
    // zero-length data PDU (keepalive)
    pkt = bluetooth5_transaction::type_id::create("pkt");
    start_item(pkt);
    if (!pkt.randomize() with {
      pkt_type == bluetooth5_transaction::DATA_PKT; length == 0;
    }) `uvm_error("RANDFAIL", "BT5 corner-0 randomization failed")
    finish_item(pkt);
    // maximum-length data PDU (LE Data Length Extension)
    pkt = bluetooth5_transaction::type_id::create("pkt");
    start_item(pkt);
    if (!pkt.randomize() with {
      pkt_type == bluetooth5_transaction::DATA_PKT; length == 251;
    }) `uvm_error("RANDFAIL", "BT5 corner-251 randomization failed")
    finish_item(pkt);
  endtask
endclass

// ---------------------------------------------------------------------------
// Reset behavior: single advertising packet right after reset release
// ---------------------------------------------------------------------------
class bt5_reset_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_reset_sequence)
  function new(string name = "bt5_reset_sequence"); super.new(name); endfunction
  task body();
    bluetooth5_transaction pkt;
    pkt = bluetooth5_transaction::type_id::create("pkt");
    start_item(pkt);
    if (!pkt.randomize() with {
      pkt_type == bluetooth5_transaction::ADV_PKT;
      adv_type == bluetooth5_transaction::ADV_IND;
      channel == 37;
      length == 6;
    }) `uvm_error("RANDFAIL", "BT5 reset randomization failed")
    finish_item(pkt);
  endtask
endclass

// ---------------------------------------------------------------------------
// Regression: weighted mix of all directed sequences
// ---------------------------------------------------------------------------
class bt5_regression_sequence extends bt5_base_sequence;
  `uvm_object_utils(bt5_regression_sequence)
  rand int num_pkts = 30;
  function new(string name = "bt5_regression_sequence"); super.new(name); endfunction
  task body();
    bt5_random_sequence        rnd_seq;
    bt5_adv_sequence           adv_seq;
    bt5_data_sequence          dat_seq;
    bt5_phy_update_sequence    phy_seq;
    bt5_back_to_back_sequence  b2b_seq;
    bt5_error_inject_sequence  err_seq;
    rnd_seq = bt5_random_sequence::type_id::create("rnd_seq");
    rnd_seq.num_pkts = num_pkts / 3;
    rnd_seq.start(m_sequencer);
    adv_seq = bt5_adv_sequence::type_id::create("adv_seq");
    adv_seq.num_pkts = num_pkts / 4 + 1;
    adv_seq.start(m_sequencer);
    dat_seq = bt5_data_sequence::type_id::create("dat_seq");
    dat_seq.num_pkts = num_pkts / 4 + 1;
    dat_seq.start(m_sequencer);
    phy_seq = bt5_phy_update_sequence::type_id::create("phy_seq");
    phy_seq.num_pkts = 4;
    phy_seq.start(m_sequencer);
    b2b_seq = bt5_back_to_back_sequence::type_id::create("b2b_seq");
    b2b_seq.num_pkts = num_pkts / 3;
    b2b_seq.start(m_sequencer);
    err_seq = bt5_error_inject_sequence::type_id::create("err_seq");
    err_seq.num_pkts = 4;
    err_seq.start(m_sequencer);
  endtask
endclass
