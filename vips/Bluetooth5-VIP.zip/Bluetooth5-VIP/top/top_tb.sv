// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- Bluetooth 5 testbench top
// Single BT5 interface + functional DUT (bluetooth5_dut): an LE link-layer
// loopback peer that receives the driver's byte stream (rx_*) and
// re-transmits it on tx_* with proper sideband, closing the loop with the
// UVM monitor.

`ifndef TOP_TB_SV
`define TOP_TB_SV

`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import bluetooth5_pkg::*;
import env_pkg::*;

module top_tb;

  logic clk = 0;
  logic rst_n;
  always #31.25ns clk = ~clk;   // 16MHz (BLE baseband)

  initial begin
    rst_n = 0;
    #200ns;
    rst_n = 1;
  end

  bluetooth5_if bt5_if (.clk(clk), .rst_n(rst_n));

  bluetooth5_dut dut (.vif(bt5_if));

  // Tiered SVA compliance checker (module form)
  bluetooth5_compliance_checker_sva u_bt5_sva_chk (.vif(bt5_if));

  // Protocol SVA checkers (module form)
  bluetooth5_data_integrity_checker        u_bt5_integrity_chk (.vif(bt5_if));
  bluetooth5_error_handling_checker        u_bt5_error_chk     (.vif(bt5_if));
  bluetooth5_protocol_compliance_checker   u_bt5_protocol_chk  (.vif(bt5_if));
  bluetooth5_timing_performance_checker    u_bt5_timing_chk    (.vif(bt5_if));

  initial begin
    uvm_config_db#(virtual bluetooth5_if)::set(null, "*", "bt5_vif", bt5_if);
    run_test();
  end
endmodule

//==========================================================================
// Functional DUT: BLE LE link-layer loopback peer.
//  - captures the ingress byte stream while rx_valid
//  - after a short T_IFS turnaround, re-transmits the packet on tx_*
//  - mirrors header sideband (phy/adv/llid/nesn/sn/md/length/addr/cte)
//==========================================================================
module bluetooth5_dut (bluetooth5_if vif);

  bit [7:0] pkt_q[$];
  typedef enum logic [1:0] {PEER_IDLE, PEER_TURN, PEER_SEND} peer_state_e;
  peer_state_e state;
  int          turn_cnt;
  int          tx_idx;

  // ingress capture
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      pkt_q.delete();
    end else begin
      if (vif.rx_valid)
        pkt_q.push_back(vif.rx_data);
    end
  end

  // loopback engine
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      state            <= PEER_IDLE;
      turn_cnt         <= 0;
      tx_idx           <= 0;
      vif.tx_en        <= 1'b0;
      vif.tx_valid     <= 1'b0;
      vif.tx_data      <= 8'h00;
      vif.rx_en        <= 1'b0;
      vif.phy_mode     <= 2'd1;
      vif.adv_type     <= 4'h0;
      vif.adv_addr     <= 48'h0;
      vif.init_addr    <= 48'h0;
      vif.access_addr  <= 32'h8E89_BED6;
      vif.llid         <= 2'h0;
      vif.nesn         <= 1'b0;
      vif.sn           <= 1'b0;
      vif.md           <= 1'b0;
      vif.length       <= 8'h0;
      vif.encrypted    <= 1'b0;
      vif.cte_type     <= 2'h0;
      vif.cte_time     <= 8'h0;
    end else begin
      case (state)
        PEER_IDLE: begin
          vif.tx_valid <= 1'b0;
          vif.tx_en    <= 1'b0;
          vif.rx_en    <= 1'b1;
          // packet fully received when rx_valid drops with data queued
          if (!vif.rx_valid && pkt_q.size() > 0) begin
            state    <= PEER_TURN;
            turn_cnt <= 4;                 // T_IFS turnaround
            tx_idx   <= 0;
            // mirror sideband from the received packet image
            vif.rx_en <= 1'b0;
            if (pkt_q.size() > 6) begin
              vif.access_addr <= {pkt_q[4], pkt_q[3], pkt_q[2], pkt_q[1]};
              vif.length      <= pkt_q[6];
              if (vif.channel inside {7'd37, 7'd38, 7'd39})
                vif.adv_type <= {1'b0, pkt_q[5][2:0]};
              else begin
                vif.llid <= pkt_q[5][1:0];
                vif.nesn <= pkt_q[5][2];
                vif.sn   <= pkt_q[5][3];
                vif.md   <= pkt_q[5][4];
              end
            end
          end
        end
        PEER_TURN: begin
          if (turn_cnt > 0) turn_cnt <= turn_cnt - 1;
          else begin
            state       <= PEER_SEND;
            vif.tx_en   <= 1'b1;
            vif.tx_valid<= 1'b1;
          end
        end
        PEER_SEND: begin
          vif.tx_en    <= 1'b1;
          vif.tx_valid <= 1'b1;
          vif.tx_data  <= pkt_q[tx_idx];
          tx_idx <= tx_idx + 1;
          if (tx_idx + 1 >= pkt_q.size()) begin
            state  <= PEER_IDLE;
            pkt_q.delete();
          end
        end
        default: state <= PEER_IDLE;
      endcase
    end
  end
endmodule
`endif
