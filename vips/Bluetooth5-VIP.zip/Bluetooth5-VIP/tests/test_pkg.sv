// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// test_pkg.sv -- Bluetooth 5 test library
// bt5_base_test builds the env and wires vif/cfg; derived tests select
// stimulus. full_regression_test is the regression default.

`ifndef TEST_PKG_SV
`define TEST_PKG_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import common_pkg::*;
import bluetooth5_pkg::*;
import env_pkg::*;

class bt5_base_test extends uvm_test;
  `uvm_component_utils(bt5_base_test)
  multi_protocol_env env;
  bluetooth5_config  cfg;
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
  virtual function void build_phase(uvm_phase phase);
    virtual bluetooth5_if vif;
    super.build_phase(phase);
    if (!uvm_config_db#(virtual bluetooth5_if)::get(this, "", "bt5_vif", vif))
      `uvm_fatal("NOVIF", "bluetooth5_if virtual interface not found")
    cfg = bluetooth5_config::type_id::create("cfg");
    uvm_config_db#(virtual bluetooth5_if)::set(this, "env.bt5_agt.*", "vif", vif);
    uvm_config_db#(virtual bluetooth5_if)::set(this, "env.sva_chk", "vif", vif);
    uvm_config_db#(bluetooth5_config)::set(this, "env.bt5_agt.*", "cfg", cfg);
    env = multi_protocol_env::type_id::create("env", this);
  endfunction
  virtual task run_phase(uvm_phase phase);
    bt5_base_sequence seq;
    phase.raise_objection(this);
    seq = bt5_base_sequence::type_id::create("seq");
    seq.start(env.bt5_agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class bt5_adv_test extends bt5_base_test;
  `uvm_component_utils(bt5_adv_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  virtual task run_phase(uvm_phase phase);
    bt5_adv_sequence seq;
    phase.raise_objection(this);
    seq = bt5_adv_sequence::type_id::create("seq");
    seq.num_pkts = 12;
    seq.start(env.bt5_agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class bt5_data_test extends bt5_base_test;
  `uvm_component_utils(bt5_data_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  virtual task run_phase(uvm_phase phase);
    bt5_data_sequence seq;
    phase.raise_objection(this);
    seq = bt5_data_sequence::type_id::create("seq");
    seq.num_pkts = 12;
    seq.start(env.bt5_agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class bt5_phy_test extends bt5_base_test;
  `uvm_component_utils(bt5_phy_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  virtual task run_phase(uvm_phase phase);
    bt5_phy_update_sequence seq;
    phase.raise_objection(this);
    seq = bt5_phy_update_sequence::type_id::create("seq");
    seq.num_pkts = 6;
    seq.start(env.bt5_agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class bt5_error_test extends bt5_base_test;
  `uvm_component_utils(bt5_error_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  virtual task run_phase(uvm_phase phase);
    bt5_error_inject_sequence seq;
    phase.raise_objection(this);
    seq = bt5_error_inject_sequence::type_id::create("seq");
    seq.num_pkts = 8;
    seq.start(env.bt5_agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class bt5_corner_test extends bt5_base_test;
  `uvm_component_utils(bt5_corner_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  virtual task run_phase(uvm_phase phase);
    bt5_corner_sequence seq;
    phase.raise_objection(this);
    seq = bt5_corner_sequence::type_id::create("seq");
    seq.start(env.bt5_agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

class bt5_regression_test extends bt5_base_test;
  `uvm_component_utils(bt5_regression_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
  virtual task run_phase(uvm_phase phase);
    bt5_regression_sequence seq;
    phase.raise_objection(this);
    seq = bt5_regression_sequence::type_id::create("seq");
    seq.num_pkts = 30;
    seq.start(env.bt5_agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Default regression test (regression/Makefile TESTNAME default)
class full_regression_test extends bt5_regression_test;
  `uvm_component_utils(full_regression_test)
  function new(string name, uvm_component parent); super.new(name, parent); endfunction
endclass
`endif
