// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// env_pkg.sv -- Bluetooth 5 verification environment package
// End-to-end scoreboard (driver-expected vs monitor-observed) + environment
// wiring the BT5 agent, coverage, protocol checker and tiered SVA
// compliance checker.

`ifndef ENV_PKG_SV
`define ENV_PKG_SV

// Guarded includes keep compilation order independent
`include "common_pkg.sv"
// The tiered L1/L2 + L4 SVA compliance checker (bluetooth5_compliance_checker_sva)
// is a compilation-unit module and cannot be referenced from inside this
// package; it is instantiated in top_tb and the file is compiled standalone.

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import bluetooth5_pkg::*;

  //==========================================================================
  // End-to-end scoreboard (Bluetooth 5)
  //   exp: packets composed by the driver (DUT ingress)
  //   obs: packets decoded by the monitor from the DUT egress
  //==========================================================================
  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  class multi_protocol_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(multi_protocol_scoreboard)

    uvm_analysis_imp_exp #(bluetooth5_transaction, multi_protocol_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(bluetooth5_transaction, multi_protocol_scoreboard) obs_ap;

    bluetooth5_transaction exp_q[$], obs_q[$];
    int unsigned n_matches;
    int unsigned n_mismatches;
    int unsigned n_errors_detected;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
      n_matches = 0;
      n_mismatches = 0;
      n_errors_detected = 0;
    endfunction

    virtual function void write_exp(bluetooth5_transaction t);
      exp_q.push_back(t);
      check();
    endfunction

    virtual function void write_obs(bluetooth5_transaction t);
      obs_q.push_back(t);
      check();
    endfunction

    virtual function void check();
      while (exp_q.size() > 0 && obs_q.size() > 0) begin
        bluetooth5_transaction e = exp_q.pop_front();
        bluetooth5_transaction o = obs_q.pop_front();
        if (compare_txn(e, o)) begin
          n_matches++;
          if (e.crc_error || e.with_error)
            n_errors_detected++;
        end else begin
          n_mismatches++;
          `uvm_error("BT5_SB", $sformatf("end-to-end mismatch\n  exp: %s\n  obs: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    // Injected CRC errors count as a match only when actually detected
    virtual function bit compare_txn(bluetooth5_transaction e,
                                     bluetooth5_transaction o);
      if (e.crc_error || e.with_error)
        return (o.crc_error == 1'b1) || (o.with_error == 1'b1);
      if (o.with_error) return 0;
      if (e.access_addr != o.access_addr) return 0;
      if (e.channel != o.channel) return 0;
      if (e.length != o.length) return 0;
      if (e.channel inside {37, 38, 39}) begin
        if (e.adv_type != o.adv_type) return 0;
      end else begin
        if (e.llid != o.llid) return 0;
      end
      for (int i = 0; i < e.length; i++)
        if (e.data_payload[i] != o.data_payload[i]) return 0;
      return 1;
    endfunction

    virtual function void report_phase(uvm_phase phase);
      super.report_phase(phase);
      `uvm_info("BT5_SB", $sformatf("n_matches=%0d n_mismatches=%0d errors_detected=%0d",
                n_matches, n_mismatches, n_errors_detected), UVM_LOW)
      if (n_mismatches > 0)
        `uvm_error("BT5_SB", "end-to-end n_mismatches detected")
    endfunction
  endclass

  //==========================================================================
  // Environment (Bluetooth 5)
  //==========================================================================
  class multi_protocol_env extends uvm_env;
    `uvm_component_utils(multi_protocol_env)

    bluetooth5_agent              bt5_agt;
    multi_protocol_scoreboard     sb;

    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      // agent internally carries the protocol checker + coverage collector
      bt5_agt = bluetooth5_agent::type_id::create("bt5_agt", this);
      sb      = multi_protocol_scoreboard::type_id::create("sb", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      // end-to-end: expected (driver) vs observed (monitor)
      bt5_agt.drv.drv_ap.connect(sb.exp_ap);
      bt5_agt.mon.ap.connect(sb.obs_ap);
    endfunction

    function void report_phase(uvm_phase phase);
      super.report_phase(phase);
      `uvm_info("ENV", "bluetooth5 env done", UVM_LOW)
    endfunction
  endclass

endpackage
`endif
