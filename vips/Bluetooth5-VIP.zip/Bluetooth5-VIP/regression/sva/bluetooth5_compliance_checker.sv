// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// Bluetooth5 Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 19
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
`ifndef BLUETOOTH5_COMPLIANCE_CHECKER_SV
`define BLUETOOTH5_COMPLIANCE_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// bluetooth5_compliance_checker_sva -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module bluetooth5_compliance_checker_sva (bluetooth5_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; l4_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_bt_phy; @(posedge vif.clk) disable iff (!vif.rst_n) vif.phy_mode inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_bt_phy: assert property(p_bt_phy) l1_pass[0]++; else begin `uvm_warning("BLUETOOTH5_L1", "PHY mode failed"); l1_fail[0]++; end
  cover_p_bt_phy: cover property(p_bt_phy);
  property p_bt_channel; @(posedge vif.clk) disable iff (!vif.rst_n) vif.channel <= 7'd39; endproperty
  assert_p_bt_channel: assert property(p_bt_channel) l1_pass[1]++; else begin `uvm_warning("BLUETOOTH5_L1", "Channel 0-39 failed"); l1_fail[1]++; end
  cover_p_bt_channel: cover property(p_bt_channel);
  property p_bt_adv_type; @(posedge vif.clk) disable iff (!vif.rst_n) vif.adv_type <= 3'd7; endproperty
  assert_p_bt_adv_type: assert property(p_bt_adv_type) l1_pass[2]++; else begin `uvm_warning("BLUETOOTH5_L1", "Adv type failed"); l1_fail[2]++; end
  cover_p_bt_adv_type: cover property(p_bt_adv_type);
  property p_bt_llid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.llid inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_bt_llid: assert property(p_bt_llid) l1_pass[3]++; else begin `uvm_warning("BLUETOOTH5_L1", "LLID valid failed"); l1_fail[3]++; end
  cover_p_bt_llid: cover property(p_bt_llid);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_bt_crc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.rx_valid == 1 |-> vif.rx_crc_ok == 1; endproperty
  assert_p_bt_crc: assert property(p_bt_crc) l2_pass[0]++; else begin `uvm_warning("BLUETOOTH5_L2", "RX CRC OK failed"); l2_fail[0]++; end
  cover_p_bt_crc: cover property(p_bt_crc);
  property p_bt_access_addr; @(posedge vif.clk) disable iff (!vif.rst_n) vif.access_addr != 32'h00000000; endproperty
  assert_p_bt_access_addr: assert property(p_bt_access_addr) l2_pass[1]++; else begin `uvm_warning("BLUETOOTH5_L2", "Access addr failed"); l2_fail[1]++; end
  cover_p_bt_access_addr: cover property(p_bt_access_addr);
  property p_bt_cte; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cte_time <= 6'd20; endproperty
  assert_p_bt_cte: assert property(p_bt_cte) l2_pass[2]++; else begin `uvm_warning("BLUETOOTH5_L2", "CTE time failed"); l2_fail[2]++; end
  cover_p_bt_cte: cover property(p_bt_cte);
  property p_bt_tx_rx; @(posedge vif.clk) disable iff (!vif.rst_n) !(vif.tx_en == 1 && vif.rx_en == 1); endproperty
  assert_p_bt_tx_rx: assert property(p_bt_tx_rx) l2_pass[3]++; else begin `uvm_warning("BLUETOOTH5_L2", "TX/RX mutual excl failed"); l2_fail[3]++; end
  cover_p_bt_tx_rx: cover property(p_bt_tx_rx);
  property p_bt_enc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.encrypted == 1 |-> vif.length > 0; endproperty
  assert_p_bt_enc: assert property(p_bt_enc) l2_pass[4]++; else begin `uvm_warning("BLUETOOTH5_L2", "Encryption failed"); l2_fail[4]++; end
  cover_p_bt_enc: cover property(p_bt_enc);
  property p_bt_length; @(posedge vif.clk) disable iff (!vif.rst_n) vif.length <= 8'd255; endproperty
  assert_p_bt_length: assert property(p_bt_length) l2_pass[5]++; else begin `uvm_warning("BLUETOOTH5_L2", "Length 0-255 failed"); l2_fail[5]++; end
  cover_p_bt_length: cover property(p_bt_length);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: NESN/SN/MD header bits must be known on every data-channel packet
  property p_bt5_l3_hdr_known; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tx_valid |-> !$isunknown({vif.nesn, vif.sn, vif.md}); endproperty
  assert_p_bt5_l3_hdr_known: assert property(p_bt5_l3_hdr_known) l3_pass[0]++; else begin `uvm_warning("BLUETOOTH5_L3", "NESN/SN/MD unknown failed"); l3_fail[0]++; end
  cover_p_bt5_l3_hdr_known: cover property(p_bt5_l3_hdr_known);
  // L3-2: a retransmitted packet (SN unchanged) must keep the same payload length
  property p_bt5_l3_retx_len; @(posedge vif.clk) disable iff (!vif.rst_n) ($rose(vif.tx_valid) && vif.sn == $past(vif.sn,1)) |-> (vif.length == $past(vif.length,1)); endproperty
  assert_p_bt5_l3_retx_len: assert property(p_bt5_l3_retx_len) l3_pass[1]++; else begin `uvm_warning("BLUETOOTH5_L3", "Retransmit with changed length failed"); l3_fail[1]++; end
  cover_p_bt5_l3_retx_len: cover property(p_bt5_l3_retx_len);
  // L3-3: CTE may only be present with a defined CTE type (AoA/AoD)
  property p_bt5_l3_cte_type; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.cte_time > 0) |-> (vif.cte_type <= 4'd2); endproperty
  assert_p_bt5_l3_cte_type: assert property(p_bt5_l3_cte_type) l3_pass[2]++; else begin `uvm_warning("BLUETOOTH5_L3", "CTE with undefined type failed"); l3_fail[2]++; end
  cover_p_bt5_l3_cte_type: cover property(p_bt5_l3_cte_type);
  // L3-4: advertising-channel packets do not carry an LL data LLID
  property p_bt5_l3_adv_llid; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.tx_valid && vif.channel inside {7'd37,7'd38,7'd39}) |-> vif.llid == 3'b000; endproperty
  assert_p_bt5_l3_adv_llid: assert property(p_bt5_l3_adv_llid) l3_pass[3]++; else begin `uvm_warning("BLUETOOTH5_L3", "LLID on advertising channel failed"); l3_fail[3]++; end
  cover_p_bt5_l3_adv_llid: cover property(p_bt5_l3_adv_llid);

  // ---------------- L4: Bluetooth 5 LE protocol-specific rules (5) ----------------
  // L4-1: advertising packets use the LE advertising access address
  property p_bt5_l4_adv_aa; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.tx_valid && vif.channel inside {7'd37, 7'd38, 7'd39})
    |-> (vif.access_addr == 32'h8E89_BED6); endproperty
  assert_p_bt5_l4_adv_aa: assert property(p_bt5_l4_adv_aa) l4_pass[0]++; else begin `uvm_warning("BT5_L4", "Adv channel packet without 0x8E89BED6 AA"); l4_fail[0]++; end
  cover_p_bt5_l4_adv_aa: cover property(p_bt5_l4_adv_aa);
  // L4-2: PHY mode is a legal Bluetooth 5 coding
  property p_bt5_l4_phy_legal; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.tx_valid |-> (vif.phy_mode inside {0, 1, 2, 3}); endproperty
  assert_p_bt5_l4_phy_legal: assert property(p_bt5_l4_phy_legal) l4_pass[1]++; else begin `uvm_warning("BT5_L4", "Illegal PHY mode"); l4_fail[1]++; end
  cover_p_bt5_l4_phy_legal: cover property(p_bt5_l4_phy_legal);
  // L4-3: data-channel length never exceeds the LE 251-byte maximum
  property p_bt5_l4_max_len; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.tx_valid && !(vif.channel inside {7'd37, 7'd38, 7'd39}))
    |-> (vif.length <= 8'd251); endproperty
  assert_p_bt5_l4_max_len: assert property(p_bt5_l4_max_len) l4_pass[2]++; else begin `uvm_warning("BT5_L4", "Data PDU length > 251"); l4_fail[2]++; end
  cover_p_bt5_l4_max_len: cover property(p_bt5_l4_max_len);
  // L4-4: every RX packet is eventually answered/looped on TX
  property p_bt5_l4_rx_tx_loop; @(posedge vif.clk) disable iff (!vif.rst_n)
    $rose(vif.rx_valid) |-> s_eventually vif.tx_valid; endproperty
  assert_p_bt5_l4_rx_tx_loop: assert property(p_bt5_l4_rx_tx_loop) l4_pass[3]++; else begin `uvm_warning("BT5_L4", "RX packet never answered on TX"); l4_fail[3]++; end
  cover_p_bt5_l4_rx_tx_loop: cover property(p_bt5_l4_rx_tx_loop);
  // L4-5: channel index stays within the LE 40-channel plan
  property p_bt5_l4_channel; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.rx_valid |-> (vif.channel <= 7'd39); endproperty
  assert_p_bt5_l4_channel: assert property(p_bt5_l4_channel) l4_pass[4]++; else begin `uvm_warning("BT5_L4", "Channel index > 39"); l4_fail[4]++; end
  cover_p_bt5_l4_channel: cover property(p_bt5_l4_channel);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("BLUETOOTH5_RPT", $sformatf("=== Bluetooth5 Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("BLUETOOTH5_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("BLUETOOTH5_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("BLUETOOTH5_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("BLUETOOTH5_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("BLUETOOTH5_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule

// ============================================================================
// bluetooth5_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the bluetooth5_compliance_checker_sva module above)
// ============================================================================
class bluetooth5_compliance_checker extends uvm_component;
  `uvm_component_utils(bluetooth5_compliance_checker)
  function new(string name = "bluetooth5_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

`endif
