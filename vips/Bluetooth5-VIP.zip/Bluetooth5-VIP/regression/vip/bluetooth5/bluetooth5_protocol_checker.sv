// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// bluetooth5 Protocol Compliance Checker
`ifndef BLUETOOTH5_PROTOCOL_CHECKER_SV
`define BLUETOOTH5_PROTOCOL_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
module bluetooth5_protocol_compliance_checker (bluetooth5_if vif);

property p_bt_phy; @(posedge vif.clk) disable iff (!vif.rst_n) vif.phy_mode inside {2'b00,2'b01,2'b10,2'b11}; endproperty
assert_p_bt_phy: assert property(p_bt_phy) else `uvm_warning("BLUETOOTH5", "PHY mode valid failed");
cover_p_bt_phy: cover property(p_bt_phy);
property p_bt_channel; @(posedge vif.clk) disable iff (!vif.rst_n) vif.channel <= 7'd39; endproperty
assert_p_bt_channel: assert property(p_bt_channel) else `uvm_warning("BLUETOOTH5", "Channel 0-39 failed");
cover_p_bt_channel: cover property(p_bt_channel);
property p_bt_adv_type; @(posedge vif.clk) disable iff (!vif.rst_n) vif.adv_type <= 3'd7; endproperty
assert_p_bt_adv_type: assert property(p_bt_adv_type) else `uvm_warning("BLUETOOTH5", "Adv type valid failed");
cover_p_bt_adv_type: cover property(p_bt_adv_type);
property p_bt_llid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.llid inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
assert_p_bt_llid: assert property(p_bt_llid) else `uvm_warning("BLUETOOTH5", "LLID valid failed");
cover_p_bt_llid: cover property(p_bt_llid);
property p_bt_length; @(posedge vif.clk) disable iff (!vif.rst_n) vif.length <= 8'd255; endproperty
assert_p_bt_length: assert property(p_bt_length) else `uvm_warning("BLUETOOTH5", "Length valid failed");
cover_p_bt_length: cover property(p_bt_length);
endmodule
`endif
