// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// bluetooth5 Data Integrity Checker
`ifndef BLUETOOTH5_DATA_INTEGRITY_CHECKER_SV
`define BLUETOOTH5_DATA_INTEGRITY_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
module bluetooth5_data_integrity_checker (bluetooth5_if vif);

property p_bt_crc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.rx_valid == 1 |-> vif.rx_crc_ok == 1; endproperty
assert_p_bt_crc: assert property(p_bt_crc) else `uvm_warning("BLUETOOTH5", "RX CRC OK failed");
cover_p_bt_crc: cover property(p_bt_crc);
property p_bt_access_addr; @(posedge vif.clk) disable iff (!vif.rst_n) vif.access_addr != 32'h00000000; endproperty
assert_p_bt_access_addr: assert property(p_bt_access_addr) else `uvm_warning("BLUETOOTH5", "Access addr non-zero failed");
cover_p_bt_access_addr: cover property(p_bt_access_addr);
property p_bt_cte; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cte_time <= 6'd20; endproperty
assert_p_bt_cte: assert property(p_bt_cte) else `uvm_warning("BLUETOOTH5", "CTE time valid failed");
cover_p_bt_cte: cover property(p_bt_cte);
endmodule
`endif
