// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// bluetooth5 Timing Performance Checker
`ifndef BLUETOOTH5_TIMING_CHECKER_SV
`define BLUETOOTH5_TIMING_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
module bluetooth5_timing_performance_checker (bluetooth5_if vif);

property p_bt_tx_rx; @(posedge vif.clk) disable iff (!vif.rst_n) !(vif.tx_en == 1 && vif.rx_en == 1); endproperty
assert_p_bt_tx_rx: assert property(p_bt_tx_rx) else `uvm_warning("BLUETOOTH5", "TX/RX mutual exclusive failed");
cover_p_bt_tx_rx: cover property(p_bt_tx_rx);
property p_bt_enc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.encrypted == 1 |-> vif.length > 0; endproperty
assert_p_bt_enc: assert property(p_bt_enc) else `uvm_warning("BLUETOOTH5", "Encryption with data failed");
cover_p_bt_enc: cover property(p_bt_enc);
endmodule
`endif
