// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// bluetooth5 Error Handling Checker
`ifndef BLUETOOTH5_ERROR_CHECKER_SV
`define BLUETOOTH5_ERROR_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

// NOTE: converted from class to module (concurrent assertions are illegal
// inside classes per IEEE 1800); checker name preserved.
module bluetooth5_error_handling_checker (bluetooth5_if vif);

property p_bt_nesn_sn; @(posedge vif.clk) disable iff (!vif.rst_n) vif.nesn != vif.sn |-> vif.rx_valid == 1 || vif.tx_valid == 1; endproperty
assert_p_bt_nesn_sn: assert property(p_bt_nesn_sn) else `uvm_warning("BLUETOOTH5", "NESN/SN toggle failed");
cover_p_bt_nesn_sn: cover property(p_bt_nesn_sn);
property p_bt_md; @(posedge vif.clk) disable iff (!vif.rst_n) vif.md == 1 |-> vif.length > 0; endproperty
assert_p_bt_md: assert property(p_bt_md) else `uvm_warning("BLUETOOTH5", "MD with valid data failed");
cover_p_bt_md: cover property(p_bt_md);
property p_bt_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tx_valid == 1 |-> !$isunknown(vif.tx_data); endproperty
assert_p_bt_no_x: assert property(p_bt_no_x) else `uvm_warning("BLUETOOTH5", "No X when valid failed");
cover_p_bt_no_x: cover property(p_bt_no_x);
endmodule
`endif
