// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_bluetooth5_tb.sv -- self-checking functional test for the Bluetooth LE
// peer model (bluetooth5_dut in top/top_tb.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py Bluetooth5-VIP
//
// Model contract (from top/top_tb.sv): the peer listens (rx_en) and collects
// air bytes while rx_valid is high: preamble, access address (4 bytes, LSB
// first), PDU header byte 0, length, payload. When rx_valid drops it decodes
// a packet of 7 or more bytes: access_addr, length, and on advertising
// channels 37-39 adv_type = header[2:0], on data channels LLID = header[1:0],
// NESN = header[2], SN = header[3], MD = header[4]. After a 5-clock
// turnaround (rx_en low) it transmits the received bytes back with tx_en and
// tx_valid, then listens again.
// Known defect (XFAIL): tx_valid rises one clock before the first echoed
// byte, so the echo starts with a stale byte (the last byte of the previous
// transmission, 0x00 after reset).

module func_bluetooth5_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic       clk = 1'b0, rst_n = 1'b0, rx_valid = 1'b0;
  logic [7:0] rx_data = '0;
  logic [6:0] channel = 7'd37;
  wire  [1:0] phy_mode;
  wire        tx_en, rx_en, tx_valid, nesn, sn, md, encrypted;
  wire  [7:0] tx_data, length;
  wire  [2:0] adv_type, llid;
  wire  [47:0] adv_addr, init_addr;
  wire  [31:0] access_addr;
  wire  [3:0] cte_type;
  wire  [5:0] cte_time;

  always #5 clk = ~clk;

  bluetooth5_dut u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_phy_mode(phy_mode), .vif_tx_en(tx_en),
    .vif_rx_en(rx_en), .vif_tx_data(tx_data), .vif_tx_valid(tx_valid), .vif_rx_data(rx_data),
    .vif_rx_valid(rx_valid), .vif_channel(channel), .vif_adv_type(adv_type),
    .vif_adv_addr(adv_addr), .vif_init_addr(init_addr), .vif_access_addr(access_addr),
    .vif_llid(llid), .vif_nesn(nesn), .vif_sn(sn), .vif_md(md), .vif_length(length),
    .vif_encrypted(encrypted), .vif_cte_type(cte_type), .vif_cte_time(cte_time)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // echoed bytes, and protocol monitors
  logic [7:0] echo[$];
  bit         both_en;
  always @(posedge clk) if (rst_n) begin
    if (tx_valid === 1'b1) echo.push_back(tx_data);
    if (tx_en && rx_en) both_en = 1;
  end

  logic [7:0] pkt[$];
  task automatic build(input [31:0] aa, input [7:0] hdr, input int n_payload, input [7:0] seed);
    pkt.delete();
    pkt.push_back(aa[0] ? 8'h55 : 8'hAA);                 // preamble alternates from AA LSB
    for (int i = 0; i < 4; i++) pkt.push_back(aa[i*8 +: 8]);
    pkt.push_back(hdr);
    pkt.push_back(n_payload);
    for (int i = 0; i < n_payload; i++) pkt.push_back(seed + i * 3);
  endtask

  task automatic send();
    foreach (pkt[i]) begin
      @(negedge clk); rx_valid = 1; rx_data = pkt[i];
    end
    @(negedge clk); rx_valid = 0;
  endtask

  // wait for the echo to finish, return the number of turnaround clocks
  int turn;
  task automatic wait_echo();
    turn = 0;
    while (!tx_valid && turn < 50) begin @(negedge clk); turn++; end
    while (tx_valid) @(negedge clk);
    @(negedge clk);
  endtask

  // echo minus the stale leading byte matches the packet
  function automatic bit echo_ok();
    if (echo.size() != pkt.size() + 1) return 0;
    foreach (pkt[i]) if (echo[i + 1] !== pkt[i]) return 0;
    return 1;
  endfunction

  logic [7:0] last;

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1;
    @(negedge clk);
    chk(access_addr == 32'h8E89_BED6, "advertising access address 0x8E89BED6 after reset");
    chk(phy_mode == 2'd1 && rx_en && !tx_en && !tx_valid, "LE 1M PHY, listening");

    // ADV_IND on channel 37
    channel = 7'd37;
    build(32'h8E89_BED6, 8'h40, 6, 8'h10);        // PDU type 0 (ADV_IND), TxAdd
    echo.delete();
    send();
    @(negedge clk);
    chk(!rx_en, "receiver off during the turnaround");
    wait_echo();
    chk(turn == 5, $sformatf("transmit starts after a 5-clock turnaround (got %0d)", turn));
    chk(access_addr == 32'h8E89_BED6 && length == 6, "access address and length decoded");
    chk(adv_type == 3'd0, "advertising PDU type decoded on channel 37");
    chk(echo.size() >= 1 && echo_ok(), $sformatf("packet echoed after the leading byte (%0d bytes)", echo.size()));
    chk_xfail(echo.size() == pkt.size() && echo[0] == pkt[0], "echo starts with the first received byte");
    chk(rx_en && !tx_en, "listening again after the echo");
    last = pkt[pkt.size() - 1];

    // SCAN_REQ (type 3) on channel 39
    channel = 7'd39;
    build(32'h8E89_BED6, 8'h03, 12, 8'h21);
    echo.delete();
    send(); wait_echo();
    chk(adv_type == 3'd3 && length == 12, "SCAN_REQ type and length decoded on channel 39");
    chk(echo_ok() && echo[0] == last, "stale leading byte is the previous packet's last byte");
    chk(llid == 0, "data-channel fields untouched on advertising channels");

    // data channel PDU
    channel = 7'd12;
    build(32'h5065_A1B2, 8'b0001_0110, 4, 8'h80);  // LLID=2, NESN=1, SN=0, MD=1
    echo.delete();
    send(); wait_echo();
    chk(access_addr == 32'h5065_A1B2, "connection access address decoded");
    chk(llid == 2 && nesn == 1 && sn == 0 && md == 1, "LLID/NESN/SN/MD decoded on a data channel");
    chk(adv_type == 3'd3, "advertising type untouched on data channels");
    chk(echo_ok(), "data PDU echoed");
    build(32'h5065_A1B2, 8'b0000_1001, 0, 8'h00);  // LLID=1 empty PDU, SN=1
    echo.delete();
    send(); wait_echo();
    chk(llid == 1 && nesn == 0 && sn == 1 && md == 0 && length == 0, "empty PDU: SN=1, length 0");
    chk(echo_ok(), "empty PDU echoed");

    // maximum-length payload
    build(32'h5065_A1B2, 8'h02, 251, 8'h01);
    echo.delete();
    send(); wait_echo();
    chk(length == 251 && echo_ok(), "251-byte payload received and echoed");

    // runt packet: echoed, header not decoded
    pkt.delete();
    for (int i = 0; i < 5; i++) pkt.push_back(8'hC0 + i);
    echo.delete();
    send(); wait_echo();
    chk(access_addr == 32'h5065_A1B2 && length == 251, "packet shorter than 7 bytes leaves the decoded header");
    chk(echo_ok(), "runt packet still echoed");
    // 6 bytes: still one short of the length byte
    pkt.delete();
    for (int i = 0; i < 6; i++) pkt.push_back(8'hD0 + i);
    echo.delete();
    send(); wait_echo();
    chk(access_addr == 32'h5065_A1B2 && length == 251 && echo_ok(), "6-byte packet: header not decoded, echoed");
    // a single byte
    pkt.delete();
    pkt.push_back(8'h3C);
    echo.delete();
    send(); wait_echo();
    chk(echo_ok(), "single-byte packet echoed");

    chk(!both_en, "never transmitting and receiving at once");

    // reset in the middle of a reception
    build(32'h1111_2222, 8'h01, 3, 8'h00);
    fork send(); join_none
    repeat (4) @(negedge clk);
    rst_n = 0;
    @(negedge clk);
    chk(u_dut.pkt_q.size() == 0 && !tx_valid && access_addr == 32'h8E89_BED6, "reset clears the buffer and header");
    chk(!tx_en && !rx_en && llid == 0 && nesn == 0 && sn == 0 && md == 0 && length == 0 && adv_type == 0,
        "reset clears the enables and the decoded header fields");
    rst_n = 1;
    wait (!rx_valid);
    repeat (3) @(negedge clk);

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
