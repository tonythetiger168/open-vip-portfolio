# Bluetooth 5 — UVM VIP (LE 1M/2M/Coded PHY, Advertising + Data PDUs, AoA/AoD CTE)

Open-source UVM verification IP for **Bluetooth 5 Low Energy**: advertising
channel PDUs (ADV_IND/ADV_DIRECT_IND/ADV_NONCONN_IND/SCAN_REQ/SCAN_RSP...),
data channel PDUs (LLID start/cont/control, NESN/SN/MD), PHY modes
(1M/2M/500k/125k Coded) and CTE sideband.

## Contents

| Path | Description |
|------|-------------|
| `bluetooth5/bluetooth5_if.sv` | Interface: byte-stream rx (ingress) / tx (egress), LL sideband, clocking blocks, L1 assertions, coverage |
| `bluetooth5/bluetooth5_transaction.svh` | LE packet item: PDU type/adv type/LLID/NESN/SN/MD/length/payload/AA/CRC/error injection |
| `bluetooth5/bluetooth5_driver.svh` | Packet composer: preamble/AA/header/payload/**CRC-24** byte stream, error injection, expected-port |
| `bluetooth5/bluetooth5_monitor.svh` | Egress decoder: burst reassembly, header decode, **CRC-24 re-check**, classification |
| `bluetooth5/bluetooth5_coverage.svh` | 3 covergroups (adv config / data pattern / LL FSM) with crosses |
| `regression/sva/bluetooth5_compliance_checker.sv` | Tiered SVA (L1=4, L2=6, L3=0, L4=5) |
| `env/env_pkg.sv` | Environment + end-to-end scoreboard |
| `tests/test_pkg.sv` | bt5_base_test + adv/data/phy/error/corner/regression tests |
| `top/top_tb.sv` | Testbench top + functional DUT (LE loopback peer) |
| `common/common_pkg.sv` | Shared base classes |
| `regression/` | Makefile + coverage regression |

## Architecture

```
sequence -> sequencer -> driver --drv_ap--> scoreboard (expected)
                              |  preamble/AA/header/payload/CRC24 (rx_*)
                              v
                    bluetooth5_dut: LE loopback peer
                    (capture, T_IFS turnaround, re-transmit, sideband)
                              v
                     tx_* byte stream -> monitor --ap--> scoreboard (observed)
                                          +-> coverage + protocol checker
                                          +-> SVA compliance (L1-L4)
```

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `bt5_base_sequence` | base random packets |
| `bt5_random_sequence` | constrained-random mix |
| `bt5_adv_sequence` | advertising PDUs (ch 37-39, AA 0x8E89BED6) |
| `bt5_data_sequence` | data channel PDUs |
| `bt5_phy_update_sequence` | 2M PHY packets |
| `bt5_error_inject_sequence` | corrupted CRC-24 (must be detected) |
| `bt5_back_to_back_sequence` | minimum-IFS stress |
| `bt5_corner_sequence` | zero-length + 251-byte max PDUs |
| `bt5_reset_sequence` | packet right after reset release |
| `bt5_regression_sequence` | weighted mix of all of the above |

## SVA compliance checker

- **L1 (4)**: AA not all-0/1, PHY legal, length<=255, channel<=39
- **L2 (6)**: CRC/addr/adv/LLID/CTE consistency, encrypted flag legality
- **L4 (5)**: adv-channel AA = 0x8E89BED6, PHY coding legal, data PDU
  length <= 251, RX packet eventually answered on TX, channel plan <= 39

## Functional coverage

- `bt5_adv_cg`: adv type / PHY / channel / LLID / length + adv×PHY,
  channel×PHY, LLID×length crosses
- `bt5_data_cg`: length corners (0/1/251) × LLID, × encryption crosses
- `bt5_fsm_cg`: NESN/SN/MD handshake bits, LLID transitions + crosses
- interface `bt5_if_cg`: rx/tx activity × channel, × PHY crosses

## Quick start

```bash
cd regression
make all SIMULATOR=vcs TESTNAME=full_regression_test
make all SIMULATOR=questa TESTNAME=bt5_regression_test
./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.4.0)

- **Driver**: real on-air packet image (preamble/AA/header/payload/
  **computed CRC-24**) byte stream with CRC error injection; adv channels
  force AA 0x8E89BED6
- **Monitor**: TX burst reassembly, preamble/AA/header decode, **CRC-24
  re-computation**, error classification, analysis-port publish
- **End-to-end scoreboard**: expected-vs-observed pairing; injected CRC
  errors must be *detected* to match (`n_matches`/`n_mismatches`,
  `UVM_ERROR` on mismatch); env reworked to a BT5-only closed loop
- **Functional DUT**: LE link-layer loopback peer (capture, T_IFS
  turnaround, re-transmit with header sideband) in new `top/top_tb.sv`
- **Sequences**: 5 new directed sequences (error inject, back-to-back,
  0/251 corner, reset, regression mix)
- **Coverage**: two new covergroups (data-pattern × LLID/encryption,
  LL-FSM NESN/SN/MD + transitions) with crosses
- **SVA L4**: five Bluetooth 5 LE-specific rules on top of the tiered
  L1/L2 set (and `virtual bt_if` fixed to `bluetooth5_if`)
