// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_env.sv -- SPDIF environment: reference-model scoreboard, checker, coverage

package spdif_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import spdif_defs_pkg::*;
  import spdif_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class spdif_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(spdif_scoreboard)
    uvm_analysis_imp_exp #(spdif_transaction, spdif_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(spdif_transaction, spdif_scoreboard) obs_ap;

    spdif_config cfg;
    spdif_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    int fidx = 0;
    bit blk = 0;
    bit [31:0] csb = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(spdif_config)::get(this, "", "cfg", cfg))
        cfg = spdif_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(spdif_transaction t);
      // receiver run on the run lengths of the burst (the run after the last one
      // is the idle line)
      int w = cfg.ui, st = 0, np = 0, nb = 0;
      int pr [4];
      bit half = 0;
      bit [1:0] pre = 3;
      bit [27:0] sb;
      t.rep.delete(); t.csq.delete();
      foreach (t.seg[i]) begin
        int c = spdif_cls(t.seg[i], w);
        case (st)
          0: if (c == 3) begin st = 1; np = 1; pr[0] = 3; end
          1: begin
               pr[np++] = c;
               if (np == 4) begin
                 if (pr[1] == 1 && pr[2] == 1 && pr[3] == 3) pre = 0;
                 else if (pr[1] == 3 && pr[2] == 1 && pr[3] == 1) pre = 1;
                 else if (pr[1] == 2 && pr[2] == 1 && pr[3] == 2) pre = 2;
                 else pre = 3;
                 if (pre == 3) begin t.rep.push_back({2'd2, 2'd3, 28'h0}); st = 0; end
                 else begin
                   if (pre == 0) begin fidx = 0; blk = 1; end
                   else if (pre == 1 && fidx < 255) fidx++;
                   st = 2; nb = 0; half = 0;
                 end
               end
             end
          2: begin
               bit err = 0, done = 0, v = 0;
               if (c == 1) begin if (half) begin done = 1; v = 1; end else half = 1; end
               else if (c == 2 && !half) begin done = 1; v = 0; end
               else err = 1;
               if (err) begin t.rep.push_back({2'd2, pre, 28'h0}); st = 0; end
               else if (done) begin
                 sb[nb] = v; half = 0;
                 if (nb == 27) begin
                   t.rep.push_back({(^sb) ? 2'd1 : 2'd0, pre, sb[24], sb[25], sb[26], sb[27], sb[23:0]});
                   if (pre != 2 && fidx < 32) begin
                     csb[fidx] = sb[26];
                     if (fidx == 31 && blk) t.csq.push_back(csb);
                   end
                   st = 0;
                 end else nb++;
               end
             end
        endcase
      end
      // no transition for 7W/2 clocks in the middle of a subframe
      if (st == 2) t.rep.push_back({2'd2, pre, 28'h0});
    endfunction

    function void write_exp(spdif_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(spdif_transaction t);
      spdif_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        spdif_transaction e = exp_q.pop_front();
        spdif_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("spdif scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class spdif_env extends uvm_env;
    `uvm_component_utils(spdif_env)
    spdif_agent      agt;
    spdif_scoreboard sb;
    spdif_checker    chk;
    spdif_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = spdif_agent     ::type_id::create("agt", this);
      sb  = spdif_scoreboard::type_id::create("sb",  this);
      chk = spdif_checker   ::type_id::create("chk", this);
      cov = spdif_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
