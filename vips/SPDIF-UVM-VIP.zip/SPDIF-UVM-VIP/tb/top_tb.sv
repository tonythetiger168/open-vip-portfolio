// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- SPDIF testbench top with a functional SPDIF DUT model

`ifndef SPDIF_UVM_VIP_TB_SV
`define SPDIF_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import spdif_defs_pkg::*;
import spdif_pkg::*;
import spdif_env_pkg::*;
import spdif_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  spdif_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  spdif_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .spdif_in(vif.spdif_in),
    .rep_valid(vif.rep_valid),
    .rep_pre(vif.rep_pre),
    .rep_data(vif.rep_data),
    .rep_vucp(vif.rep_vucp),
    .rep_status(vif.rep_status),
    .rep_cs_valid(vif.rep_cs_valid),
    .rep_cs(vif.rep_cs)
  );

  // Concurrent protocol checks
  spdif_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .spdif_in(vif.spdif_in),
    .rep_valid(vif.rep_valid),
    .rep_pre(vif.rep_pre),
    .rep_data(vif.rep_data),
    .rep_vucp(vif.rep_vucp),
    .rep_status(vif.rep_status),
    .rep_cs_valid(vif.rep_cs_valid),
    .rep_cs(vif.rep_cs)
  );

  initial begin
    uvm_config_db#(virtual spdif_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module spdif_model #(parameter int W = 8) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        spdif_in,
  output logic        rep_valid,
  output logic [1:0]  rep_pre,
  output logic [23:0] rep_data,
  output logic [3:0]  rep_vucp,
  output logic [1:0]  rep_status,
  output logic        rep_cs_valid,
  output logic [31:0] rep_cs
);
  function automatic logic [1:0] cls(input logic [15:0] n);
    if (2 * n < W) cls = 2'd0;
    else if (2 * n < 3 * W) cls = 2'd1;
    else if (2 * n < 5 * W) cls = 2'd2;
    else if (2 * n < 7 * W) cls = 2'd3;
    else cls = 2'd0;
  endfunction

  logic [1:0]  st, pre, np;
  logic [1:0]  pr1, pr2;
  logic        lv, half, blk;
  logic [15:0] cnt;
  logic [4:0]  nb;
  logic [27:0] sb;
  logic [7:0]  fidx;
  logic [31:0] csb;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= 2'd0; pre <= 2'd3; np <= '0; pr1 <= '0; pr2 <= '0; lv <= 1'b0; half <= 1'b0; blk <= 1'b0;
      cnt <= 16'hFFFF; nb <= '0; sb <= '0; fidx <= '0; csb <= '0;
      rep_valid <= 1'b0; rep_pre <= '0; rep_data <= '0; rep_vucp <= '0; rep_status <= '0;
      rep_cs_valid <= 1'b0; rep_cs <= '0;
    end else begin
      rep_valid <= 1'b0; rep_cs_valid <= 1'b0;
      if (spdif_in == lv) begin
        if (cnt != 16'hFFFF) cnt <= cnt + 16'd1;
        if (2 * (cnt + 16'd1) >= 7 * W && st != 2'd0) begin
          if (st == 2'd2) begin
            rep_valid <= 1'b1; rep_status <= 2'd2; rep_pre <= pre; rep_data <= '0; rep_vucp <= '0;
          end
          st <= 2'd0;
        end
      end else begin : run_end
        logic [1:0]  c, p;
        logic [27:0] s;
        logic [31:0] cs;
        lv <= spdif_in;
        cnt <= 16'd1;
        c = cls(cnt);
        case (st)
          2'd0: if (c == 2'd3) begin st <= 2'd1; np <= 2'd1; end
          2'd1: begin
                  if (np == 2'd1) begin pr1 <= c; np <= 2'd2; end
                  else if (np == 2'd2) begin pr2 <= c; np <= 2'd3; end
                  else begin
                    if (pr1 == 2'd1 && pr2 == 2'd1 && c == 2'd3) p = 2'd0;
                    else if (pr1 == 2'd3 && pr2 == 2'd1 && c == 2'd1) p = 2'd1;
                    else if (pr1 == 2'd2 && pr2 == 2'd1 && c == 2'd2) p = 2'd2;
                    else p = 2'd3;
                    pre <= p;
                    if (p == 2'd3) begin
                      rep_valid <= 1'b1; rep_status <= 2'd2; rep_pre <= 2'd3; rep_data <= '0; rep_vucp <= '0;
                      st <= 2'd0;
                    end else begin
                      if (p == 2'd0) begin fidx <= '0; blk <= 1'b1; end
                      else if (p == 2'd1 && fidx != 8'hFF) fidx <= fidx + 8'd1;
                      st <= 2'd2; nb <= '0; half <= 1'b0;
                    end
                  end
                end
          2'd2: begin
                  logic err, done, v;
                  err = 1'b0; done = 1'b0; v = 1'b0;
                  if (c == 2'd1) begin if (half) begin done = 1'b1; v = 1'b1; end else half <= 1'b1; end
                  else if (c == 2'd2 && !half) done = 1'b1;
                  else err = 1'b1;
                  if (err) begin
                    rep_valid <= 1'b1; rep_status <= 2'd2; rep_pre <= pre; rep_data <= '0; rep_vucp <= '0;
                    st <= 2'd0;
                  end else if (done) begin
                    half <= 1'b0;
                    s = sb; s[nb] = v; sb <= s;
                    if (nb == 5'd27) begin
                      rep_valid <= 1'b1; rep_status <= (^s) ? 2'd1 : 2'd0; rep_pre <= pre;
                      rep_data <= s[23:0]; rep_vucp <= {s[24], s[25], s[26], s[27]};
                      if (pre != 2'd2 && fidx < 8'd32) begin
                        cs = csb; cs[fidx[4:0]] = s[26]; csb <= cs;
                        if (fidx == 8'd31 && blk) begin rep_cs_valid <= 1'b1; rep_cs <= cs; end
                      end
                      st <= 2'd0;
                    end else nb <= nb + 5'd1;
                  end
                end
          default: st <= 2'd0;
        endcase
      end
    end
  end
endmodule
`endif
