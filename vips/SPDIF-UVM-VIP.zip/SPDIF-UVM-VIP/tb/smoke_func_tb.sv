// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SPDIF DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened spdif_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;
  localparam integer W = 8;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic spdif_in = 1'b0;
  wire rep_valid, rep_cs_valid;
  wire [1:0] rep_pre, rep_status;
  wire [23:0] rep_data;
  wire [3:0] rep_vucp;
  wire [31:0] rep_cs;

  always #5 clk = ~clk;

  spdif_model u_dut (.clk(clk), .rst_n(rst_n), .spdif_in(spdif_in), .rep_valid(rep_valid), .rep_pre(rep_pre),
                     .rep_data(rep_data), .rep_vucp(rep_vucp), .rep_status(rep_status),
                     .rep_cs_valid(rep_cs_valid), .rep_cs(rep_cs));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  integer nrep = 0, ncs = 0;
  logic [1:0] r_pre [0:255], r_st [0:255];
  logic [23:0] r_d [0:255];
  logic [3:0] r_v [0:255];
  logic [31:0] r_cs;
  always @(posedge clk) if (rep_valid) begin
    r_pre[nrep[7:0]] = rep_pre; r_st[nrep[7:0]] = rep_status; r_d[nrep[7:0]] = rep_data; r_v[nrep[7:0]] = rep_vucp;
    nrep = nrep + 1;
    if (rep_cs_valid) begin ncs = ncs + 1; r_cs = rep_cs; end
  end

  // a run of n UI (plus extra clocks): a transition, then n * W + extra clocks
  task automatic run(input integer n, input integer extra = 0);
    spdif_in = ~spdif_in;
    repeat (n * W + extra) @(negedge clk);
  endtask
  task automatic pre(input integer p);   // 0 B, 1 M, 2 W, 3 illegal
    case (p)
      0: begin run(3); run(1); run(1); run(3); end
      1: begin run(3); run(3); run(1); run(1); end
      2: begin run(3); run(2); run(1); run(2); end
      default: begin run(3); run(1); run(3); run(1); end
    endcase
  endtask
  // subframe: preamble p, 24-bit data, V U C; parity correct unless bad_p;
  // a cell boundary transition dropped before cell drop (-1: none)
  // odd = cell replaced by one run of oddn clocks; p0 = clocks of the first preamble run (0: 3 UI)
  task automatic sub(input integer p, input logic [23:0] d, input logic v, input logic u, input logic c,
                     input logic bad_p = 0, input integer drop = -1, input integer odd = -1, input integer oddn = 0,
                     input integer p0 = 0);
    logic [27:0] b;
    b = {1'b0, c, u, v, d};
    b[27] = ^b[26:0] ^ bad_p;
    if (p0 != 0) begin
      run(0, p0);
      case (p)
        0: begin run(1); run(1); run(3); end
        1: begin run(3); run(1); run(1); end
        default: begin run(2); run(1); run(2); end
      endcase
    end else pre(p);
    for (int i = 0; i < 28; i++) begin
      if (i == odd) begin run(0, (oddn > 0) ? oddn : -oddn); if (oddn < 0) run(0, -oddn); end
      else if (i == drop) begin
        // no transition at the start of this cell: the previous level goes on
        if (b[i]) begin repeat (W) @(negedge clk); run(1); end else repeat (2 * W) @(negedge clk);
      end else if (b[i]) begin run(1); run(1); end else run(2);
    end
  endtask
  task automatic prer(input integer a, input integer b, input integer c, input integer d);
    run(a); run(b); run(c); run(d);
    for (int i = 0; i < 28; i++) run(2);
  endtask
  task automatic stop();
    spdif_in = ~spdif_in;
    repeat (16 * W) @(negedge clk);
  endtask

  integer r0;
  logic [31:0] csw;
  initial begin
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0, "no report in reset");
    rst_n = 1;
    repeat (40) @(negedge clk);
    chk(nrep == 0, "no report on an idle line");
    r0 = nrep;
    sub(0, 24'h123456, 0, 0, 1); sub(2, 24'hABCDEF, 0, 0, 1); stop();
    chk(nrep == r0 + 2 && r_pre[r0] == 0 && r_d[r0] == 24'h123456 && r_v[r0] == 4'b0010 && r_st[r0] == 0,
        "B subframe: data, C = 1, parity ok");
    chk(r_pre[r0 + 1] == 2 && r_d[r0 + 1] == 24'hABCDEF && r_st[r0 + 1] == 0, "W subframe");
    r0 = nrep; sub(1, 24'h000000, 1, 0, 0); sub(2, 24'hFFFFFF, 0, 1, 0); stop();
    chk(nrep == r0 + 2 && r_pre[r0] == 1 && r_d[r0] == 0 && r_v[r0] == 4'b1001, "M subframe, all zeros, V = 1");
    chk(r_d[r0 + 1] == 24'hFFFFFF && r_v[r0 + 1] == 4'b0101, "all ones, U = 1 (parity 1)");
    r0 = nrep; sub(1, 24'h00F00F, 0, 0, 0, 1); stop(); chk(nrep == r0 + 1 && r_st[r0] == 1 && r_d[r0] == 24'h00F00F, "parity error: data kept");
    r0 = nrep; sub(1, 24'h5A5A5A, 0, 0, 0, 0, 9); sub(2, 24'h111111, 0, 0, 0); stop();
    chk(nrep == r0 + 2 && r_st[r0] == 2 && r_pre[r0] == 1 && r_d[r0] == 0, "missing transition: violation");
    chk(r_st[r0 + 1] == 0 && r_d[r0 + 1] == 24'h111111, "next subframe received after re-lock");
    r0 = nrep; sub(3, 24'h222222, 0, 0, 0); sub(2, 24'h333333, 0, 0, 0); stop();
    chk(nrep == r0 + 2 && r_st[r0] == 2 && r_pre[r0] == 3 && r_d[r0 + 1] == 24'h333333, "illegal preamble, then W");
    // a subframe cut in the middle: no transition for 7W/2
    r0 = nrep; pre(1); for (int i = 0; i < 10; i++) run(2); stop();
    chk(nrep == r0 + 1 && r_st[r0] == 2, "line stops inside a subframe");
    // windows: 1 UI = W/2 .. 3W/2 - 1, 2 UI up to 5W/2 - 1, 3 UI up to 7W/2 - 1
    r0 = nrep; run(3, 3); run(3, -3); run(1, 3); run(1, -4);
    for (int i = 0; i < 28; i++) if (i % 2) begin run(1, -4); run(1, 3); end else run(2, (i % 4) ? 3 : -4);
    stop();
    chk(nrep == r0 + 1 && r_pre[r0] == 1 && r_st[r0] != 2, "edge jitter at the window limits");
    // channel status: a block of 32 frames from B
    csw = 32'h0200_0004;
    r0 = nrep; ncs = 0;
    for (int f = 0; f < 32; f++) begin sub(f ? 1 : 0, f, 0, 0, csw[f]); sub(2, ~f, 0, 0, ~csw[f]); end
    stop();
    chk(nrep == r0 + 64 && ncs == 1 && r_cs == csw, "channel status word after 32 frames");
    r0 = nrep; ncs = 0;
    for (int f = 0; f < 40; f++) sub(1, f, 0, 0, 1); stop();
    chk(ncs == 0, "no second word without a new B");
    // run windows: 1 UI from W/2 = 4 clocks, 3 UI from 5W/2 = 20, out of range from 7W/2 = 28
    r0 = nrep; sub(1, 24'h0, 0, 0, 0, 0, -1, 5, 3); stop(); chk(nrep == r0 + 1 && r_st[r0] == 2, "a run of 3 clocks is a violation");
    r0 = nrep; sub(1, 24'h0, 0, 0, 0, 0, -1, 5, -3); stop(); chk(nrep == r0 + 1 && r_st[r0] == 2, "two runs of 3 clocks are not a 1 cell");
    r0 = nrep; sub(1, 24'h0, 0, 0, 0, 0, -1, 5, -4); stop(); chk(nrep == r0 + 1 && r_st[r0] == 1, "two runs of 4 clocks are a 1 cell (parity now odd)");
    r0 = nrep; sub(1, 24'h0, 0, 0, 0, 0, -1, 5, 20); stop(); chk(nrep == r0 + 1 && r_st[r0] == 2, "a run of 20 clocks (2.5 UI) in a cell is a violation");
    r0 = nrep; sub(1, 24'h0, 0, 0, 0, 0, -1, 5, 19); stop(); chk(nrep == r0 + 1 && r_st[r0] == 0, "a run of 19 clocks is a 0 cell");
    r0 = nrep; sub(1, 24'h77, 0, 0, 0, 0, -1, -1, 0, 28); sub(2, 24'h88, 0, 0, 0); stop();
    chk(nrep == r0 + 2 && r_st[r0] == 2 && r_pre[r0 + 1] == 2 && r_d[r0 + 1] == 24'h88,
        "a first preamble run of 28 clocks is not one: the hunt locks on the next 3 UI run and fails");
    r0 = nrep; sub(1, 24'h77, 0, 0, 0, 0, -1, -1, 0, 27); stop(); chk(nrep == r0 + 1 && r_d[r0] == 24'h77, "a first preamble run of 27 clocks starts a preamble");
    r0 = nrep; prer(3, 3, 1, 3); stop(); chk(nrep == r0 + 1 && r_st[r0] == 2 && r_pre[r0] == 3, "preamble 3,3,1,3 is illegal");
    r0 = nrep; prer(3, 3, 1, 2); stop(); chk(nrep == r0 + 1 && r_st[r0] == 2 && r_pre[r0] == 3, "preamble 3,3,1,2 is illegal");
    r0 = nrep; prer(3, 1, 3, 3); stop(); chk(nrep == r0 + 1 && r_st[r0] == 2 && r_pre[r0] == 3, "preamble 3,1,3,3 is illegal");
    r0 = nrep; prer(3, 2, 2, 2); stop(); chk(nrep == r0 + 1 && r_st[r0] == 2 && r_pre[r0] == 3, "preamble 3,2,2,2 is illegal");
    // channel A only: the frame counter follows M, not W
    r0 = nrep; ncs = 0;
    for (int f = 0; f < 32; f++) sub(f ? 1 : 0, f, 0, 0, ~csw[f]);
    stop();
    chk(ncs == 1 && r_cs == ~csw, "channel status from 32 channel A subframes without W");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
