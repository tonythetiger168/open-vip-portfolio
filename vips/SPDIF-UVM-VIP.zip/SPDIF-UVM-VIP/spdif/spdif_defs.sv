// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_defs.sv -- SPDIF shared type definitions

package spdif_defs_pkg;

  typedef enum bit [1:0] {SPDIF_OK, SPDIF_ERR} spdif_status_e;

  function automatic int spdif_cls(int n, int w);   // run length in UI, 0 when out of range
    if (2 * n < w) return 0;
    if (2 * n < 3 * w) return 1;
    if (2 * n < 5 * w) return 2;
    if (2 * n < 7 * w) return 3;
    return 0;
  endfunction

endpackage
