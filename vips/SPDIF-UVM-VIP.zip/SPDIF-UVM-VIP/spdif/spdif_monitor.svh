// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_monitor.svh -- SPDIF monitor: run lengths on spdif_in from the first transition of a burst to an idle line, with every subframe report the receiver gave meanwhile

class spdif_monitor extends uvm_monitor;
  `uvm_component_utils(spdif_monitor)

  virtual spdif_if vif;
  uvm_analysis_port #(spdif_transaction) ap;
  spdif_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual spdif_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spdif: virtual interface not set")
    if (!uvm_config_db#(spdif_config)::get(this, "", "cfg", cfg))
      cfg = spdif_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        spdif_transaction t;
        int unsigned n = 0;
        bit lv;
        lv = vif.mon_cb.spdif_in;
        do @(vif.mon_cb); while (vif.mon_cb.spdif_in === lv);
        lv = vif.mon_cb.spdif_in;
        t = spdif_transaction::type_id::create("t");
        n = 1;
        forever begin
          @(vif.mon_cb);
          if (vif.mon_cb.rep_valid)
            t.rep.push_back({vif.mon_cb.rep_status, vif.mon_cb.rep_pre, vif.mon_cb.rep_vucp, vif.mon_cb.rep_data});
          if (vif.mon_cb.rep_valid && vif.mon_cb.rep_cs_valid) t.csq.push_back(vif.mon_cb.rep_cs);
          if (vif.mon_cb.spdif_in === lv) begin
            n++;
            if (n >= 8 * cfg.ui) break;
          end else begin
            t.seg.push_back(n);
            lv = vif.mon_cb.spdif_in; n = 1;
          end
        end
        publish(t);
      end
    end
  endtask

  function void publish(spdif_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
