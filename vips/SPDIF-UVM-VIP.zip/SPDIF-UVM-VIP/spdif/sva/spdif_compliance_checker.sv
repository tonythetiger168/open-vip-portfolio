// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_compliance_checker.sv -- SPDIF concurrent assertion checks (bindable)

module spdif_compliance_checker
  (input logic clk, input logic rst_n, input logic spdif_in, input logic rep_valid, input logic [1:0] rep_pre, input logic [23:0] rep_data, input logic [3:0] rep_vucp, input logic [1:0] rep_status, input logic rep_cs_valid, input logic [31:0] rep_cs);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({spdif_in, rep_valid, rep_cs_valid}))
    else $error("SPDIF: X on the line / valids");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |-> rep_status != 2'd3 && !$isunknown({rep_pre, rep_data, rep_vucp}))
    else $error("SPDIF: bad report");
  assert property (@(posedge clk) disable iff (!rst_n) rep_cs_valid |-> rep_valid && rep_status != 2'd2 && rep_pre != 2'd2)
    else $error("SPDIF: channel status without a channel A subframe");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_status == 2'd2 |-> rep_data == 24'h0)
    else $error("SPDIF: data with a violation");
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_status == 2'd1);
  cover property (@(posedge clk) disable iff (!rst_n) rep_cs_valid);
endmodule
