// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_if.sv -- SPDIF interface

interface spdif_if (input logic clk);
  logic rst_n;

  logic spdif_in;
  logic rep_valid;
  logic [1:0] rep_pre;
  logic [23:0] rep_data;
  logic [3:0] rep_vucp;
  logic [1:0] rep_status;
  logic rep_cs_valid;
  logic [31:0] rep_cs;

  modport DUT (input clk, rst_n, input spdif_in, output rep_valid, output rep_pre, output rep_data, output rep_vucp, output rep_status, output rep_cs_valid, output rep_cs);
  modport MON (input clk, rst_n, spdif_in, rep_valid, rep_pre, rep_data, rep_vucp, rep_status, rep_cs_valid, rep_cs);

  clocking drv_cb @(posedge clk);
    input rst_n, rep_valid, rep_pre, rep_data, rep_vucp, rep_status, rep_cs_valid, rep_cs;
    inout spdif_in;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, spdif_in, rep_valid, rep_pre, rep_data, rep_vucp, rep_status, rep_cs_valid, rep_cs;
  endclocking
endinterface
