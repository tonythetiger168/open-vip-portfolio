// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_pkg.sv -- SPDIF UVM VIP package

package spdif_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import spdif_defs_pkg::*;
  export spdif_defs_pkg::*;

  `include "spdif_transaction.svh"
  `include "spdif_config.svh"
  `include "spdif_sequencer.svh"
  `include "spdif_driver.svh"
  `include "spdif_monitor.svh"
  `include "spdif_agent.svh"
  `include "spdif_sequences.svh"
  `include "spdif_checker.svh"
  `include "spdif_coverage.svh"
endpackage
