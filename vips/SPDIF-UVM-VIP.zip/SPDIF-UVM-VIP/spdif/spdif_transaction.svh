// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_transaction.svh -- SPDIF transaction

class spdif_transaction extends uvm_sequence_item;
  `uvm_object_utils(spdif_transaction)

  // request (driven by the agent)
  bit [15:0] seg[$];
  // response (returned by the DUT)
  bit [31:0] rep[$];
  bit [31:0] csq[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [1:0] nfr;
  rand bit valid;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "spdif_transaction"); super.new(name); endfunction

  // kind: 0-19 burst of M frames, 20 parity flip, 21 missing transition at a cell
  // boundary, 22 illegal preamble, 23 jitter, 24-27 block start (B), 28-31 M frames.
  // nfr + 1 frames per burst. Returns the frame counter after the burst.
  function void set(int k, int frames, bit [31:0] s = 32'h1); kind = k; nfr = frames - 1; seed = s; endfunction
  function int build(int unsigned w, int f, bit [31:0] csw);
    bit [31:0] x = seed | 1;
    int ru [$];                 // run lengths in UI
    int cell0 [$];              // index in ru of the first run of each data cell (for kind 21)
    int nsub = 2 * (nfr + 1);
    int fs = x[7:0] % nsub;     // subframe that carries the fault
    for (int s = 0; s < nsub; s++) begin
      bit [27:0] b;
      bit c;
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      if (s % 2 == 0) begin
        if (s == 0 && kind inside {[24:27]}) f = 0; else f = f + 1;
      end
      c = (f < 32) ? csw[f] : 1'b0;
      b = {1'b0, c, 1'b0, !valid, x[23:0]};
      b[27] = ^b[26:0];
      if (kind == 20 && s == fs) b[27] = ~b[27];
      if (kind == 22 && s == fs) begin ru.push_back(3); ru.push_back(1); ru.push_back(3); ru.push_back(1); end
      else if (s % 2) begin ru.push_back(3); ru.push_back(2); ru.push_back(1); ru.push_back(2); end
      else if (s == 0 && kind inside {[24:27]}) begin ru.push_back(3); ru.push_back(1); ru.push_back(1); ru.push_back(3); end
      else begin ru.push_back(3); ru.push_back(3); ru.push_back(1); ru.push_back(1); end
      for (int i = 0; i < 28; i++) begin
        if (s == fs) cell0.push_back(ru.size());
        if (b[i]) begin ru.push_back(1); ru.push_back(1); end else ru.push_back(2);
      end
    end
    if (kind == 21) begin
      int j = cell0[1 + x[11:8] % 26];        // merge the run before a cell boundary with the one after
      ru[j - 1] = ru[j - 1] + ru[j];
      ru.delete(j);
    end
    seg.delete();
    foreach (ru[i]) begin
      int n = ru[i] * w;
      if (kind == 23) begin x ^= x << 13; x ^= x >> 17; x ^= x << 5; n = n + x[2:0] % 5 - 2; end
      seg.push_back(n);
    end
    return f;
  endfunction

  function void do_copy(uvm_object rhs);
    spdif_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    seg = rhs_.seg;
    rep = rhs_.rep;
    csq = rhs_.csq;
    kind = rhs_.kind;
    nfr = rhs_.nfr;
    valid = rhs_.valid;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    spdif_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (seg.size() != rhs_.seg.size()) return 0;
    foreach (seg[i]) if (seg[i] != rhs_.seg[i]) return 0;
    if (rep.size() != rhs_.rep.size()) return 0;
    foreach (rep[i]) if (rep[i] != rhs_.rep[i]) return 0;
    if (csq.size() != rhs_.csq.size()) return 0;
    foreach (csq[i]) if (csq[i] != rhs_.csq[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(spdif_transaction rhs_);
    if (seg.size() != rhs_.seg.size()) return 0;
    foreach (seg[i]) if (seg[i] != rhs_.seg[i]) return 0;
    return 1;
  endfunction

  function string qstr_seg();
    string s = $sformatf("[%0d]{", seg.size());
    foreach (seg[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", seg[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rep();
    string s = $sformatf("[%0d]{", rep.size());
    foreach (rep[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rep[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_csq();
    string s = $sformatf("[%0d]{", csq.size());
    foreach (csq[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", csq[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SPDIF{tag=%0d seg=%s rep=%s csq=%s}", tag, qstr_seg(), qstr_rep(), qstr_csq());
  endfunction
endclass
