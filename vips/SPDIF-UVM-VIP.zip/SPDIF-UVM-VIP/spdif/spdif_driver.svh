// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_driver.svh -- SPDIF driver: one burst of biphase-mark frames per item (a transition then seg[i] clocks of each run), one closing transition and cfg.gap_ui idle UI; the frame counter for B / M and channel status runs across items

class spdif_driver extends uvm_driver #(spdif_transaction);
  `uvm_component_utils(spdif_driver)

  uvm_analysis_port #(spdif_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual spdif_if vif;
  spdif_config cfg;

  int fidx = 0;
  bit lvl = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual spdif_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "spdif: virtual interface not set")
    if (!uvm_config_db#(spdif_config)::get(this, "", "cfg", cfg))
      cfg = spdif_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    spdif_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.spdif_in <= 1'b0;
  endtask

  task drive_item(spdif_transaction t);
    fidx = t.build(cfg.ui, fidx, cfg.cs_word);
    @(vif.drv_cb);
    foreach (t.seg[i]) begin
      lvl = !lvl;
      vif.drv_cb.spdif_in <= lvl;
      repeat (t.seg[i]) @(vif.drv_cb);
    end
    lvl = !lvl;
    vif.drv_cb.spdif_in <= lvl;
    repeat (cfg.gap_ui * cfg.ui) @(vif.drv_cb);
  endtask

endclass
