// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_coverage.svh -- SPDIF functional coverage

class spdif_coverage extends uvm_subscriber #(spdif_transaction);
  `uvm_component_utils(spdif_coverage)
  spdif_config cfg;
  spdif_transaction tr;

  covergroup spdif_cg;
    cp_n      : coverpoint tr.rep.size() { bins frame = {2}; bins burst = {[3:8]}; }
    cp_status : coverpoint (tr.rep.size() ? tr.rep[tr.rep.size() - 1][31:30] : 2'd0) { bins ok = {0}; bins parity = {1}; bins bmc = {2}; }
    cp_cs     : coverpoint tr.csq.size() { bins none = {0}; bins block = {1}; }
    cp_first  : coverpoint (tr.rep.size() ? tr.rep[0][29:28] : 2'd3) { bins b = {0}; bins m = {1}; bins bad = {3}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    spdif_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(spdif_config)::get(this, "", "cfg", cfg))
      cfg = spdif_config::type_id::create("cfg");
  endfunction

  function void write(spdif_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    spdif_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SPDIF coverage: %0.1f%%", spdif_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
