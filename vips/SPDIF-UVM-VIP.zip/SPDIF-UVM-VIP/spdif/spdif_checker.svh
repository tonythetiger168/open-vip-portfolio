// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_checker.svh -- SPDIF protocol checker on monitored items

class spdif_checker extends uvm_component;
  `uvm_component_utils(spdif_checker)
  uvm_analysis_imp #(spdif_transaction, spdif_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  spdif_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(spdif_config)::get(this, "", "cfg", cfg))
      cfg = spdif_config::type_id::create("cfg");
  endfunction

  function void fail(spdif_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("SPDIF: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(spdif_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      foreach (t.rep[i]) begin
        if (t.rep[i][31:30] == 2'd3) fail(t, "reserved status");
        if (t.rep[i][31:30] == 2'd2 && t.rep[i][27:0] != 0) fail(t, "data reported with a violation");
        if (t.rep[i][31:30] != 2'd2 && t.rep[i][29:28] == 2'd3) fail(t, "data without a preamble");
      end
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("SPDIF checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
