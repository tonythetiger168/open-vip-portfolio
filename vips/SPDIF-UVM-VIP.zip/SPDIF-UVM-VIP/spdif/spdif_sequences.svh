// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// spdif_sequences.svh -- SPDIF sequences

// Random traffic: cfg.num_items constrained-random items.
class spdif_base_sequence extends uvm_sequence #(spdif_transaction);
  `uvm_object_utils(spdif_base_sequence)
  spdif_config cfg;

  function new(string name = "spdif_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = spdif_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "spdif_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class spdif_directed_sequence extends uvm_sequence #(spdif_transaction);
  `uvm_object_utils(spdif_directed_sequence)
  spdif_config cfg;

  function new(string name = "spdif_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function spdif_transaction item();
    item = spdif_transaction::type_id::create("req");
  endfunction

  task send(spdif_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    spdif_transaction t;
    // a 48-frame block in bursts, then every fault, jitter, and a second block
    t = item(); t.set(24, 4, 32'h11); send(t);
    for (int i = 0; i < 11; i++) begin t = item(); t.set(0, 4, 32'h100 + i); t.valid = i[0]; send(t); end
    t = item(); t.set(0, 1, 32'h7); send(t);
    for (int s = 0; s < 3; s++) begin
      t = item(); t.set(20, 2, 32'h33 * (s + 1)); send(t);
      t = item(); t.set(21, 2, 32'h55 * (s + 1)); send(t);
      t = item(); t.set(22, 2, 32'h77 * (s + 1)); send(t);
      t = item(); t.set(23, 3, 32'h99 * (s + 1)); send(t);
    end
    t = item(); t.set(25, 4, 32'h1234); send(t);
    for (int i = 0; i < 8; i++) begin t = item(); t.set(23, 4, 32'h4000 + i); send(t); end
  endtask
endclass
