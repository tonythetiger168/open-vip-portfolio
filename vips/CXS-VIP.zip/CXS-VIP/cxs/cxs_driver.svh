// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cxs_driver.svh -- CXS transmitter driver
// Runs the activate handshake (active_req -> active_ack), then streams
// flits; supports the deactivate handshake and missing-last error injection.

`ifndef CXS_DRIVER_SVH
`define CXS_DRIVER_SVH

class cxs_driver extends uvm_driver #(cxs_transaction);
  `uvm_component_utils(cxs_driver)
  virtual cxs_if vif;
  cxs_config cfg;
  uvm_analysis_port #(cxs_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual cxs_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cxs virtual interface not set")
  endfunction

  // Activate handshake: request the link and wait for the receiver grant
  task activate();
    int unsigned tmo = 0;
    vif.state = cxs_defs_pkg::ACTIVATE;
    vif.drv_cb.cxs_active_req <= 1'b1;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "cxs activate timeout: no active_ack")
    end while (!vif.drv_cb.cxs_active_ack);
    vif.state = cxs_defs_pkg::DATA_TX;
    `uvm_info("DRV", "cxs link active", UVM_MEDIUM)
  endtask

  // Deactivate handshake: hint, drop the request, wait for the ack to fall
  task deactivate();
    int unsigned tmo = 0;
    vif.state = cxs_defs_pkg::DEACTIVATE;
    vif.drv_cb.cxs_deact_hint <= 1'b1;
    @(vif.drv_cb);
    vif.drv_cb.cxs_active_req <= 1'b0;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "cxs deactivate timeout: active_ack stuck")
    end while (vif.drv_cb.cxs_active_ack);
    vif.drv_cb.cxs_deact_hint <= 1'b0;
    vif.state = cxs_defs_pkg::IDLE;
    `uvm_info("DRV", "cxs link deactivated", UVM_MEDIUM)
  endtask

  task drive_flit(cxs_transaction tr);
    `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
    if (!vif.drv_cb.cxs_active_ack) activate();   // (re-)activate on demand
    vif.state = cxs_defs_pkg::DATA_TX;
    vif.drv_cb.cxs_valid <= 1'b1;
    vif.drv_cb.cxs_data  <= tr.data;
    vif.drv_cb.cxs_cntl  <= tr.cntl;
    vif.drv_cb.cxs_last  <= tr.last;
    @(vif.drv_cb);
    vif.drv_cb.cxs_valid <= 1'b0;
    vif.drv_cb.cxs_last  <= 1'b0;
    // Protocol rule: cxs_valid must fall for at least one cycle after cxs_last
    if (tr.last && !tr.error_inject) @(vif.drv_cb);
    if (tr.error_inject) begin
      // Protocol violation: packet abandoned mid-stream without cxs_last
      vif.state = cxs_defs_pkg::LINK_ERROR;
      repeat (2) @(vif.drv_cb);
      vif.state = cxs_defs_pkg::DATA_TX;
    end
    repeat (tr.inter_pkt_gap) @(vif.drv_cb);
    if (tr.do_deactivate) deactivate();
  endtask

  task run_phase(uvm_phase phase);
    cxs_transaction tr;
    vif.drv_cb.cxs_valid      <= 1'b0;
    vif.drv_cb.cxs_last       <= 1'b0;
    vif.drv_cb.cxs_data       <= '0;
    vif.drv_cb.cxs_cntl       <= '0;
    vif.drv_cb.cxs_active_req <= 1'b0;
    vif.drv_cb.cxs_deact_hint <= 1'b0;
    vif.state = cxs_defs_pkg::IDLE;
    wait (vif.cxs_resetn === 1'b1);
    repeat (2) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(tr);
      drive_flit(tr);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
