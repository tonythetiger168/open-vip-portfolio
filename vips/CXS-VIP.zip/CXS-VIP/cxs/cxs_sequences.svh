// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cxs_sequences.svh -- CXS sequence library

`ifndef CXS_SEQUENCES_SVH
`define CXS_SEQUENCES_SVH

class cxs_base_sequence extends uvm_sequence #(cxs_transaction);
  `uvm_object_utils(cxs_base_sequence)
  int num_txns = 20;
  function new(string name = "cxs_base_sequence"); super.new(name); endfunction
  task body();
    cxs_transaction tr;
    repeat (num_txns) begin
      tr = cxs_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: single-flit packets (last on every flit)
class cxs_single_flit_seq extends cxs_base_sequence;
  `uvm_object_utils(cxs_single_flit_seq)

  function new(string name = "cxs_single_flit_seq"); super.new(name); endfunction

  task body();
    cxs_transaction tr;
    repeat (num_txns) begin
      tr = cxs_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { last == 1; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: 4-flit packets with constant cntl, last only on the final flit
class cxs_multi_flit_seq extends cxs_base_sequence;
  `uvm_object_utils(cxs_multi_flit_seq)

  function new(string name = "cxs_multi_flit_seq"); super.new(name); endfunction

  rand bit [7:0] pkt_cntl = 8'hA5;
  task body();
    cxs_transaction tr;
    repeat (num_txns / 4) begin
      for (int i = 0; i < 4; i++) begin
        tr = cxs_transaction::type_id::create("tr");
        start_item(tr);
        void'(tr.randomize() with { cntl == pkt_cntl; last == (i == 3);
                                    error_inject == 0; });
        finish_item(tr);
      end
    end
  endtask
endclass

// Directed: walking-one cntl patterns
class cxs_cntl_walk_seq extends cxs_base_sequence;
  `uvm_object_utils(cxs_cntl_walk_seq)

  function new(string name = "cxs_cntl_walk_seq"); super.new(name); endfunction

  task body();
    cxs_transaction tr;
    for (int i = 0; i < 8; i++) begin
      tr = cxs_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { cntl == (8'h01 << i); last == 1;
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: data corner values (all-0 / all-1 / alternating)
class cxs_data_corner_seq extends cxs_base_sequence;
  `uvm_object_utils(cxs_data_corner_seq)

  function new(string name = "cxs_data_corner_seq"); super.new(name); endfunction

  task body();
    cxs_transaction tr;
    bit [63:0] corners[$] = '{64'h0, {64{1'b1}}, 64'hAAAA_AAAA_AAAA_AAAA,
                              64'h5555_5555_5555_5555};
    foreach (corners[i]) begin
      tr = cxs_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { data == corners[i]; last == 1;
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back single-flit packets with no inter-packet gap
class cxs_back_to_back_seq extends cxs_base_sequence;
  `uvm_object_utils(cxs_back_to_back_seq)

  function new(string name = "cxs_back_to_back_seq"); super.new(name); endfunction

  task body();
    cxs_transaction tr;
    num_txns = 30;
    repeat (num_txns) begin
      tr = cxs_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { last == 1; inter_pkt_gap == 0;
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: full deactivate handshake, then traffic again (re-activation)
class cxs_deactivate_seq extends cxs_base_sequence;
  `uvm_object_utils(cxs_deactivate_seq)

  function new(string name = "cxs_deactivate_seq"); super.new(name); endfunction

  task body();
    cxs_transaction tr;
    tr = cxs_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { last == 1; error_inject == 0; });
    tr.do_deactivate = 1;
    finish_item(tr);
    // link re-activates on demand for the following packets
    repeat (2) begin
      tr = cxs_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { last == 1; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: packet abandoned mid-stream without cxs_last
class cxs_error_inject_seq extends cxs_base_sequence;
  `uvm_object_utils(cxs_error_inject_seq)

  function new(string name = "cxs_error_inject_seq"); super.new(name); endfunction

  task body();
    cxs_transaction tr;
    repeat (4) begin
      tr = cxs_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { last == 0; error_inject == 1; });
      finish_item(tr);
    end
    // recovery: a clean closing packet
    tr = cxs_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { last == 1; error_inject == 0; });
    finish_item(tr);
  endtask
endclass

// Reset behavior: single packet right after link activation
class cxs_reset_seq extends cxs_base_sequence;
  `uvm_object_utils(cxs_reset_seq)

  function new(string name = "cxs_reset_seq"); super.new(name); endfunction

  task body();
    cxs_transaction tr = cxs_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { last == 1; error_inject == 0; });
    finish_item(tr);
  endtask
endclass

class cxs_random_sequence extends cxs_base_sequence;
  `uvm_object_utils(cxs_random_sequence)
  function new(string name = "cxs_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class cxs_regression_sequence extends cxs_base_sequence;
  `uvm_object_utils(cxs_regression_sequence)
  function new(string name = "cxs_regression_sequence"); super.new(name); endfunction
  task body();
    cxs_single_flit_seq   sf  = cxs_single_flit_seq::type_id::create("sf");
    cxs_multi_flit_seq    mf  = cxs_multi_flit_seq::type_id::create("mf");
    cxs_cntl_walk_seq     cw  = cxs_cntl_walk_seq::type_id::create("cw");
    cxs_data_corner_seq   dc  = cxs_data_corner_seq::type_id::create("dc");
    cxs_back_to_back_seq  b2b = cxs_back_to_back_seq::type_id::create("b2b");
    cxs_deactivate_seq    da  = cxs_deactivate_seq::type_id::create("da");
    cxs_error_inject_seq  err = cxs_error_inject_seq::type_id::create("err");
    sf.num_txns = 16; mf.num_txns = 16;
    sf.start(m_sequencer); mf.start(m_sequencer); cw.start(m_sequencer);
    dc.start(m_sequencer); b2b.start(m_sequencer); err.start(m_sequencer);
    da.start(m_sequencer);
  endtask
endclass
`endif
