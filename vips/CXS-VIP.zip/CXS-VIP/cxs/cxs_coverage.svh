// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cxs_coverage.svh -- CXS functional coverage

`ifndef CXS_COVERAGE_SVH
`define CXS_COVERAGE_SVH

class cxs_coverage extends uvm_subscriber #(cxs_transaction);
  `uvm_component_utils(cxs_coverage)

  cxs_transaction tr;
  cxs_state_e cur_state;
  virtual cxs_if vif;

  covergroup cg_protocol;
    cp_last : coverpoint tr.last {
      bins mid_pkt   = {0};
      bins pkt_end   = {1};
    }
    cp_cntl : coverpoint tr.cntl {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins walk = {8'h01, 8'h02, 8'h04, 8'h08, 8'h10, 8'h20, 8'h40, 8'h80};
      bins misc = default;
    }
    cp_data : coverpoint tr.data {
      bins zero = {64'h0};
      bins ones = {{64{1'b1}}};
      bins alt  = {64'hAAAA_AAAA_AAAA_AAAA, 64'h5555_5555_5555_5555};
      bins misc = default;
    }
    cx_last_cntl : cross cp_last, cp_cntl;
  endgroup

  covergroup cg_fsm with function sample(cxs_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, ACTIVATE, DATA_TX, DEACTIVATE, LINK_ERROR};
    }
    cp_trans : coverpoint s {
      bins act_seq   = (IDLE => ACTIVATE => DATA_TX);
      bins deact_seq = (DATA_TX => DEACTIVATE => IDLE);
      bins err_seq   = (DATA_TX => LINK_ERROR => DATA_TX);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.error_inject {
      bins legal        = {0};
      bins missing_last = {1};
    }
    cp_err_last : coverpoint tr.last iff (tr.error_inject) {
      bins no_last = {0};
    }
    cp_last : coverpoint tr.last {
      bins mid_pkt   = {0};
      bins pkt_end   = {1};
    }
    cx_err_last : cross cp_err, cp_last {
      // error injection abandons the packet, so it never asserts last
      ignore_bins err_with_last = binsof(cp_err.missing_last) && binsof(cp_last.pkt_end);
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual cxs_if)::get(this, "", "vif", vif));
  endfunction

  function void write(cxs_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction

  // Sample the link FSM every cycle so all states/transitions are observable
  task run_phase(uvm_phase phase);
    if (vif == null) begin
      `uvm_warning("COV", "cxs coverage: no vif, FSM coverage disabled")
      return;
    end
    forever begin
      @(posedge vif.cxs_clk);
      cur_state = vif.state;
      cg_fsm.sample(cur_state);
    end
  endtask
endclass
`endif
