// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cxs_pkg.sv -- CXS CCIX Stream Interface UVM VIP package

package cxs_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import cxs_defs_pkg::*;
  export cxs_defs_pkg::*;

  `include "cxs_transaction.svh"
  `include "cxs_config.svh"
  `include "cxs_sequencer.svh"
  `include "cxs_driver.svh"
  `include "cxs_monitor.svh"
  `include "cxs_agent.svh"
  `include "cxs_sequences.svh"
  `include "cxs_checker.svh"
  `include "cxs_coverage.svh"
endpackage
