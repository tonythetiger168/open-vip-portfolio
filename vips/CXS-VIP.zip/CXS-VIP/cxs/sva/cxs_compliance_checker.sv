// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cxs_compliance_checker.sv -- CXS CCIX Stream Interface SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules, L4 = CXS-specific rules

`ifndef CXS_COMPLIANCE_CHECKER_SV
`define CXS_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import cxs_defs_pkg::*;

module cxs_compliance_checker
(
  input logic cxs_clk,
  input logic cxs_resetn,
  input cxs_state_e state,
  input logic cxs_valid,
  input logic cxs_last,
  input logic [7:0] cxs_cntl,
  input logic cxs_active_req,
  input logic cxs_active_ack,
  input logic cxs_deact_hint
);

  // ---------------- L1: signal sanity (4) ----------------
  a_cxs_l1_clk   : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn) !$isunknown(cxs_clk))
    else `uvm_error("SVA_L1", "cxs: clock unknown")
  a_cxs_l1_rst   : assert property (@(posedge cxs_clk) !$isunknown(cxs_resetn))
    else `uvm_error("SVA_L1", "cxs: reset unknown")
  a_cxs_l1_state : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn) !$isunknown(state))
    else `uvm_error("SVA_L1", "cxs: state unknown")
  a_cxs_l1_valid : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state inside {IDLE, ACTIVATE, DATA_TX, DEACTIVATE, LINK_ERROR})
    else `uvm_error("SVA_L1", "cxs: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_cxs_trans_idle : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state == IDLE |=> state inside {IDLE, ACTIVATE})
    else `uvm_error("SVA_L2", "cxs: illegal transition from IDLE")

  // L2-2: legal FSM transition from ACTIVATE
  a_cxs_trans_activate : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state == ACTIVATE |=> state inside {ACTIVATE, DATA_TX})
    else `uvm_error("SVA_L2", "cxs: illegal transition from ACTIVATE")

  // L2-3: legal FSM transition from DATA_TX
  a_cxs_trans_data_tx : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state == DATA_TX |=> state inside {DATA_TX, DEACTIVATE})
    else `uvm_error("SVA_L2", "cxs: illegal transition from DATA_TX")

  // L2-4: legal FSM transition from DEACTIVATE
  a_cxs_trans_deactivate : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state == DEACTIVATE |=> state inside {DEACTIVATE, LINK_ERROR})
    else `uvm_error("SVA_L2", "cxs: illegal transition from DEACTIVATE")

  // L2-5: legal FSM transition from LINK_ERROR
  a_cxs_trans_link_error : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state == LINK_ERROR |=> state inside {LINK_ERROR, IDLE})
    else `uvm_error("SVA_L2", "cxs: illegal transition from LINK_ERROR")

  // ---------------- L3: protocol rules (4) ----------------
  a_cxs_l3_reset_idle : assert property (@(posedge cxs_clk)
    $fell(cxs_resetn) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "cxs: state not IDLE during reset")
  a_cxs_l3_no_stuck   : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state == LINK_ERROR |-> ##[1:8] (state != LINK_ERROR))
    else `uvm_error("SVA_L3", "cxs: stuck in LINK_ERROR")
  a_cxs_l3_full_cycle : cover property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state == IDLE ##1 state == ACTIVATE);
  a_cxs_l3_back_idle  : cover property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    state == LINK_ERROR ##1 state == IDLE);

  // ---------------- L4: CXS protocol-specific rules (4) ----------------
  // L4-1: cxs_valid must fall for at least one cycle after cxs_last
  a_cxs_l4_last_valid_fall : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    (cxs_valid && cxs_last) |=> !cxs_valid)
    else `uvm_error("SVA_L4", "cxs: valid not deasserted after last")

  // L4-2: no stream traffic before the activate handshake completes
  a_cxs_l4_no_tx_before_ack : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    cxs_valid |-> cxs_active_ack)
    else `uvm_error("SVA_L4", "cxs: flit transmitted before active_ack")

  // L4-3: cxs_cntl must remain stable across consecutive flits of a packet
  a_cxs_l4_cntl_stable : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    (cxs_valid && $past(cxs_valid) && !$past(cxs_last)) |-> $stable(cxs_cntl))
    else `uvm_error("SVA_L4", "cxs: cntl changed mid-packet")

  // L4-4: deactivate flow completes -- active_ack falls after active_req falls
  a_cxs_l4_deactivate_complete : assert property (@(posedge cxs_clk) disable iff (!cxs_resetn)
    $fell(cxs_active_req) |-> ##[1:8] $fell(cxs_active_ack))
    else `uvm_error("SVA_L4", "cxs: deactivate handshake incomplete")

endmodule
`endif
