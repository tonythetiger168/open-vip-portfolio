// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cxs_protocol_checker.sv -- CXS CCIX Stream Interface protocol rule checker

`ifndef CXS_PROTOCOL_CHECKER_SV
`define CXS_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import cxs_defs_pkg::cxs_state_e;

module cxs_protocol_checker
(
  input logic cxs_clk,
  input logic cxs_resetn,
  input cxs_state_e state
);
  a_cxs_protocol_state_known : assert property (@(posedge cxs_clk)
    disable iff (!cxs_resetn) !$isunknown(state))
    else `uvm_error("PROTOCOL", "cxs protocol: state unknown")
endmodule
`endif
