// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// cxs_if.sv -- CXS CCIX Stream Interface
// Packetized streaming link: activate handshake (active_req/ack), then
// back-to-back flits (valid/last/data/cntl); no bubbles allowed mid-packet.

interface cxs_if (input logic cxs_clk);
  import cxs_defs_pkg::cxs_state_e;

  logic        cxs_resetn;
  // Transmitter (VIP) -> Receiver (DUT) stream
  logic        cxs_valid;
  logic        cxs_last;
  logic [63:0] cxs_data;
  logic [7:0]  cxs_cntl;
  // Link activate / deactivate handshake
  logic        cxs_active_req;   // TX requests an active link
  logic        cxs_active_ack;   // RX grants the active link
  logic        cxs_deact_hint;   // TX hints an upcoming deactivation

  cxs_state_e state;

  modport TX (input  cxs_clk, cxs_resetn, cxs_active_ack,
              output cxs_valid, cxs_last, cxs_data, cxs_cntl,
                     cxs_active_req, cxs_deact_hint, state);
  modport RX (input  cxs_clk, cxs_resetn, cxs_valid, cxs_last, cxs_data, cxs_cntl,
                     cxs_active_req, cxs_deact_hint,
              output cxs_active_ack);
  modport MON (input cxs_clk, cxs_resetn, cxs_valid, cxs_last, cxs_data, cxs_cntl,
                      cxs_active_req, cxs_active_ack, cxs_deact_hint, state);

  clocking drv_cb @(posedge cxs_clk);
    input  cxs_resetn, cxs_active_ack;
    output cxs_valid, cxs_last, cxs_data, cxs_cntl, cxs_active_req, cxs_deact_hint;
  endclocking

  clocking mon_cb @(posedge cxs_clk);
    input cxs_resetn, cxs_valid, cxs_last, cxs_data, cxs_cntl,
          cxs_active_req, cxs_active_ack, cxs_deact_hint, state;
  endclocking
endinterface
