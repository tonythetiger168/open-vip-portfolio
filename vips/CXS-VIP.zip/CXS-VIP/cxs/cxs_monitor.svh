// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cxs_monitor.svh -- CXS monitor: decodes flits from the cxs_* waveform,
// tracks packet framing (last) and a running CRC-8, and publishes
// reconstructed flit transactions.

`ifndef CXS_MONITOR_SVH
`define CXS_MONITOR_SVH

class cxs_monitor extends uvm_monitor;
  `uvm_component_utils(cxs_monitor)
  virtual cxs_if vif;
  uvm_analysis_port #(cxs_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned pkt_count = 0;

  protected bit [7:0] crc;
  protected bit       in_pkt;

  // CRC-8 (poly 0x07) folded byte-wise over the 64-bit flit
  function automatic bit [7:0] crc8(bit [7:0] c, bit [63:0] d);
    bit [7:0] r = c;
    for (int i = 0; i < 8; i++) begin
      r = r ^ d[i*8 +: 8];
      r = {r[6:0], 1'b0} ^ (r[7] ? 8'h07 : 8'h00);
    end
    return r;
  endfunction

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual cxs_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cxs virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    cxs_transaction tr;
    crc = 8'h00; in_pkt = 0;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.cxs_resetn !== 1'b1) begin crc = 8'h00; in_pkt = 0; continue; end
      if (vif.mon_cb.cxs_valid && vif.mon_cb.cxs_active_ack) begin
        tr = cxs_transaction::type_id::create("tr");
        tr.data = vif.mon_cb.cxs_data;
        tr.last = vif.mon_cb.cxs_last;
        tr.cntl = vif.mon_cb.cxs_cntl;
        crc = crc8(in_pkt ? crc : 8'h00, tr.data);
        tr.pkt_crc = crc;
        in_pkt = !tr.last;
        if (tr.last) pkt_count++;
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("cxs monitor observed %0d flits in %0d packets",
              txn_count, pkt_count), UVM_LOW)
  endfunction
endclass
`endif
