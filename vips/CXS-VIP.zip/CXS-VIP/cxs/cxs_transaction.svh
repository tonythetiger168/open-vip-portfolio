// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cxs_transaction.svh -- CXS stream flit transaction
// One transaction = one 64-bit flit; sequences frame packets by setting
// `last` on the final flit of a packet.

`ifndef CXS_TRANSACTION_SVH
`define CXS_TRANSACTION_SVH

class cxs_transaction extends uvm_sequence_item;

  rand bit [63:0] data;
  rand bit        last;          // packet-boundary marker (final flit)
  rand bit [7:0]  cntl;          // per-packet control sideband
  rand bit        error_inject;  // 1 = drop valid mid-packet without last
  rand int unsigned inter_pkt_gap;

  bit             do_deactivate; // sequence hint: run the deactivate handshake
  bit [7:0]       pkt_crc;       // monitor: running CRC-8 observed at this flit

  constraint c_last { last dist {0 := 7, 1 := 3}; }
  constraint c_gap  { inter_pkt_gap inside {[0:3]}; }
  constraint c_err  { error_inject dist {0 := 15, 1 := 1}; }
  // CXS allows no bubbles mid-packet: a non-last flit is followed immediately
  constraint c_bubble { (last == 0) -> (inter_pkt_gap == 0); }

  `uvm_object_utils_begin(cxs_transaction)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(last, UVM_ALL_ON)
    `uvm_field_int(cntl, UVM_ALL_ON)
    `uvm_field_int(error_inject, UVM_ALL_ON)
    `uvm_field_int(pkt_crc, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "cxs_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    cxs_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    ok &= comparer.compare_field("data", data, t.data, 64);
    ok &= comparer.compare_field("last", last, t.last, 1);
    ok &= comparer.compare_field("cntl", cntl, t.cntl, 8);
    return ok;
  endfunction

  function string convert2string();
    return $sformatf("CXS flit data=0x%016h last=%0b cntl=0x%02h err=%0b deact=%0b",
                     data, last, cntl, error_inject, do_deactivate);
  endfunction
endclass
`endif
