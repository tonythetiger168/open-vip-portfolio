# CXS — CXS CCIX Stream Interface UVM VIP

Open-source UVM verification IP template for **CXS CCIX Stream Interface** (Interconnect).

## Contents

| Path | Description |
|------|-------------|
| `cxs/cxs_if.sv` | Protocol interface + FSM state enum |
| `cxs/cxs_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `cxs/sva/cxs_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=4) |
| `cxs/vip/cxs/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/cxs_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional CXS receiver DUT |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Stream protocol driver**: activate handshake (`cxs_active_req`/`cxs_active_ack`), packetized flit streaming (`cxs_valid`/`cxs_last`/`cxs_data`/`cxs_cntl`), deactivate handshake with `cxs_deact_hint`, on-demand re-activation
- **Protocol-decoding monitor**: reconstructs flit transactions from the stream waveform, tracks packet framing and a running CRC-8 per packet
- **End-to-end scoreboard**: compares driver-issued vs monitor-decoded flits (data / last / cntl)
- **Functional DUT model**: CXS receiver that answers the activate handshake, accumulates a CRC-8 per packet, and flags mid-packet bubbles (valid dropped without `cxs_last`)
- **Directed sequence library**: single-flit / 4-flit packets / cntl walking-one / data corners / back-to-back / deactivate+reactivate / error-inject (missing last) / reset + regression mix
- **Functional coverage**: last x cntl cross, data corners, link FSM state + transition sequences (activate / deactivate / error), missing-last error bins
- **SVA L4**: valid falls after `cxs_last`, no traffic before `cxs_active_ack`, cntl stable mid-packet, deactivate handshake completes
