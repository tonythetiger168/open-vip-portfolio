// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- CXS testbench top with a functional CXS receiver DUT model

`ifndef CXS_TB_SV
`define CXS_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import cxs_defs_pkg::*;
import cxs_pkg::*;
import cxs_test_pkg::*;

module top_tb;
  logic cxs_clk = 0;
  always #5ns cxs_clk = ~cxs_clk;

  cxs_if vif(cxs_clk);

  initial begin
    vif.cxs_resetn = 0;
    #100ns;
    vif.cxs_resetn = 1;
  end

  cxs_receiver_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual cxs_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional CXS receiver: answers the activate handshake one cycle after
// active_req, receives flits while the link is active, accumulates a CRC-8
// per packet, and flags mid-packet bubbles (valid dropped without last).
module cxs_receiver_model (cxs_if vif);
  bit [7:0]    crc;
  bit          in_pkt;
  int unsigned pkt_count;

  // CRC-8 (poly 0x07) folded byte-wise over the 64-bit flit
  function automatic bit [7:0] crc8(bit [7:0] c, bit [63:0] d);
    bit [7:0] r = c;
    for (int i = 0; i < 8; i++) begin
      r = r ^ d[i*8 +: 8];
      r = {r[6:0], 1'b0} ^ (r[7] ? 8'h07 : 8'h00);
    end
    return r;
  endfunction

  initial begin
    vif.cxs_active_ack = 0;
    crc       = 8'h00;
    in_pkt    = 0;
    pkt_count = 0;
  end

  always_ff @(posedge vif.cxs_clk or negedge vif.cxs_resetn) begin
    if (!vif.cxs_resetn) begin
      vif.cxs_active_ack <= 0;
      crc                <= 8'h00;
      in_pkt             <= 0;
      pkt_count          <= 0;
    end else begin
      // Activate / deactivate handshake response (1-cycle latency)
      vif.cxs_active_ack <= vif.cxs_active_req;

      if (vif.cxs_valid && !vif.cxs_active_ack)
        `uvm_warning("DUT", "cxs receiver: flit received before active_ack")

      if (vif.cxs_valid && vif.cxs_active_ack) begin
        crc    <= crc8(in_pkt ? crc : 8'h00, vif.cxs_data);
        in_pkt <= !vif.cxs_last;
        if (vif.cxs_last) begin
          pkt_count <= pkt_count + 1;
          `uvm_info("DUT", $sformatf("cxs receiver: packet %0d done, crc=0x%02h cntl=0x%02h",
                    pkt_count + 1, crc8(in_pkt ? crc : 8'h00, vif.cxs_data), vif.cxs_cntl),
                    UVM_HIGH)
        end
      end else if (in_pkt && vif.cxs_active_ack && !vif.cxs_valid) begin
        // Mid-packet bubble: valid dropped before cxs_last (error injection)
        `uvm_warning("DUT", "cxs receiver: packet abandoned without cxs_last")
        in_pkt <= 0;
      end
    end
  end
endmodule
`endif
