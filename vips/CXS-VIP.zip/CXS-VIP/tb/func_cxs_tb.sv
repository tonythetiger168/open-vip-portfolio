// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_cxs_tb.sv -- self-checking functional test for the CXS receiver model
// (cxs_receiver_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py CXS-VIP
//
// Model contract (from tb/top_tb.sv):
//   cxs_active_ack follows cxs_active_req one clock later. Flits are accepted
//   only while active_ack is high; each accepted flit folds its 64-bit data
//   into a running CRC-8 (poly 0x07, byte 0 first) that restarts at every
//   packet; cxs_last ends a packet and bumps the packet counter. A gap
//   (valid low) inside a packet abandons it. CRC and counters are internal,
//   so the test reads them hierarchically (white-box).

module func_cxs_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic        clk = 1'b0, resetn = 1'b0, valid = 1'b0, last = 1'b0, req = 1'b0;
  logic [63:0] data = '0;
  logic [7:0]  cntl = '0;
  wire         ack;

  always #5 clk = ~clk;

  cxs_receiver_model u_dut (
    .vif_cxs_clk(clk), .vif_cxs_resetn(resetn), .vif_cxs_valid(valid),
    .vif_cxs_last(last), .vif_cxs_data(data), .vif_cxs_cntl(cntl),
    .vif_cxs_active_req(req), .vif_cxs_active_ack(ack)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic [7:0] crc8(input [7:0] c, input [63:0] d);
    bit [7:0] r = c;
    for (int i = 0; i < 8; i++) begin
      r = r ^ d[i*8 +: 8];
      r = {r[6:0], 1'b0} ^ (r[7] ? 8'h07 : 8'h00);
    end
    return r;
  endfunction

  // send a packet of n flits; returns its expected CRC
  task automatic packet(input int n, input [63:0] seed, output [7:0] exp_crc);
    exp_crc = 8'h00;
    for (int i = 0; i < n; i++) begin
      @(negedge clk);
      valid = 1'b1; data = seed ^ (64'(i) << 8); last = (i == n - 1); cntl = 8'(i);
      exp_crc = crc8(exp_crc, data);
    end
    @(negedge clk);
    valid = 1'b0; last = 1'b0;
  endtask

  logic [7:0] e;
  int         pc;

  initial begin
    repeat (2) @(negedge clk);
    resetn = 1'b1;
    @(negedge clk);
    chk(ack === 1'b0, "active_ack low out of reset");

    // flit before activation is not accepted
    packet(1, 64'h0123_4567_89AB_CDEF, e);
    @(negedge clk);
    chk(u_dut.pkt_count == 0, "flit sent before active_ack is not accepted");

    // activation handshake
    req = 1'b1;
    @(negedge clk);
    chk(ack === 1'b1, "active_ack follows active_req after one clock");

    packet(1, 64'h0123_4567_89AB_CDEF, e);
    chk(u_dut.pkt_count == 1 && u_dut.crc == e, "single-flit packet counted with correct CRC-8");

    packet(5, 64'hDEAD_BEEF_0000_1111, e);
    chk(u_dut.pkt_count == 2 && u_dut.crc == e, "5-flit packet: CRC chained across flits");

    packet(3, 64'hFFFF_FFFF_FFFF_FFFF, e);
    chk(u_dut.crc == e, "CRC restarts at each packet");

    // a gap inside a packet abandons it
    pc = u_dut.pkt_count;
    @(negedge clk); valid = 1'b1; last = 1'b0; data = 64'h1;
    @(negedge clk); valid = 1'b0;
    @(negedge clk);
    chk(u_dut.in_pkt === 1'b0 && u_dut.pkt_count == pc, "packet abandoned on a valid gap (not counted)");
    packet(2, 64'h5555_AAAA_5555_AAAA, e);
    chk(u_dut.pkt_count == pc + 1 && u_dut.crc == e, "next packet after abandon starts a fresh CRC");

    // deactivation
    req = 1'b0;
    @(negedge clk);
    chk(ack === 1'b0, "active_ack drops one clock after active_req");
    pc = u_dut.pkt_count;
    packet(1, 64'h77, e);
    chk(u_dut.pkt_count == pc, "flits ignored after deactivation");

    // reset
    req = 1'b1;
    @(negedge clk); resetn = 1'b0;
    @(negedge clk);
    chk(ack === 1'b0 && u_dut.pkt_count == 0, "reset clears ack and packet count");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
