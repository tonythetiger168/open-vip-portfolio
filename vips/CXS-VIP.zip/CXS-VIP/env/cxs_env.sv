// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// cxs_env.sv -- CXS verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import cxs_defs_pkg::*;
  import cxs_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares driver-issued (expected) flits against
  // monitor-decoded (observed) flits from the stream waveform.
  class cxs_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(cxs_scoreboard)
    uvm_analysis_imp_exp #(cxs_transaction, cxs_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(cxs_transaction, cxs_scoreboard) obs_ap;

    cxs_transaction exp_q[$], obs_q[$];
    int unsigned match_cnt = 0, mismatches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(cxs_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(cxs_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        cxs_transaction e = exp_q.pop_front();
        cxs_transaction o = obs_q.pop_front();
        if (e.data == o.data && e.last == o.last && e.cntl == o.cntl)
          match_cnt++;
        else begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("cxs scoreboard: matches=%0d mismatches=%0d",
                match_cnt, mismatches), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class cxs_env extends uvm_env;
    `uvm_component_utils(cxs_env)
    cxs_agent      agt;
    cxs_scoreboard sb;
    cxs_checker    chk;
    cxs_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = cxs_agent::type_id::create("agt", this);
      sb  = cxs_scoreboard::type_id::create("sb", this);
      chk = cxs_checker::type_id::create("chk", this);
      cov = cxs_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
