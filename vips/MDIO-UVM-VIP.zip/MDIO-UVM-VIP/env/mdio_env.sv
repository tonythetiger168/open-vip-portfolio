// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_env.sv -- MDIO environment: reference-model scoreboard, checker, coverage

package mdio_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import mdio_defs_pkg::*;
  import mdio_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class mdio_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(mdio_scoreboard)
    uvm_analysis_imp_exp #(mdio_transaction, mdio_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(mdio_transaction, mdio_scoreboard) obs_ap;

    mdio_config cfg;
    mdio_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [15:0] c22 [32];               // Clause 22 read / write registers (0 = BMCR, 13 = MMD control)
    bit [15:0] mmd [3][64];
    bit [15:0] maddr [3];
    bit        init_done;
    function void phy_reset22();
      c22[0] = 16'h1140;
      for (int i = 4; i < 32; i++) c22[i] = 0;
    endfunction
    function bit [15:0] mmd_rd(bit [4:0] d, bit [15:0] a);
      if (a == 2) return 16'h0141;
      if (a == 3) return 16'h0DD0 + d;
      if (a == 5) return 16'h008A;
      if (a >= 64) return 0;
      return mmd[mdio_mmd_idx(d)][a];
    endfunction
    function void mmd_wr(bit [4:0] d, bit [15:0] a, bit [15:0] v);
      if (a == 2 || a == 3 || a == 5 || a >= 64) return;
      mmd[mdio_mmd_idx(d)][a] = v;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(mdio_config)::get(this, "", "cfg", cfg))
        cfg = mdio_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(mdio_transaction t);
      begin
        bit rd = t.c45 ? t.op[1] : (t.op == 2'b10);
        bit mine = (t.pre >= 32) && t.phyad == cfg.phy_addr &&
                   (t.c45 ? mdio_mmd_ok(t.regad) : (t.op == 2'b10 || t.op == 2'b01));
        bit [15:0] v = 16'hFFFF;
        if (!init_done) begin phy_reset22(); init_done = 1; end
        if (mine && t.c45) begin
          int k = mdio_mmd_idx(t.regad);
          case (t.op)
            2'b00: maddr[k] = t.wdata;
            2'b01: mmd_wr(t.regad, maddr[k], t.wdata);
            2'b11: v = mmd_rd(t.regad, maddr[k]);
            2'b10: begin v = mmd_rd(t.regad, maddr[k]); maddr[k]++; end
          endcase
        end else if (mine) begin
          bit [1:0] f = c22[13][15:14];
          bit [4:0] d = c22[13][4:0];
          if (rd) begin
            case (t.regad)
              0: v = c22[0];
              1: v = t.phy_status;
              2: v = 16'h0141;
              3: v = 16'h0DD1;
              14: if (!mdio_mmd_ok(d)) v = 0;
                  else if (f == 2'b00) v = maddr[mdio_mmd_idx(d)];
                  else begin v = mmd_rd(d, maddr[mdio_mmd_idx(d)]); if (f == 2'b10) maddr[mdio_mmd_idx(d)]++; end
              default: v = c22[t.regad];
            endcase
          end else begin
            case (t.regad)
              0: if (t.wdata[15]) phy_reset22(); else c22[0] = t.wdata;
              1, 2, 3: ;
              14: if (mdio_mmd_ok(d)) begin
                    if (f == 2'b00) maddr[mdio_mmd_idx(d)] = t.wdata;
                    else begin mmd_wr(d, maddr[mdio_mmd_idx(d)], t.wdata); if (f != 2'b01) maddr[mdio_mmd_idx(d)]++; end
                  end
              default: c22[t.regad] = t.wdata;
            endcase
          end
        end
        t.ta_ack = rd && mine;
        t.rdata  = rd ? v : 16'h0;
        t.mdio_status = c22[0];
      end
    endfunction

    function void write_exp(mdio_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(mdio_transaction t);
      mdio_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        mdio_transaction e = exp_q.pop_front();
        mdio_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("mdio scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class mdio_env extends uvm_env;
    `uvm_component_utils(mdio_env)
    mdio_agent      agt;
    mdio_scoreboard sb;
    mdio_checker    chk;
    mdio_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = mdio_agent     ::type_id::create("agt", this);
      sb  = mdio_scoreboard::type_id::create("sb",  this);
      chk = mdio_checker   ::type_id::create("chk", this);
      cov = mdio_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
