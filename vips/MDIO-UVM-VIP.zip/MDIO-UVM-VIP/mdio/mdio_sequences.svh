// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_sequences.svh -- MDIO sequences

// Random traffic: cfg.num_items constrained-random items.
class mdio_base_sequence extends uvm_sequence #(mdio_transaction);
  `uvm_object_utils(mdio_base_sequence)
  mdio_config cfg;

  function new(string name = "mdio_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = mdio_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "mdio_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class mdio_directed_sequence extends uvm_sequence #(mdio_transaction);
  `uvm_object_utils(mdio_directed_sequence)
  mdio_config cfg;

  function new(string name = "mdio_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function mdio_transaction item();
    item = mdio_transaction::type_id::create("req");
  endfunction

  task send(mdio_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    mdio_transaction t;
    // Clause 22: BMCR, BMSR, identifiers, read-only writes, reset
    t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 0; t.pre = 32; t.phy_status = 16'h7849; send(t);
    t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 0; t.pre = 32; t.wdata = 16'h0100; send(t);
    t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 1; t.pre = 32; t.phy_status = 16'h796D; send(t);
    for (int r = 2; r < 4; r++) begin
      t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = r; t.pre = 32; t.wdata = 16'hFFFF; send(t);
      t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = r; t.pre = 32; send(t);
    end
    t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 9; t.pre = 32; t.wdata = 16'h0300; send(t);
    t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 0; t.pre = 32; t.wdata = 16'h8000; send(t);
    t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 9; t.pre = 32; send(t);
    // Clause 45 on every MMD: address, write, read, post-read-increment
    for (int i = 0; i < 3; i++) begin
      bit [4:0] dv;
      dv = (i == 0) ? 5'd1 : (i == 1) ? 5'd3 : 5'd7;
      t = item(); t.c45 = 1; t.op = 2'b00; t.phyad = 5; t.regad = dv; t.pre = 32; t.wdata = 16'd8; send(t);
      for (int k = 0; k < 3; k++) begin t = item(); t.c45 = 1; t.op = 2'b01; t.phyad = 5; t.regad = dv; t.pre = 32; t.wdata = 16'hA000 + 16 * i + k; send(t); end
      t = item(); t.c45 = 1; t.op = 2'b10; t.phyad = 5; t.regad = dv; t.pre = 32; send(t);
      t = item(); t.c45 = 1; t.op = 2'b10; t.phyad = 5; t.regad = dv; t.pre = 32; send(t);
      t = item(); t.c45 = 1; t.op = 2'b11; t.phyad = 5; t.regad = dv; t.pre = 32; send(t);
      t = item(); t.c45 = 1; t.op = 2'b00; t.phyad = 5; t.regad = dv; t.pre = 32; t.wdata = 16'd3; send(t);
      t = item(); t.c45 = 1; t.op = 2'b11; t.phyad = 5; t.regad = dv; t.pre = 32; send(t);
    end
    // Clause 22 indirect MMD access, every function
    for (int f = 0; f < 4; f++) begin
      t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 13; t.pre = 32; t.wdata = 16'h0003; send(t);
      t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 14; t.pre = 32; t.wdata = 16'd20 + f; send(t);
      t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 13; t.pre = 32; t.wdata = {f[1:0], 14'h0003}; send(t);
      t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 14; t.pre = 32; t.wdata = 16'hBEE0 + f; send(t);
      t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 14; t.pre = 32; send(t);
      t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 14; t.pre = 32; send(t);
    end
    // indirect access to the identifiers and past the last register
    t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 13; t.pre = 32; t.wdata = 16'h4001; send(t);
    for (int a = 2; a < 66; a += 62) begin
      t = item(); t.c45 = 1; t.op = 2'b00; t.phyad = 5; t.regad = 1; t.pre = 32; t.wdata = a; send(t);
      t = item(); t.c45 = 0; t.op = 2'b01; t.phyad = 5; t.regad = 14; t.pre = 32; t.wdata = 16'h5A5A; send(t);
      t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 14; t.pre = 32; send(t);
    end
    t = item(); t.c45 = 1; t.op = 2'b00; t.phyad = 5; t.regad = 1; t.pre = 32; t.wdata = 16'd3; send(t);
    t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 14; t.pre = 32; send(t);
    // no response: other address, unimplemented MMD, undefined OP, short preamble
    t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 4; t.regad = 0; t.pre = 32; send(t);
    t = item(); t.c45 = 1; t.op = 2'b11; t.phyad = 5; t.regad = 2; t.pre = 32; send(t);
    t = item(); t.c45 = 0; t.op = 2'b00; t.phyad = 5; t.regad = 0; t.pre = 32; t.wdata = 16'h0040; send(t);
    t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 0; t.pre = 31; send(t);
    t = item(); t.c45 = 0; t.op = 2'b10; t.phyad = 5; t.regad = 0; t.pre = 40; send(t);
  endtask
endclass
