// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_sequences.svh -- MDIO sequences

// Random traffic: cfg.num_items constrained-random items.
class mdio_base_sequence extends uvm_sequence #(mdio_transaction);
  `uvm_object_utils(mdio_base_sequence)
  mdio_config cfg;

  function new(string name = "mdio_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = mdio_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "mdio_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class mdio_directed_sequence extends uvm_sequence #(mdio_transaction);
  `uvm_object_utils(mdio_directed_sequence)
  mdio_config cfg;

  function new(string name = "mdio_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function mdio_transaction item();
    item = mdio_transaction::type_id::create("req");
  endfunction

  task send(mdio_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    mdio_transaction t;
    t = item(); t.read = 0; t.phyad = 5; t.regad = 0; t.wdata = 16'h1200; t.phy_status = 16'h7849; send(t);
    t = item(); t.read = 1; t.phyad = 5; t.regad = 1; t.phy_status = 16'h796D; send(t);
    t = item(); t.read = 1; t.phyad = 5; t.regad = 2; t.phy_status = 16'hFFFF; send(t);
    t = item(); t.read = 0; t.phyad = 0; t.regad = 31; t.wdata = 16'hFFFF; t.phy_status = 16'h0; send(t);
    t = item(); t.read = 1; t.phyad = 31; t.regad = 3; t.phy_status = 16'hABCD; send(t);
  endtask
endclass
