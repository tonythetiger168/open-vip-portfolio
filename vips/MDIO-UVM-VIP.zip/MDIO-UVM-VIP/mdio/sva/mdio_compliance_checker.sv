// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_compliance_checker.sv -- MDIO concurrent assertion checks (bindable)

module mdio_compliance_checker
  (input logic clk, input logic rst_n, input mdc, input mdio, input [15:0] phy_status, input [15:0] mdio_status);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(mdio_status))
    else $error("MDIO: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> mdio_status == '0)
    else $error("MDIO: output not in reset value");
  // status mirrors the PHY input register while idle
  assert property (@(posedge clk) disable iff (!rst_n) mdio_status == $past(phy_status))
    else $error("MDIO: status does not mirror phy_status");
  cover property (@(posedge clk) disable iff (!rst_n) (mdio_status != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (mdio == 1'b0));
endmodule
