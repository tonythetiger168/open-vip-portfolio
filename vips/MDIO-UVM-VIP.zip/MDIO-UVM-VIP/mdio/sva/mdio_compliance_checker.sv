// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_compliance_checker.sv -- MDIO concurrent assertion checks (bindable)

module mdio_compliance_checker
  (input logic clk, input logic rst_n, input logic mdc, input logic mdio, input logic [15:0] phy_status, input logic [15:0] mdio_status);

  logic mdc_q;
  always @(posedge clk or negedge rst_n) if (!rst_n) mdc_q <= 1'b0; else mdc_q <= mdc;
  // MDIO is set up before the MDC rising edge (station: while MDC is low; PHY: one clock after the rise)
  assert property (@(posedge clk) disable iff (!rst_n) mdc && !mdc_q |-> $stable(mdio))
    else $error("MDIO: MDIO changed on an MDC rising edge");
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(mdio_status))
    else $error("MDIO: X on the PHY's BMCR mirror");
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(mdc))
    else $error("MDIO: X on MDC");
  cover property (@(posedge clk) disable iff (!rst_n) mdc && !mdc_q && mdio == 1'b0 ##2 mdc && !mdc_q && mdio == 1'b0);
  cover property (@(posedge clk) disable iff (!rst_n) $changed(mdio_status));
endmodule
