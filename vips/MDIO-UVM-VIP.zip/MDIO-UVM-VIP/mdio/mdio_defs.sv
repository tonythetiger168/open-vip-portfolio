// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_defs.sv -- MDIO shared type definitions

package mdio_defs_pkg;

  typedef enum bit [1:0] {MDIO_OK, MDIO_ERR} mdio_status_e;

  // Clause 45 MMDs of the PHY
  function automatic bit mdio_mmd_ok(bit [4:0] d); return d == 5'd1 || d == 5'd3 || d == 5'd7; endfunction
  function automatic int mdio_mmd_idx(bit [4:0] d); return (d == 5'd1) ? 0 : (d == 5'd3) ? 1 : 2; endfunction

endpackage
