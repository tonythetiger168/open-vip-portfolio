// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_coverage.svh -- MDIO functional coverage

class mdio_coverage extends uvm_subscriber #(mdio_transaction);
  `uvm_component_utils(mdio_coverage)
  mdio_config cfg;
  mdio_transaction tr;

  covergroup mdio_cg;
    cp_op  : coverpoint tr.read { bins write = {0}; bins read = {1}; }
    cp_reg : coverpoint tr.regad { bins bmcr = {0}; bins bmsr = {1}; bins id = {[2:3]}; bins other = default; }
    cp_phy : coverpoint tr.phyad { bins five = {5}; bins other = default; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    mdio_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(mdio_config)::get(this, "", "cfg", cfg))
      cfg = mdio_config::type_id::create("cfg");
  endfunction

  function void write(mdio_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    mdio_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("MDIO coverage: %0.1f%%", mdio_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
