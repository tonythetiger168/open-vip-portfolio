// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_coverage.svh -- MDIO functional coverage

class mdio_coverage extends uvm_subscriber #(mdio_transaction);
  `uvm_component_utils(mdio_coverage)
  mdio_config cfg;
  mdio_transaction tr;

  covergroup mdio_cg;
    cp_st    : coverpoint tr.c45 { bins c22 = {0}; bins c45 = {1}; }
    cp_op22  : coverpoint tr.op iff (!tr.c45 && tr.ta_ack | (tr.op == 2'b01)) { bins write = {2'b01}; bins read = {2'b10}; }
    cp_op45  : coverpoint tr.op iff (tr.c45) { bins addr = {2'b00}; bins write = {2'b01}; bins read = {2'b11}; bins pria = {2'b10}; }
    cp_reg   : coverpoint tr.regad iff (!tr.c45) { bins bmcr = {0}; bins bmsr = {1}; bins id = {[2:3]}; bins mmdctl = {13}; bins mmdad = {14}; bins other = default; }
    cp_dev   : coverpoint tr.regad iff (tr.c45) { bins pma = {1}; bins pcs = {3}; bins an = {7}; bins none = default; }
    cp_fn    : coverpoint tr.wdata[15:14] iff (!tr.c45 && tr.op == 2'b01 && tr.regad == 13) { bins addr = {0}; bins data = {1}; bins inc = {2}; bins incw = {3}; }
    cp_ack   : coverpoint tr.ta_ack iff (tr.c45 ? tr.op[1] : (tr.op == 2'b10)) { bins none = {0}; bins ack = {1}; }
    cp_pre   : coverpoint tr.pre { bins short_ = {31}; bins min = {32}; bins long_ = {[33:63]}; }
    cp_rst   : coverpoint tr.wdata[15] iff (!tr.c45 && tr.op == 2'b01 && tr.regad == 0) { bins rst = {1}; bins norm = {0}; }
    x_op_dev : cross cp_op45, cp_dev;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    mdio_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(mdio_config)::get(this, "", "cfg", cfg))
      cfg = mdio_config::type_id::create("cfg");
  endfunction

  function void write(mdio_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    mdio_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("MDIO coverage: %0.1f%%", mdio_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
