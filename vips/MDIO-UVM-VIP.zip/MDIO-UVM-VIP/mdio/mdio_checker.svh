// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_checker.svh -- MDIO protocol invariant checker (scoreboard-adjacent)

class mdio_checker extends uvm_component;
  `uvm_component_utils(mdio_checker)
  uvm_analysis_imp #(mdio_transaction, mdio_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  mdio_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    void'(uvm_config_db#(mdio_config)::get(this, "*", "cfg", cfg));
  endfunction

  function void write(mdio_transaction t);
    if (cfg != null && !cfg.checks_enable) return;
    n_checked++;
    // protocol sanity: every sampled item must carry a non-trivial tag window
    if (t.tag == 32'hDEAD_BEEF) begin
      n_violations++;
      `uvm_error("CHK", $sformatf("MDIO checker violation: %s", t.convert2string()))
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("MDIO checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
