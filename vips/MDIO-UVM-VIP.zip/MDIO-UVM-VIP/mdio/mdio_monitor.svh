// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_monitor.svh -- MDIO monitor: decodes clause 22 frames from MDIO sampled on MDC rising edges

class mdio_monitor extends uvm_monitor;
  `uvm_component_utils(mdio_monitor)

  virtual mdio_if vif;
  uvm_analysis_port #(mdio_transaction) ap;
  mdio_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual mdio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "mdio: virtual interface not set")
    if (!uvm_config_db#(mdio_config)::get(this, "", "cfg", cfg))
      cfg = mdio_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [63:0] sh = 0;
      int unsigned ones = 0, n = 0;
      bit mdc_d = 0, in_frame = 0;
      mdio_transaction t;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.mdc && !mdc_d) begin           // MDC rising edge: one bit
          bit b = (vif.mon_cb.mdio !== 1'b0);
          if (!in_frame) begin
            // ST (01) after at least 32 preamble ones
            if (ones >= 32 && b == 1'b0) begin in_frame = 1; n = 1; sh = 0; end
            ones = b ? ones + 1 : 0;
          end else begin
            sh = {sh[62:0], b};
            n++;
            if (n == 32) begin                        // ST OP PHYAD REGAD TA DATA
              t = mdio_transaction::type_id::create("t");
              if (sh[30] != 1'b1) `uvm_error("MON", "MDIO start code is not 01")
              t.read  = (sh[29:28] == 2'b10);
              if (sh[29:28] != 2'b10 && sh[29:28] != 2'b01) `uvm_error("MON", "MDIO OP code is not read/write")
              t.phyad = sh[27:23];
              t.regad = sh[22:18];
              t.ta    = sh[17:16];
              t.ta_ack = t.read && (sh[16] == 1'b0);
              if (t.read) t.rdata = sh[15:0]; else t.wdata = sh[15:0];
              t.phy_status = vif.mon_cb.phy_status;
              in_frame = 0; ones = 0;
              repeat (3) @(vif.mon_cb);
              t.mdio_status = vif.mon_cb.mdio_status;
              publish(t);
            end
          end
        end
        mdc_d = vif.mon_cb.mdc;
      end
    end
  endtask

  function void publish(mdio_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
