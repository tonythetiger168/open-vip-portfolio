// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_if.sv -- MDIO interface

interface mdio_if (input logic clk);
  logic rst_n;

  logic mdc;
  tri0 mdio;
  logic [15:0] phy_status;
  logic [15:0] mdio_status;

  modport DUT (input clk, rst_n, mdc, phy_status, output mdio_status, inout mdio);
  modport DRV (input clk, rst_n, mdio_status, mdio, output mdc, phy_status);
  modport MON (input clk, rst_n, mdc, mdio, phy_status, mdio_status);

  clocking drv_cb @(posedge clk);
    input rst_n, mdc, mdio, phy_status, mdio_status;
    output mdc, phy_status;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, mdc, mdio, phy_status, mdio_status;
  endclocking
endinterface
