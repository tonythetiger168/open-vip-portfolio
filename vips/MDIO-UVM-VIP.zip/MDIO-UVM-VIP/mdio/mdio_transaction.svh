// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_transaction.svh -- MDIO transaction

class mdio_transaction extends uvm_sequence_item;
  `uvm_object_utils(mdio_transaction)

  rand bit mdc;
  rand bit [15:0] phy_status;
  bit [15:0] mdio_status_o;
  bit mdio_o;
  bit [31:0] tag;

  function new(string name = "mdio_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    mdio_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mdc = rhs_.mdc;
    phy_status = rhs_.phy_status;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    mdio_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           mdc == rhs_.mdc &&
           phy_status == rhs_.phy_status;
  endfunction

  function string convert2string();
    return $sformatf("MDIO{tag=%0h mdc=0x%0h phy_status=0x%0h}", tag, mdc, phy_status);
  endfunction
endclass
