// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_transaction.svh -- MDIO transaction

class mdio_transaction extends uvm_sequence_item;
  `uvm_object_utils(mdio_transaction)

  // request (driven by the agent)
  rand bit c45;
  rand bit [1:0] op;
  rand bit [4:0] phyad;
  rand bit [4:0] regad;
  rand bit [15:0] wdata;
  rand bit [15:0] phy_status;
  // response (returned by the DUT)
  bit [15:0] rdata;
  bit ta_ack;
  bit [15:0] mdio_status;
  // bookkeeping (not compared)
  bit [1:0] ta;
  rand bit [5:0] pre;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_pre  { pre dist { 6'd32 := 8, [6'd33:6'd40] :/ 1, 6'd31 := 1 }; }
  constraint c_phy  { phyad dist { 5'h05 := 8, [0:4] :/ 1, [6:31] :/ 1 }; }
  constraint c_c22  { !c45 -> op dist { 2'b10 := 5, 2'b01 := 4, 2'b00 := 1 };
                      !c45 -> regad dist { [0:3] :/ 4, [13:14] :/ 6, [4:12] :/ 2, [15:31] :/ 2 }; }
  constraint c_c45  { c45 -> regad dist { 5'd1 := 3, 5'd3 := 3, 5'd7 := 3, [0:31] :/ 1 }; }
  constraint c_wd   { (c45 && op == 2'b00) -> wdata[15:6] dist { 0 := 9, [1:1023] :/ 1 };
                      (!c45 && regad == 0) -> wdata[15] dist { 0 := 9, 1 := 1 };
                      (!c45 && regad == 13) -> wdata[4:0] inside {1, 3, 7, 2}; }

  function new(string name = "mdio_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    mdio_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    c45 = rhs_.c45;
    op = rhs_.op;
    phyad = rhs_.phyad;
    regad = rhs_.regad;
    wdata = rhs_.wdata;
    phy_status = rhs_.phy_status;
    rdata = rhs_.rdata;
    ta_ack = rhs_.ta_ack;
    mdio_status = rhs_.mdio_status;
    ta = rhs_.ta;
    pre = rhs_.pre;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    mdio_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (c45 != rhs_.c45) return 0;
    if (op != rhs_.op) return 0;
    if (phyad != rhs_.phyad) return 0;
    if (regad != rhs_.regad) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (phy_status != rhs_.phy_status) return 0;
    if (rdata != rhs_.rdata) return 0;
    if (ta_ack != rhs_.ta_ack) return 0;
    if (mdio_status != rhs_.mdio_status) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(mdio_transaction rhs_);
    if (c45 != rhs_.c45) return 0;
    if (op != rhs_.op) return 0;
    if (phyad != rhs_.phyad) return 0;
    if (regad != rhs_.regad) return 0;
    if (wdata != rhs_.wdata) return 0;
    if (phy_status != rhs_.phy_status) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("MDIO{tag=%0d c45=0x%0h op=0x%0h phyad=0x%0h regad=0x%0h wdata=0x%0h phy_status=0x%0h rdata=0x%0h ta_ack=0x%0h mdio_status=0x%0h}", tag, c45, op, phyad, regad, wdata, phy_status, rdata, ta_ack, mdio_status);
  endfunction
endclass
