// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// mdio_driver.svh -- MDIO driver: preamble, ST, OP, PHYAD, REGAD, TA, DATA; MDIO set while MDC is low

class mdio_driver extends uvm_driver #(mdio_transaction);
  `uvm_component_utils(mdio_driver)

  uvm_analysis_port #(mdio_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual mdio_if vif;
  mdio_config cfg;

  bit sampled;   // MDIO at the last MDC rising edge

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual mdio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "mdio: virtual interface not set")
    if (!uvm_config_db#(mdio_config)::get(this, "", "cfg", cfg))
      cfg = mdio_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    mdio_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.mdc <= 1'b0; vif.drv_cb.mdio_oe <= 1'b0; vif.drv_cb.mdio_o <= 1'b1; vif.drv_cb.phy_status <= '0;
  endtask

  task drive_item(mdio_transaction t);
    @(vif.drv_cb);
    vif.drv_cb.phy_status <= t.phy_status;
    repeat (32) mdc_bit(1'b1, 1'b1);               // preamble
    mdc_bit(1'b1, 1'b0); mdc_bit(1'b1, 1'b1);      // ST = 01
    mdc_bit(1'b1, t.read); mdc_bit(1'b1, !t.read); // OP: 10 read, 01 write
    for (int i = 4; i >= 0; i--) mdc_bit(1'b1, t.phyad[i]);
    for (int i = 4; i >= 0; i--) mdc_bit(1'b1, t.regad[i]);
    if (t.read) begin
      mdc_bit(1'b0, 1'b1);                         // TA: Z
      mdc_bit(1'b0, 1'b1); t.ta_ack = !sampled;    // TA: 0 from the PHY
      for (int i = 15; i >= 0; i--) begin mdc_bit(1'b0, 1'b1); t.rdata[i] = sampled; end
    end else begin
      mdc_bit(1'b1, 1'b1); mdc_bit(1'b1, 1'b0);    // TA = 10
      for (int i = 15; i >= 0; i--) mdc_bit(1'b1, t.wdata[i]);
      t.ta_ack = 0;
      t.rdata = 0;
    end
    vif.drv_cb.mdio_oe <= 1'b0;
    repeat (2) @(vif.drv_cb);
    t.mdio_status = vif.drv_cb.mdio_status;
  endtask

  // one MDC period: MDC low with MDIO set up, then MDC high (the PHY samples
  // on the rising edge, the station samples a PHY-driven bit there too)
  task mdc_bit(bit drive, bit b);
    vif.drv_cb.mdc <= 1'b0;
    vif.drv_cb.mdio_oe <= drive;
    vif.drv_cb.mdio_o <= b;
    @(vif.drv_cb);
    vif.drv_cb.mdc <= 1'b1;
    @(vif.drv_cb);
    sampled = vif.drv_cb.mdio;
  endtask
endclass
