// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (MDIO DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened mdio_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic mdc = 0, mdo = 1, moe = 0;
  logic [15:0] phy_status = 16'h7849;
  wire [15:0] mdio_status;
  tri1 mdio;
  assign mdio = moe ? mdo : 1'bz;

  always #5 clk = ~clk;

  mdio_model u_dut (.clk(clk), .rst_n(rst_n), .mdc(mdc), .mdio(mdio), .phy_status(phy_status), .mdio_status(mdio_status));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic smp;
  // one MDC period (4 clocks), MDIO set while MDC is low, sampled at the rise
  task automatic bitp(input bit drv, input bit b);
    @(negedge clk); mdc = 0; moe = drv; mdo = b;
    @(negedge clk);
    @(negedge clk); smp = (mdio !== 1'b0); mdc = 1;   // value the PHY sees at the rise
    @(negedge clk);
  endtask
  logic [15:0] rv; logic ack;
  task automatic frame(input int pre, input bit [1:0] stc, input bit [1:0] op, input bit [4:0] pa, input bit [4:0] ra,
                       input bit [15:0] wd, input bit rd);
    for (int i = 0; i < pre; i++) bitp(1, 1);
    bitp(1, stc[1]); bitp(1, stc[0]); bitp(1, op[1]); bitp(1, op[0]);
    for (int i = 4; i >= 0; i--) bitp(1, pa[i]);
    for (int i = 4; i >= 0; i--) bitp(1, ra[i]);
    if (rd) begin
      bitp(0, 1); chk(smp == 1'b1, "first TA bit left high");
      bitp(0, 1); ack = !smp;
      for (int i = 15; i >= 0; i--) begin bitp(0, 1); rv[i] = smp; end
    end else begin
      bitp(1, 1); bitp(1, 0);
      for (int i = 15; i >= 0; i--) bitp(1, wd[i]);
      ack = 0; rv = 0;
    end
    moe = 0; repeat (6) @(negedge clk);           // idle, MDC low: no extra preamble bit
  endtask
  task automatic r22(input bit [4:0] r); frame(32, 2'b01, 2'b10, 5, r, 0, 1); endtask
  task automatic w22(input bit [4:0] r, input bit [15:0] d); frame(32, 2'b01, 2'b01, 5, r, d, 0); endtask
  task automatic a45(input bit [4:0] d, input bit [15:0] a); frame(32, 2'b00, 2'b00, 5, d, a, 0); endtask
  task automatic w45(input bit [4:0] d, input bit [15:0] v); frame(32, 2'b00, 2'b01, 5, d, v, 0); endtask
  task automatic r45(input bit [4:0] d); frame(32, 2'b00, 2'b11, 5, d, 0, 1); endtask
  task automatic p45(input bit [4:0] d); frame(32, 2'b00, 2'b10, 5, d, 0, 1); endtask

  initial begin
    repeat (3) @(posedge clk);
    chk(mdio === 1'b1 && mdio_status == 16'h1140, "released bus, BMCR 0x1140 in reset");
    moe = 1; mdo = 0; #1; chk(mdio === 1'b0, "the PHY does not drive MDIO in reset"); moe = 0;
    rst_n = 1;
    repeat (2) @(posedge clk);

    // Clause 22 registers
    r22(0); chk(ack && rv == 16'h1140, $sformatf("BMCR reset value (%h)", rv));
    phy_status = 16'h796D; r22(1); chk(ack && rv == 16'h796D, "BMSR = phy_status pins");
    r22(2); chk(ack && rv == 16'h0141, "PHY identifier 1");
    r22(3); chk(ack && rv == 16'h0DD1, "PHY identifier 2");
    w22(2, 16'hFFFF); w22(3, 16'h0); w22(1, 16'h0);
    r22(2); chk(rv == 16'h0141, "identifier 1 is read-only");
    r22(3); chk(rv == 16'h0DD1, "identifier 2 is read-only");
    r22(1); chk(rv == 16'h796D, "BMSR is read-only");
    w22(0, 16'h0100); chk(mdio_status == 16'h0100, "BMCR write shows on mdio_status");
    r22(0); chk(rv == 16'h0100, "BMCR read back");
    w22(4, 16'h01E1); w22(31, 16'hC0DE); w22(13, 16'h0003); w22(12, 16'h1234);
    r22(4); chk(rv == 16'h01E1, "register 4 read / write");
    r22(31); chk(rv == 16'hC0DE, "register 31 read / write");
    r22(5); chk(rv == 16'h0, "register 5 still 0");
    // BMCR reset: registers 0 and 4..31, self-clearing
    w22(0, 16'h8000);
    r22(0); chk(rv == 16'h1140 && mdio_status == 16'h1140, "BMCR reset: back to 0x1140, bit 15 self-clears");
    r22(4); chk(rv == 16'h0, "BMCR reset clears register 4");
    r22(31); chk(rv == 16'h0, "BMCR reset clears register 31");
    r22(12); chk(rv == 16'h0, "BMCR reset clears register 12");
    r22(13); chk(rv == 16'h0, "BMCR reset clears the MMD control register");
    r22(1); chk(rv == 16'h796D, "BMSR unaffected");
    w22(0, 16'h7FFF); chk(mdio_status == 16'h7FFF, "BMCR without bit 15 is a plain write");

    // Clause 45: address, write, read, post-read-increment, on each MMD
    a45(1, 16'd10); w45(1, 16'hAA01); a45(3, 16'd10); w45(3, 16'hAA03); a45(7, 16'd10); w45(7, 16'hAA07);
    a45(1, 16'd10); r45(1); chk(ack && rv == 16'hAA01, "MMD 1 register 10");
    a45(3, 16'd10); r45(3); chk(ack && rv == 16'hAA03, "MMD 3 register 10: own storage");
    r45(7); chk(ack && rv == 16'hAA07, "MMD 7 keeps its own address register");
    a45(1, 16'd11); w45(1, 16'h1111); w45(1, 16'h2222);
    r45(1); chk(rv == 16'h2222, "a write does not move the address");
    a45(1, 16'd10); p45(1); chk(rv == 16'hAA01, "post-read-increment reads at the address");
    p45(1); chk(rv == 16'h2222, "then the next register");
    r45(1); chk(rv == 16'h0, "address now 12");
    a45(1, 16'd2); r45(1); chk(rv == 16'h0141, "MMD device identifier 1");
    a45(3, 16'd3); r45(3); chk(rv == 16'h0DD3, "MMD 3 device identifier 2");
    a45(7, 16'd3); r45(7); chk(rv == 16'h0DD7, "MMD 7 device identifier 2");
    a45(7, 16'd5); r45(7); chk(rv == 16'h008A, "devices in package: MMD 1, 3, 7");
    w45(7, 16'h0); r45(7); chk(rv == 16'h008A, "devices in package is read-only");
    a45(3, 16'd2); w45(3, 16'h0); r45(3); chk(rv == 16'h0141, "identifier is read-only");
    a45(1, 16'd63); w45(1, 16'h6363); r45(1); chk(rv == 16'h6363, "register 63 is the last one");
    a45(1, 16'd64); w45(1, 16'h6464); r45(1); chk(ack && rv == 16'h0, "register 64 reads 0");
    a45(1, 16'd0); r45(1); chk(rv == 16'h0, "register 64 write did not alias register 0");
    a45(1, 16'hFFFF); p45(1); a45(1, 16'd0); r45(1); chk(rv == 16'h0, "address 0xFFFF wraps cleanly");
    a45(1, 16'd63); p45(1); p45(1); chk(rv == 16'h0, "post-increment past 63");
    // unimplemented MMD / other port: no response, nothing changes
    a45(2, 16'd10); r45(2); chk(!ack && rv == 16'hFFFF, "MMD 2 is not implemented: no response");
    frame(32, 2'b00, 2'b11, 4, 1, 0, 1); chk(!ack && rv == 16'hFFFF, "other port address: no response");
    frame(32, 2'b00, 2'b00, 4, 1, 16'd11, 0); r45(1); chk(rv == 16'h0, "another port's address frame is ignored");
    a45(1, 16'd10); r45(1); chk(rv == 16'hAA01, "MMD 1 register 10 unchanged");

    // Clause 22 indirect MMD access (registers 13 / 14)
    w22(13, 16'h0003); w22(14, 16'd20);                   // function 00: address 20 of MMD 3
    r22(14); chk(rv == 16'd20, "register 14 reads the MMD address");
    w22(13, 16'h4003); w22(14, 16'hD001); w22(14, 16'hD002);
    r22(14); chk(rv == 16'hD002, "function 01: data, no increment");
    w22(13, 16'h8003); w22(14, 16'hE014); w22(14, 16'hE015);   // function 10: increments on writes
    w22(13, 16'h0003); r22(14); chk(rv == 16'd22, "function 10: two writes moved the address to 22");
    w22(14, 16'd20); w22(13, 16'h8003);
    r22(14); chk(rv == 16'hE014, "function 10: read at 20");
    r22(14); chk(rv == 16'hE015, "function 10: read moved to 21");
    w22(13, 16'hC003); r22(14); chk(rv == 16'h0, "function 11: read at 22");
    r22(14); chk(rv == 16'h0, "function 11: reads do not increment (still 22)");
    w22(14, 16'hF016); w22(13, 16'h0003); r22(14); chk(rv == 16'd23, "function 11: a write increments");
    a45(3, 16'd20); r45(3); chk(rv == 16'hE014, "Clause 45 sees the indirect writes");
    a45(3, 16'd22); r45(3); chk(rv == 16'hF016, "indirect write at 22");
    w22(13, 16'h4007); a45(7, 16'd5); r22(14); chk(rv == 16'h008A, "indirect read of an MMD 7 read-only register");
    w22(13, 16'h4001); a45(1, 16'd2); r22(14); chk(rv == 16'h0141, "indirect read of the MMD 1 identifier 1");
    a45(1, 16'd3); r22(14); chk(rv == 16'h0DD1, "indirect read of the MMD 1 identifier 2");
    a45(1, 16'd64); w22(14, 16'h5A5A); r22(14); chk(rv == 16'h0, "indirect access past register 63: reads 0, write ignored");
    a45(1, 16'd0); r22(14); chk(rv == 16'h0, "the write at 64 did not alias register 0");
    w22(13, 16'h4002); r22(14); chk(ack && rv == 16'h0, "indirect access to an MMD that is not implemented reads 0");
    w22(14, 16'h1234); w22(13, 16'h0002); r22(14); chk(rv == 16'h0, "and ignores writes");
    w22(13, 16'h4007); w22(14, 16'h0); r22(14); chk(rv == 16'h008A, "indirect write to a read-only register ignored");
    w22(13, 16'h8007); w22(14, 16'h0); w22(13, 16'h0007); r22(14); chk(rv == 16'd6, "but the address still increments");

    // no response: other PHY address, undefined OP, short preamble; long preamble is fine
    frame(32, 2'b01, 2'b10, 4, 0, 0, 1); chk(!ack && rv == 16'hFFFF, "PHY address 4: no response");
    frame(32, 2'b01, 2'b10, 6, 0, 0, 1); chk(!ack, "PHY address 6: no response");
    frame(32, 2'b01, 2'b00, 5, 0, 16'h0040, 0); chk(mdio_status == 16'h7FFF, "Clause 22 OP 00 ignored");
    frame(32, 2'b01, 2'b11, 5, 0, 16'h0040, 0); chk(mdio_status == 16'h7FFF, "Clause 22 OP 11 ignored");
    frame(32, 2'b01, 2'b01, 4, 0, 16'h0040, 0); chk(mdio_status == 16'h7FFF, "write to another PHY ignored");
    frame(31, 2'b01, 2'b10, 5, 0, 0, 1); chk(!ack, "31-bit preamble: ignored");
    frame(31, 2'b01, 2'b01, 5, 0, 16'h0040, 0); chk(mdio_status == 16'h7FFF, "31-bit preamble write ignored");
    frame(45, 2'b01, 2'b10, 5, 0, 0, 1); chk(ack && rv == 16'h7FFF, "45-bit preamble accepted");
    frame(70, 2'b01, 2'b10, 5, 0, 0, 1); chk(ack && rv == 16'h7FFF, "a preamble longer than 63 still counts");
    frame(32, 2'b11, 2'b10, 5, 0, 0, 1); chk(!ack, "ST 11 is not a frame");
    frame(32, 2'b10, 2'b10, 5, 0, 0, 1); chk(!ack, "ST 10 is not a frame");

    // reset
    rst_n = 0; repeat (2) @(posedge clk);
    chk(mdio === 1'b1 && mdio_status == 16'h1140, "reset");
    rst_n = 1; repeat (2) @(posedge clk);
    a45(1, 16'd10); r45(1); chk(rv == 16'h0, "reset clears MMD 1");
    r45(3); chk(rv == 16'h0, "reset clears the MMD 3 address and data");
    a45(7, 16'd0); r45(7); chk(rv == 16'h0, "reset clears MMD 7 register 0");
    r22(4); chk(rv == 16'h0, "reset clears register 4");
    r22(1); chk(rv == phy_status, "BMSR after reset");
    w22(13, 16'h0007); r22(14); chk(rv == 16'h0, "reset clears the MMD 7 address");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #4000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
