// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (MDIO PHY status and bus behaviour)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened mdio_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic mdc = 1'b0;
  tri1  mdio;
  logic [15:0] phy_status = 16'h0000;
  wire  [15:0] mdio_status;

  always #5 clk = ~clk;

  mdio_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .mdc(mdc), .mdio(mdio),
    .phy_status(phy_status), .mdio_status(mdio_status)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    repeat (8) step();
    chk(mdio_status === 16'h0000, "mdio_status reset to zero");
    chk(mdio === 1'b1, "mdio pulled high (tri1) when undriven");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // status register mirrors the PHY input
    @(negedge clk); phy_status = 16'hABCD;
    step(); step();
    chk(mdio_status === 16'hABCD, "mdio_status mirrors phy_status");

    // toggle MDC: idle bus stays released
    repeat (8) begin
      @(negedge clk); mdc = ~mdc;
      step();
      chk(mdio === 1'b1, "mdio released while idle");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
