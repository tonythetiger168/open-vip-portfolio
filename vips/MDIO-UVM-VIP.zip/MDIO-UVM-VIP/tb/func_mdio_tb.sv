// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_mdio_tb.sv -- IEEE 802.3 Clause 22 functional test for the MDIO PHY
// model (mdio_model, flattened by smoke/flatten.py); complements
// smoke_func_tb.sv (status mirror, idle bus).
// Run: python3 tools/run_func_tests.py MDIO-UVM-VIP
//
// Model contract (from tb/top_tb.sv): mdio_status mirrors phy_status one
// clock later; the PHY (address 5) answers a read with phy_status on MDIO.
// Frames here follow Clause 22: 32-bit preamble of ones, ST 01, OP 10
// (read) / 01 (write), PHYAD, REGAD, turnaround, 16 data bits, MSB first,
// MDIO sampled by the PHY on the MDC rising edge (MDC = 8 clocks).
//
// Model defect (XFAIL): the model shifts MDIO in on every clock while MDC
// is low (not on MDC edges) and only starts a response when the bits 16..24
// clocks back read 0_1100_0101 at a fixed counter phase, which a
// preamble-led frame never produces, so a read is never answered. The VIP
// driver itself only toggles MDC and phy_status (no management frames).

`timescale 1ns/1ps
module func_mdio_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic clk = 1'b0, rst_n = 1'b0, mdc = 1'b0;
  logic sta_oe = 1'b0, sta_o = 1'b1;
  tri1  mdio;
  logic [15:0] phy_status = 16'h0000;
  wire  [15:0] mdio_status;

  assign mdio = sta_oe ? sta_o : 1'bz;
  always #5 clk = ~clk;

  mdio_model u_dut (
    .clk(clk), .rst_n(rst_n), .mdc(mdc), .mdio(mdio),
    .phy_status(phy_status), .mdio_status(mdio_status)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  // PHY driving MDIO at any time (station released the line)
  int phy_drive;
  always @(posedge clk) if (!sta_oe && u_dut.drive) phy_drive++;

  // one MDC cycle: MDIO set while MDC low, PHY samples on the rising edge
  task automatic mdc_bit(input bit v, input bit oe);
    sta_oe = oe; sta_o = v;
    mdc = 1'b0; repeat (4) @(negedge clk);
    mdc = 1'b1; repeat (4) @(negedge clk);
  endtask
  // station read cycle: sample on MDC rising edge
  task automatic mdc_sample(output bit v);
    sta_oe = 1'b0;
    mdc = 1'b0; repeat (4) @(negedge clk);
    mdc = 1'b1; v = mdio; repeat (4) @(negedge clk);
  endtask

  logic [15:0] rdata;
  bit          ta0, released;
  task automatic frame(input bit read, input [4:0] phy, input [4:0] reg_a, input [15:0] wdata = '0);
    for (int i = 0; i < 32; i++) mdc_bit(1'b1, 1'b1);                   // preamble
    mdc_bit(0, 1); mdc_bit(1, 1);                                          // ST
    mdc_bit(read, 1); mdc_bit(!read, 1);                                   // OP
    for (int i = 4; i >= 0; i--) mdc_bit(phy[i], 1);
    for (int i = 4; i >= 0; i--) mdc_bit(reg_a[i], 1);
    if (read) begin
      bit z;
      mdc_sample(z);                                                       // TA: Z
      mdc_sample(ta0);                                                     // TA: 0
      for (int i = 15; i >= 0; i--) begin mdc_sample(z); rdata[i] = z; end
    end else begin
      mdc_bit(1, 1); mdc_bit(0, 1);                                        // TA: 10
      for (int i = 15; i >= 0; i--) mdc_bit(wdata[i], 1);
    end
    sta_oe = 1'b0;
    mdc_bit(1, 0); mdc_bit(1, 0);
    released = (mdio === 1'b1);
  endtask

  initial begin
    repeat (3) @(negedge clk);
    chk(mdio_status === 16'h0 && mdio === 1'b1, "reset: status 0, MDIO released (pulled up)");
    rst_n = 1'b1;
    @(negedge clk);

    // status mirror: one clock latency, every bit
    begin
      int bad;
      bad = 0;
      for (int i = 0; i < 16; i++) begin
        phy_status = 16'h1 << i;
        @(negedge clk);
        if (mdio_status !== phy_status) bad++;
      end
      chk(bad == 0, "mdio_status mirrors each phy_status bit");
    end
    phy_status = 16'h5A3C;
    @(posedge clk); #1;
    chk(mdio_status === 16'h5A3C, "mdio_status updates on the next clock edge");

    // writes and reads to other PHY addresses: PHY stays off the bus
    phy_drive = 0;
    frame(0, 5'd5, 5'd0, 16'h1234);
    chk(phy_drive == 0 && released, "write frame: PHY never drives MDIO");
    frame(1, 5'd6, 5'd1);
    chk(phy_drive == 0 && released, "read of another PHY address: no response");

    // read of PHY 5
    phy_status = 16'h796D;
    frame(1, 5'd5, 5'd1);
    chk_xfail(ta0 === 1'b0 && rdata === 16'h796D, "read of PHY 5: TA 0 then phy_status, MSB first");
    chk(released, "MDIO released after the read frame");

    // reset clears status
    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(mdio_status === 16'h0 && u_dut.drive === 1'b0, "reset clears status and the response state");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
