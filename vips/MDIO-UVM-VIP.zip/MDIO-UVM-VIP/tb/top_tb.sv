// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- MDIO testbench top with a functional MDIO DUT model

`ifndef MDIO_TB_SV
`define MDIO_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import mdio_defs_pkg::*;
import mdio_pkg::*;
import mdio_env_pkg::*;
import mdio_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  mdio_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  mdio_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .mdc(vif.mdc), .mdio(vif.mdio),
    .phy_status(vif.phy_status), .mdio_status(vif.mdio_status)
  );

  // Concurrent protocol checks
  mdio_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .mdc(vif.mdc), .mdio(vif.mdio), .phy_status(vif.phy_status), .mdio_status(vif.mdio_status)
  );

  initial begin
    uvm_config_db#(virtual mdio_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module mdio_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        mdc,
  inout  logic        mdio,
  input  logic [15:0] phy_status,
  output logic [15:0] mdio_status
);
  logic [31:0] sh;
  logic [4:0]  bcnt;
  logic        drive;
  logic [15:0] sreg;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sh          <= '0;
      bcnt        <= '0;
      drive       <= 1'b0;
      sreg        <= '0;
      mdio_status <= '0;
    end else begin
      mdio_status <= phy_status;
      if (!drive) begin
        if (!mdc) begin
          sh   <= {sh[30:0], mdio};
          bcnt <= (bcnt == 5'd31) ? 5'd0 : bcnt + 1'b1;
          // start(01) + read(10) + addr 0x05 detected: drive turnaround+data
          if (bcnt == 5'd13 && sh[31:16] == {2'b01, 2'b10, 5'h05})
            drive <= 1'b1;
        end
      end else begin
        if (sreg == 16'd0)
          sreg <= phy_status;
        else if (!mdc)
          sreg <= {sreg[14:0], 1'b0};
        if (sreg[15:1] == 15'h7FFF && !mdc)
          drive <= 1'b0;
      end
    end
  end
  assign mdio = drive ? sreg[15] : 1'bz;
endmodule
`endif
