// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- MDIO testbench top with a functional MDIO DUT model

`ifndef MDIO_TB_SV
`define MDIO_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import mdio_defs_pkg::*;
import mdio_pkg::*;
import mdio_env_pkg::*;
import mdio_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  mdio_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  mdio_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .mdc(vif.mdc), .mdio(vif.mdio),
    .phy_status(vif.phy_status), .mdio_status(vif.mdio_status)
  );

  // Concurrent protocol checks
  mdio_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .mdc(vif.mdc), .mdio(vif.mdio), .phy_status(vif.phy_status), .mdio_status(vif.mdio_status)
  );

  initial begin
    uvm_config_db#(virtual mdio_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module mdio_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        mdc,
  inout  logic        mdio,
  input  logic [15:0] phy_status,
  output logic [15:0] mdio_status
);
  // IEEE 802.3 Clause 22 PHY at address 5: MDIO is sampled on MDC rising
  // edges (MDC is oversampled by clk). After a preamble of >= 32 ones, the
  // 14-bit header ST(01) OP PHYAD REGAD is collected; a read (OP 10) of
  // PHYAD 5, any REGAD, is answered with TA Z then 0, then 16 bits of
  // phy_status (latched at TA) MSB first, then MDIO is released. As in
  // 22.3.4 the PHY changes MDIO after an MDC rising edge (one clk later),
  // so each bit is stable at the station's next rising edge. Writes and
  // other addresses are ignored until the next preamble.
  localparam logic [4:0] PHY_ADDR = 5'h05;
  localparam logic [1:0] S_IDLE = 2'd0, S_HDR = 2'd1, S_RESP = 2'd2;
  logic [1:0]  st;
  logic        mdc_q;
  logic [5:0]  pre_cnt;
  logic [4:0]  hcnt, fcnt;
  logic [12:0] sh;
  logic        drive, dout;
  logic [15:0] sreg;
  wire         bit_in = (mdio !== 1'b0);         // released line reads 1
  wire         mdc_rise = mdc && !mdc_q;
  wire  [13:0] hdr = {sh, bit_in};
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st          <= S_IDLE;
      mdc_q       <= 1'b0;
      pre_cnt     <= '0;
      hcnt        <= '0;
      fcnt        <= '0;
      sh          <= '0;
      drive       <= 1'b0;
      dout        <= 1'b1;
      sreg        <= '0;
      mdio_status <= '0;
    end else begin
      mdio_status <= phy_status;
      mdc_q       <= mdc;
      case (st)
        S_IDLE: if (mdc_rise) begin
          if (bit_in) pre_cnt <= (pre_cnt == 6'd63) ? pre_cnt : pre_cnt + 1'b1;
          else if (pre_cnt >= 6'd32) begin       // first ST bit after the preamble
            st <= S_HDR; sh <= '0; hcnt <= 5'd1;
          end else pre_cnt <= '0;
        end
        S_HDR: if (mdc_rise) begin
          sh   <= hdr[12:0];
          hcnt <= hcnt + 1'b1;
          if (hcnt == 5'd13) begin               // ST OP PHYAD REGAD complete
            pre_cnt <= '0;
            if (hdr[13:12] == 2'b01 && hdr[11:10] == 2'b10 && hdr[9:5] == PHY_ADDR) begin
              st <= S_RESP; fcnt <= '0;
            end else st <= S_IDLE;
          end
        end
        S_RESP: if (mdc_rise) begin
          // fcnt 0 = rise of the first TA bit (left Z), 1..16 = rises of
          // TA bit 2 and data bits 15..1, 17 = rise of data bit 0
          fcnt <= fcnt + 1'b1;
          if (fcnt == 5'd0) begin                // second TA bit: drive 0
            drive <= 1'b1; dout <= 1'b0; sreg <= phy_status;
          end else if (fcnt <= 5'd16) begin
            dout <= sreg[5'd16 - fcnt];
          end else begin                         // data bit 0 sampled: release
            drive <= 1'b0; dout <= 1'b1; st <= S_IDLE;
          end
        end
        default: st <= S_IDLE;
      endcase
    end
  end
  assign mdio = drive ? dout : 1'bz;
endmodule
`endif
