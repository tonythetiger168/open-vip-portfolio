// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- MDIO testbench top with a functional MDIO DUT model

`ifndef MDIO_UVM_VIP_TB_SV
`define MDIO_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import mdio_defs_pkg::*;
import mdio_pkg::*;
import mdio_env_pkg::*;
import mdio_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  mdio_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  mdio_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .mdc(vif.mdc),
    .mdio(vif.mdio),
    .phy_status(vif.phy_status),
    .mdio_status(vif.mdio_status)
  );

  // Concurrent protocol checks
  mdio_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .mdc(vif.mdc),
    .mdio(vif.mdio),
    .phy_status(vif.phy_status),
    .mdio_status(vif.mdio_status)
  );

  initial begin
    uvm_config_db#(virtual mdio_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module mdio_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        mdc,
  inout  logic        mdio,
  input  logic [15:0] phy_status,
  output logic [15:0] mdio_status
);
  localparam logic [4:0] PHY_ADDR = 5'h05;
  localparam logic [1:0] S_IDLE = 2'd0, S_HDR = 2'd1, S_RD = 2'd2, S_WR = 2'd3;
  logic [1:0]  st;
  logic        mdc_q;
  logic [5:0]  pre_cnt;
  logic [4:0]  hcnt, fcnt;
  logic [12:0] sh;
  logic [17:0] wsh;              // write frame: TA and data
  logic        drive, dout;
  logic [15:0] sreg;
  logic [15:0] c22 [0:31];
  logic [15:0] mmd [0:191];
  logic [15:0] maddr [0:2];
  logic [1:0]  hst, hop;
  logic [4:0]  hpa, hra;
  logic        c45, mine, rdf;
  logic        skip;
  logic        shortp;           // the frame's preamble was 31 bits             // frame for someone else: let its 18 bits pass
  logic [15:0] v;
  logic [1:0]  k, kd;
  logic [1:0]  fn;
  logic [4:0]  dv;
  wire         bit_in = (mdio !== 1'b0);         // released line reads 1
  wire         mdc_rise = mdc && !mdc_q;
  wire  [13:0] hdr = {sh, bit_in};

  function automatic logic ok(input logic [4:0] d);
    ok = (d == 5'd1) || (d == 5'd3) || (d == 5'd7);
  endfunction
  function automatic logic [1:0] idx(input logic [4:0] d);
    idx = (d == 5'd1) ? 2'd0 : (d == 5'd3) ? 2'd1 : 2'd2;
  endfunction
  // registers 2, 3 and 5 always read their constants, so only the
  // addresses past the 64 implemented registers need guarding on writes
  function automatic logic ro(input logic [15:0] a);
    ro = (a >= 16'd64);
  endfunction

  assign mdio_status = c22[0];
  assign fn = c22[13][15:14];
  assign dv = c22[13][4:0];
  assign kd = idx(dv);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; mdc_q <= 1'b0; pre_cnt <= '0; hcnt <= '0; fcnt <= '0; sh <= '0; wsh <= '0;
      drive <= 1'b0; dout <= 1'b1; sreg <= '0; skip <= 1'b0; shortp <= 1'b0;
      hst <= '0; hop <= '0; hpa <= '0; hra <= '0;
      c22[0] <= 16'h1140;
      for (int i = 1; i < 32; i++) c22[i] <= 16'h0;
      for (int i = 0; i < 192; i++) mmd[i] <= 16'h0;
      for (int i = 0; i < 3; i++) maddr[i] <= 16'h0;
    end else begin
      mdc_q <= mdc;
      case (st)
        S_IDLE: if (mdc_rise) begin
          if (bit_in) pre_cnt <= (pre_cnt == 6'd63) ? pre_cnt : pre_cnt + 1'b1;
          else if (pre_cnt >= 6'd31) begin       // first ST bit after the preamble
            // a 31-bit preamble is one bit short: the frame is let pass unanswered
            st <= S_HDR; sh <= '0; hcnt <= 5'd1; shortp <= (pre_cnt == 6'd31);
          end else pre_cnt <= '0;
        end
        S_HDR: if (mdc_rise) begin
          sh   <= hdr[12:0];
          hcnt <= hcnt + 1'b1;
          if (hcnt == 5'd13) begin               // ST OP PHYAD REGAD complete
            pre_cnt <= '0;
            c45  = (hdr[13:12] == 2'b00);
            rdf  = c45 ? hdr[11] : (hdr[11:10] == 2'b10);
            mine = !shortp && hdr[9:5] == PHY_ADDR &&
                   (c45 ? ok(hdr[4:0]) : (hdr[13:12] == 2'b01 && (hdr[11:10] == 2'b10 || hdr[11:10] == 2'b01)));
            hst <= hdr[13:12]; hop <= hdr[11:10]; hpa <= hdr[9:5]; hra <= hdr[4:0];
            skip <= !mine;
            if (!mine) begin st <= S_WR; fcnt <= '0; end
            else if (rdf) begin
              // read data and the read's side effects (post-increment)
              k = idx(hdr[4:0]);
              v = 16'h0;
              if (c45) begin
                v = (maddr[k] == 16'd2) ? 16'h0141 : (maddr[k] == 16'd3) ? 16'h0DD0 + {11'h0, hdr[4:0]} :
                    (maddr[k] == 16'd5) ? 16'h008A : (maddr[k] >= 16'd64) ? 16'h0 : mmd[64 * k + maddr[k][5:0]];
                if (hdr[11:10] == 2'b10) maddr[k] <= maddr[k] + 16'd1;
              end else case (hdr[4:0])
                5'd1:  v = phy_status;
                5'd2:  v = 16'h0141;
                5'd3:  v = 16'h0DD1;
                5'd14: if (ok(dv)) begin
                         if (fn == 2'b00) v = maddr[kd];
                         else begin
                           v = (maddr[kd] == 16'd2) ? 16'h0141 : (maddr[kd] == 16'd3) ? 16'h0DD0 + {11'h0, dv} :
                               (maddr[kd] == 16'd5) ? 16'h008A : (maddr[kd] >= 16'd64) ? 16'h0 : mmd[64 * kd + maddr[kd][5:0]];
                           if (fn == 2'b10) maddr[kd] <= maddr[kd] + 16'd1;
                         end
                       end
                default: v = c22[hdr[4:0]];
              endcase
              sreg <= v; st <= S_RD; fcnt <= '0;
            end else begin
              st <= S_WR; fcnt <= '0;
            end
          end
        end
        S_RD: if (mdc_rise) begin
          // fcnt 0 = rise of the first TA bit (left Z), 1..16 = rises of
          // TA bit 2 and data bits 15..1, 17 = rise of data bit 0
          fcnt <= fcnt + 1'b1;
          if (fcnt == 5'd0) begin drive <= 1'b1; dout <= 1'b0; end
          else if (fcnt <= 5'd16) dout <= sreg[5'd16 - fcnt];
          else begin drive <= 1'b0; st <= S_IDLE; end
        end
        S_WR: if (mdc_rise) begin
          wsh  <= {wsh[16:0], bit_in};
          fcnt <= fcnt + 1'b1;
          if (fcnt == 5'd17) begin               // TA and the 16 data bits are in
            v = {wsh[14:0], bit_in};
            st <= S_IDLE;
            if (skip) ;
            else if (hst == 2'b00) begin
              k = idx(hra);
              if (hop == 2'b00) maddr[k] <= v;
              else if (!ro(maddr[k])) mmd[64 * k + maddr[k][5:0]] <= v;
            end else case (hra)
              5'd0: if (v[15]) begin
                      c22[0] <= 16'h1140;
                      for (int i = 4; i < 32; i++) c22[i] <= 16'h0;
                    end else c22[0] <= v;
              5'd1, 5'd2, 5'd3: ;
              5'd14: if (ok(dv)) begin
                       if (fn == 2'b00) maddr[kd] <= v;
                       else begin
                         if (!ro(maddr[kd])) mmd[64 * kd + maddr[kd][5:0]] <= v;
                         if (fn != 2'b01) maddr[kd] <= maddr[kd] + 16'd1;
                       end
                     end
              default: c22[hra] <= v;
            endcase
          end
        end
      endcase
    end
  end
  assign mdio = drive ? dout : 1'bz;
endmodule
`endif
