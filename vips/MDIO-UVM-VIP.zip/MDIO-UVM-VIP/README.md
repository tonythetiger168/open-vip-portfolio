# MDIO UVM VIP (MDIO-UVM-VIP)

MDIO/MDC management interface UVM VIP with a PHY model that decodes clause-22 frames and drives read data. Complements the MDIO RTL IP from the open-ip-portfolio sister project.

## Structure

- `mdio/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `mdio_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `mdio_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural MDIO DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/MDIO-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh MDIO-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
