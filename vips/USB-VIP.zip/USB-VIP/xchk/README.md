# Independent cross-check model (`xchk/`)

`usb_xchk_tb.sv` checks the open-ip-portfolio `USB` RTL (`rtl/USB_top.sv`, `rtl/USB_apb.sv`)
against a USB 2.0 full-speed host: NRZI, bit stuffing, CRC5 / CRC16, a line receiver timing every J / K / SE0 interval, chapter 9 enumeration, toggles, STALL, CRC and stuffing faults. The model is written from the USB 2.0 specification, chapters 7, 8 and 9, not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/usb_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s usb_xchk_tb -o xchk.vvp $OIP/rtl/USB_top.sv $OIP/rtl/USB_apb.sv xchk/usb_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
