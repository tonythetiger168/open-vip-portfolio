# USB Test Plan（USB-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | USB family（USB 2.0 / USB 3.2 / USB4 / USB PD / eUSB2 link layers） |
| 家族 | USB |
| 類型 | UVM VIP |
| 交付目錄 | `USB-VIP/` |
| 目前 L1b 狀態 | PASS |

## 2. DUT / 待測對象

- `usb2_smoke_model`（USB 2.0 device，同 USB2-VIP）
- `usb3_smoke_model`（USB 3.2 upstream port link layer，同 USB3-VIP）
- `usb4_smoke_model`（USB4 lane adapter + transport，同 USB4-VIP）
- `usb_pd_smoke_model`（USB PD sink policy engine，同 USB_PD-VIP）
- `eusb2_smoke_model`（eUSB2 peripheral port，同 eUSB2-VIP）
- `usb3_phy_model`、`usb4_phy_model`、`pd_controller_model`（umbrella top 的 PIPE loopback model，沿用）

## 3. 驗證環境

- UVM 環境：五個協定的 link agent（driver / monitor / sequencer）、預測式 scoreboard、coverage，由 `usb_family_test` 在同一個 simulation 並行執行
- 每個協定一個 link interface 與 SVA compliance checker（見第 5 節）
- functional smoke：`tb/func_usb2_tb.sv`、`tb/func_usb3_tb.sv`、`tb/func_usb4_tb.sv`、`tb/func_usb_pd_tb.sv`、`tb/func_eusb2_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | USB 2.0 device：reset / chirp / suspend-resume、chapter 9、bulk / interrupt、PING / NYET、split、SOF（230 checks，見 USB2-VIP） | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | USB 3.2 link layer：LTSSM、LGOOD / LBAD / LRTY、credits、LMP、link power、Gen2 block header（107 checks，見 USB3-VIP） | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | USB4：training、CLx、bonding、RS-FEC、control path、paths 與 credits（213 checks，見 USB4-VIP） | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | USB PD：policy engine、GoodCRC / retry、soft / hard reset、MessageID（264 checks，見 USB_PD-VIP） | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | eUSB2：native / repeater mode、CM 控制訊息、LPM / L1 / L2、remote wake、register access（88 checks，見 eUSB2-VIP） | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | `usb_family_test`：五個 regression 並行，所有 scoreboard 無錯且各協定達到流量下限 | `SB_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | USB4 tunneling 的 USB3 / USB 2.0 traffic 經由對應 link layer |
| PT-02 | Type-C / PD 與 USB 2.0 / 3.2 連線的時序關聯（attach、role swap 後重新列舉） |
| PT-03 | 把共用 base 抽成單一相依套件，各協定 VIP 不再各自附帶 |

## 5. 覆蓋與檢查

- SVA：`rtl/sva/usb2_compliance_checker.sv`（25）、`usb3_compliance_checker.sv`（24）、`usb4_compliance_checker.sv`（21）、`usb_pd_compliance_checker.sv`（20）、`eusb2_compliance_checker.sv`（21），另有 umbrella `usb_compliance_checker.sv`
- Functional coverage：各 link package 的 coverage component（在 family test 中全部 100%）
- Scoreboard：五個協定各自逐 clock 預測 device

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/USB-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py USB-VIP && python3 smoke/smoke_run.py USB-VIP   # L1b
python3 tools/run_uvm_tests.py USB-VIP       # usb_family_test（Verilator），期望 SB_PASS
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 五個協定的檔案與各協定 VIP 相同；協定 VIP 修改時需同步複製到本 VIP。

---
*文件版本：v1.8.0*
