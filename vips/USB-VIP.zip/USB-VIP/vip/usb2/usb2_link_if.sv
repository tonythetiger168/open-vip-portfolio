// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB 2.0 packet-layer interface between the host BFM and a device: bus
// line state, one received packet per clock (PID, token fields, CRC
// result, data length / first bytes) and the device application side in;
// link state, chapter 9 state, the device's answer packet and counters
// out. See tb/usb2_smoke_model.sv.
`ifndef USB2_LINK_IF_SV
`define USB2_LINK_IF_SV

interface usb2_link_if (input logic clk, input logic rst_n);
  // host -> device
  logic        hs_cap;
  logic [1:0]  line;           // 0 SE0 1 J 2 K
  logic        rx_valid;
  logic [7:0]  rx_pid;
  logic        rx_crc_ok;
  logic [6:0]  rx_addr;
  logic [3:0]  rx_endp;
  logic [9:0]  rx_len;
  logic [31:0] rx_data;
  // device application
  logic        app_rd, app_wr, app_irq;
  logic [9:0]  app_len;
  // device -> host
  logic [2:0]  ls;             // 0 FS 1 CHIRP 2 CHIRP_WAIT 3 HS 4 SUSPEND
  logic        hs, chirp_k;
  logic [1:0]  dev_state;
  logic [6:0]  dev_addr;
  logic        cfg_val;
  logic [10:0] frame_num;
  logic [2:0]  uframe;
  logic [3:0]  ep_halt;
  logic        tx_valid;
  logic [7:0]  tx_pid;
  logic [9:0]  tx_len;
  logic [15:0] tx_data;
  logic [7:0]  pid_err, crc5_err, crc16_err, babble_cnt, dup_cnt, nak_cnt, stall_cnt, nyet_cnt;
  logic [7:0]  sof_cnt, sof_miss, resets, tmo_cnt, split_cnt;

  initial begin
    hs_cap = 1'b1; line = 2'd1; rx_valid = 1'b0; rx_pid = 8'h00; rx_crc_ok = 1'b1; rx_addr = 7'h00;
    rx_endp = 4'h0; rx_len = 10'd0; rx_data = 32'h0; app_rd = 1'b0; app_wr = 1'b0; app_irq = 1'b0; app_len = 10'd0;
  end
endinterface

`endif
