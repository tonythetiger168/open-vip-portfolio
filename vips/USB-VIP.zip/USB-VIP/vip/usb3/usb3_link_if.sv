// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB 3.2 link-layer interface between the downstream (host) port BFM and
// an upstream (device) port: LFPS / ordered sets / header packets / link
// commands / DPP words in, link commands and header packets out. One item
// per clock. See tb/usb3_smoke_model.sv for the encodings.
`ifndef USB3_LINK_IF_SV
`define USB3_LINK_IF_SV

interface usb3_link_if (input logic clk, input logic rst_n);
  // host -> device
  logic         far_end_ready;
  logic         lfps;
  logic         gen2_cap;
  logic         rx_valid;
  logic [2:0]   rx_kind;        // 0 TS1 1 TS2 2 header 3 link command 4 DPP word
  logic         rx_ts_reset;
  logic [127:0] rx_hdr;
  logic [15:0]  rx_lc;
  logic [31:0]  rx_dw;
  logic         rx_last;
  logic [3:0]   rx_blk;
  logic         app_busy;
  // device -> host
  logic [3:0]   ltssm;
  logic         gen2;
  logic         tx_lc_valid;
  logic [15:0]  tx_lc;
  logic         tx_hp_valid;
  logic [127:0] tx_hp;
  logic [2:0]   rx_free;
  logic [2:0]   tx_credits;
  logic [7:0]   hp_good, hp_bad, rec_cnt, dpp_good, dpp_bad, tp_mine, itp_cnt, u2_tmo;
  logic [7:0]   blk_fix, blk_drop;
  logic [26:0]  itp_ts;
  logic         force_pm;

  initial begin
    far_end_ready = 1'b0; lfps = 1'b0; gen2_cap = 1'b0; rx_valid = 1'b0; rx_kind = 3'd0;
    rx_ts_reset = 1'b0; rx_hdr = '0; rx_lc = '0; rx_dw = '0; rx_last = 1'b0; rx_blk = 4'b0011;
    app_busy = 1'b0;
  end
endinterface

`endif
