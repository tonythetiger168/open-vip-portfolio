// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// USB Unified Protocol Checker
// Cross-protocol sanity wrapper: instantiates no hardware, observes the
// MAC layer of a bound interface and flags cross-protocol violations
// (PID encoding, SOP/EOP pairing, device state legality).
//============================================================================
`ifndef USB_UNIFIED_CHECKER_SV
`define USB_UNIFIED_CHECKER_SV

`include "uvm_macros.svh"
import uvm_pkg::*;

class usb_unified_checker extends uvm_component;
  `uvm_component_utils(usb_unified_checker)

  virtual usb_vip_if vif;
  int pid_err_cnt;
  int frame_err_cnt;
  int state_err_cnt;

  function new(string name = "usb_unified_checker", uvm_component parent = null);
    super.new(name, parent);
    pid_err_cnt   = 0;
    frame_err_cnt = 0;
    state_err_cnt = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usb_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "USB unified checker: Virtual interface not found")
  endfunction

  // Procedural cross-protocol checks sampled on the MAC clock
  virtual task run_phase(uvm_phase phase);
    bit wait_eop = 0;
    int eop_cnt = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin
        wait_eop = 0; eop_cnt = 0;
        continue;
      end

      // PID complement on every packet start
      if (vif.mac_valid && vif.mac_sop && (vif.mac_pid[7:4] != ~vif.mac_pid[3:0])) begin
        `uvm_error("USB_UCHK", "PID complement mismatch")
        pid_err_cnt++;
      end

      // SOP is always followed by EOP within 64 beats
      if (vif.mac_valid && vif.mac_sop && !wait_eop) begin
        wait_eop = 1; eop_cnt = 0;
      end
      if (wait_eop) begin
        if (vif.mac_eop) wait_eop = 0;
        else begin
          eop_cnt++;
          if (eop_cnt > 64) begin
            `uvm_error("USB_UCHK", "SOP without EOP")
            frame_err_cnt++;
            wait_eop = 0;
          end
        end
      end

      // Device state remains a legal encoding
      if (!(vif.dev_state inside {USB_STATE_DEFAULT, USB_STATE_ADDRESS, USB_STATE_CONFIGURED,
                                  USB_STATE_SUSPENDED, USB_STATE_RESUME, USB_STATE_RESET,
                                  USB_STATE_POWERED, USB_STATE_TEST, USB_STATE_WUSB})) begin
        `uvm_error("USB_UCHK", "Illegal device state")
        state_err_cnt++;
      end
    end
  endtask

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("USB_UCHK_RPT", $sformatf(
      "USB Unified Chk | PID:%0d Frame:%0d State:%0d",
      pid_err_cnt, frame_err_cnt, state_err_cnt), UVM_LOW)
  endfunction
endclass
`endif
