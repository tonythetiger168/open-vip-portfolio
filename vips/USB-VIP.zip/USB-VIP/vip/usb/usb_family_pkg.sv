// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB family test: the link-layer environments of USB 2.0, USB 3.2, USB4,
// USB Power Delivery and eUSB2 side by side in one simulation, each with its
// own interface, device model, predicting scoreboard, coverage and
// compliance checker (the same agents as USB2-VIP, USB3-VIP, USB4-VIP,
// USB_PD-VIP and eUSB2-VIP). The five regressions run concurrently; the
// test passes when no scoreboard or checker reported an error and every
// protocol reached a traffic floor (half of its own link test's floor).
`ifndef USB_FAMILY_PKG_SV
`define USB_FAMILY_PKG_SV

package usb_family_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  class usb_family_test extends uvm_test;
    `uvm_component_utils(usb_family_test)
    usb2_link_pkg::usb2_env     e_usb2;
    usb3_link_pkg::usb3_env     e_usb3;
    usb4_link_pkg::usb4_env     e_usb4;
    usb_pd_link_pkg::usb_pd_env e_pd;
    eusb2_link_pkg::eusb2_env   e_eusb2;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      e_usb2  = usb2_link_pkg::usb2_env::type_id::create("e_usb2", this);
      e_usb3  = usb3_link_pkg::usb3_env::type_id::create("e_usb3", this);
      e_usb4  = usb4_link_pkg::usb4_env::type_id::create("e_usb4", this);
      e_pd    = usb_pd_link_pkg::usb_pd_env::type_id::create("e_pd", this);
      e_eusb2 = eusb2_link_pkg::eusb2_env::type_id::create("e_eusb2", this);
    endfunction
    task run_phase(uvm_phase phase);
      usb2_link_pkg::usb2_regression_seq     s2 = usb2_link_pkg::usb2_regression_seq::type_id::create("s2");
      usb3_link_pkg::usb3_regression_seq     s3 = usb3_link_pkg::usb3_regression_seq::type_id::create("s3");
      usb4_link_pkg::usb4_regression_seq     s4 = usb4_link_pkg::usb4_regression_seq::type_id::create("s4");
      usb_pd_link_pkg::usb_pd_regression_seq sp = usb_pd_link_pkg::usb_pd_regression_seq::type_id::create("sp");
      eusb2_link_pkg::eusb2_regression_seq   se = eusb2_link_pkg::eusb2_regression_seq::type_id::create("se");
      phase.raise_objection(this);
      fork
        s2.start(e_usb2.sqr);
        s3.start(e_usb3.sqr);
        s4.start(e_usb4.sqr);
        sp.start(e_pd.sqr);
        se.start(e_eusb2.sqr);
      join
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      int unsigned n;
      n = e_usb2.sb.n_checks + e_usb3.sb.n_lc_seen + e_usb3.sb.n_dev_hp + e_usb3.sb.n_lgood + e_usb4.sb.n_checks +
          e_pd.sb.n_checks + e_eusb2.sb.n_checks;
      `uvm_info("USB_FAMILY", $sformatf("usb2 %0d  usb3 %0d  usb4 %0d  pd %0d  eusb2 %0d checks",
                e_usb2.sb.n_checks, e_usb3.sb.n_lc_seen + e_usb3.sb.n_dev_hp + e_usb3.sb.n_lgood,
                e_usb4.sb.n_checks, e_pd.sb.n_checks, e_eusb2.sb.n_checks), UVM_LOW)
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0 &&
          e_usb2.sb.n_data > 100 && e_usb2.sb.n_split > 10 && e_usb3.sb.n_lgood > 50 && e_usb3.sb.n_dev_hp > 5 &&
          e_usb4.sb.n_fwd > 50 && e_usb4.sb.n_ctrl > 15 && e_pd.sb.n_ack > 15 && e_pd.sb.n_trans > 50 &&
          e_eusb2.sb.n_rap > 25 && e_eusb2.sb.n_l1 > 25)
        $display("SB_PASS checks=%0d", n);
      else `uvm_error("TEST", "USB_FAMILY_TEST FAILED")
    endfunction
  endclass
endpackage

`endif
