// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB Power Delivery UVM agent (source side) for a sink port on
// usb_pd_link_if:
//   usb_pd_item / usb_pd_driver  one message (SOP / SOP' / SOP'', with
//                                optional CRC, symbol, ordered-set or
//                                length errors), Hard Reset / Cable Reset
//                                ordered set, idle, VBUS or sink policy
//   usb_pd_monitor               both symbol streams, policy-engine state
//                                before and after each clock
//   usb_pd_scoreboard            decodes both directions and predicts the
//                                sink clock by clock: GoodCRC (MessageID,
//                                3 clocks after EOP), duplicate filtering,
//                                MessageIDCounter, retries 33 clocks apart,
//                                nRetryCount, every policy-engine transition
//                                (messages, GoodCRC, failures, SinkWaitCap /
//                                SenderResponse / PSTransition / Hard Reset
//                                timers, VBUS, Hard Reset either way), the
//                                message each state sends (Request object
//                                position / mismatch / currents, Sink
//                                Capabilities, Not_Supported, Soft_Reset,
//                                Accept), the contract and VBUS level, the
//                                sink's Hard Reset ordered sets and counters
//   usb_pd_coverage              transitions, receive errors, retries
//   sequences + usb_pd_env + usb_pd_link_test
`ifndef USB_PD_LINK_PKG_SV
`define USB_PD_LINK_PKG_SV

package usb_pd_link_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [4:0] K_S1 = 5'h18, K_S2 = 5'h11, K_S3 = 5'h06, K_R1 = 5'h07, K_R2 = 5'h19, K_EOP = 5'h0D;
  localparam logic [3:0] P_DIS = 4'd0, P_WCAP = 4'd1, P_REQ = 4'd2, P_WRSP = 4'd3, P_TRANS = 4'd4,
                         P_READY = 4'd5, P_SNKCAP = 4'd6, P_SRACC = 4'd7, P_NS = 4'd8,
                         P_SNDSR = 4'd9, P_WSRACC = 4'd10, P_HRST = 4'd11, P_ERR = 4'd12;
  localparam logic [4:0] C_GOODCRC = 5'd1, C_ACCEPT = 5'd3, C_REJECT = 5'd4, C_PING = 5'd5,
                         C_PS_RDY = 5'd6, C_GET_SRC = 5'd7, C_GET_SNK = 5'd8, C_DR_SWAP = 5'd9,
                         C_PR_SWAP = 5'd10, C_VCONN_SWAP = 5'd11, C_WAIT = 5'd12, C_SOFT_RST = 5'd13,
                         C_NOT_SUPP = 5'd16;
  localparam logic [4:0] D_SRC_CAP = 5'd1, D_REQUEST = 5'd2, D_BIST = 5'd3, D_SNK_CAP = 5'd4,
                         D_VDM = 5'd15;
  localparam int T_WCAP = 400, T_RSP = 100, T_TRANS = 200, T_HRST = 20;

  typedef enum int { K_MSG, K_HR, K_CR, K_IDLE, K_VBUS, K_WANT } pd_kind_e;
  // K_MSG errors
  typedef enum int { E_NONE, E_CRC, E_SYM, E_LEN, E_KCODE } pd_err_e;

  function automatic logic [4:0] enc(input logic [3:0] n);
    case (n)
      4'h0: return 5'h1E; 4'h1: return 5'h09; 4'h2: return 5'h14; 4'h3: return 5'h15;
      4'h4: return 5'h0A; 4'h5: return 5'h0B; 4'h6: return 5'h0E; 4'h7: return 5'h0F;
      4'h8: return 5'h12; 4'h9: return 5'h13; 4'hA: return 5'h16; 4'hB: return 5'h17;
      4'hC: return 5'h1A; 4'hD: return 5'h1B; 4'hE: return 5'h1C; default: return 5'h1D;
    endcase
  endfunction
  // 0..15 for a data symbol, -1 otherwise
  function automatic int dec(input logic [4:0] s);
    for (int i = 0; i < 16; i++) if (enc(4'(i)) == s) return i;
    return -1;
  endfunction
  function automatic logic [31:0] crc_byte(input logic [31:0] c0, input logic [7:0] b);
    logic [31:0] c;
    c = c0;
    for (int i = 0; i < 8; i++) c = (c[0] ^ b[i]) ? ((c >> 1) ^ 32'hEDB8_8320) : (c >> 1);
    return c;
  endfunction
  function automatic int match(input logic [4:0] a, b, c, d, input logic [4:0] w, x, y, z);
    return int'(a == w) + int'(b == x) + int'(c == y) + int'(d == z);
  endfunction
  function automatic logic [31:0] fixed_pdo(input int mv, input int ma);
    return {2'b00, 10'h000, 10'(mv / 50), 10'(ma / 10)};
  endfunction
  function automatic string pe_name(input logic [3:0] s);
    case (s)
      P_DIS: return "Disabled";       P_WCAP: return "WaitCap";      P_REQ: return "SelectCap";
      P_WRSP: return "WaitResponse";  P_TRANS: return "TransSink";   P_READY: return "Ready";
      P_SNKCAP: return "GiveSinkCap"; P_SRACC: return "SoftResetAcc"; P_NS: return "SendNotSupp";
      P_SNDSR: return "SendSoftReset"; P_WSRACC: return "WaitSRAccept"; P_HRST: return "HardReset";
      P_ERR: return "ErrorRecovery";  default: return "?";
    endcase
  endfunction

  // ------------------------------------------------------------ item
  class usb_pd_item extends uvm_sequence_item;
    `uvm_object_utils(usb_pd_item)
    pd_kind_e    kind = K_IDLE;
    int          sop;             // 0 SOP 1 SOP' 2 SOP''
    logic [4:0]  typ;
    int          ndo;
    int          id;
    logic [31:0] obj [7];
    pd_err_e     err = E_NONE;
    int          bad_k;           // K_HR / K_CR / E_KCODE: which K-code is wrong (-1 none)
    int          n = 1;           // K_IDLE clocks
    bit          level;           // K_VBUS
    logic [9:0]  v50, ma10;       // K_WANT
    function new(string name = "usb_pd_item"); super.new(name); bad_k = -1; endfunction
    virtual function string convert2string();
      if (kind == K_MSG) return $sformatf("SOP%0d type %0d ndo %0d id %0d err %s", sop, typ, ndo, id, err.name());
      return kind.name();
    endfunction
  endclass

  class usb_pd_obs extends uvm_object;
    `uvm_object_utils(usb_pd_obs)
    bit          rx_valid, tx_valid, vbus;
    logic [4:0]  rx_sym, tx_sym;
    logic [3:0]  pe, pe_next;
    bit          contract, mismatch;
    logic [9:0]  vbus_v50, want_v50, want_ma10;
    logic [2:0]  obj_pos, msg_id;
    logic [7:0]  rx_good, rx_bad, rx_dup, rx_other_sop, retries, hard_resets;
    function new(string name = "usb_pd_obs"); super.new(name); endfunction
  endclass

  typedef uvm_sequencer #(usb_pd_item) usb_pd_sequencer;

  // ------------------------------------------------------------ driver
  class usb_pd_driver extends uvm_driver #(usb_pd_item);
    `uvm_component_utils(usb_pd_driver)
    virtual usb_pd_link_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual usb_pd_link_if)::get(this, "", "usb_pd_vif", vif))
        `uvm_fatal("NOVIF", "usb_pd_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      usb_pd_item t;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(t);
        drive(t);
        seq_item_port.item_done();
      end
    endtask
    task sym(logic [4:0] s);
      @(negedge vif.clk);
      vif.rx_valid = 1'b1; vif.rx_sym = s;
      @(posedge vif.clk);
      #1 vif.rx_valid = 1'b0;
    endtask
    task drive(usb_pd_item t);
      logic [4:0]  os [4];
      logic [7:0]  b [$];
      logic [15:0] h;
      logic [31:0] c;
      int          nb;
      case (t.kind)
        K_IDLE: begin repeat (t.n) @(negedge vif.clk); return; end
        K_VBUS: begin @(negedge vif.clk); vif.vbus_present = t.level; return; end
        K_WANT: begin @(negedge vif.clk); vif.want_v50 = t.v50; vif.want_ma10 = t.ma10; return; end
        K_HR, K_CR: begin
          os = (t.kind == K_HR) ? '{K_R1, K_R1, K_R1, K_R2} : '{K_R1, K_S1, K_R1, K_S3};
          if (t.bad_k >= 0) os[t.bad_k] = K_S2;
          foreach (os[i]) sym(os[i]);
          @(negedge vif.clk);
          return;
        end
        default: ;
      endcase
      os = (t.sop == 1) ? '{K_S1, K_S1, K_S3, K_S3} : (t.sop == 2) ? '{K_S1, K_S3, K_S1, K_S3} :
                          '{K_S1, K_S1, K_S1, K_S2};
      if (t.err == E_KCODE) os[t.bad_k] = K_R2;            // 3 of 4 still right
      h = {1'b0, 3'(t.ndo), 3'(t.id), 1'b1, 2'b10, 1'b1, t.typ};   // source, Rev 3.0, DFP
      b.push_back(h[7:0]); b.push_back(h[15:8]);
      for (int i = 0; i < t.ndo; i++)
        for (int k = 0; k < 4; k++) b.push_back(t.obj[i][8 * k +: 8]);
      c = 32'hFFFF_FFFF;
      foreach (b[i]) c = crc_byte(c, b[i]);
      c = ~c;
      if (t.err == E_CRC) c[3] = ~c[3];
      for (int k = 0; k < 4; k++) b.push_back(c[8 * k +: 8]);
      if (t.err == E_LEN) void'(b.pop_back());
      foreach (os[i]) sym(os[i]);
      nb = b.size();
      for (int i = 0; i < nb; i++) begin
        sym(enc(b[i][3:0]));
        sym((t.err == E_SYM && i == 1) ? 5'h00 : enc(b[i][7:4]));
      end
      sym(K_EOP);
      @(negedge vif.clk);
    endtask
  endclass

  // ------------------------------------------------------------ monitor
  class usb_pd_monitor extends uvm_monitor;
    `uvm_component_utils(usb_pd_monitor)
    virtual usb_pd_link_if vif;
    uvm_analysis_port #(usb_pd_obs) ap;
    function new(string name, uvm_component parent); super.new(name, parent); ap = new("ap", this); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual usb_pd_link_if)::get(this, "", "usb_pd_vif", vif))
        `uvm_fatal("NOVIF", "usb_pd_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      usb_pd_obs o;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n !== 1'b1) continue;
        o = usb_pd_obs::type_id::create("o");
        o.rx_valid = vif.rx_valid; o.rx_sym = vif.rx_sym; o.tx_valid = vif.tx_valid; o.tx_sym = vif.tx_sym;
        o.vbus = vif.vbus_present; o.pe = vif.pe_state; o.contract = vif.contract; o.mismatch = vif.mismatch;
        o.vbus_v50 = vif.vbus_v50; o.want_v50 = vif.want_v50; o.want_ma10 = vif.want_ma10;
        o.obj_pos = vif.obj_pos; o.msg_id = vif.msg_id; o.rx_good = vif.rx_good; o.rx_bad = vif.rx_bad;
        o.rx_dup = vif.rx_dup; o.rx_other_sop = vif.rx_other_sop; o.retries = vif.retries;
        o.hard_resets = vif.hard_resets;
        #1 o.pe_next = vif.pe_state;
        ap.write(o);
      end
    endtask
  endclass

  // ------------------------------------------------------------ scoreboard
  class usb_pd_scoreboard extends uvm_subscriber #(usb_pd_obs);
    `uvm_component_utils(usb_pd_scoreboard)
    virtual usb_pd_link_if vif;
    int unsigned cyc, errors, n_checks;
    // source -> sink decoder (mirrors the receiver)
    logic [4:0]  rsh1, rsh2, rsh3;
    bit          r_in, r_half;
    int          r_sop;
    logic [3:0]  r_lo;
    logic [7:0]  rb [$];
    // receive side prediction
    bit          stored_v;
    logic [2:0]  stored_id;
    int unsigned p_good, p_bad, p_dup, p_other, p_retries, p_hr;
    int          gc_id [$];     // GoodCRCs the sink owes: MessageID, EOP clock, exact timing
    int          gc_eop [$];
    bit          gc_exact [$];
    // policy-engine events
    int          ev_msg_t, ev_ack_t, ev_hr_t, fail_t;
    logic [4:0]  ev_type;
    int          ev_ndo;
    logic [31:0] ev_obj [7];
    int          ent;           // clock of the last state entry (timer restart)
    bit          had;
    int          hrc;
    logic [9:0]  pend_v;
    logic [2:0]  p_pos;
    bit          p_mm;
    int          wcap_from;
    int          chk_after;     // state whose outputs are checked on the next clock (-1 none)
    // sink -> source decoder
    logic [4:0]  tw0, tw1, tw2;
    bit          t_in, t_half;
    int          t_start, last_tx;
    logic [3:0]  t_lo;
    logic [7:0]  tb_ [$];
    // transmit side prediction
    bit          exp_v;
    int          exp_t;
    logic [4:0]  exp_type;
    int          exp_ndo;
    logic [31:0] exp_obj;
    logic [2:0]  p_msg_id;
    bit          s_wait, last_sr;
    int          s_eop, s_tries, resend_due;
    logic [7:0]  last_frame [$];
    int          exp_hr;
    int unsigned n_gc, n_tx_msg, n_trans, n_sink_hr, n_ack;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    bit trace;
    function void build_phase(uvm_phase phase);
      void'(uvm_config_db#(virtual usb_pd_link_if)::get(this, "", "usb_pd_vif", vif));
      trace = $test$plusargs("PD_TRACE");
      ev_msg_t = -10; ev_ack_t = -10; ev_hr_t = -10; fail_t = -10; chk_after = -1; resend_due = -1;
      last_tx = -10;
    endfunction
    function void err(string m);
      errors++;
      `uvm_error("PD_SB", m)
    endfunction
    function void chk(bit ok, string m);
      n_checks++;
      if (!ok) err(m);
    endfunction

    // transmitter reset (Hard Reset / Disabled / received Hard Reset)
    function void tx_abort();
      s_wait = 0; s_tries = 0; resend_due = -1; p_msg_id = 3'd0; exp_v = 0;   // t_in: after this clock's symbol
    endfunction

    function logic [3:0] predict(usb_pd_obs o, bit e_msg, bit e_ack, bit e_hr, bit e_fail, output bit tmo_hr);
      bit ctl;
      int k;
      tmo_hr = 0;
      ctl = e_msg && ev_ndo == 0;
      k = int'(cyc) - ent;
      if (!o.vbus && o.pe != P_HRST) return P_DIS;
      if (e_hr && o.pe != P_DIS) return P_HRST;
      if (e_msg && ev_type == C_SOFT_RST && ev_ndo == 0 && o.pe != P_DIS && o.pe != P_HRST) return P_SRACC;
      case (o.pe)
        P_DIS:  return o.vbus ? P_WCAP : P_DIS;
        P_WCAP: begin
          if (e_msg && ev_type == D_SRC_CAP && ev_ndo != 0) return P_REQ;
          if (k == T_WCAP) begin
            if (hrc == 2) return P_ERR;
            tmo_hr = 1; return P_HRST;
          end
        end
        P_REQ:  begin if (e_ack) return P_WRSP; if (e_fail) return P_HRST; end
        P_WRSP: begin
          if (ctl && ev_type == C_ACCEPT) return P_TRANS;
          if (ctl && (ev_type == C_REJECT || ev_type == C_WAIT)) return had ? P_READY : P_WCAP;
          if (e_msg) return P_SNDSR;
          if (k == T_RSP) return P_HRST;
        end
        P_TRANS: begin
          if (ctl && ev_type == C_PS_RDY) return P_READY;
          if (e_msg || k == T_TRANS) return P_HRST;
        end
        P_READY:
          if (e_msg) begin
            if (ev_type == D_SRC_CAP && ev_ndo != 0) return P_REQ;
            if (ctl && ev_type == C_GET_SNK) return P_SNKCAP;
            if (ctl && ev_type == C_PING) return P_READY;
            if (ctl && (ev_type == C_ACCEPT || ev_type == C_REJECT || ev_type == C_PS_RDY || ev_type == C_WAIT))
              return P_SNDSR;
            return P_NS;
          end
        P_SNKCAP, P_NS: begin if (e_ack) return P_READY; if (e_fail) return P_SNDSR; end
        P_SRACC: begin if (e_ack) return P_WCAP; if (e_fail) return P_HRST; end
        P_SNDSR: begin if (e_ack) return P_WSRACC; if (e_fail) return P_HRST; end
        P_WSRACC: begin
          if (ctl && ev_type == C_ACCEPT) return P_WCAP;
          if (k == T_RSP) return P_HRST;
        end
        P_HRST: if (k == T_HRST) return o.vbus ? P_WCAP : P_DIS;
        default: ;
      endcase
      return o.pe;
    endfunction

    bit e_sr_now;
    function void expect_tx(logic [4:0] t, int n, logic [31:0] obj);
      // a Soft_Reset from the source overrides a message not yet on the line
      if (exp_v && !(t == C_ACCEPT && n == 0 && e_sr_now)) err($sformatf("@%0d expected sink message type %0d replaced by %0d before it was sent (%s)", cyc, exp_type, t,
                               pe_name(vif.pe_state)));
      exp_v = 1; exp_type = t; exp_ndo = n; exp_obj = obj; exp_t = cyc;
    endfunction

    function void write(usb_pd_obs t);
      usb_pd_obs o = t;
      bit e_msg, e_ack, e_hr, e_fail, tmo_hr, rx_clear, abort;
      logic [3:0] nx;
      cyc++;
      e_msg  = ev_msg_t == int'(cyc) - 1;
      e_ack  = ev_ack_t == int'(cyc) - 1;
      e_hr   = ev_hr_t == int'(cyc) - 1;
      e_fail = fail_t == int'(cyc);
      e_sr_now = e_msg && ev_type == C_SOFT_RST && ev_ndo == 0;

      // outputs of the state entered on the previous clock
      if (chk_after == P_HRST)
        chk(!o.contract && o.vbus_v50 == 10'd100, $sformatf("Hard Reset: contract %0d VBUS %0d (want 0, 100)",
            o.contract, o.vbus_v50));
      else if (chk_after == P_READY)
        chk(o.contract && o.vbus_v50 == pend_v && o.obj_pos == p_pos && o.mismatch == p_mm,
            $sformatf("explicit contract: contract %0d VBUS %0d pos %0d mm %0d (want 1, %0d, %0d, %0d)",
                      o.contract, o.vbus_v50, o.obj_pos, o.mismatch, pend_v, p_pos, p_mm));
      else if (chk_after == P_WCAP)
        // a Soft Reset leaves VBUS where it is; Hard Reset / attach start at vSafe5V
        chk(!o.contract && (wcap_from inside {P_SRACC, P_WSRACC, P_WRSP} || o.vbus_v50 == 10'd100),
            $sformatf("@%0d Wait_for_Capabilities (from %s): contract %0d VBUS %0d", cyc, pe_name(4'(wcap_from)),
                      o.contract, o.vbus_v50));
      else if (chk_after == P_DIS)
        chk(!o.contract && o.vbus_v50 == 10'd0, "Disabled: no contract, no VBUS");
      chk_after = -1;

      // ---- policy engine, this clock
      nx = predict(o, e_msg, e_ack, e_hr, e_fail, tmo_hr);
      chk(o.pe_next == nx, $sformatf("@%0d policy engine %s -> %s, predicted %s (msg %0d type %0d ack %0d hr %0d fail %0d)",
          cyc, pe_name(o.pe), pe_name(o.pe_next), pe_name(nx), e_msg, ev_type, e_ack, e_hr, e_fail));
      if (o.pe_next != o.pe || (e_hr && o.pe != P_DIS)) begin
        ent = cyc;
        n_trans++;
        case (o.pe_next)
          P_HRST: begin
            had = 0; p_hr++; chk_after = P_HRST;
            if (!e_hr) exp_hr++;
            if (tmo_hr) hrc++;
            exp_v = 0;
          end
          P_DIS: begin had = 0; hrc = 0; exp_v = 0; chk_after = P_DIS; end
          P_ERR: ;
          P_REQ: begin
            logic [9:0] best;
            p_pos = 3'd1; p_mm = 1; best = 0; pend_v = 10'd100;
            for (int i = 0; i < 7; i++)
              if (i < ev_ndo && ev_obj[i][31:30] == 2'b00 && ev_obj[i][19:10] <= o.want_v50 &&
                  ev_obj[i][9:0] >= o.want_ma10 && ev_obj[i][19:10] > best) begin
                best = ev_obj[i][19:10]; p_pos = 3'(i + 1); p_mm = 0; pend_v = ev_obj[i][19:10];
              end
            if (p_mm) pend_v = ev_obj[0][19:10];
            expect_tx(D_REQUEST, 1, {1'b0, p_pos, 1'b0, p_mm, 4'b0000, 2'b00, o.want_ma10, o.want_ma10});
          end
          P_SNKCAP: expect_tx(D_SNK_CAP, 1, {12'h000, 10'd100, o.want_ma10});
          P_NS:     expect_tx(C_NOT_SUPP, 0, 32'h0);
          P_SNDSR:  expect_tx(C_SOFT_RST, 0, 32'h0);
          P_SRACC:  expect_tx(C_ACCEPT, 0, 32'h0);
          P_READY:  if (o.pe == P_TRANS) begin had = 1; hrc = 0; chk_after = P_READY; end
          P_WCAP:   if (1) begin wcap_from = o.pe; end
          default: ;
        endcase
        case (o.pe_next)
          P_WCAP:   if (o.pe == P_SRACC || o.pe == P_WSRACC || (o.pe == P_WRSP && !had)) begin
                      had = 0; chk_after = P_WCAP;
                    end
                    else if (o.pe == P_HRST || o.pe == P_DIS) chk_after = P_WCAP;
          default: ;
        endcase
      end
      if (!o.vbus && o.pe != P_HRST) hrc = 0;

      // ---- transmitter / receiver resets on this edge
      abort    = e_hr || o.pe == P_HRST || o.pe == P_DIS;
      rx_clear = abort;
      if (abort) tx_abort();
      if (e_msg && ev_type == C_SOFT_RST && ev_ndo == 0) begin s_wait = 0; s_tries = 0; resend_due = -1; p_msg_id = 0; end
      if (e_ack && last_sr) stored_v = 0;

      // ---- source -> sink
      if (o.rx_valid) rx_symbol(o, rx_clear);
      if (rx_clear) begin stored_v = 0; gc_id.delete(); gc_eop.delete(); gc_exact.delete(); end

      // ---- GoodCRC timeout on the sink's message
      if (s_wait && int'(cyc) - s_eop == 31) begin
        s_wait = 0;
        if (s_tries == 3) begin fail_t = cyc + 1; s_tries = 0; end
        else begin resend_due = cyc + 2; p_retries++; end
      end

      // ---- a message the policy engine asked for must reach the line
      if (exp_v && !t_in && int'(cyc) - exp_t == 120) err($sformatf("@%0d %s: message type %0d not sent within 120 clocks",
                                                       cyc, pe_name(o.pe), exp_type));
      // ---- sink -> source
      if (o.tx_valid) begin tx_symbol(o); last_tx = cyc; end
      else if (t_in && !abort) begin err("sink frame interrupted"); t_in = 0; end
      if (abort) t_in = 0;
    endfunction

    function void rx_symbol(usb_pd_obs o, bit clear);
      logic [4:0] s;
      int d;
      s = o.rx_sym;
      d = dec(s);
      if (!r_in) begin
        if (match(rsh1, rsh2, rsh3, s, K_R1, K_R1, K_R1, K_R2) >= 3) ev_hr_t = cyc;
        else if (match(rsh1, rsh2, rsh3, s, K_R1, K_S1, K_R1, K_S3) >= 3) ;
        else if (match(rsh1, rsh2, rsh3, s, K_S1, K_S1, K_S1, K_S2) >= 3) begin r_in = 1; r_sop = 0; end
        else if (match(rsh1, rsh2, rsh3, s, K_S1, K_S1, K_S3, K_S3) >= 3) begin r_in = 1; r_sop = 1; end
        else if (match(rsh1, rsh2, rsh3, s, K_S1, K_S3, K_S1, K_S3) >= 3) begin r_in = 1; r_sop = 2; end
        if (ev_hr_t == int'(cyc) || r_in || match(rsh1, rsh2, rsh3, s, K_R1, K_S1, K_R1, K_S3) >= 3) begin
          rsh1 = 0; rsh2 = 0; rsh3 = 0; rb.delete(); r_half = 0;
          return;
        end
      end
      else if (d >= 0) begin
        if (!r_half) begin r_lo = 4'(d); r_half = 1; end
        else if (rb.size() == 34) begin r_in = 0; p_bad++; end
        else begin rb.push_back({4'(d), r_lo}); r_half = 0; end
      end
      else if (s == K_EOP) begin r_in = 0; rx_packet(o, clear); end
      else begin r_in = 0; p_bad++; end
      rsh1 = rsh2; rsh2 = rsh3; rsh3 = s;
    endfunction

    function void rx_packet(usb_pd_obs o, bit clear);
      logic [31:0] c;
      logic [15:0] h;
      int n;
      n = rb.size();
      c = 32'hFFFF_FFFF;
      foreach (rb[i]) c = crc_byte(c, rb[i]);
      h = (n >= 2) ? {rb[1], rb[0]} : 16'h0;
      if (trace) `uvm_info("PD_TRACE", $sformatf("@%0d rx SOP%0d hdr %04h type %0d id %0d crc %0d pe %s wait %0d", cyc, r_sop, h,
                                                 h[4:0], h[11:9], c == 32'hDEBB_20E3, pe_name(o.pe), s_wait), UVM_LOW)
      if (!(n >= 6 && c == 32'hDEBB_20E3 && n == 6 + 4 * int'(h[14:12]) && !r_half)) begin p_bad++; return; end
      if (r_sop != 0) begin p_other++; return; end
      if (h[4:0] == C_GOODCRC && h[14:12] == 3'd0) begin
        if (s_wait && h[11:9] == p_msg_id && int'(cyc) - s_eop <= 31) begin
          s_wait = 0; s_tries = 0; n_ack++;
          ev_ack_t = cyc;
          p_msg_id = last_sr ? 3'd1 : p_msg_id + 3'd1;
        end
        return;
      end
      p_good++;
      if (!clear) begin
        gc_id.push_back(h[11:9]); gc_eop.push_back(cyc);
        gc_exact.push_back(!s_wait && !t_in && resend_due < 0 && last_tx < int'(cyc) - 1);
      end
      if (h[4:0] == C_SOFT_RST && h[14:12] == 3'd0) begin
        stored_id = h[11:9]; stored_v = 1;
        ev_msg_t = cyc; ev_type = C_SOFT_RST; ev_ndo = 0;
      end
      else if (stored_v && stored_id == h[11:9]) p_dup++;
      else begin
        stored_id = h[11:9]; stored_v = 1;
        ev_msg_t = cyc; ev_type = h[4:0]; ev_ndo = h[14:12];
        for (int i = 0; i < 7; i++)
          ev_obj[i] = (2 + 4 * i + 3 < n) ? {rb[5 + 4 * i], rb[4 + 4 * i], rb[3 + 4 * i], rb[2 + 4 * i]} : 32'h0;
      end
    endfunction

    function void tx_symbol(usb_pd_obs o);
      logic [4:0] s;
      int d;
      s = o.tx_sym;
      d = dec(s);
      if (!t_in) begin
        if (tw0 == K_R1 && tw1 == K_R1 && tw2 == K_R1 && s == K_R2) begin
          n_sink_hr++;
          chk(exp_hr > 0, "sink sent a Hard Reset nobody asked for");
          if (exp_hr > 0) exp_hr--;
          tw0 = 0; tw1 = 0; tw2 = 0;
          return;
        end
        if (tw0 == K_S1 && tw1 == K_S1 && tw2 == K_S1 && s == K_S2) begin
          t_in = 1; t_half = 0; tb_.delete(); t_start = cyc - 3;
          tw0 = 0; tw1 = 0; tw2 = 0;
          return;
        end
        chk(s == K_S1 || s == K_R1 || s == K_S2 || s == K_R2, $sformatf("sink symbol %02h outside a frame", s));
        tw0 = tw1; tw1 = tw2; tw2 = s;
        return;
      end
      if (d >= 0) begin
        if (!t_half) begin t_lo = 4'(d); t_half = 1; end
        else begin tb_.push_back({4'(d), t_lo}); t_half = 0; end
      end
      else if (s == K_EOP) begin t_in = 0; tx_frame(); end
      else begin chk(0, $sformatf("sink sent invalid symbol %02h in a frame", s)); t_in = 0; end
    endfunction

    function bit same_frame();
      if (tb_.size() != last_frame.size()) return 0;
      foreach (tb_[i]) if (tb_[i] != last_frame[i]) return 0;
      return 1;
    endfunction
    function void tx_frame();
      logic [31:0] c, obj;
      logic [15:0] h;
      int n, id, eop;
      bit ex;
      n = tb_.size();
      c = 32'hFFFF_FFFF;
      foreach (tb_[i]) c = crc_byte(c, tb_[i]);
      h = (n >= 2) ? {tb_[1], tb_[0]} : 16'h0;
      chk(n >= 6 && c == 32'hDEBB_20E3 && n == 6 + 4 * int'(h[14:12]) && !t_half,
          $sformatf("sink frame CRC / length (%0d bytes)", n));
      chk(h[15] == 1'b0 && h[8] == 1'b0 && h[7:6] == 2'b10 && h[5] == 1'b0,
          $sformatf("sink header %04h: not a Rev 3.0 sink UFP", h));
      obj = (n >= 6 + 4) ? {tb_[5], tb_[4], tb_[3], tb_[2]} : 32'h0;
      if (trace) `uvm_info("PD_TRACE", $sformatf("@%0d tx hdr %04h type %0d id %0d start %0d", cyc, h, h[4:0], h[11:9], t_start), UVM_LOW)
      if (h[4:0] == C_GOODCRC && h[14:12] == 3'd0) begin
        n_gc++;
        if (gc_id.size() == 0) begin err("GoodCRC for no message"); return; end
        id = gc_id.pop_front(); eop = gc_eop.pop_front(); ex = gc_exact.pop_front();
        chk(h[11:9] == 3'(id), $sformatf("GoodCRC MessageID %0d, want %0d", h[11:9], id));
        if (ex) chk(t_start == eop + 3, $sformatf("GoodCRC started %0d clocks after EOP, want 3", t_start - eop));
        return;
      end
      if (resend_due >= 0) begin
        chk(t_start == resend_due && same_frame(),
            $sformatf("retry: start %0d (want %0d), same bytes %0d", t_start, resend_due, same_frame()));
        resend_due = -1; s_tries++; s_wait = 1; s_eop = cyc;
        return;
      end
      n_tx_msg++;
      chk(exp_v, $sformatf("unexpected sink message type %0d", h[4:0]));
      if (exp_v)
        chk(h[4:0] == exp_type && int'(h[14:12]) == exp_ndo && (exp_ndo == 0 || obj == exp_obj),
            $sformatf("sink message type %0d ndo %0d obj %08h, want %0d %0d %08h", h[4:0], h[14:12], obj,
                      exp_type, exp_ndo, exp_obj));
      last_sr = h[4:0] == C_SOFT_RST && h[14:12] == 3'd0;
      if (last_sr) p_msg_id = 3'd0;
      chk(h[11:9] == p_msg_id, $sformatf("sink MessageID %0d, MessageIDCounter predicted %0d", h[11:9], p_msg_id));
      exp_v = 0;
      last_frame.delete();
      foreach (tb_[i]) last_frame.push_back(tb_[i]);
      s_tries = 1; s_wait = 1; s_eop = cyc;
    endfunction

    function void check_phase(uvm_phase phase);
      if (gc_id.size() != 0) err($sformatf("%0d GoodCRCs never sent", gc_id.size()));
      if (exp_v) err($sformatf("expected sink message type %0d never sent", exp_type));
      if (exp_hr != 0) err($sformatf("%0d Hard Reset ordered sets never sent", exp_hr));
      if (vif != null) begin
        chk(vif.rx_good == 8'(p_good) && vif.rx_bad == 8'(p_bad) && vif.rx_dup == 8'(p_dup) &&
            vif.rx_other_sop == 8'(p_other),
            $sformatf("rx counters good/bad/dup/other %0d/%0d/%0d/%0d, predicted %0d/%0d/%0d/%0d",
                      vif.rx_good, vif.rx_bad, vif.rx_dup, vif.rx_other_sop, p_good, p_bad, p_dup, p_other));
        chk(vif.retries == 8'(p_retries) && vif.hard_resets == 8'(p_hr),
            $sformatf("retries %0d hard_resets %0d, predicted %0d %0d", vif.retries, vif.hard_resets, p_retries, p_hr));
      end
    endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("PD_SB", $sformatf("checks=%0d transitions=%0d good=%0d bad=%0d dup=%0d other=%0d GoodCRC=%0d sink msgs=%0d acked=%0d retries=%0d hard resets=%0d (sent %0d) errors=%0d",
                n_checks, n_trans, p_good, p_bad, p_dup, p_other, n_gc, n_tx_msg, n_ack, p_retries, p_hr,
                n_sink_hr, errors), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ coverage
  class usb_pd_coverage extends uvm_subscriber #(usb_pd_obs);
    `uvm_component_utils(usb_pd_coverage)
    logic [3:0] from_s, to_s;
    int         rx_ev;      // 0 good 1 bad 2 dup 3 other SOP
    logic [7:0] g, b, d, x, r;
    bit         first = 1;
    bit         seen [int];
    covergroup cg_pe;
      cp_tr: coverpoint {from_s, to_s} {
        bins dis_wcap     = {8'h01};
        bins wcap_req     = {8'h12};
        bins wcap_hrst    = {8'h1B};
        bins wcap_err     = {8'h1C};
        bins req_wrsp     = {8'h23};
        bins req_hrst     = {8'h2B};
        bins wrsp_trans   = {8'h34};
        bins wrsp_ready   = {8'h35};
        bins wrsp_wcap    = {8'h31};
        bins wrsp_sndsr   = {8'h39};
        bins wrsp_hrst    = {8'h3B};
        bins trans_ready  = {8'h45};
        bins trans_hrst   = {8'h4B};
        bins ready_req    = {8'h52};
        bins ready_snkcap = {8'h56};
        bins ready_sracc  = {8'h57};
        bins ready_ns     = {8'h58};
        bins ready_sndsr  = {8'h59};
        bins snkcap_ready = {8'h65};
        bins ns_ready     = {8'h85};
        bins ns_sndsr     = {8'h89};
        bins sracc_wcap   = {8'h71};
        bins sracc_hrst   = {8'h7B};
        bins sndsr_wsracc = {8'h9A};
        bins sndsr_hrst   = {8'h9B};
        bins wsracc_wcap  = {8'hA1};
        bins wsracc_hrst  = {8'hAB};
        bins hrst_wcap    = {8'hB1};
        bins ready_dis    = {8'h50};
        bins err_dis      = {8'hC0};
      }
    endgroup
    covergroup cg_rx;
      cp_ev: coverpoint rx_ev { bins good = {0}; bins bad = {1}; bins dup = {2}; bins other = {3}; bins retry = {4}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      cg_pe = new(); cg_rx = new();
    endfunction
    function void write(usb_pd_obs t);
      usb_pd_obs o = t;
      if (o.pe != o.pe_next) begin from_s = o.pe; to_s = o.pe_next; cg_pe.sample(); seen[{from_s, to_s}] = 1; end
      if (!first) begin
        rx_ev = -1;
        if (o.rx_good != g) rx_ev = 0;
        if (o.rx_bad != b) rx_ev = 1;
        if (o.rx_dup != d) rx_ev = 2;
        if (o.rx_other_sop != x) rx_ev = 3;
        if (o.retries != r) rx_ev = 4;
        if (rx_ev >= 0) cg_rx.sample();
      end
      first = 0;
      g = o.rx_good; b = o.rx_bad; d = o.rx_dup; x = o.rx_other_sop; r = o.retries;
    endfunction
    function void report_phase(uvm_phase phase);
      int want [] = '{'h01, 'h12, 'h1B, 'h1C, 'h23, 'h2B, 'h34, 'h35, 'h31, 'h39, 'h3B, 'h45, 'h4B, 'h52, 'h56,
                      'h57, 'h58, 'h59, 'h65, 'h85, 'h89, 'h71, 'h7B, 'h9A, 'h9B, 'hA1, 'hAB, 'hB1, 'h50, 'hC0};
      string miss = "";
      foreach (want[i]) if (!seen.exists(want[i])) miss = {miss, $sformatf(" %02h", want[i])};
      `uvm_info("PD_COV", $sformatf("policy engine %0.1f%%  receive %0.1f%%  transitions not seen:%s", cg_pe.get_coverage(),
                cg_rx.get_coverage(), miss), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ sequences
  class usb_pd_base_seq extends uvm_sequence #(usb_pd_item);
    `uvm_object_utils(usb_pd_base_seq)
    virtual usb_pd_link_if vif;
    int src_id;
    logic [31:0] caps [7];
    function new(string name = "usb_pd_base_seq"); super.new(name); endfunction
    task pre_body();
      if (vif == null) void'(uvm_config_db#(virtual usb_pd_link_if)::get(null, "*", "usb_pd_vif", vif));
    endtask
    task send(usb_pd_item t); start_item(t); finish_item(t); endtask
    task idle(int n);
      usb_pd_item t = usb_pd_item::type_id::create("t");
      t.kind = K_IDLE; t.n = n; send(t);
    endtask
    task vbus(bit v);
      usb_pd_item t = usb_pd_item::type_id::create("t");
      t.kind = K_VBUS; t.level = v; send(t);
    endtask
    task want(int v50, int ma10);
      usb_pd_item t = usb_pd_item::type_id::create("t");
      t.kind = K_WANT; t.v50 = 10'(v50); t.ma10 = 10'(ma10); send(t);
    endtask
    task ordered(pd_kind_e k, int bad_k = -1);
      usb_pd_item t = usb_pd_item::type_id::create("t");
      t.kind = k; t.bad_k = bad_k; send(t);
      if (k == K_HR) src_id = 0;
    endtask
    // a source message; MessageID moves on when the sink takes it
    task msg(logic [4:0] typ, int ndo = 0, pd_err_e e = E_NONE, int sop = 0, int id = -1);
      usb_pd_item t = usb_pd_item::type_id::create("t");
      t.kind = K_MSG; t.typ = typ; t.ndo = ndo; t.err = e; t.sop = sop; t.bad_k = $urandom_range(0, 3);
      if (typ == C_SOFT_RST && ndo == 0) src_id = 0;
      t.id = (id >= 0) ? id : src_id;
      for (int i = 0; i < 7; i++) t.obj[i] = caps[i];
      send(t);
      if (id < 0 && (e == E_NONE || e == E_KCODE) && sop == 0) src_id = (src_id + 1) % 8;
    endtask
    task gc(int id);
      usb_pd_item t = usb_pd_item::type_id::create("t");
      t.kind = K_MSG; t.typ = C_GOODCRC; t.ndo = 0; t.id = id; send(t);
    endtask
    function bit sending();
      return vif.pe_state inside {P_REQ, P_SNKCAP, P_NS, P_SNDSR, P_SRACC};
    endfunction
    // wait until the sink has sent something and the line is idle again
    task quiet(int max = 80);
      int t, q;
      t = 0;
      while (vif.tx_valid !== 1'b1 && t < max) begin idle(1); t++; end
      q = 0;
      while (q < 3 && t < max + 200) begin idle(1); t++; q = (vif.tx_valid === 1'b1) ? 0 : q + 1; end
    endtask
    // the sink's message is on the line: acknowledge it after `skips` lost tries
    task respond(int skips);
      for (int i = 0; i < 3; i++) begin
        if (!sending()) return;
        if (i < skips) begin quiet(60); continue; end
        gc(vif.msg_id);
        idle(2);
        return;
      end
      idle(40);                                      // third try lost: the send fails
    endtask
    // a source message the sink answers; skips lost GoodCRCs on its reply
    task exchange(logic [4:0] typ, int ndo = 0, int skips = 0);
      msg(typ, ndo);
      quiet(40);
      if (sending()) respond(skips);
    endtask
    // drive the port back to Ready / Wait_for_Capabilities
    task settle();
      for (int n = 0; n < 60; n++) begin
        case (vif.pe_state)
          P_READY, P_WCAP: begin if (vif.tx_valid !== 1'b1) return; idle(4); end
          P_DIS:  begin vbus(1); idle(3); end
          P_ERR:  begin vbus(0); idle(3); vbus(1); idle(3); end
          P_HRST: begin idle(25); src_id = 0; end
          P_WRSP: begin msg(C_REJECT); quiet(40); end
          P_TRANS: begin msg(C_PS_RDY); quiet(40); end
          P_WSRACC: begin msg(C_ACCEPT); quiet(40); end
          default: if (sending()) begin quiet(60); if (sending()) begin gc(vif.msg_id); idle(3); end end
                   else idle(4);
        endcase
      end
    endtask
    function void random_caps(output int n);
      n = $urandom_range(1, 5);
      caps[0] = fixed_pdo(5000, 100 * $urandom_range(5, 30));
      for (int i = 1; i < 7; i++) begin
        case ($urandom_range(0, 5))
          0: caps[i] = {2'b11, 30'(($urandom() & 32'h3FFF_FFFF))};               // APDO
          1: caps[i] = {2'b01, 30'(($urandom() & 32'h3FFF_FFFF))};               // battery
          default: caps[i] = fixed_pdo(1000 * $urandom_range(6, 20), 100 * $urandom_range(5, 50));
        endcase
      end
    endfunction
    // Source_Capabilities -> Request -> outcome
    //   0 Accept + PS_RDY  1 Reject  2 Wait  3 no response  4 Accept, no PS_RDY
    //   5 Ping instead of a response (Soft_Reset)  6 Accept then Ping (Hard Reset)
    task negotiate(int outcome, int req_skips = 0);
      int n;
      random_caps(n);
      exchange(D_SRC_CAP, n, req_skips);
      if (vif.pe_state != P_WRSP) begin
        `uvm_info("PD_SEQ", $sformatf("negotiate: after Source_Capabilities %s", pe_name(vif.pe_state)), UVM_MEDIUM)
        return;
      end
      case (outcome)
        0: begin exchange(C_ACCEPT); idle($urandom_range(5, 60)); exchange(C_PS_RDY); end
        1: exchange(C_REJECT);
        2: exchange(C_WAIT);
        3: idle(110);
        4: begin exchange(C_ACCEPT); idle(210); end
        5: begin exchange(C_PING, 0, $urandom_range(0, 1)); end
        default: begin exchange(C_ACCEPT); exchange(C_PING); end
      endcase
    endtask
  endclass

  class usb_pd_regression_seq extends usb_pd_base_seq;
    // settle into Ready with an explicit contract
    task contract_up();
      for (int i = 0; i < 6; i++) begin
        settle();
        idle(2);
        if (vif.pe_state == P_READY && vif.contract) return;
        `uvm_info("PD_SEQ", $sformatf("contract_up: %s", pe_name(vif.pe_state)), UVM_LOW)
        negotiate(0);
        `uvm_info("PD_SEQ", $sformatf("contract_up: after negotiate %s contract %0d", pe_name(vif.pe_state), vif.contract), UVM_LOW)
      end
      `uvm_error("PD_SEQ", "no explicit contract after 6 negotiations")
    endtask
    `uvm_object_utils(usb_pd_regression_seq)
    int n_iter = 200;
    function new(string name = "usb_pd_regression_seq"); super.new(name); endfunction
    task body();
      int n;
      idle(3);
      vbus(1);
      idle(3);
      // directed: first contract, every Ready message, every error kind
      negotiate(0);
      exchange(C_GET_SNK);
      exchange(C_PING);
      exchange(C_DR_SWAP);
      exchange(D_VDM, 1);
      exchange(C_ACCEPT); settle();
      negotiate(0);
      negotiate(1);                                    // Reject / Wait keep the contract
      negotiate(2);
      exchange(C_SOFT_RST); settle();                  // Soft_Reset in Ready
      negotiate(0);
      exchange(C_ACCEPT, 0, 3); settle();              // Soft_Reset never acknowledged
      negotiate(0);
      exchange(C_WAIT); idle(110); settle();           // Soft_Reset never accepted
      negotiate(0);
      exchange(C_DR_SWAP, 0, 3); settle();             // Not_Supported lost: Soft_Reset
      negotiate(0);
      contract_up();
      vbus(0); idle(5); vbus(1); idle(3); settle();    // detach in a contract
      negotiate(0);
      exchange(C_SOFT_RST, 0, 3); settle();            // Accept for Soft_Reset lost: Hard Reset
      negotiate(0);
      msg(C_PING, 0, E_CRC); idle(10);
      msg(C_PING, 0, E_SYM); idle(10);
      msg(C_PING, 0, E_LEN); idle(10);
      msg(C_PING, 0, E_NONE, 1); idle(10);
      msg(C_PING, 0, E_NONE, 2); idle(10);
      exchange(C_PING); msg(C_PING, 0, E_NONE, 0, (src_id + 7) % 8); quiet(30);   // retry: duplicate
      ordered(K_CR); idle(5);
      ordered(K_HR, $urandom_range(0, 3)); settle();
      idle(420); settle();                                                       // SinkWaitCap
      for (int i = 0; i < 3; i++) begin idle(T_WCAP + 30); end                   // up to ErrorRecovery
      settle();
      for (int i = 0; i < n_iter; i++) begin
        settle();
        case ($urandom_range(0, 15))
          0, 1, 2: negotiate($urandom_range(0, 6), ($urandom_range(0, 5) == 0) ? $urandom_range(1, 3) : 0);
          3: if (vif.pe_state == P_READY) exchange(C_GET_SNK, 0, ($urandom_range(0, 3) == 0) ? $urandom_range(1, 3) : 0);
          4: exchange(C_PING);
          5: exchange(($urandom_range(0, 1) == 0) ? C_DR_SWAP : C_VCONN_SWAP, 0,
                      ($urandom_range(0, 3) == 0) ? $urandom_range(1, 3) : 0);
          6: begin exchange(C_SOFT_RST, 0, ($urandom_range(0, 3) == 0) ? $urandom_range(1, 3) : 0); end
          7: begin ordered(K_HR, ($urandom_range(0, 1) == 0) ? -1 : $urandom_range(0, 3)); idle(5); end
          8: begin msg(C_PING, 0, pd_err_e'($urandom_range(1, 3))); idle(8); end
          9: begin msg(C_PING, 0, E_NONE, $urandom_range(1, 2)); idle(8); end
          10: if (vif.pe_state == P_READY) begin
                exchange(($urandom_range(0, 1) == 0) ? C_ACCEPT : C_WAIT, 0, $urandom_range(0, 1));
                if (vif.pe_state == P_WSRACC && $urandom_range(0, 1) == 0) exchange(C_ACCEPT);
              end
          11: begin vbus(0); idle($urandom_range(2, 10)); vbus(1); idle(3); end
          12: want($urandom_range(100, 400), $urandom_range(50, 500));
          13: begin exchange(C_PING); msg(C_PING, 0, E_NONE, 0, (src_id + 7) % 8); quiet(30); end
          14: begin ordered(K_CR); idle(4); end
          default: begin msg(C_PING, 0, E_KCODE); quiet(30); end
        endcase
      end
      settle();
      idle(30);
    endtask
  endclass

  // ------------------------------------------------------------ env / test
  class usb_pd_env extends uvm_env;
    `uvm_component_utils(usb_pd_env)
    usb_pd_sequencer  sqr;
    usb_pd_driver     drv;
    usb_pd_monitor    mon;
    usb_pd_scoreboard sb;
    usb_pd_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      sqr = usb_pd_sequencer::type_id::create("sqr", this);
      drv = usb_pd_driver::type_id::create("drv", this);
      mon = usb_pd_monitor::type_id::create("mon", this);
      sb  = usb_pd_scoreboard::type_id::create("sb", this);
      cov = usb_pd_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(sb.analysis_export);
      mon.ap.connect(cov.analysis_export);
    endfunction
  endclass

  class usb_pd_link_test extends uvm_test;
    `uvm_component_utils(usb_pd_link_test)
    usb_pd_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      env = usb_pd_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      usb_pd_regression_seq s = usb_pd_regression_seq::type_id::create("s");
      phase.raise_objection(this);
      s.start(env.sqr);
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0 &&
          env.sb.n_ack > 30 && env.sb.n_trans > 100)
        $display("SB_PASS checks=%0d", env.sb.n_checks);
      else `uvm_error("TEST", "USB_PD_LINK_TEST FAILED")
    endfunction
  endclass
endpackage

`endif
