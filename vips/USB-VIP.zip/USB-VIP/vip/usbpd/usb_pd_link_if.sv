// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB Power Delivery interface between the source-side BFM and a sink port:
// one 4b5b symbol per clock each way (after BMC decoding), VBUS and the
// sink's request policy in, policy-engine state and counters out. See
// tb/usb_pd_smoke_model.sv for the encodings.
`ifndef USB_PD_LINK_IF_SV
`define USB_PD_LINK_IF_SV

interface usb_pd_link_if (input logic clk, input logic rst_n);
  // source -> sink
  logic       vbus_present;
  logic       rx_valid;
  logic [4:0] rx_sym;
  logic [9:0] want_v50;
  logic [9:0] want_ma10;
  // sink -> source
  logic       tx_valid;
  logic [4:0] tx_sym;
  logic [3:0] pe_state;
  logic       contract;
  logic [9:0] vbus_v50;
  logic [2:0] obj_pos;
  logic       mismatch;
  logic [2:0] msg_id;
  logic [7:0] rx_good, rx_bad, rx_dup, rx_other_sop, retries, hard_resets;
  logic [1:0] hr_counter;

  initial begin
    vbus_present = 1'b0; rx_valid = 1'b0; rx_sym = 5'h0; want_v50 = 10'd240; want_ma10 = 10'd150;
  end
endinterface

`endif
