// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Protocol Verification IP (VIP) Package
// Protocols: USB 2.0/3.0/3.1/3.2, USB4, eUSB2, USB-PD
// MAC + PHY Layer Coverage-Driven Random Regression Suite
//============================================================================
`ifndef USB_VIP_PKG_SV
`define USB_VIP_PKG_SV

package usb_vip_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // Device address of the functional DUT model (device endpoint).
  localparam logic [6:0] USB_DUT_DEV_ADDR = 7'h20;

  //==========================================================================
  // Protocol Enumeration
  //==========================================================================
  typedef enum int {
    USB_HS      = 0,   // USB 2.0 High Speed (480 Mbps)
    USB_SS      = 1,   // USB 3.0 SuperSpeed (5 Gbps)
    USB_SS_P    = 2,   // USB 3.1 SuperSpeed+ (10 Gbps)
    USB_SS_20   = 3,   // USB 3.2 SuperSpeed 20 (20 Gbps)
    USB4        = 4,   // USB4 (40 Gbps)
    EUSB2       = 5,   // eUSB2 (Embedded USB2)
    USB_PD      = 6,   // USB Power Delivery
    USB_MAX     = 7
  } usb_protocol_e;

  //==========================================================================
  // USB Speed Enumeration (Mbps)
  //==========================================================================
  typedef enum int {
    SPEED_LS    = 1,       // Low Speed 1.5 Mbps
    SPEED_FS    = 12,      // Full Speed 12 Mbps
    SPEED_HS    = 480,     // High Speed 480 Mbps
    SPEED_SS    = 5000,    // SuperSpeed 5 Gbps
    SPEED_SS_P  = 10000,   // SuperSpeed+ 10 Gbps
    SPEED_SS_20 = 20000,   // USB 3.2 Gen 2x2 20 Gbps
    SPEED_USB4  = 40000,   // USB4 40 Gbps
    SPEED_PD    = 0        // USB-PD (control, no data rate)
  } usb_speed_e;

  // eUSB2 runs at the same 480 Mbps rate as USB 2.0 High Speed.
  localparam usb_speed_e SPEED_EUSB2 = SPEED_HS;

  //==========================================================================
  // USB Device State Enumeration
  //==========================================================================
  typedef enum logic [3:0] {
    USB_STATE_DEFAULT       = 4'b0000,
    USB_STATE_ADDRESS       = 4'b0001,
    USB_STATE_CONFIGURED    = 4'b0010,
    USB_STATE_SUSPENDED     = 4'b0011,
    USB_STATE_RESUME        = 4'b0100,
    USB_STATE_RESET         = 4'b0101,
    USB_STATE_POWERED       = 4'b0110,
    USB_STATE_TEST          = 4'b0111,
    USB_STATE_WUSB          = 4'b1000
  } usb_device_state_e;

  //==========================================================================
  // USB Transaction Type Enumeration (MAC Layer)
  //==========================================================================
  typedef enum logic [4:0] {
    // USB 2.0 Token Types
    TOK_SOF         = 5'b00000,   // Start of Frame
    TOK_SETUP       = 5'b00001,   // Setup token
    TOK_IN          = 5'b00010,   // IN token
    TOK_OUT         = 5'b00011,   // OUT token
    TOK_PING        = 5'b00100,   // PING token (HS)
    TOK_SPLIT       = 5'b00101,   // SPLIT token (HS)
    // USB 2.0 Data Types
    DATA_DATA0      = 5'b00110,   // DATA0
    DATA_DATA1      = 5'b00111,   // DATA1
    DATA_DATA2      = 5'b01000,   // DATA2 (HS)
    DATA_MDATA      = 5'b01001,   // MDATA (HS)
    // USB 2.0 Handshake Types
    HS_ACK          = 5'b01010,   // ACK
    HS_NAK          = 5'b01011,   // NAK
    HS_STALL        = 5'b01100,   // STALL
    HS_NYET         = 5'b01101,   // NYET (HS)
    // USB 3.x Header Types (MAC)
    SS_HP_START     = 5'b01110,   // Header Packet Start
    SS_DP_START     = 5'b01111,   // Data Packet Start
    SS_STATUS       = 5'b10000,   // Link Command/Status
    // USB4 Packet Types
    USB4_CTRL       = 5'b10001,   // Control Packet
    USB4_DATA       = 5'b10010,   // Data Packet
    USB4_TUNNEL     = 5'b10011,   // Tunneled Packet
    USB4_TIME_SYNC  = 5'b10100,   // Time Sync
    // USB-PD Message Types
    PD_CTRL_GOODCRC = 5'b10101,   // GoodCRC
    PD_CTRL_GOTOMIN = 5'b10110,   // GotoMin
    PD_CTRL_ACCEPT  = 5'b10111,   // Accept
    PD_CTRL_REJECT  = 5'b11000,   // Reject
    PD_CTRL_PS_RDY  = 5'b11001,   // PS_RDY
    PD_DATA_SRC_CAP = 5'b11010,   // Source Capabilities
    PD_DATA_REQ     = 5'b11011,   // Request
    PD_DATA_BIST    = 5'b11100,   // BIST
    USB_UNKNOWN     = 5'b11111    // Unknown
  } usb_txn_type_e;

  //==========================================================================
  // USB Endpoint Type
  //==========================================================================
  typedef enum logic [2:0] {
    EP_CONTROL      = 3'b000,
    EP_ISOCHRONOUS  = 3'b001,
    EP_BULK         = 3'b010,
    EP_INTERRUPT    = 3'b011,
    EP_ALL          = 3'b100
  } usb_ep_type_e;

  //==========================================================================
  // USB Transfer Status
  //==========================================================================
  typedef enum logic [3:0] {
    XFER_OK         = 4'b0000,
    XFER_CRC_ERR    = 4'b0001,
    XFER_TIMEOUT    = 4'b0010,
    XFER_STALL      = 4'b0011,
    XFER_BABBLE     = 4'b0100,
    XFER_BUFFER_ERR = 4'b0101,
    XFER_BIT_STUFF  = 4'b0110,
    XFER_SEQ_ERR    = 4'b0111,
    XFER_DISCONNECT = 4'b1000,
    XFER_SUSPEND    = 4'b1001
  } usb_xfer_status_e;

  //==========================================================================
  // PHY Interface Type
  //==========================================================================
  typedef enum logic [2:0] {
    PHY_UTMI        = 3'b000,   // USB 2.0 Transceiver Macrocell
    PHY_ULPI        = 3'b001,   // UTMI+ Low Pin Interface
    PHY_PIPE        = 3'b010,   // USB 3.0 PHY Interface
    PHY_PIPE4       = 3'b011,   // USB4/Thunderbolt PHY
    PHY_SBU         = 3'b100,   // USB-PD Sideband Unit
    PHY_RDI         = 3'b101    // USB4 Retimer/DMA Interface
  } usb_phy_if_e;

  //==========================================================================
  // USB-PD Power Contract
  //==========================================================================
  typedef enum logic [3:0] {
    PD_5V_0P5A      = 4'b0000,   // 5V @ 0.5A = 2.5W
    PD_5V_0P9A      = 4'b0001,   // 5V @ 0.9A = 4.5W
    PD_5V_1P5A      = 4'b0010,   // 5V @ 1.5A = 7.5W
    PD_5V_3A        = 4'b0011,   // 5V @ 3A = 15W
    PD_9V_3A        = 4'b0100,   // 9V @ 3A = 27W
    PD_15V_3A       = 4'b0101,   // 15V @ 3A = 45W
    PD_20V_3A       = 4'b0110,   // 20V @ 3A = 60W
    PD_20V_5A       = 4'b0111,   // 20V @ 5A = 100W
    PD_PPS          = 4'b1000,   // Programmable Power Supply
    PD_EPR          = 4'b1001    // Extended Power Range (240W)
  } usb_pd_contract_e;

  //==========================================================================
  // Configuration Structure
  //==========================================================================
  typedef struct packed {
    usb_protocol_e  protocol;
    usb_speed_e     speed;
    int             num_endpoints;
    int             max_packet_size;
    bit             lpm_enabled;
    bit             uas_enabled;
    bit             uvc_enabled;
    bit             dual_role;
    bit             pd_enabled;
    usb_phy_if_e    phy_if;
    int             pipe_width;
    int             ltssm_timeout;
    bit             crc5_enabled;
    bit             crc16_enabled;
    bit             crc32_enabled;
  } usb_protocol_cfg_t;

  //==========================================================================
  // Coverage Configuration
  //==========================================================================
  typedef struct packed {
    bit             cov_txn_types;
    bit             cov_endpoints;
    bit             cov_packet_sizes;
    bit             cov_device_states;
    bit             cov_error_injection;
    bit             cov_phy_states;
    bit             cov_pd_contracts;
    bit             cov_mac_states;
    bit             cov_cross_layer;
  } usb_coverage_cfg_t;

  //==========================================================================
  // USB PID encode/decode helpers (PID[7:4] = ~PID[3:0])
  //==========================================================================
  function automatic logic [7:0] usb_pid_encode(usb_txn_type_e t);
    case (t)
      TOK_OUT:        return 8'hE1;
      TOK_IN:         return 8'h69;
      TOK_SOF:        return 8'hA5;
      TOK_SETUP:      return 8'h2D;
      TOK_PING:       return 8'hB4;
      TOK_SPLIT:      return 8'h78;
      DATA_DATA0:     return 8'hC3;
      DATA_DATA1:     return 8'h4B;
      DATA_DATA2:     return 8'h87;
      DATA_MDATA:     return 8'h0F;
      HS_ACK:         return 8'hD2;
      HS_NAK:         return 8'h5A;
      HS_STALL:       return 8'h1E;
      HS_NYET:        return 8'h96;
      // SS / USB4 / PD types: complement-encoded pseudo-PID
      default:        return {~t[3:0], t[3:0]};
    endcase
  endfunction

  function automatic usb_txn_type_e usb_pid_decode(logic [7:0] pid);
    case (pid)
      8'hE1:    return TOK_OUT;
      8'h69:    return TOK_IN;
      8'hA5:    return TOK_SOF;
      8'h2D:    return TOK_SETUP;
      8'hB4:    return TOK_PING;
      8'h78:    return TOK_SPLIT;
      8'hC3:    return DATA_DATA0;
      8'h4B:    return DATA_DATA1;
      8'h87:    return DATA_DATA2;
      8'h0F:    return DATA_MDATA;
      8'hD2:    return HS_ACK;
      8'h5A:    return HS_NAK;
      8'h1E:    return HS_STALL;
      8'h96:    return HS_NYET;
      default:  return USB_UNKNOWN;
    endcase
  endfunction

  // Protocol-aware PID decode: USB 2.0 uses the standard PID table;
  // SS/USB4/PD classes use complement-encoded pseudo-PIDs.
  function automatic usb_txn_type_e usb_pid_decode_proto(usb_protocol_e prot, logic [7:0] pid);
    if (prot inside {USB_HS, EUSB2})
      return usb_pid_decode(pid);
    if (pid[7:4] != ~pid[3:0])
      return USB_UNKNOWN;
    case (prot)
      USB_SS, USB_SS_P, USB_SS_20: begin
        case (pid[3:0])
          4'hE:    return SS_HP_START;
          4'hF:    return SS_DP_START;
          4'h0:    return SS_STATUS;
          default: return USB_UNKNOWN;
        endcase
      end
      USB4: begin
        if (pid[3:0] inside {[4'h1:4'h4]})
          return usb_txn_type_e'(5'(16 + pid[3:0]));
        return USB_UNKNOWN;
      end
      USB_PD: begin
        if (pid[3:0] inside {[4'h5:4'hC]})
          return usb_txn_type_e'(5'(16 + pid[3:0]));
        return USB_UNKNOWN;
      end
      default: return usb_pid_decode(pid);
    endcase
  endfunction

  // Packet classes that carry a payload on the MAC stream
  function automatic bit usb_type_has_payload(usb_txn_type_e t);
    return t inside {DATA_DATA0, DATA_DATA1, DATA_DATA2, DATA_MDATA,
                     SS_DP_START, USB4_DATA, USB4_TUNNEL};
  endfunction

  //==========================================================================
  // USB Transaction Descriptor (MAC Layer)
  //==========================================================================
  class usb_txn_descriptor extends uvm_object;
    `uvm_object_utils(usb_txn_descriptor)

    rand usb_protocol_e     protocol;
    rand usb_txn_type_e     txn_type;
    rand logic [6:0]        device_addr;
    rand logic [3:0]        endpoint;
    rand usb_ep_type_e      ep_type;
    rand int                packet_len;
    rand logic [7:0]        payload[];
    rand logic [4:0]        crc5;
    rand logic [15:0]       crc16;
    rand logic [31:0]       crc32;
    rand logic [7:0]        pid;
    rand logic [10:0]       frame_number;
    rand logic [3:0]        hub_addr;
    rand logic [6:0]        port_number;
    rand bit                sc;             // Start/Complete (SPLIT)
    rand usb_device_state_e dev_state;
    rand usb_pd_contract_e  pd_contract;
    rand int                voltage_mv;
    rand int                current_ma;
    rand bit                inject_crc_err;
    rand bit                inject_timeout;
    rand bit                inject_stall;
    rand bit                inject_babble;
    rand int                inter_packet_gap;

    // PHY layer observations (filled by driver/monitor)
    usb_phy_if_e            phy_if;
    bit                     phy_term;
    bit                     phy_suspend;

    // Timestamps
    time                    start_time;
    time                    end_time;

    usb_xfer_status_e       status;

    // Constraints
    constraint c_device_addr {
      device_addr inside {[1:127]};   // Addr 0 is default
    }
    constraint c_endpoint {
      endpoint inside {[0:15]};
      if (ep_type == EP_CONTROL) endpoint == 4'd0;
    }
    constraint c_packet_len {
      if (protocol inside {USB_HS, EUSB2})
        packet_len inside {[0:1024]};    // USB 2.0 max 1024 (HS)
      else if (protocol == USB_SS)
        packet_len inside {[0:1024]};    // USB 3.0 max 1024
      else if (protocol == USB_SS_P)
        packet_len inside {[0:1024]};    // USB 3.1 max 1024
      else if (protocol == USB_SS_20)
        packet_len inside {[0:1024]};    // USB 3.2 max 1024
      else if (protocol == USB4)
        packet_len inside {[0:4096]};    // USB4 larger packets
      else if (protocol == USB_PD)
        packet_len inside {[0:260]};     // PD max 260 bytes
      else
        packet_len inside {[0:64]};
    }
    constraint c_payload_size {
      payload.size() == packet_len;
    }
    constraint c_frame_number {
      frame_number inside {[0:2047]};
    }
    constraint c_pd_voltage {
      if (protocol == USB_PD)
        voltage_mv inside {[5000:48000]};   // 5V-48V EPR
    }
    constraint c_pd_current {
      if (protocol == USB_PD)
        current_ma inside {[100:5000]};     // 0.1A-5A
    }
    constraint c_error_rate {
      inject_crc_err  dist { 0 := 95, 1 := 5 };
      inject_timeout  dist { 0 := 97, 1 := 3 };
      inject_stall    dist { 0 := 98, 1 := 2 };
      inject_babble   dist { 0 := 99, 1 := 1 };
    }
    constraint c_inter_packet_gap {
      inter_packet_gap inside {[2:16]};   // USB 2.0: min 2 bit times
    }
    constraint c_phy_if {
      if (protocol inside {USB_HS, EUSB2})
        phy_if inside {PHY_UTMI, PHY_ULPI};
      else if (protocol inside {USB_SS, USB_SS_P, USB_SS_20})
        phy_if == PHY_PIPE;
      else if (protocol == USB4)
        phy_if inside {PHY_PIPE4, PHY_RDI};
      else if (protocol == USB_PD)
        phy_if == PHY_SBU;
    }

    function new(string name = "usb_txn_descriptor");
      super.new(name);
    endfunction

    function void post_randomize();
      start_time = $time;
      // Compute CRCs
      crc5  = compute_crc5({device_addr, endpoint});
      crc16 = compute_crc16(payload);
      crc32 = compute_crc32(payload);
      pid   = usb_pid_encode(txn_type);
    endfunction

    function logic [4:0] compute_crc5(logic [10:0] data);
      logic [4:0] crc = 5'h1F;
      for (int i = 0; i < 11; i++) begin
        if (crc[4] ^ data[i])
          crc = {crc[3:0], 1'b0} ^ 5'h05;
        else
          crc = {crc[3:0], 1'b0};
      end
      return ~crc;
    endfunction

    function logic [15:0] compute_crc16(logic [7:0] data[]);
      logic [15:0] crc = 16'hFFFF;
      foreach (data[i]) begin
        for (int j = 0; j < 8; j++) begin
          if (crc[15] ^ data[i][j])
            crc = {crc[14:0], 1'b0} ^ 16'h8005;
          else
            crc = {crc[14:0], 1'b0};
        end
      end
      return ~crc;
    endfunction

    function logic [31:0] compute_crc32(logic [7:0] data[]);
      logic [31:0] crc = 32'hFFFFFFFF;
      foreach (data[i]) begin
        for (int j = 0; j < 8; j++) begin
          if (crc[31] ^ data[i][j])
            crc = {crc[30:0], 1'b0} ^ 32'h04C11DB7;
          else
            crc = {crc[30:0], 1'b0};
        end
      end
      return ~crc;
    endfunction

    function void set_complete(usb_xfer_status_e s);
      status = s;
      end_time = $time;
    endfunction

    function int get_latency_ns();
      if (end_time > start_time)
        return int'((end_time - start_time) / 1ns);
      else
        return 0;
    endfunction

    virtual function string convert2string();
      string s;
      $sformat(s, "USB %s | %s | Dev=0x%02X EP=%0d len=%0d status=%s lat=%0dns",
               protocol.name(), txn_type.name(), device_addr, endpoint,
               packet_len, status.name(), get_latency_ns());
      return s;
    endfunction
  endclass

  //==========================================================================
  // Base Sequence Item
  //==========================================================================
  class usb_sequence_item extends uvm_sequence_item;
    `uvm_object_utils(usb_sequence_item)

    rand usb_txn_descriptor txn;

    constraint c_default {
      txn.protocol != USB_MAX;
    }

    function new(string name = "usb_sequence_item");
      super.new(name);
      txn = usb_txn_descriptor::type_id::create("txn");
    endfunction

    virtual function string convert2string();
      return txn.convert2string();
    endfunction
  endclass

  //==========================================================================
  // Protocol Configuration Object
  //==========================================================================
  class usb_protocol_config extends uvm_object;
    `uvm_object_utils(usb_protocol_config)

    usb_protocol_e      protocol;
    usb_protocol_cfg_t  cfg;
    usb_coverage_cfg_t  cov_cfg;

    function new(string name = "usb_protocol_config", usb_protocol_e p = USB_HS);
      super.new(name);
      protocol = p;
      set_default_cfg();
    endfunction

    function void set_default_cfg();
      case (protocol)
        USB_HS: begin
          cfg.protocol        = USB_HS;
          cfg.speed           = SPEED_HS;
          cfg.num_endpoints   = 16;
          cfg.max_packet_size = 512;
          cfg.lpm_enabled     = 1;
          cfg.phy_if          = PHY_UTMI;
          cfg.pipe_width      = 8;
          cfg.crc5_enabled    = 1;
          cfg.crc16_enabled   = 1;
        end
        USB_SS: begin
          cfg.protocol        = USB_SS;
          cfg.speed           = SPEED_SS;
          cfg.num_endpoints   = 32;
          cfg.max_packet_size = 1024;
          cfg.uas_enabled     = 1;
          cfg.phy_if          = PHY_PIPE;
          cfg.pipe_width      = 32;
          cfg.crc32_enabled   = 1;
        end
        USB_SS_P: begin
          cfg.protocol        = USB_SS_P;
          cfg.speed           = SPEED_SS_P;
          cfg.num_endpoints   = 32;
          cfg.max_packet_size = 1024;
          cfg.uas_enabled     = 1;
          cfg.phy_if          = PHY_PIPE;
          cfg.pipe_width      = 32;
          cfg.crc32_enabled   = 1;
        end
        USB_SS_20: begin
          cfg.protocol        = USB_SS_20;
          cfg.speed           = SPEED_SS_20;
          cfg.num_endpoints   = 32;
          cfg.max_packet_size = 1024;
          cfg.dual_role       = 1;
          cfg.phy_if          = PHY_PIPE;
          cfg.pipe_width      = 32;
          cfg.crc32_enabled   = 1;
        end
        USB4: begin
          cfg.protocol        = USB4;
          cfg.speed           = SPEED_USB4;
          cfg.num_endpoints   = 64;
          cfg.max_packet_size = 4096;
          cfg.dual_role       = 1;
          cfg.pd_enabled      = 1;
          cfg.phy_if          = PHY_PIPE4;
          cfg.pipe_width      = 128;
          cfg.crc32_enabled   = 1;
        end
        EUSB2: begin
          cfg.protocol        = EUSB2;
          cfg.speed           = SPEED_EUSB2;
          cfg.num_endpoints   = 8;
          cfg.max_packet_size = 64;
          cfg.phy_if          = PHY_ULPI;
          cfg.pipe_width      = 4;
          cfg.crc5_enabled    = 1;
          cfg.crc16_enabled   = 1;
        end
        USB_PD: begin
          cfg.protocol        = USB_PD;
          cfg.speed           = SPEED_PD;
          cfg.num_endpoints   = 1;
          cfg.max_packet_size = 260;
          cfg.pd_enabled      = 1;
          cfg.phy_if          = PHY_SBU;
          cfg.pipe_width      = 1;
        end
        default: begin
          cfg.protocol        = USB_HS;
          cfg.speed           = SPEED_HS;
          cfg.num_endpoints   = 16;
          cfg.max_packet_size = 64;
        end
      endcase
      cfg.ltssm_timeout = 100000;   // 100us

      // Default coverage enable
      cov_cfg.cov_txn_types       = 1;
      cov_cfg.cov_endpoints       = 1;
      cov_cfg.cov_packet_sizes    = 1;
      cov_cfg.cov_device_states   = 1;
      cov_cfg.cov_error_injection = 1;
      cov_cfg.cov_phy_states      = 1;
      cov_cfg.cov_pd_contracts    = 1;
      cov_cfg.cov_mac_states      = 1;
      cov_cfg.cov_cross_layer     = 1;
    endfunction
  endclass

  //==========================================================================
  // Coverage Model Base Class
  //==========================================================================
  class usb_coverage_model extends uvm_component;
    `uvm_component_utils(usb_coverage_model)

    // Coverage variables (declared before the covergroups that sample them)
    usb_protocol_e      txn_protocol;
    usb_txn_type_e      txn_type;
    logic [3:0]         endpoint;
    usb_ep_type_e       ep_type;
    int                 packet_len;
    usb_device_state_e  dev_state;
    usb_phy_if_e        phy_if;
    bit                 phy_term;
    bit                 phy_suspend;
    usb_pd_contract_e   pd_contract;
    int                 voltage_mv;
    int                 error_type;
    bit                 recovery_triggered;
    logic [7:0]         first_byte;

    // Transaction type coverage (protocol configuration group)
    covergroup cg_txn_type;
      option.per_instance = 1;
      cp_protocol: coverpoint txn_protocol {
        bins usb_hs     = {USB_HS};
        bins usb_ss     = {USB_SS};
        bins usb_ss_p   = {USB_SS_P};
        bins usb_ss_20  = {USB_SS_20};
        bins usb4       = {USB4};
        bins eusb2      = {EUSB2};
        bins usb_pd     = {USB_PD};
      }
      cp_txn_type: coverpoint txn_type {
        bins tokens     = {TOK_SOF, TOK_SETUP, TOK_IN, TOK_OUT, TOK_PING, TOK_SPLIT};
        bins data       = {DATA_DATA0, DATA_DATA1, DATA_DATA2, DATA_MDATA};
        bins handshake  = {HS_ACK, HS_NAK, HS_STALL, HS_NYET};
        bins ss_header  = {SS_HP_START, SS_DP_START, SS_STATUS};
        bins usb4_pkt   = {USB4_CTRL, USB4_DATA, USB4_TUNNEL, USB4_TIME_SYNC};
        bins pd_ctrl    = {PD_CTRL_GOODCRC, PD_CTRL_ACCEPT, PD_CTRL_REJECT, PD_CTRL_PS_RDY};
        bins pd_data    = {PD_DATA_SRC_CAP, PD_DATA_REQ, PD_DATA_BIST};
      }
      cross_protocol_txn: cross cp_protocol, cp_txn_type;
    endgroup

    covergroup cg_endpoint;
      option.per_instance = 1;
      cp_ep_num: coverpoint endpoint {
        bins ep0    = {0};
        bins ep1_7  = {[1:7]};
        bins ep8_15 = {[8:15]};
      }
      cp_ep_type: coverpoint ep_type {
        bins control     = {EP_CONTROL};
        bins isochronous = {EP_ISOCHRONOUS};
        bins bulk        = {EP_BULK};
        bins interrupt   = {EP_INTERRUPT};
      }
      cross_ep: cross cp_ep_num, cp_ep_type;
    endgroup

    covergroup cg_packet_size;
      option.per_instance = 1;
      cp_size: coverpoint packet_len {
        bins zlp        = {0};
        bins little     = {[1:8]};
        bins med        = {[9:64]};
        bins big        = {[65:512]};
        bins hs_max     = {[513:1024]};
        bins superspeed = {[1025:4096]};
      }
      cp_protocol: coverpoint txn_protocol {
        bins usb2 = {USB_HS, EUSB2};
        bins usb3 = {USB_SS, USB_SS_P, USB_SS_20};
        bins usb4 = {USB4};
        bins pd   = {USB_PD};
      }
      cross_size_prot: cross cp_size, cp_protocol;
    endgroup

    // Device FSM state coverage (with transition bins)
    covergroup cg_device_state;
      option.per_instance = 1;
      cp_state: coverpoint dev_state {
        bins defaulted   = {USB_STATE_DEFAULT};
        bins addressed   = {USB_STATE_ADDRESS};
        bins configured  = {USB_STATE_CONFIGURED};
        bins suspended   = {USB_STATE_SUSPENDED};
        bins resumed     = {USB_STATE_RESUME};
        bins reset       = {USB_STATE_RESET};
        bins powered     = {USB_STATE_POWERED};
        bins pwr_to_def  = (USB_STATE_POWERED => USB_STATE_DEFAULT);
        bins def_to_addr = (USB_STATE_DEFAULT => USB_STATE_ADDRESS);
        bins addr_to_cfg = (USB_STATE_ADDRESS => USB_STATE_CONFIGURED);
        bins any_to_rst  = (USB_STATE_DEFAULT, USB_STATE_ADDRESS,
                            USB_STATE_CONFIGURED => USB_STATE_RESET);
      }
      cp_protocol: coverpoint txn_protocol {
        bins usb2 = {USB_HS, EUSB2};
        bins usb3 = {USB_SS, USB_SS_P, USB_SS_20};
        bins usb4 = {USB4};
      }
      cross_state_prot: cross cp_state, cp_protocol {
        ignore_bins ig = binsof(cp_state) intersect {USB_STATE_POWERED};
      }
    endgroup

    covergroup cg_phy_layer;
      option.per_instance = 1;
      cp_phy_if: coverpoint phy_if {
        bins utmi  = {PHY_UTMI};
        bins ulpi  = {PHY_ULPI};
        bins pipe  = {PHY_PIPE};
        bins pipe4 = {PHY_PIPE4};
        bins sbu   = {PHY_SBU};
        bins rdi   = {PHY_RDI};
      }
      cp_term: coverpoint phy_term {
        bins off = {0};
        bins on  = {1};
      }
      cp_suspend: coverpoint phy_suspend {
        bins active  = {0};
        bins suspend = {1};
      }
      cross_phy_term: cross cp_phy_if, cp_term;
    endgroup

    covergroup cg_pd_contract;
      option.per_instance = 1;
      cp_contract: coverpoint pd_contract {
        bins low_power  = {PD_5V_0P5A, PD_5V_0P9A, PD_5V_1P5A};
        bins standard   = {PD_5V_3A, PD_9V_3A};
        bins high_power = {PD_15V_3A, PD_20V_3A, PD_20V_5A};
        bins epr        = {PD_EPR};
        bins pps        = {PD_PPS};
      }
      cp_voltage: coverpoint voltage_mv {
        bins v5  = {[5000:5999]};
        bins v9  = {[9000:9999]};
        bins v15 = {[15000:15999]};
        bins v20 = {[20000:20999]};
        bins v28 = {[28000:36999]};
        bins v48 = {[37000:48000]};
      }
      cross_contract_volt: cross cp_contract, cp_voltage;
    endgroup

    covergroup cg_error_injection;
      option.per_instance = 1;
      cp_error_type: coverpoint error_type {
        bins crc_err   = {0};
        bins timeout   = {1};
        bins stall     = {2};
        bins babble    = {3};
        bins bit_stuff = {4};
      }
      cp_recovery: coverpoint recovery_triggered {
        bins yes = {1};
        bins no  = {0};
      }
      cross_err_rec: cross cp_error_type, cp_recovery;
    endgroup

    // Data pattern coverage (payload corner bytes)
    covergroup cg_data_pattern;
      option.per_instance = 1;
      cp_first_byte: coverpoint first_byte {
        bins zero     = {8'h00};
        bins ones     = {8'hFF};
        bins aa       = {8'hAA};
        bins fiftyfive = {8'h55};
        bins other    = default;
      }
      cp_len: coverpoint packet_len {
        bins zlp   = {0};
        bins short = {[1:8]};
        bins long  = {[9:4096]};
      }
      cross_byte_len: cross cp_first_byte, cp_len;
    endgroup

    function new(string name = "usb_coverage_model", uvm_component parent = null);
      super.new(name, parent);
      cg_txn_type        = new();
      cg_endpoint        = new();
      cg_packet_size     = new();
      cg_device_state    = new();
      cg_phy_layer       = new();
      cg_pd_contract     = new();
      cg_error_injection = new();
      cg_data_pattern    = new();
    endfunction

    virtual function void sample_transaction(usb_txn_descriptor txn);
      txn_protocol = txn.protocol;
      txn_type     = txn.txn_type;
      endpoint     = txn.endpoint;
      ep_type      = txn.ep_type;
      packet_len   = txn.packet_len;
      dev_state    = txn.dev_state;
      phy_if       = txn.phy_if;
      phy_term     = txn.phy_term;
      phy_suspend  = txn.phy_suspend;
      pd_contract  = txn.pd_contract;
      voltage_mv   = txn.voltage_mv;
      first_byte   = (txn.payload.size() > 0) ? txn.payload[0] : 8'h00;

      cg_txn_type.sample();
      cg_endpoint.sample();
      cg_packet_size.sample();
      cg_device_state.sample();
      cg_phy_layer.sample();
      cg_pd_contract.sample();
      cg_data_pattern.sample();
    endfunction

    virtual function void sample_error(int err_type, bit recovery);
      error_type = err_type;
      recovery_triggered = recovery;
      cg_error_injection.sample();
    endfunction

    virtual function real get_coverage();
      real cov = 0;
      cov += cg_txn_type.get_coverage();
      cov += cg_endpoint.get_coverage();
      cov += cg_packet_size.get_coverage();
      cov += cg_device_state.get_coverage();
      cov += cg_phy_layer.get_coverage();
      cov += cg_pd_contract.get_coverage();
      cov += cg_error_injection.get_coverage();
      cov += cg_data_pattern.get_coverage();
      return cov / 8.0;
    endfunction
  endclass

  //==========================================================================
  // Scoreboard: end-to-end comparison of driver-issued (expected) vs
  // monitor-decoded (observed) transactions.
  //==========================================================================
  `uvm_analysis_imp_decl(_exp)

  class usb_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(usb_scoreboard)

    uvm_analysis_imp     #(usb_sequence_item, usb_scoreboard) analysis_imp; // observed (monitor)
    uvm_analysis_imp_exp #(usb_sequence_item, usb_scoreboard) exp_imp;      // expected (driver)

    usb_sequence_item expected_queue[$];
    usb_sequence_item received_queue[$];

    int txn_count;
    int error_count;
    int mismatch_count;
    int unsigned n_matches;
    int unsigned n_mismatches;

    function new(string name = "usb_scoreboard", uvm_component parent = null);
      super.new(name, parent);
      analysis_imp = new("analysis_imp", this);
      exp_imp      = new("exp_imp", this);
      txn_count       = 0;
      error_count     = 0;
      mismatch_count  = 0;
      n_matches       = 0;
      n_mismatches    = 0;
    endfunction

    // Observed transaction from monitor
    virtual function void write(usb_sequence_item txn);
      received_queue.push_back(txn);
      txn_count++;
      `uvm_info("SCOREBOARD", $sformatf("Received: %s", txn.convert2string()), UVM_MEDIUM)
      check_transaction(txn);
      compare_queues();
    endfunction

    // Expected transaction from driver
    virtual function void write_exp(usb_sequence_item txn);
      expected_queue.push_back(txn);
      `uvm_info("SCOREBOARD", $sformatf("Expected: %s", txn.convert2string()), UVM_MEDIUM)
      compare_queues();
    endfunction

    // Pairwise end-to-end comparison
    virtual function void compare_queues();
      while (expected_queue.size() > 0 && received_queue.size() > 0) begin
        usb_sequence_item e = expected_queue.pop_front();
        usb_sequence_item o = received_queue.pop_front();
        if (compare_item(e, o)) begin
          n_matches++;
          `uvm_info("SCOREBOARD", $sformatf("MATCH: %s", e.convert2string()), UVM_HIGH)
        end else begin
          n_mismatches++;
          mismatch_count++;
          `uvm_error("SCOREBOARD", $sformatf("MISMATCH exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    virtual function bit compare_item(usb_sequence_item e, usb_sequence_item o);
      if (e.txn.txn_type    != o.txn.txn_type)    return 0;
      if (e.txn.device_addr != o.txn.device_addr) return 0;
      if (e.txn.endpoint    != o.txn.endpoint)    return 0;
      if (e.txn.status      != o.txn.status)      return 0;
      if (usb_type_has_payload(e.txn.txn_type)) begin
        if (e.txn.packet_len != o.txn.packet_len) return 0;
        foreach (e.txn.payload[i])
          if (i < o.txn.payload.size() && e.txn.payload[i] != o.txn.payload[i]) return 0;
      end
      return 1;
    endfunction

    virtual function void check_transaction(usb_sequence_item txn);
      if (txn.txn.status inside {XFER_CRC_ERR, XFER_TIMEOUT, XFER_STALL, XFER_BABBLE}) begin
        error_count++;
        `uvm_warning("SCOREBOARD", "Transaction completed with error status")
      end
    endfunction

    virtual function void report_phase(uvm_phase phase);
      super.report_phase(phase);
      `uvm_info("SCOREBOARD_REPORT", $sformatf(
        "Total Transactions: %0d | Errors: %0d | Mismatches: %0d",
        txn_count, error_count, mismatch_count), UVM_LOW)
      `uvm_info("SCOREBOARD_REPORT", $sformatf(
        "End-to-end: n_matches=%0d n_mismatches=%0d", n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches > 0)
        `uvm_error("SCOREBOARD", "End-to-end n_mismatches detected")
      if (expected_queue.size() > 0)
        `uvm_warning("SCOREBOARD", $sformatf("%0d expected transactions never observed",
                     expected_queue.size()))
    endfunction
  endclass

  //==========================================================================
  // UVM component / sequence / test classes (compiled inside the package so
  // that declaration order is well defined).
  //==========================================================================
  `include "usb_sequencer.sv"
  `include "usb_driver.sv"
  `include "usb_monitor.sv"
  `include "usb_agent.sv"
  `include "usb2_protocol_checker.sv"
  `include "usb3_protocol_checker.sv"
  `include "usb4_protocol_checker.sv"
  `include "eusb2_protocol_checker.sv"
  `include "usbpd_protocol_checker.sv"
  `include "usb_unified_checker.sv"
  `include "usb_base_sequence.sv"
  `include "usb_random_sequence.sv"
  `include "usb_regression_sequence.sv"
  `include "usb_env.sv"
  `include "usb_base_test.sv"
  `include "usb_tests.sv"

endpackage
`endif
