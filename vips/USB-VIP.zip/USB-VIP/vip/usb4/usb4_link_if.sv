// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB4 lane adapter interface between the far-end router BFM and a
// device-side lane adapter / transport layer: ordered sets per lane and
// transport-packet words in, ordered sets, packet words, lane states and
// counters out. One item per clock. See tb/usb4_smoke_model.sv.
`ifndef USB4_LINK_IF_SV
`define USB4_LINK_IF_SV

interface usb4_link_if (input logic clk, input logic rst_n);
  // far end -> adapter
  logic [1:0]  lane_det;
  logic        gen3_cap;
  logic        os_valid;
  logic        os_lane;
  logic [2:0]  os_kind;        // 0 SLOS 1 TS1 2 TS2 3 CL_REQ 4 CLD 5 WAKE
  logic        os_gen3;
  logic        w_valid, w_first, w_last;
  logic [31:0] w_data;
  logic [2:0]  w_sym_err;
  logic        out_busy;
  // adapter -> far end
  logic [2:0]  ls0, ls1;
  logic        gen3;
  logic [1:0]  width;
  logic        tx_os_valid, tx_os_lane;
  logic [2:0]  tx_os_kind;     // 0 SLOS 1 TS1 2 TS2 6 CL_ACK 7 CL_NAK
  logic        tx_valid, tx_first, tx_last;
  logic [31:0] tx_data;
  logic [7:0]  hec_err, len_err, crc_err, ovf_err, unk_hop, fec_corr, fec_unc;
  logic [7:0]  fwd_cnt, dup_cnt, notif_cnt, train_tmo, retrains;

  initial begin
    lane_det = 2'b00; gen3_cap = 1'b1; os_valid = 1'b0; os_lane = 1'b0; os_kind = 3'd0; os_gen3 = 1'b0;
    w_valid = 1'b0; w_first = 1'b0; w_last = 1'b0; w_data = 32'h0; w_sym_err = 3'd0; out_busy = 1'b0;
  end
endinterface

`endif
