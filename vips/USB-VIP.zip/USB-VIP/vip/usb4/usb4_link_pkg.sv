// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB4 UVM agent (far-end router side) for a device lane adapter on
// usb4_link_if:
//   usb4_item / usb4_driver  one ordered set on a lane, a transport packet
//                            (with HEC / length / symbol errors), a control
//                            request, idle, lane detect, Gen 3 capability
//                            or egress back-pressure
//   usb4_monitor             both directions, lane states before / after
//                            each clock
//   usb4_scoreboard          predicts the adapter clock by clock: both
//                            lane state machines (training steps, timeout,
//                            CLD, CLx ACK / NAK, WAKE, retrain after 4
//                            uncorrectable packets), Gen 3, width and the
//                            ordered sets it answers with; the transport
//                            layer: every output word in order (control
//                            responses, retransmissions, notifications,
//                            forwards with HopID translation, Credit
//                            Grants on buffer release) and every counter
//   usb4_coverage            lane transitions, packet kinds, errors
//   sequences + usb4_env + usb4_link_test
`ifndef USB4_LINK_PKG_SV
`define USB4_LINK_PKG_SV

package usb4_link_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [2:0] L_CLD = 3'd0, L_LOCK = 3'd1, L_TS1 = 3'd2, L_TS2 = 3'd3, L_CL0 = 3'd4, L_CLX = 3'd5;
  localparam logic [2:0] O_SLOS = 3'd0, O_TS1 = 3'd1, O_TS2 = 3'd2, O_CLREQ = 3'd3, O_CLD = 3'd4, O_WAKE = 3'd5,
                         O_ACK = 3'd6, O_NAK = 3'd7;
  localparam logic [3:0] PDF_RD = 4'd1, PDF_RDR = 4'd2, PDF_WR = 4'd3, PDF_WRR = 4'd4, PDF_NOTIF = 4'd5,
                         PDF_NACK = 4'd6, PDF_CG = 4'hC;
  localparam int T_TRAIN = 64, T_FWD = 6;
  localparam logic [31:0] ROUTER_ID = 32'h0004_AB1D;

  typedef enum int { K_OS, K_PKT, K_IDLE, K_DET, K_CAP, K_BUSY } u4_kind_e;

  function automatic logic [7:0] hec8(input logic [23:0] d);
    logic [7:0] c;
    c = 8'h00;
    for (int i = 23; i >= 0; i--) c = (c[7] ^ d[i]) ? ({c[6:0], 1'b0} ^ 8'h07) : {c[6:0], 1'b0};
    return c;
  endfunction
  function automatic logic [31:0] crc32w(input logic [31:0] c0, input logic [31:0] w);
    logic [31:0] c;
    c = c0;
    for (int i = 31; i >= 0; i--) c = (c[31] ^ w[i]) ? ({c[30:0], 1'b0} ^ 32'h04C1_1DB7) : {c[30:0], 1'b0};
    return c;
  endfunction
  function automatic logic [31:0] mkhdr(input logic [3:0] pdf, input logic [10:0] hop, input int nw);
    logic [23:0] u;
    u = {pdf, 1'b0, hop, 8'(4 * nw)};
    return {u, hec8(u)};
  endfunction
  function automatic logic [31:0] w1of(input int seq, input int addr, input int cnt);
    return {2'(seq), 8'h0, 6'(cnt), 16'(addr)};
  endfunction

  // ------------------------------------------------------------ item
  class usb4_item extends uvm_sequence_item;
    `uvm_object_utils(usb4_item)
    u4_kind_e    kind = K_IDLE;
    int          lane;
    logic [2:0]  os_kind;
    bit          g3;
    logic [31:0] w [$];          // K_PKT: header + payload
    int          se_at = -1;     // word with symbol errors
    int          se;
    int          n = 1;          // K_IDLE clocks
    logic [1:0]  det;
    bit          level;
    function new(string name = "usb4_item"); super.new(name); endfunction
    virtual function string convert2string();
      if (kind == K_PKT) return $sformatf("PKT %08h +%0d words", w[0], w.size() - 1);
      if (kind == K_OS) return $sformatf("OS lane %0d kind %0d", lane, os_kind);
      return kind.name();
    endfunction
  endclass

  class usb4_obs extends uvm_object;
    `uvm_object_utils(usb4_obs)
    logic [1:0]  lane_det;
    bit          gen3_cap, os_valid, os_lane, os_gen3, w_valid, w_first, w_last, out_busy;
    logic [2:0]  os_kind, w_sym_err;
    logic [31:0] w_data;
    logic [2:0]  ls0, ls1, ls0_next, ls1_next;
    bit          gen3, tx_os_valid, tx_os_lane, tx_valid, tx_first, tx_last;
    logic [1:0]  width;
    logic [2:0]  tx_os_kind;
    logic [31:0] tx_data;
    logic [7:0]  cnt [12];
    function new(string name = "usb4_obs"); super.new(name); endfunction
  endclass

  typedef uvm_sequencer #(usb4_item) usb4_sequencer;

  // ------------------------------------------------------------ driver
  class usb4_driver extends uvm_driver #(usb4_item);
    `uvm_component_utils(usb4_driver)
    virtual usb4_link_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual usb4_link_if)::get(this, "", "usb4_vif", vif))
        `uvm_fatal("NOVIF", "usb4_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      usb4_item t;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(t);
        drive(t);
        seq_item_port.item_done();
      end
    endtask
    task drive(usb4_item t);
      @(negedge vif.clk);
      case (t.kind)
        K_IDLE: begin repeat (t.n - 1) @(negedge vif.clk); return; end
        K_DET:  begin vif.lane_det = t.det; return; end
        K_CAP:  begin vif.gen3_cap = t.level; return; end
        K_BUSY: begin vif.out_busy = t.level; return; end
        K_OS: begin
          vif.os_valid = 1'b1; vif.os_lane = 1'(t.lane); vif.os_kind = t.os_kind; vif.os_gen3 = t.g3;
          @(posedge vif.clk); #1 vif.os_valid = 1'b0;
        end
        default: begin
          foreach (t.w[i]) begin
            if (i > 0) @(negedge vif.clk);
            vif.w_valid = 1'b1; vif.w_first = i == 0; vif.w_last = i == t.w.size() - 1; vif.w_data = t.w[i];
            vif.w_sym_err = (i == t.se_at) ? 3'(t.se) : 3'd0;
            @(posedge vif.clk); #1;
            vif.w_valid = 1'b0; vif.w_first = 1'b0; vif.w_last = 1'b0; vif.w_sym_err = 3'd0;
          end
        end
      endcase
    endtask
  endclass

  // ------------------------------------------------------------ monitor
  class usb4_monitor extends uvm_monitor;
    `uvm_component_utils(usb4_monitor)
    virtual usb4_link_if vif;
    uvm_analysis_port #(usb4_obs) ap;
    function new(string name, uvm_component parent); super.new(name, parent); ap = new("ap", this); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual usb4_link_if)::get(this, "", "usb4_vif", vif))
        `uvm_fatal("NOVIF", "usb4_vif not set")
    endfunction
    task run_phase(uvm_phase phase);
      usb4_obs o;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n !== 1'b1) continue;
        o = usb4_obs::type_id::create("o");
        o.lane_det = vif.lane_det; o.gen3_cap = vif.gen3_cap; o.os_valid = vif.os_valid; o.os_lane = vif.os_lane;
        o.os_kind = vif.os_kind; o.os_gen3 = vif.os_gen3; o.w_valid = vif.w_valid; o.w_first = vif.w_first;
        o.w_last = vif.w_last; o.w_data = vif.w_data; o.w_sym_err = vif.w_sym_err; o.out_busy = vif.out_busy;
        o.ls0 = vif.ls0; o.ls1 = vif.ls1;
        o.tx_os_valid = vif.tx_os_valid; o.tx_os_lane = vif.tx_os_lane; o.tx_os_kind = vif.tx_os_kind;
        o.tx_valid = vif.tx_valid; o.tx_first = vif.tx_first; o.tx_last = vif.tx_last; o.tx_data = vif.tx_data;
        o.gen3 = vif.gen3; o.width = vif.width;
        o.cnt = '{vif.hec_err, vif.len_err, vif.crc_err, vif.ovf_err, vif.unk_hop, vif.fec_corr, vif.fec_unc,
                  vif.fwd_cnt, vif.dup_cnt, vif.notif_cnt, vif.train_tmo, vif.retrains};
        #1 o.ls0_next = vif.ls0; o.ls1_next = vif.ls1;
        ap.write(o);
      end
    endtask
  endclass

  // ------------------------------------------------------------ scoreboard
  class usb4_scoreboard extends uvm_subscriber #(usb4_obs);
    `uvm_component_utils(usb4_scoreboard)
    virtual usb4_link_if vif;
    int unsigned cyc, errors, n_checks, n_words, n_fwd, n_ctrl, n_cg, n_notif, n_os;
    // predicted adapter
    logic [2:0]  ls [2];
    int          cnt_ [2], tmr [2];
    bit          g3, bond, clx, bonded, in_pkt, poison, bad_hec;
    int          unc;
    logic [31:0] cfg [64];
    logic [31:0] rh;
    logic [31:0] pw [$];
    int          used [4], cg [4];
    int          rel_t [$], rel_p [$];
    bit          last_v;
    logic [1:0]  last_seq;
    logic [3:0]  last_pdf;
    logic [31:0] last_rsp [$];
    logic [33:0] oq [$];
    int          c [12];         // hec len crc ovf unk corr unc fwd dup notif tmo retrain
    // expectations for the next clock
    bit          x_os;
    int          x_os_lane, x_os_kind;
    bit          x_tx;
    logic [33:0] x_w;
    int          now;
    string       cnt_name [12] = '{"hec_err", "len_err", "crc_err", "ovf_err", "unk_hop", "fec_corr", "fec_unc",
                                   "fwd_cnt", "dup_cnt", "notif_cnt", "train_tmo", "retrains"};
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      void'(uvm_config_db#(virtual usb4_link_if)::get(this, "", "usb4_vif", vif));
      for (int l = 0; l < 2; l++) begin ls[l] = L_CLD; cnt_[l] = 0; tmr[l] = 0; end
      foreach (cfg[i]) cfg[i] = 32'h0;
      cfg[0] = ROUTER_ID;
    endfunction
    function void err(string m);
      errors++;
      `uvm_error("USB4_SB", m)
    endfunction
    function void chk(bit ok, string m);
      n_checks++;
      if (!ok) err(m);
    endfunction

    function void push(bit f, bit l, logic [31:0] d);
      if (oq.size() < 128) oq.push_back({f, l, d});
    endfunction
    function void push_pkt(logic [31:0] h, logic [31:0] b [$]);
      push(1, b.size() == 0, h);
      foreach (b[i]) push(0, i == b.size() - 1, b[i]);
    endfunction
    function void ctrl_rsp(logic [3:0] pdf, logic [31:0] w1, int nd);
      logic [31:0] b [$];
      logic [31:0] cr;
      b.push_back(32'h0); b.push_back(w1);
      for (int i = 0; i < nd; i++) b.push_back(cfg[(int'(w1[15:0]) + i) % 64]);
      cr = 32'hFFFF_FFFF;
      foreach (b[i]) cr = crc32w(cr, b[i]);
      b.push_back(~cr);
      push_pkt(mkhdr(pdf, 11'd0, b.size()), b);
      last_rsp.delete();
      last_rsp.push_back(mkhdr(pdf, 11'd0, b.size()));
      foreach (b[i]) last_rsp.push_back(b[i]);
      n_ctrl++;
    endfunction
    function void notify(int code);
      logic [31:0] b [$];
      b.push_back(32'h0); b.push_back({8'(code), 24'h0});
      b.push_back(~crc32w(crc32w(32'hFFFF_FFFF, 32'h0), {8'(code), 24'h0}));
      push_pkt(mkhdr(PDF_NOTIF, 11'd0, 3), b);
      c[9]++; n_notif++;
    endfunction
    function void grant(int p);
      logic [31:0] b [$];
      b.push_back({24'h0, 8'(cg[p])});
      push_pkt(mkhdr(PDF_CG, cfg[8 + p][10:0], 1), b);
      n_cg++;
    endfunction

    function void control();
      logic [3:0]  pdf;
      logic [31:0] w1;
      int a, n;
      pdf = rh[31:28]; w1 = pw[1]; a = int'(w1[15:0]); n = int'(w1[21:16]);
      if (pdf == PDF_NACK) return;
      if ((pdf == PDF_RD || pdf == PDF_WR) && last_v && w1[31:30] == last_seq && pdf == last_pdf) begin
        c[8]++;
        foreach (last_rsp[i]) push(i == 0, i == last_rsp.size() - 1, last_rsp[i]);
        return;
      end
      if (pdf != PDF_RD && pdf != PDF_WR) begin notify(4); return; end
      if (n < 1 || n > 8 || a + n > 64) begin notify(2); return; end
      if (pw.size() != ((pdf == PDF_WR) ? 3 + n : 3)) begin notify(3); return; end
      if (pdf == PDF_WR) begin
        for (int i = 0; i < n; i++) begin
          int r;
          r = a + i;
          if (r == 1) begin cfg[1] = {30'h0, pw[2 + i][1:0]}; bond = pw[2 + i][0]; clx = pw[2 + i][1]; end
          else if (r >= 8 && r < 12) begin
            cfg[r] = pw[2 + i] & 32'h87FF_07FF;
            used[r - 8] = 0; cg[r - 8] = 4;
            for (int k = rel_p.size() - 1; k >= 0; k--)
              if (rel_p[k] == r - 8) begin rel_p.delete(k); rel_t.delete(k); end
            if (pw[2 + i][31]) grant(r - 8);
          end
          else if (r != 0 && r != 2) cfg[r] = pw[2 + i];
        end
        ctrl_rsp(PDF_WRR, w1, 0);
      end
      else ctrl_rsp(PDF_RDR, w1, n);
      last_v = 1; last_seq = w1[31:30]; last_pdf = pdf;
    endfunction

    function void packet();
      logic [10:0] hop;
      logic [31:0] cr;
      logic [31:0] b [$];
      int p;
      hop = rh[26:16];
      if (pw.size() != int'(rh[15:8]) / 4 || rh[9:8] != 2'b00) begin c[1]++; return; end
      if (hop == 0) begin
        cr = 32'hFFFF_FFFF;
        for (int i = 0; i < pw.size() - 1; i++) cr = crc32w(cr, pw[i]);
        if (pw.size() < 3 || ~cr != pw[pw.size() - 1]) begin c[2]++; return; end
        if (pw[0] != 0) return;
        control();
        return;
      end
      p = -1;
      for (int i = 3; i >= 0; i--) if (cfg[8 + i][31] && cfg[8 + i][10:0] == hop) p = i;
      if (p < 0) begin c[4]++; return; end
      if (used[p] == 4) begin c[3]++; return; end
      used[p]++;
      rel_t.push_back(now + T_FWD); rel_p.push_back(p);
      c[7]++; n_fwd++;
      foreach (pw[i]) b.push_back(pw[i]);
      push_pkt(mkhdr(rh[31:28], cfg[8 + p][26:16], pw.size()), b);
    endfunction

    function void write(usb4_obs t);
      usb4_obs o = t;
      bit link_up, both;
      cyc++;
      // ---- what the previous clock produced
      chk(o.tx_os_valid == x_os && (!x_os || (o.tx_os_lane == x_os_lane && o.tx_os_kind == x_os_kind)),
          $sformatf("@%0d ordered set out: valid %0d lane %0d kind %0d, predicted %0d %0d %0d", cyc, o.tx_os_valid,
                    o.tx_os_lane, o.tx_os_kind, x_os, x_os_lane, x_os_kind));
      chk(o.tx_valid == x_tx && (!x_tx || {o.tx_first, o.tx_last, o.tx_data} == x_w),
          $sformatf("@%0d word out: valid %0d %0d%0d %08h, predicted %0d %0d%0d %08h", cyc, o.tx_valid, o.tx_first,
                    o.tx_last, o.tx_data, x_tx, x_w[33], x_w[32], x_w[31:0]));
      if (o.tx_valid) n_words++;
      chk(o.ls0 == ls[0] && o.ls1 == ls[1], $sformatf("@%0d lanes %0d/%0d, predicted %0d/%0d", cyc, o.ls0, o.ls1, ls[0], ls[1]));
      chk(o.gen3 == g3 && o.width == ((bond && ls[0] == L_CL0 && ls[1] == L_CL0) ? 2'd2 : 2'd1),
          $sformatf("@%0d gen3 %0d width %0d", cyc, o.gen3, o.width));
      foreach (c[i]) chk(o.cnt[i] == 8'(c[i]), $sformatf("@%0d %s %0d, predicted %0d", cyc, cnt_name[i], o.cnt[i], c[i]));
      x_os = 0; x_tx = 0;
      now++;

      // ---- logical layer, this clock
      for (int l = 0; l < 2; l++) begin
        if (!o.lane_det[l]) ls[l] = L_CLD;
        else if (ls[l] == L_CLD) begin ls[l] = L_LOCK; cnt_[l] = 0; tmr[l] = 0; end
        else if (ls[l] inside {L_LOCK, L_TS1, L_TS2}) begin
          if (tmr[l] == T_TRAIN - 1) begin ls[l] = L_CLD; c[10]++; end
          else tmr[l]++;
        end
      end
      if (o.os_valid && o.lane_det[o.os_lane]) begin
        int l;
        l = o.os_lane;
        n_os++;
        if (o.os_kind == O_CLD) ls[l] = L_CLD;
        else case (ls[l])
          L_LOCK: if (o.os_kind == O_SLOS) begin
                    tmr[l] = 0;
                    if (cnt_[l] == 1) begin ls[l] = L_TS1; cnt_[l] = 0; x_os = 1; x_os_lane = l; x_os_kind = O_SLOS; end
                    else cnt_[l] = 1;
                  end
                  else cnt_[l] = 0;
          L_TS1:  if (o.os_kind == O_TS1) begin
                    tmr[l] = 0;
                    if (cnt_[l] == 1) begin
                      ls[l] = L_TS2; cnt_[l] = 0; x_os = 1; x_os_lane = l; x_os_kind = O_TS1;
                      if (l == 0) g3 = o.os_gen3 && o.gen3_cap;
                    end
                    else cnt_[l] = 1;
                  end
                  else if (o.os_kind != O_SLOS) cnt_[l] = 0;
          L_TS2:  if (o.os_kind == O_TS2) begin
                    tmr[l] = 0;
                    if (cnt_[l] == 1) begin ls[l] = L_CL0; cnt_[l] = 0; unc = 0; x_os = 1; x_os_lane = l; x_os_kind = O_TS2; end
                    else cnt_[l] = 1;
                  end
                  else if (o.os_kind != O_TS1) cnt_[l] = 0;
          L_CL0:  if (o.os_kind == O_CLREQ && l == 0) begin
                    x_os = 1; x_os_lane = 0;
                    if (clx && oq.size() == 0 && rel_t.size() == 0 && !in_pkt) begin
                      x_os_kind = O_ACK;
                      for (int k = 0; k < 2; k++) if (ls[k] == L_CL0) ls[k] = L_CLX;
                    end
                    else x_os_kind = O_NAK;
                  end
          L_CLX:  if (o.os_kind == O_WAKE) begin ls[l] = L_TS2; cnt_[l] = 0; tmr[l] = 0; end
          default: ;
        endcase
      end
      link_up = ls[0] == L_CL0;
      if (!link_up) in_pkt = 0;

      // ---- transport receive
      if (o.w_valid && link_up && !o.os_valid) begin
        bit bad_w;
        bad_w = g3 ? (o.w_sym_err > 2) : (o.w_sym_err != 0);
        if (g3 && o.w_sym_err != 0 && o.w_sym_err <= 2) c[5]++;
        if (o.w_first) begin in_pkt = 1; poison = bad_w; rh = o.w_data; pw.delete(); bad_hec = o.w_data[7:0] != hec8(o.w_data[31:8]); end
        else if (in_pkt) begin poison |= bad_w; pw.push_back(o.w_data); end
        if (in_pkt && o.w_last) begin
          in_pkt = 0;
          if (poison) begin
            c[6]++;
            if (unc == 3) begin
              for (int k = 0; k < 2; k++) if (ls[k] == L_CL0) begin ls[k] = L_LOCK; cnt_[k] = 0; tmr[k] = 0; end
              c[11]++; unc = 0;
            end
            else unc++;
          end
          else if (bad_hec) c[0]++;
          else if (pw.size() > 17) c[1]++;
          else packet();
        end
      end
      // ---- buffer release
      if (rel_t.size() != 0 && rel_t[0] <= now && !o.out_busy) begin
        int p;
        p = rel_p.pop_front(); void'(rel_t.pop_front());
        used[p]--; cg[p]++;
        grant(p);
      end
      // ---- bonding
      link_up = ls[0] == L_CL0;
      both = bond && ls[0] == L_CL0 && ls[1] == L_CL0;
      if (bond && link_up && both != bonded) notify(7);
      bonded = both;
      cfg[2] = {24'h0, g3, both, ls[1], ls[0]};
      // ---- output
      if (link_up && oq.size() != 0) begin x_tx = 1; x_w = oq.pop_front(); end
      if (ls[0] != L_CL0) oq.delete();
      chk(o.ls0_next == ls[0] && o.ls1_next == ls[1],
          $sformatf("@%0d lane state %0d/%0d -> %0d/%0d, predicted %0d/%0d (os %0d lane %0d kind %0d det %b)", cyc,
                    o.ls0, o.ls1, o.ls0_next, o.ls1_next, ls[0], ls[1], o.os_valid, o.os_lane, o.os_kind, o.lane_det));
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("USB4_SB", $sformatf("checks=%0d words=%0d forwards=%0d control responses=%0d credit grants=%0d notifications=%0d ordered sets in=%0d errors=%0d",
                n_checks, n_words, n_fwd, n_ctrl, n_cg, n_notif, n_os, errors), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ coverage
  class usb4_coverage extends uvm_subscriber #(usb4_obs);
    `uvm_component_utils(usb4_coverage)
    logic [2:0] from_s, to_s;
    int         ev;
    logic [3:0] pdf;
    logic [7:0] prev [12];
    bit         first = 1;
    covergroup cg_lane;
      cp_tr: coverpoint {from_s, to_s} {
        bins det    = {6'o01};
        bins lock   = {6'o12};
        bins ts1    = {6'o23};
        bins ts2    = {6'o34};
        bins tmo1   = {6'o10};
        bins tmo2   = {6'o20};
        bins tmo3   = {6'o30};
        bins cld    = {6'o40};
        bins clx    = {6'o45};
        bins wake   = {6'o53};
        bins retrain = {6'o41};
        bins clx_cld = {6'o50};
      }
    endgroup
    covergroup cg_pkt;
      cp_out: coverpoint pdf { bins fwd = {[7:11]}; bins rdr = {2}; bins wrr = {4}; bins notif = {5}; bins cg = {12}; }
    endgroup
    covergroup cg_err;
      cp_ev: coverpoint ev { bins hec = {0}; bins len = {1}; bins crc = {2}; bins ovf = {3}; bins unk = {4};
                             bins corr = {5}; bins unc = {6}; bins dup = {8}; bins tmo = {10}; bins retrain = {11};
                             bins ack = {20}; bins nak = {21}; bins width2 = {22}; bins gen3 = {23}; }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      cg_lane = new(); cg_pkt = new(); cg_err = new();
    endfunction
    function void write(usb4_obs t);
      usb4_obs o = t;
      if (o.ls0 != o.ls0_next) begin from_s = o.ls0; to_s = o.ls0_next; cg_lane.sample(); end
      if (o.ls1 != o.ls1_next) begin from_s = o.ls1; to_s = o.ls1_next; cg_lane.sample(); end
      if (o.tx_valid && o.tx_first) begin pdf = o.tx_data[31:28]; cg_pkt.sample(); end
      if (!first) foreach (o.cnt[i]) if (o.cnt[i] != prev[i]) begin ev = i; cg_err.sample(); end
      if (o.tx_os_valid && o.tx_os_kind >= O_ACK) begin ev = (o.tx_os_kind == O_ACK) ? 20 : 21; cg_err.sample(); end
      if (o.width == 2) begin ev = 22; cg_err.sample(); end
      if (o.gen3) begin ev = 23; cg_err.sample(); end
      first = 0;
      prev = o.cnt;
    endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info("USB4_COV", $sformatf("lanes %0.1f%%  packets %0.1f%%  events %0.1f%%", cg_lane.get_coverage(),
                cg_pkt.get_coverage(), cg_err.get_coverage()), UVM_LOW)
    endfunction
  endclass

  // ------------------------------------------------------------ sequences
  class usb4_base_seq extends uvm_sequence #(usb4_item);
    `uvm_object_utils(usb4_base_seq)
    virtual usb4_link_if vif;
    int seq;
    logic [10:0] in_hop [4];
    function new(string name = "usb4_base_seq"); super.new(name); endfunction
    task pre_body();
      if (vif == null) void'(uvm_config_db#(virtual usb4_link_if)::get(null, "*", "usb4_vif", vif));
    endtask
    task send(usb4_item t); start_item(t); finish_item(t); endtask
    task idle(int n);
      usb4_item t = usb4_item::type_id::create("t");
      t.kind = K_IDLE; t.n = n; send(t);
    endtask
    task det(logic [1:0] d);
      usb4_item t = usb4_item::type_id::create("t");
      t.kind = K_DET; t.det = d; send(t);
    endtask
    task level(u4_kind_e k, bit v);
      usb4_item t = usb4_item::type_id::create("t");
      t.kind = k; t.level = v; send(t);
    endtask
    task os(int lane, logic [2:0] k, bit g = 0);
      usb4_item t = usb4_item::type_id::create("t");
      t.kind = K_OS; t.lane = lane; t.os_kind = k; t.g3 = g; send(t);
    endtask
    task train(int lane, bit g = 1);
      os(lane, O_SLOS); os(lane, O_SLOS); os(lane, O_TS1, g); os(lane, O_TS1, g); os(lane, O_TS2); os(lane, O_TS2);
    endtask
    // pdf / hop / payload; err 0 none 1 HEC 2 length 3 symbol errors (se)
    task pkt(logic [3:0] pdf, logic [10:0] hop, logic [31:0] b [$], int err = 0, int se = 0, int se_at = -1);
      usb4_item t = usb4_item::type_id::create("t");
      logic [31:0] h;
      t.kind = K_PKT;
      h = mkhdr(pdf, hop, b.size() + ((err == 2) ? 1 : 0));
      if (err == 1) h[3] = ~h[3];
      t.w.push_back(h);
      foreach (b[i]) t.w.push_back(b[i]);
      t.se = se; t.se_at = se_at;
      send(t);
      idle(1);
    endtask
    task ctrl(logic [3:0] pdf, int addr, int cnt, logic [31:0] d [$], bit bad_crc = 0, bit same_seq = 0,
              logic [31:0] route = 0);
      logic [31:0] b [$];
      logic [31:0] cr;
      if (!same_seq) seq = (seq + 1) % 4;
      b.push_back(route); b.push_back(w1of(seq, addr, cnt));
      foreach (d[i]) b.push_back(d[i]);
      cr = 32'hFFFF_FFFF;
      foreach (b[i]) cr = crc32w(cr, b[i]);
      b.push_back(~cr ^ 32'(bad_crc));
      pkt(pdf, 11'd0, b);
    endtask
    task wr1(int addr, logic [31:0] v);
      logic [31:0] d [$];
      d.push_back(v);
      ctrl(PDF_WR, addr, 1, d);
      idle(12);
    endtask
    task set_path(int i, logic [10:0] in_h, logic [10:0] out_h, bit en = 1);
      in_hop[i] = in_h;
      wr1(8 + i, {en, 4'h0, out_h, 5'h0, in_h});
    endtask
    task bring_up(bit g = 1);
      int t;
      for (int k = 0; k < 4; k++) begin
        if (vif.ls0 == L_CL0) return;
        if (vif.ls0 == L_CLX) begin os(0, O_WAKE); os(0, O_TS2); os(0, O_TS2); continue; end
        if (vif.ls0 != L_LOCK) begin os(0, O_CLD); idle(3); end
        train(0, g);
        idle(2);
      end
    endtask
    task traffic(int n);
      logic [31:0] b [$];
      for (int i = 0; i < n; i++) begin
        b.delete();
        repeat ($urandom_range(0, 6)) b.push_back($urandom());
        pkt(4'(7 + $urandom_range(0, 4)), in_hop[$urandom_range(0, 3)], b, 0,
            ($urandom_range(0, 7) == 0) ? $urandom_range(1, 4) : 0, $urandom_range(0, b.size()));
        if ($urandom_range(0, 2) == 0) idle($urandom_range(1, 8));
      end
    endtask
  endclass

  class usb4_regression_seq extends usb4_base_seq;
    `uvm_object_utils(usb4_regression_seq)
    int n_iter = 250;
    function new(string name = "usb4_regression_seq"); super.new(name); endfunction
    task body();
      logic [31:0] d [$];
      logic [31:0] b [$];
      idle(3);
      det(2'b01);
      idle(2);
      os(0, O_SLOS); os(0, O_TS1); os(0, O_SLOS); os(0, O_SLOS);     // interrupted lock
      os(0, O_TS1, 0); os(0, O_TS2); os(0, O_TS1, 0); os(0, O_TS1, 0);
      os(0, O_TS2); os(0, O_TS2);                                        // Gen 2
      set_path(0, 11'h010, 11'h110);
      set_path(1, 11'h020, 11'h120);
      set_path(2, 11'h030, 11'h130);
      set_path(3, 11'h040, 11'h140);
      traffic(20);
      det(2'b11); idle(70);                                              // lane 1 times out
      os(0, O_CLD); idle(3); bring_up(1);                                // Gen 3
      os(1, O_SLOS); os(1, O_SLOS); idle(70);                            // timeout in TS1
      os(1, O_SLOS); os(1, O_SLOS); os(1, O_TS1, 1); os(1, O_TS1, 1); idle(70);   // timeout in TS2
      wr1(1, 32'h2); idle(20);
      os(0, O_CLREQ); idle(3); os(0, O_CLD); idle(3); bring_up(1);       // CLx -> CLd
      wr1(1, 32'h0);
      for (int i = 0; i < n_iter; i++) begin
        if (vif.ls0 != L_CL0) bring_up($urandom_range(0, 3) != 0);
        case ($urandom_range(0, 15))
          0, 1, 2, 3: traffic($urandom_range(1, 10));
          4: begin d.delete(); ctrl(PDF_RD, $urandom_range(0, 63), $urandom_range(0, 9), d); idle(14); end
          5: begin d.delete(); repeat ($urandom_range(1, 8)) d.push_back($urandom());
                   ctrl(PDF_WR, $urandom_range(12, 63), d.size() + (($urandom_range(0, 5) == 0) ? 1 : 0), d,
                        0, $urandom_range(0, 3) == 0); idle(10); end
          6: begin d.delete(); ctrl(($urandom_range(0, 1) == 0) ? PDF_NACK : 4'(7 + $urandom_range(0, 3)), 0, 1, d,
                                   $urandom_range(0, 1), 0, ($urandom_range(0, 3) == 0) ? 32'h100 : 32'h0); idle(8); end
          7: begin b.delete(); b.push_back($urandom()); pkt(4'h8, 11'(16 * $urandom_range(1, 6)), b,
                                                            $urandom_range(1, 2)); end
          8: begin level(K_BUSY, 1); traffic($urandom_range(3, 8)); idle($urandom_range(5, 30)); level(K_BUSY, 0); end
          9: set_path($urandom_range(0, 3), 11'(16 * $urandom_range(1, 6)), 11'($urandom()), $urandom_range(0, 4) != 0);
          10: begin wr1(1, {30'h0, 2'($urandom_range(0, 3))}); end
          11: begin os(0, O_CLREQ); idle(2); if (vif.ls0 == L_CLX) begin traffic(1); idle($urandom_range(2, 20)); end end
          12: begin det(2'b11); idle(2); if (vif.ls1 != L_CL0) train(1, 1); else os(1, O_CLD); idle(4); end
          13: begin os($urandom_range(0, 1), 3'($urandom_range(0, 5)), $urandom_range(0, 1)); idle(2); end
          14: begin b.delete(); repeat (3) b.push_back($urandom());
                    for (int k = 0; k < 5; k++) pkt(4'h8, in_hop[0], b, 0, 3 + $urandom_range(0, 4), 1); end
          default: begin level(K_CAP, $urandom_range(0, 3) != 0); det(2'($urandom_range(1, 3))); idle($urandom_range(2, 80)); end
        endcase
      end
      idle(50);
    endtask
  endclass

  // ------------------------------------------------------------ env / test
  class usb4_env extends uvm_env;
    `uvm_component_utils(usb4_env)
    usb4_sequencer  sqr;
    usb4_driver     drv;
    usb4_monitor    mon;
    usb4_scoreboard sb;
    usb4_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      sqr = usb4_sequencer::type_id::create("sqr", this);
      drv = usb4_driver::type_id::create("drv", this);
      mon = usb4_monitor::type_id::create("mon", this);
      sb  = usb4_scoreboard::type_id::create("sb", this);
      cov = usb4_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(sb.analysis_export);
      mon.ap.connect(cov.analysis_export);
    endfunction
  endclass

  class usb4_link_test extends uvm_test;
    `uvm_component_utils(usb4_link_test)
    usb4_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      env = usb4_env::type_id::create("env", this);
    endfunction
    task run_phase(uvm_phase phase);
      usb4_regression_seq s = usb4_regression_seq::type_id::create("s");
      phase.raise_objection(this);
      s.start(env.sqr);
      phase.drop_objection(this);
    endtask
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0 &&
          env.sb.n_fwd > 100 && env.sb.n_ctrl > 30)
        $display("SB_PASS checks=%0d", env.sb.n_checks);
      else `uvm_error("TEST", "USB4_LINK_TEST FAILED")
    endfunction
  endclass
endpackage

`endif
