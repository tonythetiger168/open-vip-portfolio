// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB 3.2 SuperSpeed link layer, upstream (device) port. Plain ANSI ports so
// the L1b smoke harness and tb/smoke_func_tb.sv build it directly.
//
// LTSSM (USB 3.2 ch. 7.5, counts scaled down):
//   RxDetect -> Polling.LFPS (4 LFPS bursts; the partner's SCD2 selects Gen2)
//   -> Polling.Active (8 TS1/TS2) -> Polling.Configuration (8 TS2) -> U0.
//   U0 -> Recovery on a TS1 from the partner, an out-of-sequence header, a
//   receive-buffer overrun, a bad LCRD order, an unexpected LGOOD, a pending
//   header with no LGOOD for 64 clocks, or no LPMA 32 clocks after LAU.
//   Recovery.Active (8 TS1/TS2) -> Recovery.Configuration (8 TS2) -> U0.
//   A TS1/TS2 with the Hot Reset bit -> Hot Reset; a TS2 without it -> U0
//   with the link layer reset. 128 clocks with no progress -> RxDetect.
//   LGO_U1/U2/U3 -> LAU (U3 always; U1/U2 only with Force_LinkPM_Accept and
//   no header waiting for LGOOD) or LXU; LPMA enters Ux. U1 -> U2 after the
//   U2 inactivity timeout (16 clocks per unit, 0 = off). LFPS exits Ux.
//
// Link layer (ch. 7.2):
//   Header packet = DW0..DW2 (12 bytes), DW3[15:0] CRC-16 over bytes 0-11,
//   DW3[31:16] link control word {CRC-5, Deferred, Delayed, HubDepth[2:0],
//   3'b0, HdrSeq[2:0]}.
//   Link command word = {CRC-5, LCI[10:0]}, LCI = {class, type, 3'b0, sub}:
//     LGOOD_n 00/00/n  LCRD_x 00/01/x  LRTY 00/10  LBAD 00/11
//     LGO_Ux  01/00/x  LAU    01/01    LXU  01/10  LPMA 01/11   LUP 10/00
//   Receive: good header in sequence -> LGOOD_n, takes one of 4 buffers;
//   a buffer is freed every 4 clocks (none while app_busy) and returned
//   with LCRD_A..D in order.
//   Bad CRC-16 / CRC-5 -> LBAD, then headers are ignored until LRTY.
//   On every U0 entry: LGOOD_(last good seq) and one LCRD per free buffer.
//   Transmit: headers carry HdrSeq, need one partner credit each (LCRD_x in
//   order), stay in a 4-entry retry buffer until LGOOD_n; LBAD -> LRTY and
//   resend from the oldest; after Recovery, the partner's LGOOD_n
//   advertisement acks up to n and the rest are resent.
//   Gen2 (128b/132b): every item carries its 4-bit block header; ordered
//   sets in control blocks (0011), packets and link commands in data blocks
//   (1100). One bit in error is corrected; more -> the block is dropped.
//
// Protocol layer: LMP (Set Link Function, U2 Inactivity Timeout, Port
// Capability, Port Configuration -> Port Configuration Response), ITP
// (timestamp latched), TP (count those for DEV_ADDR), DPH + DPP (CRC-32 and
// length checked). The device sends its Port Capability LMP after Polling.

module usb3_smoke_model #(parameter logic [6:0] DEV_ADDR = 7'd5) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         far_end_ready,   // RxDetect: partner termination
  input  logic         lfps,            // one LFPS burst
  input  logic         gen2_cap,        // the burst carries SCD2 (Gen2)
  input  logic         rx_valid,
  input  logic [2:0]   rx_kind,         // 0 TS1 1 TS2 2 header 3 link command 4 DPP word
  input  logic         rx_ts_reset,     // TS1/TS2 Hot Reset bit
  input  logic [127:0] rx_hdr,
  input  logic [15:0]  rx_lc,
  input  logic [31:0]  rx_dw,
  input  logic         rx_last,         // DPP: this word is the CRC-32
  input  logic [3:0]   rx_blk,          // Gen2 block header
  input  logic         app_busy,        // protocol layer not taking headers: buffers stay full
  output logic [3:0]   ltssm,
  output logic         gen2,
  output logic         tx_lc_valid,
  output logic [15:0]  tx_lc,
  output logic         tx_hp_valid,
  output logic [127:0] tx_hp,
  output logic [2:0]   rx_free,
  output logic [2:0]   tx_credits,
  output logic [7:0]   hp_good,
  output logic [7:0]   hp_bad,
  output logic [7:0]   rec_cnt,
  output logic [7:0]   dpp_good,
  output logic [7:0]   dpp_bad,
  output logic [7:0]   tp_mine,
  output logic [7:0]   itp_cnt,
  output logic [26:0]  itp_ts,
  output logic [7:0]   u2_tmo,
  output logic         force_pm,
  output logic [7:0]   blk_fix,
  output logic [7:0]   blk_drop
);

  localparam logic [3:0] S_RXDET = 4'd0, S_PLFPS = 4'd1, S_PACT = 4'd2, S_PCFG = 4'd3,
                         S_U0 = 4'd4, S_U1 = 4'd5, S_U2 = 4'd6, S_U3 = 4'd7,
                         S_RACT = 4'd8, S_RCFG = 4'd9, S_HRST = 4'd10;
  localparam logic [2:0] K_TS1 = 3'd0, K_TS2 = 3'd1, K_HP = 3'd2, K_LC = 3'd3, K_DPP = 3'd4;
  localparam logic [4:0] T_LMP = 5'b00000, T_TP = 5'b00100, T_DPH = 5'b01000, T_ITP = 5'b01100;

  // ------------------------------------------------------------------ CRCs
  function automatic logic [4:0] crc5(input logic [10:0] d);
    logic [4:0] c;
    c = 5'h1F;
    for (int i = 0; i < 11; i++)
      c = (c[4] ^ d[i]) ? ({c[3:0], 1'b0} ^ 5'h05) : {c[3:0], 1'b0};
    return ~c;
  endfunction

  function automatic logic [15:0] crc16(input logic [95:0] d);
    logic [15:0] c;
    c = 16'hFFFF;
    for (int i = 0; i < 96; i++)
      c = (c[15] ^ d[i]) ? ({c[14:0], 1'b0} ^ 16'h100B) : {c[14:0], 1'b0};
    return ~c;
  endfunction

  function automatic logic [31:0] crc32_step(input logic [31:0] c0, input logic [31:0] d);
    logic [31:0] c;
    c = c0;
    for (int i = 0; i < 32; i++)
      c = (c[31] ^ d[i]) ? ({c[30:0], 1'b0} ^ 32'h04C1_1DB7) : {c[30:0], 1'b0};
    return c;
  endfunction

  function automatic logic [15:0] lcw(input logic [1:0] cls, input logic [1:0] typ, input logic [3:0] sub);
    logic [10:0] lci;
    lci = {cls, typ, 3'b000, sub};
    return {crc5(lci), lci};
  endfunction

  // a header with its CRC-16 and link control word filled in
  function automatic logic [127:0] seal(input logic [95:0] h, input logic [2:0] seq);
    logic [10:0] lc;
    lc = {8'h00, seq};
    return {crc5(lc), lc, crc16(h), h};
  endfunction

  function automatic int ones(input logic [3:0] v);
    return int'(v[0]) + int'(v[1]) + int'(v[2]) + int'(v[3]);
  endfunction

  // ------------------------------------------------------------------ state
  logic [3:0]  st;
  logic [7:0]  tmo;
  logic [3:0]  cnt;          // LFPS / TS counter
  logic [2:0]  rx_seq;       // next expected receive HdrSeq
  logic        rx_wait_lrty;
  logic [2:0]  rx_used;      // occupied receive buffers
  logic [1:0]  proc_cnt;
  logic [1:0]  rx_crd_idx;   // next LCRD index to send
  logic [1:0]  tx_crd_exp;   // next LCRD index expected from the partner
  logic [2:0]  tx_ack_seq;   // HdrSeq of the oldest unacknowledged header
  logic [95:0] txb [0:3];
  logic [1:0]  tx_head;
  logic [2:0]  tx_cnt;       // headers in the retry buffer
  logic [2:0]  tx_sent;      // of those, sent since the last (re)start
  logic        tx_hold;      // one clock between LRTY and the resend
  logic [6:0]  pend_tmo;
  logic        pm_wait;
  logic [1:0]  pm_tgt;
  logic [5:0]  pm_tmo;
  logic [11:0] u1_cnt;
  logic        cap_rx;       // partner Port Capability seen
  logic        in_dpp;
  logic [15:0] dpp_len;
  logic [15:0] dpp_got;
  logic [31:0] dpp_crc;
  logic        dpp_err;
  logic [15:0] lcq [0:7];
  logic [2:0]  lcq_wr, lcq_rd;
  logic [3:0]  lcq_n;
  logic [2:0]  n_ack, ru, tsn, tcr;   // this clock's working copies
  logic        adv;          // first LGOOD after U0 entry: the partner's advertisement

  // block header: corrected kind, or drop
  logic        blk_ok, blk_one;
  logic [3:0]  want_blk;
  always_comb begin
    want_blk = (rx_kind == K_TS1 || rx_kind == K_TS2) ? 4'b0011 : 4'b1100;
    blk_one  = ones(rx_blk ^ want_blk) == 1;
    blk_ok   = !gen2 || rx_blk == want_blk || blk_one;
  end

  wire        item    = rx_valid && blk_ok;
  wire        is_ts   = item && (rx_kind == K_TS1 || rx_kind == K_TS2);
  wire        is_ts2  = item && rx_kind == K_TS2;
  wire [10:0] lci     = rx_lc[10:0];
  wire        lc_ok   = item && rx_kind == K_LC && rx_lc[15:11] == crc5(lci);
  wire [1:0]  lc_cls  = lci[10:9];
  wire [1:0]  lc_typ  = lci[8:7];
  wire [3:0]  lc_sub  = lci[3:0];
  wire [95:0] h       = rx_hdr[95:0];
  wire [10:0] h_lcw   = rx_hdr[122:112];
  wire        h_crc   = rx_hdr[111:96] == crc16(h) && rx_hdr[127:123] == crc5(h_lcw);
  wire [2:0]  h_seq   = h_lcw[2:0];
  wire [4:0]  h_type  = h[4:0];
  wire [3:0]  h_lsub  = h[8:5];
  wire [7:0]  h_fld   = h[16:9];

  // ack window: n acks the oldest unacked header up to tx_sent of them
  wire [2:0]  ack_dist = 3'(rx_lc[2:0] - tx_ack_seq);

  task automatic lc_push(input logic [15:0] w);
    lcq[lcq_wr] = w;
    lcq_wr = lcq_wr + 3'd1;
    lcq_n  = lcq_n + 4'd1;
  endtask

  task automatic tx_push(input logic [95:0] hh);
    if (tx_cnt < 3'd4) begin
      txb[2'(tx_head + tx_cnt[1:0])] <= hh;
      tx_cnt = tx_cnt + 3'd1;
    end
  endtask

  task automatic to_recovery();
    st <= S_RACT; cnt <= 4'd0; tmo <= 8'd0; rec_cnt <= rec_cnt + 8'd1;
    pm_wait <= 1'b0; in_dpp <= 1'b0;
  endtask

  task automatic enter_u0();
    st <= S_U0; tmo <= 8'd0; cnt <= 4'd0;
    // header sequence number and buffer credit advertisement
    lc_push(lcw(2'b00, 2'b00, {1'b0, 3'(rx_seq - 3'd1)}));
    for (int k = 0; k < 4; k++)
      if (k < 4 - int'(ru)) lc_push(lcw(2'b00, 2'b01, {2'b00, 2'(rx_crd_idx + k)}));
    rx_crd_idx <= 2'(rx_crd_idx + (3'd4 - ru));
    tcr = 3'd0; tsn = 3'd0; pend_tmo <= 7'd0; adv <= 1'b1;
  endtask

  task automatic link_reset();
    rx_seq <= 3'd0; rx_wait_lrty <= 1'b0; rx_used <= 3'd0; proc_cnt <= 2'd0;
    rx_crd_idx <= 2'd0; tx_crd_exp <= 2'd0; tx_ack_seq <= 3'd0;
    tx_head <= 2'd0; tx_cnt = 3'd0; tsn = 3'd0; tx_hold <= 1'b0;
    tcr = 3'd0; ru = 3'd0; cap_rx <= 1'b0; in_dpp <= 1'b0; pend_tmo <= 7'd0;
  endtask

  wire         rel = rx_used != 3'd0 && proc_cnt == 2'd3 && !app_busy;
  always @(posedge clk) begin
    if (!rst_n) begin
      st <= S_RXDET; tmo <= 8'd0; cnt <= 4'd0; gen2 <= 1'b0;
      rx_seq <= 3'd0; rx_wait_lrty <= 1'b0; rx_used <= 3'd0; proc_cnt <= 2'd0;
      rx_crd_idx <= 2'd0; tx_crd_exp <= 2'd0; tx_ack_seq <= 3'd0;
      tx_head <= 2'd0; tx_cnt = 3'd0; tx_sent <= 3'd0; tx_hold <= 1'b0;
      pend_tmo <= 7'd0; adv <= 1'b0; pm_wait <= 1'b0; pm_tgt <= 2'd0; pm_tmo <= 6'd0; u1_cnt <= 12'd0;
      cap_rx <= 1'b0; in_dpp <= 1'b0; dpp_len <= 16'd0; dpp_got <= 16'd0;
      dpp_crc <= 32'hFFFF_FFFF; dpp_err <= 1'b0;
      lcq_wr = 3'd0; lcq_rd = 3'd0; lcq_n = 4'd0;
      for (int k = 0; k < 4; k++) txb[k] <= 96'h0;
      for (int k = 0; k < 8; k++) lcq[k] <= 16'h0;
      tx_lc_valid <= 1'b0; tx_lc <= 16'h0; tx_hp_valid <= 1'b0; tx_hp <= 128'h0;
      tx_credits <= 3'd0; hp_good <= 8'd0; hp_bad <= 8'd0; rec_cnt <= 8'd0;
      dpp_good <= 8'd0; dpp_bad <= 8'd0; tp_mine <= 8'd0; itp_cnt <= 8'd0; itp_ts <= 27'd0;
      u2_tmo <= 8'd0; force_pm <= 1'b0; blk_fix <= 8'd0; blk_drop <= 8'd0;
    end
    else begin
      tx_lc_valid <= 1'b0;
      tx_hp_valid <= 1'b0;
      ru = rx_used; tsn = tx_sent; tcr = tx_credits;
      if (gen2 && rx_valid && rx_blk != want_blk) begin
        if (blk_one) blk_fix  <= blk_fix + 8'd1;
        else         blk_drop <= blk_drop + 8'd1;
      end

      // receive buffers drain one every 4 clocks
      if (rx_used != 3'd0) begin
        if (!app_busy) proc_cnt <= proc_cnt + 2'd1;
        if (rel) begin
          ru = ru - 3'd1;
          if (st == S_U0) begin
            lc_push(lcw(2'b00, 2'b01, {2'b00, rx_crd_idx}));
            rx_crd_idx <= rx_crd_idx + 2'd1;
          end
        end
      end
      else proc_cnt <= 2'd0;

      case (st)
        S_RXDET: begin
          cnt <= 4'd0; tmo <= 8'd0;
          if (far_end_ready) begin st <= S_PLFPS; gen2 <= 1'b0; link_reset(); end
        end

        S_PLFPS: begin
          tmo <= tmo + 8'd1;
          if (lfps) begin
            cnt <= cnt + 4'd1; tmo <= 8'd0;
            if (cnt == 4'd0) gen2 <= gen2_cap;
            else if (!gen2_cap) gen2 <= 1'b0;
            if (cnt == 4'd3) begin st <= S_PACT; cnt <= 4'd0; end
          end
          else if (tmo == 8'd127) st <= S_RXDET;
        end

        S_PACT, S_RACT: begin
          tmo <= tmo + 8'd1;
          if (is_ts && rx_ts_reset) begin st <= S_HRST; tmo <= 8'd0; end
          else if (is_ts) begin
            cnt <= cnt + 4'd1; tmo <= 8'd0;
            if (cnt == 4'd7) begin st <= (st == S_PACT) ? S_PCFG : S_RCFG; cnt <= 4'd0; end
          end
          else if (tmo == 8'd127) st <= S_RXDET;
        end

        S_PCFG, S_RCFG: begin
          tmo <= tmo + 8'd1;
          if (is_ts && rx_ts_reset) begin st <= S_HRST; tmo <= 8'd0; end
          else if (is_ts2) begin
            cnt <= cnt + 4'd1; tmo <= 8'd0;
            if (cnt == 4'd7) begin
              if (st == S_PCFG) begin
                tx_push({32'h0, 14'h0, 2'b01, 8'h00, 8'h04,                // Port Capability:
                         15'h0, (gen2 ? 8'h03 : 8'h01), 4'd4, T_LMP});   // 4 buffers, upstream
              end
              enter_u0();
            end
          end
          else if (tmo == 8'd127) st <= S_RXDET;
        end

        S_HRST: begin
          tmo <= tmo + 8'd1;
          if (is_ts2 && !rx_ts_reset) begin
            link_reset();
            st <= S_U0; tmo <= 8'd0; cnt <= 4'd0;
            lc_push(lcw(2'b00, 2'b00, 4'd7));
            for (int k = 0; k < 4; k++) lc_push(lcw(2'b00, 2'b01, k[3:0]));
            rx_crd_idx <= 2'd0;
          end
          else if (tmo == 8'd127) st <= S_RXDET;
        end

        S_U0: begin
          // pending-header timer
          if (tsn != 3'd0) begin
            pend_tmo <= pend_tmo + 7'd1;
            if (pend_tmo == 7'd63) to_recovery();
          end
          else pend_tmo <= 7'd0;
          if (pm_wait) begin
            pm_tmo <= pm_tmo + 6'd1;
            if (pm_tmo == 6'd31) to_recovery();
          end

          if (item && rx_kind == K_TS1) to_recovery();
          else if (item && rx_kind == K_HP) begin
            if (!h_crc) begin
              hp_bad <= hp_bad + 8'd1;
              if (!rx_wait_lrty) lc_push(lcw(2'b00, 2'b11, 4'd0));
              rx_wait_lrty <= 1'b1;
            end
            else if (rx_wait_lrty) ;                         // dropped until LRTY
            else if (h_seq != rx_seq || ru == 3'd4) to_recovery();
            else begin
              hp_good <= hp_good + 8'd1;
              lc_push(lcw(2'b00, 2'b00, {1'b0, rx_seq}));
              rx_seq  <= rx_seq + 3'd1;
              if (ru == 3'd0) proc_cnt <= 2'd0;
              ru = ru + 3'd1;
              case (h_type)
                T_LMP:
                  case (h_lsub)
                    4'd1: force_pm <= h[10];
                    4'd2: u2_tmo   <= h_fld;
                    4'd4: cap_rx   <= 1'b1;
                    4'd5: tx_push({64'h0, 15'h0,
                                   8'((cap_rx && (h_fld == 8'h01 || (h_fld == 8'h02 && gen2))) ? 1 : 0),
                                   4'd6, T_LMP});             // Port Configuration Response
                    default: ;
                  endcase
                T_TP:  if (h[31:25] == DEV_ADDR) tp_mine <= tp_mine + 8'd1;
                T_ITP: begin itp_ts <= h[31:5]; itp_cnt <= itp_cnt + 8'd1; end
                T_DPH: begin
                  in_dpp <= 1'b1; dpp_len <= h[63:48]; dpp_got <= 16'd0;
                  dpp_crc <= 32'hFFFF_FFFF; dpp_err <= 1'b0;
                end
                default: ;
              endcase
            end
          end
          else if (rx_valid && rx_kind == K_DPP && !blk_ok && in_dpp) dpp_err <= 1'b1;
          else if (item && rx_kind == K_DPP) begin
            if (!in_dpp) dpp_bad <= dpp_bad + 8'd1;
            else if (rx_last) begin
              in_dpp <= 1'b0;
              if (!dpp_err && rx_dw == ~dpp_crc && dpp_got == dpp_len) dpp_good <= dpp_good + 8'd1;
              else dpp_bad <= dpp_bad + 8'd1;
            end
            else begin
              dpp_crc <= crc32_step(dpp_crc, rx_dw);
              dpp_got <= dpp_got + 16'd4;
            end
          end
          else if (lc_ok && lc_cls == 2'b00) begin
            case (lc_typ)
              2'b00: begin                                     // LGOOD_n
                adv <= 1'b0;
                if (ack_dist < (adv ? tx_cnt : tsn)) begin
                  n_ack = ack_dist + 3'd1;
                  tx_head    <= 2'(tx_head + n_ack);
                  tx_cnt      = tx_cnt - n_ack;
                  tsn         = (tsn > n_ack) ? tsn - n_ack : 3'd0;
                  tx_ack_seq <= tx_ack_seq + n_ack;
                  pend_tmo   <= 7'd0;
                end
                else if (rx_lc[2:0] != 3'(tx_ack_seq - 3'd1)) to_recovery();
              end
              2'b01: begin                                     // LCRD_x
                if (lc_sub[1:0] != tx_crd_exp || tcr == 3'd4) to_recovery();
                else begin
                  tcr = tcr + 3'd1;
                  tx_crd_exp <= tx_crd_exp + 2'd1;
                end
              end
              2'b10: rx_wait_lrty <= 1'b0;                     // LRTY
              2'b11: begin                                     // LBAD
                lc_push(lcw(2'b00, 2'b10, 4'd0));
                tcr = ({1'b0, tcr} + {1'b0, tsn} > 4'd4) ? 3'd4 : tcr + tsn;
                tsn = 3'd0; tx_hold <= 1'b1;
              end
            endcase
          end
          else if (lc_ok && lc_cls == 2'b01) begin
            if (lc_typ == 2'b00 && !pm_wait && lc_sub[1:0] != 2'd0) begin   // LGO_Ux
              if (lc_sub[1:0] == 2'd3 || (force_pm && tx_cnt == 3'd0)) begin
                lc_push(lcw(2'b01, 2'b01, 4'd0));             // LAU
                pm_wait <= 1'b1; pm_tgt <= lc_sub[1:0]; pm_tmo <= 6'd0;
              end
              else lc_push(lcw(2'b01, 2'b10, 4'd0));          // LXU
            end
            else if (lc_typ == 2'b11 && pm_wait) begin          // LPMA
              pm_wait <= 1'b0; u1_cnt <= 12'd0;
              st <= (pm_tgt == 2'd1) ? S_U1 : (pm_tgt == 2'd2) ? S_U2 : S_U3;
            end
          end

          // transmit one header
          if (tx_hold) tx_hold <= 1'b0;
          else if (tsn < tx_cnt && tcr != 3'd0 && !(lc_ok && lci[10:7] == 4'b0011)) begin
            tx_hp_valid <= 1'b1;
            tx_hp       <= seal(txb[2'(tx_head + tsn[1:0])], 3'(tx_ack_seq + tsn));
            tsn = tsn + 3'd1;
            tcr = tcr - 3'd1;
          end
        end

        S_U1, S_U2, S_U3: begin
          if (lfps) to_recovery();
          else if (st == S_U1 && u2_tmo != 8'd0) begin
            u1_cnt <= u1_cnt + 12'd1;
            if (u1_cnt == {u2_tmo, 4'hF}) st <= S_U2;
          end
        end

        default: st <= S_RXDET;
      endcase

      rx_used <= ru; tx_sent <= tsn; tx_credits <= tcr;

      // link command output, one per clock
      if (lcq_n != 4'd0) begin
        tx_lc_valid <= 1'b1;
        tx_lc       <= lcq[lcq_rd];
        lcq_rd = lcq_rd + 3'd1;
        lcq_n  = lcq_n - 4'd1;
      end
    end
  end

  always_comb begin
    ltssm   = st;
    rx_free = 3'd4 - rx_used;
  end

endmodule
