// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB Power Delivery 3.x sink port: physical-layer framing, protocol layer
// and sink policy engine. Plain ANSI ports so the L1b smoke harness and
// tb/smoke_func_tb.sv build it directly. Symbols are the 5-bit 4b5b codes
// after BMC decoding, one per clock; the preamble is not modelled.
//
// Physical layer (PD 3.x ch. 5):
//   4b5b data 0-F = 1E 09 14 15 0A 0B 0E 0F 12 13 16 17 1A 1B 1C 1D,
//   K-codes Sync-1 18, Sync-2 11, Sync-3 06, RST-1 07, RST-2 19, EOP 0D.
//   SOP = S1 S1 S1 S2, SOP' = S1 S1 S3 S3, SOP'' = S1 S3 S1 S3,
//   Hard Reset = R1 R1 R1 R2, Cable Reset = R1 S1 R1 S3; an ordered set is
//   recognised when 3 of its 4 K-codes are right. A packet is the ordered
//   set, the bytes (low nibble first) of header, data objects and CRC-32
//   (reflected 04C11DB7, init FFFFFFFF, inverted, sent LSB byte first) and
//   EOP. An invalid symbol aborts the packet; a bad CRC, an odd nibble count
//   or a length that does not match Number of Data Objects drops it.
// Protocol layer (ch. 6.7):
//   every good SOP packet except GoodCRC is answered with GoodCRC carrying
//   its MessageID; a MessageID equal to the stored one is a retry (GoodCRC,
//   not passed on). SOP' / SOP'' are not for this port: no GoodCRC.
//   Transmit: MessageIDCounter in the header, GoodCRC with that ID within
//   32 clocks of EOP, else resend, nRetryCount = 2 (3 tries); success moves
//   the counter on. Soft_Reset (either way) clears the counter and the
//   stored ID. Header: Spec Revision 3.0, sink, UFP.
// Policy engine (ch. 8.3.3.3, timers scaled):
//   Disabled (no VBUS) -> Wait_for_Capabilities (SinkWaitCap 400 clocks ->
//   Hard Reset) -> Evaluate: highest fixed PDO with V <= want_v50 and
//   I >= want_ma10, else PDO 1 with Capability Mismatch -> Request ->
//   SenderResponse 100 clocks -> Accept -> Transition_Sink (PSTransition
//   200 clocks) -> PS_RDY -> Ready (explicit contract at the new voltage).
//   Reject / Wait -> Ready with a contract, else Wait_for_Capabilities.
//   Ready: Source_Capabilities renegotiates, Get_Sink_Cap -> Sink_Capabilities,
//   Ping ignored, Soft_Reset -> Accept, Accept / Reject / PS_RDY / Wait out
//   of place -> Soft_Reset, anything else -> Not_Supported. A failed send
//   -> Soft_Reset; a failed Soft_Reset or a timeout -> Hard Reset
//   (HardResetCounter, nHardResetCount = 2, then Error). A Hard Reset either
//   way drops the contract and VBUS returns to vSafe5V; hard_resets counts
//   both directions.

module usb_pd_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        vbus_present,
  input  logic        rx_valid,
  input  logic [4:0]  rx_sym,
  input  logic [9:0]  want_v50,      // highest voltage the sink accepts, 50 mV units
  input  logic [9:0]  want_ma10,     // operating current, 10 mA units
  output logic        tx_valid,
  output logic [4:0]  tx_sym,
  output logic [3:0]  pe_state,
  output logic        contract,
  output logic [9:0]  vbus_v50,
  output logic [2:0]  obj_pos,
  output logic        mismatch,
  output logic [2:0]  msg_id,        // MessageIDCounter
  output logic [7:0]  rx_good,
  output logic [7:0]  rx_bad,
  output logic [7:0]  rx_dup,
  output logic [7:0]  rx_other_sop,
  output logic [7:0]  retries,
  output logic [7:0]  hard_resets,
  output logic [1:0]  hr_counter
);

  // ------------------------------------------------------------ constants
  localparam logic [4:0] K_S1 = 5'h18, K_S2 = 5'h11, K_S3 = 5'h06, K_R1 = 5'h07, K_R2 = 5'h19, K_EOP = 5'h0D;
  localparam logic [3:0] P_DIS = 4'd0, P_WCAP = 4'd1, P_REQ = 4'd2, P_WRSP = 4'd3, P_TRANS = 4'd4,
                         P_READY = 4'd5, P_SNKCAP = 4'd6, P_SRACC = 4'd7, P_NS = 4'd8,
                         P_SNDSR = 4'd9, P_WSRACC = 4'd10, P_HRST = 4'd11, P_ERR = 4'd12;
  localparam logic [4:0] C_GOODCRC = 5'd1, C_ACCEPT = 5'd3, C_REJECT = 5'd4, C_PING = 5'd5,
                         C_PS_RDY = 5'd6, C_GET_SNK = 5'd8, C_WAIT = 5'd12, C_SOFT_RST = 5'd13,
                         C_NOT_SUPP = 5'd16;
  localparam logic [4:0] D_SRC_CAP = 5'd1, D_REQUEST = 5'd2, D_SNK_CAP = 5'd4;
  localparam int T_WCAP = 400, T_RSP = 100, T_TRANS = 200, T_CRC = 32, T_HRST = 20;

  function automatic logic [4:0] enc(input logic [3:0] n);
    case (n)
      4'h0: return 5'h1E; 4'h1: return 5'h09; 4'h2: return 5'h14; 4'h3: return 5'h15;
      4'h4: return 5'h0A; 4'h5: return 5'h0B; 4'h6: return 5'h0E; 4'h7: return 5'h0F;
      4'h8: return 5'h12; 4'h9: return 5'h13; 4'hA: return 5'h16; 4'hB: return 5'h17;
      4'hC: return 5'h1A; 4'hD: return 5'h1B; 4'hE: return 5'h1C; default: return 5'h1D;
    endcase
  endfunction
  // 5'h10 + nibble for a data symbol, 0 for anything else
  function automatic logic [4:0] dec(input logic [4:0] s);
    for (int i = 0; i < 16; i++) if (enc(4'(i)) == s) return 5'h10 | 5'(i);
    return 5'h00;
  endfunction
  function automatic logic [31:0] crc_byte(input logic [31:0] c0, input logic [7:0] b);
    logic [31:0] c;
    c = c0;
    for (int i = 0; i < 8; i++) c = (c[0] ^ b[i]) ? ((c >> 1) ^ 32'hEDB8_8320) : (c >> 1);
    return c;
  endfunction
  function automatic int match(input logic [4:0] a, b, c, d, input logic [4:0] w, x, y, z);
    return int'(a == w) + int'(b == x) + int'(c == y) + int'(d == z);
  endfunction

  // ------------------------------------------------------------ receive
  logic [4:0]  sh0, sh1, sh2, sh3;      // last 4 symbols, sh3 newest
  logic        in_pkt, half;
  logic [1:0]  sop_t;                    // 0 SOP 1 SOP' 2 SOP''
  logic [7:0]  rxb [0:33];
  logic [5:0]  rxn;                      // bytes received
  logic [3:0]  lo_nib;
  logic [2:0]  stored_id;
  logic        stored_v;
  // a complete good SOP message for the policy engine, valid one clock
  logic        pe_msg;
  logic [4:0]  pe_type;
  logic [2:0]  pe_ndo;
  logic [31:0] pe_obj [0:6];
  logic        rx_hr;                    // Hard Reset ordered set seen
  // GoodCRC to send
  logic        gc_req;
  logic [2:0]  gc_id;

  // ------------------------------------------------------------ transmit
  logic [4:0]  txs [0:79];
  logic [6:0]  txn, txi;                 // symbols in the frame, next to send
  logic        tx_busy, tx_is_gc, tx_is_hr;
  logic [1:0]  tries;
  logic        wait_gc;
  logic [5:0]  gc_tmo;
  logic        pe_send;                  // policy engine asks for a message
  logic [4:0]  pe_tx_type;
  logic [2:0]  pe_tx_ndo;
  logic [31:0] pe_tx_obj;
  logic        tx_ok, tx_fail;           // result of a policy-engine message, one clock
  logic        tx_hr;                    // send a Hard Reset ordered set

  logic [15:0] hdr;
  logic [31:0] crc;
  logic [7:0]  fb [0:33];
  int          fbn;

  // frame bytes -> symbols
  task automatic build(input logic [4:0] t, input logic [2:0] ndo, input logic [2:0] id, input logic [31:0] obj);
    hdr = {1'b0, ndo, id, 1'b0, 2'b10, 1'b0, t};
    fb[0] = hdr[7:0]; fb[1] = hdr[15:8];
    fbn = 2;
    if (ndo != 3'd0) begin
      fb[2] = obj[7:0]; fb[3] = obj[15:8]; fb[4] = obj[23:16]; fb[5] = obj[31:24];
      fbn = 6;
    end
    crc = 32'hFFFF_FFFF;
    for (int i = 0; i < 34; i++) if (i < fbn) crc = crc_byte(crc, fb[i]);
    crc = ~crc;
    fb[fbn] = crc[7:0]; fb[fbn + 1] = crc[15:8]; fb[fbn + 2] = crc[23:16]; fb[fbn + 3] = crc[31:24];
    fbn = fbn + 4;
    txs[0] = K_S1; txs[1] = K_S1; txs[2] = K_S1; txs[3] = K_S2;
    for (int i = 0; i < 34; i++)
      if (i < fbn) begin
        txs[4 + 2 * i] = enc(fb[i][3:0]);
        txs[5 + 2 * i] = enc(fb[i][7:4]);
      end
    txs[4 + 2 * fbn] = K_EOP;
    txn = 7'(5 + 2 * fbn);
  endtask

  // ------------------------------------------------------------ policy engine
  logic [3:0]  pe;
  logic [9:0]  tmr;
  logic        had_contract;
  logic [2:0]  sel_pos;
  logic        sel_mm;
  logic [9:0]  sel_v, best_v;
  logic [9:0]  pend_v;

  // receive path, combinational part
  wire [4:0]  d       = dec(rx_sym);
  wire        is_data = d[4];
  wire [15:0] rh      = {rxb[1], rxb[0]};

  logic [31:0] rc;
  logic        crc_ok;
  always_comb begin
    rc = 32'hFFFF_FFFF;
    for (int i = 0; i < 34; i++) if (i < int'(rxn)) rc = crc_byte(rc, rxb[i]);
    crc_ok = rxn >= 6'd6 && rc == 32'hDEBB_20E3 && rxn == 6'(6 + 4 * int'(rh[14:12])) && !half;
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      sh0 <= 5'h0; sh1 <= 5'h0; sh2 <= 5'h0; sh3 <= 5'h0;
      in_pkt <= 1'b0; half <= 1'b0; sop_t <= 2'd0; rxn <= 6'd0; lo_nib <= 4'h0;
      stored_id <= 3'd0; stored_v <= 1'b0;
      pe_msg <= 1'b0; pe_type <= 5'd0; pe_ndo <= 3'd0; rx_hr <= 1'b0;
      for (int i = 0; i < 7; i++) pe_obj[i] <= 32'h0;
      for (int i = 0; i < 34; i++) rxb[i] <= 8'h0;
      gc_req <= 1'b0; gc_id <= 3'd0;
      rx_good <= 8'd0; rx_bad <= 8'd0; rx_dup <= 8'd0; rx_other_sop <= 8'd0;
    end
    else begin
      pe_msg <= 1'b0;
      rx_hr  <= 1'b0;
      if (tx_ok && tx_is_gc == 1'b0 && pe_tx_type == C_SOFT_RST && pe_tx_ndo == 3'd0) stored_v <= 1'b0;
      if (tx_busy && tx_is_gc && txi == txn - 7'd1) gc_req <= 1'b0;
      if (rx_valid) begin
        sh0 <= sh1; sh1 <= sh2; sh2 <= sh3; sh3 <= rx_sym;
        if (!in_pkt) begin
          if (match(sh1, sh2, sh3, rx_sym, K_R1, K_R1, K_R1, K_R2) >= 3) rx_hr <= 1'b1;
          else if (match(sh1, sh2, sh3, rx_sym, K_R1, K_S1, K_R1, K_S3) >= 3) ;   // Cable Reset: not ours
          else if (match(sh1, sh2, sh3, rx_sym, K_S1, K_S1, K_S1, K_S2) >= 3) begin
            in_pkt <= 1'b1; sop_t <= 2'd0; rxn <= 6'd0; half <= 1'b0;
          end
          else if (match(sh1, sh2, sh3, rx_sym, K_S1, K_S1, K_S3, K_S3) >= 3) begin
            in_pkt <= 1'b1; sop_t <= 2'd1; rxn <= 6'd0; half <= 1'b0;
          end
          else if (match(sh1, sh2, sh3, rx_sym, K_S1, K_S3, K_S1, K_S3) >= 3) begin
            in_pkt <= 1'b1; sop_t <= 2'd2; rxn <= 6'd0; half <= 1'b0;
          end
          if (match(sh1, sh2, sh3, rx_sym, K_R1, K_R1, K_R1, K_R2) >= 3 ||
              match(sh1, sh2, sh3, rx_sym, K_S1, K_S1, K_S1, K_S2) >= 3 ||
              match(sh1, sh2, sh3, rx_sym, K_S1, K_S1, K_S3, K_S3) >= 3 ||
              match(sh1, sh2, sh3, rx_sym, K_S1, K_S3, K_S1, K_S3) >= 3 ||
              match(sh1, sh2, sh3, rx_sym, K_R1, K_S1, K_R1, K_S3) >= 3) begin
            sh0 <= 5'h0; sh1 <= 5'h0; sh2 <= 5'h0; sh3 <= 5'h0;
          end
        end
        else if (is_data) begin
          if (!half) begin lo_nib <= d[3:0]; half <= 1'b1; end
          else if (rxn == 6'd34) begin in_pkt <= 1'b0; rx_bad <= rx_bad + 8'd1; end   // too long
          else begin rxb[rxn] <= {d[3:0], lo_nib}; rxn <= rxn + 6'd1; half <= 1'b0; end
        end
        else if (rx_sym == K_EOP) begin
          in_pkt <= 1'b0;
          if (!crc_ok) rx_bad <= rx_bad + 8'd1;
          else if (sop_t != 2'd0) rx_other_sop <= rx_other_sop + 8'd1;
          else if (rh[4:0] == C_GOODCRC && rh[14:12] == 3'd0) ;              // to the transmitter
          else begin
            rx_good <= rx_good + 8'd1;
            gc_req <= 1'b1; gc_id <= rh[11:9];
            if (rh[4:0] == C_SOFT_RST && rh[14:12] == 3'd0) begin
              stored_id <= rh[11:9]; stored_v <= 1'b1;
              pe_msg <= 1'b1; pe_type <= rh[4:0]; pe_ndo <= 3'd0;
            end
            else if (stored_v && stored_id == rh[11:9]) rx_dup <= rx_dup + 8'd1;
            else begin
              stored_id <= rh[11:9]; stored_v <= 1'b1;
              pe_msg <= 1'b1; pe_type <= rh[4:0]; pe_ndo <= rh[14:12];
              for (int i = 0; i < 7; i++)
                pe_obj[i] <= {rxb[5 + 4 * i], rxb[4 + 4 * i], rxb[3 + 4 * i], rxb[2 + 4 * i]};
            end
          end
        end
        else begin in_pkt <= 1'b0; rx_bad <= rx_bad + 8'd1; end                 // invalid symbol
      end
      if (rx_hr || pe == P_HRST || pe == P_DIS) begin stored_v <= 1'b0; gc_req <= 1'b0; end   // detach too
    end
  end

  // GoodCRC received for the message in flight
  wire rx_gc = rx_valid && in_pkt && rx_sym == K_EOP && crc_ok && sop_t == 2'd0 &&
               rh[4:0] == C_GOODCRC && rh[14:12] == 3'd0 && rh[11:9] == msg_id;

  // ------------------------------------------------------------ transmitter
  always @(posedge clk) begin
    if (!rst_n) begin
      tx_valid <= 1'b0; tx_sym <= 5'h0; txn <= 7'd0; txi <= 7'd0; tx_busy <= 1'b0; tx_is_gc <= 1'b0;
      tx_is_hr <= 1'b0;
      tries <= 2'd0; wait_gc <= 1'b0; gc_tmo <= 6'd0; msg_id <= 3'd0; tx_ok <= 1'b0; tx_fail <= 1'b0;
      retries <= 8'd0;
      for (int i = 0; i < 80; i++) txs[i] <= 5'h0;
      for (int i = 0; i < 34; i++) fb[i] = 8'h0;
    end
    else begin
      tx_valid <= 1'b0;
      tx_ok    <= 1'b0;
      tx_fail  <= 1'b0;
      if (tx_hr) begin                                       // Hard Reset ordered set
        txs[0] = K_R1; txs[1] = K_R1; txs[2] = K_R1; txs[3] = K_R2; txn = 7'd4;
        txi <= 7'd0; tx_busy <= 1'b1; tx_is_gc <= 1'b1; tx_is_hr <= 1'b1;
        wait_gc <= 1'b0; msg_id <= 3'd0; tries <= 2'd0;
      end
      else if (tx_busy && tx_is_hr) begin
        tx_valid <= 1'b1;
        tx_sym   <= txs[txi];
        txi      <= txi + 7'd1;
        if (txi == txn - 7'd1) begin tx_busy <= 1'b0; tx_is_hr <= 1'b0; end
      end
      else if (rx_hr || pe == P_HRST || pe == P_DIS) begin
        tx_busy <= 1'b0; wait_gc <= 1'b0; msg_id <= 3'd0; tries <= 2'd0;
      end
      else if (tx_busy) begin
        tx_valid <= 1'b1;
        tx_sym   <= txs[txi];
        txi      <= txi + 7'd1;
        if (txi == txn - 7'd1) begin
          tx_busy <= 1'b0;
          if (!tx_is_gc) begin wait_gc <= 1'b1; gc_tmo <= 6'd0; end
        end
      end
      else if (gc_req && !wait_gc) begin
        build(C_GOODCRC, 3'd0, gc_id, 32'h0);
        txi <= 7'd0; tx_busy <= 1'b1; tx_is_gc <= 1'b1;
      end
      else if (wait_gc) begin
        gc_tmo <= gc_tmo + 6'd1;
        if (rx_gc) begin
          wait_gc <= 1'b0; tx_ok <= 1'b1; tries <= 2'd0;
          msg_id  <= (pe_tx_type == C_SOFT_RST && pe_tx_ndo == 3'd0) ? 3'd1 : msg_id + 3'd1;
        end
        else if (gc_tmo == 6'(T_CRC - 1)) begin
          wait_gc <= 1'b0;
          if (tries == 2'd2) begin tx_fail <= 1'b1; tries <= 2'd0; end
          else begin
            tries <= tries + 2'd1; retries <= retries + 8'd1;
            txi <= 7'd0; tx_busy <= 1'b1; tx_is_gc <= 1'b0;
          end
        end
      end
      else if (pe_send) begin
        build(pe_tx_type, pe_tx_ndo, (pe_tx_type == C_SOFT_RST && pe_tx_ndo == 3'd0) ? 3'd0 : msg_id,
              pe_tx_obj);
        if (pe_tx_type == C_SOFT_RST && pe_tx_ndo == 3'd0) msg_id <= 3'd0;
        txi <= 7'd0; tx_busy <= 1'b1; tx_is_gc <= 1'b0; tries <= 2'd0;
      end
      if (pe_msg && pe_type == C_SOFT_RST && pe_ndo == 3'd0) begin   // protocol layer reset
        msg_id <= 3'd0; wait_gc <= 1'b0; tries <= 2'd0;
      end
    end
  end

  // ------------------------------------------------------------ policy engine
  // best fixed PDO for want_v50 / want_ma10
  always_comb begin
    sel_pos = 3'd1; sel_mm = 1'b1; best_v = 10'd0; sel_v = 10'd100;
    for (int i = 0; i < 7; i++)
      if (i < int'(pe_ndo) && pe_obj[i][31:30] == 2'b00 && pe_obj[i][19:10] <= want_v50 &&
          pe_obj[i][9:0] >= want_ma10 && pe_obj[i][19:10] > best_v) begin
        best_v = pe_obj[i][19:10]; sel_pos = 3'(i + 1); sel_mm = 1'b0; sel_v = pe_obj[i][19:10];
      end
    if (sel_mm) sel_v = pe_obj[0][19:10];
  end

  wire ctl = pe_msg && pe_ndo == 3'd0;

  task automatic send(input logic [4:0] t, input logic [2:0] n, input logic [31:0] o);
    pe_send <= 1'b1; pe_tx_type <= t; pe_tx_ndo <= n; pe_tx_obj <= o;
  endtask

  task automatic go_hard_reset();
    pe <= P_HRST; tmr <= 10'd0; contract <= 1'b0; had_contract <= 1'b0; vbus_v50 <= 10'd100;
    hard_resets <= hard_resets + 8'd1; pe_send <= 1'b0;
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      pe <= P_DIS; tmr <= 10'd0; contract <= 1'b0; had_contract <= 1'b0; vbus_v50 <= 10'd0;
      obj_pos <= 3'd0; mismatch <= 1'b0; pend_v <= 10'd0; hard_resets <= 8'd0; hr_counter <= 2'd0;
      pe_send <= 1'b0; pe_tx_type <= 5'd0; pe_tx_ndo <= 3'd0; pe_tx_obj <= 32'h0; tx_hr <= 1'b0;
    end
    else begin
      tx_hr <= 1'b0;
      if (pe_send && !tx_busy && !wait_gc && !(gc_req && !wait_gc)) pe_send <= 1'b0;
      tmr <= tmr + 10'd1;
      if (!vbus_present && pe != P_HRST) begin
        pe <= P_DIS; contract <= 1'b0; had_contract <= 1'b0; vbus_v50 <= 10'd0; pe_send <= 1'b0;
        hr_counter <= 2'd0;
      end
      else if (rx_hr && pe != P_DIS) begin
        go_hard_reset();
      end
      else if (pe_msg && pe_type == C_SOFT_RST && pe_ndo == 3'd0 && pe != P_DIS && pe != P_HRST) begin
        pe <= P_SRACC; send(C_ACCEPT, 3'd0, 32'h0);
      end
      else case (pe)
        P_DIS:
          if (vbus_present) begin pe <= P_WCAP; tmr <= 10'd0; vbus_v50 <= 10'd100; end
        P_WCAP:
          if (pe_msg && pe_type == D_SRC_CAP && pe_ndo != 3'd0) begin
            pe <= P_REQ; tmr <= 10'd0;
            obj_pos <= sel_pos; mismatch <= sel_mm; pend_v <= sel_v;
            send(D_REQUEST, 3'd1, {1'b0, sel_pos, 1'b0, sel_mm, 1'b0, 1'b0, 1'b0, 3'b000,
                                    want_ma10, want_ma10});
          end
          else if (tmr == 10'(T_WCAP - 1)) begin
            if (hr_counter == 2'd2) pe <= P_ERR;
            else begin go_hard_reset(); tx_hr <= 1'b1; hr_counter <= hr_counter + 2'd1; end
          end
        P_REQ:
          if (tx_ok) begin pe <= P_WRSP; tmr <= 10'd0; end
          else if (tx_fail) begin go_hard_reset(); tx_hr <= 1'b1; end
        P_WRSP:
          if (ctl && pe_type == C_ACCEPT) begin pe <= P_TRANS; tmr <= 10'd0; end
          else if (ctl && (pe_type == C_REJECT || pe_type == C_WAIT)) begin
            pe <= had_contract ? P_READY : P_WCAP; tmr <= 10'd0;
          end
          else if (pe_msg) begin pe <= P_SNDSR; send(C_SOFT_RST, 3'd0, 32'h0); end
          else if (tmr == 10'(T_RSP - 1)) begin go_hard_reset(); tx_hr <= 1'b1; end
        P_TRANS:
          if (ctl && pe_type == C_PS_RDY) begin
            pe <= P_READY; contract <= 1'b1; had_contract <= 1'b1; vbus_v50 <= pend_v; hr_counter <= 2'd0;
          end
          else if (pe_msg) begin go_hard_reset(); tx_hr <= 1'b1; end
          else if (tmr == 10'(T_TRANS - 1)) begin go_hard_reset(); tx_hr <= 1'b1; end
        P_READY:
          if (pe_msg) begin
            if (pe_type == D_SRC_CAP && pe_ndo != 3'd0) begin
              pe <= P_REQ; tmr <= 10'd0;
              obj_pos <= sel_pos; mismatch <= sel_mm; pend_v <= sel_v;
              send(D_REQUEST, 3'd1, {1'b0, sel_pos, 1'b0, sel_mm, 1'b0, 1'b0, 1'b0, 3'b000,
                                      want_ma10, want_ma10});
            end
            else if (ctl && pe_type == C_GET_SNK) begin
              pe <= P_SNKCAP; send(D_SNK_CAP, 3'd1, {12'h000, 10'd100, want_ma10});
            end
            else if (ctl && pe_type == C_PING) ;
            else if (ctl && (pe_type == C_ACCEPT || pe_type == C_REJECT || pe_type == C_PS_RDY ||
                             pe_type == C_WAIT)) begin
              pe <= P_SNDSR; send(C_SOFT_RST, 3'd0, 32'h0);
            end
            else begin pe <= P_NS; send(C_NOT_SUPP, 3'd0, 32'h0); end
          end
        P_SNKCAP, P_NS:
          if (tx_ok) pe <= P_READY;
          else if (tx_fail) begin pe <= P_SNDSR; send(C_SOFT_RST, 3'd0, 32'h0); end
        P_SRACC:
          if (tx_ok) begin pe <= P_WCAP; tmr <= 10'd0; contract <= 1'b0; had_contract <= 1'b0; end
          else if (tx_fail) begin go_hard_reset(); tx_hr <= 1'b1; end
        P_SNDSR:
          if (tx_ok) begin pe <= P_WSRACC; tmr <= 10'd0; end
          else if (tx_fail) begin go_hard_reset(); tx_hr <= 1'b1; end
        P_WSRACC:
          if (ctl && pe_type == C_ACCEPT) begin
            pe <= P_WCAP; tmr <= 10'd0; contract <= 1'b0; had_contract <= 1'b0;
          end
          else if (tmr == 10'(T_RSP - 1)) begin go_hard_reset(); tx_hr <= 1'b1; end
        P_HRST:
          if (tmr == 10'(T_HRST - 1)) begin pe <= vbus_present ? P_WCAP : P_DIS; tmr <= 10'd0; end
        default: ;                                                   // P_ERR: until VBUS drops
      endcase
    end
  end

  always_comb pe_state = pe;

endmodule
