// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB 2.0 device (USB 2.0 ch. 7-9, timers scaled to clocks), one packet per
// clock at the packet layer plus the bus line state. Plain ANSI ports so the
// L1b smoke harness and tb/smoke_func_tb.sv build it directly.
//
// Packets: rx_pid is the full PID byte {~type, type}; a byte whose check
//   nibble does not match is dropped (pid_err). Tokens carry rx_addr /
//   rx_endp (SOF: frame = {rx_endp, rx_addr}; SPLIT: hub = rx_addr,
//   rx_endp = {SC, port}); rx_crc_ok is the CRC5 of a token or the CRC16 of
//   a data packet; rx_len is the data payload length in bytes, rx_data its
//   first 4 bytes (a SETUP packet: {wIndex[7:0], wValue[7:0], bRequest,
//   bmRequestType}). Every answer is one registered packet on tx_* the
//   clock after the packet it answers.
// Line / speed (ch. 7.1.7):
//   FS: SE0 for 16 clocks (after J was seen since the last reset) is a bus
//   reset. With hs_cap the device then chirps K for 8 clocks and waits up
//   to 48 clocks for the host chirp: 3 K-J pairs, each level held >= 2
//   clocks -> HS; else stays FS. 24 clocks of idle J -> Suspend.
//   HS: 24 clocks without a packet -> reverts to FS termination; SE0 then
//   is a reset (new chirp), J is Suspend. Suspend: K >= 4 clocks, then the
//   end of K resumes at the old speed; SE0 for 16 clocks -> reset.
//   Packets are taken only in FS / HS.
// Device (ch. 9): DEFAULT -> ADDRESS -> CONFIGURED. Endpoint 0 control;
//   EP1 bulk OUT (2 packet buffers, app_rd frees one); EP2 bulk IN (2-entry
//   FIFO loaded by app_wr / app_len, clamped to MPS); EP3 interrupt IN
//   (app_irq raises a 4-byte report). MPS: EP0 64, bulk 512 (HS) / 64 (FS).
//   EP1..3 answer only when CONFIGURED; other endpoints never answer.
// Transactions:
//   OUT/SETUP token -> data within 16 clocks. Data with a bad CRC16 or
//   longer than MPS (babble) gets no handshake. OUT to a halted endpoint
//   -> STALL; data PID != expected toggle -> ACK, dropped (dup_cnt); no
//   buffer -> NAK; else ACK, toggle flips; in HS the packet that fills the
//   last buffer -> NYET. HS PING: ACK when a buffer is free, else NAK.
//   IN token -> DATA0/1 by the endpoint toggle, or NAK (nothing to send) /
//   STALL (halted). Host ACK within 16 clocks flips the toggle and retires
//   the data; no ACK (tmo_cnt) keeps both, so the retry repeats the PID.
// Control: SETUP (always DATA0, 8 bytes) is always ACKed and clears a
//   protocol stall. SET_ADDRESS (not in CONFIGURED) and SET_CONFIGURATION
//   (0/1, not in DEFAULT; resets EP1..3 toggles and halts), CLEAR_FEATURE /
//   SET_FEATURE (ENDPOINT_HALT, EP1..3, CONFIGURED) take effect when the
//   zero-length DATA1 status IN is ACKed. GET_STATUS (device / endpoint)
//   sends 2 bytes (DATA1), then takes a zero-length DATA1 status OUT.
//   Anything else -> protocol stall: later data / status tokens get STALL.
// Split (ch. 11.14-11.18, HS hub with one Transaction Translator): a SPLIT
//   to our address (HS only) followed within 4 clocks by OUT/SETUP/IN to
//   the FS device. Start split: OUT/SETUP + data -> ACK and the TT works
//   for 8 clocks; IN -> ACK; TT busy -> NAK. Complete split on the same
//   device / endpoint / direction: TT busy -> NYET; done -> ACK (OUT) or
//   DATA0 with 8 bytes (IN) and the TT is free (split_cnt); nothing that
//   matches -> STALL.
// SOF: frame_num; in HS up to 8 microframes share a frame number (uframe);
//   a frame number other than the next one, or a 9th microframe -> sof_miss.
// A bus reset returns the device to DEFAULT / address 0 and clears toggles,
//   halts, buffers, control and TT state (resets).

module usb2_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        hs_cap,
  input  logic [1:0]  line,          // 0 SE0 1 J 2 K
  input  logic        rx_valid,
  input  logic [7:0]  rx_pid,
  input  logic        rx_crc_ok,
  input  logic [6:0]  rx_addr,
  input  logic [3:0]  rx_endp,
  input  logic [9:0]  rx_len,
  input  logic [31:0] rx_data,
  input  logic        app_rd,
  input  logic        app_wr,
  input  logic [9:0]  app_len,
  input  logic        app_irq,
  output logic [2:0]  ls,            // 0 FS 1 CHIRP 2 CHIRP_WAIT 3 HS 4 SUSPEND
  output logic        hs,
  output logic        chirp_k,
  output logic [1:0]  dev_state,     // 0 DEFAULT 1 ADDRESS 2 CONFIGURED
  output logic [6:0]  dev_addr,
  output logic        cfg_val,
  output logic [10:0] frame_num,
  output logic [2:0]  uframe,
  output logic [3:0]  ep_halt,
  output logic        tx_valid,
  output logic [7:0]  tx_pid,
  output logic [9:0]  tx_len,
  output logic [15:0] tx_data,
  output logic [7:0]  pid_err,
  output logic [7:0]  crc5_err,
  output logic [7:0]  crc16_err,
  output logic [7:0]  babble_cnt,
  output logic [7:0]  dup_cnt,
  output logic [7:0]  nak_cnt,
  output logic [7:0]  stall_cnt,
  output logic [7:0]  nyet_cnt,
  output logic [7:0]  sof_cnt,
  output logic [7:0]  sof_miss,
  output logic [7:0]  resets,
  output logic [7:0]  tmo_cnt,
  output logic [7:0]  split_cnt
);
  localparam logic [3:0] P_OUT = 4'h1, P_IN = 4'h9, P_SOF = 4'h5, P_SETUP = 4'hD,
                         P_DATA0 = 4'h3, P_DATA1 = 4'hB, P_DATA2 = 4'h7, P_MDATA = 4'hF,
                         P_ACK = 4'h2, P_NAK = 4'hA, P_STALL = 4'hE, P_NYET = 4'h6,
                         P_SPLIT = 4'h8, P_PING = 4'h4;
  localparam logic [1:0] LN_SE0 = 2'd0, LN_J = 2'd1, LN_K = 2'd2;
  localparam logic [2:0] L_FS = 3'd0, L_CHIRP = 3'd1, L_CHWAIT = 3'd2, L_HS = 3'd3, L_SUSP = 3'd4;
  localparam logic [2:0] X_IDLE = 3'd0, X_ODATA = 3'd1, X_INHS = 3'd2, X_SPLIT = 3'd3, X_SPDATA = 3'd4;
  localparam logic [2:0] C_IDLE = 3'd0, C_DIN = 3'd1, C_SOUT = 3'd2, C_SIN = 3'd3, C_STALL = 3'd4;
  localparam logic [1:0] D_DEFAULT = 2'd0, D_ADDRESS = 2'd1, D_CONFIGURED = 2'd2;
  localparam int T_RST = 16, T_CHIRP = 8, T_CHWAIT = 48, T_IDLE = 24, T_RESUME = 4,
                 T_TMO = 16, T_TT = 8, T_SPLIT = 4;

  // working copies of the outputs (blocking inside the clock), registered below
  logic [2:0]  w_ls;
  logic        w_hs, w_ck;
  logic [1:0]  w_st;
  logic [6:0]  w_addr;
  logic        w_cfg;
  logic [10:0] w_fr;
  logic [2:0]  w_uf;
  logic [3:0]  w_halt;
  logic        w_tv;
  logic [7:0]  w_tpid;
  logic [9:0]  w_tlen;
  logic [15:0] w_tdat;
  logic [7:0]  n_pid, n_c5, n_c16, n_bab, n_dup, n_nak, n_stall, n_nyet, n_sof, n_miss, n_rst, n_tmo, n_split;

  // link
  logic [4:0]  se0_cnt;
  logic        se0_armed;
  logic [5:0]  idle_cnt;
  logic [5:0]  lsc;
  logic [2:0]  k_cnt;
  logic [1:0]  ch_lvl;
  logic [5:0]  ch_len;
  logic [2:0]  ch_n;
  logic        hs_pre;
  // endpoints
  logic [3:0]  tog_out;
  logic [3:0]  tog_in;
  logic [1:0]  ob_n;
  logic [9:0]  ib_len [2];
  logic [7:0]  ib_seq [2];
  logic        ib_rd, ib_wr;
  logic [1:0]  ib_n;
  logic [7:0]  wr_seq;
  logic        irq_pend;
  logic [7:0]  irq_seq;
  // transaction
  logic [2:0]  xs;
  logic [4:0]  xt;
  logic [3:0]  x_ep;
  logic        x_setup;
  logic [1:0]  x_src;           // IN data from 0 EP0, 2 EP2, 3 EP3
  logic        sp_sc;
  logic [6:0]  sp_addr;
  logic [3:0]  sp_ep;
  // control
  logic [2:0]  cph;
  logic [7:0]  c_req, c_val, c_idx;
  logic [15:0] c_status;
  // transaction translator
  logic [1:0]  tt_st;           // 0 free 1 busy 2 done
  logic [3:0]  tt_tmr;
  logic        tt_in;
  logic [6:0]  tt_addr;
  logic [3:0]  tt_ep;
  // frame
  logic        sof_seen;

  // packet-layer locals
  logic        pv, act, consumed, is_tok, is_data, tg;
  logic [3:0]  pt;
  logic [10:0] f;
  logic [9:0]  mps;
  logic [3:0]  ce;

  task automatic answer(input logic [3:0] p, input logic [9:0] len, input logic [15:0] d);
    w_tv = 1'b1; w_tpid = {~p, p}; w_tlen = len; w_tdat = d;
    if (p == P_NAK)   n_nak   = n_nak + 8'd1;
    if (p == P_STALL) n_stall = n_stall + 8'd1;
    if (p == P_NYET)  n_nyet  = n_nyet + 8'd1;
  endtask

  task automatic send_in(input logic [1:0] src, input logic t, input logic [9:0] len, input logic [15:0] d);
    answer(t ? P_DATA1 : P_DATA0, len, d);
    xs = X_INHS; xt = 5'd0; x_src = src;
  endtask

  task automatic bus_reset();
    w_st = D_DEFAULT; w_addr = 7'h00; w_cfg = 1'b0; w_halt = 4'h0;
    tog_out = 4'h0; tog_in = 4'h0; ob_n = 2'd0;
    ib_rd = 1'b0; ib_wr = 1'b0; ib_n = 2'd0; irq_pend = 1'b0;
    xs = X_IDLE; xt = 5'd0; cph = C_IDLE; tt_st = 2'd0; tt_tmr = 4'd0;
    w_fr = 11'd0; w_uf = 3'd0; sof_seen = 1'b0;
    n_rst = n_rst + 8'd1;
    se0_cnt = 5'd0; se0_armed = 1'b0; idle_cnt = 6'd0; k_cnt = 3'd0; w_hs = 1'b0;
    lsc = 6'd0;
    if (hs_cap) w_ls = L_CHIRP;
    else        w_ls = L_FS;
  endtask

  // a completed status / data stage on EP0
  task automatic ctl_done();
    if (cph == C_DIN) cph = C_SOUT;
    else if (cph == C_SIN) begin
      cph = C_IDLE;
      case (c_req)
        8'h05: begin w_addr = c_val[6:0]; w_st = (c_val[6:0] == 7'h00) ? D_DEFAULT : D_ADDRESS; end
        8'h09: begin
          w_cfg = c_val[0]; w_st = c_val[0] ? D_CONFIGURED : D_ADDRESS;
          tog_out = 4'h0; tog_in = 4'h0; w_halt = 4'h0;
        end
        8'h01: begin w_halt[c_idx[1:0]] = 1'b0; tog_out[c_idx[1:0]] = 1'b0; tog_in[c_idx[1:0]] = 1'b0; end
        8'h03: w_halt[c_idx[1:0]] = 1'b1;
        default: ;
      endcase
    end
  endtask

  task automatic setup_decode(input logic [31:0] d);
    logic [7:0] t;
    t = d[7:0]; c_req = d[15:8]; c_val = d[23:16]; c_idx = d[31:24];
    if (c_req == 8'h05 && t == 8'h00 && w_st != D_CONFIGURED && !c_val[7])
      cph = C_SIN;
    else if (c_req == 8'h09 && t == 8'h00 && w_st != D_DEFAULT && c_val <= 8'd1)
      cph = C_SIN;
    else if (c_req == 8'h00 && t == 8'h80) begin
      c_status = 16'h0001; cph = C_DIN;                     // self-powered
    end else if (c_req == 8'h00 && t == 8'h82 && c_idx[6:2] == 5'd0 &&
                 (c_idx[1:0] == 2'd0 || w_st == D_CONFIGURED)) begin
      c_status = {15'd0, w_halt[c_idx[1:0]]}; cph = C_DIN;
    end else if ((c_req == 8'h01 || c_req == 8'h03) && t == 8'h02 && c_val == 8'h00 &&
                 c_idx[6:2] == 5'd0 && c_idx[1:0] != 2'd0 && w_st == D_CONFIGURED)
      cph = C_SIN;
    else
      cph = C_STALL;
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      w_ls = L_FS; w_hs = 1'b0; w_ck = 1'b0; w_st = D_DEFAULT; w_addr = 7'h00; w_cfg = 1'b0;
      w_fr = 11'd0; w_uf = 3'd0; w_halt = 4'h0; w_tv = 1'b0; w_tpid = 8'h00; w_tlen = 10'd0; w_tdat = 16'h0;
      n_pid = 8'd0; n_c5 = 8'd0; n_c16 = 8'd0; n_bab = 8'd0; n_dup = 8'd0; n_nak = 8'd0; n_stall = 8'd0;
      n_nyet = 8'd0; n_sof = 8'd0; n_miss = 8'd0; n_rst = 8'd0; n_tmo = 8'd0; n_split = 8'd0;
      se0_cnt = 5'd0; se0_armed = 1'b1; idle_cnt = 6'd0; lsc = 6'd0; k_cnt = 3'd0;
      ch_lvl = LN_SE0; ch_len = 6'd0; ch_n = 3'd0; hs_pre = 1'b0;
      tog_out = 4'h0; tog_in = 4'h0; ob_n = 2'd0;
      for (int i = 0; i < 2; i++) begin ib_len[i] = 10'd0; ib_seq[i] = 8'd0; end
      ib_rd = 1'b0; ib_wr = 1'b0; ib_n = 2'd0; wr_seq = 8'd0; irq_pend = 1'b0; irq_seq = 8'd0;
      xs = X_IDLE; xt = 5'd0; x_ep = 4'd0; x_setup = 1'b0; x_src = 2'd0;
      sp_sc = 1'b0; sp_addr = 7'h00; sp_ep = 4'h0;
      cph = C_IDLE; c_req = 8'h00; c_val = 8'h00; c_idx = 8'h00; c_status = 16'h0;
      tt_st = 2'd0; tt_tmr = 4'd0; tt_in = 1'b0; tt_addr = 7'h00; tt_ep = 4'h0;
      sof_seen = 1'b0;
    end else begin
      w_tv = 1'b0; w_tpid = 8'h00; w_tlen = 10'd0; w_tdat = 16'h0; w_ck = 1'b0;
      mps = w_hs ? 10'd512 : 10'd64;

      // ------------------------------------------------ packet layer
      act = (w_ls == L_FS) || (w_ls == L_HS);
      pv  = rx_valid && act;
      pt  = rx_pid[3:0];
      if (pv && (rx_pid[7:4] != ~rx_pid[3:0])) begin
        n_pid = n_pid + 8'd1; pv = 1'b0;
      end
      is_tok  = (pt == P_OUT) || (pt == P_IN) || (pt == P_SETUP) || (pt == P_SOF) ||
                (pt == P_PING) || (pt == P_SPLIT);
      is_data = (pt[1:0] == 2'b11);
      consumed = 1'b0;

      if (!pv) begin
        if (xs == X_ODATA || xs == X_SPDATA) begin
          xt = xt + 5'd1;
          if (xt == 5'(T_TMO)) xs = X_IDLE;
        end else if (xs == X_INHS) begin
          xt = xt + 5'd1;
          if (xt == 5'(T_TMO)) begin xs = X_IDLE; n_tmo = n_tmo + 8'd1; end
        end else if (xs == X_SPLIT) begin
          xt = xt + 5'd1;
          if (xt == 5'(T_SPLIT)) xs = X_IDLE;
        end
      end else begin
        // ---- waiting for the host handshake of our IN data
        if (xs == X_INHS) begin
          xs = X_IDLE;
          if (pt == P_ACK) begin
            consumed = 1'b1;
            case (x_src)
              2'd0: ctl_done();
              2'd2: begin
                tog_in[2] = ~tog_in[2]; ib_rd = ~ib_rd; ib_n = ib_n - 2'd1;
              end
              default: begin
                tog_in[3] = ~tog_in[3]; irq_pend = 1'b0; irq_seq = irq_seq + 8'd1;
              end
            endcase
          end else begin
            n_tmo = n_tmo + 8'd1;
            if (!is_tok) consumed = 1'b1;
          end
        end
        // ---- data stage of OUT / SETUP
        else if (xs == X_ODATA) begin
          if (is_data) begin
            consumed = 1'b1; xs = X_IDLE;
            tg = (pt == P_DATA1);
            if (!rx_crc_ok) n_c16 = n_c16 + 8'd1;
            else if (pt == P_DATA2 || pt == P_MDATA) n_pid = n_pid + 8'd1;
            else if (x_setup) begin
              if (pt == P_DATA0 && rx_len == 10'd8) begin
                answer(P_ACK, 10'd0, 16'h0);
                setup_decode(rx_data);
              end
            end else if (x_ep == 4'd0) begin
              if (rx_len > 10'd64) n_bab = n_bab + 8'd1;
              else if (cph == C_SOUT && tg && rx_len == 10'd0) begin
                answer(P_ACK, 10'd0, 16'h0); cph = C_IDLE;
              end else if (cph == C_SOUT && !tg) begin
                answer(P_ACK, 10'd0, 16'h0); n_dup = n_dup + 8'd1;
              end else begin
                answer(P_STALL, 10'd0, 16'h0); cph = C_STALL;
              end
            end else begin
              if (rx_len > mps) n_bab = n_bab + 8'd1;
              else if (w_halt[1]) answer(P_STALL, 10'd0, 16'h0);
              else if (tg != tog_out[1]) begin
                answer(P_ACK, 10'd0, 16'h0); n_dup = n_dup + 8'd1;
              end else if (ob_n == 2'd2) answer(P_NAK, 10'd0, 16'h0);
              else begin
                ob_n = ob_n + 2'd1; tog_out[1] = ~tog_out[1];
                if (w_hs && ob_n == 2'd2) answer(P_NYET, 10'd0, 16'h0);
                else                      answer(P_ACK, 10'd0, 16'h0);
              end
            end
          end else if (is_tok) xs = X_IDLE;
          else consumed = 1'b1;
        end
        // ---- data stage of a start-split OUT / SETUP
        else if (xs == X_SPDATA) begin
          if (is_data) begin
            consumed = 1'b1; xs = X_IDLE;
            if (!rx_crc_ok) n_c16 = n_c16 + 8'd1;
            else if (rx_len > 10'd64) n_bab = n_bab + 8'd1;
            else if (tt_st != 2'd0) answer(P_NAK, 10'd0, 16'h0);
            else begin
              answer(P_ACK, 10'd0, 16'h0);
              tt_st = 2'd1; tt_tmr = 4'd0; tt_in = 1'b0; tt_addr = sp_addr; tt_ep = sp_ep;
            end
          end else if (is_tok) xs = X_IDLE;
          else consumed = 1'b1;
        end
        // ---- the token after a SPLIT
        else if (xs == X_SPLIT) begin
          xs = X_IDLE;
          if (pt == P_OUT || pt == P_SETUP || pt == P_IN) begin
            consumed = 1'b1;
            if (!rx_crc_ok) n_c5 = n_c5 + 8'd1;
            else if (!sp_sc) begin
              if (pt == P_IN) begin
                if (tt_st == 2'd0) begin
                  answer(P_ACK, 10'd0, 16'h0);
                  tt_st = 2'd1; tt_tmr = 4'd0; tt_in = 1'b1; tt_addr = rx_addr; tt_ep = rx_endp;
                end else answer(P_NAK, 10'd0, 16'h0);
              end else begin
                xs = X_SPDATA; xt = 5'd0; sp_addr = rx_addr; sp_ep = rx_endp;
              end
            end else begin
              if (tt_st == 2'd0 || tt_addr != rx_addr || tt_ep != rx_endp || tt_in != (pt == P_IN))
                answer(P_STALL, 10'd0, 16'h0);
              else if (tt_st == 2'd1) answer(P_NYET, 10'd0, 16'h0);
              else begin
                if (tt_in) answer(P_DATA0, 10'd8, {5'd0, tt_addr, tt_ep});
                else       answer(P_ACK, 10'd0, 16'h0);
                tt_st = 2'd0; n_split = n_split + 8'd1;
              end
            end
          end else if (!is_tok) consumed = 1'b1;
        end

        // ---- a new token
        if (!consumed && xs == X_IDLE && is_tok) begin
          if (!rx_crc_ok) n_c5 = n_c5 + 8'd1;
          else if (pt == P_SOF) begin
            n_sof = n_sof + 8'd1;
            f = {rx_endp, rx_addr};
            if (sof_seen && w_hs && f == w_fr) begin
              if (w_uf == 3'd7) n_miss = n_miss + 8'd1;
              else              w_uf = w_uf + 3'd1;
            end else begin
              if (sof_seen && f != w_fr + 11'd1) n_miss = n_miss + 8'd1;
              w_uf = 3'd0;
            end
            w_fr = f; sof_seen = 1'b1;
          end else if (pt == P_SPLIT) begin
            if (w_hs && rx_addr == w_addr) begin
              xs = X_SPLIT; xt = 5'd0; sp_sc = rx_endp[3];
            end
          end else if (rx_addr == w_addr) begin
            ce = rx_endp;
            case (pt)
              P_SETUP: if (ce == 4'd0) begin xs = X_ODATA; xt = 5'd0; x_ep = 4'd0; x_setup = 1'b1; end
              P_OUT: if (ce == 4'd0 || (ce == 4'd1 && w_st == D_CONFIGURED)) begin
                xs = X_ODATA; xt = 5'd0; x_ep = ce; x_setup = 1'b0;
              end
              P_PING: if (w_hs) begin
                if (ce == 4'd0) answer(P_ACK, 10'd0, 16'h0);
                else if (ce == 4'd1 && w_st == D_CONFIGURED) begin
                  if (w_halt[1])          answer(P_STALL, 10'd0, 16'h0);
                  else if (ob_n == 2'd2)  answer(P_NAK, 10'd0, 16'h0);
                  else                    answer(P_ACK, 10'd0, 16'h0);
                end
              end
              P_IN: begin
                if (ce == 4'd0) begin
                  if (cph == C_DIN)      send_in(2'd0, 1'b1, 10'd2, c_status);
                  else if (cph == C_SIN) send_in(2'd0, 1'b1, 10'd0, 16'h0);
                  else begin
                    answer(P_STALL, 10'd0, 16'h0); cph = C_STALL;
                  end
                end else if (ce == 4'd2 && w_st == D_CONFIGURED) begin
                  if (w_halt[2])        answer(P_STALL, 10'd0, 16'h0);
                  else if (ib_n == 2'd0) answer(P_NAK, 10'd0, 16'h0);
                  else send_in(2'd2, tog_in[2], ib_len[ib_rd], {8'hB2, ib_seq[ib_rd]});
                end else if (ce == 4'd3 && w_st == D_CONFIGURED) begin
                  if (w_halt[3])   answer(P_STALL, 10'd0, 16'h0);
                  else if (!irq_pend) answer(P_NAK, 10'd0, 16'h0);
                  else send_in(2'd3, tog_in[3], 10'd4, {8'hE3, irq_seq});
                end
              end
              default: ;
            endcase
          end
        end
      end

      // ------------------------------------------------ application side
      if (app_rd && ob_n != 2'd0) ob_n = ob_n - 2'd1;
      if (app_wr && ib_n != 2'd2) begin
        ib_len[ib_wr] = (app_len > mps) ? mps : app_len;
        ib_seq[ib_wr] = wr_seq;
        wr_seq = wr_seq + 8'd1; ib_wr = ~ib_wr; ib_n = ib_n + 2'd1;
      end
      if (app_irq) irq_pend = 1'b1;
      if (tt_st == 2'd1) begin
        tt_tmr = tt_tmr + 4'd1;
        if (tt_tmr == 4'(T_TT)) tt_st = 2'd2;
      end

      // ------------------------------------------------ line / speed
      case (w_ls)
        L_FS: begin
          if (line == LN_SE0 && !rx_valid) begin
            if (se0_cnt != 5'd31) se0_cnt = se0_cnt + 5'd1;
          end else se0_cnt = 5'd0;
          if (line != LN_SE0) se0_armed = 1'b1;
          if (line == LN_J && !rx_valid) idle_cnt = idle_cnt + 6'd1;
          else idle_cnt = 6'd0;
          if (se0_cnt == 5'(T_RST) && se0_armed) bus_reset();
          else if (idle_cnt == 6'(T_IDLE)) begin
            w_ls = L_SUSP; hs_pre = 1'b0; idle_cnt = 6'd0; k_cnt = 3'd0; se0_cnt = 5'd0;
          end
        end
        L_HS: begin
          if (rx_valid) idle_cnt = 6'd0;
          else idle_cnt = idle_cnt + 6'd1;
          if (idle_cnt == 6'(T_IDLE)) begin
            if (line == LN_SE0) bus_reset();
            else begin
              w_ls = L_SUSP; hs_pre = 1'b1; w_hs = 1'b0; idle_cnt = 6'd0; k_cnt = 3'd0;
              se0_cnt = 5'd0; se0_armed = 1'b1;
            end
          end
        end
        L_SUSP: begin
          if (line == LN_K) begin
            if (k_cnt != 3'd7) k_cnt = k_cnt + 3'd1;
          end else begin
            if (k_cnt >= 3'(T_RESUME)) begin
              w_ls = hs_pre ? L_HS : L_FS; w_hs = hs_pre; idle_cnt = 6'd0;
            end
            k_cnt = 3'd0;
          end
          if (w_ls == L_SUSP) begin
            if (line == LN_SE0) begin
              if (se0_cnt != 5'd31) se0_cnt = se0_cnt + 5'd1;
            end else begin
              se0_cnt = 5'd0; se0_armed = 1'b1;
            end
            if (se0_cnt == 5'(T_RST) && se0_armed) bus_reset();
          end
        end
        L_CHIRP: begin
          w_ck = 1'b1; lsc = lsc + 6'd1;
          if (lsc == 6'(T_CHIRP)) begin
            w_ls = L_CHWAIT; lsc = 6'd0; ch_lvl = LN_SE0; ch_len = 6'd0; ch_n = 3'd0;
          end
        end
        L_CHWAIT: begin
          lsc = lsc + 6'd1;
          if (line == ch_lvl) begin
            if (ch_len != 6'd63) ch_len = ch_len + 6'd1;
          end else begin
            ch_lvl = line; ch_len = 6'd1;
          end
          if (ch_len == 6'd2 && line == (ch_n[0] ? LN_J : LN_K)) ch_n = ch_n + 3'd1;
          if (ch_n == 3'd6) begin
            w_ls = L_HS; w_hs = 1'b1; idle_cnt = 6'd0;
          end else if (lsc == 6'(T_CHWAIT)) begin
            w_ls = L_FS; idle_cnt = 6'd0; se0_cnt = 5'd0;
          end
        end
        default: w_ls = L_FS;
      endcase
    end

    ls <= w_ls; hs <= w_hs; chirp_k <= w_ck; dev_state <= w_st; dev_addr <= w_addr; cfg_val <= w_cfg;
    frame_num <= w_fr; uframe <= w_uf; ep_halt <= w_halt;
    tx_valid <= w_tv; tx_pid <= w_tpid; tx_len <= w_tlen; tx_data <= w_tdat;
    pid_err <= n_pid; crc5_err <= n_c5; crc16_err <= n_c16; babble_cnt <= n_bab; dup_cnt <= n_dup;
    nak_cnt <= n_nak; stall_cnt <= n_stall; nyet_cnt <= n_nyet; sof_cnt <= n_sof; sof_miss <= n_miss;
    resets <= n_rst; tmo_cnt <= n_tmo; split_cnt <= n_split;
  end

endmodule
