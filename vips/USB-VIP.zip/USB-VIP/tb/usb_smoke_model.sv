// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Smoke-target minimal behavioral model: unified USB (USB 2.0) device
// endpoint FSM using MAC-layer signal naming. Decodes token PIDs
// (OUT/IN/SETUP/SOF) by USB PID class bits, tracks the DATA0/DATA1 toggle,
// and drives ACK/NAK/STALL handshake status outputs. Plain ANSI ports only
// (no interfaces) so the L1b smoke harness can build it with iverilog.

module usb_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        mac_valid,       // mac_pid carries a fresh PID
  input  logic [7:0]  mac_pid,         // received PID byte (class in [1:0])
  input  logic [6:0]  mac_addr,        // token device address
  input  logic [3:0]  mac_endpoint,    // token endpoint number
  input  logic [31:0] mac_data,        // payload (byte 0 used by model)
  input  logic        mac_crc_ok,      // CRC check passed for data packet
  input  logic        promiscuous,     // test mode: accept any address
  output logic        mac_ready,       // MAC ready (registered mac_valid)
  output logic [1:0]  hs_resp,         // 00=none 01=ACK 10=NAK 11=STALL
  output logic        data_toggle,     // expected DATA0/DATA1 toggle bit
  output logic [3:0]  dev_state,       // 0=DEFAULT 1=ADDRESS 2=CONFIGURED
  output logic [6:0]  dev_addr,        // currently assigned device address
  output logic [10:0] frame_num,       // last SOF frame number
  output logic [7:0]  tx_data,         // IN endpoint payload byte
  output logic        tx_valid,        // IN endpoint has data for host
  output logic [7:0]  nak_count        // NAK/timeout counter
);

  // USB PID classes (PID[1:0]) and subtypes (PID[3:2])
  localparam logic [1:0] PID_CLS_TOKEN = 2'b01;   // OUT/IN/SOF/SETUP
  localparam logic [1:0] PID_CLS_HS    = 2'b10;   // ACK/NAK/STALL/NYET
  localparam logic [1:0] PID_CLS_DATA  = 2'b11;   // DATA0/1/2/MDATA
  localparam logic [1:0] TOK_OUT       = 2'b00;
  localparam logic [1:0] TOK_SOF       = 2'b01;
  localparam logic [1:0] TOK_IN        = 2'b10;
  localparam logic [1:0] TOK_SETUP     = 2'b11;
  localparam logic [1:0] HS_SUB_ACK    = 2'b00;

  localparam logic [1:0] RESP_NONE  = 2'b00;
  localparam logic [1:0] RESP_ACK   = 2'b01;
  localparam logic [1:0] RESP_NAK   = 2'b10;
  localparam logic [1:0] RESP_STALL = 2'b11;

  localparam logic [3:0] DEV_DEFAULT     = 4'd0;
  localparam logic [3:0] DEV_ADDRESS     = 4'd1;
  localparam logic [3:0] DEV_CONFIGURED  = 4'd2;

  localparam logic [1:0] ST_IDLE   = 2'd0;
  localparam logic [1:0] ST_RXDATA = 2'd1;
  localparam logic [1:0] ST_IN     = 2'd2;

  logic [1:0] state;
  logic [3:0] tmo;
  logic [3:0] cur_endp;
  logic       setup_pending;

  wire addressed = promiscuous || (mac_addr == dev_addr) ||
                   ((mac_addr == 7'h00) && (dev_addr == 7'h00));
  wire pid_is_token = mac_valid && (mac_pid[1:0] == PID_CLS_TOKEN);
  wire pid_is_data  = mac_valid && (mac_pid[1:0] == PID_CLS_DATA);
  wire pid_is_hs    = mac_valid && (mac_pid[1:0] == PID_CLS_HS);
  // DATA0 subtype is 00, DATA1 subtype is 10 -> expected subtype from toggle
  wire toggle_match = (mac_pid[3:2] == {data_toggle, 1'b0});

  always @(posedge clk) begin
    if (!rst_n) begin
      state         <= ST_IDLE;
      tmo           <= 4'd0;
      cur_endp      <= 4'd0;
      setup_pending <= 1'b0;
      mac_ready     <= 1'b0;
      hs_resp       <= RESP_NONE;
      data_toggle   <= 1'b0;
      dev_state     <= DEV_DEFAULT;
      dev_addr      <= 7'h00;
      frame_num     <= 11'd0;
      tx_data       <= 8'd0;
      tx_valid      <= 1'b0;
      nak_count     <= 8'd0;
    end else begin
      mac_ready <= mac_valid;   // 1-cycle MAC turnaround
      case (state)
        ST_IDLE: begin
          tx_valid <= 1'b0;
          tmo      <= 4'd0;
          if (pid_is_token && addressed) begin
            cur_endp <= mac_endpoint;
            case (mac_pid[3:2])
              TOK_OUT: begin
                state         <= ST_RXDATA;
                hs_resp       <= RESP_NONE;
                setup_pending <= 1'b0;
              end
              TOK_SETUP: begin
                state         <= ST_RXDATA;
                hs_resp       <= RESP_NONE;
                data_toggle   <= 1'b0;   // SETUP resets data toggle
                setup_pending <= 1'b1;
              end
              TOK_IN: begin
                state    <= ST_IN;
                tx_valid <= 1'b1;
                tx_data  <= tx_data + 8'd1;
                hs_resp  <= RESP_NONE;
              end
              TOK_SOF: begin
                frame_num <= {mac_data[7:0], mac_endpoint[2:0]};
                hs_resp   <= RESP_NONE;   // SOF: no handshake
              end
              default: hs_resp <= RESP_NONE;
            endcase
          end
        end

        ST_RXDATA: begin
          if (pid_is_data) begin
            state <= ST_IDLE;
            tmo   <= 4'd0;
            if (cur_endp == 4'hF) begin
              hs_resp <= RESP_STALL;              // unimplemented endpoint
            end else if (!mac_crc_ok) begin
              hs_resp   <= RESP_NAK;              // bad CRC: retry, no toggle
              nak_count <= nak_count + 8'd1;
            end else if (toggle_match) begin
              hs_resp     <= RESP_ACK;
              data_toggle <= ~data_toggle;        // accept: flip toggle
              if (setup_pending) begin
                setup_pending <= 1'b0;
                dev_addr      <= mac_data[6:0];   // simplified SET_ADDRESS
                dev_state     <= (dev_state == DEV_DEFAULT) ? DEV_ADDRESS
                                                            : DEV_CONFIGURED;
              end
            end else begin
              hs_resp <= RESP_ACK;                // dup data: ACK, keep toggle
            end
          end else if (pid_is_token) begin
            state   <= ST_IDLE;                   // new token aborts data wait
            hs_resp <= RESP_NONE;
          end else begin
            tmo <= tmo + 4'd1;
            if (tmo == 4'hF) begin
              state     <= ST_IDLE;               // data-stage timeout
              hs_resp   <= RESP_NAK;
              nak_count <= nak_count + 8'd1;
            end
          end
        end

        ST_IN: begin
          if (pid_is_hs) begin
            state    <= ST_IDLE;
            tx_valid <= 1'b0;
            tmo      <= 4'd0;
            if (mac_pid[3:2] == HS_SUB_ACK)
              data_toggle <= ~data_toggle;        // host consumed the data
          end else begin
            tmo <= tmo + 4'd1;
            if (tmo == 4'hF) begin
              state    <= ST_IDLE;                // host handshake timeout
              tx_valid <= 1'b0;
            end
          end
        end

        default: state <= ST_IDLE;
      endcase
    end
  end

endmodule
