// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB4 router lane adapter + transport layer (device side), one item per
// clock: an ordered set on one lane, or one 32-bit word of a transport
// packet. Plain ANSI ports so the L1b smoke harness and tb/smoke_func_tb.sv
// build it directly.
//
// Logical layer, per lane (USB4 ch. 4, timers scaled):
//   CLd -(lane_det)-> Lock: 2 SLOS -> Training.TS1: 2 TS1 -> Training.TS2:
//   2 TS2 -> CL0. Each step answers with one ordered set of the same kind
//   on that lane (tx_os). A TS1 carries the far end's Gen 3 bit; Gen 3 (and
//   RS-FEC) when both ends support it, else Gen 2. 64 clocks without
//   progress in Lock / TS1 / TS2 -> CLd (train_tmo). CLD on a lane or
//   lane_det low -> CLd. CL_REQ on lane 0 in CL0 with CLx enabled, no
//   packet in the output queue and no buffer held -> CL_ACK and every CL0
//   lane enters CLx; else CL_NAK. WAKE on a lane in CLx -> Training.TS2.
//   Lane bonding: with bond_en, both lanes in CL0 -> width 2; a bonded
//   lane leaving CL0 -> width 1, and every width change after bonding is
//   enabled sends a Notification (code 7).
// RS-FEC (Gen 3): each received word carries the symbol errors of its
//   codeword; up to 2 are corrected (fec_corr), more make the packet
//   uncorrectable (fec_unc). Gen 2 has no FEC: any symbol error poisons
//   the packet. 4 uncorrectable packets since the last CL0 entry -> both
//   lanes retrain from Lock (retrains).
// Transport layer (ch. 6 / 7, simplified):
//   header {PDF[31:28], SuppID[27], HopID[26:16], Length[15:8] bytes,
//   HEC[7:0] = CRC-8 (07) of bits 31:8}, then Length/4 payload words.
//   Bad HEC -> dropped (hec_err); payload count != Length -> len_err.
//   HopID 0 = control path: payload {route, {seq[31:30], cnt[21:16],
//   addr[15:0]}, data..., CRC-32}; route != 0 or a bad CRC -> dropped
//   (crc_err for the CRC). Read (PDF 1) / Write (PDF 3) of 1..8 dwords in a
//   64-dword config space -> Read / Write Response (PDF 2 / 4) echoing the
//   header word; out of range -> Notification ERR_ADDR (2); a Write whose
//   length does not match cnt -> ERR_LEN (3); other PDFs -> ERR_UNSUP (4).
//   A request with the previous sequence number and PDF is a
//   retransmission: the stored response is sent again, nothing executes.
//   A Notification Ack (PDF 6) is taken without an answer.
//   Config space: 0 router ID (RO), 1 {clx_en, bond_en}, 2 status (RO),
//   8..11 path entries {valid[31], out_hop[26:16], in_hop[10:0]}.
//   Writing a path entry resets its 4 buffers and sends a Credit Grant
//   (PDF C, HopID = in_hop, one word: cumulative credits). A packet on an
//   enabled in_hop is forwarded with out_hop and a new HEC, holding a
//   buffer for 6 clocks (more while out_busy); its release sends the next
//   Credit Grant. No free buffer -> dropped (ovf_err); unknown HopID ->
//   dropped (unk_hop). Packets outside CL0 are not received.
//   Output: one word per clock from a 128-word queue, only while lane 0
//   is in CL0; lane 0 leaving CL0 empties the queue (no half packets).

module usb4_smoke_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [1:0]  lane_det,
  input  logic        gen3_cap,
  input  logic        os_valid,
  input  logic        os_lane,
  input  logic [2:0]  os_kind,       // 0 SLOS 1 TS1 2 TS2 3 CL_REQ 4 CLD 5 WAKE
  input  logic        os_gen3,
  input  logic        w_valid,
  input  logic        w_first,
  input  logic        w_last,
  input  logic [31:0] w_data,
  input  logic [2:0]  w_sym_err,
  input  logic        out_busy,
  output logic [2:0]  ls0,           // 0 CLd 1 Lock 2 TS1 3 TS2 4 CL0 5 CLx
  output logic [2:0]  ls1,
  output logic        gen3,
  output logic [1:0]  width,
  output logic        tx_os_valid,
  output logic        tx_os_lane,
  output logic [2:0]  tx_os_kind,    // 0 SLOS 1 TS1 2 TS2 6 CL_ACK 7 CL_NAK
  output logic        tx_valid,
  output logic        tx_first,
  output logic        tx_last,
  output logic [31:0] tx_data,
  output logic [7:0]  hec_err,
  output logic [7:0]  len_err,
  output logic [7:0]  crc_err,
  output logic [7:0]  ovf_err,
  output logic [7:0]  unk_hop,
  output logic [7:0]  fec_corr,
  output logic [7:0]  fec_unc,
  output logic [7:0]  fwd_cnt,
  output logic [7:0]  dup_cnt,
  output logic [7:0]  notif_cnt,
  output logic [7:0]  train_tmo,
  output logic [7:0]  retrains
);
  // working copies (blocking inside the clock), registered onto the outputs
  logic [7:0]  n_hec, n_len, n_crc, n_ovf, n_unk, n_corr, n_unc, n_fwd, n_dup, n_notif, n_tmo, n_rtr;

  localparam logic [2:0] L_CLD = 3'd0, L_LOCK = 3'd1, L_TS1 = 3'd2, L_TS2 = 3'd3, L_CL0 = 3'd4, L_CLX = 3'd5;
  localparam logic [2:0] O_SLOS = 3'd0, O_TS1 = 3'd1, O_TS2 = 3'd2, O_CLREQ = 3'd3, O_CLD = 3'd4, O_WAKE = 3'd5,
                         O_ACK = 3'd6, O_NAK = 3'd7;
  localparam logic [3:0] PDF_RD = 4'd1, PDF_RDR = 4'd2, PDF_WR = 4'd3, PDF_WRR = 4'd4, PDF_NOTIF = 4'd5,
                         PDF_NACK = 4'd6, PDF_CG = 4'hC;
  localparam int T_TRAIN = 64, T_FWD = 6;

  function automatic logic [7:0] hec8(input logic [23:0] d);
    logic [7:0] c;
    c = 8'h00;
    for (int i = 23; i >= 0; i--) c = (c[7] ^ d[i]) ? ({c[6:0], 1'b0} ^ 8'h07) : {c[6:0], 1'b0};
    return c;
  endfunction
  function automatic logic [31:0] crc32w(input logic [31:0] c0, input logic [31:0] w);
    logic [31:0] c;
    c = c0;
    for (int i = 31; i >= 0; i--) c = (c[31] ^ w[i]) ? ({c[30:0], 1'b0} ^ 32'h04C1_1DB7) : {c[30:0], 1'b0};
    return c;
  endfunction
  function automatic logic [31:0] mkhdr(input logic [3:0] pdf, input logic [10:0] hop, input int nw);
    logic [23:0] u;
    u = {pdf, 1'b0, hop, 8'(4 * nw)};
    return {u, hec8(u)};
  endfunction

  // ------------------------------------------------------------ state
  logic [2:0]  ls [2];
  logic [1:0]  cnt [2];
  logic [6:0]  tmr [2];
  logic        g3;
  logic        bond_en, clx_en, bonded_q;
  logic [2:0]  unc_since;
  logic [31:0] cfg [64];
  // receive packet buffer
  logic        in_pkt, poison, rx_bad_hec;
  logic [31:0] rh;
  logic [31:0] pw [18];
  int          pn;
  // paths
  logic [2:0]  used [4];
  logic [7:0]  cg_tot [4];
  // buffer releases in order: ring of 16 {valid, clock, path}
  logic        rel_v [16];
  int          rel_t [16];
  int          rel_p [16];
  int          rel_wr, rel_rd, rel_n;
  int          now;
  // control retransmission
  logic        last_v;
  logic [1:0]  last_seq;
  logic [3:0]  last_pdf;
  logic [31:0] last_rsp [12];
  int          last_n;
  // output queue
  logic [33:0] oq [128];         // {first, last, data}
  int          oq_wr, oq_rd, oq_n;

  logic link_up;
  function automatic bit both_cl0(); return bond_en && ls[0] == L_CL0 && ls[1] == L_CL0; endfunction

  function automatic bit held();
    for (int k = 0; k < 16; k++) if (rel_v[k]) return 1'b1;
    return 1'b0;
  endfunction
  task automatic push(input logic f, input logic l, input logic [31:0] d);
    if (oq_n < 128) begin
      oq[oq_wr] = {f, l, d};
      oq_wr = (oq_wr + 1) % 128;
      oq_n = oq_n + 1;
    end
  endtask
  task automatic send_ctrl(input logic [3:0] pdf, input logic [31:0] w1, input int nd, input bit store);
    logic [31:0] c, b [12];
    int n;
    b[0] = 32'h0; b[1] = w1; n = 2;
    for (int i = 0; i < 8; i++) if (i < nd) begin b[n] = cfg[(int'(w1[15:0]) + i) % 64]; n++; end
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < 12; i++) if (i < n) c = crc32w(c, b[i]);
    b[n] = ~c; n++;
    push(1'b1, 1'b0, mkhdr(pdf, 11'd0, n));
    for (int i = 0; i < 12; i++) if (i < n) push(1'b0, i == n - 1, b[i]);
    if (store) begin
      last_n = n + 1;
      last_rsp[0] = mkhdr(pdf, 11'd0, n);
      for (int i = 0; i < 11; i++) if (i < n) last_rsp[i + 1] = b[i];
    end
  endtask
  task automatic notify(input logic [7:0] code);
    logic [31:0] c, w1;
    w1 = {code, 24'h0};
    c = crc32w(crc32w(32'hFFFF_FFFF, 32'h0), w1);
    push(1'b1, 1'b0, mkhdr(PDF_NOTIF, 11'd0, 3));
    push(1'b0, 1'b0, 32'h0);
    push(1'b0, 1'b0, w1);
    push(1'b0, 1'b1, ~c);
    n_notif = n_notif + 8'd1;
  endtask
  task automatic credit_grant(input int p);
    push(1'b1, 1'b0, mkhdr(PDF_CG, cfg[8 + p][10:0], 1));
    push(1'b0, 1'b1, {24'h0, cg_tot[p]});
  endtask

  // a complete, good control packet (pw[0..pn-1], CRC checked)
  task automatic control();
    logic [3:0]  pdf;
    logic [31:0] w1;
    int a, n;
    pdf = rh[31:28];
    w1  = pw[1];
    a   = int'(w1[15:0]);
    n   = int'(w1[21:16]);
    if (pdf == PDF_NACK) return;                         // Notification Ack: nothing to answer
    if ((pdf == PDF_RD || pdf == PDF_WR) && last_v && w1[31:30] == last_seq && pdf == last_pdf) begin
      n_dup = n_dup + 8'd1;
      push(1'b1, 1'b0, last_rsp[0]);
      for (int i = 1; i < 12; i++) if (i < last_n) push(1'b0, i == last_n - 1, last_rsp[i]);
      return;
    end
    if (pdf != PDF_RD && pdf != PDF_WR) begin notify(8'd4); return; end
    if (n < 1 || n > 8 || a + n > 64) begin notify(8'd2); return; end
    if (pn != ((pdf == PDF_WR) ? 3 + n : 3)) begin notify(8'd3); return; end
    if (pdf == PDF_WR) begin
      for (int i = 0; i < 8; i++)
        if (i < n) begin
          if (a + i == 1) begin cfg[1] = {30'h0, pw[2 + i][1:0]}; bond_en = pw[2 + i][0]; clx_en = pw[2 + i][1]; end
          else if (a + i >= 8 && a + i < 12) begin
            cfg[a + i] = pw[2 + i] & 32'h87FF_07FF;
            used[a + i - 8] = 3'd0;
            cg_tot[a + i - 8] = 8'd4;
            for (int k = 0; k < 16; k++) if (rel_p[k] == a + i - 8) rel_v[k] = 1'b0;
            if (pw[2 + i][31]) credit_grant(a + i - 8);
          end
          else if (a + i != 0 && a + i != 2) cfg[a + i] = pw[2 + i];
        end
      send_ctrl(PDF_WRR, w1, 0, 1'b1);
    end
    else send_ctrl(PDF_RDR, w1, n, 1'b1);
    last_v = 1'b1; last_seq = w1[31:30]; last_pdf = pdf;
  endtask

  // a complete, good packet
  task automatic packet();
    logic [10:0] hop;
    logic [31:0] c;
    int p;
    hop = rh[26:16];
    if (pn != int'(rh[15:8]) / 4 || rh[9:8] != 2'b00) begin n_len = n_len + 8'd1; return; end
    if (hop == 11'd0) begin
      c = 32'hFFFF_FFFF;
      for (int i = 0; i < 17; i++) if (i < pn - 1) c = crc32w(c, pw[i]);
      if (pn < 3 || ~c != pw[pn - 1]) begin n_crc = n_crc + 8'd1; return; end
      if (pw[0] != 32'h0) return;                       // another router's
      control();
      return;
    end
    p = -1;
    for (int i = 3; i >= 0; i--) if (cfg[8 + i][31] && cfg[8 + i][10:0] == hop) p = i;
    if (p < 0) begin n_unk = n_unk + 8'd1; return; end
    if (used[p] == 3'd4) begin n_ovf = n_ovf + 8'd1; return; end
    used[p] = used[p] + 3'd1;
    rel_v[rel_wr] = 1'b1; rel_t[rel_wr] = now + T_FWD; rel_p[rel_wr] = p;
    rel_wr = (rel_wr + 1) % 16; rel_n = rel_n + 1;
    n_fwd = n_fwd + 8'd1;
    push(1'b1, pn == 0, mkhdr(rh[31:28], cfg[8 + p][26:16], pn));
    for (int i = 0; i < 16; i++) if (i < pn) push(1'b0, i == pn - 1, pw[i]);
  endtask

  task automatic lane_train(input int l);
    if (ls[l] == L_LOCK || ls[l] == L_TS1 || ls[l] == L_TS2) begin
      if (tmr[l] == 7'(T_TRAIN - 1)) begin ls[l] = L_CLD; n_tmo = n_tmo + 8'd1; end
      else tmr[l] = tmr[l] + 7'd1;
    end
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      for (int l = 0; l < 2; l++) begin ls[l] = L_CLD; cnt[l] = 2'd0; tmr[l] = 7'd0; end
      link_up = 1'b0; g3 = 1'b0; bond_en = 1'b0; clx_en = 1'b0; bonded_q = 1'b0; unc_since = 3'd0;
      for (int i = 0; i < 64; i++) cfg[i] = 32'h0;
      cfg[0] = 32'h0004_AB1D;
      in_pkt = 1'b0; poison = 1'b0; rx_bad_hec = 1'b0; rh = 32'h0; pn = 0;
      for (int i = 0; i < 4; i++) begin used[i] = 3'd0; cg_tot[i] = 8'd0; end
      for (int k = 0; k < 16; k++) begin rel_v[k] = 1'b0; rel_t[k] = 0; rel_p[k] = 0; end
      rel_wr = 0; rel_rd = 0; rel_n = 0; now = 0;
      last_v = 1'b0; last_seq = 2'd0; last_pdf = 4'd0; last_n = 0;
      oq_wr = 0; oq_rd = 0; oq_n = 0;
      n_hec = 8'd0; n_len = 8'd0; n_crc = 8'd0; n_ovf = 8'd0; n_unk = 8'd0; n_corr = 8'd0;
      n_unc = 8'd0; n_fwd = 8'd0; n_dup = 8'd0; n_notif = 8'd0; n_tmo = 8'd0; n_rtr = 8'd0;
      hec_err <= 8'd0; len_err <= 8'd0; crc_err <= 8'd0; ovf_err <= 8'd0; unk_hop <= 8'd0; fec_corr <= 8'd0;
      fec_unc <= 8'd0; fwd_cnt <= 8'd0; dup_cnt <= 8'd0; notif_cnt <= 8'd0; train_tmo <= 8'd0; retrains <= 8'd0;
      ls0 <= L_CLD; ls1 <= L_CLD; gen3 <= 1'b0; width <= 2'd1;
      tx_os_valid <= 1'b0; tx_os_lane <= 1'b0; tx_os_kind <= 3'd0;
      tx_valid <= 1'b0; tx_first <= 1'b0; tx_last <= 1'b0; tx_data <= 32'h0;
    end
    else begin
      now = now + 1;
      tx_os_valid <= 1'b0;
      // ---- logical layer
      for (int l = 0; l < 2; l++) begin
        if (!lane_det[l]) ls[l] = L_CLD;
        else if (ls[l] == L_CLD) begin ls[l] = L_LOCK; cnt[l] = 2'd0; tmr[l] = 7'd0; end
        else lane_train(l);
      end
      if (os_valid && lane_det[os_lane]) begin
        int l;
        l = int'(os_lane);
        if (os_kind == O_CLD) ls[l] = L_CLD;
        else case (ls[l])
          L_LOCK: if (os_kind == O_SLOS) begin
                    tmr[l] = 7'd0;
                    if (cnt[l] == 2'd1) begin ls[l] = L_TS1; cnt[l] = 2'd0;
                      tx_os_valid <= 1'b1; tx_os_lane <= os_lane; tx_os_kind <= O_SLOS; end
                    else cnt[l] = 2'd1;
                  end
                  else cnt[l] = 2'd0;
          L_TS1:  if (os_kind == O_TS1) begin
                    tmr[l] = 7'd0;
                    if (cnt[l] == 2'd1) begin ls[l] = L_TS2; cnt[l] = 2'd0;
                      if (l == 0) g3 = os_gen3 && gen3_cap;
                      tx_os_valid <= 1'b1; tx_os_lane <= os_lane; tx_os_kind <= O_TS1; end
                    else cnt[l] = 2'd1;
                  end
                  else if (os_kind != O_SLOS) cnt[l] = 2'd0;
          L_TS2:  if (os_kind == O_TS2) begin
                    tmr[l] = 7'd0;
                    if (cnt[l] == 2'd1) begin ls[l] = L_CL0; cnt[l] = 2'd0; unc_since = 3'd0;
                      tx_os_valid <= 1'b1; tx_os_lane <= os_lane; tx_os_kind <= O_TS2; end
                    else cnt[l] = 2'd1;
                  end
                  else if (os_kind != O_TS1) cnt[l] = 2'd0;
          L_CL0:  if (os_kind == O_CLREQ && l == 0) begin
                    tx_os_valid <= 1'b1; tx_os_lane <= 1'b0;
                    if (clx_en && oq_n == 0 && !held() && !in_pkt) begin
                      tx_os_kind <= O_ACK;
                      for (int k = 0; k < 2; k++) if (ls[k] == L_CL0) ls[k] = L_CLX;
                    end
                    else tx_os_kind <= O_NAK;
                  end
          L_CLX:  if (os_kind == O_WAKE) begin ls[l] = L_TS2; cnt[l] = 2'd0; tmr[l] = 7'd0; end
          default: ;
        endcase
      end
      link_up = ls[0] == L_CL0;
      if (!link_up) in_pkt = 1'b0;

      // ---- transport layer: receive
      if (w_valid && link_up && !os_valid) begin
        logic bad_w;
        bad_w = g3 ? (w_sym_err > 3'd2) : (w_sym_err != 3'd0);
        if (g3 && w_sym_err != 3'd0 && w_sym_err <= 3'd2) n_corr = n_corr + 8'd1;
        if (w_first) begin
          in_pkt = 1'b1; poison = bad_w; rh = w_data; pn = 0;
          rx_bad_hec = w_data[7:0] != hec8(w_data[31:8]);
        end
        else if (in_pkt) begin
          poison = poison | bad_w;
          if (pn < 18) pw[pn] = w_data;
          pn = pn + 1;
        end
        if (in_pkt && w_last) begin
          in_pkt = 1'b0;
          if (poison) begin
            n_unc = n_unc + 8'd1;
            if (unc_since == 3'd3) begin
              for (int k = 0; k < 2; k++) if (ls[k] == L_CL0) begin ls[k] = L_LOCK; cnt[k] = 2'd0; tmr[k] = 7'd0; end
              n_rtr = n_rtr + 8'd1; unc_since = 3'd0;
            end
            else unc_since = unc_since + 3'd1;
          end
          else if (rx_bad_hec) n_hec = n_hec + 8'd1;
          else if (pn > 17) n_len = n_len + 8'd1;
          else packet();
        end
      end

      // ---- buffer release -> Credit Grant
      while (rel_n != 0 && !rel_v[rel_rd]) begin rel_rd = (rel_rd + 1) % 16; rel_n = rel_n - 1; end
      if (rel_n != 0 && rel_t[rel_rd] <= now && !out_busy) begin
        int p;
        p = rel_p[rel_rd];
        rel_v[rel_rd] = 1'b0; rel_rd = (rel_rd + 1) % 16; rel_n = rel_n - 1;
        used[p] = used[p] - 3'd1;
        cg_tot[p] = cg_tot[p] + 8'd1;
        credit_grant(p);
      end
      // ---- lane bonding
      link_up = ls[0] == L_CL0;
      if (bond_en && link_up && both_cl0() != bonded_q) notify(8'd7);
      bonded_q = both_cl0();
      cfg[2] = {24'h0, g3, both_cl0(), ls[1], ls[0]};

      // ---- output
      if (link_up && oq_n != 0) begin
        tx_valid <= 1'b1;
        tx_first <= oq[oq_rd][33];
        tx_last  <= oq[oq_rd][32];
        tx_data  <= oq[oq_rd][31:0];
        oq_rd = (oq_rd + 1) % 128;
        oq_n  = oq_n - 1;
      end
      else tx_valid <= 1'b0;
      if (ls[0] != L_CL0) begin oq_n = 0; oq_rd = oq_wr; end    // link down / retrain: queued packets lost
      ls0 <= ls[0]; ls1 <= ls[1]; gen3 <= g3; width <= (bond_en && ls[0] == L_CL0 && ls[1] == L_CL0) ? 2'd2 : 2'd1;
      hec_err <= n_hec; len_err <= n_len; crc_err <= n_crc; ovf_err <= n_ovf; unk_hop <= n_unk; fec_corr <= n_corr;
      fec_unc <= n_unc; fwd_cnt <= n_fwd; dup_cnt <= n_dup; notif_cnt <= n_notif; train_tmo <= n_tmo; retrains <= n_rtr;
    end
  end

endmodule
