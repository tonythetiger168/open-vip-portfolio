// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
//============================================================================
// USB Top-Level Testbench
// 7-protocol interface instantiation + functional DUT model:
//   - USB 2.0/eUSB2 device endpoint (chirp response, CRC16 check, ACK/STALL)
//   - USB 3.x PIPE PHY loopback (LTSSM walk, CRC32 check)
//   - USB4 PIPE4 PHY loopback (router sideband, CRC32 check)
//   - USB-PD controller (contract negotiation, Vbus transition)
// forming a driver -> DUT -> monitor closed loop.
//============================================================================
`ifndef TOP_TB_SV
`define TOP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module top_tb;
  logic clk = 0;
  logic rst_n;
  always #2ns clk = ~clk;

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  // All interfaces use the default parameterization so that a single
  // 'virtual usb_vip_if' type can be passed through uvm_config_db.
  usb_vip_if usb2_if(clk, rst_n);
  usb_vip_if usb3_if(clk, rst_n);
  usb_vip_if usb3p_if(clk, rst_n);
  usb_vip_if usb32_if(clk, rst_n);
  usb_vip_if usb4_if(clk, rst_n);
  usb_vip_if eusb2_if(clk, rst_n);
  usb_vip_if usbpd_if(clk, rst_n);

  usb_dut dut (.clk(clk), .rst_n(rst_n),
    .usb2_if(usb2_if), .usb3_if(usb3_if), .usb3p_if(usb3p_if),
    .usb32_if(usb32_if), .usb4_if(usb4_if), .eusb2_if(eusb2_if),
    .usbpd_if(usbpd_if));

  // Tiered compliance SVA checker on the USB 2.0 MAC/PHY interface
  usb_compliance_checker u_compliance (.vif(usb2_if));

  initial begin
    uvm_config_db#(virtual usb_vip_if)::set(null, "*", "usb2_vif",  usb2_if);
    uvm_config_db#(virtual usb_vip_if)::set(null, "*", "usb3_vif",  usb3_if);
    uvm_config_db#(virtual usb_vip_if)::set(null, "*", "usb3p_vif", usb3p_if);
    uvm_config_db#(virtual usb_vip_if)::set(null, "*", "usb32_vif", usb32_if);
    uvm_config_db#(virtual usb_vip_if)::set(null, "*", "usb4_vif",  usb4_if);
    uvm_config_db#(virtual usb_vip_if)::set(null, "*", "eusb2_vif", eusb2_if);
    uvm_config_db#(virtual usb_vip_if)::set(null, "*", "usbpd_vif", usbpd_if);
    run_test();
  end
endmodule

//============================================================================
// Default tie-off for every DUT-driven signal (single driver per interface;
// behavioral blocks override the signals they manage).
//============================================================================
`define USB_VIP_TIEOFF(V) \
  initial begin \
    V.mac_ready = 1'b0; V.mac_crc_ok = 1'b1; \
    V.utmi_txready = 1'b1; V.utmi_rxvalid = 1'b0; V.utmi_rxactive = 1'b0; \
    V.utmi_rxerror = 1'b0; V.utmi_linestate = 2'b01; \
    V.pipe_rx_data = 32'h0; V.pipe_rx_datak = 4'h0; V.pipe_rx_valid = 1'b0; \
    V.pipe_rx_status = 1'b0; V.pipe_rx_elecidle = 1'b1; V.pipe_phy_status = 1'b0; \
    V.pipe_phy_ready = 1'b0; V.pipe_power_state = 2'b11; \
    V.pipe4_rx_data = 128'h0; V.pipe4_rx_datak = 16'h0; \
    V.pipe4_rx_blk_start = 1'b0; V.pipe4_rx_sync_hdr = 4'h0; \
    V.pipe4_rx_valid = 1'b0; V.pipe4_rx_status = 1'b0; V.pipe4_link_ready = 1'b0; \
    V.pd_vbus_voltage = 11'd200; \
    V.crc5_error = 1'b0; V.crc16_error = 1'b0; V.crc32_error = 1'b0; \
    V.timeout_error = 1'b0; V.babble_error = 1'b0; V.bit_stuff_error = 1'b0; \
    V.disconnect_error = 1'b0; \
    V.link_up = 1'b0; V.ltssm_state = 4'b0001; V.lfps_detect = 1'b0; \
    V.training = 1'b0; V.ts1_valid = 1'b0; V.ts2_valid = 1'b0; \
    V.training_done = 1'b0; V.hot_reset = 1'b0; V.hs_chirp = 1'b0; \
    V.resume = 1'b0; V.repeater_mode = 1'b0; V.bandwidth = 32'hFFFF_FFFF; \
    V.bw_alloc = 8'd100; V.path_id = 8'h0; V.domain_id = 4'h0; \
    V.cl_state = 3'b000; V.pm_state = 3'b000; V.drd = 1'b0; V.err_inject = 1'b0; \
    V.router_config = 1'b0; V.sbtx_valid = 1'b0; V.sbrx_valid = 1'b0; \
    V.sbtx_data = 8'h0; V.tunnel_dp = 1'b0; V.tunnel_pcie = 1'b0; \
    V.tunnel_usb3 = 1'b0; \
    V.ams_start = 1'b0; V.ams_end = 1'b0; V.pd_bist = 1'b0; V.pd_crc_ok = 1'b1; \
    V.pd_eop = 1'b0; V.pd_hard_reset = 1'b0; V.pd_power_contract = 1'b0; \
    V.pd_sop = 1'b0; V.pps_en = 1'b0; V.pd_message_id = 3'h0; \
  end

//============================================================================
// DUT: functional multi-protocol USB device model
//============================================================================
module usb_dut (
  input logic clk, input logic rst_n,
  usb_vip_if.monitor_mp usb2_if,  usb_vip_if.monitor_mp usb3_if,
  usb_vip_if.monitor_mp usb3p_if, usb_vip_if.monitor_mp usb32_if,
  usb_vip_if.monitor_mp usb4_if,  usb_vip_if.monitor_mp eusb2_if,
  usb_vip_if.monitor_mp usbpd_if
);
  usb2_dev_ep     #(.DEV_ADDR(7'h20)) u_usb2_ep  (.vif(usb2_if));
  usb2_dev_ep     #(.DEV_ADDR(7'h20)) u_eusb2_ep (.vif(eusb2_if));
  usb3_phy_model                     u_usb3_phy (.vif(usb3_if));
  usb3_phy_model                     u_usb3p_phy(.vif(usb3p_if));
  usb3_phy_model                     u_usb32_phy(.vif(usb32_if));
  usb4_phy_model                     u_usb4_phy (.vif(usb4_if));
  pd_controller_model                u_pd_ctrl  (.vif(usbpd_if));
endmodule

//============================================================================
// USB 2.0 / eUSB2 device endpoint model
// - ACKs tokens/data addressed to DEV_ADDR (or default address 0)
// - STALLs unimplemented endpoint 15
// - CRC16 check on DATA packets (corrupt CRC -> no ACK + crc16_error)
// - Babble detect (>64 beats without EOP)
// - HS chirp K/J response; SE0 during bus reset
//============================================================================
module usb2_dev_ep #(parameter bit [6:0] DEV_ADDR = 7'h20)
  (usb_vip_if.monitor_mp vif);

  localparam bit [7:0] PID_ACK   = 8'hD2;
  localparam bit [7:0] PID_STALL = 8'h1E;
  localparam bit [7:0] PID_SOF   = 8'hA5;

  `USB_VIP_TIEOFF(vif)

  bit [7:0] pkt[$];
  int       beats;
  bit       in_pkt;
  bit [7:0] cur_pid;
  bit [6:0] cur_addr;
  bit [3:0] cur_ep;
  int       total_bytes;

  // MAC ready: registered valid (1-cycle turnaround)
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      vif.mac_ready  <= 1'b0;
      vif.mac_crc_ok <= 1'b1;
    end else begin
      vif.mac_ready  <= #1ns vif.mac_valid;
      vif.mac_crc_ok <= #1ns !vif.crc16_error;
    end
  end

  // UTMI linestate: SE0 during bus reset, chirp K/J response, else idle J
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      vif.utmi_linestate <= 2'b01;
      vif.hs_chirp       <= 1'b0;
    end else if (vif.dev_reset) begin
      vif.utmi_linestate <= 2'b00;              // SE0 reset signaling
      vif.hs_chirp       <= 1'b0;
    end else if (vif.utmi_xcvr_select == 2'b01 && vif.utmi_op_mode == 2'b10 &&
                 vif.utmi_term_select) begin
      // Chirp response: alternate K / J while host chirps
      vif.utmi_linestate <= (vif.utmi_linestate == 2'b10) ? 2'b01 : 2'b10;
      vif.hs_chirp       <= 1'b1;
    end else begin
      vif.utmi_linestate <= 2'b01;              // idle J
      vif.hs_chirp       <= 1'b0;
    end
  end

  // Handshake responder
  task automatic respond(bit [7:0] r);
    repeat (2) @(posedge vif.clk);
    vif.utmi_rxactive = 1'b1;
    vif.utmi_rxvalid  = 1'b1;
    vif.utmi_data     = r;
    // Hold response across the host inter-packet gap
    fork
      begin repeat (20) @(posedge vif.clk); end
      begin wait (vif.mac_valid && vif.mac_sop); end
    join_any
    disable fork;
    vif.utmi_rxactive = 1'b0;
    vif.utmi_rxvalid  = 1'b0;
  endtask

  // Packet capture / processing
  initial begin
    in_pkt = 0; beats = 0; total_bytes = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n || vif.dev_reset) begin
        in_pkt = 0; beats = 0;
        vif.crc16_error  = 1'b0;
        vif.crc5_error   = 1'b0;
        vif.babble_error = 1'b0;
      end else if (vif.mac_valid && vif.mac_sop && !in_pkt) begin
        in_pkt      = 1;
        beats       = 0;
        pkt.delete();
        cur_pid     = vif.mac_pid;
        cur_addr    = vif.mac_addr;
        cur_ep      = vif.mac_endpoint;
        total_bytes = vif.mac_frame_num;
        vif.crc16_error  = 1'b0;
        vif.crc5_error   = 1'b0;
        vif.babble_error = 1'b0;
      end else if (in_pkt && vif.mac_valid && !vif.mac_eop) begin
        beats++;
        for (int j = 0; j < 4; j++)
          if (pkt.size() < total_bytes)
            pkt.push_back(vif.mac_data[j*8 +: 8]);
      end else if (in_pkt && vif.mac_eop) begin
        in_pkt = 0;
        // Babble: packet exceeded 64 beats
        if (beats > 64) begin
          vif.babble_error = 1'b1;
        end else if (cur_addr != DEV_ADDR && cur_addr != 7'h00) begin
          // Not addressed to this device: no response (host times out)
        end else if (cur_pid == PID_SOF) begin
          // SOF: no handshake
        end else if (cur_pid[1:0] == 2'b11) begin
          // DATA packet: verify CRC16 trailer over payload bytes
          int n = pkt.size();
          if (n >= 2) begin
            logic [15:0] recv = {pkt[n-1], pkt[n-2]};
            if (recv != crc16_payload(n - 2))
              vif.crc16_error = 1'b1;
            else
              respond(PID_ACK);
          end else begin
            respond(PID_ACK);
          end
        end else if (cur_ep == 4'hF) begin
          respond(PID_STALL);          // unimplemented endpoint
        end else begin
          respond(PID_ACK);            // token accepted
        end
      end
    end
  end

  // CRC16 recomputed over the first plen payload bytes of pkt
  function automatic logic [15:0] crc16_payload(int plen);
    logic [15:0] crc;
    crc = 16'hFFFF;
    for (int i = 0; i < plen && i < pkt.size(); i++) begin
      for (int j = 0; j < 8; j++) begin
        if (crc[15] ^ pkt[i][j])
          crc = {crc[14:0], 1'b0} ^ 16'h8005;
        else
          crc = {crc[14:0], 1'b0};
      end
    end
    return ~crc;
  endfunction
endmodule

//============================================================================
// USB 3.x PIPE PHY model: LTSSM walk to U0, CRC32 check, link-layer
// loopback ACK pulse after each packet.
//============================================================================
module usb3_phy_model (usb_vip_if.monitor_mp vif);

  `USB_VIP_TIEOFF(vif)

  bit [7:0] pkt[$];
  int       beats;
  bit       in_pkt;
  int       total_bytes;
  int       train_cnt;

  function automatic logic [31:0] crc32_payload(int plen);
    logic [31:0] crc;
    crc = 32'hFFFF_FFFF;
    for (int i = 0; i < plen && i < pkt.size(); i++) begin
      for (int j = 0; j < 8; j++) begin
        if (crc[31] ^ pkt[i][j])
          crc = {crc[30:0], 1'b0} ^ 32'h04C1_1DB7;
        else
          crc = {crc[30:0], 1'b0};
      end
    end
    return ~crc;
  endfunction

  // MAC ready
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) vif.mac_ready <= 1'b0;
    else            vif.mac_ready <= #1ns vif.mac_valid;
  end

  // LTSSM: Rx.Detect -> Polling (training) -> U0
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      train_cnt           <= 0;
      vif.ltssm_state     <= 4'b0001;    // Rx.Detect
      vif.link_up         <= 1'b0;
      vif.pipe_phy_ready  <= 1'b0;
      vif.training        <= 1'b0;
      vif.ts1_valid       <= 1'b0;
      vif.ts2_valid       <= 1'b0;
      vif.lfps_detect     <= 1'b0;
      vif.training_done   <= 1'b0;
      vif.pipe_power_state<= 2'b11;
      vif.pipe_rx_elecidle<= 1'b1;
    end else if (vif.pipe_power_down) begin
      train_cnt           <= 0;
      vif.ltssm_state     <= 4'b0001;
      vif.link_up         <= 1'b0;
      vif.pipe_phy_ready  <= 1'b0;
      vif.training        <= 1'b0;
      vif.training_done   <= 1'b0;
      vif.pipe_power_state<= 2'b11;
      vif.pipe_rx_elecidle<= 1'b1;
    end else begin
      vif.pipe_rx_elecidle <= vif.pipe_tx_elecidle;
      if (train_cnt < 8) begin
        train_cnt        <= train_cnt + 1;
        vif.ltssm_state  <= 4'b0100;     // Polling
        vif.training     <= 1'b1;
        vif.lfps_detect  <= (train_cnt < 2);
        vif.ts1_valid    <= (train_cnt >= 2 && train_cnt < 5);
        vif.ts2_valid    <= (train_cnt >= 5);
        vif.pipe_power_state <= 2'b00;
      end else begin
        vif.ltssm_state      <= 4'b0000; // U0
        vif.link_up          <= 1'b1;
        vif.pipe_phy_ready   <= 1'b1;
        vif.training         <= 1'b0;
        vif.ts1_valid        <= 1'b0;
        vif.ts2_valid        <= 1'b0;
        vif.lfps_detect      <= 1'b0;
        vif.training_done    <= 1'b1;
        vif.pipe_power_state <= 2'b00;
      end
    end
  end

  // Packet capture + CRC32 check + link-layer ACK pulse
  initial begin
    in_pkt = 0; beats = 0; total_bytes = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin
        in_pkt = 0; beats = 0;
        vif.crc32_error = 1'b0;
      end else if (vif.mac_valid && vif.mac_sop && !in_pkt) begin
        in_pkt      = 1;
        beats       = 0;
        pkt.delete();
        total_bytes = vif.mac_frame_num;
        vif.crc32_error = 1'b0;
      end else if (in_pkt && vif.mac_valid && !vif.mac_eop) begin
        beats++;
        for (int j = 0; j < 4; j++)
          if (pkt.size() < total_bytes)
            pkt.push_back(vif.mac_data[j*8 +: 8]);
      end else if (in_pkt && vif.mac_eop) begin
        in_pkt = 0;
        if (total_bytes >= 4) begin
          int n = pkt.size();
          logic [31:0] recv = {pkt[n-1], pkt[n-2], pkt[n-3], pkt[n-4]};
          if (recv != crc32_payload(n - 4))
            vif.crc32_error = 1'b1;
        end
        // Link-layer ACK: loopback rx_valid pulse
        repeat (2) @(posedge vif.clk);
        vif.pipe_rx_valid = 1'b1;
        vif.pipe_rx_data  = 32'h0000_00D2;
        repeat (2) @(posedge vif.clk);
        vif.pipe_rx_valid = 1'b0;
      end
    end
  end
endmodule

//============================================================================
// USB4 PIPE4 PHY model: link ready, router sideband defaults, CRC32 check,
// loopback response block after each packet.
//============================================================================
module usb4_phy_model (usb_vip_if.monitor_mp vif);

  `USB_VIP_TIEOFF(vif)

  bit [7:0] pkt[$];
  int       beats;
  bit       in_pkt;
  int       total_bytes;
  int       ready_cnt;

  function automatic logic [31:0] crc32_payload(int plen);
    logic [31:0] crc;
    crc = 32'hFFFF_FFFF;
    for (int i = 0; i < plen && i < pkt.size(); i++) begin
      for (int j = 0; j < 8; j++) begin
        if (crc[31] ^ pkt[i][j])
          crc = {crc[30:0], 1'b0} ^ 32'h04C1_1DB7;
        else
          crc = {crc[30:0], 1'b0};
      end
    end
    return ~crc;
  endfunction

  // MAC ready
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) vif.mac_ready <= 1'b0;
    else            vif.mac_ready <= #1ns vif.mac_valid;
  end

  // Link bring-up: link_ready after 4 cycles; router config pulse
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      ready_cnt          <= 0;
      vif.pipe4_link_ready <= 1'b0;
      vif.router_config  <= 1'b0;
      vif.cl_state       <= 3'b001;      // CLd until ready
      vif.link_up        <= 1'b0;
    end else begin
      if (ready_cnt < 4) begin
        ready_cnt <= ready_cnt + 1;
        if (ready_cnt == 3) begin
          vif.pipe4_link_ready <= 1'b1;
          vif.link_up          <= 1'b1;
          vif.cl_state         <= 3'b000;  // CL0
          vif.router_config    <= 1'b1;
        end
      end else begin
        vif.router_config <= 1'b0;
      end
      // Tunneling indication: USB3 tunneled traffic while MAC active
      vif.tunnel_usb3 <= vif.mac_valid;
    end
  end

  // Packet capture + CRC32 check + loopback response block
  initial begin
    in_pkt = 0; beats = 0; total_bytes = 0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin
        in_pkt = 0; beats = 0;
        vif.crc32_error = 1'b0;
      end else if (vif.mac_valid && vif.mac_sop && !in_pkt) begin
        in_pkt      = 1;
        beats       = 0;
        pkt.delete();
        total_bytes = vif.mac_frame_num;
        vif.crc32_error = 1'b0;
      end else if (in_pkt && vif.mac_valid && !vif.mac_eop) begin
        beats++;
        for (int j = 0; j < 4; j++)
          if (pkt.size() < total_bytes)
            pkt.push_back(vif.mac_data[j*8 +: 8]);
      end else if (in_pkt && vif.mac_eop) begin
        in_pkt = 0;
        if (total_bytes >= 4) begin
          int n = pkt.size();
          logic [31:0] recv = {pkt[n-1], pkt[n-2], pkt[n-3], pkt[n-4]};
          if (recv != crc32_payload(n - 4))
            vif.crc32_error = 1'b1;
        end
        // Loopback response block with control sync header
        repeat (2) @(posedge vif.clk);
        vif.pipe4_rx_valid    = 1'b1;
        vif.pipe4_rx_sync_hdr = 4'b1010;
        vif.pipe4_rx_data     = 128'hD2;
        repeat (2) @(posedge vif.clk);
        vif.pipe4_rx_valid = 1'b0;
      end
    end
  end
endmodule

//============================================================================
// USB-PD controller model: decodes Request header, negotiates contract,
// transitions Vbus to the requested voltage after Accept/PS_RDY delay.
//============================================================================
module pd_controller_model (usb_vip_if.monitor_mp vif);

  `USB_VIP_TIEOFF(vif)

  bit          in_msg;
  logic [31:0] hdr;

  // MAC ready
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) vif.mac_ready <= 1'b0;
    else            vif.mac_ready <= #1ns vif.mac_valid;
  end

  // Message tracking + contract negotiation
  initial begin
    in_msg = 0;
    hdr    = 32'h0;
    forever begin
      @(posedge vif.clk);
      if (!vif.rst_n) begin
        in_msg = 0;
        vif.pd_vbus_voltage = 11'd200;   // vSafe5V
        vif.pd_sop = 1'b0; vif.pd_eop = 1'b0;
        vif.ams_start = 1'b0; vif.ams_end = 1'b0;
        vif.pd_power_contract = 1'b0;
      end else if (vif.pd_msg_valid && !in_msg) begin
        in_msg = 1;
        hdr = vif.pd_header;
        vif.pd_sop = 1'b1;
        vif.ams_start = 1'b1;
        vif.pd_message_id = vif.pd_message_id + 1;
        @(posedge vif.clk);
        vif.pd_sop = 1'b0;
        vif.ams_start = 1'b0;
      end else if (in_msg && !vif.pd_msg_valid) begin
        in_msg = 0;
        vif.pd_eop = 1'b1;
        vif.ams_end = 1'b1;
        @(posedge vif.clk);
        vif.pd_eop = 1'b0;
        vif.ams_end = 1'b0;
        // PS_RDY: transition Vbus to requested voltage (header[31:16] mV)
        repeat (10) @(posedge vif.clk);
        vif.pd_vbus_voltage = 11'(hdr[31:16] / 25);
        vif.pd_power_contract = 1'b1;
        repeat (4) @(posedge vif.clk);
        vif.pd_power_contract = 1'b0;
      end
    end
  end
endmodule
`endif
