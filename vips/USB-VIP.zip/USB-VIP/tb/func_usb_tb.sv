// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_usb_tb.sv -- self-checking functional test for the USB 2.0 device
// endpoint model (tb/usb_smoke_model.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py USB-VIP
//
// Model contract (from tb/usb_smoke_model.sv), one packet per mac_valid clock:
//   * PID class in pid[1:0] (01 token, 10 handshake, 11 data), sub-type in
//     pid[3:2]: tokens OUT=00 SOF=01 IN=10 SETUP=11; data DATA0=00 DATA1=10;
//     handshake ACK=00.
//   * tokens are taken when addressed: promiscuous, address match, or
//     address 0 while the device is unaddressed.
//   * OUT/SETUP then a data packet: endpoint 15 -> STALL; bad CRC -> NAK
//     (nak_count++); expected toggle -> ACK and the toggle flips; wrong toggle
//     (retry) -> ACK without flipping. SETUP resets the toggle to DATA0; its
//     accepted data byte 0 becomes the device address and advances
//     DEFAULT -> ADDRESS -> CONFIGURED. No data in 16 clocks -> NAK.
//   * IN: tx_valid with a new tx_data byte; host ACK flips the toggle; no
//     handshake within 16 clocks drops tx_valid.
//   * SOF: frame_num = {data[7:0], endpoint[2:0]}.
//   * mac_ready is mac_valid delayed one clock.

module func_usb_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam logic [1:0] NONE = 2'b00, ACK = 2'b01, NAK = 2'b10, STALL = 2'b11;
  localparam logic [7:0] P_OUT = 8'h01, P_SOF = 8'h05, P_IN = 8'h09, P_SETUP = 8'h0D,
                         P_DATA0 = 8'h03, P_DATA1 = 8'h0B, P_ACK = 8'h02, P_NAK = 8'h06;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, valid = 1'b0, crc_ok = 1'b1, promisc = 1'b0;
  logic [7:0]  pid = '0;
  logic [6:0]  addr = '0;
  logic [3:0]  endp = '0;
  logic [31:0] data = '0;
  wire         ready, toggle, tx_valid;
  wire  [1:0]  hs;
  wire  [3:0]  dstate;
  wire  [6:0]  daddr;
  wire  [10:0] frame;
  wire  [7:0]  tx_data, naks;

  always #5 clk = ~clk;

  usb_smoke_model u_dut (
    .clk(clk), .rst_n(rst_n), .mac_valid(valid), .mac_pid(pid), .mac_addr(addr),
    .mac_endpoint(endp), .mac_data(data), .mac_crc_ok(crc_ok), .promiscuous(promisc),
    .mac_ready(ready), .hs_resp(hs), .data_toggle(toggle), .dev_state(dstate),
    .dev_addr(daddr), .frame_num(frame), .tx_data(tx_data), .tx_valid(tx_valid),
    .nak_count(naks)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one packet: a single mac_valid clock; returns at the next negedge with
  // the registered response visible
  task automatic pkt(input [7:0] p, input [6:0] a = 0, input [3:0] e = 0, input [31:0] d = 0,
                     input bit ok = 1);
    @(negedge clk);
    valid = 1; pid = p; addr = a; endp = e; data = d; crc_ok = ok;
    @(negedge clk);
    valid = 0; crc_ok = 1;
  endtask

  task automatic gap(input int n); repeat (n) @(negedge clk); endtask

  bit t0;
  int n0;

  initial begin
    gap(2);
    rst_n = 1;
    gap(1);
    chk(dstate == 0 && daddr == 0 && toggle == 0 && hs == NONE && naks == 0, "reset state");

    // mac_ready echoes mac_valid one clock later
    @(negedge clk); valid = 1; pid = 8'h00;
    @(posedge clk); #1 chk(ready === 1'b1, "mac_ready follows mac_valid");
    @(negedge clk); valid = 0;
    @(posedge clk); #1 chk(ready === 1'b0, "mac_ready drops with mac_valid");

    // enumeration: SET_ADDRESS via SETUP to address 0
    pkt(P_SETUP, 0, 0);
    pkt(P_DATA0, 0, 0, 32'h0000_0015);
    chk(hs == ACK && daddr == 7'h15 && dstate == 1, "SETUP+DATA0 to address 0 is ACKed and assigns address 0x15");
    chk(toggle == 1, "accepted DATA0 flips the toggle to DATA1");

    // address filtering
    pkt(P_OUT, 0, 1);
    pkt(P_DATA1, 0, 1, 32'h99);
    chk(hs == ACK && toggle == 1, "token to address 0 is ignored once addressed (data in IDLE not taken)");
    gap(1);
    pkt(P_OUT, 7'h22, 1);
    chk(u_dut.state == 0, "token to another address is ignored");

    // OUT to own address, toggle sequence
    pkt(P_OUT, 7'h15, 1);
    pkt(P_DATA1, 7'h15, 1, 32'hA1);
    chk(hs == ACK && toggle == 0, "OUT DATA1 ACKed, toggle back to DATA0");
    pkt(P_OUT, 7'h15, 1);
    pkt(P_DATA1, 7'h15, 1, 32'hA1);
    chk(hs == ACK && toggle == 0, "retransmitted DATA1 (toggle mismatch) ACKed without flipping");
    pkt(P_OUT, 7'h15, 1);
    pkt(P_DATA0, 7'h15, 1, 32'hA2);
    chk(hs == ACK && toggle == 1, "next DATA0 ACKed and flips");

    // CRC error -> NAK, toggle unchanged
    n0 = naks; t0 = toggle;
    pkt(P_OUT, 7'h15, 1);
    pkt(P_DATA1, 7'h15, 1, 32'hA3, 0);
    chk(hs == NAK && naks == n0 + 1 && toggle == t0, "bad CRC NAKed, nak_count++, toggle kept");

    // STALL on endpoint 15
    pkt(P_OUT, 7'h15, 4'hF);
    pkt(P_DATA1, 7'h15, 4'hF, 32'h0);
    chk(hs == STALL && toggle == t0, "halted endpoint 15 returns STALL");

    // OUT with no data phase: timeout NAK
    n0 = naks;
    pkt(P_OUT, 7'h15, 2);
    gap(15);
    chk(u_dut.state == 1 && hs == NONE, "still waiting for data 15 clocks after OUT");
    gap(1);
    chk(hs == NAK && naks == n0 + 1 && u_dut.state == 0, "missing data phase times out with NAK");

    // token while waiting for data aborts the transaction
    pkt(P_OUT, 7'h15, 2);
    pkt(P_OUT, 7'h15, 2);
    chk(u_dut.state == 0 && hs == NONE, "a token in the data phase aborts back to idle");

    // IN: data offered, host ACK flips the toggle, NAK does not
    t0 = toggle;
    pkt(P_IN, 7'h15, 1);
    chk(tx_valid === 1'b1, "IN token raises tx_valid");
    n0 = tx_data;
    pkt(P_ACK, 7'h15, 1);
    chk(!tx_valid && toggle == !t0, "host ACK ends the IN and flips the toggle");
    pkt(P_IN, 7'h15, 1);
    chk(tx_valid && tx_data == ((n0 + 1) & 8'hFF), "next IN offers a new data byte");
    pkt(P_NAK, 7'h15, 1);
    chk(!tx_valid && toggle == !t0, "host NAK ends the IN without flipping");
    pkt(P_IN, 7'h15, 1);
    gap(15);
    chk(tx_valid === 1'b1, "tx_valid held while waiting for the handshake");
    gap(2);
    chk(tx_valid === 1'b0 && u_dut.state == 0, "IN without handshake times out");

    // SOF frame number
    pkt(P_SOF, 7'h15, 4'h5, 32'h0000_00AB);
    chk(frame == {8'hAB, 3'h5}, "SOF sets frame_num from the token fields");
    pkt(P_SOF, 7'h15, 4'hF, 32'h0000_0001);
    chk(frame == {8'h01, 3'h7}, "SOF uses endpoint bits [2:0] as frame[2:0]");

    // second SETUP: SET_CONFIGURATION advances to CONFIGURED, toggle reset
    if (toggle == 0) begin
      pkt(P_OUT, 7'h15, 1);
      pkt(P_DATA0, 7'h15, 1, 32'h0);
    end
    chk(toggle == 1, "toggle at DATA1 before SETUP");
    pkt(P_SETUP, 7'h15, 0);
    chk(toggle == 0, "SETUP resets the toggle to DATA0");
    pkt(P_DATA0, 7'h15, 0, 32'h0000_0015);
    chk(hs == ACK && dstate == 2 && daddr == 7'h15, "second SETUP moves to CONFIGURED");

    // SETUP data with a bad CRC changes nothing
    pkt(P_SETUP, 7'h15, 0);
    pkt(P_DATA0, 7'h15, 0, 32'h0000_0033, 0);
    chk(hs == NAK && daddr == 7'h15 && dstate == 2, "SETUP data with bad CRC NAKed, address kept");

    // promiscuous mode accepts any address
    promisc = 1;
    pkt(P_OUT, 7'h7F, 3);
    chk(u_dut.state == 1, "promiscuous mode takes a token to any address");
    pkt(P_DATA1, 7'h7F, 3, 32'h0);
    promisc = 0;

    // reset returns to DEFAULT
    @(negedge clk); rst_n = 0;
    @(negedge clk); rst_n = 1;
    chk(dstate == 0 && daddr == 0 && toggle == 0 && naks == 0 && frame == 0 && !tx_valid,
        "reset returns to DEFAULT, address 0");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
