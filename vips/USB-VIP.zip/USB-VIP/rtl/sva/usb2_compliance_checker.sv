// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB 2.0 device compliance checker on usb2_link_if. Every violation is a
// UVM_ERROR.
//   L1 signal sanity   (4)  legal link / device state codes, no X on the
//                           state and answer valid, answers fully known
//   L2 packets         (6)  answer PID check nibble, only ACK / NAK / STALL /
//                           NYET / DATA0 / DATA1 sent, handshakes carry no
//                           data, data length within MPS for the speed, NYET
//                           only at HS, data only answers an IN token
//   L3 link            (7)  every answer follows a valid packet one clock
//                           earlier while FS / HS, hs only in the HS state,
//                           chirp K only while chirping, legal link
//                           transitions (HS -> FS only on a reset with HS
//                           capability withdrawn), HS entered only from the chirp or a
//                           resume, a reset returns to DEFAULT / address 0
//   L4 chapter 9       (4)  DEFAULT <-> address 0, cfg_val <-> CONFIGURED,
//                           EP0 never halted, halts only when CONFIGURED
//   L5 counters        (4)  counters step by at most one per clock, NAK /
//                           STALL / NYET counters move exactly with those
//                           answers, a completed split answers ACK or DATA0,
//                           microframes only at HS (or suspended from HS)
`ifndef USB2_COMPLIANCE_CHECKER_SV
`define USB2_COMPLIANCE_CHECKER_SV

module usb2_compliance_checker (usb2_link_if vif);
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [3:0] P_IN = 4'h9, P_DATA0 = 4'h3, P_DATA1 = 4'hB, P_ACK = 4'h2, P_NAK = 4'hA,
                         P_STALL = 4'hE, P_NYET = 4'h6;
  localparam logic [2:0] FS = 3'd0, CHIRP = 3'd1, CHWAIT = 3'd2, HS = 3'd3, SUSP = 3'd4;

  function automatic bit legal(input logic [2:0] a, input logic [2:0] b);
    if (a == b) return 1'b1;
    case (a)
      FS:     return b == SUSP || b == CHIRP;
      CHIRP:  return b == CHWAIT;
      CHWAIT: return b == HS || b == FS;
      HS:     return b == SUSP || b == CHIRP;
      SUSP:   return b == FS || b == HS || b == CHIRP;
      default: return 1'b0;
    endcase
  endfunction
  function automatic bit step1(input logic [7:0] now, input logic [7:0] was);
    return now == was || now == was + 8'd1;
  endfunction

  wire [3:0] tp = vif.tx_pid[3:0];
  wire       tx_hsk = tp == P_ACK || tp == P_NAK || tp == P_STALL || tp == P_NYET;
  wire       tx_dat = tp == P_DATA0 || tp == P_DATA1;
  wire [103:0] cnts = {vif.pid_err, vif.crc5_err, vif.crc16_err, vif.babble_cnt, vif.dup_cnt, vif.nak_cnt,
                       vif.stall_cnt, vif.nyet_cnt, vif.sof_cnt, vif.sof_miss, vif.resets, vif.tmo_cnt,
                       vif.split_cnt};
  function automatic bit all_step1(input logic [103:0] now, input logic [103:0] was);
    for (int i = 0; i < 13; i++) if (!step1(now[8*i +: 8], was[8*i +: 8])) return 1'b0;
    return 1'b1;
  endfunction

  `define U2_CHK(LBL, NAME, PROP, MSG) \
    LBL: assert property (@(posedge vif.clk) disable iff (!vif.rst_n) PROP) \
      else `uvm_error(NAME, MSG)

  // ---------------------------------------------------- L1
  `U2_CHK(a_l1_ls, "USB2_L1", vif.ls <= SUSP, "illegal link state code")
  `U2_CHK(a_l1_dev, "USB2_L1", vif.dev_state != 2'd3, "illegal device state code")
  `U2_CHK(a_l1_known, "USB2_L1", !$isunknown({vif.ls, vif.hs, vif.chirp_k, vif.dev_state, vif.tx_valid}),
          "X/Z on link state, device state or answer valid")
  `U2_CHK(a_l1_ans, "USB2_L1", vif.tx_valid |-> !$isunknown({vif.tx_pid, vif.tx_len, vif.tx_data}),
          "X/Z in an answer")

  // ---------------------------------------------------- L2
  `U2_CHK(a_l2_check, "USB2_L2", vif.tx_valid |-> vif.tx_pid[7:4] == ~vif.tx_pid[3:0],
          "answer PID check nibble is not the complement")
  `U2_CHK(a_l2_kind, "USB2_L2", vif.tx_valid |-> (tx_hsk || tx_dat),
          "device sent a PID it may not send")
  `U2_CHK(a_l2_hsk_len, "USB2_L2", vif.tx_valid && tx_hsk |-> vif.tx_len == 10'd0,
          "handshake with a data length")
  `U2_CHK(a_l2_mps, "USB2_L2", vif.tx_valid && tx_dat |-> vif.tx_len <= (vif.hs ? 10'd512 : 10'd64),
          "data packet longer than the maximum packet size for the speed")
  `U2_CHK(a_l2_nyet, "USB2_L2", vif.tx_valid && tp == P_NYET |-> vif.hs, "NYET at full speed")
  `U2_CHK(a_l2_data_in, "USB2_L2", vif.tx_valid && tx_dat |-> $past(vif.rx_pid[3:0]) == P_IN,
          "data sent without an IN token")

  // ---------------------------------------------------- L3
  `U2_CHK(a_l3_after_pkt, "USB2_L3",
          vif.tx_valid |-> $past(vif.rx_valid) && $past(vif.rx_pid[7:4] == ~vif.rx_pid[3:0]) &&
                           ($past(vif.ls) == FS || $past(vif.ls) == HS),
          "answer without a valid packet one clock earlier in FS / HS")
  `U2_CHK(a_l3_hs, "USB2_L3", vif.hs == (vif.ls == HS), "hs does not match the HS link state")
  `U2_CHK(a_l3_chirp, "USB2_L3", vif.chirp_k |-> (vif.ls == CHIRP || vif.ls == CHWAIT),
          "chirp K outside the chirp")
  `U2_CHK(a_l3_trans, "USB2_L3", legal($past(vif.ls), vif.ls) ||
                                 ($past(vif.ls) == HS && vif.ls == FS && !$past(vif.hs_cap)),
          "illegal link state transition")
  `U2_CHK(a_l3_hs_entry, "USB2_L3", vif.ls == HS && $past(vif.ls) != HS |-> $past(vif.ls) inside {CHWAIT, SUSP},
          "HS entered without a chirp or a resume")
  `U2_CHK(a_l3_reset, "USB2_L3", vif.ls == CHIRP && $past(vif.ls) != CHIRP |-> vif.dev_state == 2'd0 &&
                                 vif.dev_addr == 7'h00 && !vif.cfg_val && vif.ep_halt == 4'h0,
          "bus reset did not return the device to DEFAULT / address 0")
  `U2_CHK(a_l3_reset_cnt, "USB2_L3", vif.resets != $past(vif.resets) |-> vif.dev_state == 2'd0 &&
                                     (vif.ls == CHIRP || vif.ls == FS),
          "reset counted without a reset")

  // ---------------------------------------------------- L4
  `U2_CHK(a_l4_addr, "USB2_L4", (vif.dev_state == 2'd0) == (vif.dev_addr == 7'h00),
          "DEFAULT state and address 0 disagree")
  `U2_CHK(a_l4_cfg, "USB2_L4", vif.cfg_val == (vif.dev_state == 2'd2), "configuration value and CONFIGURED disagree")
  `U2_CHK(a_l4_ep0, "USB2_L4", !vif.ep_halt[0], "EP0 halted")
  `U2_CHK(a_l4_halt, "USB2_L4", vif.ep_halt != 4'h0 |-> vif.dev_state == 2'd2, "endpoint halted outside CONFIGURED")

  // ---------------------------------------------------- L5
  `U2_CHK(a_l5_step, "USB2_L5", all_step1(cnts, $past(cnts)), "a counter moved by more than one")
  `U2_CHK(a_l5_hsk_cnt, "USB2_L5",
          (vif.nak_cnt != $past(vif.nak_cnt)) == (vif.tx_valid && tp == P_NAK) &&
          (vif.stall_cnt != $past(vif.stall_cnt)) == (vif.tx_valid && tp == P_STALL) &&
          (vif.nyet_cnt != $past(vif.nyet_cnt)) == (vif.tx_valid && tp == P_NYET),
          "NAK / STALL / NYET counter does not match the answers")
  `U2_CHK(a_l5_split, "USB2_L5", vif.split_cnt != $past(vif.split_cnt) |->
                                 vif.tx_valid && (tp == P_ACK || (tp == P_DATA0 && vif.tx_len == 10'd8)),
          "split completed without its ACK / DATA0")
  `U2_CHK(a_l5_uframe, "USB2_L5", vif.uframe != 3'd0 |-> (vif.hs || vif.ls == SUSP),
          "microframe index outside HS")

  // ---------------------------------------------------- covers
  c_hs:       cover property (@(posedge vif.clk) vif.ls == HS && $past(vif.ls) == CHWAIT);
  c_fs_fall:  cover property (@(posedge vif.clk) vif.ls == FS && $past(vif.ls) == CHWAIT);
  c_susp:     cover property (@(posedge vif.clk) vif.ls == SUSP && $past(vif.ls) == HS);
  c_resume:   cover property (@(posedge vif.clk) vif.ls == HS && $past(vif.ls) == SUSP);
  c_nyet:     cover property (@(posedge vif.clk) vif.tx_valid && tp == P_NYET);
  c_stall:    cover property (@(posedge vif.clk) vif.tx_valid && tp == P_STALL);
  c_data1:    cover property (@(posedge vif.clk) vif.tx_valid && tp == P_DATA1 && vif.tx_len == 10'd512);
  c_split:    cover property (@(posedge vif.clk) vif.split_cnt != $past(vif.split_cnt));
  c_uframe7:  cover property (@(posedge vif.clk) vif.uframe == 3'd7);
  c_miss:     cover property (@(posedge vif.clk) vif.sof_miss != $past(vif.sof_miss));
  c_babble:   cover property (@(posedge vif.clk) vif.babble_cnt != $past(vif.babble_cnt));
  c_config:   cover property (@(posedge vif.clk) vif.dev_state == 2'd2 && vif.hs);

  `undef U2_CHK
endmodule

`endif
