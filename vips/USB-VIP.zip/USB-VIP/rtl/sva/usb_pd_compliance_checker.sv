// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB Power Delivery sink compliance checker on usb_pd_link_if. Every
// violation is a UVM_ERROR.
//   L1 signal sanity     (4)  legal state code, no X, symbols are 4b5b
//                             data or the K-codes a sink sends
//   L2 framing           (4)  frames open with Sync-1 / RST-1, SOP or Hard
//                             Reset ordered set, no gaps inside a frame,
//                             EOP only inside a frame
//   L3 policy engine     (5)  VBUS loss disables, contract only in the
//                             explicit-contract states, Hard Reset drops
//                             the contract to vSafe5V, a contract starts
//                             only at PS_RDY, no VBUS level while disabled
//   L4 protocol layer    (4)  retries / hard_resets / MessageIDCounter
//                             move by one step, ErrorRecovery only after
//                             nHardResetCount
//   L5 receive counters  (3)  each counter moves only on its cause
`ifndef USB_PD_COMPLIANCE_CHECKER_SV
`define USB_PD_COMPLIANCE_CHECKER_SV

module usb_pd_compliance_checker (usb_pd_link_if vif);
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [4:0] S1 = 5'h18, S2 = 5'h11, R1 = 5'h07, R2 = 5'h19, EOP = 5'h0D;
  localparam logic [3:0] DIS = 4'd0, WCAP = 4'd1, TRANS = 4'd4, READY = 4'd5, HRST = 4'd11, ERR = 4'd12;

  function automatic bit is_data(input logic [4:0] s);
    case (s)
      5'h1E, 5'h09, 5'h14, 5'h15, 5'h0A, 5'h0B, 5'h0E, 5'h0F,
      5'h12, 5'h13, 5'h16, 5'h17, 5'h1A, 5'h1B, 5'h1C, 5'h1D: return 1'b1;
      default: return 1'b0;
    endcase
  endfunction

  // ---------------------------------------------------- bookkeeping
  wire        tx    = vif.tx_valid === 1'b1;
  logic [4:0] w0, w1, w2;     // last three symbols outside a frame
  logic       in_frame;
  logic       prev_tx;
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      w0 <= 5'h0; w1 <= 5'h0; w2 <= 5'h0; in_frame <= 1'b0; prev_tx <= 1'b0;
    end
    else begin
      prev_tx <= tx;
      if (vif.pe_state == HRST || vif.pe_state == DIS) in_frame <= 1'b0;
      if (tx) begin
        if (!in_frame) begin
          if (w0 == S1 && w1 == S1 && w2 == S1 && vif.tx_sym == S2) begin
            in_frame <= 1'b1; w0 <= 5'h0; w1 <= 5'h0; w2 <= 5'h0;
          end
          else begin w0 <= w1; w1 <= w2; w2 <= vif.tx_sym; end
        end
        else if (vif.tx_sym == EOP) in_frame <= 1'b0;
      end
      else if (!in_frame) begin w0 <= 5'h0; w1 <= 5'h0; w2 <= 5'h0; end
    end
  end

  `define PD_CHK(LBL, NAME, PROP, MSG) \
    LBL: assert property (@(posedge vif.clk) disable iff (!vif.rst_n) PROP) \
      else `uvm_error(NAME, MSG)

  // ---------------------------------------------------- L1
  `PD_CHK(a_l1_state, "PD_L1", vif.pe_state <= ERR, "illegal policy-engine state code")
  `PD_CHK(a_l1_known, "PD_L1", !$isunknown({vif.pe_state, vif.tx_valid, vif.contract, vif.msg_id}),
          "X/Z on state, tx_valid, contract or MessageIDCounter")
  `PD_CHK(a_l1_sym, "PD_L1", tx |-> !$isunknown(vif.tx_sym), "X/Z on a sent symbol")
  `PD_CHK(a_l1_code, "PD_L1", tx |-> (is_data(vif.tx_sym) || vif.tx_sym inside {S1, S2, R1, R2, EOP}),
          "sent symbol is neither a 4b5b data code nor a sink K-code")

  // ---------------------------------------------------- L2
  `PD_CHK(a_l2_open, "PD_L2", (tx && !prev_tx && !in_frame) |-> vif.tx_sym inside {S1, R1},
          "frame does not open with Sync-1 or RST-1")
  `PD_CHK(a_l2_os, "PD_L2", (tx && !in_frame && w0 inside {S1, R1} && w1 inside {S1, R1} && w2 inside {S1, R1}) |->
                            ((w0 == S1 && w1 == S1 && w2 == S1 && vif.tx_sym == S2) ||
                             (w0 == R1 && w1 == R1 && w2 == R1 && vif.tx_sym == R2)),
          "ordered set is neither SOP nor Hard Reset")
  `PD_CHK(a_l2_gap, "PD_L2", (in_frame && !tx) |-> (vif.pe_state == HRST || vif.pe_state == DIS ||
                                                    $past(vif.pe_state) != vif.pe_state),
          "gap inside a frame")
  `PD_CHK(a_l2_eop, "PD_L2", (tx && vif.tx_sym == EOP) |-> in_frame, "EOP outside a frame")

  // ---------------------------------------------------- L3
  `PD_CHK(a_l3_vbus, "PD_L3", (!vif.vbus_present && vif.pe_state != HRST) |=> vif.pe_state == DIS,
          "VBUS lost but the policy engine is not Disabled")
  `PD_CHK(a_l3_contract, "PD_L3", vif.contract |-> !(vif.pe_state inside {DIS, WCAP, HRST, ERR}),
          "explicit contract outside the contract states")
  `PD_CHK(a_l3_hrst, "PD_L3", (vif.pe_state == HRST && $past(vif.pe_state) != HRST) |->
                              (!vif.contract && vif.vbus_v50 == 10'd100),
          "Hard Reset kept the contract or left vSafe5V")
  `PD_CHK(a_l3_ps_rdy, "PD_L3", $rose(vif.contract) |-> ($past(vif.pe_state) == TRANS && vif.pe_state == READY),
          "contract started outside Transition_Sink -> Ready")
  `PD_CHK(a_l3_dis, "PD_L3", (vif.pe_state == DIS && $past(vif.pe_state) == DIS) |-> vif.vbus_v50 == 10'd0,
          "VBUS level reported while Disabled")

  // ---------------------------------------------------- L4
  `PD_CHK(a_l4_retry, "PD_L4", vif.retries != $past(vif.retries) |-> vif.retries == $past(vif.retries) + 8'd1,
          "retry counter jumped")
  `PD_CHK(a_l4_hr, "PD_L4", vif.hard_resets != $past(vif.hard_resets) |->
                            (vif.hard_resets == $past(vif.hard_resets) + 8'd1 && vif.pe_state == HRST),
          "Hard Reset counted without entering Hard Reset")
  `PD_CHK(a_l4_id, "PD_L4", vif.msg_id != $past(vif.msg_id) |->
                            (vif.msg_id == $past(vif.msg_id) + 3'd1 || vif.msg_id inside {3'd0, 3'd1}),
          "MessageIDCounter moved by more than one")
  `PD_CHK(a_l4_err, "PD_L4", vif.pe_state == ERR |-> vif.hr_counter == 2'd2,
          "ErrorRecovery before nHardResetCount Hard Resets")

  // ---------------------------------------------------- L5
  `PD_CHK(a_l5_bad, "PD_L5", vif.rx_bad != $past(vif.rx_bad) |-> $past(vif.rx_valid),
          "bad-packet count without a received symbol")
  `PD_CHK(a_l5_eop, "PD_L5", (vif.rx_good != $past(vif.rx_good) || vif.rx_other_sop != $past(vif.rx_other_sop)) |->
                             $past(vif.rx_valid && vif.rx_sym == EOP),
          "packet counted without an EOP")
  `PD_CHK(a_l5_dup, "PD_L5", vif.rx_dup != $past(vif.rx_dup) |-> vif.rx_good != $past(vif.rx_good),
          "duplicate counted without a good packet")

  // ---------------------------------------------------- covers
  c_contract:  cover property (@(posedge vif.clk) $rose(vif.contract));
  c_hr_sent:   cover property (@(posedge vif.clk) tx && w0 == R1 && w1 == R1 && w2 == R1 && vif.tx_sym == R2);
  c_hrst:      cover property (@(posedge vif.clk) vif.pe_state == HRST && $past(vif.pe_state) != HRST);
  c_err:       cover property (@(posedge vif.clk) vif.pe_state == ERR);
  c_retry:     cover property (@(posedge vif.clk) vif.retries != $past(vif.retries));
  c_dup:       cover property (@(posedge vif.clk) vif.rx_dup != $past(vif.rx_dup));
  c_other_sop: cover property (@(posedge vif.clk) vif.rx_other_sop != $past(vif.rx_other_sop));
  c_bad:       cover property (@(posedge vif.clk) vif.rx_bad != $past(vif.rx_bad));
  c_mismatch:  cover property (@(posedge vif.clk) vif.contract && vif.mismatch);
  c_vbus_loss: cover property (@(posedge vif.clk) $past(vif.contract) && vif.pe_state == DIS);

  `undef PD_CHK
endmodule

`endif
