// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB 3.2 link-layer compliance checker on usb3_link_if (upstream device
// port). Every violation is a UVM_ERROR.
//   L1 signal sanity        (4)  legal LTSSM code, no X, buffer/credit range
//   L2 link layer           (5)  CRC-5 of link commands, CRC-16/CRC-5 of
//                                headers, headers only in U0, LCRD_A..D
//                                order, LGOOD_n sequence / advertisement
//   L3 LTSSM                (6)  legal transitions, RxDetect needs a far
//                                end, U0 entered on a TS2, Ux left by LFPS,
//                                Gen2 fixed outside Polling.LFPS, Hot Reset
//                                only from a TS with the reset bit
//   L4 link power mgmt      (4)  Ux only after LAU + LPMA, LAU/LXU only
//                                answer LGO_Ux, U1 -> U2 only with a
//                                timeout, buffers taken only by headers
//   L5 counters / Gen2      (5)  block fixes / drops, bad headers, DPP,
//                                ITP each tied to their cause
`ifndef USB3_COMPLIANCE_CHECKER_SV
`define USB3_COMPLIANCE_CHECKER_SV

module usb3_compliance_checker (usb3_link_if vif);
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [3:0] RXDET = 4'd0, PLFPS = 4'd1, PACT = 4'd2, PCFG = 4'd3, U0 = 4'd4,
                         U1 = 4'd5, U2 = 4'd6, U3 = 4'd7, RACT = 4'd8, RCFG = 4'd9, HRST = 4'd10;

  function automatic logic [4:0] crc5(input logic [10:0] d);
    logic [4:0] c;
    c = 5'h1F;
    for (int i = 0; i < 11; i++) c = (c[4] ^ d[i]) ? ({c[3:0], 1'b0} ^ 5'h05) : {c[3:0], 1'b0};
    return ~c;
  endfunction
  function automatic logic [15:0] crc16(input logic [95:0] d);
    logic [15:0] c;
    c = 16'hFFFF;
    for (int i = 0; i < 96; i++) c = (c[15] ^ d[i]) ? ({c[14:0], 1'b0} ^ 16'h100B) : {c[14:0], 1'b0};
    return ~c;
  endfunction

  // ---------------------------------------------------- bookkeeping
  wire        lc_out   = vif.tx_lc_valid === 1'b1;
  wire [3:0]  lc_ct    = vif.tx_lc[10:7];
  wire        rx_lc    = vif.rx_valid && vif.rx_kind == 3'd3 && vif.rx_lc[15:11] == crc5(vif.rx_lc[10:0]);
  wire        rx_lgo   = rx_lc && vif.rx_lc[10:7] == 4'b0100 && vif.rx_lc[1:0] != 2'd0;
  wire        rx_lpma  = rx_lc && vif.rx_lc[10:7] == 4'b0111;
  wire        rx_ts    = vif.rx_valid && vif.rx_kind <= 3'd1;
  wire        rx_hdr   = vif.rx_valid && vif.rx_kind == 3'd2;
  wire [3:0]  blk_x    = vif.rx_blk ^ ((vif.rx_kind <= 3'd1) ? 4'b0011 : 4'b1100);
  wire [2:0]  blk_n    = 3'(blk_x[0]) + 3'(blk_x[1]) + 3'(blk_x[2]) + 3'(blk_x[3]);
  wire        hdr_bad  = vif.rx_hdr[111:96] != crc16(vif.rx_hdr[95:0]) ||
                         vif.rx_hdr[127:123] != crc5(vif.rx_hdr[122:112]);

  logic [1:0] lcrd_exp;       // next LCRD index the device must send
  logic [2:0] lgood_last;     // HdrSeq of its last LGOOD
  logic       adv_due;        // next LGOOD is the U0-entry advertisement
  logic       lgo_open;       // an LGO_Ux waits for LAU / LXU
  logic       lau_seen;       // LAU sent, LPMA not yet received
  logic [3:0] st_q;
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      lcrd_exp <= 2'd0; lgood_last <= 3'd7; adv_due <= 1'b1; lgo_open <= 1'b0; lau_seen <= 1'b0;
      st_q <= RXDET;
    end
    else begin
      st_q <= vif.ltssm;
      if ((vif.ltssm == RXDET && vif.far_end_ready) || vif.ltssm == HRST) begin
        lcrd_exp <= 2'd0; lgood_last <= 3'd7;
      end
      if (vif.ltssm != U0) adv_due <= 1'b1;     // the advertisement is sent on U0 entry
      if (lc_out && lc_ct == 4'b0001) lcrd_exp <= vif.tx_lc[1:0] + 2'd1;
      if (lc_out && lc_ct == 4'b0000) begin lgood_last <= vif.tx_lc[2:0]; adv_due <= 1'b0; end
      if (rx_lgo && vif.ltssm == U0 && !lau_seen) lgo_open <= 1'b1;
      if (lc_out && (lc_ct == 4'b0101 || lc_ct == 4'b0110)) lgo_open <= 1'b0;
      if (lc_out && lc_ct == 4'b0101) lau_seen <= 1'b1;
      if (vif.ltssm != U0 && vif.ltssm != st_q && st_q == U0) lau_seen <= 1'b0;
    end
  end

  `define USB3_CHK(LBL, NAME, PROP, MSG) \
    LBL: assert property (@(posedge vif.clk) disable iff (!vif.rst_n) PROP) \
      else `uvm_error(NAME, MSG)

  // ---------------------------------------------------- L1
  `USB3_CHK(a_l1_ltssm, "USB3_L1", vif.ltssm <= HRST, "illegal LTSSM state code")
  `USB3_CHK(a_l1_known, "USB3_L1", !$isunknown({vif.ltssm, vif.tx_lc_valid, vif.tx_hp_valid, vif.gen2}),
            "X/Z on LTSSM or a valid")
  `USB3_CHK(a_l1_payload, "USB3_L1", (vif.tx_lc_valid |-> !$isunknown(vif.tx_lc)) and
                                     (vif.tx_hp_valid |-> !$isunknown(vif.tx_hp)), "X/Z in a sent link command or header")
  `USB3_CHK(a_l1_range, "USB3_L1", vif.rx_free <= 3'd4 && vif.tx_credits <= 3'd4,
            "more than 4 receive buffers or transmit credits")

  // ---------------------------------------------------- L2
  `USB3_CHK(a_l2_lc_crc, "USB3_L2", vif.tx_lc_valid |-> vif.tx_lc[15:11] == crc5(vif.tx_lc[10:0]),
            "link command with a bad CRC-5")
  `USB3_CHK(a_l2_hp_crc, "USB3_L2", vif.tx_hp_valid |-> (vif.tx_hp[111:96] == crc16(vif.tx_hp[95:0]) &&
                                                          vif.tx_hp[127:123] == crc5(vif.tx_hp[122:112])),
            "header packet with a bad CRC-16 / CRC-5")
  `USB3_CHK(a_l2_hp_u0, "USB3_L2", vif.tx_hp_valid |-> $past(vif.ltssm) == U0, "header packet sent outside U0")
  `USB3_CHK(a_l2_lcrd, "USB3_L2", lc_out && lc_ct == 4'b0001 |-> vif.tx_lc[1:0] == lcrd_exp,
            "LCRD_x out of A, B, C, D order")
  `USB3_CHK(a_l2_lgood, "USB3_L2", lc_out && lc_ct == 4'b0000 |->
                                   vif.tx_lc[2:0] == (adv_due ? lgood_last : 3'(lgood_last + 3'd1)),
            "LGOOD_n out of HdrSeq order")

  // ---------------------------------------------------- L3
  `USB3_CHK(a_l3_trans, "USB3_L3", vif.ltssm != $past(vif.ltssm) |->
      ($past(vif.ltssm) == RXDET && vif.ltssm == PLFPS) ||
      ($past(vif.ltssm) == PLFPS && vif.ltssm inside {PACT, RXDET}) ||
      ($past(vif.ltssm) == PACT  && vif.ltssm inside {PCFG, HRST, RXDET}) ||
      ($past(vif.ltssm) == PCFG  && vif.ltssm inside {U0, HRST, RXDET}) ||
      ($past(vif.ltssm) == U0    && vif.ltssm inside {U1, U2, U3, RACT}) ||
      ($past(vif.ltssm) == U1    && vif.ltssm inside {U2, RACT}) ||
      ($past(vif.ltssm) inside {U2, U3} && vif.ltssm == RACT) ||
      ($past(vif.ltssm) == RACT  && vif.ltssm inside {RCFG, HRST, RXDET}) ||
      ($past(vif.ltssm) == RCFG  && vif.ltssm inside {U0, HRST, RXDET}) ||
      ($past(vif.ltssm) == HRST  && vif.ltssm inside {U0, RXDET}),
      "illegal LTSSM transition")
  `USB3_CHK(a_l3_rxdet, "USB3_L3", $past(vif.ltssm) == RXDET && vif.ltssm == PLFPS |-> $past(vif.far_end_ready),
            "Polling without a far-end termination")
  `USB3_CHK(a_l3_u0, "USB3_L3", $past(vif.ltssm) inside {PCFG, RCFG, HRST} && vif.ltssm == U0 |->
                                $past(vif.rx_valid && vif.rx_kind == 3'd1), "U0 entered without a TS2")
  `USB3_CHK(a_l3_ux_exit, "USB3_L3", $past(vif.ltssm) inside {U1, U2, U3} && vif.ltssm == RACT |-> $past(vif.lfps),
            "Ux left without LFPS")
  `USB3_CHK(a_l3_gen2, "USB3_L3", $past(vif.ltssm) != PLFPS && $past(vif.ltssm) != RXDET |-> $stable(vif.gen2),
            "Gen1/Gen2 changed outside Polling.LFPS")
  `USB3_CHK(a_l3_hrst, "USB3_L3", $past(vif.ltssm) != HRST && vif.ltssm == HRST |-> $past(rx_ts && vif.rx_ts_reset),
            "Hot Reset without a TS carrying the reset bit")

  // ---------------------------------------------------- L4
  `USB3_CHK(a_l4_ux, "USB3_L4", $past(vif.ltssm) == U0 && vif.ltssm inside {U1, U2, U3} |-> $past(rx_lpma && lau_seen),
            "Ux entered without LAU and LPMA")
  `USB3_CHK(a_l4_lau, "USB3_L4", lc_out && (lc_ct == 4'b0101 || lc_ct == 4'b0110) |-> lgo_open,
            "LAU/LXU without an LGO_Ux")
  `USB3_CHK(a_l4_u2, "USB3_L4", $past(vif.ltssm) == U1 && vif.ltssm == U2 |-> $past(vif.u2_tmo) != 8'd0,
            "U1 -> U2 with the inactivity timeout off")
  `USB3_CHK(a_l4_buf, "USB3_L4", vif.rx_free < $past(vif.rx_free) |-> $past(rx_hdr && vif.ltssm == U0),
            "receive buffer taken without a header")

  // ---------------------------------------------------- L5
  `USB3_CHK(a_l5_fix, "USB3_L5", vif.blk_fix != $past(vif.blk_fix) |-> $past(vif.gen2 && vif.rx_valid && blk_n == 3'd1),
            "block header correction without a 1-bit error")
  `USB3_CHK(a_l5_drop, "USB3_L5", vif.blk_drop != $past(vif.blk_drop) |-> $past(vif.gen2 && vif.rx_valid && blk_n >= 3'd2),
            "block dropped without a 2+ bit error")
  `USB3_CHK(a_l5_bad, "USB3_L5", vif.hp_bad != $past(vif.hp_bad) |-> $past(rx_hdr && hdr_bad),
            "bad-header count without a CRC error")
  `USB3_CHK(a_l5_dpp, "USB3_L5", vif.dpp_good != $past(vif.dpp_good) |-> $past(vif.rx_valid && vif.rx_kind == 3'd4 && vif.rx_last),
            "DPP completed without its CRC-32 word")
  `USB3_CHK(a_l5_itp, "USB3_L5", vif.itp_cnt != $past(vif.itp_cnt) |-> $past(rx_hdr && vif.rx_hdr[4:0] == 5'b01100),
            "ITP counted without an ITP header")

  // ---------------------------------------------------- covers
  c_u0_gen1:  cover property (@(posedge vif.clk) vif.ltssm == U0 && !vif.gen2);
  c_u0_gen2:  cover property (@(posedge vif.clk) vif.ltssm == U0 && vif.gen2);
  c_u1_u2:    cover property (@(posedge vif.clk) $past(vif.ltssm) == U1 && vif.ltssm == U2);
  c_u3:       cover property (@(posedge vif.clk) vif.ltssm == U3);
  c_hrst:     cover property (@(posedge vif.clk) $past(vif.ltssm) == HRST && vif.ltssm == U0);
  c_lbad:     cover property (@(posedge vif.clk) lc_out && lc_ct == 4'b0011);
  c_lrty:     cover property (@(posedge vif.clk) lc_out && lc_ct == 4'b0010);
  c_lau:      cover property (@(posedge vif.clk) lc_out && lc_ct == 4'b0101);
  c_lxu:      cover property (@(posedge vif.clk) lc_out && lc_ct == 4'b0110);
  c_hp_sent:  cover property (@(posedge vif.clk) vif.tx_hp_valid);
  c_blk_fix:  cover property (@(posedge vif.clk) vif.blk_fix != $past(vif.blk_fix));
  c_rec_tmo:  cover property (@(posedge vif.clk) $past(vif.ltssm) == RACT && vif.ltssm == RXDET);

  `undef USB3_CHK
endmodule

`endif
