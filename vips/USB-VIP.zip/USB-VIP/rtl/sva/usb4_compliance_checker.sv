// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// USB4 lane adapter / transport layer compliance checker on usb4_link_if.
// Every violation is a UVM_ERROR.
//   L1 signal sanity   (4)  legal lane states, no X, sent words known,
//                           width 1 or 2
//   L2 training        (5)  each answered ordered set matches the training
//                           step it closes; CL_ACK only into CLx, CL_NAK
//                           only staying in CL0; only answer codes sent
//   L3 lane states     (5)  legal transitions on both lanes, lane detect
//                           loss -> CLd, width 2 only with both lanes in
//                           CL0, Gen 3 decided at the end of TS1
//   L4 transport       (4)  words only in CL0, first / last framing, HEC
//                           of every header, word count = Length
//   L5 counters        (3)  counters step by one, forwards end a packet,
//                           a retrain restarts lane 0 from Lock
`ifndef USB4_COMPLIANCE_CHECKER_SV
`define USB4_COMPLIANCE_CHECKER_SV

module usb4_compliance_checker (usb4_link_if vif);
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam logic [2:0] CLD = 3'd0, LOCK = 3'd1, TS1 = 3'd2, TS2 = 3'd3, CL0 = 3'd4, CLX = 3'd5;
  localparam logic [2:0] O_SLOS = 3'd0, O_TS1 = 3'd1, O_TS2 = 3'd2, O_ACK = 3'd6, O_NAK = 3'd7;

  function automatic logic [7:0] hec8(input logic [23:0] d);
    logic [7:0] c;
    c = 8'h00;
    for (int i = 23; i >= 0; i--) c = (c[7] ^ d[i]) ? ({c[6:0], 1'b0} ^ 8'h07) : {c[6:0], 1'b0};
    return c;
  endfunction
  function automatic bit legal(input logic [2:0] a, input logic [2:0] b);
    if (a == b || b == CLD) return 1'b1;
    case (a)
      CLD:  return b == LOCK;
      LOCK: return b == TS1;
      TS1:  return b == TS2;
      TS2:  return b == CL0;
      CL0:  return b == CLX || b == LOCK;
      CLX:  return b == TS2;
      default: return 1'b0;
    endcase
  endfunction

  // ---------------------------------------------------- bookkeeping
  wire [2:0] os_ls  = vif.tx_os_lane ? vif.ls1 : vif.ls0;
  logic [2:0] os_ls_q;
  logic       in_f;
  logic [7:0] left;          // payload words still due in the frame
  always @(posedge vif.clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin in_f <= 1'b0; left <= 8'd0; end
    else if (vif.tx_valid === 1'b1) begin
      if (vif.tx_first) begin in_f <= !vif.tx_last; left <= {2'b00, vif.tx_data[15:10]}; end
      else begin left <= left - 8'd1; if (vif.tx_last) in_f <= 1'b0; end
    end
    else if (vif.ls0 != CL0) in_f <= 1'b0;
  end

  `define U4_CHK(LBL, NAME, PROP, MSG) \
    LBL: assert property (@(posedge vif.clk) disable iff (!vif.rst_n) PROP) \
      else `uvm_error(NAME, MSG)

  // ---------------------------------------------------- L1
  `U4_CHK(a_l1_state, "USB4_L1", vif.ls0 <= CLX && vif.ls1 <= CLX, "illegal lane state code")
  `U4_CHK(a_l1_known, "USB4_L1", !$isunknown({vif.ls0, vif.ls1, vif.tx_valid, vif.tx_os_valid, vif.width, vif.gen3}),
          "X/Z on lane state, valids, width or gen3")
  `U4_CHK(a_l1_word, "USB4_L1", vif.tx_valid |-> !$isunknown({vif.tx_first, vif.tx_last, vif.tx_data}),
          "X/Z in a sent word")
  `U4_CHK(a_l1_width, "USB4_L1", vif.width inside {2'd1, 2'd2}, "width is neither 1 nor 2")

  // ---------------------------------------------------- L2
  `U4_CHK(a_l2_code, "USB4_L2", vif.tx_os_valid |-> vif.tx_os_kind inside {O_SLOS, O_TS1, O_TS2, O_ACK, O_NAK},
          "adapter sent an ordered set it may not send")
  `U4_CHK(a_l2_slos, "USB4_L2", (vif.tx_os_valid && vif.tx_os_kind == O_SLOS) |->
                                (os_ls == TS1 && (vif.tx_os_lane ? $past(vif.ls1) : $past(vif.ls0)) == LOCK),
          "SLOS answer without leaving Lock for TS1")
  `U4_CHK(a_l2_ts1, "USB4_L2", (vif.tx_os_valid && vif.tx_os_kind == O_TS1) |->
                               (os_ls == TS2 && (vif.tx_os_lane ? $past(vif.ls1) : $past(vif.ls0)) == TS1),
          "TS1 answer without leaving TS1 for TS2")
  `U4_CHK(a_l2_ts2, "USB4_L2", (vif.tx_os_valid && vif.tx_os_kind == O_TS2) |->
                               (os_ls == CL0 && (vif.tx_os_lane ? $past(vif.ls1) : $past(vif.ls0)) == TS2),
          "TS2 answer without entering CL0")
  `U4_CHK(a_l2_clx, "USB4_L2", (vif.tx_os_valid && vif.tx_os_kind >= O_ACK) |->
                               (!vif.tx_os_lane && $past(vif.ls0) == CL0 &&
                                (vif.tx_os_kind == O_ACK ? vif.ls0 == CLX : vif.ls0 != CLX)),
          "CL_ACK / CL_NAK does not match the lane 0 state")

  // ---------------------------------------------------- L3
  `U4_CHK(a_l3_ls0, "USB4_L3", legal($past(vif.ls0), vif.ls0), "illegal lane 0 transition")
  `U4_CHK(a_l3_ls1, "USB4_L3", legal($past(vif.ls1), vif.ls1), "illegal lane 1 transition")
  `U4_CHK(a_l3_det, "USB4_L3", (!vif.lane_det[0] |=> vif.ls0 == CLD) and (!vif.lane_det[1] |=> vif.ls1 == CLD),
          "lane not detected but not in CLd")
  `U4_CHK(a_l3_width, "USB4_L3", vif.width == 2'd2 |-> (vif.ls0 == CL0 && vif.ls1 == CL0),
          "width 2 without both lanes in CL0")
  `U4_CHK(a_l3_gen3, "USB4_L3", $changed(vif.gen3) |-> ($past(vif.ls0) == TS1 && vif.ls0 == TS2),
          "Gen 3 changed outside the end of Training.TS1")

  // ---------------------------------------------------- L4
  `U4_CHK(a_l4_cl0, "USB4_L4", vif.tx_valid |-> vif.ls0 == CL0, "word sent outside CL0")
  `U4_CHK(a_l4_frame, "USB4_L4", vif.tx_valid |-> (vif.tx_first == !in_f), "first / last framing broken")
  `U4_CHK(a_l4_hec, "USB4_L4", (vif.tx_valid && vif.tx_first) |-> vif.tx_data[7:0] == hec8(vif.tx_data[31:8]),
          "header with a bad HEC")
  `U4_CHK(a_l4_len, "USB4_L4", vif.tx_valid |-> (vif.tx_last == (vif.tx_first ? vif.tx_data[15:10] == 6'd0 : left == 8'd1)),
          "packet length does not match its header")

  // ---------------------------------------------------- L5
  `U4_CHK(a_l5_step, "USB4_L5", (vif.fwd_cnt - $past(vif.fwd_cnt) <= 8'd1) && (vif.hec_err - $past(vif.hec_err) <= 8'd1) &&
                                (vif.fec_unc - $past(vif.fec_unc) <= 8'd1) && (vif.ovf_err - $past(vif.ovf_err) <= 8'd1),
          "a counter jumped by more than one")
  `U4_CHK(a_l5_fwd, "USB4_L5", vif.fwd_cnt != $past(vif.fwd_cnt) |-> $past(vif.w_valid && vif.w_last),
          "forward counted without the end of a received packet")
  `U4_CHK(a_l5_retrain, "USB4_L5", vif.retrains != $past(vif.retrains) |-> vif.ls0 == LOCK,
          "retrain counted without lane 0 back in Lock")

  // ---------------------------------------------------- covers
  c_gen3:     cover property (@(posedge vif.clk) vif.ls0 == CL0 && vif.gen3);
  c_bonded:   cover property (@(posedge vif.clk) vif.width == 2'd2);
  c_clx:      cover property (@(posedge vif.clk) vif.ls0 == CLX);
  c_ack:      cover property (@(posedge vif.clk) vif.tx_os_valid && vif.tx_os_kind == O_ACK);
  c_nak:      cover property (@(posedge vif.clk) vif.tx_os_valid && vif.tx_os_kind == O_NAK);
  c_retrain:  cover property (@(posedge vif.clk) vif.retrains != $past(vif.retrains));
  c_tmo:      cover property (@(posedge vif.clk) vif.train_tmo != $past(vif.train_tmo));
  c_corr:     cover property (@(posedge vif.clk) vif.fec_corr != $past(vif.fec_corr));
  c_ovf:      cover property (@(posedge vif.clk) vif.ovf_err != $past(vif.ovf_err));
  c_dup:      cover property (@(posedge vif.clk) vif.dup_cnt != $past(vif.dup_cnt));
  c_notif:    cover property (@(posedge vif.clk) vif.tx_valid && vif.tx_first && vif.tx_data[31:28] == 4'd5);
  c_cg:       cover property (@(posedge vif.clk) vif.tx_valid && vif.tx_first && vif.tx_data[31:28] == 4'hC);

  `undef U4_CHK
endmodule

`endif
