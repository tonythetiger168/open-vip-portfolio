// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// USB Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 19
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
// L4=USB protocol-specific rules
`ifndef USB_COMPLIANCE_CHECKER_SV
`define USB_COMPLIANCE_CHECKER_SV

module usb_compliance_checker (usb_vip_if vif);
  import uvm_pkg::*;
  import usb_vip_pkg::*;
  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov=0; l2_cov=0; l3_cov=0; l4_cov=0; total_cov=0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_usb_pid_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid |-> vif.mac_pid[3:0] ^ vif.mac_pid[7:4] == 4'b1111; endproperty
  assert_p_usb_pid_valid: assert property(p_usb_pid_valid) l1_pass[0]++; else begin `uvm_warning("USB_L1", "PID valid failed"); l1_fail[0]++; end
  cover_p_usb_pid_valid: cover property(p_usb_pid_valid);
  property p_usb_token_crc5; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid && vif.mac_pid[3:0] inside {4'b0001,4'b1001,4'b0101,4'b1101} |-> vif.mac_crc_ok; endproperty
  assert_p_usb_token_crc5: assert property(p_usb_token_crc5) l1_pass[1]++; else begin `uvm_warning("USB_L1", "Token CRC5 failed"); l1_fail[1]++; end
  cover_p_usb_token_crc5: cover property(p_usb_token_crc5);
  property p_usb_data_crc16; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid && vif.mac_pid[3:0] inside {4'b0011,4'b1011} |-> vif.mac_crc_ok; endproperty
  assert_p_usb_data_crc16: assert property(p_usb_data_crc16) l1_pass[2]++; else begin `uvm_warning("USB_L1", "Data CRC16 failed"); l1_fail[2]++; end
  cover_p_usb_data_crc16: cover property(p_usb_data_crc16);
  property p_usb_addr_range; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid |-> vif.mac_addr <= 7'd127; endproperty
  assert_p_usb_addr_range: assert property(p_usb_addr_range) l1_pass[3]++; else begin `uvm_warning("USB_L1", "Addr 0-127 failed"); l1_fail[3]++; end
  cover_p_usb_addr_range: cover property(p_usb_addr_range);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_usb_ep_range; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid |-> vif.mac_endpoint <= 4'd15; endproperty
  assert_p_usb_ep_range: assert property(p_usb_ep_range) l2_pass[0]++; else begin `uvm_warning("USB_L2", "EP 0-15 failed"); l2_fail[0]++; end
  cover_p_usb_ep_range: cover property(p_usb_ep_range);
  property p_usb_sop_eop; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_eop |-> $past(vif.mac_sop,1) || vif.mac_sop; endproperty
  assert_p_usb_sop_eop: assert property(p_usb_sop_eop) l2_pass[1]++; else begin `uvm_warning("USB_L2", "SOP before EOP failed"); l2_fail[1]++; end
  cover_p_usb_sop_eop: cover property(p_usb_sop_eop);
  property p_usb_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_valid |-> !$isunknown(vif.mac_data); endproperty
  assert_p_usb_no_x: assert property(p_usb_no_x) l2_pass[2]++; else begin `uvm_warning("USB_L2", "No X when valid failed"); l2_fail[2]++; end
  cover_p_usb_no_x: cover property(p_usb_no_x);
  property p_usb_frame_range; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_frame_num <= 11'd2047; endproperty
  assert_p_usb_frame_range: assert property(p_usb_frame_range) l2_pass[3]++; else begin `uvm_warning("USB_L2", "Frame 0-2047 failed"); l2_fail[3]++; end
  cover_p_usb_frame_range: cover property(p_usb_frame_range);
  property p_usb_sof_period; @(posedge vif.clk) disable iff (!vif.rst_n) vif.mac_pid == 8'hA5 |-> ##[11900:12100] vif.mac_pid == 8'hA5; endproperty
  assert_p_usb_sof_period: assert property(p_usb_sof_period) l2_pass[4]++; else begin `uvm_warning("USB_L2", "SOF every 1ms failed"); l2_fail[4]++; end
  cover_p_usb_sof_period: cover property(p_usb_sof_period);
  property p_usb_hs_preamble; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_preamble |-> vif.mac_pid == 8'hC0; endproperty
  assert_p_usb_hs_preamble: assert property(p_usb_hs_preamble) l2_pass[5]++; else begin `uvm_warning("USB_L2", "HS preamble failed"); l2_fail[5]++; end
  cover_p_usb_hs_preamble: cover property(p_usb_hs_preamble);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: an OUT/SETUP/IN token must be answered by a DATA or handshake packet inside 16 cycles
  property p_usb_l3_token_rsp; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b0001,4'b1101,4'b1001})
    |-> ##[1:16] (vif.mac_valid && vif.mac_pid[3:0] inside {4'b0011,4'b1011,4'b0111,4'b1111,4'b0010,4'b1010,4'b1110,4'b0110}); endproperty
  assert_p_usb_l3_token_rsp: assert property(p_usb_l3_token_rsp) l3_pass[0]++; else begin `uvm_warning("USB_L3", "Token not answered by data/handshake failed"); l3_fail[0]++; end
  cover_p_usb_l3_token_rsp: cover property(p_usb_l3_token_rsp);
  // L3-2: a handshake packet (ACK/NAK/STALL/NYET) only follows a completed packet
  property p_usb_l3_hs_after_eop; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b0010,4'b1010,4'b1110,4'b0110})
    |-> ($past(vif.mac_eop,1) || $past(vif.mac_eop,2) || $past(vif.mac_eop,3)); endproperty
  assert_p_usb_l3_hs_after_eop: assert property(p_usb_l3_hs_after_eop) l3_pass[1]++; else begin `uvm_warning("USB_L3", "Handshake without preceding packet failed"); l3_fail[1]++; end
  cover_p_usb_l3_hs_after_eop: cover property(p_usb_l3_hs_after_eop);
  // L3-3: SE1 is an illegal line state
  property p_usb_l3_no_se1; @(posedge vif.clk) disable iff (!vif.rst_n) vif.utmi_linestate != 2'b11; endproperty
  assert_p_usb_l3_no_se1: assert property(p_usb_l3_no_se1) l3_pass[2]++; else begin `uvm_warning("USB_L3", "Illegal SE1 line state failed"); l3_fail[2]++; end
  cover_p_usb_l3_no_se1: cover property(p_usb_l3_no_se1);
  // L3-4: UTMI TXVALID must hold until TXREADY accepts the byte
  property p_usb_l3_tx_hold; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.utmi_txvalid && !vif.utmi_txready) |=> vif.utmi_txvalid; endproperty
  assert_p_usb_l3_tx_hold: assert property(p_usb_l3_tx_hold) l3_pass[3]++; else begin `uvm_warning("USB_L3", "TXVALID dropped before TXREADY failed"); l3_fail[3]++; end
  cover_p_usb_l3_tx_hold: cover property(p_usb_l3_tx_hold);

  // ---------------- L4: USB protocol-specific rules (5) ----------------
  // L4-1: an addressed token (OUT/SETUP/IN) must complete with a handshake
  //       or a timeout inside 32 cycles (turnaround time bound)
  property p_usb_l4_turnaround; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b0001,4'b1101,4'b1001} &&
    vif.mac_addr inside {7'h20, 7'h00}
    |-> ##[1:32] (vif.utmi_rxvalid || !vif.mac_valid); endproperty
  assert_p_usb_l4_turnaround: assert property(p_usb_l4_turnaround) l4_pass[0]++; else begin `uvm_warning("USB_L4", "Token turnaround failed"); l4_fail[0]++; end
  cover_p_usb_l4_turnaround: cover property(p_usb_l4_turnaround);
  // L4-2: DATA payload phase must end with EOP within 80 beats (no babble)
  property p_usb_l4_data_eop; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.mac_valid && vif.mac_sop && vif.mac_pid[3:0] inside {4'b0011,4'b1011,4'b0111,4'b1111}
    |-> ##[1:80] vif.mac_eop; endproperty
  assert_p_usb_l4_data_eop: assert property(p_usb_l4_data_eop) l4_pass[1]++; else begin `uvm_warning("USB_L4", "DATA packet without EOP (babble)"); l4_fail[1]++; end
  cover_p_usb_l4_data_eop: cover property(p_usb_l4_data_eop);
  // L4-3: bus reset (dev_reset) forces SE0 on the line and RESET device state
  property p_usb_l4_reset_se0; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.dev_reset |-> (vif.utmi_linestate == 2'b00 && vif.dev_state == USB_STATE_RESET); endproperty
  assert_p_usb_l4_reset_se0: assert property(p_usb_l4_reset_se0) l4_pass[2]++; else begin `uvm_warning("USB_L4", "Reset without SE0/RESET state"); l4_fail[2]++; end
  cover_p_usb_l4_reset_se0: cover property(p_usb_l4_reset_se0);
  // L4-4: device state machine advances RESET -> DEFAULT -> ADDRESS -> CONFIGURED
  property p_usb_l4_fsm_legal; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.dev_state == USB_STATE_RESET |=> vif.dev_state inside {USB_STATE_RESET, USB_STATE_DEFAULT}; endproperty
  assert_p_usb_l4_fsm_legal: assert property(p_usb_l4_fsm_legal) l4_pass[3]++; else begin `uvm_warning("USB_L4", "Illegal FSM exit from RESET"); l4_fail[3]++; end
  cover_p_usb_l4_fsm_legal: cover property(p_usb_l4_fsm_legal);
  // L4-5: HS chirp response appears on linestate while host chirps (K or J)
  property p_usb_l4_chirp; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.utmi_xcvr_select == 2'b01 && vif.utmi_op_mode == 2'b10 && vif.utmi_term_select)
    |-> vif.utmi_linestate inside {2'b01, 2'b10}; endproperty
  assert_p_usb_l4_chirp: assert property(p_usb_l4_chirp) l4_pass[4]++; else begin `uvm_warning("USB_L4", "HS chirp response invalid"); l4_fail[4]++; end
  cover_p_usb_l4_chirp: cover property(p_usb_l4_chirp);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l1_hit=0, l2_hit=0, l3_hit=0;
    int l4_total=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("USB_RPT", $sformatf("=== USB Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("USB_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("USB_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("USB_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("USB_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("USB_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end

endmodule
`endif
