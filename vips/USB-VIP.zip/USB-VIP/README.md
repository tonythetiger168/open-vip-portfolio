# USB Protocol VIP — Unified Multi-Protocol Verification IP

## 協議概述 (Protocol Overview)

本 VIP 驗證 USB 系列協議的 MAC + PHY 雙層行為，單一環境涵蓋 7 種協議：

| Protocol | Speed | PHY Interface | 說明 |
|----------|-------|---------------|------|
| USB 2.0 (HS/FS/LS) | 480/12/1.5 Mbps | UTMI/ULPI | token/data/handshake packet、NRZI/bit-stuff、HS chirp |
| USB 3.0/3.1/3.2 (SS/SS+/SS20) | 5/10/20 Gbps | PIPE | header/data packet、LTSSM、CRC32 |
| USB4 | 40 Gbps | PIPE4 | control/tunneled block、SB-10B sync、router sideband |
| eUSB2 | 480 Mbps | ULPI | 1.2V single-ended embedded USB2 |
| USB-PD | — | SBU (CC/BMC) | SOP* message、GoodCRC、contract negotiation |

## 架構 (Architecture)

```
top_tb.sv
 ├─ usb_vip_if × 7 (MAC + PHY 雙層, clocking blocks, modports, IF assertions)
 └─ usb_dut (functional DUT model)
     ├─ usb2_dev_ep ×2     USB2/eUSB2 device endpoint: chirp response,
     │                      CRC16 檢查, ACK/STALL/timeout, babble detect
     ├─ usb3_phy_model ×3  PIPE PHY: LTSSM walk→U0, CRC32 check, loopback ACK
     ├─ usb4_phy_model     PIPE4 PHY: link ready, router sideband, loopback
     └─ pd_controller_model PD controller: header decode, Vbus transition
usb_env
 ├─ usb_agent × 7 (usb_sequencer / usb_driver / usb_monitor)
 ├─ usb_scoreboard  expected(drv_ap→exp_imp) vs observed(mon→analysis_imp)
 │                   pairwise compare, n_matches/n_mismatches, UVM_ERROR on mismatch
 ├─ usb_coverage_model × 4 (8 covergroups, 見下)
 └─ *_protocol_checker × 5 (procedural protocol checks + covergroups)
```

Closed loop：driver 依 transaction descriptor 送出 token/data packet
（含 CRC16/CRC32 trailer，data packet 以 `mac_frame_num` 作 sideband byte count），
DUT 依位址/endpoint/CRC 決定 ACK/STALL/timeout/babble，monitor 從 MAC/PHY
波形解碼 PID→packet type、重組 payload（剝除 CRC trailer）、觀察 handshake，
scoreboard 端到端比對。

## Sequence 清單

| Sequence | 類型 | 說明 |
|----------|------|------|
| `usb_base_sequence` | base | 共用參數/constraint |
| `usb_random_sequence` | random | protocol-weighted 隨機流量 (90% 打到 DUT 位址) |
| `usb_normal_seq` | directed | 正常 SETUP/IN/OUT/DATA, ACK 路徑 |
| `usb_error_inject_seq` | directed | CRC 腐敗 / timeout(未實作位址) / STALL(EP15) / babble(超長) |
| `usb_reset_seq` | directed | bus reset (SE0) 後重新列舉 |
| `usb_back_to_back_seq` | directed | 最小 inter-packet gap (=2) 背靠背 |
| `usb_stress_seq` | directed | 大 payload (256–512B) 高速率壓力 |
| `usb_corner_seq` | directed | ZLP / 1-byte / max-packet / DATA0-DATA1 toggle / 邊界 EP |
| `usb_sof_seq` | directed | SOF frame stream (11-bit frame number) |
| `usb_regression_sequence` | regression | 加權混合 regression |
| `usb_directed_regression_sequence` | regression | directed library 全掃 |

Tests：`usb_random_regression_test` (預設), `usb_directed_test`,
`usb_hs_test`, `usb_ss_test`, `usb_ssp_test`, `usb_ss20_test`,
`usb4_test`, `usb_eusb2_test`, `usb_pd_test`。

## SVA 清單 (rtl/sva/usb_compliance_checker.sv, module)

- **L1 Basic (4)**：PID complement、token CRC5、data CRC16、addr 0–127
- **L2 Full Protocol (6)**：EP 0–15、SOP→EOP、no-X when valid、frame 0–2047、
  SOF 1ms period、HS preamble
- **L3 Advanced (0)**：保留層級 (placeholder)
- **L4 USB 專屬 (5)**：token turnaround bound、DATA payload EOP (anti-babble)、
  bus reset→SE0+RESET state、FSM RESET→DEFAULT 合法遞移、HS chirp linestate 回應

Interface 內建 assertions：valid/ready handshake、SOP-EOP alignment、
PID encoding、device state、UTMI linestate (SE1 illegal)、PIPE power state、
PIPE4 link ready、PD Vbus range。

vip/*/​*_protocol_checker (class, procedural checks)：
`usb2` PID/CRC5/CRC16/timeout/bit-stuff/handshake/linestate；
`usb3` LFPS timeout/TS1-TS2/CRC32/link recovery/U0-link；
`usb4` SB-10B sync/link-ready/polarity/tunnel CRC/CL0；
`eusb2` ULPI cmd/reg/PID/CRC5/CRC16/SE1；
`usbpd` BMC differential/GoodCRC tReceive/Vbus safe/contract min/PD CRC32。

## Functional Coverage 清單

`usb_coverage_model` (8 covergroups，含 cross)：
`cg_txn_type` (protocol×type cross)、`cg_endpoint` (ep×type cross)、
`cg_packet_size` (size×protocol cross)、`cg_device_state` (FSM transition bins,
state×protocol cross)、`cg_phy_layer` (phy_if×term cross)、
`cg_pd_contract` (contract×voltage cross)、`cg_error_injection` (err×recovery cross)、
`cg_data_pattern` (first-byte pattern×length cross)。
Interface covergroup：`cg_usb_interface` (MAC handshake × device state cross)。
各 protocol checker 另有專屬 covergroup + cross。

## 快速上手 (Quick Start)

```sh
cd scripts
make compile           # VCS: pkg → checkers → if → sequences → env → tests → tb
make simulate TEST=usb_random_regression_test
make simulate TEST=usb_directed_test
make coverage          # 見 scripts/coverage.mk
```

環境變數 `TEST` 選擇測試；`UVM_VERBOSITY` 控制訊息等級。
regression 結束時 scoreboard 回報 `n_matches/n_mismatches`，
compliance checker 回報 L1/L2/L3/L4 tiered coverage。
