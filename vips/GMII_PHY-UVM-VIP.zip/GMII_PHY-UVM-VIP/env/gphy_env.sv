// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gphy_env.sv -- GPHY environment: reference-model scoreboard, checker, coverage

package gphy_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import gphy_defs_pkg::*;
  import gphy_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class gphy_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(gphy_scoreboard)
    uvm_analysis_imp_exp #(gphy_transaction, gphy_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(gphy_transaction, gphy_scoreboard) obs_ap;

    gphy_config cfg;
    gphy_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(gphy_config)::get(this, "", "cfg", cfg))
        cfg = gphy_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(gphy_transaction t);
      // the MAC receiver on the burst, then its end (grx_dv low)
      int st = 0, rn = 0;          // 0 idle 1 preamble 2 data 3 drop
      bit [31:0] rc = 0;
      bit perr = 0, acc = 0;
      bit [7:0] d [$];
      bit [47:0] da = 0;
      bit [15:0] ty = 0, op = 0;
      t.rxo.delete(); t.rst.delete(); t.nfrag = 0; t.txo.delete();
      foreach (t.rxb[i]) begin
        bit [7:0] b = t.rxb[i][7:0];
        case (st)
          0, 1: if (b == 8'hD5) begin st = 2; rn = 0; rc = 32'hFFFF_FFFF; perr = 0; acc = 0; d.delete(); end
                else if (b == 8'h55) st = 1;
                else begin st = 3; t.nfrag++; end
          2: begin
               rc = gphy_crc(rc, b); d.push_back(b);
               if (t.rxb[i][8]) perr = 1;
               if (rn < 6) da = {da[39:0], b};
               if (rn == 5) acc = da == cfg.mac || da == 48'hFFFF_FFFF_FFFF || da == 48'h01_80_C2_00_00_01;
               if (rn == 12 || rn == 13) ty = {ty[7:0], b};
               if (rn == 14 || rn == 15) op = {op[7:0], b};
               rn++;
             end
          default: ;
        endcase
      end
      if (st == 1) t.nfrag++;
      if (st == 2 && rn < 6) t.nfrag++;
      else if (st == 2 && acc) begin
        bit ce = rc != 32'hDEBB20E3;
        bit le = rn < 64 || rn > ((ty == 16'h8100) ? 1522 : 1518);
        bit pz = ty == 16'h8808 && op == 16'h0001 && rn >= 18;
        for (int i = 0; i < rn - 4; i++) t.rxo.push_back(d[i]);
        t.rst.push_back({pz, perr, le, ce});
        if (!(pz || perr || le || ce)) begin
          bit [7:0] e [$];
          bit [31:0] c = 32'hFFFF_FFFF;
          int m = rn - 18;
          bit [15:0] et = {d[12], d[13]};
          for (int i = 6; i < 12; i++) e.push_back(d[i]);
          for (int j = 5; j >= 0; j--) e.push_back(cfg.mac[8 * j +: 8]);
          e.push_back(d[12]); e.push_back(d[13]);
          if (et < 16'h0600 && et < m) m = et;
          for (int i = 0; i < m; i++) e.push_back(d[14 + i]);
          while (e.size() < 60) e.push_back(8'h00);
          foreach (e[i]) c = gphy_crc(c, e[i]);
          repeat (7) t.txo.push_back({1'b0, 8'h55});
          t.txo.push_back({1'b0, 8'hD5});
          foreach (e[i]) t.txo.push_back({1'b0, e[i]});
          for (int k = 0; k < 4; k++) t.txo.push_back({1'b0, ~c[8 * k +: 8]});
        end
      end
    endfunction

    function void write_exp(gphy_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(gphy_transaction t);
      gphy_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        gphy_transaction e = exp_q.pop_front();
        gphy_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("gphy scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class gphy_env extends uvm_env;
    `uvm_component_utils(gphy_env)
    gphy_agent      agt;
    gphy_scoreboard sb;
    gphy_checker    chk;
    gphy_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = gphy_agent     ::type_id::create("agt", this);
      sb  = gphy_scoreboard::type_id::create("sb",  this);
      chk = gphy_checker   ::type_id::create("chk", this);
      cov = gphy_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
