// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (GPHY DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened gphy_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [7:0] grxd = 8'h00;
  logic grx_dv = 1'b0, grx_er = 1'b0;
  wire [7:0] gtxd, rx_data;
  wire gtx_en, gtx_er, tx_paused, rx_valid, rx_last, rx_frag;
  wire [3:0] rx_stat;
  localparam logic [47:0] MAC = 48'h02_00_5E_10_00_01;

  always #5 clk = ~clk;

  gphy_model u_dut (.clk(clk), .rst_n(rst_n), .grxd(grxd), .grx_dv(grx_dv), .grx_er(grx_er), .gtxd(gtxd),
                    .gtx_en(gtx_en), .gtx_er(gtx_er), .tx_paused(tx_paused), .rx_valid(rx_valid),
                    .rx_data(rx_data), .rx_last(rx_last), .rx_stat(rx_stat), .rx_frag(rx_frag));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [31:0] crc8(input logic [31:0] c, input logic [7:0] d);
    logic [31:0] r;
    r = c;
    for (int i = 0; i < 8; i++) r = (r[0] ^ d[i]) ? (r >> 1) ^ 32'hEDB88320 : r >> 1;
    crc8 = r;
  endfunction

  logic [7:0] fb [0:2047];
  integer fn = 0;
  // frame without FCS: da, sa 02:11:22:33:44:55, type / length, n payload bytes
  task automatic mk(input logic [47:0] da, input logic [15:0] et, input integer n);
    logic [47:0] sa;
    sa = 48'h02_11_22_33_44_55;
    for (int i = 0; i < 6; i++) begin fb[i] = da[8 * (5 - i) +: 8]; fb[6 + i] = sa[8 * (5 - i) +: 8]; end
    fb[12] = et[15:8]; fb[13] = et[7:0];
    for (int i = 0; i < n; i++) fb[14 + i] = 8'h21 + i * 7;
    fn = 14 + n;
  endtask
  task automatic fcs();
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < 2048; i++) if (i < fn) c = crc8(c, fb[i]);
    for (int i = 0; i < 4; i++) fb[fn + i] = ~c[8 * i +: 8];
    fn = fn + 4;
  endtask

  logic [7:0] ob [0:2047], tb [0:2047];
  integer on = 0, nlast = 0, nfr = 0, tn = 0, tph = 0, ntx = 0;
  logic [3:0] lst;
  always @(posedge clk) begin
    if (rx_valid) begin ob[on] = rx_data; on = on + 1; end
    if (rx_valid && rx_last) begin nlast = nlast + 1; lst = rx_stat; end
    if (rx_frag) nfr = nfr + 1;
    if (gtx_en) begin
      if (tph == 0) begin tb[tn] = gtxd; tn = tn + 1; if (gtx_er) ntx = ntx + 1; end
      tph = (tph + 1) % 2;
    end else tph = 0;
  end
  // one burst: np preamble bytes (byte 3 = bad if >= 0), SFD unless nosfd, the first cut bytes of fb
  // (all when -1), grx_er on byte erb; then wait until the MAC is quiet unless nowait
  task automatic send(input integer np = 7, input integer cut = -1, input integer erb = -1, input integer bad = -1,
                      input logic nosfd = 0, input logic nowait = 0);
    integer n, q;
    on = 0; nlast = 0; nfr = 0; tn = 0;
    n = (cut < 0) ? fn : cut;
    for (int i = 0; i < np; i++) begin @(negedge clk); grx_dv = 1; grxd = (i == bad) ? 8'h54 : 8'h55; @(negedge clk); end
    if (!nosfd) begin @(negedge clk); grx_dv = 1; grxd = 8'hD5; @(negedge clk); end
    if (!nosfd) for (int i = 0; i < n; i++) begin
      @(negedge clk); grx_dv = 1; grxd = fb[i]; grx_er = (i == erb); @(negedge clk);
    end
    @(negedge clk); grx_dv = 0; grxd = 0; grx_er = 0;
    q = 0;
    if (!nowait) while (q < 30) begin @(negedge clk); if (gtx_en || tx_paused) q = 0; else q = q + 1; end
    else repeat (8) @(negedge clk);
  endtask
  function automatic logic got_rx(input logic [3:0] st);
    logic ok;
    ok = nlast == 1 && lst == st && on == fn - 4 && nfr == 0;
    for (int i = 0; i < 2048; i++) if (i < fn - 4 && ob[i] !== fb[i]) ok = 0;
    got_rx = ok;
  endfunction
  function automatic logic nothing();
    nothing = on == 0 && nlast == 0 && tn == 0;
  endfunction
  // expected loopback frame: m data bytes
  function automatic logic got_tx(input integer m);
    logic [7:0] e [0:2047];
    logic [31:0] c;
    integer en;
    logic ok;
    for (int i = 0; i < 6; i++) begin e[i] = fb[6 + i]; e[6 + i] = MAC[8 * (5 - i) +: 8]; end
    e[12] = fb[12]; e[13] = fb[13];
    for (int i = 0; i < 2048; i++) if (i >= 14) e[i] = (i < 14 + m) ? fb[i] : 8'h00;
    en = (14 + m < 60) ? 60 : 14 + m;
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < 2048; i++) if (i < en) c = crc8(c, e[i]);
    ok = tn == 8 + en + 4 && ntx == 0;
    for (int i = 0; i < 7; i++) if (tb[i] !== 8'h55) ok = 0;
    if (tb[7] !== 8'hD5) ok = 0;
    for (int i = 0; i < 2048; i++) if (i < en && tb[8 + i] !== e[i]) ok = 0;
    for (int i = 0; i < 4; i++) if (tb[8 + en + i] !== ~c[8 * i +: 8]) ok = 0;
    got_tx = ok;
  endfunction
  time tp, te;

  initial begin
    repeat (3) @(posedge clk);
    chk(rx_valid === 1'b0 && gtx_en === 1'b0 && rx_frag === 1'b0, "nothing out in reset");
    rst_n = 1;
    repeat (40) @(negedge clk);
    chk(on == 0 && nfr == 0 && tn == 0 && tx_paused == 0, "quiet after reset");
    mk(MAC, 16'h0800, 100); fcs(); send();
    chk(got_rx(4'h0) && got_tx(100), "frame to the MAC: delivered without FCS, sent back with swapped addresses");
    mk(48'hFFFF_FFFF_FFFF, 16'h0800, 46); fcs(); send();
    chk(got_rx(4'h0) && got_tx(46), "broadcast, 64 bytes: sent back without padding");
    mk(MAC ^ 48'h1, 16'h0800, 60); fcs(); send();
    chk(nothing() && nfr == 0, "other unicast: dropped silently");
    mk(48'h01_00_5E_00_00_FB, 16'h0800, 60); fcs(); send();
    chk(nothing(), "multicast: dropped");
    mk(MAC, 16'h0800, 60); fcs(); fb[fn - 2] = fb[fn - 2] ^ 8'h10; send();
    chk(got_rx(4'h1) && tn == 0, "FCS error: crc_err, not sent back");
    mk(MAC, 16'h0800, 60); fcs(); send(7, -1, 33);
    chk(got_rx(4'h4) && tn == 0, "grx_er: phy_err");
    mk(MAC, 16'h0800, 20); fcs(); send();
    chk(got_rx(4'h2) && tn == 0, "38-byte runt: len_err");
    mk(MAC, 16'h0800, 1501); fcs(); send();
    chk(got_rx(4'h2) && tn == 0, "1519 bytes: len_err");
    mk(MAC, 16'h0800, 1500); fcs(); send();
    chk(got_rx(4'h0) && got_tx(1500), "1518 bytes: good");
    mk(MAC, 16'h8100, 1504); fcs(); send();
    chk(got_rx(4'h0) && got_tx(1504), "VLAN-tagged 1522 bytes: good");
    mk(MAC, 16'd20, 46); fcs(); send();
    chk(got_rx(4'h0) && got_tx(20), "length field 20: 20 data bytes sent back, padded to 60");
    mk(MAC, 16'd100, 60); fcs(); send();
    chk(got_rx(4'h0) && got_tx(60), "length field longer than the frame: all of it");
    mk(MAC, 16'h0600, 50); fcs(); send();
    chk(got_rx(4'h0) && got_tx(50), "type 0x0600 is not a length");
    mk(48'h01_80_C2_00_00_01, 16'h8808, 46); fb[14] = 0; fb[15] = 1; fb[16] = 0; fb[17] = 2; fcs(); send(7, -1, -1, -1, 0, 1);
    chk(nlast == 1 && lst == 4'h8 && tn == 0 && tx_paused == 1, "PAUSE quanta 2: pause status, transmitter held");
    tp = $time;
    mk(MAC, 16'h0800, 46); fcs(); send();
    te = $time;
    chk(got_rx(4'h0) && got_tx(46), "frame during the pause is sent back after it");
    chk(te - tp >= 2 * 64 * 20, "pause lasted at least 128 byte times");
    mk(48'h01_80_C2_00_00_01, 16'h8808, 46); fb[14] = 0; fb[15] = 2; fb[16] = 0; fb[17] = 2; fcs(); send();
    chk(got_rx(4'h0) && got_tx(46) && tx_paused == 0, "MAC control opcode 2: not a PAUSE");
    mk(48'h01_80_C2_00_00_01, 16'h8808, 46); fb[14] = 0; fb[15] = 1; fb[16] = 0; fb[17] = 2; fcs();
    fb[fn - 1] = ~fb[fn - 1]; send();
    chk(got_rx(4'h9) && tx_paused == 0, "PAUSE with an FCS error is not honoured");
    mk(MAC, 16'h0800, 60); fcs(); send(7, -1, -1, 3);
    chk(nothing() && nfr == 1, "bad preamble byte: fragment");
    mk(MAC, 16'h0800, 60); fcs(); send(0);
    chk(got_rx(4'h0) && got_tx(60), "SFD without preamble");
    mk(MAC, 16'h0800, 60); fcs(); send(15);
    chk(got_rx(4'h0) && got_tx(60), "15-byte preamble");
    mk(MAC, 16'h0800, 60); fcs(); send(7, 3);
    chk(nothing() && nfr == 1, "frame cut after 3 bytes: fragment");
    mk(MAC, 16'h0800, 60); fcs(); send(7, 6);
    chk(nlast == 1 && lst == 4'h3 && on == 2 && nfr == 0, "6-byte frame: delivered with crc and len errors");
    mk(MAC, 16'h0800, 60); fcs(); send(7, -1, -1, -1, 1);
    chk(nothing() && nfr == 1, "preamble only: fragment");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
