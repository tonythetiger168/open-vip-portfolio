// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- GPHY testbench top with a functional GPHY DUT model

`ifndef GMII_PHY_UVM_VIP_TB_SV
`define GMII_PHY_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import gphy_defs_pkg::*;
import gphy_pkg::*;
import gphy_env_pkg::*;
import gphy_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  gphy_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  gphy_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .grxd(vif.grxd),
    .grx_dv(vif.grx_dv),
    .grx_er(vif.grx_er),
    .gtxd(vif.gtxd),
    .gtx_en(vif.gtx_en),
    .gtx_er(vif.gtx_er),
    .tx_paused(vif.tx_paused),
    .rx_valid(vif.rx_valid),
    .rx_data(vif.rx_data),
    .rx_last(vif.rx_last),
    .rx_stat(vif.rx_stat),
    .rx_frag(vif.rx_frag)
  );

  // Concurrent protocol checks
  gphy_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .grxd(vif.grxd),
    .grx_dv(vif.grx_dv),
    .grx_er(vif.grx_er),
    .gtxd(vif.gtxd),
    .gtx_en(vif.gtx_en),
    .gtx_er(vif.gtx_er),
    .tx_paused(vif.tx_paused),
    .rx_valid(vif.rx_valid),
    .rx_data(vif.rx_data),
    .rx_last(vif.rx_last),
    .rx_stat(vif.rx_stat),
    .rx_frag(vif.rx_frag)
  );

  initial begin
    uvm_config_db#(virtual gphy_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module gphy_model #(
  parameter logic [4:0]  DIV      = 5'd1,
  parameter logic [47:0] MAC      = 48'h02_00_5E_10_00_01,
  parameter bit          PAUSE_EN = 1'b1
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [7:0]  grxd,
  input  logic        grx_dv,
  input  logic        grx_er,
  output logic [7:0]  gtxd,
  output logic        gtx_en,
  output logic        gtx_er,
  output logic        tx_paused,
  output logic        rx_valid,
  output logic [7:0]  rx_data,
  output logic        rx_last,
  output logic [3:0]  rx_stat,
  output logic        rx_frag
);
  localparam logic [47:0] PAUSE_DA = 48'h0180C2000001;
  localparam logic [31:0] RESIDUE = 32'hDEBB20E3;
  localparam logic [2:0] T_IDLE = 3'd0, T_PRE = 3'd1, T_DATA = 3'd2, T_PAD = 3'd3, T_FCS = 3'd4, T_IFG = 3'd5;
  localparam logic [2:0] R_IDLE = 3'd0, R_PRE = 3'd1, R_DATA = 3'd2, R_DROP = 3'd3, R_FL1 = 3'd4, R_FL2 = 3'd5;
  function automatic logic [31:0] crc8(input logic [31:0] c, input logic [7:0] d);
    logic [31:0] r;
    r = c;
    for (int i = 0; i < 8; i++) r = (r[0] ^ d[i]) ? (r >> 1) ^ 32'hEDB88320 : r >> 1;
    crc8 = r;
  endfunction

  logic [4:0]  dc;
  wire         ls = dc == DIV;
  logic [2:0]  ts, rs;
  logic [3:0]  tk;
  logic [5:0]  tn;
  logic [31:0] tcrc, rcrc;
  logic [21:0] pause;
  logic [10:0] rn;
  logic [7:0]  p0, p1, p2, p3, p4, p5;
  logic [39:0] da;
  logic [15:0] rtype, ropc, rq;
  logic        acc, perr;
  // loopback client: received bytes, then the frame to send back
  logic [7:0]  rbuf [0:2047];
  logic [10:0] ridx, eidx, elen;
  logic        echo;
  wire  [7:0]  ebyte = (eidx < 11'd6) ? rbuf[eidx + 11'd6] : (eidx < 11'd12) ? MAC[8 * (11 - eidx) +: 8] : rbuf[eidx];
  wire  [15:0] et = {rbuf[12], rbuf[13]};

  assign tx_paused = pause != 22'd0;

  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin
      dc <= '0; ts <= T_IDLE; tk <= '0; tn <= '0; tcrc <= '0; pause <= '0;
      gtxd <= '0; gtx_en <= 1'b0; gtx_er <= 1'b0;
      rs <= R_IDLE; rn <= '0; rcrc <= '0; {p0, p1, p2, p3, p4, p5} <= '0; da <= '0;
      rtype <= '0; ropc <= '0; rq <= '0; acc <= 1'b0; perr <= 1'b0;
      rx_valid <= 1'b0; rx_data <= '0; rx_last <= 1'b0; rx_stat <= '0; rx_frag <= 1'b0;
      ridx <= '0; eidx <= '0; elen <= '0; echo <= 1'b0;
    end else begin
      rx_valid <= 1'b0; rx_frag <= 1'b0;
      dc <= ls ? 5'd0 : dc + 5'd1;
      if (ls) begin
        if (pause != 22'd0) pause <= pause - 22'd1;
        // ---- transmit (host stream from the loopback client, never late)
        case (ts)
          T_IDLE: if (echo && pause == 22'd0) begin
            ts <= T_PRE; tk <= 4'd1; gtx_en <= 1'b1; gtxd <= 8'h55;
          end
          T_PRE: begin
            tk <= tk + 4'd1;
            gtxd <= tk == 4'd7 ? 8'hD5 : 8'h55;
            if (tk == 4'd7) begin ts <= T_DATA; tn <= '0; tcrc <= '1; end
          end
          T_DATA: begin
            gtxd <= ebyte; tcrc <= crc8(tcrc, ebyte);
            if (tn != 6'd60) tn <= tn + 6'd1;
            eidx <= eidx + 11'd1;
            if (eidx == elen - 11'd1) begin
              echo <= 1'b0;
              if (tn >= 6'd59) ts <= T_FCS; else ts <= T_PAD;
              tk <= '0;
            end
          end
          T_PAD: begin
            gtxd <= 8'h00; tcrc <= crc8(tcrc, 8'h00); tn <= tn + 6'd1;
            if (tn == 6'd59) ts <= T_FCS;
          end
          T_FCS: begin
            gtxd <= ~tcrc[8 * tk[1:0] +: 8];
            tk <= tk + 4'd1;
            if (tk == 4'd3) begin ts <= T_IFG; tk <= '0; end
          end
          T_IFG: begin
            gtx_en <= 1'b0; gtx_er <= 1'b0; gtxd <= 8'h00;
            tk <= tk + 4'd1;
            if (tk == 4'd11) ts <= T_IDLE;
          end
          default: ts <= T_IDLE;
        endcase
        // ---- receive
        case (rs)
          R_IDLE, R_PRE: if (!grx_dv) begin
            if (rs == R_PRE) rx_frag <= 1'b1;
            rs <= R_IDLE;
          end else if (grxd == 8'hD5) begin
            rs <= R_DATA; rn <= '0; rcrc <= '1; perr <= 1'b0; acc <= 1'b0; ridx <= '0;
          end else if (grxd == 8'h55) rs <= R_PRE;
          else begin rs <= R_DROP; rx_frag <= 1'b1; end
          R_DATA: if (grx_dv) begin : b_byte
            logic [47:0] d2;
            rcrc <= crc8(rcrc, grxd);
            if (rn != 11'h7FF) rn <= rn + 11'd1;
            if (grx_er) perr <= 1'b1;
            {p5, p4, p3, p2, p1, p0} <= {p4, p3, p2, p1, p0, grxd};
            d2 = {da, grxd};
            if (rn < 11'd6) da <= d2[39:0];
            if (rn == 11'd5) acc <= d2 == MAC || d2 == 48'hFFFF_FFFF_FFFF || d2 == PAUSE_DA;
            if (rn == 11'd12 || rn == 11'd13) rtype <= {rtype[7:0], grxd};
            if (rn == 11'd14 || rn == 11'd15) ropc <= {ropc[7:0], grxd};
            if (rn == 11'd16 || rn == 11'd17) rq <= {rq[7:0], grxd};
            if (rn >= 11'd6 && acc) begin
              rx_valid <= 1'b1; rx_data <= p5; rx_last <= 1'b0;
              rbuf[ridx] <= p5; ridx <= ridx + 11'd1;
            end
          end else if (rn < 11'd6) begin rs <= R_IDLE; rx_frag <= 1'b1; end
          else if (acc) rs <= R_FL1; else rs <= R_IDLE;
          R_DROP: if (!grx_dv) rs <= R_IDLE;
          R_FL1: begin
            rx_valid <= 1'b1; rx_data <= p5; rx_last <= 1'b0; rs <= R_FL2;
            rbuf[ridx] <= p5; ridx <= ridx + 11'd1;
          end
          R_FL2: begin : b_end
            logic crc_e, len_e, pz;
            logic [10:0] m;
            crc_e = rcrc != RESIDUE;
            len_e = rn < 11'd64 || rn > (rtype == 16'h8100 ? 11'd1522 : 11'd1518);
            pz = rtype == 16'h8808 && ropc == 16'h0001 && rn >= 11'd18;
            rx_valid <= 1'b1; rx_data <= p4; rx_last <= 1'b1;
            rx_stat <= {pz, perr, len_e, crc_e};
            rbuf[ridx] <= p4;
            if (pz && PAUSE_EN && !crc_e && !len_e && !perr) pause <= {rq, 6'd0};
            if (!pz && !crc_e && !len_e && !perr) begin
              m = rn - 11'd18;
              if (et < 16'h0600 && et < {5'd0, m}) m = et[10:0];
              elen <= 11'd14 + m; eidx <= '0; echo <= 1'b1;
            end
            rs <= R_IDLE;
          end
          default: rs <= R_IDLE;
        endcase
      end
    end
endmodule
`endif
