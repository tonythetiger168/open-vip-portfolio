// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gphy_driver.svh -- GPHY driver: one burst per item: the preamble, SFD and frame bytes on grxd with grx_dv, each held cfg.bt clocks; then the line idles until the MAC has been quiet (no gtx_en, no tx_paused) for 12 byte times, plus cfg.ifg byte times

class gphy_driver extends uvm_driver #(gphy_transaction);
  `uvm_component_utils(gphy_driver)

  uvm_analysis_port #(gphy_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual gphy_if vif;
  gphy_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual gphy_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gphy: virtual interface not set")
    if (!uvm_config_db#(gphy_config)::get(this, "", "cfg", cfg))
      cfg = gphy_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    gphy_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.grxd   <= 8'h00;
    vif.drv_cb.grx_dv <= 1'b0;
    vif.drv_cb.grx_er <= 1'b0;
  endtask

  task drive_item(gphy_transaction t);
    int q = 0;
    t.build(cfg.mac);
    @(vif.drv_cb);
    foreach (t.rxb[i]) begin
      vif.drv_cb.grx_dv <= 1'b1;
      vif.drv_cb.grxd   <= t.rxb[i][7:0];
      vif.drv_cb.grx_er <= t.rxb[i][8];
      repeat (cfg.bt) @(vif.drv_cb);
    end
    vif.drv_cb.grx_dv <= 1'b0;
    vif.drv_cb.grxd   <= 8'h00;
    vif.drv_cb.grx_er <= 1'b0;
    while (q < 12 * cfg.bt) begin
      @(vif.drv_cb);
      if (vif.drv_cb.gtx_en || vif.drv_cb.tx_paused) q = 0; else q++;
    end
    repeat (cfg.ifg * cfg.bt) @(vif.drv_cb);
  endtask

endclass
