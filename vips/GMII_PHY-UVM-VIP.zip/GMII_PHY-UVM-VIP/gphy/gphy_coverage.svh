// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gphy_coverage.svh -- GPHY functional coverage

class gphy_coverage extends uvm_subscriber #(gphy_transaction);
  `uvm_component_utils(gphy_coverage)
  gphy_config cfg;
  gphy_transaction tr;

  covergroup gphy_cg;
    cp_stat : coverpoint tr.stat_of() { bins ok = {0}; bins crc = {1}; bins len = {2}; bins phy = {4}; bins pause = {8};
                                        bins none = {16}; }
    cp_echo : coverpoint tr.txo.size() { bins none = {0}; bins min = {72}; bins mid = {[73:600]}; bins max = {[1500:1530]}; }
    cp_frag : coverpoint tr.nfrag { bins no = {0}; bins yes = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    gphy_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(gphy_config)::get(this, "", "cfg", cfg))
      cfg = gphy_config::type_id::create("cfg");
  endfunction

  function void write(gphy_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    gphy_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("GPHY coverage: %0.1f%%", gphy_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
