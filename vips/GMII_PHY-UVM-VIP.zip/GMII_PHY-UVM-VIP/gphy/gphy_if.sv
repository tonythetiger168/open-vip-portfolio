// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gphy_if.sv -- GPHY interface

interface gphy_if (input logic clk);
  logic rst_n;

  logic [7:0] grxd;
  logic grx_dv;
  logic grx_er;
  logic [7:0] gtxd;
  logic gtx_en;
  logic gtx_er;
  logic tx_paused;
  logic rx_valid;
  logic [7:0] rx_data;
  logic rx_last;
  logic [3:0] rx_stat;
  logic rx_frag;

  modport DUT (input clk, rst_n, input grxd, input grx_dv, input grx_er, output gtxd, output gtx_en, output gtx_er, output tx_paused, output rx_valid, output rx_data, output rx_last, output rx_stat, output rx_frag);
  modport MON (input clk, rst_n, grxd, grx_dv, grx_er, gtxd, gtx_en, gtx_er, tx_paused, rx_valid, rx_data, rx_last, rx_stat, rx_frag);

  clocking drv_cb @(posedge clk);
    input rst_n, gtxd, gtx_en, gtx_er, tx_paused, rx_valid, rx_data, rx_last, rx_stat, rx_frag;
    inout grxd, grx_dv, grx_er;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, grxd, grx_dv, grx_er, gtxd, gtx_en, gtx_er, tx_paused, rx_valid, rx_data, rx_last, rx_stat, rx_frag;
  endclocking
endinterface
