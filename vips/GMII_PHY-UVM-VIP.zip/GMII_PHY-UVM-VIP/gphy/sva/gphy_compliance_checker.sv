// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gphy_compliance_checker.sv -- GPHY concurrent assertion checks (bindable)

module gphy_compliance_checker
  (input logic clk, input logic rst_n, input logic [7:0] grxd, input logic grx_dv, input logic grx_er, input logic [7:0] gtxd, input logic gtx_en, input logic gtx_er, input logic tx_paused, input logic rx_valid, input logic [7:0] rx_data, input logic rx_last, input logic [3:0] rx_stat, input logic rx_frag);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({grx_dv, gtx_en, rx_valid, rx_frag, tx_paused}))
    else $error("GPHY: X on a control");
  assert property (@(posedge clk) disable iff (!rst_n) grx_dv |-> !$isunknown({grxd, grx_er}))
    else $error("GPHY: X on grxd inside a frame");
  assert property (@(posedge clk) disable iff (!rst_n) gtx_en |-> !$isunknown({gtxd, gtx_er}))
    else $error("GPHY: X on gtxd inside a frame");
  assert property (@(posedge clk) disable iff (!rst_n) rx_frag |-> !rx_valid)
    else $error("GPHY: fragment pulse with a host byte");
  assert property (@(posedge clk) disable iff (!rst_n) gtx_er |-> gtx_en)
    else $error("GPHY: gtx_er outside a frame");
  cover property (@(posedge clk) disable iff (!rst_n) $rose(tx_paused));
  cover property (@(posedge clk) disable iff (!rst_n) rx_valid && rx_last && rx_stat == 4'h0);
endmodule
