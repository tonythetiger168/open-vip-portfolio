// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gphy_sequences.svh -- GPHY sequences

// Random traffic: cfg.num_items constrained-random items.
class gphy_base_sequence extends uvm_sequence #(gphy_transaction);
  `uvm_object_utils(gphy_base_sequence)
  gphy_config cfg;

  function new(string name = "gphy_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = gphy_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "gphy_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class gphy_directed_sequence extends uvm_sequence #(gphy_transaction);
  `uvm_object_utils(gphy_directed_sequence)
  gphy_config cfg;

  function new(string name = "gphy_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function gphy_transaction item();
    item = gphy_transaction::type_id::create("req");
  endfunction

  task send(gphy_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    gphy_transaction t;
    // each filter decision, each error, PAUSE, preamble cases, size limits, length-field padding
    t = item(); t.set(0, 54, 32'h11); send(t);
    t = item(); t.set(5, 30, 32'h12); send(t);
    for (int k = 10; k < 32; k++) begin t = item(); t.set(k, 7 * k, 32'h100 + k); send(t); end
    t = item(); t.set(18, 0, 32'h2); send(t);
    t = item(); t.set(0, 199, 32'h3); send(t);
    for (int i = 0; i < 6; i++) begin t = item(); t.set(27, 5 + 9 * i, 32'h200 + i); send(t); end
  endtask
endclass
