// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gphy_monitor.svh -- GPHY monitor: from grx_dv rising: the received bytes (one per byte time), the host stream, status and fragment pulses, and the next frame on gtxd, until the MAC has been quiet for 12 byte times

class gphy_monitor extends uvm_monitor;
  `uvm_component_utils(gphy_monitor)

  virtual gphy_if vif;
  uvm_analysis_port #(gphy_transaction) ap;
  gphy_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual gphy_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gphy: virtual interface not set")
    if (!uvm_config_db#(gphy_config)::get(this, "", "cfg", cfg))
      cfg = gphy_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        gphy_transaction t;
        int k = 0, tk = -1, q = 0;
        bit in_rx = 1;
        while (vif.mon_cb.grx_dv !== 1'b1) @(vif.mon_cb);
        t = gphy_transaction::type_id::create("t");
        t.nfrag = 0;
        forever begin
          if (vif.mon_cb.rx_valid === 1'b1) begin
            t.rxo.push_back(vif.mon_cb.rx_data);
            if (vif.mon_cb.rx_last === 1'b1) t.rst.push_back(vif.mon_cb.rx_stat);
          end
          if (vif.mon_cb.rx_frag === 1'b1) t.nfrag++;
          if (in_rx) begin
            if (k % cfg.bt == 0) begin
              if (vif.mon_cb.grx_dv !== 1'b1) in_rx = 0;
              else t.rxb.push_back({vif.mon_cb.grx_er, vif.mon_cb.grxd});
            end
            k++;
          end
          if (tk < 0 && vif.mon_cb.gtx_en === 1'b1) tk = 0;
          if (tk >= 0) begin
            if (tk % cfg.bt == 0) begin
              if (vif.mon_cb.gtx_en !== 1'b1) tk = -2;
              else t.txo.push_back({vif.mon_cb.gtx_er, vif.mon_cb.gtxd});
            end
            if (tk >= 0) tk++;
          end
          if (!in_rx) begin
            if (vif.mon_cb.gtx_en === 1'b1 || vif.mon_cb.tx_paused === 1'b1) q = 0; else q++;
            if (q == 12 * cfg.bt) break;
          end
          @(vif.mon_cb);
        end
        publish(t);
      end
    end
  endtask

  function void publish(gphy_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
