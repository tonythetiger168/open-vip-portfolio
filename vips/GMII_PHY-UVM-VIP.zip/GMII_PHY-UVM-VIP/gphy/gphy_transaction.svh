// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gphy_transaction.svh -- GPHY transaction

class gphy_transaction extends uvm_sequence_item;
  `uvm_object_utils(gphy_transaction)

  // request (driven by the agent)
  bit [8:0] rxb[$];
  // response (returned by the DUT)
  bit [7:0] rxo[$];
  bit [3:0] rst[$];
  bit [3:0] nfrag;
  bit [8:0] txo[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [10:0] len;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "gphy_transaction"); super.new(name); endfunction

  // kind: 0-4 frame to the MAC (type 0x0800), 5-9 the same with a length field,
  // 10 broadcast, 11 other unicast, 12 multicast, 13 FCS error, 14 grx_er,
  // 15 runt (38 bytes), 16 1519 bytes, 17 VLAN 1522 bytes, 18 PAUSE, 19 MAC
  // control opcode 2, 20 bad preamble byte, 21 no preamble (SFD only),
  // 22 cut after 1-5 bytes, 23 preamble only, 24 15-byte preamble, 25 64
  // bytes, 26 1518 bytes, 27-28 short length field, 29-31 frame to the MAC
  function void set(int k, int l = 60, bit [31:0] s = 32'h1); kind = k; len = l; seed = s; endfunction
  function int stat_of(); return rst.size() ? rst[0] : 16; endfunction
  function void build(bit [47:0] mac);
    bit [31:0] x = seed | 1;
    bit [7:0] f [$];
    bit [31:0] c = 32'hFFFF_FFFF;
    bit [47:0] da = mac, sa = 48'h02_11_22_33_44_55 ^ {16'h0, seed};
    bit [15:0] et = 16'h0800;
    int n = 46 + len % 200, np = 7, cut = -1;
    if (kind inside {[5:9]}) et = len % 120;
    case (kind)
      10: da = 48'hFFFF_FFFF_FFFF;
      11: da = mac ^ 48'h1;
      12: da = 48'h01_00_5E_00_00_FB;
      15: n = 20;
      16: n = 1501;
      17: begin et = 16'h8100; n = 1504; end
      18, 19: begin da = 48'h01_80_C2_00_00_01; et = 16'h8808; n = 46; end
      21: np = 0;
      22: cut = 1 + x[15:8] % 5;
      24: np = 15;
      25: n = 46;
      26: n = 1500;
      27, 28: et = len % 46;
      default: ;
    endcase
    for (int i = 5; i >= 0; i--) f.push_back(da[8 * i +: 8]);
    for (int i = 5; i >= 0; i--) f.push_back(sa[8 * i +: 8]);
    f.push_back(et[15:8]); f.push_back(et[7:0]);
    for (int i = 0; i < n; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      f.push_back(x[7:0]);
    end
    if (kind == 18 || kind == 19) begin
      f[14] = 8'h00; f[15] = (kind == 18) ? 8'h01 : 8'h02; f[16] = 8'h00; f[17] = 1 + seed[1:0] % 3;
    end
    foreach (f[i]) c = gphy_crc(c, f[i]);
    for (int i = 0; i < 4; i++) f.push_back(~c[8 * i +: 8]);
    if (kind == 13) f[f.size() - 1 - x[1:0]][x[4:2]] ^= 1'b1;
    rxb.delete();
    for (int i = 0; i < np; i++) rxb.push_back({1'b0, (kind == 20 && i == 3) ? 8'h54 : 8'h55});
    if (kind == 23) return;
    rxb.push_back({1'b0, 8'hD5});
    foreach (f[i]) begin
      if (cut >= 0 && i == cut) break;
      rxb.push_back({kind == 14 && i == 20 + x[5:0], f[i]});
    end
  endfunction

  function void do_copy(uvm_object rhs);
    gphy_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    rxb = rhs_.rxb;
    rxo = rhs_.rxo;
    rst = rhs_.rst;
    nfrag = rhs_.nfrag;
    txo = rhs_.txo;
    kind = rhs_.kind;
    len = rhs_.len;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    gphy_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (rxb.size() != rhs_.rxb.size()) return 0;
    foreach (rxb[i]) if (rxb[i] != rhs_.rxb[i]) return 0;
    if (rxo.size() != rhs_.rxo.size()) return 0;
    foreach (rxo[i]) if (rxo[i] != rhs_.rxo[i]) return 0;
    if (rst.size() != rhs_.rst.size()) return 0;
    foreach (rst[i]) if (rst[i] != rhs_.rst[i]) return 0;
    if (nfrag != rhs_.nfrag) return 0;
    if (txo.size() != rhs_.txo.size()) return 0;
    foreach (txo[i]) if (txo[i] != rhs_.txo[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(gphy_transaction rhs_);
    if (rxb.size() != rhs_.rxb.size()) return 0;
    foreach (rxb[i]) if (rxb[i] != rhs_.rxb[i]) return 0;
    return 1;
  endfunction

  function string qstr_rxb();
    string s = $sformatf("[%0d]{", rxb.size());
    foreach (rxb[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rxb[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rxo();
    string s = $sformatf("[%0d]{", rxo.size());
    foreach (rxo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rxo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rst();
    string s = $sformatf("[%0d]{", rst.size());
    foreach (rst[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rst[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_txo();
    string s = $sformatf("[%0d]{", txo.size());
    foreach (txo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", txo[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("GPHY{tag=%0d rxb=%s rxo=%s rst=%s nfrag=0x%0h txo=%s}", tag, qstr_rxb(), qstr_rxo(), qstr_rst(), nfrag, qstr_txo());
  endfunction
endclass
