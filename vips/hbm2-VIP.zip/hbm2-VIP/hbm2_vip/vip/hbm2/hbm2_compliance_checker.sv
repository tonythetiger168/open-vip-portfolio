// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm2_compliance_checker.sv -- HBM2 SVA compliance checker
// L1 = signal sanity, L2 = timing & data integrity, L3 = error handling,
// L4 = HBM2 protocol-specific rules (timing parameters, bank-state
// legality, refresh servicing). Instantiated in tb_top.
// HBM2 stacked DRAM: 8 channels x 2 pseudo-channels per stack, stack_id selects the die stack.

`ifndef HBM2_COMPLIANCE_CHECKER_SV
`define HBM2_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module hbm2_compliance_checker (hbm2_if vif);

  // ---------------- L1: signal sanity (4) ----------------
  property p_hbm2_cmd_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_hbm2_cmd_valid: assert property(p_hbm2_cmd_valid) else `uvm_warning("HBM2", "Command valid failed");
  cover_p_hbm2_cmd_valid: cover property(p_hbm2_cmd_valid);
  property p_hbm2_addr_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.addr); endproperty
  assert_p_hbm2_addr_valid: assert property(p_hbm2_addr_valid) else `uvm_warning("HBM2", "Address valid failed");
  cover_p_hbm2_addr_valid: cover property(p_hbm2_addr_valid);
  property p_hbm2_pseudo_ch; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pseudo_ch <= 1'b1; endproperty
  assert_p_hbm2_pseudo_ch: assert property(p_hbm2_pseudo_ch) else `uvm_warning("HBM2", "Pseudo channel 0-1 failed");
  cover_p_hbm2_pseudo_ch: cover property(p_hbm2_pseudo_ch);
  property p_hbm2_stack_id; @(posedge vif.ck) disable iff (!vif.rst_n) vif.stack_id <= 2'd3; endproperty
  assert_p_hbm2_stack_id: assert property(p_hbm2_stack_id) else `uvm_warning("HBM2", "Stack ID 0-3 failed");
  cover_p_hbm2_stack_id: cover property(p_hbm2_stack_id);

  // ---------------- L2: timing & data integrity (8) ----------------
  property p_hbm2_tRCD; @(posedge vif.ck) disable iff (!vif.rst_n) $fell(vif.cs_n) |-> ##[14:18] vif.ca[4] == 0; endproperty
  assert_p_hbm2_tRCD: assert property(p_hbm2_tRCD) else `uvm_warning("HBM2", "tRCD 14-18 cycles failed");
  cover_p_hbm2_tRCD: cover property(p_hbm2_tRCD);
  property p_hbm2_tRP; @(posedge vif.ck) disable iff (!vif.rst_n) $rose(vif.cs_n) |-> ##[14:18] $fell(vif.cs_n); endproperty
  assert_p_hbm2_tRP: assert property(p_hbm2_tRP) else `uvm_warning("HBM2", "tRP 14-18 cycles failed");
  cover_p_hbm2_tRP: cover property(p_hbm2_tRP);
  property p_hbm2_bl; @(posedge vif.ck) disable iff (!vif.rst_n) vif.bl inside {3'b001,3'b010,3'b011}; endproperty
  assert_p_hbm2_bl: assert property(p_hbm2_bl) else `uvm_warning("HBM2", "Burst length 2/4/8 failed");
  cover_p_hbm2_bl: cover property(p_hbm2_bl);
  property p_hbm2_data_valid; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dqs_t == 1 |-> !$isunknown(vif.dq); endproperty
  assert_p_hbm2_data_valid: assert property(p_hbm2_data_valid) else `uvm_warning("HBM2", "Data valid failed");
  cover_p_hbm2_data_valid: cover property(p_hbm2_data_valid);
  property p_hbm2_dbis; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dbis == 1 |-> vif.dqs_t == 1; endproperty
  assert_p_hbm2_dbis: assert property(p_hbm2_dbis) else `uvm_warning("HBM2", "DBI valid failed");
  cover_p_hbm2_dbis: cover property(p_hbm2_dbis);
  property p_hbm2_temp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp <= 8'd127; endproperty
  assert_p_hbm2_temp: assert property(p_hbm2_temp) else `uvm_warning("HBM2", "Temperature failed");
  cover_p_hbm2_temp: cover property(p_hbm2_temp);
  property p_hbm2_no_x; @(posedge vif.ck) disable iff (!vif.rst_n) vif.cs_n == 0 |-> !$isunknown(vif.ca); endproperty
  assert_p_hbm2_no_x: assert property(p_hbm2_no_x) else `uvm_warning("HBM2", "No X when active failed");
  cover_p_hbm2_no_x: cover property(p_hbm2_no_x);
  property p_hbm2_reset; @(posedge vif.ck) disable iff (!vif.rst_n) vif.rst_n == 0 |-> ##[100:200] vif.rst_n == 1; endproperty
  assert_p_hbm2_reset: assert property(p_hbm2_reset) else `uvm_warning("HBM2", "Reset stable failed");
  cover_p_hbm2_reset: cover property(p_hbm2_reset);

  // ---------------- L3: error handling (6) ----------------
  property p_hbm2_pm; @(posedge vif.ck) disable iff (!vif.rst_n) vif.pm_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_hbm2_pm: assert property(p_hbm2_pm) else `uvm_warning("HBM2", "Power management failed");
  cover_p_hbm2_pm: cover property(p_hbm2_pm);
  property p_hbm2_refresh; @(posedge vif.ck) disable iff (!vif.rst_n) vif.refresh |-> ##[1:3900] vif.cs_n == 0; endproperty
  assert_p_hbm2_refresh: assert property(p_hbm2_refresh) else `uvm_warning("HBM2", "Refresh interval failed");
  cover_p_hbm2_refresh: cover property(p_hbm2_refresh);
  property p_hbm2_overtemp; @(posedge vif.ck) disable iff (!vif.rst_n) vif.temp > 8'd85 |-> vif.cs_n == 1; endproperty
  assert_p_hbm2_overtemp: assert property(p_hbm2_overtemp) else `uvm_warning("HBM2", "Overtemp protection failed");
  cover_p_hbm2_overtemp: cover property(p_hbm2_overtemp);
  property p_hbm2_3ds; @(posedge vif.ck) disable iff (!vif.rst_n) vif.stack_id <= 2'd3; endproperty
  assert_p_hbm2_3ds: assert property(p_hbm2_3ds) else `uvm_warning("HBM2", "3DS valid failed");
  cover_p_hbm2_3ds: cover property(p_hbm2_3ds);
  property p_hbm2_dfe; @(posedge vif.ck) disable iff (!vif.rst_n) vif.dfe_tap <= 4'd15; endproperty
  assert_p_hbm2_dfe: assert property(p_hbm2_dfe) else `uvm_warning("HBM2", "DFE tap failed");
  cover_p_hbm2_dfe: cover property(p_hbm2_dfe);
  property p_hbm2_wck; @(posedge vif.ck) disable iff (!vif.rst_n) vif.wck_ratio inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_hbm2_wck: assert property(p_hbm2_wck) else `uvm_warning("HBM2", "WCK ratio failed");
  cover_p_hbm2_wck: cover property(p_hbm2_wck);

  // ---------------- L4: HBM2 protocol-specific rules (10) ----------------
  localparam int L4_TRCD  = 16;
  localparam int L4_TRP   = 16;
  localparam int L4_TRAS  = 20;
  localparam int L4_TRFC  = 48;
  localparam int L4_TREFI = 3900;

  // Command decode (mirrors the driver/monitor truth table)
  wire l4_act = (!vif.cs_n) && (!vif.act_n);
  wire l4_rd  = (!vif.cs_n) && vif.act_n && vif.ras_n && (!vif.cas_n) && vif.we_n;
  wire l4_wr  = (!vif.cs_n) && vif.act_n && vif.ras_n && (!vif.cas_n) && (!vif.we_n);
  wire l4_col = l4_rd || l4_wr;
  wire l4_pre = (!vif.cs_n) && vif.act_n && (!vif.ras_n) && vif.cas_n && (!vif.we_n);
  wire l4_ref = (!vif.cs_n) && vif.act_n && (!vif.ras_n) && (!vif.cas_n) && vif.we_n;
  wire [4:0] l4_bidx = {vif.bg, vif.ba};

  // Bank open/close state used by the legality rules below
  bit [31:0] l4_open;
  always @(posedge vif.ck or negedge vif.rst_n) begin
    if (!vif.rst_n) l4_open <= '0;
    else begin
      if (l4_act) l4_open[l4_bidx] <= 1'b1;
      if (l4_pre) l4_open[l4_bidx] <= 1'b0;
      if (l4_ref) l4_open <= '0;
    end
  end

  // L4-1: ACT may only target a closed (precharged) bank
  a_hbm2_l4_act_closed : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> !l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "hbm2: ACT issued to an already-active bank")
  // L4-2: RD/WR may only target an activated bank
  a_hbm2_l4_col_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_col |-> l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "hbm2: RD/WR to a non-activated bank")
  // L4-3: PRE may only target an activated bank
  a_hbm2_l4_pre_open : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_pre |-> l4_open[l4_bidx])
    else `uvm_error("SVA_L4", "hbm2: PRE to a non-activated bank")
  // L4-4: tRCD -- no column command within tRCD cycles after ACT
  a_hbm2_l4_trcd : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> ##1 (!l4_col)[*(L4_TRCD-1)])
    else `uvm_error("SVA_L4", "hbm2: tRCD violation (column command too soon after ACT)")
  // L4-5: tRP -- no ACT within tRP cycles after PRE
  a_hbm2_l4_trp : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_pre |-> ##1 (!l4_act)[*(L4_TRP-1)])
    else `uvm_error("SVA_L4", "hbm2: tRP violation (ACT too soon after PRE)")
  // L4-6: tRAS -- no PRE within tRAS cycles after ACT
  a_hbm2_l4_tras : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> ##1 (!l4_pre)[*(L4_TRAS-1)])
    else `uvm_error("SVA_L4", "hbm2: tRAS violation (PRE too soon after ACT)")
  // L4-7: refresh pulse must complete within tRFC (+2) cycles
  a_hbm2_l4_ref_pulse : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    $rose(vif.refresh) |-> ##[1:(L4_TRFC+2)] $fell(vif.refresh))
    else `uvm_error("SVA_L4", "hbm2: refresh pulse wider than tRFC")
  // L4-8: commands require CKE high
  a_hbm2_l4_cke : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    (!vif.cs_n && !vif.act_n) |-> vif.cke)
    else `uvm_error("SVA_L4", "hbm2: command issued while CKE low")

  // L4-9 (HBM): pseudo-channel select must be stable during a command cycle
  a_hbm2_l4_pseudo_ch : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    (!vif.cs_n) |-> $stable(vif.pseudo_ch))
    else `uvm_error("SVA_L4", "hbm2: pseudo-channel switched mid-command")
  // L4-10 (HBM): stack select must be known on any activate
  a_hbm2_l4_stack : assert property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act |-> !$isunknown(vif.stack_id))
    else `uvm_error("SVA_L4", "hbm2: stack_id unknown on ACT")

  // Refresh must be serviced again within tREFI after each REF command
  c_hbm2_l4_ref_interval : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_ref ##[1:(L4_TREFI)] l4_ref);
  // Full ACT -> column -> PRE bank cycle observed
  c_hbm2_l4_rw_cycle : cover property (@(posedge vif.ck) disable iff (!vif.rst_n)
    l4_act ##[1:64] l4_col ##[1:64] l4_pre);

endmodule
`endif
