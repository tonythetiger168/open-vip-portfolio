// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm2_agent.sv -- HBM2 UVM agent (sequencer + driver + monitor)

`ifndef HBM2_AGENT_SV
`define HBM2_AGENT_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
typedef class hbm2_driver;
typedef class hbm2_monitor;

class hbm2_agent extends uvm_agent;
  `uvm_component_utils(hbm2_agent)
  uvm_sequencer #(hbm2_transaction) sqr;
  hbm2_driver  drv;
  hbm2_monitor mon;

  function new(string name, uvm_component parent); super.new(name, parent); endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    sqr = uvm_sequencer #(hbm2_transaction)::type_id::create("sqr", this);
    drv = hbm2_driver::type_id::create("drv", this);
    mon = hbm2_monitor::type_id::create("mon", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
`endif
