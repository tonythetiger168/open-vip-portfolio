// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// hbm2_env.sv -- HBM2 verification environment with end-to-end scoreboard

`ifndef HBM2_ENV_SV
`define HBM2_ENV_SV
`include "uvm_macros.svh"

`uvm_analysis_imp_decl(_exp)
`uvm_analysis_imp_decl(_obs)

// End-to-end scoreboard: compares driver-issued (expected) transactions
// against monitor-decoded (observed) transactions.
class hbm2_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(hbm2_scoreboard)
  uvm_analysis_imp_exp #(hbm2_transaction, hbm2_scoreboard) exp_ap;
  uvm_analysis_imp_obs #(hbm2_transaction, hbm2_scoreboard) obs_ap;

  hbm2_transaction exp_q[$], obs_q[$];
  int unsigned n_matches = 0, n_mismatches = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    exp_ap = new("exp_ap", this);
    obs_ap = new("obs_ap", this);
  endfunction

  function void write_exp(hbm2_transaction t); exp_q.push_back(t); check(); endfunction
  function void write_obs(hbm2_transaction t); obs_q.push_back(t); check(); endfunction

  function void check();
    while (exp_q.size() && obs_q.size()) begin
      hbm2_transaction e = exp_q.pop_front();
      hbm2_transaction o = obs_q.pop_front();
      bit ok = (e.cmd == o.cmd) && (e.bg == o.bg) && (e.ba == o.ba);
      case (e.cmd)
        HBM2_CMD_ACT: ok = ok && (e.row == o.row) && (e.stack_id == o.stack_id);
        HBM2_CMD_RD:  ok = ok && (e.col == o.col) && (e.rdata == o.rdata);
        HBM2_CMD_WR:  ok = ok && (e.col == o.col) && (e.data == o.data);
        default: ; // PRE/REF/NOP: command + bank comparison is sufficient
      endcase
      if (ok) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                   e.convert2string(), o.convert2string()))
      end
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("SB", $sformatf("hbm2 scoreboard: n_matches=%0d n_mismatches=%0d",
              n_matches, n_mismatches), UVM_LOW)
    if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
  endfunction
endclass

class hbm2_env extends uvm_env;
  `uvm_component_utils(hbm2_env)
  hbm2_protocol_checker       protocol_chk;
  hbm2_data_integrity_checker di_chk;
  hbm2_timing_checker         timing_chk;
  hbm2_error_checker          error_chk;
  hbm2_agent                  agt;
  hbm2_scoreboard             sb;
  hbm2_coverage               cov;
  function new(string name="hbm2_env", uvm_component parent=null); super.new(name, parent); endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    protocol_chk = hbm2_protocol_checker::type_id::create("protocol_chk", this);
    di_chk       = hbm2_data_integrity_checker::type_id::create("di_chk", this);
    timing_chk   = hbm2_timing_checker::type_id::create("timing_chk", this);
    error_chk    = hbm2_error_checker::type_id::create("error_chk", this);
    agt = hbm2_agent::type_id::create("agt", this);
    sb  = hbm2_scoreboard::type_id::create("sb", this);
    cov = hbm2_coverage::type_id::create("cov", this);
  endfunction
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    agt.mon.ap.connect(sb.obs_ap);
    agt.drv.drv_ap.connect(sb.exp_ap);
    agt.mon.ap.connect(cov.analysis_export);
  endfunction
endclass
`endif
