// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_mem_tb.sv -- self-checking functional test for the HBM2 memory model
// (hbm2_mem_model, flattened by smoke/flatten.py). Run: python3 tools/run_func_tests.py hbm2-VIP
//
// Model contract (from tb_top.sv):
//   ACT (act_n=0) latches the row of {stack_id,bg,ba}; RD/WR (ras_n=1,cas_n=0)
//   address column addr[9:0] of the open row. A write samples dq 1 clock
//   after the command; a read drives dq on the negedge after 15 clocks
//   (TCL=16) for one clock, then releases dq to Z.
// dq is a variable shared by the model and the controller in the original
// interface, so the test writes it hierarchically (u_dut.vif_dq) exactly as
// the UVM driver writes vif.dq.

module func_mem_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam int TCL = 16;
  int checks = 0, fails = 0;

  logic        ck = 1'b0, rst_n = 1'b0;
  logic        cs_n = 1'b1, act_n = 1'b1, ras_n = 1'b1, cas_n = 1'b1, we_n = 1'b1;
  logic [15:0] addr = '0;
  logic [2:0]  bg = '0, stack_id = '0;
  logic [1:0]  ba = '0;
  wire  [63:0] dq;
  // idle value the test parks on the shared dq variable (Verilator cannot
  // write Z through a hierarchical reference); the model itself drives Z
  localparam [63:0] IDLE = 64'hD1E5_D1E5_D1E5_D1E5;

  always #5 ck = ~ck;

  hbm2_mem_model u_dut (
    .vif_ck(ck), .vif_rst_n(rst_n), .vif_cs_n(cs_n), .vif_act_n(act_n),
    .vif_ras_n(ras_n), .vif_cas_n(cas_n), .vif_we_n(we_n), .vif_addr(addr),
    .vif_bg(bg), .vif_ba(ba), .vif_dq(dq), .vif_stack_id(stack_id)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one command cycle: drive at negedge, sampled at the next posedge
  task automatic cmd(input bit a_n, input bit r_n, input bit c_n, input bit w_n,
                     input [2:0] sid, input [2:0] g, input [1:0] b, input [15:0] ad,
                     input bit sel = 1'b1);
    @(negedge ck);
    cs_n = !sel; act_n = a_n; ras_n = r_n; cas_n = c_n; we_n = w_n;
    stack_id = sid; bg = g; ba = b; addr = ad;
    @(posedge ck);
    @(negedge ck);
    cs_n = 1'b1; act_n = 1'b1; ras_n = 1'b1; cas_n = 1'b1; we_n = 1'b1;
  endtask

  task automatic act(input [2:0] sid, input [2:0] g, input [1:0] b, input [15:0] row);
    cmd(0, 1, 1, 1, sid, g, b, row);
  endtask

  // write: data must be on dq at the posedge 1 clock(s) after the command
  task automatic wr(input [2:0] sid, input [2:0] g, input [1:0] b, input [9:0] col,
                    input [63:0] d, input bit sel = 1'b1);
    cmd(1, 1, 0, 0, sid, g, b, {6'h0, col}, sel);   // returns at negedge after cmd edge
    u_dut.vif_dq = d;
    repeat (1) @(posedge ck);
    @(negedge ck);
    u_dut.vif_dq = IDLE;
  endtask

  // read: returns dq sampled one posedge after the driving negedge; also
  // reports what dq looked like one clock earlier (must still be released)
  task automatic rd(input [2:0] sid, input [2:0] g, input [1:0] b, input [9:0] col,
                    output [63:0] d, output [63:0] early);
    cmd(1, 1, 0, 1, sid, g, b, {6'h0, col});        // cmd edge = P0, now at N0
    repeat (TCL - 1) @(posedge ck);                 // P(TCL-1): not yet driven
    early = dq;
    @(posedge ck);                                  // P(TCL): data valid
    d = dq;
    @(negedge ck);                                  // released here
  endtask

  task automatic pre(input [2:0] sid, input [2:0] g, input [1:0] b);
    cmd(1, 0, 1, 0, sid, g, b, '0);
  endtask

  localparam [63:0] D0 = 64'hA5A5_0000_1111_2222, D1 = 64'h5A5A_3333_4444_5555,
                    D2 = 64'hDEAD_BEEF_CAFE_F00D, D3 = 64'h0123_4567_89AB_CDEF,
                    D4 = 64'hFEDC_BA98_7654_3210, D5 = 64'h1357_9BDF_2468_ACE0;
  logic [63:0] r, e;

  initial begin
    u_dut.vif_dq = IDLE;
    repeat (3) @(posedge ck);
    // commands while reset is asserted must be ignored
    act(0, 0, 0, 16'h0007);
    cs_n = 1'b0; we_n = 1'b0;  // (driven during reset only)
    @(negedge ck); cs_n = 1'b1; we_n = 1'b1;
    rst_n = 1'b1;
    repeat (2) @(posedge ck);

    // basic write / read-back through an open row
    act(0, 0, 0, 16'h0010);
    wr(0, 0, 0, 10'h004, D0);
    rd(0, 0, 0, 10'h004, r, e);
    chk(r === D0, "write then read same bank/row/col returns written data");
    chk(e !== D0, "read data not yet on dq one clock before CL (read latency = TCL)");
    @(posedge ck);
    chk(dq !== D0, "read data held for exactly one clock, then released");

    // unwritten column of an open row reads as zero
    rd(0, 0, 0, 10'h005, r, e);
    chk(r === 64'h0, "unwritten column reads 0");

    // overwrite replaces the stored word
    wr(0, 0, 0, 10'h004, D1);
    rd(0, 0, 0, 10'h004, r, e);
    chk(r === D1, "second write to same address overwrites the first");

    // bank independence: same row/col in another bank and bank group
    act(0, 0, 1, 16'h0010);
    wr(0, 0, 1, 10'h004, D2);
    act(0, 3, 0, 16'h0010);
    wr(0, 3, 0, 10'h004, D3);
    rd(0, 0, 0, 10'h004, r, e);
    chk(r === D1, "bank 0 unaffected by writes to other banks");
    rd(0, 0, 1, 10'h004, r, e);
    chk(r === D2, "bank 1 holds its own data");
    rd(0, 3, 0, 10'h004, r, e);
    chk(r === D3, "bank group 3 holds its own data");

    // stack / pseudo-channel independence
    act(1, 0, 0, 16'h0010);
    wr(1, 0, 0, 10'h004, D4);
    rd(1, 0, 0, 10'h004, r, e);
    chk(r === D4, "stack_id 1 holds its own data");
    rd(0, 0, 0, 10'h004, r, e);
    chk(r === D1, "stack_id 0 unaffected by stack_id 1 write");

    // row isolation: another row of the same bank does not alias
    pre(0, 0, 0);
    act(0, 0, 0, 16'h0020);
    rd(0, 0, 0, 10'h004, r, e);
    chk(r === 64'h0, "new row in same bank does not alias the previous row");
    wr(0, 0, 0, 10'h004, D5);
    // re-open the original row: data retained across precharge/activate
    pre(0, 0, 0);
    act(0, 0, 0, 16'h0010);
    rd(0, 0, 0, 10'h004, r, e);
    chk(r === D1, "row data retained across PRE/ACT");
    pre(0, 0, 0);
    act(0, 0, 0, 16'h0020);
    rd(0, 0, 0, 10'h004, r, e);
    chk(r === D5, "second row data retained independently");

    // deselected (CS_n high) write is ignored
    wr(0, 0, 0, 10'h004, 64'hBAD0_BAD0_BAD0_BAD0, 1'b0);
    rd(0, 0, 0, 10'h004, r, e);
    chk(r === D5, "write with CS_n high is ignored");

    // the write issued during reset did not land
    act(0, 0, 0, 16'h0007);
    rd(0, 0, 0, 10'h000, r, e);
    chk(r === 64'h0, "command during reset had no effect");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
