# HBM2 UVM VIP

**Protocol Level:** Complex
**Checkers:** 4 UVM components (Protocol L1, Data Integrity L2, Timing L2, Error L3) + module-based SVA compliance checker (L1-L4)
**License:** Apache-2.0

## Protocol Overview
HBM2 stacked DRAM: 8 channels x 2 pseudo-channels per stack, stack_id selects the die stack.

The VIP drives and monitors a DDR-style command/address bus
(`cs_n/act_n/ras_n/cas_n/we_n` + `{bg,ba}` bank + `addr` row/column):

| Command | cs_n | act_n | ras_n | cas_n | we_n | Address |
|---------|------|-------|-------|-------|------|---------|
| ACT     | 0    | 0     | -     | -     | -    | row     |
| RD      | 0    | 1     | 1     | 0     | 1    | column  |
| WR      | 0    | 1     | 1     | 0     | 0    | column  |
| PRE     | 0    | 1     | 0     | 1     | 0    | -       |
| REF     | 0    | 1     | 0     | 0     | 1    | -       |
| NOP     | 0    | 1     | 1     | 1     | 1    | -       |

Core timing parameters (cycles): tRCD=16, tRP=16, tRAS=20, tCL=16, tCWL=2, tRFC=48, tREFI=3900.

## Architecture
```
hbm2_vip/
|-- rtl/hbm2_if.sv                    # signal interface (+ clocking block)
|-- sequences/hbm2_sequence.sv        # transaction + directed sequence library
|-- vip/hbm2/
|   |-- hbm2_driver.sv                # protocol driver (cmd encoding, timing, DQ)
|   |-- hbm2_monitor.sv               # bus monitor (command/DQ decode -> analysis port)
|   |-- hbm2_agent.sv                 # sequencer + driver + monitor
|   |-- hbm2_coverage.sv              # 3 covergroups with crosses
|   |-- hbm2_compliance_checker.sv    # SVA module, L1-L4 (instanced in tb_top)
|   |-- hbm2_protocol_checker.sv      # L1 component (procedural sampling)
|   |-- hbm2_timing_checker.sv        # L2 component (tRCD/tRP/tRAS measurement)
|   |-- hbm2_data_integrity_checker.sv# L2 component (DQ/DBI/BL sampling)
|   |-- hbm2_error_checker.sv         # L3 component (temp/refresh/DFE monitoring)
|-- env/hbm2_env.sv                   # env + end-to-end scoreboard
|-- tests/hbm2_test.sv                # base/write/read/stress tests
|-- tb/tb_top.sv                     # TB top + DRAM memory-array functional model
|-- Makefile
```

Closed loop: sequences -> driver -> `hbm2_if` -> `hbm2_mem_model` (bank/row/col
storage in tb_top) drives read data back -> monitor decodes -> scoreboard
compares expected (driver) vs observed (monitor) end-to-end.

## Sequence Library
| Sequence | Purpose |
|----------|---------|
| `hbm2_base_sequence` | legacy fully-random items (API compatibility) |
| `hbm2_write_seq` | normal write flow: ACT, WR burst, PRE |
| `hbm2_read_seq` | normal read flow: ACT, RD burst, PRE |
| `hbm2_refresh_seq` | traffic punctuated by REF (tRFC apart) |
| `hbm2_bank_conflict_seq` | same bank, alternating rows (page misses) |
| `hbm2_back_to_back_seq` | one ACT, long alternating RD/WR stream (page hits) |
| `hbm2_stress_seq` | long protocol-legal random stream (bank-state model) |
| `hbm2_corner_seq` | all-zero/all-one row/col, boundary banks/stacks |
| `hbm2_random_sequence` | 50 random items |
| `hbm2_regression_sequence` | weighted mix of all directed sequences |

Tests: `hbm2_base_test` (regression seq), `hbm2_write_test`, `hbm2_read_test`, `hbm2_stress_test`.

## SVA Compliance Checker (vip/hbm2/hbm2_compliance_checker.sv)
- **L1 signal sanity (4):** command/address known when selected, bank group/address encoding bounds.
- **L2 timing & data integrity (8):** tRCD/tRP windows, burst length, data valid with DQS, DBI/WCK settings.
- **L3 error handling (6):** power-management state, refresh interval, over-temperature, DFE/bandwidth/latency bounds.
- **L4 HBM2-specific (10):** ACT/RD-WR/PRE bank-state legality (3), tRCD/tRP/tRAS timing rules (3), refresh pulse width, CKE gating, family rules (pseudo-channel stability + stack select), refresh-interval + ACT->col->PRE covers.

## Functional Coverage (vip/hbm2/hbm2_coverage.sv)
- `cg_command`    : command distribution x bank cross (`cx_cmd_bank`)
- `cg_bank_state` : bank state transitions (ACT=>RD/WR, RD/WR=>PRE, PRE/REF=>ACT, RD<=>WR)
- `cg_addr`       : row/col/stack address patterns with `cx_row_col` cross

## Quick Start
```bash
make comp                                   # compile (VCS + UVM 1.2)
make sim                                    # run default test
make regress                                # run regression test
./simv +UVM_TESTNAME=hbm2_stress_test        # run a directed test
```
