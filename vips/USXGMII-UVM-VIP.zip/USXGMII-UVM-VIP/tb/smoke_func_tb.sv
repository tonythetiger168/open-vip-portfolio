// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (USXGMII DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened usxgmii_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic blk_valid = 0;
  logic [65:0] blk = 0;
  logic [1:0] rate = 0;
  wire rep_valid, rep_fcs_ok;
  wire [7:0] rep_len;
  wire [31:0] rep_crc;
  wire [3:0] rep_err;

  always #5 clk = ~clk;

  usxgmii_model u_dut (.clk(clk), .rst_n(rst_n), .blk_valid(blk_valid), .blk(blk), .rate(rate),
                       .rep_valid(rep_valid), .rep_len(rep_len), .rep_crc(rep_crc), .rep_fcs_ok(rep_fcs_ok),
                       .rep_err(rep_err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic bit [31:0] crc32(bit [31:0] c, bit [7:0] b);
    c ^= {24'h0, b};
    for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    return c;
  endfunction

  int nrep = 0;
  logic [7:0] r_len;
  logic [31:0] r_crc;
  logic r_ok;
  logic [3:0] r_err;
  always @(posedge clk) if (rep_valid) begin nrep++; r_len = rep_len; r_crc = rep_crc; r_ok = rep_fcs_ok; r_err = rep_err; end

  // transmitter: scrambler, replication
  logic [57:0] scr = 0;
  int reps = 1;
  task automatic tx(input logic [1:0] sh, input logic [63:0] pl, input int alt_at = -1, input logic [63:0] alt = 0);
    logic [63:0] p, s;
    for (int r = 0; r < reps; r++) begin
      p = (r == alt_at) ? alt : pl;
      for (int i = 0; i < 64; i++) begin
        s[i] = p[i] ^ scr[38] ^ scr[57];
        scr = {scr[56:0], s[i]};
      end
      @(negedge clk); blk_valid = 1; blk = {s, sh};
    end
  endtask
  task automatic set_rate(input logic [1:0] r);
    rate = r;
    reps = (r == 0) ? 1 : (r == 1) ? 2 : (r == 2) ? 4 : 10;
  endtask
  task automatic idle(input int n); for (int i = 0; i < n; i++) tx(2'b10, 64'h1E); endtask
  task automatic pause(input int n); @(negedge clk); blk_valid = 0; repeat (n) @(negedge clk); endtask

  // a frame of n payload bytes v0, v0+1, ... with its FCS; sfd, bad_fcs
  logic [7:0] fr [0:127];
  int flen;
  logic [31:0] fcrc;
  task automatic build(input int n, input logic [7:0] v0, input bit bad_fcs = 0);
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < n; i++) begin fr[i] = v0 + i; c = crc32(c, fr[i]); end
    c = ~c ^ {31'h0, bad_fcs};
    for (int i = 0; i < 4; i++) fr[n + i] = c[8*i +: 8];
    flen = n + 4;
    fcrc = 32'hFFFF_FFFF;
    for (int i = 0; i < flen; i++) fcrc = crc32(fcrc, fr[i]);
  endtask
  task automatic start(input logic [7:0] sfd = 8'hD5);
    tx(2'b10, {sfd, {6{8'h55}}, 8'h78});
  endtask
  task automatic data_blk(input int b, input int alt_at = -1);
    logic [63:0] pl;
    for (int i = 0; i < 8; i++) pl[8*i +: 8] = fr[8*b + i];
    tx(2'b01, pl, alt_at, pl ^ 64'h0000_0000_0001_0000);
  endtask
  task automatic term_blk(input int from);
    logic [63:0] pl;
    int n;
    n = flen - from;
    pl = 0;
    case (n) 0: pl[7:0] = 8'h87; 1: pl[7:0] = 8'h99; 2: pl[7:0] = 8'hAA; 3: pl[7:0] = 8'hB4;
             4: pl[7:0] = 8'hCC; 5: pl[7:0] = 8'hD2; 6: pl[7:0] = 8'hE1; default: pl[7:0] = 8'hFF; endcase
    for (int i = 0; i < 7; i++) if (i < n) pl[8 + 8*i +: 8] = fr[from + i];
    tx(2'b10, pl);
  endtask
  task automatic frame(input logic [7:0] sfd = 8'hD5);
    start(sfd);
    for (int b = 0; b < flen / 8; b++) data_blk(b);
    term_blk(8 * (flen / 8));
    idle(1);
  endtask
  // expected CRC of the first k bytes
  function automatic logic [31:0] part(input int k);
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < k; i++) c = crc32(c, fr[i]);
    return c;
  endfunction

  initial begin
    int b;
    logic [31:0] c;
    logic [63:0] z, s;
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0, "no report in reset");
    rst_n = 1;
    repeat (2) @(posedge clk);
    // scrambler reference: from the all-zero state, payload bit 0 = 1 then
    // zeros gives 1 at bits 0, 39, 58 (x^58 + x^39 + 1 taps)
    begin
      logic [57:0] t;
      t = 0; z = 64'h1;
      for (int i = 0; i < 64; i++) begin s[i] = z[i] ^ t[38] ^ t[57]; t = {t[56:0], s[i]}; end
      chk(s[0] && s[39] && s[58] && $countones(s) == 3, $sformatf("scrambler taps (%h)", s));
    end

    set_rate(0); idle(3);
    chk(nrep == 0, "idles: no report");
    // every terminate lane at 10G
    for (int n = 0; n < 8; n++) begin
      b = nrep;
      build(20 + n, 8'h10 * n);
      frame();
      pause(0);
      chk(nrep == b + 1 && r_err == 0 && r_ok === 1'b1 && r_len == flen && r_crc == ~fcrc,
          $sformatf("10G frame of %0d bytes (terminate with %0d)", flen, flen % 8));
    end
    // every rate
    for (int r = 1; r < 4; r++) begin
      set_rate(r);
      b = nrep; build(45, 8'hA0 + r); frame(); pause(0);
      chk(nrep == b + 1 && r_err == 0 && r_ok === 1'b1 && r_len == 49, $sformatf("frame at rate %0d (%0d copies)", r, reps));
    end
    // bad FCS
    set_rate(1);
    b = nrep; build(30, 8'h33, 1); frame(); pause(0);
    chk(nrep == b + 1 && r_err == 0 && r_ok === 1'b0 && r_len == 34, "bad FCS reported");
    // a pause in the block stream (valid low) keeps scrambler and replication in step
    b = nrep; build(26, 8'h44); start(); data_blk(0); pause(5); data_blk(1); data_blk(2); term_blk(24); idle(1); pause(0);
    chk(nrep == b + 1 && r_err == 0 && r_ok === 1'b1, "frame across a pause in valid");

    // planted faults
    set_rate(0);
    b = nrep; build(40, 8'h01); start(); data_blk(0); data_blk(1);
    tx(2'b00, 64'h0); idle(2); pause(0);
    chk(nrep == b + 1 && r_ok === 1'b0 && r_err == 4'd1 && r_len == 16 && r_crc == ~part(16), "invalid sync header 00: code 1, 16 bytes kept");
    b = nrep; build(40, 8'h02); start(); data_blk(0); tx(2'b11, 64'h0); idle(2); pause(0);
    chk(nrep == b + 1 && r_ok === 1'b0 && r_err == 4'd1 && r_len == 8, "invalid sync header 11: code 1");
    b = nrep; build(40, 8'h03); start(); data_blk(0); tx(2'b10, {{8{7'h1E}}, 8'h1E}); idle(2); pause(0);
    chk(nrep == b + 1 && r_ok === 1'b0 && r_err == 4'd4 && r_len == 8, "error block in a frame: code 4");
    b = nrep; build(40, 8'h04); start(); data_blk(0); idle(2); pause(0);
    chk(nrep == b + 1 && r_ok === 1'b0 && r_err == 4'd4 && r_len == 8, "idle block in a frame: code 4");
    b = nrep; build(40, 8'h05); start(); data_blk(0); data_blk(1); data_blk(2); start(); pause(1);
    chk(nrep == b + 1 && r_ok === 1'b0 && r_err == 4'd4 && r_len == 24, "second start: the open frame ends with code 4");
    for (int k = 3; k < 5; k++) data_blk(k);
    term_blk(40); idle(1); pause(0);
    chk(nrep == b + 2 && r_err == 0 && r_len == 20 && r_ok === 1'b0, "the new frame runs on (its own bytes)");
    b = nrep; build(24, 8'h06); frame(8'hD4); pause(0);
    chk(nrep == b + 1 && r_err == 4'd8 && r_ok === 1'b1 && r_len == 28, "SFD D4: code 8, frame still received");
    b = nrep; build(24, 8'h07); tx(2'b10, {8'hD5, {5{8'h55}}, 8'h54, 8'h78});
    for (int k = 0; k < 3; k++) data_blk(k); term_blk(24); idle(1); pause(0);
    chk(nrep == b + 1 && r_err == 4'd8, "preamble byte 54: code 8");
    // replica faults
    set_rate(2);
    b = nrep; build(40, 8'h08); start(); data_blk(0); data_blk(1, 2); idle(2); pause(0);
    chk(nrep == b + 1 && r_ok === 1'b0 && r_err == 4'd2 && r_len == 16 && r_crc == ~part(16), "third copy differs: code 2 after the block");
    b = nrep; build(40, 8'h09); start(); data_blk(0, 3); idle(2); pause(0);
    chk(nrep == b + 1 && r_ok === 1'b0 && r_err == 4'd2 && r_len == 8, "last copy differs: code 2");
    // outside a frame: stray data, bad headers and differing copies are ignored
    b = nrep;
    tx(2'b01, 64'h1234); tx(2'b00, 64'h0); tx(2'b10, 64'h1E, 1, 64'h11E); tx(2'b10, 64'hFF);
    idle(2); pause(0);
    chk(nrep == b, "outside a frame: data, bad header, differing copy, terminate ignored");
    build(30, 8'h0A); b = nrep; frame(); pause(0);
    chk(nrep == b + 1 && r_err == 0 && r_ok === 1'b1, "clean frame after the faults");
    // rate change between frames
    set_rate(3); build(18, 8'h0B); b = nrep; frame(); pause(0);
    set_rate(0); build(18, 8'h0C); frame(); pause(0);
    chk(nrep == b + 2 && r_err == 0 && r_ok === 1'b1, "1G frame, then 10G frame");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
