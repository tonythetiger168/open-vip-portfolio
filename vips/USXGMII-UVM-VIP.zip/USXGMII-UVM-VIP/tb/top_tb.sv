// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- USXGMII testbench top with a functional USXGMII DUT model

`ifndef USXGMII_UVM_VIP_TB_SV
`define USXGMII_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import usxgmii_defs_pkg::*;
import usxgmii_pkg::*;
import usxgmii_env_pkg::*;
import usxgmii_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  usxgmii_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  usxgmii_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .blk_valid(vif.blk_valid),
    .blk(vif.blk),
    .rate(vif.rate),
    .rep_valid(vif.rep_valid),
    .rep_len(vif.rep_len),
    .rep_crc(vif.rep_crc),
    .rep_fcs_ok(vif.rep_fcs_ok),
    .rep_err(vif.rep_err)
  );

  // Concurrent protocol checks
  usxgmii_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .blk_valid(vif.blk_valid),
    .blk(vif.blk),
    .rate(vif.rate),
    .rep_valid(vif.rep_valid),
    .rep_len(vif.rep_len),
    .rep_crc(vif.rep_crc),
    .rep_fcs_ok(vif.rep_fcs_ok),
    .rep_err(vif.rep_err)
  );

  initial begin
    uvm_config_db#(virtual usxgmii_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module usxgmii_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        blk_valid,
  input  logic [65:0] blk,
  input  logic [1:0]  rate,
  output logic        rep_valid,
  output logic [7:0]  rep_len,
  output logic [31:0] rep_crc,
  output logic        rep_fcs_ok,
  output logic [3:0]  rep_err
);
  function automatic logic [31:0] crc32_byte(input logic [31:0] c, input logic [7:0] b);
    logic [31:0] x;
    x = c ^ {24'h0, b};
    for (int k = 0; k < 8; k++) x = x[0] ? (x >> 1) ^ 32'hEDB8_8320 : (x >> 1);
    crc32_byte = x;
  endfunction

  logic [57:0] st;            // descrambler: the last 58 received bits
  logic [65:0] ref_b;         // first copy of the current replication group
  logic [3:0]  cnt, reps;
  logic        in_f, pre_bad;
  logic [7:0]  len;
  logic [31:0] crc;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= '0; ref_b <= '0; cnt <= '0; reps <= 4'd1; in_f <= 1'b0; pre_bad <= 1'b0; len <= '0; crc <= '1;
      rep_valid <= 1'b0; rep_len <= '0; rep_crc <= '0; rep_fcs_ok <= 1'b0; rep_err <= '0;
    end else begin
      rep_valid <= 1'b0;
      if (blk_valid) begin : one_block
        logic [57:0] s;
        logic [63:0] d;
        logic [65:0] b;
        logic [31:0] c;
        logic [3:0]  r;
        logic [7:0]  l;
        integer      n;
        s = st;
        for (int i = 0; i < 64; i++) begin
          d[i] = blk[2 + i] ^ s[38] ^ s[57];
          s = {s[56:0], blk[2 + i]};
        end
        st <= s;
        b = {d, blk[1:0]};
        c = crc; l = len;
        if (cnt == 4'd0) begin
          case (rate)
            2'd0: r = 4'd1;
            2'd1: r = 4'd2;
            2'd2: r = 4'd4;
            default: r = 4'd10;
          endcase
          reps <= r;
          ref_b <= b;
          cnt <= (r == 4'd1) ? 4'd0 : 4'd1;
          if (b[1:0] == 2'b01) begin                      // data
            if (in_f) begin
              for (int i = 0; i < 8; i++) c = crc32_byte(c, d[8*i +: 8]);
              crc <= c; len <= l + 8'd8;
            end
          end else if (b[1:0] == 2'b10) begin             // control
            case (d[7:0])
              8'h87: n = 0;  8'h99: n = 1;  8'hAA: n = 2;  8'hB4: n = 3;
              8'hCC: n = 4;  8'hD2: n = 5;  8'hE1: n = 6;  8'hFF: n = 7;
              default: n = -1;
            endcase
            if (d[7:0] == 8'h78) begin
              if (in_f) begin                             // a start inside a frame
                rep_valid <= 1'b1; rep_len <= l; rep_crc <= ~c; rep_fcs_ok <= (c == 32'hDEBB_20E3); rep_err <= 4'd4;
              end
              in_f <= 1'b1; len <= '0; crc <= '1;
              pre_bad <= (d[63:8] != {8'hD5, {6{8'h55}}});
            end else if (in_f && n >= 0) begin            // terminate
              for (int i = 0; i < 7; i++) if (i < n) c = crc32_byte(c, d[8 + 8*i +: 8]);
              l = l + 8'(n);
              in_f <= 1'b0;
              rep_valid <= 1'b1; rep_len <= l; rep_crc <= ~c; rep_fcs_ok <= (c == 32'hDEBB_20E3);
              rep_err <= pre_bad ? 4'd8 : 4'd0;
            end else if (in_f) begin                      // error / idle / other inside a frame
              in_f <= 1'b0;
              rep_valid <= 1'b1; rep_len <= l; rep_crc <= ~c; rep_fcs_ok <= (c == 32'hDEBB_20E3); rep_err <= 4'd4;
            end
          end else if (in_f) begin                        // invalid sync header
            in_f <= 1'b0;
            rep_valid <= 1'b1; rep_len <= l; rep_crc <= ~c; rep_fcs_ok <= (c == 32'hDEBB_20E3); rep_err <= 4'd1;
          end
        end else begin
          if (b != ref_b && in_f) begin                   // a copy differs from the first
            in_f <= 1'b0;
            rep_valid <= 1'b1; rep_len <= l; rep_crc <= ~c; rep_fcs_ok <= (c == 32'hDEBB_20E3); rep_err <= 4'd2;
          end
          cnt <= (cnt + 4'd1 == reps) ? 4'd0 : cnt + 4'd1;
        end
      end
    end
  end
endmodule
`endif
