// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_transaction.svh -- USXGMII transaction

class usxgmii_transaction extends uvm_sequence_item;
  `uvm_object_utils(usxgmii_transaction)

  // request (driven by the agent)
  bit [7:0] data[$];
  rand bit [1:0] speed;
  rand bit [2:0] fault;
  rand bit [3:0] fpos;
  rand bit bad_fcs;
  // response (returned by the DUT)
  bit [7:0] rlen;
  bit [31:0] rcrc;
  bit fcs_ok;
  bit [3:0] err;
  // bookkeeping (not compared)
  rand bit [6:0] nbytes;
  rand bit [1:0] gap;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len   { nbytes >= 8; nbytes <= 80; }
  constraint c_speed { speed dist { 0 := 4, 1 := 3, 2 := 3, 3 := 2 }; }
  constraint c_fault { fault dist { 0 := 16, 1 := 1, 2 := 1, 3 := 1, 4 := 1 }; bad_fcs dist { 0 := 12, 1 := 1 }; }

  function new(string name = "usxgmii_transaction"); super.new(name); endfunction

  // payload from the seed, FCS appended (inverted in bit 0 when bad_fcs);
  // a fault falls on a whole data block, a replica fault needs replicas
  function void post_randomize();
    bit [31:0] x = seed | 1, c = 32'hFFFF_FFFF;
    data.delete();
    for (int i = 0; i < nbytes; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      data.push_back(x[7:0]);
      c = usx_crc32(c, x[7:0]);
    end
    c = ~c ^ {31'h0, bad_fcs};
    for (int i = 0; i < 4; i++) data.push_back(c[8*i +: 8]);
    if (fault > 4 || (fault == 2 && speed == 0)) fault = 0;
    fpos = (fault inside {1, 2, 3}) ? x[19:16] % (data.size() / 8) : 0;
  endfunction

  function void do_copy(uvm_object rhs);
    usxgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    data = rhs_.data;
    speed = rhs_.speed;
    fault = rhs_.fault;
    fpos = rhs_.fpos;
    bad_fcs = rhs_.bad_fcs;
    rlen = rhs_.rlen;
    rcrc = rhs_.rcrc;
    fcs_ok = rhs_.fcs_ok;
    err = rhs_.err;
    nbytes = rhs_.nbytes;
    gap = rhs_.gap;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    usxgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (speed != rhs_.speed) return 0;
    if (fault != rhs_.fault) return 0;
    if (fpos != rhs_.fpos) return 0;
    if (bad_fcs != rhs_.bad_fcs) return 0;
    if (rlen != rhs_.rlen) return 0;
    if (rcrc != rhs_.rcrc) return 0;
    if (fcs_ok != rhs_.fcs_ok) return 0;
    if (err != rhs_.err) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(usxgmii_transaction rhs_);
    if (data.size() != rhs_.data.size()) return 0;
    foreach (data[i]) if (data[i] != rhs_.data[i]) return 0;
    if (speed != rhs_.speed) return 0;
    if (fault != rhs_.fault) return 0;
    if (fpos != rhs_.fpos) return 0;
    if (bad_fcs != rhs_.bad_fcs) return 0;
    return 1;
  endfunction

  function string qstr_data();
    string s = $sformatf("[%0d]{", data.size());
    foreach (data[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", data[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("USXGMII{tag=%0d data=%s speed=0x%0h fault=0x%0h fpos=0x%0h bad_fcs=0x%0h rlen=0x%0h rcrc=0x%0h fcs_ok=0x%0h err=0x%0h}", tag, qstr_data(), speed, fault, fpos, bad_fcs, rlen, rcrc, fcs_ok, err);
  endfunction
endclass
