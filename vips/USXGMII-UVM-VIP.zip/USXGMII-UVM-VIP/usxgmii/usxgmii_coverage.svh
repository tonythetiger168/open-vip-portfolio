// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_coverage.svh -- USXGMII functional coverage

class usxgmii_coverage extends uvm_subscriber #(usxgmii_transaction);
  `uvm_component_utils(usxgmii_coverage)
  usxgmii_config cfg;
  usxgmii_transaction tr;

  covergroup usxgmii_cg;
    cp_speed : coverpoint tr.speed { bins g10 = {0}; bins g5 = {1}; bins g2_5 = {2}; bins g1 = {3}; }
    cp_fault : coverpoint tr.fault { bins none = {0}; bins header = {1}; bins replica = {2}; bins error_blk = {3}; bins sfd = {4}; }
    cp_term  : coverpoint (tr.data.size() % 8) iff (tr.fault == 0) { bins t[] = {[0:7]}; }
    cp_fcs   : coverpoint tr.bad_fcs iff (tr.fault == 0);
    x_speed_fault : cross cp_speed, cp_fault { ignore_bins rep10 = binsof(cp_speed.g10) && binsof(cp_fault.replica); }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    usxgmii_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(usxgmii_config)::get(this, "", "cfg", cfg))
      cfg = usxgmii_config::type_id::create("cfg");
  endfunction

  function void write(usxgmii_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    usxgmii_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("USXGMII coverage: %0.1f%%", usxgmii_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
