// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_compliance_checker.sv -- USXGMII concurrent assertion checks (bindable)

module usxgmii_compliance_checker
  (input logic clk, input logic rst_n, input logic blk_valid, input logic [65:0] blk, input logic [1:0] rate, input logic rep_valid, input logic [7:0] rep_len, input logic [31:0] rep_crc, input logic rep_fcs_ok, input logic [3:0] rep_err);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({blk_valid, rep_valid}))
    else $error("USXGMII: X on block valid / report");
  assert property (@(posedge clk) disable iff (!rst_n) blk_valid |-> !$isunknown(blk))
    else $error("USXGMII: X in a valid block");
  // a report follows a valid block
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |-> $past(blk_valid))
    else $error("USXGMII: report without a block");
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_err == 0 && rep_fcs_ok);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_err == 2);
  cover property (@(posedge clk) disable iff (!rst_n) blk_valid && rate == 2'd3);
endmodule
