// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_sequences.svh -- USXGMII sequences

// Random traffic: cfg.num_items constrained-random items.
class usxgmii_base_sequence extends uvm_sequence #(usxgmii_transaction);
  `uvm_object_utils(usxgmii_base_sequence)
  usxgmii_config cfg;

  function new(string name = "usxgmii_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = usxgmii_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "usxgmii_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class usxgmii_directed_sequence extends uvm_sequence #(usxgmii_transaction);
  `uvm_object_utils(usxgmii_directed_sequence)
  usxgmii_config cfg;

  function new(string name = "usxgmii_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function usxgmii_transaction item();
    item = usxgmii_transaction::type_id::create("req");
  endfunction

  task send(usxgmii_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    usxgmii_transaction t;
    // every terminate lane at 10G, every rate, then each planted fault
    for (int n = 0; n < 8; n++) begin
      t = item(); t.speed = 0; t.nbytes = 16 + n; t.seed = n + 1; t.post_randomize(); send(t);
    end
    for (int s = 0; s < 4; s++) begin
      t = item(); t.speed = s; t.nbytes = 60; t.seed = 77 + s; t.post_randomize(); send(t);
    end
    t = item(); t.speed = 1; t.nbytes = 20; t.seed = 5; t.bad_fcs = 1; t.post_randomize(); send(t);
    for (int s = 0; s < 4; s++) begin
      t = item(); t.speed = s; t.nbytes = 40; t.seed = 9 + s; t.fault = 1; t.post_randomize(); t.fpos = 2; send(t);
      t = item(); t.speed = s; t.nbytes = 40; t.seed = 19 + s; t.fault = 3; t.post_randomize(); t.fpos = 0; send(t);
      t = item(); t.speed = s; t.nbytes = 40; t.seed = 29 + s; t.fault = 4; t.post_randomize(); send(t);
      if (s != 0) begin
        t = item(); t.speed = s; t.nbytes = 40; t.seed = 39 + s; t.fault = 2; t.post_randomize(); t.fpos = 3; send(t);
      end
    end
  endtask
endclass
