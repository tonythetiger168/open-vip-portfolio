// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_driver.svh -- USXGMII driver: frames as 64b/66b blocks: start with preamble, data, terminate, idle gap; scrambled, each block repeated for the rate; planted header / replica / error-block / preamble faults

class usxgmii_driver extends uvm_driver #(usxgmii_transaction);
  `uvm_component_utils(usxgmii_driver)

  uvm_analysis_port #(usxgmii_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual usxgmii_if vif;
  usxgmii_config cfg;

  bit [57:0] scr = '0;   // scrambler state (last 58 scrambled bits)

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual usxgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "usxgmii: virtual interface not set")
    if (!uvm_config_db#(usxgmii_config)::get(this, "", "cfg", cfg))
      cfg = usxgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    usxgmii_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.blk_valid <= 1'b0;
    vif.drv_cb.blk       <= '0;
    vif.drv_cb.rate      <= '0;
  endtask

  task drive_item(usxgmii_transaction t);
    int R = usx_reps(t.speed), nfull = t.data.size() / 8, nd;
    bit [63:0] pl;
    vif.drv_cb.rate <= t.speed;
    // start: type 0x78, preamble, SFD (planted: SFD 0xD4)
    send_blk(2'b10, {(t.fault == 4) ? 8'hD4 : 8'hD5, {6{8'h55}}, 8'h78}, R);
    nd = nfull;
    for (int b = 0; b < nfull; b++) begin
      for (int i = 0; i < 8; i++) pl[8*i +: 8] = t.data[8*b + i];
      if (t.fault == 1 && b == t.fpos) begin send_blk(2'b00, pl, R); nd = b; break; end
      if (t.fault == 3 && b == t.fpos) begin send_blk(2'b10, {{8{7'h1E}}, 8'h1E}, R); nd = b; break; end
      if (t.fault == 2 && b == t.fpos) begin send_blk(2'b01, pl, R, 1, pl ^ 64'h0000_0100_0000_0000); nd = b + 1; break; end
      send_blk(2'b01, pl, R);
    end
    if (t.fault inside {1, 2, 3}) begin
      // the receiver drops the frame at the fault: what it kept is the request
      while (t.data.size() > 8 * nd) void'(t.data.pop_back());
      t.bad_fcs = 0;
    end else begin
      int n = t.data.size() - 8 * nfull;
      pl = '0;
      pl[7:0] = usx_term(n);
      for (int i = 0; i < n; i++) pl[8 + 8*i +: 8] = t.data[8*nfull + i];
      send_blk(2'b10, pl, R);
    end
    // close a cut frame's remainder with idles; inter-frame gap
    repeat (1 + t.gap) send_blk(2'b10, 64'h1E, R);
    vif.drv_cb.blk_valid <= 1'b0;
  endtask

  // scramble one payload and send it R times (copy 1 replaced by alt when given)
  task send_blk(bit [1:0] sh, bit [63:0] pl, int reps, bit use_alt = 0, bit [63:0] alt = 0);
    for (int r = 0; r < reps; r++) begin
      bit [63:0] p = (use_alt && r == 1) ? alt : pl, s;
      for (int i = 0; i < 64; i++) begin
        s[i] = p[i] ^ scr[38] ^ scr[57];
        scr = {scr[56:0], s[i]};
      end
      vif.drv_cb.blk_valid <= 1'b1;
      vif.drv_cb.blk <= {s, sh};
      @(vif.drv_cb);
    end
  endtask
endclass
