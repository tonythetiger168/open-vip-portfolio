// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_monitor.svh -- USXGMII monitor: blocks descrambled by the monitor's own descrambler, one copy per replication group, decoded into frames and faults; completed by the DUT's report

class usxgmii_monitor extends uvm_monitor;
  `uvm_component_utils(usxgmii_monitor)

  virtual usxgmii_if vif;
  uvm_analysis_port #(usxgmii_transaction) ap;
  usxgmii_config cfg;
  int unsigned n_obs = 0;

  usxgmii_transaction done_q[$], rep_q[$];

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual usxgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "usxgmii: virtual interface not set")
    if (!uvm_config_db#(usxgmii_config)::get(this, "", "cfg", cfg))
      cfg = usxgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [57:0] st = '0;
      bit [65:0] ref_b;
      int cnt = 0, R = 1;
      bit in_f = 0;
      usxgmii_transaction cur;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rep_valid) begin
          usxgmii_transaction r = usxgmii_transaction::type_id::create("r");
          r.rlen = vif.mon_cb.rep_len; r.rcrc = vif.mon_cb.rep_crc; r.fcs_ok = vif.mon_cb.rep_fcs_ok; r.err = vif.mon_cb.rep_err;
          rep_q.push_back(r);
        end
        if (vif.mon_cb.blk_valid) begin
          bit [63:0] d;
          bit [65:0] b;
          for (int i = 0; i < 64; i++) begin
            d[i] = vif.mon_cb.blk[2 + i] ^ st[38] ^ st[57];
            st = {st[56:0], vif.mon_cb.blk[2 + i]};
          end
          b = {d, vif.mon_cb.blk[1:0]};
          if (cnt == 0) begin
            R = usx_reps(vif.mon_cb.rate);
            ref_b = b;
            cnt = (R == 1) ? 0 : 1;
            if (b[1:0] == 2'b01) begin
              if (in_f) for (int i = 0; i < 8; i++) cur.data.push_back(d[8*i +: 8]);
            end else if (b[1:0] == 2'b10) begin
              int n = usx_term_n(d[7:0]);
              if (d[7:0] == 8'h78) begin
                if (in_f) `uvm_error("MON", "USXGMII: start inside a frame")
                cur = usxgmii_transaction::type_id::create("t");
                cur.speed = vif.mon_cb.rate;
                if (d[63:8] != {8'hD5, {6{8'h55}}}) cur.fault = 4;
                in_f = 1;
              end else if (in_f && n >= 0) begin
                for (int i = 0; i < n; i++) cur.data.push_back(d[8 + 8*i +: 8]);
                cur.bad_fcs = !fcs_good(cur.data);
                done_q.push_back(cur); in_f = 0;
              end else if (in_f) begin
                cur.fault = 3; cur.fpos = cur.data.size() / 8;
                done_q.push_back(cur); in_f = 0;
              end
            end else if (in_f) begin
              cur.fault = 1; cur.fpos = cur.data.size() / 8;
              done_q.push_back(cur); in_f = 0;
            end
          end else begin
            if (b != ref_b && in_f) begin
              cur.fault = 2; cur.fpos = cur.data.size() / 8 - 1;
              done_q.push_back(cur); in_f = 0;
            end
            cnt = (cnt + 1 == R) ? 0 : cnt + 1;
          end
        end
        while (done_q.size() != 0 && rep_q.size() != 0) begin
          usxgmii_transaction t = done_q.pop_front(), r = rep_q.pop_front();
          t.rlen = r.rlen; t.rcrc = r.rcrc; t.fcs_ok = r.fcs_ok; t.err = r.err;
          publish(t);
        end
      end
    end
  endtask

  function void publish(usxgmii_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  function bit fcs_good(bit [7:0] q[$]);
    bit [31:0] c = 32'hFFFF_FFFF;
    foreach (q[i]) c = usx_crc32(c, q[i]);
    return c == 32'hDEBB_20E3;
  endfunction
endclass
