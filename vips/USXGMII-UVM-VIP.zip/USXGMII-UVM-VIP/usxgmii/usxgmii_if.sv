// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_if.sv -- USXGMII interface

interface usxgmii_if (input logic clk);
  logic rst_n;

  logic blk_valid;
  logic [65:0] blk;
  logic [1:0] rate;
  logic rep_valid;
  logic [7:0] rep_len;
  logic [31:0] rep_crc;
  logic rep_fcs_ok;
  logic [3:0] rep_err;

  modport DUT (input clk, rst_n, input blk_valid, input blk, input rate, output rep_valid, output rep_len, output rep_crc, output rep_fcs_ok, output rep_err);
  modport MON (input clk, rst_n, blk_valid, blk, rate, rep_valid, rep_len, rep_crc, rep_fcs_ok, rep_err);

  clocking drv_cb @(posedge clk);
    input rst_n, rep_valid, rep_len, rep_crc, rep_fcs_ok, rep_err;
    inout blk_valid, blk, rate;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, blk_valid, blk, rate, rep_valid, rep_len, rep_crc, rep_fcs_ok, rep_err;
  endclocking
endinterface
