// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_pkg.sv -- USXGMII UVM VIP package

package usxgmii_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import usxgmii_defs_pkg::*;
  export usxgmii_defs_pkg::*;

  `include "usxgmii_transaction.svh"
  `include "usxgmii_config.svh"
  `include "usxgmii_sequencer.svh"
  `include "usxgmii_driver.svh"
  `include "usxgmii_monitor.svh"
  `include "usxgmii_agent.svh"
  `include "usxgmii_sequences.svh"
  `include "usxgmii_checker.svh"
  `include "usxgmii_coverage.svh"
endpackage
