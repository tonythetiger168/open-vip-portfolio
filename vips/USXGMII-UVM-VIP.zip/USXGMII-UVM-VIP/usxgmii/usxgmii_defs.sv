// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// usxgmii_defs.sv -- USXGMII shared type definitions

package usxgmii_defs_pkg;

  typedef enum bit [1:0] {USXGMII_OK, USXGMII_ERR} usxgmii_status_e;

  // IEEE CRC-32 step (reflected, not inverted): residue 0xDEBB20E3 over a frame with its FCS
  function automatic bit [31:0] usx_crc32(bit [31:0] c, bit [7:0] b);
    c ^= {24'h0, b};
    for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    return c;
  endfunction
  function automatic int usx_reps(bit [1:0] rate);
    case (rate) 2'd0: return 1; 2'd1: return 2; 2'd2: return 4; default: return 10; endcase
  endfunction
  // terminate block types for 0..7 bytes
  function automatic bit [7:0] usx_term(int n);
    case (n)
      0: return 8'h87; 1: return 8'h99; 2: return 8'hAA; 3: return 8'hB4;
      4: return 8'hCC; 5: return 8'hD2; 6: return 8'hE1; default: return 8'hFF;
    endcase
  endfunction
  function automatic int usx_term_n(bit [7:0] t);
    case (t)
      8'h87: return 0; 8'h99: return 1; 8'hAA: return 2; 8'hB4: return 3;
      8'hCC: return 4; 8'hD2: return 5; 8'hE1: return 6; 8'hFF: return 7;
      default: return -1;
    endcase
  endfunction

endpackage
