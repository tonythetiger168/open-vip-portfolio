// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_eth800g_tb.sv -- self-checking functional test for the 800G Ethernet
// packet-statistics model (eth800g_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py ETH800G-VIP
//
// Model contract (from tb/top_tb.sv), 256-bit packet bus:
//   Always ready. A beat counts on pkt_valid; a packet runs from SOP to EOP
//   and each beat carries 32 - MTY bytes. At EOP the packet counter and the
//   byte counter (bytes of the whole packet) advance, and err_oversize
//   pulses for one clock when the packet exceeds 9600 bytes. An EOP beat
//   outside a packet (no SOP) is ignored.

module func_eth800g_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic         clk = 1'b0, rst_n = 1'b1, valid = 1'b0, sop = 1'b0, eop = 1'b0;
  logic [255:0] data = '0;
  logic [4:0]   mty = '0;
  wire          ready, err;
  wire  [15:0]  pkt_cnt;
  wire  [31:0]  byte_cnt;

  always #5 clk = ~clk;

  eth800g_model u_dut (
    .clk(clk), .rst_n(rst_n), .pkt_valid(valid), .pkt_sop(sop), .pkt_eop(eop),
    .pkt_data(data), .pkt_mty(mty), .pkt_ready(ready), .pkt_cnt(pkt_cnt),
    .byte_cnt(byte_cnt), .err_oversize(err)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  int err_pulses = 0;
  always @(posedge clk) if (rst_n && err) err_pulses++;

  // one packet of nbytes (> 0), idle clocks between beats when gaps is set;
  // idle clocks drive SOP/EOP high with valid low (must be ignored)
  task automatic packet(input int nbytes, input bit gaps = 0);
    int left, n;
    left = nbytes;
    n = 0;
    while (left > 0) begin
      @(negedge clk);
      valid = 1'b1; sop = (n == 0); eop = (left <= 32);
      mty = (left >= 32) ? 5'd0 : 5'(32 - left);
      data = {8{$urandom}};
      left -= 32 - mty;
      n++;
      if (gaps && $urandom_range(1)) begin
        @(negedge clk);
        valid = 1'b0; sop = 1'b1; eop = 1'b1;
      end
    end
    @(negedge clk);
    valid = 1'b0; sop = 1'b0; eop = 1'b0;
  endtask

  int exp_pkts, bad;
  longint exp_bytes;
  bit  saw_err;

  initial begin
    // reset from a known-high level so the asynchronous reset edge occurs
    #2 rst_n = 1'b0;
    repeat (3) @(negedge clk);
    chk(pkt_cnt === 0 && byte_cnt === 0 && err === 1'b0, "counters and error clear in reset");
    chk(ready === 1'b1, "always ready");
    rst_n = 1'b1;

    packet(60);
    chk(pkt_cnt == 1 && byte_cnt == 60, "2-beat packet: 1 packet, 60 bytes");
    packet(32);
    chk(pkt_cnt == 2 && byte_cnt == 92, "single full beat (SOP+EOP): 32 bytes");
    packet(1);
    chk(pkt_cnt == 3 && byte_cnt == 93, "single 1-byte beat (MTY 31)");
    repeat (4) begin
      @(negedge clk); sop = 1'b1; eop = 1'b1; mty = 0;
    end
    @(negedge clk); sop = 1'b0; eop = 1'b0;
    chk(pkt_cnt == 3 && byte_cnt == 93, "SOP/EOP without valid are ignored");

    // oversize boundary
    packet(9600);
    chk(err_pulses == 0 && pkt_cnt == 4, "9600-byte packet is not oversize");
    packet(32);
    chk(err_pulses == 0, "short packet after a long one is not oversize");
    saw_err = 0;
    fork
      packet(9601);
      begin
        @(posedge eop); @(negedge eop);
        saw_err = (err === 1'b1);
      end
    join
    chk(saw_err, "9601-byte packet flags err_oversize at EOP");
    @(negedge clk);
    chk(err === 1'b0 && err_pulses == 1, "err_oversize is a one-clock pulse");
    chk(pkt_cnt == 6 && byte_cnt == 93 + 9600 + 32 + 9601, "oversize packet still counted");

    // random packets, some with idle gaps
    exp_pkts = pkt_cnt; exp_bytes = byte_cnt;
    for (int i = 0; i < 60; i++) begin
      int n;
      n = ($urandom_range(9) == 0) ? $urandom_range(9800, 9500) : $urandom_range(400, 1);
      packet(n, $urandom_range(1));
      exp_pkts++; exp_bytes += n;
      if (n > 9600) err_pulses--;
    end
    chk(pkt_cnt == 16'(exp_pkts) && byte_cnt == 32'(exp_bytes), "60 random packets: packet and byte counts");
    chk(err_pulses == 1, "60 random packets: err_oversize exactly for those over 9600 bytes");

    // a repeated SOP inside a packet: the bytes already received still count
    begin
      int c0;
      c0 = byte_cnt;
      @(negedge clk); valid = 1'b1; sop = 1'b1; eop = 1'b0; mty = 0;
      @(negedge clk); sop = 1'b1;
      @(negedge clk); sop = 1'b0; eop = 1'b1;
      @(negedge clk); sop = 1'b1; eop = 1'b0;
      @(negedge clk); sop = 1'b1; eop = 1'b1;
      @(negedge clk); valid = 1'b0; sop = 1'b0; eop = 1'b0;
      exp_pkts += 2;
      chk(byte_cnt == c0 + 5 * 32 && pkt_cnt == 16'(exp_pkts), "SOP repeated inside a packet: no bytes lost");
    end

    // EOP without a SOP: not a packet
    @(negedge clk); valid = 1'b1; eop = 1'b1; mty = 0;
    @(negedge clk); valid = 1'b0; eop = 1'b0;
    chk(pkt_cnt == 16'(exp_pkts) && byte_cnt == 32'(exp_bytes) + 5 * 32, "EOP without SOP is not counted as a packet");

    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(pkt_cnt === 0 && byte_cnt === 0 && err === 1'b0, "reset clears the counters");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
