// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- 800G Ethernet testbench top with a functional 800G Ethernet DUT model

`ifndef 800G Ethernet_TB_SV
`define 800G Ethernet_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import eth800g_defs_pkg::*;
import eth800g_pkg::*;
import eth800g_env_pkg::*;
import eth800g_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  eth800g_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  eth800g_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .pkt_valid(vif.pkt_valid),
    .pkt_sop(vif.pkt_sop),
    .pkt_eop(vif.pkt_eop),
    .pkt_data(vif.pkt_data),
    .pkt_mty(vif.pkt_mty),
    .pkt_ready(vif.pkt_ready),
    .pkt_cnt(vif.pkt_cnt),
    .byte_cnt(vif.byte_cnt),
    .err_oversize(vif.err_oversize)
  );

  // Concurrent protocol checks
  eth800g_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .pkt_valid(vif.pkt_valid), .pkt_sop(vif.pkt_sop), .pkt_eop(vif.pkt_eop), .pkt_data(vif.pkt_data), .pkt_mty(vif.pkt_mty), .pkt_ready(vif.pkt_ready), .pkt_cnt(vif.pkt_cnt), .byte_cnt(vif.byte_cnt), .err_oversize(vif.err_oversize)
  );

  initial begin
    uvm_config_db#(virtual eth800g_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module eth800g_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        pkt_valid,
  input  logic        pkt_sop,
  input  logic        pkt_eop,
  input  logic [255:0] pkt_data,
  input  logic [4:0]  pkt_mty,
  output logic        pkt_ready,
  output logic [15:0] pkt_cnt,
  output logic [31:0] byte_cnt,
  output logic        err_oversize
);
  // segment stream: 32B/beat, mty = unused bytes on final beat
  logic [15:0] cur_bytes;
  logic        in_pkt;
  integer      beat_bytes;
  assign pkt_ready = 1'b1;
  initial begin err_oversize = 1'b0; pkt_cnt = 16'd0; byte_cnt = 32'd0; end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cur_bytes <= 16'd0; in_pkt <= 1'b0; err_oversize <= 1'b0;
      pkt_cnt <= 16'd0; byte_cnt <= 32'd0;
    end else begin
      err_oversize <= 1'b0;
      if (pkt_valid && pkt_ready) begin
        beat_bytes = 32 - pkt_mty;
        if (pkt_sop && !in_pkt) begin
          in_pkt <= 1'b1;
          cur_bytes <= beat_bytes;
        end else if (in_pkt) begin
          cur_bytes <= cur_bytes + beat_bytes[15:0];
        end
        if (pkt_eop) begin
          in_pkt <= 1'b0;
          pkt_cnt <= pkt_cnt + 1;
          if (pkt_sop && !in_pkt)
            byte_cnt <= byte_cnt + beat_bytes;
          else
            byte_cnt <= byte_cnt + cur_bytes + beat_bytes;
          if ((pkt_sop && !in_pkt && beat_bytes > 9600) ||
              (in_pkt && cur_bytes + beat_bytes > 9600))
            err_oversize <= 1'b1;
        end
      end
    end
  end
endmodule
`endif
