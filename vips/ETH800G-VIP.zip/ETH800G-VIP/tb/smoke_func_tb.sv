// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (800G Ethernet segment counting + MTU)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened eth800g_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic pkt_valid = 1'b0;
  logic pkt_sop = 1'b0;
  logic pkt_eop = 1'b0;
  logic [255:0] pkt_data = '0;
  logic [4:0] pkt_mty = '0;
  wire  pkt_ready;
  wire  [15:0] pkt_cnt;
  wire  [31:0] byte_cnt;
  wire  err_oversize;

  always #5 clk = ~clk;

  eth800g_model u_dut (
    .clk(clk), .rst_n(rst_n), .pkt_valid(pkt_valid),
    .pkt_sop(pkt_sop), .pkt_eop(pkt_eop),
    .pkt_data(pkt_data), .pkt_mty(pkt_mty),
    .pkt_ready(pkt_ready), .pkt_cnt(pkt_cnt),
    .byte_cnt(byte_cnt), .err_oversize(err_oversize)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  integer i;
  initial begin
    repeat (8) step();
    chk(pkt_cnt === 16'd0 && byte_cnt === 32'd0, "counters zero in reset");
    chk(err_oversize === 1'b0, "no err in reset");
    @(negedge clk); rst_n = 1'b1;

    // packet 1: 2 beats, final mty=4 -> 32 + 28 = 60 bytes
    @(negedge clk); pkt_valid = 1'b1; pkt_sop = 1'b1;
    pkt_data = 256'hAAAA; pkt_mty = 5'd0;
    step();
    @(negedge clk); pkt_sop = 1'b0; pkt_eop = 1'b1;
    pkt_data = 256'hBBBB; pkt_mty = 5'd4;
    step();
    @(negedge clk); pkt_valid = 1'b0; pkt_eop = 1'b0;
    step();
    chk(pkt_cnt === 16'd1, "one packet counted");
    chk(byte_cnt === 32'd60, "byte count with mty");

    // packet 2: single-beat back-to-back, 32 bytes
    @(negedge clk); pkt_valid = 1'b1; pkt_sop = 1'b1; pkt_eop = 1'b1;
    pkt_data = 256'hCCCC; pkt_mty = 5'd0;
    step();
    @(negedge clk); pkt_valid = 1'b0; pkt_sop = 1'b0; pkt_eop = 1'b0;
    step();
    chk(pkt_cnt === 16'd2, "second packet counted");
    chk(byte_cnt === 32'd92, "byte count accumulates");

    // idle cycles must not count
    repeat (5) begin step(); chk(pkt_cnt === 16'd2, "no count when idle"); end

    // oversize: 301 beats x 32B = 9632B > 9600
    for (i = 0; i < 301; i = i + 1) begin
      @(negedge clk);
      pkt_valid = 1'b1;
      pkt_sop = (i == 0);
      pkt_eop = (i == 300);
      pkt_data = i;
      pkt_mty = 5'd0;
      step();
    end
    chk(err_oversize === 1'b1, "oversize flagged");
    chk(pkt_cnt === 16'd3, "oversize packet still counted");
    @(negedge clk); pkt_valid = 1'b0; pkt_sop = 1'b0; pkt_eop = 1'b0;
    step();
    chk(err_oversize === 1'b0, "err is a pulse");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
