// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_transaction.svh -- 800G Ethernet transaction

class eth800g_transaction extends uvm_sequence_item;
  `uvm_object_utils(eth800g_transaction)

  rand bit pkt_valid;
  rand bit pkt_sop;
  rand bit pkt_eop;
  rand bit [255:0] pkt_data;
  rand bit [4:0] pkt_mty;
  bit pkt_ready_o;
  bit [15:0] pkt_cnt_o;
  bit [31:0] byte_cnt_o;
  bit err_oversize_o;
  bit [31:0] tag;

  function new(string name = "eth800g_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    eth800g_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    pkt_valid = rhs_.pkt_valid;
    pkt_sop = rhs_.pkt_sop;
    pkt_eop = rhs_.pkt_eop;
    pkt_data = rhs_.pkt_data;
    pkt_mty = rhs_.pkt_mty;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    eth800g_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           pkt_valid == rhs_.pkt_valid &&
           pkt_sop == rhs_.pkt_sop &&
           pkt_eop == rhs_.pkt_eop &&
           pkt_data == rhs_.pkt_data &&
           pkt_mty == rhs_.pkt_mty;
  endfunction

  function string convert2string();
    return $sformatf("800G Ethernet{tag=%0h pkt_valid=0x%0h pkt_sop=0x%0h pkt_eop=0x%0h pkt_data=0x%0h pkt_mty=0x%0h}", tag, pkt_valid, pkt_sop, pkt_eop, pkt_data, pkt_mty);
  endfunction
endclass
