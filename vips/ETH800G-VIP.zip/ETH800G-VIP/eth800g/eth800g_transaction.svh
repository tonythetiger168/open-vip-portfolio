// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_transaction.svh -- 800G Ethernet transaction

class eth800g_transaction extends uvm_sequence_item;
  `uvm_object_utils(eth800g_transaction)

  // request (driven by the agent)
  rand bit [9:0] nbeats;
  rand bit [4:0] mty;
  bit [31:0] data_hash;
  // response (returned by the DUT)
  bit [15:0] pkt_cnt;
  bit [31:0] byte_cnt;
  bit oversize;
  // bookkeeping (not compared)
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len { nbeats dist { [1:4] :/ 4, [5:64] :/ 3, [290:302] :/ 1 }; }

  function new(string name = "eth800g_transaction"); super.new(name); endfunction

  function int unsigned bytes_len(); return nbeats * 32 - mty; endfunction

  // beat i of the packet (derived from seed)
  function bit [255:0] beat(int unsigned i);
    bit [31:0] x = seed ^ (i * 32'h9E37_79B9) | 32'h1;
    for (int k = 0; k < 8; k++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      beat[k*32 +: 32] = x;
    end
  endfunction

  static function bit [31:0] hash_beat(bit [31:0] h, bit [255:0] b);
    for (int k = 0; k < 8; k++) begin
      h ^= b[k*32 +: 32];
      h *= 32'h0100_0193;
    end
    return h;
  endfunction

  function void fill();
    data_hash = 32'h811C_9DC5;
    for (int unsigned i = 0; i < nbeats; i++) data_hash = hash_beat(data_hash, beat(i));
  endfunction

  function void post_randomize(); fill(); endfunction

  function void do_copy(uvm_object rhs);
    eth800g_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    nbeats = rhs_.nbeats;
    mty = rhs_.mty;
    data_hash = rhs_.data_hash;
    pkt_cnt = rhs_.pkt_cnt;
    byte_cnt = rhs_.byte_cnt;
    oversize = rhs_.oversize;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    eth800g_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (nbeats != rhs_.nbeats) return 0;
    if (mty != rhs_.mty) return 0;
    if (data_hash != rhs_.data_hash) return 0;
    if (pkt_cnt != rhs_.pkt_cnt) return 0;
    if (byte_cnt != rhs_.byte_cnt) return 0;
    if (oversize != rhs_.oversize) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(eth800g_transaction rhs_);
    if (nbeats != rhs_.nbeats) return 0;
    if (mty != rhs_.mty) return 0;
    if (data_hash != rhs_.data_hash) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("800G Ethernet{tag=%0d nbeats=0x%0h mty=0x%0h data_hash=0x%0h pkt_cnt=0x%0h byte_cnt=0x%0h oversize=0x%0h}", tag, nbeats, mty, data_hash, pkt_cnt, byte_cnt, oversize);
  endfunction
endclass
