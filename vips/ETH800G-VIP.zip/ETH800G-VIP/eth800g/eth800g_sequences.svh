// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_sequences.svh -- 800G Ethernet sequences

// Random traffic: cfg.num_items constrained-random items.
class eth800g_base_sequence extends uvm_sequence #(eth800g_transaction);
  `uvm_object_utils(eth800g_base_sequence)
  eth800g_config cfg;

  function new(string name = "eth800g_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = eth800g_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "eth800g_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class eth800g_directed_sequence extends uvm_sequence #(eth800g_transaction);
  `uvm_object_utils(eth800g_directed_sequence)
  eth800g_config cfg;

  function new(string name = "eth800g_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function eth800g_transaction item();
    item = eth800g_transaction::type_id::create("req");
  endfunction

  task send(eth800g_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    eth800g_transaction t;
    t = item(); t.nbeats = 2;   t.mty = 0;  t.seed = 1; t.fill(); send(t);   // 64 B
    t = item(); t.nbeats = 1;   t.mty = 31; t.seed = 2; t.fill(); send(t);   // 1 B
    t = item(); t.nbeats = 48;  t.mty = 2;  t.seed = 3; t.fill(); send(t);   // 1534 B
    t = item(); t.nbeats = 300; t.mty = 0;  t.seed = 4; t.fill(); send(t);   // 9600 B: largest legal
    t = item(); t.nbeats = 301; t.mty = 31; t.seed = 5; t.fill(); send(t);   // 9601 B: oversize
    t = item(); t.nbeats = 302; t.mty = 0;  t.seed = 6; t.fill(); send(t);
  endtask
endclass
