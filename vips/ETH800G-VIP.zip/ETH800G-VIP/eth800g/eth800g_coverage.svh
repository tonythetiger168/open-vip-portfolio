// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_coverage.svh -- 800G Ethernet functional coverage

class eth800g_coverage extends uvm_subscriber #(eth800g_transaction);
  `uvm_component_utils(eth800g_coverage)
  eth800g_config cfg;
  eth800g_transaction tr;

  covergroup eth800g_cg;
    coverpoint tr.pkt_valid;
    coverpoint tr.pkt_sop;
    coverpoint tr.pkt_eop;
    coverpoint tr.pkt_data;
    coverpoint tr.pkt_mty;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(eth800g_config)::get(this, "*", "cfg", cfg));
    eth800g_cg = new();
  endfunction

  function void write(eth800g_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    eth800g_cg.sample();
  endfunction
endclass
