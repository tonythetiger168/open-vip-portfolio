// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_coverage.svh -- 800G Ethernet functional coverage

class eth800g_coverage extends uvm_subscriber #(eth800g_transaction);
  `uvm_component_utils(eth800g_coverage)
  eth800g_config cfg;
  eth800g_transaction tr;

  covergroup eth800g_cg;
    cp_len  : coverpoint tr.bytes_len() { bins tiny = {[1:63]}; bins normal = {[64:1518]}; bins jumbo = {[1519:9600]}; bins over = {[9601:$]}; }
    cp_over : coverpoint tr.oversize;
    cp_mty  : coverpoint tr.mty { bins full = {0}; bins partial = {[1:30]}; bins one_byte = {31}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    eth800g_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(eth800g_config)::get(this, "", "cfg", cfg))
      cfg = eth800g_config::type_id::create("cfg");
  endfunction

  function void write(eth800g_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    eth800g_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("800G Ethernet coverage: %0.1f%%", eth800g_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
