// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_if.sv -- 800G Ethernet interface

interface eth800g_if (input logic clk);
  logic rst_n;

  logic pkt_valid;
  logic pkt_sop;
  logic pkt_eop;
  logic [255:0] pkt_data;
  logic [4:0] pkt_mty;
  logic pkt_ready;
  logic [15:0] pkt_cnt;
  logic [31:0] byte_cnt;
  logic err_oversize;

  modport DUT (input clk, rst_n, pkt_valid, pkt_sop, pkt_eop, pkt_data, pkt_mty, output pkt_ready, pkt_cnt, byte_cnt, err_oversize);
  modport DRV (input clk, rst_n, pkt_ready, pkt_cnt, byte_cnt, err_oversize, output pkt_valid, pkt_sop, pkt_eop, pkt_data, pkt_mty);
  modport MON (input clk, rst_n, pkt_valid, pkt_sop, pkt_eop, pkt_data, pkt_mty, pkt_ready, pkt_cnt, byte_cnt, err_oversize);

  clocking drv_cb @(posedge clk);
    input rst_n, pkt_valid, pkt_sop, pkt_eop, pkt_data, pkt_mty, pkt_ready, pkt_cnt, byte_cnt, err_oversize;
    output pkt_valid, pkt_sop, pkt_eop, pkt_data, pkt_mty;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, pkt_valid, pkt_sop, pkt_eop, pkt_data, pkt_mty, pkt_ready, pkt_cnt, byte_cnt, err_oversize;
  endclocking
endinterface
