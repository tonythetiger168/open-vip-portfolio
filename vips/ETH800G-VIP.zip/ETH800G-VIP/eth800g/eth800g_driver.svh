// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_driver.svh -- 800G Ethernet driver: one packet per item, pkt_sop/pkt_eop framing and pkt_mty on the last beat

class eth800g_driver extends uvm_driver #(eth800g_transaction);
  `uvm_component_utils(eth800g_driver)

  uvm_analysis_port #(eth800g_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual eth800g_if vif;
  eth800g_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual eth800g_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "eth800g: virtual interface not set")
    if (!uvm_config_db#(eth800g_config)::get(this, "", "cfg", cfg))
      cfg = eth800g_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    eth800g_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.pkt_valid <= 1'b0; vif.drv_cb.pkt_sop <= 1'b0; vif.drv_cb.pkt_eop <= 1'b0;
    vif.drv_cb.pkt_data <= '0; vif.drv_cb.pkt_mty <= '0;
  endtask

  task drive_item(eth800g_transaction t);
    @(vif.drv_cb);
    for (int unsigned i = 0; i < t.nbeats; i++) begin
      vif.drv_cb.pkt_valid <= 1'b1;
      vif.drv_cb.pkt_sop   <= (i == 0);
      vif.drv_cb.pkt_eop   <= (i == t.nbeats - 1);
      vif.drv_cb.pkt_mty   <= (i == t.nbeats - 1) ? t.mty : 5'd0;
      vif.drv_cb.pkt_data  <= t.beat(i);
      begin
        int unsigned to = 0;
        do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.pkt_ready === 1'b1) && to < cfg.timeout_cycles);
        if (!(vif.drv_cb.pkt_ready === 1'b1)) `uvm_error("TIMEOUT", $sformatf("800G pkt_ready: no response within %0d cycles", cfg.timeout_cycles))
      end
    end
    vif.drv_cb.pkt_valid <= 1'b0;
    vif.drv_cb.pkt_sop   <= 1'b0;
    vif.drv_cb.pkt_eop   <= 1'b0;
    @(vif.drv_cb);
  endtask

endclass
