// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_compliance_checker.sv -- 800G Ethernet concurrent assertion checks (bindable)

module eth800g_compliance_checker
  (input logic clk, input logic rst_n, input pkt_valid, input pkt_sop, input pkt_eop, input [255:0] pkt_data, input [4:0] pkt_mty, input pkt_ready, input [15:0] pkt_cnt, input [31:0] byte_cnt, input err_oversize);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({pkt_ready, pkt_cnt, byte_cnt, err_oversize}))
    else $error("800G Ethernet: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> pkt_ready == '0)
    else $error("800G Ethernet: output not in reset value");
  assert property (@(posedge clk) disable iff (!rst_n) err_oversize |=> !err_oversize)
    else $error("ETH800G: err_oversize not a pulse");
  assert property (@(posedge clk) disable iff (!rst_n) pkt_eop && !pkt_valid |-> !pkt_cnt)
    else $error("ETH800G: count changed without valid");
  cover property (@(posedge clk) disable iff (!rst_n) (pkt_ready != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (pkt_valid && pkt_sop && pkt_eop));
endmodule
