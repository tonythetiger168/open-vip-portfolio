// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_monitor.svh -- 800G Ethernet monitor: packets from SOP to EOP; counters sampled the clock after EOP

class eth800g_monitor extends uvm_monitor;
  `uvm_component_utils(eth800g_monitor)

  virtual eth800g_if vif;
  uvm_analysis_port #(eth800g_transaction) ap;
  eth800g_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual eth800g_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "eth800g: virtual interface not set")
    if (!uvm_config_db#(eth800g_config)::get(this, "", "cfg", cfg))
      cfg = eth800g_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      eth800g_transaction t, done;
      forever begin
        @(vif.mon_cb);
        if (done != null) begin
          done.pkt_cnt  = vif.mon_cb.pkt_cnt;
          done.byte_cnt = vif.mon_cb.byte_cnt;
          done.oversize = vif.mon_cb.err_oversize;
          publish(done);
          done = null;
        end
        if (vif.mon_cb.pkt_valid && vif.mon_cb.pkt_ready) begin
          if (vif.mon_cb.pkt_sop) begin
            if (t != null) `uvm_error("MON", "800G SOP inside a packet")
            t = eth800g_transaction::type_id::create("t");
            t.data_hash = 32'h811C_9DC5;
          end
          if (t == null) `uvm_error("MON", "800G beat outside a packet")
          else begin
            t.nbeats++;
            t.data_hash = eth800g_transaction::hash_beat(t.data_hash, vif.mon_cb.pkt_data);
            if (vif.mon_cb.pkt_eop) begin
              t.mty = vif.mon_cb.pkt_mty;
              done = t;
              t = null;
            end
          end
        end
      end
    end
  endtask

  function void publish(eth800g_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
