// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_monitor.svh -- 800G Ethernet monitor: decodes observed bus activity

class eth800g_monitor extends uvm_monitor;
  `uvm_component_utils(eth800g_monitor)

  virtual eth800g_if vif;
  uvm_analysis_port #(eth800g_transaction) ap;
  eth800g_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual eth800g_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "eth800g: virtual interface not set")
    void'(uvm_config_db#(eth800g_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    eth800g_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = eth800g_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.pkt_valid = vif.pkt_valid;
        t.pkt_sop = vif.pkt_sop;
        t.pkt_eop = vif.pkt_eop;
        t.pkt_data = vif.pkt_data;
        t.pkt_mty = vif.pkt_mty;
        t.pkt_ready_o = vif.pkt_ready;
        t.pkt_cnt_o = vif.pkt_cnt;
        t.byte_cnt_o = vif.byte_cnt;
        t.err_oversize_o = vif.err_oversize;
        ap.write(t);
      end
    end
  endtask
endclass
