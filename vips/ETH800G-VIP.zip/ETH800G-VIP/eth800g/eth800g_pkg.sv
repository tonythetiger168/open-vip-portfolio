// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// eth800g_pkg.sv -- 800G Ethernet UVM VIP package

package eth800g_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import eth800g_defs_pkg::*;
  export eth800g_defs_pkg::*;

  `include "eth800g_transaction.svh"
  `include "eth800g_config.svh"
  `include "eth800g_sequencer.svh"
  `include "eth800g_driver.svh"
  `include "eth800g_monitor.svh"
  `include "eth800g_agent.svh"
  `include "eth800g_sequences.svh"
  `include "eth800g_checker.svh"
  `include "eth800g_coverage.svh"
endpackage
