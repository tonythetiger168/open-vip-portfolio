# 800G Ethernet UVM VIP (ETH800G-VIP)

800G Ethernet UVM VIP: 256-bit MAC-side segment interface (SOP/EOP, modulus on final beat) with packet/byte counters and oversize detect. Targets AI-cluster fabric smoke; complements GMII/RGMII/XGMII family.

## Structure

- `eth800g/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `eth800g_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `eth800g_base_test` (constrained-random), `eth800g_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural 800G Ethernet DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/ETH800G-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh ETH800G-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py ETH800G-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
