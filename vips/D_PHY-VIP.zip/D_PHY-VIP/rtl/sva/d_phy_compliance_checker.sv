// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// d_phy_compliance_checker.sv -- D-PHY tiered compliance SVA checker (module)
// L1 = basic compliance, L2 = full protocol, L3 = advanced, L4 = protocol-specific
`ifndef D_PHY_COMPLIANCE_CHECKER_SV
`define D_PHY_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module d_phy_compliance_checker (mipi_vip_if vif);
  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_dphy_lp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.lp_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_dphy_lp: assert property(p_dphy_lp) l1_pass[0]++; else begin `uvm_warning("D-PHY_L1", "LP state valid failed"); l1_fail[0]++; end
  cover_p_dphy_lp: cover property(p_dphy_lp);
  property p_dphy_hs; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_data |-> vif.hs_mode; endproperty
  assert_p_dphy_hs: assert property(p_dphy_hs) l1_pass[1]++; else begin `uvm_warning("D-PHY_L1", "HS data valid failed"); l1_fail[1]++; end
  cover_p_dphy_hs: cover property(p_dphy_hs);
  property p_dphy_term; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_mode |-> vif.term_en; endproperty
  assert_p_dphy_term: assert property(p_dphy_term) l1_pass[2]++; else begin `uvm_warning("D-PHY_L1", "Termination on HS failed"); l1_fail[2]++; end
  cover_p_dphy_term: cover property(p_dphy_term);
  property p_dphy_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.hs_mode |-> !$isunknown(vif.hs_data); endproperty
  assert_p_dphy_no_x: assert property(p_dphy_no_x) l1_pass[3]++; else begin `uvm_warning("D-PHY_L1", "No X in HS failed"); l1_fail[3]++; end
  cover_p_dphy_no_x: cover property(p_dphy_no_x);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_dphy_stop; @(posedge vif.clk) disable iff (!vif.rst_n) vif.lp_state == 3'b100 |-> ##[1:10] vif.lp_state == 3'b000; endproperty
  assert_p_dphy_stop: assert property(p_dphy_stop) l2_pass[0]++; else begin `uvm_warning("D-PHY_L2", "Stop state failed"); l2_fail[0]++; end
  cover_p_dphy_stop: cover property(p_dphy_stop);
  property p_dphy_escape; @(posedge vif.clk) disable iff (!vif.rst_n) vif.escape |-> vif.lp_state == 3'b010; endproperty
  assert_p_dphy_escape: assert property(p_dphy_escape) l2_pass[1]++; else begin `uvm_warning("D-PHY_L2", "Escape valid failed"); l2_fail[1]++; end
  cover_p_dphy_escape: cover property(p_dphy_escape);
  property p_dphy_clk; @(posedge vif.clk) disable iff (!vif.rst_n) vif.clk_lane |-> vif.hs_mode || vif.lp_state != 3'b000; endproperty
  assert_p_dphy_clk: assert property(p_dphy_clk) l2_pass[2]++; else begin `uvm_warning("D-PHY_L2", "Clock lane failed"); l2_fail[2]++; end
  cover_p_dphy_clk: cover property(p_dphy_clk);
  property p_dphy_ulps; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ulps |-> vif.lp_state == 3'b101; endproperty
  assert_p_dphy_ulps: assert property(p_dphy_ulps) l2_pass[3]++; else begin `uvm_warning("D-PHY_L2", "ULPS valid failed"); l2_fail[3]++; end
  cover_p_dphy_ulps: cover property(p_dphy_ulps);

  // ===== L3: Advanced Features (2 SVAs) =====
  property p_dphy_calibration; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cal_done |-> vif.hs_mode == 0; endproperty
  assert_p_dphy_calibration: assert property(p_dphy_calibration) l3_pass[0]++; else begin `uvm_warning("D-PHY_L3", "Calibration failed"); l3_fail[0]++; end
  cover_p_dphy_calibration: cover property(p_dphy_calibration);
  property p_dphy_skew; @(posedge vif.clk) disable iff (!vif.rst_n) vif.skew_cal |-> vif.lane_count > 0; endproperty
  assert_p_dphy_skew: assert property(p_dphy_skew) l3_pass[1]++; else begin `uvm_warning("D-PHY_L3", "Skew calibration failed"); l3_fail[1]++; end
  cover_p_dphy_skew: cover property(p_dphy_skew);

  // ---------------- L4: D-PHY protocol-specific rules (4) ----------------
  property p_dphy_l4_hs_entry; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.lp_state == 3'b011 ##1 vif.lp_state == 3'b001) |-> ##[1:4] vif.lp_state == 3'b000; endproperty
  assert_p_dphy_l4_hs_entry: assert property(p_dphy_l4_hs_entry) l4_pass[0]++; else begin `uvm_warning("D-PHY_L4", "Illegal HS entry sequence failed"); l4_fail[0]++; end
  cover_p_dphy_l4_hs_entry: cover property(p_dphy_l4_hs_entry);
  property p_dphy_l4_sync_word; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.hs_mode) |-> vif.hs_data == 8'hB8; endproperty
  assert_p_dphy_l4_sync_word: assert property(p_dphy_l4_sync_word) l4_pass[1]++; else begin `uvm_warning("D-PHY_L4", "HS sync word not 0xB8 failed"); l4_fail[1]++; end
  cover_p_dphy_l4_sync_word: cover property(p_dphy_l4_sync_word);
  property p_dphy_l4_ulps_exit; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.lp_state == 3'b101) |-> s_eventually (vif.lp_state == 3'b011); endproperty
  assert_p_dphy_l4_ulps_exit: assert property(p_dphy_l4_ulps_exit) l4_pass[2]++; else begin `uvm_warning("D-PHY_L4", "ULPS without exit to LP-11 failed"); l4_fail[2]++; end
  cover_p_dphy_l4_ulps_exit: cover property(p_dphy_l4_ulps_exit);
  property p_dphy_l4_escape_lp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.escape |-> !vif.hs_mode; endproperty
  assert_p_dphy_l4_escape_lp: assert property(p_dphy_l4_escape_lp) l4_pass[3]++; else begin `uvm_warning("D-PHY_L4", "Escape mode during HS failed"); l4_fail[3]++; end
  cover_p_dphy_l4_escape_lp: cover property(p_dphy_l4_escape_lp);

  final begin : sva_report
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("D-PHY_RPT", $sformatf("=== D-PHY Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("D-PHY_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("D-PHY_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("D-PHY_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("D-PHY_RPT", $sformatf("  L4 Protocol Specific:  %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("D-PHY_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
