# Interlaken — Interlaken v1.2 UVM VIP

Open-source UVM verification IP template for **Interlaken v1.2** (Networking).

## Contents

| Path | Description |
|------|-------------|
| `intlkn/intlkn_if.sv` | 64-bit word interface (SOP/EOP/channel/diag sideband) + link FSM enum |
| `intlkn/intlkn_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `intlkn/sva/intlkn_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=5) |
| `intlkn/vip/intlkn/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/intlkn_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional Interlaken RX DUT model |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Link bring-up**: driver walks RESET -> SELF_TEST -> META_LOCK -> WORD_SYNC -> ACTIVE using diagnostic (meta) words; periodic diag words hold meta lock during traffic
- **Burst transmission**: 64B-aligned bursts (multiple of 8 x 64-bit words) with SOP/EOP and per-word channel sideband; back-to-back and multi-channel traffic
- **Error injection**: EOP-missing bursts (scoped SVA disable + monitor eop=0 decode) and meta-lock loss via diag starvation with automatic relock
- **Waveform-decoding monitor**: reconstructs bursts from the word stream; contiguous-burst rules close a burst on EOP, gap, or early SOP (EOP-missing case)
- **Functional DUT model**: Interlaken RX with its own lock FSM (diag-count meta lock -> word sync -> active, diag-starvation watchdog) and a 2-cycle-latency burst echo on rx_*
- **End-to-end scoreboard**: expected vs observed bursts (channel / SOP / EOP / all burst words); leftover-queue detection at end of test
- **Directed sequence library**: min-burst / max-burst / multi-channel / back-to-back / lock-relock / align-stress / error-inject / reset + random + regression mix
- **Functional coverage**: channel x burst-length cross, first-word data corners, link FSM state + startup/relock transition sequences, EOP-missing x alignment error cross
- **Transaction checker**: 64B alignment and channel-range checks on decoded bursts
- **SVA L4**: SOP implies eventual EOP (no early SOP), burst 64B alignment counter, no burst data unless ACTIVE, channel limit, EOP-missing error cover
