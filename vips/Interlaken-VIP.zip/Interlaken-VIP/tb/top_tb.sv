// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- Interlaken testbench top with a functional Interlaken RX DUT

`ifndef INTLKN_TB_SV
`define INTLKN_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import intlkn_defs_pkg::*;
import intlkn_pkg::*;
import intlkn_test_pkg::*;

module top_tb;
  logic tx_clk = 0;
  always #5ns tx_clk = ~tx_clk;

  intlkn_if vif(tx_clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  intlkn_rx_dut dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual intlkn_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional Interlaken RX: runs its own lock state machine driven by the
// diagnostic (meta) word stream -- consecutive diag words advance
// RX_META -> RX_SYNC -> RX_ACTIVE, and a diag-starvation watchdog drops
// the lock again. While active, received bursts are echoed back on
// rx_data/rx_sop/rx_eop with two cycles of latency.
module intlkn_rx_dut (intlkn_if vif);
  import intlkn_defs_pkg::*;

  typedef enum bit [1:0] {RX_RESET, RX_META, RX_SYNC, RX_ACTIVE} rx_state_e;

  rx_state_e   rx_st;
  int unsigned diag_cnt;
  int unsigned watchdog;

  // echo pipeline (2-stage)
  bit [63:0] d0, d1;
  bit        v0, v1, s0, s1, e0, e1;

  wire diag_word = vif.tx_valid && vif.tx_diag && (vif.tx_data == INTM_DIAG_WORD);
  wire data_word = vif.tx_valid && !vif.tx_diag;

  always_ff @(posedge vif.tx_clk or negedge vif.rst_n) begin
    if (!vif.rst_n) begin
      rx_st    <= RX_RESET;
      diag_cnt <= 0;
      watchdog <= 0;
      {v0, v1} <= 2'b00;
      vif.rx_valid <= 1'b0;
      vif.rx_data  <= 64'h0;
      vif.rx_sop   <= 1'b0;
      vif.rx_eop   <= 1'b0;
    end else begin
      // ---- lock state machine ----
      case (rx_st)
        RX_RESET: begin
          if (diag_word) begin rx_st <= RX_META; diag_cnt <= 1; end
        end
        RX_META: begin
          if (diag_word) begin
            diag_cnt <= diag_cnt + 1;
            if (diag_cnt >= INTM_LOCK_DIAGS-1) begin rx_st <= RX_SYNC; diag_cnt <= 0; end
          end else if (data_word) begin
            rx_st <= RX_RESET; diag_cnt <= 0;   // unexpected data before lock
          end
        end
        RX_SYNC: begin
          if (diag_word) begin
            diag_cnt <= diag_cnt + 1;
            if (diag_cnt >= INTM_LOCK_DIAGS-1) begin rx_st <= RX_ACTIVE; diag_cnt <= 0; end
          end else if (data_word) begin
            rx_st <= RX_RESET; diag_cnt <= 0;
          end
        end
        RX_ACTIVE: begin
          if (diag_word)      watchdog <= 0;
          else if (!data_word) begin
            watchdog <= watchdog + 1;
            if (watchdog >= 32) begin           // meta lock lost
              rx_st    <= RX_RESET;
              watchdog <= 0;
            end
          end
        end
        default: rx_st <= RX_RESET;
      endcase

      // ---- burst echo pipeline (2-cycle latency) ----
      d0 <= vif.tx_data;  v0 <= data_word && (rx_st == RX_ACTIVE);
      s0 <= vif.tx_sop;   e0 <= vif.tx_eop;
      d1 <= d0;           v1 <= v0;
      s1 <= s0;           e1 <= e0;
      vif.rx_data  <= d1;
      vif.rx_sop   <= s1 && v1;
      vif.rx_eop   <= e1 && v1;
      vif.rx_valid <= v1;
    end
  end
endmodule
`endif
