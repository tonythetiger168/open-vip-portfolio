// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_intlkn_tb.sv -- self-checking functional test for the Interlaken
// receiver model (intlkn_rx_dut in tb/top_tb.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py Interlaken-VIP
//
// Model contract (from tb/top_tb.sv and intlkn_defs_pkg):
//   * lock: 4 diagnostic words (tx_diag with 0xD1A6_0000_5A5A_3C3C) take the
//     receiver from reset through META to SYNC, 4 more to ACTIVE; a data
//     word before lock restarts the sequence. A diag-flagged word with any
//     other value counts as neither.
//   * ACTIVE: data words pass to rx_* with a 3-clock latency, sop/eop kept;
//     diagnostic words are not forwarded and reset a watchdog that counts
//     idle clocks; the 33rd idle clock without a diagnostic word drops lock.

module func_intlkn_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [63:0] DIAG = 64'hD1A6_0000_5A5A_3C3C;
  localparam bit [1:0]  RESET = 0, META = 1, SYNC = 2, ACTIVE = 3;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, sop = 0, eop = 0, valid = 0, diag = 0;
  logic [63:0] data = '0;
  wire  [63:0] rx_data;
  wire         rx_sop, rx_eop, rx_valid;

  always #5 clk = ~clk;

  intlkn_rx_dut u_dut (
    .vif_tx_clk(clk), .vif_rst_n(rst_n), .vif_tx_data(data), .vif_tx_sop(sop), .vif_tx_eop(eop),
    .vif_tx_valid(valid), .vif_tx_diag(diag), .vif_rx_data(rx_data), .vif_rx_sop(rx_sop),
    .vif_rx_eop(rx_eop), .vif_rx_valid(rx_valid)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic [63:0] got[$];
  logic [1:0]  flags[$];
  int          sent_at[$], lat[$];
  int          cyc = 0;
  always @(posedge clk) begin
    cyc++;
    if (rx_valid === 1'b1) begin got.push_back(rx_data); flags.push_back({rx_sop, rx_eop}); lat.push_back(cyc); end
  end

  bit stray_flag;
  always @(posedge clk) if ((rx_sop === 1'b1 || rx_eop === 1'b1) && rx_valid !== 1'b1) stray_flag = 1;

  task automatic diag_w(input int n = 1, input [63:0] v = DIAG);
    repeat (n) begin
      @(negedge clk); valid = 1; diag = 1; data = v; sop = 0; eop = 0;
    end
    @(negedge clk); valid = 0; diag = 0;
  endtask

  task automatic burst(input int n, input [63:0] base);
    for (int i = 0; i < n; i++) begin
      @(negedge clk); valid = 1; diag = 0; data = base + i; sop = (i == 0); eop = (i == n - 1);
      sent_at.push_back(cyc + 1);
    end
    @(negedge clk); valid = 0; sop = 0; eop = 0;
  endtask

  task automatic idle(input int n); repeat (n) @(negedge clk); endtask

  function automatic bit [1:0] st(); return u_dut.rx_st; endfunction

  initial begin
    idle(2);
    rst_n = 1;
    idle(2);
    chk(st() == RESET && !rx_valid, "reset: unlocked, no output");

    // data before lock is dropped
    burst(4, 64'h100);
    idle(5);
    chk(got.size() == 0, "data before lock is not forwarded");

    // lock sequence
    diag_w(3);
    chk(st() == META, "three diagnostic words: META");
    diag_w(1);
    chk(st() == SYNC, "fourth diagnostic word: SYNC");
    diag_w(3);
    chk(st() == SYNC, "seven diagnostic words: still SYNC");
    diag_w(1);
    chk(st() == ACTIVE, "eighth diagnostic word: ACTIVE");

    // data transfer
    got.delete(); flags.delete(); lat.delete(); sent_at.delete();
    burst(8, 64'hA000_0000_0000_0000);
    idle(5);
    chk(got.size() == 8, $sformatf("eight words forwarded (got %0d)", got.size()));
    begin
      bit ok = 1;
      foreach (got[i]) if (got[i] != 64'hA000_0000_0000_0000 + i) ok = 0;
      chk(ok, "data forwarded in order and unchanged");
    end
    chk(flags[0] == 2'b10 && flags[7] == 2'b01 && flags[3] == 2'b00, "sop on the first word, eop on the last");
    chk(lat.size() > 0 && lat[0] - sent_at[0] == 3, $sformatf("3-clock latency: output registered on the third edge (%0d)", lat.size() ? lat[0] - sent_at[0] : -1));

    // diagnostic words are not forwarded
    got.delete();
    burst(2, 64'h11); diag_w(2); burst(2, 64'h22);
    idle(5);
    chk(got.size() == 4 && got[1] == 64'h12 && got[2] == 64'h22, "diagnostic words removed from the data stream");

    // single-word packet
    got.delete(); flags.delete();
    burst(1, 64'h77);
    idle(5);
    chk(got.size() == 1 && flags[0] == 2'b11, "single-word packet has sop and eop");

    // framing flags on idle cycles are not forwarded
    @(negedge clk); sop = 1; eop = 1;
    @(negedge clk); sop = 0; eop = 0; valid = 1; diag = 1; data = DIAG; sop = 1;
    @(negedge clk); valid = 0; diag = 0; sop = 0;
    idle(4);
    chk(!stray_flag, "sop/eop on idle or diagnostic cycles never reach rx_sop/rx_eop");

    // watchdog: 32 idle clocks after a diagnostic word are tolerated, the 33rd drops lock
    diag_w(1);
    idle(30);
    chk(st() == ACTIVE, "lock held through 30 idle clocks");
    diag_w(1);
    idle(32);
    chk(st() == ACTIVE, "diagnostic word resets the watchdog; 32 idle clocks tolerated");
    idle(1);
    chk(st() == RESET, "lock lost on the 33rd idle clock without a diagnostic word");
    got.delete();
    burst(3, 64'h55);
    idle(5);
    chk(got.size() == 0, "no data forwarded after losing lock");

    // a word flagged diag with the wrong value does not count toward lock
    diag_w(8, 64'h1234);
    chk(st() == RESET, "diag-flagged words with the wrong value do not lock");

    // data during SYNC restarts lock
    diag_w(5);
    chk(st() == SYNC, "back in SYNC");
    burst(1, 64'h9);
    chk(st() == RESET, "data word during SYNC restarts lock");
    diag_w(4); burst(1, 64'h9);
    chk(st() == RESET, "data word during META restarts lock");

    // reset clears the pipeline
    diag_w(8);
    @(negedge clk); valid = 1; data = 64'hF; sop = 1; eop = 1;
    @(negedge clk); valid = 0; rst_n = 0;
    @(negedge clk);
    chk(!rx_valid && st() == RESET, "reset clears lock and output");
    rst_n = 1;
    idle(4);
    chk(!rx_valid, "in-flight word discarded by reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
