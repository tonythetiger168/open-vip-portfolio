// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// intlkn_transaction.svh -- Interlaken burst transaction: a 64B-aligned
// burst of 64-bit words on a logical channel, delimited by SOP/EOP.

`ifndef INTLKN_TRANSACTION_SVH
`define INTLKN_TRANSACTION_SVH

class intlkn_transaction extends uvm_sequence_item;

  rand bit [7:0]  channel;          // logical channel (0..INTM_MAX_CHANNEL)
  rand bit [63:0] burst[$];         // 64-bit burst words (SOP..EOP)
  rand bit        inj_eop_missing;  // error injection: drop the EOP word
  rand bit        lose_lock;        // error injection: stop diag words, link relocks

  bit        sop;                   // observed/driven SOP flag
  bit        eop;                   // observed/driven EOP flag (0 when deleted)

  constraint c_chan  { channel inside {[0:intlkn_defs_pkg::INTM_MAX_CHANNEL]}; }
  constraint c_len   { burst.size() inside {[8:64]};
                       burst.size() % intlkn_defs_pkg::INTM_ALIGN_WORDS == 0; }
  constraint c_eop   { inj_eop_missing dist {0 := 15, 1 := 1}; }
  constraint c_lock  { lose_lock dist {0 := 15, 1 := 1};
                       solve inj_eop_missing before lose_lock;
                       (inj_eop_missing == 1) -> (lose_lock == 0); }

  `uvm_object_utils_begin(intlkn_transaction)
    `uvm_field_int(channel, UVM_ALL_ON)
    `uvm_field_queue_int(burst, UVM_ALL_ON)
    `uvm_field_int(sop, UVM_ALL_ON)
    `uvm_field_int(eop, UVM_ALL_ON)
    `uvm_field_int(inj_eop_missing, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(lose_lock, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "intlkn_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    intlkn_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= comparer.compare_field("channel", channel, t.channel, 8);
    do_compare &= comparer.compare_field("sop", sop, t.sop, 1);
    do_compare &= comparer.compare_field("eop", eop, t.eop, 1);
    do_compare &= comparer.compare_field("blen", burst.size(), t.burst.size(), 32);
  endfunction

  function string convert2string();
    return $sformatf("INTLKN ch=%0d blen=%0d sop=%0b eop=%0b inj_eop=%0b lose_lock=%0b",
                     channel, burst.size(), sop, eop, inj_eop_missing, lose_lock);
  endfunction
endclass
`endif
