// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// intlkn_pkg.sv -- Interlaken v1.2 UVM VIP package

package intlkn_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import intlkn_defs_pkg::*;
  export intlkn_defs_pkg::*;

  `include "intlkn_transaction.svh"
  `include "intlkn_config.svh"
  `include "intlkn_sequencer.svh"
  `include "intlkn_driver.svh"
  `include "intlkn_monitor.svh"
  `include "intlkn_agent.svh"
  `include "intlkn_sequences.svh"
  `include "intlkn_checker.svh"
  `include "intlkn_coverage.svh"
endpackage
