// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// intlkn_if.sv -- Interlaken v1.2 interface
// 64-bit words with SOP/EOP/channel sideband; tx_diag marks diagnostic
// (meta) words. tx_* is the transmit direction driven by the VIP driver;
// rx_* is the DUT echo direction. inj_eop_missing marks deliberate EOP
// deletion so the related protocol assertion can be scoped out.

interface intlkn_if (input logic tx_clk);
  import intlkn_defs_pkg::intlkn_state_e;

  logic        rst_n;
  logic [63:0] tx_data;
  logic        tx_sop;
  logic        tx_eop;
  logic        tx_valid;
  logic [7:0]  tx_chan;
  logic        tx_diag;
  logic        inj_eop_missing;
  logic [63:0] rx_data;
  logic        rx_sop;
  logic        rx_eop;
  logic        rx_valid;

  intlkn_state_e state;      // transmit link state (driven by VIP driver)

  modport DUT (input  tx_clk, rst_n, tx_data, tx_sop, tx_eop, tx_valid,
                      tx_chan, tx_diag,
               output rx_data, rx_sop, rx_eop, rx_valid);
  modport TB  (input  tx_clk, rx_data, rx_sop, rx_eop, rx_valid,
               output rst_n, tx_data, tx_sop, tx_eop, tx_valid, tx_chan,
                      tx_diag, inj_eop_missing, state);
  modport MON (input  tx_clk, rst_n, tx_data, tx_sop, tx_eop, tx_valid,
                      tx_chan, tx_diag, inj_eop_missing,
                      rx_data, rx_sop, rx_eop, rx_valid, state);

  clocking drv_cb @(posedge tx_clk);
    output tx_data, tx_sop, tx_eop, tx_valid, tx_chan, tx_diag,
           inj_eop_missing, state;
    input  rst_n, rx_data, rx_sop, rx_eop, rx_valid;
  endclocking

  clocking mon_cb @(posedge tx_clk);
    input rst_n, tx_data, tx_sop, tx_eop, tx_valid, tx_chan, tx_diag,
          inj_eop_missing, rx_data, rx_sop, rx_eop, rx_valid, state;
  endclocking
endinterface
