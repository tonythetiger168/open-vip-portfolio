// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// intlkn_monitor.svh -- Interlaken monitor: decodes bursts from the
// tx_data/tx_sop/tx_eop/tx_chan stream while the link is ACTIVE.
// Bursts are contiguous; a gap or a new SOP before EOP finalizes the
// previous burst with eop=0 (EOP-missing error case).

`ifndef INTLKN_MONITOR_SVH
`define INTLKN_MONITOR_SVH

class intlkn_monitor extends uvm_monitor;
  `uvm_component_utils(intlkn_monitor)
  virtual intlkn_if vif;
  uvm_analysis_port #(intlkn_transaction) ap;
  int unsigned txn_count = 0;

  protected intlkn_transaction cur;
  protected bit collecting;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual intlkn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "intlkn virtual interface not set")
  endfunction

  function void finalize(bit got_eop);
    if (!collecting || cur == null) return;
    cur.eop = got_eop;
    txn_count++;
    `uvm_info("MON", {"mon: ", cur.convert2string()}, UVM_HIGH)
    ap.write(cur);
    cur = null;
    collecting = 0;
  endfunction

  task run_phase(uvm_phase phase);
    collecting = 0;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n !== 1'b1) begin
        cur = null; collecting = 0;
        continue;
      end
      if (vif.mon_cb.state != intlkn_defs_pkg::ACTIVE) begin
        // link down: drop any partial burst silently (driver re-sends)
        cur = null; collecting = 0;
        continue;
      end
      if (vif.mon_cb.tx_valid && !vif.mon_cb.tx_diag) begin
        // burst data word
        if (vif.mon_cb.tx_sop) begin
          finalize(1'b0);              // previous burst never saw EOP
          cur = intlkn_transaction::type_id::create("cur");
          cur.sop     = 1'b1;
          cur.channel = vif.mon_cb.tx_chan;
          collecting  = 1;
        end else if (!collecting) begin
          // stray data word without SOP: start an implicit burst
          cur = intlkn_transaction::type_id::create("cur");
          cur.sop     = 1'b0;
          cur.channel = vif.mon_cb.tx_chan;
          collecting  = 1;
        end
        cur.burst.push_back(vif.mon_cb.tx_data);
        if (vif.mon_cb.tx_eop) finalize(1'b1);
      end else begin
        // idle or diag word: bursts are contiguous, so a gap closes the
        // current burst (EOP-missing case)
        finalize(1'b0);
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("intlkn monitor observed %0d bursts", txn_count), UVM_LOW)
  endfunction
endclass
`endif
