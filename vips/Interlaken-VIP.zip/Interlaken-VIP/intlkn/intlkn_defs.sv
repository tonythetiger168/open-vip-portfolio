// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// intlkn_defs.sv -- Interlaken v1.2 shared type definitions

package intlkn_defs_pkg;
  // Link state machine: RESET -> (SELF_TEST) -> META_LOCK -> WORD_SYNC ->
  // ACTIVE. Loss of meta lock returns the link towards RESET/META_LOCK.
  typedef enum bit [2:0] {
    RESET,
    META_LOCK,
    WORD_SYNC,
    ACTIVE,
    SELF_TEST
  } intlkn_state_e;

  localparam bit [63:0] INTM_DIAG_WORD   = 64'hD1A6_0000_5A5A_3C3C; // diagnostic/meta word
  localparam int unsigned INTM_MAX_CHANNEL = 31;   // channels 0..31
  localparam int unsigned INTM_ALIGN_WORDS = 8;    // 64B boundary = 8 x 64-bit words
  localparam int unsigned INTM_LOCK_DIAGS  = 4;    // diag words to advance lock FSM
endpackage
