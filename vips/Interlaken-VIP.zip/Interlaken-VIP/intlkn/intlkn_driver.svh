// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// intlkn_driver.svh -- Interlaken transmit driver.
// Brings the link up (RESET -> SELF_TEST -> META_LOCK -> WORD_SYNC ->
// ACTIVE) using diagnostic/meta words, sends periodic diag words to hold
// meta lock, and transmits 64B-aligned bursts with SOP/EOP/channel
// sideband. Supports EOP-missing and meta-lock-loss error injection.
// Expected bursts are broadcast on drv_ap for the scoreboard.

`ifndef INTLKN_DRIVER_SVH
`define INTLKN_DRIVER_SVH

class intlkn_driver extends uvm_driver #(intlkn_transaction);
  `uvm_component_utils(intlkn_driver)
  virtual intlkn_if vif;
  intlkn_config cfg;
  uvm_analysis_port #(intlkn_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual intlkn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "intlkn virtual interface not set")
  endfunction

  task idle_cycle(int unsigned n = 1);
    vif.drv_cb.tx_valid <= 1'b0;
    vif.drv_cb.tx_sop   <= 1'b0;
    vif.drv_cb.tx_eop   <= 1'b0;
    vif.drv_cb.tx_diag  <= 1'b0;
    vif.drv_cb.tx_data  <= 64'h0;
    repeat (n) @(vif.drv_cb);
  endtask

  // One diagnostic (meta) word
  task send_diag();
    vif.drv_cb.tx_data  <= intlkn_defs_pkg::INTM_DIAG_WORD;
    vif.drv_cb.tx_diag  <= 1'b1;
    vif.drv_cb.tx_sop   <= 1'b0;
    vif.drv_cb.tx_eop   <= 1'b0;
    vif.drv_cb.tx_valid <= 1'b1;
    @(vif.drv_cb);
    vif.drv_cb.tx_valid <= 1'b0;
    vif.drv_cb.tx_diag  <= 1'b0;
  endtask

  // Link startup: RESET -> SELF_TEST -> META_LOCK -> WORD_SYNC -> ACTIVE
  task link_startup();
    vif.drv_cb.state <= intlkn_defs_pkg::RESET;
    idle_cycle(2);
    vif.drv_cb.state <= intlkn_defs_pkg::SELF_TEST;
    idle_cycle(2);
    vif.drv_cb.state <= intlkn_defs_pkg::META_LOCK;
    repeat (intlkn_defs_pkg::INTM_LOCK_DIAGS) send_diag();
    vif.drv_cb.state <= intlkn_defs_pkg::WORD_SYNC;
    repeat (intlkn_defs_pkg::INTM_LOCK_DIAGS) send_diag();
    vif.drv_cb.state <= intlkn_defs_pkg::ACTIVE;
    idle_cycle(1);
  endtask

  // Error injection: meta lock loss -- diag words stop, the link partner's
  // watchdog drops lock and the link is brought up again.
  task relock();
    vif.drv_cb.state <= intlkn_defs_pkg::META_LOCK;
    idle_cycle(40);                              // diag starvation -> lock loss
    repeat (intlkn_defs_pkg::INTM_LOCK_DIAGS) send_diag();
    vif.drv_cb.state <= intlkn_defs_pkg::WORD_SYNC;
    repeat (intlkn_defs_pkg::INTM_LOCK_DIAGS) send_diag();
    vif.drv_cb.state <= intlkn_defs_pkg::ACTIVE;
    idle_cycle(1);
  endtask

  // Send one burst: contiguous words, SOP on the first, EOP on the last
  // (EOP deleted when inj_eop_missing is set).
  task send_burst(intlkn_transaction tr);
    vif.drv_cb.inj_eop_missing <= tr.inj_eop_missing;
    foreach (tr.burst[i]) begin
      vif.drv_cb.tx_data  <= tr.burst[i];
      vif.drv_cb.tx_chan  <= tr.channel;
      vif.drv_cb.tx_sop   <= (i == 0);
      vif.drv_cb.tx_eop   <= (i == tr.burst.size()-1) && !tr.inj_eop_missing;
      vif.drv_cb.tx_diag  <= 1'b0;
      vif.drv_cb.tx_valid <= 1'b1;
      @(vif.drv_cb);
    end
    vif.drv_cb.tx_valid <= 1'b0;
    vif.drv_cb.tx_sop   <= 1'b0;
    vif.drv_cb.tx_eop   <= 1'b0;
    vif.drv_cb.inj_eop_missing <= 1'b0;
    idle_cycle(1);
    tr.sop = 1'b1;
    tr.eop = !tr.inj_eop_missing;
  endtask

  task run_phase(uvm_phase phase);
    intlkn_transaction tr;
    // Deterministic drives during reset so SVA never samples X.
    vif.drv_cb.tx_data  <= 64'h0;
    vif.drv_cb.tx_sop   <= 1'b0;
    vif.drv_cb.tx_eop   <= 1'b0;
    vif.drv_cb.tx_valid <= 1'b0;
    vif.drv_cb.tx_chan  <= 8'h0;
    vif.drv_cb.tx_diag  <= 1'b0;
    vif.drv_cb.inj_eop_missing <= 1'b0;
    vif.drv_cb.state    <= intlkn_defs_pkg::RESET;
    wait (vif.rst_n === 1'b1);
    link_startup();
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      if (tr.lose_lock) relock();
      else              send_diag();          // periodic diag holds meta lock
      send_burst(tr);
      drv_ap.write(tr);                       // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
