// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// intlkn_sequences.svh -- Interlaken sequence library

`ifndef INTLKN_SEQUENCES_SVH
`define INTLKN_SEQUENCES_SVH

class intlkn_base_sequence extends uvm_sequence #(intlkn_transaction);
  `uvm_object_utils(intlkn_base_sequence)
  int num_txns = 20;
  function new(string name = "intlkn_base_sequence"); super.new(name); endfunction
  task body();
    intlkn_transaction tr;
    repeat (num_txns) begin
      tr = intlkn_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: minimum-length (64B, single-boundary) bursts
class intlkn_min_burst_seq extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_min_burst_seq)
  function new(string name = "intlkn_min_burst_seq"); super.new(name); endfunction
  task body();
    intlkn_transaction tr;
    repeat (num_txns) begin
      tr = intlkn_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { burst.size() == 8;
                                  inj_eop_missing == 0; lose_lock == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: maximum-length bursts (512B)
class intlkn_max_burst_seq extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_max_burst_seq)
  function new(string name = "intlkn_max_burst_seq"); super.new(name); endfunction
  task body();
    intlkn_transaction tr;
    repeat (num_txns) begin
      tr = intlkn_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { burst.size() == 64;
                                  inj_eop_missing == 0; lose_lock == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: walk all channels round-robin
class intlkn_multi_channel_seq extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_multi_channel_seq)
  function new(string name = "intlkn_multi_channel_seq"); super.new(name); endfunction
  task body();
    intlkn_transaction tr;
    for (int c = 0; c <= intlkn_defs_pkg::INTM_MAX_CHANNEL; c++) begin
      tr = intlkn_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { channel == c;
                                  inj_eop_missing == 0; lose_lock == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back bursts on the same channel
class intlkn_back_to_back_seq extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_back_to_back_seq)
  function new(string name = "intlkn_back_to_back_seq"); super.new(name); endfunction
  rand bit [7:0] target = 8'd7;
  task body();
    intlkn_transaction tr;
    repeat (num_txns) begin
      tr = intlkn_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { channel == target; burst.size() == 8;
                                  inj_eop_missing == 0; lose_lock == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: meta-lock loss and relock cycles
class intlkn_lock_seq extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_lock_seq)
  function new(string name = "intlkn_lock_seq"); super.new(name); num_txns = 3; endfunction
  task body();
    intlkn_transaction tr;
    repeat (num_txns) begin
      tr = intlkn_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { lose_lock == 1; inj_eop_missing == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: 64B alignment stress (all legal burst lengths)
class intlkn_align_seq extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_align_seq)
  function new(string name = "intlkn_align_seq"); super.new(name); endfunction
  task body();
    intlkn_transaction tr;
    for (int n = 8; n <= 64; n += 8) begin
      tr = intlkn_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { burst.size() == n;
                                  inj_eop_missing == 0; lose_lock == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: EOP-missing bursts mixed with meta-lock loss
class intlkn_error_inject_seq extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_error_inject_seq)
  function new(string name = "intlkn_error_inject_seq"); super.new(name); num_txns = 8; endfunction
  task body();
    intlkn_transaction tr;
    repeat (num_txns) begin
      tr = intlkn_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inj_eop_missing dist {0 := 1, 1 := 1};
                                  lose_lock        dist {0 := 1, 1 := 1}; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single burst right after link startup
class intlkn_reset_seq extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_reset_seq)
  function new(string name = "intlkn_reset_seq"); super.new(name); endfunction
  task body();
    intlkn_transaction tr = intlkn_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { burst.size() == 8;
                                inj_eop_missing == 0; lose_lock == 0; });
    finish_item(tr);
  endtask
endclass

class intlkn_random_sequence extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_random_sequence)
  function new(string name = "intlkn_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class intlkn_regression_sequence extends intlkn_base_sequence;
  `uvm_object_utils(intlkn_regression_sequence)
  function new(string name = "intlkn_regression_sequence"); super.new(name); endfunction
  task body();
    intlkn_min_burst_seq      mn  = intlkn_min_burst_seq::type_id::create("mn");
    intlkn_max_burst_seq      mx  = intlkn_max_burst_seq::type_id::create("mx");
    intlkn_multi_channel_seq  mc  = intlkn_multi_channel_seq::type_id::create("mc");
    intlkn_back_to_back_seq   b2b = intlkn_back_to_back_seq::type_id::create("b2b");
    intlkn_lock_seq           lk  = intlkn_lock_seq::type_id::create("lk");
    intlkn_align_seq          al  = intlkn_align_seq::type_id::create("al");
    intlkn_error_inject_seq   err = intlkn_error_inject_seq::type_id::create("err");
    mn.num_txns = 10; mx.num_txns = 4; b2b.num_txns = 10;
    mn.start(m_sequencer);
    mx.start(m_sequencer);
    mc.start(m_sequencer);
    b2b.start(m_sequencer);
    lk.start(m_sequencer);
    al.start(m_sequencer);
    err.start(m_sequencer);
  endtask
endclass
`endif
