// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// intlkn_checker.svh -- Interlaken transaction checker: verifies burst
// 64B alignment and channel range of decoded bursts.

`ifndef INTLKN_CHECKER_SVH
`define INTLKN_CHECKER_SVH

class intlkn_checker extends uvm_component;
  `uvm_component_utils(intlkn_checker)
  uvm_analysis_imp #(intlkn_transaction, intlkn_checker) chk_ap;
  int unsigned checked = 0, errors = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    chk_ap = new("chk_ap", this);
  endfunction

  function void write(intlkn_transaction tr);
    checked++;
    if (tr.channel > intlkn_defs_pkg::INTM_MAX_CHANNEL) begin
      errors++;
      `uvm_error("CHK", $sformatf("channel %0d above maximum", tr.channel))
    end
    // EOP-terminated bursts must be 64B aligned
    if (tr.eop && (tr.burst.size() % intlkn_defs_pkg::INTM_ALIGN_WORDS != 0)) begin
      errors++;
      `uvm_error("CHK", $sformatf("burst length %0d violates 64B alignment",
                 tr.burst.size()))
    end
    if (tr.burst.size() == 0) begin
      errors++;
      `uvm_error("CHK", "empty burst observed")
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHECKER", $sformatf("intlkn: checked=%0d errors=%0d", checked, errors), UVM_LOW)
  endfunction
endclass
`endif
