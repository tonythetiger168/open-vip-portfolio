// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// intlkn_compliance_checker.sv -- Interlaken SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = Interlaken burst/link rules

`ifndef INTLKN_COMPLIANCE_CHECKER_SV
`define INTLKN_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import intlkn_defs_pkg::*;

module intlkn_compliance_checker
(
  input logic         tx_clk,
  input logic         rst_n,
  input intlkn_state_e state,
  input logic [63:0]  tx_data,
  input logic         tx_sop,
  input logic         tx_eop,
  input logic         tx_valid,
  input logic [7:0]   tx_chan,
  input logic         tx_diag,
  input logic         inj_eop_missing
);

  // ---------------- L1: signal sanity (4) ----------------
  a_intlkn_l1_clk   : assert property (@(posedge tx_clk) disable iff (!rst_n) !$isunknown(tx_clk))
    else `uvm_error("SVA_L1", "intlkn: clock unknown")
  a_intlkn_l1_rst   : assert property (@(posedge tx_clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "intlkn: reset unknown")
  a_intlkn_l1_state : assert property (@(posedge tx_clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "intlkn: state unknown")
  a_intlkn_l1_valid : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state inside {RESET, META_LOCK, WORD_SYNC, ACTIVE, SELF_TEST})
    else `uvm_error("SVA_L1", "intlkn: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from RESET
  a_intlkn_trans_reset : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == RESET |=> state inside {RESET, SELF_TEST, META_LOCK})
    else `uvm_error("SVA_L2", "intlkn: illegal transition from RESET")

  // L2-2: legal FSM transition from SELF_TEST
  a_intlkn_trans_self_test : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == SELF_TEST |=> state inside {SELF_TEST, META_LOCK, RESET})
    else `uvm_error("SVA_L2", "intlkn: illegal transition from SELF_TEST")

  // L2-3: legal FSM transition from META_LOCK
  a_intlkn_trans_meta_lock : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == META_LOCK |=> state inside {META_LOCK, WORD_SYNC, RESET})
    else `uvm_error("SVA_L2", "intlkn: illegal transition from META_LOCK")

  // L2-4: legal FSM transition from WORD_SYNC
  a_intlkn_trans_word_sync : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == WORD_SYNC |=> state inside {WORD_SYNC, ACTIVE, RESET})
    else `uvm_error("SVA_L2", "intlkn: illegal transition from WORD_SYNC")

  // L2-5: legal FSM transition from ACTIVE (lock loss -> META_LOCK/RESET)
  a_intlkn_trans_active : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == ACTIVE |=> state inside {ACTIVE, META_LOCK, RESET})
    else `uvm_error("SVA_L2", "intlkn: illegal transition from ACTIVE")

  // ---------------- L3: protocol rules (4) ----------------
  a_intlkn_l3_reset_idle : assert property (@(posedge tx_clk)
    $fell(rst_n) |-> ##[1:4] (state == RESET))
    else `uvm_error("SVA_L3", "intlkn: state not RESET during reset")
  a_intlkn_l3_lock_prog  : assert property (@(posedge tx_clk) disable iff (!rst_n)
    state == META_LOCK |-> ##[1:64] (state == WORD_SYNC))
    else `uvm_error("SVA_L3", "intlkn: meta lock not progressing to word sync")
  a_intlkn_l3_full_cycle : cover property (@(posedge tx_clk) disable iff (!rst_n)
    state == RESET ##[1:8] state == SELF_TEST ##[1:8] state == META_LOCK
    ##[1:16] state == WORD_SYNC ##[1:16] state == ACTIVE);
  a_intlkn_l3_relock     : cover property (@(posedge tx_clk) disable iff (!rst_n)
    state == ACTIVE ##1 state == META_LOCK);

  // ---------------- L4: Interlaken burst/link rules (5) ----------------
  // L4-1: SOP is always followed by EOP (no new SOP before EOP).
  //       Scoped out while the EOP-missing error injection is active.
  a_intlkn_l4_sop_then_eop : assert property (@(posedge tx_clk)
    disable iff (!rst_n || inj_eop_missing)
    (tx_sop && !tx_eop) |=> (!tx_sop) until tx_eop)
    else `uvm_error("SVA_L4", "intlkn: SOP without EOP (new SOP arrived first)")

  // L4-2: bursts are 64B aligned: SOP..EOP word count is a multiple of 8
  int unsigned burst_cnt = 0;
  bit          in_burst = 0;
  always @(posedge tx_clk) begin
    if (!rst_n) begin
      burst_cnt <= 0;
      in_burst  <= 0;
    end else if (tx_valid && !tx_diag) begin
      if (tx_sop) begin
        burst_cnt <= 1;
        in_burst  <= !tx_eop;
      end else if (in_burst) begin
        burst_cnt <= burst_cnt + 1;
        if (tx_eop) begin
          in_burst <= 0;
          a_intlkn_l4_burst_align : assert ((burst_cnt + 1) % INTM_ALIGN_WORDS == 0)
            else `uvm_error("SVA_L4", "intlkn: burst not aligned to 64B boundary")
        end
      end
    end
  end

  // L4-3: no burst data unless the link is ACTIVE
  a_intlkn_l4_active_only : assert property (@(posedge tx_clk) disable iff (!rst_n)
    (tx_valid && !tx_diag) |-> (state == ACTIVE))
    else `uvm_error("SVA_L4", "intlkn: burst data transmitted while link not ACTIVE")

  // L4-4: channel number within range
  a_intlkn_l4_chan_limit : assert property (@(posedge tx_clk) disable iff (!rst_n)
    (tx_valid && !tx_diag) |-> (tx_chan <= INTM_MAX_CHANNEL))
    else `uvm_error("SVA_L4", "intlkn: channel above maximum")

  // L4-5: cover the EOP-missing error case (SOP, gap without EOP, new SOP)
  c_intlkn_l4_eop_missing_seen : cover property (@(posedge tx_clk) disable iff (!rst_n)
    inj_eop_missing ##[1:$] (tx_sop && !tx_eop));

endmodule
`endif
