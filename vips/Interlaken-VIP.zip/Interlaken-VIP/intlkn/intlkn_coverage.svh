// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// intlkn_coverage.svh -- Interlaken functional coverage.
// cg_protocol samples decoded bursts (channel x burst-length cross),
// cg_fsm samples the link FSM from the interface on state changes,
// cg_error covers EOP-missing and lock-loss error scenarios.

`ifndef INTLKN_COVERAGE_SVH
`define INTLKN_COVERAGE_SVH

class intlkn_coverage extends uvm_subscriber #(intlkn_transaction);
  `uvm_component_utils(intlkn_coverage)

  virtual intlkn_if vif;
  intlkn_transaction tr;

  covergroup cg_protocol;
    cp_chan : coverpoint tr.channel {
      bins low  = {[0:15]};
      bins high = {[16:31]};
    }
    cp_len  : coverpoint tr.burst.size() {
      bins min    = {8};
      bins short  = {[16:32]};
      bins long   = {[40:56]};
      bins max    = {64};
    }
    cp_sop  : coverpoint tr.sop { bins sop = {1}; }
    cp_data : coverpoint tr.burst[0] iff (tr.burst.size() > 0) {
      bins zero = {64'h0};
      bins ones = {64'hFFFF_FFFF_FFFF_FFFF};
      bins val  = default;
    }
    cx_chan_len : cross cp_chan, cp_len;
  endgroup

  covergroup cg_fsm with function sample(intlkn_state_e s);
    cp_state : coverpoint s {
      bins states[] = {RESET, SELF_TEST, META_LOCK, WORD_SYNC, ACTIVE};
    }
    cp_trans : coverpoint s {
      bins startup = (RESET => SELF_TEST => META_LOCK => WORD_SYNC => ACTIVE);
      bins relock  = (ACTIVE => META_LOCK => WORD_SYNC => ACTIVE);
    }
  endgroup

  covergroup cg_error;
    cp_eop   : coverpoint tr.eop { bins eop = {1}; bins missing = {0}; }
    cp_align : coverpoint (tr.burst.size() % intlkn_defs_pkg::INTM_ALIGN_WORDS) {
      bins aligned = {0};
    }
    cx_eop_align : cross cp_eop, cp_align;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual intlkn_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "intlkn virtual interface not set")
  endfunction

  function void write(intlkn_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction

  task run_phase(uvm_phase phase);
    intlkn_state_e prev;
    prev = intlkn_state_e'('x);
    forever begin
      @(posedge vif.tx_clk);
      if (vif.rst_n === 1'b1) begin
        // sample FSM on state change so chained transition bins can hit
        if (vif.state !== prev) begin
          cg_fsm.sample(vif.state);
          prev = vif.state;
        end
      end
    end
  endtask
endclass
`endif
