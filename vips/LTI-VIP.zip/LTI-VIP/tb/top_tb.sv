// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- LTI testbench top with a functional translation unit DUT model

`ifndef LTI_TB_SV
`define LTI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import lti_defs_pkg::*;
import lti_pkg::*;
import lti_test_pkg::*;

module top_tb;
  logic aclk = 0;
  always #5ns aclk = ~aclk;

  lti_if vif(aclk);

  initial begin
    vif.aresetn = 0;
    #100ns;
    vif.aresetn = 1;
  end

  lti_translation_unit_model dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual lti_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional LTI translation unit: registered la_ready (~80%), single
// outstanding translation, 1-6 cycle translation latency, identity map
// (paddr = vaddr) for normal addresses, translation fault (resp=FAULT,
// paddr=0) for the fault region (vaddr[51:48] == 0xF).
module lti_translation_unit_model (lti_if vif);
  localparam bit [1:0] RESP_OK = 2'b00, RESP_FAULT = 2'b01;

  bit         pend;
  bit [7:0]   pend_id;
  bit [51:0]  pend_va;
  int unsigned xlate_timer;

  initial begin
    vif.la_ready = 0;
    vif.lr_valid = 0;
    vif.lr_id    = '0;
    vif.lr_resp  = RESP_OK;
    vif.lr_paddr = '0;
    pend         = 0;
    xlate_timer  = 0;
  end

  always_ff @(posedge vif.aclk or negedge vif.aresetn) begin
    if (!vif.aresetn) begin
      vif.la_ready <= 0;
      vif.lr_valid <= 0;
      vif.lr_id    <= '0;
      vif.lr_resp  <= RESP_OK;
      vif.lr_paddr <= '0;
      pend         <= 0;
      xlate_timer  <= 0;
    end else begin
      // Registered ready: ~80% while no translation is outstanding
      vif.la_ready <= !pend && ($urandom_range(4) != 0);
      vif.lr_valid <= 1'b0;

      // LA handshake: latch the translation request
      if (vif.la_valid && vif.la_ready) begin
        pend        <= 1;
        pend_id     <= vif.la_id;
        pend_va     <= vif.la_addr;
        xlate_timer <= $urandom_range(1, 6);
      end

      // LR channel: respond after the translation latency (lr_ready is
      // held high by the requester, so the response is a single cycle)
      if (pend) begin
        if (xlate_timer > 1) begin
          xlate_timer <= xlate_timer - 1;
        end else begin
          pend        <= 0;
          vif.lr_valid <= 1'b1;
          vif.lr_id    <= pend_id;
          if (pend_va[51:48] == 4'hF) begin
            vif.lr_resp  <= RESP_FAULT;   // translation fault: no paddr
            vif.lr_paddr <= 52'h0;
          end else begin
            vif.lr_resp  <= RESP_OK;      // identity map
            vif.lr_paddr <= pend_va;
          end
        end
      end
    end
  end
endmodule
`endif
