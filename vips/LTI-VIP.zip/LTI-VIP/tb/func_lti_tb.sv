// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_lti_tb.sv -- self-checking functional test for the Arm LTI
// translation-unit model (lti_translation_unit_model, flattened by
// smoke/flatten.py). Run: python3 tools/run_func_tests.py LTI-VIP
//
// Model contract (from tb/top_tb.sv):
//   LA channel: request (la_id, la_addr) accepted on la_valid && la_ready;
//   la_ready is randomly throttled and low while a translation is pending
//   (one outstanding request). LR channel: after 1..6 clocks a one-clock
//   lr_valid returns the same id with resp OK and paddr = VA (identity map),
//   or resp FAULT and paddr 0 when VA[51:48] == 0xF.

module func_lti_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [1:0] OK = 2'b00, FAULT = 2'b01;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0, la_valid = 1'b0;
  logic [7:0]  la_id = '0;
  logic [51:0] la_addr = '0;
  wire         la_ready, lr_valid;
  wire  [7:0]  lr_id;
  wire  [1:0]  lr_resp;
  wire  [51:0] lr_paddr;

  always #5 clk = ~clk;

  lti_translation_unit_model u_dut (
    .vif_aclk(clk), .vif_aresetn(rst_n), .vif_la_valid(la_valid), .vif_la_ready(la_ready),
    .vif_la_id(la_id), .vif_la_addr(la_addr), .vif_lr_valid(lr_valid), .vif_lr_id(lr_id),
    .vif_lr_resp(lr_resp), .vif_lr_paddr(lr_paddr)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  int xfails = 0;

  // protocol monitors
  int ready_while_pending = 0, lr_pulses = 0, lr_long = 0;
  logic lr_valid_d = 0;
  always @(posedge clk) begin
    if (rst_n && u_dut.pend && la_ready) ready_while_pending++;
    if (lr_valid) lr_pulses++;
    if (lr_valid && lr_valid_d) lr_long++;
    lr_valid_d <= lr_valid;
  end

  // issue one request, wait for its response; lat = clocks from the
  // accepting edge to lr_valid
  logic [7:0]  rid;
  logic [1:0]  rresp;
  logic [51:0] rpa;
  int          lat, accept_wait;
  task automatic xlate(input [7:0] id, input [51:0] va);
    @(negedge clk);
    la_valid = 1'b1; la_id = id; la_addr = va;
    accept_wait = 0;
    while (la_ready !== 1'b1) begin @(negedge clk); accept_wait++; end
    @(negedge clk);                       // accepted at the edge just passed
    la_valid = 1'b0; la_addr = 52'hBAD_BAD0_BAD0;
    lat = 0;
    while (lr_valid !== 1'b1 && lat < 20) begin @(negedge clk); lat++; end
    rid = lr_id; rresp = lr_resp; rpa = lr_paddr;
  endtask

  int bad_lat = 0, bad_map = 0;
  int lat_hist [8];

  initial begin
    repeat (2) @(negedge clk);
    chk(la_ready === 1'b0 && lr_valid === 1'b0, "no ready / no response during reset");
    rst_n = 1'b1;

    xlate(8'h11, 52'h0_0012_3456_7000);
    chk(rid == 8'h11 && rresp == OK && rpa == 52'h0_0012_3456_7000,
        "translation returns the request id, OKAY and the identity-mapped PA");
    xlate(8'h22, 52'hF_0000_0000_1000);
    chk(rid == 8'h22 && rresp == FAULT && rpa == 52'h0, "VA[51:48]=0xF faults with PA 0");
    xlate(8'h33, 52'hE_FFFF_FFFF_F000);
    chk(rresp == OK && rpa == 52'hE_FFFF_FFFF_F000, "VA just below the fault region translates");

    // randomised sweep: latency bound and mapping on every request
    for (int i = 0; i < 80; i++) begin
      logic [51:0] va;
      va = {4'($urandom_range(15)), 48'({$urandom, $urandom}) << 12};
      xlate(8'(i), va);
      if (lat < 1 || lat > 7) begin bad_lat++; $display("  lat=%0d i=%0d", lat, i); end
      else lat_hist[lat]++;
      if (rid != 8'(i) || (va[51:48] == 4'hF ? (rresp != FAULT || rpa != 0) : (rresp != OK || rpa != va)))
        bad_map++;
    end
    repeat (2) @(negedge clk);           // let the monitors see the last pulse
    chk(bad_lat == 0, "every response arrives within 1..7 clocks of acceptance");
    chk(bad_map == 0, "80 random requests: ids, responses and PAs all correct");
    begin
      int lo, hi, n;
      lo = 8; hi = 0; n = 0;
      for (int l = 1; l < 8; l++) if (lat_hist[l] > 0) begin
        n++;
        if (l < lo) lo = l;
        hi = l;
      end
      chk(n == 6 && hi - lo == 5, $sformatf("six distinct translation latencies, one per timer value 1..6 (%0d..%0d, %0d values)", lo, hi, n));
    end
    chk(ready_while_pending == 0, "la_ready is low while a translation is outstanding");
    chk(lr_long == 0 && lr_pulses == 83, "exactly one single-clock lr_valid per request");

    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(la_ready === 1'b0 && lr_valid === 1'b0 && u_dut.pend === 1'b0, "reset clears pending state");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
