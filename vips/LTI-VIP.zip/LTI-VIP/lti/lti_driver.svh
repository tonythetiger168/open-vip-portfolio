// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lti_driver.svh -- LTI requester driver
// Issues LA translation requests (la_valid held until la_ready) and
// collects the matching LR response by translation id.

`ifndef LTI_DRIVER_SVH
`define LTI_DRIVER_SVH

class lti_driver extends uvm_driver #(lti_transaction);
  `uvm_component_utils(lti_driver)
  virtual lti_if vif;
  lti_config cfg;
  uvm_analysis_port #(lti_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual lti_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "lti virtual interface not set")
  endfunction

  task drive_req(lti_transaction tr);
    int unsigned tmo = 0;
    `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
    // LA channel: hold the request stable until accepted (la_ready)
    vif.state = lti_defs_pkg::REQUEST;
    vif.drv_cb.la_valid <= 1'b1;
    vif.drv_cb.la_id    <= tr.id;
    vif.drv_cb.la_addr  <= tr.vaddr;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "lti LA accept timeout")
    end while (!vif.drv_cb.la_ready);
    vif.drv_cb.la_valid <= 1'b0;
    // LR channel: wait for the response carrying this translation id
    vif.state = lti_defs_pkg::TRANSLATE;
    tmo = 0;
    do begin
      @(vif.drv_cb);
      if (++tmo > 1000) `uvm_fatal("DRV", "lti LR response timeout")
    end while (!(vif.drv_cb.lr_valid && vif.drv_cb.lr_id == tr.id));
    tr.resp  = lti_transaction::lti_resp_e'(vif.drv_cb.lr_resp);
    tr.paddr = vif.drv_cb.lr_paddr;
    vif.state = (tr.resp == lti_transaction::LTI_RESP_FAULT)
                ? lti_defs_pkg::FAULT : lti_defs_pkg::RESPONSE;
    if (tr.resp == lti_transaction::LTI_RESP_FAULT)
      `uvm_info("DRV", $sformatf("translation fault for va=0x%013h", tr.vaddr), UVM_MEDIUM)
    @(vif.drv_cb);
    vif.state = lti_defs_pkg::IDLE;
  endtask

  task run_phase(uvm_phase phase);
    lti_transaction tr;
    vif.drv_cb.la_valid <= 1'b0;
    vif.drv_cb.lr_ready <= 1'b1;   // requester always ready for responses
    vif.state = lti_defs_pkg::IDLE;
    wait (vif.aresetn === 1'b1);
    repeat (2) @(vif.drv_cb);
    forever begin
      seq_item_port.get_next_item(tr);
      drive_req(tr);
      drv_ap.write(tr);                 // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
