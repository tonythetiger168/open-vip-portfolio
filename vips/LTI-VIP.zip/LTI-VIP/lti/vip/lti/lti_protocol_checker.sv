// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lti_protocol_checker.sv -- ARM Local Translation Interface protocol rule checker

`ifndef LTI_PROTOCOL_CHECKER_SV
`define LTI_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import lti_defs_pkg::lti_state_e;

module lti_protocol_checker
(
  input logic aclk,
  input logic aresetn,
  input lti_state_e state
);
  a_lti_protocol_state_known : assert property (@(posedge aclk)
    disable iff (!aresetn) !$isunknown(state))
    else `uvm_error("PROTOCOL", "lti protocol: state unknown")
endmodule
`endif
