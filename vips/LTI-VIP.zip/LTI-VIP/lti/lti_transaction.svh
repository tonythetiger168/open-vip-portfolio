// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lti_transaction.svh -- LTI translation transaction (LA request + LR response)

`ifndef LTI_TRANSACTION_SVH
`define LTI_TRANSACTION_SVH

class lti_transaction extends uvm_sequence_item;

  typedef enum bit [1:0] {LTI_RESP_OK    = 2'b00,
                          LTI_RESP_FAULT = 2'b01} lti_resp_e;

  rand bit [7:0]  id;            // translation tag (LA id <-> LR id)
  rand bit [51:0] vaddr;         // virtual address to translate
  rand bit        error_inject;  // 1 = request a faulting VA range

  bit [51:0]      paddr;         // observed translated physical address
  lti_resp_e      resp;          // observed translation response
  int unsigned    latency;       // monitor: cycles from LA accept to LR

  constraint c_align { vaddr[11:0] == 12'h0; }   // 4 KB page aligned
  constraint c_err   { error_inject dist {0 := 7, 1 := 3}; }

  `uvm_object_utils_begin(lti_transaction)
    `uvm_field_int(id, UVM_ALL_ON)
    `uvm_field_int(vaddr, UVM_ALL_ON)
    `uvm_field_int(error_inject, UVM_ALL_ON)
    `uvm_field_int(paddr, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_enum(lti_resp_e, resp, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(latency, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "lti_transaction");
    super.new(name);
  endfunction

  // Fault injection region: top nibble of the 52-bit VA space
  function bit is_fault_va();
    return vaddr[51:48] == 4'hF;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    lti_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    ok &= comparer.compare_field("id",    id,    t.id,    8);
    ok &= comparer.compare_field("vaddr", vaddr, t.vaddr, 52);
    return ok;
  endfunction

  function string convert2string();
    return $sformatf("LTI id=0x%02h va=0x%013h -> pa=0x%013h resp=%s lat=%0d err=%0b",
                     id, vaddr, paddr,
                     resp == LTI_RESP_FAULT ? "FAULT" : "OK",
                     latency, error_inject);
  endfunction
endclass
`endif
