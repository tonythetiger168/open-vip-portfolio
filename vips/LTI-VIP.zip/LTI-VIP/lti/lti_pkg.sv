// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lti_pkg.sv -- ARM Local Translation Interface UVM VIP package

package lti_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import lti_defs_pkg::*;
  export lti_defs_pkg::*;

  `include "lti_transaction.svh"
  `include "lti_config.svh"
  `include "lti_sequencer.svh"
  `include "lti_driver.svh"
  `include "lti_monitor.svh"
  `include "lti_agent.svh"
  `include "lti_sequences.svh"
  `include "lti_checker.svh"
  `include "lti_coverage.svh"
endpackage
