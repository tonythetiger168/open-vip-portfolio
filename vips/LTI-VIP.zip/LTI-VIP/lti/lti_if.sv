// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lti_if.sv -- ARM Local Translation Interface (LTI)
// LA channel (requester -> translation unit): la_valid/la_ready/la_id/la_addr
// LR channel (translation unit -> requester): lr_valid/lr_ready/lr_id/lr_resp/lr_paddr
// lr_resp : 0=OK (translated paddr valid) 1=FAULT (no paddr returned)

interface lti_if (input logic aclk);
  import lti_defs_pkg::lti_state_e;

  logic        aresetn;
  // LA channel: translation request
  logic        la_valid;
  logic        la_ready;
  logic [7:0]  la_id;
  logic [51:0] la_addr;
  // LR channel: translation response
  logic        lr_valid;
  logic        lr_ready;
  logic [7:0]  lr_id;
  logic [1:0]  lr_resp;
  logic [51:0] lr_paddr;

  lti_state_e state;

  modport REQUESTER (input  aclk, aresetn, la_ready, lr_valid, lr_id, lr_resp, lr_paddr,
                     output la_valid, la_id, la_addr, lr_ready, state);
  modport TU        (input  aclk, aresetn, la_valid, la_id, la_addr, lr_ready,
                     output la_ready, lr_valid, lr_id, lr_resp, lr_paddr);
  modport MON       (input  aclk, aresetn, la_valid, la_ready, la_id, la_addr,
                           lr_valid, lr_ready, lr_id, lr_resp, lr_paddr, state);

  clocking drv_cb @(posedge aclk);
    input  aresetn, la_ready, lr_valid, lr_id, lr_resp, lr_paddr;
    output la_valid, la_id, la_addr, lr_ready;
  endclocking

  clocking mon_cb @(posedge aclk);
    input aresetn, la_valid, la_ready, la_id, la_addr,
          lr_valid, lr_ready, lr_id, lr_resp, lr_paddr, state;
  endclocking
endinterface
