// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lti_sequences.svh -- LTI sequence library

`ifndef LTI_SEQUENCES_SVH
`define LTI_SEQUENCES_SVH

class lti_base_sequence extends uvm_sequence #(lti_transaction);
  `uvm_object_utils(lti_base_sequence)
  int num_txns = 20;
  function new(string name = "lti_base_sequence"); super.new(name); endfunction
  task body();
    lti_transaction tr;
    repeat (num_txns) begin
      tr = lti_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { vaddr[51:48] != 4'hF; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: translations of low (identity-mapped) addresses
class lti_low_addr_seq extends lti_base_sequence;
  `uvm_object_utils(lti_low_addr_seq)

  function new(string name = "lti_low_addr_seq"); super.new(name); endfunction

  task body();
    lti_transaction tr;
    repeat (num_txns) begin
      tr = lti_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { vaddr[51:32] == 20'h0; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: translations of high (non-faulting) addresses
class lti_high_addr_seq extends lti_base_sequence;
  `uvm_object_utils(lti_high_addr_seq)

  function new(string name = "lti_high_addr_seq"); super.new(name); endfunction

  task body();
    lti_transaction tr;
    repeat (num_txns) begin
      tr = lti_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { vaddr[51:48] inside {[4'h1:4'hE]};
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: unique translation id per request (id sweep)
class lti_id_sweep_seq extends lti_base_sequence;
  `uvm_object_utils(lti_id_sweep_seq)

  function new(string name = "lti_id_sweep_seq"); super.new(name); endfunction

  task body();
    lti_transaction tr;
    for (int i = 0; i < 16; i++) begin
      tr = lti_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { id == i; vaddr[51:48] != 4'hF;
                                  error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: same virtual address translated repeatedly (id varies)
class lti_same_va_seq extends lti_base_sequence;
  `uvm_object_utils(lti_same_va_seq)

  function new(string name = "lti_same_va_seq"); super.new(name); endfunction

  rand bit [51:0] target = 52'h0_0000_0004_5000;
  constraint c_t { target[11:0] == 12'h0; target[51:48] != 4'hF; }
  task body();
    lti_transaction tr;
    repeat (num_txns) begin
      tr = lti_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { vaddr == target; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back translation requests (id increments)
class lti_back_to_back_seq extends lti_base_sequence;
  `uvm_object_utils(lti_back_to_back_seq)

  function new(string name = "lti_back_to_back_seq"); super.new(name); endfunction

  task body();
    lti_transaction tr;
    num_txns = 30;
    repeat (num_txns) begin
      tr = lti_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { vaddr[51:48] != 4'hF; error_inject == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: translation requests to the faulting VA range
class lti_error_inject_seq extends lti_base_sequence;
  `uvm_object_utils(lti_error_inject_seq)

  function new(string name = "lti_error_inject_seq"); super.new(name); endfunction

  task body();
    lti_transaction tr;
    repeat (6) begin
      tr = lti_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { error_inject == 1; vaddr[51:48] == 4'hF; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single translation right after reset release
class lti_reset_seq extends lti_base_sequence;
  `uvm_object_utils(lti_reset_seq)

  function new(string name = "lti_reset_seq"); super.new(name); endfunction

  task body();
    lti_transaction tr = lti_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { vaddr == 52'h0; error_inject == 0; });
    finish_item(tr);
  endtask
endclass

class lti_random_sequence extends lti_base_sequence;
  `uvm_object_utils(lti_random_sequence)
  function new(string name = "lti_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class lti_regression_sequence extends lti_base_sequence;
  `uvm_object_utils(lti_regression_sequence)
  function new(string name = "lti_regression_sequence"); super.new(name); endfunction
  task body();
    lti_low_addr_seq     lo  = lti_low_addr_seq::type_id::create("lo");
    lti_high_addr_seq    hi  = lti_high_addr_seq::type_id::create("hi");
    lti_id_sweep_seq     ids = lti_id_sweep_seq::type_id::create("ids");
    lti_same_va_seq      sv  = lti_same_va_seq::type_id::create("sv");
    lti_back_to_back_seq b2b = lti_back_to_back_seq::type_id::create("b2b");
    lti_error_inject_seq err = lti_error_inject_seq::type_id::create("err");
    lo.num_txns = 20; hi.num_txns = 20; sv.num_txns = 10;
    sv.randomize();
    lo.start(m_sequencer); hi.start(m_sequencer); ids.start(m_sequencer);
    sv.start(m_sequencer); b2b.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
`endif
