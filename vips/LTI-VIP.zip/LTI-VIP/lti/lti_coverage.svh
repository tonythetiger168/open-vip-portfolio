// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lti_coverage.svh -- LTI functional coverage

`ifndef LTI_COVERAGE_SVH
`define LTI_COVERAGE_SVH

class lti_coverage extends uvm_subscriber #(lti_transaction);
  `uvm_component_utils(lti_coverage)

  lti_transaction tr;
  lti_state_e cur_state;
  virtual lti_if vif;

  covergroup cg_protocol;
    cp_resp : coverpoint tr.resp {
      bins ok    = {lti_transaction::LTI_RESP_OK};
      bins fault = {lti_transaction::LTI_RESP_FAULT};
    }
    cp_id : coverpoint tr.id {
      bins low  = {[8'h00 : 8'h7F]};
      bins high = {[8'h80 : 8'hFF]};
    }
    cp_va_region : coverpoint tr.vaddr[51:48] {
      bins identity = {[4'h0 : 4'h7]};
      bins high     = {[4'h8 : 4'hE]};
      bins fault    = {4'hF};
    }
    cp_latency : coverpoint tr.latency {
      bins fast = {[1:2]};
      bins mid  = {[3:4]};
      bins slow = {[5:8]};
    }
    cx_resp_region : cross cp_resp, cp_va_region {
      // the fault region always faults; normal regions always translate OK
      ignore_bins ok_in_fault = binsof(cp_resp.ok) && binsof(cp_va_region.fault);
      ignore_bins fault_in_ok = binsof(cp_resp.fault) &&
                                (binsof(cp_va_region.identity) || binsof(cp_va_region.high));
    }
  endgroup

  covergroup cg_fsm with function sample(lti_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, REQUEST, TRANSLATE, RESPONSE, FAULT};
    }
    cp_trans : coverpoint s {
      bins ok_seq    = (IDLE => REQUEST => TRANSLATE => RESPONSE => IDLE);
      bins fault_seq = (TRANSLATE => FAULT => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_err : coverpoint tr.error_inject {
      bins legal = {0};
      bins fault = {1};
    }
    cp_fault_va : coverpoint tr.vaddr[51:48] iff (tr.error_inject) {
      bins fault_region = {4'hF};
    }
    cp_fault_paddr : coverpoint tr.paddr iff (tr.resp == lti_transaction::LTI_RESP_FAULT) {
      bins no_paddr = {52'h0};
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(virtual lti_if)::get(this, "", "vif", vif));
  endfunction

  function void write(lti_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_error.sample();
  endfunction

  // Sample the link FSM every cycle so all states/transitions are observable
  task run_phase(uvm_phase phase);
    if (vif == null) begin
      `uvm_warning("COV", "lti coverage: no vif, FSM coverage disabled")
      return;
    end
    forever begin
      @(posedge vif.aclk);
      cur_state = vif.state;
      cg_fsm.sample(cur_state);
    end
  endtask
endclass
`endif
