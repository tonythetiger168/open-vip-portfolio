// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lti_monitor.svh -- LTI monitor: decodes LA translation requests and pairs
// them with their LR responses (matched by translation id), measuring
// translation latency.

`ifndef LTI_MONITOR_SVH
`define LTI_MONITOR_SVH

class lti_monitor extends uvm_monitor;
  `uvm_component_utils(lti_monitor)
  virtual lti_if vif;
  uvm_analysis_port #(lti_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned fault_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual lti_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "lti virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    lti_transaction tr;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.aresetn !== 1'b1) continue;
      // LA handshake: capture the translation request
      if (vif.mon_cb.la_valid && vif.mon_cb.la_ready) begin
        tr = lti_transaction::type_id::create("tr");
        tr.id      = vif.mon_cb.la_id;
        tr.vaddr   = vif.mon_cb.la_addr;
        tr.latency = 0;
        // LR handshake: pair the response by translation id
        do begin
          @(vif.mon_cb);
          tr.latency++;
          if (tr.latency > 1000) `uvm_fatal("MON", "lti LR response timeout")
        end while (!(vif.mon_cb.lr_valid && vif.mon_cb.lr_ready &&
                     vif.mon_cb.lr_id == tr.id));
        tr.resp  = lti_transaction::lti_resp_e'(vif.mon_cb.lr_resp);
        tr.paddr = vif.mon_cb.lr_paddr;
        if (tr.resp == lti_transaction::LTI_RESP_FAULT) begin
          tr.error_inject = 1;
          fault_count++;
        end
        txn_count++;
        `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
        ap.write(tr);
      end
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("lti monitor observed %0d translations (%0d faults)",
              txn_count, fault_count), UVM_LOW)
  endfunction
endclass
`endif
