// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// lti_compliance_checker.sv -- ARM Local Translation Interface SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules, L4 = LTI-specific rules

`ifndef LTI_COMPLIANCE_CHECKER_SV
`define LTI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import lti_defs_pkg::*;

module lti_compliance_checker
(
  input logic aclk,
  input logic aresetn,
  input lti_state_e state,
  input logic la_valid,
  input logic la_ready,
  input logic [7:0] la_id,
  input logic [51:0] la_addr,
  input logic lr_valid,
  input logic lr_ready,
  input logic [7:0] lr_id,
  input logic [1:0] lr_resp,
  input logic [51:0] lr_paddr
);

  localparam bit [1:0] RESP_FAULT = 2'b01;
  localparam int unsigned MAX_OUTSTANDING = 4;

  // Outstanding translation id queue (LA accept pushes, LR handshake pops)
  bit [7:0] id_q[$];

  always @(posedge aclk or negedge aresetn) begin
    if (!aresetn) begin
      id_q.delete();
    end else begin
      if (la_valid && la_ready) id_q.push_back(la_id);
      if (lr_valid && lr_ready) void'(id_q.pop_front());
    end
  end

  // ---------------- L1: signal sanity (4) ----------------
  a_lti_l1_clk   : assert property (@(posedge aclk) disable iff (!aresetn) !$isunknown(aclk))
    else `uvm_error("SVA_L1", "lti: clock unknown")
  a_lti_l1_rst   : assert property (@(posedge aclk) !$isunknown(aresetn))
    else `uvm_error("SVA_L1", "lti: reset unknown")
  a_lti_l1_state : assert property (@(posedge aclk) disable iff (!aresetn) !$isunknown(state))
    else `uvm_error("SVA_L1", "lti: state unknown")
  a_lti_l1_valid : assert property (@(posedge aclk) disable iff (!aresetn)
    state inside {IDLE, REQUEST, TRANSLATE, RESPONSE, FAULT})
    else `uvm_error("SVA_L1", "lti: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_lti_trans_idle : assert property (@(posedge aclk) disable iff (!aresetn)
    state == IDLE |=> state inside {IDLE, REQUEST})
    else `uvm_error("SVA_L2", "lti: illegal transition from IDLE")

  // L2-2: legal FSM transition from REQUEST
  a_lti_trans_request : assert property (@(posedge aclk) disable iff (!aresetn)
    state == REQUEST |=> state inside {REQUEST, TRANSLATE})
    else `uvm_error("SVA_L2", "lti: illegal transition from REQUEST")

  // L2-3: legal FSM transition from TRANSLATE
  a_lti_trans_translate : assert property (@(posedge aclk) disable iff (!aresetn)
    state == TRANSLATE |=> state inside {TRANSLATE, RESPONSE})
    else `uvm_error("SVA_L2", "lti: illegal transition from TRANSLATE")

  // L2-4: legal FSM transition from RESPONSE
  a_lti_trans_response : assert property (@(posedge aclk) disable iff (!aresetn)
    state == RESPONSE |=> state inside {RESPONSE, FAULT})
    else `uvm_error("SVA_L2", "lti: illegal transition from RESPONSE")

  // L2-5: legal FSM transition from FAULT
  a_lti_trans_fault : assert property (@(posedge aclk) disable iff (!aresetn)
    state == FAULT |=> state inside {FAULT, IDLE})
    else `uvm_error("SVA_L2", "lti: illegal transition from FAULT")

  // ---------------- L3: protocol rules (4) ----------------
  a_lti_l3_reset_idle : assert property (@(posedge aclk)
    $fell(aresetn) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "lti: state not IDLE during reset")
  a_lti_l3_no_stuck   : assert property (@(posedge aclk) disable iff (!aresetn)
    state == FAULT |-> ##[1:8] (state != FAULT))
    else `uvm_error("SVA_L3", "lti: stuck in FAULT")
  a_lti_l3_full_cycle : cover property (@(posedge aclk) disable iff (!aresetn)
    state == IDLE ##1 state == REQUEST);
  a_lti_l3_back_idle  : cover property (@(posedge aclk) disable iff (!aresetn)
    state == FAULT ##1 state == IDLE);

  // ---------------- L4: LTI protocol-specific rules (4) ----------------
  // L4-1: an LA request must be held (valid, id, addr stable) until accepted
  a_lti_l4_la_held : assert property (@(posedge aclk) disable iff (!aresetn)
    (la_valid && !la_ready) |=>
    (la_valid && la_id == $past(la_id) && la_addr == $past(la_addr)))
    else `uvm_error("SVA_L4", "lti: LA request not held until accepted")

  // L4-2: every LR response must match the id of an outstanding LA request
  a_lti_l4_lr_matches_la : assert property (@(posedge aclk) disable iff (!aresetn)
    (lr_valid && lr_ready) |-> (id_q.size() > 0 && lr_id == id_q[0]))
    else `uvm_error("SVA_L4", "lti: LR response with no matching LA id")

  // L4-3: a fault response must not carry a translated physical address
  a_lti_l4_fault_no_paddr : assert property (@(posedge aclk) disable iff (!aresetn)
    (lr_valid && lr_resp == RESP_FAULT) |-> (lr_paddr == 52'h0))
    else `uvm_error("SVA_L4", "lti: fault response carries a paddr")

  // L4-4: outstanding translations must not exceed the configured limit
  a_lti_l4_outstanding_limit : assert property (@(posedge aclk) disable iff (!aresetn)
    id_q.size() <= MAX_OUTSTANDING)
    else `uvm_error("SVA_L4", "lti: outstanding translation limit exceeded")

endmodule
`endif
