// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
class lti_checker extends uvm_component;
  `uvm_component_utils(lti_checker)
  uvm_analysis_imp #(lti_transaction, lti_checker) chk_ap;
  int unsigned checked = 0, errors = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    chk_ap = new("chk_ap", this);
  endfunction

  function void write(lti_transaction tr);
    checked++;
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHECKER", $sformatf("lti: checked=%0d errors=%0d", checked, errors), UVM_LOW)
  endfunction
endclass
