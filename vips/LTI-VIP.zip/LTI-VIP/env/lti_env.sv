// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// lti_env.sv -- LTI verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import lti_defs_pkg::*;
  import lti_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: match_cnt requester-issued LA translations against
  // monitor-decoded LA/LR pairs and checks the translation contract
  // (OK -> identity-mapped paddr, FAULT -> no paddr).
  class lti_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(lti_scoreboard)
    uvm_analysis_imp_exp #(lti_transaction, lti_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(lti_transaction, lti_scoreboard) obs_ap;

    lti_transaction exp_q[$], obs_q[$];
    int unsigned match_cnt = 0, mismatches = 0, translations = 0, faults = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(lti_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(lti_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        lti_transaction e = exp_q.pop_front();
        lti_transaction o = obs_q.pop_front();
        if (e.id != o.id || e.vaddr != o.vaddr || e.resp != o.resp ||
            e.paddr != o.paddr) begin
          mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
          continue;
        end
        // Translation contract: identity map on OK, no paddr on FAULT
        if (o.resp == lti_transaction::LTI_RESP_OK && o.paddr != o.vaddr) begin
          mismatches++;
          `uvm_error("SB", $sformatf("identity map broken: %s", o.convert2string()))
          continue;
        end
        if (o.resp == lti_transaction::LTI_RESP_FAULT && o.paddr != 52'h0) begin
          mismatches++;
          `uvm_error("SB", $sformatf("paddr returned on fault: %s", o.convert2string()))
          continue;
        end
        if (o.resp == lti_transaction::LTI_RESP_FAULT) faults++;
        else translations++;
        match_cnt++;
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("lti scoreboard: matches=%0d mismatches=%0d translations=%0d faults=%0d",
                match_cnt, mismatches, translations, faults), UVM_LOW)
      if (mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class lti_env extends uvm_env;
    `uvm_component_utils(lti_env)
    lti_agent      agt;
    lti_scoreboard sb;
    lti_checker    chk;
    lti_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = lti_agent::type_id::create("agt", this);
      sb  = lti_scoreboard::type_id::create("sb", this);
      chk = lti_checker::type_id::create("chk", this);
      cov = lti_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
