# LTI — ARM Local Translation Interface UVM VIP

Open-source UVM verification IP template for **ARM Local Translation Interface** (Interconnect).

## Contents

| Path | Description |
|------|-------------|
| `lti/lti_if.sv` | Protocol interface + FSM state enum |
| `lti/lti_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `lti/sva/lti_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=4) |
| `lti/vip/lti/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/lti_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional translation unit DUT |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **LTI requester driver**: LA-channel request held (`la_valid`/`la_id`/`la_addr`) until `la_ready`, LR response collected by translation id (`lr_ready` always high)
- **Protocol-decoding monitor**: pairs LA requests with LR responses by translation id, measuring per-translation latency
- **End-to-end scoreboard**: matches requester vs monitor transactions and checks the translation contract (OK -> identity-mapped paddr, FAULT -> no paddr)
- **Functional DUT model**: translation unit with registered `la_ready` (~80%), 1-6 cycle translation latency, identity map, and translation-fault region (`vaddr[51:48]==0xF` -> `lr_resp=FAULT`, `lr_paddr=0`)
- **Directed sequence library**: low / high address / id sweep / same-VA repeat / back-to-back / error-inject (translation fault) / reset + regression mix
- **Functional coverage**: resp x VA-region cross, id ranges, translation latency bins, FSM state + transition sequences (incl. fault path), fault error bins
- **SVA L4**: LA held until accepted, LR matches an outstanding LA id, fault response carries no paddr, outstanding translation limit
