// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_env.sv -- CEC environment: reference-model scoreboard, checker, coverage

package cec_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import cec_defs_pkg::*;
  import cec_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class cec_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(cec_scoreboard)
    uvm_analysis_imp_exp #(cec_transaction, cec_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(cec_transaction, cec_scoreboard) obs_ap;

    cec_config cfg;
    cec_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(cec_config)::get(this, "", "cfg", cfg))
        cfg = cec_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(cec_transaction t);
      // follower (logical address 0) run on whole pulses: marks are the initiator's
      // lows, a bit's period is its mark plus the following space
      int unsigned u = cfg.cec_u, n = t.seg.size();
      int b = 0, k = 0;
      bit [7:0] sh = 0;
      bit eom = 0, ack = 0, done = 0, hdr = 0;
      t.odata.delete(); t.nack = 0; t.epulse = 0;
      t.rstatus = 4; t.rinit = 0; t.rdest = 0; t.rlen = 0;
      if (!cec_rng(t.seg[0], 70 * u, 78 * u) || n < 2 || !cec_rng(t.seg[0] + t.seg[1], 86 * u, 94 * u)) done = 1;
      for (int i = 2; i < n && !done; i += 2) begin
        int lo = t.seg[i];
        int per = (i + 1 < n) ? lo + t.seg[i + 1] : 32'h7FFF_FFFF;
        bit v;
        if (b == 9 && ack) begin v = 0; t.nack++; end
        else if (cec_rng(lo, 8 * u, 16 * u)) v = 1;
        else if (cec_rng(lo, 26 * u, 34 * u)) v = 0;
        else begin t.rstatus = 3; t.epulse = 1; done = 1; break; end
        if (b < 8) sh = {sh[6:0], v};
        else if (b == 8) eom = v;
        if (k == 0 && b == 7) begin
          t.rinit = sh[7:4]; t.rdest = sh[3:0]; hdr = 1;
          ack = (sh[3:0] == 4'h0);
        end
        if (b == 9) begin
          if (k == 0 && t.rdest != 4'h0 && t.rdest != 4'hF) begin t.rstatus = 2; done = 1; break; end
          if (k != 0) begin t.odata.push_back(sh); t.rlen++; end
          if (eom) begin t.rstatus = (t.rdest == 4'hF) ? 1 : 0; done = 1; break; end
          k++; b = 0;
        end else b++;
        // period of this bit, measured at the next falling edge (or overrun)
        if (per > 55 * u) begin t.rstatus = 3; done = 1; break; end
        if (per < 41 * u) begin t.rstatus = 3; t.epulse = 1; done = 1; break; end
      end
      if (!done) t.rstatus = 3;
    endfunction

    function void write_exp(cec_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(cec_transaction t);
      cec_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        cec_transaction e = exp_q.pop_front();
        cec_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("cec scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class cec_env extends uvm_env;
    `uvm_component_utils(cec_env)
    cec_agent      agt;
    cec_scoreboard sb;
    cec_checker    chk;
    cec_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = cec_agent     ::type_id::create("agt", this);
      sb  = cec_scoreboard::type_id::create("sb",  this);
      chk = cec_checker   ::type_id::create("chk", this);
      cov = cec_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
