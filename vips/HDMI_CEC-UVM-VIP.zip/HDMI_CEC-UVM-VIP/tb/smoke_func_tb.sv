// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (CEC DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened cec_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;
  localparam integer U = 2;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic agent_low = 1'b0;
  wire cec_oe_low, out_valid, rep_valid;
  wire [7:0] out_data;
  wire [2:0] rep_status;
  wire [3:0] rep_init, rep_dest;
  wire [4:0] rep_len;
  wire cec_in = ~(agent_low | cec_oe_low);

  always #5 clk = ~clk;

  cec_model u_dut (.clk(clk), .rst_n(rst_n), .cec_in(cec_in), .cec_oe_low(cec_oe_low), .out_valid(out_valid),
                   .out_data(out_data), .rep_valid(rep_valid), .rep_status(rep_status), .rep_init(rep_init),
                   .rep_dest(rep_dest), .rep_len(rep_len));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  integer nrep = 0, nout = 0, nacks = 0, nerrp = 0, oen = 0, last_oe = 0;
  logic [2:0] r_st;
  logic [3:0] r_in, r_de;
  logic [4:0] r_ln;
  logic [7:0] ob [0:31];
  always @(posedge clk) begin
    if (rep_valid) begin nrep = nrep + 1; r_st = rep_status; r_in = rep_init; r_de = rep_dest; r_ln = rep_len; end
    if (out_valid) begin ob[nout] = out_data; nout = nout + 1; end
    if (cec_oe_low) oen = oen + 1;
    else if (oen != 0) begin if (oen <= 40 * U) nacks = nacks + 1; else nerrp = nerrp + 1; last_oe = oen; oen = 0; end
  end

  integer r0, sampled, eperr;
  // one bit: low lo units, period per units; sampled = line at 1.05 ms
  task automatic cbit(input integer lo, input integer per);
    agent_low = 1;
    repeat (lo * U) @(negedge clk);
    agent_low = 0;
    for (int c = lo * U; c < per * U; c++) begin
      @(negedge clk);
      if (c + 1 == 21 * U) sampled = cec_in;
    end
    if (cec_in == 1'b0) eperr = 1;
  endtask
  task automatic start(input integer lo = 74, input integer per = 90);
    agent_low = 1; repeat (lo * U) @(negedge clk);
    agent_low = 0; repeat ((per - lo) * U) @(negedge clk);
  endtask
  task automatic idle();
    agent_low = 0; repeat (336 * U) @(negedge clk);
  endtask
  logic [7:0] fb [0:15];
  integer fn;
  // frame of fn blocks fb[]; bad = bit index (from 0, after the start bit) with low time badlo
  task automatic frame(input integer bad = -1, input integer badlo = 20, input integer badper = 48,
                       input logic noeom = 0, input integer slo = 74, input integer sper = 90);
    integer bi;
    r0 = nrep; nout = 0; nacks = 0; nerrp = 0; eperr = 0; bi = 0;
    start(slo, sper);
    for (int k = 0; k < 16; k++) if (k < fn && eperr == 0) begin
      for (int i = 0; i < 10; i++) if (eperr == 0) begin
        logic v;
        v = (i < 8) ? fb[k][7 - i] : (i == 8) ? (k == fn - 1 && !noeom) : 1'b1;
        if (bi == bad) cbit(badlo, badper); else cbit(v ? 12 : 30, 48);
        bi = bi + 1;
      end
    end
    idle();
  endtask
  function automatic logic got(input logic [2:0] s, input logic [3:0] i, input logic [3:0] d, input integer n);
    got = (nrep == r0 + 1) && r_st == s && r_in == i && r_de == d && r_ln == n;
  endfunction
  function automatic logic outs(input integer n);
    logic ok;
    ok = (nout == n);
    for (int j = 0; j < 16; j++) if (j < n && ob[j] !== fb[j + 1]) ok = 0;
    outs = ok;
  endfunction

  initial begin
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0 && cec_oe_low === 1'b0, "nothing out in reset");
    rst_n = 1;
    repeat (4) @(negedge clk);
    fn = 1; fb[0] = 8'h40; frame(); chk(got(0, 4, 0, 0) && nacks == 1, "polling 4 -> 0: ACK, no data");
    fn = 2; fb[1] = 8'h36; frame(); chk(got(0, 4, 0, 1) && outs(1) && nacks == 2, "Standby: header and opcode ACKed");
    fn = 4; fb[0] = 8'h30; fb[1] = 8'h82; fb[2] = 8'h10; fb[3] = 8'h00; frame();
    chk(got(0, 3, 0, 3) && outs(3) && nacks == 4, "Active Source 3 -> 0 with two operands");
    fn = 16; fb[0] = 8'hB0; for (int j = 1; j < 16; j++) fb[j] = 8'h11 * j; frame();
    chk(got(0, 4'hB, 0, 15) && outs(15) && nacks == 16, "15 data blocks");
    fn = 4; fb[0] = 8'h4F; fb[1] = 8'h84; fb[2] = 8'h10; fb[3] = 8'h00; frame();
    chk(got(1, 4, 15, 3) && outs(3) && nacks == 0, "broadcast: accepted without pulling ACK low");
    fn = 1; fb[0] = 8'h45; frame(); chk(got(2, 4, 5, 0) && nout == 0 && nacks == 0, "polling another device: NACK");
    fn = 3; fb[0] = 8'h40; fb[1] = 8'h44; fb[2] = 8'h41; frame(15, 20);
    chk(got(3, 4, 0, 0) && nerrp == 1 && eperr == 1, "data bit low 1.0 ms: error notification");
    frame(25, 30, 36); chk(got(3, 4, 0, 1) && nerrp == 1 && eperr == 1, "bit period 1.8 ms: error notification");
    frame(25, 30, 58); chk(got(3, 4, 0, 1) && nerrp == 0, "bit period 2.9 ms: overrun, no notification");
    fn = 2; fb[1] = 8'h04; frame(-1, 20, 48, 1); chk(got(3, 4, 0, 1) && outs(1) && nerrp == 0, "no EOM: the frame never ends");
    r0 = nrep; start(60, 90); idle(); chk(got(4, 0, 0, 0), "start low 3.0 ms");
    r0 = nrep; start(74, 100); idle(); chk(got(4, 0, 0, 0), "start period 5.0 ms");
    // windows: 1 low 0.4 / 0.8 ms, 0 low 1.3 / 1.7 ms, period 2.05 / 2.75 ms
    r0 = nrep; nout = 0; nacks = 0; eperr = 0; start(70, 86);
    for (int i = 0; i < 8; i++) cbit((8'h40 >> (7 - i)) & 1 ? 8 : 26, 41);
    cbit(30, 55); cbit(16, 55);
    for (int i = 0; i < 8; i++) cbit((8'h9F >> (7 - i)) & 1 ? 16 : 34, 55);
    cbit(8, 41); cbit(12, 48); idle();
    chk(got(0, 4, 0, 1) && nout == 1 && ob[0] == 8'h9F && nacks == 2, "every window edge accepted");
    fn = 2; fb[0] = 8'h40; fb[1] = 8'h8F; frame(); chk(got(0, 4, 0, 1) && outs(1), "frame after the faults");
    chk(last_oe == 30 * U, $sformatf("ACK pulse is 1.5 ms (%0d clocks)", last_oe));
    frame(-1, 20, 48, 0, 78, 90); chk(got(0, 4, 0, 1), "start low 3.9 ms accepted");
    frame(-1, 20, 48, 0, 79, 90); chk(got(4, 0, 0, 0), "start low 3.95 ms rejected");
    frame(-1, 20, 48, 0, 70, 94); chk(got(0, 4, 0, 1), "start period 4.7 ms accepted");
    frame(-1, 20, 48, 0, 74, 95); chk(got(4, 0, 0, 0), "start period 4.75 ms rejected");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
