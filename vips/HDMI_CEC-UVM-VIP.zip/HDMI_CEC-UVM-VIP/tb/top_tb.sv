// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- CEC testbench top with a functional CEC DUT model

`ifndef HDMI_CEC_UVM_VIP_TB_SV
`define HDMI_CEC_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import cec_defs_pkg::*;
import cec_pkg::*;
import cec_env_pkg::*;
import cec_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  cec_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  cec_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cec_in(vif.cec_in),
    .cec_oe_low(vif.cec_oe_low),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data),
    .rep_valid(vif.rep_valid),
    .rep_status(vif.rep_status),
    .rep_init(vif.rep_init),
    .rep_dest(vif.rep_dest),
    .rep_len(vif.rep_len)
  );

  // Concurrent protocol checks
  cec_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .cec_in(vif.cec_in),
    .cec_oe_low(vif.cec_oe_low),
    .out_valid(vif.out_valid),
    .out_data(vif.out_data),
    .rep_valid(vif.rep_valid),
    .rep_status(vif.rep_status),
    .rep_init(vif.rep_init),
    .rep_dest(vif.rep_dest),
    .rep_len(vif.rep_len)
  );

  initial begin
    uvm_config_db#(virtual cec_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module cec_model #(parameter int U = 2, parameter logic [3:0] LA = 4'h0) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       cec_in,
  output logic       cec_oe_low,
  output logic       out_valid,
  output logic [7:0] out_data,
  output logic       rep_valid,
  output logic [2:0] rep_status,
  output logic [3:0] rep_init,
  output logic [3:0] rep_dest,
  output logic [4:0] rep_len
);
  localparam logic [2:0] S_IDLE = 3'd0, S_STL = 3'd1, S_STH = 3'd2, S_BL = 3'd3, S_BH = 3'd4,
                         S_ERRP = 3'd5, S_WAIT = 3'd6;
  logic [2:0]  st;
  logic        lv, ack, eom;
  logic [15:0] lcnt, hcnt, dcnt;
  logic [3:0]  b;
  logic [4:0]  k;
  logic [7:0]  sh;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; lv <= 1'b1; ack <= 1'b0; eom <= 1'b0; lcnt <= '0; hcnt <= '0; dcnt <= '0;
      b <= '0; k <= '0; sh <= '0;
      cec_oe_low <= 1'b0; out_valid <= 1'b0; out_data <= '0;
      rep_valid <= 1'b0; rep_status <= '0; rep_init <= '0; rep_dest <= '0; rep_len <= '0;
    end else begin : step
      logic        x, v, err, ovr, fin;
      logic [2:0]  nst;
      logic [7:0]  s2;
      logic [15:0] per;
      x = cec_in; nst = st; err = 1'b0; ovr = 1'b0; fin = 1'b0; s2 = sh;
      rep_valid <= 1'b0; out_valid <= 1'b0;
      lv <= x;
      // the ACK pulse and the error notification
      if (dcnt != 16'd0) begin
        dcnt <= dcnt - 16'd1;
        if (dcnt == 16'd1) cec_oe_low <= 1'b0;
      end
      if (!x) lcnt <= (lv) ? 16'd1 : lcnt + 16'd1;
      else    hcnt <= (!lv) ? 16'd1 : hcnt + 16'd1;
      case (st)
        S_IDLE: if (!x && lv) begin
                  nst = S_STL; rep_init <= '0; rep_dest <= '0; rep_len <= '0; k <= '0; b <= '0; ack <= 1'b0;
                end
        S_STL:  if (x && !lv) begin
                  if (lcnt >= 70 * U && lcnt <= 78 * U) nst = S_STH;
                  else begin rep_valid <= 1'b1; rep_status <= 3'd4; nst = S_WAIT; end
                end
        S_STH:  if (!x && lv) begin
                  per = lcnt + hcnt;
                  if (per >= 86 * U && per <= 94 * U) nst = S_BL;
                  else begin rep_valid <= 1'b1; rep_status <= 3'd4; nst = S_WAIT; end
                end else if (x && lcnt + hcnt + 16'd1 > 94 * U) begin
                  rep_valid <= 1'b1; rep_status <= 3'd4; nst = S_WAIT;
                end
        S_BL:   if (x && !lv) begin : bit_end
                  if (b == 4'd9 && ack) v = 1'b0;
                  else if (lcnt >= 8 * U && lcnt <= 16 * U) v = 1'b1;
                  else if (lcnt >= 26 * U && lcnt <= 34 * U) v = 1'b0;
                  else begin v = 1'b0; err = 1'b1; end
                  if (!err) begin
                    if (b < 4'd8) s2 = {sh[6:0], v};
                    if (b == 4'd8) eom <= v;
                    sh <= s2;
                    if (k == 5'd0 && b == 4'd7) begin
                      rep_init <= s2[7:4]; rep_dest <= s2[3:0]; ack <= (s2[3:0] == LA);
                    end
                    nst = S_BH;
                    if (b == 4'd9) begin
                      b <= '0;
                      if (k == 5'd0 && rep_dest != LA && rep_dest != 4'hF) begin
                        rep_valid <= 1'b1; rep_status <= 3'd2; nst = S_WAIT;
                      end else begin
                        if (k != 5'd0) begin out_valid <= 1'b1; out_data <= sh; rep_len <= rep_len + 5'd1; end
                        if (eom) begin
                          rep_valid <= 1'b1; rep_status <= (rep_dest == 4'hF) ? 3'd1 : 3'd0; nst = S_WAIT;
                        end
                        k <= k + 5'd1;
                      end
                    end else b <= b + 4'd1;
                  end
                end
        S_BH:   if (!x && lv) begin
                  per = lcnt + hcnt;
                  if (per < 41 * U) err = 1'b1;
                  else if (per > 55 * U) ovr = 1'b1;
                  else begin
                    nst = S_BL;
                    if (b == 4'd9 && ack) begin cec_oe_low <= 1'b1; dcnt <= 30 * U; end
                  end
                end else if (x && lcnt + hcnt + 16'd1 > 55 * U) ovr = 1'b1;
        S_ERRP: if (dcnt == 16'd1) nst = S_WAIT;
        S_WAIT: if (x && lv && hcnt + 16'd1 >= 96 * U) nst = S_IDLE;
        default: nst = S_IDLE;
      endcase
      if (err) begin
        rep_valid <= 1'b1; rep_status <= 3'd3;
        cec_oe_low <= 1'b1; dcnt <= 72 * U; nst = S_ERRP;
      end else if (ovr) begin
        rep_valid <= 1'b1; rep_status <= 3'd3; nst = S_WAIT;
      end
      st <= nst;
    end
  end
endmodule
`endif
