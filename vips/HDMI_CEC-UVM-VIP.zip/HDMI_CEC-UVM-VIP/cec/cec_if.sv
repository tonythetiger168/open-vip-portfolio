// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_if.sv -- CEC interface

interface cec_if (input logic clk);
  logic rst_n;

  logic       agent_low;    // initiator (this agent) pulls the line low
  logic       cec_oe_low;   // DUT pulls the line low
  logic       cec_in;       // line level (wired-AND)
  logic       out_valid;
  logic [7:0] out_data;
  logic       rep_valid;
  logic [2:0] rep_status;
  logic [3:0] rep_init;
  logic [3:0] rep_dest;
  logic [4:0] rep_len;

  assign cec_in = ~(agent_low | cec_oe_low);

  modport DUT (input clk, rst_n, cec_in, output cec_oe_low, out_valid, out_data, rep_valid, rep_status,
               rep_init, rep_dest, rep_len);
  modport MON (input clk, rst_n, agent_low, cec_oe_low, cec_in, out_valid, out_data, rep_valid, rep_status,
               rep_init, rep_dest, rep_len);

  clocking drv_cb @(posedge clk);
    input rst_n, cec_in, cec_oe_low, out_valid, out_data, rep_valid, rep_status, rep_init, rep_dest, rep_len;
    inout agent_low;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, agent_low, cec_oe_low, cec_in, out_valid, out_data, rep_valid, rep_status, rep_init,
          rep_dest, rep_len;
  endclocking
endinterface
