// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_driver.svh -- CEC driver: one CEC frame per item: start bit, blocks of 10 bits; reads the ACK bits, stops after a NACKed direct block or an error notification; t.seg keeps the pulses actually driven

class cec_driver extends uvm_driver #(cec_transaction);
  `uvm_component_utils(cec_driver)

  uvm_analysis_port #(cec_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual cec_if vif;
  cec_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual cec_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cec: virtual interface not set")
    if (!uvm_config_db#(cec_config)::get(this, "", "cfg", cfg))
      cfg = cec_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    cec_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.agent_low <= 1'b0;
  endtask

  task drive_item(cec_transaction t);
    bit [16:0] q[$];
    int nseg = 0, bitn = 0;
    bit stop = 0;
    t.build(cfg.cec_u);
    @(vif.drv_cb);
    foreach (t.seg[i]) q.push_back(t.seg[i]);
    t.seg.delete();
    t.odata.delete(); t.nack = 0; t.epulse = 0;
    for (int i = 0; i < q.size() && !stop; i += 2) begin
      int lo = q[i], hi = (i + 1 < q.size()) ? q[i + 1] : 0;
      bit sampled = 1;
      vif.drv_cb.agent_low <= 1'b1;
      repeat (lo) begin @(vif.drv_cb); watch(t); end
      vif.drv_cb.agent_low <= 1'b0;
      t.seg.push_back(lo);
      if (i == 0) begin
        repeat (hi) begin @(vif.drv_cb); watch(t); end
        t.seg.push_back(hi);
        continue;
      end
      bitn++;
      for (int c = lo; c < lo + hi; c++) begin
        @(vif.drv_cb); watch(t);
        if (c + 1 == 21 * cfg.cec_u) sampled = vif.drv_cb.cec_in;
      end
      if (hi == 0) break;
      // error notification: the line is still low at the end of the bit
      if (vif.drv_cb.cec_in === 1'b0) begin t.epulse = 1; stop = 1; end
      // NACK of a direct block: stop the frame
      else if (bitn % 10 == 0 && t.dest_of() != 4'hF && sampled) stop = 1;
      if (!stop) t.seg.push_back(hi);
    end
    repeat (cfg.gap_u * cfg.cec_u) begin @(vif.drv_cb); watch(t); end
  endtask

  bit oe_q = 0;
  int unsigned oe_n = 0;
  function void watch(cec_transaction t);
    if (vif.drv_cb.out_valid) t.odata.push_back(vif.drv_cb.out_data);
    if (vif.drv_cb.rep_valid) begin
      t.rstatus = vif.drv_cb.rep_status; t.rinit = vif.drv_cb.rep_init; t.rdest = vif.drv_cb.rep_dest;
      t.rlen = vif.drv_cb.rep_len;
    end
    if (vif.drv_cb.cec_oe_low === 1'b1) oe_n++;
    else if (oe_q) begin if (oe_n <= 40 * cfg.cec_u) t.nack++; else t.epulse = 1; oe_n = 0; end
    oe_q = (vif.drv_cb.cec_oe_low === 1'b1);
  endfunction
endclass
