// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_pkg.sv -- CEC UVM VIP package

package cec_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import cec_defs_pkg::*;
  export cec_defs_pkg::*;

  `include "cec_transaction.svh"
  `include "cec_config.svh"
  `include "cec_sequencer.svh"
  `include "cec_driver.svh"
  `include "cec_monitor.svh"
  `include "cec_agent.svh"
  `include "cec_sequences.svh"
  `include "cec_checker.svh"
  `include "cec_coverage.svh"
endpackage
