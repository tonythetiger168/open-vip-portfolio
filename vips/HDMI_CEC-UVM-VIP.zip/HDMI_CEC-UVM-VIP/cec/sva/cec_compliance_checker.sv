// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_compliance_checker.sv -- CEC concurrent assertion checks (bindable)

module cec_compliance_checker
  (input logic clk, input logic rst_n, input logic cec_in, input logic cec_oe_low, input logic out_valid, input logic [7:0] out_data, input logic rep_valid, input logic [2:0] rep_status, input logic [3:0] rep_init, input logic [3:0] rep_dest, input logic [4:0] rep_len);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({cec_in, cec_oe_low, rep_valid, out_valid}))
    else $error("CEC: X on the line / valids");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |-> rep_status <= 3'd4 && !$isunknown({rep_init, rep_dest, rep_len}))
    else $error("CEC: bad report");
  assert property (@(posedge clk) disable iff (!rst_n) cec_oe_low |-> !cec_in)
    else $error("CEC: the follower pulls low but the line is high");
  assert property (@(posedge clk) disable iff (!rst_n) $rose(cec_oe_low) |-> cec_oe_low [*20])
    else $error("CEC: follower pulse shorter than 0.5 ms");
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_status == 3'd1);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_status == 3'd3);
endmodule
