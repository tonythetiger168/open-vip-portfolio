// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_monitor.svh -- CEC monitor: the initiator's low pulses (agent_low) from the start bit to cfg.mon_end idle units, the follower's ACK / error pulses (cec_oe_low), delivered blocks and the report

class cec_monitor extends uvm_monitor;
  `uvm_component_utils(cec_monitor)

  virtual cec_if vif;
  uvm_analysis_port #(cec_transaction) ap;
  cec_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual cec_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "cec: virtual interface not set")
    if (!uvm_config_db#(cec_config)::get(this, "", "cfg", cfg))
      cfg = cec_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        cec_transaction t;
        int unsigned n = 0, nrep = 0, oe_n = 0;
        bit lv = 1'b1, oe_q = 0;
        do @(vif.mon_cb); while (vif.mon_cb.agent_low !== 1'b1);
        t = cec_transaction::type_id::create("t");
        n = 1;
        forever begin
          @(vif.mon_cb);
          if (vif.mon_cb.out_valid) t.odata.push_back(vif.mon_cb.out_data);
          if (vif.mon_cb.rep_valid) begin
            nrep++;
            t.rstatus = vif.mon_cb.rep_status; t.rinit = vif.mon_cb.rep_init; t.rdest = vif.mon_cb.rep_dest;
            t.rlen = vif.mon_cb.rep_len;
          end
          if (vif.mon_cb.cec_oe_low === 1'b1) oe_n++;
          else if (oe_q) begin if (oe_n <= 40 * cfg.cec_u) t.nack++; else t.epulse = 1; oe_n = 0; end
          oe_q = (vif.mon_cb.cec_oe_low === 1'b1);
          if (vif.mon_cb.agent_low === lv) begin
            n++;
            if (lv == 1'b0 && n >= cfg.mon_end * cfg.cec_u && !oe_q) break;
          end else begin
            t.seg.push_back(n);
            lv = vif.mon_cb.agent_low; n = 1;
          end
        end
        if (nrep != 1) `uvm_error("MON", $sformatf("CEC: %0d reports for one frame", nrep))
        publish(t);
      end
    end
  endtask

  function void publish(cec_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
