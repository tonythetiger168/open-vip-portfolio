// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_checker.svh -- CEC protocol checker on monitored items

class cec_checker extends uvm_component;
  `uvm_component_utils(cec_checker)
  uvm_analysis_imp #(cec_transaction, cec_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  cec_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(cec_config)::get(this, "", "cfg", cfg))
      cfg = cec_config::type_id::create("cfg");
  endfunction

  function void fail(cec_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("CEC: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(cec_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      if (t.rstatus > 4) fail(t, "reserved status");
      if (t.rstatus == 2 && t.rlen != 0) fail(t, "blocks delivered for a frame to another device");
      if (t.odata.size() != t.rlen) fail(t, "delivered blocks do not match the reported length");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("CEC checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
