// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_coverage.svh -- CEC functional coverage

class cec_coverage extends uvm_subscriber #(cec_transaction);
  `uvm_component_utils(cec_coverage)
  cec_config cfg;
  cec_transaction tr;

  covergroup cec_cg;
    cp_status : coverpoint tr.rstatus { bins direct = {0}; bins bcast = {1}; bins other = {2}; bins bit_err = {3};
                                        bins start_err = {4}; }
    cp_len    : coverpoint tr.rlen iff (tr.rstatus < 2) { bins poll = {0}; bins op = {1}; bins short_f = {[2:4]};
                                                           bins long_f = {[5:15]}; }
    cp_epulse : coverpoint tr.epulse;
    cp_init   : coverpoint tr.rinit iff (tr.rstatus < 3) { bins tuner = {3}; bins player = {4}; bins other = default; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cec_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(cec_config)::get(this, "", "cfg", cfg))
      cfg = cec_config::type_id::create("cfg");
  endfunction

  function void write(cec_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    cec_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("CEC coverage: %0.1f%%", cec_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
