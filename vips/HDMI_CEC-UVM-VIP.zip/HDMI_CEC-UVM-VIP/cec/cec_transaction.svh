// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_transaction.svh -- CEC transaction

class cec_transaction extends uvm_sequence_item;
  `uvm_object_utils(cec_transaction)

  // request (driven by the agent)
  bit [15:0] seg[$];
  // response (returned by the DUT)
  bit [4:0] nack;
  bit epulse;
  bit [2:0] rstatus;
  bit [3:0] rinit;
  bit [3:0] rdest;
  bit [4:0] rlen;
  bit [7:0] odata[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [3:0] init;
  rand bit [3:0] dest;
  rand bit [3:0] nblk;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "cec_transaction"); super.new(name); endfunction

  // kind: 0-9 direct to the TV, 10-12 broadcast, 13-14 to another device, 15 polling
  // (header only), 16 data bit low 20 (between 1 and 0), 17 short bit period (36),
  // 18 start low 60, 19 start period 100, 20 last block without EOM, 21-22 jitter,
  // 23 long bit period (58), 24-31 direct to the TV
  function void set(int k, bit [3:0] d, int n, bit [3:0] i = 4'h4);
    kind = k; dest = d; nblk = n; init = i;
  endfunction
  function bit [3:0] dest_of();
    if (kind inside {[10:12]}) return 4'hF;
    if (kind inside {13, 14}) return (dest == 4'h0 || dest == 4'hF) ? 4'h3 : dest;
    return 4'h0;
  endfunction
  // blocks: header, then nblk data blocks (opcode, operands) from the seed
  function void blocks(output bit [7:0] b[$]);
    bit [31:0] x = seed | 1;
    b.delete();
    b.push_back({init, dest_of()});
    if (kind != 15)
      for (int i = 0; i < ((nblk == 0) ? 1 : nblk); i++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        b.push_back(x[7:0]);
      end
  endfunction
  // pulse train in clocks (marks = agent low, spaces); u = clocks per 50 us
  function void build(int unsigned u);
    bit [31:0] x = seed | 1;
    bit [7:0] b[$];
    int nbit = 0;
    int fbit;
    blocks(b);
    fbit = 1 + seed[11:4] % (10 * b.size() - 1);       // a bit of the frame after the first
    seg.delete();
    seg.push_back(((kind == 18) ? 60 : 74) * u);
    seg.push_back(((kind == 19) ? 26 : 16) * u);
    foreach (b[k])
      for (int i = 0; i < 10; i++) begin
        bit v = (i < 8) ? b[k][7 - i] : (i == 8) ? (k == b.size() - 1 && kind != 20) : 1'b1;
        int lo = (v ? 12 : 30) * u, per = 48 * u;
        nbit++;
        if (kind == 16 && nbit == fbit) lo = 20 * u;
        if (kind == 17 && nbit == fbit) per = 36 * u;
        if (kind == 23 && nbit == fbit) per = 58 * u;
        seg.push_back(lo);
        seg.push_back(per - lo);
      end
    void'(seg.pop_back());                           // the line stays high after the last bit
    if (kind inside {21, 22}) foreach (seg[i]) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      seg[i] = seg[i] + x[2:0] - 3;
    end
  endfunction

  function void do_copy(uvm_object rhs);
    cec_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    seg = rhs_.seg;
    nack = rhs_.nack;
    epulse = rhs_.epulse;
    rstatus = rhs_.rstatus;
    rinit = rhs_.rinit;
    rdest = rhs_.rdest;
    rlen = rhs_.rlen;
    odata = rhs_.odata;
    kind = rhs_.kind;
    init = rhs_.init;
    dest = rhs_.dest;
    nblk = rhs_.nblk;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    cec_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (seg.size() != rhs_.seg.size()) return 0;
    foreach (seg[i]) if (seg[i] != rhs_.seg[i]) return 0;
    if (nack != rhs_.nack) return 0;
    if (epulse != rhs_.epulse) return 0;
    if (rstatus != rhs_.rstatus) return 0;
    if (rinit != rhs_.rinit) return 0;
    if (rdest != rhs_.rdest) return 0;
    if (rlen != rhs_.rlen) return 0;
    if (odata.size() != rhs_.odata.size()) return 0;
    foreach (odata[i]) if (odata[i] != rhs_.odata[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(cec_transaction rhs_);
    if (seg.size() != rhs_.seg.size()) return 0;
    foreach (seg[i]) if (seg[i] != rhs_.seg[i]) return 0;
    return 1;
  endfunction

  function string qstr_seg();
    string s = $sformatf("[%0d]{", seg.size());
    foreach (seg[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", seg[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_odata();
    string s = $sformatf("[%0d]{", odata.size());
    foreach (odata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", odata[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("CEC{tag=%0d seg=%s nack=0x%0h epulse=0x%0h rstatus=0x%0h rinit=0x%0h rdest=0x%0h rlen=0x%0h odata=%s}", tag, qstr_seg(), nack, epulse, rstatus, rinit, rdest, rlen, qstr_odata());
  endfunction
endclass
