// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// cec_sequences.svh -- CEC sequences

// Random traffic: cfg.num_items constrained-random items.
class cec_base_sequence extends uvm_sequence #(cec_transaction);
  `uvm_object_utils(cec_base_sequence)
  cec_config cfg;

  function new(string name = "cec_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = cec_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "cec_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class cec_directed_sequence extends uvm_sequence #(cec_transaction);
  `uvm_object_utils(cec_directed_sequence)
  cec_config cfg;

  function new(string name = "cec_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function cec_transaction item();
    item = cec_transaction::type_id::create("req");
  endfunction

  task send(cec_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    cec_transaction t;
    // poll, direct frames of every length, broadcast, another device, each fault, jitter
    t = item(); t.set(15, 0, 0); send(t);
    t = item(); t.set(0, 0, 1); t.seed = 32'h36; send(t);                      // e.g. Standby
    for (int n = 2; n <= 15; n += 3) begin t = item(); t.set(0, 0, n); t.seed = n * 977; send(t); end
    t = item(); t.set(0, 0, 15, 4'hB); t.seed = 32'hBEEF; send(t);
    t = item(); t.set(10, 15, 3); t.seed = 32'h84; send(t);                    // Report Physical Address
    t = item(); t.set(10, 15, 1, 4'h3); send(t);
    t = item(); t.set(13, 5, 2); send(t);
    t = item(); t.set(13, 0, 2); send(t);
    for (int s = 0; s < 3; s++) begin
      t = item(); t.set(16, 0, 4); t.seed = 32'h101 * (s + 7); send(t);
      t = item(); t.set(17, 0, 4); t.seed = 32'h202 * (s + 5); send(t);
      t = item(); t.set(23, 0, 4); t.seed = 32'h303 * (s + 3); send(t);
    end
    t = item(); t.set(18, 0, 2); send(t);
    t = item(); t.set(19, 0, 2); send(t);
    t = item(); t.set(20, 0, 3); send(t);
    t = item(); t.set(0, 0, 2); send(t);
    for (int s = 0; s < 4; s++) begin t = item(); t.set(21 + s[0], s[0] ? 15 : 0, 2 + s); t.seed = 32'h55 * (s + 1); send(t); end
  endtask
endclass
