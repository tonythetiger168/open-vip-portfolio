// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2025 Functional smoke testbench (UART frame loopback)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened uart_loopback_model.
// DUT behaviour (from dut_uart_loopback_model.sv):
//   - RX: decodes frames on txd (start=0, 8 data bits LSB-first, parity slot,
//     stop=1) at BAUD_DIV=16 clk/bit; accepts only when stop==1 and the
//     parity-slot rule holds; a start pulse shorter than half a bit is
//     rejected as a glitch
//   - TX: echoes accepted frames back on rxd after a one-bit turn-around,
//     replaying the parity slot bit
// This tb drives frames on txd and decodes echoes on rxd independently,
// so a pass exercises both the RX and TX paths of the model.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  localparam int BD = 16;

  logic vif_clk   = 1'b0;
  logic vif_rst_n = 1'b0;
  logic vif_txd   = 1'b1;   // idle high
  wire  vif_rxd;

  always #5 vif_clk = ~vif_clk;

  uart_loopback_model #(.BAUD_DIV(BD)) u_dut (
    .vif_clk(vif_clk), .vif_rst_n(vif_rst_n),
    .vif_txd(vif_txd), .vif_rxd(vif_rxd)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // host->dut frame: start, 8 data bits (LSB first), parity slot, stop
  task automatic uart_send(input bit [7:0] d, input bit slot, input bit stop);
    vif_txd = 1'b0;
    repeat (BD) @(posedge vif_clk);
    for (int i = 0; i < 8; i++) begin
      vif_txd = d[i];
      repeat (BD) @(posedge vif_clk);
    end
    vif_txd = slot;
    repeat (BD) @(posedge vif_clk);
    vif_txd = stop;
    repeat (BD) @(posedge vif_clk);
    vif_txd = 1'b1;
  endtask

  // dut->host echo decoder (plain buffer: iverilog-friendly)
  bit [7:0] echo_buf [0:15];
  int       echo_wr = 0;
  int       echo_rd = 0;
  initial forever begin
    bit [7:0] d;
    @(negedge vif_rxd);
    repeat (BD/2) @(posedge vif_clk);
    if (vif_rxd === 1'b0) begin
      d = 8'h00;
      for (int i = 0; i < 8; i++) begin
        repeat (BD) @(posedge vif_clk);
        d[i] = vif_rxd;
      end
      echo_buf[echo_wr % 16] = d;
      echo_wr++;
    end
  end

  task automatic expect_echo(input bit [7:0] exp, input string msg);
    int to;
    to = 0;
    while (echo_rd == echo_wr && to < 30*BD) begin @(posedge vif_clk); to++; end
    chk(echo_rd != echo_wr, {msg, ": echo received"});
    if (echo_rd != echo_wr) begin
      chk(echo_buf[echo_rd % 16] === exp, {msg, ": echo byte matches"});
      echo_rd++;
    end
  endtask

  task automatic expect_silence(input string msg);
    int base;
    base = echo_wr;
    repeat (30*BD) @(posedge vif_clk);   // > one full frame + turn-around
    chk(echo_wr == base, msg);
  endtask

  initial begin
    repeat (8) @(posedge vif_clk);
    vif_rst_n = 1'b1;
    repeat (4) @(posedge vif_clk);

    chk(vif_rxd === 1'b1, "rxd idle high after reset");

    // 1. three clean frames echo back in order (slot=1 is always accepted)
    uart_send(8'h41, 1'b1, 1'b1);
    expect_echo(8'h41, "frame 1 (0x41)");

    uart_send(8'hA5, 1'b1, 1'b1);
    uart_send(8'h00, 1'b1, 1'b1);
    expect_echo(8'hA5, "frame 2 (0xA5)");
    expect_echo(8'h00, "frame 3 (0x00)");

    // 2. bad stop bit: frame must be rejected, no echo
    uart_send(8'hFF, 1'b1, 1'b0);
    expect_silence("bad-stop frame rejected (no echo)");

    // 3. glitch: 2-clk low pulse is not a start bit, no echo
    vif_txd = 1'b0;
    repeat (2) @(posedge vif_clk);
    vif_txd = 1'b1;
    expect_silence("glitch pulse rejected (no echo)");

    // 4. line still functional after rejects
    uart_send(8'h3C, 1'b1, 1'b1);
    expect_echo(8'h3C, "frame 4 after rejects (0x3C)");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  // safety timeout
  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
