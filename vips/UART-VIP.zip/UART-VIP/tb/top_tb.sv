// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// top_tb.sv -- UART testbench top with a functional UART RX+TX loopback DUT

`ifndef UART_TB_SV
`define UART_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import uart_defs_pkg::*;
import uart_pkg::*;
import uart_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  uart_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  uart_loopback_model #(.BAUD_DIV(16)) dut(.vif(vif));

  initial begin
    uvm_config_db#(virtual uart_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional UART DUT: an RX path decodes frames from txd (start detect +
// mid-bit sampling, fixed start/8-data/parity-slot/stop format) and a TX
// path echoes every error-free received frame back on rxd with identical
// data and parity slot. Frames with a framing error (stop bit low) or a
// parity error are dropped and produce no echo.
module uart_loopback_model #(parameter int unsigned BAUD_DIV = 16)
  (uart_if vif);

  bit [7:0] echo_q[$];
  bit       slot_q[$];
  bit       echo_pending = 1'b0;   // mirrors (echo_q.size() > 0)

  // RX path: decode txd, queue good frames for echo
  initial begin : rx_proc
    forever begin
      bit [7:0] d;
      bit       slot, stopb;
      wait (vif.rst_n === 1'b1);
      @(negedge vif.txd);
      repeat (BAUD_DIV/2) @(posedge vif.clk);
      if (vif.txd === 1'b0) begin                  // glitch reject
        d = 8'h00;
        for (int i = 0; i < 8; i++) begin
          repeat (BAUD_DIV) @(posedge vif.clk);
          d[i] = vif.txd;
        end
        repeat (BAUD_DIV) @(posedge vif.clk);      // parity slot
        slot = vif.txd;
        repeat (BAUD_DIV) @(posedge vif.clk);      // stop bit
        stopb = vif.txd;
        // accept: stop==1 and no parity error (slot 0 requires even-ones data)
        if (stopb === 1'b1 && !(slot === 1'b0 && ^d === 1'b1)) begin
          echo_q.push_back(d);
          slot_q.push_back(slot);
          echo_pending = 1'b1;
        end
      end
    end
  end

  // TX path: echo queued frames back on rxd (start/8-data/parity-slot/stop)
  initial begin : tx_proc
    vif.rxd = 1'b1;                                // idle line high
    forever begin
      bit [7:0] d;
      bit       slot;
      wait (echo_pending);
      d    = echo_q.pop_front();
      slot = slot_q.pop_front();
      echo_pending = (echo_q.size() > 0);
      repeat (BAUD_DIV) @(posedge vif.clk);        // turn-around delay
      vif.rxd = 1'b0;                              // start bit
      repeat (BAUD_DIV) @(posedge vif.clk);
      for (int i = 0; i < 8; i++) begin            // 8 data bits, LSB first
        vif.rxd = d[i];
        repeat (BAUD_DIV) @(posedge vif.clk);
      end
      vif.rxd = slot;                              // replay parity slot
      repeat (BAUD_DIV) @(posedge vif.clk);
      vif.rxd = 1'b1;                              // stop bit
      repeat (BAUD_DIV) @(posedge vif.clk);
    end
  end
endmodule
`endif
