// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// uart_if.sv -- UART interface (TX/RX modports, idle-high lines)
//
// The VIP driver transmits on txd; the DUT (loopback model in
// tb/top_tb.sv) receives on txd and echoes received bytes back on rxd.
// Both lines idle high.

interface uart_if (input logic clk);
  import uart_defs_pkg::uart_state_e;

  logic rst_n;

  logic txd = 1'b1;   // VIP -> DUT
  logic rxd = 1'b1;   // DUT -> VIP

  uart_state_e state;

  modport TB  (input  clk, rst_n, rxd,
               output txd, state);
  modport DUT (input  clk, rst_n, txd,
               output rxd);
  modport MON (input  clk, rst_n, txd, rxd, state);

  clocking drv_cb @(posedge clk);
    input  rxd, rst_n;
    output txd;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, txd, rxd, state;
  endclocking
endinterface
