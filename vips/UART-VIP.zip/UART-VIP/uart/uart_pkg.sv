// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// uart_pkg.sv -- UART UVM VIP package

package uart_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import uart_defs_pkg::*;
  export uart_defs_pkg::*;

  `include "uart_transaction.svh"
  `include "uart_config.svh"
  `include "uart_sequencer.svh"
  `include "uart_driver.svh"
  `include "uart_monitor.svh"
  `include "uart_agent.svh"
  `include "uart_sequences.svh"
  `include "uart_checker.svh"
  `include "uart_coverage.svh"
endpackage
