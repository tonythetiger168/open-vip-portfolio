// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// uart_transaction.svh -- UART transaction (one frame)
//
// Wire format (fixed length, LSB first):
//   start(0) + 8 data bits + parity slot + stop(1)
//   parity_en=1 : parity slot carries even parity (^data)
//   parity_en=0 : parity slot is driven to mark (1'b1)
//   stop2       : an additional stop bit-time follows the stop bit
// Error injection:
//   inj_parity_err : drive the wrong parity value
//                    (only legal with parity_en and odd-ones data, so the
//                    injected slot reads 0 where 1 was expected -- the
//                    monitor can then detect it unambiguously)
//   inj_frame_err  : drive the stop bit low for one bit-time
// Observed (monitor / driver-expected):
//   parity_err, frame_err, dir (0 = VIP txd frame, 1 = DUT rxd echo)

`ifndef UART_TRANSACTION_SVH
`define UART_TRANSACTION_SVH

class uart_transaction extends uvm_sequence_item;

  rand bit [7:0]    data;
  rand bit          parity_en;
  rand bit          stop2;
  rand int unsigned baud_div;     // ref-clk cycles per bit-time
  rand int unsigned idle_bits;    // idle bit-times between frames
  rand bit          inj_parity_err;
  rand bit          inj_frame_err;

  bit               parity_err;   // observed parity error
  bit               frame_err;    // observed framing error (stop bit 0)
  bit               dir;          // 0 = txd (VIP->DUT), 1 = rxd (DUT->VIP)
  uart_state_e      fsm_states[$];// FSM states observed during the frame

  constraint c_baud { soft baud_div == 16; }
  constraint c_idle { idle_bits inside {[1:8]}; }
  constraint c_inj  {
    inj_parity_err dist {0 := 9, 1 := 1};
    inj_frame_err  dist {0 := 9, 1 := 1};
    inj_parity_err -> (parity_en && ($countones(data) % 2 == 1));
  }

  `uvm_object_utils_begin(uart_transaction)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(parity_en, UVM_ALL_ON)
    `uvm_field_int(stop2, UVM_ALL_ON)
    `uvm_field_int(baud_div, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(idle_bits, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(inj_parity_err, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(inj_frame_err, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(parity_err, UVM_ALL_ON)
    `uvm_field_int(frame_err, UVM_ALL_ON)
    `uvm_field_int(dir, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "uart_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    uart_transaction t;
    do_compare = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 0;
    do_compare &= (comparer.compare_field("dir",        dir,        t.dir,        1) == 1);
    do_compare &= (comparer.compare_field("data",       data,       t.data,       8) == 1);
    do_compare &= (comparer.compare_field("parity_err", parity_err, t.parity_err, 1) == 1);
    do_compare &= (comparer.compare_field("frame_err",  frame_err,  t.frame_err,  1) == 1);
  endfunction

  function string convert2string();
    return $sformatf("UART %s data=0x%02h parity_en=%0b stop2=%0b baud_div=%0d%s%s",
                     dir ? "RX" : "TX", data, parity_en, stop2, baud_div,
                     parity_err ? " PARITY-ERR" : "",
                     frame_err  ? " FRAME-ERR"  : "");
  endfunction
endclass
`endif
