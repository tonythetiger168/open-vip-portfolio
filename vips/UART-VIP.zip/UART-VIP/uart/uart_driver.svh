// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// uart_driver.svh -- UART transmit driver
//
// Sends one frame per sequence item on txd (idle high, LSB first):
//   start(0) + 8 data bits + parity slot + stop(1) [+ 2nd stop] + idle
// The parity slot is always present: even parity when parity_en=1, mark
// (1'b1) otherwise, so the frame length is fixed and monitor/DUT can
// decode it unambiguously. inj_parity_err flips the parity value;
// inj_frame_err holds the stop bit low for one bit-time before recovering.
// The expected transaction is broadcast on drv_ap before item_done().

`ifndef UART_DRIVER_SVH
`define UART_DRIVER_SVH

class uart_driver extends uvm_driver #(uart_transaction);
  `uvm_component_utils(uart_driver)
  virtual uart_if vif;
  uart_config cfg;
  uvm_analysis_port #(uart_transaction) drv_ap;  // expected items for scoreboard

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual uart_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "uart virtual interface not set")
  endfunction

  task run_phase(uvm_phase phase);
    uart_transaction tr;
    vif.drv_cb.txd <= 1'b1;
    vif.state = uart_defs_pkg::IDLE;
    wait (vif.rst_n === 1'b1);
    forever begin
      int unsigned bd;
      bit          pbit;
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      bd = tr.baud_div;

      // start bit
      vif.state = uart_defs_pkg::START_BIT;
      vif.drv_cb.txd <= 1'b0;
      repeat (bd) @(vif.drv_cb);

      // 8 data bits, LSB first
      vif.state = uart_defs_pkg::DATA_BITS;
      for (int i = 0; i < 8; i++) begin
        vif.drv_cb.txd <= tr.data[i];
        repeat (bd) @(vif.drv_cb);
      end

      // parity slot (even parity when enabled, mark otherwise)
      vif.state = uart_defs_pkg::PARITY;
      pbit = tr.parity_en ? (^tr.data ^ tr.inj_parity_err) : 1'b1;
      vif.drv_cb.txd <= pbit;
      repeat (bd) @(vif.drv_cb);

      // stop bit (held low for one bit-time on frame-error injection)
      vif.state = uart_defs_pkg::STOP_BIT;
      vif.drv_cb.txd <= (tr.inj_frame_err ? 1'b0 : 1'b1);
      repeat (bd) @(vif.drv_cb);
      if (tr.inj_frame_err) begin
        vif.drv_cb.txd <= 1'b1;              // recover to idle
        repeat (bd) @(vif.drv_cb);
      end
      if (tr.stop2) begin                    // optional second stop bit
        vif.drv_cb.txd <= 1'b1;
        repeat (bd) @(vif.drv_cb);
      end

      // inter-frame idle
      vif.state = uart_defs_pkg::IDLE;
      vif.drv_cb.txd <= 1'b1;
      repeat (tr.idle_bits * bd) @(vif.drv_cb);

      // expected monitor observations
      tr.dir        = 1'b0;
      tr.parity_err = tr.inj_parity_err;
      tr.frame_err  = tr.inj_frame_err;
      drv_ap.write(tr);                      // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
