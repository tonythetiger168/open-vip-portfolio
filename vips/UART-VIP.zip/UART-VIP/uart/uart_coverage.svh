// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// uart_coverage.svh -- UART functional coverage
//
// Only VIP-transmitted frames (dir=0) are sampled; DUT echo frames
// (dir=1) are checked by the scoreboard, not covered here.

`ifndef UART_COVERAGE_SVH
`define UART_COVERAGE_SVH

class uart_coverage extends uvm_subscriber #(uart_transaction);
  `uvm_component_utils(uart_coverage)

  uart_transaction tr;

  covergroup cg_protocol;
    cp_data : coverpoint tr.data {
      bins zero  = {8'h00};
      bins ones  = {8'hFF};
      bins alt10 = {8'hAA};
      bins alt01 = {8'h55};
      bins low   = {[8'h01 : 8'h7F]};
      bins high  = {[8'h80 : 8'hFE]};
    }
    cp_parity : coverpoint tr.parity_en { bins off = {0}; bins on = {1}; }
    cp_stop2  : coverpoint tr.stop2 { bins one = {0}; bins two = {1}; }
    cp_idle   : coverpoint tr.idle_bits {
      bins b2b   = {1};
      bins short = {[2:4]};
      bins long  = {[5:8]};
    }
    cx_parity_stop : cross cp_parity, cp_stop2;
  endgroup

  covergroup cg_fsm with function sample(uart_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {IDLE, START_BIT, DATA_BITS, PARITY, STOP_BIT};
    }
    cp_trans : coverpoint s {
      bins frame_seq = (IDLE => START_BIT => DATA_BITS => PARITY => STOP_BIT => IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_perr : coverpoint tr.parity_err { bins ok = {0}; bins err = {1}; }
    cp_ferr : coverpoint tr.frame_err  { bins ok = {0}; bins err = {1}; }
    cx_err  : cross cp_perr, cp_ferr;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(uart_transaction t);
    if (t.dir) return;               // cover VIP TX frames only
    tr = t;
    cg_protocol.sample();
    foreach (t.fsm_states[i]) cg_fsm.sample(t.fsm_states[i]);
    cg_error.sample();
  endfunction
endclass
`endif
