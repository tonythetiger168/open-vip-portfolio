// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// uart_sequences.svh -- UART sequence library

`ifndef UART_SEQUENCES_SVH
`define UART_SEQUENCES_SVH

class uart_base_sequence extends uvm_sequence #(uart_transaction);
  `uvm_object_utils(uart_base_sequence)
  int num_txns = 20;
  function new(string name = "uart_base_sequence"); super.new(name); endfunction
  task body();
    uart_transaction tr;
    repeat (num_txns) begin
      tr = uart_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: corner data patterns, no parity (mark slot)
class uart_write_seq extends uart_base_sequence;
  function new(string name = "uart_write_seq"); super.new(name); endfunction
  `uvm_object_utils(uart_write_seq)
  task body();
    uart_transaction tr;
    bit [7:0] corners[$] = '{8'h00, 8'hFF, 8'hAA, 8'h55, 8'h01, 8'h80};
    foreach (corners[i]) begin
      tr = uart_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { data == corners[i]; parity_en == 0;
                                  inj_parity_err == 0; inj_frame_err == 0; });
      finish_item(tr);
    end
    repeat (num_txns) begin
      tr = uart_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { parity_en == 0;
                                  inj_parity_err == 0; inj_frame_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: parity-enabled frames (read-back via the DUT loopback echo)
class uart_read_seq extends uart_base_sequence;
  function new(string name = "uart_read_seq"); super.new(name); endfunction
  `uvm_object_utils(uart_read_seq)
  task body();
    uart_transaction tr;
    repeat (num_txns) begin
      tr = uart_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { parity_en == 1;
                                  inj_parity_err == 0; inj_frame_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: long burst of frames with two stop bits
class uart_burst_seq extends uart_base_sequence;
  `uvm_object_utils(uart_burst_seq)
  function new(string name = "uart_burst_seq"); super.new(name); num_txns = 40; endfunction
  task body();
    uart_transaction tr;
    repeat (num_txns) begin
      tr = uart_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { stop2 == 1; idle_bits inside {[1:2]};
                                  inj_parity_err == 0; inj_frame_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: back-to-back frames with a single idle bit-time
class uart_back_to_back_seq extends uart_base_sequence;
  function new(string name = "uart_back_to_back_seq"); super.new(name); endfunction
  `uvm_object_utils(uart_back_to_back_seq)
  task body();
    uart_transaction tr;
    repeat (num_txns) begin
      tr = uart_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { idle_bits == 1; stop2 == 0;
                                  inj_parity_err == 0; inj_frame_err == 0; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: parity errors and framing errors
class uart_error_inject_seq extends uart_base_sequence;
  function new(string name = "uart_error_inject_seq"); super.new(name); endfunction
  `uvm_object_utils(uart_error_inject_seq)
  task body();
    uart_transaction tr;
    repeat (num_txns / 2 + 1) begin
      tr = uart_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inj_parity_err == 1; inj_frame_err == 0; });
      finish_item(tr);
    end
    repeat (num_txns / 2 + 1) begin
      tr = uart_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { inj_parity_err == 0; inj_frame_err == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single frame attempted right after reset release
class uart_reset_seq extends uart_base_sequence;
  function new(string name = "uart_reset_seq"); super.new(name); endfunction
  `uvm_object_utils(uart_reset_seq)
  task body();
    uart_transaction tr = uart_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { inj_parity_err == 0; inj_frame_err == 0; });
    finish_item(tr);
  endtask
endclass

class uart_random_sequence extends uart_base_sequence;
  `uvm_object_utils(uart_random_sequence)
  function new(string name = "uart_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class uart_regression_sequence extends uart_base_sequence;
  `uvm_object_utils(uart_regression_sequence)
  function new(string name = "uart_regression_sequence"); super.new(name); endfunction
  task body();
    uart_write_seq       wr  = uart_write_seq::type_id::create("wr");
    uart_read_seq        rd  = uart_read_seq::type_id::create("rd");
    uart_burst_seq       br  = uart_burst_seq::type_id::create("br");
    uart_back_to_back_seq b2b = uart_back_to_back_seq::type_id::create("b2b");
    uart_error_inject_seq err = uart_error_inject_seq::type_id::create("err");
    uart_random_sequence rnd = uart_random_sequence::type_id::create("rnd");
    wr.num_txns = 10; rd.num_txns = 10; br.num_txns = 20; b2b.num_txns = 10;
    err.num_txns = 8; rnd.num_txns = 30;
    wr.start(m_sequencer);  rd.start(m_sequencer);
    br.start(m_sequencer);  b2b.start(m_sequencer);
    err.start(m_sequencer); rnd.start(m_sequencer);
  endtask
endclass
`endif
