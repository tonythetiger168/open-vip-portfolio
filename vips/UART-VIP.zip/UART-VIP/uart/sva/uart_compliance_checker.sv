// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// uart_compliance_checker.sv -- UART SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = UART-specific pin-level rules (txd line, BAUD_DIV-parameterized)

`ifndef UART_COMPLIANCE_CHECKER_SV
`define UART_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import uart_defs_pkg::*;

module uart_compliance_checker
#(parameter int unsigned BAUD_DIV = 16)
(
  input logic clk,
  input logic rst_n,
  input uart_state_e state,
  input logic txd,
  input logic rxd
);

  // ---------------- L1: signal sanity (4) ----------------
  a_uart_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "uart: clock unknown")
  a_uart_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "uart: reset unknown")
  a_uart_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "uart: state unknown")
  a_uart_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, START_BIT, DATA_BITS, PARITY, STOP_BIT})
    else `uvm_error("SVA_L1", "uart: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_uart_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, START_BIT})
    else `uvm_error("SVA_L2", "uart: illegal transition from IDLE")

  // L2-2: legal FSM transition from START_BIT
  a_uart_trans_start_bit : assert property (@(posedge clk) disable iff (!rst_n)
    state == START_BIT |=> state inside {START_BIT, DATA_BITS})
    else `uvm_error("SVA_L2", "uart: illegal transition from START_BIT")

  // L2-3: legal FSM transition from DATA_BITS
  a_uart_trans_data_bits : assert property (@(posedge clk) disable iff (!rst_n)
    state == DATA_BITS |=> state inside {DATA_BITS, PARITY})
    else `uvm_error("SVA_L2", "uart: illegal transition from DATA_BITS")

  // L2-4: legal FSM transition from PARITY
  a_uart_trans_parity : assert property (@(posedge clk) disable iff (!rst_n)
    state == PARITY |=> state inside {PARITY, STOP_BIT})
    else `uvm_error("SVA_L2", "uart: illegal transition from PARITY")

  // L2-5: legal FSM transition from STOP_BIT
  a_uart_trans_stop_bit : assert property (@(posedge clk) disable iff (!rst_n)
    state == STOP_BIT |=> state inside {STOP_BIT, IDLE})
    else `uvm_error("SVA_L2", "uart: illegal transition from STOP_BIT")

  // ---------------- L3: protocol rules (4) ----------------
  a_uart_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "uart: state not IDLE during reset")
  a_uart_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == STOP_BIT |-> ##[1:8] (state != STOP_BIT))
    else `uvm_error("SVA_L3", "uart: stuck in STOP_BIT")
  a_uart_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == START_BIT);
  a_uart_l3_back_idle  : cover property (@(posedge clk) disable iff (!rst_n)
    state == STOP_BIT ##1 state == IDLE);

  // ---------------- L4: UART protocol-specific rules (4) ----------------
  // L4-1: idle line is high whenever no frame is being transmitted
  a_uart_l4_idle_high : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |-> txd === 1'b1)
    else `uvm_error("SVA_L4", "uart: txd not high while idle")

  // L4-2: bit-cell timing -- any falling edge (start/data) holds low for a
  // full bit-time (start bit is followed by 8 data + parity + stop cells)
  a_uart_l4_bit_width : assert property (@(posedge clk) disable iff (!rst_n)
    $fell(txd) |=> (!txd) [*BAUD_DIV-2])
    else `uvm_error("SVA_L4", "uart: bit cell shorter than one bit-time")

  // L4-3: stop bit must be 1 (a low stop bit is a framing error)
  a_uart_l4_stop_high : assert property (@(posedge clk) disable iff (!rst_n)
    state == STOP_BIT |-> txd === 1'b1)
    else `uvm_error("SVA_L4", "uart: stop bit not high (framing error)")

  // L4-4: parity slot carries even parity of the preceding 8 data slots or
  // mark (1); a 0 slot with odd-ones data is a parity error
  a_uart_l4_parity : assert property (@(posedge clk) disable iff (!rst_n)
    $rose(state == PARITY) |-> ##(BAUD_DIV/2)
      ((txd === 1'b1) ||
       (txd === ($past(txd, BAUD_DIV)   ^ $past(txd, 2*BAUD_DIV) ^
                 $past(txd, 3*BAUD_DIV) ^ $past(txd, 4*BAUD_DIV) ^
                 $past(txd, 5*BAUD_DIV) ^ $past(txd, 6*BAUD_DIV) ^
                 $past(txd, 7*BAUD_DIV) ^ $past(txd, 8*BAUD_DIV)))))
    else `uvm_error("SVA_L4", "uart: parity slot mismatch")

endmodule
`endif
