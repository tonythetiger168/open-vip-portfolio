// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// uart_monitor.svh -- UART monitor: decodes frames from the txd/rxd pin
// waveforms (start detect + mid-bit sampling) and publishes reconstructed
// transactions. Detects framing errors (stop bit low) and parity errors.
//
// Both directions are decoded concurrently:
//   dir=0 : txd frames sent by the VIP driver
//   dir=1 : rxd echo frames returned by the DUT loopback model

`ifndef UART_MONITOR_SVH
`define UART_MONITOR_SVH

class uart_monitor extends uvm_monitor;
  `uvm_component_utils(uart_monitor)
  virtual uart_if vif;
  uvm_analysis_port #(uart_transaction) ap;
  int unsigned txn_count = 0;

  localparam int unsigned BAUD = 16;   // matches uart_transaction soft baud_div

  uart_state_e fsm_q[$];               // FSM transitions seen since last TX frame

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual uart_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "uart virtual interface not set")
  endfunction

  // Track protocol FSM transitions (driven by the VIP TX path).
  task automatic track_fsm();
    uart_state_e last = uart_defs_pkg::IDLE;
    forever begin
      @(vif.mon_cb);
      if (vif.mon_cb.rst_n === 1'b1 && vif.mon_cb.state !== last) begin
        fsm_q.push_back(vif.mon_cb.state);
        last = vif.mon_cb.state;
      end
    end
  endtask

  // Decode one line (use_rxd=0: txd, use_rxd=1: rxd), frame by frame.
  task automatic decode_line(input bit use_rxd);
    forever begin
      uart_transaction tr;
      bit [7:0] d;
      bit       slot, stopb;
      wait (vif.rst_n === 1'b1);
      wait ((use_rxd ? vif.rxd : vif.txd) === 1'b0);        // start edge
      repeat (BAUD/2) @(vif.mon_cb);
      if ((use_rxd ? vif.rxd : vif.txd) !== 1'b0) continue; // glitch reject

      d = 8'h00;
      for (int i = 0; i < 8; i++) begin                     // 8 data bits
        repeat (BAUD) @(vif.mon_cb);
        d[i] = use_rxd ? vif.rxd : vif.txd;
      end
      repeat (BAUD) @(vif.mon_cb);                          // parity slot
      slot = use_rxd ? vif.rxd : vif.txd;
      repeat (BAUD) @(vif.mon_cb);                          // stop bit
      stopb = use_rxd ? vif.rxd : vif.txd;

      tr = uart_transaction::type_id::create("tr");
      tr.dir        = use_rxd;
      tr.data       = d;
      // slot==0 implies even-parity mode; slot==1 with odd-ones data is
      // consistent with even parity too, otherwise it is a mark slot
      tr.parity_en  = (slot === 1'b0) || (^d === 1'b1);
      tr.parity_err = (slot === 1'b0) && (^d === 1'b1);
      tr.frame_err  = (stopb !== 1'b1);
      if (!use_rxd) begin
        tr.fsm_states = fsm_q;
        fsm_q.delete();
      end
      txn_count++;
      `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
      ap.write(tr);
    end
  endtask

  task run_phase(uvm_phase phase);
    fork
      decode_line(1'b0);
      decode_line(1'b1);
      track_fsm();
    join
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("uart monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
