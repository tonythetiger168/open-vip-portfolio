// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// uart_env.sv -- UART verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import uart_defs_pkg::*;
  import uart_pkg::*;

  // End-to-end scoreboard: compares driver-issued (expected) TX frames
  // against monitor-decoded (observed) TX frames, and checks the DUT
  // loopback property (every error-free TX frame must be echoed on rxd
  // with identical data).
    `uvm_analysis_imp_decl(_exp)
    `uvm_analysis_imp_decl(_obs)

  class uart_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(uart_scoreboard)
    uvm_analysis_imp_exp #(uart_transaction, uart_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(uart_transaction, uart_scoreboard) obs_ap;

    uart_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;

    // loopback tracking
    bit       echo_pending = 0;
    bit [7:0] echo_data    = 8'h00;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(uart_transaction t); exp_q.push_back(t); check(); endfunction

    function void write_obs(uart_transaction t);
      if (t.dir == 1'b0) begin
        obs_q.push_back(t);
        check();
      end else begin
        // DUT echo frame: must match the last error-free TX frame
        if (!echo_pending) begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("unexpected echo: %s", t.convert2string()))
        end else if (t.data !== echo_data || t.frame_err || t.parity_err) begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("loopback mismatch: echo{%s} expected data=0x%02h",
                     t.convert2string(), echo_data))
          echo_pending = 0;
        end else begin
          n_matches++;
          echo_pending = 0;
        end
      end
    endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        uart_transaction e = exp_q.pop_front();
        uart_transaction o = obs_q.pop_front();
        if (e.data == o.data && e.parity_err == o.parity_err &&
            e.frame_err == o.frame_err) begin
          n_matches++;
        end else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
        // error-free frames must be echoed back by the DUT
        if (!o.frame_err && !o.parity_err) begin
          echo_pending = 1;
          echo_data    = o.data;
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("uart scoreboard: matches=%0d mismatches=%0d",
                n_matches, n_mismatches), UVM_LOW)
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("unpaired transactions: exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
      if (echo_pending)
        `uvm_error("SB", "missing loopback echo for last error-free frame")
      if (n_mismatches) `uvm_error("SB", "end-to-end mismatches detected")
    endfunction
  endclass

  class uart_env extends uvm_env;
    `uvm_component_utils(uart_env)
    uart_agent      agt;
    uart_scoreboard sb;
    uart_checker    chk;
    uart_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = uart_agent::type_id::create("agt", this);
      sb  = uart_scoreboard::type_id::create("sb", this);
      chk = uart_checker::type_id::create("chk", this);
      cov = uart_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
