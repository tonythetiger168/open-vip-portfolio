# Independent cross-check model (`xchk/`)

`uart_xchk_tb.sv` checks the open-ip-portfolio `UART` RTL (`rtl/UART_top.sv`, `rtl/UART_apb.sv`)
against an 8N1 line receiver timing every edge and a line driver at -2.5 .. +2.5 % baud. The model is written from the UART character format (start, 8 data bits LSB first, stop), not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/uart_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s uart_xchk_tb -o xchk.vvp $OIP/rtl/UART_top.sv $OIP/rtl/UART_apb.sv xchk/uart_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
