# UART — UART UVM VIP

Open-source UVM verification IP template for **UART** (Serial).

## Contents

| Path | Description |
|------|-------------|
| `uart/uart_if.sv` | Protocol interface + FSM state enum |
| `uart/uart_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `uart/sva/uart_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4) |
| `uart/vip/uart/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/uart_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with FSM-walking DUT stub |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **UART transmit driver**: baud_div-parameterized frames (start / 8 data LSB-first / parity slot / stop, optional 2nd stop), even-parity or mark slot, parity- and frame-error injection, `drv_ap` broadcasts expected transactions before `item_done()`
- **Protocol-decoding monitor**: start-detect + mid-bit sampling on both txd and rxd concurrently; detects framing errors (stop bit low) and parity errors
- **End-to-end scoreboard**: compares driver-issued vs monitor-decoded TX frames (data/parity_err/frame_err) and checks the loopback property (every error-free frame echoed on rxd with identical data)
- **Functional DUT model**: UART RX+TX loopback — RX decodes txd and drops errored frames, TX echoes good frames back on rxd
- **Directed sequence library**: write / read (parity) / burst (2 stop bits) / back-to-back / error-inject (parity + framing) / reset + regression mix
- **Functional coverage**: data corners, parity x stop-bit cross, idle-gap bins, FSM state + frame transition sequence, parity/frame error cross bins
- **SVA L4**: idle line high, bit-cell width = one bit-time, stop bit must be 1 (framing error), parity slot = even parity of the 8 data slots or mark
