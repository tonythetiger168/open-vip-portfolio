# GPIO UVM VIP (GPIO-UVM-VIP)

General Purpose I/O UVM VIP with an 8-bit bidirectional-capable GPIO register model (data out, output-enable). Complements the GPIO RTL IP from the open-ip-portfolio sister project.

## Structure

- `gpio/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `gpio_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `gpio_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural GPIO DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/GPIO-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh GPIO-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
