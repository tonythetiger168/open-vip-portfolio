# Independent cross-check model (`xchk/`)

`gpio_xchk_tb.sv` checks the open-ip-portfolio `GPIO` RTL (`rtl/GPIO_top.sv`, `rtl/GPIO_apb.sv`)
against a board model driving or floating each pin, every pin checked as 0 / 1 / Z. The model is written from the register map and pin rules of open-ip docs/ip/GPIO.md, not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/gpio_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s gpio_xchk_tb -o xchk.vvp $OIP/rtl/GPIO_top.sv $OIP/rtl/GPIO_apb.sv xchk/gpio_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
