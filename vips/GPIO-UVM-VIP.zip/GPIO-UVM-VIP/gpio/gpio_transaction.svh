// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_transaction.svh -- GPIO transaction

class gpio_transaction extends uvm_sequence_item;
  `uvm_object_utils(gpio_transaction)

  rand bit [7:0] gpio_in;
  rand bit [7:0] gpio_dir;
  bit [7:0] gpio_out_o;
  bit [7:0] gpio_oen_o;
  bit [31:0] tag;

  function new(string name = "gpio_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    gpio_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    gpio_in = rhs_.gpio_in;
    gpio_dir = rhs_.gpio_dir;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    gpio_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           gpio_in == rhs_.gpio_in &&
           gpio_dir == rhs_.gpio_dir;
  endfunction

  function string convert2string();
    return $sformatf("GPIO{tag=%0h gpio_in=0x%0h gpio_dir=0x%0h}", tag, gpio_in, gpio_dir);
  endfunction
endclass
