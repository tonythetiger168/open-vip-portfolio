// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_transaction.svh -- GPIO transaction

class gpio_transaction extends uvm_sequence_item;
  `uvm_object_utils(gpio_transaction)

  // request (driven by the agent)
  rand bit [7:0] gin;
  rand bit [7:0] dir;
  // response (returned by the DUT)
  bit [7:0] gout;
  bit [7:0] oen;
  // bookkeeping (not compared)
  rand bit [2:0] hold;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_hold { hold inside {[2:6]}; }

  function new(string name = "gpio_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    gpio_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    gin = rhs_.gin;
    dir = rhs_.dir;
    gout = rhs_.gout;
    oen = rhs_.oen;
    hold = rhs_.hold;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    gpio_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (gin != rhs_.gin) return 0;
    if (dir != rhs_.dir) return 0;
    if (gout != rhs_.gout) return 0;
    if (oen != rhs_.oen) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(gpio_transaction rhs_);
    if (gin != rhs_.gin) return 0;
    if (dir != rhs_.dir) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("GPIO{tag=%0d gin=0x%0h dir=0x%0h gout=0x%0h oen=0x%0h}", tag, gin, dir, gout, oen);
  endfunction
endclass
