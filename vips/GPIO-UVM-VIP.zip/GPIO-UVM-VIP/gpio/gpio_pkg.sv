// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_pkg.sv -- GPIO UVM VIP package

package gpio_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import gpio_defs_pkg::*;
  export gpio_defs_pkg::*;

  `include "gpio_transaction.svh"
  `include "gpio_config.svh"
  `include "gpio_sequencer.svh"
  `include "gpio_driver.svh"
  `include "gpio_monitor.svh"
  `include "gpio_agent.svh"
  `include "gpio_sequences.svh"
  `include "gpio_checker.svh"
  `include "gpio_coverage.svh"
endpackage
