// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_if.sv -- GPIO interface

interface gpio_if (input logic clk);
  logic rst_n;

  logic [7:0] gpio_in;
  logic [7:0] gpio_dir;
  logic [7:0] gpio_out;
  logic [7:0] gpio_oen;

  modport DUT (input clk, rst_n, gpio_in, gpio_dir, output gpio_out, gpio_oen);
  modport DRV (input clk, rst_n, gpio_out, gpio_oen, output gpio_in, gpio_dir);
  modport MON (input clk, rst_n, gpio_in, gpio_dir, gpio_out, gpio_oen);

  clocking drv_cb @(posedge clk);
    input rst_n, gpio_in, gpio_dir, gpio_out, gpio_oen;
    output gpio_in, gpio_dir;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, gpio_in, gpio_dir, gpio_out, gpio_oen;
  endclocking
endinterface
