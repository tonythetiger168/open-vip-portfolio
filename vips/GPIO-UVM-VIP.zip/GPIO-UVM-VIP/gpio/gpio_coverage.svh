// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_coverage.svh -- GPIO functional coverage

class gpio_coverage extends uvm_subscriber #(gpio_transaction);
  `uvm_component_utils(gpio_coverage)
  gpio_config cfg;
  gpio_transaction tr;

  covergroup gpio_cg;
    cp_dir : coverpoint tr.dir { bins all_in = {8'h00}; bins all_out = {8'hFF}; bins mixed = default; }
    cp_in  : coverpoint tr.gin { bins zero = {8'h00}; bins ones = {8'hFF}; bins other = default; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    gpio_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(gpio_config)::get(this, "", "cfg", cfg))
      cfg = gpio_config::type_id::create("cfg");
  endfunction

  function void write(gpio_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    gpio_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("GPIO coverage: %0.1f%%", gpio_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
