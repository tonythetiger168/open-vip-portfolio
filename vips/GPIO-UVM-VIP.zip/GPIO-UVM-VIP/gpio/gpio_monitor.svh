// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_monitor.svh -- GPIO monitor: decodes observed bus activity

class gpio_monitor extends uvm_monitor;
  `uvm_component_utils(gpio_monitor)

  virtual gpio_if vif;
  uvm_analysis_port #(gpio_transaction) ap;
  gpio_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual gpio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gpio: virtual interface not set")
    void'(uvm_config_db#(gpio_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    gpio_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = gpio_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.gpio_in = vif.gpio_in;
        t.gpio_dir = vif.gpio_dir;
        t.gpio_out_o = vif.gpio_out;
        t.gpio_oen_o = vif.gpio_oen;
        ap.write(t);
      end
    end
  endtask
endclass
