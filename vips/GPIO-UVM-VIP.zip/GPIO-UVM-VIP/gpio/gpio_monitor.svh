// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_monitor.svh -- GPIO monitor: one item per input change, outputs sampled one clock later

class gpio_monitor extends uvm_monitor;
  `uvm_component_utils(gpio_monitor)

  virtual gpio_if vif;
  uvm_analysis_port #(gpio_transaction) ap;
  gpio_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual gpio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gpio: virtual interface not set")
    if (!uvm_config_db#(gpio_config)::get(this, "", "cfg", cfg))
      cfg = gpio_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] pin = 0, pdir = 0;
      gpio_transaction t;
      forever begin
        @(vif.mon_cb);
        if (t != null) begin
          t.gout = vif.mon_cb.gpio_out;
          t.oen  = vif.mon_cb.gpio_oen;
          publish(t);
          t = null;
        end
        if (vif.mon_cb.gpio_in != pin || vif.mon_cb.gpio_dir != pdir) begin
          pin = vif.mon_cb.gpio_in; pdir = vif.mon_cb.gpio_dir;
          t = gpio_transaction::type_id::create("t");
          t.gin = pin; t.dir = pdir;
        end
      end
    end
  endtask

  function void publish(gpio_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
