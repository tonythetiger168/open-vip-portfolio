// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_driver.svh -- GPIO driver: applies one gpio_in/gpio_dir value, samples the registered outputs

class gpio_driver extends uvm_driver #(gpio_transaction);
  `uvm_component_utils(gpio_driver)

  uvm_analysis_port #(gpio_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual gpio_if vif;
  gpio_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual gpio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gpio: virtual interface not set")
    if (!uvm_config_db#(gpio_config)::get(this, "", "cfg", cfg))
      cfg = gpio_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    gpio_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.gpio_in <= '0; vif.drv_cb.gpio_dir <= '0;
  endtask

  task drive_item(gpio_transaction t);
    if ({t.gin, t.dir} == cfg.pins)
      `uvm_error("GPIO", "item does not change any pin: the monitor cannot see it")
    @(vif.drv_cb);
    vif.drv_cb.gpio_in  <= t.gin;
    vif.drv_cb.gpio_dir <= t.dir;
    cfg.pins = {t.gin, t.dir};
    @(vif.drv_cb);          // the model registers the new value
    @(vif.drv_cb);
    t.gout = vif.drv_cb.gpio_out;
    t.oen  = vif.drv_cb.gpio_oen;
    repeat ((t.hold > 2) ? t.hold - 2 : 0) @(vif.drv_cb);
  endtask

endclass
