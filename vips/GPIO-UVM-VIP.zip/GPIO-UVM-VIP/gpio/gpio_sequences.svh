// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_sequences.svh -- GPIO sequences

// Random traffic: cfg.num_items constrained-random items.
class gpio_base_sequence extends uvm_sequence #(gpio_transaction);
  `uvm_object_utils(gpio_base_sequence)
  gpio_config cfg;

  bit [15:0] cur;

  function new(string name = "gpio_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin
      cur = (cfg != null) ? cfg.pins : 16'h0;
      req = gpio_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize() with {{gin, dir} != local::cur;})
        `uvm_error("RANDFAIL", "gpio_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class gpio_directed_sequence extends uvm_sequence #(gpio_transaction);
  `uvm_object_utils(gpio_directed_sequence)
  gpio_config cfg;

  function new(string name = "gpio_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function gpio_transaction item();
    item = gpio_transaction::type_id::create("req");
  endfunction

  task send(gpio_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    gpio_transaction t;
    // walking one on each pin in both directions, then all-ones / all-zeros
    for (int i = 0; i < 8; i++) begin t = item(); t.gin = 8'h1 << i; t.dir = 8'h00; t.hold = 3; send(t); end
    for (int i = 0; i < 8; i++) begin t = item(); t.gin = 8'h1 << i; t.dir = 8'h1 << i; t.hold = 2; send(t); end
    t = item(); t.gin = 8'hFF; t.dir = 8'hFF; t.hold = 4; send(t);
    t = item(); t.gin = 8'h00; t.dir = 8'hFF; t.hold = 2; send(t);
    t = item(); t.gin = 8'hA5; t.dir = 8'h5A; t.hold = 6; send(t);
  endtask
endclass
