// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gpio_compliance_checker.sv -- GPIO concurrent assertion checks (bindable)

module gpio_compliance_checker
  (input logic clk, input logic rst_n, input [7:0] gpio_in, input [7:0] gpio_dir, input [7:0] gpio_out, input [7:0] gpio_oen);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({gpio_out, gpio_oen}))
    else $error("GPIO: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> gpio_out == '0)
    else $error("GPIO: output not in reset value");
  // output-enable register mirrors the direction input
  assert property (@(posedge clk) disable iff (!rst_n) gpio_oen == $past(gpio_dir))
    else $error("GPIO: oen does not mirror dir");
  cover property (@(posedge clk) disable iff (!rst_n) (gpio_out != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (gpio_oen != gpio_dir));
endmodule
