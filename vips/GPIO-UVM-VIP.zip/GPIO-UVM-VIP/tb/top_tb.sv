// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- GPIO testbench top with a functional GPIO DUT model

`ifndef GPIO_TB_SV
`define GPIO_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import gpio_defs_pkg::*;
import gpio_pkg::*;
import gpio_env_pkg::*;
import gpio_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  gpio_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  gpio_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .gpio_in(vif.gpio_in),
    .gpio_dir(vif.gpio_dir),
    .gpio_out(vif.gpio_out),
    .gpio_oen(vif.gpio_oen)
  );

  // Concurrent protocol checks
  gpio_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .gpio_in(vif.gpio_in), .gpio_dir(vif.gpio_dir), .gpio_out(vif.gpio_out), .gpio_oen(vif.gpio_oen)
  );

  initial begin
    uvm_config_db#(virtual gpio_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module gpio_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [7:0] gpio_in,
  input  logic [7:0] gpio_dir,
  output logic [7:0] gpio_out,
  output logic [7:0] gpio_oen
);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      gpio_out <= '0;
      gpio_oen <= '0;
    end else begin
      gpio_out <= gpio_in;
      gpio_oen <= gpio_dir;
    end
  end
endmodule
`endif
