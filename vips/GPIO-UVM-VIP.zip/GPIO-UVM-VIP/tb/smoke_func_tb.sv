// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (GPIO register loopback)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened gpio_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [7:0] gpio_in = '0;
  logic [7:0] gpio_dir = '0;
  wire  [7:0] gpio_out;
  wire  [7:0] gpio_oen;

  always #5 clk = ~clk;

  gpio_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .gpio_in(gpio_in), .gpio_dir(gpio_dir),
    .gpio_out(gpio_out), .gpio_oen(gpio_oen)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [7:0] exp_out, exp_oen;
  initial begin
    repeat (8) step();
    chk(gpio_out === 8'h00, "gpio_out reset to zero");
    chk(gpio_oen === 8'h00, "gpio_oen reset to zero");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    exp_out = '0; exp_oen = '0;
    repeat (20) begin
      logic [7:0] din, ddir;
      din  = $urandom; ddir = $urandom;
      @(negedge clk); gpio_in = din; gpio_dir = ddir;
      step();                      // registered: visible one cycle later
      exp_out = din; exp_oen = ddir;
      chk(gpio_out === exp_out, "gpio_out follows gpio_in (1-cycle)");
      chk(gpio_oen === exp_oen, "gpio_oen mirrors gpio_dir (1-cycle)");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
