// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- DBI testbench top with a functional display controller DUT

`ifndef DBI_TB_SV
`define DBI_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import dbi_defs_pkg::*;
import dbi_pkg::*;
import dbi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  dbi_if vif(clk);

  initial begin
    vif.resx = 0;
    #100ns;
    vif.resx = 1;
  end

  dbi_display_controller dut (
    .clk      (vif.clk),
    .resx     (vif.resx),
    .csx      (vif.csx),
    .dcx      (vif.dcx),
    .wrx      (vif.wrx),
    .rdx      (vif.rdx),
    .d_i      (vif.d_i),
    .slv_d_o  (vif.slv_d_o),
    .slv_d_oe (vif.slv_d_oe)
  );

  initial begin
    uvm_config_db#(virtual dbi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional DBI display controller:
//  - command decode on DCX=0 writes (0x11 sleep-out initializes the panel,
//    0x2C enters GRAM write mode)
//  - parameter writes update the register file; pixel writes fill GRAM
//  - read-back: drives the register file (default cmd^0xA5) while RDX is low
//  - GRAM writes are ignored until initialized (mirrors the L4 rule)
//  - WRX pulses narrower than the spec are ignored (not latched)
module dbi_display_controller
(
  input  logic       clk,
  input  logic       resx,
  input  logic       csx,
  input  logic       dcx,
  input  logic       wrx,
  input  logic       rdx,
  input  logic [7:0] d_i,
  output logic [7:0] slv_d_o,
  output logic       slv_d_oe
);
  import dbi_defs_pkg::*;

  bit [7:0] regs [bit [7:0]];
  bit [7:0] gram [0:255];
  int       gram_addr   = 0;
  bit       gram_mode   = 0;
  bit       initialized = 0;
  bit [7:0] cur_cmd     = 8'h00;
  bit       wrx_d       = 1;
  int       wr_low_cnt  = 0;

  always @(posedge clk or negedge resx) begin
    if (!resx) begin
      gram_addr <= 0; gram_mode <= 0; initialized <= 0;
      cur_cmd <= 0; wrx_d <= 1; wr_low_cnt <= 0;
      slv_d_o <= 8'h00; slv_d_oe <= 1'b0;
    end else begin
      // ---- write latch on WRX rising edge (ignore violated pulses) ----
      if (wrx == 1'b0) wr_low_cnt <= wr_low_cnt + 1;
      if (wrx_d == 1'b0 && wrx == 1'b1 && csx == 1'b0) begin
        if (wr_low_cnt >= DBI_MIN_WR_LOW) begin
          if (dcx == 1'b0) begin
            cur_cmd <= d_i;
            if (d_i == DBI_CMD_INIT) initialized <= 1;
            gram_mode <= (d_i == DBI_CMD_GRAM);
            if (d_i == DBI_CMD_GRAM) gram_addr <= 0;
          end else if (gram_mode) begin
            if (initialized) begin
              gram[gram_addr] <= d_i;
              gram_addr <= (gram_addr + 1) % 256;
            end
          end else begin
            regs[cur_cmd] = d_i;
          end
        end
        wr_low_cnt <= 0;
      end
      wrx_d <= wrx;

      // ---- read drive while RDX is low ----
      if (csx == 1'b0 && rdx == 1'b0 && dcx == 1'b1) begin
        slv_d_oe <= 1'b1;
        slv_d_o  <= regs.exists(cur_cmd) ? regs[cur_cmd] : (cur_cmd ^ 8'hA5);
      end else begin
        slv_d_oe <= 1'b0;
      end
    end
  end
endmodule
`endif
