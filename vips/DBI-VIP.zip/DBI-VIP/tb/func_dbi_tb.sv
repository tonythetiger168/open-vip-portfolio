// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_dbi_tb.sv -- self-checking functional test for the MIPI DBI (type B,
// 8-bit) display controller model (dbi_display_controller, flattened by
// smoke/flatten.py). Run: python3 tools/run_func_tests.py DBI-VIP
//
// Model contract (from tb/top_tb.sv and dbi_defs_pkg):
//   a write is latched on the WRX rising edge with CSX low, if WRX was low for
//   at least DBI_MIN_WR_LOW=2 clocks; DCX=0 selects a command, DCX=1 a
//   parameter/pixel. Parameters are stored per command and read back with
//   RDX low, DCX high (unset commands read cmd^0xA5). Memory write (0x2C)
//   streams pixels into GRAM (256 B, auto-increment, wraps) but only after
//   sleep-out (0x11). RESX low resets the controller state.

module func_dbi_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [7:0] INIT = 8'h11, GRAM = 8'h2C, MADCTL = 8'h36, COLMOD = 8'h3A, DISPON = 8'h29;
  int checks = 0, fails = 0;

  logic       clk = 1'b0, resx = 1'b0, csx = 1'b1, dcx = 1'b0, wrx = 1'b1, rdx = 1'b1;
  logic [7:0] d_i = '0;
  wire  [7:0] d_o;
  wire        d_oe;

  always #5 clk = ~clk;

  dbi_display_controller u_dut (
    .clk(clk), .resx(resx), .csx(csx), .dcx(dcx), .wrx(wrx), .rdx(rdx),
    .d_i(d_i), .slv_d_o(d_o), .slv_d_oe(d_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic wr(input bit dc, input [7:0] d, input int low = 2, input bit sel = 1'b1);
    @(negedge clk);
    csx = !sel; dcx = dc; d_i = d; wrx = 1'b0;
    repeat (low) @(negedge clk);
    wrx = 1'b1;
    @(negedge clk);
    csx = 1'b1;
  endtask
  task automatic cmd(input [7:0] c);  wr(1'b0, c); endtask
  task automatic prm(input [7:0] p);  wr(1'b1, p); endtask

  task automatic rd(output [7:0] d, output bit oe);
    @(negedge clk);
    csx = 1'b0; dcx = 1'b1; rdx = 1'b0;
    @(negedge clk);
    d = d_o; oe = d_oe;
    rdx = 1'b1; csx = 1'b1;
  endtask

  logic [7:0] d;
  bit         oe;

  initial begin
    repeat (2) @(negedge clk);
    resx = 1'b1;
    @(negedge clk);
    chk(d_oe === 1'b0, "data bus not driven out of reset");

    // parameter write / read-back per command
    cmd(MADCTL); prm(8'h48);
    rd(d, oe);
    chk(oe === 1'b1 && d === 8'h48, "parameter of MADCTL reads back");
    @(negedge clk);
    chk(d_oe === 1'b0, "data bus released after the read strobe");
    cmd(COLMOD); prm(8'h55);
    rd(d, oe);
    chk(d === 8'h55, "parameter of COLMOD reads back");
    cmd(MADCTL);
    rd(d, oe);
    chk(d === 8'h48, "parameters are stored per command");
    cmd(DISPON);
    rd(d, oe);
    chk(d === (DISPON ^ 8'hA5), "unset command reads the default cmd^0xA5");

    // GRAM writes are dropped before sleep-out
    cmd(GRAM); prm(8'hC1);
    chk(u_dut.gram[0] === 8'h00, "memory write ignored before sleep-out (0x11)");

    // after INIT, pixels stream into GRAM with auto-increment
    cmd(INIT);
    cmd(GRAM); prm(8'hA0); prm(8'hA1); prm(8'hA2);
    chk(u_dut.gram[0] === 8'hA0 && u_dut.gram[1] === 8'hA1 && u_dut.gram[2] === 8'hA2,
        "memory write streams pixels with address auto-increment");
    cmd(GRAM); prm(8'hB0);
    chk(u_dut.gram[0] === 8'hB0 && u_dut.gram[1] === 8'hA1, "new memory-write command restarts at address 0");

    // timing / select qualification
    cmd(MADCTL); wr(1'b1, 8'h99, 1);
    rd(d, oe);
    chk(d === 8'h48, "WRX low pulse shorter than 2 clocks is ignored");
    wr(1'b1, 8'h77, 2, 1'b0);
    rd(d, oe);
    chk(d === 8'h48, "write with CSX high is ignored");

    // GRAM address wraps at 256
    cmd(GRAM);
    for (int i = 0; i < 257; i++) prm(8'(i));
    chk(u_dut.gram[255] === 8'd255 && u_dut.gram[0] === 8'd0 && u_dut.gram_addr == 1,
        "GRAM address wraps after 256 pixels");

    // RESX clears sleep-out: memory writes dropped again
    @(negedge clk); resx = 1'b0;
    @(negedge clk); resx = 1'b1;
    cmd(GRAM); prm(8'hEE);
    chk(u_dut.gram[0] === 8'd0, "after RESX, memory write needs sleep-out again");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
