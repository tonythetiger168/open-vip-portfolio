// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_env.sv -- DBI verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import dbi_defs_pkg::*;
  import dbi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares host-issued (expected) transactions
  // against monitor-decoded (observed) transactions. Read-back expectations
  // come from the driver's shadow register file (true end-to-end checking).
  class dbi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(dbi_scoreboard)
    uvm_analysis_imp_exp #(dbi_transaction, dbi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(dbi_transaction, dbi_scoreboard) obs_ap;

    dbi_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0, n_error_matches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(dbi_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(dbi_transaction t); obs_q.push_back(t); check(); endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        dbi_transaction e = exp_q.pop_front();
        dbi_transaction o = obs_q.pop_front();
        if (e.wr_low < DBI_MIN_WR_LOW) begin
          // error injection: monitor must flag the violated WRX pulse width
          if (o.short_wr) n_error_matches++;
          else begin
            n_mismatches++;
            `uvm_error("SB", $sformatf("short WRX not flagged, obs{%s}", o.convert2string()))
          end
        end else if (e.op == o.op && e.cmd == o.cmd &&
                     e.payload.size() == o.payload.size() &&
                     (e.op != DBI_READ ||
                      (e.rdata.size() == o.rdata.size() &&
                       (e.rdata.size() == 0 || e.rdata[0] == o.rdata[0])))) begin
          n_matches++;
        end else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("dbi scoreboard: n_matches=%0d n_error_matches=%0d n_mismatches=%0d",
                n_matches, n_error_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
      if (exp_q.size() || obs_q.size())
        `uvm_warning("SB", $sformatf("unmatched transactions left: exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
    endfunction
  endclass

  class dbi_env extends uvm_env;
    `uvm_component_utils(dbi_env)
    dbi_agent      agt;
    dbi_scoreboard sb;
    dbi_checker    chk;
    dbi_coverage   cov;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = dbi_agent::type_id::create("agt", this);
      sb  = dbi_scoreboard::type_id::create("sb", this);
      chk = dbi_checker::type_id::create("chk", this);
      cov = dbi_coverage::type_id::create("cov", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
