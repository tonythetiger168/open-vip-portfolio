// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_compliance_checker.sv -- DBI (8080) SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = DBI protocol-specific rules (D stable while WRX low, DCX consistent
//      with command/data phase, CSX frames the transfer, init after RESX)

`ifndef DBI_COMPLIANCE_CHECKER_SV
`define DBI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import dbi_defs_pkg::*;

module dbi_compliance_checker
(
  input logic       clk,
  input logic       resx,
  input dbi_state_e state,
  input logic       csx,
  input logic       dcx,
  input logic       wrx,
  input logic       rdx,
  input logic [7:0] d_i,
  input logic       initialized,
  input logic [7:0] last_cmd,
  input logic       error_inject
);

  // ---------------- L1: signal sanity (4) ----------------
  a_dbi_l1_clk   : assert property (@(posedge clk) disable iff (!resx) !$isunknown(clk))
    else `uvm_error("SVA_L1", "dbi: clock unknown")
  a_dbi_l1_rst   : assert property (@(posedge clk) !$isunknown(resx))
    else `uvm_error("SVA_L1", "dbi: reset unknown")
  a_dbi_l1_state : assert property (@(posedge clk) disable iff (!resx) !$isunknown(state))
    else `uvm_error("SVA_L1", "dbi: state unknown")
  a_dbi_l1_valid : assert property (@(posedge clk) disable iff (!resx)
    state inside {IDLE, COMMAND_WRITE, PARAM_WRITE, PIXEL_WRITE, READ_BACK})
    else `uvm_error("SVA_L1", "dbi: state outside legal encoding")

  // ---------------- L2: FSM legality (5) ----------------
  // L2-1: legal FSM transition from IDLE
  a_dbi_trans_idle : assert property (@(posedge clk) disable iff (!resx)
    state == IDLE |=> state inside {IDLE, COMMAND_WRITE})
    else `uvm_error("SVA_L2", "dbi: illegal transition from IDLE")
  // L2-2: legal FSM transition from COMMAND_WRITE
  a_dbi_trans_command_write : assert property (@(posedge clk) disable iff (!resx)
    state == COMMAND_WRITE |=> state inside {COMMAND_WRITE, PARAM_WRITE, PIXEL_WRITE,
                                             READ_BACK, IDLE})
    else `uvm_error("SVA_L2", "dbi: illegal transition from COMMAND_WRITE")
  // L2-3: legal FSM transition from PARAM_WRITE
  a_dbi_trans_param_write : assert property (@(posedge clk) disable iff (!resx)
    state == PARAM_WRITE |=> state inside {PARAM_WRITE, IDLE})
    else `uvm_error("SVA_L2", "dbi: illegal transition from PARAM_WRITE")
  // L2-4: legal FSM transition from PIXEL_WRITE
  a_dbi_trans_pixel_write : assert property (@(posedge clk) disable iff (!resx)
    state == PIXEL_WRITE |=> state inside {PIXEL_WRITE, IDLE})
    else `uvm_error("SVA_L2", "dbi: illegal transition from PIXEL_WRITE")
  // L2-5: legal FSM transition from READ_BACK
  a_dbi_trans_read_back : assert property (@(posedge clk) disable iff (!resx)
    state == READ_BACK |=> state inside {READ_BACK, IDLE})
    else `uvm_error("SVA_L2", "dbi: illegal transition from READ_BACK")

  // ---------------- L3: protocol rules (4) ----------------
  a_dbi_l3_reset_idle : assert property (@(posedge clk)
    $fell(resx) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "dbi: state not IDLE during reset")
  a_dbi_l3_no_stuck   : assert property (@(posedge clk) disable iff (!resx)
    state == PIXEL_WRITE |-> ##[1:512] (state != PIXEL_WRITE))
    else `uvm_error("SVA_L3", "dbi: stuck in PIXEL_WRITE")
  a_dbi_l3_full_cycle : cover property (@(posedge clk) disable iff (!resx)
    state == IDLE ##1 state == COMMAND_WRITE);
  a_dbi_l3_read_cycle : cover property (@(posedge clk) disable iff (!resx)
    state == COMMAND_WRITE ##1 state == READ_BACK);

  // ---------------- L4: DBI protocol-specific rules (6) ----------------
  // L4-1: D is stable while WRX is low (write data valid window)
  a_dbi_l4_d_stable_wrx : assert property (@(posedge clk)
    disable iff (!resx || error_inject)
    (wrx == 1'b0 && csx == 1'b0) |-> $stable(d_i))
    else `uvm_error("SVA_L4", "dbi: D changed while WRX low")
  // L4-2a: DCX low during the command phase
  a_dbi_l4_dcx_cmd : assert property (@(posedge clk) disable iff (!resx)
    (state == COMMAND_WRITE && csx == 1'b0 && wrx == 1'b0) |-> dcx == 1'b0)
    else `uvm_error("SVA_L4", "dbi: DCX high during command write")
  // L4-2b: DCX high during parameter/pixel data phases
  a_dbi_l4_dcx_data : assert property (@(posedge clk) disable iff (!resx)
    (state inside {PARAM_WRITE, PIXEL_WRITE} && csx == 1'b0 && wrx == 1'b0) |-> dcx == 1'b1)
    else `uvm_error("SVA_L4", "dbi: DCX low during data write")
  // L4-3a: CSX frames the whole transfer (active during any transfer phase)
  a_dbi_l4_csx_covers : assert property (@(posedge clk) disable iff (!resx)
    state != IDLE |-> csx == 1'b0)
    else `uvm_error("SVA_L4", "dbi: transfer phase without CSX")
  // L4-3b: CSX may only release when the transfer is complete (IDLE)
  a_dbi_l4_csx_release : assert property (@(posedge clk) disable iff (!resx)
    $rose(csx) |-> state == IDLE)
    else `uvm_error("SVA_L4", "dbi: CSX released mid-transfer")
  // L4-4: pixel traffic requires the initialization command after RESX
  a_dbi_l4_init_first : assert property (@(posedge clk) disable iff (!resx)
    state == PIXEL_WRITE |-> initialized)
    else `uvm_error("SVA_L4", "dbi: pixel write before initialization command")

endmodule
`endif
