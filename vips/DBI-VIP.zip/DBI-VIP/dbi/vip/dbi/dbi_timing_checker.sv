// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dbi_timing_checker.sv -- MIPI DBI (Display Bus Interface) timing parameter checker

`ifndef DBI_TIMING_CHECKER_SV
`define DBI_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import dbi_defs_pkg::dbi_state_e;

module dbi_timing_checker
(
  input logic clk,
  input logic resx,
  input dbi_state_e state
);
  a_dbi_timing_state_known : assert property (@(posedge clk)
    disable iff (!resx) !$isunknown(state))
    else `uvm_error("TIMING", "dbi timing: state unknown")
endmodule
`endif
