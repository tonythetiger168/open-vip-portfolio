// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_sequences.svh -- DBI (8080) sequence library

`ifndef DBI_SEQUENCES_SVH
`define DBI_SEQUENCES_SVH

class dbi_base_sequence extends uvm_sequence #(dbi_transaction);
  `uvm_object_utils(dbi_base_sequence)
  int num_txns = 20;
  function new(string name = "dbi_base_sequence"); super.new(name); endfunction
  task body();
    dbi_transaction tr;
    repeat (num_txns) begin
      tr = dbi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: display command writes (init / display-on / madctl / colmod)
class dbi_cmd_write_seq extends dbi_base_sequence;
  `uvm_object_utils(dbi_cmd_write_seq)
  function new(string name = "dbi_cmd_write_seq"); super.new(name); endfunction
  task body();
    dbi_transaction tr;
    bit [7:0] cmds[$] = '{dbi_defs_pkg::DBI_CMD_INIT, dbi_defs_pkg::DBI_CMD_DISPON,
                          dbi_defs_pkg::DBI_CMD_MADCTL, dbi_defs_pkg::DBI_CMD_COLMOD,
                          dbi_defs_pkg::DBI_CMD_SWRESET};
    foreach (cmds[i]) begin
      tr = dbi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == DBI_CMD_WRITE; cmd == cmds[i]; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: parameter writes (command + 1-4 parameter bytes)
class dbi_param_write_seq extends dbi_base_sequence;
  `uvm_object_utils(dbi_param_write_seq)
  function new(string name = "dbi_param_write_seq"); super.new(name); endfunction
  task body();
    dbi_transaction tr;
    repeat (num_txns) begin
      tr = dbi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == DBI_PARAM_WRITE;
                                  payload.size() inside {[1:4]}; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: pixel (GRAM) writes - 0x2C followed by pixel data
class dbi_pixel_write_seq extends dbi_base_sequence;
  `uvm_object_utils(dbi_pixel_write_seq)
  function new(string name = "dbi_pixel_write_seq"); super.new(name); endfunction
  task body();
    dbi_transaction tr;
    repeat (num_txns) begin
      tr = dbi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == DBI_PIXEL_WRITE;
                                  payload.size() inside {[4:16]}; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: read back - parameter write followed by read of the same register
class dbi_read_back_seq extends dbi_base_sequence;
  `uvm_object_utils(dbi_read_back_seq)
  function new(string name = "dbi_read_back_seq"); super.new(name); endfunction
  task body();
    dbi_transaction tr;
    bit [7:0] cmd;
    repeat (num_txns) begin
      tr = dbi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == DBI_PARAM_WRITE; payload.size() == 1; });
      cmd = tr.cmd;
      finish_item(tr);
      tr = dbi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == DBI_READ; cmd == local::cmd; });
      finish_item(tr);
    end
  endtask
endclass

// Error injection: WRX low pulse narrower than spec
class dbi_error_inject_seq extends dbi_base_sequence;
  `uvm_object_utils(dbi_error_inject_seq)
  function new(string name = "dbi_error_inject_seq"); super.new(name); endfunction
  task body();
    dbi_transaction tr;
    dbi_op_e ops[$] = '{DBI_CMD_WRITE, DBI_PARAM_WRITE, DBI_PIXEL_WRITE, DBI_CMD_WRITE};
    foreach (ops[i]) begin
      // legal transfer, then the same kind with a violated pulse width
      tr = dbi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == ops[i]; wr_low inside {[2:6]}; });
      finish_item(tr);
      tr = dbi_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == ops[i]; wr_low == 1; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: initialization command issued right after RESX release
class dbi_reset_seq extends dbi_base_sequence;
  `uvm_object_utils(dbi_reset_seq)
  function new(string name = "dbi_reset_seq"); super.new(name); endfunction
  task body();
    dbi_transaction tr = dbi_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { op == DBI_CMD_WRITE;
                                cmd == dbi_defs_pkg::DBI_CMD_INIT; });
    finish_item(tr);
  endtask
endclass

class dbi_random_sequence extends dbi_base_sequence;
  `uvm_object_utils(dbi_random_sequence)
  function new(string name = "dbi_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class dbi_regression_sequence extends dbi_base_sequence;
  `uvm_object_utils(dbi_regression_sequence)
  function new(string name = "dbi_regression_sequence"); super.new(name); endfunction
  task body();
    dbi_cmd_write_seq    cmd = dbi_cmd_write_seq::type_id::create("cmd");
    dbi_param_write_seq  prm = dbi_param_write_seq::type_id::create("prm");
    dbi_pixel_write_seq  pxl = dbi_pixel_write_seq::type_id::create("pxl");
    dbi_read_back_seq    rd  = dbi_read_back_seq::type_id::create("rd");
    dbi_error_inject_seq err = dbi_error_inject_seq::type_id::create("err");
    prm.num_txns = 12; pxl.num_txns = 12; rd.num_txns = 8;
    cmd.start(m_sequencer); prm.start(m_sequencer); pxl.start(m_sequencer);
    rd.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
`endif
