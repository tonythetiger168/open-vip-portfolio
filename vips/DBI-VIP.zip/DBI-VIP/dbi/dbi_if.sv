// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_if.sv -- DBI (8080 parallel) interface (CSX/DCX/WRX/RDX/D[7:0],
// host/display modports)
//
// The host drives D during writes; the display drives D during reads.

interface dbi_if (input logic clk);
  import dbi_defs_pkg::dbi_state_e;

  logic       resx;           // display reset (active low, driven by TB)
  logic       csx;            // chip select (active low)
  logic       dcx;            // 0 = command, 1 = data
  logic       wrx;            // write strobe (active low, latch on rising edge)
  logic       rdx;            // read strobe (active low)

  // Host drive
  logic [7:0] d_o;
  logic       d_oe;
  logic [7:0] d_i;

  // Display drive (read data)
  logic [7:0] slv_d_o;
  logic       slv_d_oe;

  dbi_state_e state;

  // Protocol bookkeeping (driven by host, used by monitor/SVA/coverage)
  logic       initialized;    // DBI_CMD_INIT seen since resx release
  logic [7:0] last_cmd;       // most recent command byte
  logic       error_inject;   // WRX pulse-width violation being injected

  assign d_i = d_oe ? d_o : (slv_d_oe ? slv_d_o : 8'hzz);

  modport MASTER (input  clk, resx, d_i,
                  output csx, dcx, wrx, rdx, d_o, d_oe, state,
                         initialized, last_cmd, error_inject);
  modport SLAVE  (input  clk, resx, csx, dcx, wrx, rdx, d_i,
                  output slv_d_o, slv_d_oe);
  modport MON    (input  clk, resx, csx, dcx, wrx, rdx, d_i, state,
                         initialized, last_cmd, error_inject);

  clocking drv_cb @(posedge clk);
    input  resx, d_i;
    output csx, dcx, wrx, rdx, d_o, d_oe;
  endclocking

  clocking mon_cb @(posedge clk);
    input resx, csx, dcx, wrx, rdx, d_i, state, initialized, last_cmd, error_inject;
  endclocking
endinterface
