// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_monitor.svh -- DBI (8080) monitor: watches CSX/DCX/WRX/RDX and the
// D bus, latches bytes on WRX rising edges, captures read data on RDX
// rising edges, measures WRX low pulse widths and assembles transactions
// (command + payload / read data) per CSX-framed transfer.

`ifndef DBI_MONITOR_SVH
`define DBI_MONITOR_SVH

class dbi_monitor extends uvm_monitor;
  `uvm_component_utils(dbi_monitor)
  virtual dbi_if vif;
  uvm_analysis_port #(dbi_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned short_wr_count = 0;

  protected bit wrx_d = 1, rdx_d = 1, csx_d = 1;
  protected int unsigned wr_low_cnt = 0;
  protected dbi_transaction cur = null;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual dbi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "dbi virtual interface not set")
  endfunction

  task flush_txn();
    if (cur != null) begin
      // classify the transfer
      if (cur.rdata.size() > 0)           cur.op = dbi_defs_pkg::DBI_READ;
      else if (cur.payload.size() == 0)   cur.op = dbi_defs_pkg::DBI_CMD_WRITE;
      else if (cur.cmd == dbi_defs_pkg::DBI_CMD_GRAM) cur.op = dbi_defs_pkg::DBI_PIXEL_WRITE;
      else                                cur.op = dbi_defs_pkg::DBI_PARAM_WRITE;
      cur.fsm_state = vif.state;
      txn_count++;
      `uvm_info("MON", {"mon: ", cur.convert2string()}, UVM_HIGH)
      ap.write(cur);
      cur = null;
    end
  endtask

  task run_phase(uvm_phase phase);
    bit [7:0] b;
    forever begin
      @(posedge vif.clk);
      if (!vif.resx) begin
        flush_txn();
        wrx_d = 1; rdx_d = 1; csx_d = 1; wr_low_cnt = 0;
        continue;
      end

      // WRX low pulse-width measurement
      if (vif.wrx == 1'b0) wr_low_cnt++;

      // write strobe: latch D on WRX rising edge while selected
      if (wrx_d == 1'b0 && vif.wrx == 1'b1 && vif.csx == 1'b0) begin
        b = vif.d_i;
        if (vif.dcx == 1'b0) begin
          flush_txn();                       // a new command closes the previous transfer
          cur = dbi_transaction::type_id::create("tr");
          cur.cmd = b;
        end else if (cur != null) begin
          cur.payload.push_back(b);
        end
        if (cur != null && wr_low_cnt < dbi_defs_pkg::DBI_MIN_WR_LOW) begin
          cur.short_wr = 1;
          short_wr_count++;
          `uvm_warning("MON", $sformatf("WRX low pulse %0d clk(s) < spec %0d",
                       wr_low_cnt, dbi_defs_pkg::DBI_MIN_WR_LOW))
        end
        if (cur != null) cur.wr_low_obs = wr_low_cnt;
        wr_low_cnt = 0;
      end

      // read strobe: capture D on RDX rising edge while selected
      if (rdx_d == 1'b0 && vif.rdx == 1'b1 && vif.csx == 1'b0 && cur != null)
        cur.rdata.push_back(vif.d_i);

      // CSX frames the whole transfer: rising edge closes it
      if (csx_d == 1'b0 && vif.csx == 1'b1) flush_txn();

      wrx_d = vif.wrx; rdx_d = vif.rdx; csx_d = vif.csx;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("dbi monitor observed %0d transactions, %0d short WRX pulses",
              txn_count, short_wr_count), UVM_LOW)
  endfunction
endclass
`endif
