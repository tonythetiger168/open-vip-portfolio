// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// dbi_pkg.sv -- MIPI DBI (Display Bus Interface) UVM VIP package

package dbi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import dbi_defs_pkg::*;
  export dbi_defs_pkg::*;

  `include "dbi_transaction.svh"
  `include "dbi_config.svh"
  `include "dbi_sequencer.svh"
  `include "dbi_driver.svh"
  `include "dbi_monitor.svh"
  `include "dbi_agent.svh"
  `include "dbi_sequences.svh"
  `include "dbi_checker.svh"
  `include "dbi_coverage.svh"
endpackage
