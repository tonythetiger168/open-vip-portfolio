// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_coverage.svh -- DBI (8080) functional coverage

`ifndef DBI_COVERAGE_SVH
`define DBI_COVERAGE_SVH

class dbi_coverage extends uvm_subscriber #(dbi_transaction);
  `uvm_component_utils(dbi_coverage)

  dbi_transaction tr;

  covergroup cg_protocol;
    cp_op : coverpoint tr.op {
      bins cmd   = {dbi_defs_pkg::DBI_CMD_WRITE};
      bins param = {dbi_defs_pkg::DBI_PARAM_WRITE};
      bins pixel = {dbi_defs_pkg::DBI_PIXEL_WRITE};
      bins rd    = {dbi_defs_pkg::DBI_READ};
    }
    cp_cmd : coverpoint tr.cmd {
      bins init   = {dbi_defs_pkg::DBI_CMD_INIT};
      bins gram   = {dbi_defs_pkg::DBI_CMD_GRAM};
      bins dispon = {dbi_defs_pkg::DBI_CMD_DISPON};
      bins madctl = {dbi_defs_pkg::DBI_CMD_MADCTL};
      bins colmod = {dbi_defs_pkg::DBI_CMD_COLMOD};
      bins other  = default;
    }
    cp_len : coverpoint tr.payload.size() {
      bins none  = {0};
      bins one   = {1};
      bins short = {[2:4]};
      bins burst = {[5:16]};
    }
    cp_p0 : coverpoint tr.payload[0] iff (tr.payload.size() > 0) {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins walk = {[8'h01 : 8'hFE]};
    }
    cx_op_len : cross cp_op, cp_len;
  endgroup

  covergroup cg_fsm with function sample(dbi_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {dbi_defs_pkg::IDLE, dbi_defs_pkg::COMMAND_WRITE,
                           dbi_defs_pkg::PARAM_WRITE, dbi_defs_pkg::PIXEL_WRITE,
                           dbi_defs_pkg::READ_BACK};
    }
    cp_trans : coverpoint s {
      bins cmd_param = (dbi_defs_pkg::COMMAND_WRITE => dbi_defs_pkg::PARAM_WRITE);
      bins cmd_pixel = (dbi_defs_pkg::COMMAND_WRITE => dbi_defs_pkg::PIXEL_WRITE);
      bins cmd_read  = (dbi_defs_pkg::COMMAND_WRITE => dbi_defs_pkg::READ_BACK);
      bins xfer_done = (dbi_defs_pkg::PIXEL_WRITE => dbi_defs_pkg::IDLE);
    }
  endgroup

  covergroup cg_error;
    cp_short_wr : coverpoint tr.short_wr { bins ok = {0}; bins err = {1}; }
    cp_wr_low   : coverpoint tr.wr_low_obs {
      bins violated = {0, 1};
      bins legal    = {[dbi_defs_pkg::DBI_MIN_WR_LOW:6]};
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(dbi_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_fsm.sample(t.fsm_state);
    cg_error.sample();
  endfunction
endclass
`endif
