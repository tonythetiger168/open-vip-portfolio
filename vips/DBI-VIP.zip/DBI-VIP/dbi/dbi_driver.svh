// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_driver.svh -- DBI (8080) host driver.
// Protocol-level drive: CSX-framed transfers, command bytes (DCX=0),
// parameter/pixel bytes (DCX=1), RDX read-back, WRX pulse-width control
// (with violation injection), and automatic post-reset initialization
// (DBI_CMD_INIT) before pixel traffic.

`ifndef DBI_DRIVER_SVH
`define DBI_DRIVER_SVH

class dbi_driver extends uvm_driver #(dbi_transaction);
  `uvm_component_utils(dbi_driver)
  virtual dbi_if vif;
  dbi_config cfg;
  uvm_analysis_port #(dbi_transaction) drv_ap;  // expected items for scoreboard

  protected bit [7:0] shadow[bit [7:0]];        // cmd -> last parameter byte

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual dbi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "dbi virtual interface not set")
  endfunction

  // ---- low-level byte write: data launched, WRX pulsed for low_w clks ----
  task write_byte(bit [7:0] b, bit dc, int unsigned low_w);
    vif.drv_cb.dcx  <= dc;
    vif.drv_cb.d_o  <= b;
    vif.drv_cb.d_oe <= 1'b1;
    if (low_w < dbi_defs_pkg::DBI_MIN_WR_LOW) vif.error_inject <= 1'b1;
    vif.drv_cb.wrx  <= 1'b0;
    repeat (low_w) @(vif.drv_cb);
    vif.drv_cb.wrx  <= 1'b1;
    vif.error_inject <= 1'b0;
    @(vif.drv_cb);
  endtask

  // ---- low-level byte read: RDX pulsed, D sampled from the display ----
  task read_byte(output bit [7:0] b);
    vif.drv_cb.dcx  <= 1'b1;
    vif.drv_cb.d_oe <= 1'b0;
    vif.drv_cb.rdx  <= 1'b0;
    repeat (2) @(vif.drv_cb);
    b = vif.d_i;
    vif.drv_cb.rdx  <= 1'b1;
    @(vif.drv_cb);
  endtask

  task xfer_begin();
    @(vif.drv_cb);
    vif.drv_cb.csx <= 1'b0;
    vif.drv_cb.wrx <= 1'b1;
    vif.drv_cb.rdx <= 1'b1;
  endtask

  task xfer_end();
    vif.drv_cb.csx  <= 1'b1;
    vif.drv_cb.d_oe <= 1'b0;
    vif.state <= dbi_defs_pkg::IDLE;
    @(vif.drv_cb);
  endtask

  // Post-reset initialization: DBI_CMD_INIT must precede pixel traffic
  task do_init();
    dbi_transaction e = dbi_transaction::type_id::create("init_exp");
    xfer_begin();
    vif.state <= dbi_defs_pkg::COMMAND_WRITE;
    vif.last_cmd <= dbi_defs_pkg::DBI_CMD_INIT;
    write_byte(dbi_defs_pkg::DBI_CMD_INIT, 1'b0, dbi_defs_pkg::DBI_MIN_WR_LOW);
    xfer_end();
    vif.initialized <= 1'b1;
    e.op = dbi_defs_pkg::DBI_CMD_WRITE;
    e.cmd = dbi_defs_pkg::DBI_CMD_INIT;
    drv_ap.write(e);
  endtask

  task run_phase(uvm_phase phase);
    dbi_transaction tr;
    bit [7:0] rd;
    vif.drv_cb.csx <= 1'b1; vif.drv_cb.wrx <= 1'b1; vif.drv_cb.rdx <= 1'b1;
    vif.drv_cb.d_oe <= 1'b0; vif.drv_cb.dcx <= 1'b0;
    vif.state <= dbi_defs_pkg::IDLE;
    vif.initialized <= 1'b0; vif.last_cmd <= 8'h00; vif.error_inject <= 1'b0;
    wait (vif.resx === 1'b1);
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      if (tr.op == dbi_defs_pkg::DBI_PIXEL_WRITE && !vif.initialized) do_init();
      xfer_begin();
      case (tr.op)
        dbi_defs_pkg::DBI_CMD_WRITE: begin
          vif.state <= dbi_defs_pkg::COMMAND_WRITE;
          vif.last_cmd <= tr.cmd;
          write_byte(tr.cmd, 1'b0, tr.wr_low);
          if (tr.cmd == dbi_defs_pkg::DBI_CMD_INIT) vif.initialized <= 1'b1;
        end
        dbi_defs_pkg::DBI_PARAM_WRITE: begin
          vif.state <= dbi_defs_pkg::COMMAND_WRITE;
          vif.last_cmd <= tr.cmd;
          write_byte(tr.cmd, 1'b0, tr.wr_low);
          vif.state <= dbi_defs_pkg::PARAM_WRITE;
          foreach (tr.payload[i]) write_byte(tr.payload[i], 1'b1, tr.wr_low);
          shadow[tr.cmd] = tr.payload[tr.payload.size()-1];
        end
        dbi_defs_pkg::DBI_PIXEL_WRITE: begin
          vif.state <= dbi_defs_pkg::COMMAND_WRITE;
          vif.last_cmd <= tr.cmd;
          write_byte(tr.cmd, 1'b0, tr.wr_low);
          vif.state <= dbi_defs_pkg::PIXEL_WRITE;
          foreach (tr.payload[i]) write_byte(tr.payload[i], 1'b1, tr.wr_low);
        end
        dbi_defs_pkg::DBI_READ: begin
          vif.state <= dbi_defs_pkg::COMMAND_WRITE;
          vif.last_cmd <= tr.cmd;
          write_byte(tr.cmd, 1'b0, tr.wr_low);
          vif.state <= dbi_defs_pkg::READ_BACK;
          read_byte(rd);
          // end-to-end read prediction from the shadow register file
          tr.rdata.push_back(shadow.exists(tr.cmd) ? shadow[tr.cmd] : (tr.cmd ^ 8'hA5));
          if (rd !== tr.rdata[0])
            `uvm_warning("DRV", $sformatf("read-back mismatch exp=0x%02h got=0x%02h",
                         tr.rdata[0], rd))
        end
      endcase
      xfer_end();
      drv_ap.write(tr);                  // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
