// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_defs.sv -- DBI (8080 parallel) shared type definitions and constants

package dbi_defs_pkg;
  // Bus-level FSM (driven by the host, observed by monitor/SVA)
  typedef enum bit [2:0] {
    IDLE,
    COMMAND_WRITE,
    PARAM_WRITE,
    PIXEL_WRITE,
    READ_BACK
  } dbi_state_e;

  // Transaction-level operations
  typedef enum bit [1:0] {
    DBI_CMD_WRITE,    // command byte only (DCX=0)
    DBI_PARAM_WRITE,  // command + parameter bytes (DCX=1)
    DBI_PIXEL_WRITE,  // GRAM write command 0x2C + pixel data
    DBI_READ          // command + read data (RDX strobe)
  } dbi_op_e;

  localparam int       DBI_MIN_WR_LOW = 2;      // WRX low pulse width (clks)
  localparam bit [7:0] DBI_CMD_INIT   = 8'h11;  // sleep out (required after RESX)
  localparam bit [7:0] DBI_CMD_GRAM   = 8'h2C;  // memory write (pixel data follows)
  localparam bit [7:0] DBI_CMD_DISPON = 8'h29;  // display on
  localparam bit [7:0] DBI_CMD_MADCTL = 8'h36;  // memory access control
  localparam bit [7:0] DBI_CMD_COLMOD = 8'h3A;  // pixel format
  localparam bit [7:0] DBI_CMD_SWRESET= 8'h01;  // software reset
endpackage
