// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dbi_transaction.svh -- DBI (8080) transaction (command write / parameter
// write / pixel (GRAM) write / read back)

`ifndef DBI_TRANSACTION_SVH
`define DBI_TRANSACTION_SVH

class dbi_transaction extends uvm_sequence_item;

  rand dbi_op_e    op;
  rand bit [7:0]   cmd;
  rand bit [7:0]   payload[$];    // parameter / pixel bytes (DCX=1 writes)
  rand int unsigned wr_low;       // WRX low pulse width (clks); < 2 = violation

  // Observed fields (filled by driver expectation / monitor decode)
  bit [7:0]       rdata[$];       // read-back data
  bit             short_wr;       // monitor: WRX low pulse narrower than spec
  int unsigned    wr_low_obs;     // monitor: measured WRX low width
  dbi_state_e     fsm_state;      // monitor: bus state when observed

  constraint c_op     { op dist { DBI_CMD_WRITE := 2, DBI_PARAM_WRITE := 3,
                                  DBI_PIXEL_WRITE := 3, DBI_READ := 1 }; }
  constraint c_cmd    { op == DBI_PIXEL_WRITE -> cmd == dbi_defs_pkg::DBI_CMD_GRAM;
                        op == DBI_PARAM_WRITE -> cmd != dbi_defs_pkg::DBI_CMD_GRAM; }
  constraint c_len    { op == DBI_CMD_WRITE   -> payload.size() == 0;
                        op == DBI_PARAM_WRITE -> payload.size() inside {[1:4]};
                        op == DBI_PIXEL_WRITE -> payload.size() inside {[4:16]};
                        op == DBI_READ        -> payload.size() == 0; }
  constraint c_wr_low { soft wr_low inside {[dbi_defs_pkg::DBI_MIN_WR_LOW:6]}; }

  `uvm_object_utils_begin(dbi_transaction)
    `uvm_field_enum(dbi_op_e, op, UVM_ALL_ON)
    `uvm_field_int(cmd, UVM_ALL_ON)
    `uvm_field_queue_int(payload, UVM_ALL_ON)
    `uvm_field_int(wr_low, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_queue_int(rdata, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(short_wr, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_enum(dbi_state_e, fsm_state, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "dbi_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    dbi_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    ok &= comparer.compare_field("payload_size", payload.size(), t.payload.size(), 32);
    if (op == DBI_READ)
      ok &= comparer.compare_field("rdata_size", rdata.size(), t.rdata.size(), 32);
    return ok;
  endfunction

  function string convert2string();
    string s = $sformatf("DBI %s cmd=0x%02h len=%0d", op.name(), cmd, payload.size());
    foreach (payload[i]) s = {s, $sformatf(" %02h", payload[i])};
    foreach (rdata[i])   s = {s, $sformatf(" rd%02h", rdata[i])};
    if (short_wr) s = {s, " [SHORT_WRX]"};
    return s;
  endfunction
endclass
`endif
