# DBI — MIPI DBI (Display Bus Interface) UVM VIP

Open-source UVM verification IP template for **MIPI DBI (Display Bus Interface)** (MIPI).

## Contents

| Path | Description |
|------|-------------|
| `dbi/dbi_if.sv` | Protocol interface + FSM state enum |
| `dbi/dbi_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `dbi/sva/dbi_compliance_checker.sv` | SVA compliance checker (L1=4, L2=5, L3=4, L4=6) |
| `dbi/vip/dbi/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + end-to-end scoreboard |
| `tests/dbi_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with functional display controller DUT |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **8080-protocol host driver**: CSX-framed transfers, command (DCX=0) / parameter / pixel (DCX=1) writes, RDX read-back, programmable WRX pulse width with violation injection, automatic DBI_CMD_INIT before pixel traffic, shadow register file for read prediction
- **Protocol-decoding monitor**: WRX rising-edge byte latching, RDX read capture, WRX low pulse-width measurement, CSX-framed transfer assembly and classification
- **End-to-end scoreboard**: host-issued vs monitor-decoded comparison (op/cmd/payload/read-back data), short-WRX error-injection matching
- **Functional DUT model**: display controller - command decode, register file, GRAM write with auto-increment, init-before-pixel enforcement, short-WRX rejection
- **Directed sequence library**: command-write / param-write / pixel-write / read-back / WRX-violation error-inject / reset + random + regression mix
- **Functional coverage**: op x length cross, command bins (init/GRAM/display-on), payload corners, FSM states + command-to-data/read transitions, short-WRX and pulse-width error bins
- **SVA L4**: D stable while WRX low, DCX consistent with command/data phase, CSX framing and release rules, initialization required before pixel writes
