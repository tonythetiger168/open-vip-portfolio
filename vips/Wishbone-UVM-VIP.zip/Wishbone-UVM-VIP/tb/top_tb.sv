// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- Wishbone testbench top with a functional Wishbone DUT model

`ifndef WISHBONE_UVM_VIP_TB_SV
`define WISHBONE_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import wishbone_defs_pkg::*;
import wishbone_pkg::*;
import wishbone_env_pkg::*;
import wishbone_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  wishbone_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  wishbone_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .wb_cyc_i(vif.wb_cyc_i),
    .wb_stb_i(vif.wb_stb_i),
    .wb_we_i(vif.wb_we_i),
    .wb_adr_i(vif.wb_adr_i),
    .wb_sel_i(vif.wb_sel_i),
    .wb_dat_i(vif.wb_dat_i),
    .wb_cti_i(vif.wb_cti_i),
    .wb_bte_i(vif.wb_bte_i),
    .wb_stall_o(vif.wb_stall_o),
    .wb_ack_o(vif.wb_ack_o),
    .wb_err_o(vif.wb_err_o),
    .wb_rty_o(vif.wb_rty_o),
    .wb_dat_o(vif.wb_dat_o)
  );

  // Concurrent protocol checks
  wishbone_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .wb_cyc_i(vif.wb_cyc_i),
    .wb_stb_i(vif.wb_stb_i),
    .wb_we_i(vif.wb_we_i),
    .wb_adr_i(vif.wb_adr_i),
    .wb_sel_i(vif.wb_sel_i),
    .wb_dat_i(vif.wb_dat_i),
    .wb_cti_i(vif.wb_cti_i),
    .wb_bte_i(vif.wb_bte_i),
    .wb_stall_o(vif.wb_stall_o),
    .wb_ack_o(vif.wb_ack_o),
    .wb_err_o(vif.wb_err_o),
    .wb_rty_o(vif.wb_rty_o),
    .wb_dat_o(vif.wb_dat_o)
  );

  initial begin
    uvm_config_db#(virtual wishbone_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module wishbone_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        wb_cyc_i,
  input  logic        wb_stb_i,
  input  logic        wb_we_i,
  input  logic [31:0] wb_adr_i,
  input  logic [3:0]  wb_sel_i,
  input  logic [31:0] wb_dat_i,
  input  logic [2:0]  wb_cti_i,
  input  logic [1:0]  wb_bte_i,
  output logic        wb_stall_o,
  output logic        wb_ack_o,
  output logic        wb_err_o,
  output logic        wb_rty_o,
  output logic [31:0] wb_dat_o
);
  logic [31:0] mem [0:255];
  logic [31:0] dev [0:15];
  logic [1:0]  tries [0:15];
  // response queue: {kind (0 ACK, 1 ERR, 2 RTY), data}
  logic [1:0]  q_k [0:3];
  logic [31:0] q_d [0:3];
  logic [1:0]  wp, rp;
  logic [2:0]  cnt;
  logic [7:0]  lfsr;
  logic        bact;             // inside a CTI burst
  logic [11:0] bnext;            // the address the burst must use next
  logic        acc, give, bad;
  logic [1:0]  kind;
  logic [31:0] rd;
  logic [1:0]  reg_;
  logic        ack_q, err_q, rty_q;
  logic [31:0] dat_q;

  function automatic logic [11:0] nxt(input logic [11:0] a, input logic [1:0] bte);
    case (bte)
      2'd1: nxt = {a[11:4], a[3:2] + 2'd1, 2'b00};
      2'd2: nxt = {a[11:5], a[4:2] + 3'd1, 2'b00};
      2'd3: nxt = {a[11:6], a[5:2] + 4'd1, 2'b00};
      default: nxt = a + 12'd4;
    endcase
  endfunction

  // registered terminations, qualified with CYC so that none is seen after the master drops it
  assign wb_ack_o = ack_q && wb_cyc_i;
  assign wb_err_o = err_q && wb_cyc_i;
  assign wb_rty_o = rty_q && wb_cyc_i;
  assign wb_dat_o = wb_cyc_i ? dat_q : 32'h0;
  assign wb_stall_o = rst_n && wb_cyc_i && wb_stb_i && (lfsr[1:0] == 2'b00 || cnt == 3'd4);
  assign acc  = wb_cyc_i && wb_stb_i && !wb_stall_o;
  assign give = wb_cyc_i && cnt != 3'd0 && !lfsr[4];
  assign bad  = (wb_cti_i >= 3'b011 && wb_cti_i <= 3'b110) || (bact && wb_adr_i[11:0] != bnext);
  assign reg_ = (wb_adr_i[31:10] == 22'h0) ? 2'd0 : (wb_adr_i[31:6] == 26'h20) ? 2'd1 : 2'd2;

  always_comb begin
    kind = 2'd0; rd = 32'h0;
    if (bad || reg_ == 2'd2) kind = 2'd1;
    else if (reg_ == 2'd1) begin
      if (tries[wb_adr_i[5:2]] != 2'd2) kind = 2'd2;
      else if (!wb_we_i) rd = dev[wb_adr_i[5:2]];
    end else if (!wb_we_i) rd = mem[wb_adr_i[9:2]];
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 256; i++) mem[i] <= 32'h0;
      for (int i = 0; i < 16; i++) begin dev[i] <= 32'h0; tries[i] <= 2'd0; end
      for (int i = 0; i < 4; i++) begin q_k[i] <= 2'd0; q_d[i] <= 32'h0; end
      wp <= 2'd0; rp <= 2'd0; cnt <= 3'd0; lfsr <= 8'hC3; bact <= 1'b0; bnext <= 12'h0;
      ack_q <= 1'b0; err_q <= 1'b0; rty_q <= 1'b0; dat_q <= 32'h0;
    end else begin
      lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};
      ack_q <= 1'b0; err_q <= 1'b0; rty_q <= 1'b0; dat_q <= 32'h0;
      if (!wb_cyc_i) begin
        // CYC low ends the bus cycle: queued responses are dropped, the burst is over
        cnt <= 3'd0; rp <= wp; bact <= 1'b0;
      end else begin
        if (acc) begin
          q_k[wp] <= kind; q_d[wp] <= rd; wp <= wp + 2'd1;
          bact  <= (wb_cti_i == 3'b001 || wb_cti_i == 3'b010);
          bnext <= (wb_cti_i == 3'b001) ? wb_adr_i[11:0] : nxt(wb_adr_i[11:0], wb_bte_i);
          if (kind == 2'd2) tries[wb_adr_i[5:2]] <= tries[wb_adr_i[5:2]] + 2'd1;
          else if (!bad && reg_ == 2'd1) tries[wb_adr_i[5:2]] <= 2'd0;
          if (kind == 2'd0 && wb_we_i)
            for (int b = 0; b < 4; b++) if (wb_sel_i[b]) begin
              if (reg_ == 2'd1) dev[wb_adr_i[5:2]][8 * b +: 8] <= wb_dat_i[8 * b +: 8];
              else mem[wb_adr_i[9:2]][8 * b +: 8] <= wb_dat_i[8 * b +: 8];
            end
        end
        if (give) begin
          ack_q <= (q_k[rp] == 2'd0); err_q <= (q_k[rp] == 2'd1); rty_q <= (q_k[rp] == 2'd2);
          dat_q <= q_d[rp]; rp <= rp + 2'd1;
        end
        cnt <= cnt + {2'b0, acc} - {2'b0, give};
      end
    end
  end
endmodule
`endif
