// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- Wishbone testbench top with a functional Wishbone DUT model

`ifndef Wishbone_TB_SV
`define Wishbone_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import wishbone_defs_pkg::*;
import wishbone_pkg::*;
import wishbone_env_pkg::*;
import wishbone_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  wishbone_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  wishbone_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .wb_adr_i(vif.wb_adr_i),
    .wb_dat_i(vif.wb_dat_i),
    .wb_we_i(vif.wb_we_i),
    .wb_stb_i(vif.wb_stb_i),
    .wb_cyc_i(vif.wb_cyc_i),
    .wb_ack_o(vif.wb_ack_o),
    .wb_dat_o(vif.wb_dat_o)
  );

  // Concurrent protocol checks
  wishbone_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .wb_adr_i(vif.wb_adr_i), .wb_dat_i(vif.wb_dat_i), .wb_we_i(vif.wb_we_i), .wb_stb_i(vif.wb_stb_i), .wb_cyc_i(vif.wb_cyc_i), .wb_ack_o(vif.wb_ack_o), .wb_dat_o(vif.wb_dat_o)
  );

  initial begin
    uvm_config_db#(virtual wishbone_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module wishbone_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [31:0] wb_adr_i,
  input  logic [31:0] wb_dat_i,
  input  logic        wb_we_i,
  input  logic        wb_stb_i,
  input  logic        wb_cyc_i,
  output logic        wb_ack_o,
  output logic [31:0] wb_dat_o
);
  logic [31:0] mem [0:15];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wb_ack_o <= 1'b0;
      wb_dat_o <= '0;
      for (int i = 0; i < 16; i++) mem[i] <= '0;
    end else begin
      wb_ack_o <= wb_cyc_i && wb_stb_i && !wb_ack_o;
      if (wb_cyc_i && wb_stb_i && !wb_ack_o && wb_we_i)
        mem[wb_adr_i[5:2]] <= wb_dat_i;
      if (wb_cyc_i && wb_stb_i && wb_we_i)
        wb_dat_o <= wb_dat_i;
      else if (wb_cyc_i && wb_stb_i)
        wb_dat_o <= mem[wb_adr_i[5:2]];
    end
  end
endmodule
`endif
