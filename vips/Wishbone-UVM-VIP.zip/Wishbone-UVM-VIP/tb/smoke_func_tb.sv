// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (Wishbone DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened wishbone_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic wb_cyc_i = 0, wb_stb_i = 0, wb_we_i = 0;
  logic [31:0] wb_adr_i = 0, wb_dat_i = 0;
  logic [3:0] wb_sel_i = 4'hF;
  logic [2:0] wb_cti_i = 0;
  logic [1:0] wb_bte_i = 0;
  wire wb_stall_o, wb_ack_o, wb_err_o, wb_rty_o;
  wire [31:0] wb_dat_o;

  always #5 clk = ~clk;

  wishbone_model u_dut (.clk(clk), .rst_n(rst_n), .wb_cyc_i(wb_cyc_i), .wb_stb_i(wb_stb_i), .wb_we_i(wb_we_i),
                        .wb_adr_i(wb_adr_i), .wb_sel_i(wb_sel_i), .wb_dat_i(wb_dat_i), .wb_cti_i(wb_cti_i),
                        .wb_bte_i(wb_bte_i), .wb_stall_o(wb_stall_o), .wb_ack_o(wb_ack_o), .wb_err_o(wb_err_o),
                        .wb_rty_o(wb_rty_o), .wb_dat_o(wb_dat_o));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // response log
  logic [1:0]  r_k [0:255];
  logic [31:0] r_d [0:255];
  int nr = 0, nstall = 0, nacc = 0;
  always @(posedge clk) begin
    if (wb_ack_o || wb_err_o || wb_rty_o) begin
      r_k[nr % 256] = wb_ack_o ? 0 : wb_err_o ? 1 : 2; r_d[nr % 256] = wb_dat_o; nr++;
    end
    if (wb_stb_i && wb_stall_o) nstall++;
    if (wb_stb_i && wb_cyc_i && !wb_stall_o) nacc++;
  end

  task automatic idle(input int n); repeat (n) @(negedge clk); endtask
  // one request, held until a clock without STALL
  task automatic rq(input logic w, input logic [31:0] a, input logic [3:0] s, input logic [31:0] d,
                    input logic [2:0] c, input logic [1:0] b);
    bit st;
    wb_stb_i = 1; wb_we_i = w; wb_adr_i = a; wb_sel_i = s; wb_dat_i = d; wb_cti_i = c; wb_bte_i = b;
    do begin @(posedge clk); st = wb_stall_o; @(negedge clk); end while (st);
    wb_stb_i = 0;
  endtask
  int r0;
  task automatic wait_rsp(input int k);
    int t = 0;
    while (nr < r0 + k && t < 200) begin @(negedge clk); t++; end
    chk(nr >= r0 + k, $sformatf("%0d responses", k));
  endtask
  task automatic cyc_on(); wb_cyc_i = 1; r0 = nr; endtask
  task automatic cyc_off(input int k); wait_rsp(k); wb_cyc_i = 0; idle(1); endtask
  // a whole classic single cycle
  task automatic single(input logic w, input logic [31:0] a, input logic [3:0] s, input logic [31:0] d);
    cyc_on(); rq(w, a, s, d, 3'b000, 2'b00); cyc_off(1);
  endtask

  initial begin
    idle(3);
    chk(!wb_ack_o && !wb_err_o && !wb_rty_o && wb_dat_o == 0, "quiet in reset");
    wb_cyc_i = 1; wb_stb_i = 1; #1; chk(!wb_stall_o, "no STALL in reset"); wb_cyc_i = 0; wb_stb_i = 0;
    @(negedge clk); rst_n = 1; idle(2);
    wb_stb_i = 1; #1; chk(!wb_stall_o, "no STALL without CYC"); wb_stb_i = 0;

    single(1, 32'h010, 4'hF, 32'hCAFE_F00D);
    chk(r_k[r0 % 256] == 0 && r_d[r0 % 256] == 0, "write: ACK, DAT_O 0");
    single(0, 32'h010, 4'hF, 0);
    chk(r_k[r0 % 256] == 0 && r_d[r0 % 256] == 32'hCAFE_F00D, "read back");
    single(1, 32'h010, 4'h2, 32'h0000_AB00); single(1, 32'h010, 4'h8, 32'h7700_0000); single(1, 32'h010, 4'h0, 32'hFFFF_FFFF);
    single(0, 32'h010, 4'h0, 0);
    chk(r_d[r0 % 256] == 32'h77FE_AB0D, $sformatf("SEL byte lanes (%h)", r_d[r0 % 256]));
    single(1, 32'h3FC, 4'hF, 32'h1357); single(0, 32'h3FC, 4'hF, 0);
    chk(r_k[r0 % 256] == 0 && r_d[r0 % 256] == 32'h1357, "0x3FC is memory");
    single(0, 32'h014, 4'hF, 0);
    chk(r_d[r0 % 256] == 0, "neighbour still 0");

    // error region and the 32-bit decode
    single(0, 32'h400, 4'hF, 0); chk(r_k[r0 % 256] == 1 && r_d[r0 % 256] == 0, "0x400: ERR");
    single(1, 32'h7FC, 4'hF, 32'h1); chk(r_k[r0 % 256] == 1, "0x7FC: ERR");
    single(0, 32'h840, 4'hF, 0); chk(r_k[r0 % 256] == 1, "0x840 (past the device): ERR");
    single(0, 32'h1000, 4'hF, 0); chk(r_k[r0 % 256] == 1, "0x1000 (ADR above bit 11): ERR");
    single(0, 32'h1000_0010, 4'hF, 0); chk(r_k[r0 % 256] == 1, "upper ADR bits decoded");
    single(0, 32'h010, 4'hF, 0); chk(r_d[r0 % 256] == 32'h77FE_AB0D, "error-region accesses wrote nothing");

    // busy device: RTY, RTY, ACK per word
    single(1, 32'h804, 4'hF, 32'h5EED); chk(r_k[r0 % 256] == 2, "busy device: first try RTY");
    single(1, 32'h804, 4'hF, 32'h5EED); chk(r_k[r0 % 256] == 2, "second try RTY");
    single(0, 32'h808, 4'hF, 0); chk(r_k[r0 % 256] == 2, "another word counts its own tries");
    single(1, 32'h804, 4'hF, 32'h5EED); chk(r_k[r0 % 256] == 0, "third try ACK");
    single(0, 32'h804, 4'hF, 0); chk(r_k[r0 % 256] == 2, "the count restarts after an ACK");
    single(0, 32'h804, 4'hF, 0); single(0, 32'h804, 4'hF, 0);
    chk(r_k[r0 % 256] == 0 && r_d[r0 % 256] == 32'h5EED, "device word written once accepted");
    single(0, 32'h808, 4'hF, 0); single(0, 32'h808, 4'hF, 0);
    chk(r_k[r0 % 256] == 0 && r_d[r0 % 256] == 0, "RTY attempts wrote nothing");
    single(1, 32'h83C, 4'h1, 32'hAA); single(1, 32'h83C, 4'h1, 32'hAA); single(1, 32'h83C, 4'h1, 32'hAA);
    single(0, 32'h83C, 4'hF, 0); single(0, 32'h83C, 4'hF, 0); single(0, 32'h83C, 4'hF, 0);
    chk(r_d[r0 % 256] == 32'hAA, "last device word, SEL lane 0");
    single(0, 32'h03C, 4'hF, 0); chk(r_d[r0 % 256] == 0, "device word does not alias memory");
    // a request rejected for its CTI is not a try and does not restart the count
    single(0, 32'h820, 4'hF, 0); chk(r_k[r0 % 256] == 2, "device word 8: first try RTY");
    cyc_on(); rq(0, 32'h820, 4'hF, 0, 3'b100, 2'd0); cyc_off(1); chk(r_k[r0 % 256] == 1, "reserved CTI to the device: ERR");
    single(0, 32'h820, 4'hF, 0); chk(r_k[r0 % 256] == 2, "second try RTY");
    single(0, 32'h820, 4'hF, 0); chk(r_k[r0 % 256] == 0, "third try ACK: the ERR did not count");

    // pipelined incrementing burst, 8 requests, linear
    cyc_on();
    for (int i = 0; i < 8; i++) rq(1, 32'h100 + 4 * i, 4'hF, 32'h11 * (i + 1), (i == 7) ? 3'b111 : 3'b010, 2'd0);
    cyc_off(8);
    begin bit ok = 1; for (int i = 0; i < 8; i++) if (r_k[(r0 + i) % 256] != 0) ok = 0; chk(ok, "8 ACKs for the linear burst"); end
    cyc_on();
    for (int i = 0; i < 8; i++) rq(0, 32'h100 + 4 * i, 4'hF, 0, (i == 7) ? 3'b111 : 3'b010, 2'd0);
    cyc_off(8);
    begin bit ok = 1; for (int i = 0; i < 8; i++) if (r_d[(r0 + i) % 256] != 32'h11 * (i + 1) || r_k[(r0 + i) % 256] != 0) ok = 0;
          chk(ok, "8 read beats in order"); end
    // wrap-4 from the third word: 0x188, 0x18C, 0x180, 0x184
    cyc_on();
    rq(0, 32'h188, 4'hF, 0, 3'b010, 2'd1); rq(0, 32'h18C, 4'hF, 0, 3'b010, 2'd1);
    rq(0, 32'h180, 4'hF, 0, 3'b010, 2'd1); rq(0, 32'h184, 4'hF, 0, 3'b111, 2'd1);
    cyc_off(4);
    begin bit ok = 1; for (int i = 0; i < 4; i++) if (r_k[(r0 + i) % 256] != 0) ok = 0; chk(ok, "wrap-4 burst accepted"); end
    cyc_on();
    rq(0, 32'h188, 4'hF, 0, 3'b010, 2'd1); rq(0, 32'h18C, 4'hF, 0, 3'b010, 2'd1); rq(0, 32'h190, 4'hF, 0, 3'b111, 2'd1);
    cyc_off(3);
    chk(r_k[r0 % 256] == 0 && r_k[(r0 + 1) % 256] == 0 && r_k[(r0 + 2) % 256] == 1, "wrap-4 without the wrap: ERR");
    // wrap-8: 0x11C -> 0x100; wrap-16: 0x13C -> 0x100
    cyc_on(); rq(0, 32'h118, 4'hF, 0, 3'b010, 2'd2); rq(0, 32'h11C, 4'hF, 0, 3'b010, 2'd2); rq(0, 32'h100, 4'hF, 0, 3'b111, 2'd2); cyc_off(3);
    chk(r_k[(r0 + 2) % 256] == 0 && r_d[(r0 + 2) % 256] == 32'h11 && r_d[(r0 + 1) % 256] == 32'h88, "wrap-8 back to 0x100");
    cyc_on(); rq(0, 32'h13C, 4'hF, 0, 3'b010, 2'd3); rq(0, 32'h100, 4'hF, 0, 3'b111, 2'd3); cyc_off(2);
    chk(r_k[(r0 + 1) % 256] == 0, "wrap-16 back to 0x100");
    cyc_on(); rq(0, 32'h13C, 4'hF, 0, 3'b010, 2'd2); rq(0, 32'h120, 4'hF, 0, 3'b111, 2'd2); cyc_off(2);
    chk(r_k[(r0 + 1) % 256] == 0, "wrap-8 from 0x13C wraps to 0x120");
    cyc_on(); rq(0, 32'h13C, 4'hF, 0, 3'b010, 2'd0); rq(0, 32'h140, 4'hF, 0, 3'b111, 2'd0); cyc_off(2);
    chk(r_k[(r0 + 1) % 256] == 0, "linear crosses 0x140");
    cyc_on(); rq(0, 32'h13C, 4'hF, 0, 3'b010, 2'd0); rq(0, 32'h100, 4'hF, 0, 3'b111, 2'd0); cyc_off(2);
    chk(r_k[(r0 + 1) % 256] == 1, "linear does not wrap: ERR");
    // constant-address burst
    cyc_on(); for (int i = 0; i < 4; i++) rq(1, 32'h200, 4'h1 << i, 32'hFFFF_FFFF, (i == 3) ? 3'b111 : 3'b001, 2'd0); cyc_off(4);
    single(0, 32'h200, 4'hF, 0); chk(r_d[r0 % 256] == 32'hFFFF_FFFF, "constant burst: four lanes into one word");
    cyc_on(); rq(0, 32'h200, 4'hF, 0, 3'b001, 2'd0); rq(0, 32'h204, 4'hF, 0, 3'b111, 2'd0); cyc_off(2);
    chk(r_k[(r0 + 1) % 256] == 1, "constant burst with a new address: ERR");
    // a burst address error writes nothing and the burst goes on from the received address
    cyc_on(); rq(1, 32'h220, 4'hF, 32'h1, 3'b010, 2'd0); rq(1, 32'h230, 4'hF, 32'h2, 3'b010, 2'd0);
    rq(1, 32'h234, 4'hF, 32'h3, 3'b111, 2'd0); cyc_off(3);
    chk(r_k[r0 % 256] == 0 && r_k[(r0 + 1) % 256] == 1 && r_k[(r0 + 2) % 256] == 0, "ERR on the jump, the next request follows it");
    single(0, 32'h230, 4'hF, 0); chk(r_d[r0 % 256] == 0, "the ERR request wrote nothing");
    single(0, 32'h234, 4'hF, 0); chk(r_d[r0 % 256] == 32'h3, "the request after it was written");
    // end of burst, classic after a burst, reserved CTI
    cyc_on(); rq(0, 32'h100, 4'hF, 0, 3'b010, 2'd0); rq(0, 32'h104, 4'hF, 0, 3'b111, 2'd0); rq(0, 32'h300, 4'hF, 0, 3'b000, 2'd0); cyc_off(3);
    chk(r_k[(r0 + 2) % 256] == 0, "after end-of-burst any address is fine");
    cyc_on(); rq(0, 32'h100, 4'hF, 0, 3'b000, 2'd0); rq(0, 32'h300, 4'hF, 0, 3'b000, 2'd0); cyc_off(2);
    chk(r_k[(r0 + 1) % 256] == 0, "classic requests are not a burst");
    for (int c = 3; c <= 6; c++) begin
      cyc_on(); rq(1, 32'h240, 4'hF, 32'h99, c[2:0], 2'd0); cyc_off(1);
      chk(r_k[r0 % 256] == 1, $sformatf("reserved CTI %0d: ERR", c));
    end
    single(0, 32'h240, 4'hF, 0); chk(r_d[r0 % 256] == 0, "reserved-CTI writes landed nowhere");
    cyc_on(); rq(0, 32'h100, 4'hF, 0, 3'b111, 2'd0); rq(0, 32'h300, 4'hF, 0, 3'b111, 2'd0); cyc_off(2);
    chk(r_k[r0 % 256] == 0 && r_k[(r0 + 1) % 256] == 0, "end-of-burst alone is a single");
    // the burst state ends with CYC
    cyc_on(); rq(0, 32'h100, 4'hF, 0, 3'b010, 2'd0); cyc_off(1);
    cyc_on(); rq(0, 32'h300, 4'hF, 0, 3'b111, 2'd0); cyc_off(1);
    chk(r_k[r0 % 256] == 0, "a new bus cycle starts outside any burst");

    // four outstanding, STALL while full
    begin : full
      int acc = 0, early = 0, t = 0;
      cyc_on(); wb_stb_i = 1; wb_we_i = 0; wb_adr_i = 32'h100; wb_cti_i = 3'b000;
      while (acc < 6 && t < 100) begin
        #4; if (!wb_stall_o) begin acc++; if (acc == 5 && nr == r0) early = 1; end
        @(negedge clk); t++;
      end
      wb_stb_i = 0;
      chk(!early, "no fifth request accepted before a response");
      cyc_off(6);
      chk(nr == r0 + 6, "six responses for six requests");
    end
    // abort: CYC dropped with responses outstanding
    cyc_on();
    for (int i = 0; i < 4; i++) rq(1, 32'h2C0 + 4 * i, 4'hF, 32'hAB0 + i, (i == 3) ? 3'b111 : 3'b010, 2'd0);
    wb_cyc_i = 0; idle(1);
    begin int n1; n1 = nr; idle(10); chk(nr == n1, "no response after CYC drops"); end
    cyc_on(); for (int i = 0; i < 4; i++) rq(0, 32'h2C0 + 4 * i, 4'hF, 0, (i == 3) ? 3'b111 : 3'b010, 2'd0); cyc_off(4);
    chk(r_d[r0 % 256] == 32'hAB0 && r_d[(r0 + 3) % 256] == 32'hAB3, "aborted writes were performed when accepted");
    chk(r_k[r0 % 256] == 0 && nr == r0 + 4, "the next cycle gets only its own responses");
    // gaps: STB low between requests of a burst
    cyc_on(); rq(0, 32'h100, 4'hF, 0, 3'b010, 2'd0); idle(3); rq(0, 32'h104, 4'hF, 0, 3'b111, 2'd0); cyc_off(2);
    chk(r_k[(r0 + 1) % 256] == 0 && r_d[(r0 + 1) % 256] == 32'h22, "idle clocks inside a burst");
    // wait states: the LFSR pattern
    chk(nstall == 32 && nacc == 111, $sformatf("STALL pattern: %0d stalls for %0d requests", nstall, nacc));

    // reset clears memory, device, retry counts and the queue
    single(1, 32'h000, 4'hF, 32'h600D);
    single(1, 32'h800, 4'hF, 32'hD0D0); single(1, 32'h800, 4'hF, 32'hD0D0); single(1, 32'h800, 4'hF, 32'hD0D0);
    single(0, 32'h800, 4'hF, 0); chk(r_k[r0 % 256] == 2, "device word 0: one try counted before the reset");
    cyc_on(); rq(0, 32'h100, 4'hF, 0, 3'b000, 2'd0);
    @(negedge clk); rst_n = 0; idle(2);
    chk(!wb_ack_o && !wb_err_o && !wb_rty_o, "reset clears the responses");
    wb_cyc_i = 0; rst_n = 1; idle(2);
    single(0, 32'h100, 4'hF, 0); chk(r_k[r0 % 256] == 0 && r_d[r0 % 256] == 0, "memory cleared");
    single(0, 32'h808, 4'hF, 0); chk(r_k[r0 % 256] == 2, "retry count cleared");
    single(0, 32'h000, 4'hF, 0); chk(r_d[r0 % 256] == 0, "word 0 cleared");
    single(0, 32'h800, 4'hF, 0); chk(r_k[r0 % 256] == 2, "device word 0: count cleared, first try RTY");
    single(0, 32'h800, 4'hF, 0); chk(r_k[r0 % 256] == 2, "device word 0: second try RTY");
    single(0, 32'h800, 4'hF, 0); chk(r_k[r0 % 256] == 0 && r_d[r0 % 256] == 0, "device word 0 cleared");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
