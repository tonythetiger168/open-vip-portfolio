// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (Wishbone write/read cycle)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened wishbone_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [31:0] wb_adr_i = '0;
  logic [31:0] wb_dat_i = '0;
  logic wb_we_i = 1'b0;
  logic wb_stb_i = 1'b0;
  logic wb_cyc_i = 1'b0;
  wire  wb_ack_o;
  wire  [31:0] wb_dat_o;

  always #5 clk = ~clk;

  wishbone_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .wb_adr_i(wb_adr_i), .wb_dat_i(wb_dat_i),
    .wb_we_i(wb_we_i), .wb_stb_i(wb_stb_i),
    .wb_cyc_i(wb_cyc_i),
    .wb_ack_o(wb_ack_o), .wb_dat_o(wb_dat_o)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  initial begin
    logic [31:0] wdata [0:3];
    wdata[0] = 32'hDEAD_BEEF; wdata[1] = 32'h12345678;
    wdata[2] = 32'hA5A5A5A5; wdata[3] = 32'h00000001;

    repeat (8) step();
    chk(wb_ack_o === 1'b0, "ack reset low");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // write 4 words to word-aligned addresses 0..3
    for (int a = 0; a < 4; a++) begin
      @(negedge clk);
      wb_adr_i = a*4; wb_dat_i = wdata[a];
      wb_we_i = 1; wb_stb_i = 1; wb_cyc_i = 1;
      step();
      chk(wb_ack_o === 1'b1, "write acknowledged");
      @(negedge clk); wb_stb_i = 0; wb_cyc_i = 0; wb_we_i = 0;
      step();
      chk(wb_ack_o === 1'b0, "ack deasserts after cycle");
    end

    // read back: dat_o shows written data
    for (int a = 0; a < 4; a++) begin
      @(negedge clk);
      wb_adr_i = a*4; wb_we_i = 0; wb_stb_i = 1; wb_cyc_i = 1;
      step();
      chk(wb_ack_o === 1'b1, "read acknowledged");
      chk(wb_dat_o === wdata[a], "read data integrity");
      @(negedge clk); wb_stb_i = 0; wb_cyc_i = 0;
      step();
    end

    // idle: no ack
    repeat (4) begin step(); chk(wb_ack_o === 1'b0, "no ack when idle"); end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
