// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_wishbone_tb.sv -- Wishbone B4 classic-cycle functional test for the
// register model (wishbone_model, flattened by smoke/flatten.py);
// complements smoke_func_tb.sv.
// Run: python3 tools/run_func_tests.py Wishbone-UVM-VIP
//
// Model contract (from tb/top_tb.sv): 16 x 32-bit registers (ADR[5:2]),
// cleared by reset; ACK one clock after CYC && STB (one ACK per cycle,
// registered); a write is stored once per ACK; DAT_O carries the read data
// (or echoes the write data) with ACK. Checked against a reference with
// 400 random classic cycles, STB held over consecutive cycles, and cycles
// where only one of CYC / STB is high.

`timescale 1ns/1ps
module func_wishbone_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [31:0] adr = '0, dat_i = '0;
  logic        we = 0, stb = 0, cyc = 0;
  wire         ack;
  wire  [31:0] dat_o;

  always #5 clk = ~clk;

  wishbone_model u_dut (
    .clk(clk), .rst_n(rst_n), .wb_adr_i(adr), .wb_dat_i(dat_i), .wb_we_i(we),
    .wb_stb_i(stb), .wb_cyc_i(cyc), .wb_ack_o(ack), .wb_dat_o(dat_o)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic [31:0] ref_r [0:15];
  int          lat, stray_ack;
  logic [31:0] rd;

  always @(posedge clk) if (ack && !(cyc && stb)) stray_ack++;

  task automatic cycle(input bit w, input [31:0] a, input [31:0] d = '0);
    @(negedge clk);
    cyc = 1; stb = 1; we = w; adr = a; dat_i = d;
    lat = 0;
    @(negedge clk);
    while (!ack) begin lat++; @(negedge clk); end
    rd = dat_o;
    if (w) ref_r[a[5:2]] = d;
    @(negedge clk);                           // ACK sampled at this edge ends the cycle
    cyc = 0; stb = 0; we = 0;
  endtask

  int bad;
  initial begin
    repeat (2) @(negedge clk);
    chk(!ack && dat_o === '0, "reset: ACK low, DAT_O 0");
    rst_n = 1'b1;
    for (int i = 0; i < 16; i++) ref_r[i] = '0;

    bad = 0;
    for (int i = 0; i < 16; i++) begin cycle(0, i * 4); if (rd !== 32'h0) bad++; end
    chk(bad == 0, "all 16 registers read 0 after reset");

    cycle(1, 32'h14, 32'hA5A5_0014);
    chk(lat == 0 && rd == 32'hA5A5_0014, "write: ACK in the next clock, DAT_O echoes the write data");
    cycle(0, 32'h14);
    chk(lat == 0 && rd == 32'hA5A5_0014, "read: ACK in the next clock with the register value");
    cycle(0, 32'h1014);
    chk(rd == 32'hA5A5_0014, "registers decode ADR[5:2] only");

    // CYC without STB and STB without CYC: no cycle
    @(negedge clk); cyc = 1; stb = 0; we = 1; adr = 32'h8; dat_i = 32'hBAD0_0008;
    repeat (4) @(negedge clk);
    cyc = 0; stb = 1;
    repeat (4) @(negedge clk);
    stb = 0; we = 0;
    chk(stray_ack == 0, "no ACK unless both CYC and STB are high");
    cycle(0, 32'h8);
    chk(rd == 32'h0, "no write unless both CYC and STB are high");

    // STB held over consecutive write cycles: one write per ACK
    @(negedge clk);
    cyc = 1; stb = 1; we = 1; adr = 32'h20; dat_i = 32'h1;
    for (int k = 0; k < 4; k++) begin
      @(negedge clk);
      while (!ack) @(negedge clk);
      ref_r[8 + k] = dat_i;
      @(negedge clk);                         // ACK sampled: next cycle's address / data
      adr = 32'h24 + 4 * k; dat_i = 32'h2 + k;
    end
    cyc = 0; stb = 0; we = 0;
    bad = 0;
    for (int k = 0; k < 4; k++) begin cycle(0, 32'h20 + 4 * k); if (rd !== ref_r[8 + k]) bad++; end
    chk(bad == 0, "consecutive cycles with STB held: each ACK completes exactly one write");

    // random classic cycles
    bad = 0;
    for (int t = 0; t < 400; t++) begin
      logic [31:0] a;
      a = $urandom_range(15) * 4;
      if ($urandom_range(1)) cycle(1, a, $urandom);
      else begin cycle(0, a); if (rd !== ref_r[a[5:2]]) bad++; end
      if (lat != 0) bad++;
      repeat ($urandom_range(2)) @(negedge clk);
    end
    chk(bad == 0, "400 random cycles match the reference registers, ACK latency 1");
    chk(stray_ack == 0, "ACK only during a cycle");

    // reset clears registers and a pending ACK
    @(negedge clk); cyc = 1; stb = 1; we = 1; adr = 32'h3C; dat_i = 32'h77;
    @(negedge clk);
    chk(ack, "(ACK pending before reset)");
    rst_n = 1'b0;
    #1;
    chk(!ack && dat_o === '0, "reset drops ACK and DAT_O");
    cyc = 0; stb = 0; we = 0;
    @(negedge clk); rst_n = 1'b1;
    bad = 0;
    for (int i = 0; i < 16; i++) begin cycle(0, i * 4); if (rd !== 32'h0) bad++; end
    chk(bad == 0, "reset clears all registers");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
