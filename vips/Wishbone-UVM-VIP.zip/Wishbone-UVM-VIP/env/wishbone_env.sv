// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_env.sv -- Wishbone environment: reference-model scoreboard, checker, coverage

package wishbone_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import wishbone_defs_pkg::*;
  import wishbone_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // ---- UVM RAL model: wishbone_model register file, 16 x 32-bit registers at ADR[5:2], reset 0
  class wishbone_data_reg extends uvm_reg;
    `uvm_object_utils(wishbone_data_reg)
    rand uvm_reg_field DATA;
    function new(string name = "wishbone_data_reg"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      DATA = uvm_reg_field::type_id::create("DATA");
      //            parent size lsb access volatile reset has_reset rand individually_accessible
      DATA.configure(this, 32,  0,  "RW",  0,       32'h0, 1,        1,   1);
    endfunction
  endclass

  class wishbone_reg_block extends uvm_reg_block;
    `uvm_object_utils(wishbone_reg_block)
    localparam int N_REGS = 16;
    rand wishbone_data_reg REG[N_REGS];
    uvm_reg_map       map;
    function new(string name = "wishbone_reg_block"); super.new(name, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      map = create_map("map", 'h0, 4, UVM_LITTLE_ENDIAN, 1);
      default_map = map;
      foreach (REG[i]) begin
        REG[i] = wishbone_data_reg::type_id::create($sformatf("REG%0d", i));
        REG[i].configure(this, null, "");
        REG[i].build();
        map.add_reg(REG[i], i * 4, "RW");
      end
    endfunction
  endclass

  // register access <-> Wishbone transaction (the driver fills the read data
  // into the request item, so no separate response is needed)
  class wishbone_reg_adapter extends uvm_reg_adapter;
    `uvm_object_utils(wishbone_reg_adapter)
    function new(string name = "wishbone_reg_adapter");
      super.new(name);
      supports_byte_enable = 0;
      provides_responses   = 0;
    endfunction
    virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
      wishbone_transaction t = wishbone_transaction::type_id::create("t");
      t.we   = (rw.kind == UVM_WRITE);
      t.adr  = rw.addr[31:0];
      t.wdat = t.we ? rw.data[31:0] : 32'h0;
      return t;
    endfunction
    virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
      wishbone_transaction t;
      if (!$cast(t, bus_item)) begin
        `uvm_fatal("RAL", "bus2reg: not a wishbone_transaction")
        return;
      end
      rw.kind   = t.we ? UVM_WRITE : UVM_READ;
      rw.addr   = t.adr;
      rw.data   = t.we ? t.wdat : t.rdat;
      rw.status = UVM_IS_OK;
    endfunction
  endclass

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class wishbone_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(wishbone_scoreboard)
    uvm_analysis_imp_exp #(wishbone_transaction, wishbone_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(wishbone_transaction, wishbone_scoreboard) obs_ap;

    wishbone_config cfg;
    wishbone_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [31:0] regs [16];   // reset value 0

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(wishbone_config)::get(this, "", "cfg", cfg))
        cfg = wishbone_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(wishbone_transaction t);
      if (t.we) begin
        regs[t.adr[5:2]] = t.wdat;
        t.rdat = t.wdat;            // the model echoes the write data on DAT_O
      end else
        t.rdat = regs[t.adr[5:2]];
    endfunction

    function void write_exp(wishbone_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(wishbone_transaction t);
      wishbone_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        wishbone_transaction e = exp_q.pop_front();
        wishbone_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("wishbone scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class wishbone_env extends uvm_env;
    `uvm_component_utils(wishbone_env)
    wishbone_agent      agt;
    wishbone_scoreboard sb;
    wishbone_checker    chk;
    wishbone_coverage   cov;

    // UVM RAL: register model of the DUT model, frontdoor through the agent,
    // mirror kept by an explicit predictor fed by the monitor
    wishbone_reg_block                         regmodel;
    wishbone_reg_adapter                       reg_adapter;
    uvm_reg_predictor #(wishbone_transaction)  reg_predictor;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = wishbone_agent     ::type_id::create("agt", this);
      sb  = wishbone_scoreboard::type_id::create("sb",  this);
      chk = wishbone_checker   ::type_id::create("chk", this);
      cov = wishbone_coverage  ::type_id::create("cov", this);
      regmodel = wishbone_reg_block::type_id::create("regmodel");
      regmodel.configure(null, "");
      regmodel.build();
      regmodel.lock_model();
      reg_adapter   = wishbone_reg_adapter::type_id::create("reg_adapter");
      reg_predictor = uvm_reg_predictor#(wishbone_transaction)::type_id::create("reg_predictor", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
      regmodel.default_map.set_sequencer(agt.sqr, reg_adapter);
      regmodel.default_map.set_auto_predict(0);
      reg_predictor.map     = regmodel.default_map;
      reg_predictor.adapter = reg_adapter;
      agt.mon.ap.connect(reg_predictor.bus_in);
    endfunction
  endclass
endpackage
