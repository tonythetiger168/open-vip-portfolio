// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_env.sv -- Wishbone environment: reference-model scoreboard, checker, coverage

package wishbone_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import wishbone_defs_pkg::*;
  import wishbone_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // ---- UVM RAL model: wishbone_model memory words 0..15 (ADR 0x00-0x3C), reset 0
  class wishbone_data_reg extends uvm_reg;
    `uvm_object_utils(wishbone_data_reg)
    rand uvm_reg_field DATA;
    function new(string name = "wishbone_data_reg"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      DATA = uvm_reg_field::type_id::create("DATA");
      //            parent size lsb access volatile reset has_reset rand individually_accessible
      DATA.configure(this, 32,  0,  "RW",  0,       32'h0, 1,        1,   1);
    endfunction
  endclass

  class wishbone_reg_block extends uvm_reg_block;
    `uvm_object_utils(wishbone_reg_block)
    localparam int N_REGS = 16;
    rand wishbone_data_reg REG[N_REGS];
    uvm_reg_map       map;
    function new(string name = "wishbone_reg_block"); super.new(name, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      map = create_map("map", 'h0, 4, UVM_LITTLE_ENDIAN, 1);
      default_map = map;
      foreach (REG[i]) begin
        REG[i] = wishbone_data_reg::type_id::create($sformatf("REG%0d", i));
        REG[i].configure(this, null, "");
        REG[i].build();
        map.add_reg(REG[i], i * 4, "RW");
      end
    endfunction
  endclass

  // register access <-> Wishbone transaction (the driver fills the read data
  // into the request item, so no separate response is needed)
  class wishbone_reg_adapter extends uvm_reg_adapter;
    `uvm_object_utils(wishbone_reg_adapter)
    function new(string name = "wishbone_reg_adapter");
      super.new(name);
      supports_byte_enable = 0;
      provides_responses   = 0;
    endfunction
    virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
      wishbone_transaction t = wishbone_transaction::type_id::create("t");
      t.we       = (rw.kind == UVM_WRITE);
      t.adr      = rw.addr[11:0];
      t.n        = 1;
      t.mode     = WB_CLASSIC;
      t.bte      = 0;
      t.sel      = 32'hF;
      t.wdat     = t.we ? {224'h0, rw.data[31:0]} : 256'h0;
      t.inj      = WB_INJ_NONE;
      t.abort_at = 0;
      return t;
    endfunction
    virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
      wishbone_transaction t;
      if (!$cast(t, bus_item)) begin
        `uvm_fatal("RAL", "bus2reg: not a wishbone_transaction")
        return;
      end
      rw.kind   = t.we ? UVM_WRITE : UVM_READ;
      rw.addr   = t.badr[11:0];
      rw.data   = t.we ? t.wdat[31:0] : t.rdat[31:0];
      rw.status = (t.rsp[1:0] == 2'd0) ? UVM_IS_OK : UVM_NOT_OK;
    endfunction
  endclass

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class wishbone_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(wishbone_scoreboard)
    uvm_analysis_imp_exp #(wishbone_transaction, wishbone_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(wishbone_transaction, wishbone_scoreboard) obs_ap;

    wishbone_config cfg;
    wishbone_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [31:0] mem  [256];   // reset value 0
    bit [31:0] dev  [16];    // busy device behind RTY
    bit [1:0]  tries[16];
    function bit [1:0] region(bit [31:0] a);   // 0 memory, 1 busy device, 2 error
      if (a[31:10] == 0) return 0;
      if (a[31:6] == 26'h20) return 1;
      return 2;
    endfunction

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(wishbone_config)::get(this, "", "cfg", cfg))
        cfg = wishbone_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(wishbone_transaction t);
      begin
        bit bact = 0;
        bit [11:0] bnext = 0;
        for (int i = 0; i < t.n; i++) begin
          bit [11:0] a = t.badr[12 * i +: 12];
          bit [2:0]  c = t.bcti[3 * i +: 3];
          bit [1:0]  r;
          bit [31:0] d = 0;
          bit e = (c inside {[3'b011:3'b110]}) || (bact && a != bnext);
          bact = (c == 3'b001 || c == 3'b010);
          bnext = (c == 3'b001) ? a : wb_next(a, t.bte);
          if (e || region({20'h0, a}) == 2) r = 2'd1;
          else if (region({20'h0, a}) == 1) begin
            if (tries[a[5:2]] < 2) begin r = 2'd2; tries[a[5:2]]++; end
            else begin
              r = 2'd0; tries[a[5:2]] = 0;
              if (t.we) begin for (int b = 0; b < 4; b++) if (t.sel[4 * i + b]) dev[a[5:2]][8 * b +: 8] = t.wdat[32 * i + 8 * b +: 8]; end
              else d = dev[a[5:2]];
            end
          end else begin
            r = 2'd0;
            if (t.we) begin for (int b = 0; b < 4; b++) if (t.sel[4 * i + b]) mem[a[9:2]][8 * b +: 8] = t.wdat[32 * i + 8 * b +: 8]; end
            else d = mem[a[9:2]];
          end
          // a request whose response was dropped by the abort keeps the observed "none"
          if (i < t.nrsp) begin t.rsp[2 * i +: 2] = r; t.rdat[32 * i +: 32] = d; end
        end
      end
    endfunction

    function void write_exp(wishbone_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(wishbone_transaction t);
      wishbone_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active && !(t.n == 0)) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        wishbone_transaction e = exp_q.pop_front();
        wishbone_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("wishbone scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class wishbone_env extends uvm_env;
    `uvm_component_utils(wishbone_env)
    wishbone_agent      agt;
    wishbone_scoreboard sb;
    wishbone_checker    chk;
    wishbone_coverage   cov;

    // UVM RAL: register model of the DUT model, frontdoor through the agent,
    // mirror kept by an explicit predictor fed by the monitor
    wishbone_reg_block                         regmodel;
    wishbone_reg_adapter                       reg_adapter;
    uvm_reg_predictor #(wishbone_transaction)  reg_predictor;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = wishbone_agent     ::type_id::create("agt", this);
      sb  = wishbone_scoreboard::type_id::create("sb",  this);
      chk = wishbone_checker   ::type_id::create("chk", this);
      cov = wishbone_coverage  ::type_id::create("cov", this);
      regmodel = wishbone_reg_block::type_id::create("regmodel");
      regmodel.configure(null, "");
      regmodel.build();
      regmodel.lock_model();
      reg_adapter   = wishbone_reg_adapter::type_id::create("reg_adapter");
      reg_predictor = uvm_reg_predictor#(wishbone_transaction)::type_id::create("reg_predictor", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
      regmodel.default_map.set_sequencer(agt.sqr, reg_adapter);
      regmodel.default_map.set_auto_predict(0);
      reg_predictor.map     = regmodel.default_map;
      reg_predictor.adapter = reg_adapter;
      agt.mon.ap.connect(reg_predictor.bus_in);
    endfunction
  endclass
endpackage
