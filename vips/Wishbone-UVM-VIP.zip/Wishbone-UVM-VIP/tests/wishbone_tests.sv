// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_tests.sv -- Wishbone tests

package wishbone_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import wishbone_defs_pkg::*;
  import wishbone_pkg::*;
  import wishbone_env_pkg::*;

  // constrained-random traffic (cfg.num_items items)
  class wishbone_base_test extends uvm_test;
    `uvm_component_utils(wishbone_base_test)
    wishbone_env env;
    wishbone_config cfg;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      cfg = wishbone_config::type_id::create("cfg");
      uvm_config_db#(wishbone_config)::set(this, "*", "cfg", cfg);
      env = wishbone_env::type_id::create("env", this);
    endfunction

    virtual task stimulus();
      wishbone_base_sequence seq = wishbone_base_sequence::type_id::create("seq");
      seq.cfg = cfg;
      seq.start(env.agt.sqr);
    endtask

    task run_phase(uvm_phase phase);
      phase.raise_objection(this);
      stimulus();
      #(2000ns);   // let the monitor see the last DUT response
      phase.drop_objection(this);
    endtask

    // pass criteria: scoreboard checked traffic and nothing was reported
    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      super.report_phase(phase);
      if (env.sb.n_checks == 0)
        `uvm_error("TEST", "scoreboard checked no traffic")
      else if (rs.get_severity_count(UVM_ERROR) == 0 && rs.get_severity_count(UVM_FATAL) == 0)
        $display("SB_PASS checks=%0d", env.sb.n_checks);
    endfunction
  endclass

  // directed corner cases, then random traffic; the test run on Verilator
  // by tools/run_uvm_tests.py
  class wishbone_func_test extends wishbone_base_test;
    `uvm_component_utils(wishbone_func_test)

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task stimulus();
      wishbone_directed_sequence dseq = wishbone_directed_sequence::type_id::create("dseq");
      dseq.cfg = cfg;
      dseq.start(env.agt.sqr);
      super.stimulus();
    endtask
  endclass

  // UVM RAL on the DUT model's register file (env regmodel):
  //   1. uvm_reg_hw_reset_seq  -- every register reads its reset value
  //   2. uvm_reg_bit_bash_seq  -- every bit of every register writes 0/1 and reads back
  //   3. pseudo-random write + mirror(UVM_CHECK) + read on every register
  // The scoreboard checks the same traffic against the reference model.
  // Uses no randomize(). Prints "RAL_PASS checks=<n>" when nothing was reported.
  class wishbone_ral_test extends wishbone_base_test;
    `uvm_component_utils(wishbone_ral_test)
    int unsigned checks;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task stimulus();
      uvm_reg_hw_reset_seq rst_seq;
      uvm_reg_bit_bash_seq bb_seq;
      uvm_status_e         status;
      uvm_reg_data_t       val, exp;
      wishbone_reg_block        rm = env.regmodel;
      bit [31:0]           x = 32'h1357_9BDF;

      rst_seq = uvm_reg_hw_reset_seq::type_id::create("rst_seq");
      rst_seq.model = rm;
      rst_seq.start(null);
      checks += rm.N_REGS;

      bb_seq = uvm_reg_bit_bash_seq::type_id::create("bb_seq");
      bb_seq.model = rm;
      bb_seq.start(null);
      checks += rm.N_REGS * 32;

      foreach (rm.REG[i]) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        rm.REG[i].write(status, x);
        if (status != UVM_IS_OK) `uvm_error("RAL", $sformatf("REG%0d write status %s", i, status.name()))
      end
      foreach (rm.REG[i]) begin
        exp = rm.REG[i].get_mirrored_value();
        rm.REG[i].mirror(status, UVM_CHECK);
        rm.REG[i].read(status, val);
        if (status != UVM_IS_OK || val != exp)
          `uvm_error("RAL", $sformatf("REG%0d read 0x%08h status %s, expected 0x%08h",
                     i, val, status.name(), exp))
        checks += 2;
      end
    endtask

    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      super.report_phase(phase);
      if (rs.get_severity_count(UVM_ERROR) + rs.get_severity_count(UVM_FATAL) == 0)
        $display("RAL_PASS checks=%0d", checks);
      else
        $display("RAL_FAIL errors=%0d", rs.get_severity_count(UVM_ERROR));
    endfunction
  endclass
endpackage
