// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_defs.sv -- Wishbone shared type definitions

package wishbone_defs_pkg;

  typedef enum bit [1:0] {WISHBONE_OK, WISHBONE_ERR} wishbone_status_e;

  typedef enum bit [1:0] { WB_CLASSIC = 0, WB_CONST = 1, WB_INCR = 2, WB_SINGLES = 3 } wb_mode_e;
  typedef enum bit [1:0] { WB_INJ_NONE = 0, WB_INJ_ADDR = 1, WB_INJ_CTI = 2 } wb_inj_e;
  // next address of an incrementing burst
  function automatic bit [11:0] wb_next(bit [11:0] a, bit [1:0] bte);
    case (bte)
      2'd1: return {a[11:4], a[3:2] + 2'd1, 2'b00};
      2'd2: return {a[11:5], a[4:2] + 3'd1, 2'b00};
      2'd3: return {a[11:6], a[5:2] + 4'd1, 2'b00};
      default: return a + 12'd4;
    endcase
  endfunction

endpackage
