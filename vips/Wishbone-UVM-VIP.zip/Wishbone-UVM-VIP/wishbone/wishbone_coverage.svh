// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_coverage.svh -- Wishbone functional coverage

class wishbone_coverage extends uvm_subscriber #(wishbone_transaction);
  `uvm_component_utils(wishbone_coverage)
  wishbone_config cfg;
  wishbone_transaction tr;

  covergroup wishbone_cg;
    coverpoint tr.wb_adr_i;
    coverpoint tr.wb_dat_i;
    coverpoint tr.wb_we_i;
    coverpoint tr.wb_stb_i;
    coverpoint tr.wb_cyc_i;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(wishbone_config)::get(this, "*", "cfg", cfg));
    wishbone_cg = new();
  endfunction

  function void write(wishbone_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    wishbone_cg.sample();
  endfunction
endclass
