// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_coverage.svh -- Wishbone functional coverage

class wishbone_coverage extends uvm_subscriber #(wishbone_transaction);
  `uvm_component_utils(wishbone_coverage)
  wishbone_config cfg;
  wishbone_transaction tr;

  covergroup wishbone_cg;
    cp_we    : coverpoint tr.we;
    cp_mode  : coverpoint tr.mode iff (tr.n > 0);
    cp_n     : coverpoint tr.n { bins one = {1}; bins few = {[2:4]}; bins many = {[5:7]}; bins max = {8}; }
    cp_bte   : coverpoint tr.bte iff (tr.mode == WB_INCR) { bins linear = {0}; bins wrap4 = {1}; bins wrap8 = {2}; bins wrap16 = {3}; }
    cp_rsp0  : coverpoint tr.rsp[1:0] iff (tr.nrsp > 0) { bins ack = {0}; bins err = {1}; bins rty = {2}; }
    cp_abort : coverpoint (tr.nrsp < tr.n) { bins full = {0}; bins aborted = {1}; }
    cp_sel   : coverpoint tr.sel[3:0] iff (tr.we) { bins full = {4'hF}; bins none = {0}; bins part = {[1:14]}; }
    cp_stall : coverpoint tr.stalls { bins none = {0}; bins some = {[1:3]}; bins many = {[4:$]}; }
    x_mode_we : cross cp_mode, cp_we;
    x_bte_we  : cross cp_bte, cp_we;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    wishbone_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(wishbone_config)::get(this, "", "cfg", cfg))
      cfg = wishbone_config::type_id::create("cfg");
  endfunction

  function void write(wishbone_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    wishbone_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("Wishbone coverage: %0.1f%%", wishbone_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
