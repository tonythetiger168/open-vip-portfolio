// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_sequences.svh -- Wishbone sequences

// Random traffic: cfg.num_items constrained-random items.
class wishbone_base_sequence extends uvm_sequence #(wishbone_transaction);
  `uvm_object_utils(wishbone_base_sequence)
  wishbone_config cfg;

  function new(string name = "wishbone_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = wishbone_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "wishbone_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class wishbone_directed_sequence extends uvm_sequence #(wishbone_transaction);
  `uvm_object_utils(wishbone_directed_sequence)
  wishbone_config cfg;

  function new(string name = "wishbone_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function wishbone_transaction item();
    item = wishbone_transaction::type_id::create("req");
  endfunction

  task send(wishbone_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    wishbone_transaction t;
    // every cycle type, then read back
    t = item(); t.we = 1; t.mode = WB_CLASSIC; t.n = 1; t.adr = 12'h010; t.sel = 32'hF; t.wdat = 32'hCAFE_F00D; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    t = item(); t.we = 0; t.mode = WB_CLASSIC; t.n = 1; t.adr = 12'h010; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    for (int b = 0; b < 4; b++) begin
      t = item(); t.we = 1; t.mode = WB_INCR; t.bte = b; t.n = 8; t.adr = 12'h100 + 12'h40 * b + 12'h8; t.sel = '1;
      for (int i = 0; i < 8; i++) t.wdat[32 * i +: 32] = 32'h1000 * b + i;
      t.inj = WB_INJ_NONE; t.abort_at = 0; t.bgap = (b == 2) ? 8'b0101_0100 : 0; send(t);
      t = item(); t.we = 0; t.mode = WB_INCR; t.bte = b; t.n = 8; t.adr = 12'h100 + 12'h40 * b + 12'h8; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    end
    t = item(); t.we = 1; t.mode = WB_CONST; t.n = 4; t.adr = 12'h200; t.sel = 32'h0000_8421; t.wdat = '1; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    t = item(); t.we = 0; t.mode = WB_SINGLES; t.n = 8; t.adr = 12'h1F8; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    t = item(); t.we = 0; t.mode = WB_CONST; t.n = 3; t.adr = 12'h200; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    t = item(); t.we = 1; t.mode = WB_CLASSIC; t.n = 1; t.adr = 12'h200; t.sel = 32'h0; t.wdat = 32'h1; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    // busy device: RTY, RTY, ACK
    for (int k = 0; k < 3; k++) begin t = item(); t.we = 1; t.mode = WB_CLASSIC; t.n = 1; t.adr = 12'h804; t.sel = 32'hF; t.wdat = 32'h5EED; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t); end
    t = item(); t.we = 0; t.mode = WB_SINGLES; t.n = 3; t.adr = 12'h804; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    // error region, burst errors, abort
    t = item(); t.we = 0; t.mode = WB_SINGLES; t.n = 4; t.adr = 12'h3F8; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
    t = item(); t.we = 1; t.mode = WB_INCR; t.bte = 0; t.n = 6; t.adr = 12'h300; t.sel = '1; t.wdat = '1; t.inj = WB_INJ_ADDR; t.inj_at = 3; t.abort_at = 0; send(t);
    t = item(); t.we = 0; t.mode = WB_INCR; t.bte = 1; t.n = 4; t.adr = 12'h300; t.inj = WB_INJ_CTI; t.inj_at = 1; t.abort_at = 0; send(t);
    t = item(); t.we = 1; t.mode = WB_INCR; t.bte = 0; t.n = 8; t.adr = 12'h380; t.sel = '1; t.wdat = '1; t.inj = WB_INJ_NONE; t.abort_at = 3; send(t);
    t = item(); t.we = 0; t.mode = WB_INCR; t.bte = 0; t.n = 8; t.adr = 12'h380; t.inj = WB_INJ_NONE; t.abort_at = 0; send(t);
  endtask
endclass
