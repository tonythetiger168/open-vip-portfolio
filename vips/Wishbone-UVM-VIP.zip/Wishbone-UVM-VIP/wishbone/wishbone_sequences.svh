// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_sequences.svh -- Wishbone sequences

// Random traffic: cfg.num_items constrained-random items.
class wishbone_base_sequence extends uvm_sequence #(wishbone_transaction);
  `uvm_object_utils(wishbone_base_sequence)
  wishbone_config cfg;

  function new(string name = "wishbone_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = wishbone_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "wishbone_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class wishbone_directed_sequence extends uvm_sequence #(wishbone_transaction);
  `uvm_object_utils(wishbone_directed_sequence)
  wishbone_config cfg;

  function new(string name = "wishbone_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function wishbone_transaction item();
    item = wishbone_transaction::type_id::create("req");
  endfunction

  task send(wishbone_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    wishbone_transaction t;
    // write every register with a distinct pattern, then read all back
    for (int i = 0; i < 16; i++) begin
      t = item(); t.we = 1; t.adr = i * 4; t.wdat = 32'hA5A5_0000 | (i * 32'h0101_0101); send(t);
    end
    for (int i = 0; i < 16; i++) begin
      t = item(); t.we = 0; t.adr = i * 4; send(t);
    end
    // overwrite, all-ones / all-zeros data, immediate read-after-write
    t = item(); t.we = 1; t.adr = 32'h3C; t.wdat = 32'hFFFF_FFFF; send(t);
    t = item(); t.we = 0; t.adr = 32'h3C; send(t);
    t = item(); t.we = 1; t.adr = 32'h00; t.wdat = 32'h0; send(t);
    t = item(); t.we = 0; t.adr = 32'h00; send(t);
  endtask
endclass
