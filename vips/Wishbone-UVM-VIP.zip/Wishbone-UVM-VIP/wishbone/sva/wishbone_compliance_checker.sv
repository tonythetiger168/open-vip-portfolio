// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_compliance_checker.sv -- Wishbone concurrent assertion checks (bindable)

module wishbone_compliance_checker
  (input logic clk, input logic rst_n, input logic wb_cyc_i, input logic wb_stb_i, input logic wb_we_i, input logic [31:0] wb_adr_i, input logic [3:0] wb_sel_i, input logic [31:0] wb_dat_i, input logic [2:0] wb_cti_i, input logic [1:0] wb_bte_i, input logic wb_stall_o, input logic wb_ack_o, input logic wb_err_o, input logic wb_rty_o, input logic [31:0] wb_dat_o);

  logic [3:0] outst;      // accepted requests not yet answered in this bus cycle
  always @(posedge clk or negedge rst_n)
    if (!rst_n) outst <= 4'd0;
    else if (!wb_cyc_i) outst <= 4'd0;
    else outst <= outst + (wb_stb_i && !wb_stall_o) - (wb_ack_o || wb_err_o || wb_rty_o);
  // no X on the slave's outputs out of reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({wb_stall_o, wb_ack_o, wb_err_o, wb_rty_o}))
    else $error("Wishbone: X on STALL / ACK / ERR / RTY");
  assert property (@(posedge clk) disable iff (!rst_n) wb_ack_o |-> !$isunknown(wb_dat_o))
    else $error("Wishbone: X on DAT_O with ACK");
  // master rules
  assert property (@(posedge clk) disable iff (!rst_n) wb_stb_i |-> wb_cyc_i)
    else $error("Wishbone: STB outside CYC");
  assert property (@(posedge clk) disable iff (!rst_n) wb_stb_i && wb_stall_o |=>
                   wb_stb_i && $stable({wb_we_i, wb_adr_i, wb_sel_i, wb_dat_i, wb_cti_i, wb_bte_i}) || !wb_cyc_i)
    else $error("Wishbone: request changed while STALL");
  // slave rules
  assert property (@(posedge clk) disable iff (!rst_n) $onehot0({wb_ack_o, wb_err_o, wb_rty_o}))
    else $error("Wishbone: more than one of ACK / ERR / RTY");
  assert property (@(posedge clk) disable iff (!rst_n) (wb_ack_o || wb_err_o || wb_rty_o) |-> wb_cyc_i && outst != 0)
    else $error("Wishbone: termination without an outstanding request");
  cover property (@(posedge clk) disable iff (!rst_n) wb_stb_i && wb_stall_o ##1 wb_stb_i && !wb_stall_o);
  cover property (@(posedge clk) disable iff (!rst_n) wb_rty_o);
  cover property (@(posedge clk) disable iff (!rst_n) wb_cyc_i && outst != 0 ##1 !wb_cyc_i);
  cover property (@(posedge clk) disable iff (!rst_n) wb_stb_i && wb_cti_i == 3'b010 && wb_bte_i == 2'd3);
endmodule
