// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_compliance_checker.sv -- Wishbone concurrent assertion checks (bindable)

module wishbone_compliance_checker
  (input logic clk, input logic rst_n, input [31:0] wb_adr_i, input [31:0] wb_dat_i, input wb_we_i, input wb_stb_i, input wb_cyc_i, input wb_ack_o, input [31:0] wb_dat_o);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({wb_ack_o, wb_dat_o}))
    else $error("Wishbone: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> wb_ack_o == '0)
    else $error("Wishbone: output not in reset value");
  // ACK only inside an active cycle
  assert property (@(posedge clk) disable iff (!rst_n) wb_ack_o |-> (wb_cyc_i && wb_stb_i))
    else $error("WB: ACK outside cycle");
  // single-cycle ACK, no doubling
  assert property (@(posedge clk) disable iff (!rst_n) wb_ack_o |=> !wb_ack_o || !(wb_cyc_i && wb_stb_i))
    else $error("WB: back-to-back ACK");
  cover property (@(posedge clk) disable iff (!rst_n) (wb_ack_o != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (wb_we_i == 1'b1));
endmodule
