// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_driver.svh -- Wishbone driver: one bus cycle per item: requests issued while STALL is low (optionally with idle clocks), responses counted until all are in or the cycle is aborted

class wishbone_driver extends uvm_driver #(wishbone_transaction);
  `uvm_component_utils(wishbone_driver)

  uvm_analysis_port #(wishbone_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual wishbone_if vif;
  wishbone_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual wishbone_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "wishbone: virtual interface not set")
    if (!uvm_config_db#(wishbone_config)::get(this, "", "cfg", cfg))
      cfg = wishbone_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wishbone_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.wb_cyc_i <= 1'b0; vif.drv_cb.wb_stb_i <= 1'b0; vif.drv_cb.wb_we_i <= 1'b0;
    vif.drv_cb.wb_adr_i <= '0; vif.drv_cb.wb_sel_i <= '0; vif.drv_cb.wb_dat_i <= '0;
    vif.drv_cb.wb_cti_i <= '0; vif.drv_cb.wb_bte_i <= '0;
  endtask

  task drive_item(wishbone_transaction t);
    begin
      bit [11:0] a = t.adr;
      int unsigned sent = 0, got = 0, to = 0, n = (t.n == 0) ? 1 : t.n;
      bit req, gapped = 0;
      // addresses and CTI of every request; beats past n carry nothing
      t.badr = 0; t.bcti = 0; t.rdat = 0; t.rsp = 0; t.stalls = 0;
      for (int i = 0; i < 8; i++) begin
        if (i >= n) begin t.sel[4 * i +: 4] = 0; t.wdat[32 * i +: 32] = 0; t.bgap[i] = 0; continue; end
        t.badr[12 * i +: 12] = a;
        t.bcti[3 * i +: 3] = (t.mode == WB_CLASSIC || t.mode == WB_SINGLES) ? 3'b000 :
                             (i == n - 1) ? 3'b111 : (t.mode == WB_CONST) ? 3'b001 : 3'b010;
        if (t.inj == WB_INJ_ADDR && i == t.inj_at && i != 0) t.badr[12 * i +: 12] = a + 12'h40;
        if (t.inj == WB_INJ_CTI && i == t.inj_at) t.bcti[3 * i +: 3] = 3'b011 + (a[3:2] % 4);
        if (!t.we) begin t.sel[4 * i +: 4] = 4'hF; t.wdat[32 * i +: 32] = 0; end
        a = (t.mode == WB_CONST) ? a : (t.mode == WB_INCR) ? wb_next(a, t.bte) : a + 12'd4;
      end
      if (t.mode != WB_INCR) t.bte = 0;
      t.bgap[0] = 0;
      repeat (t.gap) @(vif.drv_cb);
      vif.drv_cb.wb_cyc_i <= 1'b1;
      while ((sent < n || got < sent) && to < cfg.timeout_cycles && !(t.abort_at != 0 && sent >= t.abort_at)) begin
        req = (sent < n);
        if (req && t.bgap[sent] && !gapped) begin req = 0; gapped = 1; end   // one idle clock before this request
        vif.drv_cb.wb_stb_i <= req;
        if (req) begin
          vif.drv_cb.wb_we_i <= t.we; vif.drv_cb.wb_adr_i <= {20'h0, t.badr[12 * sent +: 12]};
          vif.drv_cb.wb_sel_i <= t.sel[4 * sent +: 4]; vif.drv_cb.wb_dat_i <= t.wdat[32 * sent +: 32];
          vif.drv_cb.wb_cti_i <= t.bcti[3 * sent +: 3]; vif.drv_cb.wb_bte_i <= t.bte;
        end
        @(vif.drv_cb); to++;
        if (vif.drv_cb.wb_ack_o === 1'b1 || vif.drv_cb.wb_err_o === 1'b1 || vif.drv_cb.wb_rty_o === 1'b1) begin
          t.rsp[2 * got +: 2] = vif.drv_cb.wb_ack_o ? 2'd0 : vif.drv_cb.wb_err_o ? 2'd1 : 2'd2;
          t.rdat[32 * got +: 32] = vif.drv_cb.wb_dat_o;
          got++;
        end
        if (req) begin
          if (vif.drv_cb.wb_stall_o === 1'b0) begin sent++; gapped = 0; end
          else t.stalls++;
        end
      end
      if (to >= cfg.timeout_cycles) `uvm_error("TIMEOUT", "Wishbone: bus cycle did not complete")
      for (int i = got; i < 8; i++) t.rsp[2 * i +: 2] = (i < sent) ? 2'd3 : 2'd0;
      t.nrsp = got;
      // an aborted cycle carries only the requests that went out
      for (int i = sent; i < 8; i++) begin
        t.badr[12 * i +: 12] = 0; t.bcti[3 * i +: 3] = 0; t.sel[4 * i +: 4] = 0; t.wdat[32 * i +: 32] = 0;
      end
      t.n = sent;
      vif.drv_cb.wb_stb_i <= 1'b0; vif.drv_cb.wb_cyc_i <= 1'b0;
      @(vif.drv_cb);
    end
  endtask

endclass
