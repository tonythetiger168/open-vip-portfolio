// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_driver.svh -- Wishbone driver: classic single-read / single-write cycles, waits for ACK

class wishbone_driver extends uvm_driver #(wishbone_transaction);
  `uvm_component_utils(wishbone_driver)

  uvm_analysis_port #(wishbone_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual wishbone_if vif;
  wishbone_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual wishbone_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "wishbone: virtual interface not set")
    if (!uvm_config_db#(wishbone_config)::get(this, "", "cfg", cfg))
      cfg = wishbone_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wishbone_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.wb_cyc_i <= 1'b0;
    vif.drv_cb.wb_stb_i <= 1'b0;
    vif.drv_cb.wb_we_i  <= 1'b0;
    vif.drv_cb.wb_adr_i <= '0;
    vif.drv_cb.wb_dat_i <= '0;
  endtask

  task drive_item(wishbone_transaction t);
    @(vif.drv_cb);
    vif.drv_cb.wb_cyc_i <= 1'b1;
    vif.drv_cb.wb_stb_i <= 1'b1;
    vif.drv_cb.wb_we_i  <= t.we;
    vif.drv_cb.wb_adr_i <= t.adr;
    vif.drv_cb.wb_dat_i <= t.wdat;
    begin
      int unsigned to = 0;
      do begin @(vif.drv_cb); to++; end while (!(vif.drv_cb.wb_ack_o === 1'b1) && to < cfg.timeout_cycles);
      if (!(vif.drv_cb.wb_ack_o === 1'b1)) `uvm_error("TIMEOUT", $sformatf("Wishbone ACK: no response within %0d cycles", cfg.timeout_cycles))
    end
    t.rdat = vif.drv_cb.wb_dat_o;
    vif.drv_cb.wb_cyc_i <= 1'b0;
    vif.drv_cb.wb_stb_i <= 1'b0;
    vif.drv_cb.wb_we_i  <= 1'b0;
  endtask

endclass
