// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_transaction.svh -- Wishbone transaction

class wishbone_transaction extends uvm_sequence_item;
  `uvm_object_utils(wishbone_transaction)

  // request (driven by the agent)
  rand bit we;
  rand bit [31:0] adr;
  rand bit [31:0] wdat;
  // response (returned by the DUT)
  bit [31:0] rdat;
  // bookkeeping (not compared)
  int unsigned wait_cycles;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_adr  { adr[1:0] == 2'b00; adr < 32'h40; }   // 16 word registers
  constraint c_wdat { !we -> wdat == 0; }

  function new(string name = "wishbone_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    wishbone_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    we = rhs_.we;
    adr = rhs_.adr;
    wdat = rhs_.wdat;
    rdat = rhs_.rdat;
    wait_cycles = rhs_.wait_cycles;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    wishbone_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (we != rhs_.we) return 0;
    if (adr != rhs_.adr) return 0;
    if (wdat != rhs_.wdat) return 0;
    if (rdat != rhs_.rdat) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(wishbone_transaction rhs_);
    if (we != rhs_.we) return 0;
    if (adr != rhs_.adr) return 0;
    if (wdat != rhs_.wdat) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("Wishbone{tag=%0d we=0x%0h adr=0x%0h wdat=0x%0h rdat=0x%0h}", tag, we, adr, wdat, rdat);
  endfunction
endclass
