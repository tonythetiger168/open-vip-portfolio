// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_transaction.svh -- Wishbone transaction

class wishbone_transaction extends uvm_sequence_item;
  `uvm_object_utils(wishbone_transaction)

  // request (driven by the agent)
  rand bit we;
  rand bit [3:0] n;
  rand bit [95:0] badr;
  rand bit [23:0] bcti;
  rand bit [31:0] sel;
  rand bit [255:0] wdat;
  // response (returned by the DUT)
  bit [255:0] rdat;
  bit [15:0] rsp;
  bit [3:0] nrsp;
  // bookkeeping (not compared)
  rand wb_mode_e mode;
  rand bit [1:0] bte;
  rand bit [11:0] adr;
  rand bit [2:0] gap;
  rand bit [7:0] bgap;
  rand bit [3:0] abort_at;
  rand wb_inj_e inj;
  rand bit [2:0] inj_at;
  int unsigned stalls;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_n    { n inside {[1:8]}; mode == WB_CLASSIC -> n == 1; mode == WB_SINGLES -> n >= 2; }
  constraint c_mode { mode dist { WB_CLASSIC := 2, WB_CONST := 1, WB_INCR := 4, WB_SINGLES := 2 }; }
  constraint c_adr  { adr[1:0] == 2'b00; adr[11:8] dist { 4'h0 := 6, 4'h1 := 2, 4'h3 := 2, 4'h4 := 1, 4'h8 := 3, 4'hF := 1 };
                      adr[11:8] == 4'h8 -> adr[7:6] == 2'b00; }
  constraint c_ab   { abort_at dist { 0 := 8, [1:8] :/ 1 }; abort_at <= n; }
  constraint c_inj  { inj dist { WB_INJ_NONE := 8, WB_INJ_ADDR := 1, WB_INJ_CTI := 1 }; inj_at < n;
                      (mode == WB_CLASSIC || mode == WB_SINGLES) -> inj != WB_INJ_ADDR; }
  constraint c_gap  { gap dist { 0 := 6, [1:7] :/ 2 }; }

  function new(string name = "wishbone_transaction"); super.new(name); endfunction


  function void do_copy(uvm_object rhs);
    wishbone_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    we = rhs_.we;
    n = rhs_.n;
    mode = rhs_.mode;
    bte = rhs_.bte;
    adr = rhs_.adr;
    badr = rhs_.badr;
    bcti = rhs_.bcti;
    sel = rhs_.sel;
    wdat = rhs_.wdat;
    rdat = rhs_.rdat;
    rsp = rhs_.rsp;
    nrsp = rhs_.nrsp;
    gap = rhs_.gap;
    bgap = rhs_.bgap;
    abort_at = rhs_.abort_at;
    inj = rhs_.inj;
    inj_at = rhs_.inj_at;
    stalls = rhs_.stalls;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    wishbone_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (we != rhs_.we) return 0;
    if (n != rhs_.n) return 0;
    if (badr != rhs_.badr) return 0;
    if (bcti != rhs_.bcti) return 0;
    if (sel != rhs_.sel) return 0;
    if (wdat != rhs_.wdat) return 0;
    if (rdat != rhs_.rdat) return 0;
    if (rsp != rhs_.rsp) return 0;
    if (nrsp != rhs_.nrsp) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(wishbone_transaction rhs_);
    if (we != rhs_.we) return 0;
    if (n != rhs_.n) return 0;
    if (badr != rhs_.badr) return 0;
    if (bcti != rhs_.bcti) return 0;
    if (sel != rhs_.sel) return 0;
    if (wdat != rhs_.wdat) return 0;
    return 1;
  endfunction


  function string convert2string();
    return $sformatf("Wishbone{tag=%0d we=0x%0h n=0x%0h badr=0x%0h bcti=0x%0h sel=0x%0h wdat=0x%0h rdat=0x%0h rsp=0x%0h nrsp=0x%0h}", tag, we, n, badr, bcti, sel, wdat, rdat, rsp, nrsp);
  endfunction
endclass
