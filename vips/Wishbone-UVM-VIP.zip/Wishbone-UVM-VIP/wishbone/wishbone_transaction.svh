// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_transaction.svh -- Wishbone transaction

class wishbone_transaction extends uvm_sequence_item;
  `uvm_object_utils(wishbone_transaction)

  rand bit [31:0] wb_adr_i;
  rand bit [31:0] wb_dat_i;
  rand bit wb_we_i;
  rand bit wb_stb_i;
  rand bit wb_cyc_i;
  bit wb_ack_o_o;
  bit [31:0] wb_dat_o_o;
  bit [31:0] tag;

  function new(string name = "wishbone_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    wishbone_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    wb_adr_i = rhs_.wb_adr_i;
    wb_dat_i = rhs_.wb_dat_i;
    wb_we_i = rhs_.wb_we_i;
    wb_stb_i = rhs_.wb_stb_i;
    wb_cyc_i = rhs_.wb_cyc_i;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    wishbone_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           wb_adr_i == rhs_.wb_adr_i &&
           wb_dat_i == rhs_.wb_dat_i &&
           wb_we_i == rhs_.wb_we_i &&
           wb_stb_i == rhs_.wb_stb_i &&
           wb_cyc_i == rhs_.wb_cyc_i;
  endfunction

  function string convert2string();
    return $sformatf("Wishbone{tag=%0h wb_adr_i=0x%0h wb_dat_i=0x%0h wb_we_i=0x%0h wb_stb_i=0x%0h wb_cyc_i=0x%0h}", tag, wb_adr_i, wb_dat_i, wb_we_i, wb_stb_i, wb_cyc_i);
  endfunction
endclass
