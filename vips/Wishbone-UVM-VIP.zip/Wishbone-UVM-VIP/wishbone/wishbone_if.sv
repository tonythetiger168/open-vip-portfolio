// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_if.sv -- Wishbone interface

interface wishbone_if (input logic clk);
  logic rst_n;

  logic [31:0] wb_adr_i;
  logic [31:0] wb_dat_i;
  logic wb_we_i;
  logic wb_stb_i;
  logic wb_cyc_i;
  logic wb_ack_o;
  logic [31:0] wb_dat_o;

  modport DUT (input clk, rst_n, wb_adr_i, wb_dat_i, wb_we_i, wb_stb_i, wb_cyc_i, output wb_ack_o, wb_dat_o);
  modport DRV (input clk, rst_n, wb_ack_o, wb_dat_o, output wb_adr_i, wb_dat_i, wb_we_i, wb_stb_i, wb_cyc_i);
  modport MON (input clk, rst_n, wb_adr_i, wb_dat_i, wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_dat_o);

  clocking drv_cb @(posedge clk);
    input rst_n, wb_adr_i, wb_dat_i, wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_dat_o;
    output wb_adr_i, wb_dat_i, wb_we_i, wb_stb_i, wb_cyc_i;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, wb_adr_i, wb_dat_i, wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_dat_o;
  endclocking
endinterface
