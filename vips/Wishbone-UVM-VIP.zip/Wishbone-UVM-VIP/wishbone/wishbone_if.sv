// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_if.sv -- Wishbone interface

interface wishbone_if (input logic clk);
  logic rst_n;

  logic wb_cyc_i;
  logic wb_stb_i;
  logic wb_we_i;
  logic [31:0] wb_adr_i;
  logic [3:0] wb_sel_i;
  logic [31:0] wb_dat_i;
  logic [2:0] wb_cti_i;
  logic [1:0] wb_bte_i;
  logic wb_stall_o;
  logic wb_ack_o;
  logic wb_err_o;
  logic wb_rty_o;
  logic [31:0] wb_dat_o;

  modport DUT (input clk, rst_n, input wb_cyc_i, input wb_stb_i, input wb_we_i, input wb_adr_i, input wb_sel_i, input wb_dat_i, input wb_cti_i, input wb_bte_i, output wb_stall_o, output wb_ack_o, output wb_err_o, output wb_rty_o, output wb_dat_o);
  modport MON (input clk, rst_n, wb_cyc_i, wb_stb_i, wb_we_i, wb_adr_i, wb_sel_i, wb_dat_i, wb_cti_i, wb_bte_i, wb_stall_o, wb_ack_o, wb_err_o, wb_rty_o, wb_dat_o);

  clocking drv_cb @(posedge clk);
    input rst_n, wb_stall_o, wb_ack_o, wb_err_o, wb_rty_o, wb_dat_o;
    inout wb_cyc_i, wb_stb_i, wb_we_i, wb_adr_i, wb_sel_i, wb_dat_i, wb_cti_i, wb_bte_i;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, wb_cyc_i, wb_stb_i, wb_we_i, wb_adr_i, wb_sel_i, wb_dat_i, wb_cti_i, wb_bte_i, wb_stall_o, wb_ack_o, wb_err_o, wb_rty_o, wb_dat_o;
  endclocking
endinterface
