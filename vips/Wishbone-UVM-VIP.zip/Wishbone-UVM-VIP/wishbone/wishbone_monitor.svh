// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_monitor.svh -- Wishbone monitor: one item per bus cycle: requests taken on STB without STALL, responses paired in order until CYC drops

class wishbone_monitor extends uvm_monitor;
  `uvm_component_utils(wishbone_monitor)

  virtual wishbone_if vif;
  uvm_analysis_port #(wishbone_transaction) ap;
  wishbone_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual wishbone_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "wishbone: virtual interface not set")
    if (!uvm_config_db#(wishbone_config)::get(this, "", "cfg", cfg))
      cfg = wishbone_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      wishbone_transaction t;
      int unsigned nreq = 0, waits = 0;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rst_n !== 1'b1) begin t = null; nreq = 0; continue; end
        if (vif.mon_cb.wb_cyc_i) begin
          if (t == null) begin t = wishbone_transaction::type_id::create("t"); nreq = 0; waits = 0; end
          if (vif.mon_cb.wb_ack_o || vif.mon_cb.wb_err_o || vif.mon_cb.wb_rty_o) begin
            if (t.nrsp >= nreq) `uvm_error("MON", "Wishbone: response without an outstanding request")
            else begin
              t.rsp[2 * t.nrsp +: 2] = vif.mon_cb.wb_ack_o ? 2'd0 : vif.mon_cb.wb_err_o ? 2'd1 : 2'd2;
              t.rdat[32 * t.nrsp +: 32] = vif.mon_cb.wb_dat_o;
              t.nrsp++;
            end
          end
          if (vif.mon_cb.wb_stb_i) begin
            if (vif.mon_cb.wb_stall_o) waits++;
            else if (nreq < 8) begin
              t.we = vif.mon_cb.wb_we_i;
              t.badr[12 * nreq +: 12] = vif.mon_cb.wb_adr_i[11:0];
              t.bcti[3 * nreq +: 3] = vif.mon_cb.wb_cti_i;
              t.bte = vif.mon_cb.wb_bte_i;
              t.sel[4 * nreq +: 4] = vif.mon_cb.wb_sel_i;
              t.wdat[32 * nreq +: 32] = vif.mon_cb.wb_we_i ? vif.mon_cb.wb_dat_i : 32'h0;
              nreq++;
            end
          end
        end else if (t != null) begin
          t.n = nreq; t.stalls = waits;
          t.adr = t.badr[11:0];
          t.mode = (t.bcti[2:0] == 3'b001) ? WB_CONST : (t.bcti[2:0] == 3'b010) ? WB_INCR :
                   (nreq > 1) ? WB_SINGLES : (t.bcti[2:0] == 3'b111 || t.bcti[2:0] == 3'b000) ? WB_CLASSIC : WB_SINGLES;
          if (t.mode != WB_INCR) t.bte = 0;
          for (int i = t.nrsp; i < 8; i++) t.rsp[2 * i +: 2] = (i < nreq) ? 2'd3 : 2'd0;
          publish(t);
          t = null;
        end
      end
    end
  endtask

  function void publish(wishbone_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
