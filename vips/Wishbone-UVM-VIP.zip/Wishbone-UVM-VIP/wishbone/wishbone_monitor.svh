// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_monitor.svh -- Wishbone monitor: decodes observed bus activity

class wishbone_monitor extends uvm_monitor;
  `uvm_component_utils(wishbone_monitor)

  virtual wishbone_if vif;
  uvm_analysis_port #(wishbone_transaction) ap;
  wishbone_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual wishbone_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "wishbone: virtual interface not set")
    void'(uvm_config_db#(wishbone_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    wishbone_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = wishbone_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.wb_adr_i = vif.wb_adr_i;
        t.wb_dat_i = vif.wb_dat_i;
        t.wb_we_i = vif.wb_we_i;
        t.wb_stb_i = vif.wb_stb_i;
        t.wb_cyc_i = vif.wb_cyc_i;
        t.wb_ack_o_o = vif.wb_ack_o;
        t.wb_dat_o_o = vif.wb_dat_o;
        ap.write(t);
      end
    end
  endtask
endclass
