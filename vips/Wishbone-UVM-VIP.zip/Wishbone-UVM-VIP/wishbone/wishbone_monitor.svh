// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// wishbone_monitor.svh -- Wishbone monitor: one item per ACKed classic cycle

class wishbone_monitor extends uvm_monitor;
  `uvm_component_utils(wishbone_monitor)

  virtual wishbone_if vif;
  uvm_analysis_port #(wishbone_transaction) ap;
  wishbone_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual wishbone_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "wishbone: virtual interface not set")
    if (!uvm_config_db#(wishbone_config)::get(this, "", "cfg", cfg))
      cfg = wishbone_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      int unsigned waits = 0;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.wb_cyc_i && vif.mon_cb.wb_stb_i) begin
          if (vif.mon_cb.wb_ack_o) begin
            wishbone_transaction t = wishbone_transaction::type_id::create("t");
            t.we   = vif.mon_cb.wb_we_i;
            t.adr  = vif.mon_cb.wb_adr_i;
            t.wdat = t.we ? vif.mon_cb.wb_dat_i : 32'h0;
            t.rdat = vif.mon_cb.wb_dat_o;
            t.wait_cycles = waits;
            waits = 0;
            publish(t);
          end else
            waits++;
        end
      end
    end
  endtask

  function void publish(wishbone_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
