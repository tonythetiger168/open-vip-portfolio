# Wishbone UVM VIP (Wishbone-UVM-VIP)

Wishbone B4 classic slave UVM VIP with ACK/data memory model. Complements the Wishbone RTL IP from the open-ip-portfolio sister project.

## Structure

- `wishbone/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `wishbone_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment: scoreboard with a reference model of the DUT (checks
  every monitored transfer; in an active agent also matches the driver's items
  against the monitor's), protocol checker, functional coverage
- `tests/` -- `wishbone_base_test` (constrained-random), `wishbone_func_test` (directed +
  random)
- `tb/top_tb.sv` -- UVM testbench top + behavioural Wishbone DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/Wishbone-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh Wishbone-UVM-VIP` -> `SMOKE_PASS`
- L1d UVM (Verilator + uvm-core): `python3 tools/run_uvm_tests.py Wishbone-UVM-VIP` -> `UVM_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
