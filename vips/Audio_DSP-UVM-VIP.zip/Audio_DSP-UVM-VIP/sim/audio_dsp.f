// Audio_DSP-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+audio_dsp
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/Audio_DSP_top.sv
rtl/Audio_DSP_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
audio_dsp/audio_dsp_pins_if.sv
common/ssv_pkg.sv
audio_dsp/audio_dsp_pkg.sv
tb/top_tb.sv
