# Audio_DSP UVM VIP (Audio_DSP-UVM-VIP)

UVM verification IP for the open-ip-portfolio **Audio_DSP** subsystem: Audio DSP: stereo 16-bit PCM gain, mono downmix and mute with peak and clip meters over AXI4.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`8e9722204875`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 8) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What Audio_DSP does (from the spec)

- One stereo frame per word: left = bits 15:0, right = bits 31:16, signed 16-bit.
- MIX 1: both channels take (L + R) >>> 1 first (17-bit sum, arithmetic shift).
- y = sat16((x * GAIN) >>> 8), GAIN_L / GAIN_R signed Q8.8 (256 = 0 dB); MUTE 1: y = 0.
- PEAK = the largest |y| of the last job; CLIPS = output samples that saturated (saturating).

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `audio_dsp/` -- `audio_dsp_ral.svh` register model (generated from the spec, same
  offsets as `Audio_DSP_apb`), `audio_dsp_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `audio_dsp_pins_if.sv`
- `rtl/` -- `Audio_DSP_apb.sv`, `Audio_DSP_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/audio_dsp.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | SRC_ADDR | rw |
| 0x018 | DST_ADDR | rw |
| 0x01C | LEN | rw |
| 0x020 | GAIN | rw |
| 0x024 | CTRL | rw |
| 0x028 | CMD | cmd |
| 0x02C | STATUS | ro |
| 0x030 | METER | ro |
| 0x034 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR.

## Tests

| Test | Seeds |
|---|---|
| `audio_dsp_ral_test` | 1 |
| `audio_dsp_gain_test` | 3 |
| `audio_dsp_mix_mute_test` | 2 |
| `audio_dsp_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT Audio_DSP mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/audio_dsp.f
./obj_dir/Vtop_tb +UVM_TESTNAME=audio_dsp_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py Audio_DSP-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
