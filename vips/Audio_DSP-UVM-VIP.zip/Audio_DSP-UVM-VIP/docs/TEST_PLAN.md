# Audio_DSP-UVM-VIP test plan

## Register test (`audio_dsp_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `audio_dsp_gain_test`: 32 jobs: gains 0 dB, -6 dB, +6 dB, x0, -1 (phase
  invert), the extremes 0x7FFF and 0x8000, and random; random PCM with full
  scale and near-full-scale frames mixed in so clipping happens both ways;
  lengths 0, 1, 16, 17 and random up to 600 frames; four back-pressure
  settings. Checks every output frame, METER.peak and METER.clips, STATUS,
  DONE / ERR, read / write word counts and windows, AXI ID 8.
- `audio_dsp_mix_mute_test`: mono downmix with equal and different channel
  gains (both channels must come from (L + R) >>> 1, including the odd-sum
  rounding toward minus infinity and L = R = -32768), and mute (output 0,
  peak 0, clips 0, even with gains that would clip).
- `audio_dsp_err_test`: SLVERR in the source (those frames read as 0 and give
  0 out), DECERR in the destination (frames untouched): DONE + ERR,
  STATUS.err; the next clean job clears it.
