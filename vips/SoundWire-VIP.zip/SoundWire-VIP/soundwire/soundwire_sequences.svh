// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_sequences.svh -- SoundWire sequence library

`ifndef SOUNDWIRE_SEQUENCES_SVH
`define SOUNDWIRE_SEQUENCES_SVH

class soundwire_base_sequence extends uvm_sequence #(soundwire_transaction);
  `uvm_object_utils(soundwire_base_sequence)
  int num_txns = 20;
  function new(string name = "soundwire_base_sequence"); super.new(name); endfunction
  task body();
    soundwire_transaction tr;
    repeat (num_txns) begin
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize());
      finish_item(tr);
    end
  endtask
endclass

// Directed: register writes across all valid devices
class soundwire_write_seq extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_write_seq)
  function new(string name = "soundwire_write_seq"); super.new(name); endfunction
  rand bit [3:0] dev = 1;
  constraint c_dev { dev inside {[1:3]}; }
  task body();
    soundwire_transaction tr;
    repeat (num_txns) begin
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SW_WRITE; dev_num == local::dev; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: read-after-write (shadow-map checkable)
class soundwire_read_seq extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_read_seq)
  function new(string name = "soundwire_read_seq"); super.new(name); endfunction
  task body();
    soundwire_transaction tr;
    bit [15:0] addr;
    bit [7:0]  d;
    repeat (num_txns) begin
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SW_WRITE; dev_num == 2; });
      addr = tr.reg_addr; d = tr.data;
      finish_item(tr);
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SW_READ; dev_num == 2;
                                  reg_addr == addr; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: data block transport (2-6 bytes, consecutive addresses)
class soundwire_block_transfer_seq extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_block_transfer_seq)
  function new(string name = "soundwire_block_transfer_seq"); super.new(name); endfunction
  task body();
    soundwire_transaction tr;
    repeat (num_txns) begin
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SW_BLOCK; dev_num inside {[1:3]};
                                  block.size() inside {[2:6]}; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: ping cadence (explicit pings between commands)
class soundwire_ping_seq extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_ping_seq)
  function new(string name = "soundwire_ping_seq"); super.new(name); endfunction
  task body();
    soundwire_transaction tr;
    repeat (num_txns) begin
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SW_WRITE; });
      finish_item(tr);
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SW_PING; });
      finish_item(tr);
    end
  endtask
endclass

// Directed: bus request (BRA) - arm the peripheral, ping, expect grant
class soundwire_bra_seq extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_bra_seq)
  function new(string name = "soundwire_bra_seq"); super.new(name); endfunction
  task body();
    soundwire_transaction tr;
    // arm a bus request on device 2
    tr = soundwire_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { op == SW_WRITE; dev_num == 2;
                                reg_addr == soundwire_defs_pkg::SW_BRA_REG;
                                data == 8'h01; });
    finish_item(tr);
    // pings let the peripheral advertise the request; master grants
    repeat (2) begin
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SW_PING; });
      finish_item(tr);
    end
    // follow-up traffic after the grant
    tr = soundwire_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { op == SW_WRITE; dev_num == 2; });
    finish_item(tr);
  endtask
endclass

// Error injection: commands to a non-existent device number
class soundwire_error_inject_seq extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_error_inject_seq)
  function new(string name = "soundwire_error_inject_seq"); super.new(name); endfunction
  task body();
    soundwire_transaction tr;
    soundwire_op_e ops[$] = '{SW_WRITE, SW_READ, SW_WRITE, SW_READ};
    foreach (ops[i]) begin
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == ops[i]; dev_num == 4'hF; });
      finish_item(tr);
      // valid traffic in between keeps the bus alive
      tr = soundwire_transaction::type_id::create("tr");
      start_item(tr);
      void'(tr.randomize() with { op == SW_WRITE; dev_num inside {[1:3]}; });
      finish_item(tr);
    end
  endtask
endclass

// Reset behavior: single write issued right after reset release
class soundwire_reset_seq extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_reset_seq)
  function new(string name = "soundwire_reset_seq"); super.new(name); endfunction
  task body();
    soundwire_transaction tr = soundwire_transaction::type_id::create("tr");
    start_item(tr);
    void'(tr.randomize() with { op == SW_WRITE; dev_num == 1; data == 8'hA5; });
    finish_item(tr);
  endtask
endclass

class soundwire_random_sequence extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_random_sequence)
  function new(string name = "soundwire_random_sequence"); super.new(name); num_txns = 50; endfunction
endclass

// Regression: weighted mix of all directed sequences
class soundwire_regression_sequence extends soundwire_base_sequence;
  `uvm_object_utils(soundwire_regression_sequence)
  function new(string name = "soundwire_regression_sequence"); super.new(name); endfunction
  task body();
    soundwire_write_seq          wr  = soundwire_write_seq::type_id::create("wr");
    soundwire_read_seq           rd  = soundwire_read_seq::type_id::create("rd");
    soundwire_block_transfer_seq blk = soundwire_block_transfer_seq::type_id::create("blk");
    soundwire_ping_seq           png = soundwire_ping_seq::type_id::create("png");
    soundwire_bra_seq            bra = soundwire_bra_seq::type_id::create("bra");
    soundwire_error_inject_seq   err = soundwire_error_inject_seq::type_id::create("err");
    wr.num_txns = 12; rd.num_txns = 8; blk.num_txns = 8; png.num_txns = 6;
    wr.start(m_sequencer); rd.start(m_sequencer); blk.start(m_sequencer);
    png.start(m_sequencer); bra.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
`endif
