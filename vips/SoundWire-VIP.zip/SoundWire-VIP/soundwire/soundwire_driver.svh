// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_driver.svh -- SoundWire master driver.
// Bit-bangs DDR command frames (sync/dev/opcode/addr/data + slave response
// window), keeps the ping cadence, detects bus requests in status bytes and
// issues BRA grants. Maintains a shadow register map so read expectations
// are true end-to-end predictions.

`ifndef SOUNDWIRE_DRIVER_SVH
`define SOUNDWIRE_DRIVER_SVH

class soundwire_driver extends uvm_driver #(soundwire_transaction);
  `uvm_component_utils(soundwire_driver)
  virtual soundwire_if vif;
  soundwire_config cfg;
  uvm_analysis_port #(soundwire_transaction) drv_ap;  // expected items for scoreboard

  protected int unsigned frame_no = 0;
  protected int unsigned frames_since_ping = 0;
  protected bit          bra_pending = 0;
  protected bit [7:0]    shadow[int];                 // {dev,addr} -> last written data

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual soundwire_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "soundwire virtual interface not set")
  endfunction

  // ---- DDR bit drive: even bits on posedge, odd bits on negedge ----
  // Bus state changes exactly on the first bit of a frame.
  soundwire_state_e next_state = soundwire_defs_pkg::IDLE;
  task drive_bit(bit b, bit oe, int unsigned bidx);
    if (bidx % 2 == 0) @(posedge vif.clk); else @(negedge vif.clk);
    vif.data_o      <= b;
    vif.data_oe     <= oe;
    vif.bit_cnt     <= bidx[5:0];
    vif.frame_start <= (bidx <= 1);
    if (bidx == 0) vif.state <= next_state;
  endtask

  // One 48-bit DDR frame + 2 idle edges (50-edge period, frames start on
  // the posedge). Returns the slave response-window byte.
  task send_frame(bit [47:0] f, output bit [7:0] resp);
    frame_no++;
    vif.frame_no <= frame_no[15:0];
    frames_since_ping++;
    for (int k = 0; k < 40; k++) drive_bit(f[47-k], 1'b1, k);
    drive_bit(1'b1, 1'b0, 40);                       // release DATA
    resp = 8'h00;
    for (int i = 7; i >= 0; i--) begin
      @(vif.clk);                                    // edges 41..48
      resp[i] = vif.data_i;
      if (i > 0) begin
        vif.data_oe     <= 1'b0;
        vif.bit_cnt     <= 41 + (7 - i);
        vif.frame_start <= 1'b0;
      end
    end
    @(vif.clk);                                      // inter-frame idle edge
    vif.data_oe <= 1'b0;
  endtask

  function bit [47:0] pack_frame(bit [3:0] opc, bit [3:0] dev,
                                 bit [15:0] addr, bit [7:0] dbyte);
    return {soundwire_defs_pkg::SW_SYNC, dev, opc, addr, dbyte, 8'h00};
  endfunction

  task set_state(soundwire_state_e s);
    next_state = s;   // applied at the next frame's first bit
  endtask

  // Bus-request detection in a slave status byte (bit0 pulled low)
  task watch_bra(bit [7:0] resp);
    if (resp !== soundwire_defs_pkg::SW_NO_RESP && resp[0] == 1'b0 && !bra_pending) begin
      bra_pending = 1;
      vif.bra_req <= 1'b1;
      `uvm_info("DRV", "bus request (BRA) detected in status", UVM_HIGH)
    end
  endtask

  task do_ping();
    bit [7:0] resp;
    soundwire_transaction p = soundwire_transaction::type_id::create("ping_exp");
    set_state(soundwire_defs_pkg::PING);
    send_frame(pack_frame(soundwire_defs_pkg::SWC_PING, 4'h0, 16'h0, 8'h0), resp);
    vif.last_ping_frame <= frame_no[15:0];
    frames_since_ping = 0;
    p.op = soundwire_defs_pkg::SW_PING; p.dev_num = 0; p.resp = resp;
    drv_ap.write(p);
    watch_bra(resp);
  endtask

  task do_grant();
    bit [7:0] resp;
    soundwire_transaction g = soundwire_transaction::type_id::create("bra_exp");
    set_state(soundwire_defs_pkg::BRA);
    vif.bra_grant <= 1'b1;
    vif.grant_dev <= 4'h0;                            // broadcast grant
    send_frame(pack_frame(soundwire_defs_pkg::SWC_BRA_GRANT, 4'h0, 16'h0, 8'h0), resp);
    vif.bra_grant <= 1'b0;
    vif.bra_req   <= 1'b0;
    bra_pending = 0;
    g.op = soundwire_defs_pkg::SW_BRA; g.dev_num = 0;
    drv_ap.write(g);
  endtask

  function int shadow_key(bit [3:0] dev, bit [15:0] addr);
    return int'(dev) * 65536 + int'(addr);
  endfunction

  task run_phase(uvm_phase phase);
    soundwire_transaction tr;
    bit [7:0] resp;
    vif.data_oe <= 1'b0;
    vif.state <= soundwire_defs_pkg::IDLE;
    vif.bit_cnt <= 0; vif.frame_start <= 0;
    vif.frame_no <= 0; vif.last_ping_frame <= 0;
    vif.bra_req <= 0; vif.bra_grant <= 0; vif.grant_dev <= 0;
    wait (vif.rst_n === 1'b1);
    @(posedge vif.clk);                      // frames start on the posedge
    forever begin
      seq_item_port.get_next_item(tr);
      `uvm_info("DRV", {"drive: ", tr.convert2string()}, UVM_HIGH)
      case (tr.op)
        soundwire_defs_pkg::SW_WRITE: begin
          set_state(soundwire_defs_pkg::COMMAND);
          send_frame(pack_frame(soundwire_defs_pkg::SWC_WRITE, tr.dev_num,
                                tr.reg_addr, tr.data), resp);
          tr.resp = resp;
          if (tr.is_bad_dev()) begin
            if (resp === soundwire_defs_pkg::SW_NO_RESP)
              `uvm_warning("DRV", $sformatf("no response from dev 0x%01h", tr.dev_num))
          end else begin
            shadow[shadow_key(tr.dev_num, tr.reg_addr)] = tr.data;
            watch_bra(resp);
          end
        end
        soundwire_defs_pkg::SW_READ: begin
          set_state(soundwire_defs_pkg::COMMAND);
          send_frame(pack_frame(soundwire_defs_pkg::SWC_READ, tr.dev_num,
                                tr.reg_addr, 8'h00), resp);
          tr.resp = resp;
          if (tr.is_bad_dev()) begin
            if (resp === soundwire_defs_pkg::SW_NO_RESP)
              `uvm_warning("DRV", $sformatf("no response from dev 0x%01h", tr.dev_num))
          end else begin
            // end-to-end read prediction from the shadow register map
            tr.data = shadow.exists(shadow_key(tr.dev_num, tr.reg_addr)) ?
                      shadow[shadow_key(tr.dev_num, tr.reg_addr)] : 8'h00;
          end
        end
        soundwire_defs_pkg::SW_PING: begin
          set_state(soundwire_defs_pkg::PING);
          send_frame(pack_frame(soundwire_defs_pkg::SWC_PING, 4'h0, 16'h0, 8'h0), resp);
          vif.last_ping_frame <= frame_no[15:0];
          frames_since_ping = 0;
          tr.dev_num = 0;
          tr.resp = resp;
          watch_bra(resp);
        end
        soundwire_defs_pkg::SW_BLOCK: begin
          set_state(soundwire_defs_pkg::DATA_BLOCK);
          foreach (tr.block[i]) begin
            send_frame(pack_frame(i == 0 ? soundwire_defs_pkg::SWC_BLOCK_FIRST
                                         : soundwire_defs_pkg::SWC_BLOCK,
                                  tr.dev_num, tr.reg_addr + i[15:0], tr.block[i]), resp);
            if (!tr.is_bad_dev()) begin
              shadow[shadow_key(tr.dev_num, tr.reg_addr + i[15:0])] = tr.block[i];
              watch_bra(resp);
            end
          end
          tr.resp = resp;
        end
        // REACHABILITY: sequences may now request a BRA grant directly; drive a
        // real grant frame (dev 0 broadcast) so the monitor decodes op=SW_BRA
        // and the expected transaction matches the observed frame.
        soundwire_defs_pkg::SW_BRA: begin
          set_state(soundwire_defs_pkg::BRA);
          vif.bra_grant <= 1'b1;
          vif.grant_dev <= 4'h0;
          send_frame(pack_frame(soundwire_defs_pkg::SWC_BRA_GRANT, 4'h0, 16'h0, 8'h0), resp);
          vif.bra_grant <= 1'b0;
          vif.bra_req   <= 1'b0;
          bra_pending = 0;
          tr.dev_num  = 0;
          tr.reg_addr = 16'h0;
          tr.data     = 8'h0;
          tr.resp     = resp;
        end
        default: ;
      endcase
      drv_ap.write(tr);                      // broadcast expected transaction
      if (tr.op == soundwire_defs_pkg::SW_BLOCK) do_ping();  // block delimiter
      if (bra_pending) do_grant();
      if (frames_since_ping >= 7) do_ping();
      if (bra_pending) do_grant();
      seq_item_port.item_done();
    end
  endtask
endclass
`endif
