// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_transaction.svh -- SoundWire transaction (command frame /
// ping / data block transport / bus-request acknowledge)

`ifndef SOUNDWIRE_TRANSACTION_SVH
`define SOUNDWIRE_TRANSACTION_SVH

class soundwire_transaction extends uvm_sequence_item;

  rand soundwire_op_e op;
  rand bit [3:0]  dev_num;      // device number (1..SW_NUM_DEV valid, 0 broadcast)
  rand bit [15:0] reg_addr;     // register address
  rand bit [7:0]  data;         // write data / (expected) read data
  rand bit [7:0]  block[$];     // SW_BLOCK payload bytes (consecutive addresses)

  // Observed fields (filled by driver expectation / monitor decode)
  bit [7:0]        resp;        // response-window byte (status / rdata)
  bit              no_resp;     // monitor: no device responded (0xFF window)
  soundwire_state_e fsm_state;  // monitor: bus state when observed

  // REACHABILITY: SW_BRA grants may now be requested directly by sequences
  // (driver drives a real grant frame), so include it in the op domain with a
  // low weight; this makes cg_protocol cp_op.bra generatable.
  constraint c_op    { op dist { SW_WRITE := 3, SW_READ := 2, SW_BLOCK := 2,
                                 SW_PING := 1, SW_BRA := 1 }; }
  // dev_num 0 (broadcast) is intentionally not randomized here: it appears on
  // the bus for ping and BRA-grant frames (driver forces dev 0), which the
  // monitor decodes, so cg_protocol cp_dev.bcast is still hit.
  constraint c_dev   { dev_num dist {[4'h1 : 4'h3] := 9, 4'hF := 1}; }
  constraint c_block { op == SW_BLOCK -> block.size() inside {[2:6]};
                       op != SW_BLOCK -> block.size() == 0; }
  constraint c_bra_reg { soft reg_addr != soundwire_defs_pkg::SW_BRA_REG; }

  `uvm_object_utils_begin(soundwire_transaction)
    `uvm_field_enum(soundwire_op_e, op, UVM_ALL_ON)
    `uvm_field_int(dev_num, UVM_ALL_ON)
    `uvm_field_int(reg_addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_queue_int(block, UVM_ALL_ON)
    `uvm_field_int(resp, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_int(no_resp, UVM_ALL_ON | UVM_NOCOMPARE)
    `uvm_field_enum(soundwire_state_e, fsm_state, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  function new(string name = "soundwire_transaction");
    super.new(name);
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    soundwire_transaction t;
    bit ok = super.do_compare(rhs, comparer);
    if (!$cast(t, rhs)) return 1'b0;
    if (op == SW_BLOCK)
      ok &= comparer.compare_field("block_size", block.size(), t.block.size(), 32);
    return ok;
  endfunction

  function bit is_bad_dev();
    return dev_num > soundwire_defs_pkg::SW_NUM_DEV;
  endfunction

  function string convert2string();
    string s = $sformatf("SoundWire %s dev=0x%01h addr=0x%04h data=0x%02h",
                         op.name(), dev_num, reg_addr, data);
    if (op == SW_BLOCK) s = $sformatf("SoundWire BLOCK dev=0x%01h addr=0x%04h len=%0d",
                                      dev_num, reg_addr, block.size());
    if (no_resp) s = {s, " [NO_RESP]"};
    return s;
  endfunction
endclass
`endif
