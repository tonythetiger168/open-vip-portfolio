// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_if.sv -- SoundWire interface (CLK + DDR DATA, master/slave modports)
//
// DATA is double-data-rate: two bits per bus clock. The master drives bits
// 0-39 of each 48-bit frame; slaves drive the response window (bits 40-47).
// DATA is resolved wired-AND so multiple peripherals can share the line.

interface soundwire_if (input logic clk);
  import soundwire_defs_pkg::soundwire_state_e;

  logic rst_n;

  // Master drive
  logic data_o;
  logic data_oe;
  logic data_i;

  // Slave (peripheral DUT) drive - aggregated wired-AND in the testbench
  logic slv_data_o;
  logic slv_data_oe;

  soundwire_state_e state;

  // Protocol bookkeeping (driven by master, used by monitor/SVA/coverage)
  logic [5:0]  bit_cnt;          // bit index within the 48-bit frame
  logic        frame_start;      // high during the first bits of a frame
  logic [15:0] frame_no;         // running frame counter
  logic [15:0] last_ping_frame;  // frame_no of the most recent ping
  logic        bra_req;          // a peripheral requested the bus
  logic        bra_grant;        // master grants the bus (BRA frame)
  logic [3:0]  grant_dev;        // grant target (0 = broadcast)

  assign data_i = (data_oe     ? data_o     : 1'b1) &
                  (slv_data_oe ? slv_data_o : 1'b1);

  modport MASTER (input  clk, rst_n, data_i,
                  output data_o, data_oe, state, bit_cnt, frame_start,
                         frame_no, last_ping_frame, bra_req, bra_grant, grant_dev);
  modport SLAVE  (input  clk, rst_n, data_i,
                  output slv_data_o, slv_data_oe);
  modport MON    (input  clk, rst_n, data_i, state, bit_cnt, frame_start,
                         frame_no, last_ping_frame, bra_req, bra_grant, grant_dev);

  // Master launches on both edges; drv_cb is the posedge launch view.
  clocking drv_cb @(posedge clk);
    input  rst_n, data_i;
    output data_o, data_oe;
  endclocking

  // Monitor samples every edge (raw events); mon_cb is the posedge view.
  clocking mon_cb @(posedge clk);
    input rst_n, data_i, state, bit_cnt, frame_start,
          frame_no, last_ping_frame, bra_req, bra_grant, grant_dev;
  endclocking
endinterface
