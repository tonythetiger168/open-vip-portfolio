// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_reg_adapter.svh -- UVM RAL adapter for the SoundWire manager agent
//   reg2bus: UVM_WRITE -> SW_WRITE command frame, UVM_READ -> SW_READ command
//            frame, to peripheral dev_num (16-bit register address)
//   bus2reg: soundwire_transaction (driver-completed or monitor-observed) -> uvm_reg_bus_op
// The driver writes the response-window byte (resp) back into the request item
// and sends no separate response, so provides_responses = 0. For a read, resp
// is the register value; a write is UVM_IS_OK only when the peripheral answered
// with a write status (SW_STS_WRITE / SW_STS_WRITE_BRA). An undriven window
// reads 0xFF, the same as a register holding 0xFF, so a read is always
// UVM_IS_OK for the mapped device.

`ifndef SOUNDWIRE_REG_ADAPTER_SVH
`define SOUNDWIRE_REG_ADAPTER_SVH

class soundwire_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(soundwire_reg_adapter)

  bit [3:0] dev_num = 4'h1;   // peripheral the register model maps

  function new(string name = "soundwire_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 0;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    soundwire_transaction tr = soundwire_transaction::type_id::create("ral_item");
    tr.op       = (rw.kind == UVM_WRITE) ? soundwire_defs_pkg::SW_WRITE : soundwire_defs_pkg::SW_READ;
    tr.dev_num  = dev_num;
    tr.reg_addr = rw.addr[15:0];
    tr.data     = (rw.kind == UVM_WRITE) ? rw.data[7:0] : 8'h00;
    tr.block.delete();
    return tr;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    soundwire_transaction tr;
    bit wr, rd;
    if (!$cast(tr, bus_item)) begin
      `uvm_fatal("SW_RAL", "bus2reg: item is not a soundwire_transaction")
      return;
    end
    wr         = (tr.op == soundwire_defs_pkg::SW_WRITE);
    rd         = (tr.op == soundwire_defs_pkg::SW_READ);
    rw.kind    = wr ? UVM_WRITE : UVM_READ;
    rw.addr    = tr.reg_addr;
    rw.data    = wr ? tr.data : tr.resp;
    rw.n_bits  = 8;
    rw.byte_en = '1;
    rw.status  = ((wr && tr.resp inside {soundwire_defs_pkg::SW_STS_WRITE,
                                         soundwire_defs_pkg::SW_STS_WRITE_BRA}) || rd) &&
                 tr.dev_num == dev_num ? UVM_IS_OK : UVM_NOT_OK;
    // pings, grants, blocks, other devices and unanswered writes: unmapped,
    // the predictor skips them
    if (rw.status != UVM_IS_OK) rw.addr = 'h1_0000;
  endfunction
endclass
`endif
