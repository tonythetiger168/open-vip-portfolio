// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_coverage.svh -- SoundWire functional coverage

`ifndef SOUNDWIRE_COVERAGE_SVH
`define SOUNDWIRE_COVERAGE_SVH

class soundwire_coverage extends uvm_subscriber #(soundwire_transaction);
  `uvm_component_utils(soundwire_coverage)

  soundwire_transaction tr;

  covergroup cg_protocol;
    cp_op : coverpoint tr.op {
      bins wr   = {soundwire_defs_pkg::SW_WRITE};
      bins rd   = {soundwire_defs_pkg::SW_READ};
      bins ping = {soundwire_defs_pkg::SW_PING};
      bins blk  = {soundwire_defs_pkg::SW_BLOCK};
      bins bra  = {soundwire_defs_pkg::SW_BRA};
    }
    cp_dev : coverpoint tr.dev_num {
      bins dev1 = {1}; bins dev2 = {2}; bins dev3 = {3};
      bins bcast = {0};
      bins bad   = {4'hF};
    }
    cp_addr : coverpoint tr.reg_addr {
      bins low     = {[16'h0000 : 16'h00EF]};
      bins bra_reg = {soundwire_defs_pkg::SW_BRA_REG};
      bins high    = {[16'h0100 : 16'hFFFF]};
    }
    cp_data : coverpoint tr.data {
      bins zero = {8'h00};
      bins ones = {8'hFF};
      bins walk = {[8'h01 : 8'hFE]};
    }
    cp_blk_len : coverpoint tr.block.size() iff (tr.op == soundwire_defs_pkg::SW_BLOCK) {
      bins len[] = {[2:6]};
    }
    cx_op_dev : cross cp_op, cp_dev;
  endgroup

  covergroup cg_fsm with function sample(soundwire_state_e s);
    cp_state : coverpoint s {
      bins all_states[] = {soundwire_defs_pkg::IDLE, soundwire_defs_pkg::COMMAND,
                           soundwire_defs_pkg::PING, soundwire_defs_pkg::DATA_BLOCK,
                           soundwire_defs_pkg::BRA};
    }
    cp_trans : coverpoint s {
      bins cmd_blk  = (soundwire_defs_pkg::COMMAND => soundwire_defs_pkg::DATA_BLOCK);
      bins blk_ping = (soundwire_defs_pkg::DATA_BLOCK => soundwire_defs_pkg::PING);
      bins cmd_bra  = (soundwire_defs_pkg::COMMAND => soundwire_defs_pkg::BRA);
      bins ping_bra = (soundwire_defs_pkg::PING => soundwire_defs_pkg::BRA);
    }
  endgroup

  covergroup cg_error;
    cp_no_resp : coverpoint tr.no_resp { bins resp = {0}; bins none = {1}; }
    cp_bra_req : coverpoint tr.resp[0] iff
      (tr.op == soundwire_defs_pkg::SW_WRITE || tr.op == soundwire_defs_pkg::SW_PING) {
      bins idle    = {1};
      bins request = {0};
    }
    cp_bad_dev : coverpoint (tr.dev_num > soundwire_defs_pkg::SW_NUM_DEV
                             && tr.dev_num != 0) {
      bins good = {0}; bins bad = {1};
    }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_protocol = new();
    cg_fsm      = new();
    cg_error    = new();
  endfunction

  function void write(soundwire_transaction t);
    tr = t;
    cg_protocol.sample();
    cg_fsm.sample(t.fsm_state);
    cg_error.sample();
  endfunction
endclass
`endif
