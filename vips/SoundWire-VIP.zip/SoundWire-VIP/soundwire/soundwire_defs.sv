// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_defs.sv -- SoundWire shared type definitions and protocol constants

package soundwire_defs_pkg;
  // Bus-level FSM (driven by the master, observed by monitor/SVA)
  typedef enum bit [2:0] {
    IDLE,
    COMMAND,
    PING,
    DATA_BLOCK,
    BRA
  } soundwire_state_e;

  // Transaction-level operations
  typedef enum bit [2:0] {
    SW_WRITE,   // register write command frame
    SW_READ,    // register read command frame (response carries rdata)
    SW_PING,    // ping frame (broadcast status query)
    SW_BLOCK,   // data block transport (multiple BLOCK frames)
    SW_BRA      // bus-request acknowledge (grant)
  } soundwire_op_e;

  // DDR frame: 48 bits (2 bits per clock, 25 clocks incl. inter-frame gap)
  //   bits  0- 7 : sync (SW_SYNC)
  //   bits  8-11 : device number (0 = broadcast)
  //   bits 12-15 : opcode (SWC_*)
  //   bits 16-31 : register address
  //   bits 32-39 : write data / block byte
  //   bits 40-47 : response window (slave driven)
  localparam int        SW_FRAME_BITS = 48;
  localparam bit [7:0]  SW_SYNC       = 8'hC7;
  localparam int        SW_NUM_DEV    = 3;        // devices 1..3 exist on the bus
  localparam bit [15:0] SW_BRA_REG    = 16'h00F0; // write 0x01 to arm a bus request

  localparam bit [3:0]  SWC_WRITE       = 4'h1;
  localparam bit [3:0]  SWC_READ        = 4'h2;
  localparam bit [3:0]  SWC_PING        = 4'h3;
  localparam bit [3:0]  SWC_BLOCK       = 4'h4;
  localparam bit [3:0]  SWC_BRA_GRANT   = 4'h5;
  localparam bit [3:0]  SWC_BLOCK_FIRST = 4'h6;

  // Slave status bytes (bit0 is an active-high "no request" flag; a
  // requesting slave pulls it low so wired-AND aggregation works on ping)
  localparam bit [7:0]  SW_STS_PING     = 8'h5B;  // ping status, no request
  localparam bit [7:0]  SW_STS_PING_BRA = 8'h5A;  // ping status, bus request
  localparam bit [7:0]  SW_STS_WRITE    = 8'hAB;  // write ACK, no request
  localparam bit [7:0]  SW_STS_WRITE_BRA= 8'hAA;  // write ACK + bus request
  localparam bit [7:0]  SW_NO_RESP      = 8'hFF;  // no device responded
endpackage
