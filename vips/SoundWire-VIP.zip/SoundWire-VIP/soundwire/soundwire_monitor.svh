// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_monitor.svh -- SoundWire monitor: hunts the sync pattern on the
// DDR DATA line, decodes command frames (dev/opcode/addr/data + response
// window), groups BLOCK frames into data-block transfers and publishes
// reconstructed transactions.

`ifndef SOUNDWIRE_MONITOR_SVH
`define SOUNDWIRE_MONITOR_SVH

class soundwire_monitor extends uvm_monitor;
  `uvm_component_utils(soundwire_monitor)
  virtual soundwire_if vif;
  uvm_analysis_port #(soundwire_transaction) ap;
  int unsigned txn_count = 0;
  int unsigned no_resp_count = 0;

  protected soundwire_transaction cur_block = null;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual soundwire_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "soundwire virtual interface not set")
  endfunction

  function soundwire_op_e map_op(bit [3:0] opc);
    case (opc)
      soundwire_defs_pkg::SWC_WRITE:       return soundwire_defs_pkg::SW_WRITE;
      soundwire_defs_pkg::SWC_READ:        return soundwire_defs_pkg::SW_READ;
      soundwire_defs_pkg::SWC_PING:        return soundwire_defs_pkg::SW_PING;
      soundwire_defs_pkg::SWC_BLOCK:       return soundwire_defs_pkg::SW_BLOCK;
      soundwire_defs_pkg::SWC_BLOCK_FIRST: return soundwire_defs_pkg::SW_BLOCK;
      soundwire_defs_pkg::SWC_BRA_GRANT:   return soundwire_defs_pkg::SW_BRA;
      default:                             return soundwire_defs_pkg::SW_PING;
    endcase
  endfunction

  task flush_block();
    if (cur_block != null) begin
      txn_count++;
      `uvm_info("MON", {"mon: ", cur_block.convert2string()}, UVM_HIGH)
      ap.write(cur_block);
      cur_block = null;
    end
  endtask

  task run_phase(uvm_phase phase);
    bit [7:0]  w = 0, resp;
    bit [31:0] hdr;
    bit [3:0]  dev, opc;
    bit [15:0] addr;
    bit [7:0]  dat;
    soundwire_transaction tr;
    forever begin
      @(vif.clk);                        // sample every edge (DDR)
      if (!vif.rst_n) continue;
      // ---- sync hunt ----
      w = {w[6:0], vif.data_i};
      if (w !== soundwire_defs_pkg::SW_SYNC) continue;

      // ---- decode 32 header bits + 8 response bits ----
      for (int i = 31; i >= 0; i--) begin @(vif.clk); hdr[i] = vif.data_i; end
      for (int i = 7; i >= 0; i--) begin @(vif.clk); resp[i] = vif.data_i; end
      w = 8'h00;   // clear the hunt window: next sync starts after this frame
      dev  = hdr[31:28];
      opc  = hdr[27:24];
      addr = hdr[23:8];
      dat  = hdr[7:0];

      // ---- data block grouping ----
      if (opc == soundwire_defs_pkg::SWC_BLOCK_FIRST) begin
        flush_block();
        cur_block = soundwire_transaction::type_id::create("tr");
        cur_block.op        = soundwire_defs_pkg::SW_BLOCK;
        cur_block.dev_num   = dev;
        cur_block.reg_addr  = addr;
        cur_block.resp      = resp;
        cur_block.no_resp   = (resp === soundwire_defs_pkg::SW_NO_RESP);
        cur_block.fsm_state = vif.state;
        cur_block.block.push_back(dat);
        continue;
      end
      if (opc == soundwire_defs_pkg::SWC_BLOCK && cur_block != null) begin
        cur_block.block.push_back(dat);
        cur_block.resp = resp;
        continue;
      end
      flush_block();                     // any non-BLOCK frame ends the block

      tr = soundwire_transaction::type_id::create("tr");
      tr.op        = map_op(opc);
      tr.dev_num   = dev;
      tr.reg_addr  = addr;
      tr.data      = dat;
      tr.resp      = resp;
      tr.no_resp   = (resp === soundwire_defs_pkg::SW_NO_RESP);
      tr.fsm_state = vif.state;
      if (tr.op == soundwire_defs_pkg::SW_READ) tr.data = resp;   // rdata
      if (tr.no_resp) no_resp_count++;
      txn_count++;
      `uvm_info("MON", {"mon: ", tr.convert2string()}, UVM_HIGH)
      ap.write(tr);
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MON", $sformatf("soundwire monitor observed %0d transactions, %0d no-response",
              txn_count, no_resp_count), UVM_LOW)
  endfunction
endclass
`endif
