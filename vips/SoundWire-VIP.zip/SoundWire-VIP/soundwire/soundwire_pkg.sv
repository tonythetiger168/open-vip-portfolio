// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// soundwire_pkg.sv -- MIPI SoundWire UVM VIP package

package soundwire_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import soundwire_defs_pkg::*;
  export soundwire_defs_pkg::*;

  `include "soundwire_transaction.svh"
  `include "soundwire_config.svh"
  `include "soundwire_sequencer.svh"
  `include "soundwire_driver.svh"
  `include "soundwire_monitor.svh"
  `include "soundwire_agent.svh"
  `include "soundwire_sequences.svh"
  `include "soundwire_checker.svh"
  `include "soundwire_coverage.svh"
endpackage
