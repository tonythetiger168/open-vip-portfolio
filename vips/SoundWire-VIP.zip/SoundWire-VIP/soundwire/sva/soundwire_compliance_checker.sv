// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_compliance_checker.sv -- SoundWire SVA compliance checker
// L1 = signal sanity, L2 = FSM legality, L3 = protocol rules,
// L4 = SoundWire protocol-specific rules (command frame format, ping
//      period, data block alignment, BRA grant)

`ifndef SOUNDWIRE_COMPLIANCE_CHECKER_SV
`define SOUNDWIRE_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import soundwire_defs_pkg::*;

module soundwire_compliance_checker
(
  input logic             clk,
  input logic             rst_n,
  input soundwire_state_e state,
  input logic             data_i,
  input logic [5:0]       bit_cnt,
  input logic             frame_start,
  input logic [15:0]      frame_no,
  input logic [15:0]      last_ping_frame,
  input logic             bra_req,
  input logic             bra_grant,
  input logic [3:0]       grant_dev
);

  // DDR shift register: at any edge it holds the previous 8 driven bits.
  bit [7:0] sr = 0;
  always @(posedge clk or negedge clk) begin
    if (!rst_n) sr <= 0;
    else        sr <= {sr[6:0], data_i};
  end

  // ---------------- L1: signal sanity (4) ----------------
  a_soundwire_l1_clk   : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(clk))
    else `uvm_error("SVA_L1", "soundwire: clock unknown")
  a_soundwire_l1_rst   : assert property (@(posedge clk) !$isunknown(rst_n))
    else `uvm_error("SVA_L1", "soundwire: reset unknown")
  a_soundwire_l1_state : assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(state))
    else `uvm_error("SVA_L1", "soundwire: state unknown")
  a_soundwire_l1_valid : assert property (@(posedge clk) disable iff (!rst_n)
    state inside {IDLE, COMMAND, PING, DATA_BLOCK, BRA})
    else `uvm_error("SVA_L1", "soundwire: state outside legal encoding")

  // ---------------- L2: FSM legality (6) ----------------
  // L2-1: legal FSM transition from IDLE
  a_soundwire_trans_idle : assert property (@(posedge clk) disable iff (!rst_n)
    state == IDLE |=> state inside {IDLE, COMMAND, PING, DATA_BLOCK})
    else `uvm_error("SVA_L2", "soundwire: illegal transition from IDLE")
  // L2-2: legal FSM transition from COMMAND
  a_soundwire_trans_command : assert property (@(posedge clk) disable iff (!rst_n)
    state == COMMAND |=> state inside {COMMAND, PING, DATA_BLOCK, BRA, IDLE})
    else `uvm_error("SVA_L2", "soundwire: illegal transition from COMMAND")
  // L2-3: legal FSM transition from PING
  a_soundwire_trans_ping : assert property (@(posedge clk) disable iff (!rst_n)
    state == PING |=> state inside {PING, COMMAND, DATA_BLOCK, BRA, IDLE})
    else `uvm_error("SVA_L2", "soundwire: illegal transition from PING")
  // L2-4: legal FSM transition from DATA_BLOCK (terminated by ping delimiter)
  a_soundwire_trans_data_block : assert property (@(posedge clk) disable iff (!rst_n)
    state == DATA_BLOCK |=> state inside {DATA_BLOCK, PING, IDLE})
    else `uvm_error("SVA_L2", "soundwire: illegal transition from DATA_BLOCK")
  // L2-5: legal FSM transition from BRA
  a_soundwire_trans_bra : assert property (@(posedge clk) disable iff (!rst_n)
    state == BRA |=> state inside {COMMAND, PING, IDLE})
    else `uvm_error("SVA_L2", "soundwire: illegal transition from BRA")
  // L2-6: state may only change on a frame boundary
  a_soundwire_trans_aligned : assert property (@(posedge clk) disable iff (!rst_n)
    $changed(state) |-> frame_start)
    else `uvm_error("SVA_L2", "soundwire: state change not frame aligned")

  // ---------------- L3: protocol rules (4) ----------------
  a_soundwire_l3_reset_idle : assert property (@(posedge clk)
    $fell(rst_n) |-> ##[1:4] (state == IDLE))
    else `uvm_error("SVA_L3", "soundwire: state not IDLE during reset")
  a_soundwire_l3_no_stuck   : assert property (@(posedge clk) disable iff (!rst_n)
    state == BRA |-> ##[1:64] (state != BRA))
    else `uvm_error("SVA_L3", "soundwire: stuck in BRA")
  a_soundwire_l3_full_cycle : cover property (@(posedge clk) disable iff (!rst_n)
    state == IDLE ##1 state == COMMAND);
  a_soundwire_l3_blk_close  : cover property (@(posedge clk) disable iff (!rst_n)
    state == DATA_BLOCK ##1 state == PING);

  // ---------------- L4: SoundWire protocol-specific rules (4) ----------------
  // L4-1: command frame format - every frame opens with the sync pattern
  // (at bit_cnt == 8 the DDR shift register holds frame bits 0-7)
  a_soundwire_l4_cmd_sync : assert property (@(posedge clk or negedge clk)
    disable iff (!rst_n)
    bit_cnt == 6'd8 |-> sr == SW_SYNC)
    else `uvm_error("SVA_L4", "soundwire: command frame missing sync pattern")
  // L4-2: ping period - a ping frame occurs at least every 8 frames
  a_soundwire_l4_ping_period : assert property (@(posedge clk) disable iff (!rst_n)
    $rose(frame_start) |-> (frame_no - last_ping_frame) <= 16'd8)
    else `uvm_error("SVA_L4", "soundwire: ping period exceeded")
  // L4-3: data block transport starts on a frame boundary
  a_soundwire_l4_block_align : assert property (@(posedge clk) disable iff (!rst_n)
    (state == DATA_BLOCK && $past(state) != DATA_BLOCK) |-> frame_start)
    else `uvm_error("SVA_L4", "soundwire: data block not frame aligned")
  // L4-4: a bus request (BRA) is granted within 128 clocks
  a_soundwire_l4_bra_grant : assert property (@(posedge clk) disable iff (!rst_n)
    $rose(bra_req) |-> ##[1:128] bra_grant)
    else `uvm_error("SVA_L4", "soundwire: bus request not granted")

endmodule
`endif
