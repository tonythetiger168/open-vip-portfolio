// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- SoundWire testbench top with three functional audio
// peripheral DUTs (register map + bus-request handshake)

`ifndef SOUNDWIRE_TB_SV
`define SOUNDWIRE_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import soundwire_defs_pkg::*;
import soundwire_pkg::*;
import soundwire_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  soundwire_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // Three peripherals on the bus; response drives are resolved wired-AND
  logic d1_o, d1_oe, d2_o, d2_oe, d3_o, d3_oe;
  assign vif.slv_data_o  = d1_o & d2_o & d3_o;
  assign vif.slv_data_oe = d1_oe | d2_oe | d3_oe;

  soundwire_audio_peripheral #(.DEV_NUM(4'h1)) dut1
    (.clk(vif.clk), .rst_n(vif.rst_n), .data_i(vif.data_i),
     .slv_data_o(d1_o), .slv_data_oe(d1_oe));
  soundwire_audio_peripheral #(.DEV_NUM(4'h2)) dut2
    (.clk(vif.clk), .rst_n(vif.rst_n), .data_i(vif.data_i),
     .slv_data_o(d2_o), .slv_data_oe(d2_oe));
  soundwire_audio_peripheral #(.DEV_NUM(4'h3)) dut3
    (.clk(vif.clk), .rst_n(vif.rst_n), .data_i(vif.data_i),
     .slv_data_o(d3_o), .slv_data_oe(d3_oe));

  initial begin
    uvm_config_db#(virtual soundwire_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

// Functional SoundWire audio peripheral:
//  - decodes DDR command frames (sync hunt + 32-bit header)
//  - register map write / read (default 0x00)
//  - ping status response; write of 0x01 to SW_BRA_REG arms a bus request,
//    advertised in status bytes until a BRA grant arrives
// Sampling and response driving both happen on clock edges with NBA
// updates, so a slave can complete a header and launch the response bit
// on the same edge.
module soundwire_audio_peripheral #(parameter bit [3:0] DEV_NUM = 4'h1)
(
  input  logic clk,
  input  logic rst_n,
  input  logic data_i,
  output logic slv_data_o,
  output logic slv_data_oe
);
  import soundwire_defs_pkg::*;

  bit [7:0] mem [bit [15:0]];
  bit       bra_armed = 0;

  bit [7:0]  w    = 0;          // sync hunt window
  bit [31:0] h32  = 0;          // header shift register
  int        bcnt = 0;          // header bits decoded (0..32)
  int        rcnt = 0;          // response bits driven (0..8)
  int        skip = 0;          // response-window edges to skip before hunting
  bit        respond  = 0;
  bit [7:0]  resp_byte = 8'h00;

  always @(posedge clk or negedge clk or negedge rst_n) begin
    if (!rst_n) begin
      w <= 0; h32 <= 0; bcnt <= 0; rcnt <= 0; skip <= 0; respond <= 0;
      slv_data_o <= 1'b1; slv_data_oe <= 1'b0;
      bra_armed <= 0;
    end else begin
      // ---- response window drive (bits 40-47 of the frame) ----
      // Bit 7 is launched by the decode branch on the header-completing
      // edge; this block drives the remaining 7 bits.
      if (respond && rcnt >= 1 && rcnt < 8) begin
        slv_data_oe <= 1'b1;
        slv_data_o  <= resp_byte[7-rcnt];
        rcnt <= rcnt + 1;
        if (rcnt == 7) respond <= 0;
      end else if (!respond) begin
        slv_data_oe <= 1'b0;
        rcnt <= 0;
      end

      // ---- frame decode ----
      if (skip > 0) begin
        skip <= skip - 1;            // stay quiet through the response window
      end else if (bcnt == 0 && !respond) begin
        w <= {w[6:0], data_i};
        if ({w[6:0], data_i} == SW_SYNC) bcnt <= 1;
      end else if (bcnt > 0) begin
        automatic bit [31:0] h = {h32[30:0], data_i};
        h32 <= h;
        if (bcnt == 32) begin
          automatic bit [3:0]  dev  = h[31:28];
          automatic bit [3:0]  opc  = h[27:24];
          automatic bit [15:0] addr = h[23:8];
          automatic bit [7:0]  dat  = h[7:0];
          automatic bit        do_resp = 0;
          automatic bit [7:0]  rb = 8'h00;
          bcnt <= 0;
          skip <= 8;                   // response window: edges 41-48
          case (opc)
            SWC_WRITE, SWC_BLOCK, SWC_BLOCK_FIRST: begin
              if (dev == DEV_NUM) begin
                mem[addr] = dat;
                if (addr == SW_BRA_REG) bra_armed <= dat[0];
                do_resp = 1;
                rb = bra_armed ? SW_STS_WRITE_BRA : SW_STS_WRITE;
              end
            end
            SWC_READ: begin
              if (dev == DEV_NUM) begin
                do_resp = 1;
                rb = mem.exists(addr) ? mem[addr] : 8'h00;
              end
            end
            SWC_PING: begin
              do_resp = 1;
              rb = bra_armed ? SW_STS_PING_BRA : SW_STS_PING;
            end
            SWC_BRA_GRANT: begin
              bra_armed <= 0;          // grant clears the request
            end
            default: ;
          endcase
          if (do_resp) begin
            // launch response bit 7 on this very edge (bit 40 of the frame)
            respond     <= 1;
            resp_byte   <= rb;
            slv_data_oe <= 1'b1;
            slv_data_o  <= rb[7];
            rcnt        <= 1;
          end
        end else begin
          bcnt <= bcnt + 1;
        end
      end
    end
  end
endmodule
`endif
