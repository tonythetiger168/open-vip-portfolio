// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_soundwire_tb.sv -- self-checking functional test for the MIPI
// SoundWire audio peripheral model (soundwire_audio_peripheral, flattened by
// smoke/flatten.py). Run: python3 tools/run_func_tests.py SoundWire-VIP
//
// Model contract (from tb/top_tb.sv and soundwire_defs_pkg):
//   DATA is sampled on both clock edges (double data rate). A frame is SYNC
//   (0xC7) + 32 header bits {device[3:0], opcode[3:0], address[15:0],
//   data[7:0]}. The addressed peripheral (DEV_NUM = 1) answers with a status
//   byte over the next 8 edges: WRITE / BLOCK -> 0xAB (0xAA with a bus
//   request armed), READ -> register data, PING (any device) -> 0x5B / 0x5A
//   with a bus request. Writing 1 to register 0x00F0 arms a bus request;
//   BRA_GRANT clears it. Frames for other devices get no response.

module func_soundwire_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [7:0] SYNC = 8'hC7;
  localparam bit [3:0] WRITE = 4'h1, READ = 4'h2, PING = 4'h3, BLOCK = 4'h4, GRANT = 4'h5, BLOCK1 = 4'h6;
  localparam bit [7:0] ST_PING = 8'h5B, ST_PING_BRA = 8'h5A, ST_WR = 8'hAB, ST_WR_BRA = 8'hAA;
  int checks = 0, fails = 0;

  logic clk = 1'b0, rst_n = 1'b0, data_i = 1'b0;
  wire  data_o, data_oe;

  always #10 clk = ~clk;

  soundwire_audio_peripheral u_dut (
    .clk(clk), .rst_n(rst_n), .data_i(data_i), .slv_data_o(data_o), .slv_data_oe(data_oe)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // one bit per clock edge; data changes 3 time units after the edge
  task automatic dbit(input bit b);
    @(clk); #3 data_i = b;
  endtask

  logic [7:0] rsp;
  bit         got;
  task automatic frame(input [3:0] dev, input [3:0] op, input [15:0] addr, input [7:0] d,
                       input bit with_sync = 1);
    logic [39:0] f = {(with_sync ? SYNC : 8'h00), dev, op, addr, d};
    for (int i = 39; i >= 0; i--) dbit(f[i]);
    got = 0; rsp = '0;
    // response starts on the edge that samples the last header bit
    for (int i = 7; i >= 0; i--) begin
      @(clk); #3;
      if (data_oe === 1'b1) begin got = 1; rsp[i] = data_o; end
    end
    data_i = 1'b0;
    repeat (12) @(clk);
  endtask

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1'b1;
    repeat (4) @(clk);

    frame(4'h1, WRITE, 16'h0010, 8'h3C);
    chk(got && rsp == ST_WR, "register WRITE answered with the write status 0xAB");
    chk(u_dut.mem[16'h0010] === 8'h3C, "register WRITE stores the data");
    frame(4'h1, READ, 16'h0010, 8'h00);
    chk(got && rsp == 8'h3C, "register READ returns the written byte");
    frame(4'h1, READ, 16'h0011, 8'h00);
    chk(got && rsp == 8'h00, "READ of an unwritten register returns 0");

    frame(4'h2, WRITE, 16'h0010, 8'hFF);
    chk(!got && u_dut.mem[16'h0010] === 8'h3C, "WRITE to another device: no response, no update");
    frame(4'h3, READ, 16'h0010, 8'h00);
    chk(!got, "READ to another device gets no response");

    frame(4'h0, PING, 16'h0000, 8'h00);
    chk(got && rsp == ST_PING, "PING (broadcast) answered with status 0x5B");

    // bus request: arm, report on PING / WRITE, grant clears it
    frame(4'h1, WRITE, 16'h00F0, 8'h01);
    chk(u_dut.bra_armed === 1'b1, "writing 1 to 0x00F0 arms a bus request");
    frame(4'h0, PING, 16'h0000, 8'h00);
    chk(got && rsp == ST_PING_BRA, "PING reports the pending bus request (0x5A)");
    frame(4'h1, WRITE, 16'h0020, 8'h11);
    chk(got && rsp == ST_WR_BRA, "WRITE status reports the pending bus request (0xAA)");
    frame(4'h1, GRANT, 16'h0000, 8'h00);
    chk(!got && u_dut.bra_armed === 1'b0, "BRA grant clears the request (no response)");
    frame(4'h0, PING, 16'h0000, 8'h00);
    chk(got && rsp == ST_PING, "PING status back to no-request after the grant");

    // block transport
    frame(4'h1, BLOCK1, 16'h0100, 8'hA0);
    frame(4'h1, BLOCK,  16'h0101, 8'hA1);
    frame(4'h1, BLOCK,  16'h0102, 8'hA2);
    chk(u_dut.mem[16'h0100] === 8'hA0 && u_dut.mem[16'h0101] === 8'hA1 && u_dut.mem[16'h0102] === 8'hA2,
        "BLOCK_FIRST + BLOCK frames store the data block");

    frame(4'h1, 4'hC, 16'h0010, 8'h00);
    chk(!got, "unknown opcode gets no response");
    frame(4'h1, READ, 16'h0010, 8'h00, 0);
    chk(!got, "frame without SYNC is ignored");

    @(negedge clk); rst_n = 1'b0;
    @(negedge clk); rst_n = 1'b1;
    chk(data_oe === 1'b0 && u_dut.bra_armed === 1'b0, "reset releases the line and clears the bus request");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
