// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_env.sv -- SoundWire verification environment with end-to-end scoreboard

package env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import soundwire_defs_pkg::*;
  import soundwire_pkg::*;

  `include "soundwire_reg_model.svh"

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // End-to-end scoreboard: compares master-issued (expected) transactions
  // against monitor-decoded (observed) transactions. Read data expectations
  // come from the driver's shadow register map (true end-to-end checking).
  class soundwire_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(soundwire_scoreboard)
    uvm_analysis_imp_exp #(soundwire_transaction, soundwire_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(soundwire_transaction, soundwire_scoreboard) obs_ap;

    soundwire_transaction exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0, n_error_matches = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void write_exp(soundwire_transaction t); exp_q.push_back(t); check(); endfunction
    function void write_obs(soundwire_transaction t); obs_q.push_back(t); check(); endfunction

    function bit block_eq(soundwire_transaction a, soundwire_transaction b);
      if (a.block.size() != b.block.size()) return 0;
      foreach (a.block[i]) if (a.block[i] != b.block[i]) return 0;
      return 1;
    endfunction

    function void check();
      while (exp_q.size() && obs_q.size()) begin
        soundwire_transaction e = exp_q.pop_front();
        soundwire_transaction o = obs_q.pop_front();
        if (e.is_bad_dev()) begin
          // error injection: commands to a non-existent device get no response
          if (o.no_resp) n_error_matches++;
          else begin
            n_mismatches++;
            `uvm_error("SB", $sformatf("expected no-response, obs{%s}", o.convert2string()))
          end
        end else if (e.op == o.op &&
                     (e.op == SW_PING || e.op == SW_BRA ||
                      (e.dev_num == o.dev_num && e.reg_addr == o.reg_addr &&
                       (e.op == SW_BLOCK ? block_eq(e, o) : e.data == o.data)))) begin
          n_matches++;
        end else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("mismatch exp{%s} obs{%s}",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("soundwire scoreboard: n_matches=%0d n_error_matches=%0d n_mismatches=%0d",
                n_matches, n_error_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("SB", "end-to-end n_mismatches detected")
      if (exp_q.size() || obs_q.size())
        `uvm_warning("SB", $sformatf("unmatched transactions left: exp=%0d obs=%0d",
                   exp_q.size(), obs_q.size()))
    endfunction
  endclass

  class soundwire_env extends uvm_env;
    `uvm_component_utils(soundwire_env)
    soundwire_agent      agt;
    soundwire_scoreboard sb;
    soundwire_checker    chk;
    soundwire_coverage   cov;
    // UVM RAL: register model of the DUT model in tb/top_tb.sv, frontdoor
    // through the agent, mirror kept by an explicit predictor fed by the
    // monitor (which publishes each item before the driver completes it)
    soundwire_reg_block                        regmodel;
    soundwire_reg_adapter                      reg_adapter;
    uvm_reg_predictor #(soundwire_transaction)  reg_predictor;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = soundwire_agent::type_id::create("agt", this);
      sb  = soundwire_scoreboard::type_id::create("sb", this);
      chk = soundwire_checker::type_id::create("chk", this);
      cov = soundwire_coverage::type_id::create("cov", this);
      if (!uvm_config_db#(soundwire_reg_block)::get(this, "", "regmodel", regmodel)) begin
        regmodel = soundwire_reg_block::type_id::create("regmodel");
        regmodel.configure(null, "");
        regmodel.build();
        regmodel.lock_model();
      end
      reg_adapter   = soundwire_reg_adapter::type_id::create("reg_adapter");
      reg_predictor = uvm_reg_predictor#(soundwire_transaction)::type_id::create("reg_predictor", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      agt.mon.ap.connect(sb.obs_ap);
      agt.drv.drv_ap.connect(sb.exp_ap);
      agt.mon.ap.connect(chk.chk_ap);
      agt.mon.ap.connect(cov.analysis_export);
      regmodel.default_map.set_sequencer(agt.sqr, reg_adapter);
      regmodel.default_map.set_auto_predict(0);
      reg_predictor.map     = regmodel.default_map;
      reg_predictor.adapter = reg_adapter;
      agt.mon.ap.connect(reg_predictor.bus_in);
    endfunction
  endclass
endpackage
