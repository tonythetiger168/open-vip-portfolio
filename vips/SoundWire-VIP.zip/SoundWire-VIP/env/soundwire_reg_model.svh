// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// soundwire_reg_model.svh -- UVM register model of SoundWire peripheral 1 in
// tb/top_tb.sv (soundwire_audio_peripheral, DEV_NUM 1). The peripheral keeps
// a sparse 64 K x 8 register map that reads 0 until written; the model maps
//   REG0..REG31 @ 0x0000-0x001F  8-bit RW registers (reset, bit-bash, mirror tests)
//   MEM         @ 0x0100-0x01FF  256 x 8 RW (walk test)
// SW_BRA_REG (0x00F0) arms a bus request and is left out on purpose.

`ifndef SOUNDWIRE_REG_MODEL_SVH
`define SOUNDWIRE_REG_MODEL_SVH

class soundwire_data_reg extends uvm_reg;
  `uvm_object_utils(soundwire_data_reg)
  rand uvm_reg_field DATA;

  function new(string name = "soundwire_data_reg");
    super.new(name, 8, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    DATA = uvm_reg_field::type_id::create("DATA");
    //            parent size lsb access volatile reset has_reset rand individually_accessible
    DATA.configure(this, 8,   0,  "RW",  0,       8'h0, 1,        1,   1);
  endfunction
endclass

class soundwire_reg_block extends uvm_reg_block;
  `uvm_object_utils(soundwire_reg_block)
  localparam int N_REGS  = 32;
  localparam int N_WORDS = 256;
  rand soundwire_data_reg REG[N_REGS];
  uvm_mem                 MEM;
  uvm_reg_map             sw_map;

  function new(string name = "soundwire_reg_block");
    super.new(name, UVM_NO_COVERAGE);
  endfunction

  virtual function void build();
    sw_map = create_map("sw_map", 'h0, 1, UVM_LITTLE_ENDIAN, 1);
    default_map = sw_map;
    foreach (REG[i]) begin
      REG[i] = soundwire_data_reg::type_id::create($sformatf("REG%0d", i));
      REG[i].configure(this, null, "");
      REG[i].build();
      sw_map.add_reg(REG[i], i, "RW");
    end
    MEM = new("MEM", N_WORDS, 8, "RW", UVM_NO_COVERAGE);
    MEM.configure(this, "");
    sw_map.add_mem(MEM, 'h100, "RW");
  endfunction
endclass
`endif
