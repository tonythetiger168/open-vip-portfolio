# SoundWire — MIPI SoundWire UVM VIP

Open-source UVM verification IP template for **MIPI SoundWire** (MIPI).

## Contents

| Path | Description |
|------|-------------|
| `soundwire/soundwire_if.sv` | Protocol interface + FSM state enum |
| `soundwire/soundwire_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / coverage / checker) |
| `soundwire/sva/soundwire_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=4) |
| `soundwire/vip/soundwire/` | protocol / timing / error / data-integrity checkers |
| `env/` | Environment + scoreboard |
| `tests/soundwire_tests.sv` | base / random / regression tests |
| `tb/top_tb.sv` | Testbench top with FSM-walking DUT stub |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Quick start

```bash
cd scripts
make all                       # single run (VCS default)
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **DDR command-frame driver**: bit-banged 48-bit DDR frames (sync/dev/opcode/addr/data + slave response window), automatic ping cadence, BRA detection in status bytes and broadcast grant, shadow register map for true end-to-end read prediction
- **Protocol-decoding monitor**: dual-edge sync hunting, command frame decode, BLOCK frame grouping into data-block transfers, no-response detection
- **End-to-end scoreboard**: master-issued vs monitor-decoded comparison (op/dev/addr/data/block payload/read data), no-response error-injection matching
- **Functional DUT models**: three audio peripherals (dev 1-3) with register maps, ping status, bus-request arming via register and grant handling, wired-AND response aggregation
- **Directed sequence library**: write / read-after-write / block-transfer / ping-cadence / BRA request-grant / bad-device error-inject / reset + random + regression mix
- **Functional coverage**: op x device cross, address ranges (incl. BRA register), data corners, block lengths, FSM states + command/block/BRA transitions, no-response and bus-request error bins
- **SVA L4**: command frame sync format, ping period bound, frame-aligned data block start, bus-request grant liveness
