// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// Ethernet Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 19
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
`ifndef ETHERNET_COMPLIANCE_CHECKER_SV
`define ETHERNET_COMPLIANCE_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"

// ============================================================================
// ethernet_compliance_checker_sva -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module ethernet_compliance_checker_sva (net_vip_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; l4_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_eth_preamble; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sop |-> $past(vif.data[7:0],1) == 8'h55; endproperty
  assert_p_eth_preamble: assert property(p_eth_preamble) l1_pass[0]++; else begin `uvm_warning("ETHERNET_L1", "Preamble 0x55 failed"); l1_fail[0]++; end
  cover_p_eth_preamble: cover property(p_eth_preamble);
  property p_eth_sfd; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sop |-> vif.data[7:0] == 8'hD5; endproperty
  assert_p_eth_sfd: assert property(p_eth_sfd) l1_pass[1]++; else begin `uvm_warning("ETHERNET_L1", "SFD 0xD5 failed"); l1_fail[1]++; end
  cover_p_eth_sfd: cover property(p_eth_sfd);
  property p_eth_fcs_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.crc_ok; endproperty
  assert_p_eth_fcs_valid: assert property(p_eth_fcs_valid) l1_pass[2]++; else begin `uvm_warning("ETHERNET_L1", "FCS on valid frame failed"); l1_fail[2]++; end
  cover_p_eth_fcs_valid: cover property(p_eth_fcs_valid);
  property p_eth_speed_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.speed inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110}; endproperty
  assert_p_eth_speed_valid: assert property(p_eth_speed_valid) l1_pass[3]++; else begin `uvm_warning("ETHERNET_L1", "Speed valid failed"); l1_fail[3]++; end
  cover_p_eth_speed_valid: cover property(p_eth_speed_valid);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_eth_min_frame; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.frame_len >= 11'd64; endproperty
  assert_p_eth_min_frame: assert property(p_eth_min_frame) l2_pass[0]++; else begin `uvm_warning("ETHERNET_L2", "Min 64 bytes failed"); l2_fail[0]++; end
  cover_p_eth_min_frame: cover property(p_eth_min_frame);
  property p_eth_max_frame; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.frame_len <= 11'd1518; endproperty
  assert_p_eth_max_frame: assert property(p_eth_max_frame) l2_pass[1]++; else begin `uvm_warning("ETHERNET_L2", "Max 1518 bytes failed"); l2_fail[1]++; end
  cover_p_eth_max_frame: cover property(p_eth_max_frame);
  property p_eth_interframe; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> ##[12:256] vif.sop; endproperty
  assert_p_eth_interframe: assert property(p_eth_interframe) l2_pass[2]++; else begin `uvm_warning("ETHERNET_L2", "IFG >= 96 bits failed"); l2_fail[2]++; end
  cover_p_eth_interframe: cover property(p_eth_interframe);
  property p_eth_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_eth_no_x: assert property(p_eth_no_x) l2_pass[3]++; else begin `uvm_warning("ETHERNET_L2", "No X when valid failed"); l2_fail[3]++; end
  cover_p_eth_no_x: cover property(p_eth_no_x);
  property p_eth_vlan; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vlan_tag |-> vif.frame_len >= 11'd68; endproperty
  assert_p_eth_vlan: assert property(p_eth_vlan) l2_pass[4]++; else begin `uvm_warning("ETHERNET_L2", "VLAN tag valid failed"); l2_fail[4]++; end
  cover_p_eth_vlan: cover property(p_eth_vlan);
  property p_eth_jumbo; @(posedge vif.clk) disable iff (!vif.rst_n) vif.jumbo_en == 0 |-> vif.frame_len <= 11'd1518; endproperty
  assert_p_eth_jumbo: assert property(p_eth_jumbo) l2_pass[5]++; else begin `uvm_warning("ETHERNET_L2", "Jumbo frame limit failed"); l2_fail[5]++; end
  cover_p_eth_jumbo: cover property(p_eth_jumbo);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: a VLAN-tagged frame must carry the 802.1Q TPID 0x8100
  property p_eth_l3_vlan_tpid; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.sop && vif.vlan_tag) |-> vif.ethertype == 16'h8100; endproperty
  assert_p_eth_l3_vlan_tpid: assert property(p_eth_l3_vlan_tpid) l3_pass[0]++; else begin `uvm_warning("ETHERNET_L3", "Tagged frame without 0x8100 TPID failed"); l3_fail[0]++; end
  cover_p_eth_l3_vlan_tpid: cover property(p_eth_l3_vlan_tpid);
  // L3-2: PAUSE (MAC control) frames must target the reserved multicast address 01-80-C2-00-00-01
  property p_eth_l3_pause_dmac; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.sop && vif.ethertype == 16'h8808) |-> vif.dst_mac == 48'h0180_C200_0001; endproperty
  assert_p_eth_l3_pause_dmac: assert property(p_eth_l3_pause_dmac) l3_pass[1]++; else begin `uvm_warning("ETHERNET_L3", "PAUSE frame destination MAC failed"); l3_fail[1]++; end
  cover_p_eth_l3_pause_dmac: cover property(p_eth_l3_pause_dmac);
  // L3-3: Length/Type field must be a valid type (>=0x0600) or a valid 802.3 length (<=1500)
  property p_eth_l3_lentype; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.sop && !vif.vlan_tag) |-> (vif.ethertype >= 16'h0600 || vif.ethertype <= 16'd1500); endproperty
  assert_p_eth_l3_lentype: assert property(p_eth_l3_lentype) l3_pass[2]++; else begin `uvm_warning("ETHERNET_L3", "Length/Type field in undefined range failed"); l3_fail[2]++; end
  cover_p_eth_l3_lentype: cover property(p_eth_l3_lentype);
  // L3-4: FCS verdict must be unambiguous - crc_ok and crc_error never set together
  property p_eth_l3_crc_mutex; @(posedge vif.clk) disable iff (!vif.rst_n) vif.fcs_valid |-> !(vif.crc_ok && vif.crc_error); endproperty
  assert_p_eth_l3_crc_mutex: assert property(p_eth_l3_crc_mutex) l3_pass[3]++; else begin `uvm_warning("ETHERNET_L3", "Ambiguous CRC verdict failed"); l3_fail[3]++; end
  cover_p_eth_l3_crc_mutex: cover property(p_eth_l3_crc_mutex);

  // ---------------- L4: Ethernet protocol-specific rules (5) ----------------
  // L4-1: SFD (0xD5) terminates the preamble in the first beat of a frame
  property p_eth_l4_sfd; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop) |-> (vif.data[63:56] == 8'hD5); endproperty
  assert_p_eth_l4_sfd: assert property(p_eth_l4_sfd) l4_pass[0]++; else begin `uvm_warning("ETHERNET_L4", "SFD 0xD5 not at end of preamble"); l4_fail[0]++; end
  cover_p_eth_l4_sfd: cover property(p_eth_l4_sfd);
  // L4-2: preamble sideband must read 0x55 while a frame starts
  property p_eth_l4_preamble; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop) |-> (vif.preamble == 8'h55); endproperty
  assert_p_eth_l4_preamble: assert property(p_eth_l4_preamble) l4_pass[1]++; else begin `uvm_warning("ETHERNET_L4", "Preamble 0x55 sideband failed"); l4_fail[1]++; end
  cover_p_eth_l4_preamble: cover property(p_eth_l4_preamble);
  // L4-3: frame atomicity - valid held for the beat after SOP of a multi-beat frame
  property p_eth_l4_atomic; @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop && !vif.eop) |=> vif.valid; endproperty
  assert_p_eth_l4_atomic: assert property(p_eth_l4_atomic) l4_pass[2]++; else begin `uvm_warning("ETHERNET_L4", "Frame aborted mid-burst (valid dropped)"); l4_fail[2]++; end
  cover_p_eth_l4_atomic: cover property(p_eth_l4_atomic);
  // L4-4: every SOP is eventually matched by an EOP
  property p_eth_l4_sop_eop; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.sop |-> s_eventually vif.eop; endproperty
  assert_p_eth_l4_sop_eop: assert property(p_eth_l4_sop_eop) l4_pass[3]++; else begin `uvm_warning("ETHERNET_L4", "SOP without eventual EOP"); l4_fail[3]++; end
  cover_p_eth_l4_sop_eop: cover property(p_eth_l4_sop_eop);
  // L4-5: FCS evaluation at frame end always resolves to a verdict
  property p_eth_l4_fcs_verdict; @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.fcs_valid |-> (vif.crc_ok || vif.crc_error || vif.len_error); endproperty
  assert_p_eth_l4_fcs_verdict: assert property(p_eth_l4_fcs_verdict) l4_pass[4]++; else begin `uvm_warning("ETHERNET_L4", "FCS valid without verdict"); l4_fail[4]++; end
  cover_p_eth_l4_fcs_verdict: cover property(p_eth_l4_fcs_verdict);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("ETHERNET_RPT", $sformatf("=== Ethernet Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("ETHERNET_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("ETHERNET_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("ETHERNET_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("ETHERNET_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("ETHERNET_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule

// ============================================================================
// ethernet_compliance_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the ethernet_compliance_checker_sva module above)
// ============================================================================
class ethernet_compliance_checker extends uvm_component;
  `uvm_component_utils(ethernet_compliance_checker)
  function new(string name = "ethernet_compliance_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

`endif
