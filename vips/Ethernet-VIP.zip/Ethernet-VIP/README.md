# Ethernet — UVM VIP (10M/1G/100G/400G/800G/1.6T + UEC + Fibre Channel datapath)

Open-source UVM verification IP for **Ethernet** from 10M/1G up to 1.6T,
including high-speed PAM4/FEC sideband, UEC (Ultra Ethernet) sideband, and a
Fibre Channel port (shared `net_*` infrastructure).

## Contents

| Path | Description |
|------|-------------|
| `rtl/net_vip_if.sv` | Protocol interface (valid/ready datapath, header sideband, clocking blocks, modports, interface coverage) |
| `vip/base/net_vip_pkg.sv` | Enums, config objects, `net_txn_descriptor` (real CRC-32 FCS), coverage model, end-to-end scoreboard |
| `vip/base/net_driver.sv` | Frame composer: preamble/SFD/DA/SA/[VLAN]/ethertype/payload/FCS + IFG + flow control |
| `vip/base/net_monitor.sv` | Waveform decoder: SOP→EOP reassembly, header decode, CRC-32 re-check, analysis port |
| `vip/eth/`, `vip/uec/`, `vip/fc/` | Protocol-specific SVA checkers |
| `rtl/sva/ethernet_compliance_checker.sv` | Tiered SVA compliance checker (L1=4, L2=6, L3=0, L4=5) |
| `env/net_env.sv` | Environment: agent + scoreboard + checkers |
| `sequences/` | base/random/regression + directed sequences |
| `tests/` | base / per-speed / UEC / FC / regression tests |
| `tb/top_tb.sv` | Testbench top + functional DUT (MAC model per port + FC port model) |
| `scripts/` | Makefile + **coverage-driven regression (line/fsm/toggle/SVA, 100% goal)** |

## Architecture

```
sequence -> net_sequencer -> net_driver --drv_ap--> net_scoreboard (expected)
                                    |
                                 net_vip_if <--> net_dut (MAC/FC models:
                                    |            link FSM, ready/flow ctrl,
                                    v            FCS check, FC credits)
                              net_monitor --ap--> net_scoreboard (observed)
                                    +-> net_coverage_model (4 covergroups)
                                    +-> eth/uec/fc protocol checkers
                                    +-> tiered SVA compliance checker (L1-L4)
```

The scoreboard pairs driver-issued and monitor-decoded transactions
(`n_matches` / `n_mismatches`, `UVM_ERROR` on mismatch). Injected CRC/FCS/length
errors count as a match only when the monitor actually detects them.

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `net_base_sequence` | constrained-random frames for a target protocol |
| `net_unicast_sequence` | directed normal unicast traffic |
| `net_vlan_sequence` | 802.1Q VLAN-tagged frames (PCP sweep) |
| `net_pause_sequence` | 802.3x PAUSE flow-control frames |
| `net_random_sequence` | multi-protocol random mix |
| `net_back_to_back_sequence` | minimum-IFG stress |
| `net_max_frame_sequence` | corner: max-length frames per protocol |
| `net_error_inject_sequence` | bad CRC / bad FCS / runt frames |
| `net_reset_sequence` | frame right after reset release |
| `net_stress_sequence` | long weighted-mix stress burst |
| `net_regression_sequence` | weighted mix of all of the above |

## SVA compliance checker

- **L1 (4)**: preamble 0x55, SFD 0xD5, FCS valid at EOP, speed encoding legal
- **L2 (6)**: min 64B frame, max 1518B frame, inter-frame gap, no-X on valid,
  VLAN min size, jumbo limit
- **L4 (5)**: SFD at end of preamble, preamble sideband, frame atomicity
  (valid held), SOP→EOP pairing, FCS verdict resolution

## Functional coverage

- `cg_frame_type`: protocol × frame-type cross
- `cg_frame_size`: size corners (runt/min/medium/jumbo) × protocol cross
- `cg_link_fsm`: link-state bins + DOWN→ANEG→TRAIN→UP transition sequences
- `cg_error`: error type × recovery cross
- interface `cg_interface_activity`: valid/ready handshake, link state,
  error vector, modulation + valid×ready cross

## Quick start

```bash
cd scripts
make all                       # single run (VCS default), TEST=net_random_regression_test
make run TEST=net_ethernet_400g_test
./coverage_regression.sh       # full regression + 100% coverage gate
SIMULATOR=questa ./coverage_regression.sh
```

License: Apache-2.0

## Deepened Features (v1.6.0)

- **Real frame composition**: preamble/SFD, header, payload and **computed
  CRC-32 FCS** streamed over the 512-bit datapath with sop/eop/be framing
- **Flow control**: valid/ready handshake, minimum-IFG control, 802.3x PAUSE
  backpressure in the DUT, FC buffer-to-buffer credits (credit_rdy/r_rdy)
- **Decoding monitor**: preamble strip, header/VLAN parse, payload
  reconstruction, CRC-32 re-computation and runt/bad-FCS classification
- **End-to-end scoreboard**: expected-vs-observed pairing with payload
  compare and error-injection detection accounting
- **Functional DUT**: per-port MAC model (link FSM + FCS check + PAUSE
  backpressure) and FC port model (credits + CRC), closing the loop
- **Directed sequences**: unicast / VLAN / PAUSE / back-to-back / max-frame /
  error-inject / reset / stress + regression mix
- **SVA L4**: five Ethernet-specific rules added on top of the tiered L1/L2
