// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_base_sequence.sv -- Network protocol base + directed sequences
//   net_base_sequence        : base (random) sequence
//   net_unicast_sequence     : directed normal unicast traffic
//   net_vlan_sequence        : directed 802.1Q VLAN-tagged traffic
//   net_pause_sequence       : directed 802.3x PAUSE flow-control frames

`ifndef NET_BASE_SEQUENCE_SV
`define NET_BASE_SEQUENCE_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_base_sequence extends uvm_sequence #(net_sequence_item);
  `uvm_object_utils(net_base_sequence)

  rand int             num_frames;
  rand net_protocol_e  target_protocol;

  constraint c_num_frames {
    num_frames inside {[10:1000]};
  }

  function new(string name = "net_base_sequence");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info("SEQ", $sformatf("Starting %0d frames for %s",
              num_frames, target_protocol.name()), UVM_LOW)
    repeat (num_frames) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { txn.protocol == target_protocol; })
        `uvm_error("SEQ", "Randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Directed: normal unicast frames, moderate sizes
class net_unicast_sequence extends net_base_sequence;
  `uvm_object_utils(net_unicast_sequence)

  function new(string name = "net_unicast_sequence");
    super.new(name);
  endfunction

  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol   == target_protocol;
        txn.frame_type == FRAME_UNICAST;
        txn.dst_mac[47:40] != 8'h01;
        txn.dst_mac    != 48'hFFFF_FFFF_FFFF;
        txn.inject_crc_error == 0;
        txn.inject_fcs_error == 0;
        txn.inject_len_error == 0;
      }) `uvm_error("SEQ", "Unicast randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Directed: VLAN-tagged frames sweeping PCP values
class net_vlan_sequence extends net_base_sequence;
  `uvm_object_utils(net_vlan_sequence)

  function new(string name = "net_vlan_sequence");
    super.new(name);
  endfunction

  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol   == target_protocol;
        txn.frame_type == FRAME_VLAN_TAGGED;
        txn.ethertype  == 16'h8100;
        txn.vlan_id    inside {[1:4094]};
      }) `uvm_error("SEQ", "VLAN randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Directed: 802.3x PAUSE frames (flow control)
class net_pause_sequence extends net_base_sequence;
  `uvm_object_utils(net_pause_sequence)

  function new(string name = "net_pause_sequence");
    super.new(name);
  endfunction

  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol   == target_protocol;
        txn.frame_type == FRAME_PAUSE;
        txn.dst_mac    == 48'h0180_C200_0001;
        txn.ethertype  == 16'h8808;
        txn.payload_len == 64;
      }) `uvm_error("SEQ", "PAUSE randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
