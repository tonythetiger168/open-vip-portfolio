// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_random_sequence.sv -- Network protocol random + stress/corner sequences
//   net_random_sequence        : constrained-random multi-protocol mix
//   net_back_to_back_sequence  : minimum-IFG back-to-back frames
//   net_max_frame_sequence     : corner case: maximum-length frames
//   net_error_inject_sequence  : bad CRC / bad FCS / runt frame injection
//   net_reset_sequence         : single frame issued right after reset
//   net_stress_sequence        : long randomized stress burst

`ifndef NET_RANDOM_SEQUENCE_SV
`define NET_RANDOM_SEQUENCE_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_random_sequence extends net_base_sequence;
  `uvm_object_utils(net_random_sequence)

  rand bit enable_eth;
  rand bit enable_uec;
  rand bit enable_fc;

  constraint c_protocol_dist {
    if (enable_eth) target_protocol inside
      {NET_ETH_1G, NET_ETH_100G, NET_ETH_400G, NET_ETH_800G, NET_ETH_1P6T};
    if (enable_uec) target_protocol == NET_UEC;
    if (enable_fc)  target_protocol == NET_FC;
  }

  function new(string name = "net_random_sequence");
    super.new(name);
  endfunction

  virtual task body();
    super.body();
  endtask
endclass

// Stress: back-to-back frames with minimum inter-frame gap
class net_back_to_back_sequence extends net_base_sequence;
  `uvm_object_utils(net_back_to_back_sequence)

  function new(string name = "net_back_to_back_sequence");
    super.new(name);
  endfunction

  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol   == target_protocol;
        txn.ifg_cycles == 12;          // minimum legal IFG
        txn.payload_len inside {[64:128]};
      }) `uvm_error("SEQ", "Back-to-back randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Corner case: maximum-length frames for the target protocol
class net_max_frame_sequence extends net_base_sequence;
  `uvm_object_utils(net_max_frame_sequence)

  function new(string name = "net_max_frame_sequence");
    super.new(name);
  endfunction

  virtual task body();
    net_protocol_config pc;
    int max_len;
    pc = new("pc", target_protocol);
    max_len = pc.cfg.max_frame_size;
    repeat (num_frames) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol    == target_protocol;
        txn.payload_len == max_len;
      }) `uvm_error("SEQ", "Max-frame randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Error injection: bad CRC, bad FCS and runt frames
class net_error_inject_sequence extends net_base_sequence;
  `uvm_object_utils(net_error_inject_sequence)

  function new(string name = "net_error_inject_sequence");
    super.new(name);
  endfunction

  virtual task body();
    // bad CRC frames
    repeat (num_frames / 3 + 1) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol == target_protocol;
        txn.inject_crc_error == 1;
      }) `uvm_error("SEQ", "CRC-error randomization failed")
      finish_item(item);
    end
    // bad FCS frames
    repeat (num_frames / 3 + 1) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol == target_protocol;
        txn.inject_fcs_error == 1;
      }) `uvm_error("SEQ", "FCS-error randomization failed")
      finish_item(item);
    end
    // runt frames
    repeat (num_frames / 3 + 1) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol == target_protocol;
        txn.inject_len_error == 1;
      }) `uvm_error("SEQ", "Runt randomization failed")
      finish_item(item);
    end
  endtask
endclass

// Reset behavior: one frame immediately after reset release
class net_reset_sequence extends net_base_sequence;
  `uvm_object_utils(net_reset_sequence)

  function new(string name = "net_reset_sequence");
    super.new(name);
  endfunction

  virtual task body();
    net_sequence_item item;
    item = net_sequence_item::type_id::create("item");
    start_item(item);
    if (!item.randomize() with {
      txn.protocol == target_protocol;
      txn.payload_len == 64;
      txn.ifg_cycles == 12;
    }) `uvm_error("SEQ", "Reset randomization failed")
    finish_item(item);
  endtask
endclass

// Stress: long randomized burst mixing all frame types
class net_stress_sequence extends net_base_sequence;
  `uvm_object_utils(net_stress_sequence)

  function new(string name = "net_stress_sequence");
    super.new(name);
  endfunction

  virtual task body();
    repeat (num_frames) begin
      net_sequence_item item;
      item = net_sequence_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with {
        txn.protocol == target_protocol;
        txn.frame_type dist {
          FRAME_UNICAST     := 50,
          FRAME_MULTICAST   := 15,
          FRAME_BROADCAST   := 10,
          FRAME_VLAN_TAGGED := 15,
          FRAME_JUMBO       := 10
        };
        txn.ifg_cycles inside {[12:24]};
      }) `uvm_error("SEQ", "Stress randomization failed")
      finish_item(item);
    end
  endtask
endclass
`endif
