// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// fc_protocol_checker.sv -- Fibre Channel protocol checker
// Assertions for FC-2 framing, delimiters and credit-based flow control.

`ifndef FC_PROTOCOL_CHECKER_SV
`define FC_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

// ============================================================================
// fc_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module fc_protocol_checker_sva (net_vip_if vif);

  int sof_err_cnt = 0;
  int eof_err_cnt = 0;
  int credit_err_cnt = 0;
  int class_err_cnt = 0;


// SOF delimiter must be a legal FC SOF word (first data word at SOP)
property p_fc_sof;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.fc_valid && vif.sop)
    |-> (vif.data[31:0] inside {32'hFFFF_FFF6, 32'hFFFF_FFF7,
                                 32'hFFFF_FFF5, 32'hFFFF_FFF4,
                                 32'hFFFF_FFF2, 32'hFFFF_FFF3,
                                 32'hFFFF_FFF1, 32'hFFFF_FFF0});
endproperty
assert_fc_sof: assert property (p_fc_sof)
  else begin
    `uvm_error("FC_CHK", "FC SOF delimiter violation")
    sof_err_cnt++;
  end

// EOF delimiter must be a legal FC EOF word (first data word at EOP)
property p_fc_eof;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.fc_valid && vif.eop)
    |-> (vif.data[31:0] inside {32'hFFFF_FFF7, 32'hFFFF_FFF5,
                                 32'hFFFF_FFF4, 32'hFFFF_FFF2,
                                 32'hFFFF_FFF3, 32'hFFFF_FFF1,
                                 32'hFFFF_FFF0});
endproperty
assert_fc_eof: assert property (p_fc_eof)
  else begin
    `uvm_error("FC_CHK", "FC EOF delimiter violation")
    eof_err_cnt++;
  end

// No frame transmission without buffer-to-buffer credit
property p_fc_credit;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.fc_valid |-> vif.credit_rdy;
endproperty
assert_fc_credit: assert property (p_fc_credit)
  else begin
    `uvm_error("FC_CHK", "FC frame transmitted without credit")
    credit_err_cnt++;
  end

// FC class of service must be 1, 2 or 3
property p_fc_class;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.fc_valid && vif.sop) |-> (vif.fc_class inside {1, 2, 3});
endproperty
assert_fc_class: assert property (p_fc_class)
  else begin
    `uvm_error("FC_CHK", "FC invalid class of service")
    class_err_cnt++;
  end

  final begin
    `uvm_info("FC_RPT", $sformatf("FC Checker | SOF:%0d EOF:%0d Credit:%0d Class:%0d", sof_err_cnt, eof_err_cnt, credit_err_cnt, class_err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// fc_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the fc_protocol_checker_sva module above)
// ============================================================================

class fc_protocol_checker extends uvm_component;
  `uvm_component_utils(fc_protocol_checker)
  function new(string name = "fc_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
