// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_vip_pkg.sv -- Network protocol VIP package
// Supports: Ethernet 10M-1.6T, UEC, Fibre Channel
// Contains: enumerations, configuration objects, transaction descriptor
// (with real CRC-32 FCS computation), functional coverage model and the
// end-to-end scoreboard.

`ifndef NET_VIP_PKG_SV
`define NET_VIP_PKG_SV

package net_vip_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  //==========================================================================
  // Protocol Enumeration
  //==========================================================================
  typedef enum int {
    NET_ETH_1G      = 0,   // 10/100/1000M Ethernet
    NET_ETH_100G    = 1,   // 10G/25G/40G/50G/100G
    NET_ETH_400G    = 2,   // 200G/400G
    NET_ETH_800G    = 3,   // 800G
    NET_ETH_1P6T    = 4,   // 1.6T
    NET_UEC         = 5,   // Ultra Ethernet Consortium
    NET_FC          = 6,   // Fibre Channel
    NET_MAX         = 7
  } net_protocol_e;

  //==========================================================================
  // Ethernet Speed Enumeration (Mbps)
  //==========================================================================
  typedef enum int {
    SPEED_10M       = 10,
    SPEED_100M      = 100,
    SPEED_1G        = 1000,
    SPEED_10G       = 10000,
    SPEED_25G       = 25000,
    SPEED_40G       = 40000,
    SPEED_50G       = 50000,
    SPEED_100G      = 100000,
    SPEED_200G      = 200000,
    SPEED_400G      = 400000,
    SPEED_800G      = 800000,
    SPEED_1P6T      = 1600000,
    SPEED_FC_1G     = 1062,     // 1GFC
    SPEED_FC_2G     = 2125,     // 2GFC
    SPEED_FC_4G     = 4250,     // 4GFC
    SPEED_FC_8G     = 8500,     // 8GFC
    SPEED_FC_16G    = 14025,    // 16GFC
    SPEED_FC_32G    = 28750,    // 32GFC
    SPEED_FC_64G    = 57500     // 64GFC
  } net_speed_e;

  // UEC baseline 800G (alias kept out of the enum: IEEE 1800 requires
  // unique enumeration values and 800000 is already taken by SPEED_800G)
  localparam net_speed_e SPEED_UEC = SPEED_800G;

  //==========================================================================
  // Link State Enumeration
  //==========================================================================
  typedef enum logic [3:0] {
    LINK_DOWN        = 4'b0000,
    LINK_ANEG        = 4'b0001,   // Auto-negotiation
    LINK_TRAINING    = 4'b0010,   // Link training
    LINK_UP          = 4'b0011,
    LINK_LOCAL_FAULT = 4'b0100,
    LINK_REMOTE_FAULT= 4'b0101,
    LINK_TEST        = 4'b0110,
    LINK_RECOVERY    = 4'b0111
  } net_link_state_e;

  //==========================================================================
  // Frame Type Enumeration
  //==========================================================================
  typedef enum logic [4:0] {
    // Ethernet Frame Types
    FRAME_UNICAST       = 5'b00000,
    FRAME_MULTICAST     = 5'b00001,
    FRAME_BROADCAST     = 5'b00010,
    FRAME_VLAN_TAGGED   = 5'b00011,
    FRAME_QINQ          = 5'b00100,   // Double-tagged
    FRAME_JUMBO         = 5'b00101,
    FRAME_PAUSE         = 5'b00110,   // 802.3x
    FRAME_PFC           = 5'b00111,   // Priority Flow Control
    FRAME_ECN           = 5'b01000,   // Explicit Congestion Notification
    FRAME_FEC_CW        = 5'b01001,   // FEC Codeword
    FRAME_PCS_BLOCK     = 5'b01010,   // PCS block (for 200G+)
    FRAME_PAM4_SYMBOL   = 5'b01011,   // PAM4 symbol (for 400G+/PAM4)
    // UEC Types
    UEC_AI_FRAME        = 5'b01100,   // AI/ML optimized frame
    UEC_RDMA_FRAME      = 5'b01101,   // RDMA over UEC
    UEC_CONGestion      = 5'b01110,   // UEC congestion control
    // Fibre Channel Types
    FC_CLASS_1          = 5'b10000,
    FC_CLASS_2          = 5'b10001,
    FC_CLASS_3          = 5'b10010,
    FC_FICON            = 5'b10011,
    FC_ELS              = 5'b10100,   // Extended Link Service
    FC_ABTS             = 5'b10101,   // Abort Sequence
    FRAME_UNKNOWN       = 5'b11111
  } frame_type_e;

  //==========================================================================
  // Transaction Status
  //==========================================================================
  typedef enum logic [2:0] {
    TXN_OK          = 3'b000,
    TXN_CRC_ERROR   = 3'b001,
    TXN_FCS_ERROR   = 3'b010,
    TXN_LEN_ERROR   = 3'b011,
    TXN_DROP        = 3'b100,
    TXN_TIMEOUT     = 3'b101,
    TXN_REPLAY      = 3'b110
  } net_txn_status_e;

  //==========================================================================
  // Modulation Type
  //==========================================================================
  typedef enum logic [1:0] {
    MOD_NRZ     = 2'b00,
    MOD_PAM4    = 2'b01,
    MOD_PAM6    = 2'b10,
    MOD_PAM8    = 2'b11
  } modulation_e;

  //==========================================================================
  // Configuration Structure
  //==========================================================================
  typedef struct packed {
    net_protocol_e  protocol;
    net_speed_e     speed;
    int             num_lanes;
    int             max_frame_size;
    bit             fec_enabled;
    bit             rs_fec;
    bit             fc_fec;
    bit             pause_enabled;
    bit             pfc_enabled;
    bit             ecn_enabled;
    bit             vlan_enabled;
    bit             jumbo_enabled;
    modulation_e    modulation;
    int             ifg;            // Inter-Frame Gap
    int             preamble_len;   // Preamble length
  } net_protocol_cfg_t;

  //==========================================================================
  // Coverage Configuration
  //==========================================================================
  typedef struct packed {
    bit             cov_frame_types;
    bit             cov_frame_sizes;
    bit             cov_addresses;
    bit             cov_data_patterns;
    bit             cov_link_states;
    bit             cov_error_injection;
    bit             cov_fec;
    bit             cov_modulation;
    bit             cov_latency;
    bit             cov_cross_protocol;
  } net_coverage_cfg_t;

  //==========================================================================
  // Shared CRC-32 (IEEE 802.3, reflected polynomial 0xEDB88320)
  //==========================================================================
  function automatic bit [31:0] net_crc32(ref bit [7:0] bytes[$]);
    bit [31:0] crc;
    crc = 32'hFFFF_FFFF;
    foreach (bytes[i]) begin
      crc ^= bytes[i];
      for (int b = 0; b < 8; b++)
        crc = crc[0] ? (crc >> 1) ^ 32'hEDB8_8320 : (crc >> 1);
    end
    return ~crc;
  endfunction

  //==========================================================================
  // Frame / Packet Descriptor
  //==========================================================================
  class net_txn_descriptor extends uvm_object;
    `uvm_object_utils(net_txn_descriptor)

    rand net_protocol_e     protocol;
    rand frame_type_e       frame_type;
    rand logic [47:0]       dst_mac;
    rand logic [47:0]       src_mac;
    rand logic [15:0]       ethertype;
    rand logic [11:0]       vlan_id;
    rand logic [2:0]        vlan_pcp;       // Priority Code Point
    rand logic              vlan_cfi;
    rand logic [63:0]       payload[];
    rand int                payload_len;    // in bytes
    rand logic [31:0]       fcs;
    rand logic [7:0]        preamble[7];
    rand logic [7:0]        sfd;            // Start Frame Delimiter

    // Fibre Channel fields
    rand logic [3:0]        fc_class;
    rand logic [23:0]       fc_d_id;        // Destination ID (FC)
    rand logic [23:0]       fc_s_id;        // Source ID (FC)
    rand logic [7:0]        fc_seq_id;
    rand logic [15:0]       fc_ox_id;
    rand logic [15:0]       fc_rx_id;
    rand logic [31:0]       fc_sof;         // SOF delimiter word
    rand logic [31:0]       fc_eof;         // EOF delimiter word

    // UEC fields
    rand logic [3:0]        uec_vc;         // UEC Virtual Channel
    rand logic [15:0]       uec_ai_tag;     // AI/ML tag

    // Error injection
    rand bit                inject_crc_error;
    rand bit                inject_fcs_error;
    rand bit                inject_len_error;
    rand int                ifg_cycles;
    rand int                delay_cycles;

    // Timestamp / status
    time                    start_time;
    time                    end_time;
    net_txn_status_e        status;

    // Constraints
    constraint c_payload_len {
      if (protocol inside {NET_ETH_1G})
        payload_len inside {[64:1522]};
      else if (protocol inside {NET_ETH_100G, NET_ETH_400G})
        payload_len inside {[64:9600]};          // Jumbo capable
      else if (protocol == NET_ETH_800G)
        payload_len inside {[64:16383]};         // Extended jumbo
      else if (protocol == NET_ETH_1P6T)
        payload_len inside {[64:65535]};         // Max jumbo
      else if (protocol == NET_UEC)
        payload_len inside {[64:65535]};
      else if (protocol == NET_FC)
        payload_len inside {[28:2148]};          // FC frame size
      else
        payload_len inside {[64:1522]};
    }
    constraint c_jumbo_frame {
      if (frame_type == FRAME_JUMBO)
        payload_len > 1522;
    }
    constraint c_vlan_tagged {
      if (frame_type inside {FRAME_VLAN_TAGGED, FRAME_QINQ})
        ethertype == 16'h8100;
    }
    constraint c_broadcast_mac {
      if (frame_type == FRAME_BROADCAST)
        dst_mac == 48'hFFFF_FFFF_FFFF;
    }
    constraint c_multicast_mac {
      if (frame_type == FRAME_MULTICAST)
        dst_mac[47:40] == 8'h01;   // I/G bit set
    }
    constraint c_pause_frame {
      if (frame_type == FRAME_PAUSE)
        dst_mac == 48'h0180_C200_0001;   // MAC control
    }
    constraint c_pfc_frame {
      if (frame_type == FRAME_PFC)
        dst_mac == 48'h0180_C200_0001;   // MAC control
    }
    constraint c_ifg {
      ifg_cycles inside {[12:96]};   // Standard IFG range
    }
    constraint c_error_rate {
      inject_crc_error dist { 0 := 95, 1 := 5 };
      inject_fcs_error dist { 0 := 97, 1 := 3 };
      inject_len_error dist { 0 := 98, 1 := 2 };
    }
    constraint c_payload_data {
      payload.size() == ((payload_len + 7) / 8);
    }
    constraint c_uec_ai {
      if (protocol == NET_UEC && frame_type == UEC_AI_FRAME)
        uec_ai_tag inside {[16'h0000 : 16'h00FF]};
    }
    constraint c_fc_class {
      if (protocol == NET_FC)
        fc_class inside {1, 2, 3};
    }
    constraint c_fc_delim {
      // SOF: c1/c2/c3/f (class fabric/connect), EOF: t/n/dt/ni
      fc_sof inside {32'hFFFF_FFF6, 32'hFFFF_FFF7, 32'hFFFF_FFF5};
      fc_eof inside {32'hFFFF_FFF7, 32'hFFFF_FFF5, 32'hFFFF_FFF4};
    }

    function new(string name = "net_txn_descriptor");
      super.new(name);
    endfunction

    function void post_randomize();
      start_time = $time;
      // Generate preamble
      foreach (preamble[i]) preamble[i] = 8'h55;
      sfd = 8'hD5;
      // Real FCS: CRC-32 over DA | SA | [VLAN tag] | Ethertype | payload
      if (protocol != NET_FC) begin
        bit [7:0] bytes[$];
        assemble_eth_bytes(bytes);
        fcs = net_crc32(bytes);
      end else begin
        bit [7:0] bytes[$];
        assemble_fc_bytes(bytes);
        fcs = net_crc32(bytes);
      end
    endfunction

    // Assemble Ethernet frame bytes (no preamble/SFD, no FCS)
    function void assemble_eth_bytes(ref bit [7:0] bytes[$]);
      bytes.delete();
      for (int i = 5; i >= 0; i--) bytes.push_back(dst_mac[i*8 +: 8]);
      for (int i = 5; i >= 0; i--) bytes.push_back(src_mac[i*8 +: 8]);
      if (frame_type inside {FRAME_VLAN_TAGGED, FRAME_QINQ}) begin
        bytes.push_back(8'h81); bytes.push_back(8'h00);
        bytes.push_back({vlan_pcp, vlan_cfi, vlan_id[11:8]});
        bytes.push_back(vlan_id[7:0]);
        bytes.push_back(8'h08); bytes.push_back(8'h00);   // inner ethertype
      end else begin
        bytes.push_back(ethertype[15:8]);
        bytes.push_back(ethertype[7:0]);
      end
      for (int i = 0; i < payload_len; i++)
        bytes.push_back(payload[i/8][(i%8)*8 +: 8]);
    endfunction

    // Assemble FC frame bytes (header + payload, no SOF/EOF/CRC)
    function void assemble_fc_bytes(ref bit [7:0] bytes[$]);
      bytes.delete();
      bytes.push_back(8'h22);                              // R_CTL (device data)
      bytes.push_back(fc_d_id[23:16]);
      bytes.push_back(fc_d_id[15:8]);
      bytes.push_back(fc_d_id[7:0]);
      bytes.push_back(8'h00);                              // CS_CTL
      bytes.push_back(fc_s_id[23:16]);
      bytes.push_back(fc_s_id[15:8]);
      bytes.push_back(fc_s_id[7:0]);
      bytes.push_back(8'h27);                              // TYPE (SCSI-FCP)
      bytes.push_back(8'h00);                              // F_CTL[23:16]
      bytes.push_back(8'h00);                              // F_CTL[15:8]
      bytes.push_back({4'h0, fc_class});                   // F_CTL[7:0] class bits
      bytes.push_back(fc_seq_id);
      bytes.push_back(8'h00);                              // DF_CTL
      bytes.push_back(8'h00); bytes.push_back(8'h00);      // SEQ_CNT
      bytes.push_back(fc_ox_id[15:8]); bytes.push_back(fc_ox_id[7:0]);
      bytes.push_back(fc_rx_id[15:8]); bytes.push_back(fc_rx_id[7:0]);
      bytes.push_back(8'h00); bytes.push_back(8'h00);
      bytes.push_back(8'h00); bytes.push_back(8'h00);      // Parameter
      for (int i = 0; i < payload_len; i++)
        bytes.push_back(payload[i/8][(i%8)*8 +: 8]);
    endfunction

    function void set_complete(net_txn_status_e s);
      status = s;
      end_time = $time;
    endfunction

    function int get_latency_ns();
      if (end_time > start_time)
        return int'((end_time - start_time) / 1ns);
      else
        return 0;
    endfunction

    virtual function string convert2string();
      string s;
      $sformat(s, "protocol=%s frame=%s dst=0x%012X src=0x%012X len=%0d status=%s lat=%0dns",
               protocol.name(), frame_type.name(), dst_mac, src_mac, payload_len,
               status.name(), get_latency_ns());
      return s;
    endfunction
  endclass

  //==========================================================================
  // Base Sequence Item
  //==========================================================================
  class net_sequence_item extends uvm_sequence_item;
    `uvm_object_utils(net_sequence_item)

    rand net_txn_descriptor txn;

    constraint c_default {
      txn.protocol != NET_MAX;
    }

    function new(string name = "net_sequence_item");
      super.new(name);
      txn = net_txn_descriptor::type_id::create("txn");
    endfunction

    virtual function string convert2string();
      return txn.convert2string();
    endfunction
  endclass

  //==========================================================================
  // Protocol Configuration Object
  //==========================================================================
  class net_protocol_config extends uvm_object;
    `uvm_object_utils(net_protocol_config)

    net_protocol_e      protocol;
    net_protocol_cfg_t  cfg;
    net_coverage_cfg_t  cov_cfg;

    function new(string name = "net_protocol_config", net_protocol_e p = NET_ETH_1G);
      super.new(name);
      protocol = p;
      set_default_cfg();
    endfunction

    function void set_default_cfg();
      case (protocol)
        NET_ETH_1G: begin
          cfg.protocol        = NET_ETH_1G;
          cfg.speed           = SPEED_1G;
          cfg.num_lanes       = 1;
          cfg.max_frame_size  = 1522;
          cfg.fec_enabled     = 0;
          cfg.pause_enabled   = 1;
          cfg.pfc_enabled     = 0;
          cfg.vlan_enabled    = 1;
          cfg.jumbo_enabled   = 0;
          cfg.modulation      = MOD_NRZ;
          cfg.ifg             = 12;
          cfg.preamble_len    = 8;
        end
        NET_ETH_100G: begin
          cfg.protocol        = NET_ETH_100G;
          cfg.speed           = SPEED_100G;
          cfg.num_lanes       = 4;   // CAUI-4
          cfg.max_frame_size  = 9600;
          cfg.fec_enabled     = 1;
          cfg.rs_fec          = 1;
          cfg.pause_enabled   = 1;
          cfg.pfc_enabled     = 1;
          cfg.vlan_enabled    = 1;
          cfg.jumbo_enabled   = 1;
          cfg.modulation      = MOD_NRZ;
          cfg.ifg             = 12;
          cfg.preamble_len    = 8;
        end
        NET_ETH_400G: begin
          cfg.protocol        = NET_ETH_400G;
          cfg.speed           = SPEED_400G;
          cfg.num_lanes       = 8;   // 8x56G
          cfg.max_frame_size  = 9600;
          cfg.fec_enabled     = 1;
          cfg.rs_fec          = 1;
          cfg.pause_enabled   = 1;
          cfg.pfc_enabled     = 1;
          cfg.vlan_enabled    = 1;
          cfg.jumbo_enabled   = 1;
          cfg.modulation      = MOD_PAM4;
          cfg.ifg             = 12;
          cfg.preamble_len    = 8;
        end
        NET_ETH_800G: begin
          cfg.protocol        = NET_ETH_800G;
          cfg.speed           = SPEED_800G;
          cfg.num_lanes       = 8;   // 8x112G
          cfg.max_frame_size  = 16383;
          cfg.fec_enabled     = 1;
          cfg.rs_fec          = 1;
          cfg.pause_enabled   = 1;
          cfg.pfc_enabled     = 1;
          cfg.vlan_enabled    = 1;
          cfg.jumbo_enabled   = 1;
          cfg.modulation      = MOD_PAM4;
          cfg.ifg             = 12;
          cfg.preamble_len    = 8;
        end
        NET_ETH_1P6T: begin
          cfg.protocol        = NET_ETH_1P6T;
          cfg.speed           = SPEED_1P6T;
          cfg.num_lanes       = 16;  // 16x112G
          cfg.max_frame_size  = 65535;
          cfg.fec_enabled     = 1;
          cfg.rs_fec          = 1;
          cfg.pause_enabled   = 1;
          cfg.pfc_enabled     = 1;
          cfg.vlan_enabled    = 1;
          cfg.jumbo_enabled   = 1;
          cfg.modulation      = MOD_PAM4;
          cfg.ifg             = 12;
          cfg.preamble_len    = 8;
        end
        NET_UEC: begin
          cfg.protocol        = NET_UEC;
          cfg.speed           = SPEED_UEC;
          cfg.num_lanes       = 8;
          cfg.max_frame_size  = 65535;
          cfg.fec_enabled     = 1;
          cfg.rs_fec          = 1;
          cfg.pause_enabled   = 0;   // UEC uses different congestion
          cfg.pfc_enabled     = 0;
          cfg.ecn_enabled     = 1;   // ECN-based congestion
          cfg.vlan_enabled    = 1;
          cfg.jumbo_enabled   = 1;
          cfg.modulation      = MOD_PAM4;
          cfg.ifg             = 8;
          cfg.preamble_len    = 8;
        end
        NET_FC: begin
          cfg.protocol        = NET_FC;
          cfg.speed           = SPEED_FC_32G;
          cfg.num_lanes       = 1;
          cfg.max_frame_size  = 2148;
          cfg.fec_enabled     = 0;
          cfg.fc_fec          = 0;
          cfg.pause_enabled   = 0;
          cfg.pfc_enabled     = 0;
          cfg.vlan_enabled    = 0;
          cfg.jumbo_enabled   = 0;
          cfg.modulation      = MOD_NRZ;
          cfg.ifg             = 6;
          cfg.preamble_len    = 4;   // FC primitive
        end
        default: begin
          cfg.protocol        = NET_ETH_1G;
          cfg.speed           = SPEED_1G;
          cfg.num_lanes       = 1;
          cfg.max_frame_size  = 1522;
        end
      endcase

      // Default coverage enable
      cov_cfg.cov_frame_types     = 1;
      cov_cfg.cov_frame_sizes     = 1;
      cov_cfg.cov_addresses       = 1;
      cov_cfg.cov_data_patterns   = 1;
      cov_cfg.cov_link_states     = 1;
      cov_cfg.cov_error_injection = 1;
      cov_cfg.cov_fec             = 1;
      cov_cfg.cov_modulation      = 1;
      cov_cfg.cov_latency         = 1;
      cov_cfg.cov_cross_protocol  = 1;
    endfunction
  endclass

  //==========================================================================
  // Functional Coverage Model
  //   cg_frame_type : protocol config / frame type cross
  //   cg_frame_size : frame-size corners cross protocol
  //   cg_link_fsm   : link FSM state + transition coverage
  //   cg_error      : error-injection / recovery cross
  //==========================================================================
  class net_coverage_model extends uvm_component;
    `uvm_component_utils(net_coverage_model)

    // Coverpoint sample variables (declared before the covergroups that
    // reference them, per IEEE 1800 declaration-before-use rules)
    net_protocol_e   txn_protocol;
    frame_type_e     txn_frame_type;
    int              txn_payload_len;
    net_link_state_e txn_link_state;
    int              err_type;
    bit              err_recovery;

    // Frame type coverage
    covergroup cg_frame_type;
      option.per_instance = 1;
      cp_protocol: coverpoint txn_protocol {
        bins eth_1g    = {NET_ETH_1G};
        bins eth_100g  = {NET_ETH_100G};
        bins eth_400g  = {NET_ETH_400G};
        bins eth_800g  = {NET_ETH_800G};
        bins eth_1p6t  = {NET_ETH_1P6T};
        bins uec       = {NET_UEC};
        bins fc        = {NET_FC};
      }
      cp_frame_type: coverpoint txn_frame_type {
        bins unicast     = {FRAME_UNICAST};
        bins multicast   = {FRAME_MULTICAST};
        bins broadcast   = {FRAME_BROADCAST};
        bins vlan        = {FRAME_VLAN_TAGGED, FRAME_QINQ};
        bins jumbo       = {FRAME_JUMBO};
        bins pause       = {FRAME_PAUSE};
        bins pfc         = {FRAME_PFC};
        bins ecn         = {FRAME_ECN};
        bins fec_cw      = {FRAME_FEC_CW};
        bins pcs_block   = {FRAME_PCS_BLOCK};
        bins pam4_sym    = {FRAME_PAM4_SYMBOL};
        bins uec_ai      = {UEC_AI_FRAME};
        bins uec_rdma    = {UEC_RDMA_FRAME};
        bins fc_class1   = {FC_CLASS_1};
        bins fc_class2   = {FC_CLASS_2};
        bins fc_class3   = {FC_CLASS_3};
        bins fc_els      = {FC_ELS};
      }
      cx_protocol_frame: cross cp_protocol, cp_frame_type;
    endgroup

    // Frame size coverage (data pattern / corner bins)
    covergroup cg_frame_size;
      option.per_instance = 1;
      cp_size: coverpoint txn_payload_len {
        bins runt      = {[0:63]};
        bins min_frame = {64};
        bins sz_small   = {[65:511]};
        bins sz_medium  = {[512:1023]};
        bins sz_large   = {[1024:1518]};
        bins max_std   = {[1519:1522]};
        bins jumbo     = {[1523:9600]};
        bins super_jumbo = {[9601:65535]};
      }
      cp_protocol: coverpoint txn_protocol {
        bins eth_1g    = {NET_ETH_1G};
        bins eth_100g  = {NET_ETH_100G};
        bins eth_400g  = {NET_ETH_400G};
        bins eth_800g  = {NET_ETH_800G};
        bins eth_1p6t  = {NET_ETH_1P6T};
        bins uec       = {NET_UEC};
        bins fc        = {NET_FC};
      }
      cx_protocol_size: cross cp_protocol, cp_size;
    endgroup

    // Link FSM transition coverage
    covergroup cg_link_fsm;
      option.per_instance = 1;
      cp_state: coverpoint txn_link_state {
        bins down     = {LINK_DOWN};
        bins aneg     = {LINK_ANEG};
        bins training = {LINK_TRAINING};
        bins up       = {LINK_UP};
        bins lfault   = {LINK_LOCAL_FAULT};
        bins rfault   = {LINK_REMOTE_FAULT};
      }
      cp_trans: coverpoint txn_link_state {
        bins bring_up   = (LINK_DOWN => LINK_ANEG => LINK_TRAINING => LINK_UP);
        bins retrain    = (LINK_UP => LINK_TRAINING => LINK_UP);
        bins local_flt  = (LINK_UP => LINK_LOCAL_FAULT => LINK_RECOVERY => LINK_UP);
        bins remote_flt = (LINK_UP => LINK_REMOTE_FAULT => LINK_RECOVERY => LINK_UP);
      }
    endgroup

    // Error injection coverage
    covergroup cg_error;
      option.per_instance = 1;
      cp_err_type: coverpoint err_type {
        bins crc  = {0};
        bins fcs  = {1};
        bins len  = {2};
        bins drop = {3};
      }
      cp_recovery: coverpoint err_recovery {
        bins recovered = {1};
        bins fatal     = {0};
      }
      cx_err_recovery: cross cp_err_type, cp_recovery;
    endgroup

    function new(string name = "net_coverage_model", uvm_component parent = null);
      super.new(name, parent);
      cg_frame_type = new();
      cg_frame_size = new();
      cg_link_fsm   = new();
      cg_error      = new();
    endfunction

    virtual function void sample_transaction(net_txn_descriptor txn);
      txn_protocol    = txn.protocol;
      txn_frame_type  = txn.frame_type;
      txn_payload_len = txn.payload_len;
      cg_frame_type.sample();
      cg_frame_size.sample();
    endfunction

    virtual function void sample_link_state(net_link_state_e s);
      txn_link_state = s;
      cg_link_fsm.sample();
    endfunction

    virtual function void sample_error(int e_type, bit recovery);
      err_type     = e_type;
      err_recovery = recovery;
      cg_error.sample();
    endfunction

    virtual function void sample_modulation(modulation_e mod, int speed);
      // modulation sampling folded into frame-type coverage protocol bins
    endfunction

    virtual function real get_coverage();
      return (cg_frame_type.get_coverage() + cg_frame_size.get_coverage() +
              cg_link_fsm.get_coverage()  + cg_error.get_coverage()) / 4.0;
    endfunction
  endclass

  //==========================================================================
  // End-to-End Scoreboard
  //   exp_ap <- driver-issued transactions (expected)
  //   obs_ap <- monitor-decoded transactions (observed)
  //==========================================================================
  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  class net_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(net_scoreboard)

    uvm_analysis_imp_exp #(net_sequence_item, net_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(net_sequence_item, net_scoreboard) obs_ap;

    net_sequence_item exp_q[$], obs_q[$];

    int txn_count;
    int error_count;
    int mismatch_count;
    int unsigned n_matches;
    int unsigned n_mismatches;

    function new(string name = "net_scoreboard", uvm_component parent = null);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
      txn_count      = 0;
      error_count    = 0;
      mismatch_count = 0;
      n_matches      = 0;
      n_mismatches   = 0;
    endfunction

    // Legacy single-port entry (kept for backward compatibility)
    virtual function void write(net_sequence_item txn);
      write_obs(txn);
    endfunction

    virtual function void write_exp(net_sequence_item t);
      exp_q.push_back(t);
      txn_count++;
      check();
    endfunction

    virtual function void write_obs(net_sequence_item t);
      obs_q.push_back(t);
      check_transaction(t);
      check();
    endfunction

    virtual function void check_transaction(net_sequence_item txn);
      if (txn.txn.status != TXN_OK) error_count++;
    endfunction

    // Pair-wise end-to-end comparison
    virtual function void check();
      while (exp_q.size() > 0 && obs_q.size() > 0) begin
        net_sequence_item e = exp_q.pop_front();
        net_sequence_item o = obs_q.pop_front();
        if (compare_txn(e, o)) begin
          n_matches++;
        end else begin
          n_mismatches++;
          mismatch_count++;
          `uvm_error("SCOREBOARD", $sformatf("end-to-end mismatch\n  exp: %s\n  obs: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    // Returns 1 when observed matches expected. Injected CRC/FCS/length
    // errors must be *detected* by the monitor to count as a match.
    virtual function bit compare_txn(net_sequence_item e, net_sequence_item o);
      if (e.txn.protocol != o.txn.protocol) return 0;
      if (e.txn.inject_crc_error || e.txn.inject_fcs_error) begin
        return (o.txn.status inside {TXN_CRC_ERROR, TXN_FCS_ERROR});
      end
      if (e.txn.inject_len_error) begin
        return (o.txn.status == TXN_LEN_ERROR) || (o.txn.payload_len != e.txn.payload_len);
      end
      if (o.txn.status != TXN_OK) return 0;
      if (e.txn.dst_mac != o.txn.dst_mac) return 0;
      if (e.txn.src_mac != o.txn.src_mac) return 0;
      if (e.txn.payload_len != o.txn.payload_len) return 0;
      for (int i = 0; i < e.txn.payload_len; i++) begin
        if (e.txn.payload[i/8][(i%8)*8 +: 8] != o.txn.payload[i/8][(i%8)*8 +: 8])
          return 0;
      end
      return 1;
    endfunction

    virtual function void report_phase(uvm_phase phase);
      super.report_phase(phase);
      `uvm_info("SCOREBOARD_REPORT", $sformatf(
                "Total Frames: %0d | Errors: %0d | Mismatches: %0d | n_matches=%0d n_mismatches=%0d",
                txn_count, error_count, mismatch_count, n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches > 0)
        `uvm_error("SCOREBOARD", "end-to-end n_mismatches detected")
    endfunction
  endclass

endpackage
`endif
