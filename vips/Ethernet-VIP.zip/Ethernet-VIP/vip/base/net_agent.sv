// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_agent.sv -- Network protocol agent
// Active: sequencer + driver + monitor. Always contains the coverage model;
// the monitor publishes both to the agent analysis port and the coverage
// model.

`ifndef NET_AGENT_SV
`define NET_AGENT_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_agent extends uvm_agent;
  `uvm_component_utils(net_agent)

  net_sequencer       sqr;
  net_driver          drv;
  net_monitor         mon;
  net_coverage_model  cov;

  uvm_analysis_port #(net_sequence_item) ap;

  function new(string name = "net_agent", uvm_component parent = null);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    mon = net_monitor::type_id::create("mon", this);
    cov = net_coverage_model::type_id::create("cov", this);
    if (get_is_active() == UVM_ACTIVE) begin
      sqr = net_sequencer::type_id::create("sqr", this);
      drv = net_driver::type_id::create("drv", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (get_is_active() == UVM_ACTIVE)
      drv.seq_item_port.connect(sqr.seq_item_export);
    mon.cov_model = cov;
    mon.analysis_port.connect(ap);
  endfunction
endclass
`endif
