// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_sequencer.sv -- Network protocol sequencer

`ifndef NET_SEQUENCER_SV
`define NET_SEQUENCER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_sequencer extends uvm_sequencer #(net_sequence_item);
  `uvm_component_utils(net_sequencer)

  function new(string name = "net_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
