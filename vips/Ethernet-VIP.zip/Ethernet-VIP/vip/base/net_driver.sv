// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_driver.sv -- Network protocol driver
// Composes real frames on the interface: preamble/SFD/DA/SA/[/VLAN]/ethertype/
// payload/FCS for Ethernet, SOF/header/payload/CRC/EOF for Fibre Channel,
// honors valid/ready flow control and inter-frame gap, and publishes each
// driven item as the scoreboard's expected transaction.

`ifndef NET_DRIVER_SV
`define NET_DRIVER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_driver extends uvm_driver #(net_sequence_item);
  `uvm_component_utils(net_driver)

  virtual net_vip_if vif;
  net_protocol_e     protocol;
  net_protocol_cfg_t cfg;

  // Expected-transaction port for the end-to-end scoreboard
  uvm_analysis_port #(net_sequence_item) drv_ap;

  int txn_count;
  int error_count;
  int bytes_per_beat = 64;   // DATA_WIDTH/8 of the connected interface

  function new(string name = "net_driver", uvm_component parent = null);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
    txn_count = 0;
    error_count = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual net_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "Virtual interface not found")
    if (!uvm_config_db#(net_protocol_e)::get(this, "", "protocol", protocol))
      protocol = NET_ETH_1G;
    if (!uvm_config_db#(net_protocol_cfg_t)::get(this, "", "cfg", cfg))
      `uvm_warning("CONFIG", "Protocol config not found, using defaults")
    void'(uvm_config_db#(int)::get(this, "", "bytes_per_beat", bytes_per_beat));
  endfunction

  task run_phase(uvm_phase phase);
    init_signals();
    wait (vif.rst_n === 1'b1);
    forever begin
      net_sequence_item req_item;
      seq_item_port.get_next_item(req_item);
      drive_item(req_item);
      seq_item_port.item_done();
    end
  endtask

  virtual task init_signals();
    vif.driver_cb.valid   <= 1'b0;
    vif.driver_cb.sop     <= 1'b0;
    vif.driver_cb.eop     <= 1'b0;
    vif.driver_cb.be      <= 8'h0;
    vif.driver_cb.fc_valid<= 1'b0;
    vif.driver_cb.fec_valid <= 1'b0;
  endtask

  virtual task drive_item(net_sequence_item item);
    net_txn_descriptor txn = item.txn;
    `uvm_info("DRIVER", $sformatf("Driving: %s", txn.convert2string()), UVM_HIGH)
    wait (vif.rst_n === 1'b1);
    repeat (txn.delay_cycles) @(vif.driver_cb);
    case (txn.protocol)
      NET_ETH_1G:                   drive_eth_1g(txn);
      NET_ETH_100G, NET_ETH_400G:   drive_eth_high_speed(txn);
      NET_ETH_800G, NET_ETH_1P6T:   drive_eth_ultra_speed(txn);
      NET_UEC:                      drive_uec(txn);
      NET_FC:                       drive_fc(txn);
      default:                      drive_eth_1g(txn);
    endcase
    txn_count++;
    if (txn.status inside {TXN_CRC_ERROR, TXN_FCS_ERROR, TXN_LEN_ERROR})
      error_count++;
    drv_ap.write(item);   // broadcast expected transaction
  endtask

  //------------------------------------------------------------------------
  // Low-level: stream a byte queue over the data bus with sop/eop/be
  // framing and valid/ready flow control.
  //------------------------------------------------------------------------
  virtual task drive_stream(ref bit [7:0] bytes[$],
                            input net_txn_status_e result_status,
                            input net_txn_descriptor txn);
    int total = bytes.size();
    int idx   = 0;
    int beat  = 0;
    while (idx < total) begin
      logic [511:0] beat_data;
      int n;
      beat_data = '0;
      n = (total - idx < bytes_per_beat) ? (total - idx) : bytes_per_beat;
      for (int j = 0; j < n; j++)
        beat_data[j*8 +: 8] = bytes[idx + j];
      // flow control: wait for ready before the beat is accepted
      @(vif.driver_cb);
      while (vif.driver_cb.ready !== 1'b1) @(vif.driver_cb);
      vif.driver_cb.valid <= 1'b1;
      vif.driver_cb.data  <= beat_data;
      vif.driver_cb.be    <= (n >= 8) ? 8'hFF : (8'hFF >> (8 - n));
      vif.driver_cb.sop   <= (beat == 0);
      vif.driver_cb.eop   <= (idx + n >= total);
      if (beat == 0) begin
        // sideband header observability at SOP
        vif.driver_cb.dst_mac   <= txn.dst_mac;
        vif.driver_cb.src_mac   <= txn.src_mac;
        vif.driver_cb.ethertype <= txn.ethertype;
        vif.driver_cb.vlan_id   <= txn.vlan_id;
        vif.driver_cb.vlan_pcp  <= txn.vlan_pcp;
        vif.driver_cb.vlan_cfi  <= txn.vlan_cfi;
        vif.driver_cb.preamble  <= 8'h55;
        vif.driver_cb.vlan_tag  <= (txn.frame_type inside {FRAME_VLAN_TAGGED, FRAME_QINQ});
        vif.driver_cb.jumbo_en  <= (txn.payload_len > 1522);
        vif.driver_cb.speed     <= speed_code(txn.protocol);
        vif.driver_cb.fc_d_id   <= txn.fc_d_id;
        vif.driver_cb.fc_s_id   <= txn.fc_s_id;
        vif.driver_cb.fc_class  <= txn.fc_class;
        vif.driver_cb.fc_seq_id <= txn.fc_seq_id;
        vif.driver_cb.fc_ox_id  <= txn.fc_ox_id;
        vif.driver_cb.fc_rx_id  <= txn.fc_rx_id;
        vif.driver_cb.uec_vc    <= txn.uec_vc;
        vif.driver_cb.uec_ai_tag<= txn.uec_ai_tag;
      end
      if (idx + n >= total) begin
        vif.driver_cb.fcs       <= txn.fcs;
        vif.driver_cb.frame_len <= 11'(total > 2047 ? 2047 : total);
        vif.driver_cb.length_dw <= 16'((total + 3) / 4);
      end
      idx  += n;
      beat++;
    end
    @(vif.driver_cb);
    vif.driver_cb.valid <= 1'b0;
    vif.driver_cb.sop   <= 1'b0;
    vif.driver_cb.eop   <= 1'b0;
    vif.driver_cb.be    <= 8'h0;
    // inter-frame gap
    repeat (txn.ifg_cycles) @(vif.driver_cb);
    txn.set_complete(result_status);
  endtask

  virtual function logic [2:0] speed_code(net_protocol_e p);
    case (p)
      NET_ETH_1G:   return 3'b000;
      NET_ETH_100G: return 3'b001;
      NET_ETH_400G: return 3'b010;
      NET_ETH_800G: return 3'b011;
      NET_ETH_1P6T: return 3'b100;
      NET_UEC:      return 3'b101;
      NET_FC:       return 3'b110;
      default:      return 3'b000;
    endcase
  endfunction

  // Build the complete Ethernet frame byte stream:
  // preamble(7x55) | SFD(D5) | DA | SA | [VLAN] | ET | payload | FCS
  virtual function void build_eth_frame(net_txn_descriptor txn, ref bit [7:0] bytes[$]);
    bit [7:0] body[$];
    bytes.delete();
    for (int i = 0; i < 7; i++) bytes.push_back(8'h55);   // preamble
    bytes.push_back(8'hD5);                                // SFD
    txn.assemble_eth_bytes(body);
    foreach (body[i]) bytes.push_back(body[i]);
    // FCS (corrupted on request)
    begin
      logic [31:0] f = txn.fcs;
      if (txn.inject_crc_error || txn.inject_fcs_error) f = f ^ 32'hA5A5_5A5A;
      for (int i = 0; i < 4; i++) bytes.push_back(f[i*8 +: 8]);
    end
    // runt-frame injection: truncate below the 64-byte minimum
    if (txn.inject_len_error) begin
      while (bytes.size() > 40) void'(bytes.pop_back());
    end
  endfunction

  //========================================================================
  // 1G Ethernet Driving (GMII-like)
  //========================================================================
  virtual task drive_eth_1g(net_txn_descriptor txn);
    bit [7:0] bytes[$];
    net_txn_status_e st;
    build_eth_frame(txn, bytes);
    st = txn.inject_len_error  ? TXN_LEN_ERROR  :
         txn.inject_crc_error  ? TXN_CRC_ERROR  :
         txn.inject_fcs_error  ? TXN_FCS_ERROR  : TXN_OK;
    drive_stream(bytes, st, txn);
    txn.status = st;
  endtask

  //========================================================================
  // 100G/400G Ethernet Driving (with FEC and PAM4)
  //========================================================================
  virtual task drive_eth_high_speed(net_txn_descriptor txn);
    bit [7:0] bytes[$];
    build_eth_frame(txn, bytes);
    vif.driver_cb.fec_valid  <= 1'b1;
    vif.driver_cb.modulation <= cfg.modulation;
    vif.driver_cb.fec_error  <= txn.inject_fcs_error;
    drive_stream(bytes, txn.inject_crc_error ? TXN_CRC_ERROR :
                        txn.inject_fcs_error ? TXN_FCS_ERROR : TXN_OK, txn);
    vif.driver_cb.fec_valid  <= 1'b0;
    vif.driver_cb.fec_error  <= 1'b0;
    txn.status = txn.inject_crc_error ? TXN_CRC_ERROR :
                 txn.inject_fcs_error ? TXN_FCS_ERROR : TXN_OK;
  endtask

  //========================================================================
  // 800G/1.6T Ethernet Driving
  //========================================================================
  virtual task drive_eth_ultra_speed(net_txn_descriptor txn);
    // Same datapath, PAM4 modulation and full PCS lane indication
    vif.driver_cb.pcs_lane_status <= '1;
    drive_eth_high_speed(txn);
    vif.driver_cb.pcs_lane_status <= '0;
  endtask

  //========================================================================
  // UEC Driving (Ethernet frame + AI tag / VC sideband)
  //========================================================================
  virtual task drive_uec(net_txn_descriptor txn);
    vif.driver_cb.uec_congestion <= 1'b0;
    vif.driver_cb.uec_priority   <= 8'(txn.uec_vc);
    drive_eth_high_speed(txn);
  endtask

  //========================================================================
  // Fibre Channel Driving
  //   SOF(4) | header(24) | payload | CRC(4) | EOF(4)
  //   with buffer-to-buffer credit flow control (fc_rdy / r_rdy).
  //========================================================================
  virtual task drive_fc(net_txn_descriptor txn);
    bit [7:0] bytes[$];
    bit [7:0] body[$];
    logic [31:0] crc;
    net_txn_status_e st;
    bytes.delete();
    // delimiters are placed LSB-first so the first beat reads 32'hFFFF_FFxx
    for (int i = 0; i < 4; i++) bytes.push_back(txn.fc_sof[i*8 +: 8]);
    txn.assemble_fc_bytes(body);
    foreach (body[i]) bytes.push_back(body[i]);
    crc = txn.fcs;
    if (txn.inject_crc_error || txn.inject_fcs_error) crc = crc ^ 32'h5A5A_A5A5;
    for (int i = 0; i < 4; i++) bytes.push_back(crc[i*8 +: 8]);
    for (int i = 0; i < 4; i++) bytes.push_back(txn.fc_eof[i*8 +: 8]);
    if (txn.inject_len_error) begin
      while (bytes.size() > 24) void'(bytes.pop_back());   // truncated frame
    end
    st = txn.inject_len_error ? TXN_LEN_ERROR :
         (txn.inject_crc_error || txn.inject_fcs_error) ? TXN_CRC_ERROR : TXN_OK;
    // credit-based flow control: wait for transmit credit
    @(vif.driver_cb);
    while (vif.driver_cb.credit_rdy !== 1'b1) @(vif.driver_cb);
    vif.driver_cb.fc_valid <= 1'b1;
    drive_stream(bytes, st, txn);
    vif.driver_cb.fc_valid <= 1'b0;
    txn.status = st;
  endtask

endclass
`endif
