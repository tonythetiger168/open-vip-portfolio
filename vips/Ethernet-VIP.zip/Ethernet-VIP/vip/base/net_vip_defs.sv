// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_vip_defs.sv -- compile-order anchor for single-unit compilation
// The package and the agent/checker classes must be elaborated before the
// interface (uses net_link_state_e), the environment and the tests. Every
// included file carries its own include guard, so standalone compilation
// of the individual files later in the file list is a no-op.

`ifndef NET_VIP_DEFS_SV
`define NET_VIP_DEFS_SV

`include "net_vip_pkg.sv"
import net_vip_pkg::*;

`include "net_sequencer.sv"
`include "net_driver.sv"
`include "net_monitor.sv"
`include "net_agent.sv"
`include "eth_protocol_checker.sv"
`include "fc_protocol_checker.sv"
`include "uec_protocol_checker.sv"

`endif
