// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_monitor.sv -- Network protocol monitor
// Reassembles frames from the interface waveform (SOP->EOP beat collection,
// preamble/SFD stripping, header decode, payload reconstruction), re-computes
// the CRC-32 and compares against the received FCS, then publishes the
// transaction on the analysis port.

`ifndef NET_MONITOR_SV
`define NET_MONITOR_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_monitor extends uvm_monitor;
  `uvm_component_utils(net_monitor)

  virtual net_vip_if vif;
  net_protocol_e     protocol;

  uvm_analysis_port #(net_sequence_item) analysis_port;

  int txn_count;
  int error_count;
  int bytes_per_beat = 64;
  net_coverage_model cov_model;

  function new(string name = "net_monitor", uvm_component parent = null);
    super.new(name, parent);
    analysis_port = new("analysis_port", this);
    txn_count = 0;
    error_count = 0;
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual net_vip_if)::get(this, "", "vif", vif))
      `uvm_fatal("CONFIG", "Virtual interface not found")
    if (!uvm_config_db#(net_protocol_e)::get(this, "", "protocol", protocol))
      protocol = NET_ETH_1G;
    void'(uvm_config_db#(int)::get(this, "", "bytes_per_beat", bytes_per_beat));
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    `uvm_info("MONITOR", "Monitor started", UVM_MEDIUM)
    forever begin
      collect_transaction();
    end
  endtask

  virtual task collect_transaction();
    net_sequence_item item;
    net_txn_descriptor txn;

    @(vif.monitor_cb);
    while (vif.monitor_cb.sop !== 1'b1 || vif.monitor_cb.valid !== 1'b1)
      @(vif.monitor_cb);

    item = net_sequence_item::type_id::create("item");
    txn = item.txn;
    txn.protocol = protocol;
    txn.start_time = $time;

    case (protocol)
      NET_ETH_1G:                   collect_eth_1g(txn);
      NET_ETH_100G, NET_ETH_400G:   collect_eth_high_speed(txn);
      NET_ETH_800G, NET_ETH_1P6T:   collect_eth_ultra_speed(txn);
      NET_UEC:                      collect_uec(txn);
      NET_FC:                       collect_fc(txn);
      default:                      collect_eth_1g(txn);
    endcase

    if (cov_model != null) begin
      cov_model.sample_transaction(txn);
      cov_model.sample_link_state(vif.monitor_cb.link_state);
      if (txn.status != TXN_OK)
        cov_model.sample_error(txn.status == TXN_LEN_ERROR ? 2 : 0, 1'b1);
    end

    analysis_port.write(item);
    txn_count++;
    if (txn.status inside {TXN_CRC_ERROR, TXN_FCS_ERROR, TXN_LEN_ERROR})
      error_count++;
  endtask

  //------------------------------------------------------------------------
  // Collect all beat bytes from SOP to EOP into a byte queue.
  // On the EOP beat only the byte-enabled lanes are captured.
  //------------------------------------------------------------------------
  virtual task collect_stream(ref bit [7:0] bytes[$]);
    bytes.delete();
    // first beat already observed (sop && valid)
    capture_beat(bytes);
    while (vif.monitor_cb.eop !== 1'b1) begin
      @(vif.monitor_cb);
      if (vif.monitor_cb.valid === 1'b1)
        capture_beat(bytes);
    end
  endtask

  virtual task capture_beat(ref bit [7:0] bytes[$]);
    int n;
    n = bytes_per_beat;
    if (vif.monitor_cb.eop === 1'b1) begin
      int be_bytes;
      be_bytes = 0;
      for (int j = 0; j < 8; j++)
        if (vif.monitor_cb.be[j]) be_bytes += 8;
      if (be_bytes > 0) n = be_bytes;
    end
    for (int j = 0; j < n; j++)
      bytes.push_back(vif.monitor_cb.data[j*8 +: 8]);
  endtask

  //------------------------------------------------------------------------
  // CRC-32 over decoded header + payload, via a scratch descriptor
  //------------------------------------------------------------------------
  virtual function bit [31:0] recompute_eth_fcs(net_txn_descriptor txn);
    net_txn_descriptor tmp;
    bit [7:0] b[$];
    tmp = net_txn_descriptor::type_id::create("tmp");
    tmp.dst_mac     = txn.dst_mac;
    tmp.src_mac     = txn.src_mac;
    tmp.ethertype   = txn.ethertype;
    tmp.frame_type  = txn.frame_type;
    tmp.vlan_id     = txn.vlan_id;
    tmp.vlan_pcp    = txn.vlan_pcp;
    tmp.vlan_cfi    = txn.vlan_cfi;
    tmp.payload_len = txn.payload_len;
    tmp.payload     = new[txn.payload.size()];
    foreach (txn.payload[i]) tmp.payload[i] = txn.payload[i];
    tmp.assemble_eth_bytes(b);
    return net_crc32(b);
  endfunction

  virtual function bit [31:0] recompute_fc_crc(net_txn_descriptor txn);
    net_txn_descriptor tmp;
    bit [7:0] b[$];
    tmp = net_txn_descriptor::type_id::create("tmp");
    tmp.fc_d_id     = txn.fc_d_id;
    tmp.fc_s_id     = txn.fc_s_id;
    tmp.fc_class    = txn.fc_class;
    tmp.fc_seq_id   = txn.fc_seq_id;
    tmp.fc_ox_id    = txn.fc_ox_id;
    tmp.fc_rx_id    = txn.fc_rx_id;
    tmp.payload_len = txn.payload_len;
    tmp.payload     = new[txn.payload.size()];
    foreach (txn.payload[i]) tmp.payload[i] = txn.payload[i];
    tmp.assemble_fc_bytes(b);
    return net_crc32(b);
  endfunction

  //------------------------------------------------------------------------
  // Decode an Ethernet frame: strip preamble/SFD, parse header, split
  // payload and FCS, re-compute CRC-32.
  //------------------------------------------------------------------------
  virtual task decode_eth(net_txn_descriptor txn, ref bit [7:0] bytes[$]);
    bit [7:0] body[$];
    bit [31:0] calc_fcs;
    bit [7:0]  t0, t1;
    int        hdr;
    // strip preamble (7 x 0x55) + SFD (0xD5)
    repeat (8) if (bytes.size() > 0) void'(bytes.pop_front());
    if (bytes.size() < 14) begin
      txn.status = TXN_LEN_ERROR;               // runt frame
      txn.payload_len = bytes.size();
      txn.set_complete(txn.status);
      return;
    end
    for (int i = 5; i >= 0; i--) txn.dst_mac[i*8 +: 8] = bytes.pop_front();
    for (int i = 5; i >= 0; i--) txn.src_mac[i*8 +: 8] = bytes.pop_front();
    t0 = bytes.pop_front(); t1 = bytes.pop_front();
    txn.ethertype = {t0, t1};
    hdr = 14;
    if (txn.ethertype == 16'h8100) begin        // VLAN tag present
      logic [15:0] tci;
      t0 = bytes.pop_front(); t1 = bytes.pop_front();
      tci = {t0, t1};
      txn.vlan_pcp = tci[15:13];
      txn.vlan_cfi = tci[12];
      txn.vlan_id  = tci[11:0];
      t0 = bytes.pop_front(); t1 = bytes.pop_front();
      txn.ethertype  = {t0, t1};
      txn.frame_type = FRAME_VLAN_TAGGED;
      hdr = 18;
    end else if (txn.dst_mac == 48'hFFFF_FFFF_FFFF)
      txn.frame_type = FRAME_BROADCAST;
    else if (txn.dst_mac[47:40] == 8'h01)
      txn.frame_type = FRAME_MULTICAST;
    else if (txn.dst_mac == 48'h0180_C200_0001)
      txn.frame_type = FRAME_PAUSE;
    else
      txn.frame_type = FRAME_UNICAST;

    // split payload / FCS
    if (bytes.size() < 4) begin
      txn.status = TXN_LEN_ERROR;
      txn.set_complete(txn.status);
      return;
    end
    for (int i = 0; i < 4; i++)
      txn.fcs[i*8 +: 8] = bytes[bytes.size() - 4 + i];
    repeat (4) void'(bytes.pop_back());
    body = bytes;
    txn.payload_len = body.size();
    txn.payload = new[(txn.payload_len + 7) / 8];
    foreach (body[i])
      txn.payload[i/8][(i%8)*8 +: 8] = body[i];

    // CRC-32 recompute over header + payload
    calc_fcs = recompute_eth_fcs(txn);
    if (vif.monitor_cb.crc_error === 1'b1 || vif.monitor_cb.fcs_error === 1'b1 ||
        calc_fcs != txn.fcs)
      txn.status = TXN_CRC_ERROR;
    else if (txn.payload_len + hdr < 64)
      txn.status = TXN_LEN_ERROR;
    else
      txn.status = TXN_OK;
    txn.set_complete(txn.status);
  endtask

  virtual task collect_eth_1g(net_txn_descriptor txn);
    bit [7:0] bytes[$];
    collect_stream(bytes);
    decode_eth(txn, bytes);
  endtask

  virtual task collect_eth_high_speed(net_txn_descriptor txn);
    bit [7:0] bytes[$];
    collect_stream(bytes);
    decode_eth(txn, bytes);
    if (txn.status == TXN_OK) begin
      if (vif.monitor_cb.modulation == MOD_PAM4)
        txn.frame_type = FRAME_PAM4_SYMBOL;
      else
        txn.frame_type = FRAME_PCS_BLOCK;
    end
    if (vif.monitor_cb.fec_error === 1'b1 ||
        vif.monitor_cb.fec_uncorrectable === 1'b1) begin
      txn.status = TXN_FCS_ERROR;
      txn.set_complete(txn.status);
    end
  endtask

  virtual task collect_eth_ultra_speed(net_txn_descriptor txn);
    collect_eth_high_speed(txn);   // Same collection logic
  endtask

  virtual task collect_uec(net_txn_descriptor txn);
    txn.uec_vc     = vif.monitor_cb.uec_vc;
    txn.uec_ai_tag = vif.monitor_cb.uec_ai_tag;
    collect_eth_high_speed(txn);
    if (txn.status == TXN_OK)
      txn.frame_type = UEC_AI_FRAME;
  endtask

  // FC frame: SOF(4) | header(24) | payload | CRC(4) | EOF(4)
  virtual task collect_fc(net_txn_descriptor txn);
    bit [7:0] bytes[$];
    bit [7:0] body[$];
    bit [31:0] calc_crc;
    bit [7:0]  b0, b1, b2;
    collect_stream(bytes);
    if (bytes.size() < 36) begin
      txn.status = TXN_LEN_ERROR;
      txn.payload_len = bytes.size();
      txn.set_complete(txn.status);
      return;
    end
    for (int i = 3; i >= 0; i--) txn.fc_sof[i*8 +: 8] = bytes.pop_front();
    void'(bytes.pop_front());                       // R_CTL
    b0 = bytes.pop_front(); b1 = bytes.pop_front(); b2 = bytes.pop_front();
    txn.fc_d_id = {b0, b1, b2};
    void'(bytes.pop_front());                       // CS_CTL
    b0 = bytes.pop_front(); b1 = bytes.pop_front(); b2 = bytes.pop_front();
    txn.fc_s_id = {b0, b1, b2};
    void'(bytes.pop_front());                       // TYPE
    repeat (2) void'(bytes.pop_front());            // F_CTL[23:8]
    b0 = bytes.pop_front();
    txn.fc_class = b0[3:0];                         // F_CTL class bits
    txn.fc_seq_id = bytes.pop_front();
    repeat (3) void'(bytes.pop_front());            // DF_CTL + SEQ_CNT
    b0 = bytes.pop_front(); b1 = bytes.pop_front();
    txn.fc_ox_id = {b0, b1};
    b0 = bytes.pop_front(); b1 = bytes.pop_front();
    txn.fc_rx_id = {b0, b1};
    repeat (4) void'(bytes.pop_front());            // Parameter
    // trailing: CRC(4) + EOF(4)
    for (int i = 0; i < 4; i++) txn.fc_eof[i*8 +: 8] = bytes[bytes.size()-4+i];
    repeat (4) void'(bytes.pop_back());
    for (int i = 0; i < 4; i++) txn.fcs[i*8 +: 8] = bytes[bytes.size()-4+i];
    repeat (4) void'(bytes.pop_back());
    body = bytes;
    txn.payload_len = body.size();
    txn.payload = new[(txn.payload_len + 7) / 8];
    foreach (body[i]) txn.payload[i/8][(i%8)*8 +: 8] = body[i];
    txn.frame_type = frame_type_e'(5'b10000 + 5'(txn.fc_class));
    // CRC check over header + payload
    calc_crc = recompute_fc_crc(txn);
    if (vif.monitor_cb.crc_error === 1'b1 || calc_crc != txn.fcs)
      txn.status = TXN_CRC_ERROR;
    else
      txn.status = TXN_OK;
    txn.set_complete(txn.status);
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("MONITOR", $sformatf("Observed %0d transactions (%0d errors)",
              txn_count, error_count), UVM_LOW)
  endfunction
endclass
`endif
