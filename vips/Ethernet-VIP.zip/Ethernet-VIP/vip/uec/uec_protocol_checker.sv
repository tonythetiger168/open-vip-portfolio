// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// uec_protocol_checker.sv -- Ultra Ethernet Consortium (UEC) protocol checker
// Assertions for UEC AI/ML-optimized transport frames.

`ifndef UEC_PROTOCOL_CHECKER_SV
`define UEC_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

// ============================================================================
// uec_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module uec_protocol_checker_sva (net_vip_if vif);

  int vc_err_cnt = 0;
  int tag_err_cnt = 0;
  int congestion_err_cnt = 0;


// UEC virtual channel must stay within the configured 4-bit space
property p_uec_vc_valid;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop) |-> (vif.uec_vc <= 4'hF);
endproperty
assert_uec_vc: assert property (p_uec_vc_valid)
  else begin
    `uvm_error("UEC_CHK", "UEC virtual channel out of range")
    vc_err_cnt++;
  end

// AI frames carry a non-zero AI/ML tag
property p_uec_ai_tag;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop && vif.uec_ai_tag != 16'h0)
    |-> (vif.uec_ai_tag <= 16'h00FF);
endproperty
assert_uec_ai_tag: assert property (p_uec_ai_tag)
  else begin
    `uvm_error("UEC_CHK", "UEC AI/ML tag out of range")
    tag_err_cnt++;
  end

// Congestion indication must coincide with valid traffic
property p_uec_congestion;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.uec_congestion |-> vif.valid;
endproperty
assert_uec_congestion: assert property (p_uec_congestion)
  else begin
    `uvm_error("UEC_CHK", "UEC congestion signaled while idle")
    congestion_err_cnt++;
  end

  final begin
    `uvm_info("UEC_RPT", $sformatf("UEC Checker | VC:%0d Tag:%0d Cong:%0d", vc_err_cnt, tag_err_cnt, congestion_err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// uec_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the uec_protocol_checker_sva module above)
// ============================================================================

class uec_protocol_checker extends uvm_component;
  `uvm_component_utils(uec_protocol_checker)
  function new(string name = "uec_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
