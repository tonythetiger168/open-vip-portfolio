// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// eth_protocol_checker.sv -- Ethernet protocol checker
// Protocol-specific assertions for 1G/100G/400G/800G/1.6T Ethernet

`ifndef ETH_PROTOCOL_CHECKER_SV
`define ETH_PROTOCOL_CHECKER_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

// ============================================================================
// eth_protocol_checker_sva -- SVA-carrying module form of the protocol checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module eth_protocol_checker_sva #(parameter int protocol = 0) (net_vip_if vif);

  int fcs_err_cnt = 0;
  int preamble_err_cnt = 0;
  int ifg_err_cnt = 0;
  int jumbo_err_cnt = 0;
  int vlan_err_cnt = 0;

//========================================================================
// Assertion: Preamble Sequence (7 bytes of 0x55 + 1 byte SFD 0xD5)
//========================================================================
property p_eth_preamble;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop)
    |-> (vif.preamble == 8'h55);
endproperty
assert_eth_preamble: assert property (p_eth_preamble)
  else begin
    `uvm_error("ETH_CHK", "Ethernet preamble violation")
    preamble_err_cnt++;
  end

//========================================================================
// Assertion: SFD (Start Frame Delimiter) = 0xD5
//========================================================================
property p_eth_sfd;
  logic [7:0] sfd;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop, sfd = vif.data[63:56])
    |-> (sfd == 8'hD5);
endproperty
assert_eth_sfd: assert property (p_eth_sfd)
  else `uvm_error("ETH_CHK", "Ethernet SFD mismatch");

//========================================================================
// Assertion: FCS Valid at EOP
//========================================================================
property p_eth_fcs;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.eop && vif.fcs_valid)
    |-> (vif.crc_ok == 1'b1);
endproperty
assert_eth_fcs: assert property (p_eth_fcs)
  else begin
    `uvm_error("ETH_CHK", "Ethernet FCS error at EOP")
    fcs_err_cnt++;
  end

//========================================================================
// Assertion: Inter-Frame Gap (min 12 bytes for 1G, 8 for 800G+)
//========================================================================
property p_eth_ifg;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.eop
    |-> ##[((protocol == NET_ETH_800G || protocol == NET_ETH_1P6T) ? 8 : 12):96] vif.sop;
endproperty
assert_eth_ifg: assert property (p_eth_ifg)
  else begin
    `uvm_error("ETH_CHK", "Ethernet IFG violation")
    ifg_err_cnt++;
  end

//========================================================================
// Assertion: Max Frame Size per Speed
//========================================================================
property p_eth_max_frame;
  int max_size;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop, max_size =
      (protocol == NET_ETH_1G)   ? 1522 :
      (protocol == NET_ETH_100G) ? 9600 :
      (protocol == NET_ETH_400G) ? 9600 :
      (protocol == NET_ETH_800G) ? 16383 :
      (protocol == NET_ETH_1P6T) ? 65535 : 1522)
    |-> (vif.length_dw * 4 <= max_size);
endproperty
assert_eth_max_frame: assert property (p_eth_max_frame)
  else begin
    `uvm_error("ETH_CHK", "Ethernet max frame size exceeded")
    jumbo_err_cnt++;
  end

//========================================================================
// Assertion: VLAN Ethertype = 0x8100
//========================================================================
property p_eth_vlan;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.vlan_tag)
    |-> (vif.vlan_id != 12'h000);
endproperty
assert_eth_vlan: assert property (p_eth_vlan)
  else begin
    `uvm_error("ETH_CHK", "Ethernet VLAN ethertype mismatch")
    vlan_err_cnt++;
  end

//========================================================================
// Assertion: Pause Frame MAC = 01:80:C2:00:00:01
//========================================================================
property p_eth_pause_mac;
  @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.valid && vif.sop && vif.ethertype == 16'h8808)
    |-> (vif.dst_mac == 48'h0180_C200_0001);
endproperty
assert_eth_pause_mac: assert property (p_eth_pause_mac)
  else `uvm_error("ETH_CHK", "Ethernet PAUSE frame with wrong destination MAC");

  final begin
    `uvm_info("ETH_RPT", $sformatf(
      "ETH Checker | FCS:%0d Preamble:%0d IFG:%0d Jumbo:%0d VLAN:%0d",
      fcs_err_cnt, preamble_err_cnt, ifg_err_cnt, jumbo_err_cnt, vlan_err_cnt), UVM_LOW)
  end
endmodule

// ============================================================================
// eth_protocol_checker -- thin UVM shell (kept so the environment can create/start it;
// all SVA content moved to the eth_protocol_checker_sva module above)
// ============================================================================

class eth_protocol_checker extends uvm_component;
  `uvm_component_utils(eth_protocol_checker)
  function new(string name = "eth_protocol_checker", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
