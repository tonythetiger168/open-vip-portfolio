// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (Ethernet MAC frame check)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened net_mac_model DUT.
// Link training (DOWN->ANEG->TRAIN->UP), then frame reception with FCS
// validation: good frame -> crc_ok, short frame -> len_error, corrupted
// FCS -> crc_error, and ethertype 0x8808 -> 4-cycle pause (ready low).
// Prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic vif_clk = 1'b0;
  logic vif_rst_n = 1'b0;
  logic [511:0] vif_data = '0;
  logic vif_valid = 1'b0;
  logic vif_sop = 1'b0;
  logic vif_eop = 1'b0;
  logic [7:0]   vif_be = 8'hFF;
  wire  vif_ready;
  wire  vif_fcs_valid;
  wire  vif_crc_ok;
  wire  vif_link_up;
  wire  vif_crc_error;
  wire  vif_fcs_error;
  wire  vif_len_error;
  wire  vif_framing_error;
  wire  vif_fec_uncorrectable;
  wire  [3:0] vif_link_state;

  always #5 vif_clk = ~vif_clk;

  net_mac_model u_dut (
    .vif_clk(vif_clk), .vif_rst_n(vif_rst_n),
    .vif_data(vif_data), .vif_valid(vif_valid),
    .vif_sop(vif_sop), .vif_eop(vif_eop), .vif_be(vif_be),
    .vif_ready(vif_ready), .vif_fcs_valid(vif_fcs_valid),
    .vif_crc_ok(vif_crc_ok), .vif_link_up(vif_link_up),
    .vif_crc_error(vif_crc_error), .vif_fcs_error(vif_fcs_error),
    .vif_len_error(vif_len_error), .vif_framing_error(vif_framing_error),
    .vif_fec_uncorrectable(vif_fec_uncorrectable),
    .vif_link_state(vif_link_state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge vif_clk); #1;
  endtask

  // build a 64-byte frame; etype 0x0800 unless pause_frame set (0x8808)
  bit [7:0] fr [0:63];
  task automatic build_frame(input bit pause_frame, input bit bad_fcs, input bit short_f);
    logic [31:0] fcs;
    begin
      for (int i = 0; i < 7; i++) fr[i] = 8'h55;
      fr[7]  = 8'hD5;                         // SFD
      fr[8]  = 8'h02; fr[9]  = 8'h00; fr[10] = 8'h00;
      fr[11] = 8'h00; fr[12] = 8'h00; fr[13] = 8'h01;   // dst MAC
      fr[14] = 8'h02; fr[15] = 8'h00; fr[16] = 8'h00;
      fr[17] = 8'h00; fr[18] = 8'h00; fr[19] = 8'h02;   // src MAC
      if (pause_frame) begin fr[20] = 8'h88; fr[21] = 8'h08; end
      else             begin fr[20] = 8'h08; fr[21] = 8'h00; end
      if (short_f) begin
        for (int i = 22; i < 28; i++) fr[i] = i[7:0];
        for (int i = 28; i < 64; i++) fr[i] = 8'h00;
        fcs = 32'hFFFF_FFFF;               // standard CRC-32 over bytes 8..27
        for (int i = 8; i < 28; i++) begin
          fcs ^= fr[i];
          for (int k = 0; k < 8; k++)
            fcs = fcs[0] ? (fcs >> 1) ^ 32'hEDB88320 : (fcs >> 1);
        end
        fcs = fcs ^ 32'hFFFF_FFFF;
        if (bad_fcs) fcs = fcs ^ 32'h0000_00FF;
        fr[28] = fcs[7:0];  fr[29] = fcs[15:8];
        fr[30] = fcs[23:16]; fr[31] = fcs[31:24];
      end else begin
        for (int i = 22; i < 60; i++) fr[i] = i[7:0];
        fcs = 32'hFFFF_FFFF;               // standard CRC-32 over bytes 8..59
        for (int i = 8; i < 60; i++) begin
          fcs ^= fr[i];
          for (int k = 0; k < 8; k++)
            fcs = fcs[0] ? (fcs >> 1) ^ 32'hEDB88320 : (fcs >> 1);
        end
        fcs = fcs ^ 32'hFFFF_FFFF;
        if (bad_fcs) fcs = fcs ^ 32'h0000_00FF;
        fr[60] = fcs[7:0];  fr[61] = fcs[15:8];
        fr[62] = fcs[23:16]; fr[63] = fcs[31:24];
      end
    end
  endtask

  // one 512-bit beat; be = 8 byte-lane enables (each lane = 8 bytes)
  task automatic send_frame(input bit [7:0] lanes_be);
    begin
      while (vif_ready !== 1'b1) step();
      @(negedge vif_clk);
      vif_data = '0;
      for (int j = 0; j < 64; j++) vif_data[j*8 +: 8] = fr[j];
      vif_be    = lanes_be;
      vif_valid = 1'b1;
      vif_sop   = 1'b1;
      vif_eop   = 1'b1;
      step();
      @(negedge vif_clk);
      vif_valid = 1'b0; vif_sop = 1'b0; vif_eop = 1'b0;
    end
  endtask

  bit seen_fcs, seen_pause, seen_len_err, seen_crc_err;

  initial begin
    repeat (8) step();
    chk(vif_ready === 1'b0, "ready low out of reset");
    chk(vif_link_up === 1'b0, "link down out of reset");
    chk(vif_crc_ok === 1'b0 && vif_fcs_valid === 1'b0, "flags quiet out of reset");
    @(negedge vif_clk); vif_rst_n = 1'b1;

    // link training: DOWN -> ANEG -> TRAIN -> UP
    begin : train
      int to = 0;
      bit saw_aneg = 0, saw_train = 0;
      while (vif_link_up !== 1'b1 && to < 60) begin
        step(); to++;
        if (vif_link_state === 4'd1) saw_aneg = 1;
        if (vif_link_state === 4'd2) saw_train = 1;
      end
      chk(vif_link_up === 1'b1, "link came up after training");
      chk(saw_aneg, "passed through autonegotiation");
      chk(saw_train, "passed through training");
      step();
      chk(vif_ready === 1'b1, "ready high with link up");
    end

    // ---- good frame (64B, ethertype 0x0800) ----
    begin : good
      build_frame(1'b0, 1'b0, 1'b0);
      send_frame(8'hFF);
      chk(vif_fcs_valid === 1'b1, "fcs_valid strobe at end of frame");
      step();
      chk(vif_crc_ok === 1'b1, "good frame CRC accepted");
      chk(vif_len_error === 1'b0 && vif_crc_error === 1'b0,
          "no error flags on good frame");
      chk(vif_ready === 1'b1, "no pause for ethertype 0x0800");
    end

    // ---- pause frame (ethertype 0x8808) ----
    begin : pausef
      build_frame(1'b1, 1'b0, 1'b0);
      seen_pause = 0;
      send_frame(8'hFF);
      for (int i = 0; i < 10; i++) begin
        step();
        if (vif_ready === 1'b0 && vif_link_up === 1'b1) seen_pause = 1;
      end
      chk(vif_crc_ok === 1'b1, "pause frame still CRC-valid");
      chk(seen_pause, "pause frame dropped ready for 4 cycles");
      while (vif_ready !== 1'b1) step();
    end

    // ---- short frame (32B) -> len_error ----
    begin : shortf
      build_frame(1'b0, 1'b0, 1'b1);
      send_frame(8'h0F);
      chk(vif_fcs_valid === 1'b1, "fcs_valid on short frame");
      chk(vif_len_error === 1'b1, "short frame raised len_error");
      step();
      chk(vif_crc_ok === 1'b0, "short frame not CRC-ok");
    end

    // ---- corrupted FCS -> crc_error ----
    begin : badf
      build_frame(1'b0, 1'b1, 1'b0);
      send_frame(8'hFF);
      chk(vif_fcs_valid === 1'b1, "fcs_valid on bad frame");
      chk(vif_crc_error === 1'b1, "corrupted FCS raised crc_error");
      step();
      chk(vif_crc_ok === 1'b0, "bad frame not CRC-ok");
    end

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
