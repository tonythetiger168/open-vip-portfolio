// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_ethernet_tb.sv -- self-checking functional test for the Ethernet MAC
// receive model (net_mac_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py Ethernet-VIP
//
// Model contract (from tb/top_tb.sv), 512-bit (64-byte) beats:
//   Link training after reset: DOWN (6 clocks), ANEG (10), TRAIN (10), UP;
//   ready follows link up one clock later. A frame (8-byte preamble/SFD,
//   then DA..FCS) runs from SOP to EOP; on the EOP beat BE[j] enables bytes
//   8j..8j+7 (all-ones or all-zero: whole beat). At EOP fcs_valid pulses;
//   frames under 64 bytes give len_error, a bad CRC-32 (over DA..payload)
//   gives crc_error, otherwise crc_ok is set. EtherType 0x8808 (PAUSE)
//   drops ready for 4 clocks.

module func_ethernet_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic         clk = 1'b0, rst_n = 1'b0, valid = 1'b0, sop = 1'b0, eop = 1'b0;
  logic [511:0] data = '0;
  logic [7:0]   be = 8'hFF;
  // The MAC model takes the byte count of the EOP beat from `empty` (unused
  // bytes); be keeps this bench's 8-byte lane enables and is mapped here.
  logic [6:0]   empty;
  assign empty = (eop && be != 8'hFF && be != 8'h00) ? 7'(64 - 8 * $countones(be)) : 7'd0;
  wire          ready, fcs_valid, crc_ok, link_up, crc_err, fcs_err, len_err, frm_err, fec_unc;
  wire  [3:0]   link_state;

  always #5 clk = ~clk;

  net_mac_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_valid(valid), .vif_ready(ready),
    .vif_data(data), .vif_sop(sop), .vif_eop(eop), .vif_empty(empty),
    .vif_fcs_valid(fcs_valid), .vif_crc_ok(crc_ok), .vif_link_up(link_up),
    .vif_crc_error(crc_err), .vif_fcs_error(fcs_err), .vif_len_error(len_err),
    .vif_framing_error(frm_err), .vif_fec_uncorrectable(fec_unc), .vif_link_state(link_state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  int fcs_pulses = 0, crc_err_pulses = 0, len_err_pulses = 0, ready_low = 0;
  bit count_ready = 0;
  always @(posedge clk) if (rst_n) begin
    if (fcs_valid) fcs_pulses++;
    if (crc_err) crc_err_pulses++;
    if (len_err) len_err_pulses++;
    if (count_ready && !ready) ready_low++;
  end

  // frame bytes: 8 preamble/SFD + flen bytes (DA .. FCS)
  bit [7:0] fr [$];
  task automatic build(input int flen, input bit [15:0] etype, input bit bad_fcs = 0);
    bit [31:0] c;
    fr.delete();
    for (int i = 0; i < 7; i++) fr.push_back(8'h55);
    fr.push_back(8'hD5);
    for (int i = 0; i < 12; i++) fr.push_back($urandom);
    fr.push_back(etype[15:8]); fr.push_back(etype[7:0]);
    while (fr.size() < 8 + flen - 4) fr.push_back($urandom);
    c = 32'hFFFF_FFFF;
    for (int i = 8; i < fr.size(); i++) begin
      c ^= fr[i];
      for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    c = ~c;
    if (bad_fcs) c ^= 32'h0100_0000;
    for (int i = 0; i < 4; i++) fr.push_back(c[i*8 +: 8]);
  endtask

  // send fr in 64-byte beats (total must be a multiple of 8); random idle
  // clocks between beats when gaps is set
  task automatic send(input bit gaps = 0);
    int nb;
    nb = (fr.size() + 63) / 64;
    for (int b = 0; b < nb; b++) begin
      int last;
      @(negedge clk);
      last = fr.size() - 64 * b;
      data = {16{$urandom}};
      for (int j = 0; j < 64 && j < last; j++) data[j*8 +: 8] = fr[64*b + j];
      valid = 1'b1; sop = (b == 0); eop = (b == nb - 1);
      be = (b == nb - 1 && last < 64) ? 8'((1 << (last / 8)) - 1) : (eop && $urandom_range(1) ? 8'h00 : 8'hFF);
      @(posedge clk);
      while (ready !== 1'b1) @(posedge clk);
      if (gaps && $urandom_range(1)) begin
        @(negedge clk); valid = 1'b0; sop = 1'b1; eop = 1'b1; be = 8'h01;
      end
    end
    @(negedge clk);
    valid = 1'b0; sop = 1'b0; eop = 1'b0; be = 8'hFF;
  endtask

  int t_state [4];
  int bad, n_good, n_bad, n_short;

  initial begin
    repeat (3) @(negedge clk);
    chk(link_up === 1'b0 && ready === 1'b0 && link_state == 0, "link down and not ready in reset");
    chk(fcs_valid === 1'b0 && crc_err === 1'b0 && fcs_err === 1'b0 && len_err === 1'b0, "status flags clear in reset");
    rst_n = 1'b1;
    foreach (t_state[i]) t_state[i] = 0;
    while (link_up !== 1'b1 && t_state[0] + t_state[1] + t_state[2] < 100) begin
      @(posedge clk); #1;
      t_state[link_state]++;
    end
    // first sample is one clock after release; DOWN lasts 6 clocks
    chk(t_state[0] == 5 && t_state[1] == 10 && t_state[2] == 10,
        $sformatf("link training: DOWN 6, ANEG 10, TRAIN 10 clocks (%0d+1/%0d/%0d)", t_state[0], t_state[1], t_state[2]));
    chk(ready === 1'b0, "ready one clock after link up");
    @(posedge clk); #1;
    chk(ready === 1'b1, "ready with link up");
    repeat (20) @(posedge clk);
    chk(link_up === 1'b1 && link_state == 3, "link stays up");

    // 2-beat good frame (64-byte minimum + preamble = 72 bytes)
    build(64, 16'h0800);
    send();
    @(negedge clk);
    chk(fcs_pulses == 1 && crc_ok === 1'b1 && crc_err_pulses == 0 && len_err_pulses == 0,
        "64-byte frame over 2 beats (partial BE): crc_ok");
    @(negedge clk);
    chk(fcs_valid === 1'b0 && fcs_pulses == 1, "fcs_valid is a one-clock pulse");

    build(64, 16'h0800, 1);
    send();
    @(negedge clk);
    chk(crc_err_pulses == 1 && crc_ok === 1'b0, "corrupted FCS: crc_error, crc_ok cleared");
    build(56, 16'h0800);
    send();
    @(negedge clk);
    chk(len_err_pulses == 1 && crc_ok === 1'b0, "56-byte frame (under the 64-byte minimum) gives len_error");
    build(48, 16'h0800);
    send();
    @(negedge clk);
    chk(len_err_pulses == 2 && crc_ok === 1'b0, "48-byte frame gives len_error");

    // PAUSE frame: ready low for 4 clocks
    build(64, 16'h8808);
    count_ready = 1;
    send();
    repeat (8) @(negedge clk);
    count_ready = 0;
    chk(ready_low == 4, $sformatf("PAUSE frame drops ready for 4 clocks (%0d)", ready_low));
    chk(crc_ok === 1'b1, "PAUSE frame itself is a good frame");

    // random frames: sizes multiple of 8, random gaps, random corruption
    bad = 0; n_good = 0; n_bad = 0;
    fcs_pulses = 0; crc_err_pulses = 0; len_err_pulses = 0;
    for (int i = 0; i < 40; i++) begin
      int flen;
      bit corrupt;
      flen = 8 * $urandom_range(190, 8);
      corrupt = ($urandom_range(3) == 0);
      build(flen, 16'h0800, corrupt);
      send($urandom_range(1));
      @(negedge clk);
      if (corrupt) begin n_bad++; if (crc_ok !== 1'b0) bad++; end
      else         begin n_good++; if (crc_ok !== 1'b1) bad++; end
    end
    chk(bad == 0 && fcs_pulses == 40 && crc_err_pulses == n_bad,
        "40 random multi-beat frames with gaps: one fcs_valid each, CRC verdict correct");
    chk(len_err_pulses == 0, "no len_error for frames of 64 bytes or more");

    // beat without SOP outside a frame is ignored
    @(negedge clk); valid = 1'b1; sop = 1'b0; eop = 1'b0; data = '1;
    @(negedge clk); valid = 1'b0;
    build(64, 16'h0800);
    send();
    @(negedge clk);
    chk(crc_ok === 1'b1, "stray beat outside a frame does not corrupt the next frame");
    chk(frm_err === 1'b0 && fec_unc === 1'b0 && fcs_err === 1'b0, "framing / FEC / FCS error flags stay low");

    @(negedge clk); rst_n = 1'b0;
    @(negedge clk);
    chk(link_up === 1'b0 && ready === 1'b0 && crc_ok === 1'b0, "reset drops link, ready and crc_ok");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
