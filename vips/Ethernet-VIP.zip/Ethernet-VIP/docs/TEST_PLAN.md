# Ethernet Test Plan（Ethernet-VIP）

> 本文件由 `tools/gen_test_plans.py` 依該 VIP 目錄內的實際產物自動產生，作為驗證規劃與狀態追蹤之用。

## 1. 概述

| 項目 | 內容 |
|---|---|
| 協定 | Ethernet |
| 家族 | Networking |
| 類型 | UVM VIP |
| 交付目錄 | `Ethernet-VIP/` |
| 目前 L1b 狀態 | PASS(functional) |

## 2. DUT / 待測對象

- `net_dut`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）
- `net_fc_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）
- `net_mac_model`（行為級 model，供 open-toolchain smoke 與 functional smoke 使用）

## 3. 驗證環境

- UVM 環境：agent（driver/monitor/sequencer）、env（scoreboard/checker/coverage）、base test
- 介面 + clocking block（`drv_cb`/`mon_cb`）與 modport
- SVA 協定檢查器（concurrent assertions，見第 5 節）
- functional smoke：`tb/smoke_func_tb.sv`（self-checking，輸出 `FUNC_PASS`）

## 4. 測試項目

### 4.1 Functional smoke（現狀：PASS(functional)）

| ID | 檢查項目 | 通過準則 |
|---|---|---|
| FS-01 | ready low out of reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-02 | link down out of reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-03 | flags quiet out of reset | 檢查成立，`FUNC_PASS` 輸出 |
| FS-04 | link came up after training | 檢查成立，`FUNC_PASS` 輸出 |
| FS-05 | passed through autonegotiation | 檢查成立，`FUNC_PASS` 輸出 |
| FS-06 | passed through training | 檢查成立，`FUNC_PASS` 輸出 |
| FS-07 | ready high with link up | 檢查成立，`FUNC_PASS` 輸出 |
| FS-08 | fcs_valid strobe at end of frame | 檢查成立，`FUNC_PASS` 輸出 |
| FS-09 | good frame CRC accepted | 檢查成立，`FUNC_PASS` 輸出 |
| FS-10 | no error flags on good frame | 檢查成立，`FUNC_PASS` 輸出 |
| FS-11 | no pause for ethertype 0x0800 | 檢查成立，`FUNC_PASS` 輸出 |
| FS-12 | pause frame still CRC-valid | 檢查成立，`FUNC_PASS` 輸出 |
| FS-13 | pause frame dropped ready for 4 cycles | 檢查成立，`FUNC_PASS` 輸出 |
| FS-14 | fcs_valid on short frame | 檢查成立，`FUNC_PASS` 輸出 |
| FS-15 | short frame raised len_error | 檢查成立，`FUNC_PASS` 輸出 |
| FS-16 | short frame not CRC-ok | 檢查成立，`FUNC_PASS` 輸出 |
| FS-17 | fcs_valid on bad frame | 檢查成立，`FUNC_PASS` 輸出 |
| FS-18 | corrupted FCS raised crc_error | 檢查成立，`FUNC_PASS` 輸出 |
| FS-19 | bad frame not CRC-ok | 檢查成立，`FUNC_PASS` 輸出 |

### 4.2 規劃測試（後續輪次）

| ID | 測試項目 |
|---|---|
| PT-01 | Agent reset and first-transaction bring-up |
| PT-02 | Constrained-random sequence sweep (base sequence extended) |
| PT-03 | Error injection and protocol-violation response |
| PT-04 | Backpressure / wait-state interaction |
| PT-05 | End-to-end scoreboard matching (exp vs obs streams) |
| PT-06 | Coverage closure toward the self-served COV_GOAL=100 checklist |

## 5. 覆蓋與檢查

- （本 VIP 無獨立 SVA/coverage 檔案，覆蓋由 directed tb 之通過/失敗判定承擔。）

## 6. 品質閘

```bash
python3 tools/elab_scan.py vips/Ethernet-VIP      # L1a（pyslang + UVM 1.2）
python3 smoke/flatten.py Ethernet-VIP && python3 smoke/smoke_run.py Ethernet-VIP   # L1b
```
- L1a 期望：`ELAB_ERRORS=0`
- L1b 期望：`SMOKE_PASS`（functional smoke 的 VIP 期望 `smoke_func_tb:PASS`）

## 7. 已知限制與備註

- 512-bit data bus = 64B/beat，`be[7:0]` 每 bit 控 8-byte lane。
- functional smoke 已覆蓋 link training / FCS / pause / len_error / crc_error。

---
*文件版本：v1.7.5 自動產生*
