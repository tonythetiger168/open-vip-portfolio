// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_ethernet_800g_test.sv -- Ethernet 800G test
`ifndef NET_ETHERNET_800G_TEST_SV
`define NET_ETHERNET_800G_TEST_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_ethernet_800g_test extends net_base_test;
  `uvm_component_utils(net_ethernet_800g_test)

  function new(string name = "net_ethernet_800g_test", uvm_component parent = null);
    super.new(name, parent);
    protocol       = NET_ETH_800G;
    vif_name       = "eth_800g_vif";
    bytes_per_beat = 64;
    num_frames     = 12;
  endfunction

  virtual task run_phase(uvm_phase phase);
    net_regression_sequence seq;
    phase.raise_objection(this);
    seq = net_regression_sequence::type_id::create("seq");
    seq.num_frames = num_frames;
    seq.target_protocol = protocol;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Alias used by scripts/regression.sh test-name list
class net_eth_800g_test extends net_ethernet_800g_test;
  `uvm_component_utils(net_eth_800g_test)
  function new(string name = "net_eth_800g_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
