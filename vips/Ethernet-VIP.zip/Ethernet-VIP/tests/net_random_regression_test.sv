// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_random_regression_test.sv -- Random regression test
`ifndef NET_RANDOM_REGRESSION_TEST_SV
`define NET_RANDOM_REGRESSION_TEST_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_random_regression_test extends net_base_test;
  `uvm_component_utils(net_random_regression_test)

  function new(string name = "net_random_regression_test", uvm_component parent = null);
    super.new(name, parent);
    protocol       = NET_ETH_400G;
    vif_name       = "eth_400g_vif";
    bytes_per_beat = 64;
    num_frames     = 32;
  endfunction

  virtual task run_phase(uvm_phase phase);
    net_regression_sequence seq;
    phase.raise_objection(this);
    seq = net_regression_sequence::type_id::create("seq");
    seq.num_frames = num_frames;
    seq.target_protocol = protocol;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Alias used by scripts/regression.sh test-name list
class net_rand_reg_test extends net_random_regression_test;
  `uvm_component_utils(net_rand_reg_test)
  function new(string name = "net_rand_reg_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
