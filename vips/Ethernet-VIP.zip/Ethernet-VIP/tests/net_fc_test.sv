// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// net_fc_test.sv -- Fibre Channel test
`ifndef NET_FC_TEST_SV
`define NET_FC_TEST_SV

import uvm_pkg::*;
`include "uvm_macros.svh"
import net_vip_pkg::*;

class net_fc_test extends net_base_test;
  `uvm_component_utils(net_fc_test)

  function new(string name = "net_fc_test", uvm_component parent = null);
    super.new(name, parent);
    protocol       = NET_FC;
    vif_name       = "fc_vif";
    bytes_per_beat = 32;
    num_frames     = 16;
  endfunction

  virtual task run_phase(uvm_phase phase);
    net_regression_sequence seq;
    phase.raise_objection(this);
    seq = net_regression_sequence::type_id::create("seq");
    seq.num_frames = num_frames;
    seq.target_protocol = protocol;
    seq.start(env.agt.sqr);
    phase.drop_objection(this);
  endtask
endclass

// Alias used by scripts/regression.sh test-name list
class net_fc_cls3_test extends net_fc_test;
  `uvm_component_utils(net_fc_cls3_test)
  function new(string name = "net_fc_cls3_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
`endif
