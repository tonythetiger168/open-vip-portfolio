// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_emmc_tb.sv -- self-checking functional test for the eMMC device model
// (emmc_device_dut in tb_top.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py eMMC-VIP
//
// Model contract (from tb_top.sv):
//   * a command is 48 bits on cmd, MSB first, one per clock with cmd_valid:
//     start 0, transmission 1, index[5:0], argument[31:0], CRC7 (x^7+x^3+1),
//     end 1. A burst of any other length is ignored.
//   * responses are shifted out on resp with resp_valid: 48-bit R1/R1b/R3
//     {0, 0, index, status/OCR, CRC7, 1} (R3 index 0x3F) and 136-bit R2 (CID).
//     R1 status: ADDRESS_OUT_OF_RANGE bit 31, COM_CRC_ERROR bit 23,
//     ILLEGAL_COMMAND bit 22, CURRENT_STATE bits 12:9.
//   * CMD0 reset (no response), CMD1/CMD41 (after CMD55) R3 with OCR
//     C0FF8000, CMD2 R2 CID, CMD3 sets RCA -> stby, CMD7 -> tran, CMD13 R1.
//   * CMD17/18 read one 512-byte block at block address arg (rd_data/
//     rd_valid), CMD8 returns EXT_CSD (byte i = i); unwritten memory holds
//     (address[7:0] ^ 0xA5). Block address >= 2048 is out of range.
//   * CMD24/25 write: 512 data bytes then one XOR checksum byte; a bad
//     checksum sets err and clears data_crc_ok. Then busy for 32 clocks.
//   * CMD6 busy 32 clocks; CMD38 erases blocks 0-15 to 0xFF, busy 64 clocks.
//   * unknown indices, CMD41 without CMD55, bad CRC/start/transmission bits
//     set the matching status bits and err.
// The command CRC7 covers {start 0, transmission 1, index, argument};
// response CRCs cover {0, 0, index, status}. Every R1 carries the card
// status with CURRENT_STATE in bits 12:9. R2 is {0, 0, 111111,
// CID[127:1]} with the CID's CRC7 over [127:8] in [7:1].

module func_emmc_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam bit [3:0] CS_IDLE = 0, CS_READY = 1, CS_IDENT = 2, CS_STBY = 3, CS_TRAN = 4, CS_PRG = 7;
  int checks = 0, fails = 0, xfails = 0;

  logic       clk = 1'b0, rst_n = 1'b0, cmd = 1'b1, cmd_valid = 1'b0, dvalid = 1'b0;
  logic [7:0] data = '0;
  wire        resp, resp_valid, busy, rd_valid, card_busy, crc_ok, err, ready, app_cmd;
  wire  [7:0] rd_data;
  wire  [3:0] card_state;
  wire  [2:0] resp_type, status, pwr;

  always #5 clk = ~clk;

  emmc_device_dut u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_cmd(cmd), .vif_cmd_valid(cmd_valid), .vif_data(data),
    .vif_data_valid(dvalid), .vif_resp(resp), .vif_resp_valid(resp_valid), .vif_busy(busy),
    .vif_rd_data(rd_data), .vif_rd_valid(rd_valid), .vif_card_busy(card_busy),
    .vif_data_crc_ok(crc_ok), .vif_card_state(card_state), .vif_resp_type(resp_type),
    .vif_err(err), .vif_status(status), .vif_power_state(pwr), .vif_ready(ready), .vif_app_cmd(app_cmd)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // CRC7, polynomial x^7 + x^3 + 1, over the first 40 bits of a frame
  function automatic bit [6:0] crc7(input bit [39:0] s);
    bit [6:0] c = 0;
    for (int b = 39; b >= 0; b--) begin
      bit fb = c[6] ^ s[b];
      c = c << 1;
      if (fb) c ^= 7'h09;
    end
    return c;
  endfunction

  function automatic bit [6:0] crc7r2(input bit [119:0] s);
    bit [6:0] c = 0;
    for (int b = 119; b >= 0; b--) begin
      bit fb = c[6] ^ s[b];
      c = c << 1;
      if (fb) c ^= 7'h09;
    end
    return c;
  endfunction

  // device -> host capture
  bit         rbits[$];
  logic [7:0] rd[$];
  int         err_seen, busy_len, cbusy_bad = 0;
  always @(posedge clk) if (rst_n) begin
    if (resp_valid === 1'b1) rbits.push_back(resp);
    if (rd_valid === 1'b1) rd.push_back(rd_data);
    if (err === 1'b1) err_seen = 1;
    if (busy === 1'b1) busy_len++;
    if (rst_n && card_busy !== busy) cbusy_bad++;
  end

  task automatic send_cmd(input [5:0] idx, input [31:0] arg, input int nbits = 48,
                          input [47:0] xor_mask = 0);
    bit [47:0] f;
    f = {2'b01, idx, arg, crc7({2'b01, idx, arg}), 1'b1} ^ xor_mask;
    rbits.delete(); rd.delete(); err_seen = 0; busy_len = 0;
    for (int i = 47; i >= 48 - nbits; i--) begin
      @(negedge clk); cmd_valid = 1; cmd = f[i];
    end
    @(negedge clk); cmd_valid = 0; cmd = 1;
  endtask

  task automatic wait_idle(input int max = 3000);
    int t = 0;
    @(negedge clk); @(negedge clk);
    while (!(u_dut.st == 0) && t < max) begin @(negedge clk); t++; end
    repeat (2) @(negedge clk);
  endtask

  function automatic bit [47:0] r48();
    bit [47:0] r = '0;
    for (int i = 0; i < 48 && i < rbits.size(); i++) r[47 - i] = rbits[i];
    return r;
  endfunction

  // response is a well-formed R1 for index idx; returns its status
  bit [31:0] rstat;
  function automatic bit r1_ok(input [5:0] idx);
    bit [47:0] r = r48();
    rstat = r[39:8];
    return rbits.size() == 48 && r[47:46] == 2'b00 && r[45:40] == idx && r[0] == 1'b1 &&
           r[7:1] == crc7(r[47:8]);
  endfunction

  task automatic cmd_wait(input [5:0] idx, input [31:0] arg);
    send_cmd(idx, arg); wait_idle();
  endtask

  bit ok;
  logic [7:0] blk[512];
  logic [7:0] xs;

  initial begin
    chk(crc7({2'b01, 6'd0, 32'h0}) == 7'h4A && crc7({2'b01, 6'd17, 32'h0}) == 7'h2A &&
        crc7({2'b01, 6'd8, 32'h1AA}) == 7'h43, "CRC7 reference matches the known command CRCs");
    repeat (2) @(negedge clk);
    rst_n = 1;
    repeat (2) @(negedge clk);
    chk(ready && card_state == CS_IDLE && pwr == 3'b001, "ready, idle state after reset");

    // command CRC as specified
    cmd_wait(13, 0);
    chk(r1_ok(13), "CMD13 answered with R1");
    chk(!rstat[23] && !err_seen, "command with the specified CRC7 is accepted");

    // identification
    cmd_wait(0, 0);
    chk(rbits.size() == 0 && card_state == CS_IDLE, "CMD0: no response, idle");
    cmd_wait(1, 32'h40FF_8000);
    begin
      bit [47:0] r;
      r = r48();
      chk(rbits.size() == 48 && r[47:46] == 2'b00 && r[45:40] == 6'h3F && r[39:8] == 32'hC0FF_8000,
          "CMD1: R3 with OCR C0FF8000 (busy bit set)");
    end
    chk(card_state == CS_READY, "CMD1 moves to ready");
    cmd_wait(2, 0);
    chk(rbits.size() == 136, "CMD2: 136-bit R2");
    begin
      bit [135:0] r = '0;
      foreach (rbits[i]) r[135 - i] = rbits[i];
      chk(r[127:8] == 120'h1B534D_00010203_405A5A5A_202609, "R2 carries the CID");
      chk(r[7:1] == crc7r2(r[127:8]) && r[0], "R2 ends with the CID CRC7 and the end bit");
      chk(r[135:128] == 8'b0011_1111, "R2 starts with 0, 0, 111111");
    end
    chk(card_state == CS_IDENT, "CMD2 moves to ident");
    cmd_wait(3, 32'h0002_0000);
    chk(r1_ok(3) && card_state == CS_STBY && u_dut.rca == 16'h0002, "CMD3: R1, RCA 2 assigned, stby");
    cmd_wait(13, 32'h0002_0000);
    chk(r1_ok(13) && rstat[12:9] == CS_STBY && rstat[31:22] == 0, "CMD13: R1 reports stby, no errors");
    cmd_wait(7, 32'h0002_0000);
    chk(r1_ok(7) && card_state == CS_TRAN, "CMD7 selects the card: tran");
    chk(rstat[12:9] == CS_STBY && rstat[15:13] == 0, "CMD7 R1 reports CURRENT_STATE (stby) in bits 12:9");

    // EXT_CSD
    cmd_wait(8, 0);
    ok = r1_ok(8) && rd.size() == 512;
    foreach (rd[i]) if (rd[i] != i[7:0]) ok = 0;
    chk(ok, "CMD8 returns the 512-byte EXT_CSD");

    // read an unwritten block
    cmd_wait(17, 32'd3);
    ok = r1_ok(17) && rd.size() == 512;
    foreach (rd[i]) if (rd[i] != (((3 * 512 + i) & 8'hFF) ^ 8'hA5)) ok = 0;
    chk(ok, "CMD17 reads block 3 (initial pattern)");
    chk(card_state == CS_TRAN, "back to tran after the read");

    // write a block, then read it back
    xs = 0;
    for (int i = 0; i < 512; i++) begin blk[i] = (i * 13) ^ 8'h3C; xs ^= blk[i]; end
    send_cmd(24, 32'd9);
    while (u_dut.st != 5) @(negedge clk);             // data phase
    @(negedge clk);
    chk(r1_ok(24), "CMD24: R1 before the data phase");
    for (int i = 0; i < 513; i++) begin
      @(negedge clk); dvalid = 1; data = (i < 512) ? blk[i] : xs;
    end
    @(negedge clk); dvalid = 0;
    @(negedge clk);
    chk(busy && card_state == CS_PRG, "programming: busy, prg state");
    wait_idle();
    chk(!err_seen && busy_len >= 30 && busy_len <= 34, $sformatf("good checksum, busy ~32 clocks (%0d)", busy_len));
    chk(card_state == CS_TRAN, "back to tran after programming");
    cmd_wait(17, 32'd9);
    ok = rd.size() == 512;
    foreach (rd[i]) if (rd[i] != blk[i]) ok = 0;
    chk(ok, "written block read back");
    cmd_wait(18, 32'd10);
    chk(rd.size() == 512 && rd[0] == ((10 * 512) & 8'hFF ^ 8'hA5), "neighbouring block untouched");

    // write with a bad checksum
    send_cmd(25, 32'd11);
    while (u_dut.st != 5) @(negedge clk);
    for (int i = 0; i < 513; i++) begin
      @(negedge clk); dvalid = 1; data = (i < 512) ? 8'h00 : 8'h01;
    end
    @(negedge clk); dvalid = 0;
    chk(err === 1'b1 || err_seen, "bad data checksum flags err");
    wait_idle();

    // erase
    cmd_wait(38, 0);
    chk(r1_ok(38) && busy_len == 64, $sformatf("CMD38: R1b, busy for 64 clocks (%0d)", busy_len));
    cmd_wait(17, 32'd9);
    ok = rd.size() == 512;
    foreach (rd[i]) if (rd[i] != 8'hFF) ok = 0;
    chk(ok, "erased block reads 0xFF");
    cmd_wait(17, 32'd16);
    chk(rd.size() == 512 && rd[0] == ((16 * 512) & 8'hFF ^ 8'hA5), "erase stops at block 15");

    // SWITCH
    cmd_wait(6, 32'h03B9_0100);
    chk(r1_ok(6) && busy_len == 32, $sformatf("CMD6: R1b with 32 clocks busy (%0d)", busy_len));

    // errors
    cmd_wait(17, 32'd2048);
    chk(r1_ok(17) && rstat[31] && rd.size() == 0 && err_seen, "read beyond capacity: ADDRESS_OUT_OF_RANGE, no data");
    chk(card_state == CS_TRAN, "rejected read leaves the card in tran (no data state)");
    chk(cbusy_bad == 0, $sformatf("card_busy follows busy on every clock (%0d mismatches)", cbusy_bad));
    cmd_wait(24, 32'd5000);
    chk(r1_ok(24) && rstat[31] && u_dut.st == 0, "write beyond capacity rejected");
    send_cmd(13, 0, 48, 48'h0000_0000_0004); wait_idle();
    chk(r1_ok(13) && rstat[23] && err_seen, "CRC error: COM_CRC_ERROR");
    send_cmd(13, 0, 48, 48'h4000_0000_0000); wait_idle();
    chk(rstat[23], "transmission bit 0 treated as a CRC error");
    cmd_wait(60, 0);
    chk(r1_ok(60) && rstat[22] && err_seen, "unknown CMD60: ILLEGAL_COMMAND");
    cmd_wait(41, 0);
    chk(rstat[22], "ACMD41 without CMD55: ILLEGAL_COMMAND");
    cmd_wait(55, 0);
    chk(r1_ok(55) && !rstat[22] && app_cmd === 1'b1, "CMD55 accepted and sets APP_CMD");
    cmd_wait(41, 32'h40FF_8000);
    chk(!err_seen && r48()[45:40] == 6'h3F && !app_cmd, "ACMD41 after CMD55 accepted, APP_CMD cleared");
    send_cmd(13, 0, 40); wait_idle();
    chk(rbits.size() == 0 && !err_seen, "a 40-bit burst is ignored");

    // CMD0 from tran
    cmd_wait(0, 0);
    chk(card_state == CS_IDLE, "CMD0 returns the card to idle");

    // reset in a read
    cmd_wait(1, 0); cmd_wait(2, 0); cmd_wait(3, 32'h0001_0000); cmd_wait(7, 32'h0001_0000);
    send_cmd(17, 0);
    repeat (100) @(negedge clk);
    rst_n = 0;
    @(negedge clk);
    chk(!rd_valid && !resp_valid && !busy && card_state == CS_IDLE && ready, "reset aborts the read");
    rst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
