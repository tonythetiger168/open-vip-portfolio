# Independent cross-check model (`xchk/`)

`emmc_xchk_tb.sv` checks the open-ip-portfolio `eMMC` RTL (`rtl/eMMC_top.sv`, `rtl/eMMC_apb.sv`)
against an e*MMC device: R1 / R2 / R3, device states, sector addresses, CRC16 data, CRC status and busy, injected device faults. The model is written from JEDEC JESD84 (e*MMC 5.1), not from the RTL, so it
gives a second opinion next to the RTL's own testbench. It is the bench of
`ipcheck/emmc_xchk_tb.sv` in open-vip-portfolio (see `ipcheck/README.md` there for
the full list of checks, the planted faults it catches and the notes it
reports).

Run from the VIP root with Icarus Verilog 12 (Verilator 5.052 with
`--binary --timing` also works):

```
OIP=/path/to/open-ip-portfolio
iverilog -g2012 -I xchk -s emmc_xchk_tb -o xchk.vvp $OIP/rtl/eMMC_top.sv $OIP/rtl/eMMC_apb.sv xchk/emmc_xchk_tb.sv && vvp -n xchk.vvp
```

Pass: a line `XCHK_PASS checks=N`. Any `[FAIL]` line fails the run;
`[NOTE]` lines report differences from the specification that do not
change the result. `-DSEED=<n>` changes the random stimulus.
