// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// memory_coverage_pkg.sv -- 8-protocol functional coverage package
`ifndef MEMORY_COVERAGE_PKG_SV
`define MEMORY_COVERAGE_PKG_SV
package memory_coverage_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import ddr_pkg::*; import lpddr_pkg::*; import hbm_pkg::*;
  import ufs_pkg::*; import unipro_pkg::*; import emmc_pkg::*;
  import onfi_pkg::*; import sd_pkg::*;

  class ddr_coverage extends uvm_component;
    `uvm_component_utils(ddr_coverage)
    uvm_analysis_imp #(ddr_seq_item, ddr_coverage) analysis_export;
    ddr_seq_item item;
    real coverage_target = 100.0;
    covergroup ddr_cg;
      option.per_instance = 1; option.goal = 100;
      cmd: coverpoint item.cmd_type;
      bank: coverpoint item.bank { bins b[8] = {[0:7]}; }
      bank_group: coverpoint item.bank_group { bins bg[4] = {[0:3]}; }
      burst_len: coverpoint item.burst_len { bins bl[4] = {8, 16, 32, 64}; }
      cmd_x_bank: cross cmd, bank;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      ddr_cg = new();
    endfunction
    virtual function void write(ddr_seq_item t); item = t; ddr_cg.sample(); endfunction
    function real get_coverage(); return ddr_cg.get_coverage(); endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target) `uvm_error(get_type_name(), "Coverage < 100%");
    endfunction
  endclass

  class lpddr_coverage extends uvm_component;
    `uvm_component_utils(lpddr_coverage)
    uvm_analysis_imp #(lpddr_seq_item, lpddr_coverage) analysis_export;
    lpddr_seq_item item;
    real coverage_target = 100.0;
    covergroup lpddr_cg;
      option.per_instance = 1; option.goal = 100;
      cmd: coverpoint item.cmd_type;
      bank: coverpoint item.bank { bins b[8] = {[0:7]}; }
      cmd_x_bank: cross cmd, bank;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      lpddr_cg = new();
    endfunction
    virtual function void write(lpddr_seq_item t); item = t; lpddr_cg.sample(); endfunction
    function real get_coverage(); return lpddr_cg.get_coverage(); endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target) `uvm_error(get_type_name(), "Coverage < 100%");
    endfunction
  endclass

  class hbm_coverage extends uvm_component;
    `uvm_component_utils(hbm_coverage)
    uvm_analysis_imp #(hbm_seq_item, hbm_coverage) analysis_export;
    hbm_seq_item item;
    real coverage_target = 100.0;
    covergroup hbm_cg;
      option.per_instance = 1; option.goal = 100;
      cmd: coverpoint item.cmd_type;
      cid: coverpoint item.cid { bins ch[8] = {[0:7]}; }
      bank: coverpoint item.bank { bins b[4] = {[0:3]}; }
      cmd_x_cid: cross cmd, cid;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      hbm_cg = new();
    endfunction
    virtual function void write(hbm_seq_item t); item = t; hbm_cg.sample(); endfunction
    function real get_coverage(); return hbm_cg.get_coverage(); endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target) `uvm_error(get_type_name(), "Coverage < 100%");
    endfunction
  endclass

  // UFS: 3 covergroups (protocol config / UPIU exchange FSM transitions / data), with crosses
  class ufs_coverage extends uvm_component;
    `uvm_component_utils(ufs_coverage)
    uvm_analysis_imp #(ufs_seq_item, ufs_coverage) analysis_export;
    ufs_seq_item item;
    real coverage_target = 100.0;
    // (1) protocol configuration coverage
    covergroup ufs_cg;
      option.per_instance = 1; option.goal = 100;
      upiu: coverpoint item.upiu_type {
        bins host[] = {ufs_seq_item::COMMAND, ufs_seq_item::TASK_MGT,
                       ufs_seq_item::QUERY_REQ, ufs_seq_item::NOP_OUT};
        bins dev[]  = {ufs_seq_item::RESPONSE, ufs_seq_item::DATA_IN,
                       ufs_seq_item::READY_XFER, ufs_seq_item::QUERY_RSP};
      }
      lun: coverpoint item.lun { bins l[8] = {[0:7]}; }
      opcode: coverpoint item.opcode {
        bins tur   = {SCSI_TUR};  bins sense = {SCSI_REQ_SENSE};
        bins inq   = {SCSI_INQUIRY};
        bins rd10  = {SCSI_READ10}; bins wr10 = {SCSI_WRITE10};
      }
      cmd_x_lun: cross upiu, lun {
        bins cmd_lun = binsof(upiu) intersect {ufs_seq_item::COMMAND};
      }
    endgroup
    // (2) UPIU exchange FSM transition coverage (observed transaction stream)
    covergroup ufs_fsm_cg;
      option.per_instance = 1; option.goal = 100;
      trans: coverpoint item.upiu_type {
        bins cmd_rtt     = (ufs_seq_item::COMMAND => ufs_seq_item::READY_XFER);
        bins rtt_rsp     = (ufs_seq_item::READY_XFER => ufs_seq_item::RESPONSE);
        bins cmd_din     = (ufs_seq_item::COMMAND => ufs_seq_item::DATA_IN);
        bins din_rsp     = (ufs_seq_item::DATA_IN => ufs_seq_item::RESPONSE);
        bins rsp_cmd     = (ufs_seq_item::RESPONSE => ufs_seq_item::COMMAND);
        bins qry_qrsp    = (ufs_seq_item::QUERY_REQ => ufs_seq_item::QUERY_RSP);
        bins tm_rsp      = (ufs_seq_item::TASK_MGT => ufs_seq_item::TASK_MGT_RSP);
      }
      lun_t: coverpoint item.lun { bins lo = {[0:3]}; bins hi = {[4:7]}; }
      trans_x_lun: cross trans, lun_t;
    endgroup
    // (3) data-phase coverage
    covergroup ufs_data_cg;
      option.per_instance = 1; option.goal = 100;
      dlen: coverpoint item.data_length {
        bins l512 = {512}; bins l1k = {1024}; bins l2k = {2048};
        bins l4k  = {4096}; bins l8k = {8192}; bins other = default;
      }
      lba: coverpoint item.lba {
        bins low  = {[0:511]}; bins mid = {[512:1535]}; bins high = {[1536:$]};
      }
      status: coverpoint item.status {
        bins good  = {UFS_ST_GOOD}; bins check = {UFS_ST_CHECK}; bins other = default;
      }
      len_x_lba: cross dlen, lba;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      ufs_cg = new();
      ufs_fsm_cg = new();
      ufs_data_cg = new();
    endfunction
    virtual function void write(ufs_seq_item t);
      item = t;
      ufs_cg.sample();
      ufs_fsm_cg.sample();
      ufs_data_cg.sample();
    endfunction
    function real get_coverage();
      return (ufs_cg.get_coverage() + ufs_fsm_cg.get_coverage() + ufs_data_cg.get_coverage()) / 3.0;
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target) `uvm_error(get_type_name(), "Coverage < 100%");
    endfunction
  endclass

  // UniPro: 3 covergroups (protocol config / msg FSM transitions / credit), with crosses
  class unipro_coverage extends uvm_component;
    `uvm_component_utils(unipro_coverage)
    uvm_analysis_imp #(unipro_seq_item, unipro_coverage) analysis_export;
    unipro_seq_item item;
    real coverage_target = 100.0;
    covergroup unipro_cg;
      option.per_instance = 1; option.goal = 100;
      msg: coverpoint item.msg_type;
      cport: coverpoint item.cportid { bins cp[8] = {[0:31]}; }
      msg_x_cport: cross msg, cport;
    endgroup
    covergroup unipro_fsm_cg;
      option.per_instance = 1; option.goal = 100;
      msg_trans: coverpoint item.msg_type {
        bins connect_seq = (unipro_seq_item::CONNECT => unipro_seq_item::DATA => unipro_seq_item::DISCONNECT);
        bins data_burst  = (unipro_seq_item::DATA [*4]);
        bins credit_seq  = (unipro_seq_item::CREDIT => unipro_seq_item::DATA);
      }
      tc: coverpoint item.tc { bins tc0 = {0}; bins tc1 = {1}; bins tcX = default; }
      msg_x_tc: cross msg_trans, tc;
    endgroup
    covergroup unipro_credit_cg;
      option.per_instance = 1; option.goal = 100;
      cred: coverpoint item.tx_cred { bins zero = {0}; bins low = {[1:127]}; bins high = {[128:255]}; }
      msg: coverpoint item.msg_type;
      cred_x_msg: cross cred, msg;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      unipro_cg = new();
      unipro_fsm_cg = new();
      unipro_credit_cg = new();
    endfunction
    virtual function void write(unipro_seq_item t);
      item = t;
      unipro_cg.sample();
      unipro_fsm_cg.sample();
      unipro_credit_cg.sample();
    endfunction
    function real get_coverage();
      return (unipro_cg.get_coverage() + unipro_fsm_cg.get_coverage() + unipro_credit_cg.get_coverage()) / 3.0;
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target) `uvm_error(get_type_name(), "Coverage < 100%");
    endfunction
  endclass
  // eMMC: 3 covergroups (protocol config / command-sequence FSM / data+status), with crosses
  class emmc_coverage extends uvm_component;
    `uvm_component_utils(emmc_coverage)
    uvm_analysis_imp #(emmc_seq_item, emmc_coverage) analysis_export;
    emmc_seq_item item;
    real coverage_target = 100.0;
    // (1) protocol configuration coverage
    covergroup emmc_cg;
      option.per_instance = 1; option.goal = 100;
      cmd: coverpoint item.cmd_type;
      bw: coverpoint item.bus_width { bins width[3] = {[0:2]}; }
      cmd_x_bw: cross cmd, bw {
        bins data_bw = binsof(cmd) intersect {emmc_seq_item::READ_SINGLE, emmc_seq_item::WRITE_SINGLE,
                                              emmc_seq_item::READ_MULTIPLE, emmc_seq_item::WRITE_MULTIPLE};
      }
    endgroup
    // (2) command-sequence FSM transition coverage (host command stream only)
    covergroup emmc_fsm_cg;
      option.per_instance = 1; option.goal = 100;
      seq_t: coverpoint item.cmd_type {
        bins init_chain = (emmc_seq_item::GO_IDLE => emmc_seq_item::SEND_OP_COND);
        bins ident      = (emmc_seq_item::ALL_SEND_CID => emmc_seq_item::SET_REL_ADDR);
        bins acmd       = (emmc_seq_item::APP_CMD => emmc_seq_item::SD_SEND_OP);
        bins wr_status  = (emmc_seq_item::WRITE_SINGLE => emmc_seq_item::SEND_STATUS);
        bins rd_wr      = (emmc_seq_item::READ_SINGLE => emmc_seq_item::WRITE_SINGLE);
        bins erase_grp  = (emmc_seq_item::ERASE_GRP_START => emmc_seq_item::ERASE_GRP_END);
      }
      bw_t: coverpoint item.bus_width { bins b1 = {0}; bins b4 = {1}; bins b8 = {2}; }
      seq_x_bw: cross seq_t, bw_t;
    endgroup
    // (3) data/status coverage
    covergroup emmc_data_cg;
      option.per_instance = 1; option.goal = 100;
      blen: coverpoint item.block_len {
        bins b512 = {512}; bins b1k = {1024}; bins b2k = {2048}; bins b4k = {4096};
      }
      addr: coverpoint item.cmd_arg {
        bins low  = {[0:511]}; bins mid = {[512:1535]}; bins high = {[1536:2047]};
        bins out_of_range = {[2048:$]};
      }
      resp_err: coverpoint item.resp[31] {
        bins ok = {0}; bins addr_err = {1};
      }
      blen_x_addr: cross blen, addr {
        ignore_bins oor = binsof(addr.out_of_range);
      }
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      emmc_cg = new();
      emmc_fsm_cg = new();
      emmc_data_cg = new();
    endfunction
    virtual function void write(emmc_seq_item t);
      item = t;
      emmc_cg.sample();
      if (t.from_host) emmc_fsm_cg.sample();
      if (t.from_host || t.resp_valid) emmc_data_cg.sample();
    endfunction
    function real get_coverage();
      return (emmc_cg.get_coverage() + emmc_fsm_cg.get_coverage() + emmc_data_cg.get_coverage()) / 3.0;
    endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target) `uvm_error(get_type_name(), "Coverage < 100%");
    endfunction
  endclass

  class onfi_coverage extends uvm_component;
    `uvm_component_utils(onfi_coverage)
    uvm_analysis_imp #(onfi_seq_item, onfi_coverage) analysis_export;
    onfi_seq_item item;
    real coverage_target = 100.0;
    covergroup onfi_cg;
      option.per_instance = 1; option.goal = 100;
      cmd: coverpoint item.cmd_type;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      onfi_cg = new();
    endfunction
    virtual function void write(onfi_seq_item t); item = t; onfi_cg.sample(); endfunction
    function real get_coverage(); return onfi_cg.get_coverage(); endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target) `uvm_error(get_type_name(), "Coverage < 100%");
    endfunction
  endclass

  class sd_coverage extends uvm_component;
    `uvm_component_utils(sd_coverage)
    uvm_analysis_imp #(sd_seq_item, sd_coverage) analysis_export;
    sd_seq_item item;
    real coverage_target = 100.0;
    covergroup sd_cg;
      option.per_instance = 1; option.goal = 100;
      cmd: coverpoint item.cmd_type;
      bw: coverpoint item.bus_width { bins width[3] = {[0:2]}; }
      cmd_x_bw: cross cmd, bw;
    endgroup
    function new(string name, uvm_component parent);
      super.new(name, parent);
      analysis_export = new("analysis_export", this);
      sd_cg = new();
    endfunction
    virtual function void write(sd_seq_item t); item = t; sd_cg.sample(); endfunction
    function real get_coverage(); return sd_cg.get_coverage(); endfunction
    function void report_phase(uvm_phase phase);
      real cov = get_coverage();
      `uvm_info(get_type_name(), $sformatf("Coverage: %0.2f%%", cov), UVM_LOW)
      if (cov < coverage_target) `uvm_error(get_type_name(), "Coverage < 100%");
    endfunction
  endclass

  class memory_coverage_report_checker extends uvm_component;
    `uvm_component_utils(memory_coverage_report_checker)
    ddr_coverage ddr_cov_h; lpddr_coverage lpddr_cov_h; hbm_coverage hbm_cov_h;
    ufs_coverage ufs_cov_h; unipro_coverage unipro_cov_h; emmc_coverage emmc_cov_h;
    onfi_coverage onfi_cov_h; sd_coverage sd_cov_h;
    real overall_target = 100.0;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void report_phase(uvm_phase phase);
      real ddr_cov = 0, lpddr_cov = 0, hbm_cov = 0, ufs_cov = 0, unipro_cov = 0, emmc_cov = 0, onfi_cov = 0, sd_cov = 0;
      int fail_count = 0;
      if (ddr_cov_h != null) ddr_cov = ddr_cov_h.get_coverage(); if (lpddr_cov_h != null) lpddr_cov = lpddr_cov_h.get_coverage();
      if (hbm_cov_h != null) hbm_cov = hbm_cov_h.get_coverage(); if (ufs_cov_h != null) ufs_cov = ufs_cov_h.get_coverage();
      if (unipro_cov_h != null) unipro_cov = unipro_cov_h.get_coverage(); if (emmc_cov_h != null) emmc_cov = emmc_cov_h.get_coverage();
      if (onfi_cov_h != null) onfi_cov = onfi_cov_h.get_coverage(); if (sd_cov_h != null) sd_cov = sd_cov_h.get_coverage();
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), "  MEMORY PROTOCOL COVERAGE FINAL REPORT", UVM_NONE)
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("DDR    Coverage: %6.2f%%", ddr_cov), UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("LPDDR  Coverage: %6.2f%%", lpddr_cov), UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("HBM    Coverage: %6.2f%%", hbm_cov), UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("UFS    Coverage: %6.2f%%", ufs_cov), UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("UniPro Coverage: %6.2f%%", unipro_cov), UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("eMMC   Coverage: %6.2f%%", emmc_cov), UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("ONFI   Coverage: %6.2f%%", onfi_cov), UVM_NONE)
      `uvm_info(get_type_name(), $sformatf("SD     Coverage: %6.2f%%", sd_cov), UVM_NONE)
      if (ddr_cov < overall_target) fail_count++;
      if (lpddr_cov < overall_target) fail_count++;
      if (hbm_cov < overall_target) fail_count++;
      if (ufs_cov < overall_target) fail_count++;
      if (unipro_cov < overall_target) fail_count++;
      if (emmc_cov < overall_target) fail_count++;
      if (onfi_cov < overall_target) fail_count++;
      if (sd_cov < overall_target) fail_count++;
      if (fail_count > 0)
        `uvm_error(get_type_name(), $sformatf("%0d protocol(s) below coverage target", fail_count))
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
    endfunction
  endclass
endpackage : memory_coverage_pkg
`endif
