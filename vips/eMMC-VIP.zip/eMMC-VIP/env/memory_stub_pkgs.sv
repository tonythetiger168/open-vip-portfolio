// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// memory_stub_pkgs.sv
// Minimal stub packages for external protocols referenced by the shared
// memory_env_pkg / memory_coverage_pkg / memory_test_pkg but whose VIP is
// not part of this tree. Each stub preserves the API surface used by the
// shared code: <p>_cfg, <p>_seq_item, <p>_agent (with mon.item_collected_port,
// drv.drv_ap and sqr) and the coverage/regression sequences.

`ifndef MEMORY_STUB_PKGS_SV
`define MEMORY_STUB_PKGS_SV

`include "uvm_macros.svh"

package ddr_pkg;
  import uvm_pkg::*;
  class ddr_seq_item extends uvm_sequence_item;
    `uvm_object_utils(ddr_seq_item)
    rand bit [3:0] cmd_type;
    rand bit [2:0] bank;
    rand bit [1:0] bank_group;
    rand bit [7:0] burst_len;
    function new(string name = "ddr_seq_item"); super.new(name); endfunction
  endclass
  class ddr_cfg extends uvm_object;
    `uvm_object_utils(ddr_cfg)
    function new(string name = "ddr_cfg"); super.new(name); endfunction
  endclass
  class ddr_driver extends uvm_driver #(ddr_seq_item);
    `uvm_component_utils(ddr_driver)
    uvm_analysis_port #(ddr_seq_item) drv_ap;
    function new(string name = "ddr_driver", uvm_component parent = null);
      super.new(name, parent); drv_ap = new("drv_ap", this);
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        ddr_seq_item item;
        seq_item_port.get_next_item(item);
        drv_ap.write(item);
        seq_item_port.item_done();
      end
    endtask
  endclass
  class ddr_monitor extends uvm_monitor;
    `uvm_component_utils(ddr_monitor)
    uvm_analysis_port #(ddr_seq_item) item_collected_port;
    function new(string name = "ddr_monitor", uvm_component parent = null);
      super.new(name, parent); item_collected_port = new("item_collected_port", this);
    endfunction
  endclass
  class ddr_agent extends uvm_agent;
    `uvm_component_utils(ddr_agent)
    uvm_sequencer #(ddr_seq_item) sqr;
    ddr_driver  drv;
    ddr_monitor mon;
    function new(string name = "ddr_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = ddr_monitor::type_id::create("mon", this);
      sqr = uvm_sequencer#(ddr_seq_item)::type_id::create("sqr", this);
      drv = ddr_driver::type_id::create("drv", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass
  class ddr_base_seq extends uvm_sequence #(ddr_seq_item);
    `uvm_object_utils(ddr_base_seq)
    int num_trans = 10;
    function new(string name = "ddr_base_seq"); super.new(name); endfunction
    virtual task body();
      repeat (num_trans) begin
        ddr_seq_item item = ddr_seq_item::type_id::create("item");
        start_item(item);
        void'(item.randomize());
        finish_item(item);
      end
    endtask
  endclass
  class ddr_rw_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_rw_seq)
    function new(string name = "ddr_rw_seq"); super.new(name); endfunction
  endclass
  class ddr_cov_cmd_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_cmd_seq)
    function new(string name = "ddr_cov_cmd_seq"); super.new(name); endfunction
  endclass
  class ddr_cov_bank_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_bank_seq)
    function new(string name = "ddr_cov_bank_seq"); super.new(name); endfunction
  endclass
  class ddr_cov_bl_seq extends ddr_base_seq;
    `uvm_object_utils(ddr_cov_bl_seq)
    function new(string name = "ddr_cov_bl_seq"); super.new(name); endfunction
  endclass
endpackage

package lpddr_pkg;
  import uvm_pkg::*;
  class lpddr_seq_item extends uvm_sequence_item;
    `uvm_object_utils(lpddr_seq_item)
    rand bit [3:0] cmd_type;
    rand bit [2:0] bank;
    function new(string name = "lpddr_seq_item"); super.new(name); endfunction
  endclass
  class lpddr_cfg extends uvm_object;
    `uvm_object_utils(lpddr_cfg)
    function new(string name = "lpddr_cfg"); super.new(name); endfunction
  endclass
  class lpddr_driver extends uvm_driver #(lpddr_seq_item);
    `uvm_component_utils(lpddr_driver)
    uvm_analysis_port #(lpddr_seq_item) drv_ap;
    function new(string name = "lpddr_driver", uvm_component parent = null);
      super.new(name, parent); drv_ap = new("drv_ap", this);
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        lpddr_seq_item item;
        seq_item_port.get_next_item(item);
        drv_ap.write(item);
        seq_item_port.item_done();
      end
    endtask
  endclass
  class lpddr_monitor extends uvm_monitor;
    `uvm_component_utils(lpddr_monitor)
    uvm_analysis_port #(lpddr_seq_item) item_collected_port;
    function new(string name = "lpddr_monitor", uvm_component parent = null);
      super.new(name, parent); item_collected_port = new("item_collected_port", this);
    endfunction
  endclass
  class lpddr_agent extends uvm_agent;
    `uvm_component_utils(lpddr_agent)
    uvm_sequencer #(lpddr_seq_item) sqr;
    lpddr_driver  drv;
    lpddr_monitor mon;
    function new(string name = "lpddr_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = lpddr_monitor::type_id::create("mon", this);
      sqr = uvm_sequencer#(lpddr_seq_item)::type_id::create("sqr", this);
      drv = lpddr_driver::type_id::create("drv", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass
  class lpddr_base_seq extends uvm_sequence #(lpddr_seq_item);
    `uvm_object_utils(lpddr_base_seq)
    int num_trans = 10;
    function new(string name = "lpddr_base_seq"); super.new(name); endfunction
    virtual task body();
      repeat (num_trans) begin
        lpddr_seq_item item = lpddr_seq_item::type_id::create("item");
        start_item(item);
        void'(item.randomize());
        finish_item(item);
      end
    endtask
  endclass
  class lpddr_rw_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_rw_seq)
    function new(string name = "lpddr_rw_seq"); super.new(name); endfunction
  endclass
  class lpddr_cov_cmd_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_cov_cmd_seq)
    function new(string name = "lpddr_cov_cmd_seq"); super.new(name); endfunction
  endclass
  class lpddr_cov_bank_seq extends lpddr_base_seq;
    `uvm_object_utils(lpddr_cov_bank_seq)
    function new(string name = "lpddr_cov_bank_seq"); super.new(name); endfunction
  endclass
endpackage

package hbm_pkg;
  import uvm_pkg::*;
  class hbm_seq_item extends uvm_sequence_item;
    `uvm_object_utils(hbm_seq_item)
    rand bit [3:0] cmd_type;
    rand bit [2:0] cid;
    rand bit [1:0] bank;
    function new(string name = "hbm_seq_item"); super.new(name); endfunction
  endclass
  class hbm_cfg extends uvm_object;
    `uvm_object_utils(hbm_cfg)
    function new(string name = "hbm_cfg"); super.new(name); endfunction
  endclass
  class hbm_driver extends uvm_driver #(hbm_seq_item);
    `uvm_component_utils(hbm_driver)
    uvm_analysis_port #(hbm_seq_item) drv_ap;
    function new(string name = "hbm_driver", uvm_component parent = null);
      super.new(name, parent); drv_ap = new("drv_ap", this);
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        hbm_seq_item item;
        seq_item_port.get_next_item(item);
        drv_ap.write(item);
        seq_item_port.item_done();
      end
    endtask
  endclass
  class hbm_monitor extends uvm_monitor;
    `uvm_component_utils(hbm_monitor)
    uvm_analysis_port #(hbm_seq_item) item_collected_port;
    function new(string name = "hbm_monitor", uvm_component parent = null);
      super.new(name, parent); item_collected_port = new("item_collected_port", this);
    endfunction
  endclass
  class hbm_agent extends uvm_agent;
    `uvm_component_utils(hbm_agent)
    uvm_sequencer #(hbm_seq_item) sqr;
    hbm_driver  drv;
    hbm_monitor mon;
    function new(string name = "hbm_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = hbm_monitor::type_id::create("mon", this);
      sqr = uvm_sequencer#(hbm_seq_item)::type_id::create("sqr", this);
      drv = hbm_driver::type_id::create("drv", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass
  class hbm_base_seq extends uvm_sequence #(hbm_seq_item);
    `uvm_object_utils(hbm_base_seq)
    int num_trans = 10;
    function new(string name = "hbm_base_seq"); super.new(name); endfunction
    virtual task body();
      repeat (num_trans) begin
        hbm_seq_item item = hbm_seq_item::type_id::create("item");
        start_item(item);
        void'(item.randomize());
        finish_item(item);
      end
    endtask
  endclass
  class hbm_rw_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_rw_seq)
    function new(string name = "hbm_rw_seq"); super.new(name); endfunction
  endclass
  class hbm_cov_cmd_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_cov_cmd_seq)
    function new(string name = "hbm_cov_cmd_seq"); super.new(name); endfunction
  endclass
  class hbm_cov_ch_seq extends hbm_base_seq;
    `uvm_object_utils(hbm_cov_ch_seq)
    function new(string name = "hbm_cov_ch_seq"); super.new(name); endfunction
  endclass
endpackage

package ufs_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  `uvm_analysis_imp_decl(_ufs_exp)
  `uvm_analysis_imp_decl(_ufs_obs)
  // SCSI opcodes carried inside the UFS COMMAND UPIU
  localparam bit [7:0] SCSI_TUR       = 8'h00;
  localparam bit [7:0] SCSI_REQ_SENSE = 8'h03;
  localparam bit [7:0] SCSI_INQUIRY   = 8'h12;
  localparam bit [7:0] SCSI_READ10    = 8'h28;
  localparam bit [7:0] SCSI_WRITE10   = 8'h2A;
  // Response status bytes
  localparam bit [7:0] UFS_ST_GOOD   = 8'h00;
  localparam bit [7:0] UFS_ST_CHECK  = 8'h02;
  localparam bit [7:0] UFS_ST_BUSY   = 8'h08;
  localparam bit [7:0] UFS_ST_ABORT  = 8'h0B;
  class ufs_seq_item extends uvm_sequence_item;
    `uvm_object_utils(ufs_seq_item)
    typedef enum bit [7:0] {
      NOP_OUT = 8'h00, COMMAND = 8'h01, TASK_MGT = 8'h04, QUERY_REQ = 8'h16,
      RESPONSE = 8'h21, DATA_IN = 8'h22, TASK_MGT_RSP = 8'h24,
      READY_XFER = 8'h31, QUERY_RSP = 8'h36
    } upiu_type_e;
    rand upiu_type_e  upiu_type;
    rand bit [7:0]    opcode;
    rand bit [7:0]    task_tag;
    rand bit [15:0]   data_length;
    rand bit [31:0]   lba;
    rand bit [7:0]    lun;
    rand bit [7:0]    status;
    function new(string name = "ufs_seq_item"); super.new(name); endfunction
    function bit is_host_upiu();
      return upiu_type inside {NOP_OUT, COMMAND, TASK_MGT, QUERY_REQ};
    endfunction
  endclass
  class ufs_cfg extends uvm_object;
    `uvm_object_utils(ufs_cfg)
    function new(string name = "ufs_cfg"); super.new(name); endfunction
  endclass
  class ufs_driver extends uvm_driver #(ufs_seq_item);
    `uvm_component_utils(ufs_driver)
    uvm_analysis_port #(ufs_seq_item) drv_ap;
    function new(string name = "ufs_driver", uvm_component parent = null);
      super.new(name, parent); drv_ap = new("drv_ap", this);
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        ufs_seq_item item;
        seq_item_port.get_next_item(item);
        drv_ap.write(item);
        seq_item_port.item_done();
      end
    endtask
  endclass
  class ufs_monitor extends uvm_monitor;
    `uvm_component_utils(ufs_monitor)
    uvm_analysis_port #(ufs_seq_item) item_collected_port;
    function new(string name = "ufs_monitor", uvm_component parent = null);
      super.new(name, parent); item_collected_port = new("item_collected_port", this);
    endfunction
  endclass
  class ufs_agent extends uvm_agent;
    `uvm_component_utils(ufs_agent)
    uvm_sequencer #(ufs_seq_item) sqr;
    ufs_driver  drv;
    ufs_monitor mon;
    function new(string name = "ufs_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = ufs_monitor::type_id::create("mon", this);
      sqr = uvm_sequencer#(ufs_seq_item)::type_id::create("sqr", this);
      drv = ufs_driver::type_id::create("drv", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass
  class ufs_base_seq extends uvm_sequence #(ufs_seq_item);
    `uvm_object_utils(ufs_base_seq)
    int num_trans = 10;
    function new(string name = "ufs_base_seq"); super.new(name); endfunction
    virtual task body();
      repeat (num_trans) begin
        ufs_seq_item item = ufs_seq_item::type_id::create("item");
        start_item(item);
        void'(item.randomize());
        finish_item(item);
      end
    endtask
  endclass
  class ufs_rw_seq extends ufs_base_seq;
    `uvm_object_utils(ufs_rw_seq)
    function new(string name = "ufs_rw_seq"); super.new(name); endfunction
  endclass
  class ufs_cov_upiu_seq extends ufs_base_seq;
    `uvm_object_utils(ufs_cov_upiu_seq)
    function new(string name = "ufs_cov_upiu_seq"); super.new(name); endfunction
  endclass
  class ufs_cov_lun_seq extends ufs_base_seq;
    `uvm_object_utils(ufs_cov_lun_seq)
    function new(string name = "ufs_cov_lun_seq"); super.new(name); endfunction
  endclass
endpackage

package unipro_pkg;
  import uvm_pkg::*;
  `uvm_analysis_imp_decl(_unipro_exp)
  `uvm_analysis_imp_decl(_unipro_obs)
  class unipro_seq_item extends uvm_sequence_item;
    `uvm_object_utils(unipro_seq_item)
    typedef enum bit [1:0] {CONNECT = 2'd0, DATA = 2'd1, DISCONNECT = 2'd2, CREDIT = 2'd3} msg_type_e;
    rand msg_type_e  msg_type;
    rand bit [4:0]   cportid;
    rand bit [3:0]   tc;
    rand bit [7:0]   tx_cred;
    function new(string name = "unipro_seq_item"); super.new(name); endfunction
  endclass
  class unipro_cfg extends uvm_object;
    `uvm_object_utils(unipro_cfg)
    function new(string name = "unipro_cfg"); super.new(name); endfunction
  endclass
  class unipro_driver extends uvm_driver #(unipro_seq_item);
    `uvm_component_utils(unipro_driver)
    uvm_analysis_port #(unipro_seq_item) drv_ap;
    function new(string name = "unipro_driver", uvm_component parent = null);
      super.new(name, parent); drv_ap = new("drv_ap", this);
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        unipro_seq_item item;
        seq_item_port.get_next_item(item);
        drv_ap.write(item);
        seq_item_port.item_done();
      end
    endtask
  endclass
  class unipro_monitor extends uvm_monitor;
    `uvm_component_utils(unipro_monitor)
    uvm_analysis_port #(unipro_seq_item) item_collected_port;
    function new(string name = "unipro_monitor", uvm_component parent = null);
      super.new(name, parent); item_collected_port = new("item_collected_port", this);
    endfunction
  endclass
  class unipro_agent extends uvm_agent;
    `uvm_component_utils(unipro_agent)
    uvm_sequencer #(unipro_seq_item) sqr;
    unipro_driver  drv;
    unipro_monitor mon;
    function new(string name = "unipro_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = unipro_monitor::type_id::create("mon", this);
      sqr = uvm_sequencer#(unipro_seq_item)::type_id::create("sqr", this);
      drv = unipro_driver::type_id::create("drv", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass
  class unipro_base_seq extends uvm_sequence #(unipro_seq_item);
    `uvm_object_utils(unipro_base_seq)
    int num_trans = 10;
    function new(string name = "unipro_base_seq"); super.new(name); endfunction
    virtual task body();
      repeat (num_trans) begin
        unipro_seq_item item = unipro_seq_item::type_id::create("item");
        start_item(item);
        void'(item.randomize());
        finish_item(item);
      end
    endtask
  endclass
  class unipro_rw_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_rw_seq)
    function new(string name = "unipro_rw_seq"); super.new(name); endfunction
  endclass
  class unipro_cov_msg_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_cov_msg_seq)
    function new(string name = "unipro_cov_msg_seq"); super.new(name); endfunction
    // REACHABILITY: directed chain so unipro_fsm_cg transition bins are hit
    // deterministically: CONNECT=>DATA=>DISCONNECT, DATA[*4], CREDIT=>DATA.
    task body();
      unipro_seq_item::msg_type_e chain[8] = '{
        unipro_seq_item::CONNECT, unipro_seq_item::DATA, unipro_seq_item::DATA,
        unipro_seq_item::DATA, unipro_seq_item::DATA, unipro_seq_item::DISCONNECT,
        unipro_seq_item::CREDIT, unipro_seq_item::DATA};
      foreach (chain[i]) begin
        unipro_seq_item item = unipro_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { msg_type == chain[i]; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass
  class unipro_cov_cport_seq extends unipro_base_seq;
    `uvm_object_utils(unipro_cov_cport_seq)
    function new(string name = "unipro_cov_cport_seq"); super.new(name); endfunction
  endclass
endpackage

package onfi_pkg;
  import uvm_pkg::*;
  class onfi_seq_item extends uvm_sequence_item;
    `uvm_object_utils(onfi_seq_item)
    rand bit [7:0] cmd_type;
    function new(string name = "onfi_seq_item"); super.new(name); endfunction
  endclass
  class onfi_cfg extends uvm_object;
    `uvm_object_utils(onfi_cfg)
    function new(string name = "onfi_cfg"); super.new(name); endfunction
  endclass
  class onfi_driver extends uvm_driver #(onfi_seq_item);
    `uvm_component_utils(onfi_driver)
    uvm_analysis_port #(onfi_seq_item) drv_ap;
    function new(string name = "onfi_driver", uvm_component parent = null);
      super.new(name, parent); drv_ap = new("drv_ap", this);
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        onfi_seq_item item;
        seq_item_port.get_next_item(item);
        drv_ap.write(item);
        seq_item_port.item_done();
      end
    endtask
  endclass
  class onfi_monitor extends uvm_monitor;
    `uvm_component_utils(onfi_monitor)
    uvm_analysis_port #(onfi_seq_item) item_collected_port;
    function new(string name = "onfi_monitor", uvm_component parent = null);
      super.new(name, parent); item_collected_port = new("item_collected_port", this);
    endfunction
  endclass
  class onfi_agent extends uvm_agent;
    `uvm_component_utils(onfi_agent)
    uvm_sequencer #(onfi_seq_item) sqr;
    onfi_driver  drv;
    onfi_monitor mon;
    function new(string name = "onfi_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = onfi_monitor::type_id::create("mon", this);
      sqr = uvm_sequencer#(onfi_seq_item)::type_id::create("sqr", this);
      drv = onfi_driver::type_id::create("drv", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass
  class onfi_base_seq extends uvm_sequence #(onfi_seq_item);
    `uvm_object_utils(onfi_base_seq)
    int num_trans = 10;
    function new(string name = "onfi_base_seq"); super.new(name); endfunction
    virtual task body();
      repeat (num_trans) begin
        onfi_seq_item item = onfi_seq_item::type_id::create("item");
        start_item(item);
        void'(item.randomize());
        finish_item(item);
      end
    endtask
  endclass
  class onfi_rw_seq extends onfi_base_seq;
    `uvm_object_utils(onfi_rw_seq)
    function new(string name = "onfi_rw_seq"); super.new(name); endfunction
  endclass
  class onfi_cov_cmd_seq extends onfi_base_seq;
    `uvm_object_utils(onfi_cov_cmd_seq)
    function new(string name = "onfi_cov_cmd_seq"); super.new(name); endfunction
  endclass
endpackage

package sd_pkg;
  import uvm_pkg::*;
  class sd_seq_item extends uvm_sequence_item;
    `uvm_object_utils(sd_seq_item)
    rand bit [5:0] cmd_type;
    rand bit [1:0] bus_width;
    function new(string name = "sd_seq_item"); super.new(name); endfunction
  endclass
  class sd_cfg extends uvm_object;
    `uvm_object_utils(sd_cfg)
    function new(string name = "sd_cfg"); super.new(name); endfunction
  endclass
  class sd_driver extends uvm_driver #(sd_seq_item);
    `uvm_component_utils(sd_driver)
    uvm_analysis_port #(sd_seq_item) drv_ap;
    function new(string name = "sd_driver", uvm_component parent = null);
      super.new(name, parent); drv_ap = new("drv_ap", this);
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        sd_seq_item item;
        seq_item_port.get_next_item(item);
        drv_ap.write(item);
        seq_item_port.item_done();
      end
    endtask
  endclass
  class sd_monitor extends uvm_monitor;
    `uvm_component_utils(sd_monitor)
    uvm_analysis_port #(sd_seq_item) item_collected_port;
    function new(string name = "sd_monitor", uvm_component parent = null);
      super.new(name, parent); item_collected_port = new("item_collected_port", this);
    endfunction
  endclass
  class sd_agent extends uvm_agent;
    `uvm_component_utils(sd_agent)
    uvm_sequencer #(sd_seq_item) sqr;
    sd_driver  drv;
    sd_monitor mon;
    function new(string name = "sd_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      mon = sd_monitor::type_id::create("mon", this);
      sqr = uvm_sequencer#(sd_seq_item)::type_id::create("sqr", this);
      drv = sd_driver::type_id::create("drv", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass
  class sd_base_seq extends uvm_sequence #(sd_seq_item);
    `uvm_object_utils(sd_base_seq)
    int num_trans = 10;
    function new(string name = "sd_base_seq"); super.new(name); endfunction
    virtual task body();
      repeat (num_trans) begin
        sd_seq_item item = sd_seq_item::type_id::create("item");
        start_item(item);
        void'(item.randomize());
        finish_item(item);
      end
    endtask
  endclass
  class sd_rw_seq extends sd_base_seq;
    `uvm_object_utils(sd_rw_seq)
    function new(string name = "sd_rw_seq"); super.new(name); endfunction
  endclass
  class sd_cov_cmd_seq extends sd_base_seq;
    `uvm_object_utils(sd_cov_cmd_seq)
    function new(string name = "sd_cov_cmd_seq"); super.new(name); endfunction
  endclass
endpackage

`endif
