// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// emmc_protocol_checker.sv -- eMMC Protocol Compliance Checker (module form)
// Validates command indices, bus/speed configuration, and data CRC handling
`ifndef EMMC_PROTOCOL_CHECKER_SV
`define EMMC_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module emmc_protocol_checker (emmc_if vif);
  property p_emmc_cmd_idx; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_index <= 6'd63; endproperty
  assert_p_emmc_cmd_idx: assert property(p_emmc_cmd_idx) else `uvm_warning("EMMC_CHK", "Command index valid failed");
  cover_p_emmc_cmd_idx: cover property(p_emmc_cmd_idx);
  property p_emmc_speed_mode; @(posedge vif.clk) disable iff (!vif.rst_n) vif.speed_mode inside {3'b000,3'b001,3'b010,3'b011,3'b100}; endproperty
  assert_p_emmc_speed_mode: assert property(p_emmc_speed_mode) else `uvm_warning("EMMC_CHK", "Speed mode valid failed");
  cover_p_emmc_speed_mode: cover property(p_emmc_speed_mode);
  property p_emmc_bus_width; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bus_width inside {3'b001,3'b010,3'b100,3'b111}; endproperty
  assert_p_emmc_bus_width: assert property(p_emmc_bus_width) else `uvm_warning("EMMC_CHK", "Bus width valid failed");
  cover_p_emmc_bus_width: cover property(p_emmc_bus_width);
  property p_emmc_data_crc; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.data_end) |-> ##[1:8] vif.data_crc_ok == 1; endproperty
  assert_p_emmc_data_crc: assert property(p_emmc_data_crc) else `uvm_warning("EMMC_CHK", "Data CRC check failed");
  cover_p_emmc_data_crc: cover property(p_emmc_data_crc);
endmodule
`endif
