// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// emmc_data_integrity_checker.sv -- eMMC Data-Integrity Compliance Checker (module form)
// Validates command framing, payload integrity, and write-block termination
`ifndef EMMC_DATA_INTEGRITY_CHECKER_SV
`define EMMC_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module emmc_data_integrity_checker (emmc_if vif);
  property p_emmc_cmd_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_valid == 1 |-> vif.cmd_index <= 6'd63; endproperty
  assert_p_emmc_cmd_valid: assert property(p_emmc_cmd_valid) else `uvm_warning("EMMC_DI", "Command valid failed");
  cover_p_emmc_cmd_valid: cover property(p_emmc_cmd_valid);
  property p_emmc_wdata_known; @(posedge vif.clk) disable iff (!vif.rst_n) vif.data_valid == 1 |-> !$isunknown(vif.data); endproperty
  assert_p_emmc_wdata_known: assert property(p_emmc_wdata_known) else `uvm_warning("EMMC_DI", "Write payload has X failed");
  cover_p_emmc_wdata_known: cover property(p_emmc_wdata_known);
  property p_emmc_rdata_known; @(posedge vif.clk) disable iff (!vif.rst_n) vif.rd_valid == 1 |-> !$isunknown(vif.rd_data); endproperty
  assert_p_emmc_rdata_known: assert property(p_emmc_rdata_known) else `uvm_warning("EMMC_DI", "Read payload has X failed");
  cover_p_emmc_rdata_known: cover property(p_emmc_rdata_known);
  property p_emmc_wdata_term; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.data_write) |-> ##[1:4096] vif.data_end == 1; endproperty
  assert_p_emmc_wdata_term: assert property(p_emmc_wdata_term) else `uvm_warning("EMMC_DI", "Write block not terminated failed");
  cover_p_emmc_wdata_term: cover property(p_emmc_wdata_term);
endmodule
`endif
