// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// emmc_error_checker.sv -- eMMC Error-Handling Compliance Checker (module form)
// Validates error detection, error status reporting, and recovery behavior
`ifndef EMMC_ERROR_CHECKER_SV
`define EMMC_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module emmc_error_checker (emmc_if vif);
  property p_emmc_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_valid == 1 |-> !$isunknown(vif.cmd_arg); endproperty
  assert_p_emmc_no_x: assert property(p_emmc_no_x) else `uvm_warning("EMMC_ERR", "No X when valid failed");
  cover_p_emmc_no_x: cover property(p_emmc_no_x);
  property p_emmc_error_abort; @(posedge vif.clk) disable iff (!vif.rst_n) vif.status == 3'b111 |-> vif.card_busy == 0; endproperty
  assert_p_emmc_error_abort: assert property(p_emmc_error_abort) else `uvm_warning("EMMC_ERR", "Error abort failed");
  cover_p_emmc_error_abort: cover property(p_emmc_error_abort);
  property p_emmc_err_reject; @(posedge vif.clk) disable iff (!vif.rst_n) vif.err == 1 |-> ##[0:64] vif.resp_valid == 1; endproperty
  assert_p_emmc_err_reject: assert property(p_emmc_err_reject) else `uvm_warning("EMMC_ERR", "Error without response failed");
  cover_p_emmc_err_reject: cover property(p_emmc_err_reject);
endmodule
`endif
