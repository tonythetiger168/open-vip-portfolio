// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// emmc_timing_checker.sv -- eMMC Timing Compliance Checker (module form)
// Validates response latency, busy window, and command acceptance timing
`ifndef EMMC_TIMING_CHECKER_SV
`define EMMC_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module emmc_timing_checker (emmc_if vif);
  property p_emmc_card_busy; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.data_end == 1 && vif.data_write == 1) |-> ##[1:256] vif.card_busy == 0; endproperty
  assert_p_emmc_card_busy: assert property(p_emmc_card_busy) else `uvm_warning("EMMC_TIM", "Card busy window violated");
  cover_p_emmc_card_busy: cover property(p_emmc_card_busy);
  property p_emmc_resp_latency; @(posedge vif.clk) disable iff (!vif.rst_n) ($fell(vif.cmd_valid) && vif.cmd_index != 6'd0) |-> ##[1:64] vif.resp_valid == 1; endproperty
  assert_p_emmc_resp_latency: assert property(p_emmc_resp_latency) else `uvm_warning("EMMC_TIM", "Response latency violated");
  cover_p_emmc_resp_latency: cover property(p_emmc_resp_latency);
  property p_emmc_cmd_accept; @(posedge vif.clk) disable iff (!vif.rst_n) $rose(vif.cmd_valid) |-> vif.ready == 1; endproperty
  assert_p_emmc_cmd_accept: assert property(p_emmc_cmd_accept) else `uvm_warning("EMMC_TIM", "Command sent while card not ready violated");
  cover_p_emmc_cmd_accept: cover property(p_emmc_cmd_accept);
endmodule
`endif
