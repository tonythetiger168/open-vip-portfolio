// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// memory_env_pkg.sv -- 8-protocol memory/UniPro environment
`ifndef MEMORY_ENV_PKG_SV
`define MEMORY_ENV_PKG_SV
package memory_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import ddr_pkg::*; import lpddr_pkg::*; import hbm_pkg::*;
  import ufs_pkg::*; import unipro_pkg::*; import emmc_pkg::*;
  import onfi_pkg::*; import sd_pkg::*;
  import memory_coverage_pkg::*;

  class memory_env_cfg extends uvm_object;
    `uvm_object_utils(memory_env_cfg)
    ddr_cfg ddr_cfg_h; lpddr_cfg lpddr_cfg_h; hbm_cfg hbm_cfg_h;
    ufs_cfg ufs_cfg_h; unipro_cfg unipro_cfg_h; emmc_cfg emmc_cfg_h;
    onfi_cfg onfi_cfg_h; sd_cfg sd_cfg_h;
    bit scoreboard_enable = 1; bit coverage_enable = 1;
    int num_ddr = 30; int num_lpddr = 30; int num_hbm = 30;
    int num_ufs = 20; int num_unipro = 20; int num_emmc = 20;
    int num_onfi = 20; int num_sd = 20;
    function new(string name = "memory_env_cfg");
      super.new(name);
      ddr_cfg_h = ddr_cfg::type_id::create("ddr_cfg_h"); lpddr_cfg_h = lpddr_cfg::type_id::create("lpddr_cfg_h");
      hbm_cfg_h = hbm_cfg::type_id::create("hbm_cfg_h"); ufs_cfg_h = ufs_cfg::type_id::create("ufs_cfg_h");
      unipro_cfg_h = unipro_cfg::type_id::create("unipro_cfg_h"); emmc_cfg_h = emmc_cfg::type_id::create("emmc_cfg_h");
      onfi_cfg_h = onfi_cfg::type_id::create("onfi_cfg_h"); sd_cfg_h = sd_cfg::type_id::create("sd_cfg_h");
    endfunction
  endclass

  `uvm_analysis_imp_decl(_ddr)
  `uvm_analysis_imp_decl(_lpddr)
  `uvm_analysis_imp_decl(_hbm)
  `uvm_analysis_imp_decl(_ufs)
  `uvm_analysis_imp_decl(_unipro)
  `uvm_analysis_imp_decl(_emmc)
  `uvm_analysis_imp_decl(_onfi)
  `uvm_analysis_imp_decl(_sd)

  class memory_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(memory_scoreboard)
    uvm_analysis_imp_ddr #(ddr_seq_item, memory_scoreboard) ddr_export;
    uvm_analysis_imp_lpddr #(lpddr_seq_item, memory_scoreboard) lpddr_export;
    uvm_analysis_imp_hbm #(hbm_seq_item, memory_scoreboard) hbm_export;
    uvm_analysis_imp_ufs #(ufs_seq_item, memory_scoreboard) ufs_export;
    uvm_analysis_imp_unipro #(unipro_seq_item, memory_scoreboard) unipro_export;
    uvm_analysis_imp_emmc #(emmc_seq_item, memory_scoreboard) emmc_export;
    uvm_analysis_imp_onfi #(onfi_seq_item, memory_scoreboard) onfi_export;
    uvm_analysis_imp_sd #(sd_seq_item, memory_scoreboard) sd_export;
    // end-to-end UniPro compare (expected from driver vs observed from monitor)
    uvm_analysis_imp_unipro_exp #(unipro_seq_item, memory_scoreboard) unipro_exp_ap;
    uvm_analysis_imp_unipro_obs #(unipro_seq_item, memory_scoreboard) unipro_obs_ap;
    unipro_seq_item exp_q[$], obs_q[$];
    int unsigned n_matches = 0, n_mismatches = 0;
    // end-to-end UFS compare (expected from driver drv_ap vs observed from monitor)
    uvm_analysis_imp_ufs_exp #(ufs_seq_item, memory_scoreboard) ufs_exp_ap;
    uvm_analysis_imp_ufs_obs #(ufs_seq_item, memory_scoreboard) ufs_obs_ap;
    ufs_seq_item ufs_exp_q[$], ufs_obs_q[$];
    int unsigned ufs_n_matches = 0, ufs_n_mismatches = 0;
    // end-to-end eMMC compare (expected from driver drv_ap vs observed from monitor)
    uvm_analysis_imp_emmc_exp #(emmc_seq_item, memory_scoreboard) emmc_exp_ap;
    uvm_analysis_imp_emmc_obs #(emmc_seq_item, memory_scoreboard) emmc_obs_ap;
    emmc_seq_item emmc_exp_q[$], emmc_obs_q[$];
    int unsigned emmc_n_matches = 0, emmc_n_mismatches = 0;
    int ddr_count = 0, lpddr_count = 0, hbm_count = 0, ufs_count = 0, unipro_count = 0, emmc_count = 0, onfi_count = 0, sd_count = 0;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ddr_export = new("ddr_export", this); lpddr_export = new("lpddr_export", this); hbm_export = new("hbm_export", this);
      ufs_export = new("ufs_export", this); unipro_export = new("unipro_export", this); emmc_export = new("emmc_export", this);
      onfi_export = new("onfi_export", this); sd_export = new("sd_export", this);
      unipro_exp_ap = new("unipro_exp_ap", this); unipro_obs_ap = new("unipro_obs_ap", this);
      ufs_exp_ap = new("ufs_exp_ap", this); ufs_obs_ap = new("ufs_obs_ap", this);
      emmc_exp_ap = new("emmc_exp_ap", this); emmc_obs_ap = new("emmc_obs_ap", this);
    endfunction
    virtual function void write_ddr(ddr_seq_item item); ddr_count++; endfunction
    virtual function void write_lpddr(lpddr_seq_item item); lpddr_count++; endfunction
    virtual function void write_hbm(hbm_seq_item item); hbm_count++; endfunction
    virtual function void write_ufs(ufs_seq_item item); ufs_count++; endfunction
    virtual function void write_unipro(unipro_seq_item item); unipro_count++; endfunction
    virtual function void write_emmc(emmc_seq_item item); emmc_count++; endfunction
    virtual function void write_onfi(onfi_seq_item item); onfi_count++; endfunction
    virtual function void write_sd(sd_seq_item item); sd_count++; endfunction
    virtual function void write_unipro_exp(unipro_seq_item item);
      exp_q.push_back(item); check();
    endfunction
    virtual function void write_unipro_obs(unipro_seq_item item);
      obs_q.push_back(item); check();
    endfunction
    function void check();
      while (exp_q.size() && obs_q.size()) begin
        unipro_seq_item e = exp_q.pop_front();
        unipro_seq_item o = obs_q.pop_front();
        if (e.compare(o))
          n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("MEM_SB", $sformatf("unipro mismatch exp{%s} obs{%s}", e.convert2string(), o.convert2string()))
        end
      end
    endfunction
    // UFS end-to-end: only host-initiated UPIUs are compared (cmd direction)
    // eMMC end-to-end: only host commands are compared (response/data items skipped)
    virtual function void write_emmc_exp(emmc_seq_item item);
      emmc_exp_q.push_back(item);
      emmc_check();
    endfunction
    virtual function void write_emmc_obs(emmc_seq_item item);
      if (item.from_host) begin
        emmc_obs_q.push_back(item);
        emmc_check();
      end
    endfunction
    function void emmc_check();
      while (emmc_exp_q.size() && emmc_obs_q.size()) begin
        emmc_seq_item e = emmc_exp_q.pop_front();
        emmc_seq_item o = emmc_obs_q.pop_front();
        if (e.compare(o))
          emmc_n_matches++;
        else begin
          emmc_n_mismatches++;
          `uvm_error("MEM_SB", $sformatf("eMMC mismatch exp{%s} obs{%s}", e.convert2string(), o.convert2string()))
        end
      end
    endfunction
    virtual function void write_ufs_exp(ufs_seq_item item);
      if (item.is_host_upiu()) begin
        ufs_exp_q.push_back(item);
        ufs_check();
      end
    endfunction
    virtual function void write_ufs_obs(ufs_seq_item item);
      if (item.is_host_upiu()) begin
        ufs_obs_q.push_back(item);
        ufs_check();
      end
    endfunction
    function void ufs_check();
      while (ufs_exp_q.size() && ufs_obs_q.size()) begin
        ufs_seq_item e = ufs_exp_q.pop_front();
        ufs_seq_item o = ufs_obs_q.pop_front();
        if (e.compare(o))
          ufs_n_matches++;
        else begin
          ufs_n_mismatches++;
          `uvm_error("MEM_SB", $sformatf("UFS mismatch exp{%s} obs{%s}", e.convert2string(), o.convert2string()))
        end
      end
    endfunction
    function void report_phase(uvm_phase phase);
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
      `uvm_info(get_type_name(), "  MEMORY SCOREBOARD REPORT", UVM_LOW)
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("DDR:    %0d", ddr_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("LPDDR:  %0d", lpddr_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("HBM:    %0d", hbm_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("UFS:    %0d", ufs_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("UniPro: %0d", unipro_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("eMMC:   %0d", emmc_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("ONFI:   %0d", onfi_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("SD:     %0d", sd_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("TOTAL:  %0d", ddr_count+lpddr_count+hbm_count+ufs_count+unipro_count+emmc_count+onfi_count+sd_count), UVM_LOW)
      `uvm_info(get_type_name(), $sformatf("UniPro end-to-end: n_matches=%0d n_mismatches=%0d", n_matches, n_mismatches), UVM_LOW)
      if (n_mismatches) `uvm_error("MEM_SB", "UniPro end-to-end n_mismatches detected")
      `uvm_info(get_type_name(), $sformatf("UFS end-to-end:    n_matches=%0d n_mismatches=%0d", ufs_n_matches, ufs_n_mismatches), UVM_LOW)
      if (ufs_n_mismatches) `uvm_error("MEM_SB", "UFS end-to-end n_mismatches detected")
      if (ufs_exp_q.size() || ufs_obs_q.size())
        `uvm_error("MEM_SB", $sformatf("UFS e2e queue residue exp=%0d obs=%0d", ufs_exp_q.size(), ufs_obs_q.size()))
      `uvm_info(get_type_name(), $sformatf("eMMC end-to-end:   n_matches=%0d n_mismatches=%0d", emmc_n_matches, emmc_n_mismatches), UVM_LOW)
      if (emmc_n_mismatches) `uvm_error("MEM_SB", "eMMC end-to-end n_mismatches detected")
      if (emmc_exp_q.size() || emmc_obs_q.size())
        `uvm_error("MEM_SB", $sformatf("eMMC e2e queue residue exp=%0d obs=%0d", emmc_exp_q.size(), emmc_obs_q.size()))
      `uvm_info(get_type_name(), "==========================================", UVM_LOW)
    endfunction
  endclass

  class memory_env extends uvm_env;
    `uvm_component_utils(memory_env)
    ddr_agent ddr_ag; lpddr_agent lpddr_ag; hbm_agent hbm_ag;
    ufs_agent ufs_ag; unipro_agent unipro_ag; emmc_agent emmc_ag;
    onfi_agent onfi_ag; sd_agent sd_ag;
    ddr_coverage ddr_cov; lpddr_coverage lpddr_cov; hbm_coverage hbm_cov;
    ufs_coverage ufs_cov; unipro_coverage unipro_cov; emmc_coverage emmc_cov;
    onfi_coverage onfi_cov; sd_coverage sd_cov;
    memory_coverage_report_checker cov_chk;
    memory_scoreboard sb; memory_env_cfg cfg;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(memory_env_cfg)::get(this, "", "cfg", cfg)) cfg = memory_env_cfg::type_id::create("cfg");
      ddr_ag = ddr_agent::type_id::create("ddr_ag", this); lpddr_ag = lpddr_agent::type_id::create("lpddr_ag", this);
      hbm_ag = hbm_agent::type_id::create("hbm_ag", this); ufs_ag = ufs_agent::type_id::create("ufs_ag", this);
      unipro_ag = unipro_agent::type_id::create("unipro_ag", this); emmc_ag = emmc_agent::type_id::create("emmc_ag", this);
      onfi_ag = onfi_agent::type_id::create("onfi_ag", this); sd_ag = sd_agent::type_id::create("sd_ag", this);
      if (cfg.coverage_enable) begin
        ddr_cov = ddr_coverage::type_id::create("ddr_cov", this); lpddr_cov = lpddr_coverage::type_id::create("lpddr_cov", this);
        hbm_cov = hbm_coverage::type_id::create("hbm_cov", this); ufs_cov = ufs_coverage::type_id::create("ufs_cov", this);
        unipro_cov = unipro_coverage::type_id::create("unipro_cov", this); emmc_cov = emmc_coverage::type_id::create("emmc_cov", this);
        onfi_cov = onfi_coverage::type_id::create("onfi_cov", this); sd_cov = sd_coverage::type_id::create("sd_cov", this);
        cov_chk = memory_coverage_report_checker::type_id::create("cov_chk", this);
      end
      if (cfg.scoreboard_enable) sb = memory_scoreboard::type_id::create("sb", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.scoreboard_enable) begin
        ddr_ag.mon.item_collected_port.connect(sb.ddr_export); lpddr_ag.mon.item_collected_port.connect(sb.lpddr_export);
        hbm_ag.mon.item_collected_port.connect(sb.hbm_export); ufs_ag.mon.item_collected_port.connect(sb.ufs_export);
        unipro_ag.mon.item_collected_port.connect(sb.unipro_export); emmc_ag.mon.item_collected_port.connect(sb.emmc_export);
        onfi_ag.mon.item_collected_port.connect(sb.onfi_export); sd_ag.mon.item_collected_port.connect(sb.sd_export);
        // UniPro end-to-end: expected (driver) vs observed (monitor)
        unipro_ag.drv.drv_ap.connect(sb.unipro_exp_ap);
        unipro_ag.mon.item_collected_port.connect(sb.unipro_obs_ap);
        // UFS end-to-end: expected (driver drv_ap) vs observed (monitor)
        ufs_ag.drv.drv_ap.connect(sb.ufs_exp_ap);
        ufs_ag.mon.item_collected_port.connect(sb.ufs_obs_ap);
        // eMMC end-to-end: expected (driver drv_ap) vs observed (monitor)
        emmc_ag.drv.drv_ap.connect(sb.emmc_exp_ap);
        emmc_ag.mon.item_collected_port.connect(sb.emmc_obs_ap);
        // eMMC end-to-end: expected (driver drv_ap) vs observed (monitor)
        emmc_ag.drv.drv_ap.connect(sb.emmc_exp_ap);
        emmc_ag.mon.item_collected_port.connect(sb.emmc_obs_ap);
      end
      if (cfg.coverage_enable) begin
        ddr_ag.mon.item_collected_port.connect(ddr_cov.analysis_export); lpddr_ag.mon.item_collected_port.connect(lpddr_cov.analysis_export);
        hbm_ag.mon.item_collected_port.connect(hbm_cov.analysis_export); ufs_ag.mon.item_collected_port.connect(ufs_cov.analysis_export);
        unipro_ag.mon.item_collected_port.connect(unipro_cov.analysis_export); emmc_ag.mon.item_collected_port.connect(emmc_cov.analysis_export);
        onfi_ag.mon.item_collected_port.connect(onfi_cov.analysis_export); sd_ag.mon.item_collected_port.connect(sd_cov.analysis_export);
        cov_chk.ddr_cov_h = ddr_cov; cov_chk.lpddr_cov_h = lpddr_cov; cov_chk.hbm_cov_h = hbm_cov;
        cov_chk.ufs_cov_h = ufs_cov; cov_chk.unipro_cov_h = unipro_cov; cov_chk.emmc_cov_h = emmc_cov;
        cov_chk.onfi_cov_h = onfi_cov; cov_chk.sd_cov_h = sd_cov;
      end
    endfunction
  endclass
endpackage : memory_env_pkg
`endif
