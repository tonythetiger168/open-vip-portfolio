// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// emmc_pkg.sv -- eMMC UVM VIP package
// Real eMMC protocol behavior over emmc_if:
//   CMD line : 48-bit command frame {start=0, host=1, idx[5:0], arg[31:0], CRC7, end=1}
//   RESP line: R1/R1b/R3 (48-bit) / R2 (136-bit CID/CSD) responses
//   DAT lines: block read (card->host rd_data) / block write (host->card data + XOR CRC)
//   busy handshake on card_busy (DAT0) after write/erase/switch
`ifndef EMMC_PKG_SV
`define EMMC_PKG_SV
package emmc_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  `uvm_analysis_imp_decl(_emmc_exp)
  `uvm_analysis_imp_decl(_emmc_obs)

  // Device model geometry (must match emmc_device_dut in tb_top.sv)
  localparam int EMMC_BLOCK_SIZE = 512;
  localparam int EMMC_CAP_BLOCKS = 2048; // 1 MiB card
  // R1 status error bits (subset of the JEDEC card-status layout)
  localparam bit [31:0] R1_ADDR_OUT_OF_RANGE = 32'h8000_0000;
  localparam bit [31:0] R1_COM_CRC_ERROR     = 32'h0080_0000;
  localparam bit [31:0] R1_ILLEGAL_COMMAND   = 32'h0040_0000;
  // Card states
  localparam bit [3:0] ST_IDLE = 0, ST_READY = 1, ST_IDENT = 2, ST_STBY = 3,
                       ST_TRAN = 4, ST_DATA = 5, ST_RCV = 6, ST_PRG = 7, ST_DIS = 8;

  //============================================================================
  // eMMC Sequence Item
  //============================================================================
  class emmc_seq_item extends uvm_sequence_item;
    `uvm_object_utils(emmc_seq_item)
    typedef enum {GO_IDLE, SEND_OP_COND, ALL_SEND_CID, SET_REL_ADDR, SWITCH, SEND_EXT_CSD,
                  SEND_STATUS, SET_BLOCKLEN, READ_SINGLE, READ_MULTIPLE, WRITE_SINGLE,
                  WRITE_MULTIPLE, ERASE_GRP_START, ERASE_GRP_END, ERASE, APP_CMD,
                  SET_BUS_WIDTH, SD_SEND_OP, SELECT_CARD, IO_RW_DIRECT, IO_RW_EXTENDED} cmd_type_e;
    rand cmd_type_e cmd_type;
    rand bit [5:0]  cmd_index;
    rand bit [31:0] cmd_arg;
    rand bit [7:0]  data[];        // write payload bytes
    rand bit [15:0] block_len;
    rand bit [1:0]  bus_width;
    bit        inject_crc_err;     // corrupt command CRC7 (error injection)
    bit        from_host;          // monitor tag: 1=command, 0=response/data
    bit [7:0]  rdata[];            // read payload bytes
    bit [31:0] resp;               // R1/R3 status argument
    bit        resp_valid;
    bit        busy;
    rand int unsigned delay;
    // Constraints
    // REACHABILITY: dist must list every command the directed sequences send
    // (unlisted dist values get weight 0, which makes send_t(cmd==X) fail for
    // them) and every emmc_fsm_cg transition endpoint. Add the init/ACMD/erase
    // group commands with a low weight so those bins are generatable.
    constraint c_cmd_dist { cmd_type dist {READ_SINGLE := 20, READ_MULTIPLE := 15,
      WRITE_SINGLE := 20, WRITE_MULTIPLE := 15, SEND_STATUS := 10, SWITCH := 5,
      ERASE := 5, GO_IDLE := 2, SELECT_CARD := 3, SET_BLOCKLEN := 3, IO_RW_DIRECT := 2,
      SEND_OP_COND := 1, ALL_SEND_CID := 1, SET_REL_ADDR := 1, SEND_EXT_CSD := 1,
      ERASE_GRP_START := 1, ERASE_GRP_END := 1, APP_CMD := 1, SET_BUS_WIDTH := 1,
      SD_SEND_OP := 1, IO_RW_EXTENDED := 1}; }
    constraint c_bus_width { bus_width inside {0, 1, 2}; } // 1-bit, 4-bit, 8-bit
    constraint c_block_len { block_len inside {512, 1024, 2048, 4096}; }
    constraint c_data_size { data.size() == block_len; }
    constraint c_idx { cmd_index == cmd_index_of(cmd_type); }
    // block data transfers are one 512-byte block in this model; block_len is
    // randomized for coverage / SET_BLOCKLEN arguments
    constraint c_data_bl { (cmd_type inside {READ_SINGLE, READ_MULTIPLE, WRITE_SINGLE, WRITE_MULTIPLE}) -> block_len == 512; }
    constraint c_arg_range { (cmd_type inside {READ_SINGLE, READ_MULTIPLE, WRITE_SINGLE, WRITE_MULTIPLE,
                                               ERASE_GRP_START, ERASE_GRP_END}) -> cmd_arg < EMMC_CAP_BLOCKS; }
    constraint c_delay { delay inside {[0:10]}; }
    function new(string name = "emmc_seq_item"); super.new(name); endfunction

    static function bit [5:0] cmd_index_of(cmd_type_e t);
      case (t)
        GO_IDLE:         return 6'd0;
        SEND_OP_COND:    return 6'd1;
        ALL_SEND_CID:    return 6'd2;
        SET_REL_ADDR:    return 6'd3;
        SWITCH:          return 6'd6;
        SET_BUS_WIDTH:   return 6'd6;  // SWITCH with bus-width access field
        SELECT_CARD:     return 6'd7;
        SEND_EXT_CSD:    return 6'd8;
        SEND_STATUS:     return 6'd13;
        SET_BLOCKLEN:    return 6'd16;
        READ_SINGLE:     return 6'd17;
        READ_MULTIPLE:   return 6'd18;
        WRITE_SINGLE:    return 6'd24;
        WRITE_MULTIPLE:  return 6'd25;
        ERASE_GRP_START: return 6'd35;
        ERASE_GRP_END:   return 6'd36;
        ERASE:           return 6'd38;
        SD_SEND_OP:      return 6'd41; // ACMD41
        IO_RW_DIRECT:    return 6'd52;
        IO_RW_EXTENDED:  return 6'd53;
        APP_CMD:         return 6'd55;
        default:         return 6'd0;
      endcase
    endfunction

    function bit is_read_data_cmd();
      return cmd_type inside {READ_SINGLE, READ_MULTIPLE, SEND_EXT_CSD};
    endfunction
    function bit is_write_data_cmd();
      return cmd_type inside {WRITE_SINGLE, WRITE_MULTIPLE};
    endfunction
    function bit is_r1b_cmd();
      return cmd_type inside {SWITCH, SET_BUS_WIDTH, ERASE};
    endfunction

    virtual function string convert2string();
      return $sformatf("eMMC %s: idx=%0d arg=0x%0h bl=%0d bw=%0d resp=0x%0h",
                       cmd_type.name(), cmd_index, cmd_arg, block_len, bus_width, resp);
    endfunction
    virtual function bit do_compare(uvm_object rhs, uvm_comparer comparer);
      emmc_seq_item o;
      if (!$cast(o, rhs)) return 0;
      if (cmd_type != o.cmd_type) return 0;
      if (cmd_index != o.cmd_index || cmd_arg != o.cmd_arg) return 0;
      if (block_len != o.block_len) return 0;
      if (data.size() != o.data.size()) return 0;
      foreach (data[i]) if (data[i] != o.data[i]) return 0;
      return 1;
    endfunction
  endclass : emmc_seq_item

  //============================================================================
  // eMMC Configuration
  //============================================================================
  class emmc_cfg extends uvm_object;
    `uvm_object_utils(emmc_cfg)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1;
    int tCmd = 8;
    int tRead = 50;
    int tWrite = 100;
    int tErase = 500;
    int tBusy = 200;
    int rsp_timeout = 100000;
    function new(string name = "emmc_cfg"); super.new(name); endfunction
  endclass : emmc_cfg

  //============================================================================
  // eMMC Sequencer/Driver/Monitor/Agent
  //============================================================================
  class emmc_sequencer extends uvm_sequencer #(emmc_seq_item);
    `uvm_component_utils(emmc_sequencer)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass : emmc_sequencer

  class emmc_driver extends uvm_driver #(emmc_seq_item);
    `uvm_component_utils(emmc_driver)
    virtual emmc_if vif;
    emmc_cfg cfg;
    uvm_analysis_port #(emmc_seq_item) drv_ap; // expected transactions (e2e scoreboard)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual emmc_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "eMMC virtual interface not found")
      if (!uvm_config_db#(emmc_cfg)::get(this, "", "cfg", cfg))
        cfg = emmc_cfg::type_id::create("cfg");
      drv_ap = new("drv_ap", this);
    endfunction

    // eMMC CRC7 (x^7 + x^3 + 1) over the 40-bit {idx, arg} field
    function automatic bit [6:0] crc7(bit [5:0] idx, bit [31:0] arg);
      bit [6:0] crc = 7'h00;
      bit [39:0] stream = {idx, arg};
      for (int i = 39; i >= 0; i--) begin
        bit fb = crc[6] ^ stream[i];
        crc = {crc[5:0], 1'b0};
        if (fb) crc = crc ^ 7'h09;
      end
      return crc;
    endfunction

    task run_phase(uvm_phase phase);
      emmc_seq_item req;
      vif.drv_cb.cmd <= 1'b1; // CMD line idle high
      vif.drv_cb.cmd_valid <= 1'b0;
      vif.drv_cb.data_valid <= 1'b0;
      vif.drv_cb.data_end <= 1'b0;
      vif.drv_cb.data_write <= 1'b0;
      vif.drv_cb.valid <= 1'b0;
      vif.drv_cb.speed_mode <= 3'b000;
      vif.drv_cb.bus_width <= 3'b001;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        `uvm_info(get_type_name(), $sformatf("Driving: %s", req.convert2string()), UVM_MEDIUM)
        repeat (req.delay) @(vif.drv_cb);
        drive_cmd(req);
        drv_ap.write(req);
        seq_item_port.item_done();
      end
    endtask

    // Full command/response (+optional data) exchange
    task automatic drive_cmd(emmc_seq_item req);
      bit [47:0] frame;
      bit [6:0]  crc;
      crc = crc7(req.cmd_index, req.cmd_arg);
      if (req.inject_crc_err) crc = crc ^ 7'h55;
      frame = {1'b0, 1'b1, req.cmd_index, req.cmd_arg, crc, 1'b1};
      // host sideband config
      vif.drv_cb.cmd_index <= req.cmd_index;
      vif.drv_cb.cmd_arg   <= req.cmd_arg;
      vif.drv_cb.bus_width <= (req.bus_width == 2'd0) ? 3'b001 :
                              (req.bus_width == 2'd1) ? 3'b010 : 3'b100;
      vif.drv_cb.valid     <= 1'b1;
      // 48-bit command frame on the CMD line, MSB first
      for (int i = 47; i >= 0; i--) begin
        @(vif.drv_cb);
        vif.drv_cb.cmd <= frame[i];
        vif.drv_cb.cmd_valid <= 1'b1;
      end
      @(vif.drv_cb);
      vif.drv_cb.cmd <= 1'b1;
      vif.drv_cb.cmd_valid <= 1'b0;
      vif.drv_cb.valid <= 1'b0;
      // response (CMD0 has none)
      if (req.cmd_type == emmc_seq_item::GO_IDLE) begin
        req.resp = 32'h0; req.resp_valid = 1'b0; req.busy = 1'b0;
        req.data = new[0];
        repeat (cfg.tCmd) @(vif.drv_cb);
        return;
      end
      collect_response(req);
      // R1b commands: wait for the busy handshake to clear
      if (req.is_r1b_cmd()) wait_busy(req);
      // data phases
      if (req.is_read_data_cmd()) begin
        collect_read_data(req);
        req.data = new[0]; // no host->card payload
      end else if (req.is_write_data_cmd()) begin
        send_write_data(req);
        wait_busy(req);
      end else begin
        req.data = new[0];
      end
    endtask

    // Collect a response frame from the RESP line (48 or 136 bits)
    task automatic collect_response(emmc_seq_item req);
      bit [135:0] rframe = 136'h0;
      int nbits = 0;
      int guard = 0;
      // wait for response start
      while (vif.drv_cb.resp_valid !== 1'b1 && guard < cfg.rsp_timeout) begin
        @(vif.drv_cb); guard++;
      end
      if (guard >= cfg.rsp_timeout) begin
        `uvm_error(get_type_name(), "Timeout waiting for eMMC response")
        req.resp = 32'hFFFF_FFFF; req.resp_valid = 1'b0;
        return;
      end
      while (vif.drv_cb.resp_valid === 1'b1 && guard < cfg.rsp_timeout) begin
        rframe = {rframe[134:0], vif.drv_cb.resp};
        nbits++;
        @(vif.drv_cb); guard++;
      end
      // status argument sits at bits [39:8] of a 48-bit frame
      if (nbits >= 48) begin
        rframe = rframe >> (nbits - 48);
        req.resp = rframe[39:8];
        req.resp_valid = 1'b1;
      end else begin
        req.resp = 32'hFFFF_FFFF; req.resp_valid = 1'b0;
      end
      req.busy = (vif.drv_cb.card_busy === 1'b1);
    endtask

    // Collect a read data block from the DAT lines (card->host)
    task automatic collect_read_data(emmc_seq_item req);
      int nbytes = (req.cmd_type == emmc_seq_item::SEND_EXT_CSD) ? 512 : req.block_len;
      bit [7:0] rd_q[$];
      int guard = 0;
      while (rd_q.size() < nbytes && guard < cfg.rsp_timeout) begin
        @(vif.drv_cb); guard++;
        if (vif.drv_cb.rd_valid === 1'b1) rd_q.push_back(vif.drv_cb.rd_data);
      end
      if (guard >= cfg.rsp_timeout)
        `uvm_error(get_type_name(), "Timeout waiting for eMMC read data")
      req.rdata = new[rd_q.size()];
      foreach (rd_q[i]) req.rdata[i] = rd_q[i];
    endtask

    // Stream a write data block + XOR CRC byte on the DAT lines (host->card)
    task automatic send_write_data(emmc_seq_item req);
      bit [7:0] xcrc = 8'h00;
      foreach (req.data[i]) xcrc = xcrc ^ req.data[i];
      vif.drv_cb.data_write <= 1'b1;
      vif.drv_cb.valid <= 1'b1;
      foreach (req.data[i]) begin
        @(vif.drv_cb);
        vif.drv_cb.data <= req.data[i];
        vif.drv_cb.data_valid <= 1'b1;
      end
      // trailing CRC byte, flagged as the last beat
      @(vif.drv_cb);
      vif.drv_cb.data <= req.inject_crc_err ? (xcrc ^ 8'hFF) : xcrc;
      vif.drv_cb.data_valid <= 1'b1;
      vif.drv_cb.data_end <= 1'b1;
      @(vif.drv_cb);
      vif.drv_cb.data_valid <= 1'b0;
      vif.drv_cb.data_end <= 1'b0;
      vif.drv_cb.data_write <= 1'b0;
      vif.drv_cb.valid <= 1'b0;
    endtask

    // Busy handshake: wait for programming to start, then for card_busy (DAT0) release
    task automatic wait_busy(emmc_seq_item req);
      int guard = 0;
      while (guard < 64) begin
        @(vif.drv_cb); guard++;
        if (vif.drv_cb.card_state === ST_PRG || vif.drv_cb.card_busy === 1'b1) break;
      end
      guard = 0;
      while (guard < cfg.rsp_timeout) begin
        @(vif.drv_cb); guard++;
        if (vif.drv_cb.card_busy === 1'b0 && vif.drv_cb.busy === 1'b0 &&
            vif.drv_cb.card_state !== ST_PRG) begin
          req.busy = 1'b0;
          return;
        end
      end
      `uvm_error(get_type_name(), "Timeout waiting for card busy release")
    endtask
  endclass : emmc_driver

  class emmc_monitor extends uvm_monitor;
    `uvm_component_utils(emmc_monitor)
    virtual emmc_if vif;
    uvm_analysis_port #(emmc_seq_item) item_collected_port;
    int unsigned txn_count = 0;
    emmc_seq_item pending_wr = null;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      item_collected_port = new("item_collected_port", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(virtual emmc_if)::get(this, "", "vif", vif))
        `uvm_fatal(get_type_name(), "eMMC virtual interface not found")
    endfunction
    task run_phase(uvm_phase phase);
      fork
        collect_cmd();
        collect_resp();
        collect_wdata();
        collect_rdata();
      join
    endtask

    // Decode 48-bit command frames from the CMD line
    task automatic collect_cmd();
      bit [47:0] frame = 48'h0;
      int nbits = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) begin nbits = 0; pending_wr = null; continue; end
        if (vif.mon_cb.cmd_valid === 1'b1) begin
          frame = {frame[46:0], vif.mon_cb.cmd};
          nbits++;
        end else if (nbits > 0) begin
          decode_cmd(frame, nbits);
          nbits = 0; frame = 48'h0;
        end
      end
    endtask

    function automatic void decode_cmd(bit [47:0] frame, int nbits);
      emmc_seq_item item;
      bit [5:0] idx;
      if (nbits < 48) begin
        `uvm_warning(get_type_name(), $sformatf("Short command frame (%0d bits) ignored", nbits))
        return;
      end
      frame = frame >> (nbits - 48);
      idx = frame[45:40];
      item = emmc_seq_item::type_id::create("cmd_item");
      item.cmd_index = idx;
      item.cmd_arg   = frame[39:8];
      item.from_host = 1'b1;
      item.block_len = 16'd512;
      // map index back to command type
      begin
        emmc_seq_item::cmd_type_e t = emmc_seq_item::GO_IDLE;
        emmc_seq_item::cmd_type_e cand[21] = '{
          emmc_seq_item::GO_IDLE, emmc_seq_item::SEND_OP_COND, emmc_seq_item::ALL_SEND_CID,
          emmc_seq_item::SET_REL_ADDR, emmc_seq_item::SWITCH, emmc_seq_item::SEND_EXT_CSD,
          emmc_seq_item::SEND_STATUS, emmc_seq_item::SET_BLOCKLEN, emmc_seq_item::READ_SINGLE,
          emmc_seq_item::READ_MULTIPLE, emmc_seq_item::WRITE_SINGLE, emmc_seq_item::WRITE_MULTIPLE,
          emmc_seq_item::ERASE_GRP_START, emmc_seq_item::ERASE_GRP_END, emmc_seq_item::ERASE,
          emmc_seq_item::APP_CMD, emmc_seq_item::SET_BUS_WIDTH, emmc_seq_item::SD_SEND_OP,
          emmc_seq_item::SELECT_CARD, emmc_seq_item::IO_RW_DIRECT, emmc_seq_item::IO_RW_EXTENDED};
        foreach (cand[i])
          if (emmc_seq_item::cmd_index_of(cand[i]) == idx) t = cand[i];
        item.cmd_type = t;
      end
      if (item.is_write_data_cmd())
        pending_wr = item; // publish after the write data burst
      else begin
        item_collected_port.write(item);
        txn_count++;
      end
      `uvm_info(get_type_name(), $sformatf("Monitored CMD: %s", item.convert2string()), UVM_HIGH)
    endfunction

    // Collect write data bursts (host->card) and complete the pending write item
    task automatic collect_wdata();
      bit [7:0] burst[$];
      bit in_burst = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) begin burst.delete(); in_burst = 0; continue; end
        if (vif.mon_cb.data_valid === 1'b1) begin
          burst.push_back(vif.mon_cb.data);
          in_burst = 1;
        end else if (in_burst) begin
          in_burst = 0;
          if (pending_wr != null) begin
            int n = (burst.size() > 0) ? burst.size() - 1 : 0; // drop trailing CRC byte
            pending_wr.data = new[n];
            for (int i = 0; i < n; i++) pending_wr.data[i] = burst[i];
            pending_wr.block_len = n;
            item_collected_port.write(pending_wr);
            txn_count++;
            pending_wr = null;
          end
          burst.delete();
        end
      end
    endtask

    // Decode response frames from the RESP line
    task automatic collect_resp();
      bit [135:0] rframe = 136'h0;
      int nbits = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) begin nbits = 0; rframe = 136'h0; continue; end
        if (vif.mon_cb.resp_valid === 1'b1) begin
          rframe = {rframe[134:0], vif.mon_cb.resp};
          nbits++;
        end else if (nbits > 0) begin
          emmc_seq_item item = emmc_seq_item::type_id::create("rsp_item");
          bit [135:0] f = rframe >> ((nbits >= 48) ? nbits - 48 : 0);
          item.from_host = 1'b0;
          item.cmd_index = f[45:40];
          item.resp      = f[39:8];
          item.resp_valid = 1'b1;
          item.busy      = (vif.mon_cb.card_busy === 1'b1);
          item_collected_port.write(item);
          txn_count++;
          nbits = 0; rframe = 136'h0;
        end
      end
    endtask

    // Decode read data bursts from the DAT lines (card->host)
    task automatic collect_rdata();
      bit [7:0] burst[$];
      bit in_burst = 0;
      forever begin
        @(vif.mon_cb);
        if (!vif.rst_n) begin burst.delete(); in_burst = 0; continue; end
        if (vif.mon_cb.rd_valid === 1'b1) begin
          burst.push_back(vif.mon_cb.rd_data);
          in_burst = 1;
        end else if (in_burst) begin
          emmc_seq_item item = emmc_seq_item::type_id::create("rd_item");
          in_burst = 0;
          item.from_host = 1'b0;
          item.block_len = burst.size();
          item.rdata = new[burst.size()];
          foreach (burst[i]) item.rdata[i] = burst[i];
          item_collected_port.write(item);
          txn_count++;
          burst.delete();
        end
      end
    endtask
  endclass : emmc_monitor

  class emmc_agent extends uvm_agent;
    `uvm_component_utils(emmc_agent)
    emmc_sequencer sqr;
    emmc_driver    drv;
    emmc_monitor   mon;
    emmc_cfg       cfg;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(emmc_cfg)::get(this, "", "cfg", cfg))
        cfg = emmc_cfg::type_id::create("cfg");
      uvm_config_db#(emmc_cfg)::set(this, "*", "cfg", cfg);
      mon = emmc_monitor::type_id::create("mon", this);
      if (cfg.is_active == UVM_ACTIVE) begin
        sqr = emmc_sequencer::type_id::create("sqr", this);
        drv = emmc_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (cfg.is_active == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass : emmc_agent

  //============================================================================
  // eMMC Sequences
  //============================================================================
  class emmc_base_seq extends uvm_sequence #(emmc_seq_item);
    `uvm_object_utils(emmc_base_seq)
    function new(string name = "emmc_base_seq"); super.new(name); endfunction
    task automatic send(emmc_seq_item item);
      start_item(item);
      finish_item(item);
    endtask
    task automatic send_t(emmc_seq_item::cmd_type_e t, bit [31:0] arg = 32'h0);
      emmc_seq_item item = emmc_seq_item::type_id::create("item");
      start_item(item);
      if (!item.randomize() with { cmd_type == t; cmd_arg == arg; })
        `uvm_error(get_type_name(), "Rand failed");
      finish_item(item);
    endtask
  endclass : emmc_base_seq

  // Random read/write mix (normal traffic)
  class emmc_rw_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_rw_seq)
    rand int num_trans = 20;
    function new(string name = "emmc_rw_seq"); super.new(name); endfunction
    task body();
      emmc_seq_item item;
      repeat (num_trans) begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {emmc_seq_item::READ_SINGLE, emmc_seq_item::WRITE_SINGLE};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : emmc_rw_seq

  // Directed: JEDEC initialization chain CMD0->CMD1->CMD2->CMD3->CMD7->CMD16
  class emmc_init_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_init_seq)
    function new(string name = "emmc_init_seq"); super.new(name); endfunction
    task body();
      send_t(emmc_seq_item::GO_IDLE, 32'h0);
      send_t(emmc_seq_item::SEND_OP_COND, 32'h40FF_8000);
      send_t(emmc_seq_item::ALL_SEND_CID, 32'h0);
      send_t(emmc_seq_item::SET_REL_ADDR, 32'h0002_0000);
      send_t(emmc_seq_item::SELECT_CARD, 32'h0002_0000);
      send_t(emmc_seq_item::SET_BLOCKLEN, 32'd512);
      send_t(emmc_seq_item::SEND_STATUS, 32'h0002_0000);
    endtask
  endclass : emmc_init_seq

  // Directed: block reads (CMD17/CMD18)
  class emmc_read_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_read_seq)
    rand int num_trans = 8;
    function new(string name = "emmc_read_seq"); super.new(name); endfunction
    task body();
      repeat (num_trans) begin
        emmc_seq_item item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {emmc_seq_item::READ_SINGLE, emmc_seq_item::READ_MULTIPLE};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : emmc_read_seq

  // Directed: block writes (CMD24/CMD25)
  class emmc_write_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_write_seq)
    rand int num_trans = 8;
    function new(string name = "emmc_write_seq"); super.new(name); endfunction
    task body();
      repeat (num_trans) begin
        emmc_seq_item item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {emmc_seq_item::WRITE_SINGLE, emmc_seq_item::WRITE_MULTIPLE};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : emmc_write_seq

  // Directed: EXT_CSD read + bus-width switch + status polling
  class emmc_config_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_config_seq)
    function new(string name = "emmc_config_seq"); super.new(name); endfunction
    task body();
      send_t(emmc_seq_item::SEND_EXT_CSD, 32'h0);
      send_t(emmc_seq_item::SET_BUS_WIDTH, 32'h03B7_0100); // SWITCH: write BUS_WIDTH=8
      send_t(emmc_seq_item::SEND_STATUS, 32'h0002_0000);
    endtask
  endclass : emmc_config_seq

  // Directed erase: CMD35/CMD36 group range + CMD38
  class emmc_erase_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_erase_seq)
    function new(string name = "emmc_erase_seq"); super.new(name); endfunction
    task body();
      send_t(emmc_seq_item::ERASE_GRP_START, 32'd0);
      send_t(emmc_seq_item::ERASE_GRP_END, 32'd15);
      send_t(emmc_seq_item::ERASE, 32'h0);
    endtask
  endclass : emmc_erase_seq

  // Directed error: out-of-range address, reserved command index, command CRC error
  class emmc_error_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_error_seq)
    rand int num_trans = 4;
    function new(string name = "emmc_error_seq"); super.new(name); endfunction
    task body();
      // address beyond card capacity
      repeat (num_trans) begin
        emmc_seq_item item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {emmc_seq_item::READ_SINGLE, emmc_seq_item::WRITE_SINGLE};
          cmd_arg inside {[EMMC_CAP_BLOCKS : EMMC_CAP_BLOCKS + 255]};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      // corrupted command CRC7 -> R1 COM_CRC_ERROR
      begin
        emmc_seq_item item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == emmc_seq_item::SEND_STATUS; })
          `uvm_error(get_type_name(), "Rand failed");
        item.inject_crc_err = 1'b1;
        finish_item(item);
      end
    endtask
  endclass : emmc_error_seq

  // Directed reset: CMD0 mid-traffic then re-initialize
  class emmc_reset_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_reset_seq)
    function new(string name = "emmc_reset_seq"); super.new(name); endfunction
    task body();
      emmc_init_seq init = emmc_init_seq::type_id::create("init");
      send_t(emmc_seq_item::READ_SINGLE, 32'd0);
      send_t(emmc_seq_item::GO_IDLE, 32'hF0F0_F0F0); // reset with argument
      init.start(m_sequencer);
      send_t(emmc_seq_item::READ_SINGLE, 32'd0); // traffic after re-init
    endtask
  endclass : emmc_reset_seq

  // Back-to-back: zero idle cycles between commands
  class emmc_b2b_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_b2b_seq)
    rand int num_trans = 16;
    function new(string name = "emmc_b2b_seq"); super.new(name); endfunction
    task body();
      repeat (num_trans) begin
        emmc_seq_item item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {emmc_seq_item::READ_SINGLE, emmc_seq_item::WRITE_SINGLE,
                           emmc_seq_item::SEND_STATUS};
          delay == 0;
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : emmc_b2b_seq

  // Stress: heavy randomized traffic
  class emmc_stress_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_stress_seq)
    rand int num_trans = 48;
    function new(string name = "emmc_stress_seq"); super.new(name); endfunction
    task body();
      emmc_seq_item item;
      repeat (num_trans) begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type inside {emmc_seq_item::READ_SINGLE, emmc_seq_item::WRITE_SINGLE,
                           emmc_seq_item::SEND_STATUS, emmc_seq_item::READ_MULTIPLE,
                           emmc_seq_item::WRITE_MULTIPLE};
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : emmc_stress_seq

  // Corner: first/last block, min & max block length, APP_CMD + ACMD41 path
  class emmc_corner_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_corner_seq)
    function new(string name = "emmc_corner_seq"); super.new(name); endfunction
    task body();
      send_t(emmc_seq_item::WRITE_SINGLE, 32'd0);                    // first block
      send_t(emmc_seq_item::READ_SINGLE, 32'd0);
      send_t(emmc_seq_item::WRITE_SINGLE, EMMC_CAP_BLOCKS - 1);      // last block
      send_t(emmc_seq_item::READ_SINGLE, EMMC_CAP_BLOCKS - 1);
      begin // SET_BLOCKLEN with a large length, then a max-length register read
        emmc_seq_item item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with {
          cmd_type == emmc_seq_item::SET_BLOCKLEN; block_len == 16'd4096;
          cmd_arg == 32'd4096;
        }) `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
      send_t(emmc_seq_item::READ_MULTIPLE, EMMC_CAP_BLOCKS - 8);
      send_t(emmc_seq_item::SET_BLOCKLEN, 32'd512); // restore default block length
      send_t(emmc_seq_item::APP_CMD, 32'h0002_0000);                 // ACMD path
      send_t(emmc_seq_item::SD_SEND_OP, 32'h40FF_8000);              // ACMD41
      send_t(emmc_seq_item::IO_RW_DIRECT, 32'h0);
    endtask
  endclass : emmc_corner_seq

  // Coverage: every command type (preserved API)
  class emmc_cov_cmd_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_cov_cmd_seq)
    function new(string name = "emmc_cov_cmd_seq"); super.new(name); endfunction
    task body();
      emmc_seq_item item;
      emmc_seq_item::cmd_type_e cmds[21] = '{
        emmc_seq_item::GO_IDLE, emmc_seq_item::SEND_OP_COND, emmc_seq_item::ALL_SEND_CID,
        emmc_seq_item::SET_REL_ADDR, emmc_seq_item::SWITCH, emmc_seq_item::SEND_EXT_CSD,
        emmc_seq_item::SEND_STATUS, emmc_seq_item::SET_BLOCKLEN, emmc_seq_item::READ_SINGLE,
        emmc_seq_item::READ_MULTIPLE, emmc_seq_item::WRITE_SINGLE, emmc_seq_item::WRITE_MULTIPLE,
        emmc_seq_item::ERASE_GRP_START, emmc_seq_item::ERASE_GRP_END, emmc_seq_item::ERASE,
        emmc_seq_item::APP_CMD, emmc_seq_item::SET_BUS_WIDTH, emmc_seq_item::SD_SEND_OP,
        emmc_seq_item::SELECT_CARD, emmc_seq_item::IO_RW_DIRECT, emmc_seq_item::IO_RW_EXTENDED};
      foreach (cmds[i]) begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { cmd_type == cmds[i]; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : emmc_cov_cmd_seq

  // Coverage: every bus width (preserved API)
  class emmc_cov_bw_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_cov_bw_seq)
    function new(string name = "emmc_cov_bw_seq"); super.new(name); endfunction
    task body();
      emmc_seq_item item;
      for (int bw = 0; bw < 3; bw++) begin
        item = emmc_seq_item::type_id::create("item");
        start_item(item);
        if (!item.randomize() with { bus_width == bw; })
          `uvm_error(get_type_name(), "Rand failed");
        finish_item(item);
      end
    endtask
  endclass : emmc_cov_bw_seq

  // Regression mix: init + every directed sequence in order
  // REACHABILITY: deterministic command chain hitting every emmc_fsm_cg
  // transition bin (init_chain / ident / acmd / wr_status / rd_wr / erase_grp).
  class emmc_fsm_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_fsm_seq)
    function new(string name = "emmc_fsm_seq"); super.new(name); endfunction
    task body();
      send_t(emmc_seq_item::GO_IDLE, 32'h0);
      send_t(emmc_seq_item::SEND_OP_COND, 32'h40FF_8000);    // init_chain
      send_t(emmc_seq_item::ALL_SEND_CID, 32'h0);
      send_t(emmc_seq_item::SET_REL_ADDR, 32'h0002_0000);    // ident
      send_t(emmc_seq_item::APP_CMD, 32'h0002_0000);
      send_t(emmc_seq_item::SD_SEND_OP, 32'h40FF_8000);      // acmd
      send_t(emmc_seq_item::WRITE_SINGLE, 32'd0);
      send_t(emmc_seq_item::SEND_STATUS, 32'h0002_0000);     // wr_status
      send_t(emmc_seq_item::READ_SINGLE, 32'd0);
      send_t(emmc_seq_item::WRITE_SINGLE, 32'd0);            // rd_wr
      send_t(emmc_seq_item::ERASE_GRP_START, 32'd0);
      send_t(emmc_seq_item::ERASE_GRP_END, 32'd15);          // erase_grp
      send_t(emmc_seq_item::ERASE, 32'h0);
    endtask
  endclass : emmc_fsm_seq

  class emmc_regression_mix_seq extends emmc_base_seq;
    `uvm_object_utils(emmc_regression_mix_seq)
    function new(string name = "emmc_regression_mix_seq"); super.new(name); endfunction
    task body();
      emmc_init_seq   i  = emmc_init_seq::type_id::create("i");
      emmc_fsm_seq    f  = emmc_fsm_seq::type_id::create("f");
      emmc_config_seq cf = emmc_config_seq::type_id::create("cf");
      emmc_read_seq   r  = emmc_read_seq::type_id::create("r");
      emmc_write_seq  w  = emmc_write_seq::type_id::create("w");
      emmc_erase_seq  e  = emmc_erase_seq::type_id::create("e");
      emmc_error_seq  er = emmc_error_seq::type_id::create("er");
      emmc_reset_seq  rs = emmc_reset_seq::type_id::create("rs");
      emmc_b2b_seq    b  = emmc_b2b_seq::type_id::create("b");
      emmc_corner_seq c  = emmc_corner_seq::type_id::create("c");
      emmc_stress_seq s  = emmc_stress_seq::type_id::create("s");
      `uvm_info(get_type_name(), "=== eMMC regression mix: init/config/rw/erase/error/reset/b2b/corner/stress ===", UVM_LOW)
      i.start(m_sequencer);
      f.start(m_sequencer);
      cf.start(m_sequencer);
      r.num_trans = 4;  r.start(m_sequencer);
      w.num_trans = 4;  w.start(m_sequencer);
      e.start(m_sequencer);
      er.num_trans = 2; er.start(m_sequencer);
      rs.start(m_sequencer);
      b.num_trans = 8;  b.start(m_sequencer);
      c.start(m_sequencer);
      s.num_trans = 16; s.start(m_sequencer);
    endtask
  endclass : emmc_regression_mix_seq
endpackage : emmc_pkg
`endif
