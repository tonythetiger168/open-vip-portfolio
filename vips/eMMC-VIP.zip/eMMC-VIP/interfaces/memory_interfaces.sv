// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// memory_interfaces.sv -- Memory/Storage Protocol Interfaces with UVM Clocking Blocks
// 9 Protocols: DDR4/5, LPDDR4/5/6, HBM2/2E/3, UFS, UniPro, eMMC, ONFI, SD/SDIO
`ifndef MEMORY_INTERFACES_SV
`define MEMORY_INTERFACES_SV

interface ddr_if #(parameter ADDR_WIDTH = 17, parameter DATA_WIDTH = 64)
  (input logic ck, input logic ck_n, input logic rst_n);
  logic [ADDR_WIDTH-1:0] addr;
  logic [2:0]  ba;        // Bank address
  logic [1:0]  bg;        // Bank group (DDR5)
  logic        ras_n, cas_n, we_n, cs_n, cke, odt, act_n;
  wire  [DATA_WIDTH-1:0] dq;
  wire  [7:0]  dqs, dqs_n, dm;
  // Timing
  int tRCD = 18; int tRP = 18; int tRAS = 42; int tCL = 22; int tCWL = 11;
  clocking drv_cb @(posedge ck);
    default input #0.5 output #0.5;
    output addr, ba, bg, ras_n, cas_n, we_n, cs_n, cke, odt, act_n;
    inout  dq, dqs, dqs_n, dm;
  endclocking
  clocking mon_cb @(posedge ck);
    default input #0.5 output #0.5;
    input addr, ba, bg, ras_n, cas_n, we_n, cs_n, cke, odt, act_n;
    input dq, dqs, dqs_n, dm;
  endclocking
  modport driver  (clocking drv_cb, input ck, ck_n, rst_n);
  modport monitor (clocking mon_cb, input ck, ck_n, rst_n);
endinterface : ddr_if

interface lpddr_if #(parameter ADDR_WIDTH = 16, parameter DATA_WIDTH = 32, parameter CA_WIDTH = 6)
  (input logic ck, input logic ck_n, input logic cke, input logic rst_n);
  logic [CA_WIDTH-1:0] ca;
  logic                cs;
  wire  [DATA_WIDTH-1:0] dq;
  wire  [3:0]  dqs, dqs_n, dm, dmi;
  // Timing
  int tRCD = 18; int tRP = 18; int tRAS = 42; int tCL = 22; int tCWL = 11;
  clocking drv_cb @(posedge ck);
    default input #0.5 output #0.5;
    output ca, cs;
    inout  dq, dqs, dqs_n, dm, dmi;
  endclocking
  clocking mon_cb @(posedge ck);
    default input #0.5 output #0.5;
    input ca, cs;
    input dq, dqs, dqs_n, dm, dmi;
  endclocking
  modport driver  (clocking drv_cb, input ck, ck_n, cke, rst_n);
  modport monitor (clocking mon_cb, input ck, ck_n, cke, rst_n);
endinterface : lpddr_if

interface hbm_if #(parameter ADDR_WIDTH = 34, parameter DATA_WIDTH = 128, parameter CHANNELS = 8)
  (input logic ck, input logic ck_n, input logic rst_n);
  logic [ADDR_WIDTH-1:0] addr;
  logic [2:0]  cid;
  logic [3:0]  ba;
  logic        cs_n, cke, ras_n, cas_n, we_n, par;
  wire  [DATA_WIDTH-1:0] dq;
  wire  [15:0] dqs, dqs_n, dm;
  // Timing
  int tRCD = 14; int tRP = 14; int tRAS = 34; int tCL = 14; int tCWL = 8;
  clocking drv_cb @(posedge ck);
    default input #0.5 output #0.5;
    output addr, cid, ba, cs_n, cke, ras_n, cas_n, we_n, par;
    inout  dq, dqs, dqs_n, dm;
  endclocking
  clocking mon_cb @(posedge ck);
    default input #0.5 output #0.5;
    input addr, cid, ba, cs_n, cke, ras_n, cas_n, we_n, par;
    input dq, dqs, dqs_n, dm;
  endclocking
  modport driver  (clocking drv_cb, input ck, ck_n, rst_n);
  modport monitor (clocking mon_cb, input ck, ck_n, rst_n);
endinterface : hbm_if

interface ufs_if #(parameter DATA_WIDTH = 8, parameter LANE_COUNT = 2)
  (input logic ref_clk, input logic rst_n);
  // M-PHY based interface
  logic [LANE_COUNT-1:0] tx_dp, tx_dn, rx_dp, rx_dn;
  // UFS application layer (byte-serial UTP transfer)
  logic [DATA_WIDTH-1:0] data_out;
  logic                  data_out_valid;
  logic [DATA_WIDTH-1:0] data_in;
  logic                  data_in_valid;
  logic [7:0]            task_tag;
  logic [15:0]           data_length;
  // UPIU (UFS Protocol Information Unit) types
  typedef enum logic [7:0] {
    UPIU_NOP_OUT     = 8'h00, UPIU_COMMAND     = 8'h01,
    UPIU_DATA_OUT    = 8'h02, UPIU_TASK_MGT    = 8'h04,
    UPIU_QUERY_REQ   = 8'h16, UPIU_NOP_IN      = 8'h20,
    UPIU_RESPONSE    = 8'h21, UPIU_DATA_IN     = 8'h22,
    UPIU_TASK_MGT_RSP= 8'h24, UPIU_QUERY_RSP   = 8'h36,
    UPIU_READY_XFER  = 8'h31, UPIU_REJECT      = 8'h3F
  } upiu_t;
  // Deepened: protocol sideband/status signals used by VIP + tiered SVA checkers
  logic [7:0]  lun_id;         // LUN sideband for current UPIU (host)
  logic [3:0]  cmd_type;       // UPIU transaction type of current transfer (host)
  logic [7:0]  req_data;       // opcode / argument of current request (host)
  logic        req_valid;      // request (header) phase active (host)
  logic        doorbell;       // UTP doorbell: new UPIU queued (host pulse)
  logic        valid;          // generic transfer valid (host)
  logic        transfer_ready; // device ready-to-transfer (RTT) for write data
  logic        ready;          // device ready
  logic        busy;           // device processing a command
  logic        err;            // device error indication
  logic [1:0]  data_dir;       // 00=idle 01=host->dev 10=dev->host
  logic [2:0]  status;         // device status class
  logic [2:0]  power_state;    // device power state
  logic        resp_valid;     // response UPIU in flight (device)
  logic [2:0]  resp_status;    // response status (device)
  clocking drv_cb @(posedge ref_clk);
    default input #1 output #1;
    output tx_dp, tx_dn, data_out, data_out_valid, task_tag, data_length;
    output lun_id, cmd_type, req_data, req_valid, doorbell, valid;
    input  rx_dp, rx_dn, data_in, data_in_valid;
    input  transfer_ready, ready, busy, err, data_dir, status, power_state, resp_valid, resp_status;
  endclocking
  clocking mon_cb @(posedge ref_clk);
    default input #1 output #1;
    input tx_dp, tx_dn, rx_dp, rx_dn;
    input data_out, data_out_valid, data_in, data_in_valid, task_tag, data_length;
    input lun_id, cmd_type, req_data, req_valid, doorbell, valid;
    input transfer_ready, ready, busy, err, data_dir, status, power_state, resp_valid, resp_status;
  endclocking
  modport driver  (clocking drv_cb, input ref_clk, rst_n);
  modport monitor (clocking mon_cb, input ref_clk, rst_n);
endinterface : ufs_if

interface unipro_if #(parameter DATA_WIDTH = 8, parameter LANE_COUNT = 2)
  (input logic clk, input logic rst_n);
  // UniPro uses M-PHY physical layer
  logic [LANE_COUNT-1:0] tx_dp, tx_dn, rx_dp, rx_dn;
  // L2 CAP (Credit-based flow control)
  logic [7:0]            tx_cred, rx_cred;
  logic                  tx_cred_valid, rx_cred_valid;
  // L3 PA (Protocol Adapter)
  logic [DATA_WIDTH-1:0] tx_data, rx_data;
  logic                  tx_data_valid, rx_data_valid;
  // CPort ID
  logic [4:0]            cportid;
  // UniPro message types
  typedef enum logic [3:0] {
    UNI_NOP     = 4'h0, UNI_DATA    = 4'h1,
    UNI_CTRL    = 4'h2, UNI_CREDIT  = 4'h3,
    UNI_ERROR   = 4'hF
  } unipro_msg_t;
  clocking drv_cb @(posedge clk);
    default input #1 output #1;
    output tx_dp, tx_dn, tx_cred, tx_cred_valid, tx_data, tx_data_valid, cportid;
    input  rx_dp, rx_dn, rx_cred, rx_cred_valid, rx_data, rx_data_valid;
  endclocking
  clocking mon_cb @(posedge clk);
    default input #1 output #1;
    input tx_dp, tx_dn, rx_dp, rx_dn;
    input tx_cred, tx_cred_valid, rx_cred, rx_cred_valid;
    input tx_data, tx_data_valid, rx_data, rx_data_valid, cportid;
  endclocking
  modport driver  (clocking drv_cb, input clk, rst_n);
  modport monitor (clocking mon_cb, input clk, rst_n);
endinterface : unipro_if

interface emmc_if #(parameter DATA_WIDTH = 8)
  (input logic clk, input logic rst_n);
  logic        cmd, cmd_valid;
  logic [DATA_WIDTH-1:0] data;
  logic        data_valid, data_read;
  logic [5:0]  cmd_index;
  logic [31:0] cmd_arg;
  logic        resp, resp_valid, busy;
  // Bus widths
  typedef enum logic [1:0] {
    BW_1BIT = 2'b00, BW_4BIT = 2'b01, BW_8BIT = 2'b10, BW_RSVD = 2'b11
  } emmc_bw_t;
  // Deepened: protocol sideband/status signals used by VIP + tiered SVA checkers
  logic [7:0]  rd_data;      // card->host read data (DAT lines, read direction)
  logic        rd_valid;
  logic        card_busy;    // DAT0 busy during programming/erase
  logic        data_end;     // host: last data beat of a write block
  logic        data_write;   // host: write data phase active
  logic        data_crc_ok;  // card: write-data CRC check result
  logic [2:0]  bus_width;    // 001=1-bit 010=4-bit 100=8-bit (host config sideband)
  logic [2:0]  speed_mode;   // 000 legacy 001 HS 010 HS200 011 HS400 (host sideband)
  logic [3:0]  card_state;   // 0 idle 1 ready 2 ident 3 stby 4 tran 5 data 6 rcv 7 prg 8 dis
  logic [2:0]  resp_type;    // 0 none 1 R1 2 R2 3 R3 4 R1b
  logic        err;          // card error indication (R1 error bits set)
  logic [2:0]  status;       // card status class
  logic [2:0]  power_state;  // card power state
  logic        ready;        // card ready for a new command
  logic        valid;        // host transfer valid (cmd or data)
  logic        app_cmd;      // CMD55 prefix seen; next command is application-specific
  clocking drv_cb @(posedge clk);
    default input #1 output #1;
    output cmd, cmd_valid, data, data_valid, data_read, cmd_index, cmd_arg;
    output data_end, data_write, bus_width, speed_mode, valid;
    input  resp, resp_valid, busy;
    input  rd_data, rd_valid, card_busy, data_crc_ok, card_state, resp_type;
    input  err, status, power_state, ready, app_cmd;
  endclocking
  clocking mon_cb @(posedge clk);
    default input #1 output #1;
    input cmd, cmd_valid, data, data_valid, data_read, cmd_index, cmd_arg;
    input resp, resp_valid, busy;
    input data_end, data_write, bus_width, speed_mode, valid;
    input rd_data, rd_valid, card_busy, data_crc_ok, card_state, resp_type;
    input err, status, power_state, ready, app_cmd;
  endclocking
  modport driver  (clocking drv_cb, input clk, rst_n);
  modport monitor (clocking mon_cb, input clk, rst_n);
endinterface : emmc_if

interface onfi_if #(parameter DATA_WIDTH = 8, parameter ADDR_WIDTH = 16)
  (input logic clk, input logic rst_n);
  logic [DATA_WIDTH-1:0] io;
  logic        cle, ale, ce_n, re_n, we_n, wp_n, rb_n;
  // Status register bits
  typedef enum logic [7:0] {
    STAT_FAIL       = 8'h01, STAT_FAILC      = 8'h02,
    STAT_CSP        = 8'h08, STAT_VSP        = 8'h10,
    STAT_ARDY       = 8'h20, STAT_RDY        = 8'h40,
    STAT_WP         = 8'h80
  } onfi_status_t;
  clocking drv_cb @(posedge clk);
    default input #1 output #1;
    output io, cle, ale, ce_n, re_n, we_n, wp_n;
    input  rb_n;
  endclocking
  clocking mon_cb @(posedge clk);
    default input #1 output #1;
    input io, cle, ale, ce_n, re_n, we_n, wp_n, rb_n;
  endclocking
  modport driver  (clocking drv_cb, input clk, rst_n);
  modport monitor (clocking mon_cb, input clk, rst_n);
endinterface : onfi_if

interface sd_if #(parameter DATA_WIDTH = 4)
  (input logic clk, input logic rst_n);
  logic        cmd;
  logic [DATA_WIDTH-1:0] dat;
  logic        cmd_dir, dat_dir;
  // Transfer modes
  typedef enum logic {
    TM_BLOCK     = 1'b0, TM_STREAM    = 1'b1
  } sd_tm_t;
  clocking drv_cb @(posedge clk);
    default input #1 output #1;
    output cmd, dat, cmd_dir, dat_dir;
  endclocking
  clocking mon_cb @(posedge clk);
    default input #1 output #1;
    input cmd, dat, cmd_dir, dat_dir;
  endclocking
  modport driver  (clocking drv_cb, input clk, rst_n);
  modport monitor (clocking mon_cb, input clk, rst_n);
endinterface : sd_if
`endif
