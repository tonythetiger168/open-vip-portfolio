// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- IDE testbench top with a functional IDE DUT model

`ifndef PCIE_IDE_UVM_VIP_TB_SV
`define PCIE_IDE_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ide_defs_pkg::*;
import ide_pkg::*;
import ide_env_pkg::*;
import ide_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ide_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ide_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .in_valid(vif.in_valid),
    .in_dw(vif.in_dw),
    .in_last(vif.in_last),
    .out_valid(vif.out_valid),
    .out_dw(vif.out_dw),
    .out_last(vif.out_last),
    .rep_valid(vif.rep_valid),
    .rep_status(vif.rep_status)
  );

  // Concurrent protocol checks
  ide_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .in_valid(vif.in_valid),
    .in_dw(vif.in_dw),
    .in_last(vif.in_last),
    .out_valid(vif.out_valid),
    .out_dw(vif.out_dw),
    .out_last(vif.out_last),
    .rep_valid(vif.rep_valid),
    .rep_status(vif.rep_status)
  );

  initial begin
    uvm_config_db#(virtual ide_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ide_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        in_valid,
  input  logic [31:0] in_dw,
  input  logic        in_last,
  output logic        out_valid,
  output logic [31:0] out_dw,
  output logic        out_last,
  output logic        rep_valid,
  output logic [2:0]  rep_status
);
  localparam logic [255:0] KBASE = 256'h0001_0203_0405_0607_0809_0A0B_0C0D_0E0F_1011_1213_1415_1617_1819_1A1B_1C1D_1E1F;
  localparam logic [7:0]   SID   = 8'd3;

  function automatic logic [7:0] xt(input logic [7:0] a);
    xt = {a[6:0], 1'b0} ^ (a[7] ? 8'h1B : 8'h00);
  endfunction
  function automatic logic [7:0] gm(input logic [7:0] a, input logic [7:0] b);
    logic [7:0] p, x;
    p = 8'h00; x = a;
    for (int i = 0; i < 8; i++) begin
      if (b[i]) p = p ^ x;
      x = xt(x);
    end
    gm = p;
  endfunction
  function automatic logic [7:0] sbox(input logic [7:0] a);
    logic [7:0] r;
    r = 8'h01;
    for (int i = 7; i >= 0; i--) begin
      r = gm(r, r);
      if (i != 0) r = gm(r, a);
    end
    sbox = r ^ {r[6:0], r[7]} ^ {r[5:0], r[7:6]} ^ {r[4:0], r[7:5]} ^ {r[3:0], r[7:4]} ^ 8'h63;
  endfunction
  function automatic logic [31:0] subw(input logic [31:0] w);
    subw = {sbox(w[31:24]), sbox(w[23:16]), sbox(w[15:8]), sbox(w[7:0])};
  endfunction
  function automatic logic [127:0] kexp(input logic [127:0] k, input logic [31:0] w);
    logic [127:0] n;
    n[127:96] = k[127:96] ^ w;
    n[95:64]  = k[95:64] ^ n[127:96];
    n[63:32]  = k[63:32] ^ n[95:64];
    n[31:0]   = k[31:0] ^ n[63:32];
    kexp = n;
  endfunction
  function automatic logic [127:0] aes(input logic [255:0] key, input logic [127:0] blk);
    logic [127:0] ka, kb, s, t, rk;
    logic [7:0]   rc, a0, a1, a2, a3;
    ka = key[255:128]; kb = key[127:0]; s = blk ^ key[255:128]; rc = 8'h01;
    for (int r = 1; r <= 14; r++) begin
      for (int c = 0; c < 4; c++)
        for (int j = 0; j < 4; j++)
          t[127 - 8*(4*c + j) -: 8] = sbox(s[127 - 8*(4*((c + j) % 4) + j) -: 8]);
      if (r != 14)
        for (int c = 0; c < 4; c++) begin
          a0 = t[127 - 32*c -: 8]; a1 = t[119 - 32*c -: 8]; a2 = t[111 - 32*c -: 8]; a3 = t[103 - 32*c -: 8];
          t[127 - 32*c -: 8] = xt(a0) ^ xt(a1) ^ a1 ^ a2 ^ a3;
          t[119 - 32*c -: 8] = a0 ^ xt(a1) ^ xt(a2) ^ a2 ^ a3;
          t[111 - 32*c -: 8] = a0 ^ a1 ^ xt(a2) ^ xt(a3) ^ a3;
          t[103 - 32*c -: 8] = xt(a0) ^ a0 ^ a1 ^ a2 ^ xt(a3);
        end
      if (r == 1) rk = kb;
      else if (r % 2 == 0) begin
        ka = kexp(ka, subw({kb[23:0], kb[31:24]}) ^ {rc, 24'h0});
        rc = xt(rc);
        rk = ka;
      end else begin
        kb = kexp(kb, subw(ka[31:0]));
        rk = kb;
      end
      s = t ^ rk;
    end
    aes = s;
  endfunction
  function automatic logic [127:0] gmul(input logic [127:0] x, input logic [127:0] y);
    logic [127:0] z, v;
    z = 128'h0; v = y;
    for (int i = 0; i < 128; i++) begin
      if (x[127 - i]) z = z ^ v;
      v = v[0] ? ((v >> 1) ^ {8'hE1, 120'h0}) : (v >> 1);
    end
    gmul = z;
  endfunction

  logic [7:0]  rb [0:191];      // TLP bytes
  logic [31:0] ob [0:47];       // delivered DWs
  logic [7:0]  nrb;             // DWs received
  logic [5:0]  olen, opos;
  logic        go, busy, insecure;
  logic [63:0] ctr [0:5];       // receive counters, index 2 * sub-stream + key set

  function automatic logic [127:0] blk(input integer from, input integer lim);
    logic [127:0] v;
    for (int j = 0; j < 16; j++) v[127 - 8*j -: 8] = (from + j < lim) ? rb[from + j] : 8'h00;
    blk = v;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      nrb <= '0; olen <= '0; opos <= '0; go <= 1'b0; busy <= 1'b0; insecure <= 1'b0;
      for (int i = 0; i < 6; i++) ctr[i] <= 64'd1;
      out_valid <= 1'b0; out_dw <= '0; out_last <= 1'b0; rep_valid <= 1'b0; rep_status <= '0;
    end else begin
      rep_valid <= 1'b0; out_valid <= 1'b0; out_last <= 1'b0;
      go <= in_valid && in_last;
      if (in_valid) begin
        if (nrb < 8'd48) begin
          rb[4*nrb] <= in_dw[31:24]; rb[4*nrb + 1] <= in_dw[23:16]; rb[4*nrb + 2] <= in_dw[15:8]; rb[4*nrb + 3] <= in_dw[7:0];
        end
        nrb <= nrb + 8'd1;
      end
      if (go) begin : receive
        logic [2:0]   st, ss, want;
        logic [9:0]   len;
        logic [255:0] key;
        logic [127:0] hk, x, tag, ks, cb, mac;
        logic [95:0]  iv;
        logic [63:0]  la, lc, c;
        integer       n, plen, nd;
        n = 4 * nrb;
        nrb <= '0;
        st = 3'd0; nd = 0;
        if (n < 4 || rb[0] != 8'h92) begin
          if (n == 16 && rb[0] == 8'h72 && rb[7] == 8'h7F && rb[12] == 8'h05 && rb[14] == SID) begin
            st = 3'd5;
            for (int i = 0; i < 6; i++) ctr[i] <= 64'd1;
            insecure <= 1'b0;
          end else begin
            st = 3'd1;
            for (int i = 0; i < 48; i++) if (4*i < n) ob[i] <= {rb[4*i], rb[4*i + 1], rb[4*i + 2], rb[4*i + 3]};
            nd = n / 4;
          end
        end else begin
          ss = rb[1][3:1];
          want = (rb[4] == 8'h40) ? 3'd0 : (rb[4] == 8'h00) ? 3'd1 : (rb[4] == 8'h4A) ? 3'd2 : 3'd7;
          len = {rb[6][1:0], rb[7]};
          plen = (want == 3'd1) ? 0 : 4 * ((len == 10'd0) ? 1024 : len);
          if (rb[2] != SID || want == 3'd7 || ss != want || !rb[1][7] || rb[1][4] || plen > 32 || n != 16 + plen + 12) st = 3'd2;
          else if (insecure) st = 3'd4;
          else begin
            key = KBASE ^ {251'h0, ss, 1'b0, rb[1][6]};
            c = ctr[2*ss + rb[1][6]];
            iv = {16'h0, 5'h0, ss, SID, c};
            hk = aes(key, 128'h0);
            x = gmul(blk(0, 16), hk);
            for (int b = 0; b < 2; b++) if (16*b < plen) x = gmul(x ^ blk(16 + 16*b, 16 + plen), hk);
            la = 64'd128; lc = plen * 8;
            x = gmul(x ^ {la, lc}, hk);
            tag = x ^ aes(key, {iv, 32'h1});
            mac = blk(16 + plen, 16 + plen + 12);
            if (tag[127:32] != mac[127:32]) begin
              st = 3'd3; insecure <= 1'b1;
            end else begin
              ctr[2*ss + rb[1][6]] <= c + 64'd1;
              for (int i = 0; i < 3; i++) ob[i] <= {rb[4 + 4*i], rb[5 + 4*i], rb[6 + 4*i], rb[7 + 4*i]};
              for (int b = 0; b < 2; b++)
                if (16*b < plen) begin
                  ks = aes(key, {iv, 32'd2 + b});
                  cb = blk(16 + 16*b, 16 + plen) ^ ks;
                  for (int j = 0; j < 4; j++) if (16*b + 4*j < plen) ob[3 + 4*b + j] <= cb[127 - 32*j -: 32];
                end
              nd = 3 + plen / 4;
            end
          end
        end
        if (nd != 0) begin olen <= 6'(nd); opos <= '0; busy <= 1'b1; end
        else begin rep_valid <= 1'b1; rep_status <= st; end
        rep_status <= st;
      end
      if (busy) begin
        out_valid <= 1'b1;
        out_dw <= ob[opos];
        opos <= opos + 6'd1;
        if (opos == olen - 6'd1) begin out_last <= 1'b1; busy <= 1'b0; rep_valid <= 1'b1; end
      end
    end
  end
endmodule
`endif
