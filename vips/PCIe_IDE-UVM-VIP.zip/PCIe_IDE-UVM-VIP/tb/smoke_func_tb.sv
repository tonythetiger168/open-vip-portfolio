// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (IDE DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened ide_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic in_valid = 1'b0, in_last = 1'b0;
  logic [31:0] in_dw = 32'h0;
  wire out_valid, out_last, rep_valid;
  wire [31:0] out_dw;
  wire [2:0] rep_status;

  always #5 clk = ~clk;

  ide_model u_dut (.clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_dw(in_dw), .in_last(in_last),
                   .out_valid(out_valid), .out_dw(out_dw), .out_last(out_last), .rep_valid(rep_valid), .rep_status(rep_status));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // reference AES-256 / GHASH (table S-box from brute-force inverses)
  function automatic logic [7:0] r_xt(input logic [7:0] a); r_xt = {a[6:0], 1'b0} ^ (a[7] ? 8'h1B : 8'h00); endfunction
  logic [7:0] sb [0:255];
  initial for (int i = 0; i < 256; i++) begin : mk_sbox
    logic [7:0] r, p, x, y;
    r = 8'h00;
    for (int b = 1; b < 256; b++) begin
      p = 8'h00; x = i; y = b;
      for (int k = 0; k < 8; k++) begin
        if (y[k]) p = p ^ x;
        x = r_xt(x);
      end
      if (p == 8'h01) r = b;
    end
    sb[i] = r ^ {r[6:0], r[7]} ^ {r[5:0], r[7:6]} ^ {r[4:0], r[7:5]} ^ {r[3:0], r[7:4]} ^ 8'h63;
  end
  function automatic logic [31:0] r_mix(input logic [31:0] c);
    logic [7:0] a0, a1, a2, a3;
    {a0, a1, a2, a3} = c;
    r_mix = {r_xt(a0) ^ r_xt(a1) ^ a1 ^ a2 ^ a3, a0 ^ r_xt(a1) ^ r_xt(a2) ^ a2 ^ a3,
             a0 ^ a1 ^ r_xt(a2) ^ r_xt(a3) ^ a3, r_xt(a0) ^ a0 ^ a1 ^ a2 ^ r_xt(a3)};
  endfunction
  function automatic logic [31:0] r_sw(input logic [31:0] w); r_sw = {sb[w[31:24]], sb[w[23:16]], sb[w[15:8]], sb[w[7:0]]}; endfunction
  // full key schedule: 60 words
  function automatic logic [127:0] r_aes(input logic [255:0] key, input logic [127:0] pt);
    logic [31:0] w [0:59];
    logic [31:0] tmp;
    logic [127:0] s, t;
    logic [7:0] rc;
    for (int i = 0; i < 8; i++) w[i] = key[255 - 32*i -: 32];
    rc = 8'h01;
    for (int i = 8; i < 60; i++) begin
      tmp = w[i - 1];
      if (i % 8 == 0) begin tmp = r_sw({tmp[23:0], tmp[31:24]}) ^ {rc, 24'h0}; rc = r_xt(rc); end
      else if (i % 8 == 4) tmp = r_sw(tmp);
      w[i] = w[i - 8] ^ tmp;
    end
    s = pt ^ {w[0], w[1], w[2], w[3]};
    for (int r = 1; r <= 14; r++) begin
      for (int c = 0; c < 4; c++)
        for (int j = 0; j < 4; j++)
          t[8*(15 - 4*c - j) +: 8] = sb[s[8*(15 - 4*((c + j) & 3) - j) +: 8]];
      if (r < 14) for (int c = 0; c < 4; c++) t[32*(3 - c) +: 32] = r_mix(t[32*(3 - c) +: 32]);
      s = t ^ {w[4*r], w[4*r + 1], w[4*r + 2], w[4*r + 3]};
    end
    r_aes = s;
  endfunction
  function automatic logic [127:0] r_gmul(input logic [127:0] x, input logic [127:0] y);
    logic [127:0] z, v;
    z = 0; v = x;
    for (int i = 127; i >= 0; i--) begin
      if (y[i]) z = z ^ v;
      v = v[0] ? ((v >> 1) ^ {8'hE1, 120'h0}) : (v >> 1);
    end
    r_gmul = z;
  endfunction

  logic [255:0] KB = 256'h0001_0203_0405_0607_0809_0A0B_0C0D_0E0F_1011_1213_1415_1617_1819_1A1B_1C1D_1E1F;
  logic [7:0] tb_ [0:191];
  logic [7:0] pt [0:63];
  integer tn, plen;
  logic [63:0] txc [0:5];
  function automatic logic [127:0] tblk(input integer from, input integer lim);
    logic [127:0] v;
    for (int j = 0; j < 16; j++) v[8*(15 - j) +: 8] = (from + j < lim) ? tb_[from + j] : 8'h00;
    tblk = v;
  endfunction
  // IDE TLP: type 0 MWr / 1 MRd / 2 CplD, ndw payload DWs, sub-stream ss, key set ks, stream sid, counter c
  task automatic ide(input integer typ, input integer ndw, input integer ss, input integer ks, input integer sid,
                     input logic [63:0] c, input logic m = 1, input logic p = 0);
    logic [255:0] key;
    logic [127:0] hk, x, k2, tag;
    logic [95:0] iv;
    logic [63:0] la, lc;
    for (int i = 0; i < 192; i++) tb_[i] = 8'h00;
    tb_[0] = 8'h92; tb_[1] = {m, ks[0], 1'b1, p, ss[2:0], 1'b0}; tb_[2] = sid; tb_[3] = 8'h00;
    tb_[4] = (typ == 1) ? 8'h00 : (typ == 2) ? 8'h4A : 8'h40; tb_[6] = 8'h00; tb_[7] = ndw;
    for (int i = 8; i < 16; i++) tb_[i] = 8'hC0 + i + ndw;
    plen = (typ == 1) ? 0 : 4 * ndw;
    for (int i = 0; i < 64; i++) pt[i] = 8'h31 * i + ndw + 8'h0B * ss;
    key = KB ^ {251'h0, ss[2:0], 1'b0, ks[0]};
    iv = {16'h0, 5'h0, ss[2:0], sid[7:0], c};
    hk = r_aes(key, 0);
    for (int b = 0; b < 2; b++) begin
      k2 = r_aes(key, {iv, 32'd2 + b});
      for (int j = 0; j < 16; j++) if (16*b + j < plen) tb_[16 + 16*b + j] = pt[16*b + j] ^ k2[8*(15 - j) +: 8];
    end
    x = r_gmul(tblk(0, 16), hk);
    for (int b = 0; b < 2; b++) if (16*b < plen) x = r_gmul(x ^ tblk(16 + 16*b, 16 + plen), hk);
    la = 128; lc = plen * 8;
    x = r_gmul(x ^ {la, lc}, hk);
    tag = x ^ r_aes(key, {iv, 32'h1});
    for (int j = 0; j < 12; j++) tb_[16 + plen + j] = tag[8*(15 - j) +: 8];
    tn = 16 + plen + 12;
  endtask

  logic [31:0] ob [0:63];
  integer on = 0, nrep = 0, nlast = 0, ndel = 0;
  logic [2:0] st;
  always @(posedge clk) begin
    if (out_valid) begin ob[on] = out_dw; on = on + 1; if (out_last) nlast = nlast + 1; end
    if (rep_valid && rep_status <= 3'd1 && out_last) ndel = ndel + 1;
    if (rep_valid) begin nrep = nrep + 1; st = rep_status; end
  end
  task automatic send();
    integer r0, k;
    r0 = nrep; on = 0;
    for (int i = 0; i < 192; i += 4)
      if (i < tn) begin
        @(negedge clk); in_valid = 1; in_dw = {tb_[i], tb_[i + 1], tb_[i + 2], tb_[i + 3]}; in_last = (i + 4 >= tn);
      end
    @(negedge clk); in_valid = 0; in_last = 0;
    k = 0;
    while (k < 200 && nrep == r0) begin @(negedge clk); k = k + 1; end
    @(negedge clk);
  endtask
  // delivered: header DWs and the plaintext
  function automatic logic delivered(input integer ndw);
    logic ok;
    ok = (on == 3 + ndw);
    for (int i = 0; i < 3; i++) if (ob[i] !== {tb_[4 + 4*i], tb_[5 + 4*i], tb_[6 + 4*i], tb_[7 + 4*i]}) ok = 0;
    for (int i = 0; i < 16; i++) if (i < ndw && ob[3 + i] !== {pt[4*i], pt[4*i + 1], pt[4*i + 2], pt[4*i + 3]}) ok = 0;
    delivered = ok;
  endfunction
  task automatic want(input integer s, input integer ndw, input string msg);
    if (s == 0) chk(st == 3'd0 && delivered(ndw), msg);
    else chk(st == s && on == 0, msg);
  endtask
  task automatic set_go(input integer sid);
    for (int i = 0; i < 192; i++) tb_[i] = 8'h00;
    tb_[0] = 8'h72; tb_[3] = 8'h01; tb_[7] = 8'h7F; tb_[12] = 8'h05; tb_[14] = sid;
    tn = 16;
    send();
  endtask

  initial begin
    logic [127:0] h0;
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0 && out_valid === 1'b0 && out_last === 1'b0, "nothing out in reset");
    rst_n = 1;
    chk(r_aes(KB, 128'h0011_2233_4455_6677_8899_AABB_CCDD_EEFF) == 128'h8EA2_B7CA_5167_45BF_EAFC_4990_4B49_6089,
        "reference AES-256: FIPS-197 C.3");
    h0 = r_aes(0, 0);
    chk(h0 == 128'hDC95_C078_A240_8989_AD48_A214_9284_2087, "reference H for the zero 256-bit key (GCM test case 13)");
    chk(r_aes(0, 1) == 128'h530F_8AFB_C745_36B9_A963_B4F1_C4CB_738B, "GCM test case 13 tag");
    chk(r_aes(0, 2) == 128'hCEA7_403D_4D60_6B6E_074E_C5D3_BAF3_9D18, "GCM test case 14 ciphertext");
    chk((r_gmul(r_gmul(128'hCEA7_403D_4D60_6B6E_074E_C5D3_BAF3_9D18, h0) ^ 128'd128, h0) ^ r_aes(0, 1)) ==
        128'hD0D1_C8A7_9999_6BF0_265B_98B5_D48A_B919, "GCM test case 14 tag");
    repeat (4) @(negedge clk);
    chk(nrep == 0 && on == 0, "no status or output without a TLP");

    // every sub-stream and key set; counters count per sub-stream / key set
    ide(0, 1, 0, 0, 3, 1); send(); want(0, 1, "MWr 1 DW, posted, key set 0, counter 1");
    ide(0, 8, 0, 0, 3, 2); send(); want(0, 8, "MWr 8 DW, counter 2");
    ide(0, 5, 0, 1, 3, 1); send(); want(0, 5, "MWr on key set 1 starts at counter 1");
    ide(1, 4, 1, 0, 3, 1); send(); want(0, 0, "MRd (no payload), non-posted");
    ide(2, 3, 2, 0, 3, 1); send(); want(0, 3, "CplD, completions");
    ide(2, 4, 2, 1, 3, 1); send(); want(0, 4, "CplD on key set 1");
    ide(2, 2, 2, 0, 3, 2); send(); want(0, 2, "CplD key set 0 counter 2");
    ide(0, 3, 0, 0, 3, 3); send(); want(0, 3, "MWr key set 0 counter 3");
    // plain TLP
    ide(0, 2, 0, 0, 3, 9); for (int i = 0; i < 16 + 8; i++) tb_[i] = tb_[i + 4]; tb_[0] = 8'h40; tn = 12 + 8;
    for (int i = 0; i < 8; i++) tb_[12 + i] = pt[i];
    send();
    chk(st == 3'd1 && on == 5 && ob[0] == {tb_[0], tb_[1], tb_[2], tb_[3]} && ob[1] == {tb_[4], tb_[5], tb_[6], tb_[7]} &&
        ob[3] == {pt[0], pt[1], pt[2], pt[3]} && ob[4] == {pt[4], pt[5], pt[6], pt[7]}, "TLP without a prefix: delivered as it came");
    for (int i = 0; i < 192; i++) tb_[i] = 8'h00;
    tb_[0] = 8'h92; tb_[2] = 8'd3; tn = 4; send(); want(2, 0, "a lone IDE prefix DW: dropped");
    ide(0, 9, 0, 0, 3, 4); tn = 16 + 36 + 12; send(); want(2, 0, "9-DW payload (over the model's 8): dropped");
    // bad IDE TLPs: dropped, not counted
    ide(0, 2, 0, 0, 5, 4); send(); want(2, 0, "stream 5: dropped");
    ide(0, 2, 1, 0, 3, 4); send(); want(2, 0, "MWr on the non-posted sub-stream: dropped");
    ide(1, 2, 0, 0, 3, 4); send(); want(2, 0, "MRd on the posted sub-stream: dropped");
    ide(0, 2, 0, 0, 3, 4, 0); send(); want(2, 0, "M = 0: dropped");
    ide(0, 2, 0, 0, 3, 4, 1, 1); send(); want(2, 0, "P = 1: dropped");
    ide(0, 2, 0, 0, 3, 4); tn = tn - 4; send(); want(2, 0, "MAC DW missing: dropped");
    ide(0, 2, 0, 0, 3, 4); tb_[4] = 8'h60; send(); want(2, 0, "unknown TLP type 0x60: dropped");
    ide(0, 2, 0, 0, 3, 4); send(); want(0, 2, "posted key set 0 still at counter 4");
    // MAC failure: the stream goes insecure
    ide(0, 2, 0, 0, 3, 5); tb_[16] = tb_[16] ^ 8'h01; send(); want(3, 0, "payload bit flipped: MAC fails");
    ide(0, 2, 0, 0, 3, 5); send(); want(4, 0, "next IDE TLP: insecure");
    ide(2, 1, 2, 1, 3, 2); send(); want(4, 0, "other sub-streams too");
    ide(0, 2, 0, 0, 3, 9); for (int i = 0; i < 24; i++) tb_[i] = tb_[i + 4]; tb_[0] = 8'h40; tn = 20;
    send(); chk(st == 3'd1, "plain TLPs still pass while insecure");
    set_go(4); chk(st == 3'd1 && on == 4, "K_SET_GO for stream 4: just a message");
    set_go(3); chk(st == 3'd5 && on == 0, "K_SET_GO for stream 3: consumed");
    ide(0, 2, 0, 0, 3, 1); send(); want(0, 2, "after K_SET_GO: counter 1 again");
    ide(2, 1, 2, 1, 3, 1); send(); want(0, 1, "every counter reset");
    // replay and loss, header and MAC faults (re-key after each)
    ide(0, 2, 0, 0, 3, 1); send(); want(3, 0, "counter 1 replayed: MAC fails");
    set_go(3);
    ide(0, 2, 0, 0, 3, 2); send(); want(3, 0, "counter 2 where 1 is due (a TLP lost): MAC fails");
    set_go(3);
    ide(0, 2, 0, 0, 3, 1); tb_[9] = tb_[9] ^ 8'h40; send(); want(3, 0, "header bit flipped (AAD): MAC fails");
    set_go(3);
    ide(1, 1, 1, 0, 3, 1); tb_[16] = tb_[16] ^ 8'h80; send(); want(3, 0, "MRd MAC bit flipped");
    set_go(3);
    ide(0, 3, 0, 0, 3, 1, 1, 0); tb_[1][6] = 1'b1; send(); want(3, 0, "key set bit changed: other key, MAC fails");
    set_go(3);
    ide(0, 2, 0, 1, 3, 1); tb_[1][5] = 1'b0; send(); want(3, 0, "T bit is in the AAD");
    set_go(3);
    ide(0, 3, 0, 1, 3, 1); send(); want(0, 3, "key set 1 after the faults");
    chk(nlast == 15 && ndel == 15, $sformatf("one last-DW strobe per delivered TLP (%0d / %0d)", nlast, ndel));

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #50000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
