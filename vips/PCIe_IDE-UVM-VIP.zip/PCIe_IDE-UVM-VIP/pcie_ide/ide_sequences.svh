// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_sequences.svh -- IDE sequences

// Random traffic: cfg.num_items constrained-random items.
class ide_base_sequence extends uvm_sequence #(ide_transaction);
  `uvm_object_utils(ide_base_sequence)
  ide_config cfg;

  function new(string name = "ide_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ide_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ide_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ide_directed_sequence extends uvm_sequence #(ide_transaction);
  `uvm_object_utils(ide_directed_sequence)
  ide_config cfg;

  function new(string name = "ide_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ide_transaction item();
    item = ide_transaction::type_id::create("req");
  endfunction

  task send(ide_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ide_transaction t;
    // each sub-stream on both key sets, a plain TLP, every fault (each followed by K_SET_GO), replay
    for (int s = 0; s < 3; s++)
      for (int k = 0; k < 2; k++) begin t = item(); t.set(0, s, k, 1 + 3 * s + k); send(t); end
    t = item(); t.set(16, 0, 0, 2); send(t);
    for (int f = 20; f < 29; f++) begin
      t = item(); t.set(f, 0, 0, 2); send(t);
      t = item(); t.set(0, 2, 1, 3); send(t);
      t = item(); t.set(18, 0, 0, 1); send(t);
    end
    t = item(); t.set(0, 1, 1, 1); send(t);
    t = item(); t.set(0, 0, 1, 8); send(t);
  endtask
endclass
