// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_if.sv -- IDE interface

interface ide_if (input logic clk);
  logic rst_n;

  logic in_valid;
  logic [31:0] in_dw;
  logic in_last;
  logic out_valid;
  logic [31:0] out_dw;
  logic out_last;
  logic rep_valid;
  logic [2:0] rep_status;

  modport DUT (input clk, rst_n, input in_valid, input in_dw, input in_last, output out_valid, output out_dw, output out_last, output rep_valid, output rep_status);
  modport MON (input clk, rst_n, in_valid, in_dw, in_last, out_valid, out_dw, out_last, rep_valid, rep_status);

  clocking drv_cb @(posedge clk);
    input rst_n, out_valid, out_dw, out_last, rep_valid, rep_status;
    inout in_valid, in_dw, in_last;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, in_valid, in_dw, in_last, out_valid, out_dw, out_last, rep_valid, rep_status;
  endclocking
endinterface
