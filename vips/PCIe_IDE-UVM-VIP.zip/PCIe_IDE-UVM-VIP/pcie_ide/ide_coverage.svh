// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_coverage.svh -- IDE functional coverage

class ide_coverage extends uvm_subscriber #(ide_transaction);
  `uvm_component_utils(ide_coverage)
  ide_config cfg;
  ide_transaction tr;

  covergroup ide_cg;
    cp_status : coverpoint tr.status { bins passed = {0}; bins plain = {1}; bins bad = {2}; bins mac_fail = {3}; bins insecure = {4};
                                       bins set_go = {5}; }
    cp_ss : coverpoint tr.tlp[1][3:1] iff (tr.status == 0) { bins posted = {0}; bins non_posted = {1}; bins cpl = {2}; }
    cp_ks : coverpoint tr.tlp[1][6] iff (tr.status == 0);
    cp_len : coverpoint tr.odata.size() iff (tr.status == 0) { bins nodata = {12}; bins one = {16}; bins more = {[20:44]}; }
    x_ss_ks : cross cp_ss, cp_ks;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ide_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ide_config)::get(this, "", "cfg", cfg))
      cfg = ide_config::type_id::create("cfg");
  endfunction

  function void write(ide_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ide_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("IDE coverage: %0.1f%%", ide_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
