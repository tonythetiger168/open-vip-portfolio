// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_defs.sv -- IDE shared type definitions

package ide_defs_pkg;

  typedef enum bit [1:0] {IDE_OK, IDE_ERR} ide_status_e;

  localparam bit [255:0] IDE_KBASE = 256'h0001_0203_0405_0607_0809_0A0B_0C0D_0E0F_1011_1213_1415_1617_1819_1A1B_1C1D_1E1F;
  localparam bit [7:0]   IDE_SID   = 8'd3;
  function automatic bit [255:0] ide_key(bit [2:0] ss, bit ks); return IDE_KBASE ^ {251'h0, ss, 1'b0, ks}; endfunction
  function automatic bit [7:0] ide_xt(bit [7:0] a); return {a[6:0], 1'b0} ^ (a[7] ? 8'h1B : 8'h00); endfunction
  function automatic bit [7:0] ide_gm(bit [7:0] a, bit [7:0] b);
    bit [7:0] p = 0;
    for (int i = 0; i < 8; i++) begin
      if (b[i]) p ^= a;
      a = ide_xt(a);
    end
    return p;
  endfunction
  function automatic bit [7:0] ide_sbox(bit [7:0] a);
    bit [7:0] r = 8'h01;
    for (int i = 7; i >= 0; i--) begin
      r = ide_gm(r, r);
      if (i != 0) r = ide_gm(r, a);
    end
    return r ^ {r[6:0], r[7]} ^ {r[5:0], r[7:6]} ^ {r[4:0], r[7:5]} ^ {r[3:0], r[7:4]} ^ 8'h63;
  endfunction
  function automatic bit [31:0] ide_subw(bit [31:0] w);
    return {ide_sbox(w[31:24]), ide_sbox(w[23:16]), ide_sbox(w[15:8]), ide_sbox(w[7:0])};
  endfunction
  function automatic bit [127:0] ide_next(bit [127:0] k, bit [31:0] w);
    bit [127:0] n;
    n[127:96] = k[127:96] ^ w; n[95:64] = k[95:64] ^ n[127:96]; n[63:32] = k[63:32] ^ n[95:64]; n[31:0] = k[31:0] ^ n[63:32];
    return n;
  endfunction
  // AES-256 encryption (14 rounds, round keys made on the fly)
  function automatic bit [127:0] ide_aes(bit [255:0] key, bit [127:0] blk);
    bit [127:0] ka = key[255:128], kb = key[127:0], s = blk ^ key[255:128], t, rk;
    bit [7:0] rc = 8'h01, a0, a1, a2, a3;
    for (int r = 1; r <= 14; r++) begin
      for (int c = 0; c < 4; c++)
        for (int j = 0; j < 4; j++)
          t[127 - 8*(4*c + j) -: 8] = ide_sbox(s[127 - 8*(4*((c + j) % 4) + j) -: 8]);
      if (r != 14)
        for (int c = 0; c < 4; c++) begin
          a0 = t[127 - 32*c -: 8]; a1 = t[119 - 32*c -: 8]; a2 = t[111 - 32*c -: 8]; a3 = t[103 - 32*c -: 8];
          t[127 - 32*c -: 8] = ide_xt(a0) ^ ide_xt(a1) ^ a1 ^ a2 ^ a3;
          t[119 - 32*c -: 8] = a0 ^ ide_xt(a1) ^ ide_xt(a2) ^ a2 ^ a3;
          t[111 - 32*c -: 8] = a0 ^ a1 ^ ide_xt(a2) ^ ide_xt(a3) ^ a3;
          t[103 - 32*c -: 8] = ide_xt(a0) ^ a0 ^ a1 ^ a2 ^ ide_xt(a3);
        end
      if (r == 1) rk = kb;
      else if (r % 2 == 0) begin
        ka = ide_next(ka, ide_subw({kb[23:0], kb[31:24]}) ^ {rc, 24'h0});
        rc = ide_xt(rc);
        rk = ka;
      end else begin
        kb = ide_next(kb, ide_subw(ka[31:0]));
        rk = kb;
      end
      s = t ^ rk;
    end
    return s;
  endfunction
  function automatic bit [127:0] ide_gmul(bit [127:0] x, bit [127:0] y);
    bit [127:0] z = 0, v = y;
    for (int i = 0; i < 128; i++) begin
      if (x[127 - i]) z ^= v;
      v = v[0] ? ((v >> 1) ^ {8'hE1, 120'h0}) : (v >> 1);
    end
    return z;
  endfunction
  function automatic bit [127:0] ide_ghash(bit [127:0] h, bit [127:0] x, bit [7:0] q[$]);
    for (int i = 0; i < q.size(); i += 16) begin
      bit [127:0] b = 0;
      for (int j = 0; j < 16; j++) if (i + j < q.size()) b[127 - 8*j -: 8] = q[i + j];
      x = ide_gmul(x ^ b, h);
    end
    return x;
  endfunction
  // AES-256-GCM: out = text XOR keystream; returns the tag over aad and the ciphertext
  function automatic bit [127:0] ide_gcm(bit [255:0] key, bit [95:0] iv, bit [7:0] aad[$], bit [7:0] txt[$], bit enc,
                                         output bit [7:0] out[$]);
    bit [127:0] h = ide_aes(key, 128'h0), x, ks;
    bit [63:0] la = 64'(aad.size()) * 8, lc = 64'(txt.size()) * 8;
    out.delete();
    for (int i = 0; i < txt.size(); i += 16) begin
      ks = ide_aes(key, {iv, 32'(2 + i / 16)});
      for (int j = 0; j < 16; j++) if (i + j < txt.size()) out.push_back(txt[i + j] ^ ks[127 - 8*j -: 8]);
    end
    x = ide_ghash(h, 128'h0, aad);
    if (enc) x = ide_ghash(h, x, out);
    else     x = ide_ghash(h, x, txt);
    x = ide_gmul(x ^ {la, lc}, h);
    return x ^ ide_aes(key, {iv, 32'h1});
  endfunction
  function automatic bit [95:0] ide_iv(bit [2:0] ss, bit [7:0] sid, bit [63:0] ctr); return {16'h0, 5'h0, ss, sid, ctr}; endfunction

endpackage
