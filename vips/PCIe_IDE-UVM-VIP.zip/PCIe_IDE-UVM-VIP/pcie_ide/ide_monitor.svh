// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_monitor.svh -- IDE monitor: TLPs into the IDE block, then the delivered DWs and the status that close each one

class ide_monitor extends uvm_monitor;
  `uvm_component_utils(ide_monitor)

  virtual ide_if vif;
  uvm_analysis_port #(ide_transaction) ap;
  ide_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ide_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ide: virtual interface not set")
    if (!uvm_config_db#(ide_config)::get(this, "", "cfg", cfg))
      cfg = ide_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] b[$], o[$];
      bit [7:0] tlps[$][$];
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.in_valid) begin
          for (int i = 3; i >= 0; i--) b.push_back(vif.mon_cb.in_dw[8*i +: 8]);
          if (vif.mon_cb.in_last) begin tlps.push_back(b); b.delete(); end
        end
        if (vif.mon_cb.out_valid) for (int i = 3; i >= 0; i--) o.push_back(vif.mon_cb.out_dw[8*i +: 8]);
        if (vif.mon_cb.rep_valid) begin
          if (tlps.size() == 0) `uvm_error("MON", "IDE: status without a TLP")
          else begin
            ide_transaction t = ide_transaction::type_id::create("t");
            t.tlp = tlps.pop_front();
            t.odata = o;
            t.status = vif.mon_cb.rep_status;
            publish(t);
          end
          o.delete();
        end
      end
    end
  endtask

  function void publish(ide_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
