// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_driver.svh -- IDE driver: one TLP per item: the driver keeps the transmit invocation counters (and follows the receiver's insecure state) and seals IDE TLPs with them; DW per clock; then the delivered DWs and the status

class ide_driver extends uvm_driver #(ide_transaction);
  `uvm_component_utils(ide_driver)

  uvm_analysis_port #(ide_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ide_if vif;
  ide_config cfg;

  bit [63:0] tx_ctr [3][2] = '{'{1, 1}, '{1, 1}, '{1, 1}};
  bit insecure = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ide_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ide: virtual interface not set")
    if (!uvm_config_db#(ide_config)::get(this, "", "cfg", cfg))
      cfg = ide_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ide_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.in_valid <= 1'b0;
    vif.drv_cb.in_dw    <= 32'h0;
    vif.drv_cb.in_last  <= 1'b0;
  endtask

  task drive_item(ide_transaction t);
    bit [2:0] ss = t.ss_of();
    bit [63:0] c = tx_ctr[ss][t.ks];
    int k = 0;
    if (t.kind == 27) c = c - 1;
    t.seal(c);
    if (t.is_ide() && !insecure) begin
      if (t.kind inside {24, 25, 26, 27}) insecure = 1;
      else if (!(t.kind inside {20, 21, 22, 23, 28})) tx_ctr[ss][t.ks] = c + 1;
    end
    if (t.kind inside {18, 19}) begin
      foreach (tx_ctr[i, j]) tx_ctr[i][j] = 1;
      insecure = 0;
    end
    for (int i = 0; i < t.tlp.size(); i += 4) begin
      vif.drv_cb.in_valid <= 1'b1;
      vif.drv_cb.in_dw <= {t.tlp[i], t.tlp[i + 1], t.tlp[i + 2], t.tlp[i + 3]};
      vif.drv_cb.in_last <= (i + 4 >= t.tlp.size());
      @(vif.drv_cb);
    end
    vif.drv_cb.in_valid <= 1'b0; vif.drv_cb.in_last <= 1'b0;
    t.odata.delete();
    do begin
      @(vif.drv_cb);
      if (vif.drv_cb.out_valid) for (int i = 3; i >= 0; i--) t.odata.push_back(vif.drv_cb.out_dw[8*i +: 8]);
      k++;
    end while (!vif.drv_cb.rep_valid && k < cfg.timeout_cycles);
    if (!vif.drv_cb.rep_valid) `uvm_error("DRV", "IDE: no status for a TLP")
    t.status = vif.drv_cb.rep_status;
    repeat (2) @(vif.drv_cb);
  endtask

endclass
