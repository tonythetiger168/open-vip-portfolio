// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_compliance_checker.sv -- IDE concurrent assertion checks (bindable)

module ide_compliance_checker
  (input logic clk, input logic rst_n, input logic in_valid, input logic [31:0] in_dw, input logic in_last, input logic out_valid, input logic [31:0] out_dw, input logic out_last, input logic rep_valid, input logic [2:0] rep_status);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({in_valid, out_valid, rep_valid}))
    else $error("IDE: X on a valid");
  assert property (@(posedge clk) disable iff (!rst_n) out_valid |-> !$isunknown(out_dw))
    else $error("IDE: X on delivered data");
  assert property (@(posedge clk) disable iff (!rst_n) out_last |-> rep_valid && rep_status <= 3'd1)
    else $error("IDE: last delivered DW without a pass / plain status");
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_status == 3'd3);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_status == 3'd5);
endmodule
