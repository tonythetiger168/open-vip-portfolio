// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_transaction.svh -- IDE transaction

class ide_transaction extends uvm_sequence_item;
  `uvm_object_utils(ide_transaction)

  // request (driven by the agent)
  bit [7:0] tlp[$];
  // response (returned by the DUT)
  bit [2:0] status;
  bit [7:0] odata[$];
  // bookkeeping (not compared)
  bit [7:0] pt[$];
  rand bit [4:0] kind;
  rand bit [1:0] tsel;
  rand bit ks;
  rand bit [2:0] len_r;
  rand bit [31:0] seed;
  bit [63:0] ctr;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "ide_transaction"); super.new(name); endfunction

  // kind: 0-15 IDE TLP, 16-17 plain TLP, 18-19 K_SET_GO, 20 other stream, 21 sub-stream mismatch,
  // 22 M = 0, 23 P = 1, 24 MAC bit, 25 payload bit, 26 header bit, 27 replayed counter, 28 MAC DW missing,
  // 29-31 IDE TLP
  function bit is_ide(); return !(kind inside {16, 17, 18, 19}); endfunction
  function bit [2:0] ss_of(); return (tsel == 1) ? 3'd1 : (tsel == 2) ? 3'd2 : 3'd0; endfunction
  // header (3 DW) and payload; the driver seals with the counter it chooses
  function void hdr(output bit [7:0] h[$]);
    bit [31:0] x = seed | 1;
    bit [9:0] len = len_r + 1;
    h.delete();
    if (kind inside {18, 19}) begin
      h = '{8'h72, 8'h00, 8'h00, 8'h01, 8'h00, 8'h00, 8'h00, 8'h7F, 8'h00, 8'h00, 8'h00, 8'h00};
      return;
    end
    h.push_back((tsel == 1) ? 8'h00 : (tsel == 2) ? 8'h4A : 8'h40);
    h.push_back(8'h00); h.push_back({6'h0, len[9:8]}); h.push_back(len[7:0]);
    for (int i = 0; i < 8; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      h.push_back(x[7:0]);
    end
    if (tsel != 2) h[11][1:0] = 2'b00;
  endfunction
  function void mk_pt();
    bit [31:0] x = seed ^ 32'h5A5A_0F0F;
    pt.delete();
    if (kind inside {18, 19}) begin pt = '{8'h05, 8'h00, IDE_SID, 8'h00}; return; end
    if (tsel == 1) return;
    for (int i = 0; i < 4 * (len_r + 1); i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      pt.push_back(x[7:0]);
    end
  endfunction
  function void post_randomize(); if (tsel == 3) tsel = 0; mk_pt(); endfunction
  function void set(int k, bit [1:0] ts, bit kset, int n);
    kind = k; tsel = ts; ks = kset; len_r = n - 1;
    mk_pt();
  endfunction
  // the TLP on the wire, sealed with counter c
  function void seal(bit [63:0] c);
    bit [7:0] h[$], a[$], o[$];
    bit [127:0] tag;
    bit [2:0] ss = ss_of();
    ctr = c;
    hdr(h);
    tlp.delete();
    if (!is_ide()) begin
      tlp = h;
      foreach (pt[i]) tlp.push_back(pt[i]);
      return;
    end
    if (kind == 21) ss = (ss == 0) ? 3'd1 : 3'd0;
    a = '{8'h92, {kind != 22, ks, 1'b1, kind == 23, ss, 1'b0}, (kind == 20) ? 8'd5 : IDE_SID, 8'h00};
    foreach (h[i]) a.push_back(h[i]);
    tag = ide_gcm(ide_key(ss, ks), ide_iv(ss, (kind == 20) ? 8'd5 : IDE_SID, c), a, pt, 1'b1, o);
    if (kind == 24) tag[100] = ~tag[100];
    if (kind == 25 && o.size() != 0) o[0][2] = ~o[0][2];
    if (kind == 26 || (kind == 25 && o.size() == 0)) a[12][5] = ~a[12][5];
    tlp = a;
    foreach (o[i]) tlp.push_back(o[i]);
    if (kind != 28) for (int i = 15; i >= 4; i--) tlp.push_back(tag[8*i +: 8]);
  endfunction

  function void do_copy(uvm_object rhs);
    ide_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    tlp = rhs_.tlp;
    status = rhs_.status;
    odata = rhs_.odata;
    pt = rhs_.pt;
    kind = rhs_.kind;
    tsel = rhs_.tsel;
    ks = rhs_.ks;
    len_r = rhs_.len_r;
    seed = rhs_.seed;
    ctr = rhs_.ctr;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ide_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (tlp.size() != rhs_.tlp.size()) return 0;
    foreach (tlp[i]) if (tlp[i] != rhs_.tlp[i]) return 0;
    if (status != rhs_.status) return 0;
    if (odata.size() != rhs_.odata.size()) return 0;
    foreach (odata[i]) if (odata[i] != rhs_.odata[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ide_transaction rhs_);
    if (tlp.size() != rhs_.tlp.size()) return 0;
    foreach (tlp[i]) if (tlp[i] != rhs_.tlp[i]) return 0;
    return 1;
  endfunction

  function string qstr_tlp();
    string s = $sformatf("[%0d]{", tlp.size());
    foreach (tlp[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", tlp[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_odata();
    string s = $sformatf("[%0d]{", odata.size());
    foreach (odata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", odata[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_pt();
    string s = $sformatf("[%0d]{", pt.size());
    foreach (pt[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", pt[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("IDE{tag=%0d tlp=%s status=0x%0h odata=%s}", tag, qstr_tlp(), status, qstr_odata());
  endfunction
endclass
