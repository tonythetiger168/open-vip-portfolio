// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ide_env.sv -- IDE environment: reference-model scoreboard, checker, coverage

package ide_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import ide_defs_pkg::*;
  import ide_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class ide_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(ide_scoreboard)
    uvm_analysis_imp_exp #(ide_transaction, ide_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(ide_transaction, ide_scoreboard) obs_ap;

    ide_config cfg;
    ide_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [63:0] rx_ctr [3][2] = '{'{1, 1}, '{1, 1}, '{1, 1}};
    bit insecure = 0;
    bit kat_done = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(ide_config)::get(this, "", "cfg", cfg))
        cfg = ide_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(ide_transaction t);
      bit [7:0] q[$], aad[$], c[$], p[$];
      bit [127:0] tag;
      bit [2:0] ss, want;
      bit [9:0] len;
      int n = t.tlp.size(), plen;
      bit m, pb, ks, data;
      if (!kat_done) begin
        // FIPS-197 C.3 and GCM test case 13 on the scoreboard's own AES-256 / GHASH
        kat_done = 1;
        if (ide_aes(IDE_KBASE, 128'h0011_2233_4455_6677_8899_AABB_CCDD_EEFF) != 128'h8EA2_B7CA_5167_45BF_EAFC_4990_4B49_6089)
          `uvm_error("SB", "IDE: AES-256 known answer wrong")
        if (ide_aes(256'h0, 128'h1) != 128'h530F_8AFB_C745_36B9_A963_B4F1_C4CB_738B)
          `uvm_error("SB", "IDE: GCM test case 13 tag wrong")
      end
      t.odata.delete();
      if (n < 4 || t.tlp[0] != 8'h92) begin
        // no IDE prefix: K_SET_GO for this stream, or delivered as it came
        if (n == 16 && t.tlp[0] == 8'h72 && t.tlp[7] == 8'h7F && t.tlp[12] == 8'h05 && t.tlp[14] == IDE_SID) begin
          t.status = 5;
          foreach (rx_ctr[i, j]) rx_ctr[i][j] = 1;
          insecure = 0;
        end else begin
          t.status = 1;
          t.odata = t.tlp;
        end
      end else begin
        {m, ks, pb} = {t.tlp[1][7], t.tlp[1][6], t.tlp[1][4]};
        ss = t.tlp[1][3:1];
        want = (t.tlp[4] == 8'h40) ? 3'd0 : (t.tlp[4] == 8'h00) ? 3'd1 : (t.tlp[4] == 8'h4A) ? 3'd2 : 3'd7;
        len = {t.tlp[6][1:0], t.tlp[7]};
        data = (want != 3'd1);
        plen = data ? 4 * ((len == 0) ? 1024 : len) : 0;
        if (t.tlp[2] != IDE_SID || want == 3'd7 || ss != want || !m || pb || plen > 32 || n != 16 + plen + 12) t.status = 2;
        else if (insecure) t.status = 4;
        else begin
          for (int i = 0; i < 16; i++) aad.push_back(t.tlp[i]);
          for (int i = 0; i < plen; i++) c.push_back(t.tlp[16 + i]);
          tag = ide_gcm(ide_key(ss, ks), ide_iv(ss, IDE_SID, rx_ctr[ss][ks]), aad, c, 1'b0, p);
          for (int i = 0; i < 12; i++) q.push_back(tag[127 - 8*i -: 8]);
          for (int i = 0; i < 12; i++) if (q[i] != t.tlp[16 + plen + i]) insecure = 1;
          if (insecure) t.status = 3;
          else begin
            t.status = 0;
            rx_ctr[ss][ks]++;
            for (int i = 4; i < 16; i++) t.odata.push_back(t.tlp[i]);
            foreach (p[i]) t.odata.push_back(p[i]);
          end
        end
      end
    endfunction

    function void write_exp(ide_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(ide_transaction t);
      ide_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        ide_transaction e = exp_q.pop_front();
        ide_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("ide scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class ide_env extends uvm_env;
    `uvm_component_utils(ide_env)
    ide_agent      agt;
    ide_scoreboard sb;
    ide_checker    chk;
    ide_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = ide_agent     ::type_id::create("agt", this);
      sb  = ide_scoreboard::type_id::create("sb",  this);
      chk = ide_checker   ::type_id::create("chk", this);
      cov = ide_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
