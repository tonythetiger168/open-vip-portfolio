// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// scm_ssd_tests.sv -- tests for the SCM dual-mode SSD VIP

`ifndef SCM_SSD_TESTS_SV
`define SCM_SSD_TESTS_SV
package scm_ssd_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import scm_ssd_pkg::*;

  class scm_ssd_base_test extends uvm_test;
    `uvm_component_utils(scm_ssd_base_test)
    scm_ssd_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      env = scm_ssd_env::type_id::create("env", this);
    endfunction
  endclass

  // Block traffic on all queue pairs (valid, then with malformed commands
  // and CQ back-pressure) with byte-port traffic on the upper half of the
  // SCM region in parallel; FDP across reclaim units and bad placement
  // handles; then a dual-mode phase where namespace 1 Writes are read
  // through the byte port and byte stores are read back as blocks.
  class scm_ssd_random_test extends scm_ssd_base_test;
    `uvm_component_utils(scm_ssd_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    task run_phase(uvm_phase phase);
      scm_ssd_cmd_seq  cs;
      scm_ssd_bacc_seq bs;
      phase.raise_objection(this);
      // 1: valid traffic
      cs = scm_ssd_cmd_seq::type_id::create("cs_valid");
      cs.n = 150;
      cs.start(env.cmd_sqr);
      env.cmd_drv.wait_idle();
      // 2: errors + CQ back-pressure, byte port in parallel
      env.cmd_drv.cq_hold = 10;
      fork
        begin
          cs = scm_ssd_cmd_seq::type_id::create("cs_err");
          cs.n = 200; cs.p_err = 35;
          cs.start(env.cmd_sqr);
        end
        begin
          bs = scm_ssd_bacc_seq::type_id::create("bs");
          bs.n = 400;
          bs.start(env.bacc_sqr);
        end
      join
      env.cmd_drv.wait_idle();
      env.cmd_drv.cq_hold = 0;
      // 3: FDP: NAND writes on every handle, then invalid handles
      cs = scm_ssd_cmd_seq::type_id::create("cs_fdp");
      cs.n = 40; cs.f_op = 1; cs.f_ns = 2;
      cs.start(env.cmd_sqr);
      for (int h = 0; h < 3; h++) begin
        cs = scm_ssd_cmd_seq::type_id::create("cs_fdp_bad");
        cs.n = 1; cs.f_op = 1; cs.f_ns = 2; cs.f_dspec = NRUH + h * 1000;
        cs.start(env.cmd_sqr);
      end
      env.cmd_drv.wait_idle();
      // 4: dual mode, one view at a time
      for (int k = 0; k < 6; k++) begin
        cs = scm_ssd_cmd_seq::type_id::create("cs_dm_wr");
        cs.n = 1; cs.f_op = 1; cs.f_ns = 1; cs.scm_lo_only = 0;
        cs.start(env.cmd_sqr);
        env.cmd_drv.wait_idle();
        bs = scm_ssd_bacc_seq::type_id::create("bs_ld");
        bs.n = 16; bs.lo = 0; bs.p_oob = 0; bs.f_we = 0;
        bs.start(env.bacc_sqr);
        bs = scm_ssd_bacc_seq::type_id::create("bs_st");
        bs.n = 8; bs.lo = 0; bs.p_oob = 0; bs.f_we = 1;
        bs.start(env.bacc_sqr);
        cs = scm_ssd_cmd_seq::type_id::create("cs_dm_rd");
        cs.n = 2; cs.f_op = 2; cs.f_ns = 1; cs.scm_lo_only = 0;
        cs.start(env.cmd_sqr);
        env.cmd_drv.wait_idle();
      end
      phase.drop_objection(this);
    endtask
  endclass
endpackage
`endif
