// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// scm_ssd_pkg.sv -- UVM VIP for an SCM dual-mode SSD (NVMe 2.1-style
// multi-queue block mode with Flexible Data Placement, plus a CXL.mem-style
// byte port onto the SCM region). The DUT is open-ip-portfolio SCM_SSD_top.
//
//   scm_ssd_host      host memory slave for the controller's DMA master
//                     (random back-pressure and read latency)
//   nvme side         scm_ssd_cmd item, sequencer, driver (builds SQ entries
//                     and buffers in host memory, rings SQ doorbells on any
//                     queue pair without waiting, collects completions in
//                     the order ev_cqe reports them, rings CQ doorbells)
//   byte side         scm_ssd_bacc item, sequencer, driver
//   scm_ssd_monitor   passive: rebuilds completion entries from the CQ
//                     writes on the DMA bus, and byte-port accesses from the
//                     pins, and samples ru_fill / block counters
//   scm_ssd_scoreboard reference model: the command checks (status codes),
//                     the SCM and NAND namespaces, FDP reclaim unit fill
//                     per handle; checks every completion (driver and
//                     monitor views), Read data, byte-port data and errors
`ifndef SCM_SSD_PKG_SV
`define SCM_SSD_PKG_SV
package scm_ssd_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  localparam int NQ = 4, QD = 8, BLKDW = 4, NBS = 8, NBN = 16, NRUH = 4, RUB = 4;
  localparam int DS = NBS * BLKDW, DN = NBN * BLKDW;

  // host memory layout (dword addresses)
  function automatic int sq_addr(int q); return 'h1000 * q + 'h0100; endfunction
  function automatic int cq_addr(int q); return 'h1000 * q + 'h0800; endfunction
  function automatic int buf_addr(int q, int s); return 'h8000 + 'h400 * q + 'h40 * s; endfunction

  // expected status code of a command, NVMe 2.1 generic status, in the
  // order the controller checks the fields
  function automatic bit [7:0] exp_status(int op, int fuse, bit [31:0] nsid, int dtype, int dspec,
                                          bit [31:0] prp, bit [31:0] prp_hi, bit [31:0] slba,
                                          bit [31:0] slba_hi, int nlb);
    int nb;
    if (op > 2) return 8'h01;
    if (fuse != 0) return 8'h02;
    if (!(nsid == 1 || nsid == 2 || op == 0 && nsid == 32'hFFFF_FFFF)) return 8'h0B;
    if (op == 1 && (!(dtype == 0 || dtype == 2) || dtype == 2 && (nsid != 2 || dspec >= NRUH))) return 8'h02;
    if (op != 0 && prp[1:0] != 0) return 8'h13;
    nb = nsid == 2 ? NBN : NBS;
    if (op != 0 && !(slba_hi == 0 && slba < nb && nlb < nb && slba + nlb < nb)) return 8'h80;
    if (op != 0 && (prp_hi != 0 || prp[31:18] != 0)) return 8'h04;
    return 8'h00;
  endfunction

  //==========================================================================
  // items
  //==========================================================================
  class scm_ssd_cmd extends uvm_sequence_item;
    // request
    int          qid;                   // queue pair 0 .. NQ-1
    int          opcode;                // 00h Flush, 01h Write, 02h Read, others invalid
    int          fuse;
    bit [31:0]   nsid;
    bit [31:0]   slba, slba_hi;
    int          nlb;                   // 0-based
    int          dtype, dspec;          // CDW12[23:20], CDW13[31:16]
    bit [1:0]    prp_off;               // PRP1 bits 1:0 (non-zero: offset error)
    bit [31:0]   prp_hi;                // PRP1 bits 63:32
    bit [13:0]   prp_win;               // PRP1 bits 31:18 (non-zero: outside the window)
    bit [31:0]   wdata[$];
    // filled by the driver
    bit [15:0]   cid;
    int          sqhd;
    int          buf_a;                 // host buffer (dword address)
    bit [7:0]    status;
    bit          dnr, phase;
    bit [31:0]   rdata[$];
    `uvm_object_utils(scm_ssd_cmd)
    function new(string name = "scm_ssd_cmd"); super.new(name); endfunction
    function string convert2string();
      return $sformatf("NVMe q%0d cid=%h op=%02h ns=%0h slba=%0d nlb=%0d dtype=%0d dspec=%0d -> sc=%02h",
                       qid, cid, opcode, nsid, slba, nlb, dtype, dspec, status);
    endfunction
  endclass

  class scm_ssd_bacc extends uvm_sequence_item;
    bit          we;
    bit [15:0]   addr;                  // dword index into the SCM region
    bit [31:0]   wdata;
    // filled by the driver / monitor
    bit [7:0]    tag;
    bit [31:0]   rdata;
    bit          err;
    `uvm_object_utils(scm_ssd_bacc)
    function new(string name = "scm_ssd_bacc"); super.new(name); endfunction
    function string convert2string();
      return $sformatf("BYTE %s tag=%h addr=%0d wdata=%h -> rdata=%h err=%0d",
                       we ? "ST" : "LD", tag, addr, wdata, rdata, err);
    endfunction
  endclass

  // a completion entry as the monitor saw it on the DMA bus
  class scm_ssd_cqe extends uvm_sequence_item;
    int          qid;
    bit [15:0]   cid;
    int          sqid, sqhd;
    bit [7:0]    status;
    bit          dnr, phase;
    bit [7:0]    ru_fill;               // sampled with ev_cqe
    bit [31:0]   nand_blks, scm_blks;
    `uvm_object_utils(scm_ssd_cqe)
    function new(string name = "scm_ssd_cqe"); super.new(name); endfunction
  endclass

  //==========================================================================
  // host memory
  //==========================================================================
  class scm_ssd_host extends uvm_component;
    `uvm_component_utils(scm_ssd_host)
    virtual scm_ssd_if vif;
    bit [31:0] hm [int];
    int        p_rdy = 80, max_lat = 4, p_rsp = 90;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual scm_ssd_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "scm_ssd_if not set")
    endfunction
    function bit [31:0] rd(int a); return hm.exists(a) ? hm[a] : 32'h0; endfunction
    task run_phase(uvm_phase phase);
      bit [31:0] rs_d [$];
      int        rs_t [$];
      int        cyc = 0;
      vif.m_req_ready = 0; vif.m_rsp_valid = 0; vif.m_rsp_data = 0;
      forever begin
        @(posedge vif.clk);
        cyc++;
        if (vif.rst_n !== 1'b1) begin rs_d.delete(); rs_t.delete(); end
        else begin
          if (vif.m_rsp_valid) begin void'(rs_d.pop_front()); void'(rs_t.pop_front()); end
          if (vif.m_req_valid && vif.m_req_ready) begin
            if (vif.m_req_we) hm[vif.m_req_addr] = vif.m_req_wdata;
            else begin rs_d.push_back(rd(vif.m_req_addr)); rs_t.push_back(cyc + 1 + $urandom % max_lat); end
          end
        end
        @(negedge vif.clk);
        vif.m_req_ready = $urandom % 100 < p_rdy;
        vif.m_rsp_valid = rs_d.size() != 0 && rs_t[0] <= cyc && $urandom % 100 < p_rsp;
        vif.m_rsp_data  = vif.m_rsp_valid ? rs_d[0] : $urandom;
      end
    endtask
  endclass

  //==========================================================================
  // NVMe side: sequencer, driver
  //==========================================================================
  typedef uvm_sequencer #(scm_ssd_cmd) scm_ssd_cmd_sqr;

  class scm_ssd_cmd_driver extends uvm_driver #(scm_ssd_cmd);
    `uvm_component_utils(scm_ssd_cmd_driver)
    virtual scm_ssd_if vif;
    scm_ssd_host       host;
    uvm_analysis_port #(scm_ssd_cmd) done_ap;   // completed commands, in execution order
    scm_ssd_cmd        infl [NQ][$];
    int                sq_t [NQ], cq_h [NQ], slot [NQ], unrung [NQ];
    bit                ph [NQ];
    int                cq_hold = 0;              // CQ doorbell delay (1 in cq_hold per clock)
    int unsigned       n_done = 0;
    bit                db_busy = 0;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      done_ap = new("done_ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual scm_ssd_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "scm_ssd_if not set")
    endfunction
    function int outstanding();
      int n = 0;
      foreach (infl[q]) n += infl[q].size();
      return n;
    endfunction

    task ring(bit sq, int q, int v);
      while (db_busy) @(negedge vif.clk);
      db_busy = 1;
      @(negedge vif.clk);
      if (sq) begin vif.sq_db_valid = 1; vif.sq_db_qid = q; vif.sq_db = v; end
      else    begin vif.cq_db_valid = 1; vif.cq_db_qid = q; vif.cq_db = v; end
      @(negedge vif.clk);
      vif.sq_db_valid = 0; vif.cq_db_valid = 0;
      db_busy = 0;
    endtask

    task run_phase(uvm_phase phase);
      vif.cc_en = 0; vif.sq_db_valid = 0; vif.cq_db_valid = 0;
      vif.sq_db_qid = 0; vif.cq_db_qid = 0; vif.sq_db = 0; vif.cq_db = 0;
      for (int q = 0; q < NQ; q++) begin
        vif.sq_base[16*q +: 16] = sq_addr(q);
        vif.cq_base[16*q +: 16] = cq_addr(q);
        sq_t[q] = 0; cq_h[q] = 0; slot[q] = 0; ph[q] = 1; unrung[q] = 0;
        for (int i = 0; i < QD * 4; i++) host.hm[cq_addr(q) + i] = 0;
      end
      wait (vif.rst_n === 1'b1);
      @(negedge vif.clk);
      vif.cc_en = 1;
      while (vif.csts_rdy !== 1'b1) @(negedge vif.clk);
      fork
        collect();
        cq_doorbells();
        forever begin
          seq_item_port.get_next_item(req);
          submit(req);
          seq_item_port.item_done();
        end
      join
    endtask

    task submit(scm_ssd_cmd c);
      bit [31:0] e [16];
      int        q = c.qid, b;
      while (infl[q].size() >= QD - 1) @(negedge vif.clk);   // the SQ (and CQ) has room
      foreach (e[i]) e[i] = $urandom;
      c.cid = e[0][31:16];
      b = buf_addr(q, slot[q]);
      c.buf_a = b;
      slot[q] = (slot[q] + 1) % QD;
      e[0] = {c.cid, 2'b00, e[0][13:10], 2'(c.fuse), 8'(c.opcode)};
      e[1] = c.nsid;
      e[6] = {c.prp_win, 16'(b), c.prp_off};
      e[7] = c.prp_hi;
      e[10] = c.slba; e[11] = c.slba_hi;
      e[12] = {e[12][31:24], 4'(c.dtype), e[12][19:16], 16'(c.nlb)};
      e[13] = {16'(c.dspec), e[13][15:0]};
      // Write data goes to the buffer; a Read buffer is filled with noise
      for (int i = 0; i < (c.nlb + 1) * BLKDW && i < 64; i++)
        host.hm[b + i] = c.opcode == 1 && i < c.wdata.size() ? c.wdata[i] : $urandom;
      for (int i = 0; i < 16; i++) host.hm[sq_addr(q) + sq_t[q] * 16 + i] = e[i];
      c.sqhd = (sq_t[q] + 1) % QD;
      infl[q].push_back(c);
      sq_t[q] = (sq_t[q] + 1) % QD;
      ring(1, q, sq_t[q]);
    endtask

    // completions, in the order the controller posts them
    task collect();
      forever begin
        @(posedge vif.clk);
        if (vif.ev_cqe === 1'b1) begin
          int q = vif.ev_cqe_qid, a;
          bit [31:0] d2, d3;
          scm_ssd_cmd c;
          a = cq_addr(q) + cq_h[q] * 4;
          #1;
          d2 = host.rd(a + 2); d3 = host.rd(a + 3);
          if (infl[q].size() == 0) `uvm_error("DRV", $sformatf("completion on pair %0d with none outstanding", q))
          else begin
            c = infl[q].pop_front();
            if (d3[16] != ph[q]) `uvm_error("DRV", $sformatf("pair %0d CQE phase %0d, expected %0d", q, d3[16], ph[q]))
            if (d3[15:0] != c.cid) `uvm_error("DRV", $sformatf("pair %0d CQE CID %h, expected %h", q, d3[15:0], c.cid))
            if (d2 != {16'(q + 1), 16'(c.sqhd)}) `uvm_error("DRV", $sformatf("pair %0d CQE DW2 %h", q, d2))
            c.status = d3[24:17]; c.dnr = d3[31]; c.phase = d3[16];
            if (c.status == 0 && c.opcode == 2)
              for (int i = 0; i < (c.nlb + 1) * BLKDW; i++) c.rdata.push_back(host.rd(c.buf_a + i));
            n_done++;
            done_ap.write(c);
          end
          cq_h[q] = (cq_h[q] + 1) % QD;
          if (cq_h[q] == 0) ph[q] = !ph[q];
          unrung[q]++;
        end
      end
    endtask

    task cq_doorbells();
      forever begin
        @(negedge vif.clk);
        for (int q = 0; q < NQ; q++)
          if (unrung[q] != 0 && (cq_hold == 0 || $urandom % cq_hold == 0)) begin
            unrung[q] = 0;
            ring(0, q, cq_h[q]);
          end
      end
    endtask

    task wait_idle();
      while (outstanding() != 0) @(negedge vif.clk);
      repeat (4) @(negedge vif.clk);
    endtask
  endclass

  //==========================================================================
  // byte side
  //==========================================================================
  typedef uvm_sequencer #(scm_ssd_bacc) scm_ssd_bacc_sqr;

  class scm_ssd_bacc_driver extends uvm_driver #(scm_ssd_bacc);
    `uvm_component_utils(scm_ssd_bacc_driver)
    virtual scm_ssd_if vif;
    bit [7:0] tag_n = 0;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual scm_ssd_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "scm_ssd_if not set")
    endfunction
    task run_phase(uvm_phase phase);
      vif.b_req_valid = 0; vif.b_req_we = 0; vif.b_req_tag = 0; vif.b_req_addr = 0; vif.b_req_wdata = 0;
      wait (vif.rst_n === 1'b1);
      forever begin
        int t;
        seq_item_port.get_next_item(req);
        @(negedge vif.clk);
        req.tag = tag_n++;
        vif.b_req_valid = 1; vif.b_req_we = req.we; vif.b_req_tag = req.tag;
        vif.b_req_addr = req.addr; vif.b_req_wdata = req.wdata;
        @(posedge vif.clk);
        while (vif.b_req_ready !== 1'b1) @(posedge vif.clk);
        @(negedge vif.clk);
        vif.b_req_valid = 0;
        t = 0;
        while (vif.b_rsp_valid !== 1'b1 && t < 1000) begin @(posedge vif.clk); #1; t++; end
        if (vif.b_rsp_valid !== 1'b1) `uvm_error("BDRV", "byte port: no response")
        if (vif.b_rsp_tag != req.tag) `uvm_error("BDRV", $sformatf("byte port tag %h, expected %h", vif.b_rsp_tag, req.tag))
        req.rdata = vif.b_rsp_data; req.err = vif.b_rsp_err;
        seq_item_port.item_done();
      end
    endtask
  endclass

  //==========================================================================
  // monitor
  //==========================================================================
  class scm_ssd_monitor extends uvm_monitor;
    `uvm_component_utils(scm_ssd_monitor)
    virtual scm_ssd_if vif;
    uvm_analysis_port #(scm_ssd_cqe)  cqe_ap;
    uvm_analysis_port #(scm_ssd_bacc) bacc_ap;
    int unsigned n_cqe = 0, n_bacc = 0;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      cqe_ap = new("cqe_ap", this);
      bacc_ap = new("bacc_ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      if (!uvm_config_db#(virtual scm_ssd_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "scm_ssd_if not set")
    endfunction
    task run_phase(uvm_phase phase);
      bit [31:0]   cw [NQ][4];
      scm_ssd_bacc pend_b [$];
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n !== 1'b1) continue;
        // CQ entry dwords as the controller writes them
        if (vif.m_req_valid && vif.m_req_ready && vif.m_req_we)
          for (int q = 0; q < NQ; q++)
            if (vif.m_req_addr >= cq_addr(q) && vif.m_req_addr < cq_addr(q) + QD * 4)
              cw[q][vif.m_req_addr[1:0]] = vif.m_req_wdata;
        if (vif.ev_cqe) begin
          scm_ssd_cqe e = scm_ssd_cqe::type_id::create("e");
          e.qid = vif.ev_cqe_qid;
          e.sqid = cw[e.qid][2][31:16]; e.sqhd = cw[e.qid][2][15:0];
          e.cid = cw[e.qid][3][15:0]; e.phase = cw[e.qid][3][16];
          e.status = cw[e.qid][3][24:17]; e.dnr = cw[e.qid][3][31];
          e.ru_fill = vif.ru_fill; e.nand_blks = vif.nand_blks; e.scm_blks = vif.scm_blks;
          if (cw[e.qid][0] != 0 || cw[e.qid][1] != 0) `uvm_error("MON", "CQE DW0/DW1 not zero")
          n_cqe++;
          cqe_ap.write(e);
        end
        // byte port: request taken, then its response
        if (vif.b_req_valid && vif.b_req_ready) begin
          scm_ssd_bacc b = scm_ssd_bacc::type_id::create("b");
          b.we = vif.b_req_we; b.addr = vif.b_req_addr; b.wdata = vif.b_req_wdata; b.tag = vif.b_req_tag;
          pend_b.push_back(b);
        end
        if (vif.b_rsp_valid) begin
          if (pend_b.size() == 0) `uvm_error("MON", "byte response without a request")
          else begin
            scm_ssd_bacc b = pend_b.pop_front();
            if (vif.b_rsp_tag != b.tag) `uvm_error("MON", $sformatf("byte response tag %h, expected %h", vif.b_rsp_tag, b.tag))
            b.rdata = vif.b_rsp_data; b.err = vif.b_rsp_err;
            n_bacc++;
            bacc_ap.write(b);
          end
        end
      end
    endtask
  endclass

  //==========================================================================
  // scoreboard (reference model)
  //==========================================================================
  `uvm_analysis_imp_decl(_cmd)
  `uvm_analysis_imp_decl(_cqe)
  `uvm_analysis_imp_decl(_bacc)
  class scm_ssd_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(scm_ssd_scoreboard)
    uvm_analysis_imp_cmd  #(scm_ssd_cmd,  scm_ssd_scoreboard) cmd_imp;
    uvm_analysis_imp_cqe  #(scm_ssd_cqe,  scm_ssd_scoreboard) cqe_imp;
    uvm_analysis_imp_bacc #(scm_ssd_bacc, scm_ssd_scoreboard) bacc_imp;
    bit [31:0]   ns_s [DS], ns_n [DN];
    int          fill [NRUH];
    int          r_nand = 0, r_scm = 0;
    scm_ssd_cqe  cqe_q [$];
    scm_ssd_cmd  cmd_q [$];
    int unsigned checks = 0, errs = 0, n_status [256], n_ru = 0, n_fdp = 0;
    int unsigned n_bld = 0, n_bst = 0, n_berr = 0;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      cmd_imp = new("cmd_imp", this); cqe_imp = new("cqe_imp", this); bacc_imp = new("bacc_imp", this);
      foreach (ns_s[i]) ns_s[i] = 0;
      foreach (ns_n[i]) ns_n[i] = 0;
      foreach (fill[h]) fill[h] = 0;
    endfunction
    function void chk(bit ok, string msg);
      checks++;
      if (!ok) begin errs++; `uvm_error("SB", msg) end
    endfunction

    // driver view: the command, its status and Read data; the model runs it
    function void write_cmd(scm_ssd_cmd c);
      bit [7:0] sc;
      sc = exp_status(c.opcode, c.fuse, c.nsid, c.dtype, c.dspec, {c.prp_win, 16'h0, c.prp_off},
                      c.prp_hi, c.slba, c.slba_hi, c.nlb);
      chk(c.status == sc && c.dnr == (sc != 0), $sformatf("%s: expected status %02h", c.convert2string(), sc));
      n_status[sc]++;
      if (sc == 0 && c.opcode == 2)
        for (int i = 0; i < (c.nlb + 1) * BLKDW; i++)
          chk(c.rdata[i] == (c.nsid == 2 ? ns_n[c.slba * BLKDW + i] : ns_s[c.slba * BLKDW + i]),
              $sformatf("%s: Read dword %0d %h", c.convert2string(), i, c.rdata[i]));
      if (sc == 0 && c.opcode == 1) begin
        for (int i = 0; i < (c.nlb + 1) * BLKDW; i++)
          if (c.nsid == 2) ns_n[c.slba * BLKDW + i] = c.wdata[i];
          else ns_s[c.slba * BLKDW + i] = c.wdata[i];
        if (c.nsid == 2) begin
          int h = c.dtype == 2 ? c.dspec : 0, s;
          if (c.dtype == 2) n_fdp++;
          s = fill[h] + c.nlb + 1;
          if (s >= RUB) n_ru++;
          fill[h] = s % RUB;
          r_nand += c.nlb + 1;
        end else r_scm += c.nlb + 1;
      end
      cmd_q.push_back(c);
      match();
    endfunction
    // monitor view: the completion entry on the bus and the FDP state with it
    function void write_cqe(scm_ssd_cqe e);
      cqe_q.push_back(e);
      match();
    endfunction
    function void match();
      while (cmd_q.size() && cqe_q.size()) begin
        scm_ssd_cmd c = cmd_q.pop_front();
        scm_ssd_cqe e = cqe_q.pop_front();
        chk(e.qid == c.qid && e.cid == c.cid && e.status == c.status && e.sqid == c.qid + 1 && e.sqhd == c.sqhd,
            $sformatf("monitor CQE q%0d cid=%h sc=%02h sqid=%0d sqhd=%0d vs driver %s",
                      e.qid, e.cid, e.status, e.sqid, e.sqhd, c.convert2string()));
        for (int h = 0; h < NRUH; h++)
          chk(e.ru_fill[2*h +: 2] == fill[h], $sformatf("ru_fill[%0d] %0d, model %0d", h, e.ru_fill[2*h +: 2], fill[h]));
        chk(e.nand_blks == r_nand && e.scm_blks == r_scm,
            $sformatf("block counters nand %0d/%0d scm %0d/%0d", e.nand_blks, r_nand, e.scm_blks, r_scm));
      end
    endfunction
    // byte port: an access as the monitor saw it
    function void write_bacc(scm_ssd_bacc b);
      chk(b.err == (b.addr >= DS), $sformatf("%s: error flag", b.convert2string()));
      if (b.addr >= DS) n_berr++;
      else if (b.we) begin ns_s[b.addr] = b.wdata; n_bst++; chk(b.rdata == 0, "store answered with data"); end
      else begin n_bld++; chk(b.rdata == ns_s[b.addr], $sformatf("%s: model %h", b.convert2string(), ns_s[b.addr])); end
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("checks=%0d errors=%0d | status 00:%0d 01:%0d 02:%0d 0B:%0d 13:%0d 80:%0d 04:%0d | FDP writes %0d RU fills %0d | nand %0d scm %0d blocks | byte ld %0d st %0d err %0d",
                checks, errs, n_status[8'h00], n_status[8'h01], n_status[8'h02], n_status[8'h0B], n_status[8'h13],
                n_status[8'h80], n_status[8'h04], n_fdp, n_ru, r_nand, r_scm, n_bld, n_bst, n_berr), UVM_LOW)
      if (checks > 0 && (n_status[8'h00] == 0 || n_status[8'h01] == 0 || n_status[8'h02] == 0 || n_status[8'h0B] == 0 ||
                         n_status[8'h13] == 0 || n_status[8'h80] == 0 || n_status[8'h04] == 0 || n_ru == 0 ||
                         n_bld == 0 || n_bst == 0 || n_berr == 0)) begin
        errs++;
        `uvm_error("SB", "stimulus hole: a status code, an FDP reclaim unit fill or a byte-port case never happened")
      end
      if (cmd_q.size() || cqe_q.size())
        `uvm_error("SB", $sformatf("unmatched completions: driver %0d monitor %0d", cmd_q.size(), cqe_q.size()))
      if (errs == 0 && checks > 0 && !cmd_q.size() && !cqe_q.size()) $display("SB_PASS checks=%0d", checks);
    endfunction
  endclass

  //==========================================================================
  // env
  //==========================================================================
  class scm_ssd_env extends uvm_env;
    `uvm_component_utils(scm_ssd_env)
    scm_ssd_host        host;
    scm_ssd_cmd_sqr     cmd_sqr;
    scm_ssd_cmd_driver  cmd_drv;
    scm_ssd_bacc_sqr    bacc_sqr;
    scm_ssd_bacc_driver bacc_drv;
    scm_ssd_monitor     mon;
    scm_ssd_scoreboard  sb;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      host     = scm_ssd_host::type_id::create("host", this);
      cmd_sqr  = scm_ssd_cmd_sqr::type_id::create("cmd_sqr", this);
      cmd_drv  = scm_ssd_cmd_driver::type_id::create("cmd_drv", this);
      bacc_sqr = scm_ssd_bacc_sqr::type_id::create("bacc_sqr", this);
      bacc_drv = scm_ssd_bacc_driver::type_id::create("bacc_drv", this);
      mon      = scm_ssd_monitor::type_id::create("mon", this);
      sb       = scm_ssd_scoreboard::type_id::create("sb", this);
    endfunction
    function void connect_phase(uvm_phase phase);
      cmd_drv.host = host;
      cmd_drv.seq_item_port.connect(cmd_sqr.seq_item_export);
      bacc_drv.seq_item_port.connect(bacc_sqr.seq_item_export);
      cmd_drv.done_ap.connect(sb.cmd_imp);
      mon.cqe_ap.connect(sb.cqe_imp);
      mon.bacc_ap.connect(sb.bacc_imp);
    endfunction
  endclass

  //==========================================================================
  // sequences (fields set with $urandom: no solver needed)
  //==========================================================================
  class scm_ssd_cmd_seq extends uvm_sequence #(scm_ssd_cmd);
    `uvm_object_utils(scm_ssd_cmd_seq)
    int n = 100;
    int p_err = 0;                      // percent of malformed commands
    bit scm_lo_only = 1;                // namespace 1 traffic in the lower half (byte port owns the upper)
    int f_qid = -1, f_op = -1, f_ns = -1, f_dspec = -1;
    function new(string name = "scm_ssd_cmd_seq"); super.new(name); endfunction
    task body();
      repeat (n) begin
        scm_ssd_cmd c = scm_ssd_cmd::type_id::create("c");
        int r = $urandom % 100, nb, span, kind;
        start_item(c);
        c.qid = f_qid >= 0 ? f_qid : $urandom % NQ;
        c.opcode = f_op >= 0 ? f_op : r < 45 ? 1 : r < 88 ? 2 : 0;
        c.nsid = f_ns >= 0 ? f_ns : 1 + $urandom % 2;
        if (c.opcode == 0 && f_ns < 0 && $urandom % 4 == 0) c.nsid = 32'hFFFF_FFFF;
        nb = c.nsid == 2 ? NBN : NBS;
        span = c.nsid == 1 && scm_lo_only ? NBS / 2 : nb;
        c.slba = $urandom % span;
        c.nlb = $urandom % (span - c.slba);
        if (c.opcode == 1 && c.nsid == 2 && $urandom % 3 != 0) begin c.dtype = 2; c.dspec = $urandom % NRUH; end
        if (f_dspec >= 0) begin c.dtype = 2; c.dspec = f_dspec; end
        kind = $urandom % 10;           // drawn once: a case on $urandom redraws per item
        if ($urandom % 100 < p_err)
          case (kind)
            0: c.opcode = 3 + $urandom % 253;
            1: c.fuse = 1 + $urandom % 3;
            2: c.nsid = $urandom % 2 ? 32'd3 : 32'd0;
            3: begin c.opcode = 1; c.nsid = 2; c.dtype = 2; c.dspec = NRUH + $urandom % 1000; end
            4: begin c.opcode = 1; c.dtype = $urandom % 2 ? 1 : 3 + $urandom % 13; end
            5: begin c.opcode = 1; c.nsid = 1; c.dtype = 2; c.dspec = $urandom % NRUH; end
            6: c.prp_off = 1 + $urandom % 3;
            7: c.slba = nb + $urandom % 8;
            8: c.slba_hi = 32'd1 << ($urandom % 32);
            default: c.prp_win = 14'd1 << ($urandom % 14);
          endcase
        for (int i = 0; i < (c.nlb + 1) * BLKDW && i < 64; i++) c.wdata.push_back($urandom);
        finish_item(c);
      end
    endtask
  endclass

  class scm_ssd_bacc_seq extends uvm_sequence #(scm_ssd_bacc);
    `uvm_object_utils(scm_ssd_bacc_seq)
    int n = 200;
    int lo = DS / 2, hi = DS;           // address range [lo, hi)
    int p_oob = 10;                     // percent beyond the SCM region
    int f_we = -1;
    function new(string name = "scm_ssd_bacc_seq"); super.new(name); endfunction
    task body();
      repeat (n) begin
        scm_ssd_bacc b = scm_ssd_bacc::type_id::create("b");
        start_item(b);
        b.we = f_we >= 0 ? f_we : $urandom % 2;
        b.addr = $urandom % 100 < p_oob ? DS + $urandom % 4000 : lo + $urandom % (hi - lo);
        b.wdata = $urandom;
        finish_item(b);
      end
    endtask
  endclass
endpackage
`endif
