// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// scm_ssd_if.sv -- pins of the SCM dual-mode SSD controller (open-ip-portfolio
// SCM_SSD_top, default parameters): controller registers and doorbells, the
// host memory master the controller uses for queues and data, the byte-mode
// (CXL.mem-style) port, FDP statistics and events.

`ifndef SCM_SSD_IF_SV
`define SCM_SSD_IF_SV
interface scm_ssd_if (input logic clk, input logic rst_n);
  localparam int NQ = 4, QW = 3, NRUH = 4, RW = 2;
  // controller registers
  logic              cc_en;
  logic              csts_rdy;
  logic [NQ*16-1:0]  sq_base, cq_base;
  logic              sq_db_valid, cq_db_valid;
  logic [1:0]        sq_db_qid, cq_db_qid;
  logic [15:0]       sq_db, cq_db;
  logic [NQ*QW-1:0]  sq_head, cq_tail;
  // host memory master (the controller's DMA)
  logic              m_req_valid, m_req_ready, m_req_we;
  logic [15:0]       m_req_addr;
  logic [31:0]       m_req_wdata;
  logic              m_rsp_valid;
  logic [31:0]       m_rsp_data;
  // byte port
  logic              b_req_valid, b_req_ready, b_req_we;
  logic [7:0]        b_req_tag;
  logic [15:0]       b_req_addr;
  logic [31:0]       b_req_wdata;
  logic              b_rsp_valid, b_rsp_err;
  logic [7:0]        b_rsp_tag;
  logic [31:0]       b_rsp_data;
  // FDP and statistics
  logic [NRUH*RW-1:0] ru_fill;
  logic [31:0]       nand_blks, scm_blks;
  // events
  logic              ev_cqe, ev_err, ev_db, ev_ru;
  logic [1:0]        ev_cqe_qid, ev_ru_h;
endinterface
`endif
