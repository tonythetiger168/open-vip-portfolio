// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// scm_ssd_uvm_top.sv (module top_tb) -- SCM dual-mode SSD VIP top: the real controller RTL
// (open-ip-portfolio rtl/SCM_SSD_top.sv) driven by the UVM environment.

`ifndef SCM_SSD_TOP_TB_SV
`define SCM_SSD_TOP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import scm_ssd_pkg::*;
import scm_ssd_test_pkg::*;

module top_tb;
  logic clk = 0, rst_n = 0;
  always #5ns clk = ~clk;
  initial begin
    #100ns;
    rst_n = 1;
  end

  scm_ssd_if vif (clk, rst_n);

  SCM_SSD_top dut (
    .clk(clk), .rst_n(rst_n),
    .cc_en(vif.cc_en), .csts_rdy(vif.csts_rdy), .sq_base(vif.sq_base), .cq_base(vif.cq_base),
    .sq_db_valid(vif.sq_db_valid), .sq_db_qid(vif.sq_db_qid), .sq_db(vif.sq_db),
    .cq_db_valid(vif.cq_db_valid), .cq_db_qid(vif.cq_db_qid), .cq_db(vif.cq_db),
    .sq_head(vif.sq_head), .cq_tail(vif.cq_tail),
    .m_req_valid(vif.m_req_valid), .m_req_ready(vif.m_req_ready), .m_req_we(vif.m_req_we),
    .m_req_addr(vif.m_req_addr), .m_req_wdata(vif.m_req_wdata),
    .m_rsp_valid(vif.m_rsp_valid), .m_rsp_data(vif.m_rsp_data),
    .b_req_valid(vif.b_req_valid), .b_req_ready(vif.b_req_ready), .b_req_we(vif.b_req_we),
    .b_req_tag(vif.b_req_tag), .b_req_addr(vif.b_req_addr), .b_req_wdata(vif.b_req_wdata),
    .b_rsp_valid(vif.b_rsp_valid), .b_rsp_tag(vif.b_rsp_tag), .b_rsp_data(vif.b_rsp_data),
    .b_rsp_err(vif.b_rsp_err),
    .ru_fill(vif.ru_fill), .nand_blks(vif.nand_blks), .scm_blks(vif.scm_blks),
    .ev_cqe(vif.ev_cqe), .ev_cqe_qid(vif.ev_cqe_qid), .ev_err(vif.ev_err), .ev_db(vif.ev_db),
    .ev_ru(vif.ev_ru), .ev_ru_h(vif.ev_ru_h)
  );

  initial begin
    uvm_config_db#(virtual scm_ssd_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule
`endif
