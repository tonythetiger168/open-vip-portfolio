# SCM_SSD Test Plan (SCM_SSD-VIP)

| Item | Content |
|---|---|
| Protocol | SCM dual-mode SSD: NVMe 2.1-style multi-queue + FDP, CXL.mem-style byte port |
| DUT | `SCM_SSD_top` (open-ip-portfolio RTL, default parameters) |
| Test | `scm_ssd_random_test` |

## Phases of `scm_ssd_random_test`

| # | Stimulus | Checked |
|---|---|---|
| 1 | 150 valid commands, random pair, namespace, LBA range, opcode | status, Read data against the model, CQE fields (driver and monitor) |
| 2 | 200 commands with 35% malformed (opcode, FUSE, NSID, DTYPE, DSPEC, FDP on SCM, PRP offset, LBA range, PRP window), CQ doorbells delayed; 400 byte-port accesses on the upper SCM half (10% out of range) in parallel | every status code, DNR, CQ full handling, byte data and errors |
| 3 | 40 NAND Writes (2/3 with FDP handles), 3 Writes with handles of NRUH or more | reclaim unit fill per handle (`ru_fill`), NAND block counter, Invalid Field on bad handles |
| 4 | dual mode, serialized: namespace 1 Write → byte loads over the whole SCM region → byte stores → namespace 1 Reads | both views see the same cells |
