# SCM_SSD — SCM dual-mode SSD UVM VIP

UVM verification IP for an SCM dual-mode SSD: one device with an SCM
(storage-class memory, XL-FLASH-class) region and a NAND region, reached in
two ways:

- **block mode**: NVMe 2.1-style I/O queues (4 submission / completion
  queue pairs), Write / Read / Flush on namespace 1 (SCM) and namespace 2
  (NAND), Flexible Data Placement (FDP) on namespace 2 (CDW12 DTYPE 2,
  CDW13 DSPEC placement handle, reclaim unit fill per handle)
- **byte mode**: a CXL.mem-style tagged load / store port onto the SCM
  region, coherent with namespace 1

The DUT is the real RTL: `rtl/SCM_SSD_top.sv`, a copy of
[open-ip-portfolio](https://github.com/tonythetiger168/open-ip-portfolio)
`rtl/SCM_SSD_top.sv` (default parameters). Written for the Helios KV-cache
chip, whose SSD tier this models.

## Contents

| Path | Description |
|------|-------------|
| `scm_ssd/scm_ssd_if.sv` | DUT pins |
| `scm_ssd/scm_ssd_pkg.sv` | items, host memory, NVMe and byte-port drivers, monitor, reference scoreboard, env, sequences |
| `tests/scm_ssd_tests.sv` | `scm_ssd_random_test` |
| `tb/scm_ssd_uvm_top.sv` | UVM top (`top_tb`): `SCM_SSD_top` + `scm_ssd_if` |
| `tb/SCM_SSD_tb.sv` | directed self-checking TB from open-ip-portfolio (`TEST PASSED: SCM_SSD`), run by `tools/run_func_tests.py` |
| `rtl/SCM_SSD_top.sv` | DUT (copy of the open-ip-portfolio core) |

## Architecture

- `scm_ssd_host`: host memory slave for the controller's DMA master
  (random back-pressure and read latency); holds the queues and buffers.
- NVMe driver: builds 64-byte SQ entries and data buffers in host memory,
  rings SQ doorbells on any queue pair without waiting for completions
  (several commands in flight on every pair), collects completion entries
  in the order `ev_cqe` reports them (checking CID, SQ identifier, SQ head
  and phase), rings CQ doorbells after a configurable delay
  (`cq_hold`), and publishes each completed command.
- Byte-port driver: one tagged access at a time.
- Monitor (passive): rebuilds completion entries from the CQ writes on the
  DMA bus and samples `ru_fill` and the block counters with `ev_cqe`;
  rebuilds byte-port accesses from request / response pins.
- Scoreboard: a reference model of the command checks (generic status
  01h, 02h, 0Bh, 13h, 80h, 04h and DNR), the SCM and NAND namespaces and
  the FDP reclaim unit fill per handle. It checks every completion from
  both the driver and monitor views, every Read's data, `ru_fill` and the
  block counters, and every byte-port load, store and out-of-range error.
  Prints `SB_PASS checks=<n>` when clean.

## Running

```
python3 tools/run_uvm_tests.py --smoke SCM_SSD-VIP
```
