// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_env.sv -- NCSI environment: reference-model scoreboard, checker, coverage

package ncsi_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import ncsi_defs_pkg::*;
  import ncsi_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class ncsi_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(ncsi_scoreboard)
    uvm_analysis_imp_exp #(ncsi_transaction, ncsi_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(ncsi_transaction, ncsi_scoreboard) obs_ap;

    ncsi_config cfg;
    ncsi_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [1:0] init_req = 2'b11, en = 2'b00;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(ncsi_config)::get(this, "", "cfg", cfg))
        cfg = ncsi_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(ncsi_transaction t);
      int e = ncsi_exp_len(t.cmd), ch = t.chan[4:0];
      bit pkgc = (t.cmd == 8'h01 || t.cmd == 8'h02);
      t.got = 0; t.rtype = 0; t.riid = 0; t.rchan = 0; t.rcode = 0; t.reason = 0; t.rok = 0; t.rdata.delete();
      if (!(t.fault inside {1, 2, 3}) && t.chan[7:5] == 0 && (ch <= 1 || ch == 31)) begin
        t.got = 1; t.rok = 1; t.rtype = t.cmd | 8'h80; t.riid = t.iid; t.rchan = t.chan;
        if (e < 0) begin t.rcode = 3; t.reason = 16'h7FFF; end
        else if (pkgc != (ch == 31) || t.fault == 4) begin t.rcode = 1; t.reason = 2; end
        else if (ch != 31 && init_req[ch] && t.cmd != 0) begin t.rcode = 1; t.reason = 1; end
        else
          case (t.cmd)
            8'h00: init_req[ch] = 0;
            8'h03: en[ch] = 1;
            8'h04: en[ch] = 0;
            8'h05: begin init_req[ch] = 1; en[ch] = 0; end
            8'h0A: begin
              repeat (12) t.rdata.push_back(8'h00);
              t.rdata[3] = en[ch] ? 8'h11 : 8'h10;
            end
            8'h15: for (int i = 0; i < 40; i++) t.rdata.push_back(ncsi_ver_byte(i));
            default: ;
          endcase
      end
    endfunction

    function void write_exp(ncsi_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(ncsi_transaction t);
      ncsi_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        ncsi_transaction e = exp_q.pop_front();
        ncsi_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("ncsi scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class ncsi_env extends uvm_env;
    `uvm_component_utils(ncsi_env)
    ncsi_agent      agt;
    ncsi_scoreboard sb;
    ncsi_checker    chk;
    ncsi_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = ncsi_agent     ::type_id::create("agt", this);
      sb  = ncsi_scoreboard::type_id::create("sb",  this);
      chk = ncsi_checker   ::type_id::create("chk", this);
      cov = ncsi_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
