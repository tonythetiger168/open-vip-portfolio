// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- NCSI testbench top with a functional NCSI DUT model

`ifndef NC_SI_UVM_VIP_TB_SV
`define NC_SI_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ncsi_defs_pkg::*;
import ncsi_pkg::*;
import ncsi_env_pkg::*;
import ncsi_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ncsi_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ncsi_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tx_en(vif.tx_en),
    .txd(vif.txd),
    .crs_dv(vif.crs_dv),
    .rxd(vif.rxd)
  );

  // Concurrent protocol checks
  ncsi_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .tx_en(vif.tx_en),
    .txd(vif.txd),
    .crs_dv(vif.crs_dv),
    .rxd(vif.rxd)
  );

  initial begin
    uvm_config_db#(virtual ncsi_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ncsi_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic       tx_en,
  input  logic [1:0] txd,
  output logic       crs_dv,
  output logic [1:0] rxd
);
  localparam int GAP = 16;            // REF_CLKs from the command's end to the response

  function automatic logic [31:0] crc32_byte(input logic [31:0] c, input logic [7:0] b);
    logic [31:0] x;
    x = c ^ {24'h0, b};
    for (int k = 0; k < 8; k++) x = x[0] ? (x >> 1) ^ 32'hEDB8_8320 : (x >> 1);
    crc32_byte = x;
  endfunction
  function automatic logic [7:0] ver_byte(input integer i);
    case (i)
      0, 1: ver_byte = 8'hF1;
      2: ver_byte = 8'hF0;
      8: ver_byte = "O"; 9: ver_byte = "P"; 10: ver_byte = "E"; 11: ver_byte = "N";
      12: ver_byte = "V"; 13: ver_byte = "I"; 14: ver_byte = "P"; 15: ver_byte = "-";
      16: ver_byte = "N"; 17: ver_byte = "C"; 18: ver_byte = "S"; 19: ver_byte = "I";
      20: ver_byte = 8'h01; 21: ver_byte = 8'h02; 22: ver_byte = 8'h03; 23: ver_byte = 8'h04;
      24: ver_byte = 8'h12; 25: ver_byte = 8'h34; 26: ver_byte = 8'hAB; 27: ver_byte = 8'hCD;
      28: ver_byte = 8'h00; 29: ver_byte = 8'h01; 30: ver_byte = 8'hAB; 31: ver_byte = 8'hCD;
      39: ver_byte = 8'h2A;
      default: ver_byte = 8'h00;
    endcase
  endfunction

  logic [7:0]  rb [0:127];            // command frame after the SFD
  logic [7:0]  tb [0:127];            // response: preamble, SFD, frame
  logic [7:0]  nrb, sh, tlen;
  logic [1:0]  dib;
  logic        sync, tx_p, pend, busy;
  logic [1:0]  init_req, en;
  logic [4:0]  wcnt;
  logic [9:0]  tdib;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      nrb <= '0; sh <= '0; dib <= '0; sync <= 1'b0; tx_p <= 1'b0; pend <= 1'b0; busy <= 1'b0;
      init_req <= 2'b11; en <= 2'b00; wcnt <= '0; tdib <= '0; tlen <= '0;
      crs_dv <= 1'b0; rxd <= 2'b00;
    end else begin
      tx_p <= tx_en;
      // receive: dibits after the SFD's 11, LSB first
      if (tx_en) begin
        if (!tx_p) begin sync <= (txd == 2'b11); nrb <= '0; dib <= '0; end
        else if (!sync) sync <= (txd == 2'b11);
        else begin
          sh <= {txd, sh[7:2]};
          dib <= dib + 2'd1;
          if (dib == 2'd3) begin
            if (nrb < 8'd128) rb[nrb[6:0]] <= {txd, sh[7:2]};
            nrb <= nrb + 8'd1;
          end
        end
      end else if (tx_p && !busy && !pend) begin : decode
        logic [7:0]  f [0:127];
        logic [31:0] c, s, sum;
        logic [11:0] len;
        logic [7:0]  cmd, ch;
        logic [15:0] code, reason;
        integer      n, p4, e, dl, fl;
        logic        ok, pkgc;
        n = nrb;
        ok = (n >= 64 && n <= 128);
        c = 32'hFFFF_FFFF;
        for (int i = 0; i < 128; i++) if (i < n) c = crc32_byte(c, rb[i]);
        if (c != 32'hDEBB_20E3) ok = 1'b0;
        if ({rb[12], rb[13]} != 16'h88F8 || rb[15] != 8'h01) ok = 1'b0;
        cmd = rb[18]; ch = rb[19];
        if (ch[7:5] != 3'd0 || (ch[4:0] > 5'd1 && ch[4:0] != 5'h1F)) ok = 1'b0;
        len = {rb[20][3:0], rb[21]};
        p4 = (len + 3) / 4 * 4;
        if (34 + p4 > n - 4) ok = 1'b0;
        s = 32'h0;
        for (int i = 0; i < 112; i += 2) if (i < 16 + p4) s = s + {16'h0, rb[14 + i], rb[15 + i]};
        s = -s;
        sum = {rb[30 + p4], rb[31 + p4], rb[32 + p4], rb[33 + p4]};
        if (sum != 32'h0 && sum != s) ok = 1'b0;
        case (cmd)
          8'h00, 8'h02, 8'h03, 8'h0A, 8'h15: e = 0;
          8'h01, 8'h04, 8'h05: e = 4;
          default: e = -1;
        endcase
        pkgc = (cmd == 8'h01 || cmd == 8'h02);
        dl = 0;
        for (int i = 0; i < 128; i++) f[i] = 8'h00;
        if (ok) begin
          if (e < 0) begin code = 16'h0003; reason = 16'h7FFF; end
          else if (pkgc != (ch[4:0] == 5'h1F) || len != e) begin code = 16'h0001; reason = 16'h0002; end
          else if (ch[4:0] != 5'h1F && init_req[ch[0]] && cmd != 8'h00) begin code = 16'h0001; reason = 16'h0001; end
          else begin
            code = 16'h0000; reason = 16'h0000;
            case (cmd)
              8'h00: init_req[ch[0]] <= 1'b0;
              8'h03: en[ch[0]] <= 1'b1;
              8'h04: en[ch[0]] <= 1'b0;
              8'h05: begin init_req[ch[0]] <= 1'b1; en[ch[0]] <= 1'b0; end
              8'h0A: begin dl = 12; f[45] = en[ch[0]] ? 8'h11 : 8'h10; end
              8'h15: begin dl = 40; for (int i = 0; i < 40; i++) f[42 + i] = ver_byte(i); end
              default: ;
            endcase
          end
          // response frame at f[8..]: preamble and SFD first
          for (int i = 0; i < 7; i++) f[i] = 8'h55;
          f[7] = 8'hD5;
          for (int i = 0; i < 12; i++) f[8 + i] = 8'hFF;
          f[20] = 8'h88; f[21] = 8'hF8;
          f[22] = rb[14]; f[23] = 8'h01; f[25] = rb[17]; f[26] = cmd | 8'h80; f[27] = ch;
          f[28] = 8'h00; f[29] = 8'(4 + dl);
          f[38] = code[15:8]; f[39] = code[7:0]; f[40] = reason[15:8]; f[41] = reason[7:0];
          s = 32'h0;
          for (int i = 0; i < 60; i += 2) if (i < 20 + dl) s = s + {16'h0, f[22 + i], f[23 + i]};
          s = -s;
          for (int i = 0; i < 4; i++) f[42 + dl + i] = s[31 - 8*i -: 8];
          fl = 38 + dl;                          // frame bytes before the padding
          if (fl < 60) fl = 60;
          c = 32'hFFFF_FFFF;
          for (int i = 0; i < 100; i++) if (i < fl) c = crc32_byte(c, f[8 + i]);
          c = ~c;
          for (int i = 0; i < 4; i++) f[8 + fl + i] = c[8*i +: 8];
          for (int i = 0; i < 128; i++) tb[i] <= f[i];
          tlen <= 8'(8 + fl + 4);
          pend <= 1'b1; wcnt <= '0;
        end
      end
      // transmit after the gap
      if (pend) begin
        wcnt <= wcnt + 5'd1;
        if (wcnt == 5'(GAP - 1)) begin pend <= 1'b0; busy <= 1'b1; tdib <= '0; end
      end
      if (busy) begin
        crs_dv <= 1'b1;
        rxd <= tb[tdib[9:2]][2*tdib[1:0] +: 2];
        tdib <= tdib + 10'd1;
        if (tdib == {tlen, 2'b00} - 10'd1) busy <= 1'b0;
      end else begin
        crs_dv <= 1'b0; rxd <= 2'b00;
      end
    end
  end
endmodule
`endif
