// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (NCSI DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened ncsi_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic tx_en = 1'b0;
  logic [1:0] txd = 2'b00;
  wire crs_dv;
  wire [1:0] rxd;

  always #10 clk = ~clk;

  ncsi_model u_dut (.clk(clk), .rst_n(rst_n), .tx_en(tx_en), .txd(txd), .crs_dv(crs_dv), .rxd(rxd));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic logic [31:0] crc32(input logic [31:0] c, input logic [7:0] b);
    logic [31:0] x;
    x = c ^ {24'h0, b};
    for (int k = 0; k < 8; k++) x = x[0] ? (x >> 1) ^ 32'hEDB8_8320 : (x >> 1);
    crc32 = x;
  endfunction

  // response capture
  logic [7:0] rr [0:127];
  integer rn = 0, rcount = 0, npre = 0, cyc = 0, tend = 0, rstart = 0, rd = 0;
  logic rs = 0, cp = 0, tp = 0;
  logic [7:0] rsh = 0;
  always @(posedge clk) begin
    cyc = cyc + 1;
    if (crs_dv) begin
      if (!cp) begin rs = 0; rn = 0; npre = 0; rstart = cyc; end
      if (!rs) begin
        if (rxd == 2'b11) begin rs = 1; rd = 0; end
        else if (rxd == 2'b01) npre = npre + 1;
      end else begin
        rsh = {rxd, rsh[7:2]}; rd = rd + 1;
        if (rd == 4) begin rr[rn] = rsh; rn = rn + 1; rd = 0; end
      end
    end else if (cp) rcount = rcount + 1;
    if (!tx_en && tp) tend = cyc;
    cp = crs_dv; tp = tx_en;
  end

  // command frame
  logic [7:0] fb [0:127];
  integer fn;
  integer iid = 1;
  function automatic integer exp_len(input logic [7:0] cmd);
    case (cmd)
      8'h00, 8'h02, 8'h03, 8'h0A, 8'h15: exp_len = 0;
      8'h01, 8'h04, 8'h05: exp_len = 4;
      default: exp_len = 4;
    endcase
  endfunction
  // fault: 1 checksum + 0x100, 2 FCS, 3 header revision 2, 5 zero checksum, 6 EtherType 0x0800
  task automatic build(input logic [7:0] mcid, input logic [7:0] cmd, input logic [7:0] ch, input integer len, input integer fault);
    logic [31:0] c, s;
    for (int i = 0; i < 128; i++) fb[i] = 8'h00;
    for (int i = 0; i < 6; i++) fb[i] = 8'hFF;
    fb[6] = 8'h02; fb[11] = mcid;
    fb[12] = (fault == 6) ? 8'h08 : 8'h88; fb[13] = (fault == 6) ? 8'h00 : 8'hF8;
    fb[14] = mcid; fb[15] = (fault == 3) ? 8'h02 : 8'h01; fb[17] = iid; fb[18] = cmd; fb[19] = ch;
    fb[20] = len >> 8; fb[21] = len;
    for (int i = 0; i < 64; i++) if (i < len) fb[30 + i] = 8'hA0 + i;
    fn = 30 + (len + 3) / 4 * 4;
    s = 0;
    for (int i = 14; i < 128; i += 2) if (i < fn) s = s + {16'h0, fb[i], fb[i + 1]};
    s = -s;
    if (fault == 5) s = 0;
    if (fault == 1) s = s ^ 32'h100;
    fb[fn] = s[31:24]; fb[fn + 1] = s[23:16]; fb[fn + 2] = s[15:8]; fb[fn + 3] = s[7:0];
    fn = fn + 4;
    if (fn < 60) fn = 60;
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < 128; i++) if (i < fn) c = crc32(c, fb[i]);
    c = ~c;
    if (fault == 2) c = c ^ 32'h1;
    fb[fn] = c[7:0]; fb[fn + 1] = c[15:8]; fb[fn + 2] = c[23:16]; fb[fn + 3] = c[31:24];
    fn = fn + 4;
  endtask
  task automatic send_byte(input logic [7:0] b);
    for (int j = 0; j < 4; j++) begin
      @(negedge clk); tx_en = 1; txd = b[2*j +: 2];
    end
  endtask
  logic got;
  task automatic send_frame();
    integer r0, k;
    r0 = rcount;
    for (int i = 0; i < 7; i++) send_byte(8'h55);
    send_byte(8'hD5);
    for (int i = 0; i < 128; i++) if (i < fn) send_byte(fb[i]);
    @(negedge clk); tx_en = 0; txd = 0;
    k = 0;
    while (k < 500 && rcount == r0) begin @(negedge clk); k = k + 1; end
    got = (rcount != r0);
    iid = iid + 1;
  endtask
  task automatic xact(input logic [7:0] cmd, input logic [7:0] ch, input integer len = -1, input integer fault = 0,
                      input logic [7:0] mcid = 8'h00);
    build(mcid, cmd, ch, (len < 0) ? exp_len(cmd) : len, fault);
    send_frame();
  endtask

  // FCS again after editing fb
  task automatic refcs();
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < 128; i++) if (i < fn - 4) c = crc32(c, fb[i]);
    c = ~c;
    fb[fn - 4] = c[7:0]; fb[fn - 3] = c[15:8]; fb[fn - 2] = c[23:16]; fb[fn - 1] = c[31:24];
  endtask
  localparam integer RSP_GAP = 18;   // GAP clocks plus the two register stages
  function automatic logic [7:0] ver_exp(input integer i);
    reg [8*12-1:0] name;
    name = "OPENVIP-NCSI";
    case (i)
      0, 1: ver_exp = 8'hF1;
      2: ver_exp = 8'hF0;
      20: ver_exp = 8'h01; 21: ver_exp = 8'h02; 22: ver_exp = 8'h03; 23: ver_exp = 8'h04;
      24: ver_exp = 8'h12; 25: ver_exp = 8'h34; 26: ver_exp = 8'hAB; 27: ver_exp = 8'hCD;
      28: ver_exp = 8'h00; 29: ver_exp = 8'h01; 30: ver_exp = 8'hAB; 31: ver_exp = 8'hCD;
      39: ver_exp = 8'h2A;
      default: ver_exp = (i >= 8 && i < 20) ? name[8*(19 - i) +: 8] : 8'h00;
    endcase
  endfunction
  // response fields
  function automatic logic [15:0] r_code(input integer x); r_code = {rr[30], rr[31]}; endfunction
  function automatic logic [15:0] r_reason(input integer x); r_reason = {rr[32], rr[33]}; endfunction
  function automatic logic r_good(input integer dl);
    logic [31:0] c, s;
    c = 32'hFFFF_FFFF;
    for (int i = 0; i < 128; i++) if (i < rn) c = crc32(c, rr[i]);
    s = 0;
    for (int i = 14; i < 128; i += 2) if (i < 34 + dl) s = s + {16'h0, rr[i], rr[i + 1]};
    s = -s;
    r_good = (c == 32'hDEBB_20E3) && ({rr[34 + dl], rr[35 + dl], rr[36 + dl], rr[37 + dl]} == s) &&
             ({rr[20][3:0], rr[21]} == 4 + dl) && rr[15] == 8'h01 && {rr[12], rr[13]} == 16'h88F8 &&
             rn == ((38 + dl < 60) ? 64 : 38 + dl + 4);
  endfunction
  function automatic logic rsp(input logic [7:0] cmd, input logic [7:0] ch, input logic [15:0] code, input logic [15:0] reason,
                               input integer dl);
    rsp = got && rr[18] == (cmd | 8'h80) && rr[19] == ch && rr[17] == iid - 1 && r_code(0) == code && r_reason(0) == reason && r_good(dl);
  endfunction

  initial begin
    logic ok;
    repeat (4) @(posedge clk);
    chk(crs_dv === 1'b0, "CRS_DV low in reset");
    rst_n = 1;
    repeat (4) @(negedge clk);

    // initial state: channel commands other than Clear Initial State are refused
    xact(8'h15, 8'h00, -1, 0, 8'h5A);
    chk(rsp(8'h15, 8'h00, 16'h1, 16'h1, 0) && rr[14] == 8'h5A, "Get Version ID in the initial state: 1 / 1, MC ID echoed");
    chk(npre == 31, $sformatf("response preamble and SFD (%0d dibits 01 before 11)", npre));
    chk(rstart - tend == RSP_GAP, $sformatf("response %0d clocks after the command", rstart - tend));
    xact(8'h00, 8'h00);
    chk(rsp(8'h00, 8'h00, 16'h0, 16'h0, 0), "Clear Initial State ch 0");
    xact(8'h15, 8'h00);
    ok = rsp(8'h15, 8'h00, 16'h0, 16'h0, 40) && rr[34] == 8'hF1 && rr[35] == 8'hF1 && rr[36] == 8'hF0 && rr[37] == 8'h00 &&
         rr[42] == "O" && rr[53] == "I" && rr[54] == 8'h01 && rr[57] == 8'h04 && rr[58] == 8'h12 && rr[73] == 8'h2A;
    chk(ok, "Get Version ID: 40 bytes, version F1 F1 F0 00, name, firmware, IDs");
    ok = 1;
    for (int i = 0; i < 40; i++) if (rr[34 + i] !== ver_exp(i)) ok = 0;
    chk(ok, "Get Version ID: every data byte");
    ok = 1;
    for (int i = 0; i < 12; i++) if (rr[i] !== 8'hFF) ok = 0;
    chk(ok, "response DA and SA FF:FF:FF:FF:FF:FF");
    xact(8'h0A, 8'h00);
    chk(rsp(8'h0A, 8'h00, 16'h0, 16'h0, 12) && {rr[34], rr[35], rr[36], rr[37]} == 32'h10, "Get Link Status ch 0 disabled: 0x10");
    xact(8'h03, 8'h00);
    chk(rsp(8'h03, 8'h00, 16'h0, 16'h0, 0), "Enable Channel ch 0");
    xact(8'h0A, 8'h00);
    chk(rsp(8'h0A, 8'h00, 16'h0, 16'h0, 12) && rr[37] == 8'h11, "Get Link Status ch 0 enabled: 0x11");
    // channel 1 has its own state
    xact(8'h03, 8'h01);
    chk(rsp(8'h03, 8'h01, 16'h1, 16'h1, 0), "Enable Channel ch 1 in its initial state: 1 / 1");
    xact(8'h00, 8'h01);
    chk(rsp(8'h00, 8'h01, 16'h0, 16'h0, 0), "Clear Initial State ch 1");
    xact(8'h0A, 8'h01);
    chk(rsp(8'h0A, 8'h01, 16'h0, 16'h0, 12) && rr[37] == 8'h10, "ch 1 cleared but disabled: 0x10");
    xact(8'h03, 8'h01);
    xact(8'h04, 8'h00);
    chk(rsp(8'h04, 8'h00, 16'h0, 16'h0, 0), "Disable Channel ch 0");
    xact(8'h0A, 8'h00);
    chk(rsp(8'h0A, 8'h00, 16'h0, 16'h0, 12) && rr[37] == 8'h10, "ch 0 disabled again: 0x10");
    xact(8'h0A, 8'h01);
    chk(rsp(8'h0A, 8'h01, 16'h0, 16'h0, 12) && rr[37] == 8'h11, "ch 1 still enabled: 0x11");
    // package commands
    xact(8'h01, 8'h1F, -1, 0, 8'h33);
    chk(rsp(8'h01, 8'h1F, 16'h0, 16'h0, 0) && rr[14] == 8'h33, "Select Package to 0x1F");
    xact(8'h02, 8'h1F);
    chk(rsp(8'h02, 8'h1F, 16'h0, 16'h0, 0), "Deselect Package to 0x1F");
    xact(8'h01, 8'h00);
    chk(rsp(8'h01, 8'h00, 16'h1, 16'h2, 0), "Select Package to a channel: 1 / 2");
    xact(8'h03, 8'h1F);
    chk(rsp(8'h03, 8'h1F, 16'h1, 16'h2, 0), "Enable Channel to 0x1F: 1 / 2");
    // unsupported, wrong length
    xact(8'h50, 8'h00);
    chk(rsp(8'h50, 8'h00, 16'h3, 16'h7FFF, 0), "unsupported command 0x50: 3 / 0x7FFF");
    xact(8'h0E, 8'h1F);
    chk(rsp(8'h0E, 8'h1F, 16'h3, 16'h7FFF, 0), "unsupported command 0x0E to the package: 3 / 0x7FFF");
    xact(8'h03, 8'h00, 4);
    chk(rsp(8'h03, 8'h00, 16'h1, 16'h2, 0), "Enable Channel with 4 payload bytes: 1 / 2");
    xact(8'h04, 8'h01, 0);
    chk(rsp(8'h04, 8'h01, 16'h1, 16'h2, 0), "Disable Channel with no payload: 1 / 2");
    xact(8'h05, 8'h00, 8);
    chk(rsp(8'h05, 8'h00, 16'h1, 16'h2, 0), "Reset Channel with 8 payload bytes: 1 / 2");
    // payload length 28 fills the frame to the checksum (no padding): still parsed
    xact(8'h03, 8'h00, 28);
    chk(fn == 66 && rsp(8'h03, 8'h00, 16'h1, 16'h2, 0), "unpadded 66-byte command with a 28-byte payload: 1 / 2");
    // a length field past the end of the frame (good FCS): dropped
    build(8'h00, 8'h03, 8'h00, 0, 0);
    fb[21] = 8'd60; refcs();
    send_frame();
    chk(!got, "payload length past the frame: no response");
    // a zero checksum is accepted
    xact(8'h03, 8'h00, -1, 5);
    chk(rsp(8'h03, 8'h00, 16'h0, 16'h0, 0), "zero checksum accepted");
    // dropped frames
    xact(8'h0A, 8'h00, -1, 1); chk(!got, "wrong checksum: no response");
    xact(8'h0A, 8'h00, -1, 2); chk(!got, "bad FCS: no response");
    xact(8'h0A, 8'h00, -1, 3); chk(!got, "header revision 2: no response");
    xact(8'h0A, 8'h00, -1, 6); chk(!got, "EtherType 0x0800: no response");
    xact(8'h0A, 8'h20);        chk(!got, "package 1: no response");
    xact(8'h0A, 8'h02);        chk(!got, "channel 2: no response");
    xact(8'h0A, 8'h3F);        chk(!got, "package 1 channel 0x1F: no response");
    xact(8'h0A, 8'h00);
    chk(rsp(8'h0A, 8'h00, 16'h0, 16'h0, 12) && rr[37] == 8'h11, "a clean command after the drops (ch 0 enabled)");
    // reset channel: back to the initial state, disabled
    xact(8'h05, 8'h00);
    chk(rsp(8'h05, 8'h00, 16'h0, 16'h0, 0), "Reset Channel ch 0");
    xact(8'h0A, 8'h00);
    chk(rsp(8'h0A, 8'h00, 16'h1, 16'h1, 0), "after Reset Channel: initialization required");
    xact(8'h00, 8'h00);
    xact(8'h0A, 8'h00);
    chk(rsp(8'h0A, 8'h00, 16'h0, 16'h0, 12) && rr[37] == 8'h10, "Reset Channel left ch 0 disabled");
    xact(8'h0A, 8'h01);
    chk(rsp(8'h0A, 8'h01, 16'h0, 16'h0, 12) && rr[37] == 8'h11, "ch 1 untouched by the reset of ch 0");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
