// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_monitor.svh -- NCSI monitor: command frames from TX_EN / TXD and response frames from CRS_DV / RXD, each after its SFD; a command without a response within the wait is published with got = 0

class ncsi_monitor extends uvm_monitor;
  `uvm_component_utils(ncsi_monitor)

  virtual ncsi_if vif;
  uvm_analysis_port #(ncsi_transaction) ap;
  ncsi_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ncsi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ncsi: virtual interface not set")
    if (!uvm_config_db#(ncsi_config)::get(this, "", "cfg", cfg))
      cfg = ncsi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] b[$], r[$];
      bit [7:0] tsh, rsh;
      int td = 0, rd = 0, cnt = 0;
      bit tsync = 0, rsync = 0, tx_p = 0, rx_p = 0, pend = 0;
      ncsi_transaction cur;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.tx_en) begin
          if (!tx_p) begin tsync = 0; b.delete(); td = 0; end
          if (!tsync) tsync = (vif.mon_cb.txd == 2'b11);
          else begin
            tsh = {vif.mon_cb.txd, tsh[7:2]};
            if (++td == 4) begin b.push_back(tsh); td = 0; end
          end
        end else if (tx_p) begin
          if (pend) publish(cur);
          if (b.size() < 64) `uvm_error("MON", $sformatf("NC-SI: command frame of %0d bytes", b.size()))
          cur = ncsi_transaction::type_id::create("t");
          cur.from_cmd(b);
          pend = 1; cnt = 0; td = 0;
        end
        if (vif.mon_cb.crs_dv) begin
          if (!rx_p) begin rsync = 0; r.delete(); rd = 0; end
          if (!rsync) rsync = (vif.mon_cb.rxd == 2'b11);
          else begin
            rsh = {vif.mon_cb.rxd, rsh[7:2]};
            if (++rd == 4) begin r.push_back(rsh); rd = 0; end
          end
        end else if (rx_p) begin
          if (!pend) `uvm_error("MON", "NC-SI: response without a command")
          else begin cur.from_rsp(r); publish(cur); pend = 0; end
          rd = 0;
        end
        if (pend && !vif.mon_cb.crs_dv && !vif.mon_cb.tx_en && ++cnt > NCSI_WAIT) begin publish(cur); pend = 0; end
        tx_p = vif.mon_cb.tx_en; rx_p = vif.mon_cb.crs_dv;
      end
    end
  endtask

  function void publish(ncsi_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
