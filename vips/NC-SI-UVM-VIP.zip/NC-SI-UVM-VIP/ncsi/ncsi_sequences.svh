// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_sequences.svh -- NCSI sequences

// Random traffic: cfg.num_items constrained-random items.
class ncsi_base_sequence extends uvm_sequence #(ncsi_transaction);
  `uvm_object_utils(ncsi_base_sequence)
  ncsi_config cfg;

  function new(string name = "ncsi_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ncsi_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ncsi_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ncsi_directed_sequence extends uvm_sequence #(ncsi_transaction);
  `uvm_object_utils(ncsi_directed_sequence)
  ncsi_config cfg;

  function new(string name = "ncsi_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ncsi_transaction item();
    item = ncsi_transaction::type_id::create("req");
  endfunction

  task send(ncsi_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ncsi_transaction t;
    // initial state, clear, every command per channel, package commands, then the faults
    t = item(); t.set(8'h15, 8'h00); send(t);
    t = item(); t.set(8'h00, 8'h00); send(t);
    t = item(); t.set(8'h15, 8'h00); send(t);
    t = item(); t.set(8'h0A, 8'h00); send(t);
    t = item(); t.set(8'h03, 8'h00); send(t);
    t = item(); t.set(8'h0A, 8'h00); send(t);
    t = item(); t.set(8'h03, 8'h01); send(t);
    t = item(); t.set(8'h00, 8'h01); send(t);
    t = item(); t.set(8'h03, 8'h01); send(t);
    t = item(); t.set(8'h04, 8'h00); send(t);
    t = item(); t.set(8'h0A, 8'h00); send(t);
    t = item(); t.set(8'h0A, 8'h01); send(t);
    t = item(); t.set(8'h01, 8'h1F); send(t);
    t = item(); t.set(8'h02, 8'h1F); send(t);
    t = item(); t.set(8'h01, 8'h00); send(t);
    t = item(); t.set(8'h00, 8'h1F); send(t);
    t = item(); t.set(8'h50, 8'h00); send(t);
    t = item(); t.set(8'h50, 8'h1F); send(t);
    for (int f = 1; f < 6; f++) begin
      t = item(); t.set(8'h03, 8'h00, f); send(t);
    end
    t = item(); t.set(8'h03, 8'h20); send(t);
    t = item(); t.set(8'h03, 8'h02); send(t);
    t = item(); t.set(8'h05, 8'h00); send(t);
    t = item(); t.set(8'h0A, 8'h00); send(t);
    t = item(); t.set(8'h00, 8'h00); send(t);
    t = item(); t.set(8'h0A, 8'h00); send(t);
  endtask
endclass
