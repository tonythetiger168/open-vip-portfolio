// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_transaction.svh -- NCSI transaction

class ncsi_transaction extends uvm_sequence_item;
  `uvm_object_utils(ncsi_transaction)

  // request (driven by the agent)
  rand bit [7:0] mcid;
  rand bit [7:0] iid;
  rand bit [7:0] cmd;
  rand bit [7:0] chan;
  bit [7:0] pl[$];
  rand bit [2:0] fault;
  // response (returned by the DUT)
  bit got;
  bit [7:0] rtype;
  bit [7:0] riid;
  bit [7:0] rchan;
  bit [15:0] rcode;
  bit [15:0] reason;
  bit [7:0] rdata[$];
  bit rok;
  // bookkeeping (not compared)
  rand bit [3:0] csel;
  rand bit [3:0] tsel;
  rand bit [4:0] fsel;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_iid { iid != 0; }

  function new(string name = "ncsi_transaction"); super.new(name); endfunction

  // command, channel and fault from the selectors (no dist inside implications)
  function void post_randomize();
    bit [7:0] cmds [16] = '{8'h00, 8'h00, 8'h01, 8'h02, 8'h03, 8'h03, 8'h04, 8'h05,
                            8'h0A, 8'h0A, 8'h15, 8'h15, 8'h50, 8'h0E, 8'h0A, 8'h03};
    cmd = cmds[csel];
    if (cmd == 8'h01 || cmd == 8'h02)
      chan = (tsel < 14) ? 8'h1F : (tsel == 14) ? 8'h00 : 8'h20;
    else
      chan = (tsel < 7) ? 8'h00 : (tsel < 13) ? 8'h01 : (tsel == 13) ? 8'h1F : (tsel == 14) ? 8'h02 : 8'h21;
    case (fsel)
      25: fault = 1;
      26: fault = 2;
      27: fault = 3;
      28: fault = (ncsi_exp_len(cmd) >= 0) ? 4 : 0;
      29, 30: fault = 5;
      default: fault = 0;
    endcase
    mk_pl();
  endfunction
  function void mk_pl();
    bit [31:0] x = seed | 1;
    int n = (ncsi_exp_len(cmd) >= 0) ? ncsi_exp_len(cmd) : 4;
    pl.delete();
    for (int i = 0; i < n; i++) begin
      x ^= x << 13; x ^= x >> 17; x ^= x << 5;
      pl.push_back(x[7:0]);
    end
  endfunction
  function void set(bit [7:0] c, bit [7:0] ch, bit [2:0] f = 0);
    cmd = c; chan = ch; fault = f;
    mk_pl();
  endfunction

  // Ethernet frame from DA to FCS (no preamble)
  function void cmd_bytes(output bit [7:0] b[$]);
    bit [31:0] c = 32'hFFFF_FFFF, s;
    int len = pl.size() + ((fault == 4) ? 4 : 0);
    b.delete();
    repeat (6) b.push_back(8'hFF);
    b.push_back(8'h02); repeat (4) b.push_back(8'h00); b.push_back(mcid);
    b.push_back(8'h88); b.push_back(8'hF8);
    b.push_back(mcid); b.push_back((fault == 3) ? 8'h02 : 8'h01); b.push_back(8'h00); b.push_back(iid);
    b.push_back(cmd); b.push_back(chan); b.push_back({4'h0, len[11:8]}); b.push_back(len[7:0]);
    repeat (8) b.push_back(8'h00);
    foreach (pl[i]) b.push_back(pl[i]);
    if (fault == 4) repeat (4) b.push_back(8'h00);
    while (b.size() % 4 != 2) b.push_back(8'h00);
    s = ncsi_csum(b, 14, b.size() - 14);
    if (fault == 5) s = 0;
    else if (fault == 1) s ^= 32'h0000_0100;
    for (int i = 3; i >= 0; i--) b.push_back(s[8*i +: 8]);
    while (b.size() < 60) b.push_back(8'h00);
    foreach (b[i]) c = ncsi_crc32(c, b[i]);
    c = ~c ^ {31'h0, fault == 2};
    for (int i = 0; i < 4; i++) b.push_back(c[8*i +: 8]);
  endfunction

  // command fields and the planted fault from a command frame
  function void from_cmd(bit [7:0] b[$]);
    bit [31:0] c = 32'hFFFF_FFFF, s, sum;
    int len, e, p4;
    foreach (b[i]) c = ncsi_crc32(c, b[i]);
    mcid = b[14]; iid = b[17]; cmd = b[18]; chan = b[19];
    len = {b[20][3:0], b[21]};
    e = ncsi_exp_len(cmd);
    p4 = (len + 3) / 4 * 4;
    pl.delete();
    for (int i = 0; i < ((e >= 0 && len != e) ? e : len); i++) pl.push_back(b[30 + i]);
    s = ncsi_csum(b, 14, 16 + p4);
    sum = {b[30 + p4], b[31 + p4], b[32 + p4], b[33 + p4]};
    fault = (c != 32'hDEBB_20E3) ? 2 : (b[15] != 8'h01) ? 3 : (e >= 0 && len != e) ? 4 : (sum == 0) ? 5 : (sum != s) ? 1 : 0;
  endfunction

  // response fields from a response frame
  function void from_rsp(bit [7:0] r[$]);
    bit [31:0] c = 32'hFFFF_FFFF, s;
    int len, p4;
    got = 1; rok = 0; rdata.delete();
    if (r.size() < 64) return;
    foreach (r[i]) c = ncsi_crc32(c, r[i]);
    riid = r[17]; rtype = r[18]; rchan = r[19];
    len = {r[20][3:0], r[21]};
    rcode = {r[30], r[31]}; reason = {r[32], r[33]};
    for (int i = 4; i < len; i++) rdata.push_back(r[30 + i]);
    p4 = (len + 3) / 4 * 4;
    s = ncsi_csum(r, 14, 16 + p4);
    rok = (c == 32'hDEBB_20E3) && ({r[30 + p4], r[31 + p4], r[32 + p4], r[33 + p4]} == s) && r[15] == 8'h01 &&
          r[14] == mcid && {r[12], r[13]} == 16'h88F8 && r.size() == ((34 + p4 < 60) ? 60 : 34 + p4) + 4;
  endfunction

  function void do_copy(uvm_object rhs);
    ncsi_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mcid = rhs_.mcid;
    iid = rhs_.iid;
    cmd = rhs_.cmd;
    chan = rhs_.chan;
    pl = rhs_.pl;
    fault = rhs_.fault;
    got = rhs_.got;
    rtype = rhs_.rtype;
    riid = rhs_.riid;
    rchan = rhs_.rchan;
    rcode = rhs_.rcode;
    reason = rhs_.reason;
    rdata = rhs_.rdata;
    rok = rhs_.rok;
    csel = rhs_.csel;
    tsel = rhs_.tsel;
    fsel = rhs_.fsel;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ncsi_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mcid != rhs_.mcid) return 0;
    if (iid != rhs_.iid) return 0;
    if (cmd != rhs_.cmd) return 0;
    if (chan != rhs_.chan) return 0;
    if (pl.size() != rhs_.pl.size()) return 0;
    foreach (pl[i]) if (pl[i] != rhs_.pl[i]) return 0;
    if (fault != rhs_.fault) return 0;
    if (got != rhs_.got) return 0;
    if (rtype != rhs_.rtype) return 0;
    if (riid != rhs_.riid) return 0;
    if (rchan != rhs_.rchan) return 0;
    if (rcode != rhs_.rcode) return 0;
    if (reason != rhs_.reason) return 0;
    if (rdata.size() != rhs_.rdata.size()) return 0;
    foreach (rdata[i]) if (rdata[i] != rhs_.rdata[i]) return 0;
    if (rok != rhs_.rok) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ncsi_transaction rhs_);
    if (mcid != rhs_.mcid) return 0;
    if (iid != rhs_.iid) return 0;
    if (cmd != rhs_.cmd) return 0;
    if (chan != rhs_.chan) return 0;
    if (pl.size() != rhs_.pl.size()) return 0;
    foreach (pl[i]) if (pl[i] != rhs_.pl[i]) return 0;
    if (fault != rhs_.fault) return 0;
    return 1;
  endfunction

  function string qstr_pl();
    string s = $sformatf("[%0d]{", pl.size());
    foreach (pl[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", pl[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rdata();
    string s = $sformatf("[%0d]{", rdata.size());
    foreach (rdata[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rdata[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("NCSI{tag=%0d mcid=0x%0h iid=0x%0h cmd=0x%0h chan=0x%0h pl=%s fault=0x%0h got=0x%0h rtype=0x%0h riid=0x%0h rchan=0x%0h rcode=0x%0h reason=0x%0h rdata=%s rok=0x%0h}", tag, mcid, iid, cmd, chan, qstr_pl(), fault, got, rtype, riid, rchan, rcode, reason, qstr_rdata(), rok);
  endfunction
endclass
