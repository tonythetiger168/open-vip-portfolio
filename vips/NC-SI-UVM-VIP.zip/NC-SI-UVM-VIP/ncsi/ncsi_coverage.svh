// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_coverage.svh -- NCSI functional coverage

class ncsi_coverage extends uvm_subscriber #(ncsi_transaction);
  `uvm_component_utils(ncsi_coverage)
  ncsi_config cfg;
  ncsi_transaction tr;

  covergroup ncsi_cg;
    cp_cmd : coverpoint tr.cmd { bins clear = {8'h00}; bins sel = {8'h01}; bins desel = {8'h02}; bins enable = {8'h03};
                                 bins disable_ch = {8'h04}; bins reset_ch = {8'h05}; bins link = {8'h0A}; bins version = {8'h15};
                                 bins unsupported = {8'h50, 8'h0E}; }
    cp_rsp : coverpoint (!tr.got ? 4 : tr.rcode == 0 ? 0 : tr.rcode == 3 ? 3 : tr.reason == 1 ? 1 : 2) {
      bins completed = {0}; bins init_required = {1}; bins param_invalid = {2}; bins unsupported = {3}; bins dropped = {4}; }
    cp_fault : coverpoint tr.fault { bins none = {0}; bins checksum = {1}; bins fcs = {2}; bins revision = {3}; bins length = {4}; bins zero_sum = {5}; }
    cp_target : coverpoint tr.chan { bins ch0 = {8'h00}; bins ch1 = {8'h01}; bins pkg = {8'h1F}; bins absent = {8'h02, 8'h20, 8'h21}; }
    cp_link : coverpoint (tr.rdata.size() == 12 ? tr.rdata[3] : 8'h00) iff (tr.cmd == 8'h0A && tr.rcode == 0 && tr.got) { bins up = {8'h11}; bins down = {8'h10}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ncsi_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ncsi_config)::get(this, "", "cfg", cfg))
      cfg = ncsi_config::type_id::create("cfg");
  endfunction

  function void write(ncsi_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ncsi_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("NCSI coverage: %0.1f%%", ncsi_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
