// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_pkg.sv -- NCSI UVM VIP package

package ncsi_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ncsi_defs_pkg::*;
  export ncsi_defs_pkg::*;

  `include "ncsi_transaction.svh"
  `include "ncsi_config.svh"
  `include "ncsi_sequencer.svh"
  `include "ncsi_driver.svh"
  `include "ncsi_monitor.svh"
  `include "ncsi_agent.svh"
  `include "ncsi_sequences.svh"
  `include "ncsi_checker.svh"
  `include "ncsi_coverage.svh"
endpackage
