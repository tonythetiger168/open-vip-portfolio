// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_driver.svh -- NCSI driver: one control packet per item: preamble, SFD and frame on TX_EN / TXD two bits a clock, then the response taken from CRS_DV / RXD (or none within the wait)

class ncsi_driver extends uvm_driver #(ncsi_transaction);
  `uvm_component_utils(ncsi_driver)

  uvm_analysis_port #(ncsi_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ncsi_if vif;
  ncsi_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ncsi_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ncsi: virtual interface not set")
    if (!uvm_config_db#(ncsi_config)::get(this, "", "cfg", cfg))
      cfg = ncsi_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ncsi_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.tx_en <= 1'b0;
    vif.drv_cb.txd   <= 2'b00;
  endtask

  task drive_item(ncsi_transaction t);
    bit [7:0] b[$], r[$];
    bit [7:0] sh;
    int k = 0, d = 0;
    bit sync = 0;
    t.cmd_bytes(b);
    b.push_front(8'hD5);
    repeat (7) b.push_front(8'h55);
    foreach (b[i]) for (int j = 0; j < 4; j++) begin
      vif.drv_cb.tx_en <= 1'b1; vif.drv_cb.txd <= b[i][2*j +: 2];
      @(vif.drv_cb);
    end
    vif.drv_cb.tx_en <= 1'b0; vif.drv_cb.txd <= 2'b00;
    while (k < NCSI_WAIT && !vif.drv_cb.crs_dv) begin @(vif.drv_cb); k++; end
    if (vif.drv_cb.crs_dv) begin
      while (vif.drv_cb.crs_dv) begin
        if (!sync) sync = (vif.drv_cb.rxd == 2'b11);
        else begin
          sh = {vif.drv_cb.rxd, sh[7:2]};
          if (++d == 4) begin r.push_back(sh); d = 0; end
        end
        @(vif.drv_cb);
      end
      t.from_rsp(r);
    end
    repeat (4) @(vif.drv_cb);
  endtask

endclass
