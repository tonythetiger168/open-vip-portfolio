// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_defs.sv -- NCSI shared type definitions

package ncsi_defs_pkg;

  typedef enum bit [1:0] {NCSI_OK, NCSI_ERR} ncsi_status_e;

  localparam int NCSI_WAIT = 200;    // REF_CLKs the controller waits for a response
  function automatic bit [31:0] ncsi_crc32(bit [31:0] c, bit [7:0] b);
    c ^= {24'h0, b};
    for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    return c;
  endfunction
  // payload length the command takes (-1: not supported by the model)
  function automatic int ncsi_exp_len(bit [7:0] cmd);
    case (cmd)
      8'h00, 8'h02, 8'h03, 8'h0A, 8'h15: return 0;
      8'h01, 8'h04, 8'h05: return 4;
      default: return -1;
    endcase
  endfunction
  // Get Version ID response data
  function automatic bit [7:0] ncsi_ver_byte(int i);
    string name = "OPENVIP-NCSI";
    case (i)
      0, 1: return 8'hF1;
      2: return 8'hF0;
      20: return 8'h01; 21: return 8'h02; 22: return 8'h03; 23: return 8'h04;
      24: return 8'h12; 25: return 8'h34; 26: return 8'hAB; 27: return 8'hCD;
      28: return 8'h00; 29: return 8'h01; 30: return 8'hAB; 31: return 8'hCD;
      39: return 8'h2A;
      default: return (i >= 8 && i < 20) ? name[i - 8] : 8'h00;
    endcase
  endfunction
  // two's complement of the 16-bit big-endian sum of b[from +: n]
  function automatic bit [31:0] ncsi_csum(bit [7:0] b[$], int from, int n);
    bit [31:0] s = 0;
    for (int i = 0; i < n; i += 2) s += {16'h0, b[from + i], (i + 1 < n) ? b[from + i + 1] : 8'h00};
    return -s;
  endfunction

endpackage
