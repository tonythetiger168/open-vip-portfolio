// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ncsi_compliance_checker.sv -- NCSI concurrent assertion checks (bindable)

module ncsi_compliance_checker
  (input logic clk, input logic rst_n, input logic tx_en, input logic [1:0] txd, input logic crs_dv, input logic [1:0] rxd);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({tx_en, crs_dv}))
    else $error("NC-SI: X on TX_EN / CRS_DV");
  assert property (@(posedge clk) disable iff (!rst_n) crs_dv |-> !$isunknown(rxd))
    else $error("NC-SI: X on RXD while CRS_DV");
  // the controller never answers over a command
  assert property (@(posedge clk) disable iff (!rst_n) !(tx_en && $rose(crs_dv)))
    else $error("NC-SI: response started during a command");
  cover property (@(posedge clk) disable iff (!rst_n) $fell(crs_dv));
  cover property (@(posedge clk) disable iff (!rst_n) $fell(tx_en) ##1 (!crs_dv)[*200]);
endmodule
