// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// common_pkg.sv
// Common definitions and base classes for multi-protocol UVM VIP

package common_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  typedef enum bit [3:0] {
    PROTOCOL_SATA         = 4'd0,
    PROTOCOL_NVME         = 4'd1,
    PROTOCOL_JTAG         = 4'd2,
    PROTOCOL_BLUETOOTH5   = 4'd3,
    PROTOCOL_DISPLAYPORT2 = 4'd4,
    PROTOCOL_CAN          = 4'd5,
    PROTOCOL_LIN          = 4'd6,
    PROTOCOL_FLEXRAY      = 4'd7,
    PROTOCOL_ETH_AVB_TSN  = 4'd8
  } protocol_e;

  typedef enum bit [1:0] {
    TX_OK      = 2'b00,
    TX_ERROR   = 2'b01,
    TX_TIMEOUT = 2'b10,
    TX_ABORT   = 2'b11
  } tx_status_e;

  class base_tx extends uvm_sequence_item;
    `uvm_object_utils(base_tx)
    rand protocol_e    protocol;
    rand tx_status_e   status;
    rand bit [63:0]    timestamp;
    rand bit [31:0]    tx_id;
    function new(string name = "base_tx");
      super.new(name);
    endfunction
    virtual function string convert2string();
      return $sformatf("protocol=%s status=%s timestamp=0x%0x tx_id=0x%0x",
        protocol.name(), status.name(), timestamp, tx_id);
    endfunction
  endclass

  // Abstract base: not registered with the factory (virtual classes cannot
  // be instantiated); concrete checkers register themselves.
  virtual class protocol_checker_base extends uvm_component;
    int error_count = 0;
    int warning_count = 0;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    pure virtual task run_phase(uvm_phase phase);
    pure virtual function void report_phase(uvm_phase phase);
    virtual function void check_protocol_error(string msg);
      error_count++;
      `uvm_error("PROTOCOL_CHK", $sformatf("[ERROR] %s (total=%0d)", msg, error_count))
    endfunction
    virtual function void check_protocol_warning(string msg);
      warning_count++;
      `uvm_warning("PROTOCOL_CHK", $sformatf("[WARN] %s (total=%0d)", msg, warning_count))
    endfunction
  endclass

  // Abstract base: not registered with the factory (virtual classes cannot
  // be instantiated); concrete collectors register themselves.
  virtual class coverage_collector_base extends uvm_component;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    pure virtual function void sample_coverage(uvm_sequence_item tx);
    pure virtual function void report_phase(uvm_phase phase);
  endclass

  class vip_config extends uvm_object;
    `uvm_object_utils(vip_config)
    bit enable_checker  = 1;
    bit enable_coverage = 1;
    bit enable_scoreboard = 1;
    int num_transactions = 1000;
    int seed = 0;
    function new(string name = "vip_config");
      super.new(name);
    endfunction
  endclass
endpackage
