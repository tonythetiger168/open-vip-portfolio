// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
`ifndef NVME_COMPLIANCE_CHECKER_SV
`define NVME_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// Module form of the tiered NVMe compliance checker (bindable from any tb).
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=NVMe specific
module nvme_compliance_checker (nvme_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[5], l4_fail[5];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

// ===== L1: Basic Compliance (4 SVAs) =====
  property p_nvme_tlp_type; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tlp_type inside {4'b0000,4'b0001,4'b0010,4'b0100,4'b0101,4'b0110,4'b1000,4'b1010,4'b1100,4'b1101,4'b1110}; endproperty
  assert_p_nvme_tlp_type: assert property(p_nvme_tlp_type) l1_pass[0]++; else begin `uvm_warning("NVME_L1", "TLP type failed"); l1_fail[0]++; end
  cover_p_nvme_tlp_type: cover property(p_nvme_tlp_type);
  property p_nvme_tag; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tag <= 10'h3FF; endproperty
  assert_p_nvme_tag: assert property(p_nvme_tag) l1_pass[1]++; else begin `uvm_warning("NVME_L1", "Tag 0-1023 failed"); l1_fail[1]++; end
  cover_p_nvme_tag: cover property(p_nvme_tag);
  property p_nvme_tc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tc inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_nvme_tc: assert property(p_nvme_tc) l1_pass[2]++; else begin `uvm_warning("NVME_L1", "TC 0-7 failed"); l1_fail[2]++; end
  cover_p_nvme_tc: cover property(p_nvme_tc);
  property p_nvme_length; @(posedge vif.clk) disable iff (!vif.rst_n) vif.length > 11'd0; endproperty
  assert_p_nvme_length: assert property(p_nvme_length) l1_pass[3]++; else begin `uvm_warning("NVME_L1", "Length > 0 failed"); l1_fail[3]++; end
  cover_p_nvme_length: cover property(p_nvme_length);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_nvme_sq_tail; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sq_tail <= 16'hFFFF; endproperty
  assert_p_nvme_sq_tail: assert property(p_nvme_sq_tail) l2_pass[0]++; else begin `uvm_warning("NVME_L2", "SQ tail failed"); l2_fail[0]++; end
  cover_p_nvme_sq_tail: cover property(p_nvme_sq_tail);
  property p_nvme_cq_head; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cq_head <= 16'hFFFF; endproperty
  assert_p_nvme_cq_head: assert property(p_nvme_cq_head) l2_pass[1]++; else begin `uvm_warning("NVME_L2", "CQ head failed"); l2_fail[1]++; end
  cover_p_nvme_cq_head: cover property(p_nvme_cq_head);
  property p_nvme_status; @(posedge vif.clk) disable iff (!vif.rst_n) vif.status_code <= 8'hFF; endproperty
  assert_p_nvme_status: assert property(p_nvme_status) l2_pass[2]++; else begin `uvm_warning("NVME_L2", "Status code failed"); l2_fail[2]++; end
  cover_p_nvme_status: cover property(p_nvme_status);
  property p_nvme_tlp_ready; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tlp_valid == 1 |-> ##[1:16] vif.tlp_ready == 1; endproperty
  assert_p_nvme_tlp_ready: assert property(p_nvme_tlp_ready) l2_pass[3]++; else begin `uvm_warning("NVME_L2", "TLP handshake failed"); l2_fail[3]++; end
  cover_p_nvme_tlp_ready: cover property(p_nvme_tlp_ready);
  property p_nvme_irq; @(posedge vif.clk) disable iff (!vif.rst_n) vif.irq_assert == 1 |-> vif.cq_head != vif.sq_tail; endproperty
  assert_p_nvme_irq: assert property(p_nvme_irq) l2_pass[4]++; else begin `uvm_warning("NVME_L2", "IRQ after completion failed"); l2_fail[4]++; end
  cover_p_nvme_irq: cover property(p_nvme_irq);
  property p_nvme_admin_q; @(posedge vif.clk) disable iff (!vif.rst_n) vif.admin_q == 1 |-> vif.qid == 16'h0000; endproperty
  assert_p_nvme_admin_q: assert property(p_nvme_admin_q) l2_pass[5]++; else begin `uvm_warning("NVME_L2", "Admin Q failed"); l2_fail[5]++; end
  cover_p_nvme_admin_q: cover property(p_nvme_admin_q);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_nvme_cq_valid; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tlp_valid == 1 |-> ##[1:64] vif.irq_assert == 1; endproperty
  assert_p_nvme_cq_valid: assert property(p_nvme_cq_valid) l3_pass[0]++; else begin `uvm_warning("NVME_L3", "CQ valid failed"); l3_fail[0]++; end
  cover_p_nvme_cq_valid: cover property(p_nvme_cq_valid);
  property p_nvme_addr_align; @(posedge vif.clk) disable iff (!vif.rst_n) vif.addr[1:0] == 2'b00; endproperty
  assert_p_nvme_addr_align: assert property(p_nvme_addr_align) l3_pass[1]++; else begin `uvm_warning("NVME_L3", "Addr aligned failed"); l3_fail[1]++; end
  cover_p_nvme_addr_align: cover property(p_nvme_addr_align);
  property p_nvme_cmd_set; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_set inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_nvme_cmd_set: assert property(p_nvme_cmd_set) l3_pass[2]++; else begin `uvm_warning("NVME_L3", "Cmd set failed"); l3_fail[2]++; end
  cover_p_nvme_cmd_set: cover property(p_nvme_cmd_set);
  property p_nvme_sgl; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_set == 3'b001 |-> vif.addr != 64'h0; endproperty
  assert_p_nvme_sgl: assert property(p_nvme_sgl) l3_pass[3]++; else begin `uvm_warning("NVME_L3", "SGL valid failed"); l3_fail[3]++; end
  cover_p_nvme_sgl: cover property(p_nvme_sgl);

  
  // ---------------- L4: NVMe protocol-specific rules (5) ----------------
  // L4-1: SQ tail doorbell advances in single-entry steps
  property p_nvme_l4_sq_step;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.sq_tail != $past(vif.sq_tail)) |-> (vif.sq_tail == $past(vif.sq_tail) + 16'd1);
  endproperty
  assert_p_nvme_l4_sq_step: assert property(p_nvme_l4_sq_step) l4_pass[0]++;
    else begin `uvm_warning("NVME_L4", "SQ tail doorbell skipped entries"); l4_fail[0]++; end
  cover_p_nvme_l4_sq_step: cover property(p_nvme_l4_sq_step);

  // L4-2: CQ head only advances after a completion (irq or error status)
  property p_nvme_l4_cq_after_cpl;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.cq_head != $past(vif.cq_head)) |-> $past(vif.irq_assert || vif.status_code != 8'h00);
  endproperty
  assert_p_nvme_l4_cq_after_cpl: assert property(p_nvme_l4_cq_after_cpl) l4_pass[1]++;
    else begin `uvm_warning("NVME_L4", "CQ head advanced without completion"); l4_fail[1]++; end
  cover_p_nvme_l4_cq_after_cpl: cover property(p_nvme_l4_cq_after_cpl);

  // L4-3: TLP payload must be known on accepted beats
  property p_nvme_l4_tlp_known;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.tlp_valid && vif.tlp_ready) |-> !$isunknown(vif.tlp_data);
  endproperty
  assert_p_nvme_l4_tlp_known: assert property(p_nvme_l4_tlp_known) l4_pass[2]++;
    else begin `uvm_warning("NVME_L4", "X on accepted TLP data"); l4_fail[2]++; end
  cover_p_nvme_l4_tlp_known: cover property(p_nvme_l4_tlp_known);

  // L4-4: no TLP traffic while the controller is in reset
  property p_nvme_l4_rst_no_tlp;
    @(posedge vif.clk) !vif.rst_n |-> !vif.tlp_valid;
  endproperty
  assert_p_nvme_l4_rst_no_tlp: assert property(p_nvme_l4_rst_no_tlp) l4_pass[3]++;
    else begin `uvm_warning("NVME_L4", "TLP valid during reset"); l4_fail[3]++; end
  cover_p_nvme_l4_rst_no_tlp: cover property(p_nvme_l4_rst_no_tlp);

  // L4-5: admin queue submissions must use a valid NVM command set encoding
  property p_nvme_l4_admin_cmdset;
    @(posedge vif.clk) disable iff (!vif.rst_n)
      (vif.admin_q && vif.qid == 16'h0000) |-> vif.cmd_set inside {3'b000, 3'b001};
  endproperty
  assert_p_nvme_l4_admin_cmdset: assert property(p_nvme_l4_admin_cmdset) l4_pass[4]++;
    else begin `uvm_warning("NVME_L4", "admin queue with invalid command set"); l4_fail[4]++; end
  cover_p_nvme_l4_admin_cmdset: cover property(p_nvme_l4_admin_cmdset);

  function void report_sva();
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0;
    int l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0)/(l1_total+l2_total+l3_total+l4_total);
    `uvm_info("NVME_RPT", "=== NVMe Tiered SVA Report ===", UVM_LOW)
    `uvm_info("NVME_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("NVME_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("NVME_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("NVME_RPT", $sformatf("  L4 NVMe Specific:     %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("NVME_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%%", total_cov), UVM_LOW)
  endfunction

  final report_sva();

endmodule
`endif
