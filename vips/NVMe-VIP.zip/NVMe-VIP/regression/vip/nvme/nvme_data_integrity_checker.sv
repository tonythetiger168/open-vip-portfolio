// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// nvme Data Integrity Checker (module form, bindable from any tb)
`ifndef NVME_DATA_INTEGRITY_CHECKER_SV
`define NVME_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module nvme_data_integrity_checker (nvme_if vif);
  property p_nvme_sq_tail; @(posedge vif.clk) disable iff (!vif.rst_n) vif.sq_tail <= 16'hFFFF; endproperty
  assert_p_nvme_sq_tail: assert property(p_nvme_sq_tail) else `uvm_warning("NVME", "SQ tail valid failed");
  cover_p_nvme_sq_tail: cover property(p_nvme_sq_tail);
  property p_nvme_cq_head; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cq_head <= 16'hFFFF; endproperty
  assert_p_nvme_cq_head: assert property(p_nvme_cq_head) else `uvm_warning("NVME", "CQ head valid failed");
  cover_p_nvme_cq_head: cover property(p_nvme_cq_head);
  property p_nvme_status; @(posedge vif.clk) disable iff (!vif.rst_n) vif.status_code <= 8'hFF; endproperty
  assert_p_nvme_status: assert property(p_nvme_status) else `uvm_warning("NVME", "Status code valid failed");
  cover_p_nvme_status: cover property(p_nvme_status);
endmodule
`endif