// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// nvme Timing Performance Checker (module form, bindable from any tb)
`ifndef NVME_TIMING_CHECKER_SV
`define NVME_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module nvme_timing_performance_checker (nvme_if vif);
  property p_nvme_tlp_ready; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tlp_valid == 1 |-> ##[1:16] vif.tlp_ready == 1; endproperty
  assert_p_nvme_tlp_ready: assert property(p_nvme_tlp_ready) else `uvm_warning("NVME", "TLP handshake failed");
  cover_p_nvme_tlp_ready: cover property(p_nvme_tlp_ready);
  property p_nvme_irq; @(posedge vif.clk) disable iff (!vif.rst_n) vif.irq_assert == 1 |-> vif.cq_head > vif.sq_tail || vif.cq_head < vif.sq_tail; endproperty
  assert_p_nvme_irq: assert property(p_nvme_irq) else `uvm_warning("NVME", "IRQ after completion failed");
  cover_p_nvme_irq: cover property(p_nvme_irq);
endmodule
`endif
