// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// nvme Protocol Compliance Checker (module form, bindable from any tb)
`ifndef NVME_PROTOCOL_CHECKER_SV
`define NVME_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module nvme_protocol_compliance_checker (nvme_if vif);
  property p_nvme_tlp_type; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tlp_type inside {4'b0000,4'b0001,4'b0010,4'b0100,4'b0101,4'b0110,4'b1000,4'b1010,4'b1100,4'b1101,4'b1110}; endproperty
  assert_p_nvme_tlp_type: assert property(p_nvme_tlp_type) else `uvm_warning("NVME", "TLP type valid failed");
  cover_p_nvme_tlp_type: cover property(p_nvme_tlp_type);
  property p_nvme_tag; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tag <= 10'h3FF; endproperty
  assert_p_nvme_tag: assert property(p_nvme_tag) else `uvm_warning("NVME", "Tag range failed");
  cover_p_nvme_tag: cover property(p_nvme_tag);
  property p_nvme_tc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tc inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_nvme_tc: assert property(p_nvme_tc) else `uvm_warning("NVME", "TC valid failed");
  cover_p_nvme_tc: cover property(p_nvme_tc);
  property p_nvme_length; @(posedge vif.clk) disable iff (!vif.rst_n) vif.length > 11'd0; endproperty
  assert_p_nvme_length: assert property(p_nvme_length) else `uvm_warning("NVME", "Length > 0 failed");
  cover_p_nvme_length: cover property(p_nvme_length);
  property p_nvme_admin; @(posedge vif.clk) disable iff (!vif.rst_n) vif.admin_q == 1 |-> vif.qid == 16'h0000; endproperty
  assert_p_nvme_admin: assert property(p_nvme_admin) else `uvm_warning("NVME", "Admin Q ID failed");
  cover_p_nvme_admin: cover property(p_nvme_admin);
endmodule
`endif