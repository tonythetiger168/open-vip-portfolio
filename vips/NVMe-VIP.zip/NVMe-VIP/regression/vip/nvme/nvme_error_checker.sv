// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// nvme Error Handling Checker (module form, bindable from any tb)
`ifndef NVME_ERROR_CHECKER_SV
`define NVME_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module nvme_error_handling_checker (nvme_if vif);
  property p_nvme_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.tlp_valid == 1 |-> !$isunknown(vif.tlp_data); endproperty
  assert_p_nvme_no_x: assert property(p_nvme_no_x) else `uvm_warning("NVME", "No X when valid failed");
  cover_p_nvme_no_x: cover property(p_nvme_no_x);
  property p_nvme_addr_align; @(posedge vif.clk) disable iff (!vif.rst_n) vif.addr[1:0] == 2'b00; endproperty
  assert_p_nvme_addr_align: assert property(p_nvme_addr_align) else `uvm_warning("NVME", "Address aligned failed");
  cover_p_nvme_addr_align: cover property(p_nvme_addr_align);
  property p_nvme_cmd_set; @(posedge vif.clk) disable iff (!vif.rst_n) vif.cmd_set inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_nvme_cmd_set: assert property(p_nvme_cmd_set) else `uvm_warning("NVME", "Cmd set valid failed");
  cover_p_nvme_cmd_set: cover property(p_nvme_cmd_set);
endmodule
`endif