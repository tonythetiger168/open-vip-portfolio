// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// nvme_tests.sv -- NVMe UVM tests on the controller model in tb/top_tb.sv.
// Commands are built field by field (no randomize()), so the test runs on
// simulators without a constraint solver.

package nvme_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import nvme_pkg::*;
  import env_pkg::*;

  // Admin and I/O commands on valid queues (1..7) and invalid ones (> 7),
  // reads / writes / compares of 1..256 blocks, other NVM and admin opcodes.
  class nvme_cmd_sequence extends uvm_sequence #(nvme_transaction);
    `uvm_object_utils(nvme_cmd_sequence)
    int unsigned n = 60;
    bit          directed = 1;

    function new(string name = "nvme_cmd_sequence"); super.new(name); endfunction

    function nvme_transaction make(nvme_transaction::nvme_opcode_e op, bit [15:0] qid, bit [15:0] nlb);
      nvme_transaction tx = nvme_transaction::type_id::create("tx");
      tx.opcode = op; tx.qid = qid; tx.admin_cmd = (qid == 0); tx.nlb = nlb;
      tx.nsid = 16'(1 + $urandom_range(31)); tx.cid = 16'($urandom);
      tx.slba = {40'($urandom), 12'h000}; tx.prp1 = {40'($urandom), 12'h000}; tx.prp2 = 0;
      tx.fuse = 0; tx.cmd_set = (op == nvme_transaction::CMD_WRITE) ? 3'b000 : 3'b001;
      tx.data_len = (op inside {nvme_transaction::CMD_WRITE, nvme_transaction::CMD_READ,
                                nvme_transaction::CMD_COMPARE}) ? (nlb + 1) * 512 : 0;
      tx.status = 0; tx.with_error = (qid > 7);
      return tx;
    endfunction

    task send(nvme_transaction tx);
      start_item(tx);
      finish_item(tx);
    endtask

    task body();
      nvme_transaction::nvme_opcode_e io_ops[$] = '{nvme_transaction::CMD_WRITE, nvme_transaction::CMD_READ,
        nvme_transaction::CMD_COMPARE, nvme_transaction::CMD_FLUSH, nvme_transaction::CMD_WRITE_ZEROES,
        nvme_transaction::CMD_DATASET_MGMT, nvme_transaction::CMD_VERIFY, nvme_transaction::CMD_COPY};
      nvme_transaction::nvme_opcode_e adm_ops[$] = '{nvme_transaction::CMD_FORMAT_NVM,
        nvme_transaction::CMD_SECURITY_SND, nvme_transaction::CMD_SECURITY_RCV, nvme_transaction::CMD_SANITIZE};
      if (directed) begin
        foreach (adm_ops[i]) send(make(adm_ops[i], 0, 0));            // admin queue
        foreach (io_ops[i]) send(make(io_ops[i], 1, 0));              // single block
        send(make(nvme_transaction::CMD_WRITE, 7, 255));              // 256 blocks, last valid queue
        send(make(nvme_transaction::CMD_READ, 7, 255));
        send(make(nvme_transaction::CMD_WRITE, 8, 3));                // first invalid queue
        send(make(nvme_transaction::CMD_READ, 16'hFFFF, 0));          // largest invalid QID
      end
      repeat (n) begin
        bit [15:0] q = ($urandom_range(9) == 0) ? 16'(8 + $urandom_range(100)) : 16'($urandom_range(7));
        nvme_transaction::nvme_opcode_e op = (q == 0) ? adm_ops[$urandom_range(adm_ops.size() - 1)]
                                                      : io_ops[$urandom_range(io_ops.size() - 1)];
        send(make(op, q, 16'($urandom_range(255))));
      end
    endtask
  endclass

  `uvm_analysis_imp_decl(_nvme_cpl)

  // Completion check: the controller completes every command, with Invalid
  // Queue Identifier (status 01h) on a queue above 7 and success otherwise.
  class nvme_cpl_checker extends uvm_subscriber #(nvme_transaction);
    `uvm_component_utils(nvme_cpl_checker)
    int unsigned n_checks, n_ok, n_err;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void write(nvme_transaction t);
      bit [7:0] exp = (t.qid > 7) ? 8'h01 : 8'h00;
      n_checks++;
      if (t.status !== exp)
        `uvm_error("NVME_CPL", $sformatf("%s: status %02h, expected %02h", t.convert2string(), t.status, exp))
      else if (exp == 0) n_ok++;
      else n_err++;
    endfunction
  endclass

  class nvme_base_test extends uvm_test;
    `uvm_component_utils(nvme_base_test)
    nvme_env         env;
    nvme_cpl_checker cpl;
    int unsigned     n = 60;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = nvme_env::type_id::create("env", this);
      cpl = nvme_cpl_checker::type_id::create("cpl", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      env.agt.drv.drv_ap.connect(cpl.analysis_export);
    endfunction

    virtual task stimulus();
      nvme_cmd_sequence seq = nvme_cmd_sequence::type_id::create("seq");
      seq.n = n;
      seq.start(env.agt.sqr);
    endtask

    task run_phase(uvm_phase phase);
      phase.raise_objection(this);
      stimulus();
      #(500ns);
      phase.drop_objection(this);
    endtask

    function void report_phase(uvm_phase phase);
      uvm_report_server rs = uvm_report_server::get_server();
      int unsigned checks = cpl.n_checks + env.sb.n_matches;
      super.report_phase(phase);
      `uvm_info("TEST", $sformatf("%0d completions checked (%0d success, %0d invalid queue), %0d commands matched end to end",
                                  cpl.n_checks, cpl.n_ok, cpl.n_err, env.sb.n_matches), UVM_LOW)
      if (cpl.n_checks == 0 || cpl.n_ok == 0 || cpl.n_err == 0)
        `uvm_error("TEST", "the completions checked do not include both success and error")
      else if (rs.get_severity_count(UVM_ERROR) == 0 && rs.get_severity_count(UVM_FATAL) == 0)
        $display("SB_PASS checks=%0d", checks);
    endfunction
  endclass

  // directed corner cases, then random commands; run by tools/run_uvm_tests.py
  class nvme_func_test extends nvme_base_test;
    `uvm_component_utils(nvme_func_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
  endclass
endpackage
