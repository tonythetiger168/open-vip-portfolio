// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (NVMe admin submission/completion)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened nvme_controller_model DUT.
// Doorbell (sq_tail) -> TLP pulse with payload -> completion + IRQ;
// cq_head == sq_tail clears the IRQ; qid > 7 sets error status.
// Prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic vif_clk = 1'b0;
  logic vif_rst_n = 1'b0;
  wire  [127:0] vif_tlp_data;
  wire  vif_tlp_valid;
  logic vif_tlp_ready = 1'b1;
  wire  [3:0]   vif_tlp_type;
  wire  [15:0]  vif_requester_id;
  wire  [15:0]  vif_completer_id;
  wire  [9:0]   vif_tag;
  wire  [2:0]   vif_tc;
  wire  [2:0]   vif_attr;
  wire  [10:0]  vif_length;
  wire  [63:0]  vif_addr;
  logic [511:0] vif_cq_entry = '0;
  wire  [511:0] vif_sq_entry;
  logic [15:0]  vif_cq_head = 16'd0;
  logic [15:0]  vif_sq_tail = 16'd0;
  logic [15:0]  vif_qid = 16'd0;
  logic vif_admin_q = 1'b0;
  logic [2:0]   vif_cmd_set = 3'd0;
  wire  [7:0]   vif_status_code;
  wire  vif_irq_assert;

  always #5 vif_clk = ~vif_clk;

  nvme_controller_model u_dut (
    .vif_clk(vif_clk), .vif_rst_n(vif_rst_n),
    .vif_tlp_data(vif_tlp_data), .vif_tlp_valid(vif_tlp_valid),
    .vif_tlp_ready(vif_tlp_ready), .vif_tlp_type(vif_tlp_type),
    .vif_requester_id(vif_requester_id), .vif_completer_id(vif_completer_id),
    .vif_tag(vif_tag), .vif_tc(vif_tc), .vif_attr(vif_attr),
    .vif_length(vif_length), .vif_addr(vif_addr),
    .vif_cq_entry(vif_cq_entry), .vif_sq_entry(vif_sq_entry),
    .vif_cq_head(vif_cq_head), .vif_sq_tail(vif_sq_tail),
    .vif_qid(vif_qid), .vif_admin_q(vif_admin_q), .vif_cmd_set(vif_cmd_set),
    .vif_status_code(vif_status_code), .vif_irq_assert(vif_irq_assert)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge vif_clk); #1;
  endtask

  bit seen_tlp, seen_irq;

  initial begin
    repeat (8) step();
    chk(vif_tlp_valid === 1'b0, "tlp_valid quiet out of reset");
    chk(vif_irq_assert === 1'b0, "irq quiet out of reset");
    chk(vif_status_code === 8'h00, "status clean out of reset");
    chk(vif_requester_id === 16'h0100, "requester id initialised");
    @(negedge vif_clk); vif_rst_n = 1'b1;
    repeat (4) step();

    repeat (6) begin
      step();
      chk(vif_tlp_valid === 1'b0, "no TLP while idle");
      chk(vif_irq_assert === 1'b0, "no IRQ while idle");
    end

    // ---- admin command 1: doorbell sq_tail 0 -> 1 ----
    seen_tlp = 0; seen_irq = 0;
    @(negedge vif_clk);
    vif_admin_q = 1'b1; vif_qid = 16'd0; vif_cmd_set = 3'd0;
    vif_sq_tail = 16'd1;
    begin : cmd1
      int to = 0;
      while (to < 12) begin
        step(); to++;
        if (vif_tlp_valid === 1'b1) begin
          seen_tlp = 1;
          chk(vif_tlp_type === 4'b0001, "TLP type is memory read");
          chk(vif_length === 11'd2, "TLP length 2 DW");
          chk(vif_addr === 64'h1000, "doorbell 1 addr = 0x1000");
        end
        if (vif_irq_assert === 1'b1) seen_irq = 1;
      end
      chk(seen_tlp, "doorbell produced a TLP pulse");
      chk(seen_irq, "completion raised IRQ");
      chk(vif_sq_entry[31:0] === {16'd1, 8'h80}, "submission entry tagged admin (0x80)");
      chk(vif_tlp_data === {32'h1000, 16'h0001, 16'h5A5A},
          "TLP payload = {addr, count, 5A5A}");
      chk(vif_status_code === 8'h00, "qid 0 -> success status");
    end

    // cq_head == sq_tail clears the IRQ
    @(negedge vif_clk); vif_cq_head = 16'd1;
    begin : irqclr
      int to = 0;
      step();
      while (vif_irq_assert === 1'b1 && to < 10) begin step(); to++; end
      chk(vif_irq_assert === 1'b0, "IRQ cleared when cq_head == sq_tail");
    end

    // ---- admin command 2 with qid=8: error status ----
    seen_tlp = 0; seen_irq = 0;
    @(negedge vif_clk); vif_qid = 16'd8; vif_sq_tail = 16'd2;
    begin : cmd2
      int to = 0;
      while (to < 12) begin
        step(); to++;
        if (vif_tlp_valid === 1'b1) begin
          seen_tlp = 1;
          chk(vif_addr === 64'h2000, "doorbell 2 addr = 0x2000");
        end
        if (vif_irq_assert === 1'b1) seen_irq = 1;
      end
      chk(seen_tlp, "second doorbell produced TLP");
      chk(seen_irq, "second completion raised IRQ");
      chk(vif_tlp_data === {32'h2000, 16'h0002, 16'h5A5A}, "second TLP payload");
      chk(vif_status_code === 8'h01, "qid 8 -> invalid queue status");
    end
    @(negedge vif_clk); vif_cq_head = 16'd2;
    begin : irqclr2
      int to = 0;
      step();
      while (vif_irq_assert === 1'b1 && to < 10) begin step(); to++; end
      chk(vif_irq_assert === 1'b0, "IRQ cleared again");
    end

    // ---- non-admin doorbell: TLP still fires, tagged 0x01 ----
    seen_tlp = 0;
    @(negedge vif_clk); vif_admin_q = 1'b0; vif_qid = 16'd0; vif_sq_tail = 16'd3;
    begin : cmd3
      int to = 0;
      while (to < 12 && !seen_tlp) begin
        step(); to++;
        if (vif_tlp_valid === 1'b1) seen_tlp = 1;
      end
      chk(seen_tlp, "non-admin doorbell also produces TLP");
      chk(vif_sq_entry[31:0] === {16'd1, 8'h01}, "non-admin entry tagged 0x01");
    end
    @(negedge vif_clk); vif_cq_head = 16'd3;
    repeat (4) step();

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #500000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
