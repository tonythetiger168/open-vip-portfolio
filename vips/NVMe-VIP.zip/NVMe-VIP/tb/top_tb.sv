// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- NVMe testbench top with a functional NVMe controller DUT model

`ifndef NVME_TB_SV
`define NVME_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import nvme_pkg::*;
import nvme_test_pkg::*;

module top_tb;
  logic clk = 0;
  logic rst_n;

  always #5ns clk = ~clk;

  initial begin
    rst_n = 0;
    #100ns;
    rst_n = 1;
  end

  nvme_if vif(clk, rst_n);

  // Functional NVMe controller model (closed loop driver->DUT->monitor)
  nvme_controller_model dut (.vif(vif));

  // Module-form SVA/compliance checkers bound to the NVMe interface
  nvme_compliance_checker          nvme_sva_chk    (.vif(vif));
  nvme_data_integrity_checker      nvme_data_chk   (.vif(vif));
  nvme_protocol_compliance_checker nvme_proto_chk  (.vif(vif));
  nvme_error_handling_checker      nvme_err_chk    (.vif(vif));
  nvme_timing_performance_checker  nvme_timing_chk (.vif(vif));

  initial begin
    uvm_config_db#(virtual nvme_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

//============================================================================
// Functional NVMe controller: on each SQ tail doorbell it fetches the
// command, sets the completion status (Invalid Queue Identifier, 01h, for a
// queue above 7), moves one DMA TLP to the host (tlp_valid until
// tlp_ready), then raises the completion interrupt, which stays up until the
// host's CQ head doorbell catches up with the SQ tail. Namespace memory keeps
// the write payloads.
//============================================================================
module nvme_controller_model (nvme_if vif);

  bit [31:0] ns_mem [bit [63:0]];   // namespace memory (LBA -> DWORD)
  bit [15:0] last_sq_tail = 0;
  int unsigned cmd_count = 0, err_count = 0;
  bit        busy, irq_pend;

  // level interrupt: a completion is pending and the CQ head lags the SQ tail
  always @(*) vif.irq_assert = irq_pend && (vif.cq_head != vif.sq_tail);

  initial begin
    vif.tlp_data   = '0;
    vif.tlp_valid  = 0;
    vif.tlp_type   = 4'b0001;
    vif.requester_id = 16'h0100;
    vif.completer_id = 16'h0000;
    vif.tag        = '0;
    vif.tc         = 3'b000;
    vif.attr       = 3'b000;
    vif.length     = 11'd1;
    vif.addr       = 64'h1000;
    vif.status_code = 8'h00;
    foreach (vif.sq_entry[i]) vif.sq_entry[i] = 32'h0;
    foreach (vif.cq_entry[i]) vif.cq_entry[i] = 32'h0;
  end

  always @(posedge vif.clk) begin
    if (!vif.rst_n) begin
      last_sq_tail   <= 0;
      busy           <= 0;
      irq_pend       <= 0;
      vif.tlp_valid  <= 0;
      vif.status_code <= 8'h00;
    end else begin
      if (vif.cq_head == vif.sq_tail) irq_pend <= 0;
      if (!busy && vif.sq_tail != last_sq_tail) begin
        bit [7:0] st;
        st = (vif.qid > 16'd7) ? 8'h01 : 8'h00;
        last_sq_tail <= vif.sq_tail;
        busy <= 1;
        cmd_count++;
        if (st != 0) err_count++;
        vif.sq_entry[0] <= {16'd1, 8'h00, (vif.admin_q ? 8'h80 : 8'h01)};
        vif.addr   <= 64'h1000 * cmd_count;
        vif.length <= 11'd2;
        vif.tag    <= 10'(cmd_count);
        vif.tlp_data <= {64'h0, 32'(64'h1000 * cmd_count), 16'(cmd_count), 16'h5A5A};
        vif.status_code <= st;
        vif.cq_entry[0] <= {16'h0, 8'h00, st};
        vif.tlp_valid <= 1;
      end
      if (vif.tlp_valid && vif.tlp_ready) begin
        if (vif.cmd_set == 3'b000) ns_mem[vif.addr[63:12]] = vif.tlp_data[31:0];
        vif.tlp_valid  <= 0;
        irq_pend       <= 1;
        busy <= 0;
      end
    end
  end

  final $display("NVME_CONTROLLER_MODEL: commands=%0d errors=%0d ns_entries=%0d",
                 cmd_count, err_count, ns_mem.num());
endmodule
`endif
