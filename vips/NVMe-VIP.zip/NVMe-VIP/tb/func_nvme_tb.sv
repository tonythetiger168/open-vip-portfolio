// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_nvme_tb.sv -- self-checking functional test for the NVMe controller
// model (nvme_controller_model, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py NVMe-VIP
//
// Model contract (from tb/top_tb.sv):
//   Every change of the SQ tail doorbell is one command: the controller
//   tags SQ entry word 0 ({16'd1, 0x80 admin / 0x01 I/O}), raises a 2-DW
//   TLP at address 0x1000 * command count and holds TLP valid until ready.
//   The accepted TLP completes the command: payload {addr, count, 16'h5A5A},
//   status 0x00 (0x01 for QID > 7), IRQ asserted until CQ head == SQ tail.
//   NVM command set (0) commands store the TLP data word in the namespace.

module func_nvme_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0, xfails = 0;

  logic         clk = 1'b0, rst_n = 1'b0, tlp_ready = 1'b1, admin_q = 1'b0;
  logic [15:0]  cq_head = '0, sq_tail = '0, qid = '0;
  logic [2:0]   cmd_set = '0;
  wire  [127:0] tlp_data;
  wire          tlp_valid, irq;
  wire  [3:0]   tlp_type;
  wire  [15:0]  req_id, cpl_id;
  wire  [9:0]   tag;
  wire  [2:0]   tc, attr;
  wire  [10:0]  length;
  wire  [63:0]  addr;
  wire  [511:0] cq_entry, sq_entry;
  wire  [7:0]   status;

  always #5 clk = ~clk;

  nvme_controller_model u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_tlp_data(tlp_data), .vif_tlp_valid(tlp_valid),
    .vif_tlp_ready(tlp_ready), .vif_tlp_type(tlp_type), .vif_requester_id(req_id),
    .vif_completer_id(cpl_id), .vif_tag(tag), .vif_tc(tc), .vif_attr(attr),
    .vif_length(length), .vif_addr(addr), .vif_cq_entry(cq_entry), .vif_sq_entry(sq_entry),
    .vif_cq_head(cq_head), .vif_sq_tail(sq_tail), .vif_qid(qid), .vif_admin_q(admin_q),
    .vif_cmd_set(cmd_set), .vif_status_code(status), .vif_irq_assert(irq)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask
  // known model defect: XFAIL (not a failure); XPASS once fixed
  task automatic chk_xfail(input bit ok, input string msg);
    checks++;
    if (!ok) begin xfails++; $display("  [XFAIL] %s", msg); end
    else     begin fails++;  $display("  [XPASS] %s (remove the XFAIL marker)", msg); end
  endtask

  int tlp_beats = 0;
  always @(posedge clk) if (rst_n && tlp_valid && tlp_ready) tlp_beats++;

  int ncmd = 0;
  int wait_clks, held, bad;
  // ring the doorbell (tail + 1) and wait for the TLP handshake; ready is
  // held low for `stall` clocks after valid rises
  task automatic command(input bit adm, input [15:0] q, input [2:0] cs, input int stall = 0);
    @(negedge clk);
    admin_q = adm; qid = q; cmd_set = cs;
    tlp_ready = (stall == 0);
    sq_tail = sq_tail + 1;
    ncmd++;
    wait_clks = 0;
    while (tlp_valid !== 1'b1 && wait_clks < 10) begin @(negedge clk); wait_clks++; end
    held = 1;
    for (int s = 0; s < stall; s++) begin
      @(negedge clk);
      if (tlp_valid !== 1'b1 || addr !== 64'h1000 * ncmd) held = 0;
    end
    tlp_ready = 1'b1;
    @(negedge clk);
  endtask

  initial begin
    repeat (3) @(negedge clk);
    chk(tlp_valid === 1'b0 && irq === 1'b0 && status === 8'h00, "TLP, IRQ and status idle in reset");
    chk(sq_entry[31:0] === 32'h0 && cq_entry[31:0] === 32'h0, "SQ / CQ entry words cleared at start");
    chk(req_id === 16'h0100 && tlp_type === 4'b0001, "requester ID 0x0100, TLP type 1");
    rst_n = 1'b1;
    repeat (4) @(negedge clk);
    chk(tlp_valid === 1'b0 && irq === 1'b0, "no TLP / IRQ without a doorbell");

    // admin command, NVM command set
    command(1, 16'd0, 3'd0);
    chk(wait_clks == 1, "TLP valid one clock after the doorbell");
    chk(sq_entry[31:0] === {16'd1, 8'h80}, "admin SQ entry tagged 0x80");
    chk(length === 11'd2, "TLP length 2 DW");
    @(negedge clk);
    chk(tlp_valid === 1'b0, "TLP valid drops after the handshake");
    chk(tlp_data === {32'h1000, 16'd1, 16'h5A5A}, "TLP payload {addr, count, 5A5A}");
    chk(irq === 1'b1 && status === 8'h00, "completion: IRQ, success status");
    chk(u_dut.ns_mem.num() == 1, "NVM command set stores one namespace word");

    // IRQ held until CQ head reaches SQ tail
    repeat (5) @(negedge clk);
    chk(irq === 1'b1, "IRQ held while CQ head lags SQ tail");
    cq_head = sq_tail;
    repeat (2) @(negedge clk);
    chk(irq === 1'b0, "IRQ cleared when CQ head == SQ tail");
    repeat (3) @(negedge clk);
    chk(irq === 1'b0, "IRQ stays low with no new command");

    // backpressure: TLP held with its address until ready
    command(0, 16'd1, 3'd1, 4);
    chk(held == 1, "TLP valid and address held while ready is low");
    chk(sq_entry[31:0] === {16'd1, 8'h01}, "I/O SQ entry tagged 0x01");
    @(negedge clk);
    chk(u_dut.ns_mem.num() == 1, "non-NVM command set does not touch the namespace");
    cq_head = sq_tail;

    // QID boundary: 7 succeeds, 8 fails
    command(0, 16'd7, 3'd0);
    @(negedge clk);
    chk(status === 8'h00, "QID 7 completes with success");
    command(0, 16'd8, 3'd0);
    @(negedge clk);
    chk(status === 8'h01, "QID 8 completes with invalid-queue status");
    // the CQ entry is built from the old status register: it carries the
    // previous command's status
    chk_xfail(cq_entry[7:0] === 8'h01, "CQ entry carries this command's status");
    cq_head = sq_tail;

    // random commands with random backpressure
    bad = 0;
    for (int i = 0; i < 40; i++) begin
      logic [15:0] q;
      q = $urandom_range(12);
      command($urandom_range(1), q, $urandom_range(1) ? 3'd0 : 3'd2, $urandom_range(3));
      if (wait_clks != 1 || !held) bad++;
      @(negedge clk);
      if (tlp_data !== {32'h1000 * ncmd, 16'(ncmd), 16'h5A5A}) bad++;
      if (status !== ((q > 7) ? 8'h01 : 8'h00) || irq !== 1'b1) bad++;
      if ($urandom_range(1)) begin cq_head = sq_tail; repeat (2) @(negedge clk); if (irq !== 1'b0) bad++; end
    end
    chk(bad == 0, "40 random commands: address, payload, status and IRQ correct");
    chk(tlp_beats == ncmd, "exactly one TLP per doorbell");

    @(negedge clk); rst_n = 1'b0; sq_tail = sq_tail + 1;
    @(negedge clk); @(negedge clk);
    chk(tlp_valid === 1'b0 && irq === 1'b0 && status === 8'h00, "reset clears TLP, IRQ and status");

    if (fails == 0) $display("FUNC_PASS checks=%0d xfail=%0d", checks, xfails);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
