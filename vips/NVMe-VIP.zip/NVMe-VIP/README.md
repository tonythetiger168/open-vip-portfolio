# NVMe — NVMe UVM VIP

Open-source UVM verification IP template for **NVMe** (PCIe-attached storage).

## Protocol overview

The VIP models the NVMe host side: submission-queue doorbell writes, DMA TLP
flow control (tlp_valid/tlp_ready), completion-queue head advancement and
MSI-style interrupt handling. Transaction fields cover the full NVMe command
set (NVM + admin opcodes), NSID, PRP/SGL addressing, SLBA/NLB, fused commands
and status codes.

## Contents

| Path | Description |
|------|-------------|
| `nvme/nvme_if.sv` | PCIe/TLP + SQ/CQ interface with clocking blocks |
| `nvme/nvme_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / checker / coverage) |
| `regression/sva/nvme_compliance_checker.sv` | SVA compliance checker (L1=4, L2=6, L3=4, L4=5, module form) |
| `regression/vip/nvme/` | protocol / timing / error / data-integrity checkers |
| `env/env_pkg.sv` | multi-protocol env + **nvme_e2e_scoreboard** + **nvme_env** |
| `tb/top_tb.sv` | Testbench top with functional NVMe controller DUT model |
| `regression/` | Makefile + coverage-driven regression scripts |

## Deepened Features (v2.0.0)

- **Host driver**: SQ doorbell submission, TLP ready/valid flow control,
  completion wait with timeout, CQ head advance, `drv_ap` expected broadcast.
- **Decoding monitor**: reconstructs commands from accepted TLP beats +
  completion status (opcode/nsid/qid/slba/nlb/status), publishes via analysis
  port with per-transaction counting.
- **End-to-end scoreboard** (`nvme_e2e_scoreboard`): expected vs observed
  (qid/admin/cmd_set) with `n_matches`/`n_mismatches`, UVM_ERROR on mismatch.
- **Functional DUT model** (`nvme_controller_model`): doorbell detect, DMA
  TLP generation, namespace memory, CQ completion + status + IRQ.
- **Directed sequences (10)**: random, admin, io_rw, error_inject,
  back_to_back, stress (max NLB all queues), corner (nlb 0/1/255, admin
  boundary), reset, regression mix.
- **Functional coverage (4 covergroups)**: nvme_cmd_cg (opcode x admin,
  opcode x error, qid x opcode crosses), nvme_status_cg, nvme_fsm_cg
  (command/admin FSM transitions), nvme_data_cg (cdw10 pattern x length
  cross).
- **SVA L4 (5)**: SQ tail single-step doorbell, CQ head only after
  completion, known data on accepted TLPs, no TLP during reset, admin queue
  command-set legality.

All modified .sv/.svh files pass a pyslang syntax parse with 0 errors.

## Quick start

```bash
cd regression
make all                       # single run (xrun default)
./coverage_regression.sh       # full regression + coverage gate
```
License: Apache-2.0
