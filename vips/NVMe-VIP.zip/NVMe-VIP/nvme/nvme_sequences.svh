// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// nvme_sequences.svh

class nvme_base_sequence extends uvm_sequence #(nvme_transaction);
  `uvm_object_utils(nvme_base_sequence)
  function new(string name = "nvme_base_sequence");
    super.new(name);
  endfunction
endclass

class nvme_random_sequence extends nvme_base_sequence;
  `uvm_object_utils(nvme_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "nvme_random_sequence");
    super.new(name);
  endfunction
  task body();
    nvme_transaction tx;
    repeat (num_txns) begin
      tx = nvme_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "NVMe tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class nvme_admin_sequence extends nvme_base_sequence;
  `uvm_object_utils(nvme_admin_sequence)
  rand int num_txns = 20;
  function new(string name = "nvme_admin_sequence");
    super.new(name);
  endfunction
  task body();
    nvme_transaction tx;
    repeat (num_txns) begin
      tx = nvme_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { admin_cmd == 1; qid == 0; })
        `uvm_error("RANDFAIL", "NVMe admin randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class nvme_io_rw_sequence extends nvme_base_sequence;
  `uvm_object_utils(nvme_io_rw_sequence)
  rand int num_txns = 50;
  rand bit read_ratio = 1; // 1=more reads
  function new(string name = "nvme_io_rw_sequence");
    super.new(name);
  endfunction
  task body();
    nvme_transaction tx;
    repeat (num_txns) begin
      tx = nvme_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with {
        admin_cmd == 0;
        opcode dist {nvme_transaction::CMD_READ:=60, nvme_transaction::CMD_WRITE:=40};
        nsid inside {[1:8]};
        nlb inside {[0:63]};
      }) `uvm_error("RANDFAIL", "NVMe IO RW randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class nvme_error_inject_sequence extends nvme_base_sequence;
  `uvm_object_utils(nvme_error_inject_sequence)
  rand int num_txns = 20;
  function new(string name = "nvme_error_inject_sequence");
    super.new(name);
  endfunction
  task body();
    nvme_transaction tx;
    repeat (num_txns) begin
      tx = nvme_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { with_error == 1; status inside {[1:255]}; })
        `uvm_error("RANDFAIL", "NVMe error inject randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// ---------------------------------------------------------------------------
// Deepened directed sequences (v2.0.0)
// ---------------------------------------------------------------------------

// Directed: back-to-back commands on the same queue (no idle doorbell gap)
class nvme_back_to_back_seq extends nvme_base_sequence;
  `uvm_object_utils(nvme_back_to_back_seq)
  rand int num_txns = 30;
  function new(string name = "nvme_back_to_back_seq"); super.new(name); endfunction
  task body();
    nvme_transaction tx;
    repeat (num_txns) begin
      tx = nvme_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { admin_cmd == 0; qid == 1;
                                 opcode inside {nvme_transaction::CMD_READ,
                                                nvme_transaction::CMD_WRITE};
                                 nlb == 0; })
        `uvm_error("RANDFAIL", "NVMe b2b randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: stress - max NLB transfers across all IO queues
class nvme_stress_seq extends nvme_base_sequence;
  `uvm_object_utils(nvme_stress_seq)
  rand int num_txns = 40;
  function new(string name = "nvme_stress_seq"); super.new(name); endfunction
  task body();
    nvme_transaction tx;
    repeat (num_txns) begin
      tx = nvme_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { admin_cmd == 0; qid inside {[1:7]};
                                 opcode inside {nvme_transaction::CMD_READ,
                                                nvme_transaction::CMD_WRITE};
                                 nlb inside {[128:255]}; })
        `uvm_error("RANDFAIL", "NVMe stress randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: corner cases - nlb=0/255, slba at region boundaries, CID reuse
class nvme_corner_seq extends nvme_base_sequence;
  `uvm_object_utils(nvme_corner_seq)
  function new(string name = "nvme_corner_seq"); super.new(name); endfunction
  task body();
    nvme_transaction tx;
    bit [15:0] nlbs[4] = '{16'd0, 16'd1, 16'd255, 16'd0};
    foreach (nlbs[i]) begin
      tx = nvme_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { admin_cmd == 0;
                                 opcode inside {nvme_transaction::CMD_READ,
                                                nvme_transaction::CMD_WRITE};
                                 nlb == nlbs[i];
                                 slba[11:0] == 12'h000; })
        `uvm_error("RANDFAIL", "NVMe corner randomization failed")
      finish_item(tx);
    end
    // admin command on queue 0 boundary
    tx = nvme_transaction::type_id::create("tx");
    start_item(tx);
    if (!tx.randomize() with { admin_cmd == 1; qid == 0;
                               opcode == nvme_transaction::CMD_FLUSH; })
      `uvm_error("RANDFAIL", "NVMe corner(admin) randomization failed")
    finish_item(tx);
  endtask
endclass

// Directed: single command issued immediately after reset release
class nvme_reset_seq extends nvme_base_sequence;
  `uvm_object_utils(nvme_reset_seq)
  function new(string name = "nvme_reset_seq"); super.new(name); endfunction
  task body();
    nvme_transaction tx = nvme_transaction::type_id::create("tx");
    start_item(tx);
    if (!tx.randomize() with { admin_cmd == 1; qid == 0;
                               opcode == nvme_transaction::CMD_FLUSH; })
      `uvm_error("RANDFAIL", "NVMe reset randomization failed")
    finish_item(tx);
  endtask
endclass

// Regression: weighted mix of all directed sequences
class nvme_regression_seq extends nvme_base_sequence;
  `uvm_object_utils(nvme_regression_seq)
  function new(string name = "nvme_regression_seq"); super.new(name); endfunction
  task body();
    nvme_random_sequence      rnd = nvme_random_sequence::type_id::create("rnd");
    nvme_io_rw_sequence       ior = nvme_io_rw_sequence::type_id::create("ior");
    nvme_admin_sequence       adm = nvme_admin_sequence::type_id::create("adm");
    nvme_back_to_back_seq     b2b = nvme_back_to_back_seq::type_id::create("b2b");
    nvme_stress_seq           str = nvme_stress_seq::type_id::create("str");
    nvme_corner_seq           cor = nvme_corner_seq::type_id::create("cor");
    nvme_error_inject_sequence err = nvme_error_inject_sequence::type_id::create("err");
    rnd.num_txns = 40; ior.num_txns = 40; adm.num_txns = 10;
    b2b.num_txns = 20; str.num_txns = 10; err.num_txns = 10;
    rnd.start(m_sequencer); ior.start(m_sequencer); adm.start(m_sequencer);
    b2b.start(m_sequencer); str.start(m_sequencer);
    cor.start(m_sequencer); err.start(m_sequencer);
  endtask
endclass
