// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// nvme_monitor.svh -- NVMe monitor: decodes TLP traffic + completion status
// from the interface and publishes reconstructed transactions.

`ifndef NVME_MONITOR_SVH
`define NVME_MONITOR_SVH

class nvme_monitor extends uvm_monitor;
  `uvm_component_utils(nvme_monitor)
  virtual nvme_if vif;
  uvm_analysis_port #(nvme_transaction) ap;
  nvme_config cfg;
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual nvme_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "NVMe virtual interface not found")
    if (!uvm_config_db#(nvme_config)::get(this, "", "cfg", cfg))
      cfg = nvme_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    nvme_transaction tx;
    bit [7:0] last_status = 8'hFF;
    forever begin
      @(vif.mon_cb);
      // decode a TLP beat accepted by the host
      if (vif.mon_cb.tlp_valid && vif.mon_cb.tlp_ready) begin
        tx = nvme_transaction::type_id::create("tx");
        tx.opcode = nvme_transaction::nvme_opcode_e'(vif.mon_cb.sq_entry[0][7:0]);
        tx.nsid   = vif.mon_cb.sq_entry[0][31:16];
        tx.qid    = vif.mon_cb.qid;
        tx.admin_cmd = vif.mon_cb.admin_q;
        tx.cmd_set   = vif.mon_cb.cmd_set;
        tx.slba   = vif.mon_cb.addr[63:12] << 12;
        tx.nlb    = vif.mon_cb.length[15:0];
        tx.cid    = vif.mon_cb.tag[9:0];
        tx.status = vif.mon_cb.status_code;
        txn_count++;
        `uvm_info("NVMe_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_HIGH)
        ap.write(tx);
      end
      // completion with error status also produces a transaction
      else if (vif.mon_cb.status_code != 8'h00 && vif.mon_cb.status_code != last_status) begin
        tx = nvme_transaction::type_id::create("tx");
        tx.qid    = vif.mon_cb.qid;
        tx.admin_cmd = vif.mon_cb.admin_q;
        tx.cmd_set   = vif.mon_cb.cmd_set;
        tx.status = vif.mon_cb.status_code;
        txn_count++;
        ap.write(tx);
      end
      last_status = vif.mon_cb.status_code;
    end
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("NVMe_MON", $sformatf("nvme monitor observed %0d transactions", txn_count), UVM_LOW)
  endfunction
endclass
`endif
