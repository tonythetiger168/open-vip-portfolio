// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// nvme_transaction.svh

class nvme_transaction extends uvm_sequence_item;
  `uvm_object_utils(nvme_transaction)

  typedef enum bit [7:0] {
    CMD_FLUSH        = 8'h00,
    CMD_WRITE        = 8'h01,
    CMD_READ         = 8'h02,
    CMD_WRITE_UNC    = 8'h04,
    CMD_COMPARE      = 8'h05,
    CMD_WRITE_ZEROES = 8'h08,
    CMD_DATASET_MGMT = 8'h09,
    CMD_VERIFY       = 8'h0C,
    CMD_RESERV_REG   = 8'h0D,
    CMD_RESERV_REP   = 8'h0E,
    CMD_COPY         = 8'h19,
    CMD_FORMAT_NVM   = 8'h80,
    CMD_SECURITY_SND = 8'h81,
    CMD_SECURITY_RCV = 8'h82,
    CMD_SANITIZE     = 8'h84
  } nvme_opcode_e;

  typedef enum bit [2:0] {
    PRP_SGL_PRP    = 3'b000,
    PRP_SGL_SGL    = 3'b001,
    PRP_SGL_SGL_FB = 3'b010
  } prp_sgl_e;

  rand nvme_opcode_e opcode;
  rand bit [15:0]    nsid;
  rand bit [63:0]    prp1;
  rand bit [63:0]    prp2;
  rand bit [31:0]    cdw10;
  rand bit [31:0]    cdw11;
  rand bit [31:0]    cdw12;
  rand bit [31:0]    cdw13;
  rand bit [31:0]    cdw14;
  rand bit [31:0]    cdw15;
  rand bit [15:0]    qid;
  rand bit           admin_cmd;
  rand prp_sgl_e     prp_sgl;
  rand bit [2:0]     fuse;
  rand bit [15:0]    cid;
  rand bit [63:0]    slba;
  rand bit [15:0]    nlb;
  rand bit [31:0]    data_len;
  rand bit [7:0]     status;
  rand bit           with_error;
  rand bit [2:0]     cmd_set;

  constraint c_nsid { nsid inside {[1:32]}; }
  constraint c_admin { admin_cmd == (qid == 0); }
  constraint c_fuse { fuse inside {0, 1, 3}; }
  constraint c_error { with_error dist {0:=95, 1:=5}; }
  constraint c_slba { slba[11:0] == 12'h000; } // 4K aligned
  constraint c_nlb { nlb inside {[0:255]}; }
  constraint c_data_len {
    if (opcode inside {CMD_WRITE, CMD_READ, CMD_COMPARE})
      data_len == (nlb + 1) * 512;
    else
      data_len inside {[0:4096]};
  }
  constraint c_prp_align {
    prp1[11:0] == 12'h000;
    prp2[11:0] == 12'h000;
  }

  function new(string name = "nvme_transaction");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("NVMe: opcode=%s nsid=%0d qid=%0d admin=%b slba=0x%0x nlb=%0d len=%0d status=0x%0x err=%b",
      opcode.name(), nsid, qid, admin_cmd, slba, nlb, data_len, status, with_error);
  endfunction
endclass
