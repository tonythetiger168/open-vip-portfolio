// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// nvme_coverage.svh

class nvme_coverage extends coverage_collector_base;
  `uvm_component_utils(nvme_coverage)
  uvm_analysis_imp #(nvme_transaction, nvme_coverage) analysis_export;

  // sampled transaction (declared before the covergroups that reference it)
  nvme_transaction tx;

  covergroup nvme_cmd_cg;
    option.per_instance = 1;
    opcode_cp: coverpoint tx.opcode {
      bins flush = {nvme_transaction::CMD_FLUSH};
      bins write = {nvme_transaction::CMD_WRITE};
      bins read  = {nvme_transaction::CMD_READ};
      bins w_unc = {nvme_transaction::CMD_WRITE_UNC};
      bins comp  = {nvme_transaction::CMD_COMPARE};
      bins w_zero= {nvme_transaction::CMD_WRITE_ZEROES};
      bins dsm   = {nvme_transaction::CMD_DATASET_MGMT};
      bins verify= {nvme_transaction::CMD_VERIFY};
      bins admin_cmds[] = {nvme_transaction::CMD_FORMAT_NVM, nvme_transaction::CMD_SECURITY_SND,
                           nvme_transaction::CMD_SECURITY_RCV, nvme_transaction::CMD_SANITIZE};
    }
    nsid_cp: coverpoint tx.nsid { bins low = {[1:8]}; bins mid = {[9:16]}; bins high = {[17:32]}; }
    admin_cp: coverpoint tx.admin_cmd;
    qid_cp: coverpoint tx.qid { bins admin_q = {0}; bins io_q = {[1:7]}; }
    nlb_cp: coverpoint tx.nlb { bins lo = {[0:15]}; bins mid = {[16:127]}; bins hi = {[128:255]}; }
    error_cp: coverpoint tx.with_error;
    fuse_cp: coverpoint tx.fuse { bins none = {0}; bins first = {1}; bins second = {3}; }
    cross opcode_cp, admin_cp;
    cross opcode_cp, error_cp;
    cross qid_cp, opcode_cp;
  endgroup

  covergroup nvme_status_cg;
    option.per_instance = 1;
    status_cp: coverpoint tx.status {
      bins success = {0};
      bins err[] = {[1:255]};
    }
  endgroup


  // FSM transition coverage: admin/io command issue -> completion flow
  nvme_transaction::nvme_opcode_e prev_opcode;
  covergroup nvme_fsm_cg;
    option.per_instance = 1;
    cmd_trans_cp: coverpoint tx.opcode {
      bins wr_then_rd = (nvme_transaction::CMD_WRITE => nvme_transaction::CMD_READ);
      bins rd_then_wr = (nvme_transaction::CMD_READ  => nvme_transaction::CMD_WRITE);
      bins flush_any  = (nvme_transaction::CMD_FLUSH => nvme_transaction::CMD_FLUSH);
    }
    admin_trans_cp: coverpoint tx.admin_cmd {
      bins admin_to_io = (1 => 0);
      bins io_to_admin = (0 => 1);
      bins io_steady   = (0 => 0);
    }
  endgroup

  // Data pattern coverage: command DWORD patterns x transfer length
  covergroup nvme_data_cg;
    option.per_instance = 1;
    cdw10_cp: coverpoint tx.cdw10 {
      bins zero = {32'h0};
      bins ones = {32'hFFFF_FFFF};
      bins walk = default;
    }
    len_cp: coverpoint tx.data_len {
      bins sector  = {[0:512]};
      bins page    = {[513:4096]};
      bins big     = {[4097:$]};
    }
    cross cdw10_cp, len_cp;
  endgroup

  nvme_transaction tx;
  int sample_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    nvme_cmd_cg = new();
    nvme_status_cg = new();
    nvme_fsm_cg = new();
    nvme_data_cg = new();
  endfunction
  function void write(nvme_transaction tx_); tx = tx_; sample_coverage(tx); endfunction
  virtual function void sample_coverage(uvm_sequence_item tx_);
    nvme_transaction ntx;
    if (!$cast(ntx, tx_)) return;
    tx = ntx;
    nvme_cmd_cg.sample();
    nvme_status_cg.sample();
    nvme_fsm_cg.sample();
    nvme_data_cg.sample();
    prev_opcode = ntx.opcode;
    sample_count++;
  endfunction
  function void report_phase(uvm_phase phase);
    `uvm_info("NVMe_COV", $sformatf("Sampled %0d transactions", sample_count), UVM_LOW)
    `uvm_info("NVMe_COV", $sformatf("CMD coverage = %0.2f%%", nvme_cmd_cg.get_coverage()), UVM_LOW)
  endfunction
endclass
