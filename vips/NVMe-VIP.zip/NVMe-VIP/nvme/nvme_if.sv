// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// nvme_if.sv
// NVMe PCIe Interface

interface nvme_if (input logic clk, input logic rst_n);
  // PCIe-like signals
  logic [127:0] tlp_data;
  logic         tlp_valid;
  logic         tlp_ready;
  logic [3:0]   tlp_type;
  logic [15:0]  requester_id;
  logic [15:0]  completer_id;
  logic [9:0]   tag;
  logic [2:0]   tc;
  logic [2:0]   attr;
  logic [10:0]  length;
  logic [63:0]  addr;
  logic [31:0]  cq_entry [0:15];  // Completion Queue
  logic [31:0]  sq_entry [0:15];  // Submission Queue
  logic [15:0]  cq_head;
  logic [15:0]  sq_tail;
  logic [15:0]  qid;
  logic         admin_q;
  logic [2:0]   cmd_set;
  logic [7:0]   status_code;
  logic         irq_assert;

  modport DUT (
    input  clk, rst_n, tlp_ready, cq_entry, cq_head, sq_tail, qid, admin_q, cmd_set,
    output tlp_data, tlp_valid, tlp_type, requester_id, completer_id, tag, tc, attr,
    output length, addr, sq_entry, status_code, irq_assert
  );

  modport TB (
    input  clk, rst_n, tlp_data, tlp_valid, tlp_type, requester_id, completer_id,
    input  tag, tc, attr, length, addr, sq_entry, status_code, irq_assert,
    output tlp_ready, cq_entry, cq_head, sq_tail, qid, admin_q, cmd_set
  );

  clocking mon_cb @(posedge clk);
    input tlp_data, tlp_valid, tlp_ready, tlp_type, requester_id, completer_id;
    input tag, tc, attr, length, addr, sq_entry, status_code, irq_assert;
    input cq_head, sq_tail, qid, admin_q, cmd_set;
  endclocking

  clocking drv_cb @(posedge clk);
    output tlp_ready, cq_entry, cq_head, sq_tail, qid, admin_q, cmd_set;
    input  tlp_valid;
  endclocking
endinterface
