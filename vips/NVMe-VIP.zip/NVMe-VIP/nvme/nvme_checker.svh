// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// nvme_checker.svh

class nvme_checker extends protocol_checker_base;
  `uvm_component_utils(nvme_checker)
  uvm_analysis_imp #(nvme_transaction, nvme_checker) analysis_export;
  int tx_count = 0;
  bit [15:0] used_cid[$];
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
  endfunction
  function void write(nvme_transaction tx);
    tx_count++;
    check_opcode(tx);
    check_nsid(tx);
    check_alignment(tx);
    check_cid_unique(tx);
    check_status(tx);
  endfunction
  function void check_opcode(nvme_transaction tx);
    case (tx.opcode)
      nvme_transaction::CMD_FLUSH, nvme_transaction::CMD_WRITE,
      nvme_transaction::CMD_READ, nvme_transaction::CMD_WRITE_UNC,
      nvme_transaction::CMD_COMPARE, nvme_transaction::CMD_WRITE_ZEROES,
      nvme_transaction::CMD_DATASET_MGMT, nvme_transaction::CMD_VERIFY,
      nvme_transaction::CMD_RESERV_REG, nvme_transaction::CMD_RESERV_REP,
      nvme_transaction::CMD_COPY, nvme_transaction::CMD_FORMAT_NVM,
      nvme_transaction::CMD_SECURITY_SND, nvme_transaction::CMD_SECURITY_RCV,
      nvme_transaction::CMD_SANITIZE: ;
      default: check_protocol_error($sformatf("Invalid opcode 0x%0x", tx.opcode));
    endcase
  endfunction
  function void check_nsid(nvme_transaction tx);
    if (tx.nsid == 0 && !tx.admin_cmd)
      check_protocol_error("NSID=0 for non-admin command");
  endfunction
  function void check_alignment(nvme_transaction tx);
    if (tx.slba[11:0] != 0)
      check_protocol_warning($sformatf("SLBA 0x%0x not 4K aligned", tx.slba));
  endfunction
  function void check_cid_unique(nvme_transaction tx);
    if (tx.cid inside {used_cid})
      check_protocol_warning($sformatf("CID %0d reused", tx.cid));
    else
      used_cid.push_back(tx.cid);
  endfunction
  function void check_status(nvme_transaction tx);
    if (tx.status != 0 && !tx.with_error)
      check_protocol_warning($sformatf("Non-zero status 0x%0x without error flag", tx.status));
  endfunction
  task run_phase(uvm_phase phase); endtask
  function void report_phase(uvm_phase phase);
    `uvm_info("NVMe_CHK", $sformatf("Checked %0d transactions, %0d errors, %0d warnings",
      tx_count, error_count, warning_count), UVM_LOW)
  endfunction
endclass
