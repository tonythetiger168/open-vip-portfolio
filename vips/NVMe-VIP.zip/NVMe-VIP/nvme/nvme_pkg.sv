// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// nvme_pkg.sv

package nvme_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  `include "nvme_config.svh"
  `include "nvme_transaction.svh"
  `include "nvme_sequencer.svh"
  `include "nvme_driver.svh"
  `include "nvme_monitor.svh"
  `include "nvme_checker.svh"
  `include "nvme_coverage.svh"
  `include "nvme_agent.svh"
  `include "nvme_sequences.svh"
endpackage
