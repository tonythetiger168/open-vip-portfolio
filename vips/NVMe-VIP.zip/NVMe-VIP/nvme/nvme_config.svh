// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// nvme_config.svh

class nvme_config extends uvm_object;
  `uvm_object_utils(nvme_config)
  bit enable_checker  = 1;
  bit enable_coverage = 1;
  int num_queues = 8;
  int queue_depth = 256;
  int max_transfer_size = 1048576; // 1MB
  bit msix_enabled = 1;
  function new(string name = "nvme_config");
    super.new(name);
  endfunction
endclass
