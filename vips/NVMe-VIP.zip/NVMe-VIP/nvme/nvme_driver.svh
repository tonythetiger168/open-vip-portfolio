// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// nvme_driver.svh -- NVMe host driver: SQ doorbell submission, TLP flow
// control, completion wait, expected-transaction broadcast.

`ifndef NVME_DRIVER_SVH
`define NVME_DRIVER_SVH

class nvme_driver extends uvm_driver #(nvme_transaction);
  `uvm_component_utils(nvme_driver)
  virtual nvme_if vif;
  nvme_config cfg;
  uvm_analysis_port #(nvme_transaction) drv_ap;  // expected items for scoreboard
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual nvme_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "NVMe virtual interface not found")
    if (!uvm_config_db#(nvme_config)::get(this, "", "cfg", cfg))
      cfg = nvme_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    vif.drv_cb.tlp_ready <= 0;
    vif.drv_cb.sq_tail   <= 0;
    vif.drv_cb.cq_head   <= 0;
    vif.drv_cb.qid       <= 0;
    vif.drv_cb.admin_q   <= 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      drv_ap.write(req);  // broadcast expected transaction
      seq_item_port.item_done();
    end
  endtask

  task drive_item(nvme_transaction tx);
    `uvm_info("NVMe_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)

    // ---- SQ submission: present queue id/type, ring the doorbell ----
    @(vif.drv_cb);
    vif.drv_cb.qid       <= tx.qid;
    vif.drv_cb.admin_q   <= tx.admin_cmd;
    vif.drv_cb.cmd_set   <= tx.cmd_set;
    vif.drv_cb.sq_tail   <= vif.sq_tail + 1;  // doorbell

    // ---- TLP flow control: accept DMA TLPs from the controller ----
    vif.drv_cb.tlp_ready <= 1;
    if (tx.opcode == nvme_transaction::CMD_WRITE ||
        tx.opcode == nvme_transaction::CMD_READ  ||
        tx.opcode == nvme_transaction::CMD_COMPARE) begin
      // one TLP per 512B sector, bounded by queue depth
      repeat ((tx.nlb + 1) > 8 ? 8 : (tx.nlb + 1)) @(vif.drv_cb);
    end else begin
      repeat (2) @(vif.drv_cb);
    end
    vif.drv_cb.tlp_ready <= 0;

    // ---- completion wait: poll irq/status, then advance CQ head ----
    begin
      int timeout = 0;
      while (vif.mon_cb.status_code === 8'h00 && vif.mon_cb.irq_assert !== 1'b1 &&
             timeout < 100) begin
        @(vif.drv_cb);
        timeout++;
      end
    end
    vif.drv_cb.cq_head <= vif.cq_head + 1;
    tx.status = vif.mon_cb.status_code;
    txn_count++;
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("NVMe_DRV", $sformatf("nvme driver submitted %0d commands", txn_count), UVM_LOW)
  endfunction
endclass
`endif
