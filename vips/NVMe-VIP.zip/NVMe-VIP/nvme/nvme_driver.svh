// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// nvme_driver.svh -- NVMe host driver: SQ doorbell submission, TLP flow
// control, completion wait, expected-transaction broadcast.

`ifndef NVME_DRIVER_SVH
`define NVME_DRIVER_SVH

class nvme_driver extends uvm_driver #(nvme_transaction);
  `uvm_component_utils(nvme_driver)
  virtual nvme_if vif;
  nvme_config cfg;
  uvm_analysis_port #(nvme_transaction) drv_ap;  // expected items for scoreboard
  int unsigned txn_count = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual nvme_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "NVMe virtual interface not found")
    if (!uvm_config_db#(nvme_config)::get(this, "", "cfg", cfg))
      cfg = nvme_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    vif.drv_cb.tlp_ready <= 0;
    vif.drv_cb.sq_tail   <= 0;
    vif.drv_cb.cq_head   <= 0;
    vif.drv_cb.qid       <= 0;
    vif.drv_cb.admin_q   <= 0;
    vif.drv_cb.cmd_set   <= 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      drv_ap.write(req);  // broadcast the completed command (with its status)
      seq_item_port.item_done();
    end
  endtask

  // One command: ring the SQ tail doorbell, accept the controller's DMA TLP
  // (tlp_ready held from the doorbell to the completion), wait for the
  // completion interrupt, take the status and advance the CQ head.
  task drive_item(nvme_transaction tx);
    int timeout = 0;
    `uvm_info("NVMe_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)
    @(vif.drv_cb);
    vif.drv_cb.qid       <= tx.qid;
    vif.drv_cb.admin_q   <= tx.admin_cmd;
    vif.drv_cb.cmd_set   <= tx.cmd_set;
    vif.drv_cb.sq_tail   <= vif.sq_tail + 1;  // doorbell
    vif.drv_cb.tlp_ready <= 1;
    // completion: the controller raises irq_assert after the TLP
    do begin
      @(vif.drv_cb);
      timeout++;
    end while (vif.mon_cb.irq_assert !== 1'b1 && timeout < 200);
    if (timeout >= 200) `uvm_error("NVMe_DRV", $sformatf("no completion for %s", tx.convert2string()))
    tx.status = vif.mon_cb.status_code;
    vif.drv_cb.cq_head   <= vif.cq_head + 1;
    @(vif.drv_cb);
    vif.drv_cb.tlp_ready <= 0;
    txn_count++;
  endtask

  function void report_phase(uvm_phase phase);
    `uvm_info("NVMe_DRV", $sformatf("nvme driver submitted %0d commands", txn_count), UVM_LOW)
  endfunction
endclass
`endif
