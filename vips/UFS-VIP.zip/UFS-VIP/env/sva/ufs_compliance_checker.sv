// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ufs_compliance_checker.sv -- UFS tiered compliance SVA checker (module form)
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features | L4=Protocol-Specific
`ifndef UFS_COMPLIANCE_CHECKER_SV
`define UFS_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ufs_compliance_checker (ufs_if vif);
  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[6], l4_fail[6];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_ufs_cmd_valid; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.req_valid == 1 |-> !$isunknown(vif.req_data); endproperty
  assert_p_ufs_cmd_valid: assert property(p_ufs_cmd_valid) l1_pass[0]++; else begin `uvm_warning("UFS_L1", "Command valid failed"); l1_fail[0]++; end
  cover_p_ufs_cmd_valid: cover property(p_ufs_cmd_valid);
  property p_ufs_addr_valid; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.valid == 1 |-> !$isunknown(vif.data_out); endproperty
  assert_p_ufs_addr_valid: assert property(p_ufs_addr_valid) l1_pass[1]++; else begin `uvm_warning("UFS_L1", "Address valid failed"); l1_fail[1]++; end
  cover_p_ufs_addr_valid: cover property(p_ufs_addr_valid);
  property p_ufs_data_valid; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.data_in_valid == 1 |-> !$isunknown(vif.data_in); endproperty
  assert_p_ufs_data_valid: assert property(p_ufs_data_valid) l1_pass[2]++; else begin `uvm_warning("UFS_L1", "Data valid failed"); l1_fail[2]++; end
  cover_p_ufs_data_valid: cover property(p_ufs_data_valid);
  property p_ufs_no_x; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.data_out_valid == 1 |-> !$isunknown({vif.task_tag, vif.data_length}); endproperty
  assert_p_ufs_no_x: assert property(p_ufs_no_x) l1_pass[3]++; else begin `uvm_warning("UFS_L1", "No X when active failed"); l1_fail[3]++; end
  cover_p_ufs_no_x: cover property(p_ufs_no_x);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_ufs_transfer_ready; @(posedge vif.ref_clk) disable iff (!vif.rst_n) ($rose(vif.req_valid) && vif.cmd_type == 4'h1) |-> ##[1:64] (vif.transfer_ready == 1 || vif.resp_valid == 1); endproperty
  assert_p_ufs_transfer_ready: assert property(p_ufs_transfer_ready) l2_pass[0]++; else begin `uvm_warning("UFS_L2", "Transfer ready failed"); l2_fail[0]++; end
  cover_p_ufs_transfer_ready: cover property(p_ufs_transfer_ready);
  property p_ufs_resp_latency; @(posedge vif.ref_clk) disable iff (!vif.rst_n) $rose(vif.req_valid) |-> ##[1:16384] vif.resp_valid == 1; endproperty
  assert_p_ufs_resp_latency: assert property(p_ufs_resp_latency) l2_pass[1]++; else begin `uvm_warning("UFS_L2", "Response latency failed"); l2_fail[1]++; end
  cover_p_ufs_resp_latency: cover property(p_ufs_resp_latency);
  property p_ufs_task_tag; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.task_tag <= 8'd255; endproperty
  assert_p_ufs_task_tag: assert property(p_ufs_task_tag) l2_pass[2]++; else begin `uvm_warning("UFS_L2", "Task tag 0-255 failed"); l2_fail[2]++; end
  cover_p_ufs_task_tag: cover property(p_ufs_task_tag);
  property p_ufs_lun_id; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.lun_id <= 8'd7; endproperty
  assert_p_ufs_lun_id: assert property(p_ufs_lun_id) l2_pass[3]++; else begin `uvm_warning("UFS_L2", "LUN 0-7 failed"); l2_fail[3]++; end
  cover_p_ufs_lun_id: cover property(p_ufs_lun_id);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_ufs_error; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.err == 1 |-> ##[1:16] vif.err == 0; endproperty
  assert_p_ufs_error: assert property(p_ufs_error) l3_pass[0]++; else begin `uvm_warning("UFS_L3", "Error handling failed"); l3_fail[0]++; end
  cover_p_ufs_error: cover property(p_ufs_error);
  property p_ufs_timeout; @(posedge vif.ref_clk) disable iff (!vif.rst_n) $rose(vif.valid) |-> ##[1:1000] vif.busy == 1; endproperty
  assert_p_ufs_timeout: assert property(p_ufs_timeout) l3_pass[1]++; else begin `uvm_warning("UFS_L3", "Timeout failed"); l3_fail[1]++; end
  cover_p_ufs_timeout: cover property(p_ufs_timeout);
  property p_ufs_status; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.status inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ufs_status: assert property(p_ufs_status) l3_pass[2]++; else begin `uvm_warning("UFS_L3", "Status valid failed"); l3_fail[2]++; end
  cover_p_ufs_status: cover property(p_ufs_status);
  property p_ufs_power; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.power_state inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ufs_power: assert property(p_ufs_power) l3_pass[3]++; else begin `uvm_warning("UFS_L3", "Power state failed"); l3_fail[3]++; end
  cover_p_ufs_power: cover property(p_ufs_power);

  // ---------------- L4: UFS protocol-specific rules (6) ----------------
  property p_ufs_l4_upiu_type; @(posedge vif.ref_clk) disable iff (!vif.rst_n) $rose(vif.doorbell) |-> vif.data_out inside {8'h00,8'h01,8'h02,8'h04,8'h16,8'h20,8'h21,8'h22,8'h24,8'h31,8'h36,8'h3F}; endproperty
  assert_p_ufs_l4_upiu_type: assert property(p_ufs_l4_upiu_type) l4_pass[0]++; else begin `uvm_warning("UFS_L4", "Illegal UPIU type on doorbell failed"); l4_fail[0]++; end
  cover_p_ufs_l4_upiu_type: cover property(p_ufs_l4_upiu_type);
  property p_ufs_l4_rtt_before_wdata; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.transfer_ready == 1 |-> ##[1:16] vif.data_out_valid == 1; endproperty
  assert_p_ufs_l4_rtt_before_wdata: assert property(p_ufs_l4_rtt_before_wdata) l4_pass[1]++; else begin `uvm_warning("UFS_L4", "RTT not followed by write data failed"); l4_fail[1]++; end
  cover_p_ufs_l4_rtt_before_wdata: cover property(p_ufs_l4_rtt_before_wdata);
  property p_ufs_l4_resp_after_cmd; @(posedge vif.ref_clk) disable iff (!vif.rst_n) $rose(vif.doorbell) |-> s_eventually vif.resp_valid == 1; endproperty
  assert_p_ufs_l4_resp_after_cmd: assert property(p_ufs_l4_resp_after_cmd) l4_pass[2]++; else begin `uvm_warning("UFS_L4", "Command without response failed"); l4_fail[2]++; end
  cover_p_ufs_l4_resp_after_cmd: cover property(p_ufs_l4_resp_after_cmd);
  property p_ufs_l4_tag_stable; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.busy == 1 |-> $stable(vif.task_tag); endproperty
  assert_p_ufs_l4_tag_stable: assert property(p_ufs_l4_tag_stable) l4_pass[3]++; else begin `uvm_warning("UFS_L4", "Task tag changed mid-transfer failed"); l4_fail[3]++; end
  cover_p_ufs_l4_tag_stable: cover property(p_ufs_l4_tag_stable);
  property p_ufs_l4_err_status; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.err == 1 |-> vif.status == 3'b010; endproperty
  assert_p_ufs_l4_err_status: assert property(p_ufs_l4_err_status) l4_pass[4]++; else begin `uvm_warning("UFS_L4", "Error without CHECK CONDITION status failed"); l4_fail[4]++; end
  cover_p_ufs_l4_err_status: cover property(p_ufs_l4_err_status);
  property p_ufs_l4_data_dir; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.data_in_valid == 1 |-> vif.data_dir == 2'b10; endproperty
  assert_p_ufs_l4_data_dir: assert property(p_ufs_l4_data_dir) l4_pass[5]++; else begin `uvm_warning("UFS_L4", "Device data without device ownership failed"); l4_fail[5]++; end
  cover_p_ufs_l4_data_dir: cover property(p_ufs_l4_data_dir);

  final begin : sva_report
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("UFS_RPT", "=== UFS Tiered SVA Report ===", UVM_LOW)
    `uvm_info("UFS_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("UFS_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("UFS_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("UFS_RPT", $sformatf("  L4 Protocol Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("UFS_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
