// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ufs_timing_checker.sv -- UFS Timing Compliance Checker (module form)
// Validates request/response and ready-to-transfer latency bounds
`ifndef UFS_TIMING_CHECKER_SV
`define UFS_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ufs_timing_checker (ufs_if vif);
  property p_ufs_transfer_ready; @(posedge vif.ref_clk) disable iff (!vif.rst_n) ($rose(vif.req_valid) && vif.cmd_type == 4'h1 && vif.req_data == 8'h2A) |-> ##[1:64] (vif.transfer_ready == 1 || vif.resp_valid == 1); endproperty
  assert_p_ufs_transfer_ready: assert property(p_ufs_transfer_ready) else `uvm_warning("UFS_TIM", "Transfer ready violated");
  cover_p_ufs_transfer_ready: cover property(p_ufs_transfer_ready);
  property p_ufs_resp_latency; @(posedge vif.ref_clk) disable iff (!vif.rst_n) $rose(vif.req_valid) |-> ##[1:16384] vif.resp_valid == 1; endproperty
  assert_p_ufs_resp_latency: assert property(p_ufs_resp_latency) else `uvm_warning("UFS_TIM", "Response latency violated");
  cover_p_ufs_resp_latency: cover property(p_ufs_resp_latency);
  property p_ufs_rtt_burst; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.transfer_ready == 1 |-> vif.data_in_valid == 1; endproperty
  assert_p_ufs_rtt_burst: assert property(p_ufs_rtt_burst) else `uvm_warning("UFS_TIM", "RTT not accompanied by UPIU burst violated");
  cover_p_ufs_rtt_burst: cover property(p_ufs_rtt_burst);
endmodule
`endif
