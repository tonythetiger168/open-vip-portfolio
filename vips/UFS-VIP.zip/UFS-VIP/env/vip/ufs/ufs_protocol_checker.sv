// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ufs_protocol_checker.sv -- UFS Protocol Compliance Checker (module form)
// Validates protocol state machine, field ranges, and command sequences
`ifndef UFS_PROTOCOL_CHECKER_SV
`define UFS_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ufs_protocol_checker (ufs_if vif);
  property p_ufs_task_tag; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.task_tag <= 8'd255; endproperty
  assert_p_ufs_task_tag: assert property(p_ufs_task_tag) else `uvm_warning("UFS_CHK", "Task tag valid failed");
  cover_p_ufs_task_tag: cover property(p_ufs_task_tag);
  property p_ufs_lun_id; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.lun_id <= 8'd7; endproperty
  assert_p_ufs_lun_id: assert property(p_ufs_lun_id) else `uvm_warning("UFS_CHK", "LUN ID valid failed");
  cover_p_ufs_lun_id: cover property(p_ufs_lun_id);
  property p_ufs_data_dir; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.data_dir inside {2'b00,2'b01,2'b10,2'b11}; endproperty
  assert_p_ufs_data_dir: assert property(p_ufs_data_dir) else `uvm_warning("UFS_CHK", "Data direction valid failed");
  cover_p_ufs_data_dir: cover property(p_ufs_data_dir);
  property p_ufs_resp_status; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.resp_valid |-> vif.resp_status inside {3'b000,3'b001,3'b010,3'b011,3'b100,3'b101,3'b110,3'b111}; endproperty
  assert_p_ufs_resp_status: assert property(p_ufs_resp_status) else `uvm_warning("UFS_CHK", "Response status valid failed");
  cover_p_ufs_resp_status: cover property(p_ufs_resp_status);
endmodule
`endif
