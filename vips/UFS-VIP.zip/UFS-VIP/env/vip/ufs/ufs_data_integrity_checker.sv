// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ufs_data_integrity_checker.sv -- UFS Data-Integrity Compliance Checker (module form)
// Validates doorbell semantics, command typing, and payload integrity
`ifndef UFS_DATA_INTEGRITY_CHECKER_SV
`define UFS_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ufs_data_integrity_checker (ufs_if vif);
  property p_ufs_cmd_type; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.cmd_type <= 8'd255; endproperty
  assert_p_ufs_cmd_type: assert property(p_ufs_cmd_type) else `uvm_warning("UFS_DI", "Command type valid failed");
  cover_p_ufs_cmd_type: cover property(p_ufs_cmd_type);
  property p_ufs_doorbell; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.doorbell == 1 |-> vif.task_tag <= 8'd255; endproperty
  assert_p_ufs_doorbell: assert property(p_ufs_doorbell) else `uvm_warning("UFS_DI", "Doorbell valid failed");
  cover_p_ufs_doorbell: cover property(p_ufs_doorbell);
  property p_ufs_payload_known; @(posedge vif.ref_clk) disable iff (!vif.rst_n) (vif.data_out_valid == 1 && vif.req_valid == 0) |-> !$isunknown(vif.data_out); endproperty
  assert_p_ufs_payload_known: assert property(p_ufs_payload_known) else `uvm_warning("UFS_DI", "Write payload has X failed");
  cover_p_ufs_payload_known: cover property(p_ufs_payload_known);
  property p_ufs_len_stable; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.busy == 1 |-> $stable(vif.data_length); endproperty
  assert_p_ufs_len_stable: assert property(p_ufs_len_stable) else `uvm_warning("UFS_DI", "Data length changed mid-transfer failed");
  cover_p_ufs_len_stable: cover property(p_ufs_len_stable);
endmodule
`endif
