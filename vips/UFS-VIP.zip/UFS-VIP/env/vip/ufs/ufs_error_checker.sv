// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// ufs_error_checker.sv -- UFS Error-Handling Compliance Checker (module form)
// Validates error detection, error status reporting, and abort behavior
`ifndef UFS_ERROR_CHECKER_SV
`define UFS_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module ufs_error_checker (ufs_if vif);
  property p_ufs_no_x; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.req_valid == 1 |-> !$isunknown(vif.req_data); endproperty
  assert_p_ufs_no_x: assert property(p_ufs_no_x) else `uvm_warning("UFS_ERR", "No X when valid failed");
  cover_p_ufs_no_x: cover property(p_ufs_no_x);
  property p_ufs_error_abort; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.resp_status == 3'b111 |-> vif.transfer_ready == 0; endproperty
  assert_p_ufs_error_abort: assert property(p_ufs_error_abort) else `uvm_warning("UFS_ERR", "Error abort failed");
  cover_p_ufs_error_abort: cover property(p_ufs_error_abort);
  property p_ufs_err_reject; @(posedge vif.ref_clk) disable iff (!vif.rst_n) vif.err == 1 |-> ##[0:8] vif.resp_valid == 1; endproperty
  assert_p_ufs_err_reject: assert property(p_ufs_err_reject) else `uvm_warning("UFS_ERR", "Error without response/reject failed");
  cover_p_ufs_err_reject: cover property(p_ufs_err_reject);
endmodule
`endif
