# UFS UVM Verification IP (VIP)

Universal Flash Storage (UFS) host-side UVM VIP with a functional UFS device
DUT model, end-to-end scoreboard, tiered SVA compliance checkers, and
functional coverage. Part of the memory/storage protocol VIP framework
(`memory_*_pkg` shared environment, 8 protocols).

## Protocol Overview

UFS transports SCSI commands inside UPIUs (UFS Protocol Information Units)
over a UTP (UFS Transport Protocol) layer with a doorbell-based command queue:

- **Host -> device**: UTP doorbell + 10-byte UPIU header
  `{type, lun, task_tag, opcode, lba[31:0], len[15:0]}` followed by an optional
  write data phase (gated by the device READY_XFER / RTT UPIU).
- **Device -> host**: READY_XFER burst (`0x31`), DATA_IN burst (read data),
  and a 3-byte response trailer `{resp_type, task_tag, status}`.
- UPIU types: NOP_OUT/IN, COMMAND, DATA_OUT/IN, TASK_MGT(+RSP),
  QUERY_REQ/RSP, READY_XFER, REJECT.
- SCSI opcodes modeled: TEST UNIT READY (`0x00`), REQUEST SENSE (`0x03`),
  INQUIRY (`0x12`), READ(10) (`0x28`), WRITE(10) (`0x2A`).
- Error behavior: out-of-capacity LBA, reserved opcode, or LUN > 7 returns
  CHECK CONDITION (`0x02`) with no data phase.

## Architecture

```
memory_test_pkg (tests)
  -> memory_env_pkg (memory_env + memory_scoreboard: UFS exp/obs e2e compare)
    -> ufs_pkg: ufs_agent { ufs_sequencer, ufs_driver (drv_ap), ufs_monitor }
    -> memory_coverage_pkg: ufs_coverage (3 covergroups)
ufs_if (interfaces/memory_interfaces.sv) -- byte-serial UTP link + sideband
ufs_device_dut (tb_top.sv) -- 1 MiB block memory + UPIU FSM (functional DUT)
env/sva/ufs_compliance_checker.sv + env/vip/ufs/*.sv -- SVA checker modules
```

Closed loop: driver publishes expected items on `drv_ap`; the monitor decodes
both link directions from the waveform; `memory_scoreboard` compares
host-initiated UPIUs (`ufs_n_matches` / `ufs_n_mismatches`, mismatch ->
`UVM_ERROR`).

## Sequence List (ufs_pkg)

| Sequence | Kind | Description |
|---|---|---|
| `ufs_base_seq` | base | helpers (`send`, `send_cmd`) |
| `ufs_rw_seq` | normal | random READ(10)/WRITE(10) mix |
| `ufs_read_seq` | directed | READ(10) block reads |
| `ufs_write_seq` | directed | WRITE(10) block writes |
| `ufs_query_seq` | directed | QUERY_REQ (INQUIRY/TUR/REQ SENSE) |
| `ufs_error_seq` | error | out-of-capacity LBA + reserved opcode |
| `ufs_reset_seq` | reset | TASK_MGT abort/LU-reset + recovery read |
| `ufs_b2b_seq` | back-to-back | zero idle cycles between transfers |
| `ufs_stress_seq` | stress | heavy random traffic, all LUNs |
| `ufs_corner_seq` | corner | LBA 0/last block, min/max length, edge LUNs |
| `ufs_cov_upiu_seq` | coverage | all 12 UPIU types |
| `ufs_cov_lun_seq` | coverage | COMMAND to LUN 0-7 |
| `ufs_regression_mix_seq` | regression | runs all directed sequences in order |

Tests (`memory_test_pkg`): `memory_base_test`,
`memory_coverage_regression_test`, `memory_random_test`, `ufs_regression_test`,
`ufs_read_write_test`, `ufs_error_test`, `ufs_reset_test`, `ufs_b2b_test`,
`ufs_corner_test`, `ufs_stress_test`.

## SVA Compliance (env/sva/ufs_compliance_checker.sv)

- **L1 Basic (4)**: cmd/addr/data valid, no-X when active
- **L2 Full Protocol (4)**: transfer-ready, response latency, task tag, LUN id
- **L3 Advanced (4)**: error recovery, timeout, status class, power state
- **L4 UFS-specific (6)**: legal UPIU type at doorbell, RTT-before-write-data,
  response-after-command, task-tag stable during transfer, error implies
  CHECK CONDITION, device data direction ownership

Additional checker modules in `env/vip/ufs/`: `ufs_protocol_checker`,
`ufs_error_checker`, `ufs_timing_checker`, `ufs_data_integrity_checker`
(all instantiated in `tb_top.sv`).

## Functional Coverage (memory_coverage_pkg::ufs_coverage)

1. `ufs_cg` — protocol config: UPIU type x LUN (cross), SCSI opcode
2. `ufs_fsm_cg` — UPIU exchange FSM transitions (CMD->RTT->RSP,
   CMD->DATA_IN->RSP, QRY->QRSP, TM->TMRSP) x LUN (cross)
3. `ufs_data_cg` — data phase: transfer length x LBA region (cross), status

## Quick Start

```sh
cd scripts
make compile elaborate run TEST=ufs_regression_test SIMULATOR=vcs
make regression                       # coverage-driven regression
# or directly:
./run.sh                              # TESTNAME=ufs_regression_test ...
```

Parse-check any file with pyslang 11 (UVM macro stub required on the
include path); all VIP sources parse with 0 syntax errors.
