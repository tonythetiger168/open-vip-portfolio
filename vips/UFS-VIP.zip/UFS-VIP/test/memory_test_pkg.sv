// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// memory_test_pkg.sv -- 8-protocol test package (UFS-deepened)
`ifndef MEMORY_TEST_PKG_SV
`define MEMORY_TEST_PKG_SV
package memory_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import ddr_pkg::*; import lpddr_pkg::*; import hbm_pkg::*;
  import ufs_pkg::*; import unipro_pkg::*; import emmc_pkg::*;
  import onfi_pkg::*; import sd_pkg::*;
  import memory_env_pkg::*;

  class memory_base_test extends uvm_test;
    `uvm_component_utils(memory_base_test)
    memory_env env;
    memory_env_cfg env_cfg;
    int random_seed;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env_cfg = memory_env_cfg::type_id::create("env_cfg");
      env_cfg.coverage_enable = 1; env_cfg.scoreboard_enable = 1;
      env = memory_env::type_id::create("env", this);
      uvm_config_db#(memory_env_cfg)::set(this, "env", "cfg", env_cfg);
      if (!$value$plusargs("ntb_random_seed=%d", random_seed)) random_seed = $urandom;
      $srandom(random_seed);
    endfunction
    function void report_phase(uvm_phase phase);
      uvm_report_server server = uvm_report_server::get_server();
      int err_count = server.get_severity_count(UVM_ERROR);
      `uvm_info(get_type_name(), $sformatf("Seed: %0d | Errors: %0d", random_seed, err_count), UVM_LOW)
      if (err_count == 0) `uvm_info(get_type_name(), "TEST PASSED", UVM_LOW)
      else `uvm_error(get_type_name(), $sformatf("TEST FAILED with %0d errors", err_count))
    endfunction
  endclass

  // Coverage-driven regression across all 8 protocols (plus UFS directed mix)
  class memory_coverage_regression_test extends memory_base_test;
    `uvm_component_utils(memory_coverage_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      phase.raise_objection(this);
      `uvm_info(get_type_name(), "[1/9] DDR Coverage Sequences", UVM_LOW)
      begin ddr_cov_cmd_seq seq = new(); seq.start(env.ddr_ag.sqr); end
      begin ddr_cov_bank_seq seq = new(); seq.start(env.ddr_ag.sqr); end
      begin ddr_cov_bl_seq seq = new(); seq.start(env.ddr_ag.sqr); end
      begin ddr_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_ddr; seq.start(env.ddr_ag.sqr); end
      `uvm_info(get_type_name(), "[2/9] LPDDR Coverage Sequences", UVM_LOW)
      begin lpddr_cov_cmd_seq seq = new(); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_cov_bank_seq seq = new(); seq.start(env.lpddr_ag.sqr); end
      begin lpddr_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_lpddr; seq.start(env.lpddr_ag.sqr); end
      `uvm_info(get_type_name(), "[3/9] HBM Coverage Sequences", UVM_LOW)
      begin hbm_cov_cmd_seq seq = new(); seq.start(env.hbm_ag.sqr); end
      begin hbm_cov_ch_seq seq = new(); seq.start(env.hbm_ag.sqr); end
      begin hbm_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_hbm; seq.start(env.hbm_ag.sqr); end
      `uvm_info(get_type_name(), "[4/9] UFS Coverage Sequences", UVM_LOW)
      begin ufs_cov_upiu_seq seq = new(); seq.start(env.ufs_ag.sqr); end
      begin ufs_cov_lun_seq seq = new(); seq.start(env.ufs_ag.sqr); end
      begin ufs_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_ufs; seq.start(env.ufs_ag.sqr); end
      `uvm_info(get_type_name(), "[5/9] UniPro Coverage Sequences", UVM_LOW)
      begin unipro_cov_msg_seq seq = new(); seq.start(env.unipro_ag.sqr); end
      begin unipro_cov_cport_seq seq = new(); seq.start(env.unipro_ag.sqr); end
      begin unipro_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_unipro; seq.start(env.unipro_ag.sqr); end
      `uvm_info(get_type_name(), "[6/9] eMMC Coverage Sequences", UVM_LOW)
      begin emmc_cov_cmd_seq seq = new(); seq.start(env.emmc_ag.sqr); end
      begin emmc_cov_bw_seq seq = new(); seq.start(env.emmc_ag.sqr); end
      begin emmc_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_emmc; seq.start(env.emmc_ag.sqr); end
      `uvm_info(get_type_name(), "[7/9] ONFI Coverage Sequences", UVM_LOW)
      begin onfi_cov_cmd_seq seq = new(); seq.start(env.onfi_ag.sqr); end
      begin onfi_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_onfi; seq.start(env.onfi_ag.sqr); end
      `uvm_info(get_type_name(), "[8/9] SD Coverage Sequences", UVM_LOW)
      begin sd_cov_cmd_seq seq = new(); seq.start(env.sd_ag.sqr); end
      begin sd_rw_seq seq = new("seq"); seq.num_trans = env_cfg.num_sd; seq.start(env.sd_ag.sqr); end
      `uvm_info(get_type_name(), "[9/9] UFS Directed Regression Mix", UVM_LOW)
      begin ufs_regression_mix_seq seq = new(); seq.start(env.ufs_ag.sqr); end
      #1000;
      `uvm_info(get_type_name(), "==========================================", UVM_NONE)
      phase.drop_objection(this);
    endtask
  endclass

  // All-protocol random smoke test (concurrent)
  class memory_random_test extends memory_base_test;
    `uvm_component_utils(memory_random_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      ddr_rw_seq    ddr_seq    = new("ddr_seq");
      lpddr_rw_seq  lpddr_seq  = new("lpddr_seq");
      hbm_rw_seq    hbm_seq    = new("hbm_seq");
      ufs_rw_seq    ufs_seq    = new("ufs_seq");
      unipro_rw_seq unipro_seq = new("unipro_seq");
      emmc_rw_seq   emmc_seq   = new("emmc_seq");
      onfi_rw_seq   onfi_seq   = new("onfi_seq");
      sd_rw_seq     sd_seq     = new("sd_seq");
      phase.raise_objection(this);
      fork
        ddr_seq.start(env.ddr_ag.sqr);
        lpddr_seq.start(env.lpddr_ag.sqr);
        hbm_seq.start(env.hbm_ag.sqr);
        ufs_seq.start(env.ufs_ag.sqr);
        unipro_seq.start(env.unipro_ag.sqr);
        emmc_seq.start(env.emmc_ag.sqr);
        onfi_seq.start(env.onfi_ag.sqr);
        sd_seq.start(env.sd_ag.sqr);
      join
      #1000;
      phase.drop_objection(this);
    endtask
  endclass

  // ---- UFS directed tests ----
  class ufs_regression_test extends memory_base_test;
    `uvm_component_utils(ufs_regression_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      ufs_regression_mix_seq seq = new();
      phase.raise_objection(this);
      seq.start(env.ufs_ag.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  class ufs_read_write_test extends memory_base_test;
    `uvm_component_utils(ufs_read_write_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      ufs_write_seq w = new();
      ufs_read_seq  r = new();
      phase.raise_objection(this);
      w.num_trans = 8; w.start(env.ufs_ag.sqr);
      r.num_trans = 8; r.start(env.ufs_ag.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  class ufs_error_test extends memory_base_test;
    `uvm_component_utils(ufs_error_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      ufs_error_seq seq = new();
      phase.raise_objection(this);
      seq.num_trans = 8;
      seq.start(env.ufs_ag.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  class ufs_reset_test extends memory_base_test;
    `uvm_component_utils(ufs_reset_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      ufs_reset_seq seq = new();
      ufs_rw_seq    rw  = new("rw");
      phase.raise_objection(this);
      seq.start(env.ufs_ag.sqr);
      rw.num_trans = 4;
      rw.start(env.ufs_ag.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  class ufs_b2b_test extends memory_base_test;
    `uvm_component_utils(ufs_b2b_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      ufs_b2b_seq seq = new();
      phase.raise_objection(this);
      seq.num_trans = 16;
      seq.start(env.ufs_ag.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  class ufs_corner_test extends memory_base_test;
    `uvm_component_utils(ufs_corner_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      ufs_corner_seq seq = new();
      phase.raise_objection(this);
      seq.start(env.ufs_ag.sqr);
      #2000;
      phase.drop_objection(this);
    endtask
  endclass

  class ufs_stress_test extends memory_base_test;
    `uvm_component_utils(ufs_stress_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction
    virtual task run_phase(uvm_phase phase);
      ufs_stress_seq seq = new();
      phase.raise_objection(this);
      seq.num_trans = 30;
      seq.start(env.ufs_ag.sqr);
      #5000;
      phase.drop_objection(this);
    endtask
  endclass
endpackage : memory_test_pkg
`endif
