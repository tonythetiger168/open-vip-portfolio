// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_ufs_tb.sv -- self-checking functional test for the UFS device model
// (ufs_device_dut in tb_top.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py UFS-VIP
//
// Model contract (from tb_top.sv), byte stream on data_out/data_in:
//   * request header, 10 bytes: UPIU transaction type, LUN, task tag, SCSI
//     opcode, LBA (4 bytes, MSB first), data length in bytes (2, MSB first).
//   * the device answers with a 3-byte response: type (NOP OUT 00 -> NOP IN
//     20, COMMAND 01 -> RESPONSE 21, TASK MGMT 04 -> 24, QUERY 16 -> 36,
//     other -> REJECT 3F), the task tag, and SCSI status (00 GOOD, 02 CHECK
//     CONDITION); resp_valid marks it, resp_status is 001 good / 010 error.
//   * errors: LUN > 7, a COMMAND with an opcode other than TEST UNIT READY
//     00, REQUEST SENSE 03, INQUIRY 12, READ(10) 28, WRITE(10) 2A, or
//     LBA*512 + length beyond the 1 MiB capacity (err, CHECK CONDITION).
//   * WRITE(10): the device sends READY TO TRANSFER (0x31, transfer_ready),
//     takes 'length' data bytes into LBA*512 onward, then responds.
//   * READ(10): 'length' bytes from LBA*512 onward, then the response.
//     Unwritten memory holds (address[7:0] ^ 0x5A).

module func_ufs_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic       clk = 1'b0, rst_n = 1'b0, out_valid = 1'b0;
  logic [7:0] dout = '0;
  wire  [7:0] din;
  wire        din_valid, xfer_rdy, ready, busy, err, resp_valid;
  wire  [1:0] dir;
  wire  [2:0] status, pwr, resp_status;

  always #5 clk = ~clk;

  ufs_device_dut u_dut (
    .vif_ref_clk(clk), .vif_rst_n(rst_n), .vif_data_out(dout), .vif_data_out_valid(out_valid),
    .vif_data_in(din), .vif_data_in_valid(din_valid), .vif_transfer_ready(xfer_rdy),
    .vif_ready(ready), .vif_busy(busy), .vif_err(err), .vif_data_dir(dir), .vif_status(status),
    .vif_power_state(pwr), .vif_resp_valid(resp_valid), .vif_resp_status(resp_status)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // device -> host stream: data bytes and response bytes kept apart
  logic [7:0] rdata[$], resp[$];
  logic [2:0] rstat[$];
  int         rtt_seen, err_seen;
  always @(posedge clk) if (rst_n && din_valid === 1'b1) begin
    if (resp_valid) begin resp.push_back(din); rstat.push_back(resp_status); end
    else if (xfer_rdy) rtt_seen++;
    else rdata.push_back(din);
  end
  always @(posedge clk) if (err === 1'b1) err_seen = 1;

  task automatic send_bytes(input logic [7:0] b[$]);
    foreach (b[i]) begin @(negedge clk); out_valid = 1; dout = b[i]; end
    @(negedge clk); out_valid = 0;
  endtask

  task automatic request(input [7:0] typ, input [7:0] lun, input [7:0] tag, input [7:0] op,
                         input [31:0] lba, input [15:0] len);
    rdata.delete(); resp.delete(); rstat.delete(); rtt_seen = 0; err_seen = 0;
    send_bytes('{typ, lun, tag, op, lba[31:24], lba[23:16], lba[15:8], lba[7:0], len[15:8], len[7:0]});
  endtask

  task automatic wait_resp();
    int t = 0;
    while (resp.size() < 3 && t < 3000) begin @(negedge clk); t++; end
    @(negedge clk);
  endtask

  function automatic bit resp_is(input [7:0] typ, input [7:0] tag, input [7:0] st);
    return resp.size() == 3 && resp[0] == typ && resp[1] == tag && resp[2] == st;
  endfunction

  logic [7:0] wbuf[$];
  bit ok;

  initial begin
    repeat (2) @(negedge clk);
    rst_n = 1;
    repeat (2) @(negedge clk);
    chk(ready && !busy && pwr == 3'b001, "idle and ready, power state active");

    // NOP OUT / NOP IN
    request(8'h00, 0, 8'h11, 8'h00, 0, 0);
    @(negedge clk);
    chk(busy && !ready, "busy while handling a request");
    wait_resp();
    chk(resp_is(8'h20, 8'h11, 8'h00), "NOP OUT answered by NOP IN with the tag");
    chk(rstat[0] == 3'b001 && !err_seen, "good response status");
    chk(ready && !busy, "ready again after the response");

    // other UPIU types
    request(8'h16, 0, 8'h12, 8'h00, 0, 0); wait_resp();
    chk(resp_is(8'h36, 8'h12, 8'h00), "QUERY REQUEST answered by QUERY RESPONSE");
    request(8'h04, 0, 8'h13, 8'h00, 0, 0); wait_resp();
    chk(resp_is(8'h24, 8'h13, 8'h00), "TASK MANAGEMENT REQUEST answered");
    request(8'h09, 0, 8'h14, 8'h00, 0, 0); wait_resp();
    chk(resp_is(8'h3F, 8'h14, 8'h00), "unknown transaction type answered by REJECT UPIU");

    // non-data SCSI commands
    request(8'h01, 0, 8'h20, 8'h00, 0, 0); wait_resp();
    chk(resp_is(8'h21, 8'h20, 8'h00) && rdata.size() == 0, "TEST UNIT READY: GOOD, no data");
    request(8'h01, 3, 8'h21, 8'h12, 0, 0); wait_resp();
    chk(resp_is(8'h21, 8'h21, 8'h00), "INQUIRY on LUN 3: GOOD");

    // READ(10) of unwritten memory
    request(8'h01, 0, 8'h30, 8'h28, 32'd5, 16'd16); wait_resp();
    ok = rdata.size() == 16;
    foreach (rdata[i]) if (rdata[i] != (((5 * 512 + i) & 8'hFF) ^ 8'h5A)) ok = 0;
    chk(ok, $sformatf("READ(10) returns the initial pattern (%0d bytes)", rdata.size()));
    chk(resp_is(8'h21, 8'h30, 8'h00), "READ(10) completes with GOOD");

    // WRITE(10) then READ(10)
    wbuf.delete();
    for (int i = 0; i < 40; i++) wbuf.push_back(8'hA0 ^ (i * 7));
    request(8'h01, 0, 8'h40, 8'h2A, 32'd100, 16'd40);
    begin
      int t = 0;
      while (rtt_seen == 0 && t < 50) begin @(negedge clk); t++; end
    end
    chk(rtt_seen == 1, "WRITE(10): READY TO TRANSFER sent");
    chk(resp.size() == 0, "no response before the data phase");
    send_bytes(wbuf);
    wait_resp();
    chk(resp_is(8'h21, 8'h40, 8'h00), "WRITE(10) completes with GOOD after the data");
    request(8'h01, 0, 8'h41, 8'h28, 32'd100, 16'd40); wait_resp();
    ok = rdata.size() == 40;
    foreach (rdata[i]) if (rdata[i] != wbuf[i]) ok = 0;
    chk(ok, "written data read back");
    request(8'h01, 0, 8'h42, 8'h28, 32'd100, 16'd44); wait_resp();
    chk(rdata.size() == 44 && rdata[39] == wbuf[39] && rdata[40] == (((100 * 512 + 40) & 8'hFF) ^ 8'h5A),
        "write did not spill past its length");

    // last block of the device is reachable
    request(8'h01, 0, 8'h43, 8'h28, 32'd2047, 16'd512); wait_resp();
    chk(resp_is(8'h21, 8'h43, 8'h00) && rdata.size() == 512, "read of the last 512 bytes is in range");

    // errors
    request(8'h01, 0, 8'h50, 8'h28, 32'd2047, 16'd513); wait_resp();
    chk(resp_is(8'h21, 8'h50, 8'h02) && err_seen && rdata.size() == 0, "read past capacity: CHECK CONDITION, no data");
    chk(rstat[0] == 3'b010, "error response status");
    request(8'h01, 0, 8'h51, 8'h2A, 32'd4096, 16'd8); wait_resp();
    chk(resp_is(8'h21, 8'h51, 8'h02) && rtt_seen == 0, "write past capacity rejected without READY TO TRANSFER");
    request(8'h01, 8, 8'h52, 8'h00, 0, 0); wait_resp();
    chk(resp_is(8'h21, 8'h52, 8'h02) && err_seen, "LUN 8 rejected");
    request(8'h01, 0, 8'h53, 8'h35, 0, 0); wait_resp();
    chk(resp_is(8'h21, 8'h53, 8'h02), "unsupported SCSI opcode rejected");
    request(8'h00, 0, 8'h54, 8'h35, 0, 0); wait_resp();
    chk(resp_is(8'h20, 8'h54, 8'h00), "opcode not checked for NOP OUT");
    chk(u_dut.err_cnt == 4, "error counter");

    // tag echo across many requests
    ok = 1;
    for (int t = 0; t < 8; t++) begin
      request(8'h00, 0, 8'hE0 + t, 0, 0, 0); wait_resp();
      if (!resp_is(8'h20, 8'hE0 + t, 8'h00)) ok = 0;
    end
    chk(ok, "task tag echoed for each request");

    // reset in the middle of a read
    request(8'h01, 0, 8'h60, 8'h28, 0, 16'd200);
    repeat (20) @(negedge clk);
    rst_n = 0;
    @(negedge clk);
    chk(!din_valid && !busy && !resp_valid && pwr == 0, "reset aborts the read");
    rst_n = 1;
    repeat (2) @(negedge clk);
    request(8'h00, 0, 8'h61, 0, 0, 0); wait_resp();
    chk(resp_is(8'h20, 8'h61, 8'h00), "device works after reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #1000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
