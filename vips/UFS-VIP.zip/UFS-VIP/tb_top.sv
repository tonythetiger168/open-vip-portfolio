// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// tb_top.sv -- 8-protocol top-level testbench (UFS-deepened)
// Closed loop: UFS VIP driver -> ufs_if -> functional UFS device DUT -> UFS monitor
`timescale 1ns/1ps
`ifndef TB_TOP_SV
`define TB_TOP_SV
import uvm_pkg::*;
`include "uvm_macros.svh"
import memory_test_pkg::*;

module tb_top;
  logic ddr_ck = 0, ddr_rst_n = 0;
  logic lpddr_ck = 0, lpddr_rst_n = 0;
  logic hbm_ck = 0, hbm_rst_n = 0;
  logic ufs_clk = 0, ufs_rst_n = 0;
  logic unipro_clk = 0, unipro_rst_n = 0;
  logic emmc_clk = 0, emmc_rst_n = 0;
  logic onfi_clk = 0, onfi_rst_n = 0;
  logic sd_clk = 0, sd_rst_n = 0;
  always #5 ddr_ck = ~ddr_ck;
  always #5 lpddr_ck = ~lpddr_ck;
  always #5 hbm_ck = ~hbm_ck;
  always #10 ufs_clk = ~ufs_clk;
  always #10 unipro_clk = ~unipro_clk;
  always #20 emmc_clk = ~emmc_clk;
  always #50 onfi_clk = ~onfi_clk;
  always #20 sd_clk = ~sd_clk;
  initial begin
    #100;
    ddr_rst_n = 1; lpddr_rst_n = 1; hbm_rst_n = 1; ufs_rst_n = 1;
    unipro_rst_n = 1; emmc_rst_n = 1; onfi_rst_n = 1; sd_rst_n = 1;
  end

  ddr_if    ddr_if_inst    (.ck(ddr_ck), .ck_n(~ddr_ck), .rst_n(ddr_rst_n));
  lpddr_if  lpddr_if_inst  (.ck(lpddr_ck), .ck_n(~lpddr_ck), .cke(1'b1), .rst_n(lpddr_rst_n));
  hbm_if    hbm_if_inst    (.ck(hbm_ck), .ck_n(~hbm_ck), .rst_n(hbm_rst_n));
  ufs_if    ufs_if_inst    (.ref_clk(ufs_clk), .rst_n(ufs_rst_n));
  unipro_if unipro_if_inst (.clk(unipro_clk), .rst_n(unipro_rst_n));
  emmc_if   emmc_if_inst   (.clk(emmc_clk), .rst_n(emmc_rst_n));
  onfi_if   onfi_if_inst   (.clk(onfi_clk), .rst_n(onfi_rst_n));
  sd_if     sd_if_inst     (.clk(sd_clk), .rst_n(sd_rst_n));

  // functional DUT models (closed loop)
  unipro_endpoint_dut unipro_ep (.vif(unipro_if_inst));
  emmc_device_dut     emmc_dev  (.vif(emmc_if_inst));
  onfi_flash_dut      onfi_dev  (.vif(onfi_if_inst));
  ufs_device_dut      ufs_dev   (.vif(ufs_if_inst));

  // UFS tiered SVA compliance checkers (L1-L4) bound to the live interface
  ufs_compliance_checker      ufs_sva      (.vif(ufs_if_inst));
  ufs_protocol_checker        ufs_proto    (.vif(ufs_if_inst));
  ufs_error_checker           ufs_err      (.vif(ufs_if_inst));
  ufs_timing_checker          ufs_timing   (.vif(ufs_if_inst));
  ufs_data_integrity_checker  ufs_dint     (.vif(ufs_if_inst));

  initial begin
    uvm_config_db#(virtual ddr_if)::set(null, "*.ddr_*", "vif", ddr_if_inst);
    uvm_config_db#(virtual lpddr_if)::set(null, "*.lpddr_*", "vif", lpddr_if_inst);
    uvm_config_db#(virtual hbm_if)::set(null, "*.hbm_*", "vif", hbm_if_inst);
    uvm_config_db#(virtual ufs_if)::set(null, "*.ufs_*", "vif", ufs_if_inst);
    uvm_config_db#(virtual unipro_if)::set(null, "*.unipro_*", "vif", unipro_if_inst);
    uvm_config_db#(virtual emmc_if)::set(null, "*.emmc_*", "vif", emmc_if_inst);
    uvm_config_db#(virtual onfi_if)::set(null, "*.onfi_*", "vif", onfi_if_inst);
    uvm_config_db#(virtual sd_if)::set(null, "*.sd_*", "vif", sd_if_inst);
    run_test();
  end
endmodule

//--------------------------------------------------------------------------
// Functional UniPro endpoint DUT model:
//  - returns L2 credits on reception (credit-based flow control)
//  - echoes received data back on the RX path (loopback)
//  - flags 0xFF frames as errors (error-injection detection)
//--------------------------------------------------------------------------
module unipro_endpoint_dut (unipro_if vif);
  int unsigned rx_frames = 0;
  int unsigned err_frames = 0;
  always_ff @(posedge vif.clk or negedge vif.rst_n) begin : ep
    if (!vif.rst_n) begin : rst
      vif.rx_data <= 0; vif.rx_data_valid <= 0;
      vif.rx_cred <= 0; vif.rx_cred_valid <= 0;
    end else begin : run
      vif.rx_data_valid <= #1ns vif.tx_data_valid;
      vif.rx_data <= #1ns vif.tx_data;
      vif.rx_cred_valid <= #1ns (vif.tx_data_valid || vif.tx_cred_valid);
      vif.rx_cred <= #1ns vif.tx_cred + 8'd1;
      if (vif.tx_data_valid) rx_frames <= rx_frames + 1;
    end
  end
  final begin : rpt
    `uvm_info("UNIPRO_EP", $sformatf("endpoint: rx_frames=%0d err_frames=%0d", rx_frames, err_frames), UVM_LOW)
  end
endmodule

// eMMC device model: response + busy handshake
module emmc_device_dut (emmc_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) begin
      vif.resp <= 0; vif.resp_valid <= 0; vif.busy <= 0;
    end else begin
      vif.resp_valid <= #1ns vif.cmd_valid;
      vif.resp <= #1ns vif.cmd;
      vif.busy <= #1ns 1'b0;
    end
endmodule

// ONFI flash model: ready/busy handshake
module onfi_flash_dut (onfi_if vif);
  always_ff @(posedge vif.clk or negedge vif.rst_n)
    if (!vif.rst_n) vif.rb_n <= 1'b1;
    else            vif.rb_n <= #1ns 1'b1;
endmodule

//--------------------------------------------------------------------------
// Functional UFS device DUT model
//  - 1 MiB block memory (2048 blocks x 512 B), byte addressable via LBA
//  - UPIU header decode (type/lun/tag/opcode/lba/len) with UTP doorbell concept
//  - WRITE_10: READY_XFER (RTT) -> data phase -> RESPONSE
//  - READ_10:  DATA_IN burst -> RESPONSE
//  - QUERY_REQ/TASK_MGT/NOP_OUT: response-only exchanges
//  - out-of-capacity LBA / reserved opcode / bad LUN -> CHECK CONDITION, no data phase
//  - device state machine: IDLE -> HDR -> DECODE -> WRTT/WDATA/RDATA -> GAP -> RESP
//--------------------------------------------------------------------------
module ufs_device_dut (ufs_if vif);
  localparam int BLK = 512;
  localparam int CAP_BLOCKS = 2048;
  localparam int CAP_BYTES = BLK * CAP_BLOCKS;
  bit [7:0] mem [0:CAP_BYTES-1];
  typedef enum logic [3:0] {D_IDLE, D_HDR, D_DECODE, D_WRTT, D_WDATA, D_RDATA, D_GAP, D_RESP} dstate_e;
  dstate_e st;
  bit [7:0] hdr [0:9];
  int hdr_cnt, data_cnt, resp_cnt;
  bit [7:0] tag, opcode, dlun, upiu;
  bit [31:0] lba;
  bit [15:0] dlen;
  bit [7:0] resp_type, resp_status_b;
  bit bad;
  int unsigned cmd_cnt = 0, err_cnt = 0;

  initial for (int i = 0; i < CAP_BYTES; i++) mem[i] = i[7:0] ^ 8'h5A;

  function automatic bit [7:0] resp_type_for(bit [7:0] t);
    case (t)
      8'h00:   return 8'h20; // NOP_OUT   -> NOP_IN
      8'h01:   return 8'h21; // COMMAND   -> RESPONSE
      8'h04:   return 8'h24; // TASK_MGT  -> TASK_MGT_RSP
      8'h16:   return 8'h36; // QUERY_REQ -> QUERY_RSP
      default: return 8'h3F; //           -> REJECT
    endcase
  endfunction

  function automatic bit scsi_known(bit [7:0] op);
    return op inside {8'h00, 8'h03, 8'h12, 8'h28, 8'h2A};
  endfunction

  always_ff @(posedge vif.ref_clk or negedge vif.rst_n) begin : dev
    if (!vif.rst_n) begin : rst
      st <= D_IDLE; hdr_cnt <= 0; data_cnt <= 0; resp_cnt <= 0;
      vif.data_in <= 0; vif.data_in_valid <= 0;
      vif.transfer_ready <= 0; vif.ready <= 0; vif.busy <= 0; vif.err <= 0;
      vif.data_dir <= 2'b00; vif.status <= 3'b000; vif.power_state <= 3'b000;
      vif.resp_valid <= 0; vif.resp_status <= 3'b000;
    end else begin : run
      vif.data_in_valid <= 1'b0;   // default: silent device->host link
      vif.resp_valid    <= 1'b0;
      vif.power_state   <= 3'b001; // active power mode
      case (st)
        D_IDLE: begin
          vif.busy <= 1'b0; vif.data_dir <= 2'b00; vif.status <= 3'b000;
          vif.transfer_ready <= 1'b0; vif.err <= 1'b0; vif.ready <= 1'b1;
          if (vif.data_out_valid) begin
            hdr[0] <= vif.data_out; hdr_cnt <= 1;
            vif.busy <= 1'b1; vif.data_dir <= 2'b01; vif.ready <= 1'b0;
            st <= D_HDR;
          end
        end
        D_HDR: begin
          if (vif.data_out_valid) begin
            hdr[hdr_cnt] <= vif.data_out;
            if (hdr_cnt == 9) begin st <= D_DECODE; hdr_cnt <= 0; end
            else hdr_cnt <= hdr_cnt + 1;
          end
        end
        D_DECODE: begin
          upiu   <= hdr[0]; dlun <= hdr[1]; tag <= hdr[2]; opcode <= hdr[3];
          lba    <= {hdr[4], hdr[5], hdr[6], hdr[7]};
          dlen   <= {hdr[8], hdr[9]};
          resp_type     <= resp_type_for(hdr[0]);
          bad = (int'({hdr[4], hdr[5], hdr[6], hdr[7]}) * BLK + int'({hdr[8], hdr[9]}) > CAP_BYTES)
                || (hdr[1] > 8'd7)
                || (hdr[0] == 8'h01 && !scsi_known(hdr[3]));
          resp_status_b <= bad ? 8'h02 : 8'h00;
          vif.err       <= bad;
          vif.status    <= bad ? 3'b010 : 3'b001;
          if (hdr[0] == 8'h01 && hdr[3] == 8'h2A && !bad) begin
            st <= D_WRTT;                       // WRITE_10: issue RTT first
          end else if (hdr[0] == 8'h01 && hdr[3] == 8'h28 && !bad) begin
            st <= D_RDATA; data_cnt <= 0; vif.data_dir <= 2'b10;
          end else begin
            st <= D_RESP; resp_cnt <= 0; vif.data_dir <= 2'b10;
            if (bad) err_cnt <= err_cnt + 1;
          end
        end
        D_WRTT: begin  // READY_XFER burst (single byte 0x31)
          vif.data_in <= 8'h31; vif.data_in_valid <= 1'b1;
          vif.transfer_ready <= 1'b1; vif.data_dir <= 2'b10;
          data_cnt <= 0;
          st <= D_WDATA;
        end
        D_WDATA: begin
          vif.transfer_ready <= 1'b0; vif.data_dir <= 2'b01;
          if (vif.data_out_valid) begin
            mem[int'(lba) * BLK + data_cnt] <= vif.data_out;
            if (data_cnt == int'(dlen) - 1) begin
              st <= D_RESP; resp_cnt <= 0; vif.data_dir <= 2'b10; vif.status <= 3'b001;
            end
            data_cnt <= data_cnt + 1;
          end
        end
        D_RDATA: begin // DATA_IN burst from block memory
          vif.data_in <= mem[int'(lba) * BLK + data_cnt];
          vif.data_in_valid <= 1'b1; vif.data_dir <= 2'b10;
          if (data_cnt == int'(dlen) - 1) st <= D_GAP;
          data_cnt <= data_cnt + 1;
        end
        D_GAP: begin   // inter-burst gap so the monitor can delimit bursts
          vif.status <= 3'b001;
          resp_cnt <= 0;
          st <= D_RESP;
        end
        D_RESP: begin  // 3-byte response trailer {type, tag, status}
          vif.data_in_valid <= 1'b1; vif.resp_valid <= 1'b1;
          vif.resp_status <= (vif.status == 3'b010) ? 3'b010 : 3'b001;
          case (resp_cnt)
            0: vif.data_in <= resp_type;
            1: vif.data_in <= tag;
            default: vif.data_in <= resp_status_b;
          endcase
          if (resp_cnt == 2) begin
            st <= D_IDLE; resp_cnt <= 0; cmd_cnt <= cmd_cnt + 1;
          end else resp_cnt <= resp_cnt + 1;
        end
        default: st <= D_IDLE;
      endcase
    end
  end

  final begin : rpt
    `uvm_info("UFS_DEV", $sformatf("device: commands=%0d errors=%0d", cmd_cnt, err_cnt), UVM_LOW)
  end
endmodule
`endif
