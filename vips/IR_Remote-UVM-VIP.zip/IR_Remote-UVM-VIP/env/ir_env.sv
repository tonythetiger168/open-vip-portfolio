// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_env.sv -- IR environment: reference-model scoreboard, checker, coverage

package ir_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import ir_defs_pkg::*;
  import ir_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class ir_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(ir_scoreboard)
    uvm_analysis_imp_exp #(ir_transaction, ir_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(ir_transaction, ir_scoreboard) obs_ap;

    ir_config cfg;
    ir_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [15:0] last_addr = 0;
    bit [7:0]  last_cmd = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(ir_config)::get(this, "", "cfg", cfg))
        cfg = ir_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(ir_transaction t);
      // state machine of the receiver, run on whole segments
      int unsigned T = cfg.nec_t, H = cfg.rc5_h, n = t.seg.size();
      int st = 0;            // 0 leader mark, 1 leader space, 2 bit mark, 3 bit space, 4 stop mark, 5 RC5
      bit rpt = 0, done = 0;
      int nb = 0, nh = 0;
      bit [31:0] sh = 0;
      bit hv [28];
      t.rproto = 0; t.raddr = 0; t.rcmd = 0; t.rtog = 0; t.rerr = 2;
      hv[0] = 1; nh = 1;
      for (int i = 0; i <= n && !done; i++) begin
        bit mark = (i % 2) == 0;
        int v = (i < n) ? t.seg[i] : 32'h7FFF_FFFF;   // the last space is idle
        if (mark) begin
          case (st)
            0: if (ir_in_rng(v, 12 * T, 20 * T)) st = 1;
               else if (v <= 5 * H / 2 && v >= H / 2) begin
                 int k = (v <= 3 * H / 2) ? 1 : 2;
                 for (int j = 0; j < k; j++) hv[nh++] = 0;
                 st = 5; t.rproto = 2;
               end else done = 1;
            2: if (ir_in_rng(v, T / 2, 3 * T / 2)) st = 3; else done = 1;
            4: begin
                 if (ir_in_rng(v, T / 2, 3 * T / 2)) begin
                   if (rpt) begin t.rproto = 1; t.raddr = last_addr; t.rcmd = last_cmd; t.rerr = 0; end
                   else begin
                     t.raddr = (sh[15:8] == ~sh[7:0]) ? {8'h00, sh[7:0]} : sh[15:0];
                     t.rcmd = sh[23:16];
                     if (sh[31:24] == ~sh[23:16]) begin t.rerr = 0; last_addr = t.raddr; last_cmd = t.rcmd; end
                     else t.rerr = 1;
                   end
                 end
                 done = 1;
               end
            5: begin
                 int k = (v >= H / 2 && v <= 3 * H / 2) ? 1 : (v > 3 * H / 2 && v <= 5 * H / 2) ? 2 : 0;
                 if (k == 0 || nh + k > 28) done = 1;
                 else for (int j = 0; j < k; j++) hv[nh++] = 0;
               end
            default: done = 1;
          endcase
        end else begin
          case (st)
            1: if (ir_in_rng(v, 6 * T, 10 * T)) begin st = 2; nb = 0; end
               else if (ir_in_rng(v, 3 * T, 5 * T)) begin st = 4; rpt = 1; end
               else done = 1;
            3: if (ir_in_rng(v, T / 2, 3 * T / 2) || ir_in_rng(v, 2 * T, 4 * T)) begin
                 sh[nb] = (v >= 2 * T);
                 nb++;
                 st = (nb == 32) ? 4 : 2;
               end else done = 1;
            5: if (v > 5 * H / 2) begin
                 bit [13:0] r;
                 bit ok = 1;
                 if (nh == 27) hv[nh++] = 1;
                 if (nh != 28) ok = 0;
                 for (int b = 0; b < 14 && ok; b++) begin
                   if (hv[2 * b] == hv[2 * b + 1]) ok = 0;
                   r[13 - b] = hv[2 * b];
                 end
                 if (ok) begin
                   t.rerr = 0; t.rtog = r[11]; t.raddr = {11'h0, r[10:6]}; t.rcmd = {1'b0, !r[12], r[5:0]};
                 end
                 done = 1;
               end else begin
                 int k = (v >= H / 2 && v <= 3 * H / 2) ? 1 : (v > 3 * H / 2) ? 2 : 0;
                 if (k == 0 || nh + k > 28) done = 1;
                 else for (int j = 0; j < k; j++) hv[nh++] = 1;
               end
            default: done = 1;
          endcase
        end
      end
    endfunction

    function void write_exp(ir_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(ir_transaction t);
      ir_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        ir_transaction e = exp_q.pop_front();
        ir_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.compare(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("ir scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class ir_env extends uvm_env;
    `uvm_component_utils(ir_env)
    ir_agent      agt;
    ir_scoreboard sb;
    ir_checker    chk;
    ir_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = ir_agent     ::type_id::create("agt", this);
      sb  = ir_scoreboard::type_id::create("sb",  this);
      chk = ir_checker   ::type_id::create("chk", this);
      cov = ir_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
