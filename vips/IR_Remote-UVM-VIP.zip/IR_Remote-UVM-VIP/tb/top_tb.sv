// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- IR testbench top with a functional IR DUT model

`ifndef IR_REMOTE_UVM_VIP_TB_SV
`define IR_REMOTE_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import ir_defs_pkg::*;
import ir_pkg::*;
import ir_env_pkg::*;
import ir_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  ir_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  ir_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .ir_in(vif.ir_in),
    .rep_valid(vif.rep_valid),
    .rep_proto(vif.rep_proto),
    .rep_addr(vif.rep_addr),
    .rep_cmd(vif.rep_cmd),
    .rep_toggle(vif.rep_toggle),
    .rep_err(vif.rep_err)
  );

  // Concurrent protocol checks
  ir_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .ir_in(vif.ir_in),
    .rep_valid(vif.rep_valid),
    .rep_proto(vif.rep_proto),
    .rep_addr(vif.rep_addr),
    .rep_cmd(vif.rep_cmd),
    .rep_toggle(vif.rep_toggle),
    .rep_err(vif.rep_err)
  );

  initial begin
    uvm_config_db#(virtual ir_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module ir_model #(parameter int T = 8, parameter int H = 14) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        ir_in,
  output logic        rep_valid,
  output logic [1:0]  rep_proto,
  output logic [15:0] rep_addr,
  output logic [7:0]  rep_cmd,
  output logic        rep_toggle,
  output logic [1:0]  rep_err
);
  localparam int GAP = 20 * T;
  localparam logic [2:0] S_IDLE = 3'd0, S_LM = 3'd1, S_LS = 3'd2, S_BM = 3'd3, S_BS = 3'd4,
                         S_STOP = 3'd5, S_RC5 = 3'd6, S_WAIT = 3'd7;
  logic [2:0]  st;
  logic        lv, rpt;
  logic [15:0] cnt;
  logic [31:0] sh;
  logic [5:0]  nb, nh;
  logic [27:0] hv;
  logic [15:0] last_addr;
  logic [7:0]  last_cmd;

  function automatic logic rng(input logic [15:0] v, input integer lo, input integer hi);
    rng = (v >= lo) && (v <= hi);
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; lv <= 1'b1; rpt <= 1'b0; cnt <= 16'd0; sh <= '0; nb <= '0; nh <= '0; hv <= '0;
      last_addr <= '0; last_cmd <= '0;
      rep_valid <= 1'b0; rep_proto <= '0; rep_addr <= '0; rep_cmd <= '0; rep_toggle <= 1'b0; rep_err <= '0;
    end else begin : step
      logic [15:0] v;
      logic        fin, err;
      logic [1:0]  k;
      logic [2:0]  nst;
      logic [27:0] h;
      logic [5:0]  m;
      logic [13:0] r;
      logic        ok;
      rep_valid <= 1'b0;
      fin = 1'b0; err = 1'b0; nst = st; h = hv; m = nh;
      v = cnt;
      if (ir_in == lv) begin
        // segment continues: only a space can time out
        cnt <= (cnt == 16'hFFFF) ? cnt : cnt + 16'd1;
        v = cnt + 16'd1;
        if (lv) begin
          case (st)
            S_LS:   if (v > 10 * T) err = 1'b1;
            S_BS:   if (v > 4 * T) err = 1'b1;
            S_RC5:  if (v > 5 * H / 2) begin
                      if (m == 6'd27) begin h[27] = 1'b1; m = 6'd28; end
                      ok = (m == 6'd28);
                      for (int b = 0; b < 14; b++) begin
                        if (h[2 * b] == h[2 * b + 1]) ok = 1'b0;
                        r[13 - b] = h[2 * b];
                      end
                      if (ok) begin
                        rep_valid <= 1'b1; rep_proto <= 2'd2; rep_err <= 2'd0; rep_toggle <= r[11];
                        rep_addr <= {11'h0, r[10:6]}; rep_cmd <= {1'b0, ~r[12], r[5:0]};
                        nst = S_WAIT;
                      end else err = 1'b1;
                    end
            S_WAIT: if (v >= GAP) nst = S_IDLE;
            default: ;
          endcase
        end
      end else begin
        // edge: the segment of level lv and length cnt has ended
        cnt <= 16'd1;
        lv <= ir_in;
        if (!lv) begin                       // a mark ended
          case (st)
            S_LM: if (rng(v, 12 * T, 20 * T)) nst = S_LS;
                  else if (rng(v, H / 2, 5 * H / 2)) begin
                    h = '0; h[0] = 1'b1; m = 6'd1;
                    if (v > 3 * H / 2) m = 6'd3; else m = 6'd2;
                    nst = S_RC5; rep_proto <= 2'd2;
                  end else err = 1'b1;
            S_BM: if (rng(v, T / 2, 3 * T / 2)) nst = S_BS; else err = 1'b1;
            S_STOP: if (rng(v, T / 2, 3 * T / 2)) begin
                      rep_valid <= 1'b1; rep_toggle <= 1'b0;
                      if (rpt) begin
                        rep_proto <= 2'd1; rep_addr <= last_addr; rep_cmd <= last_cmd; rep_err <= 2'd0;
                      end else begin
                        rep_proto <= 2'd0;
                        rep_addr <= (sh[15:8] == ~sh[7:0]) ? {8'h00, sh[7:0]} : sh[15:0];
                        rep_cmd <= sh[23:16];
                        if (sh[31:24] == ~sh[23:16]) begin
                          rep_err <= 2'd0;
                          last_addr <= (sh[15:8] == ~sh[7:0]) ? {8'h00, sh[7:0]} : sh[15:0];
                          last_cmd <= sh[23:16];
                        end else rep_err <= 2'd1;
                      end
                      nst = S_WAIT;
                    end else err = 1'b1;
            S_RC5: begin
                     k = rng(v, H / 2, 3 * H / 2) ? 2'd1 : rng(v, 3 * H / 2 + 1, 5 * H / 2) ? 2'd2 : 2'd0;
                     if (k == 2'd0 || m + k > 28) err = 1'b1;
                     else begin
                       h[m] = 1'b0; if (k == 2'd2) h[m + 1] = 1'b0;
                       m = m + k;
                     end
                   end
            default: ;
          endcase
        end else begin                       // a space ended
          case (st)
            S_IDLE: begin nst = S_LM; rpt <= 1'b0; rep_proto <= 2'd0; end
            S_LS: if (rng(v, 6 * T, 10 * T)) begin nst = S_BM; nb <= '0; end
                  else if (rng(v, 3 * T, 5 * T)) begin nst = S_STOP; rpt <= 1'b1; end
                  else err = 1'b1;
            S_BS: if (rng(v, T / 2, 3 * T / 2) || rng(v, 2 * T, 4 * T)) begin
                    sh[nb[4:0]] <= (v >= 2 * T);
                    nb <= nb + 6'd1;
                    nst = (nb == 6'd31) ? S_STOP : S_BM;
                  end else err = 1'b1;
            S_RC5: begin
                     k = rng(v, H / 2, 3 * H / 2) ? 2'd1 : rng(v, 3 * H / 2 + 1, 5 * H / 2) ? 2'd2 : 2'd0;
                     if (k == 2'd0 || m + k > 28) err = 1'b1;
                     else begin
                       h[m] = 1'b1; if (k == 2'd2) h[m + 1] = 1'b1;
                       m = m + k;
                     end
                   end
            S_WAIT: ;                         // a mark while re-arming: keep waiting
            default: ;
          endcase
        end
      end
      if (err) begin
        rep_valid <= 1'b1; rep_err <= 2'd2; rep_addr <= '0; rep_cmd <= '0; rep_toggle <= 1'b0;
        nst = S_WAIT;
      end
      hv <= h; nh <= m;
      st <= nst;
    end
  end
endmodule
`endif
