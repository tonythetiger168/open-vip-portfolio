// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (IR DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened ir_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;
  localparam integer T = 8, H = 14;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic ir_in = 1'b1;
  wire rep_valid, rep_toggle;
  wire [1:0] rep_proto, rep_err;
  wire [15:0] rep_addr;
  wire [7:0] rep_cmd;

  always #5 clk = ~clk;

  ir_model u_dut (.clk(clk), .rst_n(rst_n), .ir_in(ir_in), .rep_valid(rep_valid), .rep_proto(rep_proto),
                  .rep_addr(rep_addr), .rep_cmd(rep_cmd), .rep_toggle(rep_toggle), .rep_err(rep_err));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  integer nrep = 0, cyc = 0, rcyc = 0, bad_end = 0;
  logic [1:0] r_pr, r_er;
  logic [15:0] r_ad;
  logic [7:0] r_cm;
  logic r_tg;
  always @(posedge clk) cyc = cyc + 1;
  always @(posedge clk) if (rep_valid) begin
    rcyc = cyc;
    nrep = nrep + 1; r_pr = rep_proto; r_ad = rep_addr; r_cm = rep_cmd; r_tg = rep_toggle; r_er = rep_err;
  end

  integer r0;
  task automatic lvl(input logic l, input integer n);
    ir_in = l;
    repeat (n) @(negedge clk);
  endtask
  task automatic idle();
    lvl(1, 200);
  endtask
  task automatic nec(input logic [31:0] w, input integer stretch_bit = -1, input logic stop = 1);
    r0 = nrep;
    lvl(0, 16 * T); lvl(1, 8 * T);
    for (int i = 0; i < 32; i++) begin
      lvl(0, T);
      lvl(1, (i == stretch_bit) ? 5 * T : (w[i] ? 3 * T : T));
    end
    if (stop) lvl(0, T);
    idle();
  endtask
  task automatic nec_rpt();
    r0 = nrep;
    lvl(0, 16 * T); lvl(1, 4 * T); lvl(0, T); idle();
  endtask
  // RC5: bits MSB first, half bits of H clocks (1 = space then mark); an extra
  // clock count for half bit number long_h stretches it
  task automatic rc5(input logic [13:0] r, input integer long_h = -1);
    integer hn;
    r0 = nrep; hn = 0;
    for (int i = 13; i >= 0; i--) begin
      if (i != 13) begin ir_in = r[i] ? 1'b1 : 1'b0; repeat ((hn == long_h) ? 3 * H : H) @(negedge clk); end
      hn = hn + 1;
      ir_in = r[i] ? 1'b0 : 1'b1; repeat ((hn == long_h) ? 3 * H : H) @(negedge clk);
      hn = hn + 1;
    end
    idle();
  endtask
  // NEC with explicit leader space ls, one bit (bi) with mark bm / space bs, trailing space tr
  task automatic necx(input logic [31:0] w, input integer ls, input integer bi, input integer bm, input integer bs,
                      input integer tr = 200);
    r0 = nrep;
    lvl(0, 16 * T); lvl(1, ls);
    for (int i = 0; i < 32; i++) begin
      lvl(0, (i == bi) ? bm : T);
      lvl(1, (i == bi) ? bs : (w[i] ? 3 * T : T));
    end
    lvl(0, T); lvl(1, tr);
  endtask
  // RC5 with half bit number hidx lasting hlen clocks
  task automatic rc5x(input logic [13:0] r, input integer hidx, input integer hlen);
    integer hn;
    // half 0 is the invisible first half of S1; half 2i + 1 / 2i + 2 are the halves of bit 13 - i
    r0 = nrep; hn = 1;
    for (int i = 13; i >= 0; i--) begin
      if (i != 13) begin
        ir_in = r[i] ? 1'b1 : 1'b0; repeat ((hn == hidx) ? hlen : H) @(negedge clk);
        if (hn == hidx) bad_end = cyc;
        hn = hn + 1;
      end
      ir_in = r[i] ? 1'b0 : 1'b1; repeat ((hn == hidx) ? hlen : H) @(negedge clk);
      if (hn == hidx) bad_end = cyc;
      hn = hn + 1;
    end
    idle();
  endtask
  function automatic logic got(input logic [1:0] pr, input logic [15:0] ad, input logic [7:0] cm,
                               input logic tg, input logic [1:0] er);
    got = (nrep == r0 + 1) && r_pr == pr && r_ad == ad && r_cm == cm && r_tg == tg && r_er == er;
  endfunction
  function automatic logic [31:0] w8(input logic [7:0] a, input logic [7:0] c);
    w8 = {~c, c, ~a, a};
  endfunction

  initial begin
    repeat (3) @(posedge clk);
    chk(rep_valid === 1'b0, "no report in reset");
    rst_n = 1;
    repeat (4) @(negedge clk);
    nec_rpt(); chk(got(1, 0, 0, 0, 0), "repeat before any frame: last address/command 0");
    nec(w8(8'h04, 8'h08)); chk(got(0, 16'h0004, 8'h08, 0, 0), "NEC 0x04 / 0x08");
    nec(w8(8'h00, 8'hFF)); chk(got(0, 16'h0000, 8'hFF, 0, 0), "NEC 0x00 / 0xFF");
    nec_rpt(); chk(got(1, 16'h0000, 8'hFF, 0, 0), "repeat: last frame's address and command");
    nec({~8'h12, 8'h12, 8'h12, 8'h34}); chk(got(0, 16'h1234, 8'h12, 0, 0), "extended NEC address 0x1234");
    nec({8'h55, 8'h12, ~8'h04, 8'h04}); chk(got(0, 16'h0004, 8'h12, 0, 1), "~cmd wrong: check error");
    nec_rpt(); chk(got(1, 16'h1234, 8'h12, 0, 0), "repeat ignores the failed frame");
    nec(w8(8'h04, 8'h33), 7); chk(got(0, 0, 0, 0, 2), "5T space in bit 7: timing error");
    nec(w8(8'h04, 8'h33), -1, 0); chk(got(0, 0, 0, 0, 2), "no stop mark: timing error");
    r0 = nrep; lvl(0, 6 * T); idle(); chk(got(0, 0, 0, 0, 2), "6T leader: unknown frame");
    r0 = nrep; lvl(0, 16 * T); lvl(1, 12 * T); lvl(0, T); idle(); chk(got(0, 0, 0, 0, 2), "12T leader space");
    nec(w8(8'h77, 8'h66)); chk(got(0, 16'h0077, 8'h66, 0, 0), "NEC after the faults");
    rc5({1'b1, 1'b1, 1'b0, 5'h00, 6'h0C}); chk(got(2, 0, 8'h0C, 0, 0), "RC5 TV standby, toggle 0");
    rc5({1'b1, 1'b1, 1'b1, 5'h00, 6'h0C}); chk(got(2, 0, 8'h0C, 1, 0), "RC5 toggle 1");
    rc5({1'b1, 1'b1, 1'b1, 5'h1F, 6'h3F}); chk(got(2, 16'h001F, 8'h3F, 1, 0), "RC5 all ones");
    rc5({1'b1, 1'b1, 1'b0, 5'h15, 6'h2A}); chk(got(2, 16'h0015, 8'h2A, 0, 0), "RC5 alternating bits");
    rc5({1'b1, 1'b1, 1'b0, 5'h00, 6'h00}); chk(got(2, 0, 0, 0, 0), "RC5 zeros (ends on a space)");
    rc5({1'b1, 1'b0, 1'b1, 5'h05, 6'h01}); chk(got(2, 16'h0005, 8'h41, 1, 0), "RC5X: S2 = 0 sets cmd bit 6");
    rc5({1'b1, 1'b1, 1'b0, 5'h03, 6'h12}, 9); chk(got(2, 0, 0, 0, 2), "RC5 half bit 3H: error");
    // tolerance: every segment 1 clock long / short
    r0 = nrep; lvl(0, 16 * T + 1); lvl(1, 8 * T - 1);
    for (int i = 0; i < 32; i++) begin lvl(0, T - 1); lvl(1, (w8(8'hA5, 8'h5A) >> i) & 1 ? 3 * T + 1 : T + 1); end
    lvl(0, T + 1); idle(); chk(got(0, 16'h00A5, 8'h5A, 0, 0), "NEC with jitter inside the windows");
    nec_rpt(); chk(got(1, 16'h00A5, 8'h5A, 0, 0), "repeat after the jittered frame");
    // a mark while re-arming is ignored
    r0 = nrep; lvl(0, 16 * T); lvl(1, 4 * T); lvl(0, T); lvl(1, 50); lvl(0, 3); lvl(1, 50); lvl(0, 40); idle();
    chk(got(1, 16'h00A5, 8'h5A, 0, 0), "marks while re-arming (under 20T of space) are ignored");
    r0 = nrep; lvl(0, 3); idle(); chk(got(0, 0, 0, 0, 2), "3-clock glitch once armed: error");
    // window edges (T = 8: unit [4, 12], 1-space [16, 32], leader space [48, 80]; H = 14: half [7, 21])
    necx(w8(8'h11, 8'h22), 80, -1, T, T); chk(got(0, 16'h0011, 8'h22, 0, 0), "leader space 10T accepted");
    necx(w8(8'h11, 8'h22), 81, -1, T, T); chk(got(0, 0, 0, 0, 2), "leader space 10T + 1 rejected");
    necx(w8(8'h11, 8'h22), 64, 0, T, 32); chk(got(0, 16'h0011, 8'h22, 0, 0), "bit space 4T is a 1");
    necx(w8(8'h11, 8'h22), 64, 0, T, 33); chk(got(0, 0, 0, 0, 2), "bit space 4T + 1 rejected");
    necx(w8(8'h11, 8'h22), 64, 3, 4, T); chk(got(0, 16'h0011, 8'h22, 0, 0), "bit mark T/2 accepted");
    necx(w8(8'h11, 8'h22), 64, 3, 3, T); chk(got(0, 0, 0, 0, 2), "bit mark T/2 - 1 rejected");
    necx(w8(8'h11, 8'h22), 64, 3, 12, T); chk(got(0, 16'h0011, 8'h22, 0, 0), "bit mark 3T/2 accepted");
    necx(w8(8'h11, 8'h22), 64, 3, 13, T); chk(got(0, 0, 0, 0, 2), "bit mark 3T/2 + 1 rejected");
    r0 = nrep; lvl(0, 6); idle(); chk(got(0, 0, 0, 0, 2), "first mark of 6 clocks: neither NEC nor RC5");
    // the receiver re-arms after exactly 20T of space
    necx(w8(8'h33, 8'h44), 64, -1, T, T, 160); r0 = nrep; nec(w8(8'h55, 8'h66));
    chk(got(0, 16'h0055, 8'h66, 0, 0), "a frame 20T after the last one is decoded");
    necx(w8(8'h33, 8'h44), 64, -1, T, T, 159); r0 = nrep; nec(w8(8'h55, 8'h66));
    chk(nrep == r0, "a frame 20T - 1 after the last one is ignored");
    rc5x({1'b1, 1'b1, 1'b0, 5'h00, 6'h00}, 6, 21); chk(got(2, 0, 0, 0, 0), "RC5 mark half of 3H/2 accepted");
    rc5x({1'b1, 1'b1, 1'b0, 5'h00, 6'h00}, 7, 21); chk(got(2, 0, 0, 0, 0), "RC5 space half of 3H/2 accepted");
    rc5x({1'b1, 1'b1, 1'b0, 5'h00, 6'h00}, 6, 6); chk(got(2, 0, 0, 0, 2), "RC5 mark half of 6 rejected");
    rc5x({1'b1, 1'b1, 1'b0, 5'h00, 6'h00}, 7, 5); chk(got(2, 0, 0, 0, 2) && rcyc - bad_end <= 3, "RC5 space half of 5 rejected at its end");
    rc5x({1'b1, 1'b1, 1'b0, 5'h00, 6'h00}, 6, 40); chk(got(2, 0, 0, 0, 2) && rcyc - bad_end <= 3, "RC5 mark of 40 rejected at its end");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
