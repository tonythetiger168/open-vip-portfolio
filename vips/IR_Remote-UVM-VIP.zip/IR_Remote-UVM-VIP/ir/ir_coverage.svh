// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_coverage.svh -- IR functional coverage

class ir_coverage extends uvm_subscriber #(ir_transaction);
  `uvm_component_utils(ir_coverage)
  ir_config cfg;
  ir_transaction tr;

  covergroup ir_cg;
    cp_proto : coverpoint tr.rproto iff (tr.rerr == 0) { bins nec = {0}; bins repeat_c = {1}; bins rc5 = {2}; }
    cp_err   : coverpoint tr.rerr { bins ok = {0}; bins cmd_check = {1}; bins timing = {2}; }
    cp_ext   : coverpoint (tr.raddr[15:8] != 0) iff (tr.rproto == 0 && tr.rerr == 0) { bins std = {0}; bins ext = {1}; }
    cp_rc5x  : coverpoint tr.rcmd[6] iff (tr.rproto == 2 && tr.rerr == 0) { bins rc5 = {0}; bins rc5x = {1}; }
    cp_tog   : coverpoint tr.rtog iff (tr.rproto == 2 && tr.rerr == 0);
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ir_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(ir_config)::get(this, "", "cfg", cfg))
      cfg = ir_config::type_id::create("cfg");
  endfunction

  function void write(ir_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    ir_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("IR coverage: %0.1f%%", ir_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
