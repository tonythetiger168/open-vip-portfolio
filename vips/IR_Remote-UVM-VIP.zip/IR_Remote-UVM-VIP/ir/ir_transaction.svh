// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_transaction.svh -- IR transaction

class ir_transaction extends uvm_sequence_item;
  `uvm_object_utils(ir_transaction)

  // request (driven by the agent)
  bit [15:0] seg[$];
  // response (returned by the DUT)
  bit [1:0] rproto;
  bit [15:0] raddr;
  bit [7:0] rcmd;
  bit rtog;
  bit [1:0] rerr;
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [7:0] addr;
  rand bit [7:0] addr_hi;
  rand bit [7:0] cmd;
  rand bit tog;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "ir_transaction"); super.new(name); endfunction

  // kind: 0-9 NEC, 10-11 NEC extended address, 12-13 NEC repeat, 14 NEC ~cmd wrong,
  // 15 NEC stretched space, 16-21 RC5, 22-23 RC5X (S2 = 0), 24 RC5 stretched half bit,
  // 25 NEC with jitter, 26 RC5 with jitter, 27 unknown leader mark, 28 NEC without
  // the stop mark, 29-31 NEC
  function void set(int k, bit [7:0] a, bit [7:0] c, bit tg = 0, bit [7:0] ah = 0);
    kind = k; addr = a; cmd = c; tog = tg; addr_hi = ah;
  endfunction
  function bit is_rc5(); return kind inside {[16:24], 26}; endfunction
  function void build(int unsigned T, int unsigned H);
    bit [31:0] x = seed | 1;
    bit [31:0] w;
    bit [13:0] r;
    bit lv [$];
    seg.delete();
    if (!is_rc5()) begin
      if (kind == 27) begin seg.push_back(6 * T); return; end
      seg.push_back(16 * T);
      if (kind inside {12, 13}) begin seg.push_back(4 * T); seg.push_back(T); return; end
      seg.push_back(8 * T);
      w = {(kind == 14) ? cmd : ~cmd, cmd, (kind inside {10, 11}) ? addr_hi : ~addr, addr};
      for (int i = 0; i < 32; i++) begin
        seg.push_back(T);
        seg.push_back(w[i] ? 3 * T : T);
      end
      if (kind == 15) seg[3 + 2 * cmd[4:0]] = 5 * T;
      if (kind == 28) void'(seg.pop_back()); else seg.push_back(T);
      if (kind == 25) foreach (seg[i]) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        seg[i] = seg[i] + x[1:0] - 2 + ((seg[i] > T) ? 0 : 1);
      end
    end else begin
      r = {1'b1, !(kind inside {22, 23}), tog, addr[4:0], cmd[5:0]};
      lv.push_back(1);                          // invisible first half of S1
      for (int i = 13; i >= 0; i--) begin
        if (i != 13) lv.push_back(r[i] ? 1'b1 : 1'b0);
        lv.push_back(r[i] ? 1'b0 : 1'b1);
      end
      // run lengths of the levels after the leading space; drop the trailing space
      while (lv.size() && lv[lv.size() - 1] == 1'b1) void'(lv.pop_back());
      begin
        int n = 0; bit cur = 0;
        for (int i = 1; i < lv.size(); i++) begin
          if (n != 0 && lv[i] != cur) begin seg.push_back(n * H); n = 0; end
          cur = lv[i]; n++;
        end
        seg.push_back(n * H);
      end
      if (kind == 24) seg[2 * cmd[1:0]] = 3 * H;
      if (kind == 26) foreach (seg[i]) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        seg[i] = seg[i] + x[1:0] - 2;
      end
    end
  endfunction

  function void do_copy(uvm_object rhs);
    ir_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    seg = rhs_.seg;
    rproto = rhs_.rproto;
    raddr = rhs_.raddr;
    rcmd = rhs_.rcmd;
    rtog = rhs_.rtog;
    rerr = rhs_.rerr;
    kind = rhs_.kind;
    addr = rhs_.addr;
    addr_hi = rhs_.addr_hi;
    cmd = rhs_.cmd;
    tog = rhs_.tog;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    ir_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (seg.size() != rhs_.seg.size()) return 0;
    foreach (seg[i]) if (seg[i] != rhs_.seg[i]) return 0;
    if (rproto != rhs_.rproto) return 0;
    if (raddr != rhs_.raddr) return 0;
    if (rcmd != rhs_.rcmd) return 0;
    if (rtog != rhs_.rtog) return 0;
    if (rerr != rhs_.rerr) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(ir_transaction rhs_);
    if (seg.size() != rhs_.seg.size()) return 0;
    foreach (seg[i]) if (seg[i] != rhs_.seg[i]) return 0;
    return 1;
  endfunction

  function string qstr_seg();
    string s = $sformatf("[%0d]{", seg.size());
    foreach (seg[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", seg[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("IR{tag=%0d seg=%s rproto=0x%0h raddr=0x%0h rcmd=0x%0h rtog=0x%0h rerr=0x%0h}", tag, qstr_seg(), rproto, raddr, rcmd, rtog, rerr);
  endfunction
endclass
