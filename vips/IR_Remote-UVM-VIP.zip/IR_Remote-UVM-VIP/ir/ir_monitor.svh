// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_monitor.svh -- IR monitor: marks and spaces on ir_in from the first mark to cfg.mon_end clocks of space, with the report the receiver gave for them

class ir_monitor extends uvm_monitor;
  `uvm_component_utils(ir_monitor)

  virtual ir_if vif;
  uvm_analysis_port #(ir_transaction) ap;
  ir_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual ir_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ir: virtual interface not set")
    if (!uvm_config_db#(ir_config)::get(this, "", "cfg", cfg))
      cfg = ir_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        ir_transaction t;
        int unsigned n = 0, nrep = 0;
        bit lv = 1'b0;
        do @(vif.mon_cb); while (vif.mon_cb.ir_in !== 1'b0);
        t = ir_transaction::type_id::create("t");
        n = 1;
        forever begin
          @(vif.mon_cb);
          if (vif.mon_cb.rep_valid) begin
            nrep++;
            t.rproto = vif.mon_cb.rep_proto; t.raddr = vif.mon_cb.rep_addr; t.rcmd = vif.mon_cb.rep_cmd;
            t.rtog = vif.mon_cb.rep_toggle; t.rerr = vif.mon_cb.rep_err;
          end
          if (vif.mon_cb.ir_in === lv) begin
            n++;
            if (lv == 1'b1 && n >= cfg.mon_end) break;
          end else begin
            t.seg.push_back(n);
            lv = vif.mon_cb.ir_in; n = 1;
          end
        end
        if (nrep != 1) `uvm_error("MON", $sformatf("IR: %0d reports for one frame", nrep))
        publish(t);
      end
    end
  endtask

  function void publish(ir_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
