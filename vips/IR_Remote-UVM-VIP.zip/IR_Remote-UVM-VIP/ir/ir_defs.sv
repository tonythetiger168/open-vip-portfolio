// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_defs.sv -- IR shared type definitions

package ir_defs_pkg;

  typedef enum bit [1:0] {IR_OK, IR_ERR} ir_status_e;

  // NEC / RC5 segment decoder shared by the scoreboard (independent of the
  // cycle-level DUT model). seg: alternating mark, space, ..., ending with a mark;
  // the space after the last mark is idle.
  function automatic bit ir_in_rng(int v, int lo, int hi); return v >= lo && v <= hi; endfunction

endpackage
