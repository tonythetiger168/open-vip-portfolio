// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_if.sv -- IR interface

interface ir_if (input logic clk);
  logic rst_n;

  logic ir_in;
  logic rep_valid;
  logic [1:0] rep_proto;
  logic [15:0] rep_addr;
  logic [7:0] rep_cmd;
  logic rep_toggle;
  logic [1:0] rep_err;

  modport DUT (input clk, rst_n, input ir_in, output rep_valid, output rep_proto, output rep_addr, output rep_cmd, output rep_toggle, output rep_err);
  modport MON (input clk, rst_n, ir_in, rep_valid, rep_proto, rep_addr, rep_cmd, rep_toggle, rep_err);

  clocking drv_cb @(posedge clk);
    input rst_n, rep_valid, rep_proto, rep_addr, rep_cmd, rep_toggle, rep_err;
    inout ir_in;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, ir_in, rep_valid, rep_proto, rep_addr, rep_cmd, rep_toggle, rep_err;
  endclocking
endinterface
