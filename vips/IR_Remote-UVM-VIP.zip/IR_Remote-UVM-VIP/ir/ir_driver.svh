// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_driver.svh -- IR driver: one NEC / RC5 pulse train per item (marks drive ir_in low), then cfg.gap clocks of idle; the report seen anywhere in the item is its response

class ir_driver extends uvm_driver #(ir_transaction);
  `uvm_component_utils(ir_driver)

  uvm_analysis_port #(ir_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual ir_if vif;
  ir_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual ir_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "ir: virtual interface not set")
    if (!uvm_config_db#(ir_config)::get(this, "", "cfg", cfg))
      cfg = ir_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    ir_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.ir_in <= 1'b1;
  endtask

  task drive_item(ir_transaction t);
    bit got = 0;
    t.build(cfg.nec_t, cfg.rc5_h);
    @(vif.drv_cb);
    foreach (t.seg[i]) begin
      vif.drv_cb.ir_in <= (i % 2) ? 1'b1 : 1'b0;
      repeat (t.seg[i]) begin
        @(vif.drv_cb);
        if (vif.drv_cb.rep_valid) begin got = 1; capture(t); end
      end
    end
    vif.drv_cb.ir_in <= 1'b1;
    repeat (cfg.gap) begin
      @(vif.drv_cb);
      if (vif.drv_cb.rep_valid) begin got = 1; capture(t); end
    end
    if (!got) `uvm_error("DRV", "IR: no report for a frame")
  endtask

  function void capture(ir_transaction t);
    t.rproto = vif.drv_cb.rep_proto; t.raddr = vif.drv_cb.rep_addr; t.rcmd = vif.drv_cb.rep_cmd;
    t.rtog = vif.drv_cb.rep_toggle; t.rerr = vif.drv_cb.rep_err;
  endfunction
endclass
