// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_sequences.svh -- IR sequences

// Random traffic: cfg.num_items constrained-random items.
class ir_base_sequence extends uvm_sequence #(ir_transaction);
  `uvm_object_utils(ir_base_sequence)
  ir_config cfg;

  function new(string name = "ir_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = ir_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "ir_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class ir_directed_sequence extends uvm_sequence #(ir_transaction);
  `uvm_object_utils(ir_directed_sequence)
  ir_config cfg;

  function new(string name = "ir_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function ir_transaction item();
    item = ir_transaction::type_id::create("req");
  endfunction

  task send(ir_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    ir_transaction t;
    // repeat before any frame, NEC, extended, repeat, every fault, RC5 / RC5X with both toggles
    t = item(); t.set(12, 0, 0); send(t);
    t = item(); t.set(0, 8'h04, 8'h08); send(t);
    t = item(); t.set(0, 8'h00, 8'hFF); send(t);
    t = item(); t.set(10, 8'h34, 8'h12, 0, 8'h12); send(t);
    t = item(); t.set(12, 0, 0); send(t);
    t = item(); t.set(14, 8'h04, 8'h55); send(t);
    t = item(); t.set(13, 0, 0); send(t);
    for (int c = 0; c < 4; c++) begin t = item(); t.set(15, 8'h04, 8'h20 + c * 7); send(t); end
    t = item(); t.set(28, 8'h04, 8'h01); send(t);
    t = item(); t.set(27, 0, 0); send(t);
    t = item(); t.set(16, 5'h00, 6'h0C, 0); send(t);
    t = item(); t.set(16, 5'h00, 6'h0C, 1); send(t);
    t = item(); t.set(16, 5'h1F, 6'h3F, 1); send(t);
    t = item(); t.set(16, 5'h15, 6'h2A, 0); send(t);
    t = item(); t.set(22, 5'h05, 6'h01, 1); send(t);
    for (int c = 0; c < 4; c++) begin t = item(); t.set(24, 5'h03, c); send(t); end
    for (int s = 0; s < 4; s++) begin
      t = item(); t.set(25, 8'h40 + s, 8'h10 + s); t.seed = 32'h1234 * (s + 1); send(t);
      t = item(); t.set(26, 5'h0A + s, 6'h11 + s, s[0]); t.seed = 32'h4321 * (s + 1); send(t);
    end
  endtask
endclass
