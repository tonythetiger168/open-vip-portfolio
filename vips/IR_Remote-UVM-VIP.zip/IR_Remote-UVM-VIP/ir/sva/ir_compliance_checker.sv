// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_compliance_checker.sv -- IR concurrent assertion checks (bindable)

module ir_compliance_checker
  (input logic clk, input logic rst_n, input logic ir_in, input logic rep_valid, input logic [1:0] rep_proto, input logic [15:0] rep_addr, input logic [7:0] rep_cmd, input logic rep_toggle, input logic [1:0] rep_err);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({ir_in, rep_valid}))
    else $error("IR: X on ir_in / rep_valid");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |-> !$isunknown({rep_proto, rep_addr, rep_cmd, rep_toggle, rep_err}))
    else $error("IR: X in a report");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |-> rep_err != 2'd3 && rep_proto != 2'd3)
    else $error("IR: reserved report code");
  assert property (@(posedge clk) disable iff (!rst_n) rep_valid |=> !rep_valid)
    else $error("IR: two reports back to back");
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_proto == 2'd1);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_proto == 2'd2 && rep_err == 2'd0);
  cover property (@(posedge clk) disable iff (!rst_n) rep_valid && rep_err == 2'd2);
endmodule
