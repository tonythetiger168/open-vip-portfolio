// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// ir_pkg.sv -- IR UVM VIP package

package ir_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import ir_defs_pkg::*;
  export ir_defs_pkg::*;

  `include "ir_transaction.svh"
  `include "ir_config.svh"
  `include "ir_sequencer.svh"
  `include "ir_driver.svh"
  `include "ir_monitor.svh"
  `include "ir_agent.svh"
  `include "ir_sequences.svh"
  `include "ir_checker.svh"
  `include "ir_coverage.svh"
endpackage
