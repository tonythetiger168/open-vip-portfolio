// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (GMII PHY loopback)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened gmii_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [7:0] txd = '0;
  logic tx_en = 1'b0;
  logic tx_er = 1'b0;
  wire  [7:0] rxd;
  wire  rx_dv;
  wire  rx_er;

  always #5 clk = ~clk;

  gmii_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .txd(txd), .tx_en(tx_en), .tx_er(tx_er),
    .rxd(rxd), .rx_dv(rx_dv), .rx_er(rx_er)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [7:0] strm [0:7];
  initial begin
    strm[0]=8'h01; strm[1]=8'h55; strm[2]=8'hAA; strm[3]=8'hFF;
    strm[4]=8'h00; strm[5]=8'h10; strm[6]=8'hAB; strm[7]=8'hCD;
    repeat (8) step();
    chk(rx_dv === 1'b0 && rxd === 8'h00, "rx path reset quiet");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    // idle: dv low
    repeat (3) begin step(); chk(rx_dv === 1'b0, "rx_dv low when tx_en low"); end

    // stream 8 bytes through the loopback (per-beat check)
    for (int i = 0; i < 8; i++) begin
      @(negedge clk); txd = strm[i]; tx_en = 1;
      step();
      chk(rx_dv === 1'b1, "rx_dv high during stream");
      chk(rxd === strm[i], "loopback data integrity");
    end
    @(negedge clk); tx_en = 0; txd = '0;
    step();
    chk(rx_dv === 1'b0, "rx_dv drops after stream");
    repeat (2) step();

    // error passthrough
    @(negedge clk); tx_er = 1;
    step(); step();
    chk(rx_er === 1'b1, "error passthrough");
    @(negedge clk); tx_er = 0;
    step();

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
