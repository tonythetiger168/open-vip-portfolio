// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- GMII testbench top with a functional GMII DUT model

`ifndef GMII_TB_SV
`define GMII_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import gmii_defs_pkg::*;
import gmii_pkg::*;
import gmii_env_pkg::*;
import gmii_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  gmii_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  gmii_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .txd(vif.txd),
    .tx_en(vif.tx_en),
    .tx_er(vif.tx_er),
    .rxd(vif.rxd),
    .rx_dv(vif.rx_dv),
    .rx_er(vif.rx_er)
  );

  // Concurrent protocol checks
  gmii_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .txd(vif.txd), .tx_en(vif.tx_en), .tx_er(vif.tx_er), .rxd(vif.rxd), .rx_dv(vif.rx_dv), .rx_er(vif.rx_er)
  );

  initial begin
    uvm_config_db#(virtual gmii_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module gmii_model (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [7:0] txd,
  input  logic       tx_en,
  input  logic       tx_er,
  output logic [7:0] rxd,
  output logic       rx_dv,
  output logic       rx_er
);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rxd   <= '0;
      rx_dv <= 1'b0;
      rx_er <= 1'b0;
    end else begin
      rxd   <= txd;
      rx_dv <= tx_en;
      rx_er <= tx_er;
    end
  end
endmodule
`endif
