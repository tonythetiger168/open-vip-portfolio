// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- GMII testbench top with a functional GMII DUT model

`ifndef GMII_UVM_VIP_TB_SV
`define GMII_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import gmii_defs_pkg::*;
import gmii_pkg::*;
import gmii_env_pkg::*;
import gmii_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  gmii_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  gmii_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .station(vif.station),
    .promisc(vif.promisc),
    .mcast_en(vif.mcast_en),
    .rxd(vif.rxd),
    .rx_dv(vif.rx_dv),
    .rx_er(vif.rx_er),
    .fr_done(vif.fr_done),
    .fr_status(vif.fr_status),
    .fr_len(vif.fr_len),
    .fr_etype(vif.fr_etype),
    .fr_cast(vif.fr_cast),
    .fr_vlan(vif.fr_vlan),
    .pause_valid(vif.pause_valid),
    .pause_quanta(vif.pause_quanta),
    .false_carrier(vif.false_carrier)
  );

  // Concurrent protocol checks
  gmii_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .station(vif.station),
    .promisc(vif.promisc),
    .mcast_en(vif.mcast_en),
    .rxd(vif.rxd),
    .rx_dv(vif.rx_dv),
    .rx_er(vif.rx_er),
    .fr_done(vif.fr_done),
    .fr_status(vif.fr_status),
    .fr_len(vif.fr_len),
    .fr_etype(vif.fr_etype),
    .fr_cast(vif.fr_cast),
    .fr_vlan(vif.fr_vlan),
    .pause_valid(vif.pause_valid),
    .pause_quanta(vif.pause_quanta),
    .false_carrier(vif.false_carrier)
  );

  initial begin
    uvm_config_db#(virtual gmii_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module gmii_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [7:0]  rxd,
  input  logic        rx_dv,
  input  logic        rx_er,
  input  logic [47:0] station,
  input  logic        promisc,
  input  logic        mcast_en,
  output logic        fr_done,
  output logic [2:0]  fr_status,
  output logic [15:0] fr_len,
  output logic [15:0] fr_etype,
  output logic [1:0]  fr_cast,
  output logic        fr_vlan,
  output logic        pause_valid,
  output logic [15:0] pause_quanta,
  output logic        false_carrier
);
  // frame buffer filled by the bus front end
  logic [7:0]  fb [0:2047];
  logic [15:0] fcnt;
  logic        fe_end, f_pre, f_code;

  logic inf, sfd, fc_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      inf <= 1'b0; sfd <= 1'b0; f_pre <= 1'b0; f_code <= 1'b0; fcnt <= 16'd0; fe_end <= 1'b0;
      false_carrier <= 1'b0; fc_q <= 1'b0;
    end else begin
      fe_end <= 1'b0;
      false_carrier <= 1'b0;
      // false carrier: rx_dv 0, rx_er 1, rxd 0E (one pulse per event)
      fc_q <= !rx_dv && rx_er && rxd == 8'h0E;
      if (!rx_dv && rx_er && rxd == 8'h0E && !fc_q) false_carrier <= 1'b1;
      if (rx_dv) begin
        if (!inf) begin
          inf <= 1'b1; fcnt <= 16'd0; f_code <= rx_er;
          sfd <= (rxd == 8'hD5); f_pre <= (rxd != 8'h55 && rxd != 8'hD5);
        end else begin
          if (rx_er) f_code <= 1'b1;
          if (!sfd) begin
            if (rxd == 8'hD5) sfd <= 1'b1;
            else if (rxd != 8'h55) f_pre <= 1'b1;
          end else begin
            if (fcnt < 16'd2048) fb[fcnt] <= rxd;
            fcnt <= fcnt + 16'd1;
          end
        end
      end else if (inf) begin
        // end of frame (carrier extension after it is ignored)
        inf <= 1'b0; fe_end <= 1'b1;
        if (!sfd) f_pre <= 1'b1;
      end
    end
  end


  // MAC receive check, the clock after the front end ends a frame
  logic [31:0] crc;
  logic [47:0] da;
  logic [15:0] lt;
  logic        vl;
  integer      pa, k, j;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fr_done <= 1'b0; fr_status <= 3'd0; fr_len <= 16'd0; fr_etype <= 16'd0; fr_cast <= 2'd0; fr_vlan <= 1'b0;
      pause_valid <= 1'b0; pause_quanta <= 16'd0;
    end else begin
      fr_done <= 1'b0;
      pause_valid <= 1'b0;
      if (fe_end) begin
        fr_done <= 1'b1; fr_len <= fcnt; fr_etype <= 16'd0; fr_cast <= 2'd0; fr_vlan <= 1'b0; pause_quanta <= 16'd0;
        vl = ({fb[12], fb[13]} == 16'h8100);
        lt = vl ? {fb[16], fb[17]} : {fb[12], fb[13]};
        da = {fb[0], fb[1], fb[2], fb[3], fb[4], fb[5]};
        if (f_pre) fr_status <= 3'd1;
        else if (f_code) fr_status <= 3'd2;
        else if (fcnt < 16'd64) fr_status <= 3'd4;
        else if (fcnt > (vl ? 16'd1522 : 16'd1518)) fr_status <= 3'd5;
        else begin
          crc = 32'hFFFF_FFFF;
          for (k = 0; k < fcnt - 4; k++) begin
            crc = crc ^ {24'h0, fb[k]};
            for (j = 0; j < 8; j++) crc = crc[0] ? ((crc >> 1) ^ 32'hEDB8_8320) : (crc >> 1);
          end
          crc = ~crc;
          if ({fb[fcnt-1], fb[fcnt-2], fb[fcnt-3], fb[fcnt-4]} != crc) fr_status <= 3'd3;
          else begin
            pa = fcnt - 18 - (vl ? 4 : 0);
            fr_etype <= lt; fr_vlan <= vl;
            fr_cast <= (da == 48'hFFFF_FFFF_FFFF) ? 2'd3 : da[40] ? 2'd2 : 2'd1;
            if (lt > 16'd1500 && lt < 16'd1536) fr_status <= 3'd6;
            else if (lt <= 16'd1500 && (lt > pa || (lt < pa && pa > (vl ? 42 : 46)))) fr_status <= 3'd6;
            else if (!vl && lt == 16'h8808 && {fb[14], fb[15]} == 16'h0001 &&
                     (da == 48'h0180_C200_0001 || da == station)) begin
              fr_status <= 3'd0; pause_valid <= 1'b1; pause_quanta <= {fb[16], fb[17]};
            end
            else if (!promisc && ((!da[40] && da != station) || (da[40] && da != 48'hFFFF_FFFF_FFFF && !mcast_en)))
              fr_status <= 3'd7;
            else fr_status <= 3'd0;
          end
        end
      end
    end
  end
endmodule
`endif
