// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_driver.svh -- GMII driver: one frame or bus event per item on the receive pins, then the inter-frame gap

class gmii_driver extends uvm_driver #(gmii_transaction);
  `uvm_component_utils(gmii_driver)

  uvm_analysis_port #(gmii_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual gmii_if vif;
  gmii_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual gmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gmii: virtual interface not set")
    if (!uvm_config_db#(gmii_config)::get(this, "", "cfg", cfg))
      cfg = gmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    gmii_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.rxd <= 8'h00; vif.drv_cb.rx_dv <= 1'b0; vif.drv_cb.rx_er <= 1'b0;
    vif.drv_cb.station <= cfg.station; vif.drv_cb.promisc <= cfg.promisc; vif.drv_cb.mcast_en <= cfg.mcast_en;
  endtask

  task drive_item(gmii_transaction t);
    bit [7:0] ln[$];
    int ci = -1;
    @(vif.drv_cb);
    repeat (t.gap) @(vif.drv_cb);
    t.pre_bad = 0; t.code_err = 0;
    if (t.kind == GMII_FC) begin
      t.bytes.delete(); t.inj = GMII_X_NONE;
      repeat (2 + t.cext) begin
        vif.drv_cb.rxd <= 8'h0E; vif.drv_cb.rx_dv <= 1'b0; vif.drv_cb.rx_er <= 1'b1; @(vif.drv_cb);
      end
      vif.drv_cb.rx_er <= 1'b0; vif.drv_cb.rxd <= 8'h00;
      repeat (cfg.ifg) @(vif.drv_cb);
      return;
    end
    t.build(cfg.station);
    for (int i = 0; i < t.pre_n; i++) ln.push_back(8'h55);
    if (t.inj == GMII_X_PRE) begin ln[0] = 8'h5D; t.pre_bad = 1; end
    if (t.inj != GMII_X_NOSFD) ln.push_back(8'hD5);
    else begin
      // no SFD: the receiver keeps hunting and only stores what follows a D5 in the frame
      int k = -1;
      t.pre_bad = 1;
      foreach (t.bytes[i]) if (k < 0 && t.bytes[i] == 8'hD5) k = i;
      foreach (t.bytes[i]) ln.push_back(t.bytes[i]);
      if (k < 0) t.bytes.delete(); else t.bytes = t.bytes[k + 1 : $];
    end
    if (t.inj != GMII_X_NOSFD) foreach (t.bytes[i]) ln.push_back(t.bytes[i]);
    if (t.inj == GMII_X_CODE) begin ci = t.pre_n + 1 + t.bytes.size() / 2; t.code_err = 1; end
    foreach (ln[i]) begin
      vif.drv_cb.rxd <= ln[i]; vif.drv_cb.rx_dv <= 1'b1; vif.drv_cb.rx_er <= (i == ci);
      @(vif.drv_cb);
    end
    vif.drv_cb.rx_dv <= 1'b0; vif.drv_cb.rx_er <= 1'b0; vif.drv_cb.rxd <= 8'h00;
    if (t.cext != 0) begin
      repeat (t.cext) begin vif.drv_cb.rx_er <= 1'b1; vif.drv_cb.rxd <= 8'h0F; @(vif.drv_cb); end
      vif.drv_cb.rx_er <= 1'b0; vif.drv_cb.rxd <= 8'h00;
    end
    repeat (cfg.ifg) @(vif.drv_cb);
  endtask

endclass
