// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_pkg.sv -- GMII UVM VIP package

package gmii_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import gmii_defs_pkg::*;
  export gmii_defs_pkg::*;

  `include "gmii_transaction.svh"
  `include "gmii_config.svh"
  `include "gmii_sequencer.svh"
  `include "gmii_driver.svh"
  `include "gmii_monitor.svh"
  `include "gmii_agent.svh"
  `include "gmii_sequences.svh"
  `include "gmii_checker.svh"
  `include "gmii_coverage.svh"
endpackage
