// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_transaction.svh -- GMII transaction

class gmii_transaction extends uvm_sequence_item;
  `uvm_object_utils(gmii_transaction)

  rand bit [7:0] txd;
  rand bit tx_en;
  rand bit tx_er;
  bit [7:0] rxd_o;
  bit rx_dv_o;
  bit rx_er_o;
  bit [31:0] tag;

  function new(string name = "gmii_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    gmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    txd = rhs_.txd;
    tx_en = rhs_.tx_en;
    tx_er = rhs_.tx_er;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    gmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           txd == rhs_.txd &&
           tx_en == rhs_.tx_en &&
           tx_er == rhs_.tx_er;
  endfunction

  function string convert2string();
    return $sformatf("GMII{tag=%0h txd=0x%0h tx_en=0x%0h tx_er=0x%0h}", tag, txd, tx_en, tx_er);
  endfunction
endclass
