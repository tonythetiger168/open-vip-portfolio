// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_coverage.svh -- GMII functional coverage

class gmii_coverage extends uvm_subscriber #(gmii_transaction);
  `uvm_component_utils(gmii_coverage)
  gmii_config cfg;
  gmii_transaction tr;

  covergroup gmii_cg;
    cp_kind   : coverpoint tr.kind { bins k[] = {GMII_FRAME, GMII_FC}; }
    cp_status : coverpoint tr.status iff (tr.kind == GMII_FRAME);
    cp_cast   : coverpoint tr.cast iff (tr.kind == GMII_FRAME && tr.status inside {0, 7}) { bins u = {1}; bins m = {2}; bins b = {3}; }
    cp_vlan   : coverpoint tr.vlan iff (tr.kind == GMII_FRAME && tr.status == 0);
    cp_pause  : coverpoint tr.pause iff (tr.kind == GMII_FRAME && tr.status == 0);
    cp_type   : coverpoint (tr.etype > 1500) iff (tr.kind == GMII_FRAME && tr.status == 0);
    cp_len    : coverpoint tr.len iff (tr.kind == GMII_FRAME && tr.status == 0) {
                  bins min_ = {64}; bins short_ = {[65:127]}; bins mid = {[128:1023]}; bins long_ = {[1024:1517]};
                  bins max_ = {1518}; bins tag_max = {[1519:1522]}; }
    cp_fc   : coverpoint tr.fc_out iff (tr.kind == GMII_FC) { bins seen = {1}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    gmii_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(gmii_config)::get(this, "", "cfg", cfg))
      cfg = gmii_config::type_id::create("cfg");
  endfunction

  function void write(gmii_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    gmii_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("GMII coverage: %0.1f%%", gmii_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
