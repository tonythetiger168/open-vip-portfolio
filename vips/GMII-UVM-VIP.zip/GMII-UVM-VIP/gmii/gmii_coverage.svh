// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_coverage.svh -- GMII functional coverage

class gmii_coverage extends uvm_subscriber #(gmii_transaction);
  `uvm_component_utils(gmii_coverage)
  gmii_config cfg;
  gmii_transaction tr;

  covergroup gmii_cg;
    coverpoint tr.txd;
    coverpoint tr.tx_en;
    coverpoint tr.tx_er;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(gmii_config)::get(this, "*", "cfg", cfg));
  endfunction

  function void write(gmii_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    gmii_cg.sample();
  endfunction
endclass
