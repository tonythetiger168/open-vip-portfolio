// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_monitor.svh -- GMII monitor: decodes observed bus activity

class gmii_monitor extends uvm_monitor;
  `uvm_component_utils(gmii_monitor)

  virtual gmii_if vif;
  uvm_analysis_port #(gmii_transaction) ap;
  gmii_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual gmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gmii: virtual interface not set")
    void'(uvm_config_db#(gmii_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    gmii_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = gmii_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.txd = vif.txd;
        t.tx_en = vif.tx_en;
        t.tx_er = vif.tx_er;
        t.rxd_o = vif.rxd;
        t.rx_dv_o = vif.rx_dv;
        t.rx_er_o = vif.rx_er;
        ap.write(t);
      end
    end
  endtask
endclass
