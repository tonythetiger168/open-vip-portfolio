// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_monitor.svh -- GMII monitor: frames on the transmit pins paired in order with the looped-back receive frames

class gmii_monitor extends uvm_monitor;
  `uvm_component_utils(gmii_monitor)

  virtual gmii_if vif;
  uvm_analysis_port #(gmii_transaction) ap;
  gmii_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual gmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gmii: virtual interface not set")
    if (!uvm_config_db#(gmii_config)::get(this, "", "cfg", cfg))
      cfg = gmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] l0[$];
      bit [3:0] lo0 = 0;
      bit h0 = 0, a0 = 0, e0 = 0;
      bit [7:0] l1[$];
      bit [3:0] lo1 = 0;
      bit h1 = 0, a1 = 0, e1 = 0;
      gmii_transaction in_q[$];
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rx_dv) begin
          a1 = 1;
          if (vif.mon_cb.rx_er) e1 = 1;
          l1.push_back(vif.mon_cb.rxd);
        end else if (a1) begin
            if (in_q.size() == 0) `uvm_error("MON", "GMII frame received that was never sent")
            else begin
              gmii_transaction t = in_q.pop_front();
              frame(l1, t, 1);
              t.out_er = e1;
              publish(t);
            end
          l1.delete(); a1 = 0; h1 = 0; e1 = 0;
        end
        if (vif.mon_cb.tx_en) begin
          a0 = 1;
          if (vif.mon_cb.tx_er) e0 = 1;
          l0.push_back(vif.mon_cb.txd);
        end else if (a0) begin
            begin
              gmii_transaction t = gmii_transaction::type_id::create("t");
              frame(l0, t, 0);
              t.inject_er = e0;
              in_q.push_back(t);
            end
          l0.delete(); a0 = 0; h0 = 0; e0 = 0;
        end
      end
    end
  endtask

  function void publish(gmii_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // split a byte stream into the preamble/SFD check and the frame bytes
  // (out = 0: transmit side into bytes, 1: receive side into out_bytes)
  function void frame(bit [7:0] l[$], gmii_transaction t, bit out);
    bit ok = (l.size() >= 8);
    for (int i = 0; i < 8 && i < l.size(); i++) if (l[i] != ((i == 7) ? 8'hD5 : 8'h55)) ok = 0;
    if (out) begin t.out_preamble_ok = ok; t.out_bytes.delete(); end
    else     begin t.preamble_ok = ok;     t.bytes.delete(); end
    for (int i = 8; i < l.size(); i++)
      if (out) t.out_bytes.push_back(l[i]); else t.bytes.push_back(l[i]);
  endfunction
endclass
