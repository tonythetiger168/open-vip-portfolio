// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_monitor.svh -- GMII monitor: frames and bus events on the receive pins, with the MAC's status and reported fields

class gmii_monitor extends uvm_monitor;
  `uvm_component_utils(gmii_monitor)

  virtual gmii_if vif;
  uvm_analysis_port #(gmii_transaction) ap;
  gmii_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual gmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "gmii: virtual interface not set")
    if (!uvm_config_db#(gmii_config)::get(this, "", "cfg", cfg))
      cfg = gmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] b[$];
      bit inf = 0, sfd = 0, pb = 0, ce = 0, fcq = 0;
      gmii_transaction pend[$];
      gmii_transaction fct;
      forever begin
        bit [7:0] d;
        bit dv, er, fc;
        @(vif.mon_cb);
        if (vif.mon_cb.rst_n !== 1'b1) begin inf = 0; fcq = 0; pend.delete(); fct = null; continue; end
        // DUT results for earlier bus activity
        if (fct != null) begin fct.fc_out = vif.mon_cb.false_carrier; publish(fct); fct = null; end
        else if (vif.mon_cb.false_carrier) `uvm_error("MON", "GMII false_carrier without a false carrier on the bus")
        if (vif.mon_cb.fr_done) begin
          if (pend.size() == 0) `uvm_error("MON", "GMII fr_done without a frame")
          else begin
            gmii_transaction t = pend.pop_front();
            t.status = vif.mon_cb.fr_status; t.len = vif.mon_cb.fr_len; t.etype = vif.mon_cb.fr_etype;
            t.cast = vif.mon_cb.fr_cast; t.vlan = vif.mon_cb.fr_vlan; t.pause = vif.mon_cb.pause_valid;
            t.quanta = t.pause ? vif.mon_cb.pause_quanta : 16'h0;
            publish(t);
          end
        end
        // the bus
        d = vif.mon_cb.rxd; dv = vif.mon_cb.rx_dv; er = vif.mon_cb.rx_er;
        if (dv) begin
          fcq = 0;
          if (!inf) begin inf = 1; b.delete(); sfd = (d == 8'hD5); pb = (d != 8'h55 && d != 8'hD5); ce = er; end
          else begin
            if (er) ce = 1;
            if (!sfd) begin if (d == 8'hD5) sfd = 1; else if (d != 8'h55) pb = 1; end
            else b.push_back(d);
          end
        end else begin
          if (inf) begin
            gmii_transaction t = gmii_transaction::type_id::create("t");
            inf = 0; t.kind = GMII_FRAME; t.bytes = b; t.pre_bad = pb || !sfd; t.code_err = ce;
            pend.push_back(t);
          end
          fc = er && d == 8'h0E;
          if (fc && !fcq) begin fct = gmii_transaction::type_id::create("fc"); fct.kind = GMII_FC; end
          fcq = fc;
        end
      end
    end
  endtask

  function void publish(gmii_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
