// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_compliance_checker.sv -- GMII concurrent assertion checks (bindable)

module gmii_compliance_checker
  (input logic clk, input logic rst_n, input [7:0] txd, input tx_en, input tx_er, input [7:0] rxd, input rx_dv, input rx_er);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({rxd, rx_dv, rx_er}))
    else $error("GMII: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> rxd == '0)
    else $error("GMII: output not in reset value");
  // loopback latency is exactly one clock
  assert property (@(posedge clk) disable iff (!rst_n) rxd == $past(txd))
    else $error("GMII: loopback data mismatch");
  cover property (@(posedge clk) disable iff (!rst_n) (rxd != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (rx_dv == 1'b1));
endmodule
