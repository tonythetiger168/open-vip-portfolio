// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_sequences.svh -- GMII sequences

// Random traffic: cfg.num_items constrained-random items.
class gmii_base_sequence extends uvm_sequence #(gmii_transaction);
  `uvm_object_utils(gmii_base_sequence)
  gmii_config cfg;

  function new(string name = "gmii_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = gmii_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "gmii_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class gmii_directed_sequence extends uvm_sequence #(gmii_transaction);
  `uvm_object_utils(gmii_directed_sequence)
  gmii_config cfg;

  function new(string name = "gmii_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function gmii_transaction item();
    item = gmii_transaction::type_id::create("req");
  endfunction

  task send(gmii_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    gmii_transaction t;
    t = item(); t.plen = 46;  t.seed = 32'h1; t.post_randomize(); send(t);   // 64-byte minimum frame
    t = item(); t.plen = 100; t.seed = 32'h2; t.post_randomize(); send(t);
    t = item(); t.plen = 60; t.seed = 32'h3; t.post_randomize(); t.inject_er = 1; send(t);
    for (int i = 0; i < 3; i++) begin t = item(); t.plen = 50 + i; t.seed = 32'h10 + i; t.post_randomize(); send(t); end
  endtask
endclass
