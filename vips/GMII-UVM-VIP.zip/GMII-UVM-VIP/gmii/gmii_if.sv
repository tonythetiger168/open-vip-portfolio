// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// gmii_if.sv -- GMII interface

interface gmii_if (input logic clk);
  logic rst_n;

  logic [7:0] txd;
  logic tx_en;
  logic tx_er;
  logic [7:0] rxd;
  logic rx_dv;
  logic rx_er;

  modport DUT (input clk, rst_n, txd, tx_en, tx_er, output rxd, rx_dv, rx_er);
  modport DRV (input clk, rst_n, rxd, rx_dv, rx_er, output txd, tx_en, tx_er);
  modport MON (input clk, rst_n, txd, tx_en, tx_er, rxd, rx_dv, rx_er);

  clocking drv_cb @(posedge clk);
    input rst_n, txd, tx_en, tx_er, rxd, rx_dv, rx_er;
    output txd, tx_en, tx_er;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, txd, tx_en, tx_er, rxd, rx_dv, rx_er;
  endclocking
endinterface
