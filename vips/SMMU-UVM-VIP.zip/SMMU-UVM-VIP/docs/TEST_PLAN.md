# SMMU-UVM-VIP test plan

## Register test (`smmu_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `smmu_bypass_test`: CTRL.enable = 0: 60 random reads and writes (1..16
  beats) reach m_* at the same address with the same ID; data both ways; no
  walk, HITS = MISSES = 0.
- `smmu_xlate_test`: 16 mapped pages (12 writable) at random VPNs and PPNs,
  300 random reads and writes (writes only to writable pages) under four
  back-pressure settings. Checks: upstream read data = memory at the PA,
  writes land at the PA and nowhere else (m_* address windows: page table
  read-only, each mapped page as its PTE allows), every walk is one beat at
  PT_BASE + 4 * VPN with ID 15 and AxPROT 3'b010, forwarded bursts keep the
  upstream ID, HITS and MISSES equal the TLB model, no fault.
- `smmu_fault_test`: read and write of an invalid page (FAULT_INFO 0001 /
  0101), write to a read-only page on a cold TLB and on a TLB hit (0110),
  walk into a SLVERR page table (1000 / 1100): SLVERR upstream on every beat,
  nothing but the walk on m_*, memory untouched, FAULT_ADDR, FAULT interrupt;
  a good access afterwards still works.
- `smmu_inv_test`: a cached translation survives a PTE change (TLB hit to the
  old PA) until CMD.tlb_inv, then the new PA is used; round-robin eviction:
  after 5 distinct pages the first one walks again.
