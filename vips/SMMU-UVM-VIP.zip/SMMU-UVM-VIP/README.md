# SMMU UVM VIP (SMMU-UVM-VIP)

UVM verification IP for the open-ip-portfolio **SMMU** subsystem: SMMU / IOMMU: 4 KB page translation with a 4-entry TLB, hardware table walk and fault reporting between AXI4 ports.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`8e9722204875`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 15) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.
The AXI4 subordinate port (`s_*`) is driven by the kit's manager BFM.

## What SMMU does (from the spec)

- s_* is the AXI4 subordinate port of the upstream master, m_* the AXI4 manager port downstream; both pass through unchanged.
- PTE at PT_BASE + 4 * VA[31:12]: bit 0 VALID, bit 1 WRITABLE, bits 31:12 PPN; PA = {PPN, VA[11:0]}. Walks are single-beat reads with ID 15 (AxPROT 3'b010).
- 4-entry fully associative TLB, round-robin fill; CMD.tlb_inv empties it.
- Fault (not VALID, walk error response, write to a page that is not WRITABLE): the burst is not forwarded and ends with SLVERR upstream (all W beats taken first); FAULT_ADDR = VA, FAULT_INFO = {walk_err, write, not_writable, not_valid}.
- CTRL.enable 0: bypass (PA = VA). One burst at a time; reads and writes alternate when both wait.

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `smmu/` -- `smmu_ral.svh` register model (generated from the spec, same
  offsets as `SMMU_apb`), `smmu_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `smmu_pins_if.sv`
- `rtl/` -- `SMMU_apb.sv`, `SMMU_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/smmu.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | CTRL | rw |
| 0x018 | PT_BASE | rw |
| 0x01C | CMD | cmd |
| 0x020 | STATUS | ro |
| 0x024 | FAULT_ADDR | ro |
| 0x028 | FAULT_INFO | ro |
| 0x02C | TLB_STATS | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 FAULT.

## Tests

| Test | Seeds |
|---|---|
| `smmu_ral_test` | 1 |
| `smmu_bypass_test` | 2 |
| `smmu_xlate_test` | 3 |
| `smmu_fault_test` | 2 |
| `smmu_inv_test` | 1 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT SMMU mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/smmu.f
./obj_dir/Vtop_tb +UVM_TESTNAME=smmu_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py SMMU-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
