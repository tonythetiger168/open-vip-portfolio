// SMMU-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+smmu
+incdir+tb
rtl/SMMU_top.sv
rtl/SMMU_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
smmu/smmu_pins_if.sv
common/ssv_pkg.sv
smmu/smmu_pkg.sv
tb/top_tb.sv
