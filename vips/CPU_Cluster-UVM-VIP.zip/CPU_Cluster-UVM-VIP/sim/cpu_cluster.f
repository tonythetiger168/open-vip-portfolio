// CPU_Cluster-UVM-VIP Verilator filelist (paths relative to the VIP root).
// Before it: +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv; top module: top_tb.
+define+UVM_NO_DPI
+incdir+common
+incdir+cpu_cluster
+incdir+tb
rtl/soc_ss_axi_engine.sv
rtl/CPU_Cluster_top.sv
rtl/CPU_Cluster_apb.sv
common/axim_if.sv
common/ssv_apb_if.sv
cpu_cluster/cpu_cluster_pins_if.sv
common/ssv_pkg.sv
cpu_cluster/cpu_cluster_pkg.sv
tb/top_tb.sv
