# CPU_Cluster UVM VIP (CPU_Cluster-UVM-VIP)

UVM verification IP for the open-ip-portfolio **CPU_Cluster** subsystem: CPU cluster memory-traffic model: cache-line write, check and copy jobs on an AXI4 manager.

The bench runs the real RTL (`rtl/`, a snapshot of open-ip-portfolio commit
`8e9722204875`) with its APB4 register port on an APB agent and RAL model, and
its AXI4 manager port (`m_*`, ID 0) on the AXI4 manager-port kit: a
memory-backed subordinate with back-pressure, latency and error regions, a
monitor that checks every burst against the IP's AXI contract, and coverage.


## What CPU_Cluster does (from the spec)

- MODE 0 WRITE: word i of DST = pattern(i), write-only.
- MODE 1 CHECK: read word i of SRC, compare with pattern(i); MISMATCHES counts differences (saturating), FIRST_FAIL is the index of the first one. Read-only.
- MODE 2 COPY: DST word i = SRC word i. (MODE 3 behaves as COPY.)
- pattern(i) = SEED ^ {~i[15:0], i[15:0]}, i = 0 .. LEN-1.
- Interrupts DONE, ERR (AXI error response), MISMATCH (a CHECK job found a difference).

## Structure

- `common/` -- `ssv_pkg`: APB4 agent + RAL adapter, AXI4 manager-port kit
  (`axim_if` with cycle-level checks, `axim_subordinate`, `axim_monitor`,
  `axim_coverage`, manager BFM), `ssv_env`, `ssv_base_test`
- `cpu_cluster/` -- `cpu_cluster_ral.svh` register model (generated from the spec, same
  offsets as `CPU_Cluster_apb`), `cpu_cluster_pkg.sv` (base test, RAL test, functional tests
  with the reference model and scoreboard), `cpu_cluster_pins_if.sv`
- `rtl/` -- `CPU_Cluster_apb.sv`, `CPU_Cluster_top.sv` and their dependencies, unchanged
  from open-ip-portfolio (`rtl/SNAPSHOT.txt`)
- `tb/top_tb.sv` -- testbench top
- `sim/cpu_cluster.f`, `sim/testlist.txt` -- filelist and test list for regression runners

## Register map

| Offset | Name | Kind |
|---|---|---|
| 0x000 | ID | id |
| 0x004 | IRQ_STATUS | irq_status |
| 0x008 | IRQ_ENABLE | irq_enable |
| 0x00C | FLAGS | flags |
| 0x010 | SCRATCH | scratch |
| 0x014 | SRC_ADDR | rw |
| 0x018 | DST_ADDR | rw |
| 0x01C | LEN | rw |
| 0x020 | CTRL | rw |
| 0x024 | SEED | rw |
| 0x028 | CMD | cmd |
| 0x02C | STATUS | ro |
| 0x030 | RESULT | ro |
| 0x034 | CYCLES | ro |

Interrupts (IRQ_STATUS / IRQ_ENABLE bits): 0 DONE, 1 ERR, 2 MISMATCH.

## Tests

| Test | Seeds |
|---|---|
| `cpu_cluster_ral_test` | 1 |
| `cpu_cluster_write_check_test` | 3 |
| `cpu_cluster_copy_test` | 2 |
| `cpu_cluster_err_test` | 2 |

A run passes when it ends with `SB_PASS checks=<n>` (functional tests) or
`RAL_PASS checks=<n>` (register test) and no UVM_ERROR / UVM_FATAL. Every run
also prints `FCOV <group> <point> <bin> <hits>` coverage lines and one
`LAT CPU_Cluster mem <R|W> <cycles>` line per completed AXI burst.

## Running (Verilator 5.052 + Accellera uvm-core 2020.3.1)

```
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module top_tb \
  +incdir+$UVM_CORE $UVM_CORE/uvm_pkg.sv -f sim/cpu_cluster.f
./obj_dir/Vtop_tb +UVM_TESTNAME=cpu_cluster_ral_test
```

or from the repo root: `python3 tools/run_uvm_tests.py CPU_Cluster-UVM-VIP`.

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
