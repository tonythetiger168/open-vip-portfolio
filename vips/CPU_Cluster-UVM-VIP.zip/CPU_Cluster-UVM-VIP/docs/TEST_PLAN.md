# CPU_Cluster-UVM-VIP test plan

## Register test (`cpu_cluster_ral_test`)

- ID reads the spec's code and version.
- `uvm_reg_hw_reset_seq`: every register that has a fixed reset value.
- `uvm_reg_bit_bash_seq`: every RW bit (IRQ_STATUS, core outputs and command
  pulses are left out: they are not plain storage).
- Random write + mirror check of every RW register.
- PSLVERR on the first unmapped word, on 0xFFC and on a misaligned address.

## AXI4 manager port (every test)

Checked on every burst by `axim_monitor` and `axim_if`: ID, INCR only, 4-byte
beats, 1..16 beats, no 4 KB crossing, aligned, full write strobes, WLAST /
RLAST position, one read and one write outstanding, address windows set per
job, responses matched to IDs, VALID/payload stability, no VALID in reset,
no X, every burst completes.

## Functional tests

- `cpu_cluster_write_check_test`: 24 rounds of WRITE a pattern, CHECK it back
  (0 mismatches, no MISMATCH interrupt), corrupt 1..5 random words by back
  door and CHECK again (mismatches and first_fail exact, MISMATCH set);
  lengths 1, 16, 17 and random up to 800 words; random seeds; addresses near
  4 KB boundaries; four back-pressure settings.
- `cpu_cluster_copy_test`: 24 COPY jobs (MODE 2 and 3): DST = SRC word for
  word, read / write counts, windows.
- `cpu_cluster_err_test`: WRITE into a DECERR region (words untouched), CHECK
  from a SLVERR region (those words read as 0 and mismatch), COPY with both:
  DONE + ERR, STATUS.err; a clean job clears it.
