// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_chi_tb.sv -- directed checks for CHI_top (rtl/CHI_top.sv) that the
// SVA-driven CHI_tb.sv does not make: exact response latency, the irq
// pulse per response, and acceptance on the last request credit.
// Run: python3 tools/run_func_tests.py CHI-VIP
//
// Contract (rtl/CHI_top.sv, CRD_MAX = 8, RSP_LAT = 4): a request flit is
// accepted in C_IDLE when txreqflitv and a request credit is left (rx_crd
// != 0); the response flit {5'b00001, txnID, addr[15:0], 1'b1} is valid
// RSP_LAT + 1 clocks after the accepting edge once a response credit is
// held; irq mirrors rxrspflitv; one request credit returns every 8 clocks.

module func_chi_tb;
  int checks = 0, fails = 0;
  logic clk = 1'b0, rst_n = 1'b0;
  logic [43:0] txreqflit = '0;
  logic        txreqflitv = 1'b0, rxrsplcrdv = 1'b0;
  wire         txreqlcrdv, rxrspflitv, busy, irq;
  wire  [33:0] rxrspflit;

  always #5 clk = ~clk;

  CHI_top dut (.clk(clk), .rst_n(rst_n), .txreqflit(txreqflit), .txreqflitv(txreqflitv),
               .txreqlcrdv(txreqlcrdv), .rxrspflit(rxrspflit), .rxrspflitv(rxrspflitv),
               .rxrsplcrdv(rxrsplcrdv), .busy(busy), .irq(irq));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // irq is exactly the response-valid strobe
  int irq_cnt = 0, rsp_cnt = 0, irq_mismatch = 0;
  always @(posedge clk) if (rst_n) begin
    if (irq !== rxrspflitv) irq_mismatch++;
    if (irq === 1'b1) irq_cnt++;
    if (rxrspflitv === 1'b1) rsp_cnt++;
  end

  int t_acc, t_rsp, lo_accepts;
  initial begin
    repeat (3) @(posedge clk);
    #1 rst_n = 1'b1;
    // one response credit for the first request
    @(negedge clk); rxrsplcrdv = 1'b1;
    @(negedge clk); rxrsplcrdv = 1'b0;

    // latency: accept edge -> response valid
    @(negedge clk); txreqflit = {12'h5A3, 32'h0000_BEEF}; txreqflitv = 1'b1;
    @(posedge clk); t_acc = $time;
    #1 chk(dut.cstate == 2'd1, "request accepted with a free credit");
    @(negedge clk); txreqflitv = 1'b0;
    while (rxrspflitv !== 1'b1) @(posedge clk) #1;
    t_rsp = $time;
    chk((t_rsp - t_acc) / 10 == 4 + 1, $sformatf("response valid RSP_LAT+1 clocks after the accepting edge (%0d)", (t_rsp - t_acc) / 10));
    chk(rxrspflit == {5'b00001, 12'h5A3, 16'hBEEF, 1'b1}, "response flit carries opcode OK, txnID and addr[15:0]");
    @(posedge clk) #1;
    chk(rxrspflitv === 1'b0 && busy === 1'b0, "one response per request, then idle");
    chk(irq_cnt == 1 && rsp_cnt == 1 && irq_mismatch == 0, $sformatf("irq pulses with the response (irq=%0d rsp=%0d mismatch=%0d)", irq_cnt, rsp_cnt, irq_mismatch));

    // no response credit: the response waits, irq stays low
    @(negedge clk); txreqflit = {12'h001, 32'h0000_0010}; txreqflitv = 1'b1;
    @(negedge clk); txreqflitv = 1'b0;
    repeat (12) @(posedge clk);
    #1 chk(rxrspflitv === 1'b0 && irq === 1'b0 && busy === 1'b1, "response held without a response credit");
    @(negedge clk); rxrsplcrdv = 1'b1;
    @(negedge clk); rxrsplcrdv = 1'b0;
    repeat (2) @(posedge clk);
    #1 chk(busy === 1'b0 && rsp_cnt == 2, "response sent once the credit arrives");

    // drain request credits with back-to-back requests (free response
    // credits) until one is accepted on the last credit
    lo_accepts = 0;
    rxrsplcrdv = 1'b1; txreqflitv = 1'b1;
    repeat (400) begin
      bit last_crd;
      @(negedge clk);
      last_crd = (dut.cstate == 2'd0 && dut.rx_crd == 4'd1);
      @(negedge clk);
      if (last_crd) begin
        chk(dut.cstate == 2'd1, "request accepted on the last credit");
        lo_accepts++;
      end
    end
    txreqflitv = 1'b0; rxrsplcrdv = 1'b0;
    chk(lo_accepts > 0, $sformatf("a request is accepted on the last credit (%0d)", lo_accepts));
    chk(irq_mismatch == 0, "irq mirrors rxrspflitv throughout");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
endmodule
