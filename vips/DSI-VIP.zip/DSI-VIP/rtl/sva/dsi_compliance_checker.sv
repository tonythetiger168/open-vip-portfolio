// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// dsi_compliance_checker.sv -- DSI tiered compliance SVA checker (module)
// L1 = basic compliance, L2 = full protocol, L3 = advanced, L4 = protocol-specific
`ifndef DSI_COMPLIANCE_CHECKER_SV
`define DSI_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

module dsi_compliance_checker (mipi_vip_if vif);
  int l1_pass[4], l1_fail[4];
  int l2_pass[4], l2_fail[4];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_dsi_dt; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.data_type inside {6'h01,6'h02,6'h03,6'h05,6'h06,6'h07,6'h08,6'h09,6'h0A,6'h0B,6'h0C,6'h0D,6'h0E,6'h11,6'h12,6'h13,6'h14,6'h15,6'h16,6'h17,6'h18,6'h19,6'h1A,6'h1B,6'h1C,6'h1D,6'h1E,6'h1F,6'h20,6'h21,6'h22,6'h23,6'h24,6'h25,6'h26,6'h27,6'h28,6'h29,6'h2A,6'h2B,6'h2C,6'h2D,6'h2E,6'h2F,6'h30,6'h31,6'h32,6'h33,6'h34,6'h35,6'h36,6'h37,6'h38,6'h39,6'h3A,6'h3B,6'h3C,6'h3D,6'h3E,6'h3F}; endproperty
  assert_p_dsi_dt: assert property(p_dsi_dt) l1_pass[0]++; else begin `uvm_warning("DSI_L1", "Data type valid failed"); l1_fail[0]++; end
  cover_p_dsi_dt: cover property(p_dsi_dt);
  property p_dsi_vc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.vc <= 2'd3; endproperty
  assert_p_dsi_vc: assert property(p_dsi_vc) l1_pass[1]++; else begin `uvm_warning("DSI_L1", "VC 0-3 failed"); l1_fail[1]++; end
  cover_p_dsi_vc: cover property(p_dsi_vc);
  property p_dsi_wc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.wc <= 16'hFFFF; endproperty
  assert_p_dsi_wc: assert property(p_dsi_wc) l1_pass[2]++; else begin `uvm_warning("DSI_L1", "WC 0-65535 failed"); l1_fail[2]++; end
  cover_p_dsi_wc: cover property(p_dsi_wc);
  property p_dsi_ecc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> vif.ecc_ok; endproperty
  assert_p_dsi_ecc: assert property(p_dsi_ecc) l1_pass[3]++; else begin `uvm_warning("DSI_L1", "ECC valid failed"); l1_fail[3]++; end
  cover_p_dsi_ecc: cover property(p_dsi_ecc);

  // ===== L2: Full Protocol (4 SVAs) =====
  property p_dsi_crc; @(posedge vif.clk) disable iff (!vif.rst_n) vif.eop |-> vif.crc_ok; endproperty
  assert_p_dsi_crc: assert property(p_dsi_crc) l2_pass[0]++; else begin `uvm_warning("DSI_L2", "CRC valid failed"); l2_fail[0]++; end
  cover_p_dsi_crc: cover property(p_dsi_crc);
  property p_dsi_lp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.lp_mode |-> !vif.hs_mode; endproperty
  assert_p_dsi_lp: assert property(p_dsi_lp) l2_pass[1]++; else begin `uvm_warning("DSI_L2", "LP mode failed"); l2_fail[1]++; end
  cover_p_dsi_lp: cover property(p_dsi_lp);
  property p_dsi_no_x; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> !$isunknown(vif.data); endproperty
  assert_p_dsi_no_x: assert property(p_dsi_no_x) l2_pass[2]++; else begin `uvm_warning("DSI_L2", "No X when valid failed"); l2_fail[2]++; end
  cover_p_dsi_no_x: cover property(p_dsi_no_x);
  property p_dsi_lane; @(posedge vif.clk) disable iff (!vif.rst_n) vif.valid |-> |vif.lane_active; endproperty
  assert_p_dsi_lane: assert property(p_dsi_lane) l2_pass[3]++; else begin `uvm_warning("DSI_L2", "Lane active failed"); l2_fail[3]++; end
  cover_p_dsi_lane: cover property(p_dsi_lane);

  // ===== L3: Advanced Features (4 SVAs) =====
  property p_dsi_bta; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bta |-> vif.lp_mode == 1; endproperty
  assert_p_dsi_bta: assert property(p_dsi_bta) l3_pass[0]++; else begin `uvm_warning("DSI_L3", "BTA valid failed"); l3_fail[0]++; end
  cover_p_dsi_bta: cover property(p_dsi_bta);
  property p_dsi_te; @(posedge vif.clk) disable iff (!vif.rst_n) vif.te |-> vif.vsync == 1; endproperty
  assert_p_dsi_te: assert property(p_dsi_te) l3_pass[1]++; else begin `uvm_warning("DSI_L3", "Tearing effect failed"); l3_fail[1]++; end
  cover_p_dsi_te: cover property(p_dsi_te);
  property p_dsi_ack; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ack |-> vif.lp_mode == 1; endproperty
  assert_p_dsi_ack: assert property(p_dsi_ack) l3_pass[2]++; else begin `uvm_warning("DSI_L3", "ACK valid failed"); l3_fail[2]++; end
  cover_p_dsi_ack: cover property(p_dsi_ack);
  property p_dsi_error; @(posedge vif.clk) disable iff (!vif.rst_n) vif.error_report |-> vif.lp_mode == 1; endproperty
  assert_p_dsi_error: assert property(p_dsi_error) l3_pass[3]++; else begin `uvm_warning("DSI_L3", "Error report failed"); l3_fail[3]++; end
  cover_p_dsi_error: cover property(p_dsi_error);

  // ---------------- L4: DSI protocol-specific rules (4) ----------------
  property p_dsi_l4_bta_lp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.bta |-> (vif.lp_mode && !vif.hs_mode); endproperty
  assert_p_dsi_l4_bta_lp: assert property(p_dsi_l4_bta_lp) l4_pass[0]++; else begin `uvm_warning("DSI_L4", "BTA not in LP mode failed"); l4_fail[0]++; end
  cover_p_dsi_l4_bta_lp: cover property(p_dsi_l4_bta_lp);
  property p_dsi_l4_te_vsync; @(posedge vif.clk) disable iff (!vif.rst_n) vif.te |-> vif.vsync; endproperty
  assert_p_dsi_l4_te_vsync: assert property(p_dsi_l4_te_vsync) l4_pass[1]++; else begin `uvm_warning("DSI_L4", "TE without VSYNC failed"); l4_fail[1]++; end
  cover_p_dsi_l4_te_vsync: cover property(p_dsi_l4_te_vsync);
  property p_dsi_l4_video_hs; @(posedge vif.clk) disable iff (!vif.rst_n) (vif.valid && vif.data_type inside {6'h0E,6'h1E,6'h2E,6'h18,6'h1F}) |-> vif.hs_mode; endproperty
  assert_p_dsi_l4_video_hs: assert property(p_dsi_l4_video_hs) l4_pass[2]++; else begin `uvm_warning("DSI_L4", "Video packet not in HS failed"); l4_fail[2]++; end
  cover_p_dsi_l4_video_hs: cover property(p_dsi_l4_video_hs);
  property p_dsi_l4_ack_lp; @(posedge vif.clk) disable iff (!vif.rst_n) vif.ack |-> vif.lp_mode; endproperty
  assert_p_dsi_l4_ack_lp: assert property(p_dsi_l4_ack_lp) l4_pass[3]++; else begin `uvm_warning("DSI_L4", "ACK outside LP mode failed"); l4_fail[3]++; end
  cover_p_dsi_l4_ack_lp: cover property(p_dsi_l4_ack_lp);

  final begin : sva_report
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0, l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ? ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("DSI_RPT", $sformatf("=== DSI Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("DSI_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("DSI_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("DSI_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("DSI_RPT", $sformatf("  L4 Protocol Specific:  %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("DSI_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov, l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule
`endif
