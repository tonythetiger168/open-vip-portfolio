// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_mipi_tb.sv -- self-checking functional test for the MIPI packet sink
// model (mipi_dut, flattened by smoke/flatten.py). The same model backs the
// CSI-2, C-PHY, D-PHY, DSI, M-PHY and UniPro VIPs, so this file is shared.
// Run: python3 tools/run_func_tests.py <VIP>
//
// Model contract (from tb/top_tb.sv):
//   * ready follows valid one clock later; a beat is taken when valid && ready.
//   * the sop beat carries the packet header on side-band (pkt_type, vc,
//     word_count, ecc) plus payload word 0; ecc_ok is registered on that beat
//     as ecc == {8'h00, ECC({word_count, vc[1:0], pkt_type})} (CSI-2 6-bit
//     Hamming code, bits 7:6 zero).
//   * on the eop beat crc_ok = (crc[15:0] == CRC-16 over every captured word,
//     bytes LSB first, poly 0x8408 reflected, seed 0xFFFF) and rx_pkts++.
//   * PHY side-band echoes, one clock late: dphy_hs_rqst->dphy_hs_rdy,
//     mphy_hs_mode->mphy_ready, unipro/hsi/cse valid->ready, hs_mode->term_en,
//     lane_state==LP11->cal_done, bta->ack, bta && !ecc_ok->error_report;
//     lane_count is 4.
// The ECC and CRC references below are written from the CSI-2 specification,
// not copied from the VIP package; the CRC is anchored on the specification's
// worked examples (CRC 0x00F0 and 0xE569).

`timescale 1ns/1ps   // the model delays its handshake outputs by #1ns

module func_mipi_tb;
`ifdef VIP_SMOKE_FLATTENED
  localparam logic [3:0] LP11 = 4'h7, LP00 = 4'h0;
  int checks = 0, fails = 0;

  logic        clk = 1'b0, rst_n = 1'b0;
  logic [31:0] data = '0, crc = '0;
  logic        valid = 1'b0, sop = 1'b0, eop = 1'b0;
  logic [5:0]  pkt_type = '0;
  logic [2:0]  vc = '0;
  logic [15:0] word_count = '0, ecc = '0;
  logic        dphy_hs_rqst = 0, mphy_hs_mode = 0, unipro_valid = 0, hsi_valid = 0, cse_valid = 0;
  logic        hs_mode = 0, bta = 0;
  logic [3:0]  lane_state = LP00;
  wire         ready, dphy_hs_rdy, mphy_ready, unipro_ready, hsi_ready, cse_ready;
  wire         ecc_ok, crc_ok, cal_done, ack, error_report, term_en;
  wire  [31:0] lane_count;

  always #5 clk = ~clk;

  mipi_dut u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_data(data), .vif_valid(valid), .vif_ready(ready),
    .vif_sop(sop), .vif_eop(eop), .vif_pkt_type(pkt_type), .vif_vc(vc),
    .vif_word_count(word_count), .vif_ecc(ecc), .vif_crc(crc),
    .vif_dphy_hs_rqst(dphy_hs_rqst), .vif_dphy_hs_rdy(dphy_hs_rdy),
    .vif_mphy_hs_mode(mphy_hs_mode), .vif_mphy_ready(mphy_ready),
    .vif_unipro_valid(unipro_valid), .vif_unipro_ready(unipro_ready),
    .vif_hsi_valid(hsi_valid), .vif_hsi_ready(hsi_ready),
    .vif_cse_valid(cse_valid), .vif_cse_ready(cse_ready),
    .vif_ecc_ok(ecc_ok), .vif_crc_ok(crc_ok), .vif_hs_mode(hs_mode), .vif_cal_done(cal_done),
    .vif_bta(bta), .vif_ack(ack), .vif_error_report(error_report), .vif_term_en(term_en),
    .vif_lane_count(lane_count), .vif_lane_state(lane_state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // ---- references from the specification ----
  // Hamming parity bit k covers data bits whose column in the CSI-2 ECC
  // table has bit k set.
  function automatic logic [7:0] ref_ecc(input logic [23:0] d);
    // columns for data bits 23..0
    localparam logic [143:0] COL = {6'h3B, 6'h37, 6'h2F, 6'h1F, 6'h38, 6'h34, 6'h32, 6'h31,
                                    6'h2C, 6'h2A, 6'h29, 6'h26, 6'h25, 6'h23, 6'h1C, 6'h1A,
                                    6'h19, 6'h16, 6'h15, 6'h13, 6'h0E, 6'h0D, 6'h0B, 6'h07};
    logic [7:0] p = '0;
    for (int i = 0; i < 24; i++) if (d[i]) p[5:0] ^= COL[i*6 +: 6];
    return p;
  endfunction

  function automatic logic [15:0] ref_crc(input logic [7:0] b[$]);
    logic [15:0] c = 16'hFFFF;
    foreach (b[i])
      for (int k = 0; k < 8; k++) begin
        logic fb = c[0] ^ b[i][k];
        c = c >> 1;
        if (fb) c ^= 16'h8408;
      end
    return c;
  endfunction

  // ---- packet driver ----
  logic [31:0] words[$];
  int          beats;
  task automatic send_pkt(input [5:0] dt, input [2:0] v, input [15:0] e_xor = 0,
                          input [15:0] c_xor = 0, input bit gap = 0);
    logic [7:0] bytes[$];
    foreach (words[i]) for (int b = 0; b < 4; b++) bytes.push_back(words[i][b*8 +: 8]);
    beats = 0;
    for (int i = 0; i < words.size(); i++) begin
      @(negedge clk);
      if (gap && i == 1) begin valid = 1'b0; @(negedge clk); @(negedge clk); end
      valid = 1'b1; data = words[i]; sop = (i == 0); eop = (i == words.size() - 1);
      pkt_type = dt; vc = v; word_count = words.size() * 4;
      ecc = {8'h00, ref_ecc({word_count, v[1:0], dt})} ^ e_xor;
      crc = {16'h0, ref_crc(bytes)} ^ c_xor;
      do @(posedge clk); while (!ready);   // beat accepted at this edge
      beats++;
    end
    @(negedge clk);
    valid = 1'b0; sop = 1'b0; eop = 1'b0;
  endtask

  // the specification's CRC examples (24 payload bytes each)
  logic [7:0] ex1[$] = '{8'hFF, 8'h00, 8'h00, 8'h02, 8'hB9, 8'hDC, 8'hF3, 8'h72, 8'hBB, 8'hD4, 8'hB8, 8'h5A,
                          8'hC8, 8'h75, 8'hC2, 8'h7C, 8'h81, 8'hF8, 8'h05, 8'hDF, 8'hFF, 8'h00, 8'h00, 8'h01};
  logic [7:0] ex2[$] = '{8'hFF, 8'h00, 8'h00, 8'h00, 8'h1E, 8'hF0, 8'h1E, 8'hC7, 8'h4F, 8'h82, 8'h78, 8'hC5,
                          8'h82, 8'hE0, 8'h8C, 8'h70, 8'hD2, 8'h3C, 8'h78, 8'hE9, 8'hFF, 8'h00, 8'h00, 8'h01};

  task automatic load_bytes(input logic [7:0] b[$]);
    words.delete();
    for (int i = 0; i < b.size(); i += 4) words.push_back({b[i+3], b[i+2], b[i+1], b[i]});
  endtask

  int pk0;

  initial begin
    repeat (2) @(negedge clk);
    chk(ready === 1'b0 && cal_done === 1'b0 && ack === 1'b0 && term_en === 1'b0,
        "outputs held low in reset");
    chk(!dphy_hs_rdy && !mphy_ready && !unipro_ready && !hsi_ready && !cse_ready && error_report === 1'b0,
        "PHY / link ready outputs and error report low in reset");
    chk(lane_count == 4, "lane_count reports 4 lanes in reset");
    rst_n = 1'b1;
    repeat (2) @(negedge clk);
    chk(lane_count == 4, "lane_count reports 4 lanes");

    // references
    chk(ref_crc(ex1) == 16'h00F0 && ref_crc(ex2) == 16'hE569,
        "CRC-16 reference matches the specification examples");

    // long packet with the spec payload: header ECC and payload CRC accepted
    pk0 = u_dut.rx_pkts;
    load_bytes(ex1);
    send_pkt(6'h2B, 3'd0);          // RAW10
    chk(beats == 6, "six payload words accepted with valid/ready");
    chk(ecc_ok === 1'b1, "correct header ECC flagged ecc_ok");
    chk(crc_ok === 1'b1, "correct payload CRC (spec example 1) flagged crc_ok");
    chk(u_dut.rx_pkts == pk0 + 1, "rx_pkts counts the packet at eop");

    load_bytes(ex2);
    send_pkt(6'h2A, 3'd2);          // RAW8 on VC2
    chk(ecc_ok === 1'b1 && crc_ok === 1'b1, "second spec example on VC2: ECC and CRC accepted");

    // single-bit header error and payload CRC error
    load_bytes(ex1);
    send_pkt(6'h2B, 3'd1, 16'h0001);
    chk(ecc_ok === 1'b0, "header ECC with one flipped parity bit flagged bad");
    chk(crc_ok === 1'b1, "payload CRC still good when only the ECC is wrong");
    send_pkt(6'h2B, 3'd1, 16'h0000, 32'h0000_8000);
    chk(ecc_ok === 1'b1 && crc_ok === 1'b0, "corrupted payload CRC flagged bad");

    // ECC covers word count, VC and data type
    for (int t = 0; t < 3; t++) begin
      logic [15:0] e; logic [23:0] h;
      h = {16'd24, 2'd1, 6'h2B};
      e = {8'h00, ref_ecc(h)};
      // ecc computed for one header, field changed on the wire
      words.delete(); load_bytes(ex1);
      @(negedge clk);
      valid = 1'b1; sop = 1'b1; eop = 1'b1; data = words[0]; word_count = 16'd24;
      vc = 3'd1; pkt_type = 6'h2B; ecc = e;
      if (t == 0) word_count = 16'd28;
      if (t == 1) vc = 3'd3;
      if (t == 2) pkt_type = 6'h2C;
      do @(posedge clk); while (!ready);
      @(negedge clk); valid = 1'b0; sop = 1'b0; eop = 1'b0;
      chk(ecc_ok === 1'b0, t == 0 ? "ECC detects a word-count change" :
                           t == 1 ? "ECC detects a virtual-channel change" :
                                    "ECC detects a data-type change");
    end

    // short packet (one beat with sop and eop), with a stall between beats
    words.delete(); words.push_back(32'h0000_0001);
    send_pkt(6'h00, 3'd0);          // frame start
    chk(ecc_ok === 1'b1 && crc_ok === 1'b1, "single-beat packet: header and CRC accepted");
    load_bytes(ex2);
    pk0 = u_dut.rx_pkts;
    send_pkt(6'h2A, 3'd0, 0, 0, 1'b1);
    chk(crc_ok === 1'b1 && u_dut.rx_pkts == pk0 + 1, "valid gap inside a packet keeps the payload intact");

    // ready backpressure: no beat taken on the first valid cycle
    @(negedge clk); valid = 1'b1; sop = 1'b0; eop = 1'b0;
    @(posedge clk); #1;
    chk(ready === 1'b0, "ready lags valid by one clock");
    @(negedge clk); chk(ready === 1'b1, "ready follows valid");
    valid = 1'b0;
    @(negedge clk); chk(ready === 1'b0, "ready drops with valid");

    // PHY / link side-band responses
    @(negedge clk);
    dphy_hs_rqst = 1; mphy_hs_mode = 1; unipro_valid = 1; hsi_valid = 1; cse_valid = 1; hs_mode = 1;
    lane_state = LP11;
    @(negedge clk);
    chk(dphy_hs_rdy && mphy_ready && unipro_ready && hsi_ready && cse_ready,
        "D-PHY/M-PHY/UniPro/HSI/CSE requests acknowledged");
    chk(term_en === 1'b1, "HS mode enables termination");
    chk(cal_done === 1'b1, "LP-11 reports calibration/stop state done");
    dphy_hs_rqst = 0; mphy_hs_mode = 0; unipro_valid = 0; hsi_valid = 0; cse_valid = 0; hs_mode = 0;
    lane_state = LP00;
    @(negedge clk);
    chk(!dphy_hs_rdy && !mphy_ready && !unipro_ready && !hsi_ready && !cse_ready && !term_en && !cal_done,
        "side-band responses drop when the requests drop");

    // bus turnaround: ack, and error report after a bad header
    load_bytes(ex1);
    send_pkt(6'h2B, 3'd0);
    @(negedge clk); bta = 1;
    @(negedge clk);
    chk(ack === 1'b1 && error_report === 1'b0, "BTA acknowledged, no error after a good packet");
    bta = 0;
    send_pkt(6'h2B, 3'd0, 16'h0004);
    @(negedge clk); bta = 1;
    @(negedge clk);
    chk(ack === 1'b1 && error_report === 1'b1, "BTA after an ECC error reports the error");
    bta = 0;
    @(negedge clk);
    chk(ack === 1'b0 && error_report === 1'b0, "ack and error report are single-cycle with BTA");

    // reset in the middle of a packet
    @(negedge clk); valid = 1; sop = 1; eop = 0; data = 32'h1234_5678;
    @(negedge clk); rst_n = 0;
    @(negedge clk);
    chk(ready === 1'b0 && ecc_ok === 1'b0 && crc_ok === 1'b0 && u_dut.rx_pkts == 0,
        "reset clears handshake, status and packet count");
    valid = 0; sop = 0; rst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
