// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_cse_tb.sv -- self-checking functional test for the MIPI CSE target
// model (mipi_dut, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py CSE-VIP
//
// Model contract (from tb/top_tb.sv):
//   * IDLE: cse_ready is high; a command (cse_cmd, operand on cse_data) is
//     taken when cse_valid && cse_ready, then the target is busy for 5
//     clocks and drives the response byte on cse_data with cse_irq high for
//     5 clocks, after which it is ready again.
//   * commands: 0 NOP->00, 1 RD_REG->reg[op[7:4]], 2 WR_REG reg[op[7:4]]=op[3:0]
//     ->op[3:0], 3 RD_MEM, 4 WR_MEM (same encoding), 5 STATUS->{err,1},
//     6 RESET (clears registers, memory, config, error)->A5, 7->00,
//     8 SET_CFG cfg=op->op, 9 GET_CFG->cfg, 10..15 illegal->EE and sets the
//     sticky error.
//   * side-band: ready/dphy/mphy/unipro/hsi acknowledges follow their
//     requests one clock later.

module func_cse_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0, fails = 0;

  logic       clk = 1'b0, rst_n = 1'b0;
  logic       valid = 0, dphy_hs_rqst = 0, mphy_hs_mode = 0, unipro_valid = 0, hsi_valid = 0;
  logic       cse_valid = 0, drv = 0;
  logic [3:0] cse_cmd = '0;
  logic [7:0] op = '0;
  wire  [7:0] cse_data;
  wire        ready, dphy_hs_rdy, mphy_ready, unipro_ready, hsi_ready, cse_ready, cse_irq;

  assign cse_data = drv ? op : 8'hzz;

  always #5 clk = ~clk;

  mipi_dut u_dut (
    .vif_clk(clk), .vif_rst_n(rst_n), .vif_valid(valid), .vif_ready(ready),
    .vif_dphy_hs_rqst(dphy_hs_rqst), .vif_dphy_hs_rdy(dphy_hs_rdy),
    .vif_mphy_hs_mode(mphy_hs_mode), .vif_mphy_ready(mphy_ready),
    .vif_unipro_valid(unipro_valid), .vif_unipro_ready(unipro_ready),
    .vif_hsi_valid(hsi_valid), .vif_hsi_ready(hsi_ready),
    .vif_cse_data(cse_data), .vif_cse_valid(cse_valid), .vif_cse_ready(cse_ready),
    .vif_cse_cmd(cse_cmd), .vif_cse_irq(cse_irq)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // issue one command; returns the response byte, the clocks from accept to
  // the first irq clock, the irq length, and whether cse_data stayed stable
  logic [7:0] rsp;
  int lat, irq_len;
  bit stable, bus_conflict;
  task automatic cmd(input [3:0] c, input [7:0] o);
    int t;
    @(negedge clk);
    while (!cse_ready) @(negedge clk);
    cse_valid = 1; cse_cmd = c; op = o; drv = 1;
    @(posedge clk);                     // accepted here
    @(negedge clk);
    cse_valid = 0; drv = 0;
    t = 0;
    while (!cse_irq && t < 50) begin @(negedge clk); t++; end
    lat = t; rsp = cse_data; irq_len = 0; stable = 1;
    while (cse_irq && irq_len < 50) begin
      if (cse_data !== rsp) stable = 0;
      irq_len++; @(negedge clk);
    end
  endtask

  // the target must not drive cse_data outside its response window
  always @(posedge clk) if (!cse_irq && rst_n && !drv && cse_data !== 8'hzz) begin
    if (!bus_conflict) $display("  bus driven at %0t: %h", $time, cse_data);
    bus_conflict = 1;
  end

  initial begin
    repeat (2) @(negedge clk);
    chk(!cse_ready && !cse_irq && cse_data === 8'hzz, "reset: not ready, no irq, bus released");
    chk(!ready && !dphy_hs_rdy && !mphy_ready && !unipro_ready && !hsi_ready, "reset: side-band acknowledges low");
    rst_n = 1;
    repeat (2) @(negedge clk);
    chk(cse_ready === 1'b1, "ready in IDLE after reset");

    cmd(4'd0, 8'h00);
    chk(rsp === 8'h00, "NOP returns 00");
    chk(lat == 5, $sformatf("response starts 5 clocks after the command (got %0d)", lat));
    chk(irq_len == 5 && stable, $sformatf("irq held 5 clocks with a stable response byte (got %0d)", irq_len));

    // registers: write then read back, independent addresses
    cmd(4'd2, 8'h3A);
    chk(rsp === 8'h0A, "WR_REG echoes the written nibble");
    cmd(4'd2, 8'h75);
    cmd(4'd1, 8'h30);
    chk(rsp === 8'h0A, "RD_REG returns register 3");
    cmd(4'd1, 8'h70);
    chk(rsp === 8'h05, "RD_REG returns register 7");
    cmd(4'd1, 8'h40);
    chk(rsp === 8'h00, "unwritten register reads 00");

    // memory is separate from the register file
    cmd(4'd4, 8'h3C);
    chk(rsp === 8'h0C, "WR_MEM echoes the written nibble");
    cmd(4'd3, 8'h30);
    chk(rsp === 8'h0C, "RD_MEM returns memory word 3");
    cmd(4'd1, 8'h30);
    chk(rsp === 8'h0A, "memory write does not touch the register file");

    // configuration register
    cmd(4'd8, 8'hC3);
    chk(rsp === 8'hC3, "SET_CFG echoes the value");
    cmd(4'd9, 8'h00);
    chk(rsp === 8'hC3, "GET_CFG reads it back");

    // status and sticky error
    cmd(4'd5, 8'h00);
    chk(rsp === 8'h01, "STATUS: ready, no error");
    cmd(4'd7, 8'h00);
    chk(rsp === 8'h00, "command 7 returns 00 without error");
    cmd(4'd12, 8'h00);
    chk(rsp === 8'hEE, "illegal command returns EE");
    cmd(4'd5, 8'h00);
    chk(rsp === 8'h03, "STATUS reports the sticky error");
    cmd(4'd15, 8'h00);
    cmd(4'd10, 8'h00);
    chk(rsp === 8'hEE, "lowest illegal command (10) returns EE");

    // RESET clears everything
    cmd(4'd6, 8'h00);
    chk(rsp === 8'hA5, "RESET returns A5");
    cmd(4'd5, 8'h00);
    chk(rsp === 8'h01, "RESET clears the sticky error");
    cmd(4'd1, 8'h30);
    chk(rsp === 8'h00, "RESET clears the register file");
    cmd(4'd3, 8'h30);
    chk(rsp === 8'h00, "RESET clears the memory");
    cmd(4'd9, 8'h00);
    chk(rsp === 8'h00, "RESET clears the configuration");
    cmd(4'd10, 8'h00);
    cmd(4'd5, 8'h00);
    chk(rsp === 8'h03, "command 10 alone sets the sticky error");
    cmd(4'd6, 8'h00);

    // a command held while busy is not taken twice
    @(negedge clk);
    cse_valid = 1; cse_cmd = 4'd2; op = 8'h1F; drv = 1;
    @(posedge clk); @(negedge clk);
    chk(cse_ready === 1'b0, "ready drops once a command is accepted");
    op = 8'h12;                         // changed while busy: must be ignored
    repeat (3) @(negedge clk);
    cse_valid = 0; drv = 0;
    while (!cse_ready) @(negedge clk);
    cmd(4'd1, 8'h10);
    chk(rsp === 8'h0F, "operand changes while busy are ignored");

    chk(!bus_conflict, "target drives cse_data only while cse_irq is high");

    // side-band handshakes
    @(negedge clk); valid = 1; dphy_hs_rqst = 1; mphy_hs_mode = 1; unipro_valid = 1; hsi_valid = 1;
    @(negedge clk);
    chk(ready && dphy_hs_rdy && mphy_ready && unipro_ready && hsi_ready, "side-band requests acknowledged");
    valid = 0; dphy_hs_rqst = 0; mphy_hs_mode = 0; unipro_valid = 0; hsi_valid = 0;
    @(negedge clk);
    chk(!ready && !dphy_hs_rdy && !mphy_ready && !unipro_ready && !hsi_ready, "acknowledges drop");

    // reset during a response
    @(negedge clk); cse_valid = 1; cse_cmd = 4'd2; op = 8'h55; drv = 1;
    @(negedge clk); cse_valid = 0; drv = 0;
    repeat (6) @(negedge clk);
    chk(cse_irq === 1'b1, "in response window before reset");
    rst_n = 0;
    @(negedge clk);
    chk(!cse_irq && cse_data === 8'hzz && !cse_ready, "reset ends the response and releases the bus");
    rst_n = 1;
    repeat (2) @(negedge clk);
    cmd(4'd1, 8'h50);
    chk(rsp === 8'h00, "reset clears the register file");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #100000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
