// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// test_pkg.sv -- multi-protocol test package (JTAG deepened)

`ifndef TEST_PKG_SV
`define TEST_PKG_SV

package test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import jtag_pkg::*;
  import env_pkg::*;

  class base_test extends uvm_test;
    `uvm_component_utils(base_test)
    multi_protocol_env env;
    function new(string name = "base_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = multi_protocol_env::type_id::create("env", this);
    endfunction
    virtual task run_phase(uvm_phase phase);
      phase.raise_objection(this);
      #5000ns;
      phase.drop_objection(this);
    endtask
  endclass

  // ---------------- JTAG tests (deepened) ----------------
  class jtag_random_test extends base_test;
    `uvm_component_utils(jtag_random_test)
    function new(string name = "jtag_random_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    virtual task run_phase(uvm_phase phase);
      jtag_random_sequence seq = jtag_random_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.num_txns = 50;
      seq.start(env.jtag_agt.sqr);
      #2000ns;
      phase.drop_objection(this);
    endtask
  endclass

  class jtag_regression_test extends base_test;
    `uvm_component_utils(jtag_regression_test)
    function new(string name = "jtag_regression_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    virtual task run_phase(uvm_phase phase);
      jtag_regression_sequence seq = jtag_regression_sequence::type_id::create("seq");
      phase.raise_objection(this);
      seq.start(env.jtag_agt.sqr);
      #5000ns;
      phase.drop_objection(this);
    endtask
  endclass

  class full_regression_test extends base_test;
    `uvm_component_utils(full_regression_test)
    function new(string name = "full_regression_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
    virtual task run_phase(uvm_phase phase);
      jtag_regression_sequence jseq = jtag_regression_sequence::type_id::create("jseq");
      jtag_stress_sequence     sseq = jtag_stress_sequence::type_id::create("sseq");
      phase.raise_objection(this);
      jseq.start(env.jtag_agt.sqr);
      sseq.num_txns = 100;
      sseq.start(env.jtag_agt.sqr);
      #10000ns;
      phase.drop_objection(this);
    endtask
  endclass

  // ---------------- stub tests for companion protocols ----------------
  class sata_random_test extends base_test;
    `uvm_component_utils(sata_random_test)
    function new(string name = "sata_random_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
  class sata_regression_test extends base_test;
    `uvm_component_utils(sata_regression_test)
    function new(string name = "sata_regression_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
  class nvme_random_test extends base_test;
    `uvm_component_utils(nvme_random_test)
    function new(string name = "nvme_random_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
  class nvme_regression_test extends base_test;
    `uvm_component_utils(nvme_regression_test)
    function new(string name = "nvme_regression_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
  class bt5_random_test extends base_test;
    `uvm_component_utils(bt5_random_test)
    function new(string name = "bt5_random_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
  class bt5_regression_test extends base_test;
    `uvm_component_utils(bt5_regression_test)
    function new(string name = "bt5_regression_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
  class dp2_random_test extends base_test;
    `uvm_component_utils(dp2_random_test)
    function new(string name = "dp2_random_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
  class dp2_regression_test extends base_test;
    `uvm_component_utils(dp2_regression_test)
    function new(string name = "dp2_regression_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction
  endclass
endpackage
`endif
