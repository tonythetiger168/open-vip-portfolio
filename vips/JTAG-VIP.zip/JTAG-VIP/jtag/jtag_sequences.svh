// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_sequences.svh

class jtag_base_sequence extends uvm_sequence #(jtag_transaction);
  `uvm_object_utils(jtag_base_sequence)
  function new(string name = "jtag_base_sequence");
    super.new(name);
  endfunction
endclass

class jtag_random_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_random_sequence)
  rand int num_txns = 100;
  constraint c_num { num_txns inside {[10:500]}; }
  function new(string name = "jtag_random_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_transaction tx;
    repeat (num_txns) begin
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize()) `uvm_error("RANDFAIL", "JTAG tx randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class jtag_idcode_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_idcode_sequence)
  rand int num_txns = 10;
  function new(string name = "jtag_idcode_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_transaction tx;
    repeat (num_txns) begin
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { op == jtag_transaction::OP_IDCODE; ir_data == 5'h01; })
        `uvm_error("RANDFAIL", "JTAG IDCODE randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class jtag_bypass_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_bypass_sequence)
  rand int num_txns = 20;
  function new(string name = "jtag_bypass_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_transaction tx;
    repeat (num_txns) begin
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { op == jtag_transaction::OP_BYPASS; ir_data == 5'h1F; })
        `uvm_error("RANDFAIL", "JTAG BYPASS randomization failed")
      finish_item(tx);
    end
  endtask
endclass

class jtag_reset_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_reset_sequence)
  rand int num_txns = 5;
  function new(string name = "jtag_reset_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_transaction tx;
    repeat (num_txns) begin
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { op == jtag_transaction::OP_RESET; trst_assert == 1; })
        `uvm_error("RANDFAIL", "JTAG reset randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: DR scans of varying length
class jtag_dr_scan_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_dr_scan_sequence)
  rand int num_txns = 20;
  function new(string name = "jtag_dr_scan_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_transaction tx;
    repeat (num_txns) begin
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { op == jtag_transaction::OP_DR_SCAN;
                                 dr_length inside {[1:64]}; })
        `uvm_error("RANDFAIL", "JTAG DR scan randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Directed: IR scan immediately followed by DR scan (back-to-back scans)
class jtag_back_to_back_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_back_to_back_sequence)
  rand int num_txns = 10;
  function new(string name = "jtag_back_to_back_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_transaction tx;
    repeat (num_txns) begin
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { op == jtag_transaction::OP_IR_SCAN; })
        `uvm_error("RANDFAIL", "JTAG IR randomization failed")
      finish_item(tx);
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { op == jtag_transaction::OP_DR_SCAN;
                                 dr_length inside {[8:32]}; })
        `uvm_error("RANDFAIL", "JTAG DR randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Corner case: maximum-length DR shifts (128 bits)
class jtag_corner_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_corner_sequence)
  function new(string name = "jtag_corner_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_transaction tx;
    repeat (5) begin
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { op == jtag_transaction::OP_DR_SCAN;
                                 dr_length == 128; })
        `uvm_error("RANDFAIL", "JTAG corner randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Stress: long random mix with pause-state and error flags exercised
class jtag_stress_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_stress_sequence)
  rand int num_txns = 200;
  function new(string name = "jtag_stress_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_transaction tx;
    repeat (num_txns) begin
      tx = jtag_transaction::type_id::create("tx");
      start_item(tx);
      if (!tx.randomize() with { op inside {jtag_transaction::OP_IR_SCAN,
                                            jtag_transaction::OP_DR_SCAN,
                                            jtag_transaction::OP_IDLE};
                                 pause_state dist {0:=70, 1:=30}; })
        `uvm_error("RANDFAIL", "JTAG stress randomization failed")
      finish_item(tx);
    end
  endtask
endclass

// Regression: weighted mix of all directed sequences
class jtag_regression_sequence extends jtag_base_sequence;
  `uvm_object_utils(jtag_regression_sequence)
  function new(string name = "jtag_regression_sequence");
    super.new(name);
  endfunction
  task body();
    jtag_idcode_sequence      idc = jtag_idcode_sequence::type_id::create("idc");
    jtag_bypass_sequence      byp = jtag_bypass_sequence::type_id::create("byp");
    jtag_dr_scan_sequence     drs = jtag_dr_scan_sequence::type_id::create("drs");
    jtag_back_to_back_sequence b2b = jtag_back_to_back_sequence::type_id::create("b2b");
    jtag_corner_sequence      cor = jtag_corner_sequence::type_id::create("cor");
    jtag_reset_sequence       rst = jtag_reset_sequence::type_id::create("rst");
    idc.num_txns = 10; byp.num_txns = 20; drs.num_txns = 20; b2b.num_txns = 10;
    idc.start(m_sequencer); byp.start(m_sequencer);
    drs.start(m_sequencer); b2b.start(m_sequencer);
    cor.start(m_sequencer); rst.start(m_sequencer);
  endtask
endclass
