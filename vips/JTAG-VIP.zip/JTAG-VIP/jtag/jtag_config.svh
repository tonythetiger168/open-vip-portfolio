// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_config.svh

class jtag_config extends uvm_object;
  `uvm_object_utils(jtag_config)
  bit enable_checker  = 1;
  bit enable_coverage = 1;
  int ir_width = 5;
  int dr_width = 32;
  bit [4:0] bypass_instr = 5'b11111;
  bit [4:0] idcode_instr = 5'b00001;
  bit [4:0] sample_instr = 5'b00010;
  bit [4:0] extest_instr = 5'b00000;
  function new(string name = "jtag_config");
    super.new(name);
  endfunction
endclass
