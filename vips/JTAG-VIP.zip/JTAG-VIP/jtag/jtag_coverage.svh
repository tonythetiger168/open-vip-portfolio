// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_coverage.svh

class jtag_coverage extends coverage_collector_base;
  `uvm_component_utils(jtag_coverage)
  uvm_analysis_imp #(jtag_transaction, jtag_coverage) analysis_export;
  jtag_transaction tx;
  int sample_count = 0;

  covergroup jtag_op_cg;
    option.per_instance = 1;
    op_cp: coverpoint tx.op {
      bins reset   = {jtag_transaction::OP_RESET};
      bins idle    = {jtag_transaction::OP_IDLE};
      bins ir_scan = {jtag_transaction::OP_IR_SCAN};
      bins dr_scan = {jtag_transaction::OP_DR_SCAN};
      bins bypass  = {jtag_transaction::OP_BYPASS};
      bins idcode  = {jtag_transaction::OP_IDCODE};
      bins sample  = {jtag_transaction::OP_SAMPLE};
      bins extest  = {jtag_transaction::OP_EXTEST};
      bins runbist = {jtag_transaction::OP_RUNBIST};
      bins clamp   = {jtag_transaction::OP_CLAMP};
      bins highz   = {jtag_transaction::OP_HIGHZ};
      bins user    = {jtag_transaction::OP_USER};
    }
    ir_cp: coverpoint tx.ir_data { bins low = {[0:15]}; bins mid = {[16:31]}; }
    dr_len_cp: coverpoint tx.dr_length {
      bins len_small = {[1:8]}; bins len_medium = {[9:32]}; bins len_large = {[33:64]}; bins len_xlarge = {[65:128]};
    }
    error_cp: coverpoint tx.with_error;
    pause_cp: coverpoint tx.pause_state;
    op_x_error: cross op_cp, error_cp;
    op_x_pause: cross op_cp, pause_cp;
  endgroup

  // FSM-oriented coverage: TAP operation flow transitions
  covergroup jtag_fsm_cg;
    option.per_instance = 1;
    op_trans_cp: coverpoint tx.op {
      bins ir_then_dr  = (jtag_transaction::OP_IR_SCAN => jtag_transaction::OP_DR_SCAN);
      bins dr_then_ir  = (jtag_transaction::OP_DR_SCAN => jtag_transaction::OP_IR_SCAN);
      bins dr_chain    = (jtag_transaction::OP_DR_SCAN => jtag_transaction::OP_DR_SCAN);
      bins rst_to_op   = (jtag_transaction::OP_RESET   => jtag_transaction::OP_IR_SCAN);
      bins idle_to_dr  = (jtag_transaction::OP_IDLE    => jtag_transaction::OP_DR_SCAN);
    }
    op_state_cp: coverpoint tx.op {
      bins scans[] = {jtag_transaction::OP_IR_SCAN, jtag_transaction::OP_DR_SCAN,
                      jtag_transaction::OP_RESET, jtag_transaction::OP_IDLE,
                      jtag_transaction::OP_BYPASS, jtag_transaction::OP_IDCODE};
    }
  endgroup

  // Data-pattern coverage: shifted data corners
  covergroup jtag_data_cg;
    option.per_instance = 1;
    dr_pat_cp: coverpoint tx.dr_data[31:0] {
      bins zero = {32'h0};
      bins ones = {32'hFFFF_FFFF};
      bins aa55 = {32'hAAAA_AAAA, 32'h5555_5555};
      bins walk = {32'h0000_0001, 32'h0000_0010, 32'h0000_0100, 32'h0000_1000,
                   32'h0001_0000, 32'h0010_0000, 32'h0100_0000, 32'h1000_0000};
      bins other = default;
    }
    ir_pat_cp: coverpoint tx.ir_data[4:0] {
      bins idcode = {5'h01};
      bins sample = {5'h02};
      bins extest = {5'h00};
      bins bypass = {5'h1F};
      bins user   = default;
    }
    dr_x_ir: cross dr_pat_cp, ir_pat_cp;
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
    jtag_op_cg = new();
    jtag_fsm_cg = new();
    jtag_data_cg = new();
  endfunction
  function void write(jtag_transaction tx_);
    tx = tx_;
    sample_coverage(tx);
  endfunction
  virtual function void sample_coverage(uvm_sequence_item tx_);
    jtag_transaction jtx;
    if (!$cast(jtx, tx_)) return;
    tx = jtx;
    jtag_op_cg.sample();
    jtag_fsm_cg.sample();
    jtag_data_cg.sample();
    sample_count++;
  endfunction
  function void report_phase(uvm_phase phase);
    `uvm_info("JTAG_COV", $sformatf("Sampled %0d transactions", sample_count), UVM_LOW)
    `uvm_info("JTAG_COV", $sformatf("Operation coverage = %0.2f%%", jtag_op_cg.get_coverage()), UVM_LOW)
    `uvm_info("JTAG_COV", $sformatf("FSM coverage = %0.2f%%", jtag_fsm_cg.get_coverage()), UVM_LOW)
    `uvm_info("JTAG_COV", $sformatf("Data coverage = %0.2f%%", jtag_data_cg.get_coverage()), UVM_LOW)
  endfunction
endclass
