// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_pkg.sv

package jtag_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  `include "jtag_config.svh"
  `include "jtag_transaction.svh"
  `include "jtag_sequencer.svh"
  `include "jtag_driver.svh"
  `include "jtag_monitor.svh"
  `include "jtag_checker.svh"
  `include "jtag_coverage.svh"
  `include "jtag_agent.svh"
  `include "jtag_sequences.svh"
endpackage
