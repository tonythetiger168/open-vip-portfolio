// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_checker.svh

class jtag_checker extends protocol_checker_base;
  `uvm_component_utils(jtag_checker)
  uvm_analysis_imp #(jtag_transaction, jtag_checker) analysis_export;
  jtag_config cfg;
  int tx_count = 0;
  bit [3:0] tms_history;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_export = new("analysis_export", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(jtag_config)::get(this, "", "cfg", cfg))
      cfg = jtag_config::type_id::create("cfg");
  endfunction
  function void write(jtag_transaction tx);
    tx_count++;
    check_ir_width(tx);
    check_dr_length(tx);
    check_tap_reset(tx);
    check_bypass(tx);
    check_trst_timing(tx);
  endfunction
  function void check_ir_width(jtag_transaction tx);
    if (tx.op == jtag_transaction::OP_IR_SCAN && tx.dr_length > cfg.ir_width)
      check_protocol_error($sformatf("IR scan length %0d exceeds width %0d", tx.dr_length, cfg.ir_width));
  endfunction
  function void check_dr_length(jtag_transaction tx);
    if (tx.op == jtag_transaction::OP_DR_SCAN && tx.dr_length > 128)
      check_protocol_warning($sformatf("DR scan length %0d very large", tx.dr_length));
  endfunction
  function void check_tap_reset(jtag_transaction tx);
    if (tx.op == jtag_transaction::OP_RESET && !tx.trst_assert)
      check_protocol_warning("TAP reset without TRST assertion");
  endfunction
  function void check_bypass(jtag_transaction tx);
    if (tx.op == jtag_transaction::OP_BYPASS && tx.ir_data != cfg.bypass_instr)
      check_protocol_error($sformatf("BYPASS instruction mismatch: expected 0x%0x, got 0x%0x",
        cfg.bypass_instr, tx.ir_data));
  endfunction
  function void check_trst_timing(jtag_transaction tx);
    if (tx.trst_assert && tx.op != jtag_transaction::OP_RESET)
      check_protocol_warning("TRST asserted during non-reset operation");
  endfunction
  task run_phase(uvm_phase phase); endtask
  function void report_phase(uvm_phase phase);
    `uvm_info("JTAG_CHK", $sformatf("Checked %0d transactions, %0d errors, %0d warnings",
      tx_count, error_count, warning_count), UVM_LOW)
  endfunction
endclass
