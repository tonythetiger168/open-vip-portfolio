// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_transaction.svh

class jtag_transaction extends uvm_sequence_item;
  `uvm_object_utils(jtag_transaction)

  typedef enum bit [3:0] {
    OP_RESET      = 4'h0,
    OP_IDLE       = 4'h1,
    OP_IR_SCAN    = 4'h2,
    OP_DR_SCAN    = 4'h3,
    OP_BYPASS     = 4'h4,
    OP_IDCODE     = 4'h5,
    OP_SAMPLE     = 4'h6,
    OP_EXTEST     = 4'h7,
    OP_RUNBIST    = 4'h8,
    OP_CLAMP      = 4'h9,
    OP_HIGHZ      = 4'hA,
    OP_USER       = 4'hB
  } jtag_op_e;

  rand jtag_op_e   op;
  rand bit [31:0]  ir_data;
  rand bit [127:0] dr_data;
  rand int         dr_length;
  rand bit [31:0]  expected_dr;
  rand bit         pause_state;
  rand bit         with_error;
  rand bit         trst_assert;

  constraint c_ir { ir_data inside {[0:31]}; }
  constraint c_dr_len { dr_length inside {[1:128]}; }
  constraint c_error { with_error dist {0:=95, 1:=5}; }
  constraint c_trst { trst_assert dist {0:=98, 1:=2}; }
  // REACHABILITY: include RUNBIST/CLAMP/HIGHZ so jtag_op_cg op bins 8-10 are
  // generatable; the driver default arm drives them safely as a TMS=0 idle clock.
  constraint c_op {
    op dist {OP_RESET:=5, OP_IDLE:=10, OP_IR_SCAN:=20, OP_DR_SCAN:=30,
             OP_BYPASS:=10, OP_IDCODE:=10, OP_SAMPLE:=5, OP_EXTEST:=5,
             OP_RUNBIST:=2, OP_CLAMP:=2, OP_HIGHZ:=2, OP_USER:=5};
  }

  function new(string name = "jtag_transaction");
    super.new(name);
  endfunction

  function string convert2string();
    return $sformatf("JTAG: op=%s ir=0x%0x dr_len=%0d dr=0x%0x pause=%b err=%b trst=%b",
      op.name(), ir_data, dr_length, dr_data, pause_state, with_error, trst_assert);
  endfunction
endclass
