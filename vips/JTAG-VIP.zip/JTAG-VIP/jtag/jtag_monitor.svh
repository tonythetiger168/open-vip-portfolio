// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_monitor.svh

class jtag_monitor extends uvm_monitor;
  `uvm_component_utils(jtag_monitor)
  virtual jtag_if vif;
  uvm_analysis_port #(jtag_transaction) ap;
  jtag_config cfg;
  tap_state_e tap_state;
  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual jtag_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "JTAG virtual interface not found")
    if (!uvm_config_db#(jtag_config)::get(this, "", "cfg", cfg))
      cfg = jtag_config::type_id::create("cfg");
    tap_state = TEST_LOGIC_RESET;
  endfunction
  task run_phase(uvm_phase phase);
    jtag_transaction tx;
    bit [127:0] shift_reg;
    int shift_cnt;
    forever begin
      @(vif.mon_cb);
      // async reset forces the TAP to Test-Logic-Reset
      if (vif.mon_cb.trst_n !== 1'b1) begin
        tap_state = TEST_LOGIC_RESET;
        continue;
      end
      // TAP state machine decode
      case (tap_state)
        TEST_LOGIC_RESET: tap_state = vif.mon_cb.tms ? TEST_LOGIC_RESET : RUN_TEST_IDLE;
        RUN_TEST_IDLE:    tap_state = vif.mon_cb.tms ? SELECT_DR_SCAN : RUN_TEST_IDLE;
        SELECT_DR_SCAN:   tap_state = vif.mon_cb.tms ? SELECT_IR_SCAN : CAPTURE_DR;
        CAPTURE_DR:       tap_state = vif.mon_cb.tms ? EXIT1_DR : SHIFT_DR;
        SHIFT_DR:         tap_state = vif.mon_cb.tms ? EXIT1_DR : SHIFT_DR;
        EXIT1_DR:         tap_state = vif.mon_cb.tms ? UPDATE_DR : PAUSE_DR;
        PAUSE_DR:         tap_state = vif.mon_cb.tms ? EXIT2_DR : PAUSE_DR;
        EXIT2_DR:         tap_state = vif.mon_cb.tms ? UPDATE_DR : SHIFT_DR;
        UPDATE_DR:        tap_state = vif.mon_cb.tms ? SELECT_DR_SCAN : RUN_TEST_IDLE;
        SELECT_IR_SCAN:   tap_state = vif.mon_cb.tms ? TEST_LOGIC_RESET : CAPTURE_IR;
        CAPTURE_IR:       tap_state = vif.mon_cb.tms ? EXIT1_IR : SHIFT_IR;
        SHIFT_IR:         tap_state = vif.mon_cb.tms ? EXIT1_IR : SHIFT_IR;
        EXIT1_IR:         tap_state = vif.mon_cb.tms ? UPDATE_IR : PAUSE_IR;
        PAUSE_IR:         tap_state = vif.mon_cb.tms ? EXIT2_IR : PAUSE_IR;
        EXIT2_IR:         tap_state = vif.mon_cb.tms ? UPDATE_IR : SHIFT_IR;
        UPDATE_IR:        tap_state = vif.mon_cb.tms ? SELECT_DR_SCAN : RUN_TEST_IDLE;
      endcase
      // Detect transactions
      if (tap_state == SHIFT_IR) begin
        tx = jtag_transaction::type_id::create("tx");
        tx.op = jtag_transaction::OP_IR_SCAN;
        shift_cnt = 0;
        while (tap_state == SHIFT_IR) begin
          shift_reg[shift_cnt] = vif.mon_cb.tdi;
          shift_cnt++;
          @(vif.mon_cb);
          tap_state = vif.mon_cb.tms ? EXIT1_IR : SHIFT_IR;
        end
        tx.ir_data = shift_reg[31:0];
        tx.dr_length = cfg.ir_width;
        ap.write(tx);
        `uvm_info("JTAG_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_MEDIUM)
      end
      else if (tap_state == SHIFT_DR) begin
        tx = jtag_transaction::type_id::create("tx");
        tx.op = jtag_transaction::OP_DR_SCAN;
        shift_cnt = 0;
        while (tap_state == SHIFT_DR) begin
          shift_reg[shift_cnt] = vif.mon_cb.tdi;
          shift_cnt++;
          @(vif.mon_cb);
          tap_state = vif.mon_cb.tms ? EXIT1_DR : SHIFT_DR;
        end
        tx.dr_data = shift_reg;
        tx.dr_length = shift_cnt;
        ap.write(tx);
        `uvm_info("JTAG_MON", $sformatf("Monitored: %s", tx.convert2string()), UVM_MEDIUM)
      end
    end
  endtask
endclass
