// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_driver.svh

class jtag_driver extends uvm_driver #(jtag_transaction);
  `uvm_component_utils(jtag_driver)
  virtual jtag_if vif;
  jtag_config cfg;
  uvm_analysis_port #(jtag_transaction) drv_ap;  // expected items for scoreboard
  function new(string name, uvm_component parent);
    super.new(name, parent);
    drv_ap = new("drv_ap", this);
  endfunction
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual jtag_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "JTAG virtual interface not found")
    if (!uvm_config_db#(jtag_config)::get(this, "", "cfg", cfg))
      cfg = jtag_config::type_id::create("cfg");
  endfunction
  task run_phase(uvm_phase phase);
    forever begin
      seq_item_port.get_next_item(req);
      drive_item(req);
      // broadcast expected transaction (monitor only decodes shift scans)
      if (req.op inside {jtag_transaction::OP_IR_SCAN, jtag_transaction::OP_DR_SCAN})
        drv_ap.write(req);
      seq_item_port.item_done();
    end
  endtask
  task drive_item(jtag_transaction tx);
    `uvm_info("JTAG_DRV", $sformatf("Driving: %s", tx.convert2string()), UVM_MEDIUM)
    if (tx.trst_assert) begin
      vif.drv_cb.trst_n <= 0;
      repeat (5) @(vif.drv_cb);
      vif.drv_cb.trst_n <= 1;
    end
    case (tx.op)
      jtag_transaction::OP_RESET: begin
        vif.drv_cb.tms <= 1;
        repeat (5) @(vif.drv_cb);
      end
      jtag_transaction::OP_IDLE: begin
        vif.drv_cb.tms <= 0;
        @(vif.drv_cb);
      end
      jtag_transaction::OP_IR_SCAN: begin
        // TMS sequence: 1,1,0,0 -> Shift-IR
        vif.drv_cb.tms <= 1; @(vif.drv_cb);
        vif.drv_cb.tms <= 1; @(vif.drv_cb);
        vif.drv_cb.tms <= 0; @(vif.drv_cb);
        vif.drv_cb.tms <= 0; @(vif.drv_cb);
        // Shift IR
        for (int i = 0; i < cfg.ir_width; i++) begin
          vif.drv_cb.tdi <= tx.ir_data[i];
          vif.drv_cb.tms <= (i == cfg.ir_width - 1) ? 1 : 0;
          @(vif.drv_cb);
        end
        vif.drv_cb.tms <= 1; @(vif.drv_cb); // Update-IR
        vif.drv_cb.tms <= 0; @(vif.drv_cb); // Run-Test/Idle
      end
      jtag_transaction::OP_DR_SCAN: begin
        vif.drv_cb.tms <= 1; @(vif.drv_cb);
        vif.drv_cb.tms <= 0; @(vif.drv_cb);
        vif.drv_cb.tms <= 0; @(vif.drv_cb);
        for (int i = 0; i < tx.dr_length; i++) begin
          vif.drv_cb.tdi <= tx.dr_data[i];
          vif.drv_cb.tms <= (i == tx.dr_length - 1) ? 1 : 0;
          @(vif.drv_cb);
        end
        vif.drv_cb.tms <= 1; @(vif.drv_cb);
        vif.drv_cb.tms <= 0; @(vif.drv_cb);
      end
      default: begin
        vif.drv_cb.tms <= 0; @(vif.drv_cb);
      end
    endcase
  endtask
endclass
