// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// jtag_if.sv

interface jtag_if (input logic tck);
  logic tms;
  logic tdi;
  logic tdo;
  logic trst_n;
  logic tdo_oe;

  // TAP decode helper signals (driven by the DUT/TAP model, observed by the
  // SVA compliance checker)
  logic        ir_shift;        // 1 while TAP is in Shift-IR
  logic        dr_shift;        // 1 while TAP is in Shift-DR
  logic [7:0]  ir;              // current instruction register
  logic [15:0] dr_len;          // length of the last DR shift
  common_pkg::tap_state_e tap_state;       // current TAP state mirror


  modport DUT (input tck, tms, tdi, trst_n, output tdo, tdo_oe,
               output ir, ir_shift, dr_shift, dr_len, tap_state);
  modport TB  (input tck, tdo, tdo_oe, output tms, tdi, trst_n);

  clocking mon_cb @(posedge tck);
    input tms, tdi, tdo, trst_n, tdo_oe;
  endclocking

  // TMS/TDI change on the falling edge of TCK (IEEE 1149.1) and the TAP
  // samples them on the rising edge. A posedge clocking block raced the TAP
  // on Verilator, which applies the drive in the same time step.
  clocking drv_cb @(negedge tck);
    output tms, tdi, trst_n;
    input  tdo, tdo_oe;
  endclocking
endinterface
