// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// jtag Protocol Compliance Checker
`ifndef JTAG_PROTOCOL_CHECKER_SV
`define JTAG_PROTOCOL_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================================
// jtag_protocol_compliance_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content is preserved verbatim)
// ============================================================================
module jtag_protocol_compliance_checker_sva (jtag_if vif);

  property p_jtag_tlr; @(posedge vif.tck) disable iff (!vif.trst_n) vif.trst_n == 0 |-> vif.tms == 1; endproperty
  assert_p_jtag_tlr: assert property(p_jtag_tlr) else `uvm_warning("JTAG", "Reset to TLR failed");
  cover_p_jtag_tlr: cover property(p_jtag_tlr);
  property p_jtag_tdo_oe; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tdo_oe == 1 |-> vif.tms inside {0,1}; endproperty
  assert_p_jtag_tdo_oe: assert property(p_jtag_tdo_oe) else `uvm_warning("JTAG", "TDO OE when shifting failed");
  cover_p_jtag_tdo_oe: cover property(p_jtag_tdo_oe);
  property p_jtag_tms; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tms inside {0,1}; endproperty
  assert_p_jtag_tms: assert property(p_jtag_tms) else `uvm_warning("JTAG", "TMS valid failed");
  cover_p_jtag_tms: cover property(p_jtag_tms);
  property p_jtag_tdi; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tdi inside {0,1}; endproperty
  assert_p_jtag_tdi: assert property(p_jtag_tdi) else `uvm_warning("JTAG", "TDI valid failed");
  cover_p_jtag_tdi: cover property(p_jtag_tdi);
endmodule

// ============================================================================
// jtag_protocol_compliance_checker -- thin UVM shell (all SVA content moved to the jtag_protocol_compliance_checker_sva module above)
// ============================================================================
class jtag_protocol_compliance_checker extends uvm_component;
  `uvm_component_utils(jtag_protocol_compliance_checker)
  function new(string name="jtag_chk", uvm_component parent=null); super.new(name, parent); endfunction
endclass
`endif
