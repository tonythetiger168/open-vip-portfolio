// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// jtag Timing Performance Checker
`ifndef JTAG_TIMING_CHECKER_SV
`define JTAG_TIMING_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================================
// jtag_timing_performance_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content is preserved verbatim)
// ============================================================================
module jtag_timing_performance_checker_sva (jtag_if vif);

  property p_jtag_tck; @(posedge vif.tck) disable iff (!vif.trst_n) $stable(vif.tck) |-> ##1 $changed(vif.tck); endproperty
  assert_p_jtag_tck: assert property(p_jtag_tck) else `uvm_warning("JTAG", "TCK stable failed");
  cover_p_jtag_tck: cover property(p_jtag_tck);
  property p_jtag_reset; @(posedge vif.tck) disable iff (!vif.trst_n) vif.trst_n == 0 |-> ##[1:10] vif.trst_n == 1; endproperty
  assert_p_jtag_reset: assert property(p_jtag_reset) else `uvm_warning("JTAG", "Reset pulse failed");
  cover_p_jtag_reset: cover property(p_jtag_reset);
endmodule

// ============================================================================
// jtag_timing_performance_checker -- thin UVM shell (all SVA content moved to the jtag_timing_performance_checker_sva module above)
// ============================================================================
class jtag_timing_performance_checker extends uvm_component;
  `uvm_component_utils(jtag_timing_performance_checker)
  function new(string name="jtag_chk", uvm_component parent=null); super.new(name, parent); endfunction
endclass
`endif
