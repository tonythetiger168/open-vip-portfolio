// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// jtag Error Handling Checker
`ifndef JTAG_ERROR_CHECKER_SV
`define JTAG_ERROR_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================================
// jtag_error_handling_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content is preserved verbatim)
// ============================================================================
module jtag_error_handling_checker_sva (jtag_if vif);

  property p_jtag_no_x; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tdo_oe == 1 |-> !$isunknown(vif.tdo); endproperty
  assert_p_jtag_no_x: assert property(p_jtag_no_x) else `uvm_warning("JTAG", "No X on TDO failed");
  cover_p_jtag_no_x: cover property(p_jtag_no_x);
  property p_jtag_tlr_exit; @(posedge vif.tck) disable iff (!vif.trst_n) vif.trst_n == 1 && $past(vif.trst_n) == 0 |-> vif.tms == 1; endproperty
  assert_p_jtag_tlr_exit: assert property(p_jtag_tlr_exit) else `uvm_warning("JTAG", "TLR exit failed");
  cover_p_jtag_tlr_exit: cover property(p_jtag_tlr_exit);
  property p_jtag_idle; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tms == 0 && $past(vif.tms) == 0 |-> ##[1:5] vif.tdo_oe == 0 || vif.tdo_oe == 1; endproperty
  assert_p_jtag_idle: assert property(p_jtag_idle) else `uvm_warning("JTAG", "Run-Test/Idle entry failed");
  cover_p_jtag_idle: cover property(p_jtag_idle);
endmodule

// ============================================================================
// jtag_error_handling_checker -- thin UVM shell (all SVA content moved to the jtag_error_handling_checker_sva module above)
// ============================================================================
class jtag_error_handling_checker extends uvm_component;
  `uvm_component_utils(jtag_error_handling_checker)
  function new(string name="jtag_chk", uvm_component parent=null); super.new(name, parent); endfunction
endclass
`endif
