// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// jtag Data Integrity Checker
`ifndef JTAG_DATA_INTEGRITY_CHECKER_SV
`define JTAG_DATA_INTEGRITY_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================================
// jtag_data_integrity_checker_sva -- SVA-carrying module form of the checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content is preserved verbatim)
// ============================================================================
module jtag_data_integrity_checker_sva (jtag_if vif);

  property p_jtag_tdo; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tdo_oe == 1 |-> !$isunknown(vif.tdo); endproperty
  assert_p_jtag_tdo: assert property(p_jtag_tdo) else `uvm_warning("JTAG", "TDO valid when OE failed");
  cover_p_jtag_tdo: cover property(p_jtag_tdo);
  property p_jtag_shift; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tms == 0 && $past(vif.tms) == 0 |-> vif.tdo_oe == 1; endproperty
  assert_p_jtag_shift: assert property(p_jtag_shift) else `uvm_warning("JTAG", "Shift state failed");
  cover_p_jtag_shift: cover property(p_jtag_shift);
endmodule

// ============================================================================
// jtag_data_integrity_checker -- thin UVM shell (all SVA content moved to the jtag_data_integrity_checker_sva module above)
// ============================================================================
class jtag_data_integrity_checker extends uvm_component;
  `uvm_component_utils(jtag_data_integrity_checker)
  function new(string name="jtag_chk", uvm_component parent=null); super.new(name, parent); endfunction
endclass
`endif
