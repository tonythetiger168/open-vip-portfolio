// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

// JTAG Tiered Compliance SVA Checker
// Level: Medium | Total SVAs: 18
// L1=Basic Compliance | L2=Full Protocol | L3=Advanced Features
`ifndef JTAG_COMPLIANCE_CHECKER_SV
`define JTAG_COMPLIANCE_CHECKER_SV
`include "uvm_macros.svh"
import uvm_pkg::*;

// ============================================================================
// jtag_compliance_checker -- SVA-carrying module form of the tiered compliance checker
// (class-scope concurrent assertions are illegal per IEEE 1800; the SVA
//  content, counters and report output are preserved verbatim)
// ============================================================================
module jtag_compliance_checker (jtag_if vif);

  int l1_pass[4], l1_fail[4];
  int l2_pass[6], l2_fail[6];
  int l3_pass[4], l3_fail[4];
  int l4_pass[4], l4_fail[4];
  real l1_cov, l2_cov, l3_cov, l4_cov, total_cov;

  initial begin
    l1_cov = 0; l2_cov = 0; l3_cov = 0; l4_cov = 0; total_cov = 0;
  end

  // ===== L1: Basic Compliance (4 SVAs) =====
  property p_jtag_tlr; @(posedge vif.tck) disable iff (!vif.trst_n) vif.trst_n == 0 |-> vif.tms == 1; endproperty
  assert_p_jtag_tlr: assert property(p_jtag_tlr) l1_pass[0]++; else begin `uvm_warning("JTAG_L1", "Reset to TLR failed"); l1_fail[0]++; end
  cover_p_jtag_tlr: cover property(p_jtag_tlr);
  property p_jtag_tdo_oe; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tdo_oe == 1 |-> vif.tms inside {0,1}; endproperty
  assert_p_jtag_tdo_oe: assert property(p_jtag_tdo_oe) l1_pass[1]++; else begin `uvm_warning("JTAG_L1", "TDO OE failed"); l1_fail[1]++; end
  cover_p_jtag_tdo_oe: cover property(p_jtag_tdo_oe);
  property p_jtag_tms; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tms inside {0,1}; endproperty
  assert_p_jtag_tms: assert property(p_jtag_tms) l1_pass[2]++; else begin `uvm_warning("JTAG_L1", "TMS valid failed"); l1_fail[2]++; end
  cover_p_jtag_tms: cover property(p_jtag_tms);
  property p_jtag_tdi; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tdi inside {0,1}; endproperty
  assert_p_jtag_tdi: assert property(p_jtag_tdi) l1_pass[3]++; else begin `uvm_warning("JTAG_L1", "TDI valid failed"); l1_fail[3]++; end
  cover_p_jtag_tdi: cover property(p_jtag_tdi);

  // ===== L2: Full Protocol (6 SVAs) =====
  property p_jtag_tdo; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tdo_oe == 1 |-> !$isunknown(vif.tdo); endproperty
  assert_p_jtag_tdo: assert property(p_jtag_tdo) l2_pass[0]++; else begin `uvm_warning("JTAG_L2", "TDO valid failed"); l2_fail[0]++; end
  cover_p_jtag_tdo: cover property(p_jtag_tdo);
  property p_jtag_shift; @(posedge vif.tck) disable iff (!vif.trst_n) vif.tms == 0 && $past(vif.tms) == 0 |-> vif.tdo_oe == 1; endproperty
  assert_p_jtag_shift: assert property(p_jtag_shift) l2_pass[1]++; else begin `uvm_warning("JTAG_L2", "Shift state failed"); l2_fail[1]++; end
  cover_p_jtag_shift: cover property(p_jtag_shift);
  property p_jtag_tck; @(posedge vif.tck) disable iff (!vif.trst_n) $stable(vif.tck) |-> ##1 $changed(vif.tck); endproperty
  assert_p_jtag_tck: assert property(p_jtag_tck) l2_pass[2]++; else begin `uvm_warning("JTAG_L2", "TCK stable failed"); l2_fail[2]++; end
  cover_p_jtag_tck: cover property(p_jtag_tck);
  property p_jtag_reset; @(posedge vif.tck) disable iff (!vif.trst_n) vif.trst_n == 0 |-> ##[1:10] vif.trst_n == 1; endproperty
  assert_p_jtag_reset: assert property(p_jtag_reset) l2_pass[3]++; else begin `uvm_warning("JTAG_L2", "Reset pulse failed"); l2_fail[3]++; end
  cover_p_jtag_reset: cover property(p_jtag_reset);
  property p_jtag_ir; @(posedge vif.tck) disable iff (!vif.trst_n) vif.ir_shift == 1 |-> vif.ir <= 8'hFF; endproperty
  assert_p_jtag_ir: assert property(p_jtag_ir) l2_pass[4]++; else begin `uvm_warning("JTAG_L2", "IR valid failed"); l2_fail[4]++; end
  cover_p_jtag_ir: cover property(p_jtag_ir);
  property p_jtag_dr; @(posedge vif.tck) disable iff (!vif.trst_n) vif.dr_shift == 1 |-> vif.dr_len <= 16'hFFFF; endproperty
  assert_p_jtag_dr: assert property(p_jtag_dr) l2_pass[5]++; else begin `uvm_warning("JTAG_L2", "DR valid failed"); l2_fail[5]++; end
  cover_p_jtag_dr: cover property(p_jtag_dr);

  // ===== L3: Advanced Features (4 SVAs) =====
  // L3-1: from Test-Logic-Reset the TAP may only stay in TLR or move to Run-Test/Idle
  property p_jtag_l3_tlr_next; @(posedge vif.tck) disable iff (!vif.trst_n)
    vif.tap_state == common_pkg::TEST_LOGIC_RESET |=> vif.tap_state inside {common_pkg::TEST_LOGIC_RESET, common_pkg::RUN_TEST_IDLE}; endproperty
  assert_p_jtag_l3_tlr_next: assert property(p_jtag_l3_tlr_next) l3_pass[0]++; else begin `uvm_warning("JTAG_L3", "Illegal exit from TLR failed"); l3_fail[0]++; end
  cover_p_jtag_l3_tlr_next: cover property(p_jtag_l3_tlr_next);
  // L3-2: from Select-DR-Scan the TAP must go to Capture-DR or Select-IR-Scan
  property p_jtag_l3_seldr_next; @(posedge vif.tck) disable iff (!vif.trst_n)
    vif.tap_state == common_pkg::SELECT_DR_SCAN |=> vif.tap_state inside {common_pkg::CAPTURE_DR, common_pkg::SELECT_IR_SCAN}; endproperty
  assert_p_jtag_l3_seldr_next: assert property(p_jtag_l3_seldr_next) l3_pass[1]++; else begin `uvm_warning("JTAG_L3", "Illegal exit from Select-DR failed"); l3_fail[1]++; end
  cover_p_jtag_l3_seldr_next: cover property(p_jtag_l3_seldr_next);
  // L3-3: Shift-DR either holds or exits via Exit1-DR
  property p_jtag_l3_shiftdr_next; @(posedge vif.tck) disable iff (!vif.trst_n)
    vif.tap_state == common_pkg::SHIFT_DR |=> vif.tap_state inside {common_pkg::SHIFT_DR, common_pkg::EXIT1_DR}; endproperty
  assert_p_jtag_l3_shiftdr_next: assert property(p_jtag_l3_shiftdr_next) l3_pass[2]++; else begin `uvm_warning("JTAG_L3", "Illegal exit from Shift-DR failed"); l3_fail[2]++; end
  cover_p_jtag_l3_shiftdr_next: cover property(p_jtag_l3_shiftdr_next);
  // L3-4: IR and DR shift indicators are mutually exclusive
  property p_jtag_l3_shift_mutex; @(posedge vif.tck) disable iff (!vif.trst_n) !(vif.ir_shift && vif.dr_shift); endproperty
  assert_p_jtag_l3_shift_mutex: assert property(p_jtag_l3_shift_mutex) l3_pass[3]++; else begin `uvm_warning("JTAG_L3", "IR and DR shift simultaneous failed"); l3_fail[3]++; end
  cover_p_jtag_l3_shift_mutex: cover property(p_jtag_l3_shift_mutex);

  // ---------------- L4: JTAG protocol-specific rules (4) ----------------
  // L4-1: TDO must only be driven (tdo_oe) during Shift-IR or Shift-DR
  property p_jtag_l4_tdo_oe_shift;
    @(posedge vif.tck) disable iff (!vif.trst_n)
      vif.tdo_oe |-> (vif.ir_shift || vif.dr_shift);
  endproperty
  assert_p_jtag_l4_tdo_oe_shift: assert property(p_jtag_l4_tdo_oe_shift) l4_pass[0]++;
    else begin `uvm_warning("JTAG_L4", "TDO driven outside shift states"); l4_fail[0]++; end
  cover_p_jtag_l4_tdo_oe_shift: cover property(p_jtag_l4_tdo_oe_shift);

  // L4-2: TMS held high for 5 consecutive TCK edges forces Test-Logic-Reset
  property p_jtag_l4_tms5_tlr;
    @(posedge vif.tck) disable iff (!vif.trst_n)
      (vif.tms ##1 vif.tms ##1 vif.tms ##1 vif.tms ##1 vif.tms) |->
      (vif.tap_state == common_pkg::TEST_LOGIC_RESET);
  endproperty
  assert_p_jtag_l4_tms5_tlr: assert property(p_jtag_l4_tms5_tlr) l4_pass[1]++;
    else begin `uvm_warning("JTAG_L4", "TMS=1 x5 did not reach TLR"); l4_fail[1]++; end
  cover_p_jtag_l4_tms5_tlr: cover property(p_jtag_l4_tms5_tlr);

  // L4-3: instruction register never contains the illegal all-X / unknown value
  //       and BYPASS (all-ones) is reachable after Update-IR
  property p_jtag_l4_ir_known;
    @(posedge vif.tck) disable iff (!vif.trst_n)
      vif.ir_shift |-> !$isunknown(vif.ir);
  endproperty
  assert_p_jtag_l4_ir_known: assert property(p_jtag_l4_ir_known) l4_pass[2]++;
    else begin `uvm_warning("JTAG_L4", "IR unknown during Shift-IR"); l4_fail[2]++; end
  cover_p_jtag_l4_ir_known: cover property(p_jtag_l4_ir_known);

  // L4-4: every Shift-DR is eventually followed by Update-DR (no stuck shift)
  property p_jtag_l4_dr_completes;
    @(posedge vif.tck) disable iff (!vif.trst_n)
      $rose(vif.dr_shift) |-> s_eventually (!vif.dr_shift);
  endproperty
  assert_p_jtag_l4_dr_completes: assert property(p_jtag_l4_dr_completes) l4_pass[3]++;
    else begin `uvm_warning("JTAG_L4", "Shift-DR never completes"); l4_fail[3]++; end
  cover_p_jtag_l4_dr_completes: cover property(p_jtag_l4_dr_completes);

  final begin
    int l1_total=0, l2_total=0, l3_total=0, l4_total=0;
    int l1_hit=0, l2_hit=0, l3_hit=0, l4_hit=0;
    foreach(l1_pass[i]) begin l1_total++; if(l1_pass[i]>0) l1_hit++; end
    foreach(l2_pass[i]) begin l2_total++; if(l2_pass[i]>0) l2_hit++; end
    foreach(l3_pass[i]) begin l3_total++; if(l3_pass[i]>0) l3_hit++; end
    foreach(l4_pass[i]) begin l4_total++; if(l4_pass[i]>0) l4_hit++; end
    l1_cov = (l1_total>0) ? (l1_hit*100.0/l1_total) : 0;
    l2_cov = (l2_total>0) ? (l2_hit*100.0/l2_total) : 0;
    l3_cov = (l3_total>0) ? (l3_hit*100.0/l3_total) : 0;
    l4_cov = (l4_total>0) ? (l4_hit*100.0/l4_total) : 0;
    total_cov = (l1_total+l2_total+l3_total+l4_total>0) ?
                ((l1_hit+l2_hit+l3_hit+l4_hit)*100.0/(l1_total+l2_total+l3_total+l4_total)) : 0;
    `uvm_info("JTAG_RPT", $sformatf("=== JTAG Tiered SVA Report ==="), UVM_LOW)
    `uvm_info("JTAG_RPT", $sformatf("  L1 Basic Compliance:  %0.1f%% (%0d/%0d)", l1_cov, l1_hit, l1_total), UVM_LOW)
    `uvm_info("JTAG_RPT", $sformatf("  L2 Full Protocol:     %0.1f%% (%0d/%0d)", l2_cov, l2_hit, l2_total), UVM_LOW)
    `uvm_info("JTAG_RPT", $sformatf("  L3 Advanced Features: %0.1f%% (%0d/%0d)", l3_cov, l3_hit, l3_total), UVM_LOW)
    `uvm_info("JTAG_RPT", $sformatf("  L4 Protocol-Specific: %0.1f%% (%0d/%0d)", l4_cov, l4_hit, l4_total), UVM_LOW)
    `uvm_info("JTAG_RPT", $sformatf("  TOTAL SVA Coverage:   %0.1f%% (%0d/%0d)", total_cov,
              l1_hit+l2_hit+l3_hit+l4_hit, l1_total+l2_total+l3_total+l4_total), UVM_LOW)
  end
endmodule

`endif
