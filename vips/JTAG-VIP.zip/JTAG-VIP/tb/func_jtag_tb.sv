// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// func_jtag_tb.sv -- self-checking functional test for the IEEE 1149.1 TAP
// model (jtag_tap_dut in top/top_tb.sv, flattened by smoke/flatten.py).
// Run: python3 tools/run_func_tests.py JTAG-VIP
//
// Model contract (from top/top_tb.sv): 16-state TAP controller (state codes
// of common_pkg::tap_state_e), 5-bit IR (IDCODE 01 selected in
// Test-Logic-Reset, SAMPLE 02, EXTEST 00, BYPASS 1F, any other code selects
// a 32-bit user data register written on Update-DR), Capture-IR loads
// 0b00101, IDCODE 0x1ABC0043. TDI is sampled on the rising TCK edge, TDO
// changes on the falling edge and is enabled only in Shift-IR/Shift-DR.
// The next-state reference below is written from the 1149.1 state diagram.

module func_jtag_tb;
`ifdef VIP_SMOKE_FLATTENED
  // 1149.1 states with the model's encoding
  localparam bit [3:0] TLR = 4'hF, RTI = 4'hC, SDR = 4'h7, CDR = 4'h6, SHDR = 4'h2, E1DR = 4'h1,
                       PDR = 4'h3, E2DR = 4'h0, UDR = 4'h5, SIR = 4'h4, CIR = 4'hE, SHIR = 4'hA,
                       E1IR = 4'h9, PIR = 4'hB, E2IR = 4'h8, UIR = 4'hD;
  localparam bit [31:0] IDCODE = 32'h1ABC_0043;
  int checks = 0, fails = 0;

  logic tck = 0, tms = 1, tdi = 0, trst_n = 1;
  wire  tdo, tdo_oe, ir_shift, dr_shift;
  wire  [7:0]  ir;
  wire  [15:0] dr_len;
  wire  [3:0]  tap_state;

  jtag_tap_dut u_dut (
    .vif_tck(tck), .vif_tms(tms), .vif_tdi(tdi), .vif_tdo(tdo), .vif_trst_n(trst_n),
    .vif_tdo_oe(tdo_oe), .vif_ir_shift(ir_shift), .vif_dr_shift(dr_shift), .vif_ir(ir),
    .vif_dr_len(dr_len), .vif_tap_state(tap_state)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  function automatic bit [3:0] nxt(input bit [3:0] s, input bit m);
    case (s)
      TLR:  return m ? TLR  : RTI;   RTI:  return m ? SDR  : RTI;
      SDR:  return m ? SIR  : CDR;   CDR:  return m ? E1DR : SHDR;
      SHDR: return m ? E1DR : SHDR;  E1DR: return m ? UDR  : PDR;
      PDR:  return m ? E2DR : PDR;   E2DR: return m ? UDR  : SHDR;
      UDR:  return m ? SDR  : RTI;   SIR:  return m ? TLR  : CIR;
      CIR:  return m ? E1IR : SHIR;  SHIR: return m ? E1IR : SHIR;
      E1IR: return m ? UIR  : PIR;   PIR:  return m ? E2IR : PIR;
      E2IR: return m ? UIR  : SHIR;  UIR:  return m ? SDR  : RTI;
    endcase
  endfunction

  // one TCK cycle; tdo_s is TDO as seen before the rising edge
  bit tdo_s, oe_s;
  task automatic cyc(input bit m, input bit d = 0);
    tms = m; tdi = d;
    #5; tdo_s = tdo; oe_s = tdo_oe;
    tck = 1; #10; tck = 0; #5;
  endtask

  task automatic go_rti();
    repeat (5) cyc(1);
    cyc(0);
  endtask

  // shift n bits through IR or DR from Run-Test/Idle back to Run-Test/Idle
  task automatic scan(input bit is_ir, input int n, input bit [31:0] din, output bit [31:0] dout);
    dout = '0;
    cyc(1);                        // Select-DR
    if (is_ir) cyc(1);             // Select-IR
    cyc(0);                        // Capture
    cyc(0);                        // -> Shift
    for (int i = 0; i < n; i++) begin
      cyc(i == n - 1, din[i]);
      dout[i] = tdo_s;
    end
    cyc(1);                        // Update
    cyc(0);                        // Run-Test/Idle
  endtask

  bit [31:0] d;
  bit [3:0]  ref_s;
  bit        arc[16][2];
  int        narcs, mism, oe_bad;

  initial begin
    // asynchronous reset
    #1 trst_n = 0;
    #2;
    chk(tap_state == TLR && ir[4:0] == 5'h01, "TRST: Test-Logic-Reset with IDCODE selected");
    trst_n = 1;

    // random walk against the reference state diagram, covering every arc
    ref_s = TLR; mism = 0; oe_bad = 0;
    for (int i = 0; i < 3000; i++) begin
      bit m;
      m = $urandom_range(0, 1);
      cyc(m, $urandom_range(0, 1));
      arc[ref_s][m] = 1;
      ref_s = nxt(ref_s, m);
      if (tap_state !== ref_s) mism++;
      if (ir_shift !== (ref_s == SHIR) || dr_shift !== (ref_s == SHDR)) oe_bad++;
    end
    narcs = 0;
    foreach (arc[s, m]) narcs += arc[s][m];
    chk(mism == 0, $sformatf("state follows the 1149.1 diagram on a random TMS walk (%0d mismatches)", mism));
    chk(narcs == 32, $sformatf("random walk covered all 32 TAP arcs (got %0d)", narcs));
    chk(oe_bad == 0, "ir_shift/dr_shift flag exactly Shift-IR/Shift-DR");

    // five TMS=1 reach Test-Logic-Reset from any state
    for (int s = 0; s < 12; s++) begin
      go_rti();
      for (int k = 0; k < s; k++) cyc(k % 3 == 0);
      repeat (5) cyc(1);
      if (tap_state !== TLR) begin chk(0, "five TMS=1 reset"); break; end
    end
    chk(tap_state == TLR && ir[4:0] == 5'h01, "five TMS=1 reach Test-Logic-Reset and select IDCODE");

    // IDCODE after reset
    cyc(0);
    scan(0, 32, 32'h0, d);
    chk(d == IDCODE, $sformatf("IDCODE scanned out after reset (got %h)", d));
    chk(d[0] == 1'b1, "IDCODE LSB is 1");
    chk(dr_len == 32, "dr_len counts 32 shifted bits");

    // IR capture pattern and instruction load
    scan(1, 5, 5'h1F, d);
    chk(d[1:0] == 2'b01, "Capture-IR loads ...01 into the IR shift register");
    chk(d[4:0] == 5'b00101, "Capture-IR value 00101");
    chk(ir[4:0] == 5'h1F, "BYPASS loaded on Update-IR");

    // BYPASS: one-bit register, captures 0
    scan(0, 9, 32'h0000_01AB, d);
    chk(d[0] == 1'b0, "BYPASS captures 0");
    chk(d[8:1] == 8'hAB, $sformatf("BYPASS delays TDI by one bit (got %h)", d[8:0]));

    // user data register: write then capture back
    scan(1, 5, 5'h07, d);
    chk(ir[4:0] == 5'h07, "user instruction 0x07 loaded");
    scan(0, 32, 32'hDEAD_BEEF, d);
    scan(0, 32, 32'h1234_5678, d);
    chk(d == 32'hDEAD_BEEF, "user DR written on Update-DR is captured back");
    scan(0, 32, 32'h0, d);
    chk(d == 32'h1234_5678, "second write captured back");

    // SAMPLE and EXTEST capture values
    scan(1, 5, 5'h02, d);
    scan(0, 32, 32'h0, d);
    chk(d == 32'hCAFE_0001, "SAMPLE captures 0xCAFE0001");
    scan(1, 5, 5'h00, d);
    scan(0, 32, 32'hFFFF_FFFF, d);
    chk(d == 32'h0, "EXTEST captures 0");

    // IDCODE register is read-only
    scan(1, 5, 5'h07, d);
    scan(0, 32, 32'hA5A5_A5A5, d);
    scan(1, 5, 5'h01, d);
    scan(0, 32, 32'h5555_5555, d);
    chk(d == IDCODE, "IDCODE capture unaffected by shifted-in data");
    scan(1, 5, 5'h07, d);
    scan(0, 32, 32'h0, d);
    chk(d == 32'hA5A5_A5A5, "Update-DR under IDCODE does not write the user register");

    // Pause-DR in the middle of a scan keeps the shift register
    scan(1, 5, 5'h07, d);
    cyc(1); cyc(0); cyc(0);                       // Shift-DR
    for (int i = 0; i < 16; i++) begin cyc(i == 15, i[0]); d[i] = tdo_s; end   // Exit1-DR
    cyc(0); cyc(0); cyc(0);                       // Pause-DR x3
    chk(tap_state == PDR && !tdo_oe, "Pause-DR: TDO disabled");
    cyc(1); cyc(0);                               // Exit2-DR, Shift-DR
    for (int i = 16; i < 32; i++) begin cyc(i == 31, 1'b1); d[i] = tdo_s; end
    cyc(1); cyc(0);
    chk(d == 32'h0, "scan across Pause-DR shifts out the captured data");
    scan(0, 32, 32'h0, d);
    chk(d == 32'hFFFF_AAAA, $sformatf("data shifted around Pause-DR is updated intact (got %h)", d));

    // Capture-DR -> Exit1 -> Update with no shift keeps the register
    cyc(1); cyc(0); cyc(1); cyc(1); cyc(0);
    scan(0, 32, 32'h0, d);
    chk(d == 32'h0, "update without shifting writes the captured value back");

    // asynchronous TRST in the middle of a scan
    scan(1, 5, 5'h1F, d);
    cyc(1); cyc(0); cyc(0); cyc(0);
    #2 trst_n = 0; #2;
    chk(tap_state == TLR && ir[4:0] == 5'h01 && !tdo_oe, "TRST mid-scan: reset, IDCODE, TDO off");
    trst_n = 1;

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #2000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
