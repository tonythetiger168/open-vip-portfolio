# JTAG — JTAG (IEEE 1149.1) UVM VIP

Open-source UVM verification IP for **JTAG / IEEE 1149.1 boundary scan**,
packaged inside a 5-protocol harness (JTAG deepened; SATA/NVMe/Bluetooth5/
DisplayPort2 are minimal stub UVCs so the shared environment compiles).

## Protocol overview

JTAG is a 4/5-wire serial test access port: `TCK` (clock), `TMS` (mode
select), `TDI`/`TDO` (data), optional `TRST_N` (async reset). A 16-state
TAP FSM navigated by TMS selects IR scans (instruction register) or DR
scans (BYPASS / IDCODE / boundary-scan / user data registers). TDO changes
on the falling edge of TCK and is only driven during shift states.

## Architecture

| Path | Description |
|------|-------------|
| `jtag/jtag_if.sv` | JTAG interface (TCK/TMS/TDI/TDO/TRST_N), TAP state enum, clocking blocks, modports, TAP-decode helper signals |
| `jtag/jtag_pkg.sv` + `*.svh` | UVM agent (driver / monitor / sequencer / checker / coverage / sequences) |
| `jtag/jtag_driver.svh` | TAP driver: TMS/TDI bit-level scan chains (IR/DR shifts, reset, TRST pulse) + expected-item analysis port |
| `jtag/jtag_monitor.svh` | TAP FSM decoder: reconstructs IR/DR scan transactions from TDI/TMS waveforms |
| `regression/sva/jtag_compliance_checker.sv` | Tiered SVA compliance checker (L1/L2/L3/L4) |
| `regression/vip/jtag/` | protocol / timing / error / data-integrity checkers |
| `env/env_pkg.sv` | 5-protocol environment + JTAG end-to-end scoreboard |
| `tests/test_pkg.sv` | `base_test`, JTAG random/regression/full-regression tests, companion-protocol stub tests |
| `top/top_tb.sv` | Testbench top + functional JTAG TAP controller DUT (16-state FSM, IR/DR registers) |
| `regression/` | Makefile + coverage-driven regression (line/fsm/toggle/SVA, 100% goal) |

## Sequence library

| Sequence | Purpose |
|----------|---------|
| `jtag_random_sequence` | Random TAP operations |
| `jtag_idcode_sequence` | Directed IDCODE instruction scans |
| `jtag_bypass_sequence` | Directed BYPASS scans |
| `jtag_reset_sequence` | TLR via TMS and async TRST pulse |
| `jtag_dr_scan_sequence` | Directed DR scans (1–64 bits) |
| `jtag_back_to_back_sequence` | IR scan immediately followed by DR scan |
| `jtag_corner_sequence` | Maximum-length (128-bit) DR shifts |
| `jtag_stress_sequence` | 200-operation mix with pause-state flags |
| `jtag_regression_sequence` | Weighted mix of all directed sequences |

## SVA compliance (regression/sva/jtag_compliance_checker.sv)

- **L1 Basic (4)**: reset-to-TLR, TDO OE sanity, TMS/TDI valid
- **L2 Full protocol (6)**: TDO valid in shift, shift-state OE, TCK toggle, reset pulse, IR/DR validity
- **L3 Advanced (0)**: reserved
- **L4 JTAG-specific (4)**: TDO only driven in Shift-IR/DR, TMS=1×5 forces TLR, IR known during Shift-IR, Shift-DR eventually completes

## Functional coverage (jtag/jtag_coverage.svh)

- `jtag_op_cg`: operation × error × pause crosses, IR/DR-length bins
- `jtag_fsm_cg`: TAP operation flow transitions (IR⇄DR, reset→scan, chains)
- `jtag_data_cg`: DR data pattern corners (all-0/all-1/0xAA55/walking-1) × IR instruction cross

## Quick start

```bash
cd regression
make all                                   # single run (xrun default)
TESTNAME=jtag_regression_test make all
./coverage_regression.sh                   # full regression + 100% coverage gate
SIMULATOR=vcs ./coverage_regression.sh
```

## Deepened Features (v1.6.0)

- **Bit-level TAP driver**: TMS navigation, IR/DR shift chains, TRST pulses, expected-item broadcast for the scoreboard
- **Waveform-decoding monitor**: full 16-state TAP FSM tracking, IR/DR scan reconstruction, async-reset handling
- **End-to-end scoreboard**: driver-issued (expected) vs monitor-decoded (observed) compare with `n_matches`/`n_mismatches` and `UVM_ERROR` on mismatch
- **Functional DUT model**: IEEE 1149.1 TAP controller with IDCODE/BYPASS/SAMPLE/USER DRs, spec-correct negedge-TDO
- **Directed sequence library**: 9 sequences (idcode / bypass / reset / DR scan / back-to-back / corner / stress / regression)
- **SVA L4**: 4 JTAG-specific rules
- **Functional coverage**: 3 covergroups with cross coverage

License: Apache-2.0
