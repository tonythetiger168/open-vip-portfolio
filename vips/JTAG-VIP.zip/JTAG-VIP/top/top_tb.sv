// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// top_tb.sv -- multi-protocol testbench top with a functional JTAG TAP
// controller DUT model (5-bit IR, IDCODE/BYPASS/SAMPLE/USER DRs).

`ifndef TOP_TB_SV
`define TOP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import sata_pkg::*;
import nvme_pkg::*;
import jtag_pkg::*;
import bluetooth5_pkg::*;
import displayport2_pkg::*;
import env_pkg::*;
import test_pkg::*;

module top_tb;
  // JTAG clock (slower than system clock)
  logic tck = 0;
  always #10ns tck = ~tck;

  // System clock / reset for stub protocols
  logic clk = 0, rst_n;
  always #5ns clk = ~clk;

  jtag_if         jtag_vif(tck);
  sata_if         sata_vif(clk, rst_n);
  nvme_if         nvme_vif(clk, rst_n);
  bluetooth5_if   bt5_vif(clk, rst_n);
  displayport2_if dp2_vif(clk, rst_n);

  initial begin
    rst_n = 0;
    jtag_vif.tms    = 1'b1;
    jtag_vif.tdi    = 1'b0;
    jtag_vif.trst_n = 1'b0;
    repeat (5) @(posedge tck);
    jtag_vif.trst_n = 1'b1;
    #100ns;
    rst_n = 1;
  end

  // Functional JTAG TAP controller DUT
  jtag_tap_dut dut(.vif(jtag_vif));

  // Tiered SVA compliance checker + protocol checkers (module form)
  jtag_compliance_checker               u_jtag_sva_chk      (.vif(jtag_vif));
  jtag_data_integrity_checker_sva       u_jtag_di_sva       (.vif(jtag_vif));
  jtag_error_handling_checker_sva       u_jtag_err_sva      (.vif(jtag_vif));
  jtag_protocol_compliance_checker_sva  u_jtag_proto_sva    (.vif(jtag_vif));
  jtag_timing_performance_checker_sva   u_jtag_timing_sva   (.vif(jtag_vif));

  initial begin
    uvm_config_db#(virtual jtag_if)::set(null, "*", "vif", jtag_vif);
    uvm_config_db#(virtual sata_if)::set(null, "*", "vif", sata_vif);
    uvm_config_db#(virtual nvme_if)::set(null, "*", "vif", nvme_vif);
    uvm_config_db#(virtual bluetooth5_if)::set(null, "*", "vif", bt5_vif);
    uvm_config_db#(virtual displayport2_if)::set(null, "*", "vif", dp2_vif);
    run_test();
  end
endmodule

//----------------------------------------------------------------------------
// Functional JTAG TAP controller (IEEE 1149.1):
//   - 16-state TAP FSM, asynchronous TRST
//   - 5-bit instruction register
//   - DRs: BYPASS (1-bit), IDCODE (32-bit), SAMPLE/BOUNDARY (32-bit),
//     USER (32-bit scratch register)
//   - TDO updated on negedge TCK, driven only during Shift-IR/Shift-DR
//----------------------------------------------------------------------------
module jtag_tap_dut(jtag_if.DUT vif);

  localparam bit [4:0]  IR_IDCODE = 5'h01;
  localparam bit [4:0]  IR_SAMPLE = 5'h02;
  localparam bit [4:0]  IR_EXTEST = 5'h00;
  localparam bit [4:0]  IR_BYPASS = 5'h1F;
  localparam bit [31:0] IDCODE    = 32'h1ABC_0043;

  tap_state_e state;
  logic [4:0]   ir_reg;
  logic [4:0]   ir_sr;
  logic [31:0]  dr_sr;
  logic [31:0]  user_dr;
  logic         bypass_sr;
  logic [15:0]  dr_cnt;

  assign vif.ir       = {3'b000, ir_reg};
  assign vif.ir_shift = (state == SHIFT_IR);
  assign vif.dr_shift = (state == SHIFT_DR);
  assign vif.dr_len   = dr_cnt;
  assign vif.tap_state = state;

  // ---------------- TAP FSM + shift registers (posedge TCK) ----------------
  always_ff @(posedge vif.tck or negedge vif.trst_n) begin
    if (!vif.trst_n) begin
      state     <= TEST_LOGIC_RESET;
      ir_reg    <= IR_IDCODE;
      ir_sr     <= 5'h0;
      dr_sr     <= 32'h0;
      user_dr   <= 32'h0;   // smoke fix: reset user DR to avoid X propagation
      bypass_sr <= 1'b0;
      dr_cnt    <= 16'h0;
    end
    else begin
      case (state)
        TEST_LOGIC_RESET: begin
          state <= vif.tms ? TEST_LOGIC_RESET : RUN_TEST_IDLE;
          ir_reg <= IR_IDCODE;
        end
        RUN_TEST_IDLE:  state <= vif.tms ? SELECT_DR_SCAN : RUN_TEST_IDLE;
        SELECT_DR_SCAN: state <= vif.tms ? SELECT_IR_SCAN : CAPTURE_DR;
        CAPTURE_DR: begin
          state <= vif.tms ? EXIT1_DR : SHIFT_DR;
          dr_cnt <= 16'h0;
          case (ir_reg)
            IR_IDCODE: dr_sr <= IDCODE;
            IR_SAMPLE: dr_sr <= 32'hCAFE_0001;
            IR_EXTEST: dr_sr <= 32'h0;
            IR_BYPASS: bypass_sr <= 1'b0;
            default:   dr_sr <= user_dr;
          endcase
        end
        SHIFT_DR: begin
          state <= vif.tms ? EXIT1_DR : SHIFT_DR;
          dr_cnt <= dr_cnt + 16'h1;
          if (ir_reg == IR_BYPASS) bypass_sr <= vif.tdi;
          else dr_sr <= {vif.tdi, dr_sr[31:1]};
        end
        EXIT1_DR:   state <= vif.tms ? UPDATE_DR : PAUSE_DR;
        PAUSE_DR:   state <= vif.tms ? EXIT2_DR : PAUSE_DR;
        EXIT2_DR:   state <= vif.tms ? UPDATE_DR : SHIFT_DR;
        UPDATE_DR: begin
          state <= vif.tms ? SELECT_DR_SCAN : RUN_TEST_IDLE;
          if (ir_reg != IR_BYPASS && ir_reg != IR_IDCODE) user_dr <= dr_sr;
        end
        SELECT_IR_SCAN: state <= vif.tms ? TEST_LOGIC_RESET : CAPTURE_IR;
        CAPTURE_IR: begin
          state <= vif.tms ? EXIT1_IR : SHIFT_IR;
          ir_sr <= 5'b00101;               // capture pattern (01 at LSBs per spec)
        end
        SHIFT_IR: begin
          state <= vif.tms ? EXIT1_IR : SHIFT_IR;
          ir_sr <= {vif.tdi, ir_sr[4:1]};
        end
        EXIT1_IR:   state <= vif.tms ? UPDATE_IR : PAUSE_IR;
        PAUSE_IR:   state <= vif.tms ? EXIT2_IR : PAUSE_IR;
        EXIT2_IR:   state <= vif.tms ? UPDATE_IR : SHIFT_IR;
        UPDATE_IR: begin
          state <= vif.tms ? SELECT_DR_SCAN : RUN_TEST_IDLE;
          ir_reg <= ir_sr;
        end
        default: state <= TEST_LOGIC_RESET;
      endcase
    end
  end

  // ---------------- TDO (negedge TCK, only during shift states) ----------------
  always_ff @(negedge vif.tck or negedge vif.trst_n) begin
    if (!vif.trst_n) begin
      vif.tdo    <= 1'b0;
      vif.tdo_oe <= 1'b0;
    end
    else begin
      if (state == SHIFT_IR) begin
        vif.tdo    <= ir_sr[0];
        vif.tdo_oe <= 1'b1;
      end
      else if (state == SHIFT_DR) begin
        vif.tdo    <= (ir_reg == IR_BYPASS) ? bypass_sr : dr_sr[0];
        vif.tdo_oe <= 1'b1;
      end
      else begin
        vif.tdo    <= 1'b0;
        vif.tdo_oe <= 1'b0;
      end
    end
  end
endmodule
`endif
