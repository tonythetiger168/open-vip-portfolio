// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// sata_if.sv -- minimal SATA stub interface (multi-protocol harness)

`ifndef SATA_IF_SV
`define SATA_IF_SV

interface sata_if (input logic clk, input logic rst_n);
  logic [63:0] data;
  logic        valid;
  logic        ready;
endinterface
`endif
