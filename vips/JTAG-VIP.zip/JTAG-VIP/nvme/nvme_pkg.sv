// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// nvme_pkg.sv -- minimal NVMe stub UVC (multi-protocol harness companion)

`ifndef NVME_PKG_SV
`define NVME_PKG_SV

package nvme_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;

  class nvme_config extends uvm_object;
    `uvm_object_utils(nvme_config)
    bit enable_checker  = 1;
    bit enable_coverage = 1;
    function new(string name = "nvme_config");
      super.new(name);
    endfunction
  endclass

  class nvme_transaction extends uvm_sequence_item;
    `uvm_object_utils(nvme_transaction)
    rand bit [63:0] addr;
    rand bit [63:0] data;
    rand bit        write;
    function new(string name = "nvme_transaction");
      super.new(name);
    endfunction
    virtual function string convert2string();
      return $sformatf("NVMe: %s addr=0x%0x data=0x%0x",
                       write ? "WR" : "RD", addr, data);
    endfunction
  endclass

  class nvme_sequencer extends uvm_sequencer #(nvme_transaction);
    `uvm_component_utils(nvme_sequencer)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
  endclass

  class nvme_driver extends uvm_driver #(nvme_transaction);
    `uvm_component_utils(nvme_driver)
    virtual nvme_if vif;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      void'(uvm_config_db#(virtual nvme_if)::get(this, "", "vif", vif));
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        seq_item_port.get_next_item(req);
        if (vif != null) begin
          @(posedge vif.clk);
          vif.data  <= req.data;
          vif.valid <= 1'b1;
          @(posedge vif.clk);
          vif.valid <= 1'b0;
        end
        seq_item_port.item_done();
      end
    endtask
  endclass

  class nvme_monitor extends uvm_monitor;
    `uvm_component_utils(nvme_monitor)
    virtual nvme_if vif;
    uvm_analysis_port #(nvme_transaction) ap;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      void'(uvm_config_db#(virtual nvme_if)::get(this, "", "vif", vif));
    endfunction
    task run_phase(uvm_phase phase);
      nvme_transaction tx;
      if (vif == null) return;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n && vif.valid && vif.ready) begin
          tx = nvme_transaction::type_id::create("tx");
          tx.data = vif.data;
          ap.write(tx);
        end
      end
    endtask
  endclass

  class nvme_agent extends uvm_agent;
    `uvm_component_utils(nvme_agent)
    nvme_sequencer sqr;
    nvme_driver    drv;
    nvme_monitor   mon;
    nvme_config    cfg;
    uvm_analysis_port #(nvme_transaction) ap;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(nvme_config)::get(this, "", "cfg", cfg))
        cfg = nvme_config::type_id::create("cfg");
      mon = nvme_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = nvme_sequencer::type_id::create("sqr", this);
        drv = nvme_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(ap);
    endfunction
  endclass
endpackage
`endif
