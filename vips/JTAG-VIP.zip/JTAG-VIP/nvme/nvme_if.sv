// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// nvme_if.sv -- minimal NVMe stub interface (multi-protocol harness)

`ifndef NVME_IF_SV
`define NVME_IF_SV

interface nvme_if (input logic clk, input logic rst_n);
  logic [63:0] data;
  logic        valid;
  logic        ready;
endinterface
`endif
