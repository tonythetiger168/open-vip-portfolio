// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// bluetooth5_pkg.sv -- minimal Bluetooth5 stub UVC (multi-protocol harness companion)

`ifndef BLUETOOTH5_PKG_SV
`define BLUETOOTH5_PKG_SV

package bluetooth5_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;

  class bluetooth5_config extends uvm_object;
    `uvm_object_utils(bluetooth5_config)
    bit enable_checker  = 1;
    bit enable_coverage = 1;
    function new(string name = "bluetooth5_config");
      super.new(name);
    endfunction
  endclass

  class bluetooth5_transaction extends uvm_sequence_item;
    `uvm_object_utils(bluetooth5_transaction)
    rand bit [63:0] addr;
    rand bit [63:0] data;
    rand bit        write;
    function new(string name = "bluetooth5_transaction");
      super.new(name);
    endfunction
    virtual function string convert2string();
      return $sformatf("Bluetooth5: %s addr=0x%0x data=0x%0x",
                       write ? "WR" : "RD", addr, data);
    endfunction
  endclass

  class bluetooth5_sequencer extends uvm_sequencer #(bluetooth5_transaction);
    `uvm_component_utils(bluetooth5_sequencer)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
  endclass

  class bluetooth5_driver extends uvm_driver #(bluetooth5_transaction);
    `uvm_component_utils(bluetooth5_driver)
    virtual bluetooth5_if vif;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      void'(uvm_config_db#(virtual bluetooth5_if)::get(this, "", "vif", vif));
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        seq_item_port.get_next_item(req);
        if (vif != null) begin
          @(posedge vif.clk);
          vif.data  <= req.data;
          vif.valid <= 1'b1;
          @(posedge vif.clk);
          vif.valid <= 1'b0;
        end
        seq_item_port.item_done();
      end
    endtask
  endclass

  class bluetooth5_monitor extends uvm_monitor;
    `uvm_component_utils(bluetooth5_monitor)
    virtual bluetooth5_if vif;
    uvm_analysis_port #(bluetooth5_transaction) ap;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      void'(uvm_config_db#(virtual bluetooth5_if)::get(this, "", "vif", vif));
    endfunction
    task run_phase(uvm_phase phase);
      bluetooth5_transaction tx;
      if (vif == null) return;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n && vif.valid && vif.ready) begin
          tx = bluetooth5_transaction::type_id::create("tx");
          tx.data = vif.data;
          ap.write(tx);
        end
      end
    endtask
  endclass

  class bluetooth5_agent extends uvm_agent;
    `uvm_component_utils(bluetooth5_agent)
    bluetooth5_sequencer sqr;
    bluetooth5_driver    drv;
    bluetooth5_monitor   mon;
    bluetooth5_config    cfg;
    uvm_analysis_port #(bluetooth5_transaction) ap;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(bluetooth5_config)::get(this, "", "cfg", cfg))
        cfg = bluetooth5_config::type_id::create("cfg");
      mon = bluetooth5_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = bluetooth5_sequencer::type_id::create("sqr", this);
        drv = bluetooth5_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(ap);
    endfunction
  endclass
endpackage
`endif
