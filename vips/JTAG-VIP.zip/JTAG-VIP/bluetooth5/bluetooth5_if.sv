// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// bluetooth5_if.sv -- minimal Bluetooth5 stub interface (multi-protocol harness)

`ifndef BLUETOOTH5_IF_SV
`define BLUETOOTH5_IF_SV

interface bluetooth5_if (input logic clk, input logic rst_n);
  logic [63:0] data;
  logic        valid;
  logic        ready;
endinterface
`endif
