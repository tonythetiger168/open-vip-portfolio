// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// displayport2_if.sv -- minimal DisplayPort2 stub interface (multi-protocol harness)

`ifndef DISPLAYPORT2_IF_SV
`define DISPLAYPORT2_IF_SV

interface displayport2_if (input logic clk, input logic rst_n);
  logic [63:0] data;
  logic        valid;
  logic        ready;
endinterface
`endif
