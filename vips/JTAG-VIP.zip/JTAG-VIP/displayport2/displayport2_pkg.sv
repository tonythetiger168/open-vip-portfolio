// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// displayport2_pkg.sv -- minimal DisplayPort2 stub UVC (multi-protocol harness companion)

`ifndef DISPLAYPORT2_PKG_SV
`define DISPLAYPORT2_PKG_SV

package displayport2_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;

  class displayport2_config extends uvm_object;
    `uvm_object_utils(displayport2_config)
    bit enable_checker  = 1;
    bit enable_coverage = 1;
    function new(string name = "displayport2_config");
      super.new(name);
    endfunction
  endclass

  class displayport2_transaction extends uvm_sequence_item;
    `uvm_object_utils(displayport2_transaction)
    rand bit [63:0] addr;
    rand bit [63:0] data;
    rand bit        write;
    function new(string name = "displayport2_transaction");
      super.new(name);
    endfunction
    virtual function string convert2string();
      return $sformatf("DisplayPort2: %s addr=0x%0x data=0x%0x",
                       write ? "WR" : "RD", addr, data);
    endfunction
  endclass

  class displayport2_sequencer extends uvm_sequencer #(displayport2_transaction);
    `uvm_component_utils(displayport2_sequencer)
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
  endclass

  class displayport2_driver extends uvm_driver #(displayport2_transaction);
    `uvm_component_utils(displayport2_driver)
    virtual displayport2_if vif;
    function new(string name, uvm_component parent);
      super.new(name, parent);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      void'(uvm_config_db#(virtual displayport2_if)::get(this, "", "vif", vif));
    endfunction
    task run_phase(uvm_phase phase);
      forever begin
        seq_item_port.get_next_item(req);
        if (vif != null) begin
          @(posedge vif.clk);
          vif.data  <= req.data;
          vif.valid <= 1'b1;
          @(posedge vif.clk);
          vif.valid <= 1'b0;
        end
        seq_item_port.item_done();
      end
    endtask
  endclass

  class displayport2_monitor extends uvm_monitor;
    `uvm_component_utils(displayport2_monitor)
    virtual displayport2_if vif;
    uvm_analysis_port #(displayport2_transaction) ap;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      void'(uvm_config_db#(virtual displayport2_if)::get(this, "", "vif", vif));
    endfunction
    task run_phase(uvm_phase phase);
      displayport2_transaction tx;
      if (vif == null) return;
      forever begin
        @(posedge vif.clk);
        if (vif.rst_n && vif.valid && vif.ready) begin
          tx = displayport2_transaction::type_id::create("tx");
          tx.data = vif.data;
          ap.write(tx);
        end
      end
    endtask
  endclass

  class displayport2_agent extends uvm_agent;
    `uvm_component_utils(displayport2_agent)
    displayport2_sequencer sqr;
    displayport2_driver    drv;
    displayport2_monitor   mon;
    displayport2_config    cfg;
    uvm_analysis_port #(displayport2_transaction) ap;
    function new(string name, uvm_component parent);
      super.new(name, parent);
      ap = new("ap", this);
    endfunction
    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(displayport2_config)::get(this, "", "cfg", cfg))
        cfg = displayport2_config::type_id::create("cfg");
      mon = displayport2_monitor::type_id::create("mon", this);
      if (get_is_active() == UVM_ACTIVE) begin
        sqr = displayport2_sequencer::type_id::create("sqr", this);
        drv = displayport2_driver::type_id::create("drv", this);
      end
    endfunction
    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE)
        drv.seq_item_port.connect(sqr.seq_item_export);
      mon.ap.connect(ap);
    endfunction
  endclass
endpackage
`endif
