// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (SNOR DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened snor_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b1;
  initial #1 rst_n = 1'b0;      // a falling edge: the flash has no clock to see a level reset
  logic sclk = 1'b0, csn = 1'b1;
  logic [3:0] io_m = 4'b1100, io_m_oe = 4'b1100;
  wire [3:0] fl_io, fl_oe;

  always #5 clk = ~clk;

  snor_model u_dut (.clk(clk), .rst_n(rst_n), .sclk(sclk), .csn(csn), .io_m(io_m), .io_m_oe(io_m_oe),
                    .fl_io(fl_io), .fl_oe(fl_oe));

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  logic [7:0] wb [0:255], rb [0:255];
  logic [3:0] so [0:4095], soe [0:4095];
  integer nr = 0, conflict = 0;
  // one transfer: command, optional address, dummy clocks, nwr written bytes, nrd read bytes (quad
  // reads release the bus); cut: rising edges to stop after (-1 = none)
  task automatic xfer(input logic [7:0] c, input logic ha, input logic [23:0] a, input integer dum,
                      input integer nwr, input integer nrd, input logic q, input integer cut = -1);
    logic [3:0] v [0:4095], e [0:4095];
    integer n, s;
    n = 0;
    for (int i = 7; i >= 0; i--) begin v[n] = {3'b110, c[i]}; e[n] = 4'b1101; n = n + 1; end
    if (ha) for (int i = 23; i >= 0; i--) begin v[n] = {3'b110, a[i]}; e[n] = 4'b1101; n = n + 1; end
    for (int i = 0; i < dum; i++) begin v[n] = 4'b1100; e[n] = 4'b1101; n = n + 1; end
    for (int b = 0; b < nwr; b++) for (int i = 7; i >= 0; i--) begin v[n] = {3'b110, wb[b][i]}; e[n] = 4'b1101; n = n + 1; end
    s = n;
    for (int i = 0; i < (q ? 2 : 8) * nrd; i++) begin v[n] = 4'b0000; e[n] = q ? 4'b0000 : 4'b1101; n = n + 1; end
    if (cut >= 0) n = cut;
    @(negedge clk); csn = 0;
    for (int i = 0; i < n; i++) begin
      @(negedge clk); sclk = 0; io_m = v[i]; io_m_oe = e[i];
      repeat (2) @(negedge clk);
      sclk = 1;
      so[i] = fl_io; soe[i] = fl_oe;
      if ((fl_oe & io_m_oe) != 4'h0) conflict = conflict + 1;
      @(negedge clk);
    end
    @(negedge clk); sclk = 0; io_m_oe = 4'b0000;
    repeat (2) @(negedge clk); csn = 1;
    @(negedge clk); io_m = 4'b1100; io_m_oe = 4'b1100;
    repeat (2) @(negedge clk);
    nr = 0;
    if (q) for (int i = s; i + 1 < n; i += 2) begin rb[nr] = {so[i] & soe[i], so[i + 1] & soe[i + 1]}; nr = nr + 1; end
    else for (int i = s; i + 7 < n; i += 8) begin
      for (int j = 0; j < 8; j++) rb[nr][7 - j] = so[i + j][1] & soe[i + j][1];
      nr = nr + 1;
    end
  endtask
  function automatic logic [7:0] init(input integer a);
    init = a[7:0] ^ a[15:8] ^ 8'hA5;
  endfunction
  function automatic logic rd_is(input integer a0, input integer n, input logic prog = 0);
    logic ok;
    ok = nr == n;
    for (int i = 0; i < 256; i++) if (i < n && rb[i] !== (prog ? (init(a0 + i) & wb[i]) : init((a0 + i) % 65536))) ok = 0;
    rd_is = ok;
  endfunction
  logic [7:0] st;

  initial begin
    repeat (3) @(posedge clk);
    chk(fl_oe === 4'h0, "flash IO released");
    rst_n = 1;
    repeat (4) @(negedge clk);
    xfer(8'h9F, 0, 0, 0, 0, 4, 0);
    chk(nr == 4 && rb[0] == 8'hEF && rb[1] == 8'h40 && rb[2] == 8'h18 && rb[3] == 8'h00, "JEDEC ID EF 40 18, then 00");
    xfer(8'h05, 0, 0, 0, 0, 2, 0);
    chk(nr == 2 && rb[0] == 8'h00 && rb[1] == 8'h00, "status after reset: WEL 0");
    xfer(8'h03, 1, 24'h000010, 0, 0, 8, 0);
    chk(rd_is(16'h0010, 8), "read 0x03 of the preloaded array");
    xfer(8'h0B, 1, 24'h000123, 8, 0, 6, 0);
    chk(rd_is(16'h0123, 6), "fast read 0x0B with 8 dummy clocks");
    xfer(8'h6B, 1, 24'h000456, 8, 0, 9, 1);
    chk(rd_is(16'h0456, 9) && soe[8 + 24 + 8] == 4'hF, "quad read 0x6B: four lines, high nibble first");
    xfer(8'h6B, 1, 24'h12FFFC, 8, 0, 8, 1);
    chk(rd_is(16'hFFFC, 8), "quad read wraps at 64 KB (address bits 23:16 ignored)");
    for (int i = 0; i < 16; i++) wb[i] = 8'h0F ^ (8'h11 * i);
    xfer(8'h02, 1, 24'h001000, 0, 16, 0, 0);
    xfer(8'h03, 1, 24'h001000, 0, 0, 16, 0);
    chk(rd_is(16'h1000, 16), "page program without WEL is ignored");
    xfer(8'h06, 0, 0, 0, 0, 0, 0);
    xfer(8'h05, 0, 0, 0, 0, 1, 0);
    chk(rb[0] == 8'h02, "WREN sets WEL");
    xfer(8'h02, 1, 24'h001000, 0, 16, 0, 0);
    xfer(8'h05, 0, 0, 0, 0, 1, 0);
    chk(rb[0] == 8'h00, "page program clears WEL");
    xfer(8'h03, 1, 24'h001000, 0, 0, 16, 0);
    chk(rd_is(16'h1000, 16, 1), "programmed bytes are ANDed into the array");
    xfer(8'h6B, 1, 24'h001000, 8, 0, 16, 1);
    chk(rd_is(16'h1000, 16, 1), "and read the same in quad mode");
    xfer(8'h06, 0, 0, 0, 0, 0, 0);
    xfer(8'h04, 0, 0, 0, 0, 0, 0);
    xfer(8'h05, 0, 0, 0, 0, 1, 0);
    chk(rb[0] == 8'h00, "WRDI clears WEL");
    xfer(8'h20, 1, 24'h001000, 0, 0, 0, 0);
    xfer(8'h03, 1, 24'h001000, 0, 0, 4, 0);
    chk(rd_is(16'h1000, 4, 1), "sector erase without WEL is ignored");
    xfer(8'h06, 0, 0, 0, 0, 0, 0);
    xfer(8'h20, 1, 24'h001ABC, 0, 0, 0, 0);
    xfer(8'h03, 1, 24'h000FFE, 0, 0, 4, 0);
    chk(nr == 4 && rb[0] == init(16'h0FFE) && rb[1] == init(16'h0FFF) && rb[2] == 8'hFF && rb[3] == 8'hFF,
        "sector erase clears the whole 4 KB sector to FF, not the one before");
    xfer(8'h03, 1, 24'h001FFF, 0, 0, 2, 0);
    chk(rb[0] == 8'hFF && rb[1] == init(16'h2000), "and not the one after");
    xfer(8'h05, 0, 0, 0, 0, 1, 0);
    chk(rb[0] == 8'h00, "erase clears WEL");
    for (int i = 0; i < 12; i++) wb[i] = 8'hFF ^ (8'h01 << (i % 8));
    xfer(8'h06, 0, 0, 0, 0, 0, 0);
    xfer(8'h02, 1, 24'h0030F8, 0, 12, 0, 0);
    xfer(8'h03, 1, 24'h0030F8, 0, 0, 8, 0);
    chk(rb[0] == (init(16'h30F8) & wb[0]) && rb[7] == (init(16'h30FF) & wb[7]), "program to the end of the page");
    xfer(8'h03, 1, 24'h003000, 0, 0, 4, 0);
    chk(rb[0] == (init(16'h3000) & wb[8]) && rb[3] == (init(16'h3003) & wb[11]) , "then wraps to the page start");
    xfer(8'h06, 0, 0, 0, 0, 0, 0);
    xfer(8'h02, 1, 24'h004000, 0, 0, 0, 0);
    xfer(8'h05, 0, 0, 0, 0, 1, 0);
    chk(rb[0] == 8'h02, "page program with no data bit keeps WEL");
    wb[0] = 8'h00;
    xfer(8'h02, 1, 24'h004000, 0, 1, 0, 0, 32 + 5);
    xfer(8'h05, 0, 0, 0, 0, 1, 0);
    chk(rb[0] == 8'h00, "a partial data byte clears WEL");
    xfer(8'h03, 1, 24'h004000, 0, 0, 1, 0);
    chk(rb[0] == init(16'h4000), "and programs nothing");
    xfer(8'hAB, 0, 0, 0, 0, 2, 0);
    chk(nr == 2 && rb[0] == 8'h00 && soe[8] == 4'h0, "unknown command: the flash stays off the bus");
    xfer(8'h03, 1, 24'h000500, 0, 0, 2, 0, 20);
    xfer(8'h03, 1, 24'h000500, 0, 0, 2, 0);
    chk(rd_is(16'h0500, 2), "a transfer cut in the address leaves no state behind");
    xfer(8'h06, 0, 0, 0, 0, 0, 0, 5);
    xfer(8'h05, 0, 0, 0, 0, 1, 0);
    chk(rb[0] == 8'h00, "WREN cut before 8 bits is ignored");
    chk(conflict == 0, "no IO contention");
    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
