// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_defs.sv -- SNOR shared type definitions

package snor_defs_pkg;

  typedef enum bit [1:0] {SNOR_OK, SNOR_ERR} snor_status_e;

  function automatic bit snor_has_addr(bit [7:0] c);
    return c == 8'h03 || c == 8'h0B || c == 8'h6B || c == 8'h02 || c == 8'h20;
  endfunction
  function automatic int snor_start(bit [7:0] c);   // rising edge of the first data bit
    return 8 + (snor_has_addr(c) ? 24 : 0) + ((c == 8'h0B || c == 8'h6B) ? 8 : 0);
  endfunction
  function automatic bit [7:0] snor_init(int a);
    return a[7:0] ^ a[15:8] ^ 8'hA5;
  endfunction

endpackage
