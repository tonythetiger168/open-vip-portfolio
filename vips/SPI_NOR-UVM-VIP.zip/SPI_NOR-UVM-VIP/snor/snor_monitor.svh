// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_monitor.svh -- SNOR monitor: host and flash drive (masked by their enables) at every sclk rising edge from CS# low to CS# high, decoded into command and returned bytes

class snor_monitor extends uvm_monitor;
  `uvm_component_utils(snor_monitor)

  virtual snor_if vif;
  uvm_analysis_port #(snor_transaction) ap;
  snor_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual snor_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "snor: virtual interface not set")
    if (!uvm_config_db#(snor_config)::get(this, "", "cfg", cfg))
      cfg = snor_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      forever begin
        snor_transaction t;
        bit ps;
        while (vif.mon_cb.csn !== 1'b0) @(vif.mon_cb);
        t = snor_transaction::type_id::create("t");
        ps = vif.mon_cb.sclk;
        while (vif.mon_cb.csn === 1'b0) begin
          @(vif.mon_cb);
          if (ps === 1'b0 && vif.mon_cb.sclk === 1'b1 && vif.mon_cb.csn === 1'b0) begin
            t.mo.push_back({vif.mon_cb.io_m_oe, vif.mon_cb.io_m & vif.mon_cb.io_m_oe});
            t.so.push_back({vif.mon_cb.fl_oe, vif.mon_cb.fl_io & vif.mon_cb.fl_oe});
          end
          ps = vif.mon_cb.sclk;
        end
        t.decode();
        publish(t);
      end
    end
  endtask

  function void publish(snor_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
