// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_sequences.svh -- SNOR sequences

// Random traffic: cfg.num_items constrained-random items.
class snor_base_sequence extends uvm_sequence #(snor_transaction);
  `uvm_object_utils(snor_base_sequence)
  snor_config cfg;

  function new(string name = "snor_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = snor_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "snor_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class snor_directed_sequence extends uvm_sequence #(snor_transaction);
  `uvm_object_utils(snor_directed_sequence)
  snor_config cfg;

  function new(string name = "snor_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function snor_transaction item();
    item = snor_transaction::type_id::create("req");
  endfunction

  task send(snor_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    snor_transaction t;
    // ID and status, WEL handling, program / read back in every read mode, erase, wraps, cuts
    t = item(); t.set(10, 0, 3); send(t);
    t = item(); t.set(11, 0, 1); send(t);
    t = item(); t.set(14, 16'h1000, 16, 32'h21); send(t);      // no WEL: ignored
    t = item(); t.set(12); send(t);
    t = item(); t.set(11, 0, 2); send(t);
    t = item(); t.set(14, 16'h1000, 16, 32'h22); send(t);
    t = item(); t.set(11, 0, 1); send(t);
    t = item(); t.set(28, 16'h0000, 20); send(t);
    t = item(); t.set(30, 16'h0004, 12); send(t);
    t = item(); t.set(31, 16'h0008, 9); send(t);
    t = item(); t.set(18, 16'h1234); send(t);                  // no WEL
    t = item(); t.set(12); send(t);
    t = item(); t.set(13); send(t);
    t = item(); t.set(11, 0, 1); send(t);
    t = item(); t.set(12); send(t);
    t = item(); t.set(18, 16'h1F00); send(t);
    t = item(); t.set(28, 16'h0000, 24); send(t);
    t = item(); t.set(12); send(t);
    t = item(); t.set(24, 16'h1000, 12, 32'h44); t.seed[0] = 1'b0; send(t);
    t = item(); t.set(29, 16'h00F0, 16); send(t);
    t = item(); t.set(29, 16'h0000, 8); send(t);
    t = item(); t.set(23, 16'h0001, 12); send(t);
    t = item(); t.set(20, 0, 4); send(t);
    t = item(); t.set(21, 16'h0100, 4); send(t);
    t = item(); t.set(22, 16'h0200, 4); send(t);
    t = item(); t.set(12); send(t);
    t = item(); t.set(24, 16'h2000, 9, 32'h3); t.seed[0] = 1'b1; send(t);
    t = item(); t.set(11, 0, 1); send(t);
    for (int i = 0; i < 6; i++) begin t = item(); t.set(7 + i % 3, 16'h2000 + 16'(i * 37), 6 + i); send(t); end
  endtask
endclass
