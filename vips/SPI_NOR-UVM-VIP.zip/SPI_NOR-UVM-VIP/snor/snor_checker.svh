// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_checker.svh -- SNOR protocol checker on monitored items

class snor_checker extends uvm_component;
  `uvm_component_utils(snor_checker)
  uvm_analysis_imp #(snor_transaction, snor_checker) imp;
  int unsigned n_checked = 0, n_violations = 0;
  snor_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    imp = new("imp", this);
    if (!uvm_config_db#(snor_config)::get(this, "", "cfg", cfg))
      cfg = snor_config::type_id::create("cfg");
  endfunction

  function void fail(snor_transaction t, string msg);
    n_violations++;
    `uvm_error("CHK", $sformatf("SNOR: %s: %s", msg, t.convert2string()))
  endfunction

  function void write(snor_transaction t);
    if (!cfg.checks_enable) return;
    n_checked++;
    begin
      foreach (t.so[i]) if ((t.so[i][7:4] & t.mo[i][7:4]) != 4'h0) fail(t, "host and flash drive the same IO line");
      if (t.op == 8'h9F && t.rd.size() >= 3 && {t.rd[0], t.rd[1], t.rd[2]} != 24'hEF4018) fail(t, "wrong JEDEC ID");
    end
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("CHK", $sformatf("SNOR checker: n_checked=%0d n_violations=%0d",
              n_checked, n_violations), UVM_LOW)
  endfunction
endclass
