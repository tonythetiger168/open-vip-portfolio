// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_transaction.svh -- SNOR transaction

class snor_transaction extends uvm_sequence_item;
  `uvm_object_utils(snor_transaction)

  // request (driven by the agent)
  bit [7:0] mo[$];
  // response (returned by the DUT)
  bit [7:0] so[$];
  // bookkeeping (not compared)
  rand bit [4:0] kind;
  rand bit [15:0] addr;
  rand bit [4:0] n;
  rand bit [31:0] seed;
  bit [7:0] op;
  bit [7:0] rd[$];
  int unsigned tag;   // sequence number (driver/monitor order)


  function new(string name = "snor_transaction"); super.new(name); endfunction

  // kind: 0-3 read 0x03, 4-6 fast read 0x0B, 7-9 quad read 0x6B, 10 JEDEC ID,
  // 11 read status, 12 / 25-27 WREN, 13 WRDI, 14-17 page program, 18-19 sector
  // erase, 20 unknown command 0xAB, 21 read cut in the address, 22 quad read cut
  // in the dummy cycles, 23 quad read wrapping at 0xFFFF, 24 page program
  // wrapping in the page, 28-31 read of the programmed area 0x1000-0x10FF
  function void set(int k, bit [15:0] a = 16'h0, int cnt = 8, bit [31:0] s = 32'h1); kind = k; addr = a; n = cnt; seed = s; endfunction
  function bit [7:0] op_of();
    case (kind)
      0, 1, 2, 3, 21, 28, 29: return 8'h03;
      4, 5, 6, 30: return 8'h0B;
      7, 8, 9, 22, 23, 31: return 8'h6B;
      10: return 8'h9F;
      11: return 8'h05;
      12, 25, 26, 27: return 8'h06;
      13: return 8'h04;
      14, 15, 16, 17, 24: return 8'h02;
      18, 19: return 8'h20;
      default: return 8'hAB;
    endcase
  endfunction
  // host cells, one per sclk rising edge: {oe, value}
  function void build();
    bit [31:0] x = seed | 1;
    bit [23:0] a = {8'h00, addr};
    int nd = n, cut = -1;
    op = op_of();
    if (kind inside {[28:31]}) a = {12'h001, addr[7:0] & 8'hF0};
    if (kind == 23) a = 24'h00_FFF8 + addr[2:0];
    if (kind == 24) a = {8'h00, addr[15:8], 8'hF8};
    if (kind inside {[14:17], 24} && nd == 0) nd = 1;
    if (op == 8'h9F) nd = 3 + n % 3;
    if (op == 8'h05) nd = 1 + n % 3;
    mo.delete();
    for (int i = 7; i >= 0; i--) mo.push_back({4'b1101, 3'b110, op[i]});
    if (snor_has_addr(op)) for (int i = 23; i >= 0; i--) mo.push_back({4'b1101, 3'b110, a[i]});
    if (op == 8'h0B || op == 8'h6B) repeat (8) mo.push_back({4'b1101, 4'b1100});
    if (op == 8'h02)
      for (int b = 0; b < nd; b++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        for (int i = 7; i >= 0; i--) mo.push_back({4'b1101, 3'b110, x[i]});
      end
    else if (op == 8'h6B) repeat (2 * nd) mo.push_back(8'h00);
    else if (op inside {8'h03, 8'h0B, 8'h9F, 8'h05}) repeat (8 * nd) mo.push_back({4'b1101, 4'b1100});
    if (kind == 21) cut = 8 + 1 + x[3:0];
    if (kind == 22) cut = 32 + 1 + x[2:0] % 7;
    if (kind == 24 && x[0]) cut = mo.size() - 1 - x[3:1];
    if (cut >= 0) while (mo.size() > cut) void'(mo.pop_back());
  endfunction
  // monitor side: the bytes the flash drove after the first data edge
  function void decode();
    int s;
    rd.delete();
    if (mo.size() < 8) return;
    op = 0;
    for (int i = 0; i < 8; i++) op = {op[6:0], mo[i][4] ? mo[i][0] : 1'b1};
    s = snor_start(op);
    if (op == 8'h6B) for (int i = s; i + 1 < so.size(); i += 2) rd.push_back({so[i][3:0], so[i + 1][3:0]});
    else if (op inside {8'h03, 8'h0B, 8'h9F, 8'h05})
      for (int i = s; i + 7 < so.size(); i += 8) begin
        bit [7:0] b;
        for (int j = 0; j < 8; j++) b[7 - j] = so[i + j][1];
        rd.push_back(b);
      end
  endfunction

  function void do_copy(uvm_object rhs);
    snor_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    mo = rhs_.mo;
    so = rhs_.so;
    kind = rhs_.kind;
    addr = rhs_.addr;
    n = rhs_.n;
    seed = rhs_.seed;
    op = rhs_.op;
    rd = rhs_.rd;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    snor_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    if (so.size() != rhs_.so.size()) return 0;
    foreach (so[i]) if (so[i] != rhs_.so[i]) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(snor_transaction rhs_);
    if (mo.size() != rhs_.mo.size()) return 0;
    foreach (mo[i]) if (mo[i] != rhs_.mo[i]) return 0;
    return 1;
  endfunction

  function string qstr_mo();
    string s = $sformatf("[%0d]{", mo.size());
    foreach (mo[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", mo[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_so();
    string s = $sformatf("[%0d]{", so.size());
    foreach (so[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", so[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_rd();
    string s = $sformatf("[%0d]{", rd.size());
    foreach (rd[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", rd[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("SNOR{tag=%0d mo=%s so=%s}", tag, qstr_mo(), qstr_so());
  endfunction
endclass
