// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_compliance_checker.sv -- SNOR concurrent assertion checks (bindable)

module snor_compliance_checker
  (input logic clk, input logic rst_n, input logic sclk, input logic csn, input logic [3:0] io_m, input logic [3:0] io_m_oe, input logic [3:0] fl_io, input logic [3:0] fl_oe);

  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({sclk, csn, fl_oe}))
    else $error("SNOR: X on sclk / CS# / flash enables");
  assert property (@(posedge clk) disable iff (!rst_n) !csn |-> (io_m_oe & fl_oe) == 4'h0)
    else $error("SNOR: host and flash drive the same IO line");
  assert property (@(posedge clk) disable iff (!rst_n) csn |-> fl_oe == 4'h0)
    else $error("SNOR: flash drives IO with CS# high");
  assert property (@(posedge clk) disable iff (!rst_n) $fell(csn) |-> !sclk)
    else $error("SNOR: CS# fell with sclk high (not mode 0)");
  cover property (@(posedge clk) disable iff (!rst_n) fl_oe == 4'hF);
endmodule
