// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_pkg.sv -- SNOR UVM VIP package

package snor_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import snor_defs_pkg::*;
  export snor_defs_pkg::*;

  `include "snor_transaction.svh"
  `include "snor_config.svh"
  `include "snor_sequencer.svh"
  `include "snor_driver.svh"
  `include "snor_monitor.svh"
  `include "snor_agent.svh"
  `include "snor_sequences.svh"
  `include "snor_checker.svh"
  `include "snor_coverage.svh"
endpackage
