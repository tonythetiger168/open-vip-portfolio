// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_driver.svh -- SNOR driver: one CS# transfer per item: CS# low, one host cell per sclk period (outputs set while sclk is low, sclk high for the second half), sclk low with the host off the bus, CS# high for cfg.gap clocks

class snor_driver extends uvm_driver #(snor_transaction);
  `uvm_component_utils(snor_driver)

  uvm_analysis_port #(snor_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual snor_if vif;
  snor_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual snor_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "snor: virtual interface not set")
    if (!uvm_config_db#(snor_config)::get(this, "", "cfg", cfg))
      cfg = snor_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    snor_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.sclk    <= 1'b0;
    vif.drv_cb.csn     <= 1'b1;
    vif.drv_cb.io_m    <= 4'b1100;
    vif.drv_cb.io_m_oe <= 4'b1100;
  endtask

  task drive_item(snor_transaction t);
    t.build();
    @(vif.drv_cb);
    vif.drv_cb.csn <= 1'b0;
    foreach (t.mo[i]) begin
      vif.drv_cb.sclk    <= 1'b0;
      vif.drv_cb.io_m_oe <= t.mo[i][7:4];
      vif.drv_cb.io_m    <= t.mo[i][3:0];
      repeat (cfg.half) @(vif.drv_cb);
      vif.drv_cb.sclk <= 1'b1;
      repeat (cfg.half) @(vif.drv_cb);
    end
    vif.drv_cb.sclk    <= 1'b0;
    vif.drv_cb.io_m_oe <= 4'b0000;              // the flash may drive until CS# rises
    repeat (cfg.half) @(vif.drv_cb);
    vif.drv_cb.csn <= 1'b1;
    @(vif.drv_cb);
    vif.drv_cb.io_m_oe <= 4'b1100;
    vif.drv_cb.io_m    <= 4'b1100;
    repeat (cfg.gap) @(vif.drv_cb);
  endtask

endclass
