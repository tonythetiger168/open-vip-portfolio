// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_coverage.svh -- SNOR functional coverage

class snor_coverage extends uvm_subscriber #(snor_transaction);
  `uvm_component_utils(snor_coverage)
  snor_config cfg;
  snor_transaction tr;

  covergroup snor_cg;
    cp_op  : coverpoint tr.op { bins rd = {8'h03}; bins fast = {8'h0B}; bins quad = {8'h6B}; bins rdsr = {8'h05};
                                bins wren = {8'h06}; bins wrdi = {8'h04}; bins pp = {8'h02}; bins se = {8'h20};
                                bins id = {8'h9F}; bins other = {8'hAB}; }
    cp_len : coverpoint tr.mo.size() { bins cut = {[9:39]}; bins cmd = {8}; bins addr = {32}; bins data = {[40:400]}; }
    cp_rd  : coverpoint tr.rd.size() { bins none = {0}; bins one = {1}; bins some = {[2:31]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    snor_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(snor_config)::get(this, "", "cfg", cfg))
      cfg = snor_config::type_id::create("cfg");
  endfunction

  function void write(snor_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    snor_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("SNOR coverage: %0.1f%%", snor_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
