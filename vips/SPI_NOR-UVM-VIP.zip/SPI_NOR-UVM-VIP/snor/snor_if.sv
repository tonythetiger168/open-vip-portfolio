// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_if.sv -- SNOR interface

interface snor_if (input logic clk);
  logic rst_n;

  logic sclk;
  logic csn;
  logic [3:0] io_m;
  logic [3:0] io_m_oe;
  logic [3:0] fl_io;
  logic [3:0] fl_oe;

  modport DUT (input clk, rst_n, input sclk, input csn, input io_m, input io_m_oe, output fl_io, output fl_oe);
  modport MON (input clk, rst_n, sclk, csn, io_m, io_m_oe, fl_io, fl_oe);

  clocking drv_cb @(posedge clk);
    input rst_n, fl_io, fl_oe;
    inout sclk, csn, io_m, io_m_oe;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, sclk, csn, io_m, io_m_oe, fl_io, fl_oe;
  endclocking
endinterface
