// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// snor_env.sv -- SNOR environment: reference-model scoreboard, checker, coverage

package snor_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import common_pkg::*;
  import snor_defs_pkg::*;
  import snor_pkg::*;

  `uvm_analysis_imp_decl(_exp)
  `uvm_analysis_imp_decl(_obs)

  // Scoreboard. Every monitored item is checked against a reference model of
  // the DUT (predict() fills the expected response from the request fields);
  // in an active agent the driver's items are also matched in order against
  // the monitor's, so a transfer the DUT never completed, or one the
  // monitor decoded differently from how it was driven, is reported.
  class snor_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(snor_scoreboard)
    uvm_analysis_imp_exp #(snor_transaction, snor_scoreboard) exp_ap;
    uvm_analysis_imp_obs #(snor_transaction, snor_scoreboard) obs_ap;

    snor_config cfg;
    snor_transaction exp_q[$], obs_q[$];
    int unsigned n_checks = 0, n_matches = 0, n_mismatches = 0;
    bit active = 1;

    bit [7:0] mem [65536];
    bit       minit = 0;
    bit       wel = 0;

    function new(string name, uvm_component parent);
      super.new(name, parent);
      exp_ap = new("exp_ap", this);
      obs_ap = new("obs_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db#(snor_config)::get(this, "", "cfg", cfg))
        cfg = snor_config::type_id::create("cfg");
      active = (cfg.is_active == UVM_ACTIVE);
    endfunction

    // reference model: expected DUT response for request t (updates state)
    function void predict(snor_transaction t);
      // the flash, edge by edge: output for this rise (set at the falling edge
      // before it), the rising edge, then the falling edge after it; CS# rise last
      int nb = 0;
      bit [7:0] cmd = 0, pp = 0;
      bit [23:0] ad = 0;
      bit [3:0] oe = 0, o = 0;
      if (!minit) begin for (int i = 0; i < 65536; i++) mem[i] = snor_init(i); minit = 1; end
      t.so.delete();
      foreach (t.mo[i]) begin
        bit io0 = t.mo[i][4] ? t.mo[i][0] : 1'b1;
        t.so.push_back({oe, o & oe});
        if (nb < 8) cmd = {cmd[6:0], io0};
        else if (snor_has_addr(cmd) && nb < 32) ad = {ad[22:0], io0};
        else if (cmd == 8'h02 && nb >= 32) begin
          pp = {pp[6:0], io0};
          if ((nb - 32) % 8 == 7) begin
            if (wel) mem[ad[15:0]] = mem[ad[15:0]] & pp;
            ad[7:0] = ad[7:0] + 8'd1;
          end
        end
        nb++;
        if (nb >= 8) begin
          int k = nb - snor_start(cmd);
          if (k >= 0)
            case (cmd)
              8'h03, 8'h0B: begin oe = 4'b0010; o[1] = mem[ad[15:0] + 16'(k / 8)][7 - k % 8]; end
              8'h6B: begin
                       bit [7:0] b = mem[ad[15:0] + 16'(k / 2)];
                       oe = 4'b1111; o = (k % 2 == 0) ? b[7:4] : b[3:0];
                     end
              8'h05: begin oe = 4'b0010; o[1] = (k % 8 == 6) ? wel : 1'b0; end
              8'h9F: begin oe = 4'b0010; o[1] = (k < 24) ? 24'hEF4018 >> (23 - k) : 1'b0; end
              default: oe = 4'b0000;
            endcase
        end
      end
      if (nb >= 8) begin
        if (cmd == 8'h06) wel = 1;
        if (cmd == 8'h04) wel = 0;
        if (cmd == 8'h20 && nb >= 32) begin
          if (wel) for (int i = 0; i < 4096; i++) mem[{ad[15:12], 12'h000} + i] = 8'hFF;
          wel = 0;
        end
        if (cmd == 8'h02 && nb > 32) wel = 0;
      end
      t.decode();
    endfunction

    function void write_exp(snor_transaction t);
      exp_q.push_back(t);
      pair();
    endfunction

    function void write_obs(snor_transaction t);
      snor_transaction p;
      $cast(p, t.clone());
      predict(p);
      n_checks++;
      if (p.compare(t)) n_matches++;
      else begin
        n_mismatches++;
        `uvm_error("SB", $sformatf("DUT response mismatch\n  expected: %s\n  observed: %s",
                   p.convert2string(), t.convert2string()))
      end
      if (active) begin
        obs_q.push_back(t);
        pair();
      end
    endfunction

    function void pair();
      while (exp_q.size() && obs_q.size()) begin
        snor_transaction e = exp_q.pop_front();
        snor_transaction o = obs_q.pop_front();
        n_checks++;
        if (e.req_equal(o)) n_matches++;
        else begin
          n_mismatches++;
          `uvm_error("SB", $sformatf("driver/monitor disagree\n  driven:   %s\n  observed: %s",
                     e.convert2string(), o.convert2string()))
        end
      end
    endfunction

    function void check_phase(uvm_phase phase);
      if (exp_q.size() || obs_q.size())
        `uvm_error("SB", $sformatf("%0d driven / %0d observed items left unmatched at end of test",
                   exp_q.size(), obs_q.size()))
    endfunction

    function void report_phase(uvm_phase phase);
      `uvm_info("SB", $sformatf("snor scoreboard: n_checks=%0d n_matches=%0d n_mismatches=%0d",
                n_checks, n_matches, n_mismatches), UVM_LOW)
    endfunction
  endclass

  class snor_env extends uvm_env;
    `uvm_component_utils(snor_env)
    snor_agent      agt;
    snor_scoreboard sb;
    snor_checker    chk;
    snor_coverage   cov;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = snor_agent     ::type_id::create("agt", this);
      sb  = snor_scoreboard::type_id::create("sb",  this);
      chk = snor_checker   ::type_id::create("chk", this);
      cov = snor_coverage  ::type_id::create("cov", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (agt.is_active == UVM_ACTIVE)
        agt.drv.ap.connect(sb.exp_ap);
      agt.mon.ap.connect(sb.obs_ap);
      agt.mon.ap.connect(chk.imp);
      agt.mon.ap.connect(cov.analysis_export);
    endfunction
  endclass
endpackage
