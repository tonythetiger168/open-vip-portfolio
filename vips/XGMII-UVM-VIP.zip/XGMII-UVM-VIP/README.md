# XGMII UVM VIP (XGMII-UVM-VIP)

XGMII (802.3ae 10Gb) UVM VIP with 32-bit data/4-bit control loopback model. Complements the XGMII RTL IP from the open-ip-portfolio sister project.

## Structure

- `xgmii/` -- VIP core: interface, agent (driver/monitor/sequencer), sequences,
  scoreboard checker, functional coverage, `xgmii_compliance_checker.sv` SVA checks
- `common/` -- shared package
- `env/` -- environment with end-to-end scoreboard
- `tests/` -- `xgmii_base_test`
- `tb/top_tb.sv` -- UVM testbench top + behavioural XGMII DUT model (plain ports;
  flattened by `smoke/flatten.py` for the open-toolchain L1b smoke gate)
- `scripts/` -- coverage regression four-piece set (Makefile / coverage.mk /
  coverage_regression.sh / cov_check.py)

## Quality gates

- L1a elaboration: `python3 tools/elab_scan.py vips/XGMII-UVM-VIP` -> `ELAB_ERRORS=0`
- L1b smoke: `bash smoke/run_smoke.sh XGMII-UVM-VIP` -> `SMOKE_PASS`

## License

Apache-2.0 (SPDX-License-Identifier: Apache-2.0).
