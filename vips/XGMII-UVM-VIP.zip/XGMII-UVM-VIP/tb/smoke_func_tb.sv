// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 VIP Portfolio Contributors
// Functional smoke testbench (XGMII DUT model)
`timescale 1ns/1ps
//
// Self-checking directed test of the flattened xgmii_model; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [47:0] station = 48'h0200_0000_0001;
  logic promisc = 1'b0, mcast_en = 1'b1;
  logic [31:0] rxd = '0;
  logic [3:0] rxc = '0;
  wire  local_fault;
  wire  remote_fault;
  wire fr_done, fr_vlan, pause_valid;
  wire [2:0] fr_status;
  wire [15:0] fr_len, fr_etype, pause_quanta;
  wire [1:0] fr_cast;

  always #5 clk = ~clk;

  xgmii_model u_dut (.clk(clk), .rst_n(rst_n), .rxd(rxd), .rxc(rxc), .local_fault(local_fault), .remote_fault(remote_fault), .station(station), .promisc(promisc), .mcast_en(mcast_en),
                 .fr_done(fr_done), .fr_status(fr_status), .fr_len(fr_len), .fr_etype(fr_etype), .fr_cast(fr_cast),
                 .fr_vlan(fr_vlan), .pause_valid(pause_valid), .pause_quanta(pause_quanta));

  int checks = 0;
  int fails  = 0;

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  // frame under construction: fr[0:fl-1] = DA .. FCS
  logic [7:0] fr [0:2199];
  int fl;
  function automatic logic [31:0] crc32(input int n);
    logic [31:0] c = 32'hFFFF_FFFF;
    for (int i = 0; i < n; i++) begin
      c = c ^ {24'h0, fr[i]};
      for (int k = 0; k < 8; k++) c = c[0] ? ((c >> 1) ^ 32'hEDB8_8320) : (c >> 1);
    end
    return ~c;
  endfunction
  task automatic addb(input logic [7:0] b); fr[fl] = b; fl++; endtask
  task automatic add_fcs();
    logic [31:0] c = crc32(fl);
    for (int i = 0; i < 4; i++) addb(c[8*i +: 8]);
  endtask
  // DA, SA, [tag,] length / type, n payload bytes, FCS
  localparam logic [47:0] ST = 48'h0200_0000_0001;
  task automatic mk(input logic [47:0] da, input logic [15:0] lt, input int n, input bit tag);
    fl = 0;
    for (int i = 5; i >= 0; i--) addb(da[8*i +: 8]);
    for (int i = 5; i >= 0; i--) addb(8'hA0 + i);
    if (tag) begin addb(8'h81); addb(8'h00); addb(8'h20); addb(8'h05); end
    addb(lt[15:8]); addb(lt[7:0]);
    for (int i = 0; i < n; i++) addb(8'(i * 7 + 3));
    add_fcs();
  endtask
  task automatic mk_pause(input logic [47:0] da, input logic [15:0] op, input logic [15:0] q);
    fl = 0;
    for (int i = 5; i >= 0; i--) addb(da[8*i +: 8]);
    for (int i = 5; i >= 0; i--) addb(8'hA0 + i);
    addb(8'h88); addb(8'h08); addb(op[15:8]); addb(op[7:0]); addb(q[15:8]); addb(q[7:0]);
    repeat (42) addb(8'h00);
    add_fcs();
  endtask

  // frame results
  int ndone = 0, npause = 0;
  logic [2:0]  lst = 0;
  logic [15:0] llen = 0, let_ = 0, lq = 0;
  logic [1:0]  lca = 0;
  logic        lvl = 0, lpz = 0;
  always @(negedge clk) if (fr_done) begin
    ndone++; lst = fr_status; llen = fr_len; let_ = fr_etype; lca = fr_cast; lvl = fr_vlan; lpz = pause_valid;
    if (pause_valid) begin npause++; lq = pause_quanta; end
  end

  task automatic idle(input int n);
    repeat (n) @(negedge clk);
    #1;
  endtask

  // send fr with the bus task, expect one result with status s
  int n0;
  task automatic rx(input logic [2:0] s, input string msg);
    n0 = ndone;
    send(7, -1, 0, -1);
    idle(4);
    chk(ndone == n0 + 1 && lst == s && llen == fl, $sformatf("%s: status %0d (got %0d, len %0d/%0d, %0d results)",
        msg, s, lst, llen, fl, ndone - n0));
  endtask


  // column buffer
  logic [7:0] cb [0:2399];
  logic       ck [0:2399];
  int cn;
  task automatic col(input logic [7:0] b, input bit k); cb[cn] = b; ck[cn] = k; cn++; endtask
  task automatic flush();
    while (cn % 4) col(8'h07, 1);
    for (int i = 0; i < cn; i += 4) begin
      @(negedge clk); rxd = {cb[i+3], cb[i+2], cb[i+1], cb[i]}; rxc = {ck[i+3], ck[i+2], ck[i+1], ck[i]};
    end
    @(negedge clk); rxd = 32'h0707_0707; rxc = 4'hF;
    cn = 0;
  endtask

  // Start in lane bad_pre + 1 when bad_pre >= 0; no SFD; /E/ instead of fr[code_at]
  // (-2: instead of the SFD, -3: instead of a preamble byte)
  task automatic send(input int pre_n, input int bad_pre, input bit nosfd, input int code_at);
    cn = 0;
    if (bad_pre >= 0) repeat (bad_pre + 1) col(8'h07, 1);
    col(8'hFB, 1);
    for (int i = 0; i < 6; i++) if (i == 2 && code_at == -3) col(8'hFE, 1); else col(8'h55, 0);
    if (code_at == -2) col(8'hFE, 1); else col(nosfd ? 8'h55 : 8'hD5, 0);
    for (int i = 0; i < fl; i++) if (i == code_at) col(8'hFE, 1); else col(fr[i], 0);
    col(8'hFD, 1);
    flush();
  endtask

  task automatic rxs(input logic [2:0] s, input int bad_pre, input bit nosfd, input int code_at, input string msg);
    n0 = ndone;
    send(0, bad_pre, nosfd, code_at);
    idle(4);
    chk(ndone == n0 + 1 && lst == s, $sformatf("%s: status %0d (got %0d, %0d results)", msg, s, lst, ndone - n0));
  endtask

  task automatic seqs(input int n, input bit remote, input int gap);
    for (int i = 0; i < n; i++) begin
      @(negedge clk); rxd = remote ? 32'h0200_009C : 32'h0100_009C; rxc = 4'b0001;
      if (gap > 0 && i < n - 1) begin @(negedge clk); rxd = 32'h0707_0707; rxc = 4'hF; repeat (gap - 1) @(negedge clk); end
    end
    @(negedge clk); rxd = 32'h0707_0707; rxc = 4'hF;
    #1;
  endtask

  initial begin

    // reset values
    idle(3);
    chk(!fr_done && fr_status == 0 && !pause_valid && !fr_vlan && fr_cast == 0 && fr_len == 0 && fr_etype == 0 &&
        pause_quanta == 0, "reset values");
    rst_n = 1;
    idle(4);

    // good frames and what is reported
    mk(ST, 16'd46, 46, 0); rx(0, "64-byte unicast to the station");
    chk(let_ == 46 && lca == 1 && !lvl && !lpz, "length 46, unicast, untagged");
    mk(48'hFFFF_FFFF_FFFF, 16'h0800, 100, 0); rx(0, "broadcast");
    chk(lca == 3 && let_ == 16'h0800, "broadcast class, type 0800");
    mk(48'h0100_5E00_0001, 16'h86DD, 60, 0); rx(0, "multicast");
    chk(lca == 2, "multicast class");
    mk(ST, 16'h0800, 46, 1); rx(0, "vtag frame");
    chk(lvl && let_ == 16'h0800, "802.1Q tag skipped for the type");
    mk(48'hFFFF_FFFF_FFFE, 16'h0800, 46, 0); rx(0, "multicast all-but-broadcast");
    chk(lca == 2, "FF-FF-FF-FF-FF-FE is multicast, not broadcast");

    // address filter
    mk(ST ^ 48'h1, 16'h0800, 46, 0); rx(7, "unicast for another station");
    mk(ST ^ 48'h0000_8000_0000, 16'h0800, 46, 0); rx(7, "unicast differing in byte 2");
    mk(ST ^ 48'h0200_0000_0000, 16'h0800, 46, 0); rx(7, "unicast differing in byte 0");
    chk(lca == 1 && let_ == 16'h0800, "filtered frame still reports its fields");
    mcast_en = 0;
    mk(48'h0100_5E00_0001, 16'h0800, 46, 0); rx(7, "multicast while disabled");
    mk(48'hFFFF_FFFF_FFFF, 16'h0800, 46, 0); rx(0, "broadcast while multicast is disabled");
    promisc = 1;
    mk(48'h0100_5E00_0001, 16'h0800, 46, 0); rx(0, "promiscuous: multicast");
    mk(ST ^ 48'h1, 16'h0800, 46, 0); rx(0, "promiscuous: other unicast");
    promisc = 0; mcast_en = 1;
    station = 48'h0200_0000_0099;
    mk(48'h0200_0000_0099, 16'h0800, 46, 0); rx(0, "new station address");
    mk(ST, 16'h0800, 46, 0); rx(7, "old station address filtered");
    station = ST;

    // FCS
    mk(ST, 16'h0800, 46, 0); fr[fl - 4] ^= 8'h01; rx(3, "FCS byte 0 wrong");
    mk(ST, 16'h0800, 46, 0); fr[fl - 1] ^= 8'h80; rx(3, "FCS byte 3 wrong");
    mk(ST, 16'h0800, 46, 0); fr[20] ^= 8'h10; rx(3, "payload bit flipped");
    mk(ST, 16'h0800, 46, 0); fr[0] ^= 8'h04; rx(3, "FCS checked before the address");

    // length limits
    mk(ST, 16'h0800, 46, 1); rx(0, "tagged frame before the runt");
    mk(ST, 16'h0800, 45, 0); rx(4, "63-byte runt");
    chk(let_ == 0 && lca == 0 && !lvl, "runt reports no fields");
    mk(ST, 16'h0800, 10, 0); fr[fl - 1] ^= 1; rx(4, "runt checked before the FCS");
    mk(ST, 16'h0800, 1500, 0); rx(0, "1518 bytes");
    mk(ST, 16'h0800, 1501, 0); rx(5, "1519 bytes");
    mk(ST, 16'h0800, 1504, 0); rx(5, "1522 bytes untagged");
    mk(ST, 16'h0800, 1500, 1); rx(0, "1522 bytes vtag");
    mk(ST, 16'h0800, 1501, 1); rx(5, "1523 bytes vtag");
    mk(ST, 16'h0800, 1501, 0); fr[fl - 1] ^= 1; rx(5, "oversize checked before the FCS");
    mk(ST, 16'h0800, 2082, 0); rx(5, "2100-byte jabber: counted past the buffer");

    // length field
    mk(ST, 16'd45, 46, 0); rx(0, "length 45 padded to 46");
    mk(ST, 16'd0, 46, 0); rx(0, "length 0 padded");
    mk(ST, 16'd47, 46, 0); rx(6, "length 47 with 46 bytes");
    mk(ST, 16'd100, 100, 0); rx(0, "length 100 exact");
    mk(ST, 16'd99, 100, 0); rx(6, "length 99 with 100 bytes");
    mk(ST, 16'd101, 100, 0); rx(6, "length 101 with 100 bytes");
    mk(ST, 16'd46, 47, 0); rx(6, "length 46 with 47 bytes");
    mk(ST, 16'd42, 42, 1); rx(0, "vtag length 42 exact");
    mk(ST, 16'd10, 42, 1); rx(0, "vtag length 10 padded to 42");
    mk(ST, 16'd10, 43, 1); rx(6, "vtag length 10 with 43 bytes");
    mk(ST, 16'd43, 42, 1); rx(6, "vtag length 43 with 42 bytes");
    mk(ST, 16'd1500, 1500, 0); rx(0, "length 1500");
    mk(ST, 16'd1500, 1499, 0); rx(6, "length 1500 with 1499 bytes");
    mk(ST, 16'd1501, 100, 0); rx(6, "length / type 1501");
    mk(ST, 16'd1535, 100, 0); rx(6, "length / type 1535");
    mk(ST, 16'd1536, 100, 0); rx(0, "type 0600");
    chk(let_ == 16'd1536, "type 0600 reported");
    mk(ST ^ 48'h1, 16'd47, 46, 0); rx(6, "length error before the address filter");

    // PAUSE
    mk_pause(48'h0180_C200_0001, 16'h0001, 16'hBEEF); rx(0, "PAUSE to 01-80-C2-00-00-01");
    chk(lpz && lq == 16'hBEEF && npause == 1 && let_ == 16'h8808, "pause quanta BEEF");
    mk_pause(ST, 16'h0001, 16'h0010); rx(0, "PAUSE to the station address");
    chk(lpz && lq == 16'h0010, "pause to the station");
    mk_pause(48'h0180_C200_0001, 16'h0002, 16'h0010); rx(0, "MAC control opcode 2");
    chk(!lpz && lca == 2, "opcode 2: not a PAUSE");
    mk_pause(48'h0180_C200_0001, 16'h0101, 16'h0010); rx(0, "MAC control opcode 0101");
    chk(!lpz, "opcode 0101: not a PAUSE");
    mk_pause(48'h0180_C200_0002, 16'h0001, 16'h0010); rx(0, "PAUSE to another multicast");
    chk(!lpz, "PAUSE to 01-80-C2-00-00-02 not honoured");
    mk_pause(48'h0180_C200_0001, 16'h0001, 16'h0010); fr[12] = 8'h88; fr[13] = 8'h09;
    fl = fl - 4; add_fcs(); rx(0, "type 8809");
    chk(!lpz, "type 8809: not a PAUSE");
    mk(48'h0180_C200_0001, 16'h8808, 50, 1); fr[18] = 8'h00; fr[19] = 8'h01; fl = fl - 4; add_fcs();
    rx(0, "vtag MAC control frame");
    chk(!lpz, "vtag: not a PAUSE");
    mk_pause(ST ^ 48'h1, 16'h0001, 16'h0010); rx(7, "PAUSE to another station");
    chk(!lpz && npause == 2, "only two PAUSE frames honoured");


    // Terminate in each lane
    for (int n = 46; n < 50; n++) begin mk(ST, 16'h0800, n, 0); rx(0, $sformatf("Terminate in lane %0d", n % 4)); end
    // Start lane, SFD, /E/
    mk(ST, 16'h0800, 46, 0);
    rxs(1, 0, 0, -1, "Start in lane 1");
    rxs(1, 1, 0, -1, "Start in lane 2");
    rxs(1, 2, 0, -1, "Start in lane 3");
    rxs(0, 3, 0, -1, "Start in lane 0 of the next column");
    rxs(1, -1, 1, -1, "no SFD");
    chk(llen == 64 - 45, $sformatf("no SFD: bytes after the first D5 in the data (%0d)", llen));
    rxs(2, -1, 0, 10, "/E/ in the frame");
    chk(llen == 63, "/E/ replaces a byte");
    rxs(2, -1, 0, 0, "/E/ on the first byte");
    rxs(2, -1, 0, 63, "/E/ on the last byte");
    rxs(2, -1, 0, -3, "/E/ in the preamble");
    rxs(1, -1, 0, -2, "/E/ instead of the SFD: no SFD");
    rxs(1, 0, 0, 5, "Start error before code error");
    mk(ST, 16'h0800, 10, 0);
    rxs(2, -1, 0, 5, "code error before runt");
    // control characters inside the frame
    mk(ST, 16'h0800, 46, 0);
    n0 = ndone;
    cn = 0; col(8'hFB, 1); repeat (6) col(8'h55, 0); col(8'hD5, 0);
    for (int i = 0; i < 30; i++) col(fr[i], 0);
    col(8'h07, 1);
    for (int i = 30; i < fl; i++) col(fr[i], 0);
    col(8'hFD, 1); flush(); idle(4);
    chk(ndone == n0 + 1 && lst == 2 && llen == 30, $sformatf("Idle inside a frame ends it with an error (%0d)", llen));
    n0 = ndone;
    cn = 0; col(8'hFB, 1); repeat (6) col(8'h55, 0); col(8'hD5, 0);
    for (int i = 0; i < 20; i++) col(fr[i], 0);
    col(8'h9C, 1); col(8'hFD, 1); flush(); idle(4);
    chk(ndone == n0 + 1 && lst == 2, "Sequence character inside a frame");
    n0 = ndone;
    cn = 0; col(8'hFB, 1); repeat (3) col(8'h55, 0); col(8'h07, 1); col(8'hFD, 1); flush(); idle(4);
    chk(ndone == n0 + 1 && lst == 1, "Idle in the preamble: Start error");
    n0 = ndone;
    cn = 0; col(8'hFB, 1); repeat (3) col(8'h55, 0); col(8'hFD, 1); flush(); idle(4);
    chk(ndone == n0 + 1 && lst == 1 && llen == 0, "Terminate before the SFD: Start error");
    n0 = ndone;
    cn = 0; col(8'h55, 0); col(8'hD5, 0); col(8'hFD, 1); col(8'hFE, 1); for (int i = 0; i < 70; i++) col(8'h11, 0);
    flush(); idle(4);
    chk(ndone == n0, "data, Terminate and /E/ outside a frame are ignored");
    mk(ST, 16'h0800, 46, 0); rx(0, "frame after stray characters");
    // back-to-back: Start in the column after the Terminate
    n0 = ndone;
    cn = 0;
    for (int f = 0; f < 2; f++) begin
      col(8'hFB, 1); repeat (6) col(8'h55, 0); col(8'hD5, 0);
      for (int i = 0; i < fl; i++) col(fr[i], 0);
      col(8'hFD, 1);
      while (cn % 4) col(8'h07, 1);
    end
    flush(); idle(4);
    chk(ndone == n0 + 2 && lst == 0, "two frames with no Idle column between");

    // link fault signalling
    chk(!local_fault && !remote_fault, "no fault after reset");
    seqs(3, 0, 0); idle(2);
    chk(!local_fault, "three local fault sequences: no fault");
    idle(130);
    seqs(4, 0, 0);
    chk(local_fault && !remote_fault, "four local fault sequences: local fault");
    idle(127);
    chk(local_fault, "fault held 127 columns after the last sequence");
    idle(1);
    chk(!local_fault, "fault cleared after 128 columns");
    seqs(4, 1, 0);
    chk(remote_fault && !local_fault, "four remote fault sequences: remote fault");
    seqs(4, 0, 0);
    chk(local_fault && !remote_fault, "four local sequences replace a remote fault");
    idle(140);
    seqs(7, 0, 0); chk(local_fault, "more than four sequences");
    idle(140);
    // alternating types never reach four of one kind
    for (int i = 0; i < 8; i++) seqs(1, i[0], 0);
    chk(!local_fault && !remote_fault, "alternating local / remote: no fault");
    idle(140);
    seqs(3, 0, 0); seqs(1, 1, 0); seqs(3, 0, 0);
    chk(!local_fault && !remote_fault, "a remote sequence restarts the local count");
    idle(140);
    // sequences 127 columns apart still count, 128 apart do not
    seqs(4, 0, 127);
    chk(local_fault, "sequences 127 columns apart");
    idle(140);
    seqs(4, 0, 128);
    chk(!local_fault, "sequences 128 columns apart");
    idle(140);
    // not a fault sequence: other lane-3 code, other control lanes
    for (int i = 0; i < 6; i++) begin @(negedge clk); rxd = 32'h0300_009C; rxc = 4'b0001; end
    for (int i = 0; i < 6; i++) begin @(negedge clk); rxd = 32'h0100_009C; rxc = 4'b0011; end
    for (int i = 0; i < 6; i++) begin @(negedge clk); rxd = 32'h0100_009D; rxc = 4'b0001; end
    for (int i = 0; i < 6; i++) begin @(negedge clk); rxd = 32'h0101_009C; rxc = 4'b0001; end
    @(negedge clk); rxd = 32'h0707_0707; rxc = 4'hF; idle(2);
    chk(!local_fault && !remote_fault, "malformed Sequence ordered sets ignored");
    // frames between sequences count as columns without a fault
    seqs(4, 1, 0);
    mk(ST, 16'h0800, 1000, 0); rx(0, "frame during a remote fault");
    chk(!remote_fault, "fault cleared by frames");
    // reset clears the fault
    seqs(4, 0, 0);
    rst_n = 0; idle(2);
    chk(!local_fault, "reset clears the fault");
    rst_n = 1; idle(2);
    seqs(3, 0, 0);
    chk(!local_fault, "count restarts after reset");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #20000000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
