// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (XGMII PHY loopback)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened xgmii_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [31:0] txd = '0;
  logic [3:0]  txc = '0;
  wire  [31:0] rxd;
  wire  [3:0]  rxc;

  always #5 clk = ~clk;

  xgmii_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .txd(txd), .txc(txc),
    .rxd(rxd), .rxc(rxc)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [31:0] strm [0:5];
  initial begin
    strm[0]=32'h07070707; strm[1]=32'hFB555555; strm[2]=32'hD5D5D5D5;
    strm[3]=32'hAAAAAAAA; strm[4]=32'h12345678; strm[5]=32'hFDFD0707;
    repeat (8) step();
    chk(rxc === 4'h0 && rxd === 32'h0, "rx path reset quiet");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    for (int i = 0; i < 6; i++) begin
      @(negedge clk); txd = strm[i]; txc = 4'hF;
      step();
      chk(rxd === strm[i], "loopback word integrity");
      chk(rxc === 4'hF, "control nibble passthrough");
    end
    @(negedge clk); txc = 4'h0; txd = '0;
    step();
    chk(rxc === 4'h0, "rxc returns to idle");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
