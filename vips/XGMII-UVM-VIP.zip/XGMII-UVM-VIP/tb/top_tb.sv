// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- XGMII testbench top with a functional XGMII DUT model

`ifndef XGMII_UVM_VIP_TB_SV
`define XGMII_UVM_VIP_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import xgmii_defs_pkg::*;
import xgmii_pkg::*;
import xgmii_env_pkg::*;
import xgmii_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  xgmii_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  xgmii_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .station(vif.station),
    .promisc(vif.promisc),
    .mcast_en(vif.mcast_en),
    .rxd(vif.rxd),
    .rxc(vif.rxc),
    .fr_done(vif.fr_done),
    .fr_status(vif.fr_status),
    .fr_len(vif.fr_len),
    .fr_etype(vif.fr_etype),
    .fr_cast(vif.fr_cast),
    .fr_vlan(vif.fr_vlan),
    .pause_valid(vif.pause_valid),
    .pause_quanta(vif.pause_quanta),
    .local_fault(vif.local_fault),
    .remote_fault(vif.remote_fault)
  );

  // Concurrent protocol checks
  xgmii_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .station(vif.station),
    .promisc(vif.promisc),
    .mcast_en(vif.mcast_en),
    .rxd(vif.rxd),
    .rxc(vif.rxc),
    .fr_done(vif.fr_done),
    .fr_status(vif.fr_status),
    .fr_len(vif.fr_len),
    .fr_etype(vif.fr_etype),
    .fr_cast(vif.fr_cast),
    .fr_vlan(vif.fr_vlan),
    .pause_valid(vif.pause_valid),
    .pause_quanta(vif.pause_quanta),
    .local_fault(vif.local_fault),
    .remote_fault(vif.remote_fault)
  );

  initial begin
    uvm_config_db#(virtual xgmii_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module xgmii_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [31:0] rxd,
  input  logic [3:0]  rxc,
  input  logic [47:0] station,
  input  logic        promisc,
  input  logic        mcast_en,
  output logic        fr_done,
  output logic [2:0]  fr_status,
  output logic [15:0] fr_len,
  output logic [15:0] fr_etype,
  output logic [1:0]  fr_cast,
  output logic        fr_vlan,
  output logic        pause_valid,
  output logic [15:0] pause_quanta,
  output logic        local_fault,
  output logic        remote_fault
);
  // frame buffer filled by the bus front end
  logic [7:0]  fb [0:2047];
  logic [15:0] fcnt;
  logic        fe_end, f_pre, f_code;

  logic        inf, sfd;
  logic [1:0]  lt_typ, flt;
  logic [2:0]  scnt;
  logic [7:0]  ccnt;
  logic        i_inf, i_sfd, i_pre, i_code, i_end, kc, seq;
  logic [15:0] i_cnt;
  logic [7:0]  b;
  logic [1:0]  styp;
  integer      ln;
  assign local_fault  = (flt == 2'd1);
  assign remote_fault = (flt == 2'd2);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      inf <= 1'b0; sfd <= 1'b0; f_pre <= 1'b0; f_code <= 1'b0; fcnt <= 16'd0; fe_end <= 1'b0;
      lt_typ <= 2'd0; flt <= 2'd0; scnt <= 3'd0; ccnt <= 8'd128;
    end else begin
      // frames, lane by lane
      i_inf = inf; i_sfd = sfd; i_pre = f_pre; i_code = f_code; i_cnt = fcnt; i_end = 1'b0;
      for (ln = 0; ln < 4; ln++) begin
        b = rxd[8*ln +: 8];
        kc = rxc[ln];
        if (!i_inf) begin
          if (kc && b == 8'hFB) begin
            i_inf = 1'b1; i_sfd = 1'b0; i_pre = (ln != 0); i_code = 1'b0; i_cnt = 16'd0;
          end
        end else if (kc && b == 8'hFD) begin
          i_inf = 1'b0; i_end = 1'b1;
          if (!i_sfd) i_pre = 1'b1;
        end else if (kc && b != 8'hFE) begin
          // any other control character ends the frame with an error
          i_inf = 1'b0; i_end = 1'b1; i_code = 1'b1;
          if (!i_sfd) i_pre = 1'b1;
        end else if (kc) i_code = 1'b1;
        else if (!i_sfd) begin
          if (b == 8'hD5) i_sfd = 1'b1;
          else if (b != 8'h55) i_pre = 1'b1;
        end else begin
          if (i_cnt < 16'd2048) fb[i_cnt] <= b;
          i_cnt = i_cnt + 16'd1;
        end
      end
      inf <= i_inf; sfd <= i_sfd; f_pre <= i_pre; f_code <= i_code; fcnt <= i_cnt; fe_end <= i_end;

      // link fault signalling (clause 46.3.4)
      seq  = (rxc == 4'b0001) && (rxd == 32'h0100_009C || rxd == 32'h0200_009C);
      styp = rxd[25:24];
      if (seq) begin
        if (styp == lt_typ && ccnt < 8'd128) begin
          if (scnt >= 3'd3) flt <= styp;
          else scnt <= scnt + 3'd1;
        end else begin
          lt_typ <= styp; scnt <= 3'd1;
        end
        ccnt <= 8'd0;
      end else if (ccnt == 8'd127) begin
        flt <= 2'd0; scnt <= 3'd0; lt_typ <= 2'd0; ccnt <= 8'd128;
      end else if (ccnt < 8'd128) ccnt <= ccnt + 8'd1;
    end
  end


  // MAC receive check, the clock after the front end ends a frame
  logic [31:0] crc;
  logic [47:0] da;
  logic [15:0] lt;
  logic        vl;
  integer      pa, k, j;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fr_done <= 1'b0; fr_status <= 3'd0; fr_len <= 16'd0; fr_etype <= 16'd0; fr_cast <= 2'd0; fr_vlan <= 1'b0;
      pause_valid <= 1'b0; pause_quanta <= 16'd0;
    end else begin
      fr_done <= 1'b0;
      pause_valid <= 1'b0;
      if (fe_end) begin
        fr_done <= 1'b1; fr_len <= fcnt; fr_etype <= 16'd0; fr_cast <= 2'd0; fr_vlan <= 1'b0; pause_quanta <= 16'd0;
        vl = ({fb[12], fb[13]} == 16'h8100);
        lt = vl ? {fb[16], fb[17]} : {fb[12], fb[13]};
        da = {fb[0], fb[1], fb[2], fb[3], fb[4], fb[5]};
        if (f_pre) fr_status <= 3'd1;
        else if (f_code) fr_status <= 3'd2;
        else if (fcnt < 16'd64) fr_status <= 3'd4;
        else if (fcnt > (vl ? 16'd1522 : 16'd1518)) fr_status <= 3'd5;
        else begin
          crc = 32'hFFFF_FFFF;
          for (k = 0; k < fcnt - 4; k++) begin
            crc = crc ^ {24'h0, fb[k]};
            for (j = 0; j < 8; j++) crc = crc[0] ? ((crc >> 1) ^ 32'hEDB8_8320) : (crc >> 1);
          end
          crc = ~crc;
          if ({fb[fcnt-1], fb[fcnt-2], fb[fcnt-3], fb[fcnt-4]} != crc) fr_status <= 3'd3;
          else begin
            pa = fcnt - 18 - (vl ? 4 : 0);
            fr_etype <= lt; fr_vlan <= vl;
            fr_cast <= (da == 48'hFFFF_FFFF_FFFF) ? 2'd3 : da[40] ? 2'd2 : 2'd1;
            if (lt > 16'd1500 && lt < 16'd1536) fr_status <= 3'd6;
            else if (lt <= 16'd1500 && (lt > pa || (lt < pa && pa > (vl ? 42 : 46)))) fr_status <= 3'd6;
            else if (!vl && lt == 16'h8808 && {fb[14], fb[15]} == 16'h0001 &&
                     (da == 48'h0180_C200_0001 || da == station)) begin
              fr_status <= 3'd0; pause_valid <= 1'b1; pause_quanta <= {fb[16], fb[17]};
            end
            else if (!promisc && ((!da[40] && da != station) || (da[40] && da != 48'hFFFF_FFFF_FFFF && !mcast_en)))
              fr_status <= 3'd7;
            else fr_status <= 3'd0;
          end
        end
      end
    end
  end
endmodule
`endif
