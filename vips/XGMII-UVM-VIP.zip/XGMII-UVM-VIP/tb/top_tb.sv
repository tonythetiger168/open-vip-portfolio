// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- XGMII testbench top with a functional XGMII DUT model

`ifndef XGMII_TB_SV
`define XGMII_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import xgmii_defs_pkg::*;
import xgmii_pkg::*;
import xgmii_env_pkg::*;
import xgmii_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  xgmii_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  xgmii_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .txd(vif.txd),
    .txc(vif.txc),
    .rxd(vif.rxd),
    .rxc(vif.rxc)
  );

  // Concurrent protocol checks
  xgmii_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .txd(vif.txd), .txc(vif.txc), .rxd(vif.rxd), .rxc(vif.rxc)
  );

  initial begin
    uvm_config_db#(virtual xgmii_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module xgmii_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [31:0] txd,
  input  logic [3:0]  txc,
  output logic [31:0] rxd,
  output logic [3:0]  rxc
);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rxd <= '0;
      rxc <= '0;
    end else begin
      rxd <= txd;
      rxc <= txc;
    end
  end
endmodule
`endif
