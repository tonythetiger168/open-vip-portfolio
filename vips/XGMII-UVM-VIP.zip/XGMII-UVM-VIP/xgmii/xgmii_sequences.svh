// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_sequences.svh -- XGMII sequences

// Random traffic: cfg.num_items constrained-random items.
class xgmii_base_sequence extends uvm_sequence #(xgmii_transaction);
  `uvm_object_utils(xgmii_base_sequence)
  xgmii_config cfg;

  function new(string name = "xgmii_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = xgmii_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "xgmii_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class xgmii_directed_sequence extends uvm_sequence #(xgmii_transaction);
  `uvm_object_utils(xgmii_directed_sequence)
  xgmii_config cfg;

  function new(string name = "xgmii_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function xgmii_transaction item();
    item = xgmii_transaction::type_id::create("req");
  endfunction

  task send(xgmii_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    xgmii_transaction t;
    for (int n = 46; n < 50; n++) begin    // Terminate in each lane
      t = item(); t.plen = n; t.seed = n; t.post_randomize(); send(t);
    end
    t = item(); t.plen = 100; t.seed = 32'h77; t.post_randomize(); send(t);
    t = item(); t.plen = 60; t.seed = 32'h78; t.inject_err = 1; t.post_randomize(); send(t);
  endtask
endclass
