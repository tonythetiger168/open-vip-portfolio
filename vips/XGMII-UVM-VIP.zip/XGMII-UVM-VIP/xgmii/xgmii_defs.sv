// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_defs.sv -- XGMII shared type definitions

package xgmii_defs_pkg;

  typedef enum bit [1:0] {XGMII_OK, XGMII_ERR} xgmii_status_e;

  localparam bit [47:0] XGMII_STATION = 48'h0200_0000_0001;   // DUT station address
  localparam bit [47:0] XGMII_PAUSE_DA = 48'h0180_C200_0001;

  typedef enum bit [1:0] {XGMII_FRAME, XGMII_FC, XGMII_STATUS, XGMII_FAULT} xgmii_kind_e;
  typedef enum bit [2:0] {XGMII_X_NONE, XGMII_X_PRE, XGMII_X_NOSFD, XGMII_X_CODE, XGMII_X_FCS, XGMII_X_RUNT, XGMII_X_OVER,
                          XGMII_X_LEN} xgmii_inj_e;
  typedef enum bit [2:0] {XGMII_D_SELF, XGMII_D_OTHER, XGMII_D_MCAST, XGMII_D_BCAST, XGMII_D_PAUSE} xgmii_da_e;

  // IEEE 802.3 CRC-32 (reflected 0xEDB88320, init and final xor all ones)
  function automatic bit [31:0] xgmii_crc32(bit [7:0] b[$], int unsigned n);
    bit [31:0] c = 32'hFFFF_FFFF;
    for (int unsigned i = 0; i < n; i++) begin
      c ^= {24'h0, b[i]};
      for (int k = 0; k < 8; k++) c = c[0] ? (c >> 1) ^ 32'hEDB8_8320 : (c >> 1);
    end
    return ~c;
  endfunction

  // receive check of one frame (bytes after the SFD): status and reported fields
  function automatic void xgmii_mac_check(input bit [7:0] b[$], input bit pre_bad, input bit code_err,
                                       input bit [47:0] station, input bit promisc, input bit mcast_en,
                                       output bit [2:0] st, output bit [15:0] et, output bit [1:0] ca,
                                       output bit vl, output bit pz, output bit [15:0] qz);
    int unsigned n = b.size(), pa;
    bit [31:0] c;
    bit [47:0] da;
    bit [15:0] lt;
    bit v;
    st = 0; et = 0; ca = 0; vl = 0; pz = 0; qz = 0;
    if (pre_bad) begin st = 1; return; end
    if (code_err) begin st = 2; return; end
    if (n < 64) begin st = 4; return; end
    v = ({b[12], b[13]} == 16'h8100);
    if (n > (v ? 1522 : 1518)) begin st = 5; return; end
    c = xgmii_crc32(b, n - 4);
    if ({b[n-1], b[n-2], b[n-3], b[n-4]} != c) begin st = 3; return; end
    lt = v ? {b[16], b[17]} : {b[12], b[13]};
    da = {b[0], b[1], b[2], b[3], b[4], b[5]};
    et = lt; vl = v;
    ca = (da == 48'hFFFF_FFFF_FFFF) ? 2'd3 : da[40] ? 2'd2 : 2'd1;
    pa = n - 18 - (v ? 4 : 0);
    if (lt > 1500 && lt < 1536) st = 6;
    else if (lt <= 1500 && (lt > pa || (lt < pa && pa > (v ? 42 : 46)))) st = 6;
    else if (!v && lt == 16'h8808 && {b[14], b[15]} == 16'h0001 && (da == XGMII_PAUSE_DA || da == station)) begin
      pz = 1; qz = {b[16], b[17]};
    end
    else if (!promisc && ((ca == 1 && da != station) || (ca == 2 && !mcast_en))) st = 7;
  endfunction

endpackage
