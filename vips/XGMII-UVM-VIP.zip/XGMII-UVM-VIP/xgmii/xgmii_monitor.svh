// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_monitor.svh -- XGMII monitor: frames between Start and Terminate on txd/txc, paired with rxd/rxc

class xgmii_monitor extends uvm_monitor;
  `uvm_component_utils(xgmii_monitor)

  virtual xgmii_if vif;
  uvm_analysis_port #(xgmii_transaction) ap;
  xgmii_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual xgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "xgmii: virtual interface not set")
    if (!uvm_config_db#(xgmii_config)::get(this, "", "cfg", cfg))
      cfg = xgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] l0[$], l1[$];
      bit f0 = 0, f1 = 0, e0 = 0, e1 = 0;
      xgmii_transaction in_q[$];
      forever begin
        @(vif.mon_cb);
        for (int ln = 0; ln < 4; ln++) begin
          bit [7:0] b = vif.mon_cb.rxd[ln*8 +: 8];
          bit k = vif.mon_cb.rxc[ln];
          if (!f1) begin
            if (k && b == 8'hFB) begin f1 = 1; l1.delete(); e1 = 0; end
          end else if (k && b == 8'hFD) begin
            f1 = 0;
            if (in_q.size() == 0) `uvm_error("MON", "XGMII frame received that was never sent")
            else begin
              xgmii_transaction t = in_q.pop_front();
              frame(l1, t, 1); t.out_err = e1;
              publish(t);
            end
          end else begin
            if (k) e1 = 1;
            l1.push_back(b);
          end
        end
        for (int ln = 0; ln < 4; ln++) begin
          bit [7:0] b = vif.mon_cb.txd[ln*8 +: 8];
          bit k = vif.mon_cb.txc[ln];
          if (!f0) begin
            if (k && b == 8'hFB) begin f0 = 1; l0.delete(); e0 = 0; end
          end else if (k && b == 8'hFD) begin
            f0 = 0;
            begin
              xgmii_transaction t = xgmii_transaction::type_id::create("t");
              frame(l0, t, 0); t.inject_err = e0;
              in_q.push_back(t);
            end
          end else begin
            if (k) e0 = 1;
            l0.push_back(b);
          end
        end
      end
    end
  endtask

  function void publish(xgmii_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

  // strip and check the preamble (six 55 + SFD after Start)
  function void frame(bit [7:0] l[$], xgmii_transaction t, bit out);
    bit ok = (l.size() >= 7);
    for (int i = 0; i < 7 && i < l.size(); i++) if (l[i] != ((i == 6) ? 8'hD5 : 8'h55)) ok = 0;
    if (out) begin t.out_preamble_ok = ok; t.out_bytes.delete(); end
    else     begin t.preamble_ok = ok;     t.bytes.delete(); end
    for (int i = 7; i < l.size(); i++)
      if (out) t.out_bytes.push_back(l[i]); else t.bytes.push_back(l[i]);
  endfunction
endclass
