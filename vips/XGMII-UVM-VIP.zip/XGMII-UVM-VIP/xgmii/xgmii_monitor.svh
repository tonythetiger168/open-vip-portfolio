// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_monitor.svh -- XGMII monitor: decodes observed bus activity

class xgmii_monitor extends uvm_monitor;
  `uvm_component_utils(xgmii_monitor)

  virtual xgmii_if vif;
  uvm_analysis_port #(xgmii_transaction) ap;
  xgmii_config cfg;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual xgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "xgmii: virtual interface not set")
    void'(uvm_config_db#(xgmii_config)::get(this, "*", "cfg", cfg));
  endfunction

  task run_phase(uvm_phase phase);
    xgmii_transaction t;
    int unsigned mon_cnt = 0;
    wait (vif.rst_n === 1'b1);
    forever begin
      @(vif.mon_cb);
      if (1'b1) begin
        t = xgmii_transaction::type_id::create("t", this);
        t.tag = mon_cnt++;
        t.txd = vif.txd;
        t.txc = vif.txc;
        t.rxd_o = vif.rxd;
        t.rxc_o = vif.rxc;
        ap.write(t);
      end
    end
  endtask
endclass
