// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_monitor.svh -- XGMII monitor: frames and bus events on the receive pins, with the MAC's status and reported fields

class xgmii_monitor extends uvm_monitor;
  `uvm_component_utils(xgmii_monitor)

  virtual xgmii_if vif;
  uvm_analysis_port #(xgmii_transaction) ap;
  xgmii_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual xgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "xgmii: virtual interface not set")
    if (!uvm_config_db#(xgmii_config)::get(this, "", "cfg", cfg))
      cfg = xgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      bit [7:0] bq[$];
      bit inf = 0, sfd = 0, pb = 0, ce = 0, prev = 0;
      int run = 0, quiet = 0;
      xgmii_transaction pend[$];
      xgmii_transaction ft;
      forever begin
        @(vif.mon_cb);
        if (vif.mon_cb.rst_n !== 1'b1) begin inf = 0; pend.delete(); ft = null; continue; end
        // DUT results for earlier columns
        if (vif.mon_cb.fr_done) begin
          if (pend.size() == 0) `uvm_error("MON", "XGMII fr_done without a frame")
          else begin
            xgmii_transaction t = pend.pop_front();
            t.status = vif.mon_cb.fr_status; t.len = vif.mon_cb.fr_len; t.etype = vif.mon_cb.fr_etype;
            t.cast = vif.mon_cb.fr_cast; t.vlan = vif.mon_cb.fr_vlan; t.pause = vif.mon_cb.pause_valid;
            t.quanta = t.pause ? vif.mon_cb.pause_quanta : 16'h0;
            publish(t);
          end
        end
        if (ft != null) ft.fseen |= {vif.mon_cb.remote_fault, vif.mon_cb.local_fault};
        else if (vif.mon_cb.remote_fault || vif.mon_cb.local_fault)
          `uvm_error("MON", "XGMII link fault reported without fault sequences")
        // link fault sequences: one item per burst, closed 132 columns after the last one
        if (vif.mon_cb.rxc == 4'b0001 && (vif.mon_cb.rxd == 32'h0100_009C || vif.mon_cb.rxd == 32'h0200_009C)) begin
          bit ty = vif.mon_cb.rxd[25];
          if (ft == null) begin ft = xgmii_transaction::type_id::create("flt"); ft.kind = XGMII_FAULT; end
          run = (ft.fcols > 0 && ty == prev) ? run + 1 : 1; prev = ty;
          ft.fcols++;
          if (run >= 4) begin if (ty) ft.frr = 1; else ft.frl = 1; end
          quiet = 0;
        end else if (ft != null && ++quiet == 132) begin
          ft.fend = {vif.mon_cb.remote_fault, vif.mon_cb.local_fault};
          publish(ft); ft = null;
        end
        // frames, lane by lane
        for (int ln = 0; ln < 4; ln++) begin
          bit [7:0] b = vif.mon_cb.rxd[8*ln +: 8];
          bit k = vif.mon_cb.rxc[ln];
          bit fin = 0;
          if (!inf) begin
            if (k && b == 8'hFB) begin inf = 1; sfd = 0; pb = (ln != 0); ce = 0; bq.delete(); end
          end else if (k && b == 8'hFD) fin = 1;
          else if (k && b != 8'hFE) begin fin = 1; ce = 1; end
          else if (k) ce = 1;
          else if (!sfd) begin if (b == 8'hD5) sfd = 1; else if (b != 8'h55) pb = 1; end
          else bq.push_back(b);
          if (fin) begin
            xgmii_transaction t = xgmii_transaction::type_id::create("t");
            inf = 0; t.kind = XGMII_FRAME; t.bytes = bq; t.pre_bad = pb || !sfd; t.code_err = ce;
            pend.push_back(t);
          end
        end
      end
    end
  endtask

  function void publish(xgmii_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
