// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_sequencer.svh -- XGMII sequencer

class xgmii_sequencer extends uvm_sequencer #(xgmii_transaction);
  `uvm_component_utils(xgmii_sequencer)
  function new(string name = "xgmii_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass
