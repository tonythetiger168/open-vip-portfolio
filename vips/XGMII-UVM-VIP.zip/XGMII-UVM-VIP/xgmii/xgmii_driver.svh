// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_driver.svh -- XGMII driver: Start, preamble, SFD, frame, Terminate and Idle, four lanes per clock

class xgmii_driver extends uvm_driver #(xgmii_transaction);
  `uvm_component_utils(xgmii_driver)

  uvm_analysis_port #(xgmii_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual xgmii_if vif;
  xgmii_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual xgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "xgmii: virtual interface not set")
    if (!uvm_config_db#(xgmii_config)::get(this, "", "cfg", cfg))
      cfg = xgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    xgmii_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.txd <= 32'h0707_0707; vif.drv_cb.txc <= 4'hF;
  endtask

  task drive_item(xgmii_transaction t);
    bit [7:0] b[$];
    bit k[$];
    @(vif.drv_cb);
    b.push_back(8'hFB); k.push_back(1);
    for (int i = 0; i < 6; i++) begin b.push_back(8'h55); k.push_back(0); end
    b.push_back(8'hD5); k.push_back(0);
    foreach (t.bytes[i]) begin
      b.push_back(t.bytes[i]);
      k.push_back(t.inject_err && i == t.bytes.size() / 2);
    end
    b.push_back(8'hFD); k.push_back(1);
    while (b.size() % 4) begin b.push_back(8'h07); k.push_back(1); end
    for (int i = 0; i < b.size(); i += 4) begin
      vif.drv_cb.txd <= {b[i+3], b[i+2], b[i+1], b[i]};
      vif.drv_cb.txc <= {k[i+3], k[i+2], k[i+1], k[i]};
      @(vif.drv_cb);
    end
    vif.drv_cb.txd <= 32'h0707_0707;
    vif.drv_cb.txc <= 4'hF;
    repeat (cfg.ifg_cols) @(vif.drv_cb);
  endtask

endclass
