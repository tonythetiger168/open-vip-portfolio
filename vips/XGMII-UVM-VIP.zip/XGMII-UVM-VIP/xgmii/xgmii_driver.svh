// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_driver.svh -- XGMII driver: one frame or bus event per item on the receive pins, then the inter-frame gap

class xgmii_driver extends uvm_driver #(xgmii_transaction);
  `uvm_component_utils(xgmii_driver)

  uvm_analysis_port #(xgmii_transaction) ap;  // items as driven (+ response seen)
  int unsigned item_cnt = 0;

  virtual xgmii_if vif;
  xgmii_config cfg;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    ap = new("ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual xgmii_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "xgmii: virtual interface not set")
    if (!uvm_config_db#(xgmii_config)::get(this, "", "cfg", cfg))
      cfg = xgmii_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    xgmii_transaction rsp_item;
    drive_idle();
    wait (vif.rst_n === 1'b1);
    repeat (4) @(vif.drv_cb);

    forever begin
      seq_item_port.get_next_item(req);
      req.tag = item_cnt++;
      `uvm_info("DRV", {"drive: ", req.convert2string()}, UVM_HIGH)
      drive_item(req);
      $cast(rsp_item, req.clone());
      ap.write(rsp_item);
      seq_item_port.item_done();
    end
  endtask

  // bus idle / reset values
  task drive_idle();
    vif.drv_cb.rxd <= 32'h0707_0707; vif.drv_cb.rxc <= 4'hF;
    vif.drv_cb.station <= cfg.station; vif.drv_cb.promisc <= cfg.promisc; vif.drv_cb.mcast_en <= cfg.mcast_en;
  endtask

  task drive_item(xgmii_transaction t);
    bit [7:0] cb[$];
    bit kq[$];
    @(vif.drv_cb);
    repeat (t.gap) @(vif.drv_cb);
    t.pre_bad = 0; t.code_err = 0; t.fcols = 0; t.frl = 0; t.frr = 0;
    if (t.kind == XGMII_FAULT) begin
      int run = 0;
      bit prev = 0;
      t.bytes.delete(); t.inj = XGMII_X_NONE;
      for (int i = 0; i < t.fn; i++) begin
        bit ty = t.fmix ? (t.ftype ^ i[0]) : t.ftype;     // 0 local, 1 remote
        vif.drv_cb.rxd <= ty ? 32'h0200_009C : 32'h0100_009C; vif.drv_cb.rxc <= 4'b0001;
        @(vif.drv_cb);
        run = (i > 0 && ty == prev) ? run + 1 : 1; prev = ty;
        if (run >= 4) begin if (ty) t.frr = 1; else t.frl = 1; end
      end
      t.fcols = t.fn;
      vif.drv_cb.rxd <= 32'h0707_0707; vif.drv_cb.rxc <= 4'hF;
      repeat (140) @(vif.drv_cb);                          // the fault clears after 128 columns
      return;
    end
    t.build(cfg.station);
    // Start in lane 0 (or later, broken on purpose), preamble, SFD
    if (t.inj == XGMII_X_PRE) begin
      repeat (1 + t.seed[9:8] % 3) begin cb.push_back(8'h07); kq.push_back(1); end
      t.pre_bad = 1;
    end
    cb.push_back(8'hFB); kq.push_back(1);
    repeat (6) begin cb.push_back(8'h55); kq.push_back(0); end
    if (t.inj != XGMII_X_NOSFD) begin
      cb.push_back(8'hD5); kq.push_back(0);
      foreach (t.bytes[i]) begin cb.push_back(t.bytes[i]); kq.push_back(0); end
    end else begin
      int k = -1;
      t.pre_bad = 1;
      cb.push_back(8'h55); kq.push_back(0);
      foreach (t.bytes[i]) if (k < 0 && t.bytes[i] == 8'hD5) k = i;
      foreach (t.bytes[i]) begin cb.push_back(t.bytes[i]); kq.push_back(0); end
      if (k < 0) t.bytes.delete(); else t.bytes = t.bytes[k + 1 : $];
    end
    if (t.inj == XGMII_X_CODE) begin
      // /E/ replaces a byte: the receiver sees the frame without it
      int ci = t.bytes.size() / 2;
      cb[cb.size() - t.bytes.size() + ci] = 8'hFE; kq[kq.size() - t.bytes.size() + ci] = 1;
      t.bytes.delete(ci);
      t.code_err = 1;
    end
    cb.push_back(8'hFD); kq.push_back(1);
    while (cb.size() % 4) begin cb.push_back(8'h07); kq.push_back(1); end
    for (int i = 0; i < cb.size(); i += 4) begin
      vif.drv_cb.rxd <= {cb[i+3], cb[i+2], cb[i+1], cb[i]};
      vif.drv_cb.rxc <= {kq[i+3], kq[i+2], kq[i+1], kq[i]};
      @(vif.drv_cb);
    end
    vif.drv_cb.rxd <= 32'h0707_0707; vif.drv_cb.rxc <= 4'hF;
    repeat (cfg.ifg) @(vif.drv_cb);
  endtask

endclass
