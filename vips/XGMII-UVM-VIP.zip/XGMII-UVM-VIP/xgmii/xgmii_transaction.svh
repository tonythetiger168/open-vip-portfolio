// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_transaction.svh -- XGMII transaction

class xgmii_transaction extends uvm_sequence_item;
  `uvm_object_utils(xgmii_transaction)

  // request (driven by the agent)
  rand xgmii_kind_e kind;
  bit [7:0] bytes[$];
  bit pre_bad;
  bit code_err;
  bit [3:0] fcols;
  bit frl;
  bit frr;
  // response (returned by the DUT)
  bit [2:0] status;
  bit [15:0] len;
  bit [15:0] etype;
  bit [1:0] cast;
  bit vlan;
  bit pause;
  bit [15:0] quanta;
  bit [1:0] fseen;
  bit [1:0] fend;
  // bookkeeping (not compared)
  rand xgmii_inj_e inj;
  rand xgmii_da_e dak;
  rand bit vtag;
  rand bit use_len;
  rand bit [10:0] plen;
  rand bit [2:0] pre_n;
  rand bit [15:0] pq;
  rand bit [31:0] seed;
  rand bit [3:0] gap;
  rand bit [3:0] fn;
  rand bit ftype;
  rand bit fmix;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_kind { kind dist { XGMII_FRAME := 12, XGMII_FAULT := 2 }; }
  constraint c_inj  { inj dist { XGMII_X_NONE := 12, [XGMII_X_PRE : XGMII_X_LEN] :/ 6 };
                      inj == XGMII_X_LEN -> dak != XGMII_D_PAUSE; }
  constraint c_da   { dak dist { XGMII_D_SELF := 6, XGMII_D_OTHER := 1, XGMII_D_MCAST := 1, XGMII_D_BCAST := 1, XGMII_D_PAUSE := 1 }; }
  constraint c_len  { plen dist { [0:45] :/ 2, [46:200] :/ 6, [1400:1500] :/ 1 }; pre_n inside {[1:7]};
                      vtag dist { 0 := 3, 1 := 1 }; gap inside {[0:4]}; }
  constraint c_flt { fn inside {[1:12]}; }

  function new(string name = "xgmii_transaction"); super.new(name); endfunction

  // the MAC frame (DA .. FCS) for the item's knobs; station: the DUT's address
  function void build(bit [47:0] station);
    bit [31:0] x = seed | 32'h1, c;
    bit [47:0] da;
    int unsigned n, pad;
    bit [15:0] lt;
    case (dak)
      XGMII_D_SELF:  da = station;
      XGMII_D_OTHER: da = station ^ 48'h0000_0000_0300;
      XGMII_D_MCAST: da = 48'h0100_5E00_0000 | seed[7:0];
      XGMII_D_BCAST: da = 48'hFFFF_FFFF_FFFF;
      default:     da = XGMII_PAUSE_DA;
    endcase
    bytes.delete();
    for (int i = 5; i >= 0; i--) bytes.push_back(da[8*i +: 8]);
    for (int i = 5; i >= 0; i--) bytes.push_back(8'hA0 + i);
    if (dak == XGMII_D_PAUSE) begin
      bytes.push_back(8'h88); bytes.push_back(8'h08); bytes.push_back(8'h00); bytes.push_back(8'h01);
      bytes.push_back(pq[15:8]); bytes.push_back(pq[7:0]);
      repeat (42) bytes.push_back(8'h00);
    end else begin
      int unsigned pl = (inj == XGMII_X_OVER) ? 1501 + plen[3:0] : (inj == XGMII_X_RUNT) ? plen % 40 : plen;
      if (vtag) begin bytes.push_back(8'h81); bytes.push_back(8'h00); bytes.push_back(seed[15:8]); bytes.push_back(seed[7:0]); end
      lt = (use_len && inj != XGMII_X_OVER) ? 16'(pl) : 16'h0800;
      if (inj == XGMII_X_LEN) lt = (pl > 46) ? 16'(pl - 1) : 16'(pl + 47);
      bytes.push_back(lt[15:8]); bytes.push_back(lt[7:0]);
      for (int unsigned i = 0; i < pl; i++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        bytes.push_back(x[7:0]);
      end
      pad = vtag ? 42 : 46;
      if (inj != XGMII_X_RUNT) while (bytes.size() < 14 + 4 * vtag + pad) bytes.push_back(8'h00);
    end
    c = xgmii_crc32(bytes, bytes.size());
    if (inj == XGMII_X_FCS) c ^= 32'h1 << seed[4:0];
    for (int i = 0; i < 4; i++) bytes.push_back(c[8*i +: 8]);
  endfunction

  function void do_copy(uvm_object rhs);
    xgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    kind = rhs_.kind;
    bytes = rhs_.bytes;
    pre_bad = rhs_.pre_bad;
    code_err = rhs_.code_err;
    status = rhs_.status;
    len = rhs_.len;
    etype = rhs_.etype;
    cast = rhs_.cast;
    vlan = rhs_.vlan;
    pause = rhs_.pause;
    quanta = rhs_.quanta;
    inj = rhs_.inj;
    dak = rhs_.dak;
    vtag = rhs_.vtag;
    use_len = rhs_.use_len;
    plen = rhs_.plen;
    pre_n = rhs_.pre_n;
    pq = rhs_.pq;
    seed = rhs_.seed;
    gap = rhs_.gap;
    fcols = rhs_.fcols;
    frl = rhs_.frl;
    frr = rhs_.frr;
    fseen = rhs_.fseen;
    fend = rhs_.fend;
    fn = rhs_.fn;
    ftype = rhs_.ftype;
    fmix = rhs_.fmix;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    xgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (kind != rhs_.kind) return 0;
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (pre_bad != rhs_.pre_bad) return 0;
    if (code_err != rhs_.code_err) return 0;
    if (status != rhs_.status) return 0;
    if (len != rhs_.len) return 0;
    if (etype != rhs_.etype) return 0;
    if (cast != rhs_.cast) return 0;
    if (vlan != rhs_.vlan) return 0;
    if (pause != rhs_.pause) return 0;
    if (quanta != rhs_.quanta) return 0;
    if (fcols != rhs_.fcols) return 0;
    if (frl != rhs_.frl) return 0;
    if (frr != rhs_.frr) return 0;
    if (fseen != rhs_.fseen) return 0;
    if (fend != rhs_.fend) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(xgmii_transaction rhs_);
    if (kind != rhs_.kind) return 0;
    if (bytes.size() != rhs_.bytes.size()) return 0;
    foreach (bytes[i]) if (bytes[i] != rhs_.bytes[i]) return 0;
    if (pre_bad != rhs_.pre_bad) return 0;
    if (code_err != rhs_.code_err) return 0;
    if (fcols != rhs_.fcols) return 0;
    if (frl != rhs_.frl) return 0;
    if (frr != rhs_.frr) return 0;
    return 1;
  endfunction

  function string qstr_bytes();
    string s = $sformatf("[%0d]{", bytes.size());
    foreach (bytes[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", bytes[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("XGMII{tag=%0d kind=0x%0h bytes=%s pre_bad=0x%0h code_err=0x%0h status=0x%0h len=0x%0h etype=0x%0h cast=0x%0h vlan=0x%0h pause=0x%0h quanta=0x%0h fcols=0x%0h frl=0x%0h frr=0x%0h fseen=0x%0h fend=0x%0h}", tag, kind, qstr_bytes(), pre_bad, code_err, status, len, etype, cast, vlan, pause, quanta, fcols, frl, frr, fseen, fend);
  endfunction
endclass
