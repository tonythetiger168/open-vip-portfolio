// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_transaction.svh -- XGMII transaction

class xgmii_transaction extends uvm_sequence_item;
  `uvm_object_utils(xgmii_transaction)

  rand bit [31:0] txd;
  rand bit [3:0] txc;
  bit [31:0] rxd_o;
  bit [3:0] rxc_o;
  bit [31:0] tag;

  function new(string name = "xgmii_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    xgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    txd = rhs_.txd;
    txc = rhs_.txc;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    xgmii_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           txd == rhs_.txd &&
           txc == rhs_.txc;
  endfunction

  function string convert2string();
    return $sformatf("XGMII{tag=%0h txd=0x%0h txc=0x%0h}", tag, txd, txc);
  endfunction
endclass
