// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_coverage.svh -- XGMII functional coverage

class xgmii_coverage extends uvm_subscriber #(xgmii_transaction);
  `uvm_component_utils(xgmii_coverage)
  xgmii_config cfg;
  xgmii_transaction tr;

  covergroup xgmii_cg;
    cp_kind   : coverpoint tr.kind { bins k[] = {XGMII_FRAME, XGMII_FAULT}; }
    cp_status : coverpoint tr.status iff (tr.kind == XGMII_FRAME);
    cp_cast   : coverpoint tr.cast iff (tr.kind == XGMII_FRAME && tr.status inside {0, 7}) { bins u = {1}; bins m = {2}; bins b = {3}; }
    cp_vlan   : coverpoint tr.vlan iff (tr.kind == XGMII_FRAME && tr.status == 0);
    cp_pause  : coverpoint tr.pause iff (tr.kind == XGMII_FRAME && tr.status == 0);
    cp_type   : coverpoint (tr.etype > 1500) iff (tr.kind == XGMII_FRAME && tr.status == 0);
    cp_len    : coverpoint tr.len iff (tr.kind == XGMII_FRAME && tr.status == 0) {
                  bins min_ = {64}; bins short_ = {[65:127]}; bins mid = {[128:1023]}; bins long_ = {[1024:1517]};
                  bins max_ = {1518}; bins tag_max = {[1519:1522]}; }
    cp_term  : coverpoint ((tr.bytes.size() + 8 + tr.code_err) % 4) iff (tr.kind == XGMII_FRAME && !tr.pre_bad) { bins lane[] = {[0:3]}; }
    cp_fault : coverpoint tr.fseen iff (tr.kind == XGMII_FAULT) { bins none = {0}; bins local_ = {1}; bins remote = {2}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    xgmii_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(xgmii_config)::get(this, "", "cfg", cfg))
      cfg = xgmii_config::type_id::create("cfg");
  endfunction

  function void write(xgmii_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    xgmii_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("XGMII coverage: %0.1f%%", xgmii_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
