// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_coverage.svh -- XGMII functional coverage

class xgmii_coverage extends uvm_subscriber #(xgmii_transaction);
  `uvm_component_utils(xgmii_coverage)
  xgmii_config cfg;
  xgmii_transaction tr;

  covergroup xgmii_cg;
    coverpoint tr.txd;
    coverpoint tr.txc;
  endgroup

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    void'(uvm_config_db#(xgmii_config)::get(this, "*", "cfg", cfg));
    xgmii_cg = new();
  endfunction

  function void write(xgmii_transaction t);
    if (cfg != null && !cfg.coverage_enable) return;
    tr = t;
    xgmii_cg.sample();
  endfunction
endclass
