// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_coverage.svh -- XGMII functional coverage

class xgmii_coverage extends uvm_subscriber #(xgmii_transaction);
  `uvm_component_utils(xgmii_coverage)
  xgmii_config cfg;
  xgmii_transaction tr;

  covergroup xgmii_cg;
    cp_len : coverpoint tr.bytes.size() { bins min_ = {[64:70]}; bins mid = {[71:100]}; bins long_ = {[101:$]}; }
    cp_err : coverpoint tr.inject_err;
    cp_end : coverpoint tr.bytes.size() % 4;   // lane of the Terminate character
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    xgmii_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(xgmii_config)::get(this, "", "cfg", cfg))
      cfg = xgmii_config::type_id::create("cfg");
  endfunction

  function void write(xgmii_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    xgmii_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("XGMII coverage: %0.1f%%", xgmii_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
