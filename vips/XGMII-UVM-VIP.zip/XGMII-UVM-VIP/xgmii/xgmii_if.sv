// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_if.sv -- XGMII interface

interface xgmii_if (input logic clk);
  logic rst_n;

  logic [31:0] txd;
  logic [3:0] txc;
  logic [31:0] rxd;
  logic [3:0] rxc;

  modport DUT (input clk, rst_n, txd, txc, output rxd, rxc);
  modport DRV (input clk, rst_n, rxd, rxc, output txd, txc);
  modport MON (input clk, rst_n, txd, txc, rxd, rxc);

  clocking drv_cb @(posedge clk);
    input rst_n, txd, txc, rxd, rxc;
    output txd, txc;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, txd, txc, rxd, rxc;
  endclocking
endinterface
