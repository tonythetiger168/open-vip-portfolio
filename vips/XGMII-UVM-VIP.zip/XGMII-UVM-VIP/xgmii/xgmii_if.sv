// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_if.sv -- XGMII interface

interface xgmii_if (input logic clk);
  logic rst_n;

  logic [47:0] station;
  logic promisc;
  logic mcast_en;
  logic [31:0] rxd;
  logic [3:0] rxc;
  logic fr_done;
  logic [2:0] fr_status;
  logic [15:0] fr_len;
  logic [15:0] fr_etype;
  logic [1:0] fr_cast;
  logic fr_vlan;
  logic pause_valid;
  logic [15:0] pause_quanta;
  logic local_fault;
  logic remote_fault;

  modport DUT (input clk, rst_n, input station, input promisc, input mcast_en, input rxd, input rxc, output fr_done, output fr_status, output fr_len, output fr_etype, output fr_cast, output fr_vlan, output pause_valid, output pause_quanta, output local_fault, output remote_fault);
  modport MON (input clk, rst_n, station, promisc, mcast_en, rxd, rxc, fr_done, fr_status, fr_len, fr_etype, fr_cast, fr_vlan, pause_valid, pause_quanta, local_fault, remote_fault);

  clocking drv_cb @(posedge clk);
    input rst_n, fr_done, fr_status, fr_len, fr_etype, fr_cast, fr_vlan, pause_valid, pause_quanta, local_fault, remote_fault;
    inout station, promisc, mcast_en, rxd, rxc;   // driven by the agent, sampled back
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, station, promisc, mcast_en, rxd, rxc, fr_done, fr_status, fr_len, fr_etype, fr_cast, fr_vlan, pause_valid, pause_quanta, local_fault, remote_fault;
  endclocking
endinterface
