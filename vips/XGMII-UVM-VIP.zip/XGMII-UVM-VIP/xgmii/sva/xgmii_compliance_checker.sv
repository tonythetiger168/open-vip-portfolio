// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_compliance_checker.sv -- XGMII concurrent assertion checks (bindable)

module xgmii_compliance_checker
  (input logic clk, input logic rst_n, input [31:0] txd, input [3:0] txc, input [31:0] rxd, input [3:0] rxc);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({rxd, rxc}))
    else $error("XGMII: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> rxd == '0)
    else $error("XGMII: output not in reset value");
  assert property (@(posedge clk) disable iff (!rst_n) rxd == $past(txd))
    else $error("XGMII: loopback data mismatch");
  cover property (@(posedge clk) disable iff (!rst_n) (rxd != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (rxc != 4'h0));
endmodule
