// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_compliance_checker.sv -- XGMII concurrent assertion checks (bindable)

module xgmii_compliance_checker
  (input logic clk, input logic rst_n, input logic [47:0] station, input logic promisc, input logic mcast_en, input logic [31:0] rxd, input logic [3:0] rxc, input logic fr_done, input logic [2:0] fr_status, input logic [15:0] fr_len, input logic [15:0] fr_etype, input logic [1:0] fr_cast, input logic fr_vlan, input logic pause_valid, input logic [15:0] pause_quanta, input logic local_fault, input logic remote_fault);

  // a frame result is a one-clock pulse; PAUSE only on a good frame
  assert property (@(posedge clk) disable iff (!rst_n) fr_done |=> !fr_done)
    else $error("MAC: fr_done longer than one clock");
  assert property (@(posedge clk) disable iff (!rst_n) pause_valid |-> fr_done && fr_status == 3'd0)
    else $error("MAC: pause_valid without a good frame");
  // a good frame is at least 64 bytes and at most 1522
  assert property (@(posedge clk) disable iff (!rst_n) fr_done && fr_status == 3'd0 |-> fr_len >= 16'd64 && fr_len <= 16'd1522)
    else $error("MAC: good frame outside 64..1522 bytes");
  assert property (@(posedge clk) disable iff (!rst_n) fr_done && fr_status == 3'd4 |-> fr_len < 16'd64)
    else $error("MAC: runt status on a frame of 64 bytes or more");
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({fr_done, fr_status, pause_valid}))
    else $error("MAC: X on frame outputs");
  cover property (@(posedge clk) disable iff (!rst_n) pause_valid);
  cover property (@(posedge clk) disable iff (!rst_n) fr_done && fr_status == 3'd3);

  assert property (@(posedge clk) disable iff (!rst_n) !(local_fault && remote_fault))
    else $error("XGMII: local and remote fault at once");
  // a fault is only set by a Sequence ordered set
  assert property (@(posedge clk) disable iff (!rst_n) $rose(local_fault) |-> $past(rxc == 4'b0001 && rxd == 32'h0100_009C))
    else $error("XGMII: local fault without a local fault sequence");
  assert property (@(posedge clk) disable iff (!rst_n) $rose(remote_fault) |-> $past(rxc == 4'b0001 && rxd == 32'h0200_009C))
    else $error("XGMII: remote fault without a remote fault sequence");
  // frame result two clocks after the Terminate column
  assert property (@(posedge clk) disable iff (!rst_n) fr_done |-> $past(rxc != 4'h0, 2))
    else $error("XGMII: fr_done without a control column");
  cover property (@(posedge clk) disable iff (!rst_n) $rose(local_fault));
  cover property (@(posedge clk) disable iff (!rst_n) $rose(remote_fault));
  cover property (@(posedge clk) disable iff (!rst_n) $fell(local_fault));
endmodule
