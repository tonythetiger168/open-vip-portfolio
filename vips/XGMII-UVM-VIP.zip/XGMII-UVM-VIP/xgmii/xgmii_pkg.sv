// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// xgmii_pkg.sv -- XGMII UVM VIP package

package xgmii_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import xgmii_defs_pkg::*;
  export xgmii_defs_pkg::*;

  `include "xgmii_transaction.svh"
  `include "xgmii_config.svh"
  `include "xgmii_sequencer.svh"
  `include "xgmii_driver.svh"
  `include "xgmii_monitor.svh"
  `include "xgmii_agent.svh"
  `include "xgmii_sequences.svh"
  `include "xgmii_checker.svh"
  `include "xgmii_coverage.svh"
endpackage
