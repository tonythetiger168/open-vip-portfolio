// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// top_tb.sv -- RapidIO testbench top with a functional RapidIO DUT model

`ifndef RapidIO_TB_SV
`define RapidIO_TB_SV
`include "uvm_macros.svh"
import uvm_pkg::*;
import common_pkg::*;
import rapidio_defs_pkg::*;
import rapidio_pkg::*;
import rapidio_env_pkg::*;
import rapidio_test_pkg::*;

module top_tb;
  logic clk = 0;
  always #5ns clk = ~clk;

  rapidio_if vif(clk);

  initial begin
    vif.rst_n = 0;
    #100ns;
    vif.rst_n = 1;
  end

  // DUT model: plain ports (flattened by smoke/flatten.py for L1b)
  rapidio_model u_dut (
    .clk(vif.clk), .rst_n(vif.rst_n),
    .in_data(vif.in_data),
    .in_soc(vif.in_soc),
    .in_valid(vif.in_valid),
    .in_prio(vif.in_prio),
    .out_data(vif.out_data),
    .out_soc(vif.out_soc),
    .out_valid(vif.out_valid),
    .out_prio(vif.out_prio)
  );

  // Concurrent protocol checks
  rapidio_compliance_checker u_chk (
    .clk(vif.clk), .rst_n(vif.rst_n), .in_data(vif.in_data), .in_soc(vif.in_soc), .in_valid(vif.in_valid), .in_prio(vif.in_prio), .out_data(vif.out_data), .out_soc(vif.out_soc), .out_valid(vif.out_valid), .out_prio(vif.out_prio)
  );

  initial begin
    uvm_config_db#(virtual rapidio_if)::set(null, "*", "vif", vif);
    run_test();
  end
endmodule

module rapidio_model (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [31:0] in_data,
  input  logic        in_soc,
  input  logic        in_valid,
  input  logic [2:0]  in_prio,
  output logic [31:0] out_data,
  output logic        out_soc,
  output logic        out_valid,
  output logic [2:0]  out_prio
);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      out_data <= '0;
      out_soc  <= 1'b0;
      out_valid<= 1'b0;
      out_prio <= '0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        out_data <= in_data;
        out_soc  <= in_soc;
        out_prio <= in_prio;
      end
    end
  end
endmodule
`endif
