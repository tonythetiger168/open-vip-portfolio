// SPDX-License-Identifier: Apache-2.0
// Copyright (c) 2026 Functional smoke testbench (RapidIO symbol loopback)
`timescale 1ns/1ps
//
// Self-checking functional smoke for the flattened rapidio_model DUT.
// Directed protocol stimulus + response checks; prints FUNC_PASS/FUNC_FAIL.

module smoke_func_tb;
`ifdef VIP_SMOKE_FLATTENED
  int checks = 0;
  int fails  = 0;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic [31:0] in_data = '0;
  logic in_soc = 1'b0;
  logic in_valid = 1'b0;
  logic [2:0]  in_prio = '0;
  wire  [31:0] out_data;
  wire  out_soc;
  wire  out_valid;
  wire  [2:0]  out_prio;

  always #5 clk = ~clk;

  rapidio_model u_dut (
    .clk(clk), .rst_n(rst_n),
    .in_data(in_data), .in_soc(in_soc),
    .in_valid(in_valid), .in_prio(in_prio),
    .out_data(out_data), .out_soc(out_soc),
    .out_valid(out_valid), .out_prio(out_prio)
  );

  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin fails++; $display("  [FAIL] %s", msg); end
  endtask

  task automatic step;
    @(posedge clk); #1;
  endtask

  logic [31:0] strm [0:3];
  initial begin
    strm[0]=32'h9CBCBCBC; strm[1]=32'h1E1E1E1E; strm[2]=32'h00F0F0F0; strm[3]=32'h5A5A5A5A;
    repeat (8) step();
    chk(out_valid === 1'b0, "out_valid quiet out of reset");
    @(negedge clk); rst_n = 1'b1;
    repeat (4) step();

    repeat (3) begin step(); chk(out_valid === 1'b0, "out_valid low without input"); end

    // send 4 symbols with control and priority
    for (int i = 0; i < 4; i++) begin
      @(negedge clk);
      in_data = strm[i]; in_valid = 1;
      in_soc = (i == 0); in_prio = i[2:0];
      step();
      chk(out_valid === 1'b1, "symbol forwarded");
      chk(out_data === strm[i], "symbol data integrity");
      chk(out_soc === (i == 0), "start-of-control passthrough");
      chk(out_prio === i[2:0], "priority passthrough");
    end
    @(negedge clk); in_valid = 0;
    step();
    chk(out_valid === 1'b0, "out_valid drops after burst");

    if (fails == 0) $display("FUNC_PASS checks=%0d", checks);
    else            $display("FUNC_FAIL checks=%0d fails=%0d", checks, fails);
    $finish;
  end

  initial begin
    #200000;
    $display("FUNC_FAIL timeout");
    $finish;
  end
`endif
endmodule
