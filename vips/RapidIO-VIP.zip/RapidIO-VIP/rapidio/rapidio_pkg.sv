// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rapidio_pkg.sv -- RapidIO UVM VIP package

package rapidio_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import rapidio_defs_pkg::*;
  export rapidio_defs_pkg::*;

  `include "rapidio_transaction.svh"
  `include "rapidio_config.svh"
  `include "rapidio_sequencer.svh"
  `include "rapidio_driver.svh"
  `include "rapidio_monitor.svh"
  `include "rapidio_agent.svh"
  `include "rapidio_sequences.svh"
  `include "rapidio_checker.svh"
  `include "rapidio_coverage.svh"
endpackage
