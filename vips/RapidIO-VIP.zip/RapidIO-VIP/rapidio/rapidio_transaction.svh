// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rapidio_transaction.svh -- RapidIO transaction

class rapidio_transaction extends uvm_sequence_item;
  `uvm_object_utils(rapidio_transaction)

  // request (driven by the agent)
  rand bit [2:0] prio;
  bit [31:0] words[$];
  // response (returned by the DUT)
  bit [2:0] out_prio;
  bit [31:0] out_words[$];
  bit out_soc_ok;
  // bookkeeping (not compared)
  rand bit [4:0] nwords;
  rand bit [31:0] seed;
  int unsigned tag;   // sequence number (driver/monitor order)


  constraint c_len { nwords inside {[1:17]}; }   // header + up to 256 bytes / 16 words
  constraint c_prio { prio inside {[0:3]}; }      // physical-layer priorities 0..3

  function new(string name = "rapidio_transaction"); super.new(name); endfunction

  function void fill_words(int unsigned n);
    bit [31:0] x = seed | 32'h1;
    words.delete();
    for (int unsigned i = 0; i < n; i++) begin
      bit [31:0] v;
      for (int k = 0; k < 1; k++) begin
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        v = (v << 32) | 32'(x);
      end
      words.push_back(v);
    end
  endfunction

  function void post_randomize();
    fill_words(nwords);
  endfunction

  function void do_copy(uvm_object rhs);
    rapidio_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    prio = rhs_.prio;
    words = rhs_.words;
    out_prio = rhs_.out_prio;
    out_words = rhs_.out_words;
    out_soc_ok = rhs_.out_soc_ok;
    nwords = rhs_.nwords;
    seed = rhs_.seed;
    tag = rhs_.tag;
  endfunction

  // request and response fields
  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    rapidio_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    if (prio != rhs_.prio) return 0;
    if (words.size() != rhs_.words.size()) return 0;
    foreach (words[i]) if (words[i] != rhs_.words[i]) return 0;
    if (out_prio != rhs_.out_prio) return 0;
    if (out_words.size() != rhs_.out_words.size()) return 0;
    foreach (out_words[i]) if (out_words[i] != rhs_.out_words[i]) return 0;
    if (out_soc_ok != rhs_.out_soc_ok) return 0;
    return 1;
  endfunction

  // request fields only (driver view vs monitor view when the driver does
  // not see the DUT response)
  function bit req_equal(rapidio_transaction rhs_);
    if (prio != rhs_.prio) return 0;
    if (words.size() != rhs_.words.size()) return 0;
    foreach (words[i]) if (words[i] != rhs_.words[i]) return 0;
    return 1;
  endfunction

  function string qstr_words();
    string s = $sformatf("[%0d]{", words.size());
    foreach (words[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", words[i])};
    end
    return {s, " }"};
  endfunction

  function string qstr_out_words();
    string s = $sformatf("[%0d]{", out_words.size());
    foreach (out_words[i]) begin
      if (i == 8) begin s = {s, " ..."}; break; end
      s = {s, $sformatf(" %0h", out_words[i])};
    end
    return {s, " }"};
  endfunction

  function string convert2string();
    return $sformatf("RapidIO{tag=%0d prio=0x%0h words=%s out_prio=0x%0h out_words=%s out_soc_ok=0x%0h}", tag, prio, qstr_words(), out_prio, qstr_out_words(), out_soc_ok);
  endfunction
endclass
