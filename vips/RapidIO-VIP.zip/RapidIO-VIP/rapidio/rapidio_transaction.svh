// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rapidio_transaction.svh -- RapidIO transaction

class rapidio_transaction extends uvm_sequence_item;
  `uvm_object_utils(rapidio_transaction)

  rand bit [31:0] in_data;
  rand bit in_soc;
  rand bit in_valid;
  rand bit [2:0] in_prio;
  bit [31:0] out_data_o;
  bit out_soc_o;
  bit out_valid_o;
  bit [2:0] out_prio_o;
  bit [31:0] tag;

  function new(string name = "rapidio_transaction"); super.new(name); endfunction

  function void do_copy(uvm_object rhs);
    rapidio_transaction rhs_;
    if (!$cast(rhs_, rhs)) `uvm_fatal("COPY", "cast failed")
    super.do_copy(rhs);
    in_data = rhs_.in_data;
    in_soc = rhs_.in_soc;
    in_valid = rhs_.in_valid;
    in_prio = rhs_.in_prio;
    tag = rhs_.tag;
  endfunction

  function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    rapidio_transaction rhs_;
    if (!$cast(rhs_, rhs)) return 0;
    return super.do_compare(rhs, comparer) &&
           in_data == rhs_.in_data &&
           in_soc == rhs_.in_soc &&
           in_valid == rhs_.in_valid &&
           in_prio == rhs_.in_prio;
  endfunction

  function string convert2string();
    return $sformatf("RapidIO{tag=%0h in_data=0x%0h in_soc=0x%0h in_valid=0x%0h in_prio=0x%0h}", tag, in_data, in_soc, in_valid, in_prio);
  endfunction
endclass
