// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rapidio_if.sv -- RapidIO interface

interface rapidio_if (input logic clk);
  logic rst_n;

  logic [31:0] in_data;
  logic in_soc;
  logic in_valid;
  logic [2:0] in_prio;
  logic [31:0] out_data;
  logic out_soc;
  logic out_valid;
  logic [2:0] out_prio;

  modport DUT (input clk, rst_n, in_data, in_soc, in_valid, in_prio, output out_data, out_soc, out_valid, out_prio);
  modport DRV (input clk, rst_n, out_data, out_soc, out_valid, out_prio, output in_data, in_soc, in_valid, in_prio);
  modport MON (input clk, rst_n, in_data, in_soc, in_valid, in_prio, out_data, out_soc, out_valid, out_prio);

  clocking drv_cb @(posedge clk);
    input rst_n, in_data, in_soc, in_valid, in_prio, out_data, out_soc, out_valid, out_prio;
    output in_data, in_soc, in_valid, in_prio;
  endclocking

  clocking mon_cb @(posedge clk);
    input rst_n, in_data, in_soc, in_valid, in_prio, out_data, out_soc, out_valid, out_prio;
  endclocking
endinterface
