// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rapidio_sequences.svh -- RapidIO sequences

// Random traffic: cfg.num_items constrained-random items.
class rapidio_base_sequence extends uvm_sequence #(rapidio_transaction);
  `uvm_object_utils(rapidio_base_sequence)
  rapidio_config cfg;

  function new(string name = "rapidio_base_sequence"); super.new(name); endfunction

  task body();
    int n = (cfg != null) ? cfg.num_items : 32;
    repeat (n) begin

      req = rapidio_transaction::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RANDFAIL", "rapidio_transaction randomize() failed")

      finish_item(req);
    end
  endtask
endclass

// Directed traffic: every transfer type and the corner cases of the DUT model.
class rapidio_directed_sequence extends uvm_sequence #(rapidio_transaction);
  `uvm_object_utils(rapidio_directed_sequence)
  rapidio_config cfg;

  function new(string name = "rapidio_directed_sequence"); super.new(name); endfunction

  // new item with every field at its default (no randomize() needed)
  function rapidio_transaction item();
    item = rapidio_transaction::type_id::create("req");
  endfunction

  task send(rapidio_transaction t);
    start_item(t);
    finish_item(t);
  endtask

  task body();
    rapidio_transaction t;
    for (int p = 0; p < 4; p++) begin
      t = item(); t.prio = p; t.seed = 32'h900 + p; t.fill_words(p == 3 ? 17 : p + 1); send(t);
    end
    t = item(); t.prio = 2; t.words = '{32'h0, 32'hFFFF_FFFF, 32'h8000_0001}; send(t);
  endtask
endclass
