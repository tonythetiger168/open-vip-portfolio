// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rapidio_compliance_checker.sv -- RapidIO concurrent assertion checks (bindable)

module rapidio_compliance_checker
  (input logic clk, input logic rst_n, input [31:0] in_data, input in_soc, input in_valid, input [2:0] in_prio, input [31:0] out_data, input out_soc, input out_valid, input [2:0] out_prio);

  // outputs never X after reset
  assert property (@(posedge clk) disable iff (!rst_n) !$isunknown({out_data, out_soc, out_valid, out_prio}))
    else $error("RapidIO: X on outputs");
  // outputs held in reset until rst_n release
  assert property (@(posedge clk) disable iff (1'b0) !rst_n |-> out_data == '0)
    else $error("RapidIO: output not in reset value");
  // out_valid mirrors in_valid
  assert property (@(posedge clk) disable iff (!rst_n) out_valid == $past(in_valid))
    else $error("RapidIO: valid mismatch");
  cover property (@(posedge clk) disable iff (!rst_n) (out_data != '0));
  cover property (@(posedge clk) disable iff (!rst_n) (out_soc == 1'b1));
endmodule
