// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rapidio_coverage.svh -- RapidIO functional coverage

class rapidio_coverage extends uvm_subscriber #(rapidio_transaction);
  `uvm_component_utils(rapidio_coverage)
  rapidio_config cfg;
  rapidio_transaction tr;

  covergroup rapidio_cg;
    cp_prio : coverpoint tr.prio { bins p[] = {[0:3]}; }
    cp_len  : coverpoint tr.words.size() { bins one = {1}; bins short_ = {[2:8]}; bins long_ = {[9:17]}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    rapidio_cg = new();
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(rapidio_config)::get(this, "", "cfg", cfg))
      cfg = rapidio_config::type_id::create("cfg");
  endfunction

  function void write(rapidio_transaction t);
    if (!cfg.coverage_enable) return;
    tr = t;
    rapidio_cg.sample();
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info("COV", $sformatf("RapidIO coverage: %0.1f%%", rapidio_cg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass
