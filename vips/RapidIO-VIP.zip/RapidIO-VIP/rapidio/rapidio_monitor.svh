// Copyright 2026 VIP Portfolio Contributors
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// rapidio_monitor.svh -- RapidIO monitor: input packets (in_soc .. idle) paired in order with output packets

class rapidio_monitor extends uvm_monitor;
  `uvm_component_utils(rapidio_monitor)

  virtual rapidio_if vif;
  uvm_analysis_port #(rapidio_transaction) ap;
  rapidio_config cfg;
  int unsigned n_obs = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    if (!uvm_config_db#(virtual rapidio_if)::get(this, "", "vif", vif))
      `uvm_fatal("NOVIF", "rapidio: virtual interface not set")
    if (!uvm_config_db#(rapidio_config)::get(this, "", "cfg", cfg))
      cfg = rapidio_config::type_id::create("cfg");
  endfunction

  task run_phase(uvm_phase phase);
    wait (vif.rst_n === 1'b1);
    begin
      rapidio_transaction in_q[$], cur_in, cur_out;
      forever begin
        @(vif.mon_cb);
        // egress first: the output side lags by one clock
        if (vif.mon_cb.out_valid) begin
          if (vif.mon_cb.out_soc || cur_out == null) begin
            if (cur_out != null) begin publish(cur_out); cur_out = null; end
            if (in_q.size() == 0) `uvm_error("MON", "RapidIO output word with no input packet")
            else begin
              cur_out = in_q.pop_front();
              cur_out.out_prio = vif.mon_cb.out_prio;
              cur_out.out_soc_ok = vif.mon_cb.out_soc;
            end
          end
          if (cur_out != null) begin
            cur_out.out_words.push_back(vif.mon_cb.out_data);
            if (vif.mon_cb.out_prio != cur_out.out_prio) cur_out.out_soc_ok = 0;
          end
        end else if (cur_out != null) begin
          publish(cur_out);
          cur_out = null;
        end
        if (vif.mon_cb.in_valid) begin
          if (vif.mon_cb.in_soc || cur_in == null) begin
            cur_in = rapidio_transaction::type_id::create("t");
            cur_in.prio = vif.mon_cb.in_prio;
            in_q.push_back(cur_in);
          end
          cur_in.words.push_back(vif.mon_cb.in_data);
        end else
          cur_in = null;
      end
    end
  endtask

  function void publish(rapidio_transaction t);
    t.tag = n_obs++;
    `uvm_info("MON", {"observed: ", t.convert2string()}, UVM_HIGH)
    ap.write(t);
  endfunction

endclass
